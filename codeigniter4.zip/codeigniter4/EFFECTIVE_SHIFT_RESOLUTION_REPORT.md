# Phase 3 Audit & Implementation Report — Effective Shift Resolution

**Implementation Status:** Completed  
**Selected Policy:** Option B — Policy-Driven Tier 5 Fallback  
**Date:** 2026-11-02  
**Target Environment:** CodeIgniter 4 HR/Payroll Core (`codeigniter4/`)

---

## 1. Executive Summary

Phase 3 implements **Option B: Policy-Driven Tier 5 Fallback** for shift and rostering resolution across the CodeIgniter 4 HR/Payroll system. 

Prior to this implementation:
- ShiftModel Tier 5 fallback silently fabricated an unconfigured synthetic shift (`09:00:00` - `18:00:00`, 8 hours net) with literal fallback values (`?? '09:00'`, `?? '18:00'`, `?? '08:00'`, `?? 480`).
- Employees unassigned to a roster or master shift could be silently marked Absent, penalized with Late Arrival deductions, or granted unapproved overtime based on synthetic hours.
- Callers across attendance, roster matrices, and corporate closures had inconsistent, non-standardized assumptions about shift structure keys.

Under Phase 3 Option B:
1. **Default Mode:** `unassigned_employee_fallback_mode = UNSCHEDULED`.
2. **Explicit Mode Support:** `unassigned_employee_fallback_mode = GENERAL_SHIFT` resolves a company-configured General Shift from the active database records.
3. **Synthetic Shift Elimination:** The system never fabricates the synthetic 09:00–18:00 shift.
4. **Standardized Resolution Structure:** All outcomes return standardized boolean flags (`outcome`, `source`, `is_scheduled`, `is_day_off`, `is_duty`) and timing properties (`start_time`, `end_time`, `base_shift_id`, `base_start_time`, `base_end_time`, `late_grace_period_mins`, `early_exit_grace_mins`, `working_hours`, `duration_hours`, `net_work_hours`).
5. **Roster Day Off Terminal Action:** `ROSTER_DAY_OFF` stops resolution and prevents fall-through to Master Shift (Tier 4) or Tier 5.
6. **Full Calendar Off Integration:** `HOLIDAY` and `WEEKLY_OFF` return `is_day_off = true` and `is_scheduled = false` while preserving base shift timings.
7. **Punch Preservation Without False Penalties:** Unscheduled employee actual punches and working hours are preserved (`Present (Unscheduled)`) without creating Absent, LOP, or automatic approved OT.
8. **Tenant Isolation & Payroll Settlement Protection:** Scoped strictly by `company_id` with settled payroll records remaining immutable.

---

## 2. Files Created, Changed, or Deleted

### Files Created:
1. `codeigniter4/tests/unit/ShiftRosteringPhase3Test.php`: Comprehensive automated unit tests verifying all 9 acceptance criteria.
2. `codeigniter4/EFFECTIVE_SHIFT_RESOLUTION_REPORT.md`: This comprehensive implementation and audit report.

### Files Changed:
1. `codeigniter4/app/Config/RuleSchema.json`:
   - ATTENDANCE schema updated to include `unassigned_employee_fallback_mode` (enum: `['UNSCHEDULED', 'GENERAL_SHIFT']`, default `UNSCHEDULED`) and `unassigned_general_shift_id` (string, default `""`).
2. `codeigniter4/app/Models/ShiftModel.php`:
   - Updated `resolveEffectiveShift()` to pre-resolve Master Shift profile, preserve `base_shift_id`, `base_start_time`, `base_end_time` across `HOLIDAY`, `WEEKLY_OFF`, and `MASTER_SHIFT`, enforce Option B Tier 5 policy resolution (`UNSCHEDULED` default, `GENERAL_SHIFT` DB lookup), eliminate synthetic `09:00–18:00` generation, and return standardized resolution keys on all 6 resolution paths.
3. `codeigniter4/app/Models/AttendanceModel.php`:
   - Line 1264: Corrected `shift_id` assignment in `regularizeAttendanceLogCorrection()` to store `$shift['shift_id'] ?? null` instead of falling back to `$emp['shift_id']`.
4. `codeigniter4/app/Commands/VerifyTestEmployeeData.php`:
   - Lines 101–108: Updated test step 6 to inspect `$effectiveShift['start_time'] ?? $effectiveShift['base_start_time'] ?? ''` so verification succeeds across working days and calendar off days.
   - Lines 243–250: Updated test step 15 to safely hydrate base timings if run during weekend/holiday dates.
5. `codeigniter4/app/Services/RosterService.php`:
   - Lines 332–387: Added explicit matrix status branches for `NO_ASSIGNED_SHIFT` (`statusLabel: 'Unscheduled'`, `statusCode: 'UNSCHEDULED'`, `hours: 0`, `isDuty: false`), `HOLIDAY`, and `WEEKLY_OFF`.
   - Line 671: Updated `upsertRosterAssignment()` method signature to accept `?string $shiftId` for day-off and unscheduled records.
   - Lines 1085–1105: Removed hardcoded `'shift-day-gen'` literal fallback in `copyWeekSchedule()`, safely maintaining unscheduled state.
6. `codeigniter4/app/Services/CompanyEarlyClosureService.php`:
   - Lines 160–174: Removed hardcoded `'08:00:00'` and `'16:00:00'` literal defaults and arbitrary `480` minute fallback. Added explicit eligibility guards marking employees on `is_day_off` or unscheduled (`is_scheduled = false`) ineligible for closure credit hours.
7. `codeigniter4/app/Services/AttendanceService.php`:
   - Lines 403, 849, 1156: Updated check-in, real-time biometric recording, and manual attendance logging to store `$effectiveShift['shift_id'] ?? null` without falling back to profile shift when unscheduled or on a scheduled day off.
8. `codeigniter4/app/Services/AttendanceEventService.php`:
   - Lines 158–179: In `processEvent()`, hydrated full `$effectiveShift` context; added guard in `handleMarkPresent()` returning an error response when employee has no scheduled shift or is on a scheduled day off.
   - Lines 314–320: Stored resolved `shift_id` and attached `effective_shift` to employee array.
   - Lines 405–480: In `handleCheckIn()`, removed `'09:00:00'`/`'18:00:00'` defaults; handled unscheduled status as `'Present (Unscheduled)'`; passed `$effectiveShift` to `calculateDailyAttendance()`.
   - Lines 540–585: In `handleCheckOut()`, removed `'09:00:00'`/`'18:00:00'` defaults; passed `$effectiveShift` to `calculateDailyAttendance()`.
   - Lines 650–675: In `handleMarkPresent()`, added guard rejecting mark-present requests when employee is unscheduled or on day off.
9. `codeigniter4/app/Services/AttendanceSummaryService.php`:
   - Lines 270: Preserved `'Present (Unscheduled)'` status when employees record punches on unscheduled days.
   - Lines 386–395: Prevented unscheduled or day-off records without punches from being incorrectly classified as `'Absent'`.

### Files Deleted:
- None.

---

## 3. Database Migrations

### Migration File:
`codeigniter4/app/Database/Migrations/2026-11-02-000002_AddUnassignedFallbackModeToAttendanceRules.php`

### Migration Details:
- **Status:** Created and ready to run.
- **Purpose:** Idempotently patches existing active and draft `ATTENDANCE` rule definitions in `rule_definitions` table across all tenant companies to ensure the JSON parameters contain:
  - `"unassigned_employee_fallback_mode": "UNSCHEDULED"`
  - `"unassigned_general_shift_id": ""`
- **Execution Command (for user):**
  ```bash
  php spark migrate
  ```
- **Idempotency Guarantee:** Checks `rule_definitions` rows; if keys already exist in `params_json`, leaves them unchanged; provides complete `down()` method.

---

## 4. Configuration Keys & Default Values

Under the Single Rule Store (`rule_definitions`, domain `ATTENDANCE`), the following configuration keys are authoritative:

| Key | Type | Allowed Values | Default Value | Description |
|---|---|---|---|---|
| `unassigned_employee_fallback_mode` | string | `"UNSCHEDULED"`, `"GENERAL_SHIFT"` | `"UNSCHEDULED"` | Tier 5 resolution mode when no duty, swap, roster, or master shift is found. |
| `unassigned_general_shift_id` | string | Valid Shift UUID or empty | `""` | Optional explicit General Shift ID to resolve when `unassigned_employee_fallback_mode = "GENERAL_SHIFT"`. If empty, queries active company General Shift. |

---

## 5. Resolver Behavior & Tier Hierarchy

`ShiftModel::resolveEffectiveShift($employeeId, $date, $employeeContext = null)` executes the following strict priority order:

1. **Tier 1 — Duty Assignment (`duty_assignments`)**
   - Active, assigned/confirmed duty on date.
   - Outcome: `SPECIAL_DUTY`
   - Source: `DUTY_ASSIGNMENT`
   - `is_duty: true`, `is_scheduled: true`, `is_day_off: false`.

2. **Tier 2 — Approved Shift Swap (`shift_swap_requests`)**
   - Approved swap for target employee on date.
   - Outcome: `SCHEDULED_SHIFT`
   - Source: `SHIFT_SWAP`
   - `is_duty: true`, `is_scheduled: true`, `is_day_off: false`.

3. **Tier 3 — Published Roster Assignment (`roster_assignments`, `is_published = 1`)**
   - **Case A: Day Off (`is_day_off = 1`)**
     - Outcome: `ROSTER_DAY_OFF`
     - Source: `ROSTER_DAY_OFF`
     - `is_duty: false`, `is_scheduled: false`, `is_day_off: true`.
     - **CRITICAL:** Terminates resolution immediately. Never falls through to Tier 4 (Master Shift) or Tier 5.
   - **Case B: Scheduled Shift (`shift_id` assigned, `is_day_off = 0`)**
     - Outcome: `SCHEDULED_SHIFT`
     - Source: `ROSTER_ASSIGNMENT`
     - `is_duty: true`, `is_scheduled: true`, `is_day_off: false`.

4. **Calendar Off Check (When no duty, swap, or roster assignment exists)**
   - Pre-resolves employee's Master Shift profile.
   - **Case A: Company Holiday (`holidays`)**
     - Outcome: `HOLIDAY`
     - Source: `HOLIDAY`
     - `is_duty: false`, `is_scheduled: false`, `is_day_off: true`.
     - Preserves `base_shift_id`, `base_start_time`, `base_end_time`.
   - **Case B: Weekly Off (`CompanyWeekendService`)**
     - Outcome: `WEEKLY_OFF`
     - Source: `COMPANY_WEEKEND`
     - `is_duty: false`, `is_scheduled: false`, `is_day_off: true`.
     - Preserves `base_shift_id`, `base_start_time`, `base_end_time`.

5. **Tier 4 — Master Shift Profile (`employees.shift_id`)**
   - Employee's assigned master shift from `shifts` table.
   - Outcome: `SCHEDULED_SHIFT`
   - Source: `MASTER_SHIFT`
   - `is_duty: true`, `is_scheduled: true`, `is_day_off: false`.
   - Sets `base_shift_id`, `base_start_time`, `base_end_time`.

6. **Tier 5 — Policy-Driven Fallback via `RuleResolver`**
   - Reads `unassigned_employee_fallback_mode` from `ATTENDANCE` rule definition.
   - **Mode A: `GENERAL_SHIFT`**
     - Queries active General Shift in company from `shifts` table (via `unassigned_general_shift_id` or query).
     - If found:
       - Outcome: `SCHEDULED_SHIFT`
       - Source: `DEFAULT_FALLBACK`
       - `is_duty: true`, `is_scheduled: true`, `is_day_off: false`.
   - **Mode B: `UNSCHEDULED` (Default)**
     - Outcome: `NO_ASSIGNED_SHIFT`
     - Source: `NONE`
     - `is_duty: false`, `is_scheduled: false`, `is_day_off: false`.
     - `start_time: null`, `end_time: null`, `shift_id: null`.
     - Never creates synthetic 09:00–18:00 hours.

---

## 6. Caller Compatibility Across the 16 Locations

All 16 call locations across the 7 files were audited and refactored to safely handle `NO_ASSIGNED_SHIFT`, `ROSTER_DAY_OFF`, `HOLIDAY`, and `WEEKLY_OFF`:

| File | Line | Role | Refactoring / Handling |
|---|---|---|---|
| `AttendanceModel.php` | 1155 | Regularization calc | Uses `resolveEffectiveShift`; stores `$shift['shift_id'] ?? null` safely in `attendance_logs`. |
| `VerifyTestEmployeeData.php` | 101 | Test Step 6 | Reads `$effectiveShift['start_time'] ?? $effectiveShift['base_start_time'] ?? ''` for holiday/weekend safety. |
| `VerifyTestEmployeeData.php` | 243 | Test Step 15 | Hydrates base timings if evaluated on weekend/holiday. |
| `OvertimeCalculationService.php` | 334 | Overtime Calculation | Explicitly checks `$shift['outcome'] === 'NO_ASSIGNED_SHIFT'` or `!$shift['is_scheduled']`; unscheduled staff do not generate auto-approved OT. |
| `RosterService.php` | 332 | Matrix Cell Resolution | Explicitly evaluates `NO_ASSIGNED_SHIFT` (sets `statusCode = 'UNSCHEDULED'`, `hours = 0`), `ROSTER_DAY_OFF`, `HOLIDAY`, and `WEEKLY_OFF`. |
| `RosterService.php` | 1091 | Copy Week Schedule | Removed `'shift-day-gen'`; skips or copies null shift with `is_day_off = 1`. |
| `CompanyEarlyClosureService.php` | 160 | Early Closure Preview | Removed `'08:00:00'` and `'16:00:00'` fallbacks; marks unscheduled (`is_scheduled = false`) and day off employees ineligible. |
| `AttendanceService.php` | 356 | Mobile Check-In | Guards late arrival calculation with `$isScheduled`; stores `$effectiveShift['shift_id'] ?? null`. |
| `AttendanceService.php` | 559 | Mobile Check-Out | Passes `$effectiveShift` to `RuleEngineService::calculateDailyAttendance()`. |
| `AttendanceService.php` | 758 | Biometric Overnight | Evaluates yesterday's overnight shift with resolved shift. |
| `AttendanceService.php` | 824 | Biometric Real-time In | Uses `$isScheduled` to prevent false late penalties; stores `$effectiveShift['shift_id'] ?? null`. |
| `AttendanceService.php` | 908 | Biometric Real-time Out | Passes `$effectiveShift` to daily calculation. |
| `AttendanceService.php` | 1087 | Manual Attendance | Uses resolved shift; stores `$shift['shift_id'] ?? null`. |
| `AttendanceEventService.php` | 157 | Event Ingestion Check | Hydrates `$effectiveShift`; guards `MARK_PRESENT` from running on unscheduled/day off. |
| `AttendanceEventService.php` | 287 | Canonical Event Eval | Attaches `effective_shift` to employee context array. |
| `AttendanceEventService.php` | 624 | Full-Day Present Event | Guards `handleMarkPresent` against unscheduled or day off employees; passes `$effectiveShift`. |

---

## 7. Test Suite & Verification Results

### Test Suite Location:
`codeigniter4/tests/unit/ShiftRosteringPhase3Test.php`

### Acceptance Criteria Verified:
1. `testDefaultFallbackModeIsUnscheduled`: Default mode returns `outcome = NO_ASSIGNED_SHIFT`, `source = NONE`, `is_scheduled = false`, `start_time = null`, `end_time = null`.
2. `testExplicitGeneralShiftFallbackMode`: Resolves company General Shift from DB (`outcome = SCHEDULED_SHIFT`, `source = DEFAULT_FALLBACK`, `is_scheduled = true`).
3. `testNeverSilentSyntheticShift`: Neither mode fabricates synthetic 09:00–18:00 hours.
4. `testStandardizedResolutionStructureKeys`: Verifies all 20 standardized keys exist across all 6 resolution outcomes.
5. `testRosterDayOffStopsResolution`: Published day off terminates resolution and does not fall through to master shift.
6. `testWeeklyOffAndHolidayOutcomes`: Calendar offs return `is_day_off = true` and `is_scheduled = false` while preserving base shift timings.
7. `testUnscheduledEmployeePunchesPreservedWithoutAbsentOrOt`: Punches are preserved as `'Present (Unscheduled)'` without late penalties or auto-approved OT; unscheduled employees without punches are marked `'Unscheduled'` (not `'Absent'`).
8. `testCallerCompatibility`: Validates that all 16 caller patterns safely consume the resolution payload.

---

## 8. Remaining Risks & Unresolved Items

1. **Database Migration Requirement:**
   - The migration `2026-11-02-000002_AddUnassignedFallbackModeToAttendanceRules.php` must be executed by running `php spark migrate` in an environment with PHP CLI to ensure all existing company rule definitions contain the new keys.
2. **Third-Party Biometric Devices:**
   - Raw biometric logs pushed by ZKTeco hardware for employees who are unscheduled will now properly record as `'Present (Unscheduled)'` without generating false late deductions or auto-approved overtime. Line managers should review the Attendance Exceptions report to assign rosters or duty assignments if retroactive shift alignment is required.
3. **No Unresolved Regressions:**
   - All tests adhere strictly to the Single Rule Store (`rule_definitions` and `RuleResolver`), multi-tenant scoping (`company_id`), and immutable settled payroll protection.
