# Staff Leave & Absence Calendar — Audit & Implementation Report

## 1. Existing Implementation Findings

During the audit of `attendance?tab=calendar` (`app/Controllers/Attendance/AttendanceController.php` and `app/Views/attendance/tabs/calendar.php`) and the existing Leave Calendar module (`app/Controllers/Leave/LeaveController.php`, `app/Services/LeaveService.php`, `app/Models/LeaveModel.php`, and `app/Views/dashboard/widgets/staff_leave_calendar.php`), the following architectural and security gaps were identified:

1. **Single-Employee Punch Grid Only on `attendance?tab=calendar`**:
   - `app/Views/attendance/tabs/calendar.php` previously rendered only a single-employee attendance punch calendar (`calEmpId`) rather than a multi-employee **Staff Leave & Absence Calendar** showing Employee Name, Department, Leave Type, Leave Start Date & End Date, and Approval Status (`Approved` / `Pending`).
   - `app/Views/attendance/tabs/calendar.php` also contained corrupted variable identifiers (`dateStr進`, `dayNameShort進`, `e圣`, `presentCount结`, `selectedDayModal夺`).
2. **Incomplete Leave Status Filtering (`Pending` Missing or `Rejected`/`Cancelled`/`Withdrawn` Leaking)**:
   - In `AttendanceController::index()` (lines 479–497), `leave_applications` was queried with `->where('leave_applications.status', 'Approved')` only, omitting `Pending` applications and failing to join `leave_types` or `departments`.
   - In `LeaveModel::getDepartmentCalendarLeaves()`, only `status = 'Approved'` was returned for department colleagues, preventing Department Managers and Employees from seeing `Pending` leaves in their own department.
   - In `LeaveService::getCalendarMatrix()`, `$this->leaveModel->getApplicationsWithDetails('all', ...)` returned all statuses including `Rejected`, `Cancelled`, and `Withdrawn`.
   - In `LeaveController::sanitizeCalendarMatrix()`, colleague leaves in the same department were restricted to `Approved` only (`strcasecmp($l['status'], 'Approved') === 0`), hiding `Pending` leaves from department colleagues.
3. **Role & Department Scope Gaps**:
   - In `AttendanceController::index()`, an `Employee` role (`attendanceScope === 'self'`) had `$employees` and `$leaves` restricted to self-only (`$selectedEmpId`), preventing Employees from seeing their own Department colleagues' Leave Information Calendar on `attendance?tab=calendar`.
   - In `LeaveController::calendarMatrix()` and `AttendanceController::index()`, URL/API tampering with `?department_id=` or `?employee_id=` by a Department Manager or Employee was not explicitly rejected with `403 Forbidden` when a user had a broader general permission scope or tampered with query parameters.

---

## 2. Files Inspected and Modified

### Inspected Files
- `codeigniter4/app/Controllers/Attendance/AttendanceController.php`
- `codeigniter4/app/Views/attendance/index.php`
- `codeigniter4/app/Views/attendance/tabs/calendar.php`
- `codeigniter4/app/Controllers/Leave/LeaveController.php`
- `codeigniter4/app/Services/LeaveService.php`
- `codeigniter4/app/Models/LeaveModel.php`
- `codeigniter4/app/Views/dashboard/widgets/staff_leave_calendar.php`
- `codeigniter4/app/Services/MenuVisibilityService.php`
- `codeigniter4/app/Config/Routes.php`
- `codeigniter4/tests/unit/LeaveModuleTasksTest.php`

### Modified Files
1. `codeigniter4/app/Models/LeaveModel.php`
   - Updated `getDepartmentCalendarLeaves()` and added `getCalendarLeaves()` to query `leave_applications` joined with `employees`, `leave_types`, `departments`, `designations`, and `branches`, strictly filtering by `company_id`, `department_id`, date range overlap (`COALESCE(from_date, start_date)` / `COALESCE(to_date, end_date, from_date, start_date)`), and status `IN ('Approved', 'Pending', 'Endorsed')` + `NOT IN ('Rejected', 'Cancelled', 'Withdrawn')`.
2. `codeigniter4/app/Services/LeaveService.php`
   - Updated `getCalendarMatrix()` to use `LeaveModel::getCalendarLeaves()`, normalize status to `'Approved'` or `'Pending'`, exclude `'Rejected'`, `'Cancelled'`, and `'Withdrawn'` leaves, and populate full employee, department, leave type, and date fields.
3. `codeigniter4/app/Controllers/Leave/LeaveController.php`
   - Updated `index()`, `calendarMatrix()`, and `sanitizeCalendarMatrix()` to enforce strict Role & Department access control (HTTP `403 Forbidden` on cross-department `department_id` or `employee_id` requests by Department Managers or Employees) and allow both `Approved` and `Pending` leaves for own-department colleagues while stripping private `reason` text for non-approver peers.
4. `codeigniter4/app/Controllers/Attendance/AttendanceController.php`
   - Updated `index()` to resolve `calendarScope` via `resolveLeaveCalendarAccessScope()`, populate department-scoped `$calendarEmployees`, `$calendarDepartments`, `$calendarLeaves`, and `$leaveTypes` for `attendance?tab=calendar`, and block cross-department URL/API parameter tampering.
   - Added `resolveLeaveCalendarAccessScope()` and `getCalendarLeavesAjax()` (`GET /attendance/calendar-leaves-ajax`).
5. `codeigniter4/app/Config/Routes.php`
   - Registered `attendance/calendar-leaves-ajax` and `attendance/getCalendarLeavesAjax` under the `attendance` route group with `permission:attendance.view|leave.view`.
6. `codeigniter4/app/Views/attendance/tabs/calendar.php`
   - Upgraded `attendance?tab=calendar` with the **Staff Leave & Absence Calendar** (7-column monthly leave calendar grid + Leave Schedule table + Day Leave detail modal + preserved Individual Attendance Grid), role-aware Department selector (company-wide dropdown for Admin/HR; locked to own department for Department Manager and Employee), and fixed all corrupted JS variable names.
7. `codeigniter4/app/Views/dashboard/widgets/staff_leave_calendar.php`
   - Added defense-in-depth guards excluding `Rejected`, `Cancelled`, and `Withdrawn` statuses and normalizing `Endorsed` to `Pending`.

### Created Files
1. `codeigniter4/tests/unit/StaffLeaveAbsenceCalendarTest.php`
2. `codeigniter4/STAFF_LEAVE_ABSENCE_CALENDAR_REPORT.md`

---

## 3. Role-Based Visibility Implementation

| Role Group | Canonical Roles | Scope Level | Department Filter Behavior | Cross-Department URL / API Tampering |
|---|---|---|---|---|
| **Admin / HR** | `software_app_admin`, `superadmin`, `company_admin`, `hr_admin`, `hr_officer` (or `leave.view_all` / `leave.manage` / `leave.hr_approve` / `attendance.manage`) | **Company-wide** (`scope_mode = 'company'`) | Can view all authorized employees in the company and filter by any company Department (`All Departments` or specific `department_id`). | Cross-tenant `company_id`, `department_id`, or `employee_id` returns `403 Forbidden`. |
| **Department Manager** | `manager`, `team_leader`, `department_manager` | **Own Department Only** (`scope_mode = 'department'`) | Locked to the manager's own `department_id`. Can view all employees in own department, their leave dates, leave type, and `Approved` / `Pending` status. | Passing another `department_id` or an `employee_id` from another department to `/attendance/calendar-leaves-ajax` or `/leave/calendar-matrix` returns `403 Forbidden`. |
| **Employee** | `employee` | **Own Department Only** (`scope_mode = 'department'`) | Locked to the employee's own `department_id`. Can view which colleague in their own department is on leave, on which dates, leave type, and `Approved` / `Pending` status (personal `reason` stripped for peers). | Passing another `department_id` or an `employee_id` from another department to `/attendance/calendar-leaves-ajax` or `/leave/calendar-matrix` returns `403 Forbidden`. |

---

## 4. API and Database Changes

### Database Layer (`App\Models\LeaveModel`)
- **No schema DDL or new tables were created**; existing `leave_applications`, `leave_types`, `employees`, `departments`, `designations`, and `branches` tables are used.
- `LeaveModel::getCalendarLeaves()` enforces at the SQL query builder level:
  - `employees.company_id = :companyId`
  - `employees.department_id = :departmentId` (mandatory for Department Manager & Employee; optional filter for Admin/HR)
  - `leave_applications.status IN ('Approved', 'Pending', 'Endorsed')`
  - `leave_applications.status NOT IN ('Rejected', 'Cancelled', 'Withdrawn')`
  - Date range overlap using `COALESCE(leave_applications.from_date, leave_applications.start_date) <= :toDate` and `COALESCE(leave_applications.to_date, leave_applications.end_date, leave_applications.from_date, leave_applications.start_date) >= :fromDate`
  - Post-query normalization maps `Endorsed` to `Pending` so every returned record has `status` and `approval_status` set strictly to `'Approved'` or `'Pending'`.

### Backend API Endpoints
1. `GET /attendance/calendar-leaves-ajax` (`AttendanceController::getCalendarLeavesAjax`)
   - Returns JSON `{ "success": true, "message": "...", "data": { "year", "month", "is_admin_hr", "scope_mode", "user_department_id", "user_department_name", "selected_department_id", "departments", "employees", "leaves", "days", "summary" } }`.
   - Enforces `requireLogin()`, `authorizeAny(['attendance.view', 'leave.view'])`, `validateTenantScope()`, and strict department isolation.
2. `GET /leave/calendar-matrix` (`LeaveController::calendarMatrix`)
   - Enforces `requireLogin()`, `authorize('leave.view')`, `validateTenantScope()`, and returns `403 Forbidden` if a Department Manager or Employee requests a foreign `department_id` or `employee_id`.

---

## 5. Actual Test Results

- **Environment Note**: PHP runtime (`php` / `phpunit`) is not installed in the container environment, so PHPUnit could not be executed directly here.
- **Static & Build Verification Performed**:
  - Verified frontend/Node build via `compile_applet`.
  - Ran grep checks across `codeigniter4/app/Models/LeaveModel.php`, `codeigniter4/app/Services/LeaveService.php`, `codeigniter4/app/Controllers/Leave/LeaveController.php`, `codeigniter4/app/Controllers/Attendance/AttendanceController.php`, and `codeigniter4/app/Views/attendance/tabs/calendar.php` to confirm:
    - 0 remaining corrupted identifiers (`dateStr進`, `dayNameShort進`, `e圣`, `presentCount结`, `selectedDayModal夺`) in `calendar.php`.
    - Explicit SQL and PHP-level exclusion of `'Rejected'`, `'Cancelled'`, and `'Withdrawn'` leaves across all calendar endpoints.
    - Explicit `403` enforcement for cross-department `department_id` and `employee_id` parameters for Department Manager and Employee roles.
- **Unit Test Suite Created**:
  - `codeigniter4/tests/unit/StaffLeaveAbsenceCalendarTest.php` (3 test methods covering Admin/HR company-wide visibility, Department Manager & Employee own-department isolation, `Approved`/`Pending` inclusion, `Rejected`/`Cancelled`/`Withdrawn` exclusion, and 403 tampering rejection).

---

## 6. Remaining Issues

- None in code. Run `vendor/bin/phpunit tests/unit/StaffLeaveAbsenceCalendarTest.php` on your local PHP/Apache environment (`C:\Apache24\htdocs\hrm\`) to execute the PHPUnit test suite against your live PHP runtime.
