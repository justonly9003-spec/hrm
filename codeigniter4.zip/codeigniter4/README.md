# CodeIgniter 4 HRMS — Single Rule Store & Leave Module

## Overview
This repository contains the CodeIgniter 4 backend for the Enterprise HR/Payroll application. Business rules are governed authoritatively in `rule_definitions` via `App\Services\Rules\RuleResolver`.

---

## Live Database Regression Suite

To execute the live MariaDB/MySQL regression test suite:

```bash
# Ensure development MySQL environment is configured in .env or via phpunit.live.xml.dist
cd codeigniter4
php vendor/bin/phpunit -c phpunit.live.xml.dist
```

### Running Standard Unit & Integration Tests:
```bash
cd codeigniter4
php vendor/bin/phpunit
```

### Database Migration & Rollback Lifecycle:
```bash
# Fresh migration
php spark migrate

# Rollback all migrations (batch 0)
php spark migrate:rollback -b 0

# Re-migrate cleanly
php spark migrate
```

### Seeding Master Data & Rule Definitions:
```bash
# Seed initial company, employee, user, attendance, and leave types
php spark db:seed DatabaseSeeder

# Migrate legacy leave entitlements & policies into LEAVE rule_definitions
php spark rules:migrate-leave
```

---

## Verified Defects Fixed

1. **LeaveApplicationService Docblock Parse Error**: Fixed missing `/**` docblock opener before `getStandardDailyHours` at line 132.
2. **Leave Cancellation SQL Error**: Appended `false` escape flag to `->orderBy('CASE ... END', 'ASC', false)` preventing invalid escaping of SQL `END` keyword.
3. **Cross-Year Leave Balance Calculation**: Updated `getEmployeeBalance` and bulk workforce balance aggregation to query overlapping leave applications and sum only the days belonging to the target year from `year_split`.
4. **Monthly Manual Adjustment Cycle Collision**: Set `cycle_no = null` for manual adjustments to prevent collision with `idx_leave_tx_cycle_unique` on multiple adjustments in the same month, keeping `idempotency_key` as duplicate guard.
5. **Unpaid Leave (LWP) Seeding Defaults**: Configured `is_paid = 0`, `paid_percentage = 0`, and `days_per_year = 0` in `AttendanceAndLeaveSeeder` and `LeavePoliciesAndTypesSeeder`.
6. **Admin User Employee ID Collision in Seeder**: Handled unique `employee_id` constraint in `EmployeeAndUserSeeder` by setting `employee_id = null` for secondary admin accounts.
7. **Foreign Key Constraint on Migration Rollback**: Updated `dropIndexIfExists` in `2026-10-14-000006` and `2026-10-06-000001` migrations to preserve a single-column index on foreign key leading columns before dropping composite indexes.
8. **Batch Approval/Rejection Empty Validation**: Added early guard returning failure when `$applicationIds` array is empty in `batchApprove` and `batchReject`.
9. **Bonus Generation Authentication Check**: Moved user identity check before rule resolution in `BonusService::generateBonusBatch`.
