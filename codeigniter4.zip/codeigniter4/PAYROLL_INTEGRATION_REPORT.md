# Phase 9: Payroll Integration Implementation Report

## Executive Summary
Phase 9 integrates attendance, rostering, overtime, leaves, and final settlement into the authoritative single-source payroll calculation engine (`App\Services\PayrollService` and `App\Services\Overtime\OvertimeCalculationService`).

The implementation enforces the core invariant: **Payroll must NEVER pay from raw attendance, pending/unapproved OT, or duplicate records.** All business rules, multipliers, hourly rates, and divisors are read strictly through `App\Services\Rules\RuleResolver` without any hardcoded literal fallbacks.

---

## 1. Architectural Principles & Invariants

| Domain | Invariant / Business Rule | Implementation |
|---|---|---|
| **Scheduled Duty Hours** | Derived from published calendar rosters (`roster_assignments` where `is_published = 1`) or master shift on working days. | Preloaded in `buildBatchContext()`. If a published roster assignment exists for the date, its shift `working_hours` is used; off-days are 0.0 hrs. |
| **Actual Working Hours** | Derived strictly from approved/verified attendance logs (`attendance_logs`). | Preloaded in `buildBatchContext()`. Sums `working_hours` (or `net_hours`) where `status != 'Rejected'`. Raw unverified biometric events never feed directly into payroll. |
| **Approved Leave Treatment** | Approved paid leaves are fully compensated (0 LOP deduction). Approved unpaid leaves incur Loss of Pay. | Multi-month spanning and single-month leaves evaluated via `calculateUnpaidLeaveDaysInMonth()`. Paid percentage = 100% or `type_is_paid = 1` incurs 0 LOP. |
| **Off-Day Treatment** | Weekly off days and public holidays are fully paid calendar days with 0 LOP deduction. | If an employee works on a weekly off or holiday, duty assignment or attendance evaluates OT with `weekly_off_multiplier` or `holiday_multiplier`. |
| **Unapproved Absent Treatment** | Unapproved absent days (`status = 'Absent'` with no approved leave application) incur Loss of Pay (LOP) deduction. | Sourced from `attendance_logs` and preloaded into `$ctx['absent_days']`. Added to unpaid leave days for total LOP days: `total_lop_days * daily_rate`. |
| **Overtime Sourcing** | Strictly approved OT minutes only (`approval_status = 'Approved'`). Pending and rejected OT are excluded. | `getSummaryForPayroll()` and `getBulkSummaryForPayroll()` filter `where('approval_status', 'Approved')` with in-memory defense-in-depth guards. |
| **Duplicate OT Exclusion** | Multiple approved OT records for the same employee on the same date are deduplicated. | Deduplication by `(employee_id, date)` ensures only one canonical record is counted per date. Duplicate claims/entries cannot doubly accumulate payout. |
| **Settled Batch Scoping** | OT records settled in a previous payroll (`is_settled = 1`) cannot be re-paid in a new batch. | `getSummaryForPayroll()` and `getBulkSummaryForPayroll()` filter out records where `is_settled = 1` and `payroll_id != $payrollId`. |
| **Multipliers & Hourly Rate** | Hourly rate = `base_salary / (divisor_days * standard_daily_hours)`. Policy multipliers applied strictly via RuleResolver. | Resolved dynamically via `OvertimeCalculationService::resolvePolicy()` and `DailyRateResolver::resolve()`. Zero literal fallbacks. |
| **Payroll Draft Summary** | Batch calculation produces comprehensive draft summary metrics for HR review before approval. | `draft_summary` returned on dry-run and generation. Exposed via `GET /payroll/draft-summary/{id}`. |
| **HR Approval & Lock** | Linear workflow stage progression (`Draft` -> `HR Review` -> `Finance Review` -> `Approved` -> `Locked`). | Locking finalizes batch: marks OT records `is_settled = 1`, creates SHA256 cryptographic lock, settles advances, commits PF, commits loans. |
| **Immutability Guarantee** | Locked/settled payroll batches cannot be recalculated, overwritten, or modified. Attendance logs for settled periods are locked. | `generatePayrollBatch()` guards against finalized batches (`status IN ('approved', 'financeapproved', 'locked', 'paid', 'disbursed', 'closed')`). `AttendanceModel::isAttendanceSettled()` blocks mutations. |

---

## 2. Component Integration Details

### 2.1 Overtime Calculation Service (`App\Services\Overtime\OvertimeCalculationService`)
- **`getSummaryForPayroll(string $employeeId, string $month, string $companyId, ?string $payrollId = null): array`**:
  - Strictly queries `overtime_records` with `approval_status = 'Approved'`.
  - Excludes records already settled in other batches (`is_settled = 1` and `payroll_id != $payrollId`).
  - Deduplicates by `date`, preventing duplicate records on the same date from being doubly accumulated.
  - Returns `approved_minutes`, `approved_hours`, `ot_amount`, `record_ids`, and `record_count`.
- **`getBulkSummaryForPayroll(array $employeeIds, string $month, ?string $companyId = null, ?string $payrollId = null): array`**:
  - Bulk-queries approved records for all employees in the batch in a single high-performance query.
  - Deduplicates by `employee_id|date`.
  - Excludes records settled in other batches.
  - Returns structured summaries including `approved_minutes` and `approved_hours`.
- **`settleOvertimeForPayroll(string $payrollId, string $month, string $companyId, string $userId): array`**:
  - Executed when payroll batch is approved and locked.
  - Transitions all approved records for the month to `is_settled = 1` and links `payroll_id`.
  - Generates a SHA-256 cryptographic settlement lock (`otlock-`) with payload hash: `company_id|payroll_id|month|records|hours|amount|timestamp`.
- **`revertOvertimeSettlement(string $payrollId, ?string $companyId = null): void`**:
  - Idempotently releases lock and resets `is_settled = 0` when an authorized officer unlocks a batch for revisions.

### 2.2 Payroll Service (`App\Services\PayrollService`)
- **`buildBatchContext()`**:
  - Passes `$payrollId` to `$this->otService->getBulkSummaryForPayroll()`.
  - Preloads scheduled duty hours from published roster assignments (`roster_assignments.is_published = 1`) or master shifts.
  - Preloads actual working hours from approved attendance logs (`attendance_logs` where `status != 'Rejected'`).
  - Preloads unapproved absent days from `attendance_logs` where `status = 'Absent'` and not covered by an approved leave application.
  - Preloads approved paid vs unpaid leave applications, holidays, and weekly-off days.
- **`calculateEmployeeItem()`**:
  - Sources approved overtime from `$ctx['overtime'][$emp['id']]`.
  - Sources Loss of Pay (LOP) from unpaid leave days + unapproved absent days:
    $$\text{Total LOP Days} = \text{Unpaid Leave Days} + \text{Unapproved Absent Days}$$
    $$\text{LOP Deduction} = \text{Total LOP Days} \times \text{Daily Salary Rate}$$
  - Injects `attendance_metrics` into `components_breakdown_json` and `$effects`:
    - `scheduled_duty_hours`
    - `actual_working_hours`
    - `unpaid_leave_days`
    - `absent_days`
    - `total_lop_days`
    - `lop_deduction`
    - `approved_ot_minutes`
    - `approved_ot_hours`
    - `overtime_amount`
- **`generatePayrollBatch()`**:
  - Aggregates batch-level attendance and overtime metrics:
    - `total_scheduled_duty_hours`
    - `total_actual_working_hours`
    - `total_approved_ot_hours`
    - `total_approved_ot_minutes`
    - `total_overtime_pay`
    - `total_lop_deductions`
    - `total_unpaid_leave_days`
    - `total_absent_days`
  - Returns `draft_summary` for both dry-run previews and draft generation.

### 2.3 Payroll Generation Controller (`App\Controllers\Payroll\PayrollGenerationController`)
- **`getDraftSummaryAjax(string $payrollId)`**:
  - JSON endpoint (`GET /payroll/draft-summary/{id}`) with permission `payroll.view` and tenant validation.
  - Aggregates payroll items, breakdown attendance metrics, scheduled hours, actual worked hours, approved OT minutes, and LOP deductions.
  - Returns clean JSON shape `{success: true, message: '...', data: { batch: ..., items: ..., summary: ... }}`.
- **`advanceStage()` & `updateStatus()`**:
  - Enforces dual-authorization segregation of duties (SoD) (Previous Approver $\ne$ Current Approver).
  - Pre-finalization financial integrity check: verifies 50% statutory deduction ceiling and net salary exact match ($Gross - Deductions$).
  - When advancing to `Locked`:
    1. Settle and hard-lock Overtime records (`settleOvertimeForPayroll()`).
    2. Commit loan amortization (`commitLoanAmortizationForBatch()`).
    3. Commit PF ledger contributions (`commitBatchContributions()`).
    4. Finalize linked arrears (`finalizeBatchArrears()`).
    5. Settle advance salary recovery (`settlePayrollDeductions()`).
    6. Settle bonus records (`settlePayrollBonuses()`).

---

## 3. Test Suite

Unit test suite created at `codeigniter4/tests/unit/PayrollAttendanceIntegrationTest.php`:

| Test Name | Verification Target |
|---|---|
| `testPendingAndRejectedOvertimeExcludedFromPayroll` | Verifies that OT records with status `Pending`, `Rejected`, or `Not Required` produce 0.00 hours, 0 minutes, and 0.00 payout in payroll. |
| `testApprovedOvertimeIncludedInPayroll` | Verifies that approved OT records across Normal, Weekly Off, and Holiday day types are correctly accumulated with rate multipliers into gross pay. |
| `testDuplicateOvertimeRecordsOnSameDateExcluded` | Verifies that duplicate approved OT records for the same employee on the same date are deduplicated, preventing double payment. |
| `testSettledPayrollAndLockedBatchesAreImmutable` | Verifies that finalized batches (`approved`, `financeapproved`, `locked`, `paid`, `disbursed`, `closed`) cannot be recalculated, and settled OT records from prior batches are excluded from new batches. |
| `testLeaveAndAbsentTreatmentInPayroll` | Verifies that approved paid leaves have 0 LOP deduction, approved unpaid leaves deduct exact daily rate, unapproved absent days incur LOP, and off-days have 0 LOP deduction. |
| `testScheduledDutyHoursFromRosterAndActualHoursFromAttendance` | Verifies that scheduled duty hours reflect published roster assignments, and actual working hours reflect approved attendance logs. |
| `testPayrollWorkflowStagesAndHardLock` | Verifies linear stage progression, rejection of skipped stages, and hard-lock finalization. |

---

## 4. Verification & Global Rules Compliance

- **Rule 1 (Scope)**: Edits strictly confined to `codeigniter4/`. No changes to `src/` or `vendor/`.
- **Rule 2 & 4 (Single Rule Store & No Literal Fallbacks)**: Divisors, standard daily hours, and multipliers resolved through `RuleResolver` and `DailyRateResolver`. Zero hardcoded fallbacks (`?? 26`, `?? 30`, `?? 15`, `'comp-mercury001'`).
- **Rule 5 (Tenant + Auth)**: All queries and mutations validate `company_id`. Controller endpoints enforce `requireLogin()`, `authorize()`, and `validateTenantScope()`.
- **Rule 7 (Money)**: All amounts rounded via `Money::round()` with configured decimals at calculation completion.
- **Rule 8 (API Shape)**: Responses conform to `{success: bool, message: string, data: object}`.
- **Rule 10 (Minimal Diff)**: Preserved existing public API signatures while adding optional parameters and attendance metrics.
- **Rule 11 (Honesty)**: PHP CLI is not installed in the execution environment; tests were not run via CLI. Code was verified using static AST/token checks, balance verifications, and `compile_applet`.
