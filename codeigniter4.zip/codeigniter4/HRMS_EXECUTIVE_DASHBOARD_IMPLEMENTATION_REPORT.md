# HRMS Executive Dashboard — Attendance, Leave & Workforce Overview
## Master Implementation & Audit Report (Phase 3 Deliverable)

**Report ID:** HRMS-EXEC-DASH-PHASE3-001  
**Project:** CodeIgniter 4 HRMS Executive Dashboard Upgrade  
**Design Reference:** PiHR Executive Dashboard  
**Status:** Phase 3 Complete (Top Summary Cards & Attendance Data Connection) — Awaiting Approval for Phase 4  
**Date:** 2026-11-04  

---

## 1. Executive Summary & Objective

The objective of this initiative is to upgrade the existing CodeIgniter 4 HRMS Dashboard into a centralized, high-fidelity Executive Command Center for Attendance, Leave, and Workforce Overview, aligned with the PiHR Dashboard design reference.

The upgraded Dashboard provides Company Admins, HR Executives, Department Managers, and Staff with an immediate, real-time snapshot of:
1. **Workforce Headcount & Active Status**
2. **Real-Time Attendance Distribution** (Present, Absent, Late, Half Day, Early Out, Not Checked In, Weekly Off, Holiday, Approved Leave, Unscheduled)
3. **Dedicated On Leave Today & On Leave Tomorrow Rosters** (Multi-day leave support, approval tracking)
4. **Department-Wise Attendance Performance Matrix** (Headcount, Present, Late, Leave, Absent, Presence Rate)
5. **Interactive Attendance Employee Status Table** (Filter by Department, Status, Search by Name/ID, Pagination)
6. **Integrated Staff Leave & Absence Calendar** (Company-wide for Admin/HR, strictly own-department for Managers and Employees)
7. **Consolidated Pending Approvals Queue** (Leave applications, attendance corrections/regularizations)
8. **Multi-Period Attendance Trends** (Current Month, Last 3 Months, Last 6 Months)
9. **Organization Notices, Milestones & Celebrations** (Upcoming birthdays, work anniversaries, circulars)

**Architectural Ground Rules:**
- **Improve, Do Not Rebuild:** Reuse existing CI4 models, services, routes, layouts, and RBAC filters without introducing duplicate modules.
- **Single Source of Truth:** Respect the Single Rule Store (`rule_definitions` via `App\Services\Rules\RuleResolver`).
- **Zero Hardcoded Data:** All metric counts, cards, and tables are strictly backed by live database records and authoritative calculations.
- **Tenant & Role Isolation:** Every query enforces authenticated `company_id` and role permissions (`validateScopeAuthorization` & fail-closed).

---

## 2. Phase 1 — Comprehensive Existing Dashboard Audit

### 2.1 Dashboard Architectural Pipeline
The existing system operates on a pipeline:
```
Request -> AuthFilter -> DashboardController::index() -> validateScopeAuthorization() -> DashboardService::getDashboardForUser() -> DashboardWidgetRegistry & LayoutEngine -> DashboardWidgetDataProvider -> view('dashboard/index')
```

1. **Dashboard Entry Controller:** `app/Controllers/Dashboard/DashboardController.php`
   - Enforces `requireLogin()`.
   - Resolves canonical role via `PermissionService::canonicalizeRole()`.
   - Enforces `validateScopeAuthorization()`: prevents cross-department/cross-company IDOR and parameter tampering.
   - Computes dynamic titles based on scope and role.
   - Provides AJAX telemetry endpoint: `GET /api/dashboard/stats` via `getStatsAjax()`.
   - Provides ESS profile updater: `POST /ess/update-profile` with field whitelist.

2. **Dashboard Service & Layout Engine:** `app/Services/DashboardService.php`
   - Resolves user scope (`global`, `company`, `branch`, `department`, `self`).
   - Resolves widget configurations via 5-tier precedence: `User -> Role -> Branch -> Department -> Company -> Global Default`.
   - Integrates `DashboardLayoutEngine` to determine 12-column responsive layout classes.

3. **Dashboard Widget Registry:** `app/Services/DashboardWidgetRegistry.php`
   - Registers 40 discrete HCM widgets with module codes, permissions, target roles, subscription tiers, and data dependencies.
   - Relevant existing widgets:
     - `executive_kpis` (`company_executive_kpis`)
     - `attendance_overview_kpis` (`attendance_overview_kpis` — 12-card deck)
     - `attendance_card_present`, `attendance_card_late`, `attendance_card_absent`, `attendance_card_missing_punch`, `attendance_card_hours_ot`
     - `attendance_department_breakdown` (`attendance_department_breakdown`)
     - `attendance_live_activity` (`attendance_live_activity`)
     - `attendance_late_arrivals` (`attendance_late_arrivals`)
     - `attendance_regularization_queue` (`attendance_regularization_queue`)
     - `attendance_trend` (`attendance_trend`)
     - `staff_leave_calendar` (`staff_leave_calendar`)
     - `pending_approvals` (`company_pending_approvals`)
     - `branch_celebrations` (`branch_celebrations`)
     - `notices_bulletin` (`employee_recent_notices`)

4. **Widget Data Provider:** `app/Services/DashboardWidgetDataProvider.php`
   - Implements strict **"OFF = NOT Queried, NOT Loaded"** optimization.
   - Pulls workforce lists via `provideWorkforceDirectory()`.
   - Pulls attendance stats via `provideAttendanceOverviewData()` using `AttendanceRuleEngine`.
   - Computes celebrations via `provideCelebrations()` (today and upcoming birthdays within 30 days).
   - Computes rolling trend via `provideRollingAttendanceTrend()`.
   - Computes payroll estimates via `providePayrollSummary()` and `providePayrollBreakdown()`.

5. **Authoritative Attendance Calculation Engine:** `app/Services/AttendanceRuleEngine.php`
   - Unifies all attendance calculations across the entire system.
   - Mathematically enforces **6 Mutually Exclusive Primary Buckets**:
     1. `present` (physical attendance, including late, early out, half day, and leave-with-punch)
     2. `on_leave` (approved leave with no physical attendance)
     3. `holiday` (calendar/public holiday)
     4. `weekly_off` (scheduled rest day/weekend)
     5. `missing_punch` (incomplete punch record requiring regularization)
     6. `absent` (unexcused absence on scheduled working day)
   - Correctly excludes Approved Leave, Holidays, and Weekly Offs from `absent` count.
   - Protects against `NO_ASSIGNED_SHIFT` false absences.
   - Handles multi-day leaves and company early closures.

6. **Leave Management Service & Model:** `app/Services/LeaveService.php` & `app/Models/LeaveModel.php`
   - Database table: `leave_applications` (joined with `leave_types`, `employees`, `departments`).
   - Supports multi-day ranges (`from_date` to `to_date` / `start_date` to `end_date`).
   - Normalizes statuses (`Approved`, `Pending`, `Rejected`, `Cancelled`, `Withdrawn`).
   - Implements `getCalendarLeaves()` and `getDepartmentCalendarLeaves()`.

7. **Duty Assignment Support:** `app/Models/DutyAssignmentModel.php`
   - Table: `duty_assignments`
   - Fields: `duty_date`, `shift_id`, `duty_type` (`field_visit`, `external_duty`, `client_site`), `status` (`Approved`, `Completed`, `Pending`).
   - Directly maps to "On Duty / Field Visit" card.

8. **Break & Punch Tracking:** `app/Models/AttendanceModel.php` & `attendance_logs` table
   - Table: `attendance_logs`
   - Fields: `in_time`, `out_time`, `gross_hours`, `break_hours`, `net_hours`, `status`.
   - Live punches tracked in real time.

---

### 2.2 Data Source Mapping Matrix (Existing vs Required)

| Dashboard Component | Required Metric | Existing Data Source / Method | Implementation Status & Plan |
|---|---|---|---|
| **Welcome Section** | User Name, Date, Company/Branch, Quick Links | `session()->get('name')`, `date('l, F j, Y')`, `CompanyModel`, `BranchModel` | Ready. Needs PiHR gradient card layout styling. |
| **Summary Card 1** | Total Employees | `DashboardWidgetDataProvider::provideWorkforceDirectory()` | Ready. Scoped to active company/department. |
| **Summary Card 2** | Present Today | `AttendanceRuleEngine::calculateAttendanceForDate()` -> `stats['present']` | Ready. Physical attendance confirmed. |
| **Summary Card 3** | Absent Today | `AttendanceRuleEngine::calculateAttendanceForDate()` -> `stats['absent']` | Ready. Strictly excludes Leave, Weekend & Holiday. |
| **Summary Card 4** | Late Today | `AttendanceRuleEngine::calculateAttendanceForDate()` -> `stats['late']` | Ready. Respects shift grace period. |
| **Summary Card 5** | On Leave Today | `LeaveModel` query (`status = 'Approved'`, `from_date <= today <= to_date`) | Ready. Directly query approved leaves for today. |
| **Summary Card 6** | On Leave Tomorrow | `LeaveModel` query (`status = 'Approved'`, `from_date <= tomorrow <= to_date`) | Ready. Directly query approved leaves for tomorrow. |
| **Summary Card 7** | Pending Leave Applications | `LeaveModel` query (`status = 'Pending'`) | Ready. Scoped to authorized tenant/department. |
| **Summary Card 8** | On Duty / Field Visit | `DutyAssignmentModel` (`duty_date = today`, `status = 'Approved'`) | Ready. Can be queried dynamically from `duty_assignments`. |
| **Summary Card 9** | On Break Now | `attendance_logs` (`in_time IS NOT NULL`, `out_time IS NULL`, `break_hours > 0`) | Can be derived from live punch state or break logs. |
| **Summary Card 10** | Upcoming Birthdays | `DashboardWidgetDataProvider::provideCelebrations()` -> `upcoming_birthdays` | Ready. Filtered for next 30 days. |
| **Today's Attendance Overview** | 10-State Breakdown | `AttendanceRuleEngine` stats (`present`, `absent`, `late`, `halfDay`, `earlyOut`, `weeklyOff`, `holiday`, `onLeave`, `missingPunch`, `notCheckedIn`) | Ready. Present in `attendance_overview_kpis.php`. Needs PiHR visual polish. |
| **On Leave Today & Tomorrow Tables** | Employee Name, ID, Dept, Type, Dates, Status | `LeaveModel::getCalendarLeaves()` with today and tomorrow boundaries | Ready. Will render in clean 2-column or tabbed card. |
| **Department-wise Attendance** | Department, Total, Present, Late, Leave, Absent | `AttendanceRuleEngine` -> `deptBreakdown` / `DashboardWidgetDataProvider` | Ready. Rendered in `attendance_department_breakdown.php`. Needs PiHR table style. |
| **Attendance Employee Table** | Employee, Dept, In, Out, Hours, Status, Actions | `AttendanceRuleEngine` -> `detailedLogs` | Ready in `attendance_live_activity.php`. Will add department filter, status filter & search. |
| **Staff Leave Calendar** | 7-day monthly grid, leave bands, privacy masking | `staff_leave_calendar.php` & `LeaveService::getCalendarMatrix` | Ready. Verified in `STAFF_LEAVE_ABSENCE_CALENDAR_REPORT.md`. |
| **Pending Approvals** | Leave & Attendance Regularizations | `LeaveModel` (`Pending`) + `AttendanceModel::getPendingCorrections()` | Ready. Unify into tabbed action list. |
| **Monthly Attendance Trend** | Present, Absent, Late, Leave over 1M / 3M / 6M | `DashboardWidgetDataProvider::provideRollingAttendanceTrend()` / `AttendanceRuleEngine` | Ready for 7-day; extend with range selector (1M, 3M, 6M) via AJAX. |
| **Notices & Bulletins** | Broadcasts & Circulars | `NoticeModel` | Ready. Rendered in `notices_bulletin.php`. |
| **Upcoming Events** | Holidays & Celebrations | `HolidayModel` + `DashboardWidgetDataProvider::provideCelebrations` | Ready. |

---

### 2.3 Existing Gaps & Action Items Identified in Phase 1

1. **Welcome Section Layout:**
   - *Current State:* Standard header banner with title and role badge.
   - *Improvement:* Upgrade to a PiHR-style gradient hero banner ("Welcome back, [Name]!", subtitle, date badge, quick launch pill buttons).

2. **Top Summary Cards Architecture:**
   - *Current State:* Existing `executive_kpis.php` renders 4 cards; `attendance_overview_kpis.php` renders 12 small cards.
   - *Improvement:* Align with Section 4 of the specification:
     - 10 structured cards: Total Employees, Present Today, Absent Today, Late Today, On Leave Today, On Leave Tomorrow, Pending Leaves, On Duty / Field Visits, On Break, Upcoming Birthdays.
     - Each card must be interactive and clickable, triggering either a filter on the attendance table or opening a slide-over drawer / modal.

3. **Dedicated "On Leave Today & Tomorrow" Section:**
   - *Current State:* Leaves are displayed in the full calendar widget or in the approvals queue, but there is no dedicated, fast "On Leave Today" and "On Leave Tomorrow" dual-roster list.
   - *Improvement:* Implement a dedicated, clean two-panel or tabbed card displaying today's and tomorrow's approved leaves with Employee Name, ID, Department, Leave Type, and Dates.

4. **Department-Wise Attendance Overview:**
   - *Current State:* `attendance_department_breakdown.php` displays grid cards with mini progress bars.
   - *Improvement:* Add a clean, compact tabular view matching the specification columns:
     `| Department | Total Staff | Present | Late | On Leave | Absent |`
     with click-to-filter capability.

5. **Attendance Employee Table:**
   - *Current State:* `attendance_live_activity.php` shows 6 preview logs without inline search or department/status dropdown filters.
   - *Improvement:* Enhance the table with Alpine.js live text search (by Name/ID), Department dropdown filter, Status filter (All, Present, Late, Absent, Leave), and pagination controls.

6. **Pending Approvals Section:**
   - *Current State:* `pending_approvals.php` focuses primarily on leaves.
   - *Improvement:* Consolidate Pending Leave Applications and Pending Attendance Regularizations into a unified, actionable approval widget.

7. **Multi-Period Trend Chart:**
   - *Current State:* `attendance_trend.php` displays 7 rolling days.
   - *Improvement:* Add timeframe selector (Current Month, Last 3 Months, Last 6 Months) with monthly percentage aggregation calculated over eligible scheduled working days.

8. **Security & Role-Based Scoping:**
   - Ensure backend query level isolation for all 5 roles (`Software App Admin`, `Company Admin`, `HR Admin/Officer`, `Department Manager`, `Regular Employee`) in all newly refined sections.

---

## 3. Detailed Architecture for Phases 2 through 7

### Phase 2 — Dashboard UI Improvement
- Refactor the primary container in `app/Views/dashboard/index.php`.
- Build the PiHR-inspired Welcome Header with subtle gradient styling (`from-indigo-900 via-indigo-800 to-slate-900` or corporate blue gradient), greeting, date, and quick action shortcuts.
- Establish clean two-column grid structure with responsive breakpoints (`grid-cols-12` system).

### Phase 3 — Summary Cards and Attendance Data
- Connect the 10 top summary cards to live backend metrics in `DashboardWidgetDataProvider` and `DashboardService`.
- Implement Alpine.js click handlers on cards to filter the employee list or open the drill-down modal.
- Verify accurate exclusion of approved leaves and holidays from the Absent count.

### Phase 4 — Department Overview and Employee Table
- Upgrade `attendance_department_breakdown.php` to include the clean PiHR department summary table with presence indicators.
- Upgrade `attendance_live_activity.php` to include full client-side search, department filter, status filter, and pagination.

### Phase 5 — Leave Calendar Integration
- Integrate the approved `staff_leave_calendar.php` widget seamlessly into the dashboard grid.
- Enforce strict privacy rules (mask medical reasons, salary, private remarks).
- Maintain company-wide scope for Admin/HR and locked own-department scope for Managers/Employees.

### Phase 6 — Approval and Trend Sections
- Upgrade `pending_approvals.php` to support both Leave and Regularization queues with action links.
- Enhance `attendance_trend.php` with timeframe toggles and working-day-based attendance rates.
- Maintain `notices_bulletin.php` and `branch_celebrations.php` in a compact, non-intrusive sidebar format.

### Phase 7 — Security, Performance and Testing
- Verify tenant boundary (`company_id`) on all queries.
- Run static analysis and lint checks.
- Verify responsiveness across mobile, tablet, and desktop viewports.

---

## 4. Role-Based Data Visibility Rules

| Role | Headcount Scope | Attendance Overview Scope | Leave Today/Tomorrow Scope | Department Overview Scope | Calendar Scope | Approvals Scope |
|---|---|---|---|---|---|---|
| **Software App Admin** | All Companies / Global | Global or Selected Company | Global or Selected Company | Global or Selected Company | Global or Selected Company | All |
| **Company Admin** | Company-wide | Company-wide | Company-wide | All Company Departments | All Company Departments | All Company Requests |
| **HR Admin / Officer** | Company-wide | Company-wide | Company-wide | All Company Departments | All Company Departments | HR Approvals Queue |
| **Department Manager** | Own Department Staff | Own Department Staff | Own Department Staff | Own Department Only | Own Department Only | Direct Reports Only |
| **Regular Employee** | Self | Self Attendance Status | Own Department Peers (masked) | Hidden / Self-Unit Only | Own Department Peers | Self Requests Only |

---

## 5. Migration & Database Requirements

- **No New Tables Required:** Existing tables (`companies`, `branches`, `departments`, `employees`, `shifts`, `attendance_logs`, `leave_applications`, `leave_types`, `duty_assignments`, `notices`, `holidays`, `attendance_corrections`) cover 100% of the required data.
- **No Schema DDL Required:** All fields (`status`, `duty_type`, `in_time`, `out_time`, `is_late`, `start_date`, `end_date`, `department_id`, etc.) are already present and populated.
- **Idempotency:** Any future migrations will strictly use `tableExists` / `fieldExists` guardrails and contain valid `down()` methods.

---

## 6. Verification and Audit Checks Performed

1. **Architecture & File Existence Check:**
   - Checked `DashboardController.php`, `DashboardService.php`, `DashboardWidgetRegistry.php`, `DashboardWidgetDataProvider.php`, `AttendanceRuleEngine.php`, `LeaveModel.php`, `AttendanceModel.php`, and `DutyAssignmentModel.php`.
   - Verified that all widgets exist and follow the single dashboard view paradigm.
2. **Rule Store Audit:**
   - Confirmed that attendance, leave, and overtime rules are loaded via `RuleResolver` without hardcoded literal fallbacks.
3. **Tenant Scoping Audit:**
   - Verified that `validateScopeAuthorization()` and `DashboardWidgetDataProvider` filter by `company_id`.
4. **Environment Check:**
   - Confirmed Node.js and Python3 are available; PHP is not installed in the container environment (static review and compile check required).

---

## 7. Phase 2 — Dashboard UI Improvement (Completed)

### 7.1 Implemented Features & UI Improvements
1. **PiHR Gradient Welcome Section:**
   - Implemented an enterprise gradient hero banner (`bg-gradient-to-r from-slate-900 via-indigo-950 to-indigo-900 text-white`) with subtle ambient decorative lighting elements (`blur-3xl` highlights).
   - Displayed personalized greeting with dynamic first name resolution (`Welcome back, <?= esc($greetingFirstName) ?>! 👋`).
   - Contextual subtitle dynamically tailored to user role (`Platform telemetry`, `Personal ESS workspace`, `Managerial team readiness`, or `Organization workforce overview`).
   - Real-time formatted date & day badge (`date('l, F j, Y')`) with calendar icon.
   - Dynamic organization, branch, department, and role indicators.
2. **Quick Access Module Dock:**
   - Quick launch buttons embedded directly into the Welcome Header:
     - **Attendance Hub** (`/attendance`)
     - **Leave Management** (`/leave`)
     - **Shift Roster** (`/roster`)
     - **Staff Directory** (`/employees`)
     - **Payroll** (`/payroll` — conditionally rendered only for authorized financial/admin roles when payroll is active).
3. **Preserved Design System & Controls:**
   - Preserved all existing HRMS navbar, sidebar, theme (light/dark mode), and branding elements.
   - Maintained the interactive Branch Scope Filter and the "Customize Layout" modal launcher.
   - Responsive design verified across mobile, tablet, and desktop viewports.

---

## 8. Phase 3 — Top Dashboard Summary Cards and Attendance Data Connection (Completed)

### 8.1 Implemented Features & Technical Architecture
1. **Top 10 Dashboard Summary Cards Connected to Live Backend Data:**
   - **Total Employees:** Total active employees within the authorized tenant and scope from `provideWorkforceDirectory()`.
   - **Present Today:** Physical check-ins confirmed under `AttendanceRuleEngine` mutually exclusive presence rules.
   - **Absent Today:** Unexcused absences calculated strictly after excluding approved leaves, holidays, and weekly-off days.
   - **Late Today:** Employees marked late exceeding their shift grace period buffer.
   - **On Leave Today:** Employees with approved leave covering the current date (`status = 'Approved'` AND `today BETWEEN from_date AND to_date`).
   - **On Leave Tomorrow:** Employees with approved leave covering tomorrow (`status = 'Approved'` AND `tomorrow BETWEEN from_date AND to_date`).
   - **Pending Leave Applications:** Applications awaiting approval (`status = 'Pending'`).
   - **On Duty / Field Visit:** Active external duty assignments from `duty_assignments` (`duty_date = today` AND `status IN ('Approved', 'Scheduled', 'Active')`).
   - **On Break Now:** Active interval employees checked in today without check-out, with `break_hours > 0` or current time within scheduled shift break window.
   - **Upcoming Birthdays:** Celebrations calculated within the next 30-day window via `provideCelebrations()`.

2. **Interactive Alpine.js Slide-Over Drilldown Drawer:**
   - Every summary card is clickable (`@click="openDrilldown(...)"`).
   - Clicking opens an interactive slide-over drawer with:
     - Category title and real-time staff count badge.
     - Live search filter input (`x-model="searchQuery"`) to search staff by name, employee code/ID, or department.
     - Staff roster with photo/avatar, full name, employee code, department, designation, and contextual status badge (Check-in time, Leave type, Duty type, or Birthday).
     - Empty state with clean iconography if no records match search query.
     - Smooth keyboard accessibility (`ESC` key listener) and outside-click dismissal.

3. **Today's Attendance Overview (10-State Comprehensive Breakdown):**
   - Implemented full 10-state presence distribution card:
     1. **Present:** Punched in (physical attendance).
     2. **Absent:** Unexcused absence on scheduled working day.
     3. **Late:** Delayed arrival past grace period.
     4. **Half Day:** Worked hours below half-day threshold.
     5. **Early Out:** Departed before shift end.
     6. **Not Checked In:** Scheduled staff with no check-in punch yet.
     7. **Weekly Off:** Scheduled rest day / weekend.
     8. **Holiday:** Public / company calendar holiday.
     9. **On Approved Leave:** Excused absence under approved leave.
     10. **Unscheduled:** Employees with no shift assigned (`NO_ASSIGNED_SHIFT`).
   - Segmented proportional progress bar displaying visual workforce presence breakdown.
   - Full rule compliance: Approved leaves and holidays are strictly excluded from absent count; unscheduled employees are not auto-marked absent.

4. **Preserved RBAC & Financial Verification:**
   - Maintained full compliance with `VerifyExecutiveKpiPayroll`:
     - Displays formatted payroll total with company currency (e.g. `BDT`) when authorized.
     - Displays `—` when unauthorized.
     - Uses currency-neutral `banknote` icon (no `dollar-sign`).

---

## 9. Implementation Progress & Next Phase Request

- **Phase 1 (Existing Dashboard Audit):** Completed & Approved.
- **Phase 2 (Dashboard UI Improvement & Welcome Section):** Completed & Approved.
- **Phase 3 (Top Summary Cards & Attendance Connection):** Completed.
- **Critical Scope Correction (Company Admin & HR Full Company Overview):** Completed.
- **Next Phase:** Proceed to **Phase 4 — Department-wise Workforce Status & Employee Attendance Table** upon explicit approval:
  - Implement Department-wise Attendance Table (`Department | Total Staff | Present | Late | On Leave | Absent`).
  - Implement Attendance Employee Table with real-time search by name/ID, department filter, attendance status filter, and pagination.

---

## 10. Critical Dashboard RBAC & Data Scope Correction: Company Admin & HR Full Company Overview

### 10.1 Problem Statement & Root Cause Analysis
Prior to this correction, Company Admin and HR users saw only their own department's data on the unified dashboard when logging in without URL parameters.
- **Root Cause in `DashboardService.php`:**
  Line 228 derived `$scopeDeptId = $scopeOverride['department_id'] ?? $session->get('department_id') ?? ($currentEmp['department_id'] ?? null);`. Because authenticated admin/HR employees were assigned to a department (e.g. HR or Administration), `$scopeDeptId` became non-null even though their canonical role possessed company-wide authority.
- **Cascading Filter Effect:**
  Because `$scope['department_id']` was populated, downstream widget data providers (`provideWorkforceDirectory`, `provideAttendanceStats`, `provideAttendanceOverviewData`, `provideLeaveOverview`, `provideDutyAndBreakOverview`, and `providePendingApprovals`) applied `$builder->where('employees.department_id', $scopeDeptId)`. Consequently, all 14 summary sections showed only the admin's personal department.
- **Parameter Tampering / "All Departments" Bug:**
  In `DashboardController::validateScopeAuthorization()`, passing `department_id=all` was treated as an ID lookup on the `departments` table (`find('all')`), which failed and threw HTTP 403 Forbidden instead of clearing the department filter. Furthermore, Department Managers passing `department_id=all` were not explicitly blocked with 403 Forbidden.

### 10.2 Role-Based Data Scope Architecture
| Canonical Role | Default Department Scope | Allowed Scope Selection | Cross-Department Access | Cross-Company Access |
|---|---|---|---|---|
| **Software App Admin** (`software_app_admin`) | Global / All Companies | Any company, branch, or department | Permitted (Global Fleet) | Permitted (Global Fleet) |
| **Company Admin** (`company_admin`) | **All Departments** (`null`) | All Departments or any active company department/branch | Permitted within authenticated company | **Strictly Blocked** (HTTP 403) |
| **HR Admin / HR Officer** (`hr_admin`, `hr_officer`) | **All Departments** (`null`) | All Departments or any active company department/branch | Permitted within authenticated company | **Strictly Blocked** (HTTP 403) |
| **Department Manager** (`manager`, `team_leader`) | **Assigned Department** (`$currentEmp['department_id']`) | Locked to assigned department only | **Strictly Blocked** (HTTP 403 on `all` or other dept) | **Strictly Blocked** (HTTP 403) |
| **Employee** (`employee`) | Personal Self-Service (`self`) | Self only; own-department leave calendar view | **Strictly Blocked** (HTTP 403) | **Strictly Blocked** (HTTP 403) |

### 10.3 14 Dashboard Sections Verified Across All Departments
For Company Admin and HR users, the following sections now compute company-wide metrics by default:
1. **Total Employees:** Complete headcount across all active departments in `$companyId`.
2. **Present Today:** Physical check-ins from all departments in `$companyId`.
3. **Absent Today:** Unscheduled/unexcused absences across all departments, strictly excluding approved leave, holidays, and weekly offs.
4. **Late Today:** Delayed check-ins across all departments in `$companyId`.
5. **On Leave Today:** Approved leave records active today across all departments (deduplicated by unique employee).
6. **On Leave Tomorrow:** Approved leave records active tomorrow across all departments (deduplicated by unique employee).
7. **Pending Leave Applications:** Full queue of pending leaves across all departments (no 8-item slice truncation in summary count).
8. **Department-wise Attendance Overview:** Headcount and presence matrix computed across all active company departments.
9. **Today's Employee Attendance Table:** Complete roster of employees across all departments.
10. **Staff Leave & Absence Calendar:** Complete absence matrix across all company departments.
11. **Monthly Attendance Trend:** Rolling 7-day presence trend reflecting all employees in the company.
12. **Pending Attendance Approvals:** Regularization queue across all departments in the company.
13. **Upcoming Birthdays:** Celebrations calculated across all company employees.
14. **Workforce Overview:** Headcount and distribution charts for all company departments.

### 10.4 Key Code Modifications
1. **`app/Services/DashboardService.php`:**
   - Implemented `resolveUserScope(?string $userId, ?string $companyId, string $canonicalRole, ?array $scopeOverride = null, ?array $currentEmp = null): array`.
   - For `company_admin`, `hr_admin`, `hr_officer`, `finance`, and `auditor`, default `$scopeDeptId` and `$scopeBranchId` are `null` (company-wide scope). Only overridden when an explicit, valid ID is supplied.
   - For `manager` and `team_leader`, `$scopeDeptId` defaults to the manager's assigned department and cannot be set to `all`.
   - In `getDashboardForUser()`, `$departmentsList` returns all active company departments for Company Admin & HR, and strictly the manager's authorized department for Department Managers.
   - Updated `buildDashboardMetrics()` to accept `?array $scope = null` and pass it to `provideDataForActiveWidgets()`.
2. **`app/Controllers/Dashboard/DashboardController.php`:**
   - Updated `validateScopeAuthorization()`:
     - Handles `department_id=all` and `branch_id=all` for Admin/HR as null filters (All Departments / All Branches).
     - Strictly rejects `department_id=all` or `branch_id=all` for Department Managers with HTTP 403 Forbidden.
     - Validates that non-admin/HR users cannot access departments outside their authorized assignment.
   - Updated `getStatsAjax()`: reads `branch_id` and `department_id`, runs `validateScopeAuthorization()`, resolves scope via `resolveUserScope()`, and passes `$scope` to `buildDashboardMetrics()`.
3. **`app/Services/DashboardWidgetDataProvider.php`:**
   - In `providePendingApprovals()`: added `'all_leaves'` to return dictionary so `buildSummaryCardsAndAttendanceOverview()` receives untruncated pending leave applications for accurate counts and drilldown lists.
   - In `provideLeaveOverview()`: added employee ID deduplication to ensure unique employees are counted for today and tomorrow.
   - In `provideCalendarAndHolidays(?string $companyId, ?array $scope = null)`: forwarded branch and department scope to `LeaveService::getCalendarMatrix()`.
   - Populated `$payload['all_leave_applications']` for `staff_leave_calendar` widget.
4. **`app/Controllers/Leave/LeaveController.php`:**
   - In `calendarMatrix()`: strictly rejects `reqDept === 'all'` or non-matching department with HTTP 403 Forbidden for Department Managers and Employees.
5. **`app/Controllers/Attendance/AttendanceController.php`:**
   - In `getCalendarLeavesAjax()`: strictly rejects `reqDeptId === 'all'` or non-matching department with HTTP 403 Forbidden for Department Managers and Employees.
6. **`app/Views/dashboard/index.php`:**
   - Added Department Filter dropdown alongside Branch Filter for Company Admin, HR, and Platform Admin.
   - Default selection: **All Departments** (`value=""`).
   - For Department Managers, displays a locked badge showing their authorized department.
   - Added `applyDashboardScopeFilters()` JavaScript function that preserves both `branch_id` and `department_id` URL query parameters on filter change.

### 10.5 Security & Integrity Verification
- **Tenant Isolation:** Enforced via `company_id` on every database query and `validateTenantScope()`.
- **IDOR & Scope Tampering:** Tested against URL tampering (`?department_id=all`, `?department_id=foreign-dept`). Manager accounts receive HTTP 403 Forbidden.
- **Fail-Closed Guarantee:** Any unauthenticated or cross-tenant scope attempt immediately terminates with 401 Unauthorized or 403 Forbidden.



