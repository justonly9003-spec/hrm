<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

/**
 * MobilePfEndpointsTest
 *
 * Verifies mobile Provident Fund membership, contribution, and interest endpoints:
 * - GET api/mobile/v1/pf/membership and GET api/v1/pf/membership
 * - GET api/mobile/v1/pf/contributions and GET api/v1/pf/contributions
 * - GET api/mobile/v1/pf/interest and GET api/v1/pf/interest
 *
 * Invariants tested:
 * - Unauthenticated requests return 401
 * - Three membership states: not_enrolled, enrolled_zero_balance, enrolled_with_transactions
 * - Excludes draft entries from official statement
 * - Posted reversals cancel target entries and are excluded from active totals
 * - Date/year filtering and validation (422 on invalid year/month)
 * - Interest statement exposes recorded entries only; reports lack of automated accrual engine
 * - Multi-tenant isolation and anti-IDOR enforcement (cross-tenant queries strictly rejected/ignored)
 */
#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobilePfEndpointsTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);

        // Add PF fields to employees table if not present in test schema
        $empFields = [
            'is_pf_applicable'     => 'INT DEFAULT 0',
            'pf_status'            => "VARCHAR(30) DEFAULT 'Not Enrolled'",
            'pf_member_id'         => 'VARCHAR(100) NULL',
            'pf_contribution_type' => "VARCHAR(30) DEFAULT 'percentage'",
            'pf_employee_rate'     => 'DECIMAL(5,2) DEFAULT 7.00',
            'pf_employer_rate'     => 'DECIMAL(5,2) DEFAULT 7.00',
            'pf_effective_date'    => 'DATE NULL',
            'pf_close_date'        => 'DATE NULL',
            'pf_exemption_reason'  => 'TEXT NULL',
        ];
        foreach ($empFields as $col => $type) {
            try {
                $this->db->query("ALTER TABLE employees ADD COLUMN {$col} {$type}");
            } catch (\Throwable $e) {
                // Column may already exist
            }
        }

        // Drop & recreate PF ledgers and eligibility periods
        foreach (['provident_fund_ledgers', 'employee_pf_eligibility_periods'] as $t) {
            $this->db->query("DROP TABLE IF EXISTS {$t}");
        }

        $this->db->query("CREATE TABLE provident_fund_ledgers (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            employee_id VARCHAR(36),
            payroll_id VARCHAR(36) NULL,
            payroll_month INT NULL,
            payroll_year INT NULL,
            pf_rule_id VARCHAR(36) NULL,
            transaction_type VARCHAR(50) DEFAULT 'CONTRIBUTION',
            pf_base_salary DECIMAL(15,2) DEFAULT 0.00,
            employee_contribution DECIMAL(15,2) DEFAULT 0.00,
            employer_contribution DECIMAL(15,2) DEFAULT 0.00,
            total_contribution DECIMAL(15,2) DEFAULT 0.00,
            running_balance DECIMAL(15,2) DEFAULT 0.00,
            transaction_date DATE,
            status VARCHAR(30) DEFAULT 'draft',
            reference_no VARCHAR(100) NULL,
            reversal_of_id VARCHAR(36) NULL,
            notes TEXT NULL,
            created_by VARCHAR(36) NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE employee_pf_eligibility_periods (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            employee_id VARCHAR(36),
            status VARCHAR(30) DEFAULT 'Eligible',
            effective_from DATE,
            effective_to DATE NULL,
            reason TEXT NULL,
            member_id VARCHAR(100) NULL,
            created_by VARCHAR(36) NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");
    }

    private function token(string $company = 'ACME', string $id = 'rahim'): array
    {
        $res = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => $company,
            'identifier'   => $id,
            'password'     => self::PASSWORD,
            'device'       => ['device_uid' => 'dev-pf-test'],
        ]);
        $json = json_decode($res->getJSON(), true);
        return ['Authorization' => 'Bearer ' . $json['data']['tokens']['access_token']];
    }

    private function json($res): array
    {
        return json_decode($res->getJSON(), true);
    }

    // 1. Unauthenticated 401
    public function testUnauthenticatedAccessReturns401(): void
    {
        $endpoints = [
            'api/mobile/v1/pf/membership',
            'api/mobile/v1/pf/contributions',
            'api/mobile/v1/pf/interest',
            'api/v1/pf/membership',
            'api/v1/pf/contributions',
            'api/v1/pf/interest',
        ];

        foreach ($endpoints as $ep) {
            $res = $this->call('get', $ep);
            $this->assertSame(401, $res->response()->getStatusCode(), "Endpoint {$ep} should return 401 unauthenticated");
            $data = $this->json($res);
            $this->assertFalse($data['success']);
        }
    }

    // 2. Membership state: Not Enrolled
    public function testMembershipNotEnrolledState(): void
    {
        // e-1 default in MobileTestSchema is not enrolled
        $this->db->table('employees')->where('id', 'e-1')->update([
            'is_pf_applicable' => 0,
            'pf_status'        => 'Not Enrolled',
        ]);

        $res = $this->withHeaders($this->token())->call('get', 'api/mobile/v1/pf/membership');
        $this->assertSame(200, $res->response()->getStatusCode());
        $body = $this->json($res);

        $this->assertTrue($body['success']);
        $this->assertFalse($body['data']['is_enrolled']);
        $this->assertSame('not_enrolled', $body['data']['enrollment_state']);
        $this->assertSame(0.00, (float)$body['data']['balance']);
        $this->assertSame(0, $body['data']['transaction_count']);
        $this->assertNull($body['data']['rule']);
    }

    // 3. Membership state: Enrolled with zero balance
    public function testMembershipEnrolledZeroBalanceState(): void
    {
        // Enroll e-1 but insert zero ledger rows
        $this->db->table('employees')->where('id', 'e-1')->update([
            'is_pf_applicable'  => 1,
            'pf_status'         => 'Enrolled',
            'pf_member_id'      => 'PF-EMP-001',
            'pf_effective_date' => '2026-01-01',
        ]);

        $res = $this->withHeaders($this->token())->call('get', 'api/mobile/v1/pf/membership');
        $this->assertSame(200, $res->response()->getStatusCode());
        $body = $this->json($res);

        $this->assertTrue($body['success']);
        $this->assertTrue($body['data']['is_enrolled']);
        $this->assertSame('enrolled_zero_balance', $body['data']['enrollment_state']);
        $this->assertSame('Enrolled', $body['data']['status']);
        $this->assertSame('PF-EMP-001', $body['data']['pf_member_id']);
        $this->assertSame(0.00, (float)$body['data']['balance']);
        $this->assertSame(0, $body['data']['transaction_count']);
    }

    // 4. Membership state: Enrolled with transactions
    public function testMembershipEnrolledWithTransactionsState(): void
    {
        $this->db->table('employees')->where('id', 'e-1')->update([
            'is_pf_applicable'  => 1,
            'pf_status'         => 'Enrolled',
            'pf_member_id'      => 'PF-EMP-001',
            'pf_effective_date' => '2026-01-01',
        ]);

        $this->db->table('provident_fund_ledgers')->insert([
            'id'                    => 'pfl-1',
            'company_id'            => 'c-1',
            'employee_id'           => 'e-1',
            'payroll_month'         => 8,
            'payroll_year'          => 2026,
            'transaction_type'      => 'CONTRIBUTION',
            'pf_base_salary'        => 50000.00,
            'employee_contribution' => 3500.00,
            'employer_contribution' => 3500.00,
            'total_contribution'    => 7000.00,
            'running_balance'       => 7000.00,
            'transaction_date'      => '2026-08-31',
            'status'                => 'posted',
            'reference_no'          => 'TXN-001',
            'created_at'            => '2026-08-31 10:00:00',
        ]);

        $res = $this->withHeaders($this->token())->call('get', 'api/mobile/v1/pf/membership');
        $this->assertSame(200, $res->response()->getStatusCode());
        $body = $this->json($res);

        $this->assertTrue($body['success']);
        $this->assertTrue($body['data']['is_enrolled']);
        $this->assertSame('enrolled_with_transactions', $body['data']['enrollment_state']);
        $this->assertSame(7000.00, (float)$body['data']['balance']);
        $this->assertSame(1, $body['data']['transaction_count']);
        $this->assertSame('2026-08-31', $body['data']['as_of']);
    }

    // 5. Contributions exclude draft entries
    public function testContributionsExcludesDraftEntries(): void
    {
        // 1 posted contribution
        $this->db->table('provident_fund_ledgers')->insert([
            'id'                    => 'pfl-post-1',
            'company_id'            => 'c-1',
            'employee_id'           => 'e-1',
            'payroll_month'         => 8,
            'payroll_year'          => 2026,
            'transaction_type'      => 'CONTRIBUTION',
            'pf_base_salary'        => 50000.00,
            'employee_contribution' => 3500.00,
            'employer_contribution' => 3500.00,
            'total_contribution'    => 7000.00,
            'running_balance'       => 7000.00,
            'transaction_date'      => '2026-08-31',
            'status'                => 'posted',
            'created_at'            => '2026-08-31 10:00:00',
        ]);

        // 1 draft contribution (should be completely excluded)
        $this->db->table('provident_fund_ledgers')->insert([
            'id'                    => 'pfl-draft-1',
            'company_id'            => 'c-1',
            'employee_id'           => 'e-1',
            'payroll_month'         => 9,
            'payroll_year'          => 2026,
            'transaction_type'      => 'CONTRIBUTION',
            'pf_base_salary'        => 50000.00,
            'employee_contribution' => 3500.00,
            'employer_contribution' => 3500.00,
            'total_contribution'    => 7000.00,
            'running_balance'       => 14000.00,
            'transaction_date'      => '2026-09-30',
            'status'                => 'draft',
            'created_at'            => '2026-09-30 10:00:00',
        ]);

        $res = $this->withHeaders($this->token())->call('get', 'api/mobile/v1/pf/contributions');
        $this->assertSame(200, $res->response()->getStatusCode());
        $body = $this->json($res);

        $this->assertTrue($body['success']);
        $this->assertSame(1, $body['data']['total_records']);
        $this->assertSame(3500.00, (float)$body['data']['total_employee_contribution']);
        $this->assertSame(3500.00, (float)$body['data']['total_employer_contribution']);
        $this->assertSame(7000.00, (float)$body['data']['total_contribution']);
        $this->assertSame('pfl-post-1', $body['data']['contributions'][0]['id']);
    }

    // 6. Contributions handle reversals correctly
    public function testContributionsHandlesReversalsCorrectly(): void
    {
        // 1 normal posted contribution
        $this->db->table('provident_fund_ledgers')->insert([
            'id'                    => 'pfl-normal',
            'company_id'            => 'c-1',
            'employee_id'           => 'e-1',
            'payroll_month'         => 7,
            'payroll_year'          => 2026,
            'transaction_type'      => 'CONTRIBUTION',
            'pf_base_salary'        => 50000.00,
            'employee_contribution' => 3500.00,
            'employer_contribution' => 3500.00,
            'total_contribution'    => 7000.00,
            'running_balance'       => 7000.00,
            'transaction_date'      => '2026-07-31',
            'status'                => 'posted',
            'created_at'            => '2026-07-31 10:00:00',
        ]);

        // 1 erroneous posted contribution that was subsequently reversed
        $this->db->table('provident_fund_ledgers')->insert([
            'id'                    => 'pfl-erroneous',
            'company_id'            => 'c-1',
            'employee_id'           => 'e-1',
            'payroll_month'         => 8,
            'payroll_year'          => 2026,
            'transaction_type'      => 'CONTRIBUTION',
            'pf_base_salary'        => 50000.00,
            'employee_contribution' => 5000.00,
            'employer_contribution' => 5000.00,
            'total_contribution'    => 10000.00,
            'running_balance'       => 17000.00,
            'transaction_date'      => '2026-08-31',
            'status'                => 'posted',
            'created_at'            => '2026-08-31 10:00:00',
        ]);

        // 1 posted reversal compensating the erroneous entry
        $this->db->table('provident_fund_ledgers')->insert([
            'id'                    => 'pfl-rev-1',
            'company_id'            => 'c-1',
            'employee_id'           => 'e-1',
            'payroll_month'         => 8,
            'payroll_year'          => 2026,
            'transaction_type'      => 'REVERSAL',
            'pf_base_salary'        => 50000.00,
            'employee_contribution' => -5000.00,
            'employer_contribution' => -5000.00,
            'total_contribution'    => -10000.00,
            'running_balance'       => 7000.00,
            'transaction_date'      => '2026-08-31',
            'status'                => 'posted',
            'reversal_of_id'        => 'pfl-erroneous',
            'created_at'            => '2026-08-31 12:00:00',
        ]);

        $res = $this->withHeaders($this->token())->call('get', 'api/mobile/v1/pf/contributions');
        $this->assertSame(200, $res->response()->getStatusCode());
        $body = $this->json($res);

        $this->assertTrue($body['success']);
        // Only pfl-normal should be in active contributions; pfl-erroneous and pfl-rev-1 excluded
        $this->assertSame(1, $body['data']['total_records']);
        $this->assertSame(3500.00, (float)$body['data']['total_employee_contribution']);
        $this->assertSame(3500.00, (float)$body['data']['total_employer_contribution']);
        $this->assertSame(7000.00, (float)$body['data']['total_contribution']);
        $this->assertSame('pfl-normal', $body['data']['contributions'][0]['id']);
    }

    // 7. Filtering by year and month & validation
    public function testContributionsFilteringAndValidation(): void
    {
        $this->db->table('provident_fund_ledgers')->insert([
            'id'                    => 'pfl-2025',
            'company_id'            => 'c-1',
            'employee_id'           => 'e-1',
            'payroll_month'         => 12,
            'payroll_year'          => 2025,
            'transaction_type'      => 'CONTRIBUTION',
            'employee_contribution' => 3000.00,
            'employer_contribution' => 3000.00,
            'total_contribution'    => 6000.00,
            'running_balance'       => 6000.00,
            'transaction_date'      => '2025-12-31',
            'status'                => 'posted',
            'created_at'            => '2025-12-31 10:00:00',
        ]);

        $this->db->table('provident_fund_ledgers')->insert([
            'id'                    => 'pfl-2026',
            'company_id'            => 'c-1',
            'employee_id'           => 'e-1',
            'payroll_month'         => 1,
            'payroll_year'          => 2026,
            'transaction_type'      => 'CONTRIBUTION',
            'employee_contribution' => 3500.00,
            'employer_contribution' => 3500.00,
            'total_contribution'    => 7000.00,
            'running_balance'       => 13000.00,
            'transaction_date'      => '2026-01-31',
            'status'                => 'posted',
            'created_at'            => '2026-01-31 10:00:00',
        ]);

        // Filter 2026
        $res = $this->withHeaders($this->token())->call('get', 'api/mobile/v1/pf/contributions?year=2026');
        $this->assertSame(200, $res->response()->getStatusCode());
        $body = $this->json($res);
        $this->assertSame(1, $body['data']['total_records']);
        $this->assertSame('pfl-2026', $body['data']['contributions'][0]['id']);

        // Filter non-existent year
        $resEmpty = $this->withHeaders($this->token())->call('get', 'api/mobile/v1/pf/contributions?year=2030');
        $this->assertSame(200, $resEmpty->response()->getStatusCode());
        $bodyEmpty = $this->json($resEmpty);
        $this->assertSame(0, $bodyEmpty['data']['total_records']);
        $this->assertSame(0.00, (float)$bodyEmpty['data']['total_contribution']);

        // Invalid year format (422)
        $res422 = $this->withHeaders($this->token())->call('get', 'api/mobile/v1/pf/contributions?year=abc');
        $this->assertSame(422, $res422->response()->getStatusCode());
    }

    // 8. Interest endpoint exposes recorded entries only
    public function testInterestExposesRecordedEntriesOnly(): void
    {
        $this->db->table('provident_fund_ledgers')->insert([
            'id'                    => 'pfl-int-1',
            'company_id'            => 'c-1',
            'employee_id'           => 'e-1',
            'payroll_month'         => 12,
            'payroll_year'          => 2025,
            'transaction_type'      => 'INTEREST',
            'employee_contribution' => 0.00,
            'employer_contribution' => 0.00,
            'total_contribution'    => 1250.50,
            'running_balance'       => 25000.00,
            'transaction_date'      => '2025-12-31',
            'status'                => 'posted',
            'reference_no'          => 'INT-VOUCHER-2025',
            'notes'                 => 'Annual statutory PF interest credit for FY2025',
            'created_at'            => '2025-12-31 23:59:59',
        ]);

        // Draft interest (should be excluded)
        $this->db->table('provident_fund_ledgers')->insert([
            'id'                    => 'pfl-int-draft',
            'company_id'            => 'c-1',
            'employee_id'           => 'e-1',
            'payroll_month'         => 12,
            'payroll_year'          => 2026,
            'transaction_type'      => 'INTEREST',
            'total_contribution'    => 2000.00,
            'running_balance'       => 27000.00,
            'transaction_date'      => '2026-12-31',
            'status'                => 'draft',
            'created_at'            => '2026-12-31 10:00:00',
        ]);

        $res = $this->withHeaders($this->token())->call('get', 'api/mobile/v1/pf/interest');
        $this->assertSame(200, $res->response()->getStatusCode());
        $body = $this->json($res);

        $this->assertTrue($body['success']);
        $this->assertFalse($body['data']['has_interest_engine']);
        $this->assertNotEmpty($body['data']['engine_note']);
        $this->assertSame(1250.50, (float)$body['data']['total_interest_credited']);
        $this->assertSame(1, $body['data']['total_records']);
        $this->assertSame('pfl-int-1', $body['data']['entries'][0]['id']);
        $this->assertSame(1250.50, (float)$body['data']['entries'][0]['amount']);
    }

    // 9. Tenant isolation & Anti-IDOR enforcement
    public function testTenantIsolationStrictEnforcement(): void
    {
        // Karim in company c-2 has a posted contribution
        $this->db->table('provident_fund_ledgers')->insert([
            'id'                    => 'pfl-c2-karim',
            'company_id'            => 'c-2',
            'employee_id'           => 'e-2',
            'payroll_month'         => 8,
            'payroll_year'          => 2026,
            'transaction_type'      => 'CONTRIBUTION',
            'employee_contribution' => 4000.00,
            'employer_contribution' => 4000.00,
            'total_contribution'    => 8000.00,
            'running_balance'       => 8000.00,
            'transaction_date'      => '2026-08-31',
            'status'                => 'posted',
            'created_at'            => '2026-08-31 10:00:00',
        ]);

        // Rahim (c-1, e-1) makes a query attempting IDOR with ?employee_id=e-2&company_id=c-2
        $res = $this->withHeaders($this->token('ACME', 'rahim'))
            ->call('get', 'api/mobile/v1/pf/contributions?employee_id=e-2&company_id=c-2');
        $this->assertSame(200, $res->response()->getStatusCode());
        $body = $this->json($res);

        // Must strictly scope to Rahim (e-1) who has 0 records, not Karim
        $this->assertSame('e-1', $body['data']['employee_id']);
        $this->assertSame(0, $body['data']['total_records']);
        $this->assertEmpty($body['data']['contributions']);

        // Check Karim's own token accesses Karim's record in c-2
        $resKarim = $this->withHeaders($this->token('OTHER', 'karim'))
            ->call('get', 'api/mobile/v1/pf/contributions');
        $this->assertSame(200, $resKarim->response()->getStatusCode());
        $bodyKarim = $this->json($resKarim);
        $this->assertSame('e-2', $bodyKarim['data']['employee_id']);
        $this->assertSame(1, $bodyKarim['data']['total_records']);
        $this->assertSame('pfl-c2-karim', $bodyKarim['data']['contributions'][0]['id']);
    }

    // 10. Route parity under api/v1
    public function testApiV1ParityRoutes(): void
    {
        $this->db->table('employees')->where('id', 'e-1')->update([
            'is_pf_applicable' => 1,
            'pf_status'        => 'Enrolled',
            'pf_member_id'     => 'PF-EMP-001',
        ]);

        $resMem = $this->withHeaders($this->token())->call('get', 'api/v1/pf/membership');
        $this->assertSame(200, $resMem->response()->getStatusCode());
        $this->assertTrue($this->json($resMem)['success']);

        $resCont = $this->withHeaders($this->token())->call('get', 'api/v1/pf/contributions');
        $this->assertSame(200, $resCont->response()->getStatusCode());
        $this->assertTrue($this->json($resCont)['success']);

        $resInt = $this->withHeaders($this->token())->call('get', 'api/v1/pf/interest');
        $this->assertSame(200, $resInt->response()->getStatusCode());
        $this->assertTrue($this->json($resInt)['success']);
    }
}
