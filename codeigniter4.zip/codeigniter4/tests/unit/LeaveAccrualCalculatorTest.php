<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\Leave\LeaveAccrualCalculator;
use App\Services\Rules\RuleNotConfiguredException;

class LeaveAccrualCalculatorTest extends TestCase
{
    /**
     * Requirement: N=12, 18, 20 calendar days in on_completion mode.
     * N=12: 11 Jan -> 0, 12 Jan -> 1, 24 Jan -> 2, 05 Feb (day 36) -> 3
     */
    public function testOnCompletionModeCalculations()
    {
        $employee = [
            'id'           => 'EMP-001',
            'company_id'   => 'COMP-001',
            'joining_date' => '2026-01-01',
            'status'       => 'Active',
        ];

        // 1. N = 12
        $ruleN12 = [
            'leave_type_code'       => 'EL',
            'accrual_mode'          => 'Calendar days',
            'earn_every_days'       => 12,
            'earn_leave_per_cycle'  => 1.0,
            'accrual_credit_timing' => 'on_completion',
            'accrual_start_from'    => 'joining_date',
        ];

        // Day 11: 01 Jan to 11 Jan = 11 days elapsed -> 0 earned
        $this->assertEquals(0.0, LeaveAccrualCalculator::calculateEarnedDays($employee, $ruleN12, '2026-01-11'));
        // Day 12: 01 Jan to 12 Jan = 12 days elapsed -> 1 earned
        $this->assertEquals(1.0, LeaveAccrualCalculator::calculateEarnedDays($employee, $ruleN12, '2026-01-12'));
        // Day 24: 01 Jan to 24 Jan = 24 days elapsed -> 2 earned
        $this->assertEquals(2.0, LeaveAccrualCalculator::calculateEarnedDays($employee, $ruleN12, '2026-01-24'));
        // Day 36: 01 Jan + 35 days = 05 Feb -> 3 earned
        $this->assertEquals(3.0, LeaveAccrualCalculator::calculateEarnedDays($employee, $ruleN12, '2026-02-05'));

        // 2. N = 18 (18 -> 1, 36 -> 2, 54 -> 3, 72 -> 4)
        $ruleN18 = [
            'leave_type_code'       => 'EL',
            'accrual_mode'          => 'Calendar days',
            'earn_every_days'       => 18,
            'earn_leave_per_cycle'  => 1.0,
            'accrual_credit_timing' => 'on_completion',
            'accrual_start_from'    => 'joining_date',
        ];

        $this->assertEquals(0.0, LeaveAccrualCalculator::calculateEarnedDays($employee, $ruleN18, '2026-01-17')); // Day 17
        $this->assertEquals(1.0, LeaveAccrualCalculator::calculateEarnedDays($employee, $ruleN18, '2026-01-18')); // Day 18
        $this->assertEquals(2.0, LeaveAccrualCalculator::calculateEarnedDays($employee, $ruleN18, '2026-02-05')); // Day 36
        $this->assertEquals(3.0, LeaveAccrualCalculator::calculateEarnedDays($employee, $ruleN18, '2026-02-23')); // Day 54
        $this->assertEquals(4.0, LeaveAccrualCalculator::calculateEarnedDays($employee, $ruleN18, '2026-03-13')); // Day 72

        // 3. N = 20 (20 -> 1, 40 -> 2, 60 -> 3, 80 -> 4)
        $ruleN20 = [
            'leave_type_code'       => 'EL',
            'accrual_mode'          => 'Calendar days',
            'earn_every_days'       => 20,
            'earn_leave_per_cycle'  => 1.0,
            'accrual_credit_timing' => 'on_completion',
            'accrual_start_from'    => 'joining_date',
        ];

        $this->assertEquals(0.0, LeaveAccrualCalculator::calculateEarnedDays($employee, $ruleN20, '2026-01-19')); // Day 19
        $this->assertEquals(1.0, LeaveAccrualCalculator::calculateEarnedDays($employee, $ruleN20, '2026-01-20')); // Day 20
        $this->assertEquals(2.0, LeaveAccrualCalculator::calculateEarnedDays($employee, $ruleN20, '2026-02-09')); // Day 40
        $this->assertEquals(3.0, LeaveAccrualCalculator::calculateEarnedDays($employee, $ruleN20, '2026-03-01')); // Day 60
        $this->assertEquals(4.0, LeaveAccrualCalculator::calculateEarnedDays($employee, $ruleN20, '2026-03-21')); // Day 80
    }

    /**
     * Requirement: N=12 in at_cycle_start mode.
     * Example N=12, joining 01 Jan: 01–12 Jan -> 1, 13–24 Jan -> 2, 25 Jan–05 Feb -> 3
     */
    public function testAtCycleStartModeCalculations()
    {
        $employee = [
            'id'           => 'EMP-002',
            'company_id'   => 'COMP-001',
            'joining_date' => '2026-01-01',
            'status'       => 'Active',
        ];

        $rule = [
            'leave_type_code'       => 'EL',
            'accrual_mode'          => 'Calendar days',
            'earn_every_days'       => 12,
            'earn_leave_per_cycle'  => 1.0,
            'accrual_credit_timing' => 'at_cycle_start',
            'accrual_start_from'    => 'joining_date',
        ];

        // 01 Jan (Day 1) -> cycle 1 -> 1 earned
        $this->assertEquals(1.0, LeaveAccrualCalculator::calculateEarnedDays($employee, $rule, '2026-01-01'));
        // 12 Jan (Day 12) -> cycle 1 -> 1 earned
        $this->assertEquals(1.0, LeaveAccrualCalculator::calculateEarnedDays($employee, $rule, '2026-01-12'));
        // 13 Jan (Day 13) -> cycle 2 -> 2 earned
        $this->assertEquals(2.0, LeaveAccrualCalculator::calculateEarnedDays($employee, $rule, '2026-01-13'));
        // 24 Jan (Day 24) -> cycle 2 -> 2 earned
        $this->assertEquals(2.0, LeaveAccrualCalculator::calculateEarnedDays($employee, $rule, '2026-01-24'));
        // 25 Jan (Day 25) -> cycle 3 -> 3 earned
        $this->assertEquals(3.0, LeaveAccrualCalculator::calculateEarnedDays($employee, $rule, '2026-01-25'));
        // 05 Feb (Day 36) -> cycle 3 -> 3 earned
        $this->assertEquals(3.0, LeaveAccrualCalculator::calculateEarnedDays($employee, $rule, '2026-02-05'));
    }

    /**
     * Requirement: No literal fallbacks or guessing when rule parameters are missing.
     */
    public function testMissingParametersThrowsRuleNotConfiguredException()
    {
        $employee = [
            'id'           => 'EMP-003',
            'company_id'   => 'COMP-001',
            'joining_date' => '2026-01-01',
        ];

        // Missing earn_every_days
        $this->expectException(RuleNotConfiguredException::class);
        LeaveAccrualCalculator::calculateEarnedDays($employee, [
            'leave_type_code'       => 'EL',
            'accrual_mode'          => 'Calendar days',
            'accrual_credit_timing' => 'on_completion',
        ], '2026-01-15');
    }

    public function testMissingTimingThrowsRuleNotConfiguredException()
    {
        $employee = [
            'id'           => 'EMP-004',
            'company_id'   => 'COMP-001',
            'joining_date' => '2026-01-01',
        ];

        // Missing accrual_credit_timing
        $this->expectException(RuleNotConfiguredException::class);
        LeaveAccrualCalculator::calculateEarnedDays($employee, [
            'leave_type_code' => 'EL',
            'accrual_mode'    => 'Calendar days',
            'earn_every_days' => 12,
        ], '2026-01-15');
    }

    /**
     * Requirement: Carry forward configurable (allowed/not, max days null=unlimited, 0=none, capped).
     */
    public function testCarryForwardCalculations()
    {
        // 1. Not allowed
        $ruleNotAllowed = [
            'carry_forward_allowed'  => false,
            'carry_forward_max_days' => 5,
        ];
        $res1 = LeaveAccrualCalculator::calculateCarryForward(8.0, $ruleNotAllowed);
        $this->assertEquals(0.0, $res1['carried_forward']);
        $this->assertEquals(8.0, $res1['expired']);

        // 2. Allowed, null max days (unlimited)
        $ruleUnlimited = [
            'carry_forward_allowed'  => true,
            'carry_forward_max_days' => null,
        ];
        $res2 = LeaveAccrualCalculator::calculateCarryForward(8.0, $ruleUnlimited);
        $this->assertEquals(8.0, $res2['carried_forward']);
        $this->assertEquals(0.0, $res2['expired']);

        // 3. Allowed, max days 0 (none)
        $ruleZeroMax = [
            'carry_forward_allowed'  => true,
            'carry_forward_max_days' => 0,
        ];
        $res3 = LeaveAccrualCalculator::calculateCarryForward(8.0, $ruleZeroMax);
        $this->assertEquals(0.0, $res3['carried_forward']);
        $this->assertEquals(8.0, $res3['expired']);

        // 4. Allowed, capped at 3 days: balance 8, use 5, baki 3 -> 3 carried, 0 expired
        $ruleCapped = [
            'carry_forward_allowed'  => true,
            'carry_forward_max_days' => 3,
        ];
        $res4 = LeaveAccrualCalculator::calculateCarryForward(3.0, $ruleCapped);
        $this->assertEquals(3.0, $res4['carried_forward']);
        $this->assertEquals(0.0, $res4['expired']);

        // 5. Allowed, balance 8, max 5 -> 5 carried, 3 expired
        $res5 = LeaveAccrualCalculator::calculateCarryForward(8.0, ['carry_forward_allowed' => true, 'carry_forward_max_days' => 5]);
        $this->assertEquals(5.0, $res5['carried_forward']);
        $this->assertEquals(3.0, $res5['expired']);
    }

    /**
     * Requirement: Live balance calculation as of date via LeaveAccrualCalculator.
     */
    public function testLiveBalanceDerivation()
    {
        $employee = [
            'id'           => 'EMP-005',
            'company_id'   => 'COMP-001',
            'joining_date' => '2026-01-01',
            'status'       => 'Active',
        ];

        $rule = [
            'leave_type_code'       => 'EL',
            'accrual_mode'          => 'Calendar days',
            'earn_every_days'       => 12,
            'earn_leave_per_cycle'  => 1.0,
            'accrual_credit_timing' => 'on_completion',
            'accrual_start_from'    => 'joining_date',
        ];

        $ledgerTotals = [
            'opening_balance'        => 0.0,
            'carry_forward_days'     => 3.0,
            'approved_leave_days'    => 2.0,
            'pending_leave_days'     => 1.0,
            'unpaid_adjustment_days' => 0.0,
            'encashed_days'          => 0.0,
            'expired_days'           => 0.0,
        ];

        // As of 2026-01-24: 24 days elapsed = 2 earned
        // Total entitlement = 0 + 2 + 3 = 5.0
        // Total deductions = 2 (approved) + 1 (pending) = 3.0
        // Available balance = 5.0 - 3.0 = 2.0
        $liveBal = LeaveAccrualCalculator::calculateLiveBalance($employee, $rule, $ledgerTotals, '2026-01-24');

        $this->assertEquals(2.0, $liveBal['earned_days']);
        $this->assertEquals(3.0, $liveBal['carry_forward_days']);
        $this->assertEquals(5.0, $liveBal['total_entitlement']);
        $this->assertEquals(3.0, $liveBal['total_deductions']);
        $this->assertEquals(2.0, $liveBal['available_balance']);
    }

    /**
     * Requirement: Prior-year cumulative clipping in Calendar days accrual.
     * An employee joining in 2024 must only accrue days within the target year (2026).
     */
    public function testCalendarDaysPerYearClipping()
    {
        $employee = [
            'id'           => 'EMP-HISTORICAL',
            'company_id'   => 'COMP-001',
            'joining_date' => '2024-05-10', // Joined ~20 months ago
            'status'       => 'Active',
        ];

        $rule = [
            'leave_type_code'       => 'EL',
            'accrual_mode'          => 'Calendar days',
            'earn_every_days'       => 12,
            'earn_leave_per_cycle'  => 1.0,
            'days_per_year'         => 18,
            'accrual_credit_timing' => 'on_completion',
            'accrual_start_from'    => 'joining_date',
        ];

        // In 2026-01-24: 24 days elapsed in 2026 = 2 cycles earned (not ~50 cycles since 2024!)
        $earned2026 = LeaveAccrualCalculator::calculateEarnedDays($employee, $rule, '2026-01-24');
        $this->assertEquals(2.0, $earned2026);
    }

    /**
     * Requirement: Live balance is authoritative to rule; lower rule rate is not overridden by higher stored accrued_days.
     */
    public function testLiveBalanceNotOverriddenByStoredAccruedDays()
    {
        $employee = [
            'id'           => 'EMP-007',
            'company_id'   => 'COMP-001',
            'joining_date' => '2026-01-01',
            'status'       => 'Active',
        ];

        // Rule calculates 2.0 earned days as of 2026-01-24
        $rule = [
            'leave_type_code'       => 'EL',
            'accrual_mode'          => 'Calendar days',
            'earn_every_days'       => 12,
            'earn_leave_per_cycle'  => 1.0,
            'accrual_credit_timing' => 'on_completion',
            'accrual_start_from'    => 'joining_date',
        ];

        // DB previously had stale/higher accrued_days = 10.0
        $ledgerTotals = [
            'opening_balance'        => 0.0,
            'accrued_days'           => 10.0,
            'carry_forward_days'     => 0.0,
            'approved_leave_days'    => 0.0,
            'pending_leave_days'     => 0.0,
            'unpaid_adjustment_days' => 0.0,
            'encashed_days'          => 0.0,
            'expired_days'           => 0.0,
        ];

        $liveBal = LeaveAccrualCalculator::calculateLiveBalance($employee, $rule, $ledgerTotals, '2026-01-24');
        // Earned days and total entitlement must reflect the rule (2.0), not the stale DB value (10.0)
        $this->assertEquals(2.0, $liveBal['earned_days']);
        $this->assertEquals(2.0, $liveBal['total_entitlement']);
        $this->assertEquals(2.0, $liveBal['available_balance']);
    }

    /**
     * Requirement: Standardized deterministic cycle numbering.
     */
    public function testCycleNumberGeneration()
    {
        $employee = [
            'id'           => 'EMP-006',
            'company_id'   => 'COMP-001',
            'joining_date' => '2026-01-01',
        ];

        $calendarRule = [
            'accrual_mode'          => 'Calendar days',
            'earn_every_days'       => 12,
            'accrual_credit_timing' => 'on_completion',
            'accrual_start_from'    => 'joining_date',
        ];

        $monthlyRule = [
            'accrual_mode' => 'Monthly accrual',
        ];

        $cycle1 = LeaveAccrualCalculator::getCycleNumber($employee, $calendarRule, '2026-01-12');
        $this->assertEquals('CYCLE-12D-1', $cycle1);

        $cycle2 = LeaveAccrualCalculator::getCycleNumber($employee, $calendarRule, '2026-01-24');
        $this->assertEquals('CYCLE-12D-2', $cycle2);

        $monthCycle = LeaveAccrualCalculator::getCycleNumber($employee, $monthlyRule, '2026-03-15');
        $this->assertEquals('MONTH-2026-03', $monthCycle);
    }

    /**
     * Requirement: Unlimited carry forward (carry_forward_max_days = null) respects overall max_balance_cap.
     */
    public function testCarryForwardWithUnlimitedDaysAndMaxBalanceCap()
    {
        // 1. Unlimited carry forward without cap
        $ruleNoCap = [
            'carry_forward_allowed'  => true,
            'carry_forward_max_days' => null,
            'max_balance_cap'        => null,
        ];
        $resNoCap = LeaveAccrualCalculator::calculateCarryForward(45.0, $ruleNoCap);
        $this->assertEquals(45.0, $resNoCap['carried_forward']);
        $this->assertEquals(0.0, $resNoCap['expired']);

        // 2. Unlimited carry forward WITH overall max_balance_cap = 30.0
        $ruleWithCap = [
            'carry_forward_allowed'  => true,
            'carry_forward_max_days' => null,
            'max_balance_cap'        => 30.0,
        ];
        $resWithCap = LeaveAccrualCalculator::calculateCarryForward(45.0, $ruleWithCap);
        $this->assertEquals(30.0, $resWithCap['carried_forward']);
        $this->assertEquals(15.0, $resWithCap['expired']);

        // 3. Capped carry forward (max 15.0) with max_balance_cap = 30.0
        $ruleCapped = [
            'carry_forward_allowed'  => true,
            'carry_forward_max_days' => 15.0,
            'max_balance_cap'        => 30.0,
        ];
        $resCapped = LeaveAccrualCalculator::calculateCarryForward(45.0, $ruleCapped);
        $this->assertEquals(15.0, $resCapped['carried_forward']);
        $this->assertEquals(30.0, $resCapped['expired']);
    }
}
