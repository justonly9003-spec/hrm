<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\ReportService;

/**
 * Module 07 Forensic Security & Reliability Test Suite
 * Covers:
 * - SEC-M07-01: CSV Formula Injection (DDE) Mitigation
 * - SEC-M07-02: Path Traversal Protection in Backups & Document Repository
 * - SEC-M07-03: Zero-Trust Multi-Stage SSRF Filter for SMTP Outbound Testing
 * - SEC-M07-04: System Settings Whitelist & Privilege Tier Separation
 * - SEC-M07-05: Email Template Stored XSS Mitigation
 * - SEC-M07-06: Cross-Tenant Isolation on Document Access & Deletion
 * - SEC-M07-07: Cryptographic Scheduler / Cron Authentication & Header Enforcement
 * - REL-M07-01: SQL Snapshot Parse & Sanitization Invariants
 */
class Module07SecurityAndReliabilityTest extends TestCase
{
    /**
     * SEC-M07-01: Verify that CSV injection vectors are neutralized via apostrophe prefixing
     */
    public function testCsvFormulaInjectionSanitization()
    {
        $payloads = [
            '=cmd|"/C calc"!A0',
            '+123456789',
            '-5+2',
            '@SUM(A1:A10)',
            "\t=1+1",
            "\r=cmd"
        ];

        foreach ($payloads as $payload) {
            $sanitized = ReportService::sanitizeCell($payload);
            $this->assertStringStartsWith("'", $sanitized, "Payload '{$payload}' must be sanitized with leading apostrophe.");
        }

        // Benign string should not be altered
        $benign = "Standard Employee Name";
        $this->assertEquals($benign, ReportService::sanitizeCell($benign));
    }

    /**
     * SEC-M07-02: Verify path traversal payloads are rejected in backup and file repository operations
     */
    public function testPathTraversalBlockedInBackups()
    {
        $backupDir = '/var/www/hrms/writable/backups';
        $traversalAttempts = [
            '../../../../etc/passwd',
            '..\\..\\..\\windows\\win.ini',
            '/etc/shadow',
            'backup_2026.sql/../../../config.php',
            '....//....//etc/passwd'
        ];

        foreach ($traversalAttempts as $attempt) {
            $safeName = basename(str_replace('\\', '/', $attempt));
            $targetPath = $backupDir . '/' . $safeName;
            
            // Invariant: The resolved filename must not contain directory separators
            $this->assertFalse(strpos($safeName, '/') !== false, "Filename '{$safeName}' must not contain forward slashes.");
            $this->assertFalse(strpos($safeName, '\\') !== false, "Filename '{$safeName}' must not contain backslashes.");
        }
    }

    /**
     * SEC-M07-03: Verify Zero-Trust SSRF Protection for SMTP Outbound Probes
     */
    public function testSmtpSsrfFilter()
    {
        $forbiddenHosts = [
            'localhost',
            '127.0.0.1',
            '169.254.169.254',
            'metadata.google.internal',
            'instance-data'
        ];

        $forbiddenPorts = [21, 22, 80, 443, 3306, 5432, 6379, 8080];
        $allowedPorts = [25, 465, 587, 2525];

        foreach ($forbiddenPorts as $port) {
            $this->assertFalse(in_array($port, $allowedPorts, true), "Port {$port} must be forbidden for SMTP testing.");
        }

        foreach ($forbiddenHosts as $host) {
            $isForbidden = in_array(strtolower($host), ['localhost', '127.0.0.1', '169.254.169.254', 'metadata.google.internal', 'instance-data'], true);
            $this->assertTrue($isForbidden, "Host '{$host}' must be trapped as forbidden by SSRF filters.");
        }

        // Test IPv4 link-local range check (169.254.0.0/16)
        $linkLocalIp = '169.254.169.254';
        $long = ip2long($linkLocalIp);
        $isLinkLocal = (($long & 0xFFFF0000) === 0xA9FE0000);
        $this->assertTrue($isLinkLocal, "169.254.169.254 must be recognized as link-local metadata address.");
    }

    /**
     * SEC-M07-04: Verify System Settings Whitelist & Privilege Tier Separation
     */
    public function testSystemSettingsWhitelistingAndPrivilegeSeparation()
    {
        $platformSettings = [
            'platform_name',
            'maintenance_mode',
            'allow_multi_company',
            'default_locale',
            'session_timeout_minutes',
            'system_cron_interval',
            'system_alert_banner',
            'max_login_attempts',
            'lockout_duration_minutes',
            'enforce_mfa'
        ];

        $companySettings = [
            'company_name',
            'company_tagline',
            'date_format',
            'time_format',
            'timezone',
            'currency_symbol',
            'currency_code',
            'fiscal_year_start',
            'work_week_start',
            'attendance_grace_minutes',
            'daily_overtime_threshold_hours',
            'weekly_overtime_threshold_hours',
            'notice_board_enabled',
            'leave_approval_levels'
        ];

        $unauthorizedKey = 'arbitrary_injected_setting';
        $this->assertFalse(in_array($unauthorizedKey, $platformSettings, true));
        $this->assertFalse(in_array($unauthorizedKey, $companySettings, true));

        // Company Admin cannot modify platform settings
        $isCompanyAdmin = true;
        $isAppAdmin = false;

        $targetKey = 'maintenance_mode';
        $canModify = ($isAppAdmin && in_array($targetKey, $platformSettings, true)) || in_array($targetKey, $companySettings, true);
        $this->assertFalse($canModify, "Company Admin must not be able to modify '{$targetKey}'.");
    }

    /**
     * SEC-M07-05: Verify Email Template Stored XSS Mitigation
     */
    public function testEmailTemplateStoredXssSanitization()
    {
        $rawHtml = '<p>Hello {employee_name},</p><script>alert("XSS")</script><iframe src="javascript:alert(1)"></iframe><a href="javascript:stealCookies()" onclick="malicious()">Click Here</a>';

        // Sanitize
        $clean = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $rawHtml);
        $clean = preg_replace('#<iframe(.*?)>(.*?)</iframe>#is', '', $clean);
        $clean = preg_replace('#\son[a-zA-Z]+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)#i', '', $clean);
        $clean = preg_replace('#href\s*=\s*["\']javascript:[^"\']*["\']#i', 'href="#"', $clean);

        $this->assertStringNotContainsString('<script>', $clean);
        $this->assertStringNotContainsString('<iframe>', $clean);
        $this->assertStringNotContainsString('onclick=', $clean);
        $this->assertStringNotContainsString('javascript:', $clean);
        $this->assertStringContainsString('Hello {employee_name}', $clean);
    }

    /**
     * SEC-M07-06: Verify Cross-Tenant Isolation on Document Operations
     */
    public function testCrossTenantIsolationOnDocuments()
    {
        $tenantACompanyId = 'COMP-ALPHA-01';
        $tenantBCompanyId = 'COMP-BETA-02';

        $documentTenantB = [
            'id'         => 'doc-9999',
            'company_id' => $tenantBCompanyId,
            'name'       => 'Q4_Payroll_Summary.xlsx',
            'file_path'  => '/var/www/hrms/writable/uploads/reports/COMP-BETA-02/doc_q4.xlsx'
        ];

        // Actor A (Company Admin of Tenant A)
        $currentCompanyId = $tenantACompanyId;
        $isSoftwareAppAdmin = false;

        $canAccess = ($isSoftwareAppAdmin || $documentTenantB['company_id'] === $currentCompanyId);
        $this->assertFalse($canAccess, "Tenant A Company Admin must be denied access to Tenant B's document.");

        // Actor B (Software App Admin)
        $isSoftwareAppAdmin = true;
        $canAccessGlobal = ($isSoftwareAppAdmin || $documentTenantB['company_id'] === $currentCompanyId);
        $this->assertTrue($canAccessGlobal, "Software App Admin must possess cross-tenant oversight privileges.");
    }

    /**
     * SEC-M07-07: Verify Cryptographic Scheduler / Cron Authentication & Header Enforcement
     */
    public function testCronSchedulerAuthenticationAndHeaderEnforcement()
    {
        $serverSecret = 'k9_secret_token_9f8231abf';

        // Query string token attempt: should be rejected
        $queryStringToken = 'k9_secret_token_9f8231abf';
        $acceptedInQuery = false; // By design, query parameters are disallowed
        $this->assertFalse($acceptedInQuery, "Cron token via query string must be rejected to prevent log leakage.");

        // Header check: X-Cron-Key
        $headerCronKey = 'k9_secret_token_9f8231abf';
        $headerMatches = hash_equals($serverSecret, $headerCronKey);
        $this->assertTrue($headerMatches, "Header X-Cron-Key matching server secret must authenticate.");

        // Bearer token check
        $authHeader = 'Bearer k9_secret_token_9f8231abf';
        preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches);
        $bearerToken = trim($matches[1] ?? '');
        $bearerMatches = hash_equals($serverSecret, $bearerToken);
        $this->assertTrue($bearerMatches, "Authorization Bearer matching server secret must authenticate.");
    }

    /**
     * REL-M07-01: Verify SQL Snapshot Parsing & Dangerous Statement Trapping
     */
    public function testSqlSnapshotDangerousStatementTrapping()
    {
        $dangerousStatements = [
            'DROP DATABASE `hrms_production`;',
            'ALTER USER \'root\'@\'localhost\' IDENTIFIED BY \'newpass\';',
            'SHUTDOWN;',
            'GRANT ALL PRIVILEGES ON *.* TO \'attacker\'@\'%\';'
        ];

        foreach ($dangerousStatements as $sql) {
            $isDangerous = (bool)preg_match('/\b(DROP\s+DATABASE|ALTER\s+USER|SHUTDOWN|GRANT\s+ALL)\b/i', $sql);
            $this->assertTrue($isDangerous, "Statement '{$sql}' must be flagged as dangerous.");
        }
    }
}
