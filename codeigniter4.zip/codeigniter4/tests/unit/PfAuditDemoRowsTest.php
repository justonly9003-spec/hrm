<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use App\Commands\PfAuditDemoRows;
use App\Database\Migrations\EnsureProvidentFundLedgerSchemaAndUniqueIndex;
use CodeIgniter\Events\Events;
use Config\Database;

/**
 * DB-Backed Test for PfAuditDemoRows Command:
 *
 * 1. Correctly classifies exact demo rows (matching company, employee, and ID pattern).
 * 2. Does NOT flag real 2026 transactions with reference_no 'PF-TXN-202607-xxxx' as demo or suspicious.
 * 3. Classifies partial matches (demo ID in real company, demo company with real-looking ID) as SUSPICIOUS, never DEMO.
 * 4. Computes per-company breakdown of total, demo, and suspicious rows accurately.
 * 5. Generates safe parenthesised SELECT and commented-out DELETE queries.
 * 6. Purely read-only: query listener proves command executes ZERO write queries (INSERT, UPDATE, DELETE).
 */
class PfAuditDemoRowsTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected static bool $schemaInitialized = false;

    public static function setUpBeforeClass(): void
    {
        parent::setUpBeforeClass();
        static::ensureSchema();
    }

    protected static function ensureSchema(): void
    {
        if (static::$schemaInitialized) {
            return;
        }

        $db = Database::connect();
        if (!$db->tableExists('provident_fund_ledgers')) {
            $migration = new EnsureProvidentFundLedgerSchemaAndUniqueIndex();
            $migration->up();
        }

        static::$schemaInitialized = true;
    }

    protected function setUp(): void
    {
        parent::setUp();
        $db = Database::connect();
        if ($db->tableExists('provident_fund_ledgers')) {
            $db->table('provident_fund_ledgers')->truncate();
        }
    }

    protected function tearDown(): void
    {
        $db = Database::connect();
        if ($db->tableExists('provident_fund_ledgers')) {
            $db->table('provident_fund_ledgers')->truncate();
        }
        parent::tearDown();
    }

    /**
     * Test 1: Unit classification of rows into DEMO, SUSPICIOUS, and REAL
     */
    public function testClassifyRowUnitRules(): void
    {
        $cmd = new PfAuditDemoRows();

        // 1. Confirmed Demo: matches company + employee + ID pattern
        $demoRow1 = [
            'id'          => 'PFL-202601-001',
            'company_id'  => 'COMP-001',
            'employee_id' => 'EMP-001',
        ];
        $this->assertSame(PfAuditDemoRows::CLASSIFICATION_DEMO, $cmd->classifyRow($demoRow1));

        $demoRow2 = [
            'id'          => 'PFL-OPEN-005',
            'company_id'  => 'COMP-002',
            'employee_id' => 'EMP-005',
        ];
        $this->assertSame(PfAuditDemoRows::CLASSIFICATION_DEMO, $cmd->classifyRow($demoRow2));

        // 2. Real transaction: even with 2026 reference_no, payroll_id, and notes, it's REAL
        $realRow = [
            'id'           => 'PFL-A1B2C3D4E5',
            'company_id'   => 'COMP-REAL-CORP',
            'employee_id'  => 'EMP-REAL-888',
            'reference_no' => 'PF-TXN-202607-0001',
            'payroll_id'   => 'PAY-2026-07-888',
            'notes'        => 'Salary batch PF contribution for July 2026',
        ];
        $this->assertSame(PfAuditDemoRows::CLASSIFICATION_REAL, $cmd->classifyRow($realRow));

        // 3. Suspicious: demo ID pattern in non-demo company
        $suspiciousDemoIdInRealCompany = [
            'id'          => 'PFL-OPEN-001',
            'company_id'  => 'COMP-REAL-CORP',
            'employee_id' => 'EMP-REAL-888',
        ];
        $this->assertSame(PfAuditDemoRows::CLASSIFICATION_SUSPICIOUS, $cmd->classifyRow($suspiciousDemoIdInRealCompany));
        $this->assertStringContainsString("Demo ID pattern in non-demo company 'COMP-REAL-CORP'", $cmd->getSuspiciousReason($suspiciousDemoIdInRealCompany));

        // 4. Suspicious: demo company with non-demo ID pattern
        $suspiciousDemoCompRealId = [
            'id'          => 'PFL-PROD-999',
            'company_id'  => 'COMP-001',
            'employee_id' => 'EMP-001',
        ];
        $this->assertSame(PfAuditDemoRows::CLASSIFICATION_SUSPICIOUS, $cmd->classifyRow($suspiciousDemoCompRealId));
        $this->assertStringContainsString('non-demo ID pattern', $cmd->getSuspiciousReason($suspiciousDemoCompRealId));

        // 5. Suspicious: demo employee in real company
        $suspiciousDemoEmpInRealComp = [
            'id'          => 'PFL-RANDOM-001',
            'company_id'  => 'COMP-REAL-CORP',
            'employee_id' => 'EMP-001',
        ];
        $this->assertSame(PfAuditDemoRows::CLASSIFICATION_SUSPICIOUS, $cmd->classifyRow($suspiciousDemoEmpInRealComp));
    }

    /**
     * Test 2: Database audit with mixed seed data and per-company breakdown
     */
    public function testDatabaseAuditWithMixedSeedData(): void
    {
        $db = Database::connect();
        $cmd = new PfAuditDemoRows();

        // Seed rows:
        // Row 1: Confirmed demo monthly contribution
        $db->table('provident_fund_ledgers')->insert([
            'id'                    => 'PFL-202601-001',
            'company_id'            => 'COMP-001',
            'employee_id'           => 'EMP-001',
            'payroll_id'            => 'PAY-2026-1-001',
            'payroll_month'         => 1,
            'payroll_year'          => 2026,
            'pf_rule_id'            => 'PF-RULE-STANDARD-10',
            'transaction_type'      => 'CONTRIBUTION',
            'pf_base_salary'        => 50000.00,
            'employee_contribution' => 5000.00,
            'employer_contribution' => 5000.00,
            'total_contribution'    => 10000.00,
            'running_balance'       => 10000.00,
            'transaction_date'      => '2026-01-28',
            'status'                => 'posted',
            'reference_no'          => 'PF-TXN-202601-001',
            'created_by'            => 'SYSTEM',
        ]);

        // Row 2: Confirmed demo opening balance
        $db->table('provident_fund_ledgers')->insert([
            'id'                    => 'PFL-OPEN-004',
            'company_id'            => 'COMP-002',
            'employee_id'           => 'EMP-004',
            'payroll_id'            => null,
            'payroll_month'         => 12,
            'payroll_year'          => 2025,
            'pf_rule_id'            => 'PF-RULE-STANDARD-10',
            'transaction_type'      => 'OPENING_BALANCE',
            'pf_base_salary'        => 45000.00,
            'employee_contribution' => 9000.00,
            'employer_contribution' => 9000.00,
            'total_contribution'    => 18000.00,
            'running_balance'       => 18000.00,
            'transaction_date'      => '2025-12-31',
            'status'                => 'posted',
            'reference_no'          => 'OB-2025-004',
            'created_by'            => 'SYSTEM',
        ]);

        // Row 3: REAL row in a REAL company with 2026 reference_no (must NOT be demo or suspicious)
        $db->table('provident_fund_ledgers')->insert([
            'id'                    => 'PFL-REAL-BATCH-01',
            'company_id'            => 'COMP-REAL-PROD',
            'employee_id'           => 'EMP-REAL-001',
            'payroll_id'            => 'PAY-2026-07-001',
            'payroll_month'         => 7,
            'payroll_year'          => 2026,
            'pf_rule_id'            => 'PF-RULE-CUSTOM',
            'transaction_type'      => 'CONTRIBUTION',
            'pf_base_salary'        => 70000.00,
            'employee_contribution' => 7000.00,
            'employer_contribution' => 7000.00,
            'total_contribution'    => 14000.00,
            'running_balance'       => 14000.00,
            'transaction_date'      => '2026-07-28',
            'status'                => 'posted',
            'reference_no'          => 'PF-TXN-202607-0001',
            'notes'                 => 'Salary batch PF contribution for July 2026',
            'created_by'            => 'USER-HR',
        ]);

        // Row 4: Suspicious row: Demo ID pattern ('PFL-OPEN-999') in real company
        $db->table('provident_fund_ledgers')->insert([
            'id'                    => 'PFL-OPEN-999',
            'company_id'            => 'COMP-REAL-PROD',
            'employee_id'           => 'EMP-REAL-002',
            'payroll_id'            => null,
            'payroll_month'         => 12,
            'payroll_year'          => 2025,
            'transaction_type'      => 'OPENING_BALANCE',
            'total_contribution'    => 5000.00,
            'running_balance'       => 5000.00,
            'transaction_date'      => '2025-12-31',
            'status'                => 'posted',
            'created_by'            => 'USER-HR',
        ]);

        // Row 5: Suspicious row: Demo company and employee, but real-looking ID pattern
        $db->table('provident_fund_ledgers')->insert([
            'id'                    => 'PFL-PROD-OVERRIDE-01',
            'company_id'            => 'COMP-001',
            'employee_id'           => 'EMP-001',
            'payroll_id'            => 'PAY-2026-08-001',
            'payroll_month'         => 8,
            'payroll_year'          => 2026,
            'transaction_type'      => 'CONTRIBUTION',
            'total_contribution'    => 8000.00,
            'running_balance'       => 18000.00,
            'transaction_date'      => '2026-08-28',
            'status'                => 'posted',
            'created_by'            => 'SYSTEM',
        ]);

        // Execute audit
        $audit = $cmd->audit($db);

        $this->assertTrue($audit['table_exists']);
        $this->assertSame(5, $audit['total_ledger_rows']);
        $this->assertCount(2, $audit['demo_rows'], 'Must identify exactly 2 demo rows.');
        $this->assertCount(2, $audit['suspicious_rows'], 'Must identify exactly 2 suspicious rows.');

        // Demo rows must contain Row 1 and Row 2
        $demoIds = array_column($audit['demo_rows'], 'id');
        $this->assertContains('PFL-202601-001', $demoIds);
        $this->assertContains('PFL-OPEN-004', $demoIds);
        $this->assertNotContains('PFL-REAL-BATCH-01', $demoIds, 'Real 2026 transaction must NEVER be classified as demo.');
        $this->assertNotContains('PFL-OPEN-999', $demoIds, 'Suspicious demo ID in real company must NEVER be classified as demo.');
        $this->assertNotContains('PFL-PROD-OVERRIDE-01', $demoIds, 'Suspicious non-demo ID pattern must NEVER be classified as demo.');

        // Suspicious rows must contain Row 4 and Row 5
        $suspiciousIds = array_column($audit['suspicious_rows'], 'id');
        $this->assertContains('PFL-OPEN-999', $suspiciousIds);
        $this->assertContains('PFL-PROD-OVERRIDE-01', $suspiciousIds);
        $this->assertNotContains('PFL-REAL-BATCH-01', $suspiciousIds, 'Pure real row must NOT be marked suspicious.');

        // Verify Per-Company breakdown counts
        $perCompany = $audit['per_company'];
        $this->assertArrayHasKey('COMP-001', $perCompany);
        $this->assertArrayHasKey('COMP-002', $perCompany);
        $this->assertArrayHasKey('COMP-REAL-PROD', $perCompany);

        // COMP-001: 2 total (1 demo, 1 suspicious)
        $this->assertSame(2, $perCompany['COMP-001']['total_rows']);
        $this->assertSame(1, $perCompany['COMP-001']['demo_rows']);
        $this->assertSame(1, $perCompany['COMP-001']['suspicious_rows']);
        $this->assertSame('DEMO DETECTED', $perCompany['COMP-001']['status']);

        // COMP-002: 1 total (1 demo, 0 suspicious)
        $this->assertSame(1, $perCompany['COMP-002']['total_rows']);
        $this->assertSame(1, $perCompany['COMP-002']['demo_rows']);
        $this->assertSame(0, $perCompany['COMP-002']['suspicious_rows']);
        $this->assertSame('DEMO DETECTED', $perCompany['COMP-002']['status']);

        // COMP-REAL-PROD: 2 total (0 demo, 1 suspicious)
        $this->assertSame(2, $perCompany['COMP-REAL-PROD']['total_rows']);
        $this->assertSame(0, $perCompany['COMP-REAL-PROD']['demo_rows']);
        $this->assertSame(1, $perCompany['COMP-REAL-PROD']['suspicious_rows']);
        $this->assertSame('SUSPICIOUS', $perCompany['COMP-REAL-PROD']['status']);

        // Safe SQL Suggestion verification:
        // Must contain parentheses around the OR condition: (id LIKE 'PFL-OPEN-%' OR id LIKE 'PFL-2026%')
        $expectedWhere = "(id LIKE 'PFL-OPEN-%' OR id LIKE 'PFL-2026%') AND company_id IN ('COMP-001', 'COMP-002') AND employee_id IN ('EMP-001', 'EMP-002', 'EMP-003', 'EMP-004', 'EMP-005')";
        $this->assertStringContainsString($expectedWhere, $audit['select_sql']);
        $this->assertStringContainsString($expectedWhere, $audit['delete_sql']);
        $this->assertStringStartsWith('SELECT * FROM provident_fund_ledgers WHERE', $audit['select_sql']);
        $this->assertStringStartsWith('-- DELETE FROM provident_fund_ledgers WHERE', $audit['delete_sql'], 'Delete statement must be commented out.');
    }

    /**
     * Test 3: Read-Only Enforcement via Database Query Listener
     * Proves command executes ZERO INSERT, UPDATE, DELETE, ALTER, DROP, TRUNCATE queries.
     */
    public function testCommandExecutesZeroWriteQueries(): void
    {
        $db = Database::connect();

        // Seed 1 record
        $db->table('provident_fund_ledgers')->insert([
            'id'                 => 'PFL-202601-001',
            'company_id'         => 'COMP-001',
            'employee_id'        => 'EMP-001',
            'transaction_type'   => 'CONTRIBUTION',
            'total_contribution' => 1000.00,
            'running_balance'    => 1000.00,
            'transaction_date'   => '2026-01-28',
            'status'             => 'posted',
        ]);

        $initialRowCount = (int)$db->table('provident_fund_ledgers')->countAllResults(false);
        $this->assertSame(1, $initialRowCount);

        $writeQueries = [];
        $queryListener = static function ($query) use (&$writeQueries) {
            $sql = trim((string)$query);
            if (preg_match('/^\s*(INSERT|UPDATE|DELETE|DROP|ALTER|TRUNCATE|REPLACE)\b/i', $sql)) {
                $writeQueries[] = $sql;
            }
        };

        Events::on('DBQuery', $queryListener);

        try {
            $cmd = new PfAuditDemoRows();
            $cmd->audit($db);

            $this->assertEmpty($writeQueries, 'PfAuditDemoRows must NOT execute write queries. Found: ' . implode('; ', $writeQueries));

            $finalRowCount = (int)$db->table('provident_fund_ledgers')->countAllResults(false);
            $this->assertSame($initialRowCount, $finalRowCount, 'Row count must be identical before and after audit.');
        } finally {
            // Unregister listener to prevent test leakage
            $listeners = Events::listeners('DBQuery');
            foreach ($listeners as $listener) {
                Events::removeListener('DBQuery', $listener);
            }
        }
    }
}
