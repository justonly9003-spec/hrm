<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use App\Models\ProvidentFundLedgerModel;
use App\Database\Migrations\EnsureProvidentFundLedgerSchemaAndUniqueIndex;
use Config\Database;

/**
 * ProvidentFundAccountingAuditTest
 *
 * Verifies accounting consistency across:
 * - Monthly payroll contributions
 * - Backdated salary revision arrears (Arrear PF)
 * - Manual interest credit vouchers (without automated accrual engine)
 * - Administrative adjustments
 * - Compensating reversal vouchers (avoiding double-deduction)
 * - Draft transaction isolation and batch commit/revert
 * - Authoritative single-source calculation parity
 */
class ProvidentFundAccountingAuditTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected static bool $schemaInitialized = false;

    public static function setUpBeforeClass(): void
    {
        parent::setUpBeforeClass();
        static::ensureSchema();
    }

    protected static function ensureSchema(): void
    {
        if (static::$schemaInitialized) {
            return;
        }

        $db = Database::connect();
        if (!$db->tableExists('provident_fund_ledgers')) {
            $migration = new EnsureProvidentFundLedgerSchemaAndUniqueIndex();
            $migration->up();
        }

        static::$schemaInitialized = true;
    }

    protected function setUp(): void
    {
        parent::setUp();
        $db = Database::connect();
        if ($db->tableExists('provident_fund_ledgers')) {
            $db->table('provident_fund_ledgers')->truncate();
        }
    }

    /**
     * 1. Contribution posting and running balance accumulation
     */
    public function testContributionPostingAccumulatesBalance(): void
    {
        $model = new ProvidentFundLedgerModel();
        $empId = 'emp-audit-001';
        $compId = 'comp-audit-mercury';

        $tx1 = $model->recordContribution([
            'company_id'            => $compId,
            'employee_id'           => $empId,
            'payroll_month'         => 1,
            'payroll_year'          => 2026,
            'transaction_type'      => 'CONTRIBUTION',
            'pf_base_salary'        => 50000.00,
            'employee_contribution' => 2500.00,
            'employer_contribution' => 2500.00,
            'total_contribution'    => 5000.00,
            'transaction_date'      => '2026-01-31',
            'status'                => 'posted',
        ]);

        $this->assertNotEmpty($tx1['id']);
        $this->assertEquals(5000.00, (float)$tx1['running_balance']);
        $this->assertEquals(5000.00, $model->getLatestBalance($empId));

        $tx2 = $model->recordContribution([
            'company_id'            => $compId,
            'employee_id'           => $empId,
            'payroll_month'         => 2,
            'payroll_year'          => 2026,
            'transaction_type'      => 'CONTRIBUTION',
            'pf_base_salary'        => 50000.00,
            'employee_contribution' => 2500.00,
            'employer_contribution' => 2500.00,
            'total_contribution'    => 5000.00,
            'transaction_date'      => '2026-02-28',
            'status'                => 'posted',
        ]);

        $this->assertEquals(10000.00, (float)$tx2['running_balance']);
        $this->assertEquals(10000.00, $model->getLatestBalance($empId));
    }

    /**
     * 2. Arrear contributions are included in savings and employer totals
     */
    public function testArrearContributionIncludedInTotals(): void
    {
        $model = new ProvidentFundLedgerModel();
        $empId = 'emp-audit-002';
        $compId = 'comp-audit-mercury';

        // Regular contribution
        $model->recordContribution([
            'company_id'            => $compId,
            'employee_id'           => $empId,
            'payroll_month'         => 1,
            'payroll_year'          => 2026,
            'transaction_type'      => 'CONTRIBUTION',
            'pf_base_salary'        => 50000.00,
            'employee_contribution' => 2500.00,
            'employer_contribution' => 2500.00,
            'total_contribution'    => 5000.00,
            'transaction_date'      => '2026-01-31',
            'status'                => 'posted',
        ]);

        // Backdated revision arrear contribution
        $model->recordContribution([
            'company_id'            => $compId,
            'employee_id'           => $empId,
            'payroll_month'         => 1,
            'payroll_year'          => 2026,
            'transaction_type'      => 'Arrear',
            'pf_base_salary'        => 10000.00,
            'employee_contribution' => 500.00,
            'employer_contribution' => 500.00,
            'total_contribution'    => 1000.00,
            'transaction_date'      => '2026-02-15',
            'status'                => 'posted',
            'notes'                 => 'Retroactive salary increment increment arrear',
        ]);

        $summary = $model->calculateEmployeeSummary($empId);
        $this->assertTrue($summary['has_pf']);
        $this->assertEquals(3000.00, $summary['employee_contribution'], 'Arrear employee portion must be summed into employee contribution.');
        $this->assertEquals(3000.00, $summary['employer_contribution'], 'Arrear employer portion must be summed into employer contribution.');
        $this->assertEquals(6000.00, $summary['balance'], 'Closing balance must be 6000.00.');
    }

    /**
     * 3. Manual interest voucher credit without automated accrual engine
     */
    public function testInterestVoucherCreditWithoutAccrualEngine(): void
    {
        $model = new ProvidentFundLedgerModel();
        $empId = 'emp-audit-003';
        $compId = 'comp-audit-mercury';

        $model->recordContribution([
            'company_id'            => $compId,
            'employee_id'           => $empId,
            'payroll_month'         => 6,
            'payroll_year'          => 2026,
            'transaction_type'      => 'CONTRIBUTION',
            'pf_base_salary'        => 60000.00,
            'employee_contribution' => 3000.00,
            'employer_contribution' => 3000.00,
            'total_contribution'    => 6000.00,
            'transaction_date'      => '2026-06-30',
            'status'                => 'posted',
        ]);

        // Annual trust interest voucher
        $model->recordContribution([
            'company_id'            => $compId,
            'employee_id'           => $empId,
            'payroll_month'         => 6,
            'payroll_year'          => 2026,
            'transaction_type'      => 'INTEREST',
            'pf_base_salary'        => 0.00,
            'employee_contribution' => 0.00,
            'employer_contribution' => 0.00,
            'total_contribution'    => 450.00,
            'transaction_date'      => '2026-06-30',
            'status'                => 'posted',
            'reference_no'          => 'INT-2026-FY',
            'notes'                 => 'Annual PF Trust interest allocation',
        ]);

        $summary = $model->calculateEmployeeSummary($empId);
        $this->assertEquals(450.00, $summary['interest']);
        $this->assertEquals(6450.00, $summary['balance']);
    }

    /**
     * 4. Manual adjustment voucher allocation
     */
    public function testAdjustmentVoucherAllocation(): void
    {
        $model = new ProvidentFundLedgerModel();
        $empId = 'emp-audit-004';
        $compId = 'comp-audit-mercury';

        $model->recordContribution([
            'company_id'            => $compId,
            'employee_id'           => $empId,
            'payroll_month'         => 3,
            'payroll_year'          => 2026,
            'transaction_type'      => 'CONTRIBUTION',
            'pf_base_salary'        => 40000.00,
            'employee_contribution' => 2000.00,
            'employer_contribution' => 2000.00,
            'total_contribution'    => 4000.00,
            'transaction_date'      => '2026-03-31',
            'status'                => 'posted',
        ]);

        // Adjustment entry
        $model->recordContribution([
            'company_id'            => $compId,
            'employee_id'           => $empId,
            'payroll_month'         => 3,
            'payroll_year'          => 2026,
            'transaction_type'      => 'ADJUSTMENT',
            'pf_base_salary'        => 0.00,
            'employee_contribution' => 150.00,
            'employer_contribution' => 150.00,
            'total_contribution'    => 300.00,
            'transaction_date'      => '2026-04-05',
            'status'                => 'posted',
            'notes'                 => 'Audit reconciliation adjustment',
        ]);

        $summary = $model->calculateEmployeeSummary($empId);
        $this->assertEquals(300.00, $summary['adjustments']);
        $this->assertEquals(4300.00, $summary['balance']);
    }

    /**
     * 5. Reversal vouchers net to zero and prevent double-deduction defect
     */
    public function testReversalVoucherNetsToZeroAndPreventsDoubleDeduction(): void
    {
        $model = new ProvidentFundLedgerModel();
        $empId = 'emp-audit-005';
        $compId = 'comp-audit-mercury';

        // January: Valid contribution
        $model->recordContribution([
            'company_id'            => $compId,
            'employee_id'           => $empId,
            'payroll_month'         => 1,
            'payroll_year'          => 2026,
            'transaction_type'      => 'CONTRIBUTION',
            'pf_base_salary'        => 50000.00,
            'employee_contribution' => 2500.00,
            'employer_contribution' => 2500.00,
            'total_contribution'    => 5000.00,
            'transaction_date'      => '2026-01-31',
            'status'                => 'posted',
        ]);

        // February: Erroneous contribution
        $febTx = $model->recordContribution([
            'company_id'            => $compId,
            'employee_id'           => $empId,
            'payroll_month'         => 2,
            'payroll_year'          => 2026,
            'transaction_type'      => 'CONTRIBUTION',
            'pf_base_salary'        => 50000.00,
            'employee_contribution' => 2500.00,
            'employer_contribution' => 2500.00,
            'total_contribution'    => 5000.00,
            'transaction_date'      => '2026-02-28',
            'status'                => 'posted',
        ]);

        $this->assertEquals(10000.00, $model->getLatestBalance($empId));

        // Perform authorized reversal of February contribution
        $reversalTx = $model->createReversal(
            $febTx['id'],
            'Payroll batch correction - employee resigned in Jan',
            'auditor-admin-01'
        );

        $this->assertNotNull($reversalTx);
        $this->assertEquals('REVERSAL', $reversalTx['transaction_type']);
        $this->assertEquals(-2500.00, (float)$reversalTx['employee_contribution']);
        $this->assertEquals(-2500.00, (float)$reversalTx['employer_contribution']);
        $this->assertEquals(-5000.00, (float)$reversalTx['total_contribution']);
        $this->assertEquals(5000.00, (float)$reversalTx['running_balance']);

        // Check running balance: Must be exactly 5000.00 (NOT 0.00 or -5000.00 from double deduction)
        $this->assertEquals(5000.00, $model->getLatestBalance($empId));

        // Summary must net out the reversed pair:
        // Employee savings: 2500.00 (from Jan)
        // Employer match: 2500.00 (from Jan)
        // Closing balance: 5000.00
        $summary = $model->calculateEmployeeSummary($empId);
        $this->assertEquals(2500.00, $summary['employee_contribution'], 'Reversed February entry must net out to 0; only January must remain in savings.');
        $this->assertEquals(2500.00, $summary['employer_contribution'], 'Reversed February entry must net out to 0; only January must remain in match.');
        $this->assertEquals(5000.00, $summary['balance'], 'Corpus balance must be exactly 5000.00.');
    }

    /**
     * 6. Draft entries are isolated and excluded from statements and balances
     */
    public function testDraftEntriesExcludedFromStatementsAndBalances(): void
    {
        $model = new ProvidentFundLedgerModel();
        $empId = 'emp-audit-006';
        $compId = 'comp-audit-mercury';

        // Posted entry
        $model->recordContribution([
            'company_id'            => $compId,
            'employee_id'           => $empId,
            'payroll_month'         => 1,
            'payroll_year'          => 2026,
            'transaction_type'      => 'CONTRIBUTION',
            'pf_base_salary'        => 50000.00,
            'employee_contribution' => 2500.00,
            'employer_contribution' => 2500.00,
            'total_contribution'    => 5000.00,
            'transaction_date'      => '2026-01-31',
            'status'                => 'posted',
        ]);

        // Draft uncommitted payroll entry
        $draftPayroll = [
            'id'          => 'pay-item-draft-99',
            'payroll_id'  => 'batch-draft-feb',
            'employee_id' => $empId,
            'company_id'  => $compId,
            'month'       => 2,
            'year'        => 2026,
        ];
        $draftPf = [
            'employee_contribution' => 2500.00,
            'employer_contribution' => 2500.00,
            'total_contribution'    => 5000.00,
            'pf_base_salary'        => 50000.00,
        ];

        $draftRecord = $model->recordPayrollContribution($draftPayroll, $draftPf, 'hr-user', 'draft');
        $this->assertEquals('draft', $draftRecord['status']);

        // Check latest balance: draft must NOT be included
        $this->assertEquals(5000.00, $model->getLatestBalance($empId));

        // Check statement: draft entries must NOT pollute posted savings or balance
        $stmt = $model->getEmployeeStatement($empId, 2026);
        $this->assertEquals(2500.00, $stmt['total_employee_savings'], 'Draft payroll must not be counted in employee savings.');
        $this->assertEquals(2500.00, $stmt['total_employer_match'], 'Draft payroll must not be counted in employer matching.');
        $this->assertEquals(5000.00, $stmt['current_accumulated_balance'], 'Draft payroll must not affect accumulated balance.');
        $this->assertEquals(5000.00, $stmt['draft_uncommitted_amount'], 'Draft payroll must be tracked under draft_uncommitted_amount.');
    }

    /**
     * 7. Batch commit promotes draft transactions to posted
     */
    public function testBatchCommitPromotesDraftsToPosted(): void
    {
        $model = new ProvidentFundLedgerModel();
        $empId = 'emp-audit-007';
        $compId = 'comp-audit-mercury';
        $batchId = 'batch-apr-2026';

        $draftPayroll = [
            'id'          => 'pay-item-apr-01',
            'payroll_id'  => $batchId,
            'employee_id' => $empId,
            'company_id'  => $compId,
            'month'       => 4,
            'year'        => 2026,
        ];
        $draftPf = [
            'employee_contribution' => 3000.00,
            'employer_contribution' => 3000.00,
            'total_contribution'    => 6000.00,
            'pf_base_salary'        => 60000.00,
        ];

        $model->recordPayrollContribution($draftPayroll, $draftPf, 'hr-user', 'draft');
        $this->assertEquals(0.00, $model->getLatestBalance($empId));

        // Commit batch
        $committedCount = $model->commitBatchContributions($batchId, 'payroll-manager');
        $this->assertEquals(1, $committedCount);

        // Verify promoted to posted and balance active
        $this->assertEquals(6000.00, $model->getLatestBalance($empId));

        $stmt = $model->getEmployeeStatement($empId, 2026);
        $this->assertEquals(3000.00, $stmt['total_employee_savings']);
        $this->assertEquals(3000.00, $stmt['total_employer_match']);
        $this->assertEquals(6000.00, $stmt['current_accumulated_balance']);
        $this->assertEquals(0.00, $stmt['draft_uncommitted_amount']);
    }

    /**
     * 8. Batch revert purges draft transactions
     */
    public function testBatchRevertPurgesDrafts(): void
    {
        $model = new ProvidentFundLedgerModel();
        $empId = 'emp-audit-008';
        $compId = 'comp-audit-mercury';
        $batchId = 'batch-cancelled-may';

        // 1. Initial posted entry
        $model->recordContribution([
            'company_id'            => $compId,
            'employee_id'           => $empId,
            'payroll_month'         => 4,
            'payroll_year'          => 2026,
            'transaction_type'      => 'CONTRIBUTION',
            'pf_base_salary'        => 50000.00,
            'employee_contribution' => 2500.00,
            'employer_contribution' => 2500.00,
            'total_contribution'    => 5000.00,
            'transaction_date'      => '2026-04-30',
            'status'                => 'posted',
        ]);

        // 2. Draft entry for May
        $draftPayroll = [
            'id'          => 'pay-item-may-draft',
            'payroll_id'  => $batchId,
            'employee_id' => $empId,
            'company_id'  => $compId,
            'month'       => 5,
            'year'        => 2026,
        ];
        $draftPf = [
            'employee_contribution' => 2500.00,
            'employer_contribution' => 2500.00,
            'total_contribution'    => 5000.00,
            'pf_base_salary'        => 50000.00,
        ];
        $model->recordPayrollContribution($draftPayroll, $draftPf, 'hr-user', 'draft');

        // Revert draft batch
        $revertedCount = $model->revertDraftBatch($batchId);
        $this->assertEquals(1, $revertedCount);

        // Pre-batch state preserved intact
        $this->assertEquals(5000.00, $model->getLatestBalance($empId));
        $summary = $model->calculateEmployeeSummary($empId);
        $this->assertEquals(2500.00, $summary['employee_contribution']);
        $this->assertEquals(2500.00, $summary['employer_contribution']);
        $this->assertEquals(5000.00, $summary['balance']);
    }

    /**
     * 9. Passbook statement and summary calculation mathematical parity
     */
    public function testSingleSourceCalculationParityAcrossStatementAndSummary(): void
    {
        $model = new ProvidentFundLedgerModel();
        $empId = 'emp-audit-009';
        $compId = 'comp-audit-mercury';

        // Jan: Contribution
        $model->recordContribution([
            'company_id'            => $compId,
            'employee_id'           => $empId,
            'payroll_month'         => 1,
            'payroll_year'          => 2026,
            'transaction_type'      => 'CONTRIBUTION',
            'pf_base_salary'        => 50000.00,
            'employee_contribution' => 2500.00,
            'employer_contribution' => 2500.00,
            'total_contribution'    => 5000.00,
            'transaction_date'      => '2026-01-31',
            'status'                => 'posted',
        ]);

        // Feb: Arrear
        $model->recordContribution([
            'company_id'            => $compId,
            'employee_id'           => $empId,
            'payroll_month'         => 1,
            'payroll_year'          => 2026,
            'transaction_type'      => 'Arrear',
            'pf_base_salary'        => 10000.00,
            'employee_contribution' => 500.00,
            'employer_contribution' => 500.00,
            'total_contribution'    => 1000.00,
            'transaction_date'      => '2026-02-15',
            'status'                => 'posted',
        ]);

        // Mar: Interest
        $model->recordContribution([
            'company_id'            => $compId,
            'employee_id'           => $empId,
            'payroll_month'         => 3,
            'payroll_year'          => 2026,
            'transaction_type'      => 'INTEREST',
            'pf_base_salary'        => 0.00,
            'employee_contribution' => 0.00,
            'employer_contribution' => 0.00,
            'total_contribution'    => 300.00,
            'transaction_date'      => '2026-03-31',
            'status'                => 'posted',
        ]);

        $summary = $model->calculateEmployeeSummary($empId, null, 2026);
        $statement = $model->getEmployeeStatement($empId, 2026);

        // Verify absolute parity across single-source calculations
        $this->assertEquals($summary['balance'], $statement['current_accumulated_balance'], 'Corpus balances must be identical.');
        $this->assertEquals($summary['employee_contribution'], $statement['total_employee_savings'], 'Employee savings must be identical.');
        $this->assertEquals($summary['employer_contribution'], $statement['total_employer_match'], 'Employer matches must be identical.');
        $this->assertEquals($summary['interest'], $statement['total_interest_earned'], 'Interest earnings must be identical.');
        $this->assertEquals(6300.00, $summary['balance']);
    }
}
