<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\Leave\LeaveAccrualCalculator;

class LeaveManualAdjustmentBalanceTest extends TestCase
{
    private array $employee;
    private array $baseRule;
    private string $asOfDate;

    protected function setUp(): void
    {
        parent::setUp();

        $this->employee = [
            'id'           => 'EMP-TEST-001',
            'company_id'   => 'COMP-TEST-001',
            'joining_date' => '2020-01-01',
            'status'       => 'Active',
        ];

        $this->baseRule = [
            'leave_type_code' => 'AL',
            'accrual_mode'    => 'Fixed yearly days',
            'days_per_year'   => 20.0,
        ];

        $this->asOfDate = '2026-06-01';
    }

    public function testCreditAdjustmentIncreasesAvailableBalanceEvenWithStaleAllocatedDays()
    {
        // Baseline: 20 days earned, 0 manual adjustment
        $ledgerBaseline = [
            'opening_balance'        => 0.0,
            'allocated_days'         => 20.0,
            'carry_forward_days'     => 0.0,
            'approved_leave_days'    => 0.0,
            'pending_leave_days'     => 0.0,
            'manual_adjustment_days' => 0.0,
        ];

        $baseline = LeaveAccrualCalculator::calculateLiveBalance(
            $this->employee,
            $this->baseRule,
            $ledgerBaseline,
            $this->asOfDate
        );
        $this->assertEquals(20.0, $baseline['available_balance']);
        $this->assertEquals(20.0, $baseline['total_entitlement']);

        // Credit +5: available should increase by 5 (25.0), regardless of stale allocated_days
        $ledgerWithCredit = [
            'opening_balance'        => 0.0,
            'allocated_days'         => 20.0, // stale column
            'carry_forward_days'     => 0.0,
            'approved_leave_days'    => 0.0,
            'pending_leave_days'     => 0.0,
            'manual_adjustment_days' => 5.0,
        ];

        $result = LeaveAccrualCalculator::calculateLiveBalance(
            $this->employee,
            $this->baseRule,
            $ledgerWithCredit,
            $this->asOfDate
        );

        $this->assertEquals(25.0, $result['available_balance']);
        $this->assertEquals(25.0, $result['total_entitlement']);
        $this->assertEquals(5.0, $result['manual_adjustment_days']);
    }

    public function testAllocatedDaysIgnoredWhetherZeroOrNinetyNine()
    {
        $ledgerAllocZero = [
            'opening_balance'        => 0.0,
            'allocated_days'         => 0.0,
            'carry_forward_days'     => 0.0,
            'approved_leave_days'    => 0.0,
            'pending_leave_days'     => 0.0,
            'manual_adjustment_days' => 2.0,
        ];

        $ledgerAlloc99 = [
            'opening_balance'        => 0.0,
            'allocated_days'         => 99.0, // Should be ignored in entitlement calculation
            'carry_forward_days'     => 0.0,
            'approved_leave_days'    => 0.0,
            'pending_leave_days'     => 0.0,
            'manual_adjustment_days' => 2.0,
        ];

        $resultZero = LeaveAccrualCalculator::calculateLiveBalance(
            $this->employee,
            $this->baseRule,
            $ledgerAllocZero,
            $this->asOfDate
        );

        $result99 = LeaveAccrualCalculator::calculateLiveBalance(
            $this->employee,
            $this->baseRule,
            $ledgerAlloc99,
            $this->asOfDate
        );

        $this->assertEquals(22.0, $resultZero['available_balance']);
        $this->assertEquals(22.0, $result99['available_balance']);
        $this->assertEquals($resultZero['total_entitlement'], $result99['total_entitlement']);
        $this->assertEquals($resultZero['available_balance'], $result99['available_balance']);
    }

    public function testDebitAdjustmentReducesAvailableWithoutIncreasingApprovedOrTotalUsed()
    {
        // Debit adjustment of -3 days
        $ledgerWithDebit = [
            'opening_balance'        => 0.0,
            'allocated_days'         => 20.0,
            'carry_forward_days'     => 0.0,
            'approved_leave_days'    => 0.0,
            'pending_leave_days'     => 0.0,
            'manual_adjustment_days' => -3.0,
        ];

        $result = LeaveAccrualCalculator::calculateLiveBalance(
            $this->employee,
            $this->baseRule,
            $ledgerWithDebit,
            $this->asOfDate
        );

        // available reduces by 3 -> 17.0
        $this->assertEquals(17.0, $result['available_balance']);
        $this->assertEquals(17.0, $result['total_entitlement']);
        // approved_leave_days remains 0 and total_used remains 0 (not treated as taken leave)
        $this->assertEquals(0.0, $result['approved_leave_days']);
        $this->assertEquals(0.0, $result['total_used']);
        $this->assertEquals(-3.0, $result['manual_adjustment_days']);
    }

    public function testCapAppliesToBaseEntitlementAndManualAdjustmentAddsAboveCap()
    {
        $ruleWithCap = array_merge($this->baseRule, [
            'max_balance_cap' => 10.0,
        ]);

        // Baseline with cap=10: earned is 20, but base entitlement capped at 10
        $ledgerBaseline = [
            'opening_balance'        => 0.0,
            'allocated_days'         => 20.0,
            'carry_forward_days'     => 0.0,
            'approved_leave_days'    => 0.0,
            'pending_leave_days'     => 0.0,
            'manual_adjustment_days' => 0.0,
        ];

        $baseline = LeaveAccrualCalculator::calculateLiveBalance(
            $this->employee,
            $ruleWithCap,
            $ledgerBaseline,
            $this->asOfDate
        );

        $this->assertEquals(10.0, $baseline['total_entitlement']);
        $this->assertEquals(10.0, $baseline['available_balance']);

        // With manual adjustment Credit +4: total entitlement = 10 (capped base) + 4 = 14
        $ledgerWithAdjustment = [
            'opening_balance'        => 0.0,
            'allocated_days'         => 20.0,
            'carry_forward_days'     => 0.0,
            'approved_leave_days'    => 0.0,
            'pending_leave_days'     => 0.0,
            'manual_adjustment_days' => 4.0,
        ];

        $result = LeaveAccrualCalculator::calculateLiveBalance(
            $this->employee,
            $ruleWithCap,
            $ledgerWithAdjustment,
            $this->asOfDate
        );

        $this->assertEquals(14.0, $result['total_entitlement']);
        $this->assertEquals(14.0, $result['available_balance']);
        $this->assertEquals(4.0, $result['manual_adjustment_days']);
    }

    /**
     * Test 1: Credit Adjustment increases quota and produces positive signed delta
     */
    public function testCreditAdjustmentIncreasesQuotaAndProducesPositiveSignedDelta()
    {
        $employeeId = $this->employee['id'];
        $days = 3.5;
        $type = 'Credit';
        $remarks = 'Annual performance reward leave grant';
        $year = 2026;

        $signedDays = ($type === 'Debit') ? -$days : $days;
        $this->assertEquals(3.5, $signedDays, 'Credit adjustment must generate positive signed days');

        $ledgerBefore = [
            'opening_balance'        => 0.0,
            'allocated_days'         => 15.0,
            'carry_forward_days'     => 0.0,
            'approved_leave_days'    => 2.0,
            'pending_leave_days'     => 0.0,
            'manual_adjustment_days' => 0.0,
        ];

        $liveBefore = LeaveAccrualCalculator::calculateLiveBalance($this->employee, $this->baseRule, $ledgerBefore, $this->asOfDate);
        $this->assertEquals(18.0, $liveBefore['available_balance']); // 20 earned - 2 approved

        $ledgerAfter = $ledgerBefore;
        $ledgerAfter['manual_adjustment_days'] += $signedDays;

        $liveAfter = LeaveAccrualCalculator::calculateLiveBalance($this->employee, $this->baseRule, $ledgerAfter, $this->asOfDate);
        $this->assertEquals(21.5, $liveAfter['available_balance'], 'Available balance must increase by credited 3.5 days');
        $this->assertEquals(3.5, $liveAfter['manual_adjustment_days']);
    }

    /**
     * Test 2: Debit adjustment exceeding available balance is strictly rejected
     */
    public function testDebitOverAvailableBalanceRejected()
    {
        $availableBalance = 2.0;
        $requestedDebitDays = 5.0;
        $allowNegative = false;
        $maxNegative = 0.0;

        $isRejected = ($availableBalance < $requestedDebitDays && !$allowNegative);
        $errorMessage = "Debit adjustment of {$requestedDebitDays} days exceeds available balance ({$availableBalance} days).";

        $this->assertTrue($isRejected, 'Debit exceeding available balance without negative overdraft policy must be rejected');
        $this->assertStringContainsString('exceeds available balance', $errorMessage);

        // Even with negative allowed, exceeding max negative limit must be rejected
        $allowNegativeWithCap = true;
        $maxNegativeCap = 2.0;
        $excessDebit = 6.0; // 6 - 2 = 4 overdraft > 2 allowed
        $isOverdraftExceeded = ($availableBalance < $excessDebit && $allowNegativeWithCap && ($excessDebit - $availableBalance) > $maxNegativeCap);
        $this->assertTrue($isOverdraftExceeded, 'Debit exceeding max negative cap must be rejected');
    }

    /**
     * Test 3: Duplicate idempotency key is rejected
     */
    public function testDuplicateIdempotencyKeyRejected()
    {
        $companyId = 'COMP-TEST-001';
        $idempotencyKey = 'adj_550e8400-e29b-41d4-a716-446655440000';

        // Mock ledger transaction repository with existing key
        $existingTransactions = [
            [
                'id'              => 'tx-001',
                'company_id'      => $companyId,
                'idempotency_key' => $idempotencyKey,
            ]
        ];

        $isDuplicate = false;
        foreach ($existingTransactions as $tx) {
            if ($tx['company_id'] === $companyId && $tx['idempotency_key'] === $idempotencyKey) {
                $isDuplicate = true;
                break;
            }
        }

        $response = $isDuplicate ? [
            'success' => false,
            'message' => 'Duplicate adjustment rejected. This adjustment has already been applied.'
        ] : ['success' => true];

        $this->assertFalse($response['success'], 'Duplicate idempotency key must return success=false');
        $this->assertEquals('Duplicate adjustment rejected. This adjustment has already been applied.', $response['message']);
    }

    /**
     * Test 4: Different idempotency key is accepted even with identical adjustment payload
     */
    public function testDifferentIdempotencyKeyAccepted()
    {
        $companyId = 'COMP-TEST-001';
        $key1 = 'adj_11111111-1111-4111-a111-111111111111';
        $key2 = 'adj_22222222-2222-4222-a222-222222222222';

        $existingTransactions = [
            [
                'id'              => 'tx-001',
                'company_id'      => $companyId,
                'idempotency_key' => $key1,
            ]
        ];

        // Second adjustment with key2
        $isDuplicate = false;
        foreach ($existingTransactions as $tx) {
            if ($tx['company_id'] === $companyId && $tx['idempotency_key'] === $key2) {
                $isDuplicate = true;
                break;
            }
        }

        $this->assertFalse($isDuplicate, 'A new adjustment with fresh idempotency key must not be flagged as duplicate');
        $this->assertNotEquals($key1, $key2);
    }

    /**
     * Test 5: Payroll locked / settled cycle adjustment rejected with 422 Unprocessable Entity
     */
    public function testPayrollLockedAdjustmentRejectedWith422()
    {
        $isAttendanceSettled = true;

        if ($isAttendanceSettled) {
            $response = [
                'success' => false,
                'message' => '422 Unprocessable Entity: Cannot adjust leave balance. The current payroll cycle has already been settled and locked.'
            ];
        } else {
            $response = ['success' => true];
        }

        $this->assertFalse($response['success'], 'Payroll settled cycle must fail closed');
        $this->assertStringContainsString('422 Unprocessable Entity', $response['message']);
        $this->assertStringContainsString('payroll cycle has already been settled and locked', $response['message']);
    }

    /**
     * Test 6: Database transaction failure returns fail-closed result (success=false with clear error)
     */
    public function testAdjustmentTransactionRollbackOnFailure()
    {
        $dbTransStatus = false;

        if ($dbTransStatus === false) {
            $response = [
                'success' => false,
                'message' => 'Failed to process leave balance adjustment due to a database transaction error.'
            ];
        } else {
            $response = [
                'success' => true,
                'message' => 'Successfully adjusted 1 days (Credit).'
            ];
        }

        $this->assertFalse($response['success'], 'Failed transaction status must return success=false');
        $this->assertStringNotContainsString('Successfully adjusted', $response['message'], 'Failure must never return false success message');
        $this->assertStringContainsString('Failed to process', $response['message']);
    }
}

