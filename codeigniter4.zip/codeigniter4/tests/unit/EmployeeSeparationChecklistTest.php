<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use App\Controllers\Employee\EmployeeSeparationController;
use App\Models\EmployeeModel;
use Config\Database;

/**
 * Real Database and Controller Tests for Mandatory Clearance Checklist Verification:
 * 1. Missing checklist_assets returns HTTP 400 and does not terminate employee.
 * 2. Missing checklist_docs returns HTTP 400 and does not terminate employee.
 * 3. Missing checklist_dues returns HTTP 400 and does not terminate employee.
 * 4. Empty/unselected checklist fields return HTTP 400.
 * 5. All three checklist items present, but employee has an Assigned asset returns HTTP 422 from asset guard.
 * 6. All three checklist items present and no assigned assets terminates employee with HTTP 200.
 */
class EmployeeSeparationChecklistTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected static bool $schemaInitialized = false;

    protected string $tenantCompanyId = 'comp-chk-test-01';
    protected string $tenantBranchId  = 'branch-chk-test-01';
    protected string $tenantDeptId    = 'dept-chk-test-01';
    protected string $tenantDesgId    = 'desg-chk-test-01';

    protected array $adminUser = [];

    public static function setUpBeforeClass(): void
    {
        parent::setUpBeforeClass();
        static::ensureSchema();
    }

    public static function registerSqliteFunctions($db): void
    {
        try {
            $rawConn = $db->connID ?? null;
            if ($rawConn instanceof \SQLite3) {
                $rawConn->createFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->createFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            } elseif (is_object($rawConn) && method_exists($rawConn, 'sqliteCreateFunction')) {
                $rawConn->sqliteCreateFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->sqliteCreateFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            }
        } catch (\Throwable $e) {
            // ignore
        }
    }

    protected static function ensureSchema(): void
    {
        $db = Database::connect();
        static::registerSqliteFunctions($db);

        $schemaFile = __DIR__ . '/Rules/schema.sqlite.sql';
        if (file_exists($schemaFile)) {
            $sql = file_get_contents($schemaFile);
            $statements = array_filter(array_map('trim', explode(';', $sql)));
            foreach ($statements as $stmt) {
                if (!empty($stmt)) {
                    try {
                        $db->query($stmt);
                    } catch (\Throwable $e) {
                        // ignore
                    }
                }
            }
        }

        // Ensure employee_terminations table exists
        $db->query("CREATE TABLE IF NOT EXISTS employee_terminations (
            id VARCHAR(36) PRIMARY KEY,
            employee_id VARCHAR(36) NOT NULL,
            termination_date DATE NOT NULL,
            termination_type VARCHAR(100) DEFAULT 'Termination',
            reason TEXT NOT NULL,
            notice_period_days INT DEFAULT 0,
            status VARCHAR(50) DEFAULT 'Pending',
            approved_by VARCHAR(100),
            clearance_status VARCHAR(50) DEFAULT 'In Progress',
            final_settlement_status VARCHAR(50) DEFAULT 'Pending',
            exit_interview_notes TEXT,
            terminated_by VARCHAR(36),
            created_at DATETIME,
            updated_at DATETIME
        )");

        // Ensure company_assets table exists
        $db->query("CREATE TABLE IF NOT EXISTS company_assets (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36) NOT NULL,
            asset_name VARCHAR(150) NOT NULL,
            asset_code VARCHAR(50),
            category VARCHAR(50),
            assigned_to VARCHAR(36),
            assigned_date DATE,
            status VARCHAR(50) DEFAULT 'Available',
            written_off_at DATETIME,
            written_off_reason TEXT,
            deleted_at DATETIME,
            created_at DATETIME,
            updated_at DATETIME
        )");

        // Ensure audit_logs table exists
        $db->query("CREATE TABLE IF NOT EXISTS audit_logs (
            id VARCHAR(36) PRIMARY KEY,
            user_id VARCHAR(36),
            company_id VARCHAR(36),
            module VARCHAR(50),
            action VARCHAR(50),
            record_id VARCHAR(36),
            entity_id VARCHAR(36),
            entity_type VARCHAR(50),
            details TEXT,
            old_values LONGTEXT,
            new_values LONGTEXT,
            ip_address VARCHAR(45),
            user_agent TEXT,
            created_at DATETIME
        )");

        static::$schemaInitialized = true;
    }

    protected function setUp(): void
    {
        parent::setUp();
        static::ensureSchema();

        $db = Database::connect();
        static::registerSqliteFunctions($db);

        // Seed Company, Branch, Department, Designation
        $db->table('companies')->replace([
            'id'     => $this->tenantCompanyId,
            'name'   => 'Checklist Testing Corp',
            'code'   => 'CTC',
            'status' => 'Active',
        ]);

        $db->table('branches')->replace([
            'id'         => $this->tenantBranchId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'HQ Branch',
            'code'       => 'BR-HQ',
            'status'     => 'Active',
        ]);

        $db->table('departments')->replace([
            'id'         => $this->tenantDeptId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'Engineering',
            'code'       => 'DEP-ENG',
            'status'     => 'Active',
        ]);

        $db->table('designations')->replace([
            'id'         => $this->tenantDesgId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'Software Engineer',
            'code'       => 'DES-SE',
            'status'     => 'Active',
        ]);

        $this->adminUser = [
            'id'                  => 'usr-chk-admin-01',
            'company_id'          => $this->tenantCompanyId,
            'username'            => 'chk_admin',
            'name'                => 'Checklist Admin',
            'email'               => 'chk_admin@test.com',
            'role'                => 'Company Admin',
            'role_code'           => 'company_admin',
            'role_id'             => 'role-chk-admin',
            'selected_company_id' => $this->tenantCompanyId,
            'permissions'         => ['*'],
        ];

        $db->table('users')->replace([
            'id'            => $this->adminUser['id'],
            'company_id'    => $this->tenantCompanyId,
            'username'      => $this->adminUser['username'],
            'email'         => $this->adminUser['email'],
            'password_hash' => password_hash('Secret123!', PASSWORD_BCRYPT),
            'role_id'       => $this->adminUser['role_id'],
            'status'        => 'Active',
        ]);
    }

    protected function setupController($controllerClass, ?array $actor = null)
    {
        $actorUser = $actor ?? $this->adminUser;

        \App\Services\PermissionService::clearCache();
        \App\Services\PermissionService::flushCache();

        $session = \Config\Services::session();
        $session->set([
            'id'                  => $actorUser['id'],
            'user_id'             => $actorUser['id'],
            'username'            => $actorUser['username'],
            'name'                => $actorUser['name'],
            'email'               => $actorUser['email'],
            'role'                => $actorUser['role'],
            'role_code'           => $actorUser['role_code'],
            'role_id'             => $actorUser['role_id'],
            'company_id'          => $actorUser['company_id'],
            'selected_company_id' => $actorUser['company_id'],
            'permissions'         => ['*'],
        ]);

        $request = \Config\Services::request();
        $response = \Config\Services::response();
        $logger = \Config\Services::logger();

        $controller = new $controllerClass();
        $controller->initController($request, $response, $logger);

        $refUser = new \ReflectionProperty(\App\Controllers\BaseController::class, 'currentUser');
        $refUser->setAccessible(true);
        $refUser->setValue($controller, $actorUser);

        return $controller;
    }

    protected function setPostRequest(array $postData, bool $isAjax = true): void
    {
        if ($isAjax) {
            $_SERVER['HTTP_X_REQUESTED_WITH'] = 'xmlhttprequest';
            $_SERVER['HTTP_ACCEPT'] = 'application/json';
        } else {
            unset($_SERVER['HTTP_X_REQUESTED_WITH']);
            $_SERVER['HTTP_ACCEPT'] = 'text/html';
        }
        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_POST = $postData;

        $request = \Config\Services::request();
        $refPost = new \ReflectionProperty($request, 'body');
        $refPost->setAccessible(true);
        $refPost->setValue($request, $postData);
    }

    protected function createEmployee(string $empId, string $status = 'Active'): array
    {
        $db = Database::connect();
        $emp = [
            'id'                   => $empId,
            'company_id'           => $this->tenantCompanyId,
            'branch_id'            => $this->tenantBranchId,
            'department_id'        => $this->tenantDeptId,
            'designation_id'       => $this->tenantDesgId,
            'employee_code'        => 'EMP-' . strtoupper(substr(md5($empId), 0, 6)),
            'first_name'           => 'Emp',
            'last_name'            => substr($empId, 4),
            'email'                => "{$empId}@test.com",
            'reporting_manager_id' => null,
            'manager_id'           => null,
            'status'               => $status,
            'deleted_at'           => null,
            'created_at'           => date('Y-m-d H:i:s'),
            'updated_at'           => date('Y-m-d H:i:s'),
        ];
        $db->table('employees')->replace($emp);
        return $emp;
    }

    protected function createAsset(string $assetId, ?string $assignedTo = null, string $status = 'Available', ?string $deletedAt = null): array
    {
        $db = Database::connect();
        $asset = [
            'id'                         => $assetId,
            'company_id'                 => $this->tenantCompanyId,
            'asset_name'                 => 'Test Asset ' . $assetId,
            'asset_code'                 => 'AST-' . strtoupper(substr(md5($assetId), 0, 6)),
            'category'                   => 'IT Equipment',
            'assigned_to'                => $assignedTo,
            'assigned_date'              => $assignedTo ? date('Y-m-d') : null,
            'status'                     => $status,
            'written_off_at'             => null,
            'written_off_reason'         => null,
            'deleted_at'                 => $deletedAt,
            'created_at'                 => date('Y-m-d H:i:s'),
            'updated_at'                 => date('Y-m-d H:i:s'),
        ];
        $db->table('company_assets')->replace($asset);
        return $asset;
    }

    /**
     * Test Case 1: Missing checklist_assets returns HTTP 400 and does NOT terminate the employee.
     */
    public function testMissingChecklistAssetsReturns400AndDoesNotTerminate()
    {
        $db = Database::connect();
        $empId = 'emp-chk-01';
        $this->createEmployee($empId);

        $controller = $this->setupController(EmployeeSeparationController::class);
        $this->setPostRequest([
            'employee_id'      => $empId,
            'termination_date' => date('Y-m-d'),
            'reason'           => 'Restructuring',
            // checklist_assets is omitted
            'checklist_docs'   => '1',
            'checklist_dues'   => '1',
        ], true);

        $response = $controller->saveTermination();
        $this->assertEquals(400, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success']);
        $this->assertEquals(
            'All items in the mandatory clearance checklist (company assets surrendered, credentials/docs revoked, and user account/settlement dues cleared) must be verified before termination.',
            $body['message']
        );

        // Employee status must remain Active in DB
        $emp = (new EmployeeModel())->find($empId);
        $this->assertEquals('Active', $emp['status']);

        // No termination record created
        $term = $db->table('employee_terminations')->where('employee_id', $empId)->get()->getRowArray();
        $this->assertNull($term);
    }

    /**
     * Test Case 2: Missing checklist_docs returns HTTP 400 and does NOT terminate the employee.
     */
    public function testMissingChecklistDocsReturns400AndDoesNotTerminate()
    {
        $db = Database::connect();
        $empId = 'emp-chk-02';
        $this->createEmployee($empId);

        $controller = $this->setupController(EmployeeSeparationController::class);
        $this->setPostRequest([
            'employee_id'      => $empId,
            'termination_date' => date('Y-m-d'),
            'reason'           => 'Restructuring',
            'checklist_assets' => '1',
            // checklist_docs is omitted
            'checklist_dues'   => '1',
        ], true);

        $response = $controller->saveTermination();
        $this->assertEquals(400, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success']);
        $this->assertEquals(
            'All items in the mandatory clearance checklist (company assets surrendered, credentials/docs revoked, and user account/settlement dues cleared) must be verified before termination.',
            $body['message']
        );

        $emp = (new EmployeeModel())->find($empId);
        $this->assertEquals('Active', $emp['status']);

        $term = $db->table('employee_terminations')->where('employee_id', $empId)->get()->getRowArray();
        $this->assertNull($term);
    }

    /**
     * Test Case 3: Missing checklist_dues returns HTTP 400 and does NOT terminate the employee.
     */
    public function testMissingChecklistDuesReturns400AndDoesNotTerminate()
    {
        $db = Database::connect();
        $empId = 'emp-chk-03';
        $this->createEmployee($empId);

        $controller = $this->setupController(EmployeeSeparationController::class);
        $this->setPostRequest([
            'employee_id'      => $empId,
            'termination_date' => date('Y-m-d'),
            'reason'           => 'Restructuring',
            'checklist_assets' => '1',
            'checklist_docs'   => '1',
            // checklist_dues is omitted
        ], true);

        $response = $controller->saveTermination();
        $this->assertEquals(400, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success']);
        $this->assertEquals(
            'All items in the mandatory clearance checklist (company assets surrendered, credentials/docs revoked, and user account/settlement dues cleared) must be verified before termination.',
            $body['message']
        );

        $emp = (new EmployeeModel())->find($empId);
        $this->assertEquals('Active', $emp['status']);

        $term = $db->table('employee_terminations')->where('employee_id', $empId)->get()->getRowArray();
        $this->assertNull($term);
    }

    /**
     * Test Case 4: Empty string values for checklist items also return HTTP 400.
     */
    public function testEmptyStringChecklistValuesReturn400()
    {
        $empId = 'emp-chk-04';
        $this->createEmployee($empId);

        $controller = $this->setupController(EmployeeSeparationController::class);
        $this->setPostRequest([
            'employee_id'      => $empId,
            'termination_date' => date('Y-m-d'),
            'reason'           => 'Contract ended',
            'checklist_assets' => '',
            'checklist_docs'   => '',
            'checklist_dues'   => '',
        ], true);

        $response = $controller->saveTermination();
        $this->assertEquals(400, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success']);

        $emp = (new EmployeeModel())->find($empId);
        $this->assertEquals('Active', $emp['status']);
    }

    /**
     * Test Case 5: All 3 checklist fields present, but employee has an Assigned asset.
     * Must return HTTP 422 from the asset guard and NOT terminate employee.
     */
    public function testAllChecklistPresentWithAssignedAssetReturns422()
    {
        $db = Database::connect();
        $empId = 'emp-chk-05';
        $this->createEmployee($empId);
        $this->createAsset('ast-chk-05', $empId, 'Assigned');

        $controller = $this->setupController(EmployeeSeparationController::class);
        $this->setPostRequest([
            'employee_id'      => $empId,
            'termination_date' => date('Y-m-d'),
            'reason'           => 'Performance dismissal',
            'checklist_assets' => '1',
            'checklist_docs'   => '1',
            'checklist_dues'   => '1',
        ], true);

        $response = $controller->saveTermination();
        $this->assertEquals(422, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success']);
        $this->assertStringContainsString('unreturned company asset', $body['message']);

        // Employee must not be terminated
        $emp = (new EmployeeModel())->find($empId);
        $this->assertEquals('Active', $emp['status']);

        $term = $db->table('employee_terminations')->where('employee_id', $empId)->get()->getRowArray();
        $this->assertNull($term);
    }

    /**
     * Test Case 6: All 3 checklist fields present and NO assigned assets.
     * Must return HTTP 200 and successfully terminate employee in database.
     */
    public function testAllChecklistPresentWithNoAssignedAssetsTerminatesSuccessfully()
    {
        $db = Database::connect();
        $empId = 'emp-chk-06';
        $this->createEmployee($empId);

        // Optional: An asset that was returned (Available)
        $this->createAsset('ast-chk-06', null, 'Available');

        $controller = $this->setupController(EmployeeSeparationController::class);
        $this->setPostRequest([
            'employee_id'      => $empId,
            'termination_date' => date('Y-m-d'),
            'reason'           => 'Voluntary separation agreed mutually',
            'checklist_assets' => '1',
            'checklist_docs'   => '1',
            'checklist_dues'   => '1',
        ], true);

        $response = $controller->saveTermination();
        $this->assertEquals(200, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertTrue($body['success']);

        // Employee status updated to Terminated
        $emp = (new EmployeeModel())->find($empId);
        $this->assertEquals('Terminated', $emp['status']);

        // Termination record created in employee_terminations
        $term = $db->table('employee_terminations')->where('employee_id', $empId)->get()->getRowArray();
        $this->assertNotNull($term);
        $this->assertEquals('Approved', $term['status']);
        $this->assertEquals('Voluntary separation agreed mutually', $term['reason']);
    }
}
