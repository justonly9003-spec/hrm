<?php

namespace Tests\Unit;

use App\Database\Migrations\CreateMobileAuthTokenTables;
use App\Models\MobileAccessTokenModel;
use App\Models\MobileDeviceModel;
use App\Models\MobileRefreshTokenModel;
use App\Services\Mobile\MobileAuthService;
use CodeIgniter\Test\CIUnitTestCase;
use Config\Database;
use Ramsey\Uuid\Uuid;

#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobileAuthTokenMigrationAndPersistenceTest extends CIUnitTestCase
{
    protected $db;
    private string $companyId = 'c-test-mob';
    private string $userId    = 'u-test-mob';

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();

        // Ensure prerequisite base tables for foreign keys and auth service
        $this->db->query("CREATE TABLE IF NOT EXISTS companies (
            id VARCHAR(36) PRIMARY KEY,
            name VARCHAR(100),
            code VARCHAR(30),
            status VARCHAR(20) DEFAULT 'active',
            logo VARCHAR(255) NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE IF NOT EXISTS roles (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36) NULL,
            code VARCHAR(50),
            name VARCHAR(100),
            status VARCHAR(20) DEFAULT 'active',
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE IF NOT EXISTS users (
            id VARCHAR(36) PRIMARY KEY,
            employee_id VARCHAR(36) NULL,
            name VARCHAR(100) NULL,
            username VARCHAR(100),
            email VARCHAR(150),
            password_hash VARCHAR(255),
            role_id VARCHAR(36),
            company_id VARCHAR(36) NULL,
            branch_id VARCHAR(36) NULL,
            department_id VARCHAR(36) NULL,
            failed_logins INT DEFAULT 0,
            locked_until DATETIME NULL,
            status VARCHAR(20) DEFAULT 'active',
            must_change_password INT DEFAULT 0,
            theme_mode VARCHAR(10) NULL,
            is_two_factor_enabled INT DEFAULT 0,
            last_login_at DATETIME NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE IF NOT EXISTS login_history (
            id VARCHAR(36) PRIMARY KEY,
            user_id VARCHAR(36) NULL,
            ip_address VARCHAR(45),
            user_agent VARCHAR(500),
            status VARCHAR(30),
            attempted_at DATETIME NULL,
            login_time DATETIME NULL,
            created_at DATETIME NULL
        )");

        // Seed tenant & user
        $this->db->table('companies')->ignore(true)->insert([
            'id'     => $this->companyId,
            'name'   => 'Mobile Test Corp',
            'code'   => 'MTCORP',
            'status' => 'active',
        ]);

        $this->db->table('roles')->ignore(true)->insert([
            'id'     => 'r-mob-emp',
            'code'   => 'employee',
            'name'   => 'Employee',
            'status' => 'active',
        ]);

        $this->db->table('users')->ignore(true)->insert([
            'id'            => $this->userId,
            'username'      => 'mob_user',
            'email'         => 'mob_user@mtcorp.test',
            'password_hash' => password_hash('SecretPass123!', PASSWORD_BCRYPT, ['cost' => 4]),
            'company_id'    => $this->companyId,
            'role_id'       => 'r-mob-emp',
            'status'        => 'active',
        ]);
    }

    /**
     * Test 1: Migration class exists and implements up() and down()
     */
    public function testMigrationClassStructure(): void
    {
        $migration = new CreateMobileAuthTokenTables();
        $this->assertTrue(method_exists($migration, 'up'), 'Migration must implement up()');
        $this->assertTrue(method_exists($migration, 'down'), 'Migration must implement down()');
    }

    /**
     * Test 2: Migration up() creates all 3 tables with expected columns and keys,
     * is idempotent on repeated runs, and down() drops tables cleanly.
     */
    public function testMigrationLifecycleAndSchema(): void
    {
        $migration = new CreateMobileAuthTokenTables();

        // Ensure clean state before migration test
        if ($this->db->tableExists('mobile_access_tokens')) {
            $this->db->query("DROP TABLE mobile_access_tokens");
        }
        if ($this->db->tableExists('mobile_refresh_tokens')) {
            $this->db->query("DROP TABLE mobile_refresh_tokens");
        }
        if ($this->db->tableExists('mobile_devices')) {
            $this->db->query("DROP TABLE mobile_devices");
        }

        // 1. First run of up()
        $migration->up();

        $this->assertTrue($this->db->tableExists('mobile_devices'), 'mobile_devices table must exist after up()');
        $this->assertTrue($this->db->tableExists('mobile_refresh_tokens'), 'mobile_refresh_tokens table must exist after up()');
        $this->assertTrue($this->db->tableExists('mobile_access_tokens'), 'mobile_access_tokens table must exist after up()');

        // Verify mobile_devices columns
        $deviceFields = [
            'id', 'user_id', 'company_id', 'device_uid', 'platform',
            'device_name', 'app_version', 'push_token', 'last_seen_at',
            'revoked_at', 'created_at', 'updated_at',
        ];
        foreach ($deviceFields as $field) {
            $this->assertTrue(
                $this->db->fieldExists($field, 'mobile_devices'),
                "Column {$field} must exist in mobile_devices"
            );
        }

        // Verify mobile_refresh_tokens columns
        $refreshFields = [
            'id', 'user_id', 'company_id', 'device_id', 'family_id',
            'token_hash', 'expires_at', 'used_at', 'revoked_at',
            'replaced_by_id', 'created_ip', 'created_at',
        ];
        foreach ($refreshFields as $field) {
            $this->assertTrue(
                $this->db->fieldExists($field, 'mobile_refresh_tokens'),
                "Column {$field} must exist in mobile_refresh_tokens"
            );
        }

        // Verify mobile_access_tokens columns
        $accessFields = [
            'id', 'user_id', 'device_id', 'refresh_token_id',
            'token_hash', 'expires_at', 'revoked_at', 'created_at',
        ];
        foreach ($accessFields as $field) {
            $this->assertTrue(
                $this->db->fieldExists($field, 'mobile_access_tokens'),
                "Column {$field} must exist in mobile_access_tokens"
            );
        }

        // 2. Idempotency: second run of up() should be a no-op without error
        $migration->up();
        $this->assertTrue($this->db->tableExists('mobile_devices'));
        $this->assertTrue($this->db->tableExists('mobile_refresh_tokens'));
        $this->assertTrue($this->db->tableExists('mobile_access_tokens'));

        // 3. Rollback: down() should safely drop in correct reverse order
        $migration->down();
        $this->assertFalse($this->db->tableExists('mobile_access_tokens'), 'mobile_access_tokens must be dropped by down()');
        $this->assertFalse($this->db->tableExists('mobile_refresh_tokens'), 'mobile_refresh_tokens must be dropped by down()');
        $this->assertFalse($this->db->tableExists('mobile_devices'), 'mobile_devices must be dropped by down()');

        // Re-run up() to restore schema for subsequent tests
        $migration->up();
    }

    /**
     * Test 3: Verify Model classes interact with migrated tables properly
     */
    public function testModelsInteractWithMigratedTables(): void
    {
        $migration = new CreateMobileAuthTokenTables();
        $migration->up();

        $deviceModel  = new MobileDeviceModel();
        $refreshModel = new MobileRefreshTokenModel();
        $accessModel  = new MobileAccessTokenModel();

        $deviceId  = Uuid::uuid4()->toString();
        $refreshId = Uuid::uuid4()->toString();
        $accessId  = Uuid::uuid4()->toString();
        $familyId  = Uuid::uuid4()->toString();
        $now       = date('Y-m-d H:i:s');

        // Insert device via model
        $deviceInserted = $deviceModel->insert([
            'id'          => $deviceId,
            'user_id'     => $this->userId,
            'company_id'  => $this->companyId,
            'device_uid'  => 'model-dev-001',
            'platform'    => 'ios',
            'device_name' => 'iPhone 15 Pro',
            'app_version' => '2.1.0',
            'created_at'  => $now,
            'updated_at'  => $now,
        ]);
        $this->assertTrue((bool)$deviceInserted);

        $foundDevice = $deviceModel->find($deviceId);
        $this->assertNotNull($foundDevice);
        $this->assertSame('model-dev-001', $foundDevice['device_uid']);

        // Insert refresh token via model
        $rawRefresh = 'mrt_' . bin2hex(random_bytes(32));
        $hashRefresh = hash('sha256', $rawRefresh);

        $refreshInserted = $refreshModel->insert([
            'id'         => $refreshId,
            'user_id'    => $this->userId,
            'company_id' => $this->companyId,
            'device_id'  => $deviceId,
            'family_id'  => $familyId,
            'token_hash' => $hashRefresh,
            'expires_at' => date('Y-m-d H:i:s', time() + 86400 * 30),
            'created_at' => $now,
        ]);
        $this->assertTrue((bool)$refreshInserted);

        $foundRefresh = $refreshModel->where('token_hash', $hashRefresh)->first();
        $this->assertNotNull($foundRefresh);
        $this->assertSame($familyId, $foundRefresh['family_id']);

        // Insert access token via model
        $rawAccess = 'mat_' . bin2hex(random_bytes(32));
        $hashAccess = hash('sha256', $rawAccess);

        $accessInserted = $accessModel->insert([
            'id'               => $accessId,
            'user_id'          => $this->userId,
            'device_id'        => $deviceId,
            'refresh_token_id' => $refreshId,
            'token_hash'       => $hashAccess,
            'expires_at'       => date('Y-m-d H:i:s', time() + 3600),
            'created_at'       => $now,
        ]);
        $this->assertTrue((bool)$accessInserted);

        $foundAccess = $accessModel->where('token_hash', $hashAccess)->first();
        $this->assertNotNull($foundAccess);
        $this->assertSame($refreshId, $foundAccess['refresh_token_id']);
    }

    /**
     * Test 4: End-to-end MobileAuthService login, refresh rotation, reuse detection,
     * and logout using the migrated tables, asserting SHA-256 token hashing.
     */
    public function testEndToEndTokenPersistenceAndSecurity(): void
    {
        $migration = new CreateMobileAuthTokenTables();
        $migration->up();

        $authService = new MobileAuthService($this->db);

        // 1. Login
        $loginRes = $authService->login(
            'MTCORP',
            'mob_user',
            'SecretPass123!',
            [
                'device_uid'  => 'e2e-dev-100',
                'platform'    => 'android',
                'device_name' => 'Samsung S24',
                'app_version' => '1.5.0',
            ],
            '192.168.1.50',
            'CustomApp/1.5.0'
        );

        $this->assertTrue($loginRes['ok'], 'Login must succeed');
        $rawAccess  = $loginRes['data']['tokens']['access_token'];
        $rawRefresh = $loginRes['data']['tokens']['refresh_token'];

        $this->assertStringStartsWith('mat_', $rawAccess);
        $this->assertStringStartsWith('mrt_', $rawRefresh);

        // Security check: Raw plaintext tokens must NEVER appear in DB
        $plainAccessInDb = $this->db->table('mobile_access_tokens')->where('token_hash', $rawAccess)->get()->getRowArray();
        $this->assertNull($plainAccessInDb, 'Raw plaintext access token must never be stored');

        $plainRefreshInDb = $this->db->table('mobile_refresh_tokens')->where('token_hash', $rawRefresh)->get()->getRowArray();
        $this->assertNull($plainRefreshInDb, 'Raw plaintext refresh token must never be stored');

        // Check SHA-256 hash persistence
        $accessHash  = hash('sha256', $rawAccess);
        $refreshHash = hash('sha256', $rawRefresh);

        $accessRecord = $this->db->table('mobile_access_tokens')->where('token_hash', $accessHash)->get()->getRowArray();
        $this->assertNotNull($accessRecord, 'Access token hash must be persisted');
        $this->assertNull($accessRecord['revoked_at']);

        $refreshRecord = $this->db->table('mobile_refresh_tokens')->where('token_hash', $refreshHash)->get()->getRowArray();
        $this->assertNotNull($refreshRecord, 'Refresh token hash must be persisted');
        $this->assertNull($refreshRecord['used_at']);
        $this->assertNull($refreshRecord['revoked_at']);

        $initialFamilyId = $refreshRecord['family_id'];

        // 2. Authenticate using access token
        $authRes = $authService->authenticate($rawAccess);
        $this->assertTrue($authRes['ok']);
        $this->assertSame($this->userId, $authRes['data']['user']['id']);

        // 3. Refresh token rotation
        $refreshRes = $authService->refresh($rawRefresh, '192.168.1.50');
        $this->assertTrue($refreshRes['ok']);

        $newRawAccess  = $refreshRes['data']['tokens']['access_token'];
        $newRawRefresh = $refreshRes['data']['tokens']['refresh_token'];
        $this->assertNotSame($rawAccess, $newRawAccess);
        $this->assertNotSame($rawRefresh, $newRawRefresh);

        // Verify old refresh token is marked used and records replaced_by_id
        $oldRefreshRecord = $this->db->table('mobile_refresh_tokens')->where('token_hash', $refreshHash)->get()->getRowArray();
        $this->assertNotNull($oldRefreshRecord['used_at']);
        $this->assertNotNull($oldRefreshRecord['replaced_by_id']);

        // Verify new refresh token retains same family_id
        $newRefreshHash   = hash('sha256', $newRawRefresh);
        $newRefreshRecord = $this->db->table('mobile_refresh_tokens')->where('token_hash', $newRefreshHash)->get()->getRowArray();
        $this->assertSame($initialFamilyId, $newRefreshRecord['family_id']);
        $this->assertSame($newRefreshRecord['id'], $oldRefreshRecord['replaced_by_id']);

        // 4. Token Reuse Detection: Attempting to reuse old refresh token revokes entire family
        $reuseRes = $authService->refresh($rawRefresh, '192.168.1.50');
        $this->assertFalse($reuseRes['ok'], 'Reusing refresh token must fail');
        $this->assertSame(401, $reuseRes['status']);

        // Both tokens in family must now be revoked
        $revokedOld = $this->db->table('mobile_refresh_tokens')->where('token_hash', $refreshHash)->get()->getRowArray();
        $revokedNew = $this->db->table('mobile_refresh_tokens')->where('token_hash', $newRefreshHash)->get()->getRowArray();
        $this->assertNotNull($revokedOld['revoked_at']);
        $this->assertNotNull($revokedNew['revoked_at']);

        // 5. Logout verification
        // Issue fresh session
        $loginRes2 = $authService->login('MTCORP', 'mob_user', 'SecretPass123!');
        $activeToken = $loginRes2['data']['tokens']['access_token'];

        $logoutRes = $authService->logout($activeToken, $this->userId, $this->companyId);
        $this->assertTrue($logoutRes['ok']);

        $authAfterLogout = $authService->authenticate($activeToken);
        $this->assertFalse($authAfterLogout['ok'], 'Logged out token must fail authentication');
    }
}
