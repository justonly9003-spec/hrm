<?php

namespace Tests\Unit;

use App\Controllers\Users\UserController;
use App\Services\Auth\PasswordPolicyService;
use App\Services\Mobile\MobileAuthService;
use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobileAuthChangePasswordTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;
    private array $deviceA = ['device_uid' => 'dev-user1-a', 'platform' => 'android', 'device_name' => 'Pixel 8'];
    private array $deviceB = ['device_uid' => 'dev-user1-b', 'platform' => 'ios', 'device_name' => 'iPhone 15'];

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);
    }

    private function login(string $company = 'ACME', string $identifier = 'rahim', string $pw = self::PASSWORD, ?array $device = null): array
    {
        $dev = $device ?? $this->deviceA;
        $svc = new MobileAuthService($this->db);
        return $svc->login($company, $identifier, $pw, $dev, '127.0.0.1', 'PHPUnit');
    }

    /**
     * Test 1: Central PasswordPolicyService validation logic and backward compatibility
     */
    public function testPasswordPolicyServiceRules(): void
    {
        // 12 char minimum by default
        $this->assertNotNull(PasswordPolicyService::validateStrength('Short1!'));
        $this->assertNotNull(PasswordPolicyService::validateStrength('Sh0rt!'));
        $this->assertNotNull(PasswordPolicyService::validateStrength('TenChars1!')); // 10 chars < 12
        $this->assertNotNull(PasswordPolicyService::validateStrength('lowercase123!@#'));
        $this->assertNotNull(PasswordPolicyService::validateStrength('UPPERCASE123!@#'));
        $this->assertNotNull(PasswordPolicyService::validateStrength('NoNumbersHere!@#'));
        $this->assertNotNull(PasswordPolicyService::validateStrength('NoSpecialChars123'));
        $this->assertNull(PasswordPolicyService::validateStrength('StrongP@ssw0rd!2026'));

        // UserController::validatePasswordStrength delegates properly
        $this->assertNull(UserController::validatePasswordStrength('StrongP@1!')); // 10 chars passes admin provision
        $this->assertNotNull(UserController::validatePasswordStrength('Short1!'));

        // Change password full payload validation
        $this->assertSame('Current password is required.', PasswordPolicyService::validateChangePassword('', 'NewPass!12345', 'NewPass!12345'));
        $this->assertSame('New password is required.', PasswordPolicyService::validateChangePassword('OldPass!12345', '', ''));
        $this->assertSame('Password confirmation is required.', PasswordPolicyService::validateChangePassword('OldPass!12345', 'NewPass!12345', ''));
        $this->assertSame('New password and confirmation do not match.', PasswordPolicyService::validateChangePassword('OldPass!12345', 'NewPass!12345', 'Mismatch!12345'));
        $this->assertSame('New password cannot be the same as your current password.', PasswordPolicyService::validateChangePassword('SamePass!12345', 'SamePass!12345', 'SamePass!12345'));
        $this->assertNull(PasswordPolicyService::validateChangePassword('OldPass!12345', 'NewStr0ng#P@ss2026', 'NewStr0ng#P@ss2026'));
    }

    /**
     * Test 2: Unauthenticated and invalid token requests to /api/v1/auth/change-password return 401
     */
    public function testUnauthenticatedRequestsRejected(): void
    {
        // Missing Authorization header
        $res = $this->withBodyFormat('json')->call('post', 'api/v1/auth/change-password', [
            'current_password' => self::PASSWORD,
            'new_password'     => 'NewValid#P@ssword2026',
            'confirm_password' => 'NewValid#P@ssword2026',
        ]);
        $res->assertStatus(401);

        // Invalid Bearer token
        $res2 = $this->withHeaders(['Authorization' => 'Bearer mat_invalid_token_12345'])
            ->withBodyFormat('json')
            ->call('post', 'api/v1/auth/change-password', [
                'current_password' => self::PASSWORD,
                'new_password'     => 'NewValid#P@ssword2026',
                'confirm_password' => 'NewValid#P@ssword2026',
            ]);
        $res2->assertStatus(401);

        // Also works on api/mobile/v1/auth/change-password
        $res3 = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/change-password', []);
        $res3->assertStatus(401);
    }

    /**
     * Test 3: Input validation errors (missing fields, mismatch, same password, weak password)
     */
    public function testValidationErrorsReturn422WithSpecificMessages(): void
    {
        $login = $this->login();
        $token = $login['data']['tokens']['access_token'];
        $h     = ['Authorization' => "Bearer {$token}"];

        // Missing current password
        $res = $this->withHeaders($h)->withBodyFormat('json')->call('post', 'api/v1/auth/change-password', [
            'current_password' => '',
            'new_password'     => 'NewValid#P@ssword2026',
            'confirm_password' => 'NewValid#P@ssword2026',
        ]);
        $res->assertStatus(422);
        $data = json_decode($res->getJSON(), true);
        $this->assertFalse($data['success']);
        $this->assertSame('Current password is required.', $data['message']);

        // Mismatched confirmation
        $res = $this->withHeaders($h)->withBodyFormat('json')->call('post', 'api/v1/auth/change-password', [
            'current_password' => self::PASSWORD,
            'new_password'     => 'NewValid#P@ssword2026',
            'confirm_password' => 'Mismatch#P@ssword2026',
        ]);
        $res->assertStatus(422);
        $data = json_decode($res->getJSON(), true);
        $this->assertSame('New password and confirmation do not match.', $data['message']);

        // Same as current password
        $res = $this->withHeaders($h)->withBodyFormat('json')->call('post', 'api/v1/auth/change-password', [
            'current_password' => self::PASSWORD,
            'new_password'     => self::PASSWORD,
            'confirm_password' => self::PASSWORD,
        ]);
        $res->assertStatus(422);
        $data = json_decode($res->getJSON(), true);
        $this->assertSame('New password cannot be the same as your current password.', $data['message']);

        // Weak new password (too short)
        $res = $this->withHeaders($h)->withBodyFormat('json')->call('post', 'api/v1/auth/change-password', [
            'current_password' => self::PASSWORD,
            'new_password'     => 'Short1!A',
            'confirm_password' => 'Short1!A',
        ]);
        $res->assertStatus(422);
        $data = json_decode($res->getJSON(), true);
        $this->assertStringContainsString('at least 12 characters', $data['message']);

        // Wrong current password
        $res = $this->withHeaders($h)->withBodyFormat('json')->call('post', 'api/v1/auth/change-password', [
            'current_password' => 'WrongCurrentP@ss123!',
            'new_password'     => 'NewValid#P@ssword2026',
            'confirm_password' => 'NewValid#P@ssword2026',
        ]);
        $res->assertStatus(422);
        $data = json_decode($res->getJSON(), true);
        $this->assertSame('Current password does not match.', $data['message']);
    }

    /**
     * Test 4: Successful password change updates hash, resets must_change_password,
     * and enables login with new credentials.
     */
    public function testSuccessfulPasswordChangeUpdatesUserAndClearsMustChange(): void
    {
        // Mark user as must_change_password = 1
        $this->db->table('users')->where('id', 'u-1')->update(['must_change_password' => 1]);

        $login = $this->login('ACME', 'rahim', self::PASSWORD);
        $token = $login['data']['tokens']['access_token'];
        $h     = ['Authorization' => "Bearer {$token}"];

        $newPassword = 'BrandNew#Secur3Pass2026';

        // Perform password change using password_confirmation field alias
        $res = $this->withHeaders($h)->withBodyFormat('json')->call('post', 'api/v1/auth/change-password', [
            'current_password'      => self::PASSWORD,
            'new_password'          => $newPassword,
            'password_confirmation' => $newPassword,
        ]);

        $res->assertStatus(200);
        $body = json_decode($res->getJSON(), true);
        $this->assertTrue($body['success']);
        $this->assertSame('Password updated successfully.', $body['message']);

        // Verify DB updates
        $user = $this->db->table('users')->where('id', 'u-1')->get()->getRowArray();
        $this->assertSame(0, (int)$user['must_change_password'], 'must_change_password must be cleared to 0');
        $this->assertSame(0, (int)$user['failed_logins'], 'failed_logins must be reset');
        $this->assertTrue(password_verify($newPassword, $user['password_hash']), 'New password must verify against password_hash');
        $this->assertFalse(password_verify(self::PASSWORD, $user['password_hash']), 'Old password must no longer verify');

        // New login with old password fails
        $oldLogin = $this->login('ACME', 'rahim', self::PASSWORD);
        $this->assertFalse($oldLogin['ok']);

        // New login with new password succeeds
        $newLogin = $this->login('ACME', 'rahim', $newPassword);
        $this->assertTrue($newLogin['ok']);
    }

    /**
     * Test 5: Invalidation of other active sessions and tokens
     */
    public function testOtherActiveTokensAreRevokedOnPasswordChange(): void
    {
        // User logs in from device A (active session A)
        $loginA = $this->login('ACME', 'rahim', self::PASSWORD, $this->deviceA);
        $tokenA = $loginA['data']['tokens']['access_token'];

        // User also logs in from device B (active session B)
        $loginB = $this->login('ACME', 'rahim', self::PASSWORD, $this->deviceB);
        $tokenB = $loginB['data']['tokens']['access_token'];

        // Both tokens initially work
        $this->withHeaders(['Authorization' => "Bearer {$tokenA}"])->get('api/v1/auth/me')->assertStatus(200);
        $this->withHeaders(['Authorization' => "Bearer {$tokenB}"])->get('api/v1/auth/me')->assertStatus(200);

        // User changes password using Token A
        $newPassword = 'BrandNew#Secur3Pass2026';
        $res = $this->withHeaders(['Authorization' => "Bearer {$tokenA}"])
            ->withBodyFormat('json')
            ->call('post', 'api/v1/auth/change-password', [
                'current_password' => self::PASSWORD,
                'new_password'     => $newPassword,
                'confirm_password' => $newPassword,
            ]);
        $res->assertStatus(200);

        // Current token (Token A) remains valid on this device
        $resA = $this->withHeaders(['Authorization' => "Bearer {$tokenA}"])->get('api/v1/auth/me');
        $resA->assertStatus(200);

        // Other token (Token B) must be revoked and rejected
        $resB = $this->withHeaders(['Authorization' => "Bearer {$tokenB}"])->get('api/v1/auth/me');
        $resB->assertStatus(401);
    }

    /**
     * Test 6: Requirement 12 - User with must_change_password is NOT trapped by filter
     */
    public function testUserWithMustChangePasswordIsNotTrappedByFilter(): void
    {
        $this->db->table('users')->where('id', 'u-1')->update(['must_change_password' => 1]);

        $login = $this->login('ACME', 'rahim', self::PASSWORD);
        $token = $login['data']['tokens']['access_token'];
        $h     = ['Authorization' => "Bearer {$token}"];

        // 1. Regular endpoints (e.g. profile) are blocked by MobileAuthFilter with 403
        $this->withHeaders($h)->get('api/mobile/v1/profile')->assertStatus(403);

        // 2. But auth/change-password is NOT blocked and can be accessed
        $newPassword = 'BrandNew#Secur3Pass2026';
        $changeRes = $this->withHeaders($h)->withBodyFormat('json')->call('post', 'api/v1/auth/change-password', [
            'current_password' => self::PASSWORD,
            'new_password'     => $newPassword,
            'confirm_password' => $newPassword,
        ]);
        $changeRes->assertStatus(200);

        // 3. Now that password is changed, profile is immediately accessible
        $profileRes = $this->withHeaders($h)->get('api/mobile/v1/profile');
        $profileRes->assertStatus(200);
    }

    /**
     * Test 7: Authorization and Tenant Isolation - Cannot change another user's password
     */
    public function testCannotChangeAnotherUsersPasswordByInjectingParams(): void
    {
        // Login as Rahim (u-1 in Acme)
        $login = $this->login('ACME', 'rahim', self::PASSWORD);
        $token = $login['data']['tokens']['access_token'];
        $h     = ['Authorization' => "Bearer {$token}"];

        // Rahim tries to pass user_id = u-2 (Karim in Other Ltd) or employee_id
        $newPassword = 'BrandNew#Secur3Pass2026';
        $res = $this->withHeaders($h)->withBodyFormat('json')->call('post', 'api/v1/auth/change-password', [
            'user_id'          => 'u-2',
            'employee_id'      => 'e-2',
            'current_password' => self::PASSWORD,
            'new_password'     => $newPassword,
            'confirm_password' => $newPassword,
        ]);
        $res->assertStatus(200);

        // Verify Rahim's password changed, but Karim's password was NOT touched
        $rahim = $this->db->table('users')->where('id', 'u-1')->get()->getRowArray();
        $karim = $this->db->table('users')->where('id', 'u-2')->get()->getRowArray();

        $this->assertTrue(password_verify($newPassword, $rahim['password_hash']));
        $this->assertTrue(password_verify(self::PASSWORD, $karim['password_hash']), "Karim's password must not be affected by Rahim's request");
    }
}
