<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use App\Controllers\Employee\EmployeeController;
use App\Controllers\Employee\ProfileController;
use App\Controllers\Employee\EmployeeSeparationController;
use App\Services\EmployeeSeparationService;
use App\Exceptions\UnreturnedAssetsException;
use App\Models\EmployeeModel;
use Config\Database;

/**
 * DB-backed tests for:
 * 1. Asset-return bypass closure on termination across all three routes:
 *    - EmployeeController::terminate()
 *    - ProfileController::saveTermination()
 *    - EmployeeSeparationController::saveTermination()
 * 2. Unreturned asset guard in approveResignation()
 * 3. Ignoring Written-Off and soft-deleted assets
 * 4. Hardened EmployeeController::delete() blocking asset holders and managers with direct reports
 */
class EmployeeSeparationAssetGuardsTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected static bool $schemaInitialized = false;

    protected string $tenantCompanyId = 'comp-asset-test-01';
    protected string $tenantBranchId  = 'branch-asset-test-01';
    protected string $tenantDeptId    = 'dept-asset-test-01';
    protected string $tenantDesgId    = 'desg-asset-test-01';

    protected array $adminUser = [];

    public static function setUpBeforeClass(): void
    {
        parent::setUpBeforeClass();
        static::ensureSchema();
    }

    public static function registerSqliteFunctions($db): void
    {
        try {
            $rawConn = $db->connID ?? null;
            if ($rawConn instanceof \SQLite3) {
                $rawConn->createFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->createFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            } elseif (is_object($rawConn) && method_exists($rawConn, 'sqliteCreateFunction')) {
                $rawConn->sqliteCreateFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->sqliteCreateFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            }
        } catch (\Throwable $e) {
            // ignore
        }
    }

    protected static function ensureSchema(): void
    {
        $db = Database::connect();
        static::registerSqliteFunctions($db);

        $schemaFile = __DIR__ . '/Rules/schema.sqlite.sql';
        if (file_exists($schemaFile)) {
            $sql = file_get_contents($schemaFile);
            $statements = array_filter(array_map('trim', explode(';', $sql)));
            foreach ($statements as $stmt) {
                if (!empty($stmt)) {
                    try {
                        $db->query($stmt);
                    } catch (\Throwable $e) {
                        // ignore
                    }
                }
            }
        }

        // Ensure company_assets exists with all needed fields
        $db->query("CREATE TABLE IF NOT EXISTS company_assets (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            category_id VARCHAR(36),
            asset_name VARCHAR(150),
            asset_code VARCHAR(100),
            serial_number VARCHAR(100),
            category VARCHAR(100),
            assigned_to VARCHAR(36),
            assigned_date DATE,
            purchase_date DATE,
            purchase_value DECIMAL(15,2),
            warranty_expiry DATE,
            condition_status VARCHAR(50) DEFAULT 'good',
            status VARCHAR(50) DEFAULT 'Available',
            notes TEXT,
            written_off_at DATETIME,
            written_off_reason VARCHAR(50),
            written_off_by_employee_id VARCHAR(36),
            recovery_amount DECIMAL(15,2),
            recovery_settlement_id VARCHAR(36),
            recovery_settled_at DATETIME,
            deleted_at DATETIME,
            created_at DATETIME,
            updated_at DATETIME
        )");

        $db->query("CREATE TABLE IF NOT EXISTS employee_terminations (
            id VARCHAR(36) PRIMARY KEY,
            employee_id VARCHAR(36),
            termination_date DATE,
            termination_type VARCHAR(100),
            reason TEXT,
            notice_period_days INT DEFAULT 0,
            status VARCHAR(50) DEFAULT 'Approved',
            approved_by VARCHAR(255),
            clearance_status VARCHAR(50) DEFAULT 'In Progress',
            exit_interview_notes TEXT,
            final_settlement_status VARCHAR(50) DEFAULT 'Pending',
            terminated_by VARCHAR(36),
            created_at DATETIME,
            updated_at DATETIME
        )");

        $db->query("CREATE TABLE IF NOT EXISTS employee_resignations (
            id VARCHAR(36) PRIMARY KEY,
            employee_id VARCHAR(36),
            submission_date DATE,
            notice_date DATE,
            resignation_date DATE,
            reason TEXT,
            status VARCHAR(50) DEFAULT 'Pending',
            manager_review TEXT,
            hr_review TEXT,
            approved_by VARCHAR(255),
            clearance_status VARCHAR(50) DEFAULT 'In Progress',
            final_settlement_status VARCHAR(50) DEFAULT 'Pending',
            created_at DATETIME,
            updated_at DATETIME
        )");

        static::$schemaInitialized = true;
    }

    protected function setUp(): void
    {
        parent::setUp();
        static::ensureSchema();

        $db = Database::connect();
        static::registerSqliteFunctions($db);

        // Seed Company, Branch, Department, Designation
        $db->table('companies')->replace([
            'id'     => $this->tenantCompanyId,
            'name'   => 'Asset Testing Corp',
            'code'   => 'ATC',
            'status' => 'Active',
        ]);

        $db->table('branches')->replace([
            'id'         => $this->tenantBranchId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'HQ Branch',
            'code'       => 'BR-HQ',
            'status'     => 'Active',
        ]);

        $db->table('departments')->replace([
            'id'         => $this->tenantDeptId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'Operations',
            'code'       => 'DEP-OPS',
            'status'     => 'Active',
        ]);

        $db->table('designations')->replace([
            'id'         => $this->tenantDesgId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'Operations Specialist',
            'code'       => 'DES-OPS',
            'status'     => 'Active',
        ]);

        $this->adminUser = [
            'id'                  => 'usr-asset-admin-01',
            'company_id'          => $this->tenantCompanyId,
            'username'            => 'asset_admin',
            'name'                => 'Asset Admin',
            'email'               => 'asset_admin@test.com',
            'role'                => 'Company Admin',
            'role_code'           => 'company_admin',
            'role_id'             => 'role-asset-admin',
            'selected_company_id' => $this->tenantCompanyId,
            'permissions'         => ['*'],
        ];

        $db->table('users')->replace([
            'id'            => $this->adminUser['id'],
            'company_id'    => $this->tenantCompanyId,
            'username'      => $this->adminUser['username'],
            'email'         => $this->adminUser['email'],
            'password_hash' => password_hash('Secret123!', PASSWORD_BCRYPT),
            'role_id'       => $this->adminUser['role_id'],
            'status'        => 'Active',
        ]);
    }

    protected function setupController($controllerClass, ?array $actor = null)
    {
        $actorUser = $actor ?? $this->adminUser;

        \App\Services\PermissionService::clearCache();
        \App\Services\PermissionService::flushCache();

        $session = \Config\Services::session();
        $session->set([
            'id'                  => $actorUser['id'],
            'user_id'             => $actorUser['id'],
            'username'            => $actorUser['username'],
            'name'                => $actorUser['name'],
            'email'               => $actorUser['email'],
            'role'                => $actorUser['role'],
            'role_code'           => $actorUser['role_code'],
            'role_id'             => $actorUser['role_id'],
            'company_id'          => $actorUser['company_id'],
            'selected_company_id' => $actorUser['company_id'],
            'permissions'         => ['*'],
        ]);

        $request = \Config\Services::request();
        $response = \Config\Services::response();
        $logger = \Config\Services::logger();

        $controller = new $controllerClass();
        $controller->initController($request, $response, $logger);

        $refUser = new \ReflectionProperty(\App\Controllers\BaseController::class, 'currentUser');
        $refUser->setAccessible(true);
        $refUser->setValue($controller, $actorUser);

        return $controller;
    }

    protected function setPostRequest(array $postData, bool $isAjax = true): void
    {
        if ($isAjax) {
            $_SERVER['HTTP_X_REQUESTED_WITH'] = 'xmlhttprequest';
            $_SERVER['HTTP_ACCEPT'] = 'application/json';
        } else {
            unset($_SERVER['HTTP_X_REQUESTED_WITH']);
            $_SERVER['HTTP_ACCEPT'] = 'text/html';
        }
        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_POST = $postData;

        $request = \Config\Services::request();
        $refPost = new \ReflectionProperty($request, 'body');
        $refPost->setAccessible(true);
        $refPost->setValue($request, $postData);
    }

    protected function createEmployee(string $empId, ?string $managerId = null, string $status = 'Active', ?string $companyId = null): array
    {
        $db = Database::connect();
        $emp = [
            'id'                   => $empId,
            'company_id'           => $companyId ?? $this->tenantCompanyId,
            'branch_id'            => $this->tenantBranchId,
            'department_id'        => $this->tenantDeptId,
            'designation_id'       => $this->tenantDesgId,
            'employee_code'        => 'EMP-' . strtoupper(substr(md5($empId), 0, 6)),
            'first_name'           => 'Emp',
            'last_name'            => substr($empId, 4),
            'email'                => "{$empId}@test.com",
            'reporting_manager_id' => $managerId,
            'manager_id'           => $managerId,
            'status'               => $status,
            'deleted_at'           => null,
            'created_at'           => date('Y-m-d H:i:s'),
            'updated_at'           => date('Y-m-d H:i:s'),
        ];
        $db->table('employees')->replace($emp);
        return $emp;
    }

    protected function createAsset(
        string $assetId,
        ?string $assignedTo = null,
        string $status = 'Available',
        ?string $deletedAt = null,
        ?string $companyId = null,
        string $assetName = ''
    ): array {
        $db = Database::connect();
        $asset = [
            'id'                         => $assetId,
            'company_id'                 => $companyId ?? $this->tenantCompanyId,
            'asset_name'                 => $assetName !== '' ? $assetName : ('Test Asset ' . $assetId),
            'asset_code'                 => 'AST-' . strtoupper(substr(md5($assetId), 0, 6)),
            'category'                   => 'IT Equipment',
            'assigned_to'                => $assignedTo,
            'status'                     => $status,
            'deleted_at'                 => $deletedAt,
            'written_off_at'             => ($status === 'Written-Off') ? date('Y-m-d H:i:s') : null,
            'written_off_reason'         => ($status === 'Written-Off') ? 'Damaged beyond repair' : null,
            'written_off_by_employee_id' => ($status === 'Written-Off') ? $assignedTo : null,
            'created_at'                 => date('Y-m-d H:i:s'),
            'updated_at'                 => date('Y-m-d H:i:s'),
        ];
        $db->table('company_assets')->replace($asset);
        return $asset;
    }

    /**
     * Test 1: EmployeeSeparationService::assertNoUnreturnedAssets throws UnreturnedAssetsException
     * only when status is 'Assigned', and ignores 'Written-Off' or soft-deleted assets.
     */
    public function testAssertNoUnreturnedAssetsDomainLogic()
    {
        $db = Database::connect();
        $empId = 'emp-test-domain-01';
        $this->createEmployee($empId);

        $service = new EmployeeSeparationService();

        // No assets assigned -> should not throw
        $service->assertNoUnreturnedAssets($empId);
        $this->assertTrue(true, 'No assets should not throw.');

        // Asset assigned -> MUST throw UnreturnedAssetsException
        $this->createAsset('ast-dom-01', $empId, 'Assigned');
        try {
            $service->assertNoUnreturnedAssets($empId);
            $this->fail('Expected UnreturnedAssetsException was not thrown.');
        } catch (UnreturnedAssetsException $e) {
            $this->assertCount(1, $e->getAssets());
            $this->assertStringContainsString('unreturned company asset', $e->getMessage());
        }

        // Asset returned (Available) -> should not throw
        $db->table('company_assets')->where('id', 'ast-dom-01')->update(['status' => 'Available', 'assigned_to' => null]);
        $service->assertNoUnreturnedAssets($empId);
        $this->assertTrue(true, 'Available asset should not throw.');

        // Asset Written-Off -> should not throw
        $this->createAsset('ast-dom-02', $empId, 'Written-Off');
        $service->assertNoUnreturnedAssets($empId);
        $this->assertTrue(true, 'Written-Off asset should not throw.');

        // Soft-deleted asset (status 'Assigned' but deleted_at set) -> should not throw
        $this->createAsset('ast-dom-03', $empId, 'Assigned', date('Y-m-d H:i:s'));
        $service->assertNoUnreturnedAssets($empId);
        $this->assertTrue(true, 'Soft-deleted assigned asset should not throw.');
    }

    /**
     * Test 2: Route 1 - EmployeeController::terminate() blocks while asset is Assigned (HTTP 422)
     * and succeeds once asset is returned or written-off.
     */
    public function testEmployeeControllerTerminateBlockedAndAllowed()
    {
        $db = Database::connect();
        $empId = 'emp-route1-term';
        $this->createEmployee($empId);
        $this->createAsset('ast-r1-01', $empId, 'Assigned');

        $controller = $this->setupController(EmployeeController::class);
        $this->setPostRequest([
            'employee_id'      => $empId,
            'termination_date' => date('Y-m-d'),
            'reason'           => 'Performance issues',
        ], true);

        // When asset is Assigned -> returns 422 JSON
        $response = $controller->terminate();
        $this->assertEquals(422, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success']);
        $this->assertStringContainsString('unreturned company asset', $body['message']);

        // Check employee not terminated in DB
        $emp = (new EmployeeModel())->find($empId);
        $this->assertEquals('Active', $emp['status']);

        // Return asset to inventory
        $db->table('company_assets')->where('id', 'ast-r1-01')->update(['status' => 'Available', 'assigned_to' => null]);

        // Retrying termination should now succeed
        $controller2 = $this->setupController(EmployeeController::class);
        $this->setPostRequest([
            'employee_id'      => $empId,
            'termination_date' => date('Y-m-d'),
            'reason'           => 'Performance issues resolved with clearance',
        ], true);
        $response2 = $controller2->terminate();
        $this->assertEquals(200, $response2->getStatusCode());
        $body2 = json_decode($response2->getBody(), true);
        $this->assertTrue($body2['success']);

        $empUpdated = (new EmployeeModel())->find($empId);
        $this->assertEquals('Terminated', $empUpdated['status']);
    }

    /**
     * Test 3: Route 2 - ProfileController::saveTermination() blocks while asset is Assigned
     * and succeeds once asset is returned or written-off.
     */
    public function testProfileControllerSaveTerminationBlockedAndAllowed()
    {
        $db = Database::connect();
        $empId = 'emp-route2-profile';
        $this->createEmployee($empId);
        $this->createAsset('ast-r2-01', $empId, 'Assigned');

        $controller = $this->setupController(ProfileController::class);
        $this->setPostRequest([
            'termination_date' => date('Y-m-d'),
            'reason'           => 'Misconduct',
        ], true);

        // When asset is Assigned -> returns 422 JSON
        $response = $controller->saveTermination($empId);
        $this->assertEquals(422, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success']);
        $this->assertStringContainsString('unreturned company asset', $body['message']);

        // Asset marked as Written-Off -> does not block
        $db->table('company_assets')->where('id', 'ast-r2-01')->update([
            'status'             => 'Written-Off',
            'written_off_at'     => date('Y-m-d H:i:s'),
            'written_off_reason' => 'Loss compensated',
        ]);

        $controller2 = $this->setupController(ProfileController::class);
        $this->setPostRequest([
            'termination_date' => date('Y-m-d'),
            'reason'           => 'Misconduct processed with written-off asset',
        ], true);
        $response2 = $controller2->saveTermination($empId);
        $this->assertEquals(200, $response2->getStatusCode());
        $body2 = json_decode($response2->getBody(), true);
        $this->assertTrue($body2['success']);

        $empUpdated = (new EmployeeModel())->find($empId);
        $this->assertEquals('Terminated', $empUpdated['status']);
    }

    /**
     * Test 4: Route 3 - EmployeeSeparationController::saveTermination() blocks while asset is Assigned
     * and succeeds once asset is returned or written-off.
     */
    public function testEmployeeSeparationControllerSaveTerminationBlockedAndAllowed()
    {
        $db = Database::connect();
        $empId = 'emp-route3-sep';
        $this->createEmployee($empId);
        $this->createAsset('ast-r3-01', $empId, 'Assigned');

        $controller = $this->setupController(EmployeeSeparationController::class);
        $this->setPostRequest([
            'employee_id'      => $empId,
            'termination_date' => date('Y-m-d'),
            'reason'           => 'Redundancy',
            'checklist_assets' => '1',
            'checklist_docs'   => '1',
            'checklist_dues'   => '1',
        ], true);

        // When asset is Assigned -> returns 422 JSON
        $response = $controller->saveTermination();
        $this->assertEquals(422, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success']);
        $this->assertStringContainsString('unreturned company asset', $body['message']);

        // Asset soft-deleted -> does not block
        $db->table('company_assets')->where('id', 'ast-r3-01')->update(['deleted_at' => date('Y-m-d H:i:s')]);

        $controller2 = $this->setupController(EmployeeSeparationController::class);
        $this->setPostRequest([
            'employee_id'      => $empId,
            'termination_date' => date('Y-m-d'),
            'reason'           => 'Redundancy processed with soft-deleted asset',
            'checklist_assets' => '1',
            'checklist_docs'   => '1',
            'checklist_dues'   => '1',
        ], true);
        $response2 = $controller2->saveTermination();
        $this->assertEquals(200, $response2->getStatusCode());
        $body2 = json_decode($response2->getBody(), true);
        $this->assertTrue($body2['success']);

        $empUpdated = (new EmployeeModel())->find($empId);
        $this->assertEquals('Terminated', $empUpdated['status']);
    }

    /**
     * Test 5: approveResignation() is blocked while an asset is assigned,
     * and succeeds once asset is returned.
     */
    public function testApproveResignationBlockedWhileAssetAssigned()
    {
        $db = Database::connect();
        $empId = 'emp-resign-01';
        $resId = 'res-test-01';
        $this->createEmployee($empId);
        $this->createAsset('ast-res-01', $empId, 'Assigned');

        // Create a Pending resignation record
        $db->table('employee_resignations')->replace([
            'id'               => $resId,
            'employee_id'      => $empId,
            'submission_date'  => date('Y-m-d'),
            'notice_date'      => date('Y-m-d'),
            'resignation_date' => date('Y-m-d', strtotime('+30 days')),
            'reason'           => 'Career growth',
            'status'           => 'Pending',
            'clearance_status' => 'In Progress',
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->setupController(EmployeeSeparationController::class);
        $this->setPostRequest([
            'last_working_day' => date('Y-m-d'),
            'remarks'          => 'Approval attempt with assigned asset',
        ], true);

        // Attempt approveResignation while asset is assigned -> 422 JSON
        $response = $controller->approveResignation($resId);
        $this->assertEquals(422, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success']);
        $this->assertStringContainsString('unreturned company asset', $body['message']);

        // Check resignation is still Pending
        $res = $db->table('employee_resignations')->where('id', $resId)->get()->getRowArray();
        $this->assertEquals('Pending', $res['status']);

        // Return asset
        $db->table('company_assets')->where('id', 'ast-res-01')->update(['status' => 'Available', 'assigned_to' => null]);

        // Attempt approveResignation again -> should succeed (200)
        $controller2 = $this->setupController(EmployeeSeparationController::class);
        $this->setPostRequest([
            'last_working_day' => date('Y-m-d'),
            'remarks'          => 'Approval successful after asset return',
        ], true);
        $response2 = $controller2->approveResignation($resId);
        $this->assertEquals(200, $response2->getStatusCode());
        $body2 = json_decode($response2->getBody(), true);
        $this->assertTrue($body2['success']);

        $resUpdated = $db->table('employee_resignations')->where('id', $resId)->get()->getRowArray();
        $this->assertEquals('Approved', $resUpdated['status']);
    }

    /**
     * Test 6: EmployeeController::delete() is blocked for an asset holder,
     * returns friendly message with counts and instruction to return assets.
     */
    public function testDeleteBlockedForAssetHolder()
    {
        $db = Database::connect();
        $empId = 'emp-del-asset-01';
        $this->createEmployee($empId);
        $this->createAsset('ast-del-01', $empId, 'Assigned');
        $this->createAsset('ast-del-02', $empId, 'Assigned');

        $controller = $this->setupController(EmployeeController::class);
        $this->setPostRequest([], true);

        $response = $controller->delete($empId);
        $this->assertEquals(400, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success']);
        $this->assertEquals(2, $body['assigned_assets_count']);
        $this->assertStringContainsString('2 assigned company asset(s)', $body['message']);
        $this->assertStringContainsString('return assets to inventory', $body['message']);

        // Soft-deleted asset does not block
        $db->table('company_assets')->where('id', 'ast-del-01')->update(['deleted_at' => date('Y-m-d H:i:s')]);
        $db->table('company_assets')->where('id', 'ast-del-02')->update(['status' => 'Written-Off']);

        $controller2 = $this->setupController(EmployeeController::class);
        $this->setPostRequest([], true);

        $response2 = $controller2->delete($empId);
        $this->assertEquals(200, $response2->getStatusCode());
        $body2 = json_decode($response2->getBody(), true);
        $this->assertTrue($body2['success']);

        // Verify soft-deleted
        $emp = (new EmployeeModel())->withDeleted()->find($empId);
        $this->assertNotNull($emp['deleted_at']);
    }

    /**
     * Test 7: EmployeeController::delete() is blocked for a manager with direct reports,
     * returns friendly message with counts and instruction to reassign reports.
     */
    public function testDeleteBlockedForManagerWithDirectReports()
    {
        $db = Database::connect();
        $managerId = 'emp-mgr-del-01';
        $this->createEmployee($managerId);

        // Create 2 direct reports
        $rep1 = 'emp-rep-del-01';
        $rep2 = 'emp-rep-del-02';
        $this->createEmployee($rep1, $managerId);
        $this->createEmployee($rep2, $managerId);

        $controller = $this->setupController(EmployeeController::class);
        $this->setPostRequest([], true);

        $response = $controller->delete($managerId);
        $this->assertEquals(400, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success']);
        $this->assertEquals(2, $body['direct_reports_count']);
        $this->assertStringContainsString('2 direct report(s)', $body['message']);
        $this->assertStringContainsString('reassign direct reports', $body['message']);

        // Soft-deleted direct reports do not block
        $db->table('employees')->where('id', $rep1)->update(['deleted_at' => date('Y-m-d H:i:s')]);
        // Reassign the other direct report
        $db->table('employees')->where('id', $rep2)->update(['reporting_manager_id' => null, 'manager_id' => null]);

        $controller2 = $this->setupController(EmployeeController::class);
        $this->setPostRequest([], true);

        $response2 = $controller2->delete($managerId);
        $this->assertEquals(200, $response2->getStatusCode());
        $body2 = json_decode($response2->getBody(), true);
        $this->assertTrue($body2['success']);

        // Verify manager is soft-deleted
        $mgr = (new EmployeeModel())->withDeleted()->find($managerId);
        $this->assertNotNull($mgr['deleted_at']);
    }

    /**
     * Test 8: EmployeeController::delete() blocked when employee has BOTH assigned assets
     * and direct reports (friendly message mentions both counts and both actions).
     */
    public function testDeleteBlockedForBothAssetsAndDirectReports()
    {
        $db = Database::connect();
        $empId = 'emp-both-del-01';
        $this->createEmployee($empId);
        $this->createAsset('ast-both-01', $empId, 'Assigned');
        $this->createEmployee('emp-both-rep-01', $empId);

        $controller = $this->setupController(EmployeeController::class);
        $this->setPostRequest([], true);

        $response = $controller->delete($empId);
        $this->assertEquals(400, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success']);
        $this->assertEquals(1, $body['assigned_assets_count']);
        $this->assertEquals(1, $body['direct_reports_count']);
        $this->assertStringContainsString('1 assigned company asset(s)', $body['message']);
        $this->assertStringContainsString('1 direct report(s)', $body['message']);
        $this->assertStringContainsString('return assets to inventory and reassign direct reports', $body['message']);
    }

    /**
     * Test 9: Terminate for an employee of another company throws the tenant SecurityException
     * and the exception/response message does not disclose or contain asset names.
     */
    public function testTerminateCrossTenantEmployeeThrowsSecurityExceptionWithoutAssetNames()
    {
        $db = Database::connect();
        $otherCompanyId = 'comp-other-org-77';
        $db->table('companies')->replace([
            'id'     => $otherCompanyId,
            'name'   => 'Other Organization',
            'code'   => 'ORG-OTH',
            'status' => 'Active',
        ]);

        $otherEmpId = 'emp-other-tenant-99';
        $this->createEmployee($otherEmpId, null, 'Active', $otherCompanyId);

        $secretAssetName = 'Confidential CEO MacBook Pro M3';
        $this->createAsset('ast-secret-99', $otherEmpId, 'Assigned', null, $otherCompanyId, $secretAssetName);

        // 1. Direct service call with scopedCompanyId = $this->tenantCompanyId
        $service = new EmployeeSeparationService();
        try {
            $service->terminate(
                $otherEmpId,
                ['reason' => 'Unauthorized termination of cross-tenant employee'],
                $this->adminUser['id'],
                $this->adminUser,
                $this->tenantCompanyId
            );
            $this->fail('Expected \SecurityException was not thrown for cross-tenant employee termination.');
        } catch (\SecurityException $e) {
            $this->assertStringContainsString('Cross-tenant operation unauthorized', $e->getMessage());
            $this->assertStringNotContainsString($secretAssetName, $e->getMessage());
            $this->assertStringNotContainsString('ast-secret-99', $e->getMessage());
            $this->assertStringNotContainsString('unreturned company asset', $e->getMessage());
        }

        // Verify target employee is still Active in DB
        $empCheck = (new EmployeeModel())->find($otherEmpId);
        $this->assertEquals('Active', $empCheck['status']);

        // 2. Controller endpoint call
        $controller = $this->setupController(EmployeeController::class);
        $this->setPostRequest([
            'employee_id' => $otherEmpId,
            'reason'      => 'Unauthorized cross-tenant attempt',
        ], true);

        $response = $controller->terminate();
        $this->assertEquals(403, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success']);
        $this->assertStringNotContainsString($secretAssetName, $body['message']);
        $this->assertStringNotContainsString('unreturned company asset', $body['message']);
    }

    /**
     * Test 10: Delete is allowed for a manager whose only direct reports are Terminated, Resigned, or Inactive.
     */
    public function testDeleteAllowedForManagerWhoseOnlyReportsAreTerminatedOrResigned()
    {
        $managerId = 'emp-mgr-departed-team';
        $this->createEmployee($managerId);

        // Create direct reports with Terminated, Resigned, and Inactive status
        $repTerminated = 'emp-rep-term-only';
        $repResigned   = 'emp-rep-res-only';
        $repInactive   = 'emp-rep-inact-only';
        $this->createEmployee($repTerminated, $managerId, 'Terminated');
        $this->createEmployee($repResigned, $managerId, 'Resigned');
        $this->createEmployee($repInactive, $managerId, 'Inactive');

        $controller = $this->setupController(EmployeeController::class);
        $this->setPostRequest([], true);

        $response = $controller->delete($managerId);
        $this->assertEquals(200, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertTrue($body['success']);

        // Verify manager record is soft-deleted
        $mgr = (new EmployeeModel())->withDeleted()->find($managerId);
        $this->assertNotNull($mgr['deleted_at']);
    }

    /**
     * Test 11: Delete is blocked while at least one direct report is Active or on Probation.
     */
    public function testDeleteBlockedWhileReportIsActiveOrOnProbation()
    {
        // Case A: Manager with one Terminated report and one Active report
        $mgrA = 'emp-mgr-with-active';
        $this->createEmployee($mgrA);
        $this->createEmployee('emp-rep-term-a', $mgrA, 'Terminated');
        $this->createEmployee('emp-rep-active-a', $mgrA, 'Active');

        $controllerA = $this->setupController(EmployeeController::class);
        $this->setPostRequest([], true);

        $responseA = $controllerA->delete($mgrA);
        $this->assertEquals(400, $responseA->getStatusCode());
        $bodyA = json_decode($responseA->getBody(), true);
        $this->assertFalse($bodyA['success']);
        $this->assertEquals(1, $bodyA['direct_reports_count']);
        $this->assertStringContainsString('1 direct report(s)', $bodyA['message']);

        // Verify manager A was not deleted
        $mgrRecordA = (new EmployeeModel())->find($mgrA);
        $this->assertNotNull($mgrRecordA);
        $this->assertNull($mgrRecordA['deleted_at']);

        // Case B: Manager with one Resigned report and one report on Probation
        $mgrB = 'emp-mgr-with-probation';
        $this->createEmployee($mgrB);
        $this->createEmployee('emp-rep-res-b', $mgrB, 'Resigned');
        $this->createEmployee('emp-rep-prob-b', $mgrB, 'Probation');

        $controllerB = $this->setupController(EmployeeController::class);
        $this->setPostRequest([], true);

        $responseB = $controllerB->delete($mgrB);
        $this->assertEquals(400, $responseB->getStatusCode());
        $bodyB = json_decode($responseB->getBody(), true);
        $this->assertFalse($bodyB['success']);
        $this->assertEquals(1, $bodyB['direct_reports_count']);
        $this->assertStringContainsString('1 direct report(s)', $bodyB['message']);

        // Verify manager B was not deleted
        $mgrRecordB = (new EmployeeModel())->find($mgrB);
        $this->assertNotNull($mgrRecordB);
        $this->assertNull($mgrRecordB['deleted_at']);
    }
}
