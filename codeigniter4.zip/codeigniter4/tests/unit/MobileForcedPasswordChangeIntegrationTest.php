<?php

namespace Tests\Unit;

use App\Services\Auth\PasswordPolicyService;
use App\Services\Mobile\MobileAuthService;
use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobileForcedPasswordChangeIntegrationTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;
    private array $device = ['device_uid' => 'dev-forced-pwd-test', 'platform' => 'android', 'device_name' => 'Pixel 9'];

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);

        // Create sample tables for protected modules if not present in schema
        $this->db->query("CREATE TABLE IF NOT EXISTS payrolls (id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36), payroll_month VARCHAR(10), status VARCHAR(20))");
        $this->db->query("CREATE TABLE IF NOT EXISTS employee_documents (id VARCHAR(36) PRIMARY KEY, employee_id VARCHAR(36), company_id VARCHAR(36), title VARCHAR(100), file_path VARCHAR(255))");
        $this->db->query("CREATE TABLE IF NOT EXISTS leaves (id VARCHAR(36) PRIMARY KEY, employee_id VARCHAR(36), company_id VARCHAR(36), status VARCHAR(20))");
        $this->db->query("CREATE TABLE IF NOT EXISTS attendances (id VARCHAR(36) PRIMARY KEY, employee_id VARCHAR(36), company_id VARCHAR(36), date DATE, status VARCHAR(20))");
    }

    private function login(string $company = 'ACME', string $id = 'rahim', string $pw = self::PASSWORD): array
    {
        $svc = new MobileAuthService($this->db);
        return $svc->login($company, $id, $pw, $this->device, '127.0.0.1', 'PHPUnit');
    }

    /**
     * Test 1: Denial of protected resources across BOTH api/mobile/v1 and api/v1 prefixes.
     * Ensures payroll, attendance, leave, PF, documents, and profile cannot be accessed.
     */
    public function testProtectedResourcesDeniedForMustChangePasswordUserOnBothPrefixes(): void
    {
        // Set user must_change_password = 1
        $this->db->table('users')->where('id', 'u-1')->update(['must_change_password' => 1]);

        $login = $this->login('ACME', 'rahim', self::PASSWORD);
        $this->assertTrue($login['ok']);
        $this->assertTrue($login['data']['user']['must_change_password']);
        $token = $login['data']['tokens']['access_token'];
        $h = ['Authorization' => "Bearer {$token}"];

        // Endpoints to verify on api/mobile/v1
        $mobileEndpoints = [
            'api/mobile/v1/profile',
            'api/mobile/v1/profile/details',
            'api/mobile/v1/dashboard',
            'api/mobile/v1/attendance/today',
            'api/mobile/v1/attendance/history',
            'api/mobile/v1/attendance/summary',
            'api/mobile/v1/salary',
            'api/mobile/v1/payroll/summary',
            'api/mobile/v1/payslips',
            'api/mobile/v1/pf/summary',
            'api/mobile/v1/pf/ledger',
            'api/mobile/v1/leaves/balances',
            'api/mobile/v1/documents',
            'api/mobile/v1/directory',
        ];

        foreach ($mobileEndpoints as $endpoint) {
            $res = $this->withHeaders($h)->get($endpoint);
            $this->assertSame(403, $res->response()->getStatusCode(), "Endpoint {$endpoint} must return 403 when must_change_password is true");
            $json = json_decode($res->getJSON(), true);
            $this->assertFalse($json['success']);
            $this->assertTrue($json['must_change_password']);
            $this->assertSame('Password change is required before continuing.', $json['message']);
        }

        // Endpoints to verify on api/v1
        $v1Endpoints = [
            'api/v1/profile',
            'api/v1/profile/details',
            'api/v1/dashboard',
            'api/v1/attendance/today',
            'api/v1/attendance/history',
            'api/v1/attendance/summary',
            'api/v1/salary',
            'api/v1/payroll/summary',
            'api/v1/payslips',
            'api/v1/pf/summary',
            'api/v1/pf/ledger',
            'api/v1/leave/balances',
            'api/v1/documents',
            'api/v1/directory',
        ];

        foreach ($v1Endpoints as $endpoint) {
            $res = $this->withHeaders($h)->get($endpoint);
            $this->assertSame(403, $res->response()->getStatusCode(), "Endpoint {$endpoint} must return 403 when must_change_password is true");
            $json = json_decode($res->getJSON(), true);
            $this->assertFalse($json['success']);
            $this->assertTrue($json['must_change_password']);
            $this->assertSame('Password change is required before continuing.', $json['message']);
        }
    }

    /**
     * Test 2: Suffix and path injection bypass attempts are strictly rejected.
     * Prevents bypassing the filter via parameterized routes like documents/(:segment).
     */
    public function testSuffixInjectionBypassAttemptsAreRejected(): void
    {
        $this->db->table('users')->where('id', 'u-1')->update(['must_change_password' => 1]);

        $login = $this->login('ACME', 'rahim', self::PASSWORD);
        $token = $login['data']['tokens']['access_token'];
        $h = ['Authorization' => "Bearer {$token}"];

        // Attempting to append allowlisted path as a segment
        $bad1 = $this->withHeaders($h)->get('api/mobile/v1/documents/api/mobile/v1/auth/change-password');
        $this->assertSame(403, $bad1->response()->getStatusCode(), 'Suffix injection on documents must be rejected');

        $bad2 = $this->withHeaders($h)->get('api/v1/documents/api/v1/auth/change-password');
        $this->assertSame(403, $bad2->response()->getStatusCode(), 'Suffix injection on v1 documents must be rejected');

        $bad3 = $this->withHeaders($h)->get('api/mobile/v1/payslips/api/mobile/v1/auth/change-password');
        $this->assertSame(403, $bad3->response()->getStatusCode(), 'Suffix injection on payslips must be rejected');

        $bad4 = $this->withHeaders($h)->get('api/v1/payslips/api/v1/auth/change-password');
        $this->assertSame(403, $bad4->response()->getStatusCode(), 'Suffix injection on v1 payslips must be rejected');
    }

    /**
     * Test 3: Minimum required endpoints ARE accessible for forced-password-change user.
     * Tests: auth/me, auth/change-password, auth/logout, auth/logout-all on both prefixes.
     */
    public function testMinimumRequiredEndpointsAreAccessibleOnBothPrefixes(): void
    {
        $this->db->table('users')->where('id', 'u-1')->update(['must_change_password' => 1]);

        $login = $this->login('ACME', 'rahim', self::PASSWORD);
        $token = $login['data']['tokens']['access_token'];
        $h = ['Authorization' => "Bearer {$token}"];

        // 1. GET auth/me accessible on api/mobile/v1
        $meMobile = $this->withHeaders($h)->get('api/mobile/v1/auth/me');
        $this->assertSame(200, $meMobile->response()->getStatusCode());
        $bodyMeMobile = json_decode($meMobile->getJSON(), true);
        $this->assertTrue($bodyMeMobile['data']['must_change_password']);

        // 2. GET auth/me accessible on api/v1
        $meV1 = $this->withHeaders($h)->get('api/v1/auth/me');
        $this->assertSame(200, $meV1->response()->getStatusCode());
        $bodyMeV1 = json_decode($meV1->getJSON(), true);
        $this->assertTrue($bodyMeV1['data']['must_change_password']);

        // 3. POST auth/change-password reaches controller (validation check passes filter)
        $resMobile = $this->withHeaders($h)->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/change-password', [
            'current_password' => '',
            'new_password'     => '',
        ]);
        // 400 Bad Request or 422 Unprocessable Entity indicates it reached the controller and was NOT blocked by filter (403)
        $this->assertTrue(in_array($resMobile->response()->getStatusCode(), [400, 422], true));

        $resV1 = $this->withHeaders($h)->withBodyFormat('json')->call('post', 'api/v1/auth/change-password', [
            'current_password' => '',
            'new_password'     => '',
        ]);
        $this->assertTrue(in_array($resV1->response()->getStatusCode(), [400, 422], true));

        // 4. POST auth/logout accessible
        $resLogout = $this->withHeaders($h)->call('post', 'api/mobile/v1/auth/logout');
        $this->assertSame(200, $resLogout->response()->getStatusCode());
    }

    /**
     * Test 4: Password flag is cleared ONLY after successful password change.
     * Failed attempts keep the flag and continue denying protected resources.
     */
    public function testPasswordFlagClearedOnlyAfterSuccessfulChange(): void
    {
        $this->db->table('users')->where('id', 'u-1')->update(['must_change_password' => 1]);

        $login = $this->login('ACME', 'rahim', self::PASSWORD);
        $token = $login['data']['tokens']['access_token'];
        $h = ['Authorization' => "Bearer {$token}"];

        // Attempt 1: Wrong current password
        $res1 = $this->withHeaders($h)->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/change-password', [
            'current_password' => 'IncorrectOldPassword123!',
            'new_password'     => 'Valid#StrongPassword2026',
            'confirm_password' => 'Valid#StrongPassword2026',
        ]);
        $this->assertTrue(in_array($res1->response()->getStatusCode(), [400, 401, 422], true));
        $user1 = $this->db->table('users')->where('id', 'u-1')->get()->getRowArray();
        $this->assertSame(1, (int)$user1['must_change_password'], 'Flag must remain 1 after wrong current password');
        $this->withHeaders($h)->get('api/mobile/v1/profile')->assertStatus(403);

        // Attempt 2: Weak new password (missing special char or uppercase or too short)
        $res2 = $this->withHeaders($h)->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/change-password', [
            'current_password' => self::PASSWORD,
            'new_password'     => 'weakpassword',
            'confirm_password' => 'weakpassword',
        ]);
        $this->assertTrue(in_array($res2->response()->getStatusCode(), [400, 422], true));
        $user2 = $this->db->table('users')->where('id', 'u-1')->get()->getRowArray();
        $this->assertSame(1, (int)$user2['must_change_password'], 'Flag must remain 1 after weak new password');
        $this->withHeaders($h)->get('api/mobile/v1/profile')->assertStatus(403);

        // Attempt 3: Mismatched confirmation
        $res3 = $this->withHeaders($h)->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/change-password', [
            'current_password' => self::PASSWORD,
            'new_password'     => 'Valid#StrongPassword2026',
            'confirm_password' => 'Different#Password2026',
        ]);
        $this->assertTrue(in_array($res3->response()->getStatusCode(), [400, 422], true));
        $user3 = $this->db->table('users')->where('id', 'u-1')->get()->getRowArray();
        $this->assertSame(1, (int)$user3['must_change_password'], 'Flag must remain 1 after mismatched confirmation');
        $this->withHeaders($h)->get('api/mobile/v1/profile')->assertStatus(403);

        // Attempt 4: Successful password change
        $strongPassword = 'Valid#StrongPassword2026';
        $res4 = $this->withHeaders($h)->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/change-password', [
            'current_password' => self::PASSWORD,
            'new_password'     => $strongPassword,
            'confirm_password' => $strongPassword,
        ]);
        $this->assertSame(200, $res4->response()->getStatusCode());

        // Verify database flag is now 0
        $user4 = $this->db->table('users')->where('id', 'u-1')->get()->getRowArray();
        $this->assertSame(0, (int)$user4['must_change_password'], 'must_change_password must be cleared to 0');
        $this->assertTrue(password_verify($strongPassword, $user4['password_hash']));

        // Verify protected resources are now immediately accessible on both prefixes
        $this->withHeaders($h)->get('api/mobile/v1/profile')->assertStatus(200);
        $this->withHeaders($h)->get('api/v1/profile')->assertStatus(200);

        // Verify auth/me reports must_change_password = false
        $resMe = $this->withHeaders($h)->get('api/mobile/v1/auth/me');
        $bodyMe = json_decode($resMe->getJSON(), true);
        $this->assertFalse($bodyMe['data']['must_change_password']);
    }

    /**
     * Test 5: Compliance with project central password policy.
     */
    public function testPasswordPolicyValidationEnforced(): void
    {
        // 12 chars minimum
        $this->assertNotNull(PasswordPolicyService::validateStrength('Short1!'));
        // Uppercase required
        $this->assertNotNull(PasswordPolicyService::validateStrength('lowercase123!@#'));
        // Lowercase required
        $this->assertNotNull(PasswordPolicyService::validateStrength('UPPERCASE123!@#'));
        // Number required
        $this->assertNotNull(PasswordPolicyService::validateStrength('NoNumbersHere!@#'));
        // Special character required
        $this->assertNotNull(PasswordPolicyService::validateStrength('NoSpecialChars123'));
        // Valid password passes
        $this->assertNull(PasswordPolicyService::validateStrength('StrongP@ssw0rd!2026'));
    }
}
