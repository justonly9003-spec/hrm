<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\ArrearService;
use App\Services\Pf\PfCalculator;
use App\Services\Pf\PfEligibilityService;
use App\Services\Rules\RuleResolver;
use App\Models\EmployeeModel;
use App\Models\SalaryRevisionModel;
use App\Models\SalaryArrearModel;
use App\Models\ProvidentFundLedgerModel;

class FakeArrearPfRuleModel
{
    /** @var array<int, array<string, mixed>> */
    public array $rows;

    public function __construct(array $rows = [])
    {
        $this->rows = $rows;
    }

    public function getActiveRules(string $companyId, string $domain): array
    {
        $filtered = [];
        foreach ($this->rows as $r) {
            if (($r['company_id'] ?? null) === $companyId &&
                ($r['domain'] ?? null) === $domain &&
                ($r['status'] ?? 'Active') === 'Active') {
                $filtered[] = $r;
            }
        }
        return $filtered;
    }

    public function paramsOf(?array $row): array
    {
        if (empty($row) || !isset($row['params_json'])) {
            return [];
        }
        if (is_array($row['params_json'])) {
            return $row['params_json'];
        }
        $decoded = json_decode((string)$row['params_json'], true);
        return is_array($decoded) ? $decoded : [];
    }
}

class FakeEligibilityService extends PfEligibilityService
{
    /** @var array<string, array<int, array<string, mixed>>> */
    public array $periods = [];

    public function __construct(array $periods = [])
    {
        $this->periods = $periods;
    }

    public function getEligibilityOn(string $employeeId, string $date): ?array
    {
        $empPeriods = $this->periods[$employeeId] ?? [];
        foreach ($empPeriods as $p) {
            $from = $p['effective_from'];
            $to = $p['effective_to'] ?? null;
            if ($date >= $from && ($to === null || $date <= $to)) {
                return $p;
            }
        }
        return null;
    }
}

class ArrearPfCalculationTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        RuleResolver::resetMemo();
    }

    protected function getCompanyPfRule(string $companyId = 'comp-1', string $basis = 'Basic'): array
    {
        return [
            'id'             => 'pf-rule-001',
            'company_id'     => $companyId,
            'domain'         => 'PF',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2020-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'schema_version' => 1,
            'params_json'    => [
                'contribution_type'     => 'Percentage',
                'employee_rate'         => 10.0,
                'employer_rate'         => 10.0,
                'employee_fixed_amount' => 0.0,
                'employer_fixed_amount' => 0.0,
                'calculation_basis'     => $basis,
                'basis_components'      => [$basis],
                'min_salary_limit'      => 0.0,
                'max_salary_limit'      => 0.0,
                'min_deduction_limit'   => 0.0,
                'max_deduction_limit'   => 0.0,
                'opt_out_allowed'       => false,
            ],
        ];
    }

    /**
     * TEST 1: Increase effective from the next month (Future effective date -> 0 arrears generated)
     */
    public function testIncreaseEffectiveFromNextMonthGeneratesZeroArrears()
    {
        $fakeRuleModel = new FakeArrearPfRuleModel([$this->getCompanyPfRule('comp-1')]);
        $resolver      = new RuleResolver($fakeRuleModel);
        $pfCalc        = new PfCalculator($resolver);

        $nextMonth = date('Y-m-01', strtotime('+1 month'));

        $employee = [
            'id'               => 'emp-101',
            'company_id'       => 'comp-1',
            'basic_salary'     => 50000.00,
            'gross_salary'     => 75000.00,
            'is_pf_applicable' => 1,
            'pf_status'        => 'Enrolled',
        ];

        // Future effective date: retroactive months must be empty
        $effectiveMonthStart = date('Y-m-01', strtotime($nextMonth));
        $currentMonthStart   = date('Y-m-01');

        $this->assertGreaterThanOrEqual(strtotime($currentMonthStart), strtotime($effectiveMonthStart));
    }

    /**
     * TEST 2: Backdated 3 months (Both employee and employer PF arrears calculated via PfCalculator)
     */
    public function testBackdatedThreeMonthsCalculatesEmployeeAndEmployerPfArrears()
    {
        $fakeRuleModel = new FakeArrearPfRuleModel([$this->getCompanyPfRule('comp-1', 'Basic')]);
        $resolver      = new RuleResolver($fakeRuleModel);
        $eligService   = new FakeEligibilityService([
            'emp-101' => [
                [
                    'id'             => 'period-1',
                    'employee_id'    => 'emp-101',
                    'status'         => 'Eligible',
                    'effective_from' => '2025-01-01',
                    'effective_to'   => null,
                ]
            ]
        ]);
        $pfCalc = new PfCalculator($resolver, $eligService);

        $prevBasic = 50000.00;
        $newBasic  = 60000.00;
        $prevGross = 75000.00;
        $newGross  = 90000.00;

        $employee = [
            'id'               => 'emp-101',
            'company_id'       => 'comp-1',
            'basic_salary'     => $prevBasic,
            'gross_salary'     => $prevGross,
            'is_pf_applicable' => 1,
            'pf_status'        => 'Enrolled',
        ];

        // For each of the 3 backdated months:
        // old PF: 10% of 50,000 = 5,000 (employee), 5,000 (employer)
        // new PF: 10% of 60,000 = 6,000 (employee), 6,000 (employer)
        // PF delta per month: 1,000 employee, 1,000 employer
        $oldPf = $pfCalc->calculate([
            'company_id'     => 'comp-1',
            'employee'       => $employee,
            'effective_date' => '2026-06-30',
            'earnings'       => ['Basic' => $prevBasic, 'Gross' => $prevGross]
        ]);

        $newPf = $pfCalc->calculate([
            'company_id'     => 'comp-1',
            'employee'       => $employee,
            'effective_date' => '2026-06-30',
            'earnings'       => ['Basic' => $newBasic, 'Gross' => $newGross]
        ]);

        $pfArrearEmp = round((float)$newPf['employee_deduction'] - (float)$oldPf['employee_deduction'], 2);
        $pfArrearComp = round((float)$newPf['employer_contribution'] - (float)$oldPf['employer_contribution'], 2);

        $this->assertEquals(1000.00, $pfArrearEmp);
        $this->assertEquals(1000.00, $pfArrearComp);

        // Over 3 months:
        $totalPfEmp = $pfArrearEmp * 3;
        $totalPfComp = $pfArrearComp * 3;
        $this->assertEquals(3000.00, $totalPfEmp);
        $this->assertEquals(3000.00, $totalPfComp);
    }

    /**
     * TEST 3: Mid-month effective date (Pro-rata days applied to first month)
     */
    public function testMidMonthEffectiveDateProration()
    {
        $fakeRuleModel = new FakeArrearPfRuleModel([$this->getCompanyPfRule('comp-1', 'Basic')]);
        $resolver      = new RuleResolver($fakeRuleModel);
        $eligService   = new FakeEligibilityService([
            'emp-101' => [
                [
                    'id'             => 'period-1',
                    'employee_id'    => 'emp-101',
                    'status'         => 'Eligible',
                    'effective_from' => '2025-01-01',
                    'effective_to'   => null,
                ]
            ]
        ]);
        $pfCalc = new PfCalculator($resolver, $eligService);

        // Effective date: June 16 in a 30-day month (15 days applicable: June 16 to 30)
        $daysInMonth = 30;
        $effectiveDay = 16;
        $applicableDays = $daysInMonth - $effectiveDay + 1; // 15
        $monthFraction = $applicableDays / $daysInMonth; // 0.5

        $prevBasic = 40000.00;
        $newBasic  = 60000.00;
        $basicDeltaFull = $newBasic - $prevBasic; // 20000
        $basicDeltaProrated = round($basicDeltaFull * $monthFraction, 2); // 10000

        $oldEarnings = ['Basic' => round($prevBasic * $monthFraction, 2), 'Gross' => 30000.00];
        $newEarnings = ['Basic' => round($prevBasic * $monthFraction + $basicDeltaProrated, 2), 'Gross' => 45000.00];

        $oldPf = $pfCalc->calculate([
            'company_id'     => 'comp-1',
            'employee'       => ['id' => 'emp-101', 'company_id' => 'comp-1'],
            'effective_date' => '2026-06-30',
            'earnings'       => $oldEarnings
        ]);

        $newPf = $pfCalc->calculate([
            'company_id'     => 'comp-1',
            'employee'       => ['id' => 'emp-101', 'company_id' => 'comp-1'],
            'effective_date' => '2026-06-30',
            'earnings'       => $newEarnings
        ]);

        $pfArrearEmp = round((float)$newPf['employee_deduction'] - (float)$oldPf['employee_deduction'], 2);
        // 10% of 10,000 delta = 1,000
        $this->assertEquals(1000.00, $pfArrearEmp);
    }

    /**
     * TEST 4: Salary decrease allows negative PF delta (recovery/adjustment, not clamped to zero)
     */
    public function testSalaryDecreaseAllowsNegativePfDelta()
    {
        $fakeRuleModel = new FakeArrearPfRuleModel([$this->getCompanyPfRule('comp-1', 'Basic')]);
        $resolver      = new RuleResolver($fakeRuleModel);
        $eligService   = new FakeEligibilityService([
            'emp-101' => [
                [
                    'id'             => 'period-1',
                    'employee_id'    => 'emp-101',
                    'status'         => 'Eligible',
                    'effective_from' => '2025-01-01',
                    'effective_to'   => null,
                ]
            ]
        ]);
        $pfCalc = new PfCalculator($resolver, $eligService);

        // Previous basic: 60,000, New decreased basic: 50,000
        $prevBasic = 60000.00;
        $newBasic  = 50000.00;
        $prevGross = 90000.00;
        $newGross  = 75000.00;

        $oldPf = $pfCalc->calculate([
            'company_id'     => 'comp-1',
            'employee'       => ['id' => 'emp-101', 'company_id' => 'comp-1'],
            'effective_date' => '2026-06-30',
            'earnings'       => ['Basic' => $prevBasic, 'Gross' => $prevGross]
        ]);

        $newPf = $pfCalc->calculate([
            'company_id'     => 'comp-1',
            'employee'       => ['id' => 'emp-101', 'company_id' => 'comp-1'],
            'effective_date' => '2026-06-30',
            'earnings'       => ['Basic' => $newBasic, 'Gross' => $newGross]
        ]);

        $pfArrearEmp = round((float)$newPf['employee_deduction'] - (float)$oldPf['employee_deduction'], 2);
        $pfArrearComp = round((float)$newPf['employer_contribution'] - (float)$oldPf['employer_contribution'], 2);

        // Negative deltas allowed: 5,000 - 6,000 = -1,000
        $this->assertEquals(-1000.00, $pfArrearEmp);
        $this->assertEquals(-1000.00, $pfArrearComp);
        $this->assertLessThan(0.00, $pfArrearEmp);
    }

    /**
     * TEST 5: Employee not eligible in some of the backdated months (PF arrear is 0 for those months)
     */
    public function testEmployeeNotEligibleInSomeBackdatedMonthsProducesZeroPfArrear()
    {
        $fakeRuleModel = new FakeArrearPfRuleModel([$this->getCompanyPfRule('comp-1', 'Basic')]);
        $resolver      = new RuleResolver($fakeRuleModel);

        // Eligible only from 2026-05-01 onwards; NOT eligible in 2026-04
        $eligService = new FakeEligibilityService([
            'emp-101' => [
                [
                    'id'             => 'period-1',
                    'employee_id'    => 'emp-101',
                    'status'         => 'Eligible',
                    'effective_from' => '2026-05-01',
                    'effective_to'   => null,
                ]
            ]
        ]);
        $pfCalc = new PfCalculator($resolver, $eligService);

        // Month 1: April 2026 (Not Eligible)
        $oldPfApr = $pfCalc->calculate([
            'company_id'     => 'comp-1',
            'employee'       => ['id' => 'emp-101', 'company_id' => 'comp-1'],
            'effective_date' => '2026-04-30',
            'earnings'       => ['Basic' => 50000.00, 'Gross' => 75000.00]
        ]);
        $newPfApr = $pfCalc->calculate([
            'company_id'     => 'comp-1',
            'employee'       => ['id' => 'emp-101', 'company_id' => 'comp-1'],
            'effective_date' => '2026-04-30',
            'earnings'       => ['Basic' => 60000.00, 'Gross' => 90000.00]
        ]);

        $this->assertFalse($oldPfApr['is_eligible']);
        $this->assertFalse($newPfApr['is_eligible']);
        $pfArrearApr = (!$newPfApr['is_eligible'] && !$oldPfApr['is_eligible'])
            ? 0.00
            : round((float)$newPfApr['employee_deduction'] - (float)$oldPfApr['employee_deduction'], 2);
        $this->assertEquals(0.00, $pfArrearApr);

        // Month 2: May 2026 (Eligible)
        $oldPfMay = $pfCalc->calculate([
            'company_id'     => 'comp-1',
            'employee'       => ['id' => 'emp-101', 'company_id' => 'comp-1'],
            'effective_date' => '2026-05-31',
            'earnings'       => ['Basic' => 50000.00, 'Gross' => 75000.00]
        ]);
        $newPfMay = $pfCalc->calculate([
            'company_id'     => 'comp-1',
            'employee'       => ['id' => 'emp-101', 'company_id' => 'comp-1'],
            'effective_date' => '2026-05-31',
            'earnings'       => ['Basic' => 60000.00, 'Gross' => 90000.00]
        ]);

        $this->assertTrue($oldPfMay['is_eligible']);
        $this->assertTrue($newPfMay['is_eligible']);
        $pfArrearMay = round((float)$newPfMay['employee_deduction'] - (float)$oldPfMay['employee_deduction'], 2);
        $this->assertEquals(1000.00, $pfArrearMay);
    }

    /**
     * TEST 6: PF on Gross basis (RuleResolver calculation_basis = 'Gross')
     */
    public function testPfOnGrossBasisCalculatesArrearsOnGrossDelta()
    {
        $fakeRuleModel = new FakeArrearPfRuleModel([$this->getCompanyPfRule('comp-1', 'Gross')]);
        $resolver      = new RuleResolver($fakeRuleModel);
        $eligService   = new FakeEligibilityService([
            'emp-101' => [
                [
                    'id'             => 'period-1',
                    'employee_id'    => 'emp-101',
                    'status'         => 'Eligible',
                    'effective_from' => '2025-01-01',
                    'effective_to'   => null,
                ]
            ]
        ]);
        $pfCalc = new PfCalculator($resolver, $eligService);

        // Old: Basic 50,000, Gross 80,000 -> PF = 10% of Gross 80,000 = 8,000
        // New: Basic 60,000, Gross 100,000 -> PF = 10% of Gross 100,000 = 10,000
        // Arrear = 2,000 (not 1,000 from basic delta)
        $oldPf = $pfCalc->calculate([
            'company_id'     => 'comp-1',
            'employee'       => ['id' => 'emp-101', 'company_id' => 'comp-1'],
            'effective_date' => '2026-06-30',
            'earnings'       => ['Basic' => 50000.00, 'Gross' => 80000.00]
        ]);

        $newPf = $pfCalc->calculate([
            'company_id'     => 'comp-1',
            'employee'       => ['id' => 'emp-101', 'company_id' => 'comp-1'],
            'effective_date' => '2026-06-30',
            'earnings'       => ['Basic' => 60000.00, 'Gross' => 100000.00]
        ]);

        $this->assertEquals('Gross', $oldPf['calculation_basis']);
        $this->assertEquals(8000.00, (float)$oldPf['employee_deduction']);
        $this->assertEquals(10000.00, (float)$newPf['employee_deduction']);

        $pfArrearEmp = round((float)$newPf['employee_deduction'] - (float)$oldPf['employee_deduction'], 2);
        $this->assertEquals(2000.00, $pfArrearEmp);
    }

    /**
     * TEST 7: Preview total equals actual arrear total
     */
    public function testPreviewTotalEqualsActualArrearTotal()
    {
        $fakeRuleModel = new FakeArrearPfRuleModel([$this->getCompanyPfRule('comp-1', 'Basic')]);
        $resolver      = new RuleResolver($fakeRuleModel);
        $eligService   = new FakeEligibilityService([
            'emp-101' => [
                [
                    'id'             => 'period-1',
                    'employee_id'    => 'emp-101',
                    'status'         => 'Eligible',
                    'effective_from' => '2025-01-01',
                    'effective_to'   => null,
                ]
            ]
        ]);
        $pfCalc = new PfCalculator($resolver, $eligService);

        $prevBasic = 50000.00;
        $newBasic  = 60000.00;
        $prevGross = 75000.00;
        $newGross  = 90000.00;

        // Preview calculation logic for 2 months
        $months = ['2026-04', '2026-05'];
        $previewTotalGross = 0.0;
        $previewTotalPf = 0.0;
        $actualTotalGross = 0.0;
        $actualTotalPf = 0.0;

        foreach ($months as $mStr) {
            $monthDate = date('Y-m-t', strtotime($mStr . '-01'));
            $oldPf = $pfCalc->calculate([
                'company_id'     => 'comp-1',
                'employee'       => ['id' => 'emp-101', 'company_id' => 'comp-1'],
                'effective_date' => $monthDate,
                'earnings'       => ['Basic' => $prevBasic, 'Gross' => $prevGross]
            ]);
            $newPf = $pfCalc->calculate([
                'company_id'     => 'comp-1',
                'employee'       => ['id' => 'emp-101', 'company_id' => 'comp-1'],
                'effective_date' => $monthDate,
                'earnings'       => ['Basic' => $newBasic, 'Gross' => $newGross]
            ]);

            $grossDelta = $newGross - $prevGross;
            $pfDelta = round((float)$newPf['employee_deduction'] - (float)$oldPf['employee_deduction'], 2);

            $previewTotalGross += $grossDelta;
            $previewTotalPf += $pfDelta;

            $actualTotalGross += $grossDelta;
            $actualTotalPf += $pfDelta;
        }

        $this->assertEquals($actualTotalGross, $previewTotalGross);
        $this->assertEquals($actualTotalPf, $previewTotalPf);
    }

    /**
     * TEST 8: Ledger total equals payroll PF deduction
     */
    public function testLedgerTotalEqualsPayrollPfDeduction()
    {
        $regularPfDeduction = 5000.00;
        $arrearPfDeduction  = 2000.00; // From 2 months of 1,000 arrear each
        $totalAppliedDeduction = $regularPfDeduction + $arrearPfDeduction;

        // In payroll item:
        $payrollItem = [
            'pf_deduction'        => $totalAppliedDeduction,
            'arrear_pf_deduction' => $arrearPfDeduction,
        ];

        // In provident_fund_ledgers:
        $ledgerContribution = 5000.00; // Regular monthly contribution entry
        $ledgerArrears      = 2000.00; // Arrear ledger entries posted from revisions

        $totalLedgerDeduction = $ledgerContribution + $ledgerArrears;

        $this->assertEquals($payrollItem['pf_deduction'], $totalLedgerDeduction);
    }

    /**
     * TEST 9: Verification of how PayrollService picks active salary for mid-month revisions
     * Documenting: PayrollService queries getActiveSalary as of month-end (Y-m-t).
     * When effective_date <= month-end, the revised salary structure is selected as active for that month.
     */
    public function testActiveSalaryResolutionForMidMonthRevision()
    {
        $salaries = [
            [
                'id'             => 'sal-old',
                'employee_id'    => 'emp-101',
                'basic_salary'   => 40000.00,
                'gross_salary'   => 60000.00,
                'effective_from' => '2025-01-01',
                'effective_to'   => '2026-03-14',
                'status'         => 'Revised'
            ],
            [
                'id'             => 'sal-new',
                'employee_id'    => 'emp-101',
                'basic_salary'   => 50000.00,
                'gross_salary'   => 75000.00,
                'effective_from' => '2026-03-15', // Mid-month effective
                'effective_to'   => null,
                'status'         => 'Active'
            ]
        ];

        $payrollMonth = '2026-03';
        $monthEnd = '2026-03-31';

        // Filter salaries active as of month-end
        $activeAsOfMonthEnd = null;
        foreach ($salaries as $s) {
            if ($s['effective_from'] <= $monthEnd && ($s['effective_to'] === null || $s['effective_to'] >= $monthEnd)) {
                $activeAsOfMonthEnd = $s;
            }
        }

        $this->assertNotNull($activeAsOfMonthEnd);
        $this->assertEquals('sal-new', $activeAsOfMonthEnd['id']);
        $this->assertEquals(50000.00, (float)$activeAsOfMonthEnd['basic_salary']);
    }
}
