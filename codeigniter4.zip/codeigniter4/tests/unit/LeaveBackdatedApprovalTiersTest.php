<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\LeaveService;
use App\Services\Leave\LeaveApplicationService;

class LeaveBackdatedApprovalTiersTest extends TestCase
{
    private LeaveService $leaveService;
    private array $defaultWorkflow;
    private array $defaultEmp;

    protected function setUp(): void
    {
        parent::setUp();
        $this->leaveService = new LeaveService();
        $this->defaultWorkflow = [
            'workflow_type'           => 'Multi-Tier',
            'auto_approve_under_days' => 0.0,
            'tier_conditions'         => [
                [
                    'min_days'           => 1,
                    'max_days'           => 2,
                    'required_approvers' => ['Manager'],
                ],
                [
                    'min_days'           => 3,
                    'max_days'           => 7,
                    'required_approvers' => ['Manager', 'HR Admin'],
                ],
                [
                    'min_days'           => 8,
                    'max_days'           => 999,
                    'required_approvers' => ['Manager', 'Department Head', 'HR Admin'],
                ],
            ],
        ];

        $this->defaultEmp = [
            'id'                   => 'EMP-100',
            'company_id'           => 'comp-test-01',
            'reporting_manager_id' => 'MGR-200',
            'manager_id'           => 'MGR-200',
            'reporting_to'         => 'MGR-200',
            'department_id'        => 'DEPT-300',
            'dept_head_id'         => 'DH-400',
            'branch_id'            => 'BR-500',
        ];
    }

    /**
     * Test 1: 1-day backdated leave with "Manager and HR":
     * - Manager endorses, then manager tries final approval -> denied (403, Separation of duties violation)
     * - HR approval -> allowed (200)
     */
    public function testOneDayBackdatedLeaveWithManagerAndHrRequiresBothAndEnforcesSeparationOfDuties()
    {
        $app = [
            'id'                => 'app-backdate-mgr-hr-01',
            'company_id'        => 'comp-test-01',
            'employee_id'       => 'EMP-100',
            'from_date'         => date('Y-m-d', strtotime('-2 days')),
            'to_date'           => date('Y-m-d', strtotime('-2 days')),
            'total_days'        => 1.0,
            'is_backdated'      => 1,
            'backdated_role'    => 'Manager and HR',
            'approval_workflow' => $this->defaultWorkflow,
            'status'            => 'Pending',
            'manager_id'        => 'MGR-200',
            'manager_status'    => 'Pending',
            'dept_head_status'  => 'Pending',
            'hr_status'         => 'Pending',
        ];

        // 1. Verify required approvers resolves to ['Manager', 'HR Admin'] even though duration is only 1 day
        $requiredApprovers = LeaveApplicationService::resolveRequiredApproversForApplication(
            $this->defaultWorkflow,
            1.0,
            (bool)$app['is_backdated'],
            $app['backdated_role']
        );
        $this->assertEquals(['Manager', 'HR Admin'], $requiredApprovers);
        $this->assertTrue(LeaveApplicationService::isManagerTierRequired($requiredApprovers));

        // 2. Before manager endorsement: HR tries final approval -> denied (supervisor endorsement required first)
        $hrApprover = [
            'id'          => 'HR-300',
            'user_id'     => 'HR-300',
            'role_code'   => 'hr_manager',
            'scope'       => 'company',
            'permissions' => ['leave.hr_approve', 'leave.view'],
            'company_id'  => 'comp-test-01',
        ];
        $policyCheckBeforeEndorse = LeaveApplicationService::checkApprovalPolicy(
            $app,
            $this->defaultEmp,
            $hrApprover,
            null,
            'HR-300',
            $this->defaultWorkflow
        );
        $this->assertFalse($policyCheckBeforeEndorse['allowed']);
        $this->assertEquals(403, $policyCheckBeforeEndorse['code']);
        $this->assertStringContainsString('supervisor endorsement is required', $policyCheckBeforeEndorse['message']);

        // 3. Manager endorses the leave
        $app['manager_status'] = 'Approved';
        $app['manager_id'] = 'MGR-200';

        // 4. Manager tries final approval -> denied due to separation of duties
        $mgrApprover = [
            'id'          => 'MGR-200',
            'user_id'     => 'MGR-200',
            'role_code'   => 'line_manager',
            'scope'       => 'department',
            'department_id' => 'DEPT-300',
            'branch_id'   => 'BR-500',
            'permissions' => ['leave.approve', 'leave.endorse', 'leave.hr_approve'],
            'company_id'  => 'comp-test-01',
        ];
        $mgrFinalApprovalCheck = LeaveApplicationService::checkApprovalPolicy(
            $app,
            $this->defaultEmp,
            $mgrApprover,
            null,
            'MGR-200',
            $this->defaultWorkflow
        );
        $this->assertFalse($mgrFinalApprovalCheck['allowed'], 'Manager who endorsed cannot give final approval');
        $this->assertEquals(403, $mgrFinalApprovalCheck['code']);
        $this->assertStringContainsString('Separation of duties violation', $mgrFinalApprovalCheck['message']);

        // 5. HR tries final approval after endorsement -> allowed
        $hrFinalApprovalCheck = LeaveApplicationService::checkApprovalPolicy(
            $app,
            $this->defaultEmp,
            $hrApprover,
            null,
            'HR-300',
            $this->defaultWorkflow
        );
        $this->assertTrue($hrFinalApprovalCheck['allowed'], 'HR with leave.hr_approve must be allowed to finalize approval');
    }

    /**
     * Test 2: 1-day backdated leave with "HR Only":
     * - Manager-only approval (direct manager without HR authority) -> denied (403)
     * - HR approval -> allowed (200)
     */
    public function testOneDayBackdatedLeaveWithHrOnlyDeniesManagerAndAllowsHr()
    {
        $app = [
            'id'                => 'app-backdate-hr-only-01',
            'company_id'        => 'comp-test-01',
            'employee_id'       => 'EMP-100',
            'from_date'         => date('Y-m-d', strtotime('-1 day')),
            'to_date'           => date('Y-m-d', strtotime('-1 day')),
            'total_days'        => 1.0,
            'is_backdated'      => 1,
            'backdated_role'    => 'HR Only',
            'approval_workflow' => $this->defaultWorkflow,
            'status'            => 'Pending',
            'manager_status'    => 'Pending',
            'hr_status'         => 'Pending',
        ];

        // 1. Verify required approvers resolves to ['HR Admin']
        $requiredApprovers = LeaveApplicationService::resolveRequiredApproversForApplication(
            $this->defaultWorkflow,
            1.0,
            (bool)$app['is_backdated'],
            $app['backdated_role']
        );
        $this->assertEquals(['HR Admin'], $requiredApprovers);
        $this->assertFalse(LeaveApplicationService::isManagerTierRequired($requiredApprovers));

        // 2. Direct manager (with leave.approve only) tries to finalize approval -> denied (403)
        $mgrApprover = [
            'id'          => 'MGR-200',
            'user_id'     => 'MGR-200',
            'role_code'   => 'line_manager',
            'scope'       => 'department',
            'department_id' => 'DEPT-300',
            'branch_id'   => 'BR-500',
            'permissions' => ['leave.approve', 'leave.endorse'],
            'company_id'  => 'comp-test-01',
        ];
        $mgrCheck = LeaveApplicationService::checkApprovalPolicy(
            $app,
            $this->defaultEmp,
            $mgrApprover,
            null,
            'MGR-200',
            $this->defaultWorkflow
        );
        $this->assertFalse($mgrCheck['allowed'], 'Direct manager without HR authority must be denied for HR Only tier');
        $this->assertEquals(403, $mgrCheck['code']);
        $this->assertStringContainsString('requires leave.hr_approve or leave.manage', $mgrCheck['message']);

        // 3. HR Admin with leave.hr_approve tries to finalize approval -> allowed
        $hrApprover = [
            'id'          => 'HR-300',
            'user_id'     => 'HR-300',
            'role_code'   => 'hr_manager',
            'scope'       => 'company',
            'permissions' => ['leave.hr_approve', 'leave.view'],
            'company_id'  => 'comp-test-01',
        ];
        $hrCheck = LeaveApplicationService::checkApprovalPolicy(
            $app,
            $this->defaultEmp,
            $hrApprover,
            null,
            'HR-300',
            $this->defaultWorkflow
        );
        $this->assertTrue($hrCheck['allowed'], 'HR user with leave.hr_approve must be allowed to approve HR Only tier');
    }

    /**
     * Test 3: 1-day backdated leave with "Manager":
     * - Same as normal manager-only tier -> allowed for direct manager (200)
     */
    public function testOneDayBackdatedLeaveWithManagerAllowedForDirectManager()
    {
        $app = [
            'id'                => 'app-backdate-mgr-01',
            'company_id'        => 'comp-test-01',
            'employee_id'       => 'EMP-100',
            'from_date'         => date('Y-m-d', strtotime('-2 days')),
            'to_date'           => date('Y-m-d', strtotime('-2 days')),
            'total_days'        => 1.0,
            'is_backdated'      => 1,
            'backdated_role'    => 'Manager',
            'approval_workflow' => $this->defaultWorkflow,
            'status'            => 'Pending',
            'manager_status'    => 'Pending',
            'hr_status'         => 'Pending',
        ];

        // 1. Verify required approvers resolves to ['Manager']
        $requiredApprovers = LeaveApplicationService::resolveRequiredApproversForApplication(
            $this->defaultWorkflow,
            1.0,
            (bool)$app['is_backdated'],
            $app['backdated_role']
        );
        $this->assertEquals(['Manager'], $requiredApprovers);
        $this->assertFalse(LeaveApplicationService::isManagerTierRequired($requiredApprovers));

        // 2. Direct manager with leave.approve tries approval -> allowed
        $mgrApprover = [
            'id'          => 'MGR-200',
            'user_id'     => 'MGR-200',
            'role_code'   => 'line_manager',
            'scope'       => 'department',
            'department_id' => 'DEPT-300',
            'branch_id'   => 'BR-500',
            'permissions' => ['leave.approve'],
            'company_id'  => 'comp-test-01',
        ];
        $mgrCheck = LeaveApplicationService::checkApprovalPolicy(
            $app,
            $this->defaultEmp,
            $mgrApprover,
            null,
            'MGR-200',
            $this->defaultWorkflow
        );
        $this->assertTrue($mgrCheck['allowed'], 'Direct manager must be allowed to approve single-tier Manager backdated leave');
    }

    /**
     * Test 4: 1-day NOT backdated leave -> unchanged behavior (manager-only allowed 200).
     */
    public function testOneDayNotBackdatedLeaveUnchangedBehaviorManagerOnly()
    {
        $app = [
            'id'                => 'app-future-01',
            'company_id'        => 'comp-test-01',
            'employee_id'       => 'EMP-100',
            'from_date'         => date('Y-m-d', strtotime('+5 days')),
            'to_date'           => date('Y-m-d', strtotime('+5 days')),
            'total_days'        => 1.0,
            'is_backdated'      => 0,
            'backdated_role'    => null,
            'approval_workflow' => $this->defaultWorkflow,
            'status'            => 'Pending',
            'manager_status'    => 'Pending',
            'hr_status'         => 'Pending',
        ];

        // 1. Verify required approvers resolves to standard tier ['Manager']
        $requiredApprovers = LeaveApplicationService::resolveRequiredApproversForApplication(
            $this->defaultWorkflow,
            1.0,
            (bool)$app['is_backdated'],
            $app['backdated_role'] ?? ''
        );
        $this->assertEquals(['Manager'], $requiredApprovers);

        // 2. Direct manager with leave.approve -> allowed
        $mgrApprover = [
            'id'          => 'MGR-200',
            'user_id'     => 'MGR-200',
            'role_code'   => 'line_manager',
            'scope'       => 'department',
            'department_id' => 'DEPT-300',
            'branch_id'   => 'BR-500',
            'permissions' => ['leave.approve'],
            'company_id'  => 'comp-test-01',
        ];
        $mgrCheck = LeaveApplicationService::checkApprovalPolicy(
            $app,
            $this->defaultEmp,
            $mgrApprover,
            null,
            'MGR-200',
            $this->defaultWorkflow
        );
        $this->assertTrue($mgrCheck['allowed'], 'Direct manager must be allowed to approve standard 1-day future leave');
    }

    /**
     * Test 5: Old row with is_backdated = 0 and backdated_role NULL -> unchanged behavior (manager-only allowed 200).
     */
    public function testOldRowWithIsBackdatedZeroAndBackdatedRoleNullUnchangedBehavior()
    {
        $app = [
            'id'                => 'app-legacy-01',
            'company_id'        => 'comp-test-01',
            'employee_id'       => 'EMP-100',
            'from_date'         => '2024-01-10',
            'to_date'           => '2024-01-10',
            'total_days'        => 1.0,
            'is_backdated'      => 0,
            'backdated_role'    => null,
            'approval_workflow' => $this->defaultWorkflow,
            'status'            => 'Pending',
            'manager_status'    => 'Pending',
            'hr_status'         => 'Pending',
        ];

        $requiredApprovers = LeaveApplicationService::resolveRequiredApproversForApplication(
            $this->defaultWorkflow,
            1.0,
            (bool)($app['is_backdated'] ?? false),
            (string)($app['backdated_role'] ?? '')
        );
        $this->assertEquals(['Manager'], $requiredApprovers);

        $mgrApprover = [
            'id'          => 'MGR-200',
            'user_id'     => 'MGR-200',
            'role_code'   => 'line_manager',
            'scope'       => 'department',
            'department_id' => 'DEPT-300',
            'branch_id'   => 'BR-500',
            'permissions' => ['leave.approve'],
            'company_id'  => 'comp-test-01',
        ];
        $mgrCheck = LeaveApplicationService::checkApprovalPolicy(
            $app,
            $this->defaultEmp,
            $mgrApprover,
            null,
            'MGR-200',
            $this->defaultWorkflow
        );
        $this->assertTrue($mgrCheck['allowed'], 'Legacy row without backdated fields must retain manager-only approval');
    }

    /**
     * Test 6: An edit that changes the dates from future to past recomputes the required approvers.
     */
    public function testEditChangingDateFromFutureToPastRecomputesRequiredApproversAndSteps()
    {
        $rules = [
            'allow_backdated_application' => true,
            'max_backdate_days'           => 14,
            'backdated_role_requirement'  => 'Manager and HR',
        ];

        // 1. Initial future date
        $futureDate = date('Y-m-d', strtotime('+5 days'));
        $futureDecision = LeaveApplicationService::recomputeBackdatedDecision($futureDate, $rules);
        $this->assertEquals(0, $futureDecision['is_backdated']);
        $this->assertEquals('', $futureDecision['backdated_role']);

        $futureApprovers = LeaveApplicationService::resolveRequiredApproversForApplication(
            $this->defaultWorkflow,
            1.0,
            (bool)$futureDecision['is_backdated'],
            $futureDecision['backdated_role']
        );
        $this->assertEquals(['Manager'], $futureApprovers, 'Future 1-day leave requires only Manager');

        $appService = new LeaveApplicationService($this->leaveService);
        $futureSteps = $appService->buildApprovalSteps('lv-future-edit-01', $futureApprovers, $this->defaultEmp, false);
        $this->assertCount(1, $futureSteps);
        $this->assertEquals('Line Manager', $futureSteps[0]['approver_role']);

        // 2. Updated to past date (backdated)
        $pastDate = date('Y-m-d', strtotime('-3 days'));
        $pastDecision = LeaveApplicationService::recomputeBackdatedDecision($pastDate, $rules);
        $this->assertEquals(1, $pastDecision['is_backdated']);
        $this->assertEquals('Manager and HR', $pastDecision['backdated_role']);

        $pastApprovers = LeaveApplicationService::resolveRequiredApproversForApplication(
            $this->defaultWorkflow,
            1.0,
            (bool)$pastDecision['is_backdated'],
            $pastDecision['backdated_role']
        );
        $this->assertEquals(['Manager', 'HR Admin'], $pastApprovers, 'Recomputed backdated leave requires Manager and HR');

        $pastSteps = $appService->buildApprovalSteps('lv-future-edit-01', $pastApprovers, $this->defaultEmp, false);
        $this->assertCount(2, $pastSteps, 'Recomputed backdated steps must now contain 2 tiers');
        $this->assertEquals('Line Manager', $pastSteps[0]['approver_role']);
        $this->assertEquals('HR Administration', $pastSteps[1]['approver_role']);
    }
}
