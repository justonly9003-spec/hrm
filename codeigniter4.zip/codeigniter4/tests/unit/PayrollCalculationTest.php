<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class PayrollCalculationTest extends TestCase
{
    public function testSalaryGradeAllowancesAndDeductions()
    {
        $basicSalary = 50000.0;
        
        // Grade dynamic allowances
        $houseRentPercentage = 20.0;
        $medicalPercentage   = 10.0;
        $transportAllowance  = 3000.0;
        $foodAllowance       = 2000.0;

        $houseRent = $basicSalary * ($houseRentPercentage / 100.0); // 15000
        $medical   = $basicSalary * ($medicalPercentage / 100.0);   // 5000

        $grossSalary = $basicSalary + $houseRent + $medical + $transportAllowance + $foodAllowance;
        $this->assertEquals(70000.0, $grossSalary, "Gross salary calculation matches dynamic grade breakdown.");

        // Unpaid leave deduction (Loss of Pay)
        $monthDays = 30;
        $unpaidLeaveDays = 2;
        $perDaySalary = $grossSalary / $monthDays; // 2333.333
        $unpaidDeduction = round($perDaySalary * $unpaidLeaveDays, 2); // 4666.67

        $this->assertEquals(4666.67, $unpaidDeduction, "Loss of Pay deduction accurately computed for unpaid leaves.");

        // Overtime addition (Interim Phase 1: zero overtime pay)
        $overtimePay = 0.0;
        $this->assertEquals(0.0, $overtimePay, "Overtime earnings safely set to zero in Phase 1 clean state.");

        // Festival Bonus addition
        $bonusAmount = 25000.0;

        // Loan / Advance deduction
        $loanEmi = 5000.0;
        $taxDeduction = 2000.0;

        $totalEarnings = $grossSalary + $overtimePay + $bonusAmount; // 95000.00
        $totalDeductions = $unpaidDeduction + $loanEmi + $taxDeduction; // 11666.67
        $netPay = round($totalEarnings - $totalDeductions, 2); // 83333.33

        $this->assertEquals(95000.00, $totalEarnings);
        $this->assertEquals(11666.67, $totalDeductions);
        $this->assertEquals(83333.33, $netPay);
    }

    /**
     * VULN-PAY-06: 50% Statutory Deduction Ceiling & Allocation Priority
     */
    public function testStatutoryDeductionCeilingPriorityAndAllocation()
    {
        $gross = 100000.0;
        $maxDeduction = round($gross * 0.50, 2); // 50,000.00

        $requestedDeductions = [
            'tax'     => 15000.0,
            'pf'      => 10000.0,
            'lop'     => 5000.0,
            'advance' => 12000.0,
            'loan'    => 15000.0,
            'other'   => 8000.0
        ]; // Total requested: 65,000.00 (exceeds 50,000 by 15,000)

        // Priority allocation: Tax (15k) -> PF (10k) -> Advance (12k) = 37k
        // LOP (5k) is applied in full and does NOT consume the 50% statutory ceiling
        // Remaining cap for Loan = 50k - 37k = 13k (out of 15k requested)
        // Remaining cap for Other = 0k (out of 8k requested)
        $priorityOrder = ['tax', 'pf', 'advance', 'loan', 'other'];
        $remainingCap = $maxDeduction;
        $applied = [];
        $unapplied = [];

        // LOP is applied in full outside the ceiling
        $applied['lop'] = round((float)($requestedDeductions['lop'] ?? 0), 2);
        $unapplied['lop'] = 0.0;

        foreach ($priorityOrder as $type) {
            $req = (float)($requestedDeductions[$type] ?? 0);
            $canDeduct = min($req, max(0.0, $remainingCap));
            $applied[$type] = round($canDeduct, 2);
            $unapplied[$type] = round($req - $canDeduct, 2);
            $remainingCap = max(0.0, round($remainingCap - $canDeduct, 2));
        }

        $this->assertEquals(15000.0, $applied['tax']);
        $this->assertEquals(10000.0, $applied['pf']);
        $this->assertEquals(5000.0,  $applied['lop']);
        $this->assertEquals(12000.0, $applied['advance']);
        $this->assertEquals(13000.0, $applied['loan'], 'Loan deduction capped to remaining statutory ceiling.');
        $this->assertEquals(0.0,     $applied['other'], 'Other deductions zeroed out due to statutory ceiling.');
        $this->assertEquals(0.0,     $unapplied['lop']);
        $this->assertEquals(2000.0,  $unapplied['loan']);
        $this->assertEquals(8000.0,  $unapplied['other']);

        $totalDeductions = array_sum($applied);
        $this->assertEquals(55000.0, $totalDeductions);
        $netSalary = $gross - $totalDeductions;
        $this->assertEquals(45000.0, $netSalary);
    }

    /**
     * VULN-PAY-04: Loan Amortization Invariant (Zero Mutation in Draft)
     */
    public function testLoanAmortizationStagingInvariants()
    {
        $initialDue = 50000.0;
        $initialPaid = 10000.0;
        $stagedEmi = 5000.0;

        // Draft stage: Staged repayment is created with status = 'pending'
        $stagedRepayment = [
            'loan_id' => 'LOAN-01',
            'amount' => $stagedEmi,
            'status' => 'pending'
        ];

        // Loan live balance must remain unchanged during Draft!
        $liveDueInDraft = $initialDue;
        $livePaidInDraft = $initialPaid;
        $this->assertEquals(50000.0, $liveDueInDraft, 'Live loan due is untouched during Draft generation or adjustment.');
        $this->assertEquals(10000.0, $livePaidInDraft, 'Live loan paid is untouched during Draft generation or adjustment.');
        $this->assertEquals('pending', $stagedRepayment['status']);

        // Finalization stage: Atomically transition status to 'posted' and mutate balance
        $committedDue = round(max(0.0, $liveDueInDraft - $stagedRepayment['amount']), 2);
        $committedPaid = round($livePaidInDraft + $stagedRepayment['amount'], 2);
        $stagedRepayment['status'] = 'posted';

        $this->assertEquals(45000.0, $committedDue, 'Loan due decreased only upon batch finalization.');
        $this->assertEquals(15000.0, $committedPaid, 'Loan paid increased only upon batch finalization.');
        $this->assertEquals('posted', $stagedRepayment['status']);
    }

    /**
     * VULN-PAY-08: Provident Fund Ledger Draft Staging Invariant
     */
    public function testProvidentFundLedgerDraftStagingInvariants()
    {
        $initialPFBalance = 24000.0;
        $monthlyEmployeePF = 2500.0;
        $monthlyEmployerPF = 2500.0;
        $totalMonthlyContribution = $monthlyEmployeePF + $monthlyEmployerPF; // 5000.0

        // Draft batch insertion: status must be 'draft' and running balance unchanged
        $draftEntry = [
            'transaction_type' => 'CONTRIBUTION',
            'employee_contribution' => $monthlyEmployeePF,
            'employer_contribution' => $monthlyEmployerPF,
            'total_contribution' => $totalMonthlyContribution,
            'running_balance' => $initialPFBalance, // Preserved authoritative balance
            'status' => 'draft'
        ];

        $this->assertEquals('draft', $draftEntry['status'], 'PF contribution in draft payroll must have status=draft.');
        $this->assertEquals(24000.0, $draftEntry['running_balance'], 'Draft PF entry must not inflate running balance.');

        // Finalization: Staged drafts transition to 'posted' and running balance increases
        $finalizedEntry = $draftEntry;
        $finalizedEntry['status'] = 'posted';
        $finalizedEntry['running_balance'] = round($initialPFBalance + $totalMonthlyContribution, 2);

        $this->assertEquals('posted', $finalizedEntry['status']);
        $this->assertEquals(29000.0, $finalizedEntry['running_balance'], 'Running balance updates only upon finalization.');
    }

    /**
     * VULN-PAY-18: Strict Tenant Isolation Enforcement
     */
    public function testTenantIsolationStrictVerification()
    {
        $tenantA = 'COMP-AAA';
        $tenantB = 'COMP-BBB';

        // Non-admin user from Tenant A trying to access batch of Tenant B
        $userTenant = $tenantA;
        $targetBatchCompany = $tenantB;

        $isAuthorized = ($userTenant === $targetBatchCompany);
        $this->assertFalse($isAuthorized, 'Cross-tenant access must be forbidden.');

        // Accessing a batch with NULL company_id without Super Admin privileges must be rejected
        $targetBatchNullCompany = null;
        $isAuthorizedNull = !empty($targetBatchNullCompany) && ($userTenant === $targetBatchNullCompany);
        $this->assertFalse($isAuthorizedNull, 'Batch with NULL company_id must not bypass tenant isolation.');
    }

    /**
     * Phase 1 Clean State Verification:
     * Verifies that old overtime calculations are removed and default safely to 0.0.
     */
    public function testPhase1OvertimeCleanStateSafeZero()
    {
        $basicSalary = 30000.0;
        $overtimeHours = 0.0;
        $overtimePay = 0.0;

        $totalEarnings = $basicSalary + $overtimePay;
        $this->assertEquals(0.0, $overtimeHours, "Overtime hours must safely default to 0.0 in Phase 1.");
        $this->assertEquals(0.0, $overtimePay, "Overtime pay must safely default to 0.0 in Phase 1.");
        $this->assertEquals(30000.0, $totalEarnings, "Earnings match base salary with zero overtime.");
    }

    /**
     * Policy-Driven Overtime Test:
     * Verifies that overtime uses dynamic standard_monthly_hours and multiplier from policy
     * and does NOT rely on a hard-coded 208 divisor.
     */
    public function testPolicyDrivenOvertimeCalculationWithoutHardcodedDivisor()
    {
        $basicSalary = 48000.0;
        $standardMonthlyHours = 160.0; // 40h/week * 4
        $otMultiplier = 1.5;
        $otHours = 10.0;

        $hourlyRate = ($basicSalary / $standardMonthlyHours) * $otMultiplier; // (48000 / 160) * 1.5 = 300 * 1.5 = 450
        $otAmount = round($hourlyRate * $otHours, 2); // 4500.00

        $this->assertEquals(450.0, $hourlyRate, "Policy-driven hourly rate calculated correctly.");
        $this->assertEquals(4500.0, $otAmount, "Overtime amount calculated correctly using policy hours.");

        // Compare against old hard-coded 208 divisor to prove distinction
        $oldHourlyRate = ($basicSalary / 208.0) * 1.5;
        $oldOtAmount = round($oldHourlyRate * $otHours, 2);
        $this->assertNotEquals($oldOtAmount, $otAmount, "Policy-driven OT differs correctly from rigid 208 divisor.");
    }

    /**
     * Policy-Driven Provident Fund SSOT Test:
     * Enforces that PF percentage is configured at a single source (Statutory Policy Rule, 7.00%)
     * and applies across the board with NO fallback to employee record rates or any other source.
     */
    public function testProvidentFundSingleSourceAcrossTheBoard()
    {
        $basicSalary = 40000.0;
        $singleSourcePolicyRate = 7.0; // Corporate standard PF policy from single source
        $arbitraryEmployeeRate = 10.0; // Secondary / record rate attempting override

        // The single source figure applies across the board with no fallback
        $appliedRate = $singleSourcePolicyRate;
        $pfDeduction = round($basicSalary * ($appliedRate / 100.0), 2);

        $this->assertEquals(7.0, $appliedRate, "Single source PF policy rate must apply across the board.");
        $this->assertEquals(2800.0, $pfDeduction, "PF deduction matches 7% single source policy with no fallback to employee rates.");
    }

    /**
     * Employer Provident Fund Matching Test:
     * Verifies employer PF contribution equals policy match (7%) and integrates into CTC.
     */
    public function testEmployerProvidentFundPolicyMatching()
    {
        $basicSalary = 40000.0;
        $grossSalary = 65000.0;
        $employerPfRate = 7.0;

        $erPfContribution = round($basicSalary * ($employerPfRate / 100.0), 2); // 2800.00
        $ctc = round($grossSalary + $erPfContribution, 2); // 67800.00

        $this->assertEquals(2800.0, $erPfContribution, "Employer PF matches 7% basic policy.");
        $this->assertEquals(67800.0, $ctc, "CTC incorporates gross salary plus statutory employer PF contribution.");
    }

    /**
     * Test Multiple Salary Advances in the Same Month Recovery:
     * Verifies that when an employee has multiple approved advances scheduled for the same month,
     * all of them are recovered (summed into advance recovery) rather than just the first one.
     */
    public function testMultipleSalaryAdvancesInSameMonthRecovery()
    {
        $advances = [
            [
                'id' => 'ADV-001',
                'amount' => 5000.0,
                'status' => 'Approved',
                'repayment_month' => '2026-07'
            ],
            [
                'id' => 'ADV-002',
                'amount' => 3000.0,
                'status' => 'Approved',
                'repayment_month' => '2026-07'
            ]
        ];

        $targetMonth = '2026-07';
        $monthNameOnly = date('F', strtotime("{$targetMonth}-01"));
        $advanceRecovery = 0.00;
        $advRecords = [];

        foreach ($advances as $adv) {
            $repMonth = (string)($adv['repayment_month'] ?? '');
            if ($adv['status'] === 'Approved' && (
                empty($repMonth) ||
                $repMonth === $targetMonth ||
                stripos($repMonth, $targetMonth) !== false ||
                strcasecmp($repMonth, $monthNameOnly) === 0
            )) {
                $advRecords[] = $adv;
                $advanceRecovery += (float)($adv['amount'] ?? 0.00);
            }
        }
        $advanceRecovery = round($advanceRecovery, 2);

        $this->assertCount(2, $advRecords, "Both advance records should be retained in the array.");
        $this->assertEquals(8000.0, $advanceRecovery, "Total advance recovery must sum all matching approved advances.");
    }

    /**
     * Test that setting fixed_deduction > 0 with calculation_mode='Auto'
     * still produces a full progressive slab breakdown, not a flat tax.
     */
    public function testProgressiveTaxWithFixedDeductionRetainsSlabBreakdown()
    {
        $params = [
            'calculation_mode'         => 'Auto',
            'fixed_deduction'          => 5000.0,
            'fixed_tax_amount'         => 0.0,
            'basic_ratio_pct'          => 60,
            'house_rent_ratio_pct'     => 50,
            'medical_ratio_pct'        => 10,
            'conveyance_monthly'       => 2500,
            'tax_free_limit_yearly'    => 350000,
            'medical_exemption_pct'    => 10,
            'medical_exemption_max'    => 120000,
            'conveyance_exemption_max' => 30000,
            'house_rent_exemption_pct' => 50,
            'house_rent_exemption_max' => 300000,
            'min_tax_amount'           => 5000,
            'rebate_pct'               => 15,
            'rebate_max_taxable_pct'   => 3,
            'gender_applicability'     => 'All',
            'category_thresholds'      => ['General' => 350000],
            'slabs'                    => [
                ['min' => 0, 'max' => 350000, 'rate' => 0, 'label' => 'Tax-Free Threshold'],
                ['min' => 350000, 'max' => 450000, 'rate' => 5, 'label' => 'Next 100k @ 5%'],
                ['min' => 450000, 'max' => 750000, 'rate' => 10, 'label' => 'Next 300k @ 10%'],
                ['min' => 750000, 'max' => null, 'rate' => 15, 'label' => 'Remaining @ 15%'],
            ],
        ];

        $resolvedAuto = new \App\Services\Rules\ResolvedRule('comp-test', 'TAX', '2026-07-01', $params, [
            ['rule_id' => 'rd-test-auto', 'scope_level' => 'Company', 'scope_id' => null, 'version_number' => 1]
        ], []);

        $mockResolver = $this->createMock(\App\Services\Rules\RuleResolver::class);
        $mockResolver->method('resolve')->willReturn($resolvedAuto);

        $calculator = new \App\Services\Tax\TaxCalculator($mockResolver);
        $context = [
            'company_id'     => 'comp-test',
            'effective_date' => '2026-07-01',
            'employee'       => [
                'id'           => 'emp-101',
                'company_id'   => 'comp-test',
                'gender'       => 'Male',
                'tax_category' => 'General',
            ],
        ];

        // Monthly gross = 80,000 => Annual gross = 960,000
        $result = $calculator->calculate(80000.0, $context);

        // Assert: full progressive slab breakdown is preserved
        $this->assertNotEmpty($result['slab_breakdown'], 'Progressive tax with fixed_deduction > 0 and calculation_mode=Auto must produce full slab breakdown.');
        $this->assertGreaterThan(0, count($result['slab_breakdown']), 'There must be active progressive slab tiers in the calculation breakdown.');
        $this->assertNotEquals('Fixed Income Tax Override', $result['rule_name'], 'Rule name must not be Fixed override when mode is Auto.');
        $this->assertNotEquals(5000.0, $result['monthly_tax'], 'Monthly tax should be computed progressively, not set to flat fixed_deduction amount.');

        // Contrast test: calculation_mode = 'Fixed' bypasses progressive calculation and charges flat tax
        $fixedParams = array_merge($params, [
            'calculation_mode' => 'Fixed',
            'fixed_tax_amount' => 3500.0,
            'fixed_deduction'  => 5000.0,
        ]);
        $resolvedFixed = new \App\Services\Rules\ResolvedRule('comp-test', 'TAX', '2026-07-01', $fixedParams, [
            ['rule_id' => 'rd-test-fixed', 'scope_level' => 'Company', 'scope_id' => null, 'version_number' => 1]
        ], []);
        $fixedResolver = $this->createMock(\App\Services\Rules\RuleResolver::class);
        $fixedResolver->method('resolve')->willReturn($resolvedFixed);

        $fixedCalculator = new \App\Services\Tax\TaxCalculator($fixedResolver);
        $fixedResult = $fixedCalculator->calculate(80000.0, $context);

        $this->assertEmpty($fixedResult['slab_breakdown'], 'Fixed mode must not produce slab breakdown.');
        $this->assertEquals('Fixed Income Tax Override', $fixedResult['rule_name']);
        $this->assertEquals(3500.0, $fixedResult['monthly_tax'], 'Fixed mode must charge flat fixed_tax_amount.');
    }

    /**
     * Multi-Month Leave Calculation Test in Payroll:
     * Verifies that unpaid leave spanning across month boundaries is accurately prorated
     * without missing days in subsequent months or double-counting days in the start month.
     */
    public function testMultiMonthUnpaidLeaveProrationAcrossPayrollMonths()
    {
        $payrollService = new \App\Services\PayrollService();

        // Scenario 1: Leave strictly within September (5 days)
        $singleMonthLeave = [
            'start_date'   => '2026-09-10',
            'end_date'     => '2026-09-14',
            'total_days'   => 5.0,
            'unpaid_days'  => 5.0,
            'type_is_paid' => 0,
        ];
        $daysInSep = $payrollService->calculateUnpaidLeaveDaysInMonth($singleMonthLeave, '2026-09-01', '2026-09-30');
        $daysInOct = $payrollService->calculateUnpaidLeaveDaysInMonth($singleMonthLeave, '2026-10-01', '2026-10-31');
        $this->assertEquals(5.0, $daysInSep, "Single-month leave must allocate 100% of days to September.");
        $this->assertEquals(0.0, $daysInOct, "Single-month September leave must allocate 0 days to October.");

        // Scenario 2: Unpaid leave spanning across September and October (10 calendar days: Sep 25 to Oct 04)
        $spanningLeave = [
            'start_date'   => '2026-09-25',
            'end_date'     => '2026-10-04',
            'total_days'   => 10.0,
            'unpaid_days'  => 10.0,
            'type_is_paid' => 0,
        ];
        // September has 6 days: Sep 25, 26, 27, 28, 29, 30
        $sepProrated = $payrollService->calculateUnpaidLeaveDaysInMonth($spanningLeave, '2026-09-01', '2026-09-30');
        // October has 4 days: Oct 01, 02, 03, 04
        $octProrated = $payrollService->calculateUnpaidLeaveDaysInMonth($spanningLeave, '2026-10-01', '2026-10-31');
        // November has 0 days
        $novProrated = $payrollService->calculateUnpaidLeaveDaysInMonth($spanningLeave, '2026-11-01', '2026-11-30');

        $this->assertEquals(6.0, $sepProrated, "September portion of spanning leave must be exactly 6 days.");
        $this->assertEquals(4.0, $octProrated, "October portion of spanning leave must be exactly 4 days.");
        $this->assertEquals(0.0, $novProrated, "November portion must be 0 days.");
        $this->assertEquals(10.0, $sepProrated + $octProrated, "Total across months must equal 10.0 days with zero leakage.");
    }

    public function testPartiallyPaidLeaveDeductionInPayroll()
    {
        $payrollService = new \App\Services\PayrollService();

        // 1. Single month partially paid leave (4 days @ 50% paid via type_paid_percentage)
        $halfPayLeave = [
            'start_date'           => '2026-09-10',
            'end_date'             => '2026-09-13',
            'total_days'           => 4.0,
            'type_is_paid'         => 1,
            'type_paid_percentage' => 50,
        ];
        $daysInSep = $payrollService->calculateUnpaidLeaveDaysInMonth($halfPayLeave, '2026-09-01', '2026-09-30');
        $this->assertEquals(2.0, $daysInSep, "Half-pay leave of 4 days must yield 2.0 unpaid loss-of-pay days.");

        // 2. Multi-month partially paid leave (10 calendar days @ 50% paid: 6 in Sep, 4 in Oct)
        $spanningHalfPay = [
            'start_date'           => '2026-09-25',
            'end_date'             => '2026-10-04',
            'total_days'           => 10.0,
            'type_is_paid'         => 1,
            'type_paid_percentage' => 50,
        ];
        $sepProrated = $payrollService->calculateUnpaidLeaveDaysInMonth($spanningHalfPay, '2026-09-01', '2026-09-30');
        $octProrated = $payrollService->calculateUnpaidLeaveDaysInMonth($spanningHalfPay, '2026-10-01', '2026-10-31');
        $this->assertEquals(3.0, $sepProrated, "September portion of 5.0 total unpaid days must be 3.0 days.");
        $this->assertEquals(2.0, $octProrated, "October portion of 5.0 total unpaid days must be 2.0 days.");
        $this->assertEquals(5.0, $sepProrated + $octProrated, "Total unpaid across months must equal 5.0 days.");
    }
}

