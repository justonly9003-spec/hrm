<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

/**
 * MobileWeekendApiTest
 *
 * Verifies mobile API endpoints for Weekly Holidays / Weekends:
 * - GET /api/mobile/v1/leaves/weekly-holidays
 * - GET /api/mobile/v1/weekends
 * - GET /api/mobile/v1/holidays/weekly
 * - GET /api/v1/leaves/weekly-holidays
 * - GET /api/v1/weekends
 * - GET /api/v1/holidays/weekly
 *
 * Validates:
 * 1. Unauthenticated requests return 401.
 * 2. Authenticated requests return configured weekly off days, working days, and details.
 * 3. Specific date check (?date=YYYY-MM-DD) returns is_weekly_off and day_of_week.
 * 4. Date range filtering (?from=YYYY-MM-DD&to=YYYY-MM-DD) returns dates array, total, from, to.
 * 5. Month filtering (?month=YYYY-MM) returns dates array for that month.
 * 6. Dual-route aliases work identically.
 */
#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobileWeekendApiTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;
    private array $device = ['device_uid' => 'dev-weekend-test', 'platform' => 'android'];

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);

        // Ensure rule_definitions table exists for RuleResolver
        $this->db->query("CREATE TABLE IF NOT EXISTS rule_definitions (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36) NOT NULL,
            domain VARCHAR(30) NOT NULL,
            scope_level VARCHAR(30) DEFAULT 'Company',
            scope_id VARCHAR(36) NULL,
            version_number INT NOT NULL,
            effective_from DATE NOT NULL,
            effective_to DATE NULL,
            status VARCHAR(30) DEFAULT 'Active',
            params_json LONGTEXT NOT NULL,
            schema_version INT DEFAULT 1,
            change_reason TEXT NULL,
            created_by VARCHAR(36) NULL,
            approved_by VARCHAR(36) NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        // Seed rule for c-1: Friday and Saturday as weekly off
        $this->db->table('rule_definitions')->insert([
            'id'             => 'rd-att-c1',
            'company_id'     => 'c-1',
            'domain'         => 'ATTENDANCE',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2020-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'weekly_off_days' => ['Friday', 'Saturday'],
                'work_days'       => ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday'],
            ]),
            'schema_version' => 1,
            'created_at'     => date('Y-m-d H:i:s'),
        ]);

        \App\Services\CompanyWeekendService::clearCache('c-1');
    }

    private function token(string $company = 'ACME', string $identifier = 'rahim'): array
    {
        $res = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => $company,
            'identifier'   => $identifier,
            'password'     => self::PASSWORD,
            'device'       => $this->device,
        ]);
        $res->assertStatus(200);
        $json = json_decode($res->getJSON(), true);
        return ['Authorization' => 'Bearer ' . $json['data']['tokens']['access_token']];
    }

    private function json($res): array
    {
        return json_decode($res->getJSON(), true);
    }

    public function testUnauthenticatedRequestReturns401(): void
    {
        $res = $this->get('api/mobile/v1/leaves/weekly-holidays');
        $res->assertStatus(401);
        $data = $this->json($res);
        $this->assertFalse($data['success']);
    }

    public function testAuthenticatedReturnsWeeklyHolidays(): void
    {
        $h = $this->token('ACME', 'rahim');
        $res = $this->withHeaders($h)->get('api/mobile/v1/leaves/weekly-holidays');
        $res->assertStatus(200);
        $data = $this->json($res);

        $this->assertTrue($data['success']);
        $this->assertSame('Weekly holidays retrieved successfully.', $data['message']);
        $this->assertIsArray($data['data']['weekly_off_days']);
        $this->assertContains('Friday', $data['data']['weekly_off_days']);
        $this->assertContains('Saturday', $data['data']['weekly_off_days']);
        $this->assertContains('Sunday', $data['data']['working_days']);
        $this->assertArrayHasKey('details', $data['data']);
    }

    public function testSpecificDateCheck(): void
    {
        $h = $this->token('ACME', 'rahim');
        // 2026-11-06 is Friday (weekend)
        $res = $this->withHeaders($h)->get('api/mobile/v1/leaves/weekly-holidays?date=2026-11-06');
        $res->assertStatus(200);
        $data = $this->json($res)['data'];

        $this->assertSame('2026-11-06', $data['date']);
        $this->assertSame('Friday', $data['day_of_week']);
        $this->assertTrue($data['is_weekly_off']);

        // 2026-11-08 is Sunday (working day)
        $res2 = $this->withHeaders($h)->get('api/mobile/v1/leaves/weekly-holidays?date=2026-11-08');
        $res2->assertStatus(200);
        $data2 = $this->json($res2)['data'];

        $this->assertSame('2026-11-08', $data2['date']);
        $this->assertSame('Sunday', $data2['day_of_week']);
        $this->assertFalse($data2['is_weekly_off']);
    }

    public function testDateRangeWeekendDatesEnumeration(): void
    {
        $h = $this->token('ACME', 'rahim');
        // 2026-11-01 to 2026-11-15
        $res = $this->withHeaders($h)->get('api/mobile/v1/leaves/weekly-holidays?from=2026-11-01&to=2026-11-15');
        $res->assertStatus(200);
        $data = $this->json($res)['data'];

        $this->assertSame('2026-11-01', $data['from']);
        $this->assertSame('2026-11-15', $data['to']);
        $this->assertIsArray($data['dates']);
        // Nov 6 (Fri), Nov 7 (Sat), Nov 13 (Fri), Nov 14 (Sat)
        $this->assertContains('2026-11-06', $data['dates']);
        $this->assertContains('2026-11-07', $data['dates']);
        $this->assertContains('2026-11-13', $data['dates']);
        $this->assertContains('2026-11-14', $data['dates']);
        $this->assertGreaterThanOrEqual(4, $data['total']);
    }

    public function testMonthFilter(): void
    {
        $h = $this->token('ACME', 'rahim');
        $res = $this->withHeaders($h)->get('api/mobile/v1/leaves/weekly-holidays?month=2026-11');
        $res->assertStatus(200);
        $data = $this->json($res)['data'];

        $this->assertSame('2026-11-01', $data['from']);
        $this->assertSame('2026-11-30', $data['to']);
        $this->assertIsArray($data['dates']);
        $this->assertNotEmpty($data['dates']);
    }

    public function testCombinedCalendarPayloadHasBothHolidaysAndWeekends(): void
    {
        $h = $this->token('ACME', 'rahim');
        $res = $this->withHeaders($h)->get('api/mobile/v1/weekends?month=2026-11');
        $res->assertStatus(200);
        $data = $this->json($res)['data'];

        // Weekends payload must contain weekend aliases
        $this->assertArrayHasKey('weekends', $data);
        $this->assertArrayHasKey('weekly_off', $data);
        $this->assertArrayHasKey('dates', $data);
        $this->assertArrayHasKey('weekend_dates', $data);
        $this->assertArrayHasKey('working_days', $data);

        // Weekends payload must also contain public holiday attachments for calendar views
        $this->assertArrayHasKey('holidays', $data);
        $this->assertArrayHasKey('public_holidays', $data);
        $this->assertArrayHasKey('holiday_dates', $data);
    }

    public function testRouteAliasesParity(): void
    {
        $h = $this->token('ACME', 'rahim');

        $endpoints = [
            'api/mobile/v1/leaves/weekly-holidays',
            'api/mobile/v1/leave/weekly-holidays',
            'api/mobile/v1/holidays/weekly',
            'api/mobile/v1/weekends',
            'api/mobile/v1/weekend',
            'api/mobile/v1/weekly-holidays',
            'api/mobile/v1/weekly-off',
            'api/mobile/v1/attendance/weekends',
            'api/mobile/v1/shifts/weekends',
            'api/v1/leaves/weekly-holidays',
            'api/v1/leave/weekly-holidays',
            'api/v1/holidays/weekly',
            'api/v1/weekends',
            'api/v1/weekend',
            'api/v1/weekly-holidays',
            'api/v1/weekly-off',
            'api/v1/attendance/weekends',
            'api/v1/shifts/weekends',
        ];

        foreach ($endpoints as $ep) {
            $res = $this->withHeaders($h)->get($ep);
            $this->assertSame(200, $res->response()->getStatusCode(), "Endpoint {$ep} must return 200");
            $json = $this->json($res);
            $this->assertTrue($json['success']);
            $this->assertContains('Friday', $json['data']['weekly_off_days']);
            $this->assertContains('Friday', $json['data']['weekends']);
        }
    }
}

