<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class MobileApiWiringTest extends TestCase
{
    private function src(string $relativePath): string
    {
        $base = dirname(__DIR__, 2);
        $full = $base . '/' . ltrim($relativePath, '/');
        $this->assertFileExists($full);
        return (string)file_get_contents($full);
    }

    public function testAuthRoutesAreRegistered(): void
    {
        $r = $this->src('app/Config/Routes.php');
        $this->assertStringContainsString("api/mobile/v1", $r);
        $this->assertStringContainsString("auth/login", $r);
        $this->assertStringContainsString("auth/refresh", $r);
        $this->assertMatchesRegularExpression("/auth\/logout'.*'filter' => 'mobileAuth'/", $r);
        $this->assertMatchesRegularExpression("/auth\/me'.*'filter' => 'mobileAuth'/", $r);
    }

    public function testEveryPhase3RouteIsBehindMobileAuth(): void
    {
        $r = $this->src('app/Config/Routes.php');
        foreach (['profile', 'attendance/today', 'attendance/history', 'attendance/summary', 'attendance/check-in', 'attendance/check-out',
                  'payslips', 'payslips/(:segment)', 'pf/summary', 'pf/ledger', 'notifications',
                  'documents', 'documents/(:segment)', 'documents/(:segment)/download',
                  'notices', 'notices/(:segment)',
                  'directory', 'directory/(:segment)',
                  'leaves/types', 'leaves/balances', 'leaves/applications', 'leaves/applications/(:segment)', 'leaves/holidays', 'leaves/(:segment)', 'leaves/apply', 'leaves/(:segment)/cancel', 'holidays'] as $path) {
            $this->assertMatchesRegularExpression('#\\$routes->(get|post)\\(\'' . preg_quote($path, '#') . '\'[^\\n]*\'filter\' => \'mobileAuth\'#', $r, "Route {$path} must use mobileAuth");
        }
    }

    public function testMobileControllersNeverTrustClientIdentity(): void
    {
        foreach (['Dashboard', 'Attendance', 'Leave', 'Profile', 'Payslip', 'Pf', 'Notification', 'Document', 'Notice', 'Overtime', 'Directory'] as $c) {
            $src = $this->src("app/Controllers/Mobile/Mobile{$c}Controller.php");
            $this->assertStringNotContainsString("getPost('employee_id')", $src);
            $this->assertStringNotContainsString("getGet('employee_id')", $src);
            $this->assertStringNotContainsString("getGet('company_id')", $src);
        }
    }

    public function testCsrfExemptionAliasAndCors(): void
    {
        $f = $this->src('app/Config/Filters.php');
        $this->assertStringContainsString("'api/mobile/*'", $f);
        $this->assertStringContainsString("'api/v1/auth/*'", $f);
        $this->assertStringContainsString("'api/v1/attendance/*'", $f);
        $this->assertStringContainsString("'api/v1/leave/*'", $f);
        $this->assertStringContainsString("'api/v1/overtime/*'", $f);
        $this->assertStringContainsString("'api/v1/notifications/*'", $f);

        // Blanket api/v1/* must NEVER be exempted
        $this->assertDoesNotMatchRegularExpression("/'api\\/v1\\/\\*\\s*'/", $f);

        $this->assertStringContainsString("'mobileAuth'    => MobileAuthFilter::class", $f);

        $cors = $this->src('app/Filters/CorsFilter.php');
        $this->assertStringContainsString("PATCH", $cors);
    }

    public function testApiV1ExemptedRoutesAreBehindMobileAuthExceptLoginAndRefresh(): void
    {
        $r = $this->src('app/Config/Routes.php');

        // Public auth endpoints
        $this->assertMatchesRegularExpression("/post\\('auth\\/login',\\s*'MobileAuthController::login'\\)/", $r);
        $this->assertMatchesRegularExpression("/post\\('auth\\/refresh',\\s*'MobileAuthController::refresh'\\)/", $r);

        // Every other exempted route must have mobileAuth filter
        $guardedRoutes = [
            'auth/logout',
            'attendance/check-in',
            'attendance/check-out',
            'leave/apply',
            'leave/(:segment)/cancel',
            'overtime/claims',
            'notifications/read-all',
            'notifications/(:segment)/read',
        ];

        foreach ($guardedRoutes as $path) {
            $pattern = '#\\$routes->post\\(\'' . preg_quote($path, '#') . '\'[^\\n]*\'filter\' => \'mobileAuth\'#';
            $this->assertMatchesRegularExpression($pattern, $r, "Route {$path} must use mobileAuth filter");
        }
    }
}
