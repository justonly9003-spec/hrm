<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use App\Controllers\Employee\EmployeeController;
use App\Models\EmployeeModel;
use Config\Database;
use CodeIgniter\HTTP\Files\UploadedFile;
use CodeIgniter\HTTP\Files\FileCollection;

/**
 * MockUploadedFile for testing server-side upload validations
 */
class TestBulkUploadFile extends UploadedFile
{
    private bool $mockValid = true;
    private bool $mockHasMoved = false;
    private ?int $mockSize = null;
    private ?string $mockExtension = null;
    private ?string $mockMime = null;
    private ?string $mockClientExtension = null;

    public function setMockClientExtension(string $e): self
    {
        $this->mockClientExtension = $e;
        return $this;
    }

    public function getClientExtension(): string
    {
        return $this->mockClientExtension ?? parent::getClientExtension();
    }

    public function setMockValid(bool $v): self
    {
        $this->mockValid = $v;
        return $this;
    }

    public function setMockHasMoved(bool $v): self
    {
        $this->mockHasMoved = $v;
        return $this;
    }

    public function setMockSize(int $s): self
    {
        $this->mockSize = $s;
        return $this;
    }

    public function setMockExtension(string $e): self
    {
        $this->mockExtension = $e;
        return $this;
    }

    public function setMockMime(string $m): self
    {
        $this->mockMime = $m;
        return $this;
    }

    public function isValid(): bool
    {
        return $this->mockValid;
    }

    public function hasMoved(): bool
    {
        return $this->mockHasMoved;
    }

    public function getSize(): int
    {
        return $this->mockSize ?? parent::getSize();
    }

    public function getExtension(): string
    {
        return $this->mockExtension ?? parent::getExtension();
    }

    public function getMimeType(): string
    {
        return $this->mockMime ?? parent::getMimeType();
    }
}

/**
 * Real DB-backed unit tests for Employee bulkUpload():
 * 1. A .php file renamed to .csv is rejected with 422.
 * 2. A file over 2 MB is rejected with 422.
 * 3. An unsupported extension is rejected with 422.
 * 4. A row with a taken code fails only that row with "Employee code not available"
 *    and does not disclose owner, while other rows still import.
 * 5. A row with a blank code gets an auto-generated code.
 * 6. A valid CSV imports successfully.
 */
class EmployeeBulkUploadValidationTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected static bool $schemaInitialized = false;

    protected string $tenantCompanyId  = 'comp-bulk-test-01';
    protected string $otherCompanyId   = 'comp-bulk-other-02';
    protected string $tenantBranchId   = 'branch-bulk-test-01';
    protected string $tenantDeptId     = 'dept-bulk-test-01';
    protected string $tenantDesgId     = 'desg-bulk-test-01';
    protected string $tenantEmpTypeId  = 'emptype-bulk-test-01';
    protected string $tenantShiftId    = 'shift-bulk-test-01';
    protected string $tenantRoleId     = 'role-bulk-emp-01';

    protected array $adminUser = [];
    protected array $tempFiles = [];

    public static function setUpBeforeClass(): void
    {
        parent::setUpBeforeClass();
        static::ensureSchema();
    }

    public static function registerSqliteFunctions($db): void
    {
        try {
            $rawConn = $db->connID ?? null;
            if ($rawConn instanceof \SQLite3) {
                $rawConn->createFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->createFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            } elseif (is_object($rawConn) && method_exists($rawConn, 'sqliteCreateFunction')) {
                $rawConn->sqliteCreateFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->sqliteCreateFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            }
        } catch (\Throwable $e) {
            // ignore
        }
    }

    protected static function ensureSchema(): void
    {
        $db = Database::connect();
        static::registerSqliteFunctions($db);

        $schemaFile = __DIR__ . '/Rules/schema.sqlite.sql';
        if (file_exists($schemaFile)) {
            $sql = file_get_contents($schemaFile);
            $statements = array_filter(array_map('trim', explode(';', $sql)));
            foreach ($statements as $stmt) {
                if (!empty($stmt)) {
                    try {
                        $db->query($stmt);
                    } catch (\Throwable $e) {
                        // ignore
                    }
                }
            }
        }
    }

    protected function setUp(): void
    {
        parent::setUp();
        static::ensureSchema();

        $db = Database::connect();
        static::registerSqliteFunctions($db);

        // Seed companies
        $db->table('companies')->replace([
            'id'     => $this->tenantCompanyId,
            'name'   => 'Bulk Test Primary Company',
            'code'   => 'COMP-BULK-1',
            'status' => 'Active',
        ]);
        $db->table('companies')->replace([
            'id'     => $this->otherCompanyId,
            'name'   => 'Bulk Test Other Company',
            'code'   => 'COMP-BULK-2',
            'status' => 'Active',
        ]);

        // Seed branch, department, designation, employment type, shift
        $db->table('branches')->replace([
            'id'         => $this->tenantBranchId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'HQ Branch',
            'code'       => 'BR-HQ',
            'status'     => 'Active',
        ]);

        $db->table('departments')->replace([
            'id'         => $this->tenantDeptId,
            'company_id' => $this->tenantCompanyId,
            'branch_id'  => $this->tenantBranchId,
            'name'       => 'Engineering',
            'code'       => 'ENG',
            'status'     => 'Active',
        ]);

        $db->table('designations')->replace([
            'id'            => $this->tenantDesgId,
            'company_id'    => $this->tenantCompanyId,
            'department_id' => $this->tenantDeptId,
            'name'          => 'Software Engineer',
            'code'          => 'SWE',
            'status'        => 'Active',
        ]);

        $db->table('employment_types')->replace([
            'id'         => $this->tenantEmpTypeId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'Permanent',
            'code'       => 'PERM',
            'status'     => 'Active',
        ]);

        $db->table('shifts')->replace([
            'id'         => $this->tenantShiftId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'Regular Shift',
            'start_time' => '09:00:00',
            'end_time'   => '17:00:00',
            'status'     => 'Active',
        ]);

        // Seed employee role
        $db->table('roles')->replace([
            'id'         => $this->tenantRoleId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'Employee',
            'code'       => 'employee',
            'status'     => 'Active',
        ]);

        // Seed company admin user
        $this->adminUser = [
            'id'                  => 'usr-bulk-admin-01',
            'company_id'          => $this->tenantCompanyId,
            'username'            => 'bulk_admin',
            'name'                => 'Bulk Admin',
            'email'               => 'bulk_admin@test.com',
            'role'                => 'Company Admin',
            'role_code'           => 'company_admin',
            'role_id'             => 'role-bulk-admin',
            'selected_company_id' => $this->tenantCompanyId,
            'permissions'         => ['*'],
        ];

        $db->table('users')->replace([
            'id'            => $this->adminUser['id'],
            'company_id'    => $this->tenantCompanyId,
            'username'      => $this->adminUser['username'],
            'email'         => $this->adminUser['email'],
            'password_hash' => password_hash('Secret123!', PASSWORD_BCRYPT),
            'role_id'       => $this->adminUser['role_id'],
            'status'        => 'Active',
        ]);
    }

    protected function tearDown(): void
    {
        foreach ($this->tempFiles as $f) {
            if (file_exists($f)) {
                @unlink($f);
            }
        }
        $this->tempFiles = [];
        parent::tearDown();
    }

    protected function createTempFile(string $content, string $suffix = '.tmp'): string
    {
        $filePath = tempnam(sys_get_temp_dir(), 'bulkupload_') . $suffix;
        file_put_contents($filePath, $content);
        $this->tempFiles[] = $filePath;
        return $filePath;
    }

    protected function createSmallXlsxFile(string $empName, string $empEmail, string $empCode): string
    {
        $filePath = tempnam(sys_get_temp_dir(), 'bulkupload_') . '.xlsx';
        $this->tempFiles[] = $filePath;

        $zip = new \ZipArchive();
        $zip->open($filePath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);

        $contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            . '<Default Extension="xml" ContentType="application/xml"/>'
            . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            . '<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>'
            . '</Types>';
        $zip->addFromString('[Content_Types].xml', $contentTypes);

        $rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            . '</Relationships>';
        $zip->addFromString('_rels/.rels', $rels);

        $workbook = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets>'
            . '</workbook>';
        $zip->addFromString('xl/workbook.xml', $workbook);

        $sharedStrings = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="6" uniqueCount="6">'
            . '<si><t>Name</t></si>'
            . '<si><t>Email</t></si>'
            . '<si><t>Employee Code</t></si>'
            . '<si><t>' . htmlspecialchars($empName, ENT_XML1) . '</t></si>'
            . '<si><t>' . htmlspecialchars($empEmail, ENT_XML1) . '</t></si>'
            . '<si><t>' . htmlspecialchars($empCode, ENT_XML1) . '</t></si>'
            . '</sst>';
        $zip->addFromString('xl/sharedStrings.xml', $sharedStrings);

        $sheet1 = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<sheetData>'
            . '<row r="1">'
            . '<c r="A1" t="s"><v>0</v></c>'
            . '<c r="B1" t="s"><v>1</v></c>'
            . '<c r="C1" t="s"><v>2</v></c>'
            . '</row>'
            . '<row r="2">'
            . '<c r="A2" t="s"><v>3</v></c>'
            . '<c r="B2" t="s"><v>4</v></c>'
            . '<c r="C2" t="s"><v>5</v></c>'
            . '</row>'
            . '</sheetData>'
            . '</worksheet>';
        $zip->addFromString('xl/worksheets/sheet1.xml', $sheet1);

        $zip->close();
        return $filePath;
    }

    protected function createZipWithoutContentTypes(string $suffix = '.xlsx'): string
    {
        $filePath = tempnam(sys_get_temp_dir(), 'bulkupload_') . $suffix;
        $this->tempFiles[] = $filePath;

        $zip = new \ZipArchive();
        $zip->open($filePath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);
        $zip->addFromString('dummy.txt', 'This is just a regular zip file, not an OpenXML spreadsheet.');
        $zip->close();

        return $filePath;
    }

    protected function createZipWithOversizedSheet(): string
    {
        $filePath = tempnam(sys_get_temp_dir(), 'bulkupload_') . '.xlsx';
        $this->tempFiles[] = $filePath;

        $zip = new \ZipArchive();
        $zip->open($filePath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);

        $contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            . '<Default Extension="xml" ContentType="application/xml"/>'
            . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            . '</Types>';
        $zip->addFromString('[Content_Types].xml', $contentTypes);

        $workbook = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets>'
            . '</workbook>';
        $zip->addFromString('xl/workbook.xml', $workbook);

        // 5.2 MB of XML (exceeding 5 MB limit)
        $padding = str_repeat('<!-- padding content -->', 220000);
        $sheetXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . $padding
            . '<sheetData></sheetData>'
            . '</worksheet>';
        $zip->addFromString('xl/worksheets/sheet1.xml', $sheetXml);
        $zip->close();

        return $filePath;
    }

    protected function createZipWithDoctype(): string
    {
        $filePath = tempnam(sys_get_temp_dir(), 'bulkupload_') . '.xlsx';
        $this->tempFiles[] = $filePath;

        $zip = new \ZipArchive();
        $zip->open($filePath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);

        $contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            . '<Default Extension="xml" ContentType="application/xml"/>'
            . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            . '</Types>';
        $zip->addFromString('[Content_Types].xml', $contentTypes);

        $workbook = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets>'
            . '</workbook>';
        $zip->addFromString('xl/workbook.xml', $workbook);

        $sheetXml = '<?xml version="1.0" encoding="UTF-8"?>'
            . '<!DOCTYPE worksheet [ <!ENTITY test "xxe"> ]>'
            . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<sheetData></sheetData>'
            . '</worksheet>';
        $zip->addFromString('xl/worksheets/sheet1.xml', $sheetXml);
        $zip->close();

        return $filePath;
    }

    protected function createXlsxWithDateSerial(string $empName, string $empEmail, string $empCode, string $dob, int $joinDateSerial): string
    {
        $filePath = tempnam(sys_get_temp_dir(), 'bulkupload_') . '.xlsx';
        $this->tempFiles[] = $filePath;

        $zip = new \ZipArchive();
        $zip->open($filePath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);

        $contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            . '<Default Extension="xml" ContentType="application/xml"/>'
            . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            . '<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>'
            . '</Types>';
        $zip->addFromString('[Content_Types].xml', $contentTypes);

        $workbook = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets>'
            . '</workbook>';
        $zip->addFromString('xl/workbook.xml', $workbook);

        $headers = ['Name', 'Email', 'Employee Code', 'Department', 'Designation', 'Gender', 'DOB', 'Join Date'];
        $values  = [$empName, $empEmail, $empCode, 'Engineering', 'Software Engineer', 'male', $dob];

        $strings = array_merge($headers, $values);
        $sstXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="' . count($strings) . '" uniqueCount="' . count($strings) . '">';
        foreach ($strings as $s) {
            $sstXml .= '<si><t>' . htmlspecialchars($s, ENT_XML1) . '</t></si>';
        }
        $sstXml .= '</sst>';
        $zip->addFromString('xl/sharedStrings.xml', $sstXml);

        $sheetXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<sheetData>'
            . '<row r="1">'
            . '<c r="A1" t="s"><v>0</v></c>'
            . '<c r="B1" t="s"><v>1</v></c>'
            . '<c r="C1" t="s"><v>2</v></c>'
            . '<c r="D1" t="s"><v>3</v></c>'
            . '<c r="E1" t="s"><v>4</v></c>'
            . '<c r="F1" t="s"><v>5</v></c>'
            . '<c r="G1" t="s"><v>6</v></c>'
            . '<c r="H1" t="s"><v>7</v></c>'
            . '</row>'
            . '<row r="2">'
            . '<c r="A2" t="s"><v>8</v></c>'
            . '<c r="B2" t="s"><v>9</v></c>'
            . '<c r="C2" t="s"><v>10</v></c>'
            . '<c r="D2" t="s"><v>11</v></c>'
            . '<c r="E2" t="s"><v>12</v></c>'
            . '<c r="F2" t="s"><v>13</v></c>'
            . '<c r="G2" t="s"><v>14</v></c>'
            . '<c r="H2"><v>' . $joinDateSerial . '</v></c>'
            . '</row>'
            . '</sheetData>'
            . '</worksheet>';
        $zip->addFromString('xl/worksheets/sheet1.xml', $sheetXml);
        $zip->close();

        return $filePath;
    }

    protected function createXlsxWithCustomFirstSheet(string $empName, string $empEmail, string $empCode): string
    {
        $filePath = tempnam(sys_get_temp_dir(), 'bulkupload_') . '.xlsx';
        $this->tempFiles[] = $filePath;

        $zip = new \ZipArchive();
        $zip->open($filePath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);

        $contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            . '<Default Extension="xml" ContentType="application/xml"/>'
            . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . '<Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            . '<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>'
            . '</Types>';
        $zip->addFromString('[Content_Types].xml', $contentTypes);

        $workbook = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<sheets><sheet name="CustomFirst" sheetId="2" r:id="rId99"/></sheets>'
            . '</workbook>';
        $zip->addFromString('xl/workbook.xml', $workbook);

        $rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId99" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/>'
            . '</Relationships>';
        $zip->addFromString('xl/_rels/workbook.xml.rels', $rels);

        $strings = ['Name', 'Email', 'Employee Code', 'Department', 'Designation', 'Gender', 'DOB', $empName, $empEmail, $empCode, 'Engineering', 'Software Engineer', 'male', '1991-01-01'];
        $sstXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="' . count($strings) . '" uniqueCount="' . count($strings) . '">';
        foreach ($strings as $s) {
            $sstXml .= '<si><t>' . htmlspecialchars($s, ENT_XML1) . '</t></si>';
        }
        $sstXml .= '</sst>';
        $zip->addFromString('xl/sharedStrings.xml', $sstXml);

        $sheet2 = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<sheetData>'
            . '<row r="1">'
            . '<c r="A1" t="s"><v>0</v></c>'
            . '<c r="B1" t="s"><v>1</v></c>'
            . '<c r="C1" t="s"><v>2</v></c>'
            . '<c r="D1" t="s"><v>3</v></c>'
            . '<c r="E1" t="s"><v>4</v></c>'
            . '<c r="F1" t="s"><v>5</v></c>'
            . '<c r="G1" t="s"><v>6</v></c>'
            . '</row>'
            . '<row r="2">'
            . '<c r="A2" t="s"><v>7</v></c>'
            . '<c r="B2" t="s"><v>8</v></c>'
            . '<c r="C2" t="s"><v>9</v></c>'
            . '<c r="D2" t="s"><v>10</v></c>'
            . '<c r="E2" t="s"><v>11</v></c>'
            . '<c r="F2" t="s"><v>12</v></c>'
            . '<c r="G2" t="s"><v>13</v></c>'
            . '</row>'
            . '</sheetData>'
            . '</worksheet>';
        $zip->addFromString('xl/worksheets/sheet2.xml', $sheet2);
        $zip->close();

        return $filePath;
    }

    protected function setupController(?TestBulkUploadFile $uploadedFile = null, array $jsonPayload = []): EmployeeController
    {
        \App\Services\PermissionService::clearCache();
        \App\Services\PermissionService::flushCache();

        $session = \Config\Services::session();
        $session->set([
            'id'                  => $this->adminUser['id'],
            'user_id'             => $this->adminUser['id'],
            'username'            => $this->adminUser['username'],
            'name'                => $this->adminUser['name'],
            'email'               => $this->adminUser['email'],
            'role'                => $this->adminUser['role'],
            'role_code'           => $this->adminUser['role_code'],
            'role_id'             => $this->adminUser['role_id'],
            'company_id'          => $this->adminUser['company_id'],
            'selected_company_id' => $this->adminUser['company_id'],
            'permissions'         => ['*'],
        ]);

        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_SERVER['HTTP_ACCEPT'] = 'application/json';
        $_SERVER['HTTP_X_REQUESTED_WITH'] = 'xmlhttprequest';
        $_POST = [];
        $_FILES = [];

        $request = \Config\Services::request();
        $response = \Config\Services::response();
        $logger = \Config\Services::logger();

        if ($uploadedFile !== null) {
            $_FILES['file'] = [
                'name'     => $uploadedFile->getClientName(),
                'type'     => $uploadedFile->getClientMimeType(),
                'tmp_name' => $uploadedFile->getTempName(),
                'error'    => $uploadedFile->getError(),
                'size'     => $uploadedFile->getSize(),
            ];

            $fileCollection = new FileCollection();
            $refFilesColl = new \ReflectionProperty($fileCollection, 'files');
            $refFilesColl->setAccessible(true);
            $refFilesColl->setValue($fileCollection, ['file' => $uploadedFile]);

            $refReqFiles = new \ReflectionProperty($request, 'files');
            $refReqFiles->setAccessible(true);
            $refReqFiles->setValue($request, $fileCollection);
        } else {
            // No file uploaded
            $refReqFiles = new \ReflectionProperty($request, 'files');
            $refReqFiles->setAccessible(true);
            $refReqFiles->setValue($request, null);
        }

        if (!empty($jsonPayload)) {
            $rawJson = json_encode($jsonPayload);
            $refBody = new \ReflectionProperty($request, 'body');
            $refBody->setAccessible(true);
            $refBody->setValue($request, $rawJson);
        } else {
            $refBody = new \ReflectionProperty($request, 'body');
            $refBody->setAccessible(true);
            $refBody->setValue($request, '');
        }

        $controller = new EmployeeController();
        $controller->initController($request, $response, $logger);

        $refUser = new \ReflectionProperty(\App\Controllers\BaseController::class, 'currentUser');
        $refUser->setAccessible(true);
        $refUser->setValue($controller, $this->adminUser);

        return $controller;
    }

    /**
     * Test 1: A .php file renamed to .csv is rejected with 422
     */
    public function testPhpFileRenamedToCsvIsRejectedWith422(): void
    {
        $phpCode = '<?php echo "malicious executable script"; phpinfo(); ?>';
        $filePath = $this->createTempFile($phpCode, '.csv');

        $uploadedFile = new TestBulkUploadFile($filePath, 'malicious.csv', 'text/x-php', strlen($phpCode), UPLOAD_ERR_OK);
        $uploadedFile->setMockValid(true);
        $uploadedFile->setMockExtension('php');
        $uploadedFile->setMockMime('text/x-php');

        $controller = $this->setupController($uploadedFile);
        $response = $controller->bulkUpload();

        $this->assertEquals(422, $response->getStatusCode(), 'Expected HTTP 422 when uploading .php file renamed to .csv');
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success'] ?? true);
        $this->assertStringContainsString('csv', strtolower($body['message']));
    }

    /**
     * Test 2: A file over 2 MB is rejected with 422
     */
    public function testFileOver2MbIsRejectedWith422(): void
    {
        $content = "name,email,gender,dob\nTest Over,test@over.com,male,1990-01-01\n";
        $filePath = $this->createTempFile($content, '.csv');

        $oversizedBytes = 2 * 1024 * 1024 + 1024; // 2 MB + 1 KB
        $uploadedFile = new TestBulkUploadFile($filePath, 'large_import.csv', 'text/csv', $oversizedBytes, UPLOAD_ERR_OK);
        $uploadedFile->setMockValid(true);
        $uploadedFile->setMockSize($oversizedBytes);
        $uploadedFile->setMockExtension('csv');
        $uploadedFile->setMockMime('text/csv');

        $controller = $this->setupController($uploadedFile);
        $response = $controller->bulkUpload();

        $this->assertEquals(422, $response->getStatusCode(), 'Expected HTTP 422 when uploading file > 2 MB');
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success'] ?? true);
        $this->assertStringContainsString('2 MB', $body['message']);
    }

    /**
     * Test 3: An unsupported extension is rejected with 422
     */
    public function testUnsupportedExtensionIsRejectedWith422(): void
    {
        $jsonContent = json_encode([['name' => 'Test User']]);
        $filePath = $this->createTempFile($jsonContent, '.json');

        $uploadedFile = new TestBulkUploadFile($filePath, 'data.json', 'application/json', strlen($jsonContent), UPLOAD_ERR_OK);
        $uploadedFile->setMockValid(true);
        $uploadedFile->setMockExtension('json');
        $uploadedFile->setMockMime('application/json');

        $controller = $this->setupController($uploadedFile);
        $response = $controller->bulkUpload();

        $this->assertEquals(422, $response->getStatusCode(), 'Expected HTTP 422 when uploading unsupported file extension');
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success'] ?? true);
        $this->assertStringContainsString('extension', strtolower($body['message']));
    }

    /**
     * Test 4: A row with a taken code fails only that row with "Employee code not available"
     * and does not disclose who owns it, while other rows still import successfully.
     */
    public function testRowWithTakenCodeFailsOnlyThatRowWithGenericMessageAndOtherRowsImport(): void
    {
        $db = Database::connect();

        // Seed an employee in the OTHER company with code 'EMP-TAKEN-999'
        $db->table('employees')->replace([
            'id'            => 'emp-external-collision-01',
            'company_id'    => $this->otherCompanyId,
            'employee_code' => 'EMP-TAKEN-999',
            'first_name'    => 'External',
            'last_name'     => 'Worker',
            'email'         => 'ext_worker@other.com',
            'gender'        => 'male',
            'dob'           => '1985-05-05',
            'status'        => 'Active',
            'deleted_at'    => null,
            'created_at'    => date('Y-m-d H:i:s'),
            'updated_at'    => date('Y-m-d H:i:s'),
        ]);

        // Also seed a soft-deleted employee in THIS company with code 'EMP-DELETED-888'
        $db->table('employees')->replace([
            'id'            => 'emp-softdel-collision-02',
            'company_id'    => $this->tenantCompanyId,
            'employee_code' => 'EMP-DELETED-888',
            'first_name'    => 'Former',
            'last_name'     => 'Worker',
            'email'         => 'former_worker@test.com',
            'gender'        => 'female',
            'dob'           => '1988-08-08',
            'status'        => 'terminated',
            'deleted_at'    => date('Y-m-d H:i:s'),
            'created_at'    => date('Y-m-d H:i:s'),
            'updated_at'    => date('Y-m-d H:i:s'),
        ]);

        $payload = [
            'rows' => [
                [
                    'name'          => 'Collision Candidate One',
                    'employee_code' => 'EMP-TAKEN-999', // Collides with other company
                    'email'         => 'candidate1@test.com',
                    'gender'        => 'male',
                    'dob'           => '1992-02-02',
                    'department'    => 'Engineering',
                    'designation'   => 'Software Engineer',
                    'employee_type' => 'Permanent',
                ],
                [
                    'name'          => 'Valid Candidate Two',
                    'employee_code' => 'EMP-VALID-777', // Unique
                    'email'         => 'candidate2@test.com',
                    'gender'        => 'female',
                    'dob'           => '1993-03-03',
                    'department'    => 'Engineering',
                    'designation'   => 'Software Engineer',
                    'employee_type' => 'Permanent',
                ],
                [
                    'name'          => 'Collision Candidate Three',
                    'employee_code' => 'EMP-DELETED-888', // Collides with soft-deleted record
                    'email'         => 'candidate3@test.com',
                    'gender'        => 'male',
                    'dob'           => '1994-04-04',
                    'department'    => 'Engineering',
                    'designation'   => 'Software Engineer',
                    'employee_type' => 'Permanent',
                ],
            ]
        ];

        $controller = $this->setupController(null, $payload);
        $response = $controller->bulkUpload();

        $this->assertEquals(200, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertTrue($body['success'] ?? false);

        $data = $body['data'];
        $this->assertEquals(1, $data['created_count'], 'Only 1 row should have been created');
        $this->assertEquals(2, $data['failed_count'], '2 rows with taken codes should have failed');

        $results = $data['results'];
        $this->assertCount(3, $results);

        // Row 1 verification: failed with exact generic message, does NOT leak company or owner
        $this->assertEquals('failed', $results[0]['status']);
        $this->assertEquals('Employee code not available', $results[0]['message']);
        $this->assertEquals('EMP-TAKEN-999', $results[0]['employee_code']);
        $this->assertStringNotContainsString('other', strtolower($results[0]['message']));
        $this->assertStringNotContainsString('external', strtolower($results[0]['message']));

        // Row 2 verification: created with supplied unique code
        $this->assertEquals('created', $results[1]['status']);
        $this->assertEquals('EMP-VALID-777', $results[1]['employee_code']);

        // Row 3 verification: failed with exact generic message, does NOT leak soft-delete state
        $this->assertEquals('failed', $results[2]['status']);
        $this->assertEquals('Employee code not available', $results[2]['message']);
        $this->assertEquals('EMP-DELETED-888', $results[2]['employee_code']);

        // Verify database: Candidate Two exists with EMP-VALID-777 in tenant company
        $empModel = new EmployeeModel();
        $importedEmp = $empModel->where('company_id', $this->tenantCompanyId)
            ->where('employee_code', 'EMP-VALID-777')
            ->first();
        $this->assertNotNull($importedEmp, 'Valid employee must be saved in database');
        $this->assertEquals('Valid Candidate Two', $importedEmp['first_name'] . ' ' . $importedEmp['last_name']);

        // Verify database: Candidate One was NOT created under a silently generated code
        $collidedEmp = $empModel->where('company_id', $this->tenantCompanyId)
            ->where('email', 'candidate1@test.com')
            ->first();
        $this->assertNull($collidedEmp, 'Collision candidate must not be silently created with replacement code');
    }

    /**
     * Test 5: A row with a blank code gets an auto-generated code
     */
    public function testRowWithBlankCodeGetsAutoCode(): void
    {
        $payload = [
            'rows' => [
                [
                    'name'          => 'Blank Code Worker',
                    'employee_code' => '', // Blank code
                    'email'         => 'blank_code@test.com',
                    'gender'        => 'female',
                    'dob'           => '1995-05-05',
                    'department'    => 'Engineering',
                    'designation'   => 'Software Engineer',
                    'employee_type' => 'Permanent',
                ]
            ]
        ];

        $controller = $this->setupController(null, $payload);
        $response = $controller->bulkUpload();

        $this->assertEquals(200, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertTrue($body['success'] ?? false);

        $data = $body['data'];
        $this->assertEquals(1, $data['created_count']);
        $this->assertEquals(0, $data['failed_count']);

        $resultRow = $data['results'][0];
        $this->assertEquals('created', $resultRow['status']);
        $this->assertNotEmpty($resultRow['employee_code'], 'Auto code must be generated');
        $this->assertStringStartsWith('EMP-', $resultRow['employee_code'], 'Auto code should follow EMP- pattern');

        // Check database persistence
        $empModel = new EmployeeModel();
        $saved = $empModel->where('company_id', $this->tenantCompanyId)
            ->where('email', 'blank_code@test.com')
            ->first();
        $this->assertNotNull($saved);
        $this->assertEquals($resultRow['employee_code'], $saved['employee_code']);
    }

    /**
     * Test 6: A valid CSV file imports successfully
     */
    public function testValidCsvImportsSuccessfully(): void
    {
        $csvContent = implode("\n", [
            'name,email,employee_code,department,designation,employee_type,dob,gender',
            'Alice Smith,alice.bulk@test.com,EMP-CSV-001,Engineering,Software Engineer,Permanent,1991-01-10,female',
            'Bob Jones,bob.bulk@test.com,EMP-CSV-002,Engineering,Software Engineer,Permanent,1992-02-20,male',
        ]);
        $filePath = $this->createTempFile($csvContent, '.csv');

        $uploadedFile = new TestBulkUploadFile($filePath, 'valid_employees.csv', 'text/csv', strlen($csvContent), UPLOAD_ERR_OK);
        $uploadedFile->setMockValid(true);
        $uploadedFile->setMockExtension('csv');
        $uploadedFile->setMockMime('text/csv');

        $controller = $this->setupController($uploadedFile);
        $response = $controller->bulkUpload();

        $this->assertEquals(200, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertTrue($body['success'] ?? false);

        $data = $body['data'];
        $this->assertEquals(2, $data['created_count'], 'Both employees from valid CSV should be created');
        $this->assertEquals(0, $data['failed_count']);

        $empModel = new EmployeeModel();
        $alice = $empModel->where('company_id', $this->tenantCompanyId)->where('employee_code', 'EMP-CSV-001')->first();
        $bob   = $empModel->where('company_id', $this->tenantCompanyId)->where('employee_code', 'EMP-CSV-002')->first();

        $this->assertNotNull($alice, 'Alice must be created in DB');
        $this->assertNotNull($bob, 'Bob must be created in DB');
        $this->assertEquals('alice.bulk@test.com', $alice['email']);
        $this->assertEquals('bob.bulk@test.com', $bob['email']);
    }

    /**
     * Test 7: A CSV with text/plain MIME is accepted and imports successfully
     */
    public function testCsvWithTextPlainMimeIsAccepted(): void
    {
        $csvContent = implode("\n", [
            'name,email,employee_code,department,designation,gender,dob',
            'Plain User,plain.csv@test.com,EMP-PLAIN-01,Engineering,Software Engineer,male,1993-03-15',
        ]);
        $filePath = $this->createTempFile($csvContent, '.csv');

        $uploadedFile = new TestBulkUploadFile($filePath, 'plain_employees.csv', 'text/plain', strlen($csvContent), UPLOAD_ERR_OK);
        $uploadedFile->setMockValid(true);
        $uploadedFile->setMockClientExtension('csv');
        $uploadedFile->setMockMime('text/plain');

        $controller = $this->setupController($uploadedFile);
        $response = $controller->bulkUpload();

        $this->assertEquals(200, $response->getStatusCode(), 'Expected HTTP 200 when uploading CSV with text/plain MIME');
        $body = json_decode($response->getBody(), true);
        $this->assertTrue($body['success'] ?? false);
        $this->assertEquals(1, $body['data']['created_count']);

        $empModel = new EmployeeModel();
        $saved = $empModel->where('company_id', $this->tenantCompanyId)->where('employee_code', 'EMP-PLAIN-01')->first();
        $this->assertNotNull($saved, 'Plain User should be created in DB');
        $this->assertEquals('plain.csv@test.com', $saved['email']);
    }

    /**
     * Test 8: A zip renamed .xlsx without [Content_Types].xml is rejected with 422
     */
    public function testZipRenamedToXlsxWithoutContentTypesXmlIsRejected(): void
    {
        $filePath = $this->createZipWithoutContentTypes('.xlsx');

        $uploadedFile = new TestBulkUploadFile($filePath, 'regular_archive.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', filesize($filePath), UPLOAD_ERR_OK);
        $uploadedFile->setMockValid(true);
        $uploadedFile->setMockClientExtension('xlsx');
        $uploadedFile->setMockMime('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');

        $controller = $this->setupController($uploadedFile);
        $response = $controller->bulkUpload();

        $this->assertEquals(422, $response->getStatusCode(), 'Expected HTTP 422 when uploading zip without [Content_Types].xml as xlsx');
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success'] ?? true);
        $this->assertStringContainsString('[content_types].xml', strtolower($body['message']));
    }

    /**
     * Test 9: A real small xlsx is accepted and imports successfully
     */
    public function testRealSmallXlsxIsAccepted(): void
    {
        $filePath = $this->createSmallXlsxFile('Xlsx Worker', 'xlsx.worker@test.com', 'EMP-XLSX-001');

        $uploadedFile = new TestBulkUploadFile($filePath, 'sample_employees.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', filesize($filePath), UPLOAD_ERR_OK);
        $uploadedFile->setMockValid(true);
        $uploadedFile->setMockClientExtension('xlsx');
        $uploadedFile->setMockMime('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');

        $controller = $this->setupController($uploadedFile);
        $response = $controller->bulkUpload();

        $this->assertEquals(200, $response->getStatusCode(), 'Expected HTTP 200 when uploading real small xlsx');
        $body = json_decode($response->getBody(), true);
        $this->assertTrue($body['success'] ?? false);
        $this->assertEquals(1, $body['data']['created_count']);

        $empModel = new EmployeeModel();
        $saved = $empModel->where('company_id', $this->tenantCompanyId)->where('employee_code', 'EMP-XLSX-001')->first();
        $this->assertNotNull($saved, 'Xlsx Worker must be created in DB');
        $this->assertEquals('xlsx.worker@test.com', $saved['email']);
    }

    /**
     * Test 10: A CSV containing a NUL byte is rejected with 422
     */
    public function testCsvContainingNulByteIsRejectedWith422(): void
    {
        $corruptCsv = "name,email\0,employee_code\nCorrupt User,corrupt@test.com,EMP-CORRUPT-01\n";
        $filePath = $this->createTempFile($corruptCsv, '.csv');

        $uploadedFile = new TestBulkUploadFile($filePath, 'corrupt.csv', 'text/csv', strlen($corruptCsv), UPLOAD_ERR_OK);
        $uploadedFile->setMockValid(true);
        $uploadedFile->setMockClientExtension('csv');
        $uploadedFile->setMockMime('text/csv');

        $controller = $this->setupController($uploadedFile);
        $response = $controller->bulkUpload();

        $this->assertEquals(422, $response->getStatusCode(), 'Expected HTTP 422 when uploading CSV with NUL byte');
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success'] ?? true);
        $this->assertStringContainsString('nul', strtolower($body['message']));
    }

    /**
     * Test 11: An XLSX whose worksheet XML exceeds 5 MB uncompressed is rejected with 422
     */
    public function testXlsxOver5MbUncompressedIsRejectedWith422WithoutOutOfMemory(): void
    {
        $filePath = $this->createZipWithOversizedSheet();

        $uploadedFile = new TestBulkUploadFile(
            $filePath,
            'oversized.xlsx',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            filesize($filePath),
            UPLOAD_ERR_OK
        );
        $uploadedFile->setMockValid(true);
        $uploadedFile->setMockClientExtension('xlsx');
        $uploadedFile->setMockMime('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');

        $controller = $this->setupController($uploadedFile);
        $response = $controller->bulkUpload();

        $this->assertEquals(422, $response->getStatusCode(), 'Expected HTTP 422 when XLSX worksheet XML exceeds 5 MB');
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success'] ?? true);
        $this->assertStringContainsString('5 mb', strtolower($body['message']));
    }

    /**
     * Test 12: An XLSX containing DOCTYPE in worksheet XML is rejected with 422
     */
    public function testXlsxContainingDoctypeInSheetXmlIsRejectedWith422(): void
    {
        $filePath = $this->createZipWithDoctype();

        $uploadedFile = new TestBulkUploadFile(
            $filePath,
            'xxe_doctype.xlsx',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            filesize($filePath),
            UPLOAD_ERR_OK
        );
        $uploadedFile->setMockValid(true);
        $uploadedFile->setMockClientExtension('xlsx');
        $uploadedFile->setMockMime('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');

        $controller = $this->setupController($uploadedFile);
        $response = $controller->bulkUpload();

        $this->assertEquals(422, $response->getStatusCode(), 'Expected HTTP 422 when XLSX contains DOCTYPE declaration');
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success'] ?? true);
        $this->assertStringContainsString('doctype', strtolower($body['message']));
    }

    /**
     * Test 13: An XLSX with date serial (e.g. 45123) and text date imports correctly
     */
    public function testXlsxWithDateSerialAndTextDateImportsCorrectly(): void
    {
        $filePath = $this->createXlsxWithDateSerial('Date Worker', 'date.worker@test.com', 'EMP-DATE-001', '1990-05-20', 45123);

        $uploadedFile = new TestBulkUploadFile(
            $filePath,
            'date_serial.xlsx',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            filesize($filePath),
            UPLOAD_ERR_OK
        );
        $uploadedFile->setMockValid(true);
        $uploadedFile->setMockClientExtension('xlsx');
        $uploadedFile->setMockMime('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');

        $controller = $this->setupController($uploadedFile);
        $response = $controller->bulkUpload();

        $this->assertEquals(200, $response->getStatusCode(), 'Expected HTTP 200 when importing XLSX with numeric serial date');
        $body = json_decode($response->getBody(), true);
        $this->assertTrue($body['success'] ?? false);
        $this->assertEquals(1, $body['data']['created_count']);

        $empModel = new EmployeeModel();
        $saved = $empModel->where('company_id', $this->tenantCompanyId)->where('employee_code', 'EMP-DATE-001')->first();
        $this->assertNotNull($saved, 'Date Worker must be created in DB');
        $this->assertEquals('1990-05-20', $saved['dob']);
        $this->assertContains($saved['join_date'], ['2023-07-15', '2023-07-16']);
    }

    /**
     * Test 14: An XLSX whose first sheet is sheet2.xml via workbook.xml order imports successfully
     */
    public function testXlsxWithFirstSheetAsSheet2ImportsSuccessfully(): void
    {
        $filePath = $this->createXlsxWithCustomFirstSheet('Sheet Two Worker', 'sheet2.worker@test.com', 'EMP-SHEET2-001');

        $uploadedFile = new TestBulkUploadFile(
            $filePath,
            'custom_first_sheet.xlsx',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            filesize($filePath),
            UPLOAD_ERR_OK
        );
        $uploadedFile->setMockValid(true);
        $uploadedFile->setMockClientExtension('xlsx');
        $uploadedFile->setMockMime('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');

        $controller = $this->setupController($uploadedFile);
        $response = $controller->bulkUpload();

        $this->assertEquals(200, $response->getStatusCode(), 'Expected HTTP 200 when first sheet is resolved dynamically');
        $body = json_decode($response->getBody(), true);
        $this->assertTrue($body['success'] ?? false);
        $this->assertEquals(1, $body['data']['created_count']);

        $empModel = new EmployeeModel();
        $saved = $empModel->where('company_id', $this->tenantCompanyId)->where('employee_code', 'EMP-SHEET2-001')->first();
        $this->assertNotNull($saved, 'Sheet Two Worker must be created in DB');
        $this->assertStringContainsString('Sheet Two', $saved['first_name']);
    }

    /**
     * Test 15: Valid XLS with OLE2 header passes file inspection but returns 422 not supported
     */
    public function testValidXlsWithOle2HeaderReturns422NotSupported(): void
    {
        $ole2Header = hex2bin('D0CF11E0A1B11AE1') . str_repeat("\0", 504);
        $filePath = $this->createTempFile($ole2Header, '.xls');

        $uploadedFile = new TestBulkUploadFile(
            $filePath,
            'legacy.xls',
            'application/vnd.ms-excel',
            strlen($ole2Header),
            UPLOAD_ERR_OK
        );
        $uploadedFile->setMockValid(true);
        $uploadedFile->setMockClientExtension('xls');
        $uploadedFile->setMockMime('application/vnd.ms-excel');

        $controller = $this->setupController($uploadedFile);
        $response = $controller->bulkUpload();

        $this->assertEquals(422, $response->getStatusCode(), 'Expected HTTP 422 for legacy XLS files');
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success'] ?? true);
        $this->assertStringContainsString('xls (legacy excel) files are not supported', strtolower($body['message']));
    }

    /**
     * Test 16: CSV with 5-digit serial date converts to Y-m-d
     */
    public function testCsvWith5DigitSerialDateConvertsToDate(): void
    {
        $csvContent = implode("\n", [
            'name,email,employee_code,department,designation,gender,dob,join_date',
            'CSV Serial,csv.serial@test.com,EMP-CSVSER-01,Engineering,Software Engineer,female,1995-10-10,45123',
        ]);
        $filePath = $this->createTempFile($csvContent, '.csv');

        $uploadedFile = new TestBulkUploadFile($filePath, 'serial_employees.csv', 'text/csv', strlen($csvContent), UPLOAD_ERR_OK);
        $uploadedFile->setMockValid(true);
        $uploadedFile->setMockClientExtension('csv');
        $uploadedFile->setMockMime('text/csv');

        $controller = $this->setupController($uploadedFile);
        $response = $controller->bulkUpload();

        $this->assertEquals(200, $response->getStatusCode(), 'Expected HTTP 200 when importing CSV with 5-digit serial date');
        $body = json_decode($response->getBody(), true);
        $this->assertTrue($body['success'] ?? false);
        $this->assertEquals(1, $body['data']['created_count']);

        $empModel = new EmployeeModel();
        $saved = $empModel->where('company_id', $this->tenantCompanyId)->where('employee_code', 'EMP-CSVSER-01')->first();
        $this->assertNotNull($saved, 'CSV Serial worker should be created in DB');
        $this->assertEquals('1995-10-10', $saved['dob']);
        $this->assertContains($saved['join_date'], ['2023-07-15', '2023-07-16']);
    }

    /**
     * Test 17: Blank email rows succeed with no login created and null email in DB,
     * while adjacent rows with valid emails succeed and receive logins.
     */
    public function testBulkUploadWithBlankEmailsCreatesEmployeesWithoutLoginAndOtherRowsSucceed(): void
    {
        $csvContent = implode("\n", [
            'name,email,employee_code,department,designation,employee_type,dob,gender',
            'Worker One,worker1.bulk@test.com,EMP-BLANK-001,Engineering,Software Engineer,Permanent,1990-01-01,male',
            'Worker Two Blank,,EMP-BLANK-002,Engineering,Software Engineer,Permanent,1991-02-02,female',
            'Worker Three,worker3.bulk@test.com,EMP-BLANK-003,Engineering,Software Engineer,Permanent,1992-03-03,male',
            'Worker Four Blank,,EMP-BLANK-004,Engineering,Software Engineer,Permanent,1993-04-04,female',
        ]);
        $filePath = $this->createTempFile($csvContent, '.csv');

        $uploadedFile = new TestBulkUploadFile($filePath, 'mixed_blank_emails.csv', 'text/csv', strlen($csvContent), UPLOAD_ERR_OK);
        $uploadedFile->setMockValid(true);
        $uploadedFile->setMockExtension('csv');
        $uploadedFile->setMockMime('text/csv');

        $controller = $this->setupController($uploadedFile);
        $response = $controller->bulkUpload();

        $this->assertEquals(200, $response->getStatusCode(), 'Expected HTTP 200 for bulk upload with blank emails');
        $body = json_decode($response->getBody(), true);
        $this->assertTrue($body['success'] ?? false);

        $data = $body['data'];
        $this->assertEquals(4, $data['created_count'], 'All 4 rows should be created');
        $this->assertEquals(0, $data['failed_count'], '0 rows should fail');

        $results = $data['results'];
        $this->assertCount(4, $results);

        // Check blank email rows had proper notice
        $this->assertStringContainsString('No login created: email not provided', $results[1]['message']);
        $this->assertNull($results[1]['email']);
        $this->assertStringContainsString('No login created: email not provided', $results[3]['message']);
        $this->assertNull($results[3]['email']);

        // Check DB records
        $empModel = new EmployeeModel();
        $db = Database::connect();

        $emp1 = $empModel->where('company_id', $this->tenantCompanyId)->where('employee_code', 'EMP-BLANK-001')->first();
        $emp2 = $empModel->where('company_id', $this->tenantCompanyId)->where('employee_code', 'EMP-BLANK-002')->first();
        $emp3 = $empModel->where('company_id', $this->tenantCompanyId)->where('employee_code', 'EMP-BLANK-003')->first();
        $emp4 = $empModel->where('company_id', $this->tenantCompanyId)->where('employee_code', 'EMP-BLANK-004')->first();

        $this->assertNotNull($emp1);
        $this->assertNotNull($emp2);
        $this->assertNotNull($emp3);
        $this->assertNotNull($emp4);

        $this->assertEquals('worker1.bulk@test.com', $emp1['email']);
        $this->assertNull($emp2['email'], 'Blank email must be stored as NULL');
        $this->assertEquals('worker3.bulk@test.com', $emp3['email']);
        $this->assertNull($emp4['email'], 'Blank email must be stored as NULL');

        // Check user logins
        $user1 = $db->table('users')->where('employee_id', $emp1['id'])->get()->getRowArray();
        $user2 = $db->table('users')->where('employee_id', $emp2['id'])->get()->getRowArray();
        $user3 = $db->table('users')->where('employee_id', $emp3['id'])->get()->getRowArray();
        $user4 = $db->table('users')->where('employee_id', $emp4['id'])->get()->getRowArray();

        $this->assertNotNull($user1, 'Login user should be created for employee with valid email');
        $this->assertNull($user2, 'No login user should be created for employee with blank email');
        $this->assertNotNull($user3, 'Login user should be created for employee with valid email');
        $this->assertNull($user4, 'No login user should be created for employee with blank email');
    }

    /**
     * Test 18: A failure on one row does not poison transaction status for subsequent valid rows.
     */
    public function testFailedRowDoesNotPoisonSubsequentValidRows(): void
    {
        $db = Database::connect();

        // Seed a pre-existing employee in another company to force a collision on row 2
        $db->table('employees')->replace([
            'id'            => 'emp-poison-blocker-01',
            'company_id'    => $this->otherCompanyId,
            'employee_code' => 'EMP-POISON-COLLISION',
            'first_name'    => 'Collision',
            'last_name'     => 'Target',
            'email'         => 'collision_target@other.com',
            'gender'        => 'male',
            'dob'           => '1980-01-01',
            'status'        => 'Active',
            'deleted_at'    => null,
            'created_at'    => date('Y-m-d H:i:s'),
            'updated_at'    => date('Y-m-d H:i:s'),
        ]);

        $payload = [
            'rows' => [
                [
                    'name'          => 'Pre-Fail Employee',
                    'employee_code' => 'EMP-POISON-OK-1',
                    'email'         => 'pre_fail@test.com',
                    'gender'        => 'male',
                    'dob'           => '1990-01-01',
                    'department'    => 'Engineering',
                    'designation'   => 'Software Engineer',
                    'employee_type' => 'Permanent',
                ],
                [
                    'name'          => 'Failing Employee Collision',
                    'employee_code' => 'EMP-POISON-COLLISION', // Taken code -> triggers row failure and rollback
                    'email'         => 'fail_row@test.com',
                    'gender'        => 'male',
                    'dob'           => '1991-01-01',
                    'department'    => 'Engineering',
                    'designation'   => 'Software Engineer',
                    'employee_type' => 'Permanent',
                ],
                [
                    'name'          => 'Post-Fail Employee 1',
                    'employee_code' => 'EMP-POISON-OK-2',
                    'email'         => 'post_fail_1@test.com',
                    'gender'        => 'female',
                    'dob'           => '1992-02-02',
                    'department'    => 'Engineering',
                    'designation'   => 'Software Engineer',
                    'employee_type' => 'Permanent',
                ],
                [
                    'name'          => 'Post-Fail Employee 2 (Blank Email)',
                    'employee_code' => 'EMP-POISON-OK-3',
                    'email'         => '',
                    'gender'        => 'female',
                    'dob'           => '1993-03-03',
                    'department'    => 'Engineering',
                    'designation'   => 'Software Engineer',
                    'employee_type' => 'Permanent',
                ],
            ]
        ];

        $controller = $this->setupController(null, $payload);
        $response = $controller->bulkUpload();

        $this->assertEquals(200, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertTrue($body['success'] ?? false);

        $data = $body['data'];
        $this->assertEquals(3, $data['created_count'], 'Rows 1, 3, and 4 should be created successfully');
        $this->assertEquals(1, $data['failed_count'], 'Only Row 2 should have failed');

        $results = $data['results'];
        $this->assertEquals('created', $results[0]['status']);
        $this->assertEquals('failed', $results[1]['status']);
        $this->assertEquals('created', $results[2]['status']);
        $this->assertEquals('created', $results[3]['status']);

        // Confirm database records exist for post-fail employees
        $empModel = new EmployeeModel();
        $postEmp1 = $empModel->where('company_id', $this->tenantCompanyId)->where('employee_code', 'EMP-POISON-OK-2')->first();
        $postEmp2 = $empModel->where('company_id', $this->tenantCompanyId)->where('employee_code', 'EMP-POISON-OK-3')->first();

        $this->assertNotNull($postEmp1, 'Post-fail employee 1 must be saved in database');
        $this->assertNotNull($postEmp2, 'Post-fail employee 2 must be saved in database');
        $this->assertNull($postEmp2['email'], 'Post-fail employee 2 blank email must be null');
    }

    /**
     * Test 19: Re-uploading the same sheet twice: the second run gives 0 created, all rows skipped, 0 failed.
     */
    public function testReuploadingSameSheetSkipsAllRows(): void
    {
        $csvContent = implode("\n", [
            'name,email,employee_code,department,designation,employee_type,dob,gender',
            'Tariq Rahman,tariq@test.com,EMP-REUP-001,Engineering,Software Engineer,Permanent,1990-01-01,male',
            'Sadia Islam,sadia@test.com,EMP-REUP-002,Engineering,Software Engineer,Permanent,1992-02-02,female',
        ]);
        $filePath = $this->createTempFile($csvContent, '.csv');

        // First upload: creates employees
        $uploadedFile1 = new TestBulkUploadFile($filePath, 'sheet.csv', 'text/csv', strlen($csvContent), UPLOAD_ERR_OK);
        $uploadedFile1->setMockValid(true);
        $uploadedFile1->setMockExtension('csv');
        $uploadedFile1->setMockMime('text/csv');

        $controller1 = $this->setupController($uploadedFile1);
        $res1 = $controller1->bulkUpload();
        $this->assertEquals(200, $res1->getStatusCode());
        $body1 = json_decode($res1->getBody(), true);
        $this->assertEquals(2, $body1['data']['created_count']);
        $this->assertEquals(0, $body1['data']['skipped_count']);
        $this->assertEquals(0, $body1['data']['failed_count']);

        // Second upload of identical sheet: all rows skipped
        $uploadedFile2 = new TestBulkUploadFile($filePath, 'sheet.csv', 'text/csv', strlen($csvContent), UPLOAD_ERR_OK);
        $uploadedFile2->setMockValid(true);
        $uploadedFile2->setMockExtension('csv');
        $uploadedFile2->setMockMime('text/csv');

        $controller2 = $this->setupController($uploadedFile2);
        $res2 = $controller2->bulkUpload();
        $this->assertEquals(200, $res2->getStatusCode());
        $body2 = json_decode($res2->getBody(), true);

        $this->assertEquals(0, $body2['data']['created_count'], '0 employees created on second run');
        $this->assertEquals(0, $body2['data']['updated_count'], '0 employees updated on second run');
        $this->assertEquals(2, $body2['data']['skipped_count'], 'All rows skipped on second run');
        $this->assertEquals(0, $body2['data']['failed_count'], '0 failed rows on second run');

        $results = $body2['data']['results'];
        $this->assertEquals('skipped', $results[0]['status']);
        $this->assertEquals('Skipped: employee already exists with same ID and name', $results[0]['message']);
        $this->assertEquals('skipped', $results[1]['status']);
        $this->assertEquals('Skipped: employee already exists with same ID and name', $results[1]['message']);
    }

    /**
     * Test 20: Same code with a different name fails with clear message avoiding overwrite.
     */
    public function testSameCodeWithDifferentNameFailsWithClearMessage(): void
    {
        $db = Database::connect();
        $db->table('employees')->replace([
            'id'            => 'emp-diffname-01',
            'company_id'    => $this->tenantCompanyId,
            'employee_code' => 'EMP-DIFFNAME-01',
            'first_name'    => 'Original',
            'last_name'     => 'Owner',
            'email'         => 'orig_owner@test.com',
            'gender'        => 'male',
            'dob'           => '1985-01-01',
            'status'        => 'Active',
            'deleted_at'    => null,
            'created_at'    => date('Y-m-d H:i:s'),
            'updated_at'    => date('Y-m-d H:i:s'),
        ]);

        $payload = [
            'rows' => [
                [
                    'name'          => 'Imposter User',
                    'employee_code' => 'EMP-DIFFNAME-01',
                    'email'         => 'imposter@test.com',
                    'gender'        => 'male',
                    'dob'           => '1990-01-01',
                    'department'    => 'Engineering',
                    'designation'   => 'Software Engineer',
                    'employee_type' => 'Permanent',
                ]
            ]
        ];

        $controller = $this->setupController(null, $payload);
        $res = $controller->bulkUpload();
        $body = json_decode($res->getBody(), true);

        $this->assertEquals(0, $body['data']['created_count']);
        $this->assertEquals(0, $body['data']['skipped_count']);
        $this->assertEquals(1, $body['data']['failed_count']);

        $resRow = $body['data']['results'][0];
        $this->assertEquals('failed', $resRow['status']);
        $this->assertEquals('Employee code EMP-DIFFNAME-01 already used by Original Owner', $resRow['message']);
    }

    /**
     * Test 21: Same name with a different code is created normally (not skipped).
     */
    public function testSameNameWithDifferentCodeIsCreatedNormally(): void
    {
        $db = Database::connect();
        $db->table('employees')->replace([
            'id'            => 'emp-samename-01',
            'company_id'    => $this->tenantCompanyId,
            'employee_code' => 'EMP-SAMENAME-01',
            'first_name'    => 'Naim',
            'last_name'     => 'Islam',
            'email'         => 'naim1@test.com',
            'gender'        => 'male',
            'dob'           => '1990-01-01',
            'status'        => 'Active',
            'deleted_at'    => null,
            'created_at'    => date('Y-m-d H:i:s'),
            'updated_at'    => date('Y-m-d H:i:s'),
        ]);

        $payload = [
            'rows' => [
                [
                    'name'          => 'Naim Islam',
                    'employee_code' => 'EMP-SAMENAME-02', // Different code
                    'email'         => 'naim2@test.com',
                    'gender'        => 'male',
                    'dob'           => '1991-01-01',
                    'department'    => 'Engineering',
                    'designation'   => 'Software Engineer',
                    'employee_type' => 'Permanent',
                ]
            ]
        ];

        $controller = $this->setupController(null, $payload);
        $res = $controller->bulkUpload();
        $body = json_decode($res->getBody(), true);

        $this->assertEquals(1, $body['data']['created_count'], 'Should create new employee with different code');
        $this->assertEquals(0, $body['data']['skipped_count'], 'Should not skip when code is different');
        $this->assertEquals(0, $body['data']['failed_count']);
    }

    /**
     * Test 22: Name differences in dots, case, or extra spaces still match and skip.
     */
    public function testNameDifferencesInDotsCaseOrSpacesStillMatchAndSkip(): void
    {
        $db = Database::connect();
        $db->table('employees')->replace([
            'id'            => 'emp-normmatch-01',
            'company_id'    => $this->tenantCompanyId,
            'employee_code' => 'EMP-NORMMATCH-01',
            'first_name'    => 'Md.',
            'last_name'     => 'Naim Islam',
            'email'         => 'naim.orig@test.com',
            'gender'        => 'male',
            'dob'           => '1990-01-01',
            'status'        => 'Active',
            'deleted_at'    => null,
            'created_at'    => date('Y-m-d H:i:s'),
            'updated_at'    => date('Y-m-d H:i:s'),
        ]);

        // Upload with: "md naim islam" (lowercase, no dots, spaces)
        $payload = [
            'rows' => [
                [
                    'name'          => '  md   naim   islam  ',
                    'employee_code' => 'EMP-NORMMATCH-01',
                    'email'         => 'naim.reupload@test.com',
                    'gender'        => 'male',
                    'dob'           => '1990-01-01',
                    'department'    => 'Engineering',
                    'designation'   => 'Software Engineer',
                    'employee_type' => 'Permanent',
                ]
            ]
        ];

        $controller = $this->setupController(null, $payload);
        $res = $controller->bulkUpload();
        $body = json_decode($res->getBody(), true);

        $this->assertEquals(0, $body['data']['created_count']);
        $this->assertEquals(1, $body['data']['skipped_count'], 'Should normalize dots, casing, whitespace and skip');
        $this->assertEquals(0, $body['data']['failed_count']);
        $this->assertEquals('Skipped: employee already exists with same ID and name', $body['data']['results'][0]['message']);
    }

    /**
     * Test 23: Duplicates inside the same file: skip the second one with "Duplicate row in file".
     */
    public function testDuplicateRowInsideSameFileIsSkipped(): void
    {
        $payload = [
            'rows' => [
                [
                    'name'          => 'Dual Row Worker',
                    'employee_code' => 'EMP-DUAL-001',
                    'email'         => 'dual1@test.com',
                    'gender'        => 'male',
                    'dob'           => '1990-01-01',
                    'department'    => 'Engineering',
                    'designation'   => 'Software Engineer',
                    'employee_type' => 'Permanent',
                ],
                [
                    'name'          => 'Dual Row Worker',
                    'employee_code' => 'EMP-DUAL-001', // Exact duplicate in same upload
                    'email'         => 'dual2@test.com',
                    'gender'        => 'male',
                    'dob'           => '1990-01-01',
                    'department'    => 'Engineering',
                    'designation'   => 'Software Engineer',
                    'employee_type' => 'Permanent',
                ]
            ]
        ];

        $controller = $this->setupController(null, $payload);
        $res = $controller->bulkUpload();
        $body = json_decode($res->getBody(), true);

        $this->assertEquals(1, $body['data']['created_count']);
        $this->assertEquals(1, $body['data']['skipped_count']);
        $this->assertEquals(0, $body['data']['failed_count']);

        $this->assertEquals('created', $body['data']['results'][0]['status']);
        $this->assertEquals('skipped', $body['data']['results'][1]['status']);
        $this->assertEquals('Duplicate row in file', $body['data']['results'][1]['message']);
    }

    /**
     * Test 24: Soft-deleted employee code fails with "Employee code belongs to a deleted employee".
     */
    public function testSoftDeletedEmployeeCodeFailsWithDeletedMessage(): void
    {
        $db = Database::connect();
        $db->table('employees')->replace([
            'id'            => 'emp-softdel-match-01',
            'company_id'    => $this->tenantCompanyId,
            'employee_code' => 'EMP-DELETED-999',
            'first_name'    => 'Deleted',
            'last_name'     => 'Worker',
            'email'         => 'del_worker@test.com',
            'gender'        => 'female',
            'dob'           => '1985-05-05',
            'status'        => 'terminated',
            'deleted_at'    => date('Y-m-d H:i:s'),
            'created_at'    => date('Y-m-d H:i:s'),
            'updated_at'    => date('Y-m-d H:i:s'),
        ]);

        $payload = [
            'rows' => [
                [
                    'name'          => 'Deleted Worker',
                    'employee_code' => 'EMP-DELETED-999',
                    'email'         => 'del_rehire@test.com',
                    'gender'        => 'female',
                    'dob'           => '1985-05-05',
                    'department'    => 'Engineering',
                    'designation'   => 'Software Engineer',
                    'employee_type' => 'Permanent',
                ]
            ]
        ];

        $controller = $this->setupController(null, $payload);
        $res = $controller->bulkUpload();
        $body = json_decode($res->getBody(), true);

        $this->assertEquals(0, $body['data']['created_count']);
        $this->assertEquals(0, $body['data']['skipped_count'], 'Soft-deleted code should not be skipped');
        $this->assertEquals(1, $body['data']['failed_count'], 'Soft-deleted code must fail');

        $this->assertEquals('failed', $body['data']['results'][0]['status']);
        $this->assertEquals('Employee code belongs to a deleted employee', $body['data']['results'][0]['message']);
    }
}

