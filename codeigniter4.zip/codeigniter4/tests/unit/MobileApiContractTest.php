<?php

namespace Tests\Unit;

use App\Services\Mobile\MobileAuthService;
use App\Traits\ApiResponseTrait;
use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

/**
 * MobileApiContractTest
 *
 * Verifies strict compliance with the mobile API response contract:
 *
 * Target Success Structure:
 * {
 *   "success": true,
 *   "status": "success",
 *   "message": "OK",
 *   "data": {}
 * }
 *
 * Target Error Structure:
 * {
 *   "success": false,
 *   "status": "error",
 *   "message": "Validation failed.",
 *   "errors": {
 *     "field": "reason"
 *   }
 * }
 */
#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobileApiContractTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;
    private array $device = ['device_uid' => 'dev-contract-test', 'platform' => 'android'];

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);

        // Supporting tables for attendance, payslips, leaves
        $this->db->query("CREATE TABLE IF NOT EXISTS attendances (id VARCHAR(36) PRIMARY KEY, employee_id VARCHAR(36), company_id VARCHAR(36), date DATE, in_time DATETIME NULL, out_time DATETIME NULL, status VARCHAR(20) DEFAULT 'Present')");
        $this->db->query("CREATE TABLE IF NOT EXISTS payrolls (id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36), payroll_month VARCHAR(10), status VARCHAR(20), is_locked INT DEFAULT 1)");
        $this->db->query("CREATE TABLE IF NOT EXISTS payroll_items (id VARCHAR(36) PRIMARY KEY, payroll_id VARCHAR(36), employee_id VARCHAR(36), basic_salary DECIMAL(12,2), gross_salary DECIMAL(12,2), total_deductions DECIMAL(12,2), net_salary DECIMAL(12,2), bank_account_no VARCHAR(50) NULL)");
    }

    private function login(string $company = 'ACME', string $identifier = 'rahim'): string
    {
        $res = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => $company,
            'identifier'   => $identifier,
            'password'     => self::PASSWORD,
            'device'       => $this->device,
        ]);
        $res->assertStatus(200);
        $json = json_decode($res->getJSON(), true);
        return $json['data']['tokens']['access_token'];
    }

    /**
     * Test 1: Successful login response matches the exact success contract
     */
    public function testLoginSuccessMatchesApprovedContract(): void
    {
        $res = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => 'ACME',
            'identifier'   => 'rahim',
            'password'     => self::PASSWORD,
            'device'       => $this->device,
        ]);

        $this->assertSame(200, $res->response()->getStatusCode());
        $json = json_decode($res->getJSON(), true);

        // Assert exact envelope structure
        $this->assertTrue($json['success'], 'success must be boolean true');
        $this->assertSame('success', $json['status'], 'status must be string "success"');
        $this->assertSame('Login successful.', $json['message']);
        $this->assertIsArray($json['data'], 'data must be present as object/array');
        $this->assertArrayHasKey('tokens', $json['data']);
        $this->assertArrayHasKey('user', $json['data']);
        $this->assertNotEmpty($json['data']['tokens']['access_token']);
        $this->assertNotEmpty($json['data']['tokens']['refresh_token']);
    }

    /**
     * Test 2: Authenticated endpoints (me, profile, attendance today) match success contract
     */
    public function testAuthenticatedEndpointsMatchSuccessContract(): void
    {
        $token = $this->login('ACME', 'rahim');
        $headers = ['Authorization' => "Bearer {$token}"];

        // 1. GET /api/mobile/v1/auth/me
        $meRes = $this->withHeaders($headers)->call('get', 'api/mobile/v1/auth/me');
        $this->assertSame(200, $meRes->response()->getStatusCode());
        $me = json_decode($meRes->getJSON(), true);
        $this->assertTrue($me['success']);
        $this->assertSame('success', $me['status']);
        $this->assertSame('OK', $me['message']);
        $this->assertIsArray($me['data']);
        $this->assertSame('e-1', $me['data']['employee_id']);
        $this->assertSame('c-1', $me['data']['company_id']);

        // 2. GET /api/mobile/v1/profile
        $profileRes = $this->withHeaders($headers)->call('get', 'api/mobile/v1/profile');
        $this->assertSame(200, $profileRes->response()->getStatusCode());
        $prof = json_decode($profileRes->getJSON(), true);
        $this->assertTrue($prof['success']);
        $this->assertSame('success', $prof['status']);
        $this->assertIsArray($prof['data']);
        $this->assertArrayHasKey('profile', $prof['data']);
        $this->assertSame('EMP-001', $prof['data']['profile']['employee_code']);

        // 3. GET /api/mobile/v1/attendance/today
        $todayRes = $this->withHeaders($headers)->call('get', 'api/mobile/v1/attendance/today');
        $this->assertSame(200, $todayRes->response()->getStatusCode());
        $today = json_decode($todayRes->getJSON(), true);
        $this->assertTrue($today['success']);
        $this->assertSame('success', $today['status']);
        $this->assertIsArray($today['data']);
        $this->assertArrayHasKey('date', $today['data']);
        $this->assertArrayHasKey('checked_in', $today['data']);
    }

    /**
     * Test 3: Unauthenticated request returns standard 401 error envelope
     */
    public function testMissingTokenReturnsStandard401ErrorEnvelope(): void
    {
        $res = $this->call('get', 'api/mobile/v1/profile');
        $this->assertSame(401, $res->response()->getStatusCode());

        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success'], 'success must be boolean false');
        $this->assertSame('error', $json['status'], 'status must be string "error"');
        $this->assertSame('Unauthorized: Missing or invalid Bearer token.', $json['message']);
        $this->assertArrayHasKey('errors', $json, 'errors dictionary must exist in error envelope');
        $this->assertEmpty((array)$json['errors'], 'errors dictionary should be empty object for generic auth failure');
    }

    /**
     * Test 4: Invalid credentials returns standard 401 error envelope
     */
    public function testInvalidCredentialsReturnsStandard401ErrorEnvelope(): void
    {
        $res = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => 'ACME',
            'identifier'   => 'rahim',
            'password'     => 'WrongPassword123!',
            'device'       => $this->device,
        ]);
        $this->assertSame(401, $res->response()->getStatusCode());

        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success']);
        $this->assertSame('error', $json['status']);
        $this->assertSame('Invalid credentials.', $json['message']);
        $this->assertArrayHasKey('errors', $json);
    }

    /**
     * Test 5: Forced password change returns standard 403 error envelope with flag
     */
    public function testForcedPasswordChangeReturnsStandard403ErrorEnvelope(): void
    {
        $this->db->table('users')->where('id', 'u-1')->update(['must_change_password' => 1]);
        $token = $this->login('ACME', 'rahim');

        $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])->call('get', 'api/mobile/v1/profile');
        $this->assertSame(403, $res->response()->getStatusCode());

        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success']);
        $this->assertSame('error', $json['status']);
        $this->assertSame('Password change is required before continuing.', $json['message']);
        $this->assertTrue($json['must_change_password']);
        $this->assertArrayHasKey('errors', $json);
    }

    /**
     * Test 6: Missing record returns standard 404 error envelope
     */
    public function testMissingRecordReturnsStandard404ErrorEnvelope(): void
    {
        $token = $this->login('ACME', 'rahim');
        $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])->call('get', 'api/mobile/v1/payslips/nonexistent-slip-999');
        $this->assertSame(404, $res->response()->getStatusCode());

        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success']);
        $this->assertSame('error', $json['status']);
        $this->assertSame('Payslip not found.', $json['message']);
        $this->assertArrayHasKey('errors', $json);
    }

    /**
     * Test 7: Validation failure returns standard 422 error envelope
     */
    public function testValidationFailureReturnsStandard422ErrorEnvelope(): void
    {
        $token = $this->login('ACME', 'rahim');

        // Invalid date format
        $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])
            ->call('get', 'api/mobile/v1/attendance/history?from=not-a-date&to=2026-10-31');
        $this->assertSame(422, $res->response()->getStatusCode());

        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success']);
        $this->assertSame('error', $json['status']);
        $this->assertSame('from/to must be strict YYYY-MM-DD.', $json['message']);
        $this->assertArrayHasKey('errors', $json);

        // Date range inverted
        $resInverted = $this->withHeaders(['Authorization' => "Bearer {$token}"])
            ->call('get', 'api/mobile/v1/attendance/history?from=2026-10-31&to=2026-10-01');
        $this->assertSame(422, $resInverted->response()->getStatusCode());

        $jsonInverted = json_decode($resInverted->getJSON(), true);
        $this->assertFalse($jsonInverted['success']);
        $this->assertSame('error', $jsonInverted['status']);
        $this->assertSame('from cannot be after to.', $jsonInverted['message']);
        $this->assertArrayHasKey('errors', $jsonInverted);
    }

    /**
     * Test 8: Field-level validation returns errors dictionary in contract format
     */
    public function testFieldValidationErrorsReturnedInContractFormat(): void
    {
        $token = $this->login('ACME', 'rahim');
        $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])
            ->withBodyFormat('json')
            ->call('post', 'api/mobile/v1/auth/change-password', [
                'current_password' => '',
                'new_password'     => 'NewValid#P@ss2026',
                'confirm_password' => 'NewValid#P@ss2026',
            ]);
        $this->assertSame(422, $res->response()->getStatusCode());

        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success']);
        $this->assertSame('error', $json['status']);
        $this->assertSame('Current password is required.', $json['message']);
        $this->assertArrayHasKey('errors', $json);
        $this->assertArrayHasKey('current_password', $json['errors']);
        $this->assertSame('Current password is required.', $json['errors']['current_password']);
    }

    /**
     * Test 9: Rate limiting error envelope includes 429 and Retry-After
     */
    public function testRateLimitResponseIncludes429AndHeader(): void
    {
        $resp = ApiResponseTrait::createErrorResponse(
            'Too many requests. Please try again later.',
            429,
            [],
            ['retry_after' => 60],
            ['Retry-After' => '60']
        );

        $this->assertSame(429, $resp->response()->getStatusCode());
        $this->assertTrue($resp->hasHeader('Retry-After'));
        $this->assertSame('60', $resp->getHeaderLine('Retry-After'));

        $json = json_decode($resp->getBody(), true);
        $this->assertFalse($json['success']);
        $this->assertSame('error', $json['status']);
        $this->assertSame(60, $json['retry_after']);
        $this->assertArrayHasKey('errors', $json);
    }

    /**
     * Test 10: SQL errors and tokens are masked from client responses
     */
    public function testDatabaseErrorAndTokenSanitization(): void
    {
        // Raw SQL syntax error should be suppressed
        $sanitizedSql = ApiResponseTrait::sanitizeErrorMessage("SQLSTATE[HY000]: General error near 'SELECT * FROM users'");
        $this->assertSame('A database error occurred. Please contact your system administrator.', $sanitizedSql);
        $this->assertStringNotContainsString('SQLSTATE', $sanitizedSql);
        $this->assertStringNotContainsString('SELECT', $sanitizedSql);

        // Bearer tokens in error messages should be redacted
        $sanitizedToken = ApiResponseTrait::sanitizeErrorMessage('Failed for token mat_0123456789abcdef0123456789abcdef due to timeout');
        $this->assertStringNotContainsString('mat_0123456789abcdef', $sanitizedToken);
        $this->assertStringContainsString('mat_[REDACTED]', $sanitizedToken);
    }
}
