<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class AuthenticationTest extends TestCase
{
    public function testPasswordBackdoorsAreStrictlyForbidden()
    {
        $backdoorPasswords = ['123456', 'admin123', 'password123'];
        $correctHash = password_hash('SecretSecurePassword!2026', PASSWORD_BCRYPT);

        foreach ($backdoorPasswords as $badPassword) {
            $isMatch = password_verify($badPassword, $correctHash);
            $this->assertFalse($isMatch, "Backdoor password '{$badPassword}' MUST NOT validate against legitimate user hash!");
        }

        $validMatch = password_verify('SecretSecurePassword!2026', $correctHash);
        $this->assertTrue($validMatch, "Legitimate password MUST validate successfully.");
    }

    public function testAccountLockoutThresholdEvaluation()
    {
        $maxAttempts = 5;
        $failedAttempts = 5;
        $lockoutDuration = 15 * 60; // 15 mins
        $currentTime = time();
        $lockedUntil = date('Y-m-d H:i:s', $currentTime + $lockoutDuration);

        // Check if locked
        $isLocked = ($failedAttempts >= $maxAttempts) && (strtotime($lockedUntil) > $currentTime);
        $this->assertTrue($isLocked, "Account MUST be marked locked when failed attempts hit threshold.");

        // Check expired lockout
        $expiredLockTime = date('Y-m-d H:i:s', $currentTime - 60);
        $isExpiredLocked = ($failedAttempts >= $maxAttempts) && (strtotime($expiredLockTime) > $currentTime);
        $this->assertFalse($isExpiredLocked, "Account MUST unlock automatically after lockout duration elapses.");
    }

    public function testTwoFactorOtpVerification()
    {
        $secretKey = 'JBSWY3DPEHPK3PXP'; // Base32 test secret
        $expectedOtp = '482910';
        $userEnteredWrong = '111111';

        $this->assertNotEquals($expectedOtp, $userEnteredWrong, "Invalid 2FA OTP must be rejected.");
        $this->assertEquals(6, strlen($expectedOtp), "2FA OTP code must be 6 digits.");
    }

    /**
     * A protected URL with 'push-punch' in the query string must still require login.
     * Ensure AuthFilter does not allow URI query substrings to skip authentication.
     */
    public function testProtectedUrlWithPushPunchInQueryStringRequiresLogin()
    {
        $appPath = dirname(__DIR__, 2) . '/app/';
        $authFilterContent = file_get_contents($appPath . 'Filters/AuthFilter.php');

        // Verify the insecure str_contains bypasses on URI substrings are removed
        $this->assertStringNotContainsString(
            "str_contains(\$uri, 'api/attendance/push-punch')",
            $authFilterContent,
            "AuthFilter MUST NOT skip authentication based on substring match of 'api/attendance/push-punch'"
        );
        $this->assertStringNotContainsString(
            "str_contains(\$uri, 'attendance/sync/api')",
            $authFilterContent,
            "AuthFilter MUST NOT skip authentication based on substring match of 'attendance/sync/api'"
        );

        // Verify device API key query string fallback is removed
        $syncControllerContent = file_get_contents($appPath . 'Controllers/Attendance/AttendanceSyncController.php');
        $this->assertStringNotContainsString(
            "\$this->request->getGet('key')",
            $syncControllerContent,
            "AttendanceSyncController::enrollTemplate MUST NOT accept API key from ?key= query string"
        );
        $this->assertStringNotContainsString(
            "\$this->request->getGet('api_key')",
            $syncControllerContent,
            "AttendanceSyncController::enrollTemplate MUST NOT accept API key from ?api_key= query string"
        );

        // Verify sync/api/push-punch is not inside the attendance auth group
        $routesContent = file_get_contents($appPath . 'Config/Routes.php');
        $this->assertDoesNotMatchRegularExpression(
            '/\$routes->group\(\s*\'attendance\'\s*,\s*\[\'filter\'\s*=>\s*\'auth\'\].*?\$routes->post\(\s*\'sync\/api\/push-punch\'/s',
            $routesContent,
            "Routes.php MUST NOT place 'sync/api/push-punch' inside the session-authenticated attendance route group"
        );
    }

    /**
     * Verify 2FA OTP hashing, attempt limiting, constant-time comparison,
     * view privacy (no simulated_otp), session regeneration, and failure auditing.
     */
    public function testTwoFactorSecurityInvariants()
    {
        $appPath = dirname(__DIR__, 2) . '/app/';
        $authControllerContent = file_get_contents($appPath . 'Controllers/Auth/AuthController.php');

        // 1. Verify simulated_otp is NEVER passed to the view
        $this->assertStringNotContainsString(
            "'simulated_otp'",
            $authControllerContent,
            "AuthController MUST NOT pass 'simulated_otp' to any view"
        );

        // 2. Verify OTP is hashed using SHA-256 before storage
        $this->assertStringContainsString(
            "hash('sha256', \$otp)",
            $authControllerContent,
            "AuthController MUST store SHA-256 hash of OTP"
        );
        $this->assertStringContainsString(
            "'2fa_otp_hash'",
            $authControllerContent,
            "AuthController MUST store OTP hash under '2fa_otp_hash' in session"
        );

        // 3. Verify constant-time comparison with hash_equals
        $this->assertStringContainsString(
            "hash_equals(\$sessionOtpHash, \$inputHash)",
            $authControllerContent,
            "AuthController MUST verify OTP hash using constant-time hash_equals()"
        );

        // 4. Verify 5-minute expiry (300 seconds)
        $this->assertStringContainsString(
            "time() + 300",
            $authControllerContent,
            "AuthController MUST enforce 5-minute (300 second) OTP expiration"
        );

        // 5. Verify 5 attempts limit
        $this->assertStringContainsString(
            "\$attempts > 5",
            $authControllerContent,
            "AuthController MUST enforce a maximum of 5 verification attempts"
        );

        // 6. Verify session regeneration on successful 2FA and successful login
        $this->assertStringContainsString(
            "session()->regenerate(true)",
            $authControllerContent,
            "AuthController MUST call session()->regenerate(true) to prevent session fixation"
        );

        // 7. Verify failure audit logging
        $this->assertStringContainsString(
            "\$this->auditService->log(",
            $authControllerContent,
            "AuthController MUST audit-log failures"
        );

        // 8. Test hash_equals behavior with matching and non-matching OTP hashes
        $generatedOtp = '739201';
        $storedHash = hash('sha256', $generatedOtp);
        $correctInputHash = hash('sha256', '739201');
        $wrongInputHash = hash('sha256', '000000');

        $this->assertTrue(hash_equals($storedHash, $correctInputHash), 'Valid OTP hash must match via hash_equals.');
        $this->assertFalse(hash_equals($storedHash, $wrongInputHash), 'Invalid OTP hash must fail via hash_equals.');
    }

    /**
     * Verify logout and switchPersona / stopImpersonation security invariants:
     * - POST-only with CSRF protection
     * - Stores original_user_id in session while impersonating
     * - Audit log entries written on impersonation start and end (recording actor, target, and IP)
     * - Visible impersonation banner rendered in main layout
     * - Only platform admin may impersonate, never another platform admin, and never a role with is_system=1 and company_id IS NULL
     * - Session ID regenerated via session()->regenerate(true) on switch
     */
    public function testLogoutAndImpersonationSecurityInvariants()
    {
        $appPath = dirname(__DIR__, 2) . '/app/';
        $authControllerContent = file_get_contents($appPath . 'Controllers/Auth/AuthController.php');
        $routesContent = file_get_contents($appPath . 'Config/Routes.php');
        $mainLayoutContent = file_get_contents($appPath . 'Views/layouts/main.php');
        $navbarContent = file_get_contents($appPath . 'Views/partials/navbar.php');

        // 1. Routes must be POST (no GET routes for logout, switch-persona, or stop-impersonation)
        $this->assertDoesNotMatchRegularExpression(
            '/\$routes->get\(\s*[\'"](auth\/)?(logout|switch-persona|stop-impersonation)/i',
            $routesContent,
            'Logout and persona switching routes MUST NOT accept GET requests.'
        );
        $this->assertStringContainsString(
            "\$routes->post('auth/logout', 'Auth\\AuthController::logout')",
            $routesContent,
            'auth/logout MUST be registered as a POST route.'
        );
        $this->assertStringContainsString(
            "\$routes->post('auth/switch-persona/(:segment)', 'Auth\\AuthController::switchPersona/\$1'",
            $routesContent,
            'auth/switch-persona MUST be registered as a POST route.'
        );
        $this->assertStringContainsString(
            "\$routes->post('auth/stop-impersonation', 'Auth\\AuthController::stopImpersonation')",
            $routesContent,
            'auth/stop-impersonation MUST be registered as a POST route.'
        );

        // 2. Controller methods enforce POST method check
        $this->assertGreaterThanOrEqual(
            3,
            substr_count($authControllerContent, "strtolower(\$this->request->getMethod()) !== 'post'"),
            'logout, switchPersona, and stopImpersonation MUST explicitly reject non-POST requests.'
        );

        // 3. Session tracks original_user_id during impersonation
        $this->assertStringContainsString(
            "'original_user_id'",
            $authControllerContent,
            'switchPersona MUST store original_user_id in session while impersonating.'
        );

        // 4. Audit logs written on impersonation start and end with actor, target, and IP
        $this->assertStringContainsString(
            "'Impersonation Started'",
            $authControllerContent,
            'switchPersona MUST write an Impersonation Started audit log entry.'
        );
        $this->assertStringContainsString(
            "'Impersonation Ended'",
            $authControllerContent,
            'stopImpersonation and logout while impersonating MUST write an Impersonation Ended audit log entry.'
        );

        // 5. Only platform admin may impersonate, never another platform admin, and never is_system with company_id IS NULL
        $this->assertStringContainsString(
            "\$canonicalRole === 'software_app_admin'",
            $authControllerContent,
            'switchPersona MUST block impersonating another platform admin.'
        );
        $this->assertStringContainsString(
            "\$targetRoleIsSystem && \$targetRoleCompanyId === ''",
            $authControllerContent,
            'switchPersona MUST block impersonating any role that has is_system=1 with company_id IS NULL.'
        );

        // 6. Session ID regenerated on switch
        $this->assertGreaterThanOrEqual(
            4,
            substr_count($authControllerContent, 'session()->regenerate(true)'),
            'AuthController MUST regenerate session ID on login, 2FA, switchPersona, and stopImpersonation.'
        );

        // 7. Visible impersonation banner in layout and CSRF-protected POST forms
        $this->assertStringContainsString(
            'id="impersonation-banner"',
            $mainLayoutContent,
            'layouts/main.php MUST render a visible impersonation banner when original_user_id is set in session.'
        );
        $this->assertStringContainsString(
            "base_url('auth/stop-impersonation')",
            $mainLayoutContent,
            'layouts/main.php impersonation banner MUST provide a POST form to auth/stop-impersonation.'
        );
        $this->assertStringContainsString(
            "base_url('auth/switch-persona/'",
            $navbarContent,
            'navbar.php MUST submit switch-persona via POST form.'
        );
        $this->assertStringContainsString(
            'csrf_field()',
            $navbarContent,
            'navbar.php forms MUST include csrf_field().'
        );
    }

    /**
     * Verify Session, Security, Cookie, env/env.example, and .gitignore security invariants.
     */
    public function testSessionSecurityCookieAndEnvInvariants()
    {
        $rootPath = dirname(__DIR__, 2) . '/';
        $appPath = $rootPath . 'app/';

        // 1. Session.php invariants
        $sessionConfigContent = file_get_contents($appPath . 'Config/Session.php');
        $this->assertStringContainsString('public int $expiration = 7200;', $sessionConfigContent);
        $this->assertStringContainsString('public bool $regenerateDestroy = true;', $sessionConfigContent);
        $this->assertStringContainsString("env('session.expiration', env('app.sessionExpiration'))", $sessionConfigContent);
        $this->assertStringContainsString("env('session.regenerateDestroy', env('app.sessionRegenerateDestroy'))", $sessionConfigContent);
        $this->assertStringContainsString("env('session.matchIP', env('app.sessionMatchIP'))", $sessionConfigContent);
        $this->assertStringContainsString('public bool $bindUserAgent = true;', $sessionConfigContent);

        // 2. Security.php invariants
        $securityConfigContent = file_get_contents($appPath . 'Config/Security.php');
        $this->assertStringContainsString('public bool $tokenRandomize = true;', $securityConfigContent);
        $this->assertStringContainsString('public bool $regenerate = true;', $securityConfigContent);

        // 3. Cookie.php invariants
        $cookieConfigContent = file_get_contents($appPath . 'Config/Cookie.php');
        $this->assertStringContainsString("'https://'", $cookieConfigContent);
        $this->assertStringContainsString('$this->secure = true;', $cookieConfigContent);

        // 4. env and env.example invariants
        $this->assertFileExists($rootPath . 'env.example');
        foreach (['env', 'env.example'] as $envFile) {
            $envContent = file_get_contents($rootPath . $envFile);
            $this->assertStringContainsString('CI_ENVIRONMENT = production', $envContent);
            $this->assertStringNotContainsString('CI_ENVIRONMENT = development', $envContent);
            $this->assertDoesNotMatchRegularExpression('/^\s*database\.default\.username\s*=\s*root\s*$/m', $envContent);
            $this->assertDoesNotMatchRegularExpression('/^\s*database\.default\.password\s*=\s*$/m', $envContent);
            $this->assertDoesNotMatchRegularExpression('/^\s*app\.baseURL\s*=\s*[\'"]?http:\/\//m', $envContent);
            $this->assertStringContainsString('security.tokenRandomize = true', $envContent);
            $this->assertStringContainsString('security.regenerate = true', $envContent);
        }

        // 5. .gitignore invariants
        $this->assertFileExists($rootPath . '.gitignore');
        $gitignoreContent = file_get_contents($rootPath . '.gitignore');
        $this->assertMatchesRegularExpression('/^\.env\s*$/m', $gitignoreContent);
    }
}


