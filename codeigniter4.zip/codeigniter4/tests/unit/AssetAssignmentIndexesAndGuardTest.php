<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class AssetAssignmentIndexesAndGuardTest extends TestCase
{
    /**
     * Test migration class exists and implements up() and down()
     */
    public function testMigrationClassExists()
    {
        $migrationClass = '\App\Database\Migrations\AddAssetAssignmentIndexesAndOpenAssignmentGuard';
        $this->assertTrue(class_exists($migrationClass), "Migration class AddAssetAssignmentIndexesAndOpenAssignmentGuard must exist.");

        $ref = new \ReflectionClass($migrationClass);
        $this->assertTrue($ref->hasMethod('up'), "Migration must have up() method.");
        $this->assertTrue($ref->hasMethod('down'), "Migration must have down() method.");
    }

    /**
     * Test duplicate open assignment resolution logic
     */
    public function testDuplicateOpenAssignmentDeduplicationLogic()
    {
        $assetId = 'ast-laptop-001';

        // Simulated duplicate open assignments (returned_date is NULL)
        $assignments = [
            [
                'id'            => 'asgn-old',
                'asset_id'      => $assetId,
                'assigned_date' => '2026-01-10',
                'created_at'    => '2026-01-10 10:00:00',
                'returned_date' => null,
                'notes'         => 'Initial assignment',
            ],
            [
                'id'            => 'asgn-newest',
                'asset_id'      => $assetId,
                'assigned_date' => '2026-03-15',
                'created_at'    => '2026-03-15 14:00:00',
                'returned_date' => null,
                'notes'         => 'Reassignment without closing previous',
            ],
        ];

        // Sort by assigned_date DESC, created_at DESC
        usort($assignments, function ($a, $b) {
            $cmp = strcmp($b['assigned_date'], $a['assigned_date']);
            return $cmp !== 0 ? $cmp : strcmp($b['created_at'], $a['created_at']);
        });

        // The first element is the one to keep open
        $keepId = $assignments[0]['id'];
        $this->assertEquals('asgn-newest', $keepId, "Most recent assignment should be preserved as open.");

        // Older elements must be closed
        $toClose = array_slice($assignments, 1);
        $this->assertCount(1, $toClose);
        $this->assertEquals('asgn-old', $toClose[0]['id']);

        $closeDate = $toClose[0]['assigned_date'] ?: date('Y-m-d');
        $this->assertEquals('2026-01-10', $closeDate);
    }

    /**
     * Test virtual generated column expression for unique open assignments
     */
    public function testVirtualColumnUniqueLogic()
    {
        // Formula: CASE WHEN returned_date IS NULL THEN asset_id ELSE NULL END
        $evaluateOpenAssetId = function (?string $assetId, ?string $returnedDate): ?string {
            return ($returnedDate === null || $returnedDate === '') ? $assetId : null;
        };

        $assetA = 'ast-001';
        $assetB = 'ast-002';

        // 1. Open assignment for assetA produces assetA's ID
        $this->assertEquals($assetA, $evaluateOpenAssetId($assetA, null));

        // 2. Closed assignment for assetA produces NULL
        $this->assertNull($evaluateOpenAssetId($assetA, '2026-02-01'));

        // 3. Two open assignments for assetA produce identical values (violating UNIQUE)
        $open1 = $evaluateOpenAssetId($assetA, null);
        $open2 = $evaluateOpenAssetId($assetA, null);
        $this->assertEquals($open1, $open2, "Two open assignments for same asset yield duplicate non-null key, violating UNIQUE constraint.");

        // 4. Two returned assignments for assetA produce NULLs (permitted in UNIQUE indexes)
        $closed1 = $evaluateOpenAssetId($assetA, '2026-01-01');
        $closed2 = $evaluateOpenAssetId($assetA, '2026-02-01');
        $this->assertNull($closed1);
        $this->assertNull($closed2);

        // 5. Open assignment for assetB produces assetB's ID (unique from assetA)
        $openB = $evaluateOpenAssetId($assetB, null);
        $this->assertNotEquals($open1, $openB);
    }

    /**
     * Test AssetAssignmentModel recordAssignment throws on open assignment
     */
    public function testRecordAssignmentGuardExceptionBehavior()
    {
        $assetId = 'ast-locked-001';
        $existingActive = [
            'id'            => 'asgn-active-99',
            'asset_id'      => $assetId,
            'returned_date' => null
        ];

        $guard = function (?array $activeAssignment, string $assetId) {
            if ($activeAssignment) {
                throw new \RuntimeException("Asset [{$assetId}] already has an active open assignment (ID: {$activeAssignment['id']}). Multiple open assignments are prohibited.");
            }
            return true;
        };

        // When active exists, must throw RuntimeException
        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage("Asset [{$assetId}] already has an active open assignment");

        $guard($existingActive, $assetId);
    }
}
