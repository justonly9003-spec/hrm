<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\DashboardWidgetRegistry;

/**
 * Final Verification Test Suite for Phase 2 & Phase 3:
 * - Category-Based Dashboard Navigation (Overview, Attendance & Shifts, Leaves & Roster, Payroll & Compliance)
 * - Asynchronous Lazy Loading with Scoped Query Execution
 * - Role-Based Access Control (Company Admin, HR Admin, Manager, Employee)
 * - Scope IDOR Defenses (Branch / Department / Cross-Company)
 * - Widget Registry Integrity (All 39 catalog widgets)
 */
class DashboardCategoryLazyLoadingTest extends TestCase
{
    /**
     * Test 1: Verify all 4 category groups exist with correct metadata and icons.
     */
    public function testCategoryGroupsMetadata()
    {
        $groups = DashboardWidgetRegistry::getCategoryGroups();

        $this->assertCount(4, $groups, "Exactly 4 dashboard categories must exist.");
        $this->assertArrayHasKey(DashboardWidgetRegistry::CATEGORY_GROUP_OVERVIEW, $groups);
        $this->assertArrayHasKey(DashboardWidgetRegistry::CATEGORY_GROUP_ATTENDANCE, $groups);
        $this->assertArrayHasKey(DashboardWidgetRegistry::CATEGORY_GROUP_LEAVES, $groups);
        $this->assertArrayHasKey(DashboardWidgetRegistry::CATEGORY_GROUP_PAYROLL, $groups);

        $this->assertEquals('Overview', $groups['overview']['title']);
        $this->assertEquals('Attendance & Shifts', $groups['attendance']['title']);
        $this->assertEquals('Leaves & Roster', $groups['leaves']['title']);
        $this->assertEquals('Payroll & Compliance', $groups['payroll']['title']);
    }

    /**
     * Test 2: Verify all 39 widgets in getMasterCatalog() resolve to an approved category without orphans.
     */
    public function testAll39CatalogWidgetsMapToApprovedCategory()
    {
        $catalog = DashboardWidgetRegistry::getMasterCatalog();
        $this->assertCount(39, $catalog, "Master catalog must contain exactly 39 widgets.");

        $validCategories = [
            DashboardWidgetRegistry::CATEGORY_GROUP_OVERVIEW,
            DashboardWidgetRegistry::CATEGORY_GROUP_ATTENDANCE,
            DashboardWidgetRegistry::CATEGORY_GROUP_LEAVES,
            DashboardWidgetRegistry::CATEGORY_GROUP_PAYROLL,
        ];

        $counts = [
            'overview'   => 0,
            'attendance' => 0,
            'leaves'     => 0,
            'payroll'    => 0,
        ];

        foreach ($catalog as $key => $widget) {
            $code = $widget['code'];
            $id   = $widget['id'];

            // Resolving by code
            $catByCode = DashboardWidgetRegistry::resolveCategoryGroup($code);
            $this->assertContains($catByCode, $validCategories, "Widget code '{$code}' must map to valid category.");

            // Resolving by ID
            $catById = DashboardWidgetRegistry::resolveCategoryGroup($id);
            $this->assertContains($catById, $validCategories, "Widget ID '{$id}' must map to valid category.");
            $this->assertEquals($catByCode, $catById, "Widget '{$code}' category by code and ID must match.");

            $counts[$catByCode]++;
        }

        // Assert exact distributions
        $this->assertEquals(16, $counts['overview'], "Overview category must contain 16 catalog widgets.");
        $this->assertEquals(16, $counts['attendance'], "Attendance category must contain 16 catalog widgets.");
        $this->assertEquals(3, $counts['leaves'], "Leaves category must contain 3 catalog widgets.");
        $this->assertEquals(4, $counts['payroll'], "Payroll category must contain 4 catalog widgets.");
        $this->assertEquals(39, array_sum($counts), "Sum of category widgets must equal 39.");
    }

    /**
     * Test 3: Verify RBAC Role Widget Partitioning for all approved roles.
     */
    public function testRoleWidgetPartitioning()
    {
        $catalog = DashboardWidgetRegistry::getMasterCatalog();

        // 1. Employee
        $empWidgets = array_filter($catalog, fn($w) => in_array('employee', $w['target_roles'], true));
        $this->assertCount(6, $empWidgets, "Employee role must have access to exactly 6 authorized widgets.");
        $empCategories = array_map(fn($w) => DashboardWidgetRegistry::resolveCategoryGroup($w['code']), $empWidgets);
        $empCatCounts = array_count_values($empCategories);
        $this->assertEquals(3, $empCatCounts['overview'] ?? 0, "Employee must have 3 overview widgets.");
        $this->assertEquals(1, $empCatCounts['attendance'] ?? 0, "Employee must have 1 attendance widget (clock card).");
        $this->assertEquals(2, $empCatCounts['leaves'] ?? 0, "Employee must have 2 leave widgets.");
        $this->assertArrayNotHasKey('payroll', $empCatCounts, "Employee must NOT have access to payroll category.");

        // 2. Department Manager
        $mgrWidgets = array_filter($catalog, fn($w) => in_array('manager', $w['target_roles'], true));
        $this->assertCount(23, $mgrWidgets, "Manager role must have access to 23 authorized widgets.");

        // 3. HR Admin
        $hrWidgets = array_filter($catalog, fn($w) => in_array('hr_admin', $w['target_roles'], true));
        $this->assertCount(27, $hrWidgets, "HR Admin role must have access to 27 authorized widgets.");

        // 4. Company Admin
        $adminWidgets = array_filter($catalog, fn($w) => in_array('company_admin', $w['target_roles'], true));
        $this->assertCount(29, $adminWidgets, "Company Admin role must have access to 29 authorized widgets.");
    }

    /**
     * Test 4: Verify Department Manager Cross-Department Scope IDOR Defense.
     */
    public function testManagerCrossDepartmentScopeBlocked()
    {
        $managerRole = 'manager';
        $managerCompanyId = 'comp-tenant-01';
        $managerDeptId = 'dept-engineering-01';

        // Attack: Manager passes department_id of Sales
        $requestedDeptId = 'dept-sales-02';
        $isAuthorized = ($requestedDeptId === $managerDeptId);
        $this->assertFalse($isAuthorized, "Department Manager must NOT access another department.");

        // Attack: Manager attempts to view all departments
        $requestedDeptIdAll = 'all';
        $isAllAuthorized = ($managerRole !== 'manager' && $managerRole !== 'team_leader');
        $this->assertFalse($isAllAuthorized, "Department Manager cannot request all departments.");
    }

    /**
     * Test 5: Verify Multi-Tenant Company Isolation.
     */
    public function testCrossCompanyTenantIsolation()
    {
        $authenticatedCompanyId = 'comp-alpha-100';
        $tamperedCompanyId = 'comp-beta-200';

        $isTenantValid = ($authenticatedCompanyId === $tamperedCompanyId);
        $this->assertFalse($isTenantValid, "Cross-company tenant access must be rejected.");
    }

    /**
     * Test 6: Verify Category API Parameter Validation.
     */
    public function testCategoryParameterValidation()
    {
        $validCategories = [
            DashboardWidgetRegistry::CATEGORY_GROUP_OVERVIEW,
            DashboardWidgetRegistry::CATEGORY_GROUP_ATTENDANCE,
            DashboardWidgetRegistry::CATEGORY_GROUP_LEAVES,
            DashboardWidgetRegistry::CATEGORY_GROUP_PAYROLL,
        ];

        // Valid categories
        foreach ($validCategories as $cat) {
            $this->assertTrue(in_array($cat, $validCategories, true), "Category '{$cat}' must be recognized as valid.");
        }

        // Invalid categories
        $invalidCategories = ['unknown', 'admin', 'system', 'undefined', ''];
        foreach ($invalidCategories as $badCat) {
            $this->assertFalse(in_array($badCat, $validCategories, true), "Category '{$badCat}' must be rejected with 400.");
        }
    }

    /**
     * Test 7: Verify Widget Registry Attributes (Grid Width, Sort Order, Modules).
     */
    public function testWidgetAttributesIntegrity()
    {
        $catalog = DashboardWidgetRegistry::getMasterCatalog();
        $allowedWidths = ['full', 'half', 'third', 'two_thirds', 'quarter'];

        foreach ($catalog as $w) {
            $this->assertArrayHasKey('id', $w);
            $this->assertArrayHasKey('code', $w);
            $this->assertArrayHasKey('title', $w);
            $this->assertArrayHasKey('grid_width', $w);
            $this->assertContains($w['grid_width'], $allowedWidths, "Widget '{$w['code']}' must have valid grid_width.");
            $this->assertArrayHasKey('default_sort_order', $w);
            $this->assertIsInt($w['default_sort_order'], "Widget '{$w['code']}' must have integer default_sort_order.");
        }
    }
}
