<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\LeaveService;
use App\Services\Leave\LeaveApplicationService;
use App\Services\PermissionService;

class LeaveScopeFailClosedTest extends TestCase
{
    private array $sampleWorkflow;
    private array $targetEmp;

    protected function setUp(): void
    {
        parent::setUp();
        $this->sampleWorkflow = [
            'workflow_type'           => 'Multi-Tier',
            'auto_approve_under_days' => 0.0,
            'tier_conditions'         => [
                [
                    'min_days'           => 1,
                    'max_days'           => 2,
                    'required_approvers' => ['Manager'],
                ],
                [
                    'min_days'           => 3,
                    'max_days'           => 7,
                    'required_approvers' => ['Manager', 'HR Admin'],
                ],
            ],
        ];

        $this->targetEmp = [
            'id'                   => 'EMP-TARGET-01',
            'company_id'           => 'comp-alpha',
            'branch_id'            => 'BR-DHAKA',
            'department_id'        => 'DEPT-SALES',
            'reporting_manager_id' => 'EMP-MGR-DIRECT',
            'manager_id'           => 'EMP-MGR-DIRECT',
        ];
    }

    /**
     * Test 1: Permission service throws during the scope check -> denied (403), no approval happens.
     */
    public function testPermissionServiceThrowsDuringScopeCheckDenied403NoApprovalHappens()
    {
        $app = [
            'id'             => 'app-throw-01',
            'company_id'     => 'comp-alpha',
            'employee_id'    => 'EMP-TARGET-01',
            'total_days'     => 4.0,
            'manager_status' => 'Approved',
            'status'         => 'Pending',
        ];

        $approverUser = [
            'id'          => 'USR-HR-01',
            'user_id'     => 'USR-HR-01',
            'company_id'  => 'comp-alpha',
            'role_code'   => 'hr_officer',
            'permissions' => ['leave.hr_approve'],
        ];

        // Create a mock PermissionService that throws on can() or assertInScope()
        $throwingPermService = $this->createMock(PermissionService::class);
        $throwingPermService->method('canonicalizeRole')->willReturn('hr_officer');
        $throwingPermService->method('can')->willThrowException(new \RuntimeException('Simulated permission database error'));

        $fakeDb = new class {
            public function table($t) { return $this; }
            public function tableExists($t) { return false; }
        };

        $res = LeaveApplicationService::checkApprovalPolicy(
            $app,
            $this->targetEmp,
            $approverUser,
            null,
            'USR-HR-01',
            $this->sampleWorkflow,
            $throwingPermService,
            $fakeDb
        );

        $this->assertFalse($res['allowed'], 'Must fail closed when permission lookup throws');
        $this->assertEquals(403, $res['code']);
        $this->assertEquals('403 Forbidden: Unable to verify your authorized organizational scope.', $res['message']);
    }

    /**
     * Test 2: ApproverUser cannot be resolved -> denied (403).
     */
    public function testApproverUserCannotBeResolvedDenied403()
    {
        $app = [
            'id'             => 'app-no-user-01',
            'company_id'     => 'comp-alpha',
            'employee_id'    => 'EMP-TARGET-01',
            'total_days'     => 4.0,
            'manager_status' => 'Approved',
            'status'         => 'Pending',
        ];

        // No approverUser provided and no database to resolve it
        $res = LeaveApplicationService::checkApprovalPolicy(
            $app,
            $this->targetEmp,
            null,
            null,
            'NON_EXISTENT_APPROVER',
            $this->sampleWorkflow,
            null,
            null
        );

        $this->assertFalse($res['allowed'], 'Must deny with 403 when approver user cannot be resolved');
        $this->assertEquals(403, $res['code']);
        $this->assertStringContainsString('Unable to verify your authorized organizational scope', $res['message']);
    }

    /**
     * Test 3: Approver in another branch with branch scope -> denied (403).
     */
    public function testApproverInAnotherBranchWithBranchScopeDenied403()
    {
        $app = [
            'id'             => 'app-branch-mismatch-01',
            'company_id'     => 'comp-alpha',
            'employee_id'    => 'EMP-TARGET-01',
            'total_days'     => 4.0,
            'manager_status' => 'Approved',
            'status'         => 'Pending',
        ];

        // Approver in Chittagong branch with branch scope
        $approverUser = [
            'id'            => 'USR-HR-CTG',
            'company_id'    => 'comp-alpha',
            'role_code'     => 'hr_officer',
            'scope'         => 'branch',
            'branch_id'     => 'BR-CHITTAGONG',
            'department_id' => 'DEPT-HR',
            'permissions'   => ['leave.hr_approve'],
        ];

        $res = LeaveApplicationService::checkApprovalPolicy(
            $app,
            $this->targetEmp,
            $approverUser,
            null,
            'USR-HR-CTG',
            $this->sampleWorkflow,
            null,
            null
        );

        $this->assertFalse($res['allowed'], 'Approver in a different branch with branch scope must be denied');
        $this->assertEquals(403, $res['code']);
        $this->assertEquals('403 Forbidden: Target employee is outside your authorized organizational scope.', $res['message']);
    }

    /**
     * Test 4: Approver with company scope -> allowed (200).
     */
    public function testApproverWithCompanyScopeAllowed200()
    {
        $app = [
            'id'             => 'app-company-scope-01',
            'company_id'     => 'comp-alpha',
            'employee_id'    => 'EMP-TARGET-01',
            'total_days'     => 4.0,
            'manager_status' => 'Approved',
            'status'         => 'Pending',
        ];

        $approverUser = [
            'id'            => 'USR-HR-CORP',
            'company_id'    => 'comp-alpha',
            'role_code'     => 'hr_officer',
            'scope'         => 'company',
            'branch_id'     => 'BR-HEADQUARTERS',
            'department_id' => 'DEPT-HR',
            'permissions'   => ['leave.hr_approve'],
        ];

        $res = LeaveApplicationService::checkApprovalPolicy(
            $app,
            $this->targetEmp,
            $approverUser,
            null,
            'USR-HR-CORP',
            $this->sampleWorkflow,
            null,
            null
        );

        $this->assertTrue($res['allowed'], 'Approver with company scope must be allowed');
        $this->assertEquals(200, $res['code']);
    }

    /**
     * Test 5: software_app_admin -> allowed (200).
     */
    public function testSoftwareAppAdminAllowed200()
    {
        $app = [
            'id'             => 'app-admin-01',
            'company_id'     => 'comp-alpha',
            'employee_id'    => 'EMP-TARGET-01',
            'total_days'     => 4.0,
            'manager_status' => 'Approved',
            'status'         => 'Pending',
        ];

        $adminUser = [
            'id'          => 'USR-SUPER-ADMIN',
            'company_id'  => 'comp-global-platform',
            'role_code'   => 'software_app_admin',
            'permissions' => ['*'],
        ];

        $res = LeaveApplicationService::checkApprovalPolicy(
            $app,
            $this->targetEmp,
            $adminUser,
            null,
            'USR-SUPER-ADMIN',
            $this->sampleWorkflow,
            null,
            null
        );

        $this->assertTrue($res['allowed'], 'software_app_admin must be allowed regardless of branch/company isolation');
        $this->assertEquals(200, $res['code']);
    }

    /**
     * Test 6: The manager-only branch and the HR branch give the same result for the same out-of-scope approver.
     */
    public function testManagerOnlyBranchAndHrBranchGiveSameResultForSameOutOfScopeApprover()
    {
        // Approver in Chittagong branch and IT department (target is in Dhaka branch and Sales department)
        $outOfScopeUser = [
            'id'            => 'USR-CROSS-ORG',
            'company_id'    => 'comp-alpha',
            'role_code'     => 'line_manager',
            'branch_id'     => 'BR-CHITTAGONG',
            'department_id' => 'DEPT-IT',
            'permissions'   => ['leave.approve', 'leave.hr_approve'],
        ];

        // 1. Manager-only tier (1.5 days duration)
        $app1Day = [
            'id'          => 'app-1day-01',
            'company_id'  => 'comp-alpha',
            'employee_id' => 'EMP-TARGET-01',
            'total_days'  => 1.5,
            'status'      => 'Pending',
        ];
        $resManagerOnly = LeaveApplicationService::checkApprovalPolicy(
            $app1Day,
            $this->targetEmp,
            $outOfScopeUser,
            null,
            'USR-CROSS-ORG',
            $this->sampleWorkflow,
            null,
            null
        );

        // 2. HR tier (5.0 days duration, Tier 1 supervisor endorsement already granted)
        $app5Day = [
            'id'             => 'app-5day-01',
            'company_id'     => 'comp-alpha',
            'employee_id'    => 'EMP-TARGET-01',
            'total_days'     => 5.0,
            'manager_status' => 'Approved',
            'status'         => 'Pending',
        ];
        $resHrTier = LeaveApplicationService::checkApprovalPolicy(
            $app5Day,
            $this->targetEmp,
            $outOfScopeUser,
            null,
            'USR-CROSS-ORG',
            $this->sampleWorkflow,
            null,
            null
        );

        // Assert both branches returned denied (403)
        $this->assertFalse($resManagerOnly['allowed'], 'Manager-only tier must deny out-of-scope approver');
        $this->assertFalse($resHrTier['allowed'], 'HR tier must deny out-of-scope approver');

        // Assert identical code and message (zero drift)
        $this->assertEquals($resManagerOnly['code'], $resHrTier['code'], 'Both branches must return identical HTTP status code 403');
        $this->assertEquals($resManagerOnly['message'], $resHrTier['message'], 'Both branches must return identical fail-closed denial message');
        $this->assertEquals('403 Forbidden: Target employee is outside your authorized organizational scope.', $resManagerOnly['message']);
    }
}
