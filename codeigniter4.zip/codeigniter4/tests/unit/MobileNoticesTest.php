<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobileNoticesTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;
    private array $device = ['device_uid' => 'dev-notice-test-1', 'platform' => 'android'];

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);

        foreach (['notices'] as $t) {
            $this->db->query("DROP TABLE IF EXISTS {$t}");
        }

        $this->db->query("CREATE TABLE notices (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36) NOT NULL,
            branch_id VARCHAR(36) NULL,
            department_id VARCHAR(36) NULL,
            title VARCHAR(200) NOT NULL,
            content LONGTEXT NOT NULL,
            description TEXT NULL,
            type VARCHAR(50) DEFAULT 'Announcement',
            category VARCHAR(50) DEFAULT 'Announcement',
            is_pinned TINYINT(1) DEFAULT 0,
            published_at DATETIME NULL,
            published_date DATE NULL,
            expires_at DATE NULL,
            expiry_date DATE NULL,
            created_by VARCHAR(36) NULL,
            status VARCHAR(30) DEFAULT 'published',
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        // Set up organizational branches and departments
        $this->db->table('branches')->insert(['id' => 'br-1', 'name' => 'HQ Branch']);
        $this->db->table('branches')->insert(['id' => 'br-other', 'name' => 'Chittagong Branch']);
        $this->db->table('departments')->insert(['id' => 'dept-1', 'name' => 'Engineering']);
        $this->db->table('departments')->insert(['id' => 'dept-other', 'name' => 'Finance']);

        // Assign Rahim (e-1) to br-1 and dept-1
        $this->db->table('employees')->where('id', 'e-1')->update([
            'branch_id'     => 'br-1',
            'department_id' => 'dept-1',
        ]);
    }

    private function token(string $company = 'ACME', string $id = 'rahim'): array
    {
        $res = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => $company, 'identifier' => $id, 'password' => self::PASSWORD, 'device' => $this->device,
        ]);
        $json = json_decode($res->getJSON(), true);
        return ['Authorization' => 'Bearer ' . ($json['data']['tokens']['access_token'] ?? '')];
    }

    private function json($res): array
    {
        return json_decode($res->getJSON(), true) ?: [];
    }

    /**
     * Test 1: List notices returns only published, active notices for employee's company.
     * Excludes cross-tenant, draft, and archived notices.
     */
    public function testListNoticesReturnsOnlyPublishedActiveForCompany(): void
    {
        $token = $this->token('ACME', 'rahim'); // e-1, c-1

        $now = date('Y-m-d H:i:s');
        $today = date('Y-m-d');
        $future = date('Y-m-d', strtotime('+30 days'));

        $this->db->table('notices')->insertBatch([
            [
                'id'           => 'not-valid-1',
                'company_id'   => 'c-1',
                'title'        => 'Company Wide Townhall',
                'content'      => 'All employees must attend.',
                'status'       => 'published',
                'published_at' => $now,
                'expires_at'   => $future,
                'created_at'   => $now,
            ],
            [
                'id'           => 'not-draft-1',
                'company_id'   => 'c-1',
                'title'        => 'Draft Notice',
                'content'      => 'Still in review.',
                'status'       => 'draft',
                'published_at' => $now,
                'expires_at'   => $future,
                'created_at'   => $now,
            ],
            [
                'id'           => 'not-archived-1',
                'company_id'   => 'c-1',
                'title'        => 'Archived Notice',
                'content'      => 'Old archived circular.',
                'status'       => 'archived',
                'published_at' => $now,
                'expires_at'   => $future,
                'created_at'   => $now,
            ],
            [
                'id'           => 'not-cross-tenant',
                'company_id'   => 'c-2',
                'title'        => 'Other Company Notice',
                'content'      => 'Confidential for other company.',
                'status'       => 'published',
                'published_at' => $now,
                'expires_at'   => $future,
                'created_at'   => $now,
            ],
        ]);

        $res = $this->withHeaders($token)->call('get', 'api/mobile/v1/notices');
        $this->assertEquals(200, $res->response()->getStatusCode());
        $data = $this->json($res);

        $this->assertTrue($data['success']);
        $this->assertEquals(1, $data['data']['count']);
        $this->assertEquals(1, $data['data']['total']);
        $this->assertEquals('not-valid-1', $data['data']['notices'][0]['id']);
        $this->assertEquals('Company Wide Townhall', $data['data']['notices'][0]['title']);
    }

    /**
     * Test 2: Publication dates and expiry boundaries.
     * Future-dated scheduled notices and expired notices must be hidden.
     */
    public function testPublicationDatesAndExpiryVisibility(): void
    {
        $token = $this->token('ACME', 'rahim');

        $now = date('Y-m-d H:i:s');
        $pastDate = date('Y-m-d', strtotime('-5 days'));
        $futureDate = date('Y-m-d', strtotime('+5 days'));
        $futureDateTime = date('Y-m-d H:i:s', strtotime('+2 days'));

        $this->db->table('notices')->insertBatch([
            [
                'id'           => 'not-active-valid',
                'company_id'   => 'c-1',
                'title'        => 'Active Valid Notice',
                'content'      => 'Currently valid announcement.',
                'status'       => 'published',
                'published_at' => date('Y-m-d H:i:s', strtotime('-1 day')),
                'expires_at'   => $futureDate,
                'created_at'   => $now,
            ],
            [
                'id'           => 'not-no-expiry',
                'company_id'   => 'c-1',
                'title'        => 'Permanent Standing Policy',
                'content'      => 'No expiration date set.',
                'status'       => 'published',
                'published_at' => date('Y-m-d H:i:s', strtotime('-2 days')),
                'expires_at'   => null,
                'created_at'   => $now,
            ],
            [
                'id'           => 'not-future-scheduled',
                'company_id'   => 'c-1',
                'title'        => 'Future Scheduled Announcement',
                'content'      => 'Should not be seen yet.',
                'status'       => 'published',
                'published_at' => $futureDateTime,
                'expires_at'   => $futureDate,
                'created_at'   => $now,
            ],
            [
                'id'           => 'not-already-expired',
                'company_id'   => 'c-1',
                'title'        => 'Expired Event',
                'content'      => 'Event took place last week.',
                'status'       => 'published',
                'published_at' => date('Y-m-d H:i:s', strtotime('-10 days')),
                'expires_at'   => $pastDate,
                'created_at'   => $now,
            ],
        ]);

        $res = $this->withHeaders($token)->call('get', 'api/mobile/v1/notices');
        $this->assertEquals(200, $res->response()->getStatusCode());
        $data = $this->json($res);

        $returnedIds = array_column($data['data']['notices'], 'id');
        $this->assertContains('not-active-valid', $returnedIds);
        $this->assertContains('not-no-expiry', $returnedIds);
        $this->assertNotContains('not-future-scheduled', $returnedIds);
        $this->assertNotContains('not-already-expired', $returnedIds);
        $this->assertCount(2, $returnedIds);
    }

    /**
     * Test 3: Branch and department targeting visibility.
     * Rahim is in br-1 and dept-1.
     */
    public function testBranchAndDepartmentTargeting(): void
    {
        $token = $this->token('ACME', 'rahim');

        $now = date('Y-m-d H:i:s');
        $future = date('Y-m-d', strtotime('+30 days'));

        $this->db->table('notices')->insertBatch([
            [
                'id'            => 'not-global',
                'company_id'    => 'c-1',
                'branch_id'     => null,
                'department_id' => null,
                'title'         => 'Global Company Circular',
                'content'       => 'For all staff.',
                'status'        => 'published',
                'published_at'  => $now,
                'expires_at'    => $future,
            ],
            [
                'id'            => 'not-my-branch',
                'company_id'    => 'c-1',
                'branch_id'     => 'br-1',
                'department_id' => null,
                'title'         => 'HQ Branch Maintenance',
                'content'       => 'Lift service at HQ.',
                'status'        => 'published',
                'published_at'  => $now,
                'expires_at'    => $future,
            ],
            [
                'id'            => 'not-my-dept',
                'company_id'    => 'c-1',
                'branch_id'     => null,
                'department_id' => 'dept-1',
                'title'         => 'Engineering Sprint Retrospective',
                'content'       => 'For Engineering department.',
                'status'        => 'published',
                'published_at'  => $now,
                'expires_at'    => $future,
            ],
            [
                'id'            => 'not-other-branch',
                'company_id'    => 'c-1',
                'branch_id'     => 'br-other',
                'department_id' => null,
                'title'         => 'Chittagong Office Notice',
                'content'       => 'Chittagong only.',
                'status'        => 'published',
                'published_at'  => $now,
                'expires_at'    => $future,
            ],
            [
                'id'            => 'not-other-dept',
                'company_id'    => 'c-1',
                'branch_id'     => null,
                'department_id' => 'dept-other',
                'title'         => 'Finance Quarterly Audit',
                'content'       => 'Finance team only.',
                'status'        => 'published',
                'published_at'  => $now,
                'expires_at'    => $future,
            ],
        ]);

        $res = $this->withHeaders($token)->call('get', 'api/mobile/v1/notices');
        $this->assertEquals(200, $res->response()->getStatusCode());
        $data = $this->json($res);

        $returnedIds = array_column($data['data']['notices'], 'id');
        $this->assertContains('not-global', $returnedIds);
        $this->assertContains('not-my-branch', $returnedIds);
        $this->assertContains('not-my-dept', $returnedIds);
        $this->assertNotContains('not-other-branch', $returnedIds);
        $this->assertNotContains('not-other-dept', $returnedIds);
        $this->assertCount(3, $returnedIds);
    }

    /**
     * Test 4: Pinned notices ordering and pinned count.
     */
    public function testPinnedNoticesAppearFirstAndCounted(): void
    {
        $token = $this->token('ACME', 'rahim');

        $now = date('Y-m-d H:i:s');
        $future = date('Y-m-d', strtotime('+30 days'));

        $this->db->table('notices')->insertBatch([
            [
                'id'           => 'not-regular-new',
                'company_id'   => 'c-1',
                'title'        => 'Regular Announcement',
                'content'      => 'Posted recently.',
                'is_pinned'    => 0,
                'status'       => 'published',
                'published_at' => $now,
                'expires_at'   => $future,
                'created_at'   => $now,
            ],
            [
                'id'           => 'not-pinned-old',
                'company_id'   => 'c-1',
                'title'        => 'Executive Urgent Memo',
                'content'      => 'Pinned urgent memo.',
                'is_pinned'    => 1,
                'status'       => 'published',
                'published_at' => date('Y-m-d H:i:s', strtotime('-5 days')),
                'expires_at'   => $future,
                'created_at'   => date('Y-m-d H:i:s', strtotime('-5 days')),
            ],
        ]);

        $res = $this->withHeaders($token)->call('get', 'api/mobile/v1/notices');
        $this->assertEquals(200, $res->response()->getStatusCode());
        $data = $this->json($res);

        $this->assertEquals(1, $data['data']['pinned_count']);
        $this->assertEquals(2, $data['data']['total']);
        // Pinned notice must come first despite being older
        $this->assertEquals('not-pinned-old', $data['data']['notices'][0]['id']);
        $this->assertTrue($data['data']['notices'][0]['is_pinned']);
        $this->assertEquals('not-regular-new', $data['data']['notices'][1]['id']);
        $this->assertFalse($data['data']['notices'][1]['is_pinned']);
    }

    /**
     * Test 5: Detail endpoint returns complete notice with explicit fields.
     */
    public function testShowNoticeDetailsSuccess(): void
    {
        $token = $this->token('ACME', 'rahim');

        $now = date('Y-m-d H:i:s');
        $future = date('Y-m-d', strtotime('+15 days'));

        $this->db->table('notices')->insert([
            'id'           => 'not-detail-1',
            'company_id'   => 'c-1',
            'title'        => 'Health Insurance Open Enrollment',
            'content'      => 'Benefit enrollment window is now open until mid month.',
            'description'  => 'Benefit enrollment details.',
            'type'         => 'Circular',
            'category'     => 'Benefits',
            'is_pinned'    => 1,
            'published_at' => $now,
            'expires_at'   => $future,
            'created_by'   => 'e-1',
            'status'       => 'published',
            'created_at'   => $now,
        ]);

        $res = $this->withHeaders($token)->call('get', 'api/mobile/v1/notices/not-detail-1');
        $this->assertEquals(200, $res->response()->getStatusCode());
        $data = $this->json($res);

        $this->assertTrue($data['success']);
        $notice = $data['data']['notice'];

        $this->assertEquals('not-detail-1', $notice['id']);
        $this->assertEquals('c-1', $notice['company_id']);
        $this->assertEquals('Health Insurance Open Enrollment', $notice['title']);
        $this->assertStringContainsString('Benefit enrollment', $notice['content']);
        $this->assertEquals('Circular', $notice['type']);
        $this->assertTrue($notice['is_pinned']);
        $this->assertEquals('published', $notice['status']);
        $this->assertEquals('Rahim Uddin', $notice['author_name']);
        $this->assertArrayHasKey('branch_name', $notice);
        $this->assertArrayHasKey('department_name', $notice);
    }

    /**
     * Test 6: Detail endpoint returns 404 for missing, expired, draft, or inaccessible notices.
     */
    public function testShowInaccessibleOrMissingReturns404(): void
    {
        $token = $this->token('ACME', 'rahim');

        $now = date('Y-m-d H:i:s');
        $past = date('Y-m-d', strtotime('-5 days'));

        $this->db->table('notices')->insertBatch([
            [
                'id'           => 'not-draft-item',
                'company_id'   => 'c-1',
                'title'        => 'Draft Item',
                'content'      => 'Draft content.',
                'status'       => 'draft',
                'published_at' => $now,
            ],
            [
                'id'           => 'not-expired-item',
                'company_id'   => 'c-1',
                'title'        => 'Expired Item',
                'content'      => 'Expired content.',
                'status'       => 'published',
                'published_at' => date('Y-m-d H:i:s', strtotime('-10 days')),
                'expires_at'   => $past,
            ],
            [
                'id'           => 'not-other-company-item',
                'company_id'   => 'c-2',
                'title'        => 'Other Company Item',
                'content'      => 'Cross-tenant content.',
                'status'       => 'published',
                'published_at' => $now,
            ],
            [
                'id'            => 'not-other-dept-item',
                'company_id'    => 'c-1',
                'department_id' => 'dept-other',
                'title'         => 'Finance Exclusive',
                'content'       => 'Only for finance.',
                'status'        => 'published',
                'published_at'  => $now,
            ],
        ]);

        // 1. Completely non-existent ID -> 404
        $resNonExistent = $this->withHeaders($token)->call('get', 'api/mobile/v1/notices/not-none-999');
        $this->assertEquals(404, $resNonExistent->response()->getStatusCode());

        // 2. Draft notice -> 404
        $resDraft = $this->withHeaders($token)->call('get', 'api/mobile/v1/notices/not-draft-item');
        $this->assertEquals(404, $resDraft->response()->getStatusCode());

        // 3. Expired notice -> 404
        $resExpired = $this->withHeaders($token)->call('get', 'api/mobile/v1/notices/not-expired-item');
        $this->assertEquals(404, $resExpired->response()->getStatusCode());

        // 4. Other company notice (cross-tenant) -> 404
        $resCross = $this->withHeaders($token)->call('get', 'api/mobile/v1/notices/not-other-company-item');
        $this->assertEquals(404, $resCross->response()->getStatusCode());

        // 5. Inaccessible department notice -> 404
        $resDept = $this->withHeaders($token)->call('get', 'api/mobile/v1/notices/not-other-dept-item');
        $this->assertEquals(404, $resDept->response()->getStatusCode());
    }

    /**
     * Test 7: Anti-IDOR: Mismatched employee_id or company_id query parameters return 403.
     */
    public function testAntiIdorAndCrossTenantParamRejection(): void
    {
        $token = $this->token('ACME', 'rahim'); // e-1, c-1

        $resEmp = $this->withHeaders($token)->call('get', 'api/mobile/v1/notices?employee_id=e-2');
        $this->assertEquals(403, $resEmp->response()->getStatusCode());

        $resComp = $this->withHeaders($token)->call('get', 'api/mobile/v1/notices?company_id=c-2');
        $this->assertEquals(403, $resComp->response()->getStatusCode());

        // Passing own employee_id is permitted
        $resOwn = $this->withHeaders($token)->call('get', 'api/mobile/v1/notices?employee_id=e-1');
        $this->assertEquals(200, $resOwn->response()->getStatusCode());
    }

    /**
     * Test 8: Empty results handling returns standard envelope with empty arrays and zero counts.
     * Never returns default dummy or sample notices.
     */
    public function testEmptyResultsFormat(): void
    {
        $token = $this->token('ACME', 'rahim');

        // No notices exist in table
        $res = $this->withHeaders($token)->call('get', 'api/mobile/v1/notices');
        $this->assertEquals(200, $res->response()->getStatusCode());
        $data = $this->json($res);

        $this->assertTrue($data['success']);
        $this->assertEquals([], $data['data']['notices']);
        $this->assertEquals(0, $data['data']['count']);
        $this->assertEquals(0, $data['data']['total']);
        $this->assertEquals(0, $data['data']['pinned_count']);
    }

    /**
     * Test 9: api/v1 route alias returns identical results to api/mobile/v1.
     */
    public function testApiV1RouteAliasWorking(): void
    {
        $token = $this->token('ACME', 'rahim');

        $now = date('Y-m-d H:i:s');
        $this->db->table('notices')->insert([
            'id'           => 'not-v1-test',
            'company_id'   => 'c-1',
            'title'        => 'API v1 Route Test Notice',
            'content'      => 'Testing route parity.',
            'status'       => 'published',
            'published_at' => $now,
            'created_at'   => $now,
        ]);

        $resList = $this->withHeaders($token)->call('get', 'api/v1/notices');
        $this->assertEquals(200, $resList->response()->getStatusCode());
        $dataList = $this->json($resList);
        $this->assertTrue($dataList['success']);
        $this->assertEquals(1, $dataList['data']['count']);

        $resDetail = $this->withHeaders($token)->call('get', 'api/v1/notices/not-v1-test');
        $this->assertEquals(200, $resDetail->response()->getStatusCode());
        $dataDetail = $this->json($resDetail);
        $this->assertTrue($dataDetail['success']);
        $this->assertEquals('not-v1-test', $dataDetail['data']['notice']['id']);
    }

    /**
     * Test 10: Unauthenticated access returns 401, unlinked user returns 403.
     */
    public function testUnauthenticatedAndUnlinkedEmployeeAccess(): void
    {
        // 1. No token -> 401
        $resNoAuth = $this->call('get', 'api/mobile/v1/notices');
        $this->assertEquals(401, $resNoAuth->response()->getStatusCode());

        // 2. User with no linked employee profile -> 403
        $this->addUser('u-orphan-notice', 'orphan-notice', 'orphan-notice@acme.test', 'c-1', null, 'r-emp');
        $resLogin = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => 'ACME', 'identifier' => 'orphan-notice', 'password' => self::PASSWORD, 'device' => $this->device,
        ]);
        $json = json_decode($resLogin->getJSON(), true);
        $orphanToken = ['Authorization' => 'Bearer ' . ($json['data']['tokens']['access_token'] ?? '')];

        $resOrphan = $this->withHeaders($orphanToken)->call('get', 'api/mobile/v1/notices');
        $this->assertEquals(403, $resOrphan->response()->getStatusCode());
        $this->assertStringContainsString('No employee profile is linked', $this->json($resOrphan)['message']);
    }
}
