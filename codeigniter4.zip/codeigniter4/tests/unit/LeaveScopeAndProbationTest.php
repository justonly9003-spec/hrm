<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\PermissionService;

class LeaveScopeAndProbationTest extends TestCase
{
    private PermissionService $permissionService;

    protected function setUp(): void
    {
        parent::setUp();
        $this->permissionService = new PermissionService();
    }

    /**
     * Test Task 1: A user whose leave.manage scope is "branch" gets 403 / denied
     * for an employee in another branch, while succeeding for an employee in the same branch.
     */
    public function testBranchScopedUserCannotAccessEmployeeInAnotherBranch()
    {
        $branchManagerUser = [
            'id'          => 'USR-BM-01',
            'employee_id' => 'EMP-BM-01',
            'company_id'  => 'COMP-001',
            'branch_id'   => 'BRANCH-A',
            'department_id' => 'DEPT-HR',
        ];

        $employeeInSameBranch = [
            'id'          => 'EMP-001',
            'employee_id' => 'EMP-001',
            'company_id'  => 'COMP-001',
            'branch_id'   => 'BRANCH-A',
            'department_id' => 'DEPT-SALES',
        ];

        $employeeInOtherBranch = [
            'id'          => 'EMP-002',
            'employee_id' => 'EMP-002',
            'company_id'  => 'COMP-001',
            'branch_id'   => 'BRANCH-B',
            'department_id' => 'DEPT-OPS',
        ];

        // When user has branch scope
        $sameBranchInScope = $this->permissionService->assertInScope($branchManagerUser, 'branch', $employeeInSameBranch);
        $otherBranchInScope = $this->permissionService->assertInScope($branchManagerUser, 'branch', $employeeInOtherBranch);

        $this->assertTrue($sameBranchInScope, "Branch-scoped manager should be in scope for employees in the same branch.");
        $this->assertFalse($otherBranchInScope, "Branch-scoped manager must NOT be in scope for employees in another branch.");
    }

    /**
     * Test Task 1: Company-scoped user succeeds across all branches within company.
     */
    public function testCompanyScopedUserSucceedsAcrossBranches()
    {
        $hrAdminUser = [
            'id'          => 'USR-HR-01',
            'employee_id' => 'EMP-HR-01',
            'company_id'  => 'COMP-001',
            'branch_id'   => 'BRANCH-HQ',
        ];

        $employeeBranchA = [
            'id'         => 'EMP-001',
            'company_id' => 'COMP-001',
            'branch_id'  => 'BRANCH-A',
        ];

        $employeeBranchB = [
            'id'         => 'EMP-002',
            'company_id' => 'COMP-001',
            'branch_id'  => 'BRANCH-B',
        ];

        $this->assertTrue(
            $this->permissionService->assertInScope($hrAdminUser, 'company', $employeeBranchA),
            "Company-scoped user must be in scope for branch A"
        );
        $this->assertTrue(
            $this->permissionService->assertInScope($hrAdminUser, 'company', $employeeBranchB),
            "Company-scoped user must be in scope for branch B"
        );
    }

    /**
     * Test Task 1: Self-approval is blocked on sensitive probation actions:
     * earlyConfirm, completeProbation, setEligibilityOverride, removeEligibilityOverride.
     */
    public function testSelfApprovalAssertionBlocksSelfAction()
    {
        $currentEmployeeId = 'EMP-USER-01';

        $isSelfAction = function ($targetEmployeeId) use ($currentEmployeeId) {
            return !empty($currentEmployeeId) && (string)$targetEmployeeId === (string)$currentEmployeeId;
        };

        $this->assertTrue(
            $isSelfAction('EMP-USER-01'),
            "Action targeting self should be flagged as self-approval attempt"
        );
        $this->assertFalse(
            $isSelfAction('EMP-OTHER-02'),
            "Action targeting another employee is not self-approval"
        );
    }
}
