<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

/**
 * Forensic Security & Integrity Test Suite for Module 03: Dashboard Widgets
 * Covers:
 * - SEC-WIDGET-01: Unauthorized Widget Assignment via Reorder Injection
 * - SEC-WIDGET-02: Cross-Department / Cross-Branch Scope IDOR & Parameter Tampering
 * - SEC-WIDGET-03: Unauthenticated Dashboard Stats API
 * - SEC-WIDGET-04: CSRF Protection on Dashboard Widget & Preference Endpoints
 * - DEBT-WIDGET-01: Platform Widget Blacklist Registry Synchronization
 */
class DashboardWidgetSecurityTest extends TestCase
{
    /**
     * SEC-WIDGET-01: Verify that unauthorized widget codes cannot be injected via reorder payload.
     */
    public function testUnauthorizedWidgetAssignmentBlockedOnReorder()
    {
        $employeeRole = 'employee';
        $unauthorizedWidgets = ['appadmin_platform_overview', 'executive_kpi_strip', 'payroll_cost_summary'];
        $authorizedWidgets = ['my_quick_actions', 'my_attendance_punch', 'my_leave_balances'];

        // Simulated check adhering to the authorization invariant:
        // "Users cannot enable or order unauthorized widgets."
        foreach ($unauthorizedWidgets as $wCode) {
            $isAuthorized = in_array($wCode, $authorizedWidgets, true);
            $this->assertFalse($isAuthorized, "Widget '{$wCode}' must NOT be authorized for role '{$employeeRole}'.");
        }

        // Duplicate IDs must be rejected
        $payloadWithDuplicates = ['my_quick_actions', 'my_attendance_punch', 'my_quick_actions'];
        $hasDuplicates = count($payloadWithDuplicates) !== count(array_unique($payloadWithDuplicates));
        $this->assertTrue($hasDuplicates, "Duplicate widget IDs in reorder payload must be flagged.");

        // Empty payload must be rejected
        $emptyPayload = [];
        $isEmpty = empty($emptyPayload);
        $this->assertTrue($isEmpty, "Empty reorder payload must be rejected.");
    }

    /**
     * SEC-WIDGET-02: Verify Cross-Department & Cross-Branch Scope IDOR defense.
     */
    public function testCrossDepartmentScopeIdorBlocked()
    {
        $managerCompanyId = 'comp-mercury-01';
        $managerAssignedDeptId = 'dept-cardio-01';
        $managerAssignedBranchId = 'branch-metro-01';

        // Attack A: Manager attempts to access Department B in same company
        $attackDeptId = 'dept-surgery-02';
        $isOwnDept = ($attackDeptId === $managerAssignedDeptId);
        $this->assertFalse($isOwnDept, "Manager must NOT be authorized to view unassigned department.");

        // Attack B: Manager attempts to access Department in another company (Tenant IDOR)
        $targetCompanyId = 'comp-competitor-99';
        $isSameCompany = ($targetCompanyId === $managerCompanyId);
        $this->assertFalse($isSameCompany, "Cross-company department access must be strictly forbidden.");

        // Legitimate: Manager accesses own department
        $legitDeptId = 'dept-cardio-01';
        $this->assertEquals($managerAssignedDeptId, $legitDeptId, "Legitimate department access must succeed.");
    }

    /**
     * SEC-WIDGET-03: Verify unauthenticated dashboard stats requests are rejected with 401.
     */
    public function testUnauthenticatedStatsApiBlocked()
    {
        $sessionUserId = null;
        $isAuthenticated = !empty($sessionUserId);
        $statusCode = $isAuthenticated ? 200 : 401;

        $this->assertEquals(401, $statusCode, "Unauthenticated /api/dashboard/stats MUST return 401 before any queries run.");
    }

    /**
     * SEC-WIDGET-04: Verify global CSRF exemption does not include 'api/*' wildcard.
     */
    public function testCsrfExemptionWildcardRemoved()
    {
        $filtersConfig = file_get_contents(__DIR__ . '/../../app/Config/Filters.php');
        $this->assertNotEmpty($filtersConfig);

        // Assert that 'api/*' wildcard is NOT present in csrf exceptions
        $this->assertStringNotContainsString("'api/*'", $filtersConfig, "Global 'api/*' wildcard MUST NOT exist in CSRF exception list.");

        // Assert that broad wildcard patterns and diagnostic routes are NOT in CSRF exceptions
        $forbiddenPatterns = [
            "'api/attendance/sync*'",
            "'api/attendance/push*'",
            "'api/attendance/raw-push*'",
            "'api/attendance/zk-push*'",
            "'api/attendance/push-punch*'",
            "'api/biometrics/*'",
            "'attendance/sync/api/*'",
            "'iclock/*'",
            "'attendance/run-diagnostic-tests*'",
            "'api/v1/system/diagnose/*'",
        ];
        foreach ($forbiddenPatterns as $pattern) {
            $this->assertStringNotContainsString($pattern, $filtersConfig, "Broad or diagnostic pattern {$pattern} MUST NOT exist in CSRF exception list.");
        }

        // Assert that exact hardware biometrics device endpoints remain listed
        $this->assertStringContainsString("'api/attendance/zk-push'", $filtersConfig);
        $this->assertStringContainsString("'api/attendance/push-punch'", $filtersConfig);
        $this->assertStringContainsString("'api/biometrics/enroll'", $filtersConfig);
        $this->assertStringContainsString("'attendance/sync/api/push-punch'", $filtersConfig);
        $this->assertStringContainsString("'attendance/sync/api/enroll'", $filtersConfig);

        // Verify CorsFilter uses CORS_ALLOWED_ORIGINS allowlist and 204 response instead of wildcard or die()
        $corsFilter = file_get_contents(__DIR__ . '/../../app/Filters/CorsFilter.php');
        $this->assertStringContainsString('CORS_ALLOWED_ORIGINS', $corsFilter);
        $this->assertStringContainsString('setStatusCode(204)', $corsFilter);
        $this->assertStringNotContainsString('Access-Control-Allow-Origin: *', $corsFilter);
        $this->assertStringNotContainsString('die()', $corsFilter);
    }

    /**
     * DEBT-WIDGET-01: Verify DashboardService blacklist matches authoritative registry codes.
     */
    public function testPlatformWidgetBlacklistUsesAuthoritativeRegistry()
    {
        $serviceCode = file_get_contents(__DIR__ . '/../../app/Services/DashboardService.php');
        $this->assertNotEmpty($serviceCode);

        $authoritativeCodes = [
            'appadmin_platform_overview',
            'appadmin_company_fleet',
            'appadmin_system_health',
            'appadmin_audit_stream'
        ];

        foreach ($authoritativeCodes as $code) {
            $this->assertStringContainsString(
                $code,
                $serviceCode,
                "Authoritative widget identifier '{$code}' MUST be present in DashboardService."
            );
        }
    }

    /**
     * SEC-WIDGET-05: Verify support for $scopeOverride['type'] is removed to prevent scope escalation.
     */
    public function testScopeOverrideTypeBypassRemoved()
    {
        $serviceCode = file_get_contents(__DIR__ . '/../../app/Services/DashboardService.php');
        $this->assertNotEmpty($serviceCode);

        // Assert $scopeOverride['type'] is not read or honored
        $this->assertStringNotContainsString(
            "\$scopeOverride['type']",
            $serviceCode,
            "Security vulnerability: \$scopeOverride['type'] MUST NOT be supported in DashboardService::resolveUserScope."
        );
    }

    /**
     * SEC-WIDGET-06: Verify PermissionService::canonicalizeRole for 'branch_manager' returns 'branch_manager'.
     */
    public function testPermissionServiceCanonicalizeRoleBranchManager()
    {
        $permissionService = new \App\Services\PermissionService();
        $canonical = $permissionService->canonicalizeRole('branch_manager');
        $this->assertEquals('branch_manager', $canonical, "canonicalizeRole('branch_manager') must return 'branch_manager'.");

        // Verify variants
        $this->assertEquals('branch_manager', $permissionService->canonicalizeRole('branchmanager'));
        $this->assertEquals('branch_manager', $permissionService->canonicalizeRole('r_bm'));
        $this->assertEquals('branch_manager', $permissionService->canonicalizeRole('role_bm'));
        $this->assertEquals('branch_manager', $permissionService->canonicalizeRole('role_branch_manager'));
    }

    /**
     * SEC-WIDGET-07: Verify DashboardService implements and documents required precedence architecture in one unified docblock:
     * - Admin layers (global default, role, branch, department, company): any layer with status=0 disables the widget; a lower layer cannot re-enable it.
     * - The USER layer may only hide/reorder/resize widgets the admin layers left enabled. It must never enable an admin-disabled widget.
     * - Order/width/height: most specific wins (user > department > branch > company > role > default).
     * - toggleUserWidget, reorderUserWidgets and saveUserPreferences return 403 when asked to enable an admin-disabled widget.
     */
    public function testAdminPrecedenceDocblockAndSecurityRules()
    {
        $serviceCode = file_get_contents(__DIR__ . '/../../app/Services/DashboardService.php');
        $this->assertNotEmpty($serviceCode);

        // Required 4 bullet points in docblock
        $this->assertStringContainsString('Admin layers (global default, role, branch, department, company): any layer with status=0 disables the widget; a lower layer cannot re-enable it.', $serviceCode);
        $this->assertStringContainsString('The USER layer may only hide/reorder/resize widgets the admin layers left enabled. It must never enable an admin-disabled widget.', $serviceCode);
        $this->assertStringContainsString('Order/width/height: most specific wins (user > department > branch > company > role > default).', $serviceCode);
        $this->assertStringContainsString('toggleUserWidget, reorderUserWidgets and saveUserPreferences return 403 when asked to enable an admin-disabled widget.', $serviceCode);

        // Verify method isWidgetAdminDisabled exists
        $this->assertStringContainsString('function isWidgetAdminDisabled(', $serviceCode);
    }

    /**
     * SEC-WIDGET-08: Verify that when company_admin disables widget X at company scope,
     * any layer with status=0 disables the widget and a lower layer cannot re-enable it.
     * User toggle ON for X returns 403, and hiding widget Y still works.
     */
    public function testCompanyAdminDisablesWidgetAtCompanyScopeOmittedAndToggleReturns403()
    {
        $service = new \App\Services\DashboardService();

        $widgetX = [
            'id'             => 'wid-payroll-x',
            'code'           => 'payroll_summary_x',
            'title'          => 'Payroll Summary X',
            'default_status' => 1,
            'grid_width'     => 'half',
        ];

        $widgetY = [
            'id'             => 'wid-tasks-y',
            'code'           => 'employee_tasks_y',
            'title'          => 'Employee Tasks Y',
            'default_status' => 1,
            'grid_width'     => 'half',
        ];

        // Scenario: Company layer sets status = 0 for widget X
        // Preloaded admin layers simulate company override: status = 0
        $preloadedDisabledAtCompany = [
            'role'    => [
                'wid-payroll-x' => ['status' => 1, 'sort_order' => 1],
            ],
            'company' => [
                'wid-payroll-x' => ['status' => 0, 'sort_order' => 1],
            ],
            'branch'  => [],
            'department' => [],
        ];

        // 1. isWidgetAdminDisabled returns disabled = true for widget X
        $adminCheckX = $service->isWidgetAdminDisabled($widgetX, 'hr_admin', 'comp-mercury-01', 'usr-hr-01', [], $preloadedDisabledAtCompany);
        $this->assertTrue($adminCheckX['disabled'], "Widget X must be flagged admin-disabled when company layer has status=0.");
        $this->assertEquals('company', $adminCheckX['layer'], "Disabling layer must be 'company'.");

        // Lower layer (e.g. branch or user or role with status=1) cannot re-enable it
        $preloadedLowerLayerCannotReenable = [
            'role'       => ['wid-payroll-x' => ['status' => 1]],
            'company'    => ['wid-payroll-x' => ['status' => 0]], // disabled here
            'branch'     => ['wid-payroll-x' => ['status' => 1]], // branch has 1
            'department' => ['wid-payroll-x' => ['status' => 1]], // department has 1
        ];
        $checkCannotReenable = $service->isWidgetAdminDisabled($widgetX, 'hr_admin', 'comp-mercury-01', 'usr-hr-01', ['branch_id' => 'br-01', 'department_id' => 'dept-01'], $preloadedLowerLayerCannotReenable);
        $this->assertTrue($checkCannotReenable['disabled'], "Lower layers cannot re-enable a widget disabled at company scope.");

        // For manager of that company: also disabled
        $checkMgr = $service->isWidgetAdminDisabled($widgetX, 'manager', 'comp-mercury-01', 'usr-mgr-01', ['department_id' => 'dept-01'], $preloadedDisabledAtCompany);
        $this->assertTrue($checkMgr['disabled'], "Widget X must be admin-disabled for manager when disabled at company scope.");

        // 2. Widget Y has not been disabled by any admin layer
        $preloadedY = [
            'role'       => ['wid-tasks-y' => ['status' => 1]],
            'company'    => ['wid-tasks-y' => ['status' => 1]],
            'branch'     => [],
            'department' => [],
        ];
        $adminCheckY = $service->isWidgetAdminDisabled($widgetY, 'hr_admin', 'comp-mercury-01', 'usr-hr-01', [], $preloadedY);
        $this->assertFalse($adminCheckY['disabled'], "Widget Y must NOT be admin-disabled.");
    }

    /**
     * SEC-WIDGET-09: Verify Order/Width/Height precedence: most specific wins:
     * user > department > branch > company > role > default.
     */
    public function testPrecedenceOrderWidthHeightHierarchy()
    {
        // Hierarchy definitions:
        // default: width = half, order = 10
        // role:    width = full, order = 8
        // company: width = half, order = 6
        // branch:  width = two_thirds, order = 4
        // dept:    width = third, order = 2
        // user:    width = quarter, order = 1

        $levels = ['default', 'role', 'company', 'branch', 'department', 'user'];
        $expectedOrder = [
            'default'    => 10,
            'role'       => 8,
            'company'    => 6,
            'branch'     => 4,
            'department' => 2,
            'user'       => 1,
        ];

        $currentSortOrder = 10;
        foreach ($levels as $lvl) {
            $currentSortOrder = $expectedOrder[$lvl];
        }
        $this->assertEquals(1, $currentSortOrder, "User level must win as the most specific layer.");
    }

    /**
     * SEC-WIDGET-10: Verify subscription plan tier authorization:
     * - company on 'enterprise', widget with min_subscription_plan 'professional' -> authorized (200)
     * - company on 'starter', widget with min_subscription_plan 'professional' -> unauthorized 403
     * - isPlanEligible logic (starter < professional < enterprise)
     */
    public function testSubscriptionPlanTierAuthorizationAndResolution()
    {
        $service = new \App\Services\DashboardService();

        // 1. Plan eligibility tier comparisons
        $this->assertTrue($service->isPlanEligible('enterprise', 'professional'));
        $this->assertTrue($service->isPlanEligible('enterprise', 'starter'));
        $this->assertTrue($service->isPlanEligible('professional', 'professional'));
        $this->assertTrue($service->isPlanEligible('professional', 'starter'));
        $this->assertFalse($service->isPlanEligible('starter', 'professional'));
        $this->assertFalse($service->isPlanEligible('starter', 'enterprise'));

        // 2. Widget authorization with explicit subscriptionPlan
        $profWidget = [
            'id'                    => 'w-prof-test',
            'code'                  => 'payroll_cost_summary',
            'title'                 => 'Payroll Cost Summary',
            'min_subscription_plan' => 'professional',
            'target_roles'          => ['hr_admin', 'company_admin'],
        ];

        // Enterprise plan -> authorized
        $authEnterprise = $service->isWidgetAuthorizedForUser(
            $profWidget,
            'hr_admin',
            'comp-dummy',
            'usr-dummy',
            'company',
            'enterprise'
        );
        $this->assertTrue($authEnterprise['authorized'], "Professional widget must be authorized for enterprise plan.");

        // Starter plan -> rejected with 403 reason
        $authStarter = $service->isWidgetAuthorizedForUser(
            $profWidget,
            'hr_admin',
            'comp-dummy',
            'usr-dummy',
            'company',
            'starter'
        );
        $this->assertFalse($authStarter['authorized'], "Professional widget must NOT be authorized for starter plan.");
        $this->assertStringContainsString("Requires subscription plan tier 'professional'", $authStarter['reason']);
    }
}

