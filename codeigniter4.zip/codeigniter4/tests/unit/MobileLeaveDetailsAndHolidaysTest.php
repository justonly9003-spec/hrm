<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobileLeaveDetailsAndHolidaysTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;
    private array $device = ['device_uid' => 'dev-leave-1', 'platform' => 'android'];

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);

        foreach (['leave_applications', 'leave_types', 'holidays'] as $t) {
            $this->db->query("DROP TABLE IF EXISTS {$t}");
        }

        $this->db->query("CREATE TABLE leave_types (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            name VARCHAR(100),
            code VARCHAR(30),
            is_paid INT DEFAULT 1,
            days_allowed INT DEFAULT 14,
            allow_carry_forward INT DEFAULT 0,
            status VARCHAR(30) DEFAULT 'Active'
        )");

        $this->db->query("CREATE TABLE leave_applications (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            employee_id VARCHAR(36),
            leave_type_id VARCHAR(36),
            from_date DATE,
            to_date DATE,
            start_date DATE,
            end_date DATE,
            total_days DECIMAL(5,2) DEFAULT 1,
            paid_days DECIMAL(5,2) DEFAULT 1,
            unpaid_days DECIMAL(5,2) DEFAULT 0,
            half_day VARCHAR(20) DEFAULT 'None',
            is_half_day INT DEFAULT 0,
            is_emergency INT DEFAULT 0,
            reason TEXT,
            status VARCHAR(30) DEFAULT 'Pending',
            applied_at DATETIME NULL,
            approved_by VARCHAR(36) NULL,
            approved_at DATETIME NULL,
            rejection_reason TEXT NULL,
            cancellation_reason TEXT NULL,
            manager_status VARCHAR(30) DEFAULT 'Pending',
            dept_head_status VARCHAR(30) DEFAULT 'Pending',
            hr_status VARCHAR(30) DEFAULT 'Pending',
            covering_employee_id VARCHAR(36) NULL,
            attachment_path VARCHAR(255) NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE holidays (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36) NULL,
            branch_id VARCHAR(36) NULL,
            department_id VARCHAR(36) NULL,
            employee_id VARCHAR(36) NULL,
            scope VARCHAR(30) DEFAULT 'Global',
            name VARCHAR(100),
            date DATE NULL,
            from_date DATE NULL,
            to_date DATE NULL,
            total_days INT DEFAULT 1,
            holiday_type VARCHAR(30) DEFAULT 'public',
            type VARCHAR(30) DEFAULT 'public',
            description TEXT NULL,
            is_working_day INT DEFAULT 0,
            status VARCHAR(30) DEFAULT 'Active',
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        // Seed organizational metadata
        $this->db->table('branches')->insert(['id' => 'br-dhaka', 'name' => 'Dhaka HQ']);
        $this->db->table('branches')->insert(['id' => 'br-ctg', 'name' => 'Chittagong Branch']);
        $this->db->table('departments')->insert(['id' => 'dept-tech', 'name' => 'Engineering']);
        $this->db->table('designations')->insert(['id' => 'desig-eng', 'name' => 'Software Engineer']);

        // Update e-1 profile to branch br-dhaka
        $this->db->table('employees')->where('id', 'e-1')->update([
            'branch_id'      => 'br-dhaka',
            'department_id'  => 'dept-tech',
            'designation_id' => 'desig-eng',
        ]);

        // Seed an additional employee in c-1 (e-covering)
        $this->db->table('employees')->insert([
            'id'            => 'e-covering',
            'company_id'    => 'c-1',
            'employee_code' => 'EMP-002',
            'first_name'    => 'Tariq',
            'last_name'     => 'Hasan',
            'branch_id'     => 'br-dhaka',
            'status'        => 'Active',
        ]);
        $this->addUser('u-cov', 'tariq', 'tariq@acme.test', 'c-1', 'e-covering', 'r-emp');

        // Seed leave types for c-1
        $this->db->table('leave_types')->insert([
            'id'                  => 'lt-annual',
            'company_id'          => 'c-1',
            'name'                => 'Annual Leave',
            'code'                => 'AL',
            'is_paid'             => 1,
            'days_allowed'        => 15,
            'allow_carry_forward' => 1,
            'status'              => 'Active',
        ]);
        $this->db->table('leave_types')->insert([
            'id'                  => 'lt-medical',
            'company_id'          => 'c-1',
            'name'                => 'Medical Leave',
            'code'                => 'ML',
            'is_paid'             => 1,
            'days_allowed'        => 14,
            'status'              => 'Active',
        ]);
    }

    private function token(string $company = 'ACME', string $id = 'rahim'): array
    {
        $res = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => $company, 'identifier' => $id, 'password' => self::PASSWORD, 'device' => $this->device,
        ]);
        $json = json_decode($res->getJSON(), true);
        return ['Authorization' => 'Bearer ' . $json['data']['tokens']['access_token']];
    }

    private function json($res): array
    {
        return json_decode($res->getJSON(), true);
    }

    public function testUnauthenticatedRequestsReturn401(): void
    {
        // 1. Missing Authorization header on application detail
        $this->get('api/mobile/v1/leaves/applications/la-1')->assertStatus(401);
        $this->get('api/mobile/v1/leaves/la-1')->assertStatus(401);

        // 2. Missing Authorization header on holidays
        $this->get('api/mobile/v1/holidays')->assertStatus(401);
        $this->get('api/mobile/v1/leaves/holidays')->assertStatus(401);

        // 3. Invalid token returns 401
        $this->withHeaders(['Authorization' => 'Bearer mat_invalid_token'])->get('api/mobile/v1/leaves/la-1')->assertStatus(401);
        $this->withHeaders(['Authorization' => 'Bearer mat_invalid_token'])->get('api/mobile/v1/holidays')->assertStatus(401);
    }

    public function testLeaveApplicationDetailOwnerCanView(): void
    {
        // Insert application owned by e-1
        $this->db->table('leave_applications')->insert([
            'id'                   => 'la-101',
            'company_id'           => 'c-1',
            'employee_id'          => 'e-1',
            'leave_type_id'        => 'lt-annual',
            'from_date'            => '2026-06-01',
            'to_date'              => '2026-06-03',
            'start_date'           => '2026-06-01',
            'end_date'             => '2026-06-03',
            'total_days'           => 3.0,
            'paid_days'            => 3.0,
            'unpaid_days'          => 0.0,
            'half_day'             => 'None',
            'is_half_day'          => 0,
            'is_emergency'         => 0,
            'reason'               => 'Family vacation',
            'status'               => 'Pending',
            'manager_status'       => 'Pending',
            'dept_head_status'     => 'Pending',
            'hr_status'            => 'Pending',
            'covering_employee_id' => 'e-covering',
            'attachment_path'      => '/app/applet/codeigniter4/writable/uploads/leaves/vacation_plan.pdf',
            'applied_at'           => '2026-05-20 10:00:00',
            'created_at'           => '2026-05-20 10:00:00',
        ]);

        $h = $this->token('ACME', 'rahim');

        // Test canonical route: api/mobile/v1/leaves/applications/la-101
        $res = $this->withHeaders($h)->get('api/mobile/v1/leaves/applications/la-101');
        $res->assertStatus(200);
        $body = $this->json($res);

        $this->assertTrue($body['success']);
        $this->assertSame('success', $body['status']);
        $this->assertSame('Leave application details retrieved successfully.', $body['message']);

        $data = $body['data'];
        $this->assertArrayHasKey('application', $data);
        $this->assertArrayHasKey('employee', $data);
        $this->assertArrayHasKey('workflow', $data);

        $app = $data['application'];
        $this->assertSame('la-101', $app['id']);
        $this->assertSame('Annual Leave', $app['leave_type_name']);
        $this->assertSame('2026-06-01', $app['from_date']);
        $this->assertSame('2026-06-03', $app['to_date']);
        $this->assertEquals(3.0, (float)$app['total_days']);
        $this->assertSame('Family vacation', $app['reason']);
        $this->assertSame('Pending', $app['status']);

        // Covering employee verified
        $this->assertNotNull($app['covering_employee']);
        $this->assertSame('e-covering', $app['covering_employee']['id']);

        // Workflow state
        $this->assertSame('Pending', $data['workflow']['final_status']);
        $this->assertTrue($data['workflow']['can_cancel']);

        // Test alias route: api/mobile/v1/leaves/la-101
        $resAlias = $this->withHeaders($h)->get('api/mobile/v1/leaves/la-101');
        $resAlias->assertStatus(200);
    }

    public function testLeaveApplicationDetailCoveringEmployeeCanView(): void
    {
        // Application created by e-1 with covering_employee_id = e-covering
        $this->db->table('leave_applications')->insert([
            'id'                   => 'la-cov-1',
            'company_id'           => 'c-1',
            'employee_id'          => 'e-1',
            'leave_type_id'        => 'lt-annual',
            'from_date'            => '2026-07-01',
            'to_date'              => '2026-07-02',
            'start_date'           => '2026-07-01',
            'end_date'             => '2026-07-02',
            'total_days'           => 2.0,
            'reason'               => 'Conference attendance',
            'status'               => 'Approved',
            'covering_employee_id' => 'e-covering',
            'created_at'           => '2026-06-20 10:00:00',
        ]);

        // Login as tariq (e-covering)
        $hCov = $this->token('ACME', 'tariq');
        $res = $this->withHeaders($hCov)->get('api/mobile/v1/leaves/applications/la-cov-1');
        $res->assertStatus(200);
        $data = $this->json($res)['data'];

        $this->assertSame('la-cov-1', $data['application']['id']);
        $this->assertSame('e-1', $data['employee']['id']);
        // Covering employee cannot cancel someone else's leave
        $this->assertFalse($data['workflow']['can_cancel']);
    }

    public function testLeaveApplicationDetailNonOwnerForbiddenReturns404(): void
    {
        // Application belonging to e-covering without e-1 as covering employee
        $this->db->table('leave_applications')->insert([
            'id'                   => 'la-private-cov',
            'company_id'           => 'c-1',
            'employee_id'          => 'e-covering',
            'leave_type_id'        => 'lt-annual',
            'from_date'            => '2026-08-01',
            'to_date'              => '2026-08-02',
            'total_days'           => 2.0,
            'reason'               => 'Confidential personal matters',
            'status'               => 'Pending',
            'covering_employee_id' => null,
            'created_at'           => '2026-07-20 10:00:00',
        ]);

        // Login as rahim (e-1), who is not the owner, not covering, and not an admin
        $h = $this->token('ACME', 'rahim');
        $res = $this->withHeaders($h)->get('api/mobile/v1/leaves/applications/la-private-cov');
        $res->assertStatus(404);
        $body = $this->json($res);
        $this->assertFalse($body['success']);
        $this->assertSame('Leave application not found.', $body['message']);
    }

    public function testLeaveApplicationDetailCrossTenantIsolationReturns404(): void
    {
        // Application in company c-2 (Other Ltd) belonging to e-2
        $this->db->table('leave_applications')->insert([
            'id'          => 'la-tenant2-app',
            'company_id'  => 'c-2',
            'employee_id' => 'e-2',
            'from_date'   => '2026-09-01',
            'to_date'     => '2026-09-02',
            'total_days'  => 2.0,
            'reason'      => 'Other company leave',
            'status'      => 'Pending',
            'created_at'  => '2026-08-20 10:00:00',
        ]);

        // Login as rahim in company c-1
        $h1 = $this->token('ACME', 'rahim');
        $res = $this->withHeaders($h1)->get('api/mobile/v1/leaves/applications/la-tenant2-app');
        $res->assertStatus(404);
    }

    public function testLeaveApplicationDetailInvalidIdReturns404(): void
    {
        $h = $this->token('ACME', 'rahim');
        $res = $this->withHeaders($h)->get('api/mobile/v1/leaves/applications/la-does-not-exist-999');
        $res->assertStatus(404);
        $body = $this->json($res);
        $this->assertFalse($body['success']);
        $this->assertSame('Leave application not found.', $body['message']);
    }

    public function testLeaveApplicationDetailSanitizesAttachmentPath(): void
    {
        $rawPath = '/app/applet/codeigniter4/writable/uploads/leaves/confidential_doctor_note.pdf';
        $this->db->table('leave_applications')->insert([
            'id'              => 'la-attach-test',
            'company_id'      => 'c-1',
            'employee_id'     => 'e-1',
            'leave_type_id'   => 'lt-medical',
            'from_date'       => '2026-06-10',
            'to_date'         => '2026-06-11',
            'total_days'      => 2.0,
            'reason'          => 'Medical leave with prescription',
            'status'          => 'Approved',
            'attachment_path' => $rawPath,
            'created_at'      => '2026-06-01 10:00:00',
        ]);

        $h = $this->token('ACME', 'rahim');
        $res = $this->withHeaders($h)->get('api/mobile/v1/leaves/applications/la-attach-test');
        $res->assertStatus(200);

        $jsonStr = $res->getJSON();
        // Crucial security requirement: Raw filesystem path MUST NOT be exposed!
        $this->assertStringNotContainsString('/app/applet/codeigniter4/writable/uploads/leaves', $jsonStr);
        $this->assertStringNotContainsString('codeigniter4/writable', $jsonStr);

        $attach = $this->json($res)['data']['application']['attachment'];
        $this->assertTrue($attach['has_attachment']);
        $this->assertSame('confidential_doctor_note.pdf', $attach['filename']);
        $this->assertStringContainsString('leave/attachment/la-attach-test', $attach['url']);
    }

    public function testLeaveApplicationDetailDoesNotExposeUnauthorizedEmployeeInfo(): void
    {
        $this->db->table('leave_applications')->insert([
            'id'          => 'la-security-test',
            'company_id'  => 'c-1',
            'employee_id' => 'e-1',
            'from_date'   => '2026-06-15',
            'to_date'     => '2026-06-15',
            'total_days'  => 1.0,
            'reason'      => 'Personal business',
            'status'      => 'Pending',
            'created_at'  => '2026-06-01 10:00:00',
        ]);

        $h = $this->token('ACME', 'rahim');
        $res = $this->withHeaders($h)->get('api/mobile/v1/leaves/applications/la-security-test');
        $res->assertStatus(200);

        $jsonStr = $res->getJSON();
        $this->assertStringNotContainsString('basic_salary', $jsonStr);
        $this->assertStringNotContainsString('gross_salary', $jsonStr);
        $this->assertStringNotContainsString('password_hash', $jsonStr);
        $this->assertStringNotContainsString('bank_account', $jsonStr);
    }

    public function testHolidayListScopingByCompany(): void
    {
        // Holiday in c-1 (Acme)
        $this->db->table('holidays')->insert([
            'id'         => 'hol-acme-1',
            'company_id' => 'c-1',
            'name'       => 'Acme Foundation Day',
            'from_date'  => '2026-05-15',
            'to_date'    => '2026-05-15',
            'total_days' => 1,
            'type'       => 'company',
            'status'     => 'Active',
        ]);

        // Holiday in c-2 (Other Ltd)
        $this->db->table('holidays')->insert([
            'id'         => 'hol-other-1',
            'company_id' => 'c-2',
            'name'       => 'Other Ltd Day',
            'from_date'  => '2026-05-15',
            'to_date'    => '2026-05-15',
            'total_days' => 1,
            'type'       => 'company',
            'status'     => 'Active',
        ]);

        // Employee in c-1 calls holidays
        $h1 = $this->token('ACME', 'rahim');
        $res = $this->withHeaders($h1)->get('api/mobile/v1/holidays?year=2026');
        $res->assertStatus(200);
        $body = $this->json($res);

        $this->assertTrue($body['success']);
        $holidays = $body['data']['holidays'];
        $ids = array_column($holidays, 'id');

        $this->assertContains('hol-acme-1', $ids);
        $this->assertNotContains('hol-other-1', $ids);
    }

    public function testHolidayListScopingByBranch(): void
    {
        // e-1 belongs to branch br-dhaka
        // 1. Global holiday for company c-1
        $this->db->table('holidays')->insert([
            'id'         => 'hol-global-c1',
            'company_id' => 'c-1',
            'branch_id'  => null,
            'scope'      => 'Global',
            'name'       => 'National Victory Day',
            'from_date'  => '2026-12-16',
            'to_date'    => '2026-12-16',
            'total_days' => 1,
            'type'       => 'national',
            'status'     => 'Active',
        ]);

        // 2. Branch-specific holiday for br-dhaka (applicable to e-1)
        $this->db->table('holidays')->insert([
            'id'         => 'hol-dhaka-local',
            'company_id' => 'c-1',
            'branch_id'  => 'br-dhaka',
            'scope'      => 'Branch',
            'name'       => 'Dhaka City Carnival',
            'from_date'  => '2026-11-10',
            'to_date'    => '2026-11-10',
            'total_days' => 1,
            'type'       => 'public',
            'status'     => 'Active',
        ]);

        // 3. Branch-specific holiday for br-ctg (NOT applicable to e-1)
        $this->db->table('holidays')->insert([
            'id'         => 'hol-ctg-local',
            'company_id' => 'c-1',
            'branch_id'  => 'br-ctg',
            'scope'      => 'Branch',
            'name'       => 'Chittagong Port Fest',
            'from_date'  => '2026-11-12',
            'to_date'    => '2026-11-12',
            'total_days' => 1,
            'type'       => 'public',
            'status'     => 'Active',
        ]);

        $h = $this->token('ACME', 'rahim');
        $res = $this->withHeaders($h)->get('api/mobile/v1/holidays?year=2026');
        $res->assertStatus(200);

        $holidays = $this->json($res)['data']['holidays'];
        $ids = array_column($holidays, 'id');

        $this->assertContains('hol-global-c1', $ids);
        $this->assertContains('hol-dhaka-local', $ids);
        $this->assertNotContains('hol-ctg-local', $ids);
    }

    public function testHolidayListDateFiltering(): void
    {
        $this->db->table('holidays')->insert([
            'id'         => 'hol-jan',
            'company_id' => 'c-1',
            'name'       => 'New Year',
            'from_date'  => '2026-01-01',
            'to_date'    => '2026-01-01',
            'total_days' => 1,
            'status'     => 'Active',
        ]);
        $this->db->table('holidays')->insert([
            'id'         => 'hol-jun',
            'company_id' => 'c-1',
            'name'       => 'Mid Year Holiday',
            'from_date'  => '2026-06-15',
            'to_date'    => '2026-06-16',
            'total_days' => 2,
            'status'     => 'Active',
        ]);

        $h = $this->token('ACME', 'rahim');

        // 1. Date range filter: June only
        $resJune = $this->withHeaders($h)->get('api/mobile/v1/holidays?from=2026-06-01&to=2026-06-30');
        $resJune->assertStatus(200);
        $juneHols = $this->json($resJune)['data']['holidays'];
        $this->assertCount(1, $juneHols);
        $this->assertSame('hol-jun', $juneHols[0]['id']);

        // 2. Inverted dates validation: from > to
        $resInverted = $this->withHeaders($h)->get('api/mobile/v1/holidays?from=2026-06-30&to=2026-06-01');
        $resInverted->assertStatus(422);
        $this->assertStringContainsString('from cannot be after to', $this->json($resInverted)['message']);

        // 3. Invalid date format
        $resBadDate = $this->withHeaders($h)->get('api/mobile/v1/holidays?from=2026/06/01&to=2026-06-30');
        $resBadDate->assertStatus(422);

        // 4. Invalid year
        $resBadYear = $this->withHeaders($h)->get('api/mobile/v1/holidays?year=abcd');
        $resBadYear->assertStatus(200); // non-numeric year gracefully ignored or defaults to current year
    }

    public function testHolidayListEmptyResults(): void
    {
        $h = $this->token('ACME', 'rahim');
        // Year 2035 has no holidays seeded
        $res = $this->withHeaders($h)->get('api/mobile/v1/holidays?year=2035');
        $res->assertStatus(200);
        $body = $this->json($res);

        $this->assertTrue($body['success']);
        $this->assertSame([], $body['data']['holidays']);
        $this->assertSame(0, $body['data']['total']);
    }

    public function testLeaveApplicationAndHolidayApiV1Aliases(): void
    {
        $this->db->table('leave_applications')->insert([
            'id'          => 'la-v1-alias',
            'company_id'  => 'c-1',
            'employee_id' => 'e-1',
            'from_date'   => '2026-10-01',
            'to_date'     => '2026-10-02',
            'total_days'  => 2.0,
            'reason'      => 'Testing api/v1 alias route',
            'status'      => 'Approved',
            'created_at'  => '2026-09-25 10:00:00',
        ]);
        $this->db->table('holidays')->insert([
            'id'         => 'hol-v1-alias',
            'company_id' => 'c-1',
            'name'       => 'V1 Alias Holiday',
            'from_date'  => '2026-10-05',
            'to_date'    => '2026-10-05',
            'total_days' => 1,
            'status'     => 'Active',
        ]);

        $h = $this->token('ACME', 'rahim');

        // Test GET api/v1/leave/applications/la-v1-alias
        $resApp = $this->withHeaders($h)->get('api/v1/leave/applications/la-v1-alias');
        $resApp->assertStatus(200);
        $this->assertSame('la-v1-alias', $this->json($resApp)['data']['application']['id']);

        // Test GET api/v1/leave/la-v1-alias
        $resApp2 = $this->withHeaders($h)->get('api/v1/leave/la-v1-alias');
        $resApp2->assertStatus(200);

        // Test GET api/v1/holidays
        $resHol = $this->withHeaders($h)->get('api/v1/holidays?from=2026-10-01&to=2026-10-10');
        $resHol->assertStatus(200);
        $this->assertNotEmpty($this->json($resHol)['data']['holidays']);

        // Test GET api/v1/leave/holidays
        $resHol2 = $this->withHeaders($h)->get('api/v1/leave/holidays?from=2026-10-01&to=2026-10-10');
        $resHol2->assertStatus(200);

        // Test GET api/mobile/v1/public-holidays
        $resPub1 = $this->withHeaders($h)->get('api/mobile/v1/public-holidays?from=2026-10-01&to=2026-10-10');
        $resPub1->assertStatus(200);
        $this->assertNotEmpty($this->json($resPub1)['data']['holidays']);
        $this->assertArrayHasKey('weekly_off_days', $this->json($resPub1)['data']);

        // Test GET api/v1/public-holidays
        $resPub2 = $this->withHeaders($h)->get('api/v1/public-holidays?from=2026-10-01&to=2026-10-10');
        $resPub2->assertStatus(200);

        // Test GET api/mobile/v1/calendar
        $resCal = $this->withHeaders($h)->get('api/mobile/v1/calendar?from=2026-10-01&to=2026-10-10');
        $resCal->assertStatus(200);
    }
}
