<?php

namespace Tests\Unit;

use App\Services\DashboardService;
use App\Services\PermissionService;
use CodeIgniter\Events\Events;
use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;

/**
 * Performance & Security Audit Test for DashboardService and Customizable Widgets API
 *
 * Verifies:
 * 1. new DashboardService() issues zero CREATE/ALTER/INSERT/UPDATE/REPLACE/DROP queries (asserted via DB query log / DBQuery events).
 * 2. Unauthenticated GET /api/dashboard/customizable-widgets is blocked (401 or redirect to login).
 * 3. Authenticated employee GET /api/dashboard/customizable-widgets returns ONLY widgets authorized for that user/role.
 *    - Privileged widgets (appadmin_platform_overview, executive_kpi_strip, payroll_cost_summary) are strictly excluded.
 * 4. Widgets disabled by an admin at company scope are excluded from customizable widgets.
 */
#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class DashboardPerformanceAuditTest extends CIUnitTestCase
{
    use FeatureTestTrait;

    protected $db;
    protected string $companyId   = 'comp-perf-01';
    protected string $branchId    = 'branch-perf-01';
    protected string $deptId      = 'dept-perf-01';
    protected string $empId       = 'emp-perf-01';
    protected string $userId      = 'usr-perf-01';
    protected string $adminUserId = 'usr-admin-01';

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->registerSqliteFunctions($this->db);
        $this->setupSchema();
        $this->seedTestData();

        PermissionService::clearCache();
        PermissionService::flushCache();
    }

    protected function tearDown(): void
    {
        parent::tearDown();
        PermissionService::clearCache();
        PermissionService::flushCache();
    }

    private function registerSqliteFunctions($db): void
    {
        try {
            $rawConn = $db->connID ?? null;
            if ($rawConn instanceof \SQLite3) {
                $rawConn->createFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->createFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            } elseif (is_object($rawConn) && method_exists($rawConn, 'sqliteCreateFunction')) {
                $rawConn->sqliteCreateFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->sqliteCreateFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            }
        } catch (\Throwable $e) {
            // Ignore if functions already registered
        }
    }

    private function setupSchema(): void
    {
        $tables = [
            'companies', 'departments', 'branches', 'roles', 'permissions',
            'role_permissions', 'users', 'employees',
            'dashboard_widgets', 'dashboard_role_widgets', 'dashboard_company_widgets',
            'dashboard_user_preferences', 'dashboard_widget_assignments'
        ];

        foreach ($tables as $t) {
            $this->db->query("DROP TABLE IF EXISTS {$t}");
        }

        $this->db->query("CREATE TABLE companies (
            id VARCHAR(36) PRIMARY KEY, name VARCHAR(100), code VARCHAR(30),
            timezone VARCHAR(50) DEFAULT 'UTC', status VARCHAR(20) DEFAULT 'active',
            subscription_plan VARCHAR(50) DEFAULT 'starter',
            created_at DATETIME NULL, updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE departments (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36) NULL, name VARCHAR(100),
            created_at DATETIME NULL, updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE branches (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36) NULL, name VARCHAR(100),
            created_at DATETIME NULL, updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE roles (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36) NULL, code VARCHAR(50),
            name VARCHAR(100), status VARCHAR(20) DEFAULT 'active'
        )");

        $this->db->query("CREATE TABLE permissions (
            id VARCHAR(36) PRIMARY KEY, code VARCHAR(100) UNIQUE, module VARCHAR(50) NULL,
            action VARCHAR(50) NULL, name VARCHAR(100)
        )");

        $this->db->query("CREATE TABLE role_permissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT, role_id VARCHAR(36), permission_id VARCHAR(36),
            scope_level VARCHAR(30) DEFAULT 'company'
        )");

        $this->db->query("CREATE TABLE users (
            id VARCHAR(36) PRIMARY KEY, employee_id VARCHAR(36) NULL, username VARCHAR(100),
            email VARCHAR(150), password_hash VARCHAR(255) NULL, role_id VARCHAR(36) NULL,
            company_id VARCHAR(36) NULL, branch_id VARCHAR(36) NULL, department_id VARCHAR(36) NULL,
            status VARCHAR(20) DEFAULT 'active', last_login_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE employees (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36), employee_code VARCHAR(50),
            first_name VARCHAR(100), last_name VARCHAR(100) NULL, branch_id VARCHAR(36) NULL,
            department_id VARCHAR(36) NULL, designation_id VARCHAR(36) NULL, shift_id VARCHAR(36) NULL,
            email VARCHAR(150) NULL, phone VARCHAR(50) NULL, status VARCHAR(30) DEFAULT 'Active'
        )");

        $this->db->query("CREATE TABLE dashboard_widgets (
            id VARCHAR(36) PRIMARY KEY, code VARCHAR(100) UNIQUE, widget_code VARCHAR(100) NULL,
            title VARCHAR(100), name VARCHAR(100) NULL, description TEXT NULL,
            category VARCHAR(50) DEFAULT 'overview', view_path VARCHAR(255) DEFAULT 'dashboard/widgets/clock_card',
            icon VARCHAR(50) DEFAULT 'layout-grid', module_code VARCHAR(100) NULL, module VARCHAR(50) NULL,
            permission_code VARCHAR(100) NULL, permission_required VARCHAR(100) NULL,
            target_roles TEXT NULL, min_subscription_plan VARCHAR(50) DEFAULT 'starter',
            default_status INT DEFAULT 1, default_sort_order INT DEFAULT 0,
            grid_width VARCHAR(50) DEFAULT 'half', is_active INT DEFAULT 1,
            created_at DATETIME NULL, updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE dashboard_role_widgets (
            id VARCHAR(36) PRIMARY KEY, role_code VARCHAR(50), widget_id VARCHAR(36), widget_code VARCHAR(100) NULL,
            status INT DEFAULT 1, is_visible INT DEFAULT 1, sort_order INT DEFAULT 0,
            grid_width VARCHAR(50) NULL, created_at DATETIME NULL, updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE dashboard_company_widgets (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36), widget_id VARCHAR(36),
            role_code VARCHAR(50) DEFAULT 'all', status INT DEFAULT 1, sort_order INT DEFAULT 0,
            grid_width VARCHAR(50) NULL, created_at DATETIME NULL, updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE dashboard_user_preferences (
            id VARCHAR(36) PRIMARY KEY, user_id VARCHAR(36), widget_id VARCHAR(36),
            status INT DEFAULT 1, sort_order INT DEFAULT 0, grid_width VARCHAR(50) NULL,
            settings TEXT NULL, created_at DATETIME NULL, updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE dashboard_widget_assignments (
            id VARCHAR(36) PRIMARY KEY, scope_type VARCHAR(50), scope_id VARCHAR(36),
            widget_id VARCHAR(36), status INT DEFAULT 1, is_visible INT DEFAULT 1,
            sort_order INT DEFAULT 0, position INT DEFAULT 0, grid_width VARCHAR(50) DEFAULT 'half',
            grid_height VARCHAR(50) DEFAULT 'auto', settings TEXT NULL,
            created_at DATETIME NULL, updated_at DATETIME NULL
        )");
    }

    private function seedTestData(): void
    {
        $this->db->table('companies')->insert([
            'id' => $this->companyId, 'name' => 'Performance Audit Ltd', 'code' => 'PERFAUDIT', 'status' => 'active'
        ]);
        $this->db->table('branches')->insert([
            'id' => $this->branchId, 'company_id' => $this->companyId, 'name' => 'Main Branch'
        ]);
        $this->db->table('departments')->insert([
            'id' => $this->deptId, 'company_id' => $this->companyId, 'name' => 'Engineering'
        ]);

        // Roles
        $this->db->table('roles')->insert([
            'id' => 'role-employee', 'company_id' => $this->companyId, 'code' => 'employee', 'name' => 'Employee'
        ]);
        $this->db->table('roles')->insert([
            'id' => 'role-admin', 'company_id' => $this->companyId, 'code' => 'company_admin', 'name' => 'Company Admin'
        ]);

        // Employee
        $this->db->table('employees')->insert([
            'id'            => $this->empId,
            'company_id'    => $this->companyId,
            'employee_code' => 'EMP-PERF-01',
            'first_name'    => 'John',
            'last_name'     => 'Doe',
            'branch_id'     => $this->branchId,
            'department_id' => $this->deptId,
            'email'         => 'john@audit.test',
            'status'        => 'Active',
        ]);

        // Users
        $this->db->table('users')->insert([
            'id'            => $this->userId,
            'employee_id'   => $this->empId,
            'username'      => 'johndoe',
            'email'         => 'john@audit.test',
            'role_id'       => 'role-employee',
            'company_id'    => $this->companyId,
            'branch_id'     => $this->branchId,
            'department_id' => $this->deptId,
            'status'        => 'active',
        ]);

        // Seed Widgets in master catalog
        $widgets = [
            [
                'id'                  => 'w-emp-quick-01',
                'code'                => 'my_quick_actions',
                'widget_code'         => 'my_quick_actions',
                'title'               => 'My Quick Actions',
                'target_roles'        => '["employee","hr_admin","company_admin"]',
                'permission_required' => null,
                'is_active'           => 1,
            ],
            [
                'id'                  => 'w-emp-punch-02',
                'code'                => 'my_attendance_punch',
                'widget_code'         => 'my_attendance_punch',
                'title'               => 'My Attendance Punch',
                'target_roles'        => '["employee"]',
                'permission_required' => 'attendance.clock',
                'is_active'           => 1,
            ],
            [
                'id'                  => 'w-admin-overview-03',
                'code'                => 'appadmin_platform_overview',
                'widget_code'         => 'appadmin_platform_overview',
                'title'               => 'Platform Overview',
                'target_roles'        => '["app_admin"]',
                'permission_required' => 'system.manage',
                'is_active'           => 1,
            ],
            [
                'id'                  => 'w-admin-payroll-04',
                'code'                => 'payroll_cost_summary',
                'widget_code'         => 'payroll_cost_summary',
                'title'               => 'Payroll Cost Summary',
                'target_roles'        => '["company_admin","hr_admin"]',
                'permission_required' => 'payroll.view',
                'is_active'           => 1,
            ],
            [
                'id'                  => 'w-emp-toggleable-05',
                'code'                => 'my_upcoming_leaves',
                'widget_code'         => 'my_upcoming_leaves',
                'title'               => 'My Upcoming Leaves',
                'target_roles'        => '["employee"]',
                'permission_required' => null,
                'is_active'           => 1,
            ],
        ];

        foreach ($widgets as $w) {
            $this->db->table('dashboard_widgets')->insert($w);
        }

        // Role widgets
        $this->db->table('dashboard_role_widgets')->insert([
            'id'         => 'drw-emp-1',
            'role_code'  => 'employee',
            'widget_id'  => 'w-emp-quick-01',
            'status'     => 1,
            'sort_order' => 1,
        ]);
        $this->db->table('dashboard_role_widgets')->insert([
            'id'         => 'drw-emp-2',
            'role_code'  => 'employee',
            'widget_id'  => 'w-emp-punch-02',
            'status'     => 1,
            'sort_order' => 2,
        ]);
        $this->db->table('dashboard_role_widgets')->insert([
            'id'         => 'drw-emp-5',
            'role_code'  => 'employee',
            'widget_id'  => 'w-emp-toggleable-05',
            'status'     => 1,
            'sort_order' => 3,
        ]);
        $this->db->table('dashboard_role_widgets')->insert([
            'id'         => 'drw-admin-1',
            'role_code'  => 'company_admin',
            'widget_id'  => 'w-admin-payroll-04',
            'status'     => 1,
            'sort_order' => 1,
        ]);

        // Unified assignments (dashboard_widget_assignments)
        $this->db->table('dashboard_widget_assignments')->insert([
            'id'          => 'dwa-emp-1',
            'scope_type'  => 'role',
            'scope_id'    => 'employee',
            'widget_id'   => 'w-emp-quick-01',
            'status'      => 1,
            'is_visible'  => 1,
            'sort_order'  => 1,
            'position'    => 1,
            'grid_width'  => 'half',
            'grid_height' => 'auto',
        ]);
        $this->db->table('dashboard_widget_assignments')->insert([
            'id'          => 'dwa-emp-2',
            'scope_type'  => 'role',
            'scope_id'    => 'employee',
            'widget_id'   => 'w-emp-punch-02',
            'status'      => 1,
            'is_visible'  => 1,
            'sort_order'  => 2,
            'position'    => 2,
            'grid_width'  => 'half',
            'grid_height' => 'auto',
        ]);
        $this->db->table('dashboard_widget_assignments')->insert([
            'id'          => 'dwa-emp-5',
            'scope_type'  => 'role',
            'scope_id'    => 'employee',
            'widget_id'   => 'w-emp-toggleable-05',
            'status'      => 1,
            'is_visible'  => 1,
            'sort_order'  => 3,
            'position'    => 3,
            'grid_width'  => 'half',
            'grid_height' => 'auto',
        ]);
        $this->db->table('dashboard_widget_assignments')->insert([
            'id'          => 'dwa-admin-1',
            'scope_type'  => 'role',
            'scope_id'    => 'company_admin',
            'widget_id'   => 'w-admin-payroll-04',
            'status'      => 1,
            'is_visible'  => 1,
            'sort_order'  => 1,
            'position'    => 1,
            'grid_width'  => 'half',
            'grid_height' => 'auto',
        ]);
    }

    /**
     * Requirement 1:
     * Assert new DashboardService() issues zero CREATE/ALTER/INSERT/UPDATE/REPLACE/DROP queries via DB query log.
     */
    public function testNewDashboardServiceIssuesZeroWriteQueries(): void
    {
        $executedQueries = [];
        $queryListener = static function ($query) use (&$executedQueries) {
            $executedQueries[] = (string)$query;
        };

        Events::on('DBQuery', $queryListener);

        try {
            // Instantiate DashboardService
            $service = new DashboardService();
            $this->assertInstanceOf(DashboardService::class, $service);

            // Check captured queries
            $forbiddenDdlDmlKeywords = [
                'CREATE TABLE',
                'ALTER TABLE',
                'DROP TABLE',
                'INSERT INTO',
                'UPDATE ',
                'REPLACE INTO',
                'DELETE FROM',
                'TRUNCATE',
            ];

            foreach ($executedQueries as $sql) {
                $upper = strtoupper(trim($sql));
                foreach ($forbiddenDdlDmlKeywords as $keyword) {
                    $this->assertStringNotContainsString(
                        $keyword,
                        $upper,
                        "new DashboardService() must not execute write or DDL statement: {$sql}"
                    );
                }
            }

            // In fact, constructor should execute exactly 0 queries
            $this->assertCount(
                0,
                $executedQueries,
                "new DashboardService() should execute zero queries on instantiation."
            );
        } finally {
            Events::removeListener('DBQuery', $queryListener);
        }
    }

    /**
     * Requirement 2:
     * Unauthenticated GET /api/dashboard/customizable-widgets must be blocked (401 or redirect to login).
     */
    public function testUnauthenticatedCustomizableWidgetsBlocked(): void
    {
        // Standard call -> redirect to login or 401
        $response = $this->call('get', 'api/dashboard/customizable-widgets');
        $statusCode = $response->response()->getStatusCode();
        $isRedirectOr401 = in_array($statusCode, [302, 303, 307, 401], true);

        $this->assertTrue(
            $isRedirectOr401,
            "Unauthenticated GET /api/dashboard/customizable-widgets must return 401 or redirect to login. Got: {$statusCode}"
        );

        // AJAX call -> must return 401
        $ajaxResponse = $this->withHeaders(['X-Requested-With' => 'XMLHttpRequest'])
                             ->call('get', 'api/dashboard/customizable-widgets');
        $this->assertEquals(
            401,
            $ajaxResponse->response()->getStatusCode(),
            "Unauthenticated AJAX GET /api/dashboard/customizable-widgets must return 401."
        );
    }

    /**
     * Requirement 3:
     * The customizable-widgets endpoint returns only widgets authorized for that user.
     * Privileged widgets must NOT be returned for standard employee.
     */
    public function testCustomizableWidgetsEndpointReturnsOnlyAuthorizedWidgetsForUser(): void
    {
        $employeeSession = [
            'id'                  => $this->userId,
            'user_id'             => $this->userId,
            'username'            => 'johndoe',
            'name'                => 'John Doe',
            'email'               => 'john@audit.test',
            'role'                => 'employee',
            'role_code'           => 'employee',
            'role_id'             => 'role-employee',
            'company_id'          => $this->companyId,
            'branch_id'           => $this->branchId,
            'department_id'       => $this->deptId,
            'employee_id'         => $this->empId,
            'selected_company_id' => $this->companyId,
            'permissions'         => [
                'dashboard.view',
                'profile.edit',
                'attendance.clock',
            ],
        ];

        $response = $this->withSession($employeeSession)
                         ->withHeaders(['X-Requested-With' => 'XMLHttpRequest'])
                         ->call('get', 'api/dashboard/customizable-widgets');

        $response->assertStatus(200);

        $rawBody = $response->getJSON();
        $this->assertNotEmpty($rawBody, "Endpoint must return valid JSON.");

        $data = json_decode($rawBody, true);
        $this->assertIsArray($data);
        $this->assertTrue($data['success'] ?? false, "API response 'success' must be true.");
        $this->assertIsArray($data['data'] ?? null, "Response 'data' must be an array of widgets.");

        $widgetList = $data['data'];
        $widgetCodes = array_column($widgetList, 'code');

        // 1. Employee authorized widgets must be present
        $this->assertContains('my_quick_actions', $widgetCodes, "Authorized widget 'my_quick_actions' should be present.");
        $this->assertContains('my_attendance_punch', $widgetCodes, "Authorized widget 'my_attendance_punch' should be present.");
        $this->assertContains('my_upcoming_leaves', $widgetCodes, "Authorized widget 'my_upcoming_leaves' should be present.");

        // 2. Privileged/admin widgets MUST NOT be present
        $this->assertNotContains(
            'appadmin_platform_overview',
            $widgetCodes,
            "Security violation: AppAdmin widget leaked to standard employee."
        );
        $this->assertNotContains(
            'payroll_cost_summary',
            $widgetCodes,
            "Security violation: Admin-only Payroll widget leaked to standard employee."
        );
    }

    /**
     * Requirement 4:
     * When an admin disables a widget for the company, it must NOT appear in customizable widgets for employees.
     */
    public function testCompanyAdminDisabledWidgetExcludedFromCustomizableWidgets(): void
    {
        $dashboardService = new DashboardService();

        // Admin disables 'my_upcoming_leaves' (id: w-emp-toggleable-05) at company scope
        $toggleResult = $dashboardService->toggleWidgetStatus(
            'w-emp-toggleable-05',
            'company',
            $this->companyId,
            0,
            $this->adminUserId
        );
        $this->assertTrue($toggleResult['success'], "Company admin should be able to disable widget at company scope.");

        $employeeSession = [
            'id'                  => $this->userId,
            'user_id'             => $this->userId,
            'username'            => 'johndoe',
            'name'                => 'John Doe',
            'email'               => 'john@audit.test',
            'role'                => 'employee',
            'role_code'           => 'employee',
            'role_id'             => 'role-employee',
            'company_id'          => $this->companyId,
            'branch_id'           => $this->branchId,
            'department_id'       => $this->deptId,
            'employee_id'         => $this->empId,
            'selected_company_id' => $this->companyId,
            'permissions'         => [
                'dashboard.view',
                'profile.edit',
                'attendance.clock',
            ],
        ];

        $response = $this->withSession($employeeSession)
                         ->withHeaders(['X-Requested-With' => 'XMLHttpRequest'])
                         ->call('get', 'api/dashboard/customizable-widgets');

        $response->assertStatus(200);
        $data = json_decode($response->getJSON(), true);
        $this->assertTrue($data['success'] ?? false);

        $widgetCodes = array_column($data['data'] ?? [], 'code');
        $this->assertNotContains(
            'my_upcoming_leaves',
            $widgetCodes,
            "Admin-disabled widget 'my_upcoming_leaves' must NOT appear in employee customizable widgets."
        );
    }

    /**
     * Requirement 5:
     * Verify alias route /api/dashboard/preferences/customizable-widgets functions identically.
     */
    public function testPreferencesAliasCustomizableWidgetsEndpoint(): void
    {
        $employeeSession = [
            'id'                  => $this->userId,
            'user_id'             => $this->userId,
            'username'            => 'johndoe',
            'name'                => 'John Doe',
            'email'               => 'john@audit.test',
            'role'                => 'employee',
            'role_code'           => 'employee',
            'role_id'             => 'role-employee',
            'company_id'          => $this->companyId,
            'branch_id'           => $this->branchId,
            'department_id'       => $this->deptId,
            'employee_id'         => $this->empId,
            'selected_company_id' => $this->companyId,
            'permissions'         => [
                'dashboard.view',
                'profile.edit',
                'attendance.clock',
            ],
        ];

        $response = $this->withSession($employeeSession)
                         ->withHeaders(['X-Requested-With' => 'XMLHttpRequest'])
                         ->call('get', 'api/dashboard/preferences/customizable-widgets');

        $response->assertStatus(200);
        $data = json_decode($response->getJSON(), true);
        $this->assertTrue($data['success'] ?? false);
        $this->assertNotEmpty($data['data']);
    }

    /**
     * Requirement: Migration Idempotency Test
     * Run the migration twice -> row counts identical on the second run.
     */
    public function testMigrationRunsTwiceWithIdenticalRowCounts(): void
    {
        // 1. Seed legacy tables with unique records
        $this->db->table('dashboard_role_widgets')->insert([
            'id'         => 'drw-mig-test-1',
            'role_code'  => 'auditor',
            'widget_id'  => 'w-emp-quick-01',
            'status'     => 1,
            'sort_order' => 10,
            'grid_width' => 'full',
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        $this->db->table('dashboard_company_widgets')->insert([
            'id'         => 'dcw-mig-test-1',
            'company_id' => $this->companyId,
            'widget_id'  => 'w-admin-payroll-04',
            'status'     => 0,
            'sort_order' => 5,
            'grid_width' => 'half',
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        $this->db->table('dashboard_user_preferences')->insert([
            'id'         => 'dup-mig-test-1',
            'user_id'    => $this->userId,
            'widget_id'  => 'w-emp-punch-02',
            'status'     => 0,
            'sort_order' => 2,
            'grid_width' => 'half',
            'settings'   => json_encode(['theme' => 'dark']),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        $migration = new \App\Database\Migrations\MigrateLegacyDashboardWidgetsToAssignments();

        // Run migration first time
        $migration->up();
        $firstRunCount = $this->db->table('dashboard_widget_assignments')->countAllResults();
        $this->assertGreaterThan(0, $firstRunCount, "Migration should populate dashboard_widget_assignments from legacy tables.");

        // Verify migrated fields
        $migratedRole = $this->db->table('dashboard_widget_assignments')
            ->where('scope_type', 'role')
            ->where('scope_id', 'auditor')
            ->where('widget_id', 'w-emp-quick-01')
            ->get()->getRowArray();
        $this->assertNotNull($migratedRole, "Role record should be migrated.");
        $this->assertEquals(1, $migratedRole['status']);
        $this->assertEquals(10, $migratedRole['sort_order']);
        $this->assertEquals('full', $migratedRole['grid_width']);

        $migratedCompany = $this->db->table('dashboard_widget_assignments')
            ->where('scope_type', 'company')
            ->where('scope_id', $this->companyId)
            ->where('widget_id', 'w-admin-payroll-04')
            ->get()->getRowArray();
        $this->assertNotNull($migratedCompany, "Company record should be migrated.");
        $this->assertEquals(0, $migratedCompany['status']);
        $this->assertEquals(5, $migratedCompany['sort_order']);

        $migratedUser = $this->db->table('dashboard_widget_assignments')
            ->where('scope_type', 'user')
            ->where('scope_id', $this->userId)
            ->where('widget_id', 'w-emp-punch-02')
            ->get()->getRowArray();
        $this->assertNotNull($migratedUser, "User record should be migrated.");
        $this->assertEquals(0, $migratedUser['status']);
        $this->assertNotNull($migratedUser['settings']);

        // Run migration second time (Idempotency assertion)
        $migration->up();
        $secondRunCount = $this->db->table('dashboard_widget_assignments')->countAllResults();

        $this->assertSame(
            $firstRunCount,
            $secondRunCount,
            "Migration must be strictly idempotent: row count after 2nd run ({$secondRunCount}) must equal 1st run ({$firstRunCount})."
        );
    }

    /**
     * Requirement: Toggling a role widget changes ONLY dashboard_widget_assignments.
     * Legacy tables must remain completely untouched.
     */
    public function testTogglingRoleWidgetChangesOnlyDashboardWidgetAssignments(): void
    {
        $dashboardService = new DashboardService();

        // Capture initial legacy counts and snapshots
        $initialRoleRows = $this->db->table('dashboard_role_widgets')->get()->getResultArray();
        $initialCompanyCount = $this->db->table('dashboard_company_widgets')->countAllResults();
        $initialUserCount = $this->db->table('dashboard_user_preferences')->countAllResults();

        // Toggle role widget
        $result = $dashboardService->toggleWidgetStatus('w-emp-quick-01', 'role', 'employee', 0, $this->adminUserId);
        $this->assertTrue($result['success']);

        // Assert dashboard_widget_assignments was updated
        $assignment = $this->db->table('dashboard_widget_assignments')
            ->where('scope_type', 'role')
            ->where('scope_id', 'employee')
            ->where('widget_id', 'w-emp-quick-01')
            ->get()->getRowArray();

        $this->assertNotNull($assignment);
        $this->assertEquals(0, $assignment['status'], "dashboard_widget_assignments status must be updated to 0.");

        // Assert legacy tables remained unchanged
        $afterRoleRows = $this->db->table('dashboard_role_widgets')->get()->getResultArray();
        $afterCompanyCount = $this->db->table('dashboard_company_widgets')->countAllResults();
        $afterUserCount = $this->db->table('dashboard_user_preferences')->countAllResults();

        $this->assertSame($initialRoleRows, $afterRoleRows, "dashboard_role_widgets must NOT be altered when toggling role widget.");
        $this->assertSame($initialCompanyCount, $afterCompanyCount, "dashboard_company_widgets must NOT be altered.");
        $this->assertSame($initialUserCount, $afterUserCount, "dashboard_user_preferences must NOT be altered.");
    }

    /**
     * Requirement: Toggling a company widget changes ONLY dashboard_widget_assignments.
     * Legacy tables must remain completely untouched.
     */
    public function testTogglingCompanyWidgetChangesOnlyDashboardWidgetAssignments(): void
    {
        $dashboardService = new DashboardService();

        $initialRoleCount = $this->db->table('dashboard_role_widgets')->countAllResults();
        $initialCompanyRows = $this->db->table('dashboard_company_widgets')->get()->getResultArray();
        $initialUserCount = $this->db->table('dashboard_user_preferences')->countAllResults();

        // Toggle company widget
        $result = $dashboardService->toggleWidgetStatus('w-emp-punch-02', 'company', $this->companyId, 0, $this->adminUserId);
        $this->assertTrue($result['success']);

        // Assert dashboard_widget_assignments was written
        $assignment = $this->db->table('dashboard_widget_assignments')
            ->where('scope_type', 'company')
            ->where('scope_id', $this->companyId)
            ->where('widget_id', 'w-emp-punch-02')
            ->get()->getRowArray();

        $this->assertNotNull($assignment);
        $this->assertEquals(0, $assignment['status'], "dashboard_widget_assignments status must be updated to 0 for company scope.");

        // Assert legacy tables remain unchanged
        $afterRoleCount = $this->db->table('dashboard_role_widgets')->countAllResults();
        $afterCompanyRows = $this->db->table('dashboard_company_widgets')->get()->getResultArray();
        $afterUserCount = $this->db->table('dashboard_user_preferences')->countAllResults();

        $this->assertSame($initialCompanyRows, $afterCompanyRows, "dashboard_company_widgets must NOT be altered when toggling company widget.");
        $this->assertSame($initialRoleCount, $afterRoleCount, "dashboard_role_widgets must NOT be altered.");
        $this->assertSame($initialUserCount, $afterUserCount, "dashboard_user_preferences must NOT be altered.");
    }

    /**
     * Requirement: Toggling a user widget changes ONLY dashboard_widget_assignments.
     * Legacy tables must remain completely untouched.
     */
    public function testTogglingUserWidgetChangesOnlyDashboardWidgetAssignments(): void
    {
        $dashboardService = new DashboardService();

        $initialRoleCount = $this->db->table('dashboard_role_widgets')->countAllResults();
        $initialCompanyCount = $this->db->table('dashboard_company_widgets')->countAllResults();
        $initialUserRows = $this->db->table('dashboard_user_preferences')->get()->getResultArray();

        // Toggle user widget
        $result = $dashboardService->toggleUserWidget($this->userId, 'w-emp-quick-01', 0, 'employee', $this->companyId);
        $this->assertTrue($result['success']);

        // Assert dashboard_widget_assignments was written
        $assignment = $this->db->table('dashboard_widget_assignments')
            ->where('scope_type', 'user')
            ->where('scope_id', $this->userId)
            ->where('widget_id', 'w-emp-quick-01')
            ->get()->getRowArray();

        $this->assertNotNull($assignment);
        $this->assertEquals(0, $assignment['status'], "dashboard_widget_assignments status must be updated to 0 for user scope.");

        // Assert legacy tables remain unchanged
        $afterRoleCount = $this->db->table('dashboard_role_widgets')->countAllResults();
        $afterCompanyCount = $this->db->table('dashboard_company_widgets')->countAllResults();
        $afterUserRows = $this->db->table('dashboard_user_preferences')->get()->getResultArray();

        $this->assertSame($initialUserRows, $afterUserRows, "dashboard_user_preferences must NOT be altered when toggling user widget.");
        $this->assertSame($initialRoleCount, $afterRoleCount, "dashboard_role_widgets must NOT be altered.");
        $this->assertSame($initialCompanyCount, $afterCompanyCount, "dashboard_company_widgets must NOT be altered.");
    }
}
