<?php

namespace Tests\Unit;

use App\Services\Mobile\MobileAuthService;
use CodeIgniter\Test\CIUnitTestCase;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

/**
 * Runs in separate processes: it owns the in-memory SQLite schema (users, employees, ...)
 */
#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobileAuthServiceTest extends CIUnitTestCase
{
    use MobileTestSchema;

    protected $db;
    private MobileAuthService $svc;
    private array $device = ['device_uid' => 'dev-test-1', 'platform' => 'android', 'device_name' => 'Pixel 7', 'app_version' => '1.0.0'];

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);

        $this->svc = new MobileAuthService($this->db);
    }

    private function login(string $code = 'ACME', string $id = 'rahim', string $pw = self::PASSWORD): array
    {
        return $this->svc->login($code, $id, $pw, $this->device, '10.0.0.1', 'PHPUnit');
    }

    public function testLoginSuccessReturnsTokens(): void
    {
        $res = $this->login();
        $this->assertTrue($res['ok'] ?? false);
        $this->assertSame(200, $res['status'] ?? 0);
        $this->assertNotEmpty($res['data']['tokens']['access_token'] ?? null);
        $this->assertNotEmpty($res['data']['tokens']['refresh_token'] ?? null);
    }

    public function testInvalidCredentialsReturnsError(): void
    {
        $res = $this->login('ACME', 'rahim', 'WrongPass!');
        $this->assertFalse($res['ok'] ?? true);
        $this->assertSame(401, $res['status'] ?? 0);
    }

    public function testRefreshTokenRotation(): void
    {
        $res = $this->login();
        $refreshToken = $res['data']['tokens']['refresh_token'];

        $refreshed = $this->svc->refresh($refreshToken, '10.0.0.1');
        $this->assertTrue($refreshed['ok'] ?? false);
        $this->assertNotEmpty($refreshed['data']['tokens']['access_token'] ?? null);
        $this->assertNotSame($refreshToken, $refreshed['data']['tokens']['refresh_token'] ?? null);
    }

    public function testReuseOfRefreshTokenRevokesFamily(): void
    {
        $res = $this->login();
        $refreshToken = $res['data']['tokens']['refresh_token'];

        // First refresh succeeds
        $firstRefresh = $this->svc->refresh($refreshToken, '10.0.0.1');
        $this->assertTrue($firstRefresh['ok'] ?? false);

        // Second refresh with old token detects reuse and revokes
        $reuseAttempt = $this->svc->refresh($refreshToken, '10.0.0.1');
        $this->assertFalse($reuseAttempt['ok'] ?? true);
        $this->assertSame(401, $reuseAttempt['status'] ?? 0);
    }

    public function testLogoutRevokesAccessToken(): void
    {
        $res = $this->login();
        $accessToken = $res['data']['tokens']['access_token'];

        $logoutRes = $this->svc->logout($accessToken);
        $this->assertTrue($logoutRes['ok'] ?? false);

        $authRes = $this->svc->authenticate($accessToken);
        $this->assertFalse($authRes['ok'] ?? true);
    }
}
