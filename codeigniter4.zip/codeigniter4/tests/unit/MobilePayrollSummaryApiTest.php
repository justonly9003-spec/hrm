<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

/**
 * MobilePayrollSummaryApiTest
 *
 * Verifies the authenticated employee payroll summary endpoints for the ESS mobile app:
 * - Route resolution: GET /api/mobile/v1/payroll/summary, GET /api/mobile/v1/payslips/summary, GET /api/v1/payroll/summary
 * - Authentication & Token validation via MobileAuthFilter
 * - Scoping strictly to authenticated employee_id and tenant company_id
 * - Anti-IDOR enforcement (query params employee_id and company_id)
 * - Period filtering (by year, specific month, date range, format validation 422)
 * - Payroll status distinction (Draft, Approved, Finalized, Paid)
 * - Invariant: Draft / unapproved records are NEVER treated as paid salary
 * - Handling empty records (clean 200 with 0.00 metrics, no mock or demo data)
 * - Inactive / separated employee access protection (403)
 * - Sensitive field exclusion (no bank numbers, passwords, internal hashes)
 */
#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobilePayrollSummaryApiTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);

        foreach (['payrolls', 'payroll_items'] as $t) {
            $this->db->query("DROP TABLE IF EXISTS {$t}");
        }

        $this->db->query("CREATE TABLE payrolls (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            payroll_month VARCHAR(10),
            status VARCHAR(20),
            is_locked INT DEFAULT 0
        )");

        $this->db->query("CREATE TABLE payroll_items (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36) NULL,
            payroll_id VARCHAR(36),
            employee_id VARCHAR(36),
            basic_salary DECIMAL(15,2) DEFAULT 0.00,
            gross_salary DECIMAL(15,2) DEFAULT 0.00,
            house_rent DECIMAL(15,2) DEFAULT 0.00,
            medical DECIMAL(15,2) DEFAULT 0.00,
            conveyance DECIMAL(15,2) DEFAULT 0.00,
            allowances DECIMAL(15,2) DEFAULT 0.00,
            other_allowances DECIMAL(15,2) DEFAULT 0.00,
            overtime_amount DECIMAL(15,2) DEFAULT 0.00,
            bonus_amount DECIMAL(15,2) DEFAULT 0.00,
            arrear_amount DECIMAL(15,2) DEFAULT 0.00,
            tax_deduction DECIMAL(15,2) DEFAULT 0.00,
            pf_deduction DECIMAL(15,2) DEFAULT 0.00,
            loan_emi DECIMAL(15,2) DEFAULT 0.00,
            advance_recovery DECIMAL(15,2) DEFAULT 0.00,
            total_deductions DECIMAL(15,2) DEFAULT 0.00,
            net_salary DECIMAL(15,2) DEFAULT 0.00,
            payment_status VARCHAR(20) DEFAULT 'Unpaid',
            bank_account_no VARCHAR(50) NULL,
            components_breakdown_json TEXT NULL
        )");
    }

    private function insertRows(string $table, array $rows): void
    {
        foreach ($rows as $r) {
            $this->db->table($table)->insert($r);
        }
    }

    private function token(string $company = 'ACME', string $id = 'rahim'): array
    {
        $res = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => $company,
            'identifier'   => $id,
            'password'     => self::PASSWORD,
            'device'       => ['device_uid' => 'dev-sal-summary'],
        ]);
        $json = json_decode($res->getJSON(), true);
        return ['Authorization' => 'Bearer ' . $json['data']['tokens']['access_token']];
    }

    private function json($res): array
    {
        return json_decode($res->getJSON(), true);
    }

    /**
     * Seed realistic payroll runs with multiple states:
     * - pr-sep26: 2026-09, Status=Paid, is_locked=1, Gross=85000, Ded=10000, Net=75000 (Paid)
     * - pr-aug26: 2026-08, Status=Approved, is_locked=1, Gross=80000, Ded=10000, Net=70000 (Pending payout)
     * - pr-oct26: 2026-10, Status=Draft, is_locked=0, Gross=90000, Ded=10000, Net=80000 (Draft unapproved)
     * - pr-dec25: 2025-12, Status=Paid, is_locked=1, Gross=70000, Ded=5000, Net=65000 (Prior year Paid)
     * - pr-c2:    2026-09, Company c-2 (Karim), Net=95000 (Other tenant)
     */
    private function seedPayrollData(): void
    {
        $this->insertRows('payrolls', [
            ['id' => 'pr-sep26', 'company_id' => 'c-1', 'payroll_month' => '2026-09', 'status' => 'Paid', 'is_locked' => 1],
            ['id' => 'pr-aug26', 'company_id' => 'c-1', 'payroll_month' => '2026-08', 'status' => 'Approved', 'is_locked' => 1],
            ['id' => 'pr-oct26', 'company_id' => 'c-1', 'payroll_month' => '2026-10', 'status' => 'Draft', 'is_locked' => 0],
            ['id' => 'pr-dec25', 'company_id' => 'c-1', 'payroll_month' => '2025-12', 'status' => 'Paid', 'is_locked' => 1],
            ['id' => 'pr-c2',    'company_id' => 'c-2', 'payroll_month' => '2026-09', 'status' => 'Paid', 'is_locked' => 1],
        ]);

        $this->insertRows('payroll_items', [
            [
                'id' => 'pi-sep26',
                'company_id' => 'c-1',
                'payroll_id' => 'pr-sep26',
                'employee_id' => 'e-1',
                'basic_salary' => 50000.00,
                'gross_salary' => 85000.00,
                'house_rent' => 25000.00,
                'medical' => 10000.00,
                'tax_deduction' => 5000.00,
                'pf_deduction' => 5000.00,
                'total_deductions' => 10000.00,
                'net_salary' => 75000.00,
                'payment_status' => 'Paid',
                'bank_account_no' => '9876543210',
            ],
            [
                'id' => 'pi-aug26',
                'company_id' => 'c-1',
                'payroll_id' => 'pr-aug26',
                'employee_id' => 'e-1',
                'basic_salary' => 50000.00,
                'gross_salary' => 80000.00,
                'house_rent' => 20000.00,
                'medical' => 10000.00,
                'tax_deduction' => 5000.00,
                'pf_deduction' => 5000.00,
                'total_deductions' => 10000.00,
                'net_salary' => 70000.00,
                'payment_status' => 'Unpaid',
                'bank_account_no' => '9876543210',
            ],
            [
                'id' => 'pi-oct26',
                'company_id' => 'c-1',
                'payroll_id' => 'pr-oct26',
                'employee_id' => 'e-1',
                'basic_salary' => 50000.00,
                'gross_salary' => 90000.00,
                'house_rent' => 30000.00,
                'medical' => 10000.00,
                'tax_deduction' => 5000.00,
                'pf_deduction' => 5000.00,
                'total_deductions' => 10000.00,
                'net_salary' => 80000.00,
                'payment_status' => 'Draft',
                'bank_account_no' => '9876543210',
            ],
            [
                'id' => 'pi-dec25',
                'company_id' => 'c-1',
                'payroll_id' => 'pr-dec25',
                'employee_id' => 'e-1',
                'basic_salary' => 45000.00,
                'gross_salary' => 70000.00,
                'house_rent' => 15000.00,
                'medical' => 10000.00,
                'tax_deduction' => 2500.00,
                'pf_deduction' => 2500.00,
                'total_deductions' => 5000.00,
                'net_salary' => 65000.00,
                'payment_status' => 'Paid',
                'bank_account_no' => '9876543210',
            ],
            [
                'id' => 'pi-c2',
                'company_id' => 'c-2',
                'payroll_id' => 'pr-c2',
                'employee_id' => 'e-2',
                'basic_salary' => 60000.00,
                'gross_salary' => 100000.00,
                'house_rent' => 30000.00,
                'medical' => 10000.00,
                'tax_deduction' => 5000.00,
                'pf_deduction' => 0.00,
                'total_deductions' => 5000.00,
                'net_salary' => 95000.00,
                'payment_status' => 'Paid',
                'bank_account_no' => '5555555555',
            ],
        ]);
    }

    public function testUnauthenticatedAccessIsRejected(): void
    {
        $res = $this->get('api/mobile/v1/payroll/summary');
        $res->assertStatus(401);

        $res2 = $this->get('api/v1/payroll/summary');
        $res2->assertStatus(401);
    }

    public function testRouteResolutionAndStandardEnvelope(): void
    {
        $this->seedPayrollData();
        $token = $this->token();

        // 1. Mobile v1 payroll/summary
        $res1 = $this->withHeaders($token)->get('api/mobile/v1/payroll/summary');
        $res1->assertStatus(200);
        $d1 = $this->json($res1);
        $this->assertTrue($d1['success']);
        $this->assertSame('success', $d1['status']);
        $this->assertArrayHasKey('summary', $d1['data']);
        $this->assertArrayHasKey('status_breakdown', $d1['data']);
        $this->assertArrayHasKey('employee', $d1['data']);

        // 2. Mobile v1 payslips/summary
        $res2 = $this->withHeaders($token)->get('api/mobile/v1/payslips/summary');
        $res2->assertStatus(200);

        // 3. API v1 payroll/summary
        $res3 = $this->withHeaders($token)->get('api/v1/payroll/summary');
        $res3->assertStatus(200);
    }

    public function testYearFilterComputesExactYearAggregates(): void
    {
        $this->seedPayrollData();
        $token = $this->token();

        // Query FY 2026
        $res = $this->withHeaders($token)->get('api/mobile/v1/payroll/summary?year=2026');
        $res->assertStatus(200);
        $body = $this->json($res)['data'];

        $this->assertSame('year', $body['period']['type']);
        $this->assertSame('2026', $body['period']['year']);

        // In 2026: 2 published payslips (2026-09 and 2026-08). Draft 2026-10 is excluded from official total.
        $this->assertEquals(2, $body['summary']['total_payslips']);
        $this->assertEquals(100000.00, $body['summary']['total_basic_salary']); // 50000 + 50000
        $this->assertEquals(165000.00, $body['summary']['total_gross_salary']); // 85000 + 80000
        $this->assertEquals(20000.00, $body['summary']['total_deductions']);    // 10000 + 10000
        $this->assertEquals(145000.00, $body['summary']['total_net_salary']);    // 75000 + 70000

        // Status breakdown: Paid vs Pending
        $this->assertEquals(1, $body['status_breakdown']['paid']['count']);
        $this->assertEquals(75000.00, $body['status_breakdown']['paid']['net_salary']);
        $this->assertEquals(1, $body['status_breakdown']['approved_pending_disbursement']['count']);
        $this->assertEquals(70000.00, $body['status_breakdown']['approved_pending_disbursement']['net_salary']);

        // Available years should list both 2026 and 2025
        $this->assertContains('2026', $body['available_years']);
        $this->assertContains('2025', $body['available_years']);
    }

    public function testDraftRecordsAreDistinguishedAndNeverTreatedAsPaid(): void
    {
        $this->seedPayrollData();
        $token = $this->token();

        $res = $this->withHeaders($token)->get('api/mobile/v1/payroll/summary?year=2026');
        $res->assertStatus(200);
        $body = $this->json($res)['data'];

        $draft = $body['status_breakdown']['draft_unapproved'];
        $this->assertEquals(1, $draft['count']);
        $this->assertEquals(80000.00, $draft['net_salary']);
        $this->assertEquals(0.00, $draft['amount_treated_as_paid']);
        $this->assertStringContainsString('excluded from paid salary', $draft['note']);

        // The paid salary must strictly equal the paid payslip amount (75000), NEVER including draft (80000)
        $this->assertEquals(75000.00, $body['summary']['total_paid_salary']);
        $this->assertEquals(70000.00, $body['summary']['total_pending_disbursement']);
    }

    public function testMonthFilterAndRangeFilter(): void
    {
        $this->seedPayrollData();
        $token = $this->token();

        // 1. Single month filter: 2026-09
        $resMonth = $this->withHeaders($token)->get('api/mobile/v1/payroll/summary?month=2026-09');
        $resMonth->assertStatus(200);
        $dMonth = $this->json($resMonth)['data'];

        $this->assertSame('month', $dMonth['period']['type']);
        $this->assertSame('2026-09', $dMonth['period']['month']);
        $this->assertEquals(1, $dMonth['summary']['total_payslips']);
        $this->assertEquals(75000.00, $dMonth['summary']['total_net_salary']);
        $this->assertEquals(75000.00, $dMonth['summary']['total_paid_salary']);

        // 2. Date range filter: 2025-12 to 2026-08
        $resRange = $this->withHeaders($token)->get('api/mobile/v1/payroll/summary?from=2025-12&to=2026-08');
        $resRange->assertStatus(200);
        $dRange = $this->json($resRange)['data'];

        $this->assertSame('range', $dRange['period']['type']);
        // Contains pi-dec25 (65000) and pi-aug26 (70000)
        $this->assertEquals(2, $dRange['summary']['total_payslips']);
        $this->assertEquals(135000.00, $dRange['summary']['total_net_salary']);
    }

    public function testInvalidFilterFormatsReturn422(): void
    {
        $token = $this->token();

        // Invalid year
        $r1 = $this->withHeaders($token)->get('api/mobile/v1/payroll/summary?year=26');
        $r1->assertStatus(422);

        // Invalid month
        $r2 = $this->withHeaders($token)->get('api/mobile/v1/payroll/summary?month=not-a-month');
        $r2->assertStatus(422);

        // Invalid range: from after to
        $r3 = $this->withHeaders($token)->get('api/mobile/v1/payroll/summary?from=2026-12&to=2026-01');
        $r3->assertStatus(422);
    }

    public function testEmptyResultsReturnsZeroTotalsAndNoDemoData(): void
    {
        // No payroll records inserted
        $token = $this->token();

        $res = $this->withHeaders($token)->get('api/mobile/v1/payroll/summary');
        $res->assertStatus(200);
        $body = $this->json($res)['data'];

        $this->assertEquals(0, $body['summary']['total_payslips']);
        $this->assertEquals(0.00, $body['summary']['total_gross_salary']);
        $this->assertEquals(0.00, $body['summary']['total_net_salary']);
        $this->assertEquals(0.00, $body['summary']['total_paid_salary']);
        $this->assertEquals(0.00, $body['summary']['total_pending_disbursement']);
        $this->assertEquals(0, $body['status_breakdown']['paid']['count']);
        $this->assertEquals(0, $body['status_breakdown']['approved_pending_disbursement']['count']);
        $this->assertEquals(0, $body['status_breakdown']['draft_unapproved']['count']);
        $this->assertNull($body['latest_payslip']);
        $this->assertEmpty($body['recent_payslips']);
        $this->assertEmpty($body['available_years']);
    }

    public function testTenantIsolationAndIdorDefenses(): void
    {
        $this->seedPayrollData();
        $token = $this->token();

        // Rahim (Company c-1, Employee e-1) attempts to query Karim's ID
        $idorEmp = $this->withHeaders($token)->get('api/mobile/v1/payroll/summary?employee_id=e-2');
        $idorEmp->assertStatus(403);

        // Rahim attempts cross-tenant query for Company c-2
        $idorComp = $this->withHeaders($token)->get('api/mobile/v1/payroll/summary?company_id=c-2');
        $idorComp->assertStatus(403);

        // Normal query must NOT include Karim's 95000 BDT in Rahim's summary
        $norm = $this->withHeaders($token)->get('api/mobile/v1/payroll/summary');
        $norm->assertStatus(200);
        $rawJson = $norm->getJSON();
        $this->assertStringNotContainsString('95000', $rawJson);
        $this->assertStringNotContainsString('pi-c2', $rawJson);
    }

    public function testSeparatedEmployeeIsForbidden(): void
    {
        $token = $this->token();

        // Set employee status to Terminated
        $this->db->table('employees')->where('id', 'e-1')->update(['status' => 'Terminated']);

        $res = $this->withHeaders($token)->get('api/mobile/v1/payroll/summary');
        $res->assertStatus(403);
        $json = $this->json($res);
        $this->assertFalse($json['success']);
        $this->assertStringContainsString('inactive or separated', $json['message']);
    }

    public function testSensitiveFieldsAreNeverExposed(): void
    {
        $this->seedPayrollData();
        $token = $this->token();

        $res = $this->withHeaders($token)->get('api/mobile/v1/payroll/summary');
        $res->assertStatus(200);
        $raw = $res->getJSON();

        $this->assertStringNotContainsString('9876543210', $raw); // Bank account number redacted
        $this->assertStringNotContainsString('password_hash', $raw);
        $this->assertStringNotContainsString('created_by', $raw);
    }
}
