<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\Leave\LeaveApplicationService;

/**
 * The backdated role requirement may add or swap an approver tier,
 * but it must never remove a tier that the day-based policy already requires.
 */
class LeaveBackdatedResolverNeverWeakensTest extends TestCase
{
    private array $workflow;

    protected function setUp(): void
    {
        parent::setUp();
        $this->workflow = [
            'workflow_type'   => 'Multi-Tier',
            'tier_conditions' => [
                ['min_days' => 1, 'max_days' => 2,   'required_approvers' => ['Manager']],
                ['min_days' => 3, 'max_days' => 7,   'required_approvers' => ['Manager', 'HR Admin']],
                ['min_days' => 8, 'max_days' => 999, 'required_approvers' => ['Manager', 'Department Head', 'HR Admin']],
            ],
        ];
    }

    public function testHrOnlyOnLongLeaveKeepsManagerDeptHeadAndHr(): void
    {
        $r = LeaveApplicationService::resolveRequiredApproversForApplication($this->workflow, 10.0, true, 'HR Only');
        $this->assertEquals(['Manager', 'Department Head', 'HR Admin'], $r);
    }

    public function testHrOnlyOnMidLeaveKeepsManagerAndHr(): void
    {
        $r = LeaveApplicationService::resolveRequiredApproversForApplication($this->workflow, 5.0, true, 'HR Only');
        $this->assertEquals(['Manager', 'HR Admin'], $r);
    }

    public function testHrOnlyOnShortLeaveSwapsManagerForHr(): void
    {
        $r = LeaveApplicationService::resolveRequiredApproversForApplication($this->workflow, 1.0, true, 'HR Only');
        $this->assertEquals(['HR Admin'], $r);
    }

    public function testManagerRoleOnMidLeaveKeepsHr(): void
    {
        $r = LeaveApplicationService::resolveRequiredApproversForApplication($this->workflow, 5.0, true, 'Manager');
        $this->assertEquals(['Manager', 'HR Admin'], $r);
    }

    public function testManagerRoleOnLongLeaveKeepsDeptHeadAndHr(): void
    {
        $r = LeaveApplicationService::resolveRequiredApproversForApplication($this->workflow, 9.0, true, 'Manager');
        $this->assertEquals(['Manager', 'Department Head', 'HR Admin'], $r);
    }

    public function testManagerRoleOnShortLeaveStaysManagerOnly(): void
    {
        $r = LeaveApplicationService::resolveRequiredApproversForApplication($this->workflow, 1.0, true, 'Manager');
        $this->assertEquals(['Manager'], $r);
    }

    public function testManagerAndHrOnShortLeaveAddsHr(): void
    {
        $r = LeaveApplicationService::resolveRequiredApproversForApplication($this->workflow, 1.0, true, 'Manager and HR');
        $this->assertEquals(['Manager', 'HR Admin'], $r);
    }

    public function testNotBackdatedIgnoresRole(): void
    {
        $r = LeaveApplicationService::resolveRequiredApproversForApplication($this->workflow, 1.0, false, 'HR Only');
        $this->assertEquals(['Manager'], $r);
    }
}
