<?php

namespace Tests\Unit;

use App\Commands\WeekendReconcile;
use App\Controllers\Master\CompanyController;
use App\Controllers\Mobile\MobileCompanyController;
use App\Models\AttendanceModel;
use App\Services\CompanyWeekendService;
use App\Services\Rules\RuleResolver;
use App\Services\Rules\RuleSeeder;
use App\Services\Rules\RuleWriteService;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\URI;
use CodeIgniter\HTTP\UserAgent;
use CodeIgniter\Test\CIUnitTestCase;
use Config\App;
use Config\Database;
use Config\Services;

class WeekendSingleSourceAndReconcileTest extends CIUnitTestCase
{
    private $db;
    private string $companyId = 'comp-wknd-reconcile-test';

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->cleanupTestArtifacts();
        $this->seedTestCompany();
    }

    protected function tearDown(): void
    {
        $this->cleanupTestArtifacts();
        parent::tearDown();
    }

    private function cleanupTestArtifacts(): void
    {
        if ($this->db->tableExists('rule_change_log')) {
            $this->db->table('rule_change_log')->where('company_id', $this->companyId)->delete();
        }
        if ($this->db->tableExists('rule_definitions')) {
            $this->db->table('rule_definitions')->where('company_id', $this->companyId)->delete();
        }
        if ($this->db->tableExists('companies')) {
            $this->db->table('companies')->where('id', $this->companyId)->delete();
        }
        CompanyWeekendService::clearCache();
        if (method_exists(RuleResolver::class, 'flushAll')) {
            RuleResolver::flushAll();
        }
    }

    private function seedTestCompany(): void
    {
        if ($this->db->tableExists('companies')) {
            $this->db->table('companies')->insert([
                'id'           => $this->companyId,
                'code'         => 'WKND-TST',
                'name'         => 'Weekend Single Source Test Co',
                'short_name'   => 'WSTC',
                'status'       => 'Active',
                'weekly_off'   => json_encode(['Friday']),
                'working_days' => json_encode(['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Saturday']),
                'created_at'   => date('Y-m-d H:i:s'),
                'updated_at'   => date('Y-m-d H:i:s'),
            ]);
        }

        $seeder = new RuleSeeder($this->db);
        $seeder->seedCompany($this->companyId, '2020-01-01', 'test-seeder');
        CompanyWeekendService::clearCache();
        if (method_exists(RuleResolver::class, 'flushAll')) {
            RuleResolver::flushAll();
        }
    }

    /**
     * (a) Save from Company Profile path, then getCompanyWeeklyOff returns the same days.
     */
    public function testSaveFromCompanyProfilePathUpdatesRuleAndGetCompanyWeeklyOffReturnsSameDays(): void
    {
        $res = CompanyWeekendService::saveWeeklyOff(
            $this->companyId,
            ['Friday', 'Saturday'],
            'admin-actor',
            'Company Profile',
            true
        );

        $this->assertTrue($res['ok']);
        $this->assertEmpty($res['errors']);
        $this->assertSame(['Friday', 'Saturday'], $res['days']);

        $resolved = CompanyWeekendService::getCompanyWeeklyOff($this->companyId);
        $this->assertSame(['Friday', 'Saturday'], $resolved);

        $compRow = $this->db->table('companies')->where('id', $this->companyId)->get()->getRowArray();
        $this->assertSame(['Friday', 'Saturday'], json_decode((string)$compRow['weekly_off'], true));
        $this->assertSame(
            ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday'],
            json_decode((string)$compRow['working_days'], true)
        );
    }

    /**
     * (b) Publish from the Rule Engine, then the company_profile view data and companies.weekly_off mirror show the same days.
     */
    public function testPublishFromRuleEngineSyncsCompanyMirrorAndCompanyProfileViewData(): void
    {
        $ruleWriteService = new RuleWriteService($this->db);
        $currentRule = RuleResolver::resolveForCompany($this->companyId, 'ATTENDANCE', date('Y-m-d'));
        $params = $currentRule->params();
        $params['weekly_off_days'] = ['Thursday', 'Friday'];

        // Publish via RuleWriteService::publishRule (Rule Engine direct publish)
        $ruleWriteService->publishRule(
            $this->companyId,
            'ATTENDANCE',
            'Company',
            null,
            $params,
            date('Y-m-d'),
            null,
            'Rule Engine publish test',
            'rule-engine-admin'
        );

        // Verify companies.weekly_off and companies.working_days mirror
        $compRow = $this->db->table('companies')->where('id', $this->companyId)->get()->getRowArray();
        $this->assertSame(['Thursday', 'Friday'], json_decode((string)$compRow['weekly_off'], true));
        $this->assertSame(
            ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Saturday'],
            json_decode((string)$compRow['working_days'], true)
        );

        // Verify company_profile view data via CompanyController::profile() and CompanyWeekendService
        $this->assertSame(['Thursday', 'Friday'], CompanyWeekendService::getCompanyWeeklyOff($this->companyId));
        $this->assertSame(
            ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Saturday'],
            CompanyWeekendService::getCompanyWorkingDays($this->companyId)
        );

        // Also test draft -> publishExistingVersion path (RuleController::publishVersion path)
        $paramsDraft = $params;
        $paramsDraft['weekly_off_days'] = ['Saturday'];
        $draftId = $ruleWriteService->saveDraft(
            $this->companyId,
            'ATTENDANCE',
            'Company',
            null,
            $paramsDraft,
            date('Y-m-d', strtotime('+1 day')),
            null,
            'Draft weekend change',
            'rule-engine-admin'
        );

        $ruleWriteService->publishExistingVersion(
            $draftId,
            'rule-engine-admin',
            date('Y-m-d'),
            null,
            'Publish draft version via Rule Engine'
        );

        $compRowAfterDraft = $this->db->table('companies')->where('id', $this->companyId)->get()->getRowArray();
        $this->assertSame(['Saturday'], json_decode((string)$compRowAfterDraft['weekly_off'], true));
        $this->assertSame(['Saturday'], CompanyWeekendService::getCompanyWeeklyOff($this->companyId));

        // Verify CompanyController::profile() view data contains the same days
        $_SESSION['isLoggedIn'] = true;
        $_SESSION['user_id']    = 'rule-engine-admin';
        $_SESSION['role']       = 'HR Admin';
        $_SESSION['company_id'] = $this->companyId;

        $capturedViewData = null;
        $controller = new class ($capturedViewData) extends CompanyController {
            public $captured;
            public function __construct(&$captured)
            {
                $this->captured = &$captured;
            }
            protected function requireLogin()
            {
                return null;
            }
            protected function authorize(string $permission)
            {
                return null;
            }
            protected function resolveActiveCompanyId(): ?string
            {
                return 'comp-wknd-reconcile-test';
            }
            protected function isSoftwareAppAdmin(): bool
            {
                return false;
            }
            protected function renderView(string $view, array $data = []): string
            {
                $this->captured = $data;
                return 'rendered';
            }
        };

        $request = new IncomingRequest(new App(), new URI('http://localhost/master/company-profile'), null, new UserAgent());
        $controller->initController($request, Services::response(), Services::logger());
        $controller->profile();

        $this->assertIsArray($capturedViewData);
        $this->assertSame(['Saturday'], $capturedViewData['savedWeeklyOff']);
        $this->assertSame(
            ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
            $capturedViewData['savedWorkingDays']
        );
    }

    /**
     * (c) Attendance Settings save without weekendDays leaves the weekend unchanged.
     */
    public function testAttendanceSettingsSaveWithoutWeekendDaysLeavesWeekendUnchanged(): void
    {
        // Set initial weekend to Friday & Saturday
        CompanyWeekendService::saveWeeklyOff(
            $this->companyId,
            ['Friday', 'Saturday'],
            'admin-actor',
            'Company Profile',
            true
        );

        $this->assertSame(['Friday', 'Saturday'], CompanyWeekendService::getCompanyWeeklyOff($this->companyId));

        // Save Attendance Settings WITHOUT 'weekendDays' key
        $attendanceModel = new AttendanceModel();
        $saved = $attendanceModel->savePolicySettings([
            'graceTime'          => 20,
            'standardDailyHours' => 8.5,
            'officeStartTime'    => '09:30',
            'officeEndTime'      => '18:00',
        ], $this->companyId);

        $this->assertTrue($saved);

        // Weekend in both rule_definitions and companies.weekly_off must remain ['Friday', 'Saturday']
        $this->assertSame(['Friday', 'Saturday'], CompanyWeekendService::getCompanyWeeklyOff($this->companyId));

        $compRow = $this->db->table('companies')->where('id', $this->companyId)->get()->getRowArray();
        $this->assertSame(['Friday', 'Saturday'], json_decode((string)$compRow['weekly_off'], true));

        $resolvedRule = RuleResolver::resolveForCompany($this->companyId, 'ATTENDANCE', date('Y-m-d'));
        $this->assertSame(['Friday', 'Saturday'], $resolvedRule->get('weekly_off_days'));
        $this->assertSame(20, (int)$resolvedRule->get('late_grace_minutes'));
    }

    /**
     * (d) saveWeeklyOff([]) is rejected.
     */
    public function testSaveWeeklyOffEmptyArrayIsRejected(): void
    {
        $beforeDays = CompanyWeekendService::getCompanyWeeklyOff($this->companyId);
        $this->assertSame(['Friday'], $beforeDays);

        $res = CompanyWeekendService::saveWeeklyOff(
            $this->companyId,
            [],
            'admin-actor',
            'Company Profile',
            true
        );

        $this->assertFalse($res['ok']);
        $this->assertContains('Select at least one weekly off day', $res['errors']);
        $this->assertSame([], $res['days']);

        // Existing rule and mirror remain untouched
        $this->assertSame(['Friday'], CompanyWeekendService::getCompanyWeeklyOff($this->companyId));
        $compRow = $this->db->table('companies')->where('id', $this->companyId)->get()->getRowArray();
        $this->assertSame(['Friday'], json_decode((string)$compRow['weekly_off'], true));
    }

    /**
     * (e) MobileCompanyController response matches the rule.
     */
    public function testMobileCompanyControllerResponseMatchesRule(): void
    {
        CompanyWeekendService::saveWeeklyOff(
            $this->companyId,
            ['Friday', 'Saturday'],
            'admin-actor',
            'Rule Engine',
            true
        );

        $controller = new MobileCompanyController();
        $request    = new IncomingRequest(new App(), new URI('http://localhost/api/v1/mobile/company/' . $this->companyId), null, new UserAgent());
        $response   = Services::response();
        $logger     = Services::logger();
        $controller->initController($request, $response, $logger);

        $res  = $controller->details($this->companyId);
        $body = json_decode($res->getBody(), true);

        $this->assertIsArray($body);
        $this->assertTrue($body['success'] ?? false);

        $ruleDays = CompanyWeekendService::getCompanyWeeklyOff($this->companyId);
        $this->assertSame(['Friday', 'Saturday'], $ruleDays);
        $this->assertSame($ruleDays, $body['data']['weekly_off']);
        $this->assertSame(
            ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday'],
            $body['data']['working_days']
        );
        $this->assertSame($ruleDays, $body['data']['weekly_off_details']['weekly_off_days']);
    }

    /**
     * WeekendReconcile command dry-run, --apply --prefer=rule, and --apply --prefer=column.
     */
    public function testWeekendReconcileDryRunAndApplyPreferRuleOrColumn(): void
    {
        $cmd = new WeekendReconcile(Services::logger(), Services::commands());

        // 1. Initially in sync -> 'match'
        $rows = $cmd->reconcile($this->companyId, false, 'rule');
        $this->assertCount(1, $rows);
        $this->assertSame('match', $rows[0]['status']);
        $this->assertFalse($rows[0]['applied']);

        // 2. Desynchronize column to comma-separated "Friday, Saturday" while rule has ['Friday']
        $this->db->table('companies')->where('id', $this->companyId)->update([
            'weekly_off' => 'Friday, Saturday',
        ]);

        // Dry run detects mismatch without writing
        $dryRows = $cmd->reconcile($this->companyId, false, 'rule');
        $this->assertSame('mismatch', $dryRows[0]['status']);
        $this->assertSame(['Friday'], $dryRows[0]['rule_days']);
        $this->assertSame(['Friday', 'Saturday'], $dryRows[0]['column_days']);
        $this->assertFalse($dryRows[0]['applied']);

        $compAfterDry = $this->db->table('companies')->where('id', $this->companyId)->get()->getRowArray();
        $this->assertSame('Friday, Saturday', $compAfterDry['weekly_off']);

        // 3. Apply with --prefer=rule updates companies.weekly_off and working_days mirror from the rule
        $applyRuleRows = $cmd->reconcile($this->companyId, true, 'rule');
        $this->assertSame('mismatch', $applyRuleRows[0]['status']);
        $this->assertTrue($applyRuleRows[0]['applied']);

        $compAfterRulePrefer = $this->db->table('companies')->where('id', $this->companyId)->get()->getRowArray();
        $this->assertSame(['Friday'], json_decode((string)$compAfterRulePrefer['weekly_off'], true));

        // 4. Desynchronize column to ['Thursday', 'Friday'] and apply with --prefer=column
        $this->db->table('companies')->where('id', $this->companyId)->update([
            'weekly_off' => json_encode(['Thursday', 'Friday']),
        ]);

        $applyColRows = $cmd->reconcile($this->companyId, true, 'column');
        $this->assertSame('mismatch', $applyColRows[0]['status']);
        $this->assertTrue($applyColRows[0]['applied']);
        $this->assertSame(['Thursday', 'Friday'], CompanyWeekendService::getCompanyWeeklyOff($this->companyId));

        // 5. Never write an empty list when column is empty and --prefer=column
        $this->db->table('companies')->where('id', $this->companyId)->update([
            'weekly_off' => '',
        ]);
        $missingColRows = $cmd->reconcile($this->companyId, true, 'column');
        $this->assertSame('column missing', $missingColRows[0]['status']);
        $this->assertFalse($missingColRows[0]['applied']);
        $this->assertSame(['Thursday', 'Friday'], CompanyWeekendService::getCompanyWeeklyOff($this->companyId));
    }
}
