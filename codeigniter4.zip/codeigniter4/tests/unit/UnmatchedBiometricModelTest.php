<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Models\UnmatchedBiometricModel;
use App\Models\RawBiometricEventModel;
use App\Models\BiometricMappingModel;

class UnmatchedBiometricModelTest extends TestCase
{
    /**
     * @testdox Get unmatched identities method exists
     */
    public function testGetUnmatchedIdentitiesMethodExists()
    {
        $this->assertTrue(
            method_exists(UnmatchedBiometricModel::class, 'getUnmatchedIdentities'),
            'UnmatchedBiometricModel must implement getUnmatchedIdentities()'
        );
    }

    /**
     * @testdox Get unprocessed raw count method exists
     */
    public function testGetUnprocessedRawCountMethodExists()
    {
        $this->assertTrue(
            method_exists(RawBiometricEventModel::class, 'getUnprocessedRawCount'),
            'RawBiometricEventModel must implement getUnprocessedRawCount()'
        );
    }

    /**
     * @testdox Get established mappings method exists
     */
    public function testGetEstablishedMappingsMethodExists()
    {
        $this->assertTrue(
            method_exists(BiometricMappingModel::class, 'getEstablishedMappings'),
            'BiometricMappingModel must implement getEstablishedMappings()'
        );
    }
}
