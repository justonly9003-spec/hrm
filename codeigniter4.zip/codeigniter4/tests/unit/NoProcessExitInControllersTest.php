<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;

/**
 * Process Exit Guard Test
 *
 * Ensures controllers never invoke bare `exit;` or `die(` directly,
 * preventing premature process termination during test execution.
 * Only BaseController::terminate() is allowed to invoke exit when ENVIRONMENT !== 'testing'.
 */
class NoProcessExitInControllersTest extends TestCase
{
    public function testNoBareExitOrDieInControllers()
    {
        $controllersDir = realpath(dirname(__DIR__, 2) . '/app/Controllers');
        $this->assertNotEmpty($controllersDir, 'Controllers directory must exist');
        $this->assertDirectoryExists($controllersDir);

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($controllersDir, RecursiveDirectoryIterator::SKIP_DOTS)
        );

        $violations = [];
        $scannedCount = 0;

        foreach ($iterator as $file) {
            if ($file->getExtension() !== 'php') {
                continue;
            }

            $scannedCount++;
            $filePath = $file->getPathname();
            $relativePath = str_replace(dirname(__DIR__, 2) . DIRECTORY_SEPARATOR, '', $filePath);
            $content = file_get_contents($filePath);

            $tokens = token_get_all($content);
            $currentFunction = null;
            $braceLevel = 0;
            $functionBraceLevel = null;

            for ($i = 0; $i < count($tokens); $i++) {
                $token = $tokens[$i];

                if (is_string($token)) {
                    if ($token === '{') {
                        $braceLevel++;
                    } elseif ($token === '}') {
                        $braceLevel--;
                        if ($functionBraceLevel !== null && $braceLevel < $functionBraceLevel) {
                            $currentFunction = null;
                            $functionBraceLevel = null;
                        }
                    }
                    continue;
                }

                if ($token[0] === T_FUNCTION) {
                    for ($j = $i + 1; $j < count($tokens); $j++) {
                        if (is_array($tokens[$j]) && $tokens[$j][0] === T_STRING) {
                            $currentFunction = $tokens[$j][1];
                            $functionBraceLevel = $braceLevel + 1;
                            break;
                        }
                    }
                } elseif ($token[0] === T_EXIT) {
                    $line = $token[2];
                    $isAllowedTerminate = (basename($filePath) === 'BaseController.php' && $currentFunction === 'terminate');

                    if (!$isAllowedTerminate) {
                        $violations[] = sprintf('%s:%d contains bare "%s"', $relativePath, $line, $token[1]);
                    }
                }
            }
        }

        $this->assertGreaterThan(0, $scannedCount, 'Must scan at least one controller file');
        $this->assertEmpty(
            $violations,
            "Found bare exit/die in controllers outside BaseController::terminate():\n" . implode("\n", $violations)
        );
    }
}
