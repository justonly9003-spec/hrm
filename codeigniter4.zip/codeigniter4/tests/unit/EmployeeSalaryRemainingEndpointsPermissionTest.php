<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use App\Models\EmployeeModel;
use App\Models\EmployeeSalaryModel;
use App\Controllers\Employee\EmployeeSalaryController;
use App\Services\EmployeeSalaryService;
use Config\Database;

/**
 * Tests for EmployeeSalaryController remaining endpoints (copyStructure and resyncSalary):
 * 1. hr_officer with employees.edit only gets 403 on copyStructure and resyncSalary and nothing changes.
 * 2. User with employee.view_salary + payroll.edit succeeds on both endpoints.
 * 3. copyStructure is rejected when target employee is outside the actor's row scope.
 * 4. copyStructure is rejected when source employee is outside the actor's row scope.
 * 5. EmployeeSalaryService::assignSalary() and resyncSalaryStructure() enforce isAuthorizedRole() at service layer.
 */
class EmployeeSalaryRemainingEndpointsPermissionTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected static bool $schemaInitialized = false;

    protected string $companyId   = 'comp-sal-perm-01';
    protected string $branchA     = 'branch-sal-a';
    protected string $branchB     = 'branch-sal-b';
    protected string $deptId      = 'dept-sal-01';
    protected string $desgId      = 'desg-sal-01';

    protected string $empTargetA  = 'emp-sal-target-a';
    protected string $empSourceA  = 'emp-sal-source-a';
    protected string $empTargetB  = 'emp-sal-target-b';
    protected string $empSourceB  = 'emp-sal-source-b';

    protected string $structureId = 'struct-sal-01';
    protected string $componentId = 'comp-sal-basic';

    public static function setUpBeforeClass(): void
    {
        parent::setUpBeforeClass();
        static::ensureSchema();
    }

    public static function registerSqliteFunctions($db): void
    {
        try {
            $rawConn = $db->connID ?? null;
            if ($rawConn instanceof \SQLite3) {
                $rawConn->createFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->createFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            } elseif (is_object($rawConn) && method_exists($rawConn, 'sqliteCreateFunction')) {
                $rawConn->sqliteCreateFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->sqliteCreateFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            }
        } catch (\Throwable $e) {
            // ignore
        }
    }

    protected static function ensureSchema(): void
    {
        $db = Database::connect();
        static::registerSqliteFunctions($db);

        $schemaFile = __DIR__ . '/Rules/schema.sqlite.sql';
        if (file_exists($schemaFile)) {
            $sql = file_get_contents($schemaFile);
            $statements = array_filter(array_map('trim', explode(';', $sql)));
            foreach ($statements as $stmt) {
                if (!empty($stmt)) {
                    try {
                        $db->query($stmt);
                    } catch (\Throwable $e) {
                        // ignore
                    }
                }
            }
        }

        $db->query("CREATE TABLE IF NOT EXISTS salary_revisions (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            employee_id VARCHAR(36),
            revision_type VARCHAR(50),
            effective_date DATE,
            basic_salary DECIMAL(15,2),
            gross_salary DECIMAL(15,2),
            net_salary DECIMAL(15,2),
            ctc DECIMAL(15,2),
            structure_id VARCHAR(36),
            reason TEXT,
            status VARCHAR(50) DEFAULT 'Approved',
            approved_by VARCHAR(36),
            snapshot_json TEXT,
            created_at DATETIME,
            updated_at DATETIME
        )");

        static::$schemaInitialized = true;
    }

    protected function setUp(): void
    {
        parent::setUp();
        static::ensureSchema();

        $db = Database::connect();
        static::registerSqliteFunctions($db);

        // Seed Company and Branches
        $db->table('companies')->replace([
            'id'     => $this->companyId,
            'name'   => 'Salary Perm Testing Corp',
            'code'   => 'SPTC',
            'status' => 'Active',
        ]);

        $db->table('branches')->replace([
            'id'         => $this->branchA,
            'company_id' => $this->companyId,
            'name'       => 'Branch Alpha',
            'code'       => 'BR-A',
            'status'     => 'Active',
        ]);

        $db->table('branches')->replace([
            'id'         => $this->branchB,
            'company_id' => $this->companyId,
            'name'       => 'Branch Beta',
            'code'       => 'BR-B',
            'status'     => 'Active',
        ]);

        $db->table('departments')->replace([
            'id'         => $this->deptId,
            'company_id' => $this->companyId,
            'name'       => 'Operations',
            'code'       => 'DEP-OPS',
            'status'     => 'Active',
        ]);

        $db->table('designations')->replace([
            'id'         => $this->desgId,
            'company_id' => $this->companyId,
            'name'       => 'Analyst',
            'code'       => 'DES-ANA',
            'status'     => 'Active',
        ]);

        // Seed Salary Component
        $db->table('salary_components')->replace([
            'id'                  => $this->componentId,
            'company_id'          => $this->companyId,
            'name'                => 'Basic Salary',
            'code'                => 'BASIC',
            'type'                => 'earning',
            'calculation_type'    => 'fixed',
            'is_taxable'          => 1,
            'include_in_pf_basis' => 1,
            'status'              => 'Active',
            'display_order'       => 1,
        ]);

        // Seed Salary Structure
        $db->table('salary_structures')->replace([
            'id'          => $this->structureId,
            'company_id'  => $this->companyId,
            'name'        => 'Standard Structure',
            'code'        => 'STD-01',
            'status'      => 'Active',
        ]);

        // Seed Salary Structure Items
        $db->table('salary_structure_items')->replace([
            'id'           => 'ssi-basic-01',
            'structure_id' => $this->structureId,
            'component_id' => $this->componentId,
            'calculation_type' => 'fixed',
            'amount'       => 50000.00,
            'sort_order'   => 1,
        ]);

        // Clean up test employees and salaries
        $db->table('employees')->whereIn('id', [$this->empTargetA, $this->empSourceA, $this->empTargetB, $this->empSourceB])->delete();
        $db->table('employee_salaries')->whereIn('employee_id', [$this->empTargetA, $this->empSourceA, $this->empTargetB, $this->empSourceB])->delete();

        // Target Employee in Branch A
        $db->table('employees')->insert([
            'id'            => $this->empTargetA,
            'company_id'    => $this->companyId,
            'branch_id'     => $this->branchA,
            'department_id' => $this->deptId,
            'designation_id'=> $this->desgId,
            'employee_code' => 'EMP-TGT-A',
            'first_name'    => 'Target',
            'last_name'     => 'Alpha',
            'email'         => 'target.a@sal.test',
            'basic_salary'  => 40000.00,
            'gross_salary'  => 40000.00,
            'net_salary'    => 40000.00,
            'status'        => 'Active',
            'salary_status' => 'CONFIGURED',
            'joining_date'  => '2025-01-01',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);

        // Active salary for Target Employee A
        $db->table('employee_salaries')->insert([
            'id'                     => 'sal-tgt-a-01',
            'employee_id'            => $this->empTargetA,
            'company_id'             => $this->companyId,
            'structure_id'           => $this->structureId,
            'basic_salary'           => 40000.00,
            'gross_salary'           => 40000.00,
            'total_deductions'       => 0.00,
            'net_salary'             => 40000.00,
            'ctc'                    => 40000.00,
            'effective_from'         => '2025-01-01',
            'status'                 => 'Active',
            'custom_components_json' => json_encode([
                'structure_id' => $this->structureId,
                'basic_salary' => 40000.00,
                'gross_salary' => 40000.00,
                'net_salary'   => 40000.00,
                'components'   => [
                    [
                        'component_id' => $this->componentId,
                        'name'         => 'Basic Salary',
                        'code'         => 'BASIC',
                        'type'         => 'earning',
                        'amount'       => 40000.00,
                    ]
                ],
                'earnings'     => [
                    [
                        'component_id' => $this->componentId,
                        'name'         => 'Basic Salary',
                        'code'         => 'BASIC',
                        'type'         => 'earning',
                        'amount'       => 40000.00,
                    ]
                ],
                'deductions'   => [],
            ]),
            'created_at'             => date('Y-m-d H:i:s'),
        ]);

        // Source Employee in Branch A
        $db->table('employees')->insert([
            'id'            => $this->empSourceA,
            'company_id'    => $this->companyId,
            'branch_id'     => $this->branchA,
            'department_id' => $this->deptId,
            'designation_id'=> $this->desgId,
            'employee_code' => 'EMP-SRC-A',
            'first_name'    => 'Source',
            'last_name'     => 'Alpha',
            'email'         => 'source.a@sal.test',
            'basic_salary'  => 50000.00,
            'gross_salary'  => 50000.00,
            'net_salary'    => 50000.00,
            'status'        => 'Active',
            'salary_status' => 'CONFIGURED',
            'joining_date'  => '2025-01-01',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);

        // Active salary for Source Employee A
        $db->table('employee_salaries')->insert([
            'id'                     => 'sal-src-a-01',
            'employee_id'            => $this->empSourceA,
            'company_id'             => $this->companyId,
            'structure_id'           => $this->structureId,
            'basic_salary'           => 50000.00,
            'gross_salary'           => 50000.00,
            'total_deductions'       => 0.00,
            'net_salary'             => 50000.00,
            'ctc'                    => 50000.00,
            'effective_from'         => '2025-01-01',
            'status'                 => 'Active',
            'custom_components_json' => json_encode([
                'structure_id' => $this->structureId,
                'basic_salary' => 50000.00,
                'gross_salary' => 50000.00,
                'net_salary'   => 50000.00,
                'components'   => [
                    [
                        'component_id' => $this->componentId,
                        'name'         => 'Basic Salary',
                        'code'         => 'BASIC',
                        'type'         => 'earning',
                        'amount'       => 50000.00,
                    ]
                ],
                'earnings'     => [
                    [
                        'component_id' => $this->componentId,
                        'name'         => 'Basic Salary',
                        'code'         => 'BASIC',
                        'type'         => 'earning',
                        'amount'       => 50000.00,
                    ]
                ],
                'deductions'   => [],
            ]),
            'created_at'             => date('Y-m-d H:i:s'),
        ]);

        // Target Employee in Branch B
        $db->table('employees')->insert([
            'id'            => $this->empTargetB,
            'company_id'    => $this->companyId,
            'branch_id'     => $this->branchB,
            'department_id' => $this->deptId,
            'designation_id'=> $this->desgId,
            'employee_code' => 'EMP-TGT-B',
            'first_name'    => 'Target',
            'last_name'     => 'Beta',
            'email'         => 'target.b@sal.test',
            'basic_salary'  => 35000.00,
            'gross_salary'  => 35000.00,
            'net_salary'    => 35000.00,
            'status'        => 'Active',
            'salary_status' => 'CONFIGURED',
            'joining_date'  => '2025-01-01',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);

        // Source Employee in Branch B
        $db->table('employees')->insert([
            'id'            => $this->empSourceB,
            'company_id'    => $this->companyId,
            'branch_id'     => $this->branchB,
            'department_id' => $this->deptId,
            'designation_id'=> $this->desgId,
            'employee_code' => 'EMP-SRC-B',
            'first_name'    => 'Source',
            'last_name'     => 'Beta',
            'email'         => 'source.b@sal.test',
            'basic_salary'  => 60000.00,
            'gross_salary'  => 60000.00,
            'net_salary'    => 60000.00,
            'status'        => 'Active',
            'salary_status' => 'CONFIGURED',
            'joining_date'  => '2025-01-01',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);

        // Seed Roles, Users, and Permissions
        $db->table('permissions')->replace([
            ['id' => 'p-emp-view', 'code' => 'employees.view', 'module' => 'directory', 'action' => 'view', 'name' => 'View Employees'],
            ['id' => 'p-emp-edit', 'code' => 'employees.edit', 'module' => 'directory', 'action' => 'edit', 'name' => 'Edit Employees'],
            ['id' => 'p-sal-view', 'code' => 'employee.view_salary', 'module' => 'directory', 'action' => 'view_salary', 'name' => 'View Salary'],
            ['id' => 'p-pay-edit', 'code' => 'payroll.edit', 'module' => 'payroll', 'action' => 'edit', 'name' => 'Edit Payroll'],
            ['id' => 'p-pay-view', 'code' => 'payroll.view', 'module' => 'payroll', 'action' => 'view', 'name' => 'View Payroll'],
            ['id' => 'p-pay-mng',  'code' => 'payroll.manage', 'module' => 'payroll', 'action' => 'manage', 'name' => 'Manage Payroll'],
        ]);

        // Role 1: hr_officer (has employees.view and employees.edit ONLY)
        $db->table('roles')->replace([
            'id'         => 'role-hr-officer',
            'company_id' => $this->companyId,
            'name'       => 'HR Officer',
            'code'       => 'hr_officer',
            'status'     => 'Active',
        ]);
        $db->table('role_permissions')->where('role_id', 'role-hr-officer')->delete();
        $db->table('role_permissions')->insertBatch([
            ['id' => 'rp-hr-1', 'role_id' => 'role-hr-officer', 'permission_id' => 'p-emp-view', 'scope_level' => 'company'],
            ['id' => 'rp-hr-2', 'role_id' => 'role-hr-officer', 'permission_id' => 'p-emp-edit', 'scope_level' => 'company'],
        ]);

        // Role 2: payroll_officer (has employee.view_salary and payroll.edit)
        $db->table('roles')->replace([
            'id'         => 'role-payroll-officer',
            'company_id' => $this->companyId,
            'name'       => 'Payroll Officer',
            'code'       => 'payroll_officer',
            'status'     => 'Active',
        ]);
        $db->table('role_permissions')->where('role_id', 'role-payroll-officer')->delete();
        $db->table('role_permissions')->insertBatch([
            ['id' => 'rp-pay-1', 'role_id' => 'role-payroll-officer', 'permission_id' => 'p-emp-view', 'scope_level' => 'company'],
            ['id' => 'rp-pay-2', 'role_id' => 'role-payroll-officer', 'permission_id' => 'p-sal-view', 'scope_level' => 'company'],
            ['id' => 'rp-pay-3', 'role_id' => 'role-payroll-officer', 'permission_id' => 'p-pay-edit', 'scope_level' => 'company'],
            ['id' => 'rp-pay-4', 'role_id' => 'role-payroll-officer', 'permission_id' => 'p-pay-view', 'scope_level' => 'company'],
        ]);

        // Users
        $db->table('users')->replace([
            [
                'id'         => 'usr-hr-01',
                'company_id' => $this->companyId,
                'branch_id'  => $this->branchA,
                'username'   => 'hr_officer_user',
                'email'      => 'hr_user@sal.test',
                'role_id'    => 'role-hr-officer',
                'status'     => 'Active',
            ],
            [
                'id'         => 'usr-pay-01',
                'company_id' => $this->companyId,
                'branch_id'  => $this->branchA,
                'username'   => 'payroll_officer_user',
                'email'      => 'payroll_user@sal.test',
                'role_id'    => 'role-payroll-officer',
                'status'     => 'Active',
            ],
        ]);
    }

    /**
     * Helper to initialize controller with specified actor user and AJAX request
     */
    protected function setupController(array $actorUser, array $postData = []): EmployeeSalaryController
    {
        \App\Services\PermissionService::clearCache();
        \App\Services\PermissionService::flushCache();

        $session = \Config\Services::session();
        $session->set([
            'id'                  => $actorUser['id'],
            'user_id'             => $actorUser['id'],
            'username'            => $actorUser['username'] ?? 'user_' . $actorUser['id'],
            'name'                => $actorUser['name'] ?? 'Test User',
            'email'               => $actorUser['email'] ?? 'test@sal.test',
            'role'                => $actorUser['role'] ?? $actorUser['role_code'],
            'role_code'           => $actorUser['role_code'],
            'role_id'             => $actorUser['role_id'] ?? 'role-' . $actorUser['role_code'],
            'company_id'          => $actorUser['company_id'],
            'branch_id'           => $actorUser['branch_id'] ?? null,
            'employee_id'         => $actorUser['employee_id'] ?? null,
            'selected_company_id' => $actorUser['company_id'],
            'permissions'         => $actorUser['permissions'] ?? [],
        ]);

        $_SERVER['HTTP_X_REQUESTED_WITH'] = 'xmlhttprequest';
        $_SERVER['HTTP_ACCEPT'] = 'application/json';
        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_POST = $postData;

        $request = \Config\Services::request();
        $refPost = new \ReflectionProperty($request, 'body');
        $refPost->setAccessible(true);
        $refPost->setValue($request, $postData);

        $response = \Config\Services::response();
        $logger = \Config\Services::logger();

        $controller = new EmployeeSalaryController();
        $controller->initController($request, $response, $logger);

        $refUser = new \ReflectionProperty(\App\Controllers\BaseController::class, 'currentUser');
        $refUser->setAccessible(true);
        $refUser->setValue($controller, $actorUser);

        return $controller;
    }

    /**
     * Test 1: hr_officer with employees.edit only gets 403 on copyStructure and nothing changes
     */
    public function testHrOfficerWithEmployeesEditOnlyGets403OnCopyStructureAndNothingChanges()
    {
        $hrActor = [
            'id'          => 'usr-hr-01',
            'company_id'  => $this->companyId,
            'branch_id'   => $this->branchA,
            'role_code'   => 'hr_officer',
            'role_id'     => 'role-hr-officer',
            'permissions' => ['employees.view', 'employees.edit'],
        ];

        $postData = [
            'source_employee_id' => $this->empSourceA,
            'basic_salary'       => 75000.00,
        ];

        $ctrl = $this->setupController($hrActor, $postData);
        $response = $ctrl->copyStructure($this->empTargetA);

        $this->assertEquals(403, $response->getStatusCode(), 'Actor with only employees.edit must receive 403 on copyStructure');

        // Verify target employee salary was completely untouched in DB
        $db = Database::connect();
        $empRow = $db->table('employees')->where('id', $this->empTargetA)->get()->getRowArray();
        $this->assertEquals(40000.00, (float)$empRow['basic_salary'], 'Target employee salary must remain unchanged');

        $activeSal = $db->table('employee_salaries')
            ->where('employee_id', $this->empTargetA)
            ->where('status', 'Active')
            ->get()->getRowArray();
        $this->assertEquals(40000.00, (float)$activeSal['basic_salary'], 'Target active salary must remain unchanged');
    }

    /**
     * Test 2: hr_officer with employees.edit only gets 403 on resyncSalary and nothing changes
     */
    public function testHrOfficerWithEmployeesEditOnlyGets403OnResyncSalaryAndNothingChanges()
    {
        $hrActor = [
            'id'          => 'usr-hr-01',
            'company_id'  => $this->companyId,
            'branch_id'   => $this->branchA,
            'role_code'   => 'hr_officer',
            'role_id'     => 'role-hr-officer',
            'permissions' => ['employees.view', 'employees.edit'],
        ];

        $ctrl = $this->setupController($hrActor, ['structure_id' => $this->structureId]);
        $response = $ctrl->resyncSalary($this->empTargetA);

        $this->assertEquals(403, $response->getStatusCode(), 'Actor with only employees.edit must receive 403 on resyncSalary');

        // Verify target employee salary was completely untouched in DB
        $db = Database::connect();
        $empRow = $db->table('employees')->where('id', $this->empTargetA)->get()->getRowArray();
        $this->assertEquals(40000.00, (float)$empRow['basic_salary'], 'Target employee salary must remain unchanged');
    }

    /**
     * Test 3: User with employee.view_salary + payroll.edit succeeds on copyStructure
     */
    public function testUserWithViewSalaryAndPayrollEditSucceedsOnCopyStructure()
    {
        $payrollActor = [
            'id'          => 'usr-pay-01',
            'company_id'  => $this->companyId,
            'branch_id'   => $this->branchA,
            'role_code'   => 'payroll_officer',
            'role_id'     => 'role-payroll-officer',
            'permissions' => ['employees.view', 'employee.view_salary', 'payroll.edit', 'payroll.view'],
        ];

        $postData = [
            'source_employee_id' => $this->empSourceA,
            'basic_salary'       => 50000.00,
            'structure_id'       => $this->structureId,
            'effective_from'     => date('Y-m-d'),
            'components'         => [
                [
                    'component_id' => $this->componentId,
                    'name'         => 'Basic Salary',
                    'code'         => 'BASIC',
                    'type'         => 'earning',
                    'amount'       => 50000.00,
                ]
            ]
        ];

        $ctrl = $this->setupController($payrollActor, $postData);
        $response = $ctrl->copyStructure($this->empTargetA);

        $this->assertEquals(200, $response->getStatusCode(), 'Authorized user must succeed with HTTP 200 on copyStructure');
        $body = json_decode((string)$response->getBody(), true);
        $this->assertTrue($body['success'], 'Response body must have success = true');

        // Verify salary updated in DB to copied 50000.00
        $db = Database::connect();
        $empRow = $db->table('employees')->where('id', $this->empTargetA)->get()->getRowArray();
        $this->assertEquals(50000.00, (float)$empRow['basic_salary'], 'Target employee salary must be updated');
    }

    /**
     * Test 4: User with employee.view_salary + payroll.edit succeeds on resyncSalary
     */
    public function testUserWithViewSalaryAndPayrollEditSucceedsOnResyncSalary()
    {
        $payrollActor = [
            'id'          => 'usr-pay-01',
            'company_id'  => $this->companyId,
            'branch_id'   => $this->branchA,
            'role_code'   => 'payroll_officer',
            'role_id'     => 'role-payroll-officer',
            'permissions' => ['employees.view', 'employee.view_salary', 'payroll.edit', 'payroll.view'],
        ];

        $postData = [
            'structure_id' => $this->structureId,
        ];

        $ctrl = $this->setupController($payrollActor, $postData);
        $response = $ctrl->resyncSalary($this->empTargetA);

        $this->assertEquals(200, $response->getStatusCode(), 'Authorized user must succeed with HTTP 200 on resyncSalary');
        $body = json_decode((string)$response->getBody(), true);
        $this->assertTrue($body['success'], 'Response body must have success = true');
    }

    /**
     * Test 5: copyStructure rejected when target employee is outside actor's row scope
     */
    public function testCopyStructureRejectedWhenTargetEmployeeOutsideScope()
    {
        // Actor is in Branch A, target employee is in Branch B
        $branchActor = [
            'id'          => 'usr-pay-01',
            'company_id'  => $this->companyId,
            'branch_id'   => $this->branchA,
            'role_code'   => 'payroll_officer',
            'role_id'     => 'role-payroll-officer',
            'permissions' => ['employees.view', 'employee.view_salary', 'payroll.edit', 'payroll.view'],
        ];

        $postData = [
            'source_employee_id' => $this->empSourceA, // Source in Branch A
            'basic_salary'       => 50000.00,
        ];

        $ctrl = $this->setupController($branchActor, $postData);
        $response = $ctrl->copyStructure($this->empTargetB); // Target in Branch B

        $this->assertEquals(403, $response->getStatusCode(), 'Target outside scope must be rejected with 403');
        $body = json_decode((string)$response->getBody(), true);
        $this->assertFalse($body['success']);
        $this->assertStringContainsString('outside your authorized scope', $body['message']);

        // Verify target in Branch B is untouched
        $db = Database::connect();
        $empRow = $db->table('employees')->where('id', $this->empTargetB)->get()->getRowArray();
        $this->assertEquals(35000.00, (float)$empRow['basic_salary']);
    }

    /**
     * Test 6: copyStructure rejected when source employee is outside actor's row scope
     */
    public function testCopyStructureRejectedWhenSourceEmployeeOutsideScope()
    {
        // Actor is in Branch A, target employee is in Branch A, but source employee is in Branch B
        $branchActor = [
            'id'          => 'usr-pay-01',
            'company_id'  => $this->companyId,
            'branch_id'   => $this->branchA,
            'role_code'   => 'payroll_officer',
            'role_id'     => 'role-payroll-officer',
            'permissions' => ['employees.view', 'employee.view_salary', 'payroll.edit', 'payroll.view'],
        ];

        $postData = [
            'source_employee_id' => $this->empSourceB, // Source in Branch B (outside actor's scope)
            'basic_salary'       => 60000.00,
        ];

        $ctrl = $this->setupController($branchActor, $postData);
        $response = $ctrl->copyStructure($this->empTargetA); // Target in Branch A (in scope)

        $this->assertEquals(403, $response->getStatusCode(), 'Source outside scope must be rejected with 403');
        $body = json_decode((string)$response->getBody(), true);
        $this->assertFalse($body['success']);
        $this->assertStringContainsString('Source employee record is outside your authorized scope', $body['message']);

        // Verify target employee in Branch A is untouched
        $db = Database::connect();
        $empRow = $db->table('employees')->where('id', $this->empTargetA)->get()->getRowArray();
        $this->assertEquals(40000.00, (float)$empRow['basic_salary']);
    }

    /**
     * Test 7: EmployeeSalaryService::assignSalary() rejects actor with only employees.edit at service layer
     */
    public function testServiceLevelAssignSalaryRejectsActorWithOnlyEmployeesEdit()
    {
        $service = new EmployeeSalaryService();
        $unauthorizedActor = [
            'id'          => 'usr-hr-01',
            'company_id'  => $this->companyId,
            'role_code'   => 'hr_officer',
            'permissions' => ['employees.edit', 'employees.view'],
        ];

        $result = $service->assignSalary(
            $this->empTargetA,
            ['basic_salary' => 70000.00],
            $this->companyId,
            $unauthorizedActor
        );

        $this->assertFalse($result['success']);
        $this->assertEquals(403, $result['status'] ?? 403);
        $this->assertStringContainsString('permission', $result['message']);
    }

    /**
     * Test 8: EmployeeSalaryService::resyncSalaryStructure() rejects actor with only employees.edit at service layer
     */
    public function testServiceLevelResyncSalaryStructureRejectsActorWithOnlyEmployeesEdit()
    {
        $service = new EmployeeSalaryService();
        $unauthorizedActor = [
            'id'          => 'usr-hr-01',
            'company_id'  => $this->companyId,
            'role_code'   => 'hr_officer',
            'permissions' => ['employees.edit', 'employees.view'],
        ];

        $result = $service->resyncSalaryStructure(
            $this->empTargetA,
            ['structure_id' => $this->structureId],
            $this->companyId,
            $unauthorizedActor
        );

        $this->assertFalse($result['success']);
        $this->assertEquals(403, $result['status'] ?? 403);
        $this->assertStringContainsString('permission', $result['message']);
    }
}
