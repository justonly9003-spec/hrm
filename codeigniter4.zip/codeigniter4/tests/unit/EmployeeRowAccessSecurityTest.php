<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use App\Models\EmployeeModel;
use App\Controllers\Employee\ProfileController;
use App\Controllers\Employee\EmployeeController;
use App\Controllers\Employee\EmployeeSalaryController;
use Config\Database;

/**
 * Tests for Row-Level Organizational Scoping Security
 *
 * Requirements:
 * 1. hr_officer with branch A cannot access an employee of branch B (profile show, editData, salary GET)
 *    and can access one in branch A.
 * 2. company_admin and software_app_admin can access both branch A and branch B.
 * 3. Self access always works regardless of branch.
 * 4. An actor with no branch assignment follows the same behavior as the directory list (allowed across company).
 * 5. Branch manager with no session branch fails closed.
 */
class EmployeeRowAccessSecurityTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected static bool $schemaInitialized = false;

    protected string $companyId = 'comp-sec-test-01';
    protected string $branchA   = 'branch-sec-a';
    protected string $branchB   = 'branch-sec-b';
    protected string $deptId    = 'dept-sec-01';
    protected string $desgId    = 'desg-sec-01';

    protected string $empAId    = 'emp-sec-a-01';
    protected string $empBId    = 'emp-sec-b-02';
    protected string $empHrId   = 'emp-sec-hr-03';

    public static function setUpBeforeClass(): void
    {
        parent::setUpBeforeClass();
        static::ensureSchema();
    }

    public static function registerSqliteFunctions($db): void
    {
        try {
            $rawConn = $db->connID ?? null;
            if ($rawConn instanceof \SQLite3) {
                $rawConn->createFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->createFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            } elseif (is_object($rawConn) && method_exists($rawConn, 'sqliteCreateFunction')) {
                $rawConn->sqliteCreateFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->sqliteCreateFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            }
        } catch (\Throwable $e) {
            // ignore if not sqlite or already registered
        }
    }

    protected static function ensureSchema(): void
    {
        $db = Database::connect();
        static::registerSqliteFunctions($db);

        $schemaFile = __DIR__ . '/Rules/schema.sqlite.sql';
        if (file_exists($schemaFile)) {
            $sql = file_get_contents($schemaFile);
            $statements = array_filter(array_map('trim', explode(';', $sql)));
            foreach ($statements as $stmt) {
                if (!empty($stmt)) {
                    try {
                        $db->query($stmt);
                    } catch (\Throwable $e) {
                        // ignore if already exists
                    }
                }
            }
        }

        static::$schemaInitialized = true;
    }

    protected function setUp(): void
    {
        parent::setUp();
        static::ensureSchema();

        $db = Database::connect();
        static::registerSqliteFunctions($db);

        // Seed Company and Branches
        $db->table('companies')->replace([
            'id'     => $this->companyId,
            'name'   => 'Security Corp',
            'code'   => 'SECCORP',
            'status' => 'Active',
        ]);

        $db->table('branches')->replace([
            'id'         => $this->branchA,
            'company_id' => $this->companyId,
            'name'       => 'Branch Alpha',
            'code'       => 'BR-A',
            'status'     => 'Active',
        ]);

        $db->table('branches')->replace([
            'id'         => $this->branchB,
            'company_id' => $this->companyId,
            'name'       => 'Branch Beta',
            'code'       => 'BR-B',
            'status'     => 'Active',
        ]);

        $db->table('departments')->replace([
            'id'         => $this->deptId,
            'company_id' => $this->companyId,
            'name'       => 'Operations',
            'code'       => 'DEP-OPS',
            'status'     => 'Active',
        ]);

        $db->table('designations')->replace([
            'id'         => $this->desgId,
            'company_id' => $this->companyId,
            'name'       => 'Officer',
            'code'       => 'DES-OFF',
            'status'     => 'Active',
        ]);

        // Clean up test employees
        $db->table('employees')->whereIn('id', [$this->empAId, $this->empBId, $this->empHrId])->delete();

        // 1. Employee in Branch A
        $db->table('employees')->insert([
            'id'            => $this->empAId,
            'company_id'    => $this->companyId,
            'branch_id'     => $this->branchA,
            'department_id' => $this->deptId,
            'designation_id'=> $this->desgId,
            'employee_code' => 'EMP-SEC-A',
            'first_name'    => 'Arthur',
            'last_name'     => 'Alpha',
            'email'         => 'arthur@sec.test',
            'status'        => 'Active',
            'joining_date'  => '2025-01-01',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);

        // 2. Employee in Branch B
        $db->table('employees')->insert([
            'id'            => $this->empBId,
            'company_id'    => $this->companyId,
            'branch_id'     => $this->branchB,
            'department_id' => $this->deptId,
            'designation_id'=> $this->desgId,
            'employee_code' => 'EMP-SEC-B',
            'first_name'    => 'Boris',
            'last_name'     => 'Beta',
            'email'         => 'boris@sec.test',
            'status'        => 'Active',
            'joining_date'  => '2025-01-01',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);

        // 3. HR Officer Employee (in Branch A)
        $db->table('employees')->insert([
            'id'            => $this->empHrId,
            'company_id'    => $this->companyId,
            'branch_id'     => $this->branchA,
            'department_id' => $this->deptId,
            'designation_id'=> $this->desgId,
            'employee_code' => 'EMP-SEC-HR',
            'first_name'    => 'Helena',
            'last_name'     => 'HR',
            'email'         => 'helena.hr@sec.test',
            'status'        => 'Active',
            'joining_date'  => '2025-01-01',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);
    }

    /**
     * Helper to set controller current user and session
     */
    protected function initControllerContext($controller, array $actorUser): void
    {
        \App\Services\PermissionService::clearCache();
        \App\Services\PermissionService::flushCache();

        $session = \Config\Services::session();
        $session->set([
            'id'                  => $actorUser['id'],
            'user_id'             => $actorUser['id'],
            'username'            => $actorUser['username'] ?? 'user_' . $actorUser['id'],
            'name'                => $actorUser['name'] ?? 'Test User',
            'email'               => $actorUser['email'] ?? 'test@sec.test',
            'role'                => $actorUser['role'] ?? $actorUser['role_code'],
            'role_code'           => $actorUser['role_code'],
            'role_id'             => $actorUser['role_id'] ?? 'role-' . $actorUser['role_code'],
            'company_id'          => $actorUser['company_id'],
            'branch_id'           => $actorUser['branch_id'] ?? null,
            'employee_id'         => $actorUser['employee_id'] ?? null,
            'selected_company_id' => $actorUser['company_id'],
            'permissions'         => $actorUser['permissions'] ?? ['*'],
        ]);

        $request = \Config\Services::request();
        $response = \Config\Services::response();
        $logger = \Config\Services::logger();

        $controller->initController($request, $response, $logger);

        $refUser = new \ReflectionProperty(\App\Controllers\BaseController::class, 'currentUser');
        $refUser->setAccessible(true);
        $refUser->setValue($controller, $actorUser);
    }

    /**
     * Test 1: EmployeeModel::canAccessEmployeeRow allows hr_officer in branch A
     * to access branch A employee, but denies branch B employee.
     */
    public function testHrOfficerWithBranchCanOnlyAccessAssignedBranch()
    {
        $hrOfficerBranchA = [
            'id'          => 'usr-hr-a',
            'company_id'  => $this->companyId,
            'branch_id'   => $this->branchA,
            'employee_id' => $this->empHrId,
            'role_code'   => 'hr_officer',
        ];

        $targetEmpA = [
            'id'         => $this->empAId,
            'company_id' => $this->companyId,
            'branch_id'  => $this->branchA,
        ];

        $targetEmpB = [
            'id'         => $this->empBId,
            'company_id' => $this->companyId,
            'branch_id'  => $this->branchB,
        ];

        // Access to same branch allowed
        $this->assertTrue(
            EmployeeModel::canAccessEmployeeRow($targetEmpA, $hrOfficerBranchA),
            'hr_officer with branch A must be allowed to access employee in branch A'
        );

        // Access to different branch denied
        $this->assertFalse(
            EmployeeModel::canAccessEmployeeRow($targetEmpB, $hrOfficerBranchA),
            'hr_officer with branch A must NOT be allowed to access employee in branch B'
        );
    }

    /**
     * Test 2: company_admin and software_app_admin can access employees in both Branch A and Branch B.
     */
    public function testCompanyAdminAndSoftwareAdminCanAccessBothBranches()
    {
        $targetEmpA = ['id' => $this->empAId, 'company_id' => $this->companyId, 'branch_id' => $this->branchA];
        $targetEmpB = ['id' => $this->empBId, 'company_id' => $this->companyId, 'branch_id' => $this->branchB];

        // Company Admin
        $companyAdmin = [
            'id'         => 'usr-ca-01',
            'company_id' => $this->companyId,
            'branch_id'  => $this->branchA, // Assigned to Branch A, but Company Admin has company-wide scope
            'role_code'  => 'company_admin',
        ];

        $this->assertTrue(EmployeeModel::canAccessEmployeeRow($targetEmpA, $companyAdmin));
        $this->assertTrue(EmployeeModel::canAccessEmployeeRow($targetEmpB, $companyAdmin));

        // Software App Admin
        $softwareAdmin = [
            'id'         => 'usr-sa-01',
            'company_id' => null,
            'branch_id'  => null,
            'role_code'  => 'software_app_admin',
        ];

        $this->assertTrue(EmployeeModel::canAccessEmployeeRow($targetEmpA, $softwareAdmin));
        $this->assertTrue(EmployeeModel::canAccessEmployeeRow($targetEmpB, $softwareAdmin));
    }

    /**
     * Test 3: Self-access always works regardless of branch.
     */
    public function testSelfAccessAlwaysAllowedRegardlessOfBranch()
    {
        $actorHr = [
            'id'          => 'usr-hr-a',
            'company_id'  => $this->companyId,
            'branch_id'   => $this->branchA,
            'employee_id' => $this->empHrId,
            'role_code'   => 'hr_officer',
        ];

        // Target is actor's own employee record, even if target employee row was assigned branch B
        $ownRecordDifferentBranch = [
            'id'          => $this->empHrId,
            'company_id'  => $this->companyId,
            'branch_id'   => $this->branchB,
            'user_id'     => 'usr-hr-a',
        ];

        $this->assertTrue(
            EmployeeModel::canAccessEmployeeRow($ownRecordDifferentBranch, $actorHr),
            'Self access must always be allowed even if branch differs'
        );
    }

    /**
     * Test 4: An actor with no branch assignment follows the directory list behavior
     * (allowed across the entire company).
     */
    public function testActorWithNoBranchAssignmentCanAccessAcrossCompany()
    {
        $hrOfficerNoBranch = [
            'id'          => 'usr-hr-nobranch',
            'company_id'  => $this->companyId,
            'branch_id'   => null, // No branch assigned
            'employee_id' => null,
            'role_code'   => 'hr_officer',
        ];

        $targetEmpA = ['id' => $this->empAId, 'company_id' => $this->companyId, 'branch_id' => $this->branchA];
        $targetEmpB = ['id' => $this->empBId, 'company_id' => $this->companyId, 'branch_id' => $this->branchB];

        $this->assertTrue(
            EmployeeModel::canAccessEmployeeRow($targetEmpA, $hrOfficerNoBranch),
            'Actor with no branch assignment can access Branch A employee'
        );
        $this->assertTrue(
            EmployeeModel::canAccessEmployeeRow($targetEmpB, $hrOfficerNoBranch),
            'Actor with no branch assignment can access Branch B employee'
        );
    }

    /**
     * Test 5: ProfileController::show enforces branch restriction:
     * hr_officer in branch A is rejected on branch B employee, and allowed on branch A employee.
     */
    public function testProfileControllerShowEnforcesBranchRestriction()
    {
        $hrActor = [
            'id'          => 'usr-hr-a',
            'username'    => 'hr_helena',
            'company_id'  => $this->companyId,
            'branch_id'   => $this->branchA,
            'employee_id' => $this->empHrId,
            'role_code'   => 'hr_officer',
            'role'        => 'HR Officer',
            'permissions' => ['employees.view', 'employee.view'],
        ];

        $ctrl = new ProfileController();
        $this->initControllerContext($ctrl, $hrActor);

        // 1. Attempt to show employee in Branch B -> Redirected with 403 Forbidden flashdata
        $responseB = $ctrl->show($this->empBId);
        $this->assertTrue(
            $responseB->isRedirect(),
            'Attempting to view employee in Branch B must redirect'
        );
        $session = \Config\Services::session();
        $this->assertStringContainsString(
            '403 Forbidden: Employee record is outside your authorized scope.',
            (string)$session->getFlashdata('error')
        );

        // 2. View employee in Branch A -> Allowed (renders view or loads successfully without 403 error)
        $this->initControllerContext($ctrl, $hrActor);
        $responseA = $ctrl->show($this->empAId);
        $this->assertFalse(
            $responseA->isRedirect(),
            'Viewing employee in own Branch A must NOT redirect with error'
        );
    }

    /**
     * Test 6: EmployeeController::editData enforces branch restriction:
     * hr_officer in branch A gets 403 JSON on branch B employee, and 200 on branch A employee.
     */
    public function testEmployeeControllerEditDataEnforcesBranchRestriction()
    {
        $hrActor = [
            'id'          => 'usr-hr-a',
            'username'    => 'hr_helena',
            'company_id'  => $this->companyId,
            'branch_id'   => $this->branchA,
            'employee_id' => $this->empHrId,
            'role_code'   => 'hr_officer',
            'role'        => 'HR Officer',
            'permissions' => ['employees.edit', 'employee.edit', 'employees.view', 'directory.view'],
        ];

        $ctrl = new EmployeeController();
        $this->initControllerContext($ctrl, $hrActor);

        // 1. editData on Branch B employee -> HTTP 403
        $respB = $ctrl->editData($this->empBId);
        $this->assertEquals(403, $respB->getStatusCode());
        $bodyB = json_decode((string)$respB->getBody(), true);
        $this->assertFalse($bodyB['success']);
        $this->assertStringContainsString('outside your authorized scope', $bodyB['message']);

        // 2. editData on Branch A employee -> HTTP 200
        $this->initControllerContext($ctrl, $hrActor);
        $respA = $ctrl->editData($this->empAId);
        $this->assertEquals(200, $respA->getStatusCode());
        $bodyA = json_decode((string)$respA->getBody(), true);
        $this->assertTrue($bodyA['success']);
        $this->assertEquals($this->empAId, $bodyA['data']['id']);
    }

    /**
     * Test 7: EmployeeSalaryController::getSalary enforces branch restriction:
     * hr_officer in branch A gets 403 JSON on branch B employee.
     */
    public function testEmployeeSalaryControllerGetSalaryEnforcesBranchRestriction()
    {
        $hrActor = [
            'id'          => 'usr-hr-a',
            'username'    => 'hr_helena',
            'company_id'  => $this->companyId,
            'branch_id'   => $this->branchA,
            'employee_id' => $this->empHrId,
            'role_code'   => 'hr_officer',
            'role'        => 'HR Officer',
            'permissions' => ['employees.view', 'employee.view', 'employee.view_salary'],
        ];

        $ctrl = new EmployeeSalaryController();
        $this->initControllerContext($ctrl, $hrActor);

        // 1. getSalary on Branch B employee -> HTTP 403
        $respB = $ctrl->getSalary($this->empBId);
        $this->assertEquals(403, $respB->getStatusCode());
        $bodyB = json_decode((string)$respB->getBody(), true);
        $this->assertFalse($bodyB['success']);
        $this->assertStringContainsString('outside your authorized scope', $bodyB['message']);

        // 2. getSalary on Branch A employee -> Allowed (200)
        $this->initControllerContext($ctrl, $hrActor);
        $respA = $ctrl->getSalary($this->empAId);
        $this->assertEquals(200, $respA->getStatusCode());
        $bodyA = json_decode((string)$respA->getBody(), true);
        $this->assertTrue($bodyA['success']);
    }
}
