<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Models\EmployeeModel;
use App\Services\AttendanceRuleEngine;

/**
 * Unit Test Suite: Point-in-Time Employment Tenure in Attendance & Reports
 *
 * Verifies that:
 * 1. An employee who resigned on 2026-09-30 appears in reports/calculations for 2026-09-15
 *    (joining_date <= date AND separation_date >= date).
 * 2. An employee who resigned on 2026-09-30 does NOT appear for 2026-10-15 (separation_date < date).
 * 3. Employee status on past dates is evaluated by tenure regardless of current status (Active/Resigned/Terminated).
 * 4. For today and future dates, Active/Probation status check is enforced.
 * 5. Preloaded employees and database query paths in AttendanceRuleEngine both adhere to this rule.
 */
class AttendancePointInTimeTenureTest extends TestCase
{
    protected string $companyId = 'comp-test-101';

    /**
     * Test 1: Employee who resigned on 2026-09-30 MUST appear for 2026-09-15 and MUST NOT appear for 2026-10-15
     */
    public function testResignedEmployeeAppearsOnPastDateAndNotAfterSeparation()
    {
        $resignedEmployee = [
            'id'                => 'emp-resigned-001',
            'employee_code'     => 'EMP-RES-01',
            'name'              => 'Rahim Uddin',
            'first_name'        => 'Rahim',
            'last_name'         => 'Uddin',
            'company_id'        => $this->companyId,
            'status'            => 'Resigned',
            'joining_date'      => '2025-01-01',
            'last_working_date' => '2026-09-30',
            'resignation_date'  => '2026-09-30',
            'separation_date'   => '2026-09-30',
            'shift_id'          => 'shift-std',
            'start_time'        => '09:00',
            'end_time'          => '17:00',
            'grace_time'        => 15,
            'weekly_off'        => ['Friday'],
        ];

        $stillActiveEmployee = [
            'id'                => 'emp-active-002',
            'employee_code'     => 'EMP-ACT-02',
            'name'              => 'Karim Hasan',
            'first_name'        => 'Karim',
            'last_name'         => 'Hasan',
            'company_id'        => $this->companyId,
            'status'            => 'Active',
            'joining_date'      => '2025-01-01',
            'last_working_date' => null,
            'separation_date'   => null,
            'shift_id'          => 'shift-std',
            'start_time'        => '09:00',
            'end_time'          => '17:00',
            'grace_time'        => 15,
            'weekly_off'        => ['Friday'],
        ];

        $engine = new AttendanceRuleEngine();

        // 1. Evaluate on 2026-09-15 (before resignation date 2026-09-30)
        // Rahim MUST be included in the calculation and appear in headcount
        $resultSep15 = $engine->calculateAttendanceForDate(
            '2026-09-15',
            null,
            null,
            $this->companyId,
            null,
            null,
            [$resignedEmployee, $stillActiveEmployee],
            false,
            false
        );

        $this->assertEquals(2, $resultSep15['total_active'], 'Both employees must be active on 2026-09-15');
        $employeeIdsSep15 = array_column($resultSep15['employees'], 'id');
        $this->assertContains('emp-resigned-001', $employeeIdsSep15, 'Resigned employee must appear for 2026-09-15');
        $this->assertContains('emp-active-002', $employeeIdsSep15);

        // 2. Evaluate on 2026-10-15 (after resignation date 2026-09-30)
        // Rahim MUST NOT be included in the calculation
        $resultOct15 = $engine->calculateAttendanceForDate(
            '2026-10-15',
            null,
            null,
            $this->companyId,
            null,
            null,
            [$resignedEmployee, $stillActiveEmployee],
            false,
            false
        );

        $this->assertEquals(1, $resultOct15['total_active'], 'Only Karim must be active on 2026-10-15');
        $employeeIdsOct15 = array_column($resultOct15['employees'], 'id');
        $this->assertNotContains('emp-resigned-001', $employeeIdsOct15, 'Resigned employee must NOT appear for 2026-10-15');
        $this->assertContains('emp-active-002', $employeeIdsOct15);
    }

    /**
     * Test 2: EmployeeModel::resolveSeparationDate resolves separation date correctly across keys
     */
    public function testResolveSeparationDatePrecedence()
    {
        // Explicit separation_date
        $emp1 = ['separation_date' => '2026-09-30', 'last_working_date' => '2026-09-28'];
        $this->assertEquals('2026-09-30', EmployeeModel::resolveSeparationDate($emp1));

        // Fallback to last_working_date
        $emp2 = ['last_working_date' => '2026-09-30'];
        $this->assertEquals('2026-09-30', EmployeeModel::resolveSeparationDate($emp2));

        // Fallback to last_working_day
        $emp3 = ['last_working_day' => '2026-09-30'];
        $this->assertEquals('2026-09-30', EmployeeModel::resolveSeparationDate($emp3));

        // Fallback to termination_date
        $emp4 = ['termination_date' => '2026-08-31'];
        $this->assertEquals('2026-08-31', EmployeeModel::resolveSeparationDate($emp4));

        // Fallback to resignation_date
        $emp5 = ['resignation_date' => '2026-07-31'];
        $this->assertEquals('2026-07-31', EmployeeModel::resolveSeparationDate($emp5));

        // Null when active without separation dates
        $emp6 = ['status' => 'Active', 'joining_date' => '2025-01-01'];
        $this->assertNull(EmployeeModel::resolveSeparationDate($emp6));
    }

    /**
     * Test 3: SQL generation for point-in-time tenure filters
     */
    public function testSeparationSqlGeneration()
    {
        $model = new EmployeeModel();
        $sepSql = $model->getSeparationDateSql('employees.');

        // Must coalesce separation fields
        $this->assertStringContainsString('COALESCE', $sepSql);
        $this->assertStringContainsString('employees.', $sepSql);
    }

    /**
     * Test 4: Terminated employee point-in-time boundary check
     */
    public function testTerminatedEmployeeBoundary()
    {
        $engine = new AttendanceRuleEngine();
        $terminatedEmployee = [
            'id'                => 'emp-term-003',
            'employee_code'     => 'EMP-TRM-03',
            'name'              => 'Sadia Jahan',
            'first_name'        => 'Sadia',
            'last_name'         => 'Jahan',
            'company_id'        => $this->companyId,
            'status'            => 'Terminated',
            'joining_date'      => '2026-01-01',
            'termination_date'  => '2026-08-31',
            'last_working_date' => '2026-08-31',
            'separation_date'   => '2026-08-31',
            'shift_id'          => 'shift-std',
            'start_time'        => '09:00',
            'end_time'          => '17:00',
            'grace_time'        => 15,
            'weekly_off'        => ['Friday'],
        ];

        // Before termination: 2026-08-15 -> MUST be included
        $resultAug = $engine->calculateAttendanceForDate(
            '2026-08-15',
            null,
            null,
            $this->companyId,
            null,
            null,
            [$terminatedEmployee],
            false,
            false
        );
        $this->assertEquals(1, $resultAug['total_active']);
        $this->assertEquals('emp-term-003', $resultAug['employees'][0]['id']);

        // After termination: 2026-09-01 -> MUST be excluded
        $resultSep = $engine->calculateAttendanceForDate(
            '2026-09-01',
            null,
            null,
            $this->companyId,
            null,
            null,
            [$terminatedEmployee],
            false,
            false
        );
        $this->assertEquals(0, $resultSep['total_active']);
        $this->assertEmpty($resultSep['employees']);
    }
}
