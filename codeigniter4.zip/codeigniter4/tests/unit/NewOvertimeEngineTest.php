<?php

namespace Tests\Unit;

use App\Models\OvertimePolicyModel;
use App\Models\OvertimeRecordModel;
use App\Services\Overtime\OvertimeCalculationService;
use Config\Database;
use PHPUnit\Framework\TestCase;

class NewOvertimeEngineTest extends TestCase
{
    protected OvertimeCalculationService $otService;

    protected function setUp(): void
    {
        parent::setUp();
        $db = Database::connect();

        $db->query("CREATE TABLE IF NOT EXISTS holidays (
            id VARCHAR(64) PRIMARY KEY,
            company_id VARCHAR(64),
            name VARCHAR(128),
            start_date DATE,
            end_date DATE,
            status VARCHAR(32) DEFAULT 'Published'
        )");

        $db->query("CREATE TABLE IF NOT EXISTS overtime_policies (
            id VARCHAR(64) PRIMARY KEY,
            company_id VARCHAR(64) NOT NULL,
            branch_id VARCHAR(64) NULL,
            department_id VARCHAR(64) NULL,
            policy_name VARCHAR(128) NOT NULL,
            is_default TINYINT(1) NOT NULL DEFAULT 0,
            allow_early_arrival_ot TINYINT(1) NOT NULL DEFAULT 0,
            early_arrival_grace_minutes INT NOT NULL DEFAULT 15,
            early_arrival_min_threshold_minutes INT NOT NULL DEFAULT 15,
            post_shift_grace_minutes INT NOT NULL DEFAULT 15,
            post_shift_min_threshold_minutes INT NOT NULL DEFAULT 15,
            normal_ot_multiplier DECIMAL(4,2) NOT NULL DEFAULT 1.50,
            weekly_off_ot_multiplier DECIMAL(4,2) NOT NULL DEFAULT 2.00,
            holiday_ot_multiplier DECIMAL(4,2) NOT NULL DEFAULT 2.00,
            min_ot_unit_minutes INT NOT NULL DEFAULT 15,
            rounding_mode VARCHAR(32) NOT NULL DEFAULT 'round',
            salary_basis VARCHAR(32) NOT NULL DEFAULT 'Basic Salary',
            divisor_mode VARCHAR(32) NOT NULL DEFAULT 'Fixed 30 Days',
            divisor_days DECIMAL(5,2) NOT NULL DEFAULT 30.00,
            standard_daily_hours DECIMAL(4,2) NOT NULL DEFAULT 8.00,
            max_daily_ot_hours DECIMAL(4,2) NOT NULL DEFAULT 4.00,
            requires_post_approval TINYINT(1) NOT NULL DEFAULT 0,
            status VARCHAR(32) NOT NULL DEFAULT 'Active',
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $db->query("CREATE TABLE IF NOT EXISTS overtime_records (
            id VARCHAR(64) PRIMARY KEY,
            company_id VARCHAR(64) NOT NULL,
            employee_id VARCHAR(64) NOT NULL,
            attendance_log_id VARCHAR(64) NULL,
            policy_id VARCHAR(64) NULL,
            date DATE NOT NULL,
            ot_type VARCHAR(32) NOT NULL DEFAULT 'Normal',
            shift_id VARCHAR(64) NULL,
            shift_start TIME NULL,
            shift_end TIME NULL,
            actual_in TIME NULL,
            actual_out TIME NULL,
            raw_early_minutes INT NOT NULL DEFAULT 0,
            raw_post_minutes INT NOT NULL DEFAULT 0,
            raw_total_minutes INT NOT NULL DEFAULT 0,
            payable_early_minutes INT NOT NULL DEFAULT 0,
            payable_post_minutes INT NOT NULL DEFAULT 0,
            payable_total_minutes INT NOT NULL DEFAULT 0,
            overtime_hours DECIMAL(6,2) NOT NULL DEFAULT 0.00,
            base_salary DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            hourly_rate DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            multiplier DECIMAL(4,2) NOT NULL DEFAULT 1.50,
            ot_rate DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            ot_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            approval_status VARCHAR(32) NOT NULL DEFAULT 'Pending',
            approved_by VARCHAR(64) NULL,
            approved_at DATETIME NULL,
            rejection_reason TEXT NULL,
            is_settled TINYINT(1) NOT NULL DEFAULT 0,
            payroll_id VARCHAR(64) NULL,
            settled_at DATETIME NULL,
            calculation_metadata_json TEXT NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $db->query("CREATE TABLE IF NOT EXISTS overtime_claims (
            id VARCHAR(64) PRIMARY KEY,
            company_id VARCHAR(64) NOT NULL,
            employee_id VARCHAR(64) NOT NULL,
            overtime_record_id VARCHAR(64) NULL,
            date DATE NOT NULL,
            ot_type VARCHAR(32) NOT NULL DEFAULT 'Normal',
            requested_hours DECIMAL(5,2) NOT NULL DEFAULT 0.00,
            approved_hours DECIMAL(5,2) NULL,
            reason TEXT NULL,
            status VARCHAR(32) NOT NULL DEFAULT 'Pending',
            reviewed_by VARCHAR(64) NULL,
            reviewed_at DATETIME NULL,
            rejection_reason TEXT NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $db->query("CREATE TABLE IF NOT EXISTS overtime_settlement_locks (
            id VARCHAR(64) PRIMARY KEY,
            company_id VARCHAR(64) NOT NULL,
            payroll_id VARCHAR(64) NOT NULL,
            payroll_month VARCHAR(10) NOT NULL,
            total_records INT NOT NULL DEFAULT 0,
            total_hours DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            total_amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
            locked_by VARCHAR(64) NOT NULL,
            locked_at DATETIME NOT NULL,
            lock_hash VARCHAR(64) NOT NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $db->query("CREATE TABLE IF NOT EXISTS attendance_logs (
            id VARCHAR(64) PRIMARY KEY,
            company_id VARCHAR(64),
            employee_id VARCHAR(64),
            date DATE,
            in_time TIME,
            out_time TIME,
            check_in TIME,
            check_out TIME,
            overtime_hours DECIMAL(5,2) DEFAULT 0.00,
            ot_amount DECIMAL(10,2) DEFAULT 0.00,
            ot_approval_status VARCHAR(32) DEFAULT 'Not Required',
            is_ot_payable TINYINT(1) DEFAULT 0,
            is_settled TINYINT(1) DEFAULT 0
        )");

        $db->query("CREATE TABLE IF NOT EXISTS employees (
            id VARCHAR(64) PRIMARY KEY,
            company_id VARCHAR(64),
            branch_id VARCHAR(64),
            department_id VARCHAR(64),
            designation_id VARCHAR(64),
            shift_id VARCHAR(64),
            first_name VARCHAR(64),
            last_name VARCHAR(64),
            employee_code VARCHAR(32),
            basic_salary DECIMAL(12,2) DEFAULT 0.00,
            gross_salary DECIMAL(12,2) DEFAULT 0.00,
            status VARCHAR(32) DEFAULT 'Active'
        )");

        $this->otService = new OvertimeCalculationService();
    }

    /**
     * Test 1: Policy Resolution & Default Fallback
     */
    public function testPolicyResolutionAndDefaults()
    {
        $policy = $this->otService->resolvePolicy('TEST-COMP-01');

        $this->assertNotEmpty($policy);
        $this->assertEquals(1.50, (float)$policy['normal_ot_multiplier']);
        $this->assertEquals(2.00, (float)$policy['weekly_off_ot_multiplier']);
        $this->assertEquals(2.00, (float)$policy['holiday_ot_multiplier']);
        $this->assertEquals(15, (int)$policy['min_ot_unit_minutes']);
        $this->assertEquals(30.00, (float)$policy['divisor_days']);
        $this->assertEquals(8.00, (float)$policy['standard_daily_hours']);
    }

    /**
     * Test 2: Authoritative Hourly Rate Derivation
     */
    public function testHourlyRateDerivation()
    {
        $employee = [
            'id'           => 'emp-test-01',
            'company_id'   => 'TEST-COMP-01',
            'basic_salary' => 24000.00,
            'gross_salary' => 48000.00
        ];

        // 1. Basic salary basis
        $policyBasic = [
            'salary_basis'         => 'Basic Salary',
            'divisor_mode'         => 'Fixed 30 Days',
            'divisor_days'         => 30.00,
            'standard_daily_hours' => 8.00
        ];
        $rateBasic = $this->otService->calculateHourlyRate($employee, $policyBasic);
        // 24,000 / (30 * 8) = 24,000 / 240 = 100.00
        $this->assertEquals(100.00, $rateBasic['hourly_rate']);
        $this->assertEquals(240.00, $rateBasic['total_monthly_hours']);

        // 2. Gross salary basis
        $policyGross = [
            'salary_basis'         => 'Gross Salary',
            'divisor_mode'         => 'Fixed 30 Days',
            'divisor_days'         => 30.00,
            'standard_daily_hours' => 8.00
        ];
        $rateGross = $this->otService->calculateHourlyRate($employee, $policyGross);
        // 48,000 / 240 = 200.00
        $this->assertEquals(200.00, $rateGross['hourly_rate']);

        // 3. 26 Days Divisor
        $policy26 = [
            'salary_basis'         => 'Basic Salary',
            'divisor_mode'         => 'Fixed 26 Days',
            'divisor_days'         => 26.00,
            'standard_daily_hours' => 8.00
        ];
        $rate26 = $this->otService->calculateHourlyRate($employee, $policy26);
        // 24,000 / (26 * 8) = 24,000 / 208 = 115.38
        $this->assertEquals(115.38, $rate26['hourly_rate']);
    }

    /**
     * Test 3: Minimum Counting Unit & Rounding Modes
     */
    public function testUnitRoundingModes()
    {
        // 85 minutes with 15-minute unit
        // Floor: floor(85 / 15) * 15 = 5 * 15 = 75
        $this->assertEquals(75, OvertimeCalculationService::applyUnitRounding(85, 15, 'floor'));

        // Round: round(85 / 15) * 15 = 6 * 15 = 90
        $this->assertEquals(90, OvertimeCalculationService::applyUnitRounding(85, 15, 'round'));

        // Ceil: ceil(85 / 15) * 15 = 6 * 15 = 90
        $this->assertEquals(90, OvertimeCalculationService::applyUnitRounding(85, 15, 'ceil'));

        // Exact: 85
        $this->assertEquals(85, OvertimeCalculationService::applyUnitRounding(85, 15, 'exact'));

        // 30-minute block rounding
        // 40 minutes floor 30 = 30
        $this->assertEquals(30, OvertimeCalculationService::applyUnitRounding(40, 30, 'floor'));
        // 45 minutes round 30 = 60 (or 2 units)
        $this->assertEquals(60, OvertimeCalculationService::applyUnitRounding(45, 30, 'round'));
    }

    /**
     * Test 4: Early Arrival Overtime Calculation
     */
    public function testEarlyArrivalOvertimeCalculation()
    {
        $employee = [
            'id'           => 'emp-test-02',
            'company_id'   => 'TEST-COMP-01',
            'basic_salary' => 24000.00,
            'gross_salary' => 30000.00
        ];

        $shift = [
            'id'         => 'shift-std',
            'name'       => 'Standard Shift',
            'start_time' => '09:00:00',
            'end_time'   => '18:00:00'
        ];

        // Case A: Early Arrival Allowed with 15 min grace, 15 min threshold
        $policyAllowed = [
            'enable_early_arrival_ot'             => 1,
            'early_arrival_grace_minutes'         => 15,
            'early_arrival_min_threshold_minutes' => 15,
            'enable_post_shift_ot'                => 1,
            'post_shift_grace_minutes'            => 15,
            'post_shift_min_threshold_minutes'    => 15,
            'min_ot_unit_minutes'                 => 15,
            'rounding_mode'                       => 'exact',
            'normal_ot_multiplier'                => 1.50,
            'salary_basis'                        => 'Basic Salary',
            'divisor_days'                        => 30.00,
            'standard_daily_hours'                => 8.00,
            'max_daily_ot_hours'                  => 4.00,
            'requires_post_approval'              => 0
        ];

        // Punch in at 08:15 (45 mins early), Punch out at 18:00 (no post-shift)
        // Date is Wednesday (normal workday)
        $attendanceLog = [
            'date'      => '2026-09-02',
            'check_in'  => '08:15:00',
            'check_out' => '18:00:00'
        ];

        $calc = $this->otService->calculateDailyOvertime($employee, $attendanceLog, $shift, $policyAllowed);

        $this->assertEquals(45, $calc['raw_early_minutes']);
        // 45 - 15 grace = 30 payable minutes = 0.50 hours
        $this->assertEquals(30, $calc['payable_early_minutes']);
        $this->assertEquals(0.50, $calc['overtime_hours']);
        $this->assertEquals(100.00, $calc['hourly_rate']);
        $this->assertEquals(150.00, $calc['ot_rate']); // 100 * 1.5
        $this->assertEquals(75.00, $calc['ot_amount']); // 0.50 * 150 = 75.00
        $this->assertEquals('Approved', $calc['approval_status']);

        // Case B: Early Arrival Disallowed
        $policyDisabled = $policyAllowed;
        $policyDisabled['enable_early_arrival_ot'] = 0;

        $calcDisabled = $this->otService->calculateDailyOvertime($employee, $attendanceLog, $shift, $policyDisabled);
        $this->assertEquals(0, $calcDisabled['payable_early_minutes']);
        $this->assertEquals(0.00, $calcDisabled['overtime_hours']);
        $this->assertEquals(0.00, $calcDisabled['ot_amount']);
    }

    /**
     * Test 5: Post-Shift Overtime and Combined Early + Post-Shift
     */
    public function testPostShiftAndCombinedOvertime()
    {
        $employee = [
            'id'           => 'emp-test-03',
            'company_id'   => 'TEST-COMP-01',
            'basic_salary' => 24000.00,
            'gross_salary' => 30000.00
        ];

        $shift = [
            'id'         => 'shift-std',
            'name'       => 'Standard Shift',
            'start_time' => '09:00:00',
            'end_time'   => '18:00:00'
        ];

        $policy = [
            'enable_early_arrival_ot'             => 1,
            'early_arrival_grace_minutes'         => 15,
            'early_arrival_min_threshold_minutes' => 15,
            'enable_post_shift_ot'                => 1,
            'post_shift_grace_minutes'            => 15,
            'post_shift_min_threshold_minutes'    => 15,
            'min_ot_unit_minutes'                 => 15,
            'rounding_mode'                       => 'floor',
            'normal_ot_multiplier'                => 1.50,
            'salary_basis'                        => 'Basic Salary',
            'divisor_days'                        => 30.00,
            'standard_daily_hours'                => 8.00,
            'max_daily_ot_hours'                  => 4.00,
            'requires_post_approval'              => 0
        ];

        // Punch in: 08:30 (30 mins early -> 30-15 = 15 payable)
        // Punch out: 19:40 (100 mins post -> 100-15 = 85 payable)
        // Total unrounded payable = 15 + 85 = 100 mins
        // Floor(100 / 15) * 15 = 6 * 15 = 90 mins = 1.50 hours
        $attendanceLog = [
            'date'      => '2026-09-03', // Thursday
            'check_in'  => '08:30:00',
            'check_out' => '19:40:00'
        ];

        $calc = $this->otService->calculateDailyOvertime($employee, $attendanceLog, $shift, $policy);

        $this->assertEquals(30, $calc['raw_early_minutes']);
        $this->assertEquals(100, $calc['raw_post_minutes']);
        $this->assertEquals(15, $calc['payable_early_minutes']);
        $this->assertEquals(85, $calc['payable_post_minutes']);
        $this->assertEquals(90, $calc['payable_total_minutes']);
        $this->assertEquals(1.50, $calc['overtime_hours']);
        $this->assertEquals(225.00, $calc['ot_amount']); // 1.50 * 150 = 225.00
    }

    /**
     * Test 6: Weekly Off & Holiday Multipliers
     */
    public function testWeeklyOffAndHolidayMultipliers()
    {
        $employee = [
            'id'           => 'emp-test-04',
            'company_id'   => 'TEST-COMP-01',
            'basic_salary' => 24000.00,
            'gross_salary' => 30000.00
        ];

        $shift = [
            'id'           => 'shift-std',
            'start_time'   => '09:00:00',
            'end_time'     => '18:00:00',
            'weekend_days' => 'Sunday'
        ];

        $policy = [
            'normal_ot_multiplier'     => 1.50,
            'weekly_off_ot_multiplier' => 2.00,
            'holiday_ot_multiplier'    => 2.50,
            'min_ot_unit_minutes'      => 15,
            'rounding_mode'            => 'round',
            'salary_basis'             => 'Basic Salary',
            'divisor_days'             => 30.00,
            'standard_daily_hours'     => 8.00,
            'max_daily_ot_hours'       => 8.00,
            'requires_post_approval'   => 0
        ];

        // 2026-09-06 is a Sunday (standard weekly off)
        // Employee worked 6 hours from 10:00 to 16:00
        $attendanceLog = [
            'date'      => '2026-09-06',
            'check_in'  => '10:00:00',
            'check_out' => '16:00:00'
        ];

        $calcSunday = $this->otService->calculateDailyOvertime($employee, $attendanceLog, $shift, $policy);

        $this->assertEquals('Weekly Off', $calcSunday['ot_type']);
        $this->assertEquals(2.00, (float)$calcSunday['multiplier']);
        $this->assertEquals(6.00, (float)$calcSunday['overtime_hours']);
        $this->assertEquals(200.00, (float)$calcSunday['ot_rate']); // 100 * 2.0
        $this->assertEquals(1200.00, (float)$calcSunday['ot_amount']); // 6 * 200 = 1200.00

        // Test with Holiday
        $holidays = [
            [
                'id'         => 'hol-1',
                'name'       => 'National Holiday',
                'start_date' => '2026-09-15',
                'end_date'   => '2026-09-15'
            ]
        ];

        $holidayLog = [
            'date'      => '2026-09-15',
            'check_in'  => '09:00:00',
            'check_out' => '13:00:00' // 4 hours
        ];

        $calcHoliday = $this->otService->calculateDailyOvertime($employee, $holidayLog, $shift, $policy, $holidays);
        $this->assertEquals('Holiday', $calcHoliday['ot_type']);
        $this->assertEquals(2.50, (float)$calcHoliday['multiplier']);
        $this->assertEquals(4.00, (float)$calcHoliday['overtime_hours']);
        $this->assertEquals(250.00, (float)$calcHoliday['ot_rate']); // 100 * 2.5
        $this->assertEquals(1000.00, (float)$calcHoliday['ot_amount']); // 4 * 250 = 1000.00
    }

    /**
     * Test 7: Max Daily Overtime Cap Enforcement
     */
    public function testMaxDailyOvertimeCap()
    {
        $employee = [
            'id'           => 'emp-test-05',
            'company_id'   => 'TEST-COMP-01',
            'basic_salary' => 24000.00,
        ];

        $shift = [
            'id'         => 'shift-std',
            'start_time' => '09:00:00',
            'end_time'   => '18:00:00'
        ];

        $policy = [
            'enable_early_arrival_ot'             => 0,
            'early_arrival_min_threshold_minutes' => 0,
            'enable_post_shift_ot'                => 1,
            'post_shift_grace_minutes'            => 0,
            'post_shift_min_threshold_minutes'    => 0,
            'min_ot_unit_minutes'                 => 1,
            'rounding_mode'                       => 'exact',
            'normal_ot_multiplier'                => 1.50,
            'salary_basis'                        => 'Basic Salary',
            'divisor_days'                        => 30.00,
            'standard_daily_hours'                => 8.00,
            'max_daily_ot_hours'                  => 3.00, // Capped at 3.0 hours
            'requires_post_approval'              => 0
        ];

        // Punch out at 23:00 (5 hours post-shift)
        $attendanceLog = [
            'date'      => '2026-09-02',
            'check_in'  => '09:00:00',
            'check_out' => '23:00:00'
        ];

        $calc = $this->otService->calculateDailyOvertime($employee, $attendanceLog, $shift, $policy);
        $this->assertEquals(3.00, (float)$calc['overtime_hours'], "Overtime should be capped at max_daily_ot_hours = 3.0");
        $this->assertEquals(450.00, (float)$calc['ot_amount']); // 3 * 150 = 450
    }

    /**
     * Test 8: Claim Workflow (Submit, Approve, Reject)
     */
    public function testClaimSubmissionAndReview()
    {
        $claim = $this->otService->submitClaim([
            'company_id'      => 'TEST-COMP-01',
            'employee_id'     => 'emp-test-06',
            'date'            => '2026-09-01',
            'ot_type'         => 'Post-Shift',
            'requested_hours' => 2.50,
            'reason'          => 'System deployment overtime'
        ]);

        $this->assertNotEmpty($claim['id']);
        $this->assertEquals('Pending', $claim['status']);

        // Approve Claim
        $approved = $this->otService->reviewClaim($claim['id'], 'admin-user', 'approve', 2.00, 'Approved 2 hours', 'TEST-COMP-01');
        $this->assertTrue($approved);

        $claimModel = new \App\Models\OvertimeClaimModel();
        $updated = $claimModel->find($claim['id']);
        $this->assertEquals('Approved', $updated['status']);
        $this->assertEquals(2.00, (float)$updated['approved_hours']);

        // Test Rejection on second claim
        $claim2 = $this->otService->submitClaim([
            'company_id'      => 'TEST-COMP-01',
            'employee_id'     => 'emp-test-06',
            'date'            => '2026-09-02',
            'ot_type'         => 'Early Arrival',
            'requested_hours' => 1.00,
            'reason'          => 'Came in early'
        ]);

        $rejected = $this->otService->reviewClaim($claim2['id'], 'admin-user', 'reject', null, 'Not pre-approved', 'TEST-COMP-01');
        $this->assertTrue($rejected);

        $updated2 = $claimModel->find($claim2['id']);
        $this->assertEquals('Rejected', $updated2['status']);
        $this->assertEquals('Not pre-approved', $updated2['rejection_reason']);
    }

    /**
     * Test 9: Payroll Hard-Lock and Settlement Immutability
     */
    public function testPayrollSettlementHardLockImmutability()
    {
        $companyId  = 'TEST-COMP-LOCK';
        $employeeId = 'emp-test-lock-01';
        $month      = '2026-08';
        $date       = '2026-08-10';

        // 1. Create and persist an approved OT record
        $recordData = [
            'company_id'            => $companyId,
            'employee_id'           => $employeeId,
            'date'                  => $date,
            'ot_type'               => 'Normal',
            'raw_early_minutes'     => 0,
            'raw_post_minutes'      => 120,
            'raw_total_minutes'     => 120,
            'payable_early_minutes' => 0,
            'payable_post_minutes'  => 120,
            'payable_total_minutes' => 120,
            'overtime_hours'        => 2.00,
            'base_salary'           => 24000.00,
            'hourly_rate'           => 100.00,
            'multiplier'            => 1.50,
            'ot_rate'               => 150.00,
            'ot_amount'             => 300.00,
            'approval_status'       => 'Approved',
            'is_settled'            => 0
        ];

        $savedRecord = $this->otService->persistRecord($recordData);
        $this->assertNotEmpty($savedRecord['id']);
        $this->assertEquals(0, $savedRecord['is_settled']);

        // 2. Query summary for payroll
        $summary = $this->otService->getSummaryForPayroll($employeeId, $month, $companyId);
        $this->assertEquals(2.00, $summary['approved_hours']);
        $this->assertEquals(300.00, $summary['ot_amount']);

        // 3. Settle and Hard-Lock
        $payrollId = 'pay-batch-202608';
        $settleResult = $this->otService->settleOvertimeForPayroll($payrollId, $month, $companyId, 'admin-user');

        $this->assertTrue($settleResult['success']);
        $this->assertEquals(2.00, $settleResult['total_hours']);
        $this->assertEquals(300.00, $settleResult['total_amount']);
        $this->assertNotEmpty($settleResult['lock_hash']);

        // 4. Verify month is reported as locked
        $this->assertTrue($this->otService->isMonthLocked($companyId, $month));

        // 5. Immutability Verification: Attempt to recalculate / persist different values
        $modifiedData = $recordData;
        $modifiedData['overtime_hours'] = 5.00;
        $modifiedData['ot_amount']      = 750.00;

        $attemptedRepersist = $this->otService->persistRecord($modifiedData);

        // Record must remain locked at original 2.00 hours and 300.00 amount!
        $this->assertEquals(2.00, (float)$attemptedRepersist['overtime_hours']);
        $this->assertEquals(300.00, (float)$attemptedRepersist['ot_amount']);
        $this->assertEquals(1, (int)$attemptedRepersist['is_settled']);
    }

    /**
     * Test 10: Approval Lifecycle and Payroll Summary Exclusion
     */
    public function testApprovalLifecycleAndPayrollExclusion()
    {
        $companyId  = 'TEST-COMP-APPR';
        $employeeId = 'emp-test-appr-01';
        $month      = '2026-07';

        // 1. Record A: Approved -> 2 hours, $300
        $recA = $this->otService->persistRecord([
            'company_id'      => $companyId,
            'employee_id'     => $employeeId,
            'date'            => '2026-07-05',
            'ot_type'         => 'Normal',
            'overtime_hours'  => 2.00,
            'hourly_rate'     => 100.00,
            'multiplier'      => 1.50,
            'ot_rate'         => 150.00,
            'ot_amount'       => 300.00,
            'approval_status' => 'Approved',
            'is_settled'      => 0
        ]);

        // 2. Record B: Pending -> 1.5 hours, $225
        $recB = $this->otService->persistRecord([
            'company_id'      => $companyId,
            'employee_id'     => $employeeId,
            'date'            => '2026-07-12',
            'ot_type'         => 'Normal',
            'overtime_hours'  => 1.50,
            'hourly_rate'     => 100.00,
            'multiplier'      => 1.50,
            'ot_rate'         => 150.00,
            'ot_amount'       => 225.00,
            'approval_status' => 'Pending',
            'is_settled'      => 0
        ]);

        // 3. Record C: Rejected -> 1 hour, $150
        $recC = $this->otService->persistRecord([
            'company_id'      => $companyId,
            'employee_id'     => $employeeId,
            'date'            => '2026-07-19',
            'ot_type'         => 'Normal',
            'overtime_hours'  => 1.00,
            'hourly_rate'     => 100.00,
            'multiplier'      => 1.50,
            'ot_rate'         => 150.00,
            'ot_amount'       => 150.00,
            'approval_status' => 'Rejected',
            'rejection_reason'=> 'Unapproved extra work',
            'is_settled'      => 0
        ]);

        // Payroll summary should ONLY include Record A (Approved)
        $summary = $this->otService->getSummaryForPayroll($employeeId, $month, $companyId);
        $this->assertEquals(2.00, $summary['approved_hours']);
        $this->assertEquals(300.00, $summary['ot_amount']);

        // Now approve Record B
        $approveSuccess = $this->otService->approveRecord($recB['id'], 'manager-01', $companyId);
        $this->assertTrue($approveSuccess);

        // Payroll summary should now include Record A + Record B = 3.50 hours, $525.00
        $updatedSummary = $this->otService->getSummaryForPayroll($employeeId, $month, $companyId);
        $this->assertEquals(3.50, $updatedSummary['approved_hours']);
        $this->assertEquals(525.00, $updatedSummary['ot_amount']);
    }

    /**
     * Test 11: Multi-Tenant Company Scoping Isolation
     */
    public function testMultiTenantCompanyIsolation()
    {
        $compA = 'COMP-ALPHA';
        $compB = 'COMP-BETA';
        $empA  = 'EMP-ALPHA-01';
        $empB  = 'EMP-BETA-01';
        $month = '2026-06';

        $this->otService->persistRecord([
            'company_id'      => $compA,
            'employee_id'     => $empA,
            'date'            => '2026-06-10',
            'ot_type'         => 'Normal',
            'overtime_hours'  => 3.00,
            'hourly_rate'     => 100.00,
            'multiplier'      => 1.50,
            'ot_rate'         => 150.00,
            'ot_amount'       => 450.00,
            'approval_status' => 'Approved',
            'is_settled'      => 0
        ]);

        $this->otService->persistRecord([
            'company_id'      => $compB,
            'employee_id'     => $empB,
            'date'            => '2026-06-10',
            'ot_type'         => 'Normal',
            'overtime_hours'  => 5.00,
            'hourly_rate'     => 100.00,
            'multiplier'      => 1.50,
            'ot_rate'         => 150.00,
            'ot_amount'       => 750.00,
            'approval_status' => 'Approved',
            'is_settled'      => 0
        ]);

        // Comp A summary must never leak Comp B data
        $summaryA = $this->otService->getSummaryForPayroll($empA, $month, $compA);
        $this->assertEquals(3.00, $summaryA['approved_hours']);
        $this->assertEquals(450.00, $summaryA['ot_amount']);

        $summaryB = $this->otService->getSummaryForPayroll($empB, $month, $compB);
        $this->assertEquals(5.00, $summaryB['approved_hours']);
        $this->assertEquals(750.00, $summaryB['ot_amount']);

        // Cross-tenant queries must return 0
        $crossSummary = $this->otService->getSummaryForPayroll($empA, $month, $compB);
        $this->assertEquals(0.00, $crossSummary['approved_hours']);
        $this->assertEquals(0.00, $crossSummary['ot_amount']);
    }

    /**
     * Test 12: Idempotent Overtime Persistence
     */
    public function testCalculationIdempotency()
    {
        $companyId  = 'TEST-COMP-IDEM';
        $employeeId = 'emp-idem-01';
        $date       = '2026-05-15';

        $recordData = [
            'company_id'            => $companyId,
            'employee_id'           => $employeeId,
            'date'                  => $date,
            'ot_type'               => 'Normal',
            'raw_early_minutes'     => 0,
            'raw_post_minutes'      => 60,
            'raw_total_minutes'     => 60,
            'payable_early_minutes' => 0,
            'payable_post_minutes'  => 60,
            'payable_total_minutes' => 60,
            'overtime_hours'        => 1.00,
            'base_salary'           => 24000.00,
            'hourly_rate'           => 100.00,
            'multiplier'            => 1.50,
            'ot_rate'               => 150.00,
            'ot_amount'             => 150.00,
            'approval_status'       => 'Approved',
            'is_settled'            => 0
        ];

        // Save 1
        $saved1 = $this->otService->persistRecord($recordData);

        // Save 2 (identical run)
        $saved2 = $this->otService->persistRecord($recordData);

        // Record IDs must match (updated, not duplicated)
        $this->assertEquals($saved1['id'], $saved2['id']);

        // Count in database for this employee and date must be exactly 1
        $recordModel = new \App\Models\OvertimeRecordModel();
        $count = $recordModel->where('company_id', $companyId)
            ->where('employee_id', $employeeId)
            ->where('date', $date)
            ->countAllResults();

        $this->assertEquals(1, $count, "Duplicate records must never be created on subsequent recalculations.");
    }
}
