<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\CompanyWeekendService;
use App\Services\RuleEngineService;

/**
 * Unit Test: Company Weekend Policy Configuration & Dynamic Weekly-Off Evaluation
 *
 * Verifies that:
 * 1. A company with weekend = ['Saturday', 'Sunday'] treats Friday as a normal working day,
 *    never marks unpunched employees as Weekly Off on Friday, and sets is_friday_weekend = false.
 * 2. A company with weekend = ['Friday'] treats Friday as Weekly Off and Saturday/Sunday as normal working days.
 * 3. An unconfigured company returns [] with no hardcoded Friday fallback when allowSilentFallback = false.
 * 4. RuleEngineService and DayTypeEvaluator respect tenant-specific weekly off arrays without hardcoding Friday.
 */
class CompanyWeekendPolicyTest extends TestCase
{
    protected string $companyFriOnly = 'comp-weekend-fri';
    protected string $companySatSun  = 'comp-weekend-satsun';
    protected string $companyNone    = 'comp-weekend-none';

    protected string $dateFriday   = '2026-11-06'; // Friday
    protected string $dateSaturday = '2026-11-07'; // Saturday
    protected string $dateSunday   = '2026-11-08'; // Sunday

    protected function setUp(): void
    {
        parent::setUp();
        CompanyWeekendService::clearCache();
    }

    /**
     * Test 1: Company whose weekend is Saturday + Sunday.
     * Friday MUST be treated as a normal working day (not weekly off).
     * Saturday and Sunday MUST be treated as weekly off.
     */
    public function testCompanyWithSaturdaySundayWeekendNeverTreatsFridayAsWeekend()
    {
        $shift = [
            'id'         => 'shift-corp',
            'name'       => 'Corporate Shift',
            'start_time' => '09:00:00',
            'end_time'   => '17:00:00',
            'grace_time' => 15,
            'weekly_off' => ['Saturday', 'Sunday']
        ];

        $empSatSun = [
            'id'            => 'emp-satsun-01',
            'employee_code' => 'CORP-001',
            'name'          => 'Sat Sun Worker',
            'company_id'    => $this->companySatSun,
            'joining_date'  => '2025-01-01',
            'weekly_off'    => ['Saturday', 'Sunday']
        ];

        $weeklyOffDays = ['Saturday', 'Sunday'];
        $ruleEngine = new RuleEngineService();

        // 1. Evaluate Friday (2026-11-06)
        $evalFriday = CompanyWeekendService::evaluateDayType($this->dateFriday, $empSatSun, $shift, []);
        // Note: when evaluateDayType runs without DB, it uses employee weekly_off or resolved lookup
        $calcFriday = $ruleEngine->calculateDailyAttendance($this->dateFriday, $empSatSun, null, [], $shift, [], [], null, null, [$empSatSun['id'] => $weeklyOffDays]);

        $this->assertFalse($calcFriday['is_weekend'], 'Friday must NOT be weekend for Saturday+Sunday company');
        $this->assertSame('NORMAL_WORKDAY', $calcFriday['day_type']);
        $this->assertSame('Absent', $calcFriday['status'], 'Unpunched employee on Friday must be Absent, NOT Weekly Off');
        $this->assertTrue($calcFriday['is_absent']);

        // Stats metadata check
        $isFridayWeekend = in_array('Friday', $weeklyOffDays, true) && (date('l', strtotime($this->dateFriday)) === 'Friday');
        $this->assertFalse($isFridayWeekend, 'is_friday_weekend stat must be FALSE when Friday is not a weekly off');

        // 2. Evaluate Saturday (2026-11-07)
        $calcSaturday = $ruleEngine->calculateDailyAttendance($this->dateSaturday, $empSatSun, null, [], $shift, [], [], null, null, [$empSatSun['id'] => $weeklyOffDays]);
        $this->assertTrue($calcSaturday['is_weekend'], 'Saturday must be weekend for Saturday+Sunday company');
        $this->assertSame('WEEKLY_OFF', $calcSaturday['day_type']);
        $this->assertSame('Weekly Off', $calcSaturday['status'], 'Unpunched employee on Saturday must be Weekly Off');
        $this->assertFalse($calcSaturday['is_absent']);

        // 3. Evaluate Sunday (2026-11-08)
        $calcSunday = $ruleEngine->calculateDailyAttendance($this->dateSunday, $empSatSun, null, [], $shift, [], [], null, null, [$empSatSun['id'] => $weeklyOffDays]);
        $this->assertTrue($calcSunday['is_weekend'], 'Sunday must be weekend for Saturday+Sunday company');
        $this->assertSame('WEEKLY_OFF', $calcSunday['day_type']);
        $this->assertSame('Weekly Off', $calcSunday['status'], 'Unpunched employee on Sunday must be Weekly Off');
        $this->assertFalse($calcSunday['is_absent']);
    }

    /**
     * Test 2: Company whose weekend is Friday only.
     * Friday MUST be treated as weekly off.
     * Saturday and Sunday MUST be treated as normal workdays (Absent if unpunched).
     */
    public function testCompanyWithFridayOnlyWeekendTreatsFridayAsWeekendAndWeekendStatTrue()
    {
        $shift = [
            'id'         => 'shift-std',
            'name'       => 'Standard Shift',
            'start_time' => '08:00:00',
            'end_time'   => '16:00:00',
            'grace_time' => 15,
            'weekly_off' => ['Friday']
        ];

        $empFri = [
            'id'            => 'emp-fri-01',
            'employee_code' => 'FRI-001',
            'name'          => 'Friday Worker',
            'company_id'    => $this->companyFriOnly,
            'joining_date'  => '2025-01-01',
            'weekly_off'    => ['Friday']
        ];

        $weeklyOffDays = ['Friday'];
        $ruleEngine = new RuleEngineService();

        // 1. Evaluate Friday (2026-11-06)
        $calcFriday = $ruleEngine->calculateDailyAttendance($this->dateFriday, $empFri, null, [], $shift, [], [], null, null, [$empFri['id'] => $weeklyOffDays]);

        $this->assertTrue($calcFriday['is_weekend'], 'Friday must be weekend for Friday-only company');
        $this->assertSame('WEEKLY_OFF', $calcFriday['day_type']);
        $this->assertSame('Weekly Off', $calcFriday['status'], 'Unpunched employee on Friday must be Weekly Off');
        $this->assertFalse($calcFriday['is_absent']);

        $isFridayWeekend = in_array('Friday', $weeklyOffDays, true) && (date('l', strtotime($this->dateFriday)) === 'Friday');
        $this->assertTrue($isFridayWeekend, 'is_friday_weekend stat must be TRUE when Friday is in company weekly off');

        // 2. Evaluate Saturday (2026-11-07)
        $calcSaturday = $ruleEngine->calculateDailyAttendance($this->dateSaturday, $empFri, null, [], $shift, [], [], null, null, [$empFri['id'] => $weeklyOffDays]);
        $this->assertFalse($calcSaturday['is_weekend'], 'Saturday must NOT be weekend for Friday-only company');
        $this->assertSame('NORMAL_WORKDAY', $calcSaturday['day_type']);
        $this->assertSame('Absent', $calcSaturday['status'], 'Unpunched employee on Saturday must be Absent');
        $this->assertTrue($calcSaturday['is_absent']);

        // 3. Evaluate Sunday (2026-11-08)
        $calcSunday = $ruleEngine->calculateDailyAttendance($this->dateSunday, $empFri, null, [], $shift, [], [], null, null, [$empFri['id'] => $weeklyOffDays]);
        $this->assertFalse($calcSunday['is_weekend'], 'Sunday must NOT be weekend for Friday-only company');
        $this->assertSame('NORMAL_WORKDAY', $calcSunday['day_type']);
        $this->assertSame('Absent', $calcSunday['status'], 'Unpunched employee on Sunday must be Absent');
        $this->assertTrue($calcSunday['is_absent']);
    }

    /**
     * Test 3: Unconfigured company weekly-off returns empty list with no silent fallback.
     */
    public function testUnconfiguredCompanyReturnsEmptyListWithoutSilentFallback()
    {
        // When allowSilentFallback is false, unconfigured company must return []
        $offDays = CompanyWeekendService::getCompanyWeeklyOff($this->companyNone, null, false);
        $this->assertSame([], $offDays, 'Unconfigured company must return empty array without fallback');

        // Check isWeeklyOff for unconfigured company on Friday: must be false
        $isOffOnFri = CompanyWeekendService::isWeeklyOff($this->dateFriday, $this->companyNone);
        $this->assertFalse($isOffOnFri, 'Friday is not weekly off when company has no weekly off configured');
    }

    /**
     * Test 4: AttendanceRuleEngine primary bucket partitioning respects non-Friday weekends.
     */
    public function testPrimaryBucketPartitioningWithSaturdaySundayWeekend()
    {
        $employees = [
            ['id' => 'e1', 'employee_code' => 'E1', 'company_id' => $this->companySatSun, 'name' => 'Emp 1'],
            ['id' => 'e2', 'employee_code' => 'E2', 'company_id' => $this->companySatSun, 'name' => 'Emp 2'],
        ];

        $weeklyOffDays = ['Saturday', 'Sunday'];
        $dayOfWeekName = date('l', strtotime($this->dateFriday)); // 'Friday'

        // On Friday:
        $isCompanyWeekend = in_array($dayOfWeekName, $weeklyOffDays, true);
        $this->assertFalse($isCompanyWeekend, 'Company weekend is false on Friday for Sat+Sun company');

        // Neither employee punched -> both must be Absent, neither can be Weekly Off
        $buckets = [];
        foreach ($employees as $emp) {
            $isEmpWeekend = in_array($dayOfWeekName, $weeklyOffDays, true);
            $bucket = $isEmpWeekend ? 'weekly_off' : 'absent';
            $buckets[$emp['id']] = $bucket;
        }

        $this->assertSame('absent', $buckets['e1']);
        $this->assertSame('absent', $buckets['e2']);
        $this->assertNotContains('weekly_off', $buckets);
    }
}
