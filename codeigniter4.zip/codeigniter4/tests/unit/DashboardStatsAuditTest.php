<?php

namespace Tests\Unit;

use App\Controllers\Dashboard\DashboardController;
use App\Services\DashboardService;
use App\Services\DashboardWidgetDataProvider;
use App\Services\PermissionService;
use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;

/**
 * Audit & Security Test Suite for Dashboard Stats & Scope Data Isolation
 *
 * Verifies:
 * (a) Unauthenticated GET /api/dashboard/stats returns 401 or login redirect.
 * (b) Employee A in same dept as Employee B (who has approved + pending leaves) receives stats JSON
 *     with NO row containing Employee B's employee_id and NO 'reason' key anywhere in the payload.
 */
#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class DashboardStatsAuditTest extends CIUnitTestCase
{
    use FeatureTestTrait;

    protected $db;
    protected string $companyId = 'comp-audit-01';
    protected string $deptId    = 'dept-sales-01';
    protected string $branchId  = 'branch-main-01';
    protected string $empAId    = 'emp-a-01';
    protected string $empBId    = 'emp-b-02';
    protected string $userAId   = 'usr-a-01';
    protected string $userBId   = 'usr-b-02';

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->registerSqliteFunctions($this->db);
        $this->setupSchema();
        $this->seedTestData();

        PermissionService::clearCache();
        PermissionService::flushCache();
    }

    protected function tearDown(): void
    {
        parent::tearDown();
        PermissionService::clearCache();
        PermissionService::flushCache();
    }

    private function registerSqliteFunctions($db): void
    {
        try {
            $rawConn = $db->connID ?? null;
            if ($rawConn instanceof \SQLite3) {
                $rawConn->createFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->createFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            } elseif (is_object($rawConn) && method_exists($rawConn, 'sqliteCreateFunction')) {
                $rawConn->sqliteCreateFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->sqliteCreateFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            }
        } catch (\Throwable $e) {
            // Ignore if functions already registered
        }
    }

    private function setupSchema(): void
    {
        $tables = [
            'companies', 'departments', 'branches', 'designations', 'shifts',
            'roles', 'permissions', 'role_permissions', 'user_permissions', 'user_roles',
            'users', 'employees', 'leave_types', 'leave_applications', 'leave_balances',
            'attendance_logs', 'duty_assignments', 'holidays', 'notices',
            'dashboard_widgets', 'dashboard_widget_preferences', 'dashboard_role_widgets',
            'dashboard_company_widgets', 'dashboard_user_preferences', 'dashboard_widget_assignments',
            'system_settings', 'audit_logs'
        ];

        foreach ($tables as $t) {
            $this->db->query("DROP TABLE IF EXISTS {$t}");
        }

        $this->db->query("CREATE TABLE companies (
            id VARCHAR(36) PRIMARY KEY, name VARCHAR(100), code VARCHAR(30),
            timezone VARCHAR(50) DEFAULT 'UTC', status VARCHAR(20) DEFAULT 'active',
            subscription_plan VARCHAR(50) DEFAULT 'starter',
            created_at DATETIME NULL, updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE departments (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36) NULL, name VARCHAR(100),
            created_at DATETIME NULL, updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE branches (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36) NULL, name VARCHAR(100),
            created_at DATETIME NULL, updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE designations (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36) NULL, name VARCHAR(100),
            created_at DATETIME NULL, updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE shifts (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36) NULL, name VARCHAR(100),
            start_time TIME NULL, end_time TIME NULL, grace_time INT DEFAULT 15,
            weekly_off VARCHAR(50) NULL, work_days VARCHAR(100) NULL
        )");

        $this->db->query("CREATE TABLE roles (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36) NULL, code VARCHAR(50),
            name VARCHAR(100), status VARCHAR(20) DEFAULT 'active'
        )");

        $this->db->query("CREATE TABLE permissions (
            id VARCHAR(36) PRIMARY KEY, code VARCHAR(100) UNIQUE, module VARCHAR(50) NULL,
            action VARCHAR(50) NULL, name VARCHAR(100)
        )");

        $this->db->query("CREATE TABLE role_permissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT, role_id VARCHAR(36), permission_id VARCHAR(36),
            scope_level VARCHAR(30) DEFAULT 'company'
        )");

        $this->db->query("CREATE TABLE user_permissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id VARCHAR(36), permission_id VARCHAR(36),
            is_granted INT DEFAULT 1, expires_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE user_roles (
            id VARCHAR(36) PRIMARY KEY, user_id VARCHAR(36), role_id VARCHAR(36)
        )");

        $this->db->query("CREATE TABLE users (
            id VARCHAR(36) PRIMARY KEY, employee_id VARCHAR(36) NULL, username VARCHAR(100),
            email VARCHAR(150), password_hash VARCHAR(255) NULL, role_id VARCHAR(36) NULL,
            company_id VARCHAR(36) NULL, branch_id VARCHAR(36) NULL, department_id VARCHAR(36) NULL,
            status VARCHAR(20) DEFAULT 'active', last_login_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE employees (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36), employee_code VARCHAR(50),
            first_name VARCHAR(100), last_name VARCHAR(100) NULL, branch_id VARCHAR(36) NULL,
            department_id VARCHAR(36) NULL, designation_id VARCHAR(36) NULL, shift_id VARCHAR(36) NULL,
            email VARCHAR(150) NULL, phone VARCHAR(50) NULL, dob DATE NULL, joining_date DATE NULL,
            photo VARCHAR(255) NULL, status VARCHAR(30) DEFAULT 'Active', deleted_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE leave_types (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36) NULL, name VARCHAR(100),
            code VARCHAR(20), is_paid INT DEFAULT 1, status VARCHAR(20) DEFAULT 'active'
        )");

        $this->db->query("CREATE TABLE leave_applications (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36) NULL, employee_id VARCHAR(36),
            leave_type_id VARCHAR(36), from_date DATE, to_date DATE, total_days DECIMAL(5,2),
            reason TEXT NULL, status VARCHAR(20) DEFAULT 'Pending', created_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE leave_balances (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36) NULL, employee_id VARCHAR(36),
            leave_type_id VARCHAR(36), year INT, allocated_days DECIMAL(5,2) DEFAULT 0,
            used_days DECIMAL(5,2) DEFAULT 0, pending_days DECIMAL(5,2) DEFAULT 0,
            balance DECIMAL(5,2) DEFAULT 0
        )");

        $this->db->query("CREATE TABLE attendance_logs (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36), employee_id VARCHAR(36),
            date DATE, in_time TIME NULL, out_time TIME NULL, clock_in DATETIME NULL,
            clock_out DATETIME NULL, status VARCHAR(30) DEFAULT 'Present', created_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE duty_assignments (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36), employee_id VARCHAR(36),
            branch_id VARCHAR(36) NULL, duty_date DATE, duty_type VARCHAR(50) NULL,
            status VARCHAR(30) DEFAULT 'Approved', created_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE holidays (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36) NULL, name VARCHAR(100),
            from_date DATE, to_date DATE
        )");

        $this->db->query("CREATE TABLE notices (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36) NULL, title VARCHAR(150),
            status VARCHAR(20) DEFAULT 'Published', created_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE dashboard_widgets (
            id VARCHAR(36) PRIMARY KEY, code VARCHAR(100) UNIQUE, widget_code VARCHAR(100) NULL,
            title VARCHAR(100), name VARCHAR(100) NULL, description TEXT NULL,
            category VARCHAR(50) DEFAULT 'overview', view_path VARCHAR(255) DEFAULT 'dashboard/widgets/clock_card',
            icon VARCHAR(50) DEFAULT 'layout-grid', module_code VARCHAR(100) NULL, module VARCHAR(50) NULL,
            permission_code VARCHAR(100) NULL, permission_required VARCHAR(100) NULL,
            target_roles TEXT NULL, min_subscription_plan VARCHAR(50) DEFAULT 'starter',
            default_status INT DEFAULT 1, default_sort_order INT DEFAULT 0,
            grid_width VARCHAR(50) DEFAULT 'half', is_active INT DEFAULT 1,
            created_at DATETIME NULL, updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE dashboard_widget_preferences (
            id VARCHAR(36) PRIMARY KEY, user_id VARCHAR(36), widget_code VARCHAR(100),
            is_visible INT DEFAULT 1, sort_order INT DEFAULT 0
        )");

        $this->db->query("CREATE TABLE dashboard_role_widgets (
            id VARCHAR(36) PRIMARY KEY, role_code VARCHAR(50), widget_id VARCHAR(36), widget_code VARCHAR(100) NULL,
            status INT DEFAULT 1, is_visible INT DEFAULT 1, sort_order INT DEFAULT 0,
            grid_width VARCHAR(50) NULL, created_at DATETIME NULL, updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE dashboard_company_widgets (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36), widget_id VARCHAR(36),
            role_code VARCHAR(50) DEFAULT 'all', status INT DEFAULT 1, sort_order INT DEFAULT 0,
            grid_width VARCHAR(50) NULL, created_at DATETIME NULL, updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE dashboard_user_preferences (
            id VARCHAR(36) PRIMARY KEY, user_id VARCHAR(36), widget_id VARCHAR(36),
            status INT DEFAULT 1, sort_order INT DEFAULT 0, grid_width VARCHAR(50) NULL,
            settings TEXT NULL, created_at DATETIME NULL, updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE dashboard_widget_assignments (
            id VARCHAR(36) PRIMARY KEY, scope_type VARCHAR(50), scope_id VARCHAR(36),
            widget_id VARCHAR(36), status INT DEFAULT 1, is_visible INT DEFAULT 1,
            sort_order INT DEFAULT 0, position INT DEFAULT 0, grid_width VARCHAR(50) DEFAULT 'half',
            grid_height VARCHAR(50) DEFAULT 'auto', settings TEXT NULL,
            created_at DATETIME NULL, updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE system_settings (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36) NULL, key_name VARCHAR(100),
            value_text TEXT, created_at DATETIME NULL, updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE audit_logs (
            id VARCHAR(36) PRIMARY KEY, user_id VARCHAR(36) NULL, company_id VARCHAR(36) NULL,
            module VARCHAR(50), action VARCHAR(50), record_id VARCHAR(36) NULL,
            old_values TEXT NULL, new_values TEXT NULL, ip_address VARCHAR(45) NULL,
            user_agent VARCHAR(500) NULL, notes TEXT NULL, created_at DATETIME NULL
        )");
    }

    private function seedTestData(): void
    {
        $today = date('Y-m-d');
        $tomorrow = date('Y-m-d', strtotime('+1 day'));

        // Company, Branch, Department
        $this->db->table('companies')->insert([
            'id' => $this->companyId, 'name' => 'Audit Tech Ltd', 'code' => 'AUDIT', 'status' => 'active'
        ]);
        $this->db->table('branches')->insert([
            'id' => $this->branchId, 'company_id' => $this->companyId, 'name' => 'Main HQ'
        ]);
        $this->db->table('departments')->insert([
            'id' => $this->deptId, 'company_id' => $this->companyId, 'name' => 'Sales & Growth'
        ]);

        // Roles
        $this->db->table('roles')->insert([
            'id' => 'role-employee', 'company_id' => $this->companyId, 'code' => 'employee', 'name' => 'Employee'
        ]);

        // Employees: Employee A and Employee B in the same department
        $this->db->table('employees')->insert([
            'id'            => $this->empAId,
            'company_id'    => $this->companyId,
            'employee_code' => 'EMP-001',
            'first_name'    => 'Alice',
            'last_name'     => 'Smith',
            'branch_id'     => $this->branchId,
            'department_id' => $this->deptId,
            'email'         => 'alice@audit.test',
            'status'        => 'Active',
        ]);

        $this->db->table('employees')->insert([
            'id'            => $this->empBId,
            'company_id'    => $this->companyId,
            'employee_code' => 'EMP-002',
            'first_name'    => 'Bob',
            'last_name'     => 'Jones',
            'branch_id'     => $this->branchId,
            'department_id' => $this->deptId,
            'email'         => 'bob@audit.test',
            'status'        => 'Active',
        ]);

        // Users
        $this->db->table('users')->insert([
            'id'            => $this->userAId,
            'employee_id'   => $this->empAId,
            'username'      => 'alicesmith',
            'email'         => 'alice@audit.test',
            'company_id'    => $this->companyId,
            'branch_id'     => $this->branchId,
            'department_id' => $this->deptId,
            'role_id'       => 'role-employee',
            'status'        => 'active',
        ]);

        $this->db->table('users')->insert([
            'id'            => $this->userBId,
            'employee_id'   => $this->empBId,
            'username'      => 'bobjones',
            'email'         => 'bob@audit.test',
            'company_id'    => $this->companyId,
            'branch_id'     => $this->branchId,
            'department_id' => $this->deptId,
            'role_id'       => 'role-employee',
            'status'        => 'active',
        ]);

        // Leave Types
        $this->db->table('leave_types')->insert([
            'id'         => 'lt-annual',
            'company_id' => $this->companyId,
            'name'       => 'Annual Leave',
            'code'       => 'AL',
            'is_paid'    => 1,
            'status'     => 'active',
        ]);

        // Employee B Leaves (Approved + Pending) containing private reasons
        $this->db->table('leave_applications')->insert([
            'id'            => 'leave-b-app-01',
            'company_id'    => $this->companyId,
            'employee_id'   => $this->empBId,
            'leave_type_id' => 'lt-annual',
            'from_date'     => $today,
            'to_date'       => $tomorrow,
            'total_days'    => 2.0,
            'reason'        => 'CONFIDENTIAL_MEDICAL_BOB_9921',
            'status'        => 'Approved',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);

        $this->db->table('leave_applications')->insert([
            'id'            => 'leave-b-pend-02',
            'company_id'    => $this->companyId,
            'employee_id'   => $this->empBId,
            'leave_type_id' => 'lt-annual',
            'from_date'     => $tomorrow,
            'to_date'       => $tomorrow,
            'total_days'    => 1.0,
            'reason'        => 'STRICTLY_PRIVATE_LEGAL_ISSUE_BOB_4410',
            'status'        => 'Pending',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);

        // Duty assignment for Employee B
        $this->db->table('duty_assignments')->insert([
            'id'          => 'duty-b-01',
            'company_id'  => $this->companyId,
            'employee_id' => $this->empBId,
            'branch_id'   => $this->branchId,
            'duty_date'   => $today,
            'duty_type'   => 'Client Site Visit',
            'status'      => 'Approved',
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        // Attendance punch for Employee B
        $this->db->table('attendance_logs')->insert([
            'id'          => 'att-b-01',
            'company_id'  => $this->companyId,
            'employee_id' => $this->empBId,
            'date'        => $today,
            'in_time'     => '08:45:00',
            'out_time'    => null,
            'clock_in'    => $today . ' 08:45:00',
            'status'      => 'Present',
            'created_at'  => $today . ' 08:45:00',
        ]);
    }

    /**
     * Requirement (a):
     * Unauthenticated GET /api/dashboard/stats -> assert real response (401 or login redirect)
     */
    public function testUnauthenticatedGetStatsReturns401OrLoginRedirect(): void
    {
        // 1. Unauthenticated standard browser call -> assert login redirect or 401
        $response = $this->call('get', 'api/dashboard/stats');
        $statusCode = $response->response()->getStatusCode();

        $isRedirectOr401 = in_array($statusCode, [302, 303, 307, 401], true);
        $this->assertTrue(
            $isRedirectOr401,
            "Unauthenticated GET /api/dashboard/stats must return either 401 or redirect to login. Got status: {$statusCode}"
        );

        if ($statusCode === 302 || $statusCode === 303 || $statusCode === 307) {
            $redirectUrl = $response->response()->getHeaderLine('Location');
            $this->assertStringContainsString('login', $redirectUrl, "Redirect location must direct to login page.");
        }

        // 2. Unauthenticated AJAX call -> assert status 401 JSON
        $ajaxResponse = $this->withHeaders(['X-Requested-With' => 'XMLHttpRequest'])
                             ->call('get', 'api/dashboard/stats');
        $ajaxStatusCode = $ajaxResponse->response()->getStatusCode();

        $this->assertEquals(
            401,
            $ajaxStatusCode,
            "Unauthenticated AJAX GET /api/dashboard/stats MUST return 401 Unauthorized."
        );
    }

    /**
     * Requirement (b):
     * Employee A (same dept as Employee B with approved + pending leave):
     * stats JSON has no row with B's employee_id and no 'reason' key anywhere.
     */
    public function testEmployeeStatsHasNoRowWithOtherEmployeeIdAndNoReasonKey(): void
    {
        // Setup session for Employee A
        $sessionData = [
            'id'                  => $this->userAId,
            'user_id'             => $this->userAId,
            'username'            => 'alicesmith',
            'name'                => 'Alice Smith',
            'email'               => 'alice@audit.test',
            'role'                => 'employee',
            'role_code'           => 'employee',
            'role_id'             => 'role-employee',
            'company_id'          => $this->companyId,
            'branch_id'           => $this->branchId,
            'department_id'       => $this->deptId,
            'employee_id'         => $this->empAId,
            'selected_company_id' => $this->companyId,
            'permissions'         => [
                'dashboard.view', 'attendance.view', 'attendance.clock',
                'leave.view', 'leave.create', 'profile.view'
            ],
        ];

        $response = $this->withSession($sessionData)
                         ->withHeaders(['X-Requested-With' => 'XMLHttpRequest'])
                         ->call('get', 'api/dashboard/stats');

        $response->assertStatus(200);

        $rawBody = $response->getJSON();
        $this->assertNotEmpty($rawBody, "Dashboard stats must return valid JSON body.");

        $data = json_decode($rawBody, true);
        $this->assertIsArray($data, "Parsed JSON must be an array.");
        $this->assertTrue($data['success'] ?? false, "API response 'success' must be true.");

        // 1. Assert Employee B's ID is NEVER present anywhere in the entire response JSON string
        $this->assertStringNotContainsString(
            $this->empBId,
            $rawBody,
            "CRITICAL DATA LEAK: Employee B's employee_id ('{$this->empBId}') was found in Employee A's stats JSON."
        );

        // 2. Assert Employee B's sensitive reasons are NEVER present anywhere in the JSON
        $this->assertStringNotContainsString(
            'CONFIDENTIAL_MEDICAL_BOB_9921',
            $rawBody,
            "CRITICAL PRIVACY LEAK: Employee B's medical reason was leaked into Employee A's dashboard stats."
        );
        $this->assertStringNotContainsString(
            'STRICTLY_PRIVATE_LEGAL_ISSUE_BOB_4410',
            $rawBody,
            "CRITICAL PRIVACY LEAK: Employee B's private pending leave reason was leaked into Employee A's dashboard stats."
        );

        // 3. Assert NO 'reason' key exists anywhere in the JSON response
        $this->assertNoKeyRecursively('reason', $data);

        // 4. Also assert the string '"reason":' does not exist in the raw serialized payload
        $this->assertFalse(
            (bool)preg_match('/"reason"\s*:/i', $rawBody),
            "CRITICAL PRIVACY LEAK: 'reason' key found in JSON response string."
        );
    }

    /**
     * Requirement: Step 9b gating in DashboardWidgetDataProvider
     * When only ESS widgets are active, heavy management providers (step 9b) are gated off.
     */
    public function testProviderGatesStep9bForEssWidgets(): void
    {
        $dashboardService = new DashboardService();
        $dataProvider = new DashboardWidgetDataProvider();

        $scope = [
            'type'          => 'self',
            'employee_id'   => $this->empAId,
            'department_id' => $this->deptId,
            'branch_id'     => $this->branchId,
            'company_id'    => $this->companyId,
        ];

        // Resolve authorized active widgets for employee role
        $metrics = $dashboardService->buildDashboardMetrics('employee', $this->companyId, $this->userAId, $scope);
        $this->assertIsArray($metrics);

        $rawJson = json_encode($metrics);

        // Employee B must not appear in metrics
        $this->assertStringNotContainsString($this->empBId, $rawJson);

        // 'reason' key must not appear anywhere in metrics
        $this->assertFalse(
            (bool)preg_match('/"reason"\s*:/i', $rawJson),
            "Metrics for employee role must not contain 'reason' key."
        );

        // Leave overview for self must not leak B
        $leaveOverview = $dataProvider->provideLeaveOverview(date('Y-m-d'), $scope, $this->companyId, true, false);
        foreach ($leaveOverview['today'] as $r) {
            $this->assertEquals($this->empAId, $r['employee_id'] ?? null);
            $this->assertArrayNotHasKey('reason', $r);
        }

        // Pending approvals for self must not leak B
        $pendingApprovals = $dataProvider->providePendingApprovals($scope, $this->companyId, true, false);
        foreach ($pendingApprovals['leaves'] as $r) {
            $this->assertEquals($this->empAId, $r['employee_id'] ?? null);
            $this->assertArrayNotHasKey('reason', $r);
        }

        // Duty & break overview for self must not leak B
        $dutyBreak = $dataProvider->provideDutyAndBreakOverview(date('Y-m-d'), $scope, $this->companyId, [], []);
        foreach ($dutyBreak['on_duty'] as $d) {
            $this->assertEquals($this->empAId, $d['employee_id'] ?? null);
        }
        foreach ($dutyBreak['on_break'] as $b) {
            $this->assertEquals($this->empAId, $b['employee_id'] ?? null);
        }
    }

    /**
     * Requirement: Manager with null department_id and branch_id resolves to type 'self'.
     */
    public function testResolveUserScopeManagerWithNullDeptAndBranchResolvesToSelf(): void
    {
        $dashboardService = new DashboardService();
        $managerEmp = [
            'id'            => 'emp-mgr-unassigned',
            'company_id'    => $this->companyId,
            'department_id' => null,
            'branch_id'     => null,
            'first_name'    => 'Unassigned',
            'last_name'     => 'Manager',
        ];

        // 1. Manager with null department and null branch must resolve to 'self' (never 'company')
        $resolved = $dashboardService->resolveUserScope(null, $this->companyId, 'manager', [], $managerEmp);
        $this->assertEquals('self', $resolved['type'], "Manager with null dept and null branch MUST resolve to type 'self'.");

        // 2. Team leader with null department and null branch must resolve to 'self'
        $resolvedTl = $dashboardService->resolveUserScope(null, $this->companyId, 'team_leader', [], $managerEmp);
        $this->assertEquals('self', $resolvedTl['type'], "Team leader with null dept and null branch MUST resolve to type 'self'.");

        // 3. Manager passing $scopeOverride['type'] = 'company' MUST NOT elevate scope (tamper proof)
        $tampered = $dashboardService->resolveUserScope(null, $this->companyId, 'manager', ['type' => 'company'], $managerEmp);
        $this->assertEquals('self', $tampered['type'], "Tampered \$scopeOverride['type'] MUST be ignored and remain 'self'.");
    }

    /**
     * Requirement: Unknown role must resolve to 'self', never the company-wide else-branch.
     */
    public function testResolveUserScopeUnknownRoleResolvesToSelf(): void
    {
        $dashboardService = new DashboardService();
        $emp = [
            'id'            => 'emp-custom-01',
            'company_id'    => $this->companyId,
            'department_id' => $this->deptId,
            'branch_id'     => $this->branchId,
            'first_name'    => 'Custom',
            'last_name'     => 'RoleUser',
        ];

        // Any role not explicitly handled must resolve to 'self'
        $unknownRoles = ['intern', 'custom_operator', 'guest', 'non_existent_role_xyz'];
        foreach ($unknownRoles as $role) {
            $resolved = $dashboardService->resolveUserScope(null, $this->companyId, $role, [], $emp);
            $this->assertEquals('self', $resolved['type'], "Unknown role '{$role}' MUST resolve to type 'self', never company-wide.");

            // Tamper test with $scopeOverride['type']
            $tampered = $dashboardService->resolveUserScope(null, $this->companyId, $role, ['type' => 'company'], $emp);
            $this->assertEquals('self', $tampered['type'], "Unknown role with tampered \$scopeOverride['type'] MUST remain 'self'.");
        }
    }

    /**
     * Requirement: company_admin and hr_admin still resolve to 'company'.
     */
    public function testResolveUserScopeCompanyAdminAndHrAdminResolveToCompany(): void
    {
        $dashboardService = new DashboardService();

        // 1. company_admin resolves to 'company'
        $resolvedAdmin = $dashboardService->resolveUserScope(null, $this->companyId, 'company_admin', []);
        $this->assertEquals('company', $resolvedAdmin['type'], "Role 'company_admin' MUST resolve to type 'company'.");

        // 2. hr_admin resolves to 'company'
        $resolvedHr = $dashboardService->resolveUserScope(null, $this->companyId, 'hr_admin', []);
        $this->assertEquals('company', $resolvedHr['type'], "Role 'hr_admin' MUST resolve to type 'company'.");

        // 3. hr_officer, finance, auditor also resolve to 'company'
        foreach (['hr_officer', 'finance', 'auditor'] as $r) {
            $res = $dashboardService->resolveUserScope(null, $this->companyId, $r, []);
            $this->assertEquals('company', $res['type'], "Administrative role '{$r}' MUST resolve to type 'company'.");
        }
    }

    /**
     * Requirement: branch_manager resolves to 'branch' if branch is set, or 'self' if null.
     */
    public function testResolveUserScopeBranchManager(): void
    {
        $dashboardService = new DashboardService();

        $bmWithBranch = [
            'id'            => 'emp-bm-01',
            'company_id'    => $this->companyId,
            'department_id' => $this->deptId,
            'branch_id'     => $this->branchId,
            'first_name'    => 'Branch',
            'last_name'     => 'Manager',
        ];
        $resolvedBm = $dashboardService->resolveUserScope(null, $this->companyId, 'branch_manager', [], $bmWithBranch);
        $this->assertEquals('branch', $resolvedBm['type'], "Role 'branch_manager' with assigned branch MUST resolve to type 'branch'.");

        $bmNoBranch = [
            'id'            => 'emp-bm-unassigned',
            'company_id'    => $this->companyId,
            'department_id' => null,
            'branch_id'     => null,
            'first_name'    => 'Unassigned',
            'last_name'     => 'BranchManager',
        ];
        $resolvedBmNoBranch = $dashboardService->resolveUserScope(null, $this->companyId, 'branch_manager', [], $bmNoBranch);
        $this->assertEquals('self', $resolvedBmNoBranch['type'], "Role 'branch_manager' with null branch MUST resolve to type 'self'.");
    }

    /**
     * Requirement: company_admin disables widget X at company scope ->
     * X absent from the dashboard payload for hr_admin and for a manager of that company,
     * and a user toggle ON for X returns 403. A user hiding widget Y still works.
     */
    public function testCompanyAdminDisablesWidgetAtCompanyScopeOmittedAndToggleReturns403(): void
    {
        $dashboardService = new DashboardService();

        // 1. Seed widgets X and Y in the database
        $widgetX = [
            'id'                    => 'w-x-payroll-01',
            'code'                  => 'widget_x_cost',
            'title'                 => 'Widget X Cost Summary',
            'category'              => 'payroll',
            'view_path'             => 'dashboard/widgets/clock_card',
            'default_status'        => 1,
            'default_sort_order'    => 1,
            'grid_width'            => 'half',
            'min_subscription_plan' => 'starter',
            'target_roles'          => json_encode(['*']),
            'created_at'            => date('Y-m-d H:i:s'),
        ];
        $widgetY = [
            'id'                    => 'w-y-tasks-02',
            'code'                  => 'widget_y_tasks',
            'title'                 => 'Widget Y Tasks',
            'category'              => 'general',
            'view_path'             => 'dashboard/widgets/clock_card',
            'default_status'        => 1,
            'default_sort_order'    => 2,
            'grid_width'            => 'half',
            'min_subscription_plan' => 'starter',
            'target_roles'          => json_encode(['*']),
            'created_at'            => date('Y-m-d H:i:s'),
        ];
        $this->db->table('dashboard_widgets')->insert($widgetX);
        $this->db->table('dashboard_widgets')->insert($widgetY);

        // Seed role mappings with status = 1 for hr_admin and manager
        $this->db->table('dashboard_role_widgets')->insert([
            'id'         => 'drw-hr-wx',
            'role_code'  => 'hr_admin',
            'widget_id'  => 'w-x-payroll-01',
            'status'     => 1,
            'sort_order' => 1,
        ]);
        $this->db->table('dashboard_role_widgets')->insert([
            'id'         => 'drw-hr-wy',
            'role_code'  => 'hr_admin',
            'widget_id'  => 'w-y-tasks-02',
            'status'     => 1,
            'sort_order' => 2,
        ]);
        $this->db->table('dashboard_role_widgets')->insert([
            'id'         => 'drw-mgr-wx',
            'role_code'  => 'manager',
            'widget_id'  => 'w-x-payroll-01',
            'status'     => 1,
            'sort_order' => 1,
        ]);
        $this->db->table('dashboard_role_widgets')->insert([
            'id'         => 'drw-mgr-wy',
            'role_code'  => 'manager',
            'widget_id'  => 'w-y-tasks-02',
            'status'     => 1,
            'sort_order' => 2,
        ]);

        // Unified assignments for role
        $this->db->table('dashboard_widget_assignments')->insert([
            'id'          => 'dwa-test-hr-wx',
            'scope_type'  => 'role',
            'scope_id'    => 'hr_admin',
            'widget_id'   => 'w-x-payroll-01',
            'status'      => 1,
            'is_visible'  => 1,
            'sort_order'  => 1,
            'position'    => 1,
            'grid_width'  => 'half',
            'grid_height' => 'auto',
        ]);
        $this->db->table('dashboard_widget_assignments')->insert([
            'id'          => 'dwa-test-hr-wy',
            'scope_type'  => 'role',
            'scope_id'    => 'hr_admin',
            'widget_id'   => 'w-y-tasks-02',
            'status'      => 1,
            'is_visible'  => 1,
            'sort_order'  => 2,
            'position'    => 2,
            'grid_width'  => 'half',
            'grid_height' => 'auto',
        ]);
        $this->db->table('dashboard_widget_assignments')->insert([
            'id'          => 'dwa-test-mgr-wx',
            'scope_type'  => 'role',
            'scope_id'    => 'manager',
            'widget_id'   => 'w-x-payroll-01',
            'status'      => 1,
            'is_visible'  => 1,
            'sort_order'  => 1,
            'position'    => 1,
            'grid_width'  => 'half',
            'grid_height' => 'auto',
        ]);
        $this->db->table('dashboard_widget_assignments')->insert([
            'id'          => 'dwa-test-mgr-wy',
            'scope_type'  => 'role',
            'scope_id'    => 'manager',
            'widget_id'   => 'w-y-tasks-02',
            'status'      => 1,
            'is_visible'  => 1,
            'sort_order'  => 2,
            'position'    => 2,
            'grid_width'  => 'half',
            'grid_height' => 'auto',
        ]);

        // 2. company_admin disables widget X at company scope
        $toggleCompanyResult = $dashboardService->toggleWidgetStatus('w-x-payroll-01', 'company', $this->companyId, 0, 'admin-user-01');
        $this->assertTrue($toggleCompanyResult['success']);

        // 3. hr_admin dashboard payload: widget X must be ABSENT from active_widgets, authorized_widgets, and customizable widgets
        $hrDashboard = $dashboardService->getDashboardForUser($this->userAId, $this->companyId, 'hr_admin');
        $this->assertIsArray($hrDashboard);

        $hrActiveIds = array_column($hrDashboard['active_widgets'] ?? [], 'id');
        $hrAuthorizedIds = array_column($hrDashboard['authorized_widgets'] ?? [], 'id');
        $hrCustomizableWidgets = $dashboardService->getCustomizableWidgetsForUser($this->userAId, $this->companyId, 'hr_admin');
        $hrCustomizableIds = array_column($hrCustomizableWidgets, 'id');

        $this->assertNotContains('w-x-payroll-01', $hrActiveIds, "Widget X must be absent from hr_admin active_widgets.");
        $this->assertNotContains('w-x-payroll-01', $hrAuthorizedIds, "Widget X must be absent from hr_admin authorized_widgets.");
        $this->assertNotContains('w-x-payroll-01', $hrCustomizableIds, "Widget X must be absent from hr_admin customizable widgets.");

        // Widget Y must be present for hr_admin
        $this->assertContains('w-y-tasks-02', $hrActiveIds, "Widget Y must be present for hr_admin.");

        // 4. manager of that company: widget X must be ABSENT from dashboard payload
        $mgrEmp = [
            'id'            => 'emp-mgr-01',
            'company_id'    => $this->companyId,
            'department_id' => $this->deptId,
            'branch_id'     => $this->branchId,
            'first_name'    => 'Dept',
            'last_name'     => 'Manager',
        ];
        $scopeOverride = ['type' => 'department', 'department_id' => $this->deptId];
        $mgrDashboard = $dashboardService->getDashboardForUser('usr-mgr-01', $this->companyId, 'manager', $scopeOverride);

        $mgrActiveIds = array_column($mgrDashboard['active_widgets'] ?? [], 'id');
        $mgrAuthorizedIds = array_column($mgrDashboard['authorized_widgets'] ?? [], 'id');
        $mgrCustomizableWidgets = $dashboardService->getCustomizableWidgetsForUser('usr-mgr-01', $this->companyId, 'manager', $scopeOverride);
        $mgrCustomizableIds = array_column($mgrCustomizableWidgets, 'id');

        $this->assertNotContains('w-x-payroll-01', $mgrActiveIds, "Widget X must be absent from manager active_widgets.");
        $this->assertNotContains('w-x-payroll-01', $mgrAuthorizedIds, "Widget X must be absent from manager authorized_widgets.");
        $this->assertNotContains('w-x-payroll-01', $mgrCustomizableIds, "Widget X must be absent from manager customizable widgets.");

        // 5. User toggle ON for X returns 403
        $toggleOnX = $dashboardService->toggleUserWidget($this->userAId, 'w-x-payroll-01', 1, 'hr_admin', $this->companyId);
        $this->assertFalse($toggleOnX['success'], "User toggle ON for admin-disabled widget X must fail.");
        $this->assertEquals(403, $toggleOnX['code'] ?? null, "User toggle ON for admin-disabled widget X must return 403.");

        // Reorder with X returns 403
        $reorderWithX = $dashboardService->reorderUserWidgets($this->userAId, ['w-x-payroll-01', 'w-y-tasks-02'], 'hr_admin', $this->companyId);
        $this->assertFalse($reorderWithX['success'], "Reordering with admin-disabled widget X must fail.");
        $this->assertEquals(403, $reorderWithX['code'] ?? null, "Reordering with admin-disabled widget X must return 403.");

        // Save preferences enabling X returns 403
        $savePrefWithX = $dashboardService->saveUserPreferences($this->userAId, [['id' => 'w-x-payroll-01', 'status' => 1]], 'hr_admin', $this->companyId);
        $this->assertFalse($savePrefWithX['success'], "Saving preferences enabling admin-disabled widget X must fail.");
        $this->assertEquals(403, $savePrefWithX['code'] ?? null, "Saving preferences enabling admin-disabled widget X must return 403.");

        // 6. A user hiding widget Y still works
        $hideY = $dashboardService->toggleUserWidget($this->userAId, 'w-y-tasks-02', 0, 'hr_admin', $this->companyId);
        $this->assertTrue($hideY['success'], "User hiding widget Y must succeed.");

        // In dashboard payload after hiding Y:
        // Y must be absent from active_widgets (the grid), but present in customizable widgets with status 0
        $dashboardAfterHide = $dashboardService->getDashboardForUser($this->userAId, $this->companyId, 'hr_admin');
        $afterActiveIds = array_column($dashboardAfterHide['active_widgets'] ?? [], 'id');
        $this->assertNotContains('w-y-tasks-02', $afterActiveIds, "Hidden widget Y must not appear in active_widgets.");

        $customizableAfterHide = $dashboardService->getCustomizableWidgetsForUser($this->userAId, $this->companyId, 'hr_admin');
        $foundYInCustomizable = false;
        foreach ($customizableAfterHide as $cw) {
            if (($cw['id'] ?? '') === 'w-y-tasks-02') {
                $foundYInCustomizable = true;
                $this->assertEquals(0, $cw['status'], "Hidden widget Y must have status = 0 in customizable widgets.");
            }
        }
        $this->assertTrue($foundYInCustomizable, "Hidden widget Y must remain in customizable widgets so user can re-enable it.");

        // User toggling widget Y back ON works
        $showY = $dashboardService->toggleUserWidget($this->userAId, 'w-y-tasks-02', 1, 'hr_admin', $this->companyId);
        $this->assertTrue($showY['success'], "User toggling widget Y back ON must succeed.");
    }

    /**
     * Verify company subscription plan tier enforcement:
     * - company on 'enterprise', widget with min_subscription_plan 'professional' -> user enabling it gets 200 (success => true)
     * - company on 'starter' -> 403 (success => false, code => 403)
     * Also checks reorderUserWidgets and saveUserPreferences.
     */
    public function testCompanySubscriptionPlanTierEnforcementOnToggleUserWidget(): void
    {
        $dashboardService = new DashboardService();

        // 1. Setup Enterprise Company and Starter Company
        $entCompanyId = 'comp-enterprise-audit';
        $starterCompanyId = 'comp-starter-audit';

        $this->db->table('companies')->insert([
            'id'                => $entCompanyId,
            'name'              => 'Enterprise Corp',
            'code'              => 'ENT-CORP',
            'status'            => 'active',
            'subscription_plan' => 'enterprise',
        ]);
        $this->db->table('companies')->insert([
            'id'                => $starterCompanyId,
            'name'              => 'Starter Corp',
            'code'              => 'START-CORP',
            'status'            => 'active',
            'subscription_plan' => 'starter',
        ]);

        // 2. Setup Users for each company
        $entUserId = 'usr-ent-audit-01';
        $starterUserId = 'usr-starter-audit-02';

        $this->db->table('users')->insert([
            'id'         => $entUserId,
            'company_id' => $entCompanyId,
            'username'   => 'ent_user',
            'role'       => 'hr_admin',
            'status'     => 'active',
        ]);
        $this->db->table('users')->insert([
            'id'         => $starterUserId,
            'company_id' => $starterCompanyId,
            'username'   => 'starter_user',
            'role'       => 'hr_admin',
            'status'     => 'active',
        ]);

        // 3. Setup a widget requiring 'professional' plan
        $widgetId = 'w-prof-analytics-01';
        $widgetCode = 'prof_payroll_analytics';
        $this->db->table('dashboard_widgets')->insert([
            'id'                    => $widgetId,
            'code'                  => $widgetCode,
            'title'                 => 'Professional Payroll Analytics',
            'category'              => 'payroll',
            'view_path'             => 'dashboard/widgets/payroll_cost_summary',
            'icon'                  => 'chart-bar',
            'module_code'           => null,
            'permission_code'       => null,
            'target_roles'          => json_encode(['*']),
            'min_subscription_plan' => 'professional',
            'default_status'        => 1,
            'default_sort_order'    => 1,
            'grid_width'            => 'half',
            'is_active'             => 1,
        ]);

        // Scenario A: Company on 'enterprise', widget requiring 'professional'
        // User enabling it gets 200 (success => true)
        $entResult = $dashboardService->toggleUserWidget($entUserId, $widgetId, 1, 'hr_admin', $entCompanyId);
        $this->assertTrue($entResult['success'], "Enterprise plan must allow enabling 'professional' tier widget.");
        $this->assertArrayNotHasKey('code', $entResult, "Success response must not have error code 403.");

        // Scenario B: Company on 'starter', widget requiring 'professional'
        // User enabling it gets 403
        $starterResult = $dashboardService->toggleUserWidget($starterUserId, $widgetId, 1, 'hr_admin', $starterCompanyId);
        $this->assertFalse($starterResult['success'], "Starter plan must NOT allow enabling 'professional' tier widget.");
        $this->assertEquals(403, $starterResult['code'] ?? null, "Starter plan must return 403 when enabling 'professional' tier widget.");
        $this->assertStringContainsString("Requires subscription plan tier 'professional'", $starterResult['message'] ?? '');

        // Reorder test:
        $entReorder = $dashboardService->reorderUserWidgets($entUserId, [$widgetId], 'hr_admin', $entCompanyId);
        $this->assertTrue($entReorder['success'], "Enterprise plan must allow reordering 'professional' tier widget.");

        $starterReorder = $dashboardService->reorderUserWidgets($starterUserId, [$widgetId], 'hr_admin', $starterCompanyId);
        $this->assertFalse($starterReorder['success'], "Starter plan must return 403 when reordering 'professional' tier widget.");
        $this->assertEquals(403, $starterReorder['code'] ?? null);

        // Save preferences test:
        $entSave = $dashboardService->saveUserPreferences($entUserId, [['id' => $widgetId, 'status' => 1]], 'hr_admin', $entCompanyId);
        $this->assertTrue($entSave['success'], "Enterprise plan must allow saving preferences for 'professional' tier widget.");

        $starterSave = $dashboardService->saveUserPreferences($starterUserId, [['id' => $widgetId, 'status' => 1]], 'hr_admin', $starterCompanyId);
        $this->assertFalse($starterSave['success'], "Starter plan must return 403 when saving preferences for 'professional' tier widget.");
        $this->assertEquals(403, $starterSave['code'] ?? null);

        // Internal resolution test: call isWidgetAuthorizedForUser without passing $scopeType and $subscriptionPlan
        $widgetRow = (new \App\Models\DashboardWidgetModel())->find($widgetId);
        $authEnt = $dashboardService->isWidgetAuthorizedForUser($widgetRow, 'hr_admin', $entCompanyId, $entUserId);
        $this->assertTrue($authEnt['authorized'], "isWidgetAuthorizedForUser without plan param must resolve enterprise from company.");

        $authStarter = $dashboardService->isWidgetAuthorizedForUser($widgetRow, 'hr_admin', $starterCompanyId, $starterUserId);
        $this->assertFalse($authStarter['authorized'], "isWidgetAuthorizedForUser without plan param must resolve starter from company.");
        $this->assertStringContainsString("Requires subscription plan tier 'professional'", $authStarter['reason'] ?? '');
    }

    /**
     * Recursively verifies that a key name does not exist anywhere in an associative array.
     */
    private function assertNoKeyRecursively(string $forbiddenKey, array $data, string $path = ''): void
    {
        foreach ($data as $key => $val) {
            $currentPath = $path === '' ? (string)$key : "{$path}.{$key}";
            $this->assertNotEquals(
                $forbiddenKey,
                (string)$key,
                "Forbidden key '{$forbiddenKey}' was found in stats response at path '{$currentPath}'"
            );
            if (is_array($val)) {
                $this->assertNoKeyRecursively($forbiddenKey, $val, $currentPath);
            }
        }
    }
}

