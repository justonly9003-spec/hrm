<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\SmtpConfigResolver;
use App\Database\Migrations\AddUniqueIndexToSystemSettingsCompanyKey;

class SmtpCompanyScopingTest extends TestCase
{
    /**
     * Verify all required SMTP config keys and defaults exist
     */
    public function testSmtpDefaultsContract(): void
    {
        $expectedKeys = [
            'smtp_host',
            'smtp_port',
            'smtp_user',
            'smtp_pass',
            'smtp_crypto',
            'from_email',
            'from_name',
            'reply_to_email',
            'smtp_is_active',
            'smtp_timeout',
        ];

        foreach ($expectedKeys as $key) {
            $this->assertContains($key, SmtpConfigResolver::SMTP_KEYS, "Key {$key} must be in SMTP_KEYS");
            $this->assertArrayHasKey($key, SmtpConfigResolver::DEFAULTS, "Key {$key} must have a default in DEFAULTS");
        }
    }

    /**
     * Verify password encryption and decryption cycle
     */
    public function testPasswordEncryptionAndDecryption(): void
    {
        $plainPass = 'P@ssw0rdEnterprise2026!';
        $encrypted = SmtpConfigResolver::encryptPassword($plainPass);

        $this->assertNotEmpty($encrypted);
        $this->assertTrue(
            str_starts_with($encrypted, 'enc:') || str_starts_with($encrypted, 'enc_b64:'),
            'Encrypted string must have an enc prefix'
        );
        $this->assertNotEquals($plainPass, $encrypted, 'Ciphertext must not match plaintext');

        $decrypted = SmtpConfigResolver::decryptPassword($encrypted);
        $this->assertEquals($plainPass, $decrypted, 'Decrypted password must match original plaintext');
    }

    /**
     * Verify masked placeholder preservation
     */
    public function testMaskedPasswordHandling(): void
    {
        $this->assertSame('', SmtpConfigResolver::encryptPassword('••••••••'));
        $this->assertSame('', SmtpConfigResolver::encryptPassword('********'));
        $this->assertSame('', SmtpConfigResolver::encryptPassword(''));

        $this->assertSame('', SmtpConfigResolver::decryptPassword('••••••••'));
        $this->assertSame('', SmtpConfigResolver::decryptPassword(''));
    }

    /**
     * Verify plain text fallback if unencrypted password was stored
     */
    public function testPlaintextFallbackDecryption(): void
    {
        $legacyPlain = 'legacy_plain_smtp_secret';
        $decrypted = SmtpConfigResolver::decryptPassword($legacyPlain);
        $this->assertEquals($legacyPlain, $decrypted, 'Unencrypted legacy password should be returned as-is');
    }

    /**
     * Verify unique index migration defines up and down properly
     */
    public function testMigrationMethodsExist(): void
    {
        $migration = new AddUniqueIndexToSystemSettingsCompanyKey();
        $this->assertTrue(method_exists($migration, 'up'), 'Migration must implement up()');
        $this->assertTrue(method_exists($migration, 'down'), 'Migration must implement down()');
    }

    /**
     * Verify SmtpController has testConnection and socket response parsing methods
     */
    public function testSmtpControllerHasDiagnosticMethods(): void
    {
        $controller = new \App\Controllers\System\SmtpController();
        $this->assertTrue(method_exists($controller, 'testConnection'), 'Controller must have testConnection()');
        $this->assertTrue(method_exists($controller, 'save'), 'Controller must have save()');
        $this->assertTrue(method_exists($controller, 'index'), 'Controller must have index()');
        $ref = new \ReflectionClass($controller);
        $this->assertTrue($ref->hasMethod('readSmtpResponse'), 'Controller must have private readSmtpResponse()');
        $this->assertTrue($ref->hasMethod('writeSmtpCommand'), 'Controller must have private writeSmtpCommand()');
    }

    /**
     * Verify global SMTP resolution returns valid fallback array without error
     */
    public function testGlobalSmtpResolutionWithoutCompany(): void
    {
        $globalConfig = SmtpConfigResolver::resolve(null, false);
        $this->assertIsArray($globalConfig);
        $this->assertFalse($globalConfig['_is_company_override']);
        $this->assertArrayHasKey('smtp_host', $globalConfig);
        $this->assertArrayHasKey('smtp_port', $globalConfig);

        $masked = SmtpConfigResolver::getMasked(null);
        $this->assertIsArray($masked);
        $this->assertFalse($masked['_is_company_override']);
    }
}
