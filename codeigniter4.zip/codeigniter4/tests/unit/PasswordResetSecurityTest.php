<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class PasswordResetSecurityTest extends TestCase
{
    protected string $controllerContent;

    protected function setUp(): void
    {
        parent::setUp();
        $controllerPath = dirname(__DIR__, 2) . '/app/Controllers/Auth/PasswordController.php';
        $this->controllerContent = file_get_contents($controllerPath);
    }

    /**
     * Requirement: Generate a random token (at least 32 bytes) and store only its hash.
     */
    public function testTokenGenerationAtLeast32BytesAndHashed()
    {
        // 32 bytes of secure random bytes
        $this->assertStringContainsString(
            "random_bytes(32)",
            $this->controllerContent,
            "PasswordController MUST generate a random token using at least random_bytes(32)"
        );

        // Raw token converted to hex (64 chars) and hashed with sha256 before storing
        $this->assertStringContainsString(
            "hash('sha256', \$rawToken)",
            $this->controllerContent,
            "PasswordController MUST hash raw token using SHA-256 before database storage"
        );
    }

    /**
     * Requirement: One active token per user.
     */
    public function testOneActiveTokenPerUserEnforced()
    {
        $this->assertStringContainsString(
            "->where('email', \$email)->delete()",
            $this->controllerContent,
            "PasswordController MUST purge existing tokens for the user before creating a new token"
        );
    }

    /**
     * Requirement: 15-minute mandatory expiry required (never skipped when expires_at is empty).
     */
    public function testMandatoryFifteenMinuteExpiryRequired()
    {
        $this->assertStringContainsString(
            "time() + 900",
            $this->controllerContent,
            "PasswordController MUST configure 15-minute (900 seconds) token expiry"
        );

        // Verification must strictly reject if expires_at is empty OR expired
        $this->assertStringContainsString(
            "empty(\$resetRecord['expires_at']) || strtotime(\$resetRecord['expires_at']) < time()",
            $this->controllerContent,
            "PasswordController MUST require expires_at and reject missing or past expiry"
        );
    }

    /**
     * Requirement: Rate limit by IP and by account, and lock the token after 5 failed attempts.
     */
    public function testRateLimitingAndFiveAttemptLockout()
    {
        // Rate limiting by IP and account
        $this->assertStringContainsString(
            "pwd_reset_req_ip_",
            $this->controllerContent,
            "PasswordController MUST track reset requests by IP"
        );
        $this->assertStringContainsString(
            "pwd_reset_req_acct_",
            $this->controllerContent,
            "PasswordController MUST track reset requests by account email"
        );

        // Lockout after 5 failed attempts
        $this->assertStringContainsString(
            "\$failedAttempts >= 5",
            $this->controllerContent,
            "PasswordController MUST lock the reset token after 5 failed attempts"
        );
    }

    /**
     * Requirement: Return the same message whether or not the account exists (anti-enumeration).
     */
    public function testIdenticalResponseWhetherAccountExistsOrNot()
    {
        // Check generic success message in sendResetLink
        $this->assertStringContainsString(
            "If an account exists with this email address, a password reset link has been dispatched to your inbox.",
            $this->controllerContent,
            "PasswordController MUST return identical response regardless of whether account exists"
        );

        // Must NOT leak account existence in sendResetLink
        $this->assertStringNotContainsString(
            "No account found with this email address.",
            $this->controllerContent,
            "PasswordController MUST NOT return 'No account found with this email address' on forgot password"
        );

        // Must NOT leak account existence in attemptResetPassword
        $this->assertStringNotContainsString(
            "No user found with the specified email address.",
            $this->controllerContent,
            "PasswordController MUST NOT return 'No user found with the specified email address' on reset password"
        );
    }

    /**
     * Requirement: No plaintext token accepted (constant-time hash_equals only).
     */
    public function testNoPlaintextTokenAccepted()
    {
        $this->assertStringNotContainsString(
            "->orWhere('token', \$code)",
            $this->controllerContent,
            "PasswordController MUST NOT accept plaintext token in database query"
        );
        $this->assertStringContainsString(
            "hash_equals((string)\$resetRecord['token'], \$inputHash)",
            $this->controllerContent,
            "PasswordController MUST verify token using constant-time hash_equals against hashed input"
        );
    }

    /**
     * Requirement: Minimum password length 12 in attemptResetPassword and changePassword.
     */
    public function testMinimumPasswordLengthTwelve()
    {
        $this->assertStringContainsString(
            "strlen(\$newPassword) < 12",
            $this->controllerContent,
            "PasswordController MUST enforce minimum password length of 12"
        );
        $this->assertStringNotContainsString(
            "strlen(\$newPassword) < 6",
            $this->controllerContent,
            "PasswordController MUST NOT allow passwords shorter than 12 characters"
        );
    }

    /**
     * Requirement: After a successful reset, delete the token and destroy all of the user's other sessions.
     */
    public function testDeleteTokenAndDestroyAllUserSessionsAfterReset()
    {
        $this->assertStringContainsString(
            "\$this->destroyUserSessions(\$user['id'])",
            $this->controllerContent,
            "PasswordController MUST destroy all active user sessions after password reset"
        );

        $this->assertStringContainsString(
            "destroyUserSessions",
            $this->controllerContent,
            "PasswordController MUST define destroyUserSessions() helper"
        );
    }
}
