<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

/**
 * Module 01 ESS and Profile Security Test Suite
 * 
 * Genuine production code invariant verification:
 * - F-01: Profile Access Control & Self-Service Gate (ProfileController.php)
 * - F-04: Document Upload Validation & Sanitization (ProfileController.php)
 * - P0-1: Private Document Storage Outside Web Root (WRITEPATH)
 * - P0-2: Authenticated Document Download Flow & Path Traversal Guards
 * - P0-3: State-Changing Document Deletion via POST & CSRF Enforcements
 * - P1-1: BaseController requireLogin() Execution Termination Guard
 */
class Module01EssAndProfileSecurityTest extends TestCase
{
    private string $profileControllerSrc;
    private string $baseControllerSrc;
    private string $routesSrc;
    private string $documentsViewSrc;

    protected function setUp(): void
    {
        parent::setUp();

        $appDir = dirname(__DIR__, 2);
        $this->profileControllerSrc = file_get_contents($appDir . '/app/Controllers/Employee/ProfileController.php');
        $this->baseControllerSrc    = file_get_contents($appDir . '/app/Controllers/BaseController.php');
        $this->routesSrc            = file_get_contents($appDir . '/app/Config/Routes.php');
        $this->documentsViewSrc     = file_get_contents($appDir . '/app/Views/employees/tabs/documents.php');
    }

    /**
     * TEST 1 (F-01): ProfileController::show enforces authentication and distinguishes self vs peer profile.
     */
    public function testProfileControllerShowEnforcesAuthAndSelfServiceAccess()
    {
        $this->assertStringContainsString('$this->requireLogin();', $this->profileControllerSrc);
        $this->assertStringContainsString('$isSelf = ($currentEmpId !== null && (string)$currentEmpId === (string)$id);', $this->profileControllerSrc);
        $this->assertStringContainsString("if (!\$isSelf) {\n            \$this->authorize('employee.view');\n        }", $this->profileControllerSrc);
    }

    /**
     * TEST 2 (F-01): ProfileController enforces strict multi-tenant scoping via verifyScopedEmployee.
     */
    public function testProfileControllerEnforcesTenantScoping()
    {
        $this->assertStringContainsString('$emp = $this->verifyScopedEmployee($id);', $this->profileControllerSrc);
        $this->assertStringContainsString("return redirect()->to('/employees')->with('error', '403 Forbidden: Employee record not accessible.');", $this->profileControllerSrc);
    }

    /**
     * TEST 3 (P0-1): Document upload stores files in private WRITEPATH, outside public web root.
     */
    public function testDocumentUploadUsesPrivateStorageOutsideWebRoot()
    {
        $this->assertStringContainsString('$uploadTargetDir = WRITEPATH . $targetSubdir;', $this->profileControllerSrc);
        $this->assertStringContainsString("mkdir(\$uploadTargetDir, 0750, true);", $this->profileControllerSrc);
        $this->assertStringContainsString("\$targetSubdir = 'uploads/documents/' . \$cleanCompanyId . '/' . \$cleanEmployeeId . '/';", $this->profileControllerSrc);
    }

    /**
     * TEST 4 (F-04): Document upload enforces cryptographically random filename and finfo MIME check.
     */
    public function testDocumentUploadEnforcesRandomFilenameAndFinfo()
    {
        $this->assertStringContainsString("\$randomFileName = 'doc_' . bin2hex(random_bytes(16)) . '.' . \$safeExt;", $this->profileControllerSrc);
        $this->assertStringContainsString('$finfo = new \finfo(FILEINFO_MIME_TYPE);', $this->profileControllerSrc);
        $this->assertStringContainsString('$realMime = $finfo->file($tempPath);', $this->profileControllerSrc);
    }

    /**
     * TEST 5 (F-04): Document upload enforces double extension defense.
     */
    public function testDocumentUploadEnforcesDoubleExtensionDefense()
    {
        $this->assertStringContainsString('$dangerousExtensions = [', $this->profileControllerSrc);
        $this->assertStringContainsString('$nameParts = explode(\'.\', strtolower($clientName));', $this->profileControllerSrc);
        $this->assertStringContainsString('in_array($nameParts[$i], $dangerousExtensions, true)', $this->profileControllerSrc);
    }

    /**
     * TEST 6 (P0-2): ProfileController implements authenticated downloadDocument with containment check.
     */
    public function testDownloadDocumentEndpointExistsAndSecured()
    {
        $this->assertStringContainsString('public function downloadDocument(string $id, string $docId)', $this->profileControllerSrc);
        $this->assertStringContainsString('$privateBase = realpath(WRITEPATH . \'uploads/documents\');', $this->profileControllerSrc);
        $this->assertStringContainsString('strpos($resolvedFile, $privateBase) !== 0', $this->profileControllerSrc);
        $this->assertStringContainsString("->setHeader('Content-Disposition', 'attachment; filename=\"' . \$downloadTitle . '\"')", $this->profileControllerSrc);
        $this->assertStringContainsString("->setHeader('X-Content-Type-Options', 'nosniff')", $this->profileControllerSrc);
    }

    /**
     * TEST 7 (P0-3): ProfileController::deleteDocument enforces POST method and allows self-service delete.
     */
    public function testDeleteDocumentEnforcesPostMethodAndSelfService()
    {
        $this->assertStringContainsString("strtolower(\$this->request->getMethod()) !== 'post'", $this->profileControllerSrc);
        $this->assertStringContainsString("Document deletion requires a POST request with CSRF token.", $this->profileControllerSrc);
        $this->assertStringContainsString('$isSelf = ($currentEmpId !== null && (string)$currentEmpId === (string)$id);', $this->profileControllerSrc);
        $this->assertStringContainsString("if (!\$isSelf) {\n            \$this->authorize('employee.edit');\n        }", $this->profileControllerSrc);
    }

    /**
     * TEST 8 (P0-3): Routes.php defines documents/delete strictly as POST and registers download route.
     */
    public function testRoutesStrictlyDefineDocumentOperations()
    {
        $this->assertStringContainsString("\$routes->post('profile/(:segment)/documents/delete/(:segment)', 'Employee\\ProfileController::deleteDocument/$1/$2');", $this->routesSrc);
        $this->assertStringNotContainsString("\$routes->match(['get', 'post'], 'profile/(:segment)/documents/delete", $this->routesSrc);
        $this->assertStringContainsString("\$routes->get('profile/(:segment)/documents/download/(:segment)', 'Employee\\ProfileController::downloadDocument/$1/$2');", $this->routesSrc);
    }

    /**
     * TEST 9 (P0-3): documents.php view embeds POST form with CSRF token and links to download endpoint.
     */
    public function testDocumentsViewEmbedsCsrfFormAndDownloadLink()
    {
        $this->assertStringContainsString('<form method="POST" action="<?= base_url(\'employees/profile/\' . $employee[\'id\'] . \'/documents/delete/\'', $this->documentsViewSrc);
        $this->assertStringContainsString('<?= csrf_field() ?>', $this->documentsViewSrc);
        $this->assertStringContainsString("base_url('employees/profile/' . \$employee['id'] . '/documents/download/' . \$doc['id'])", $this->documentsViewSrc);
    }

    /**
     * TEST 10 (P1-1): BaseController::requireLogin explicitly halts execution on failure.
     */
    public function testRequireLoginExplicitlyHaltsExecution()
    {
        $this->assertStringContainsString('$response = redirect()->to(base_url(\'login\'));', $this->baseControllerSrc);
        $this->assertStringContainsString('$response->send();', $this->baseControllerSrc);
        $this->assertStringContainsString('exit;', $this->baseControllerSrc);
    }
}
