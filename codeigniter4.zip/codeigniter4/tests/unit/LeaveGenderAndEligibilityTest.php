<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\LeaveService;
use App\Services\ProbationLeaveEligibilityService;

class LeaveGenderAndEligibilityTest extends TestCase
{
    private LeaveService $leaveService;
    private ProbationLeaveEligibilityService $probationService;

    protected function setUp(): void
    {
        parent::setUp();
        $this->leaveService = new LeaveService();
        $this->probationService = new ProbationLeaveEligibilityService();
    }

    /**
     * Test female employee is eligible for Maternity Leave.
     */
    public function testFemaleEmployeeEligibleForMaternityLeave(): void
    {
        $femaleEmployee = [
            'id' => 'EMP-FEMALE-01',
            'first_name' => 'Fatima',
            'last_name' => 'Akter',
            'gender' => 'female',
            'company_id' => 'comp-test-01',
            'employment_type' => 'Permanent',
        ];

        $maternityType = [
            'id' => 'lt-maternity-01',
            'code' => 'ML',
            'name' => 'Maternity Leave',
            'applicable_gender' => 'Female',
            'is_paid' => 1,
        ];

        $check = $this->leaveService->checkGenderEligibility($femaleEmployee, $maternityType);
        $this->assertTrue($check['eligible'], 'Female employee must be eligible for Maternity Leave');
    }

    /**
     * Test female employee is ineligible for Paternity Leave.
     */
    public function testFemaleEmployeeIneligibleForPaternityLeave(): void
    {
        $femaleEmployee = [
            'id' => 'EMP-FEMALE-01',
            'first_name' => 'Fatima',
            'last_name' => 'Akter',
            'gender' => 'female',
            'company_id' => 'comp-test-01',
            'employment_type' => 'Permanent',
        ];

        $paternityType = [
            'id' => 'lt-paternity-01',
            'code' => 'PL',
            'name' => 'Paternity Leave',
            'applicable_gender' => 'Male',
            'is_paid' => 1,
        ];

        $check = $this->leaveService->checkGenderEligibility($femaleEmployee, $paternityType);
        $this->assertFalse($check['eligible'], 'Female employee must NOT be eligible for Paternity Leave');
        $this->assertStringContainsString('Paternity Leave', $check['reason']);
        $this->assertStringContainsString('male', strtolower($check['reason']));
    }

    /**
     * Test male employee is eligible for Paternity Leave.
     */
    public function testMaleEmployeeEligibleForPaternityLeave(): void
    {
        $maleEmployee = [
            'id' => 'EMP-MALE-01',
            'first_name' => 'Tariq',
            'last_name' => 'Hasan',
            'gender' => 'male',
            'company_id' => 'comp-test-01',
            'employment_type' => 'Permanent',
        ];

        $paternityType = [
            'id' => 'lt-paternity-01',
            'code' => 'PL',
            'name' => 'Paternity Leave',
            'applicable_gender' => 'Male',
            'is_paid' => 1,
        ];

        $check = $this->leaveService->checkGenderEligibility($maleEmployee, $paternityType);
        $this->assertTrue($check['eligible'], 'Male employee must be eligible for Paternity Leave');
    }

    /**
     * Test male employee is ineligible for Maternity Leave.
     */
    public function testMaleEmployeeIneligibleForMaternityLeave(): void
    {
        $maleEmployee = [
            'id' => 'EMP-MALE-01',
            'first_name' => 'Tariq',
            'last_name' => 'Hasan',
            'gender' => 'male',
            'company_id' => 'comp-test-01',
            'employment_type' => 'Permanent',
        ];

        $maternityType = [
            'id' => 'lt-maternity-01',
            'code' => 'ML',
            'name' => 'Maternity Leave',
            'applicable_gender' => 'Female',
            'is_paid' => 1,
        ];

        $check = $this->leaveService->checkGenderEligibility($maleEmployee, $maternityType);
        $this->assertFalse($check['eligible'], 'Male employee must NOT be eligible for Maternity Leave');
        $this->assertStringContainsString('Maternity Leave', $check['reason']);
        $this->assertStringContainsString('female', strtolower($check['reason']));
    }

    /**
     * Test general leave types are open to all genders (AL, CL, SL, UL/LWP, SPL).
     */
    public function testAllGendersEligibleForGeneralLeaveTypes(): void
    {
        $employees = [
            ['id' => 'EMP-F', 'first_name' => 'Sarah', 'gender' => 'female'],
            ['id' => 'EMP-M', 'first_name' => 'John', 'gender' => 'male'],
            ['id' => 'EMP-O', 'first_name' => 'Alex', 'gender' => 'other'],
        ];

        $generalTypes = [
            ['code' => 'AL', 'name' => 'Annual Leave', 'applicable_gender' => 'All'],
            ['code' => 'CL', 'name' => 'Casual Leave', 'applicable_gender' => 'All'],
            ['code' => 'SL', 'name' => 'Sick Leave', 'applicable_gender' => 'All'],
            ['code' => 'LWP', 'name' => 'Unpaid Leave', 'applicable_gender' => 'All'],
            ['code' => 'SPL', 'name' => 'Special Leave', 'applicable_gender' => 'All'],
        ];

        foreach ($employees as $emp) {
            foreach ($generalTypes as $type) {
                $check = $this->leaveService->checkGenderEligibility($emp, $type);
                $this->assertTrue(
                    $check['eligible'],
                    "Employee {$emp['first_name']} ({$emp['gender']}) must be eligible for {$type['name']}"
                );
            }
        }
    }

    /**
     * Test rule entitlement override takes precedence over type master if rule provides applicable_gender.
     */
    public function testRuleEntitlementGenderRespected(): void
    {
        $maleEmployee = ['id' => 'EMP-M', 'gender' => 'male'];
        $type = ['code' => 'CUSTOM', 'name' => 'Custom Category', 'applicable_gender' => 'All'];
        $ruleEnt = ['leave_type_code' => 'CUSTOM', 'applicable_gender' => 'Female'];

        $check = $this->leaveService->checkGenderEligibility($maleEmployee, $type, $ruleEnt);
        $this->assertFalse($check['eligible'], 'Rule entitlement configured for Female must block male applicant');
    }

    /**
     * Test Special Leave (SPL) canonical mapping and resolution.
     */
    public function testSpecialLeaveCanonicalGroupMapping(): void
    {
        $code = $this->leaveService->matchLeaveTypeCode('Special Leave');
        $this->assertEquals('SPL', $code, 'Special Leave must resolve to SPL');

        $codeShort = $this->leaveService->matchLeaveTypeCode('SPL');
        $this->assertEquals('SPL', $codeShort, 'SPL must resolve to SPL');

        $codeAlias = $this->leaveService->matchLeaveTypeCode('SPECIAL');
        $this->assertEquals('SPL', $codeAlias, 'SPECIAL must resolve to SPL');
    }

    /**
     * Test leave filtering logic for female vs male employee list.
     */
    public function testLeaveFilteringByGenderList(): void
    {
        $allTypes = [
            ['id' => '1', 'code' => 'AL', 'name' => 'Annual Leave', 'applicable_gender' => 'All'],
            ['id' => '2', 'code' => 'CL', 'name' => 'Casual Leave', 'applicable_gender' => 'All'],
            ['id' => '3', 'code' => 'SL', 'name' => 'Sick Leave', 'applicable_gender' => 'All'],
            ['id' => '4', 'code' => 'LWP', 'name' => 'Unpaid Leave', 'applicable_gender' => 'All'],
            ['id' => '5', 'code' => 'ML', 'name' => 'Maternity Leave', 'applicable_gender' => 'Female'],
            ['id' => '6', 'code' => 'PL', 'name' => 'Paternity Leave', 'applicable_gender' => 'Male'],
            ['id' => '7', 'code' => 'SPL', 'name' => 'Special Leave', 'applicable_gender' => 'All'],
        ];

        // Filter for female
        $femaleEmp = ['id' => 'F1', 'gender' => 'female'];
        $femaleEligible = array_values(array_filter($allTypes, function ($t) use ($femaleEmp) {
            $res = $this->leaveService->checkGenderEligibility($femaleEmp, $t);
            return $res['eligible'];
        }));

        $femaleCodes = array_column($femaleEligible, 'code');
        $this->assertContains('AL', $femaleCodes);
        $this->assertContains('CL', $femaleCodes);
        $this->assertContains('SL', $femaleCodes);
        $this->assertContains('LWP', $femaleCodes);
        $this->assertContains('ML', $femaleCodes);
        $this->assertContains('SPL', $femaleCodes);
        $this->assertNotContains('PL', $femaleCodes, 'Female employee must NOT have Paternity Leave in eligible list');

        // Filter for male
        $maleEmp = ['id' => 'M1', 'gender' => 'male'];
        $maleEligible = array_values(array_filter($allTypes, function ($t) use ($maleEmp) {
            $res = $this->leaveService->checkGenderEligibility($maleEmp, $t);
            return $res['eligible'];
        }));

        $maleCodes = array_column($maleEligible, 'code');
        $this->assertContains('AL', $maleCodes);
        $this->assertContains('CL', $maleCodes);
        $this->assertContains('SL', $maleCodes);
        $this->assertContains('LWP', $maleCodes);
        $this->assertContains('PL', $maleCodes);
        $this->assertContains('SPL', $maleCodes);
        $this->assertNotContains('ML', $maleCodes, 'Male employee must NOT have Maternity Leave in eligible list');
    }

    /**
     * Test single rule store schema entitlement attributes and policy configurability.
     */
    public function testSingleRuleStoreEntitlementConfigurability(): void
    {
        $schemaFile = APPPATH . 'Config/RuleSchema.json';
        $this->assertFileExists($schemaFile, 'RuleSchema.json must exist');

        $schema = json_decode(file_get_contents($schemaFile), true);
        $this->assertIsArray($schema, 'RuleSchema.json must be valid JSON');

        $leaveDomain = $schema['domains']['LEAVE'] ?? null;
        $this->assertNotNull($leaveDomain, 'LEAVE domain must be defined in RuleSchema.json');

        // Locate entitlements and probation params from params array
        $entitlementsParam = null;
        $probationParam = null;
        foreach ($leaveDomain['params'] as $p) {
            if (($p['key'] ?? '') === 'entitlements') {
                $entitlementsParam = $p;
            }
            if (($p['key'] ?? '') === 'probation') {
                $probationParam = $p;
            }
        }

        $this->assertNotNull($entitlementsParam, 'LEAVE domain must define entitlements parameter');
        $this->assertNotNull($probationParam, 'LEAVE domain must define probation parameter');

        // Check applicable_gender in item definition
        $items = $entitlementsParam['item'] ?? [];
        $itemKeys = array_column($items, 'key');
        $this->assertContains('applicable_gender', $itemKeys, 'entitlements item must define applicable_gender property');
        $this->assertContains('is_paid', $itemKeys, 'entitlements item must define is_paid property');
        $this->assertContains('paid_percentage', $itemKeys, 'entitlements item must define paid_percentage property');
        $this->assertContains('carry_forward_allowed', $itemKeys, 'entitlements item must define carry_forward_allowed property');
        $this->assertContains('approval_required', $itemKeys, 'entitlements item must define approval_required property');

        // Check seed entitlements include SPL and gender definitions
        $seeds = $entitlementsParam['seed'] ?? [];
        $seedCodes = array_column($seeds, 'leave_type_code');
        $this->assertContains('SPL', $seedCodes, 'Seed entitlements must include Special Leave (SPL)');
        $this->assertContains('ML', $seedCodes, 'Seed entitlements must include Maternity Leave (ML)');
        $this->assertContains('PL', $seedCodes, 'Seed entitlements must include Paternity Leave (PL)');
        $this->assertContains('AL', $seedCodes, 'Seed entitlements must include Annual Leave (AL)');
        $this->assertContains('SL', $seedCodes, 'Seed entitlements must include Sick Leave (SL)');

        $mlSeed = null;
        $plSeed = null;
        $splSeed = null;
        foreach ($seeds as $s) {
            if ($s['leave_type_code'] === 'ML') $mlSeed = $s;
            if ($s['leave_type_code'] === 'PL') $plSeed = $s;
            if ($s['leave_type_code'] === 'SPL') $splSeed = $s;
        }

        $this->assertEquals('Female', $mlSeed['applicable_gender']);
        $this->assertEquals('Male', $plSeed['applicable_gender']);
        $this->assertEquals('All', $splSeed['applicable_gender']);
        $this->assertTrue($splSeed['is_paid']);

        // Check probation policy seed configuration
        $probSeed = $probationParam['seed'] ?? [];
        $this->assertArrayHasKey('can_apply_during_probation', $probSeed);
        $this->assertArrayHasKey('probation_duration_months', $probSeed);
        $this->assertArrayHasKey('allowed_leave_type_codes', $probSeed);
        $this->assertArrayHasKey('blocked_leave_type_codes', $probSeed);
    }

    /**
     * Test probation leave filtering logic honoring allowed vs blocked codes.
     */
    public function testProbationLeaveEligibilityFiltering(): void
    {
        $probConfig = [
            'probation_duration_months' => 6,
            'can_apply_during_probation' => true,
            'allowed_leave_type_codes' => ['SL', 'UL'],
            'blocked_leave_type_codes' => ['AL', 'EL'],
            'allow_paid_leave' => false,
            'allow_unpaid_leave' => true,
        ];

        $leaveTypes = [
            ['code' => 'AL', 'name' => 'Annual Leave'],
            ['code' => 'SL', 'name' => 'Sick Leave'],
            ['code' => 'UL', 'name' => 'Unpaid Leave'],
            ['code' => 'EL', 'name' => 'Earned Leave'],
            ['code' => 'SPL', 'name' => 'Special Leave'],
        ];

        $allowedInProbation = [];
        $blockedInProbation = [];
        foreach ($leaveTypes as $lt) {
            $code = $lt['code'];
            $isAllowed = in_array($code, $probConfig['allowed_leave_type_codes'], true) ||
                         (!in_array($code, $probConfig['blocked_leave_type_codes'], true) && $probConfig['can_apply_during_probation']);
            if ($isAllowed && !in_array($code, $probConfig['blocked_leave_type_codes'], true)) {
                $allowedInProbation[] = $code;
            } else {
                $blockedInProbation[] = $code;
            }
        }

        $this->assertContains('SL', $allowedInProbation, 'Sick leave must be allowed during probation');
        $this->assertContains('UL', $allowedInProbation, 'Unpaid leave must be allowed during probation');
        $this->assertContains('AL', $blockedInProbation, 'Annual leave must be blocked during probation');
        $this->assertContains('EL', $blockedInProbation, 'Earned leave must be blocked during probation');
    }
}
