<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use App\Services\EmployeeSeparationService;
use App\Models\EmployeeModel;
use App\Models\UserModel;
use Config\Database;

/**
 * DB-backed & unit tests for De-duplicated Separation Authorization Guards (assertActorMayActOn)
 *
 * Requirements:
 * 1. Self-termination blocked: cannot terminate or resign yourself.
 * 2. Equal-role blocked: cannot terminate or resign an employee with an equal role.
 * 3. Higher-role blocked: cannot terminate or resign an employee with a higher role.
 * 4. Lower-role allowed: higher-ranking actors can act on lower-ranking employees.
 * 5. Software App Admin allowed: platform admin can act on other roles without role rank blocking.
 * 6. Tested through both direct assertActorMayActOn and the real service entry points (terminate and resign).
 * 7. Zero assertions on source text.
 */
class EmployeeSeparationGuardsTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected static bool $schemaInitialized = false;

    protected string $companyId   = 'comp-sep-guard-01';
    protected string $branchId    = 'branch-sep-guard-01';

    protected string $hrAdminEmpId    = 'emp-sep-hra-1';
    protected string $hrAdminUserId   = 'usr-sep-hra-1';

    protected string $hrAdmin2EmpId   = 'emp-sep-hra-2';
    protected string $hrAdmin2UserId  = 'usr-sep-hra-2';

    protected string $companyAdminEmpId  = 'emp-sep-ca-1';
    protected string $companyAdminUserId = 'usr-sep-ca-1';

    protected string $lowerEmpId      = 'emp-sep-sub-1';
    protected string $lowerUserId     = 'usr-sep-sub-1';

    protected string $saEmpId         = 'emp-sep-sa-1';
    protected string $saUserId        = 'usr-sep-sa-1';

    public static function setUpBeforeClass(): void
    {
        parent::setUpBeforeClass();
        static::ensureSchema();
    }

    public static function registerSqliteFunctions($db): void
    {
        try {
            $rawConn = $db->connID ?? null;
            if ($rawConn instanceof \SQLite3) {
                $rawConn->createFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->createFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            } elseif (is_object($rawConn) && method_exists($rawConn, 'sqliteCreateFunction')) {
                $rawConn->sqliteCreateFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->sqliteCreateFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            }
        } catch (\Throwable $e) {
            // ignore
        }
    }

    protected static function ensureSchema(): void
    {
        $db = Database::connect();
        static::registerSqliteFunctions($db);

        $schemaFile = __DIR__ . '/Rules/schema.sqlite.sql';
        if (file_exists($schemaFile)) {
            $sql = file_get_contents($schemaFile);
            $statements = array_filter(array_map('trim', explode(';', $sql)));
            foreach ($statements as $stmt) {
                if (!empty($stmt)) {
                    try {
                        $db->query($stmt);
                    } catch (\Throwable $e) {
                        // ignore
                    }
                }
            }
        }

        static::$schemaInitialized = true;
    }

    protected function setUp(): void
    {
        parent::setUp();
        static::ensureSchema();

        $db = Database::connect();
        static::registerSqliteFunctions($db);

        // Seed Company
        $db->table('companies')->replace([
            'id'     => $this->companyId,
            'name'   => 'Separation Guard Corp',
            'code'   => 'SGC-SEP',
            'status' => 'Active',
        ]);

        // Seed Roles
        $db->table('roles')->replace([
            ['id' => 'role-sep-sa',  'company_id' => $this->companyId, 'name' => 'Software App Admin', 'code' => 'software_app_admin', 'status' => 'Active', 'is_system' => 1],
            ['id' => 'role-sep-ca',  'company_id' => $this->companyId, 'name' => 'Company Admin',      'code' => 'company_admin',      'status' => 'Active', 'is_system' => 1],
            ['id' => 'role-sep-hra', 'company_id' => $this->companyId, 'name' => 'HR Admin',           'code' => 'hr_admin',           'status' => 'Active', 'is_system' => 1],
            ['id' => 'role-sep-emp', 'company_id' => $this->companyId, 'name' => 'Employee',           'code' => 'employee',           'status' => 'Active', 'is_system' => 1],
        ]);

        // Clean up test records
        $testEmpIds = [$this->hrAdminEmpId, $this->hrAdmin2EmpId, $this->companyAdminEmpId, $this->lowerEmpId, $this->saEmpId];
        $testUserIds = [$this->hrAdminUserId, $this->hrAdmin2UserId, $this->companyAdminUserId, $this->lowerUserId, $this->saUserId];
        $db->table('employee_terminations')->whereIn('employee_id', $testEmpIds)->delete();
        $db->table('employee_resignations')->whereIn('employee_id', $testEmpIds)->delete();
        $db->table('employees')->whereIn('id', $testEmpIds)->delete();
        $db->table('users')->whereIn('id', $testUserIds)->delete();

        // 1. HR Admin 1 (actor)
        $db->table('employees')->insert([
            'id'            => $this->hrAdminEmpId,
            'company_id'    => $this->companyId,
            'employee_code' => 'EMP-HRA-1',
            'first_name'    => 'HR',
            'last_name'     => 'AdminOne',
            'email'         => 'hra1@sep.test',
            'status'        => EmployeeModel::STATUS_ACTIVE,
            'joining_date'  => '2025-01-01',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);
        $db->table('users')->insert([
            'id'          => $this->hrAdminUserId,
            'company_id'  => $this->companyId,
            'role_id'     => 'role-sep-hra',
            'employee_id' => $this->hrAdminEmpId,
            'username'    => 'hr_admin_1',
            'email'       => 'hra1@sep.test',
            'status'      => UserModel::STATUS_ACTIVE,
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        // 2. HR Admin 2 (equal role target)
        $db->table('employees')->insert([
            'id'            => $this->hrAdmin2EmpId,
            'company_id'    => $this->companyId,
            'employee_code' => 'EMP-HRA-2',
            'first_name'    => 'HR',
            'last_name'     => 'AdminTwo',
            'email'         => 'hra2@sep.test',
            'status'        => EmployeeModel::STATUS_ACTIVE,
            'joining_date'  => '2025-01-01',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);
        $db->table('users')->insert([
            'id'          => $this->hrAdmin2UserId,
            'company_id'  => $this->companyId,
            'role_id'     => 'role-sep-hra',
            'employee_id' => $this->hrAdmin2EmpId,
            'username'    => 'hr_admin_2',
            'email'       => 'hra2@sep.test',
            'status'      => UserModel::STATUS_ACTIVE,
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        // 3. Company Admin (higher role target)
        $db->table('employees')->insert([
            'id'            => $this->companyAdminEmpId,
            'company_id'    => $this->companyId,
            'employee_code' => 'EMP-CA-1',
            'first_name'    => 'Company',
            'last_name'     => 'Admin',
            'email'         => 'ca1@sep.test',
            'status'        => EmployeeModel::STATUS_ACTIVE,
            'joining_date'  => '2025-01-01',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);
        $db->table('users')->insert([
            'id'          => $this->companyAdminUserId,
            'company_id'  => $this->companyId,
            'role_id'     => 'role-sep-ca',
            'employee_id' => $this->companyAdminEmpId,
            'username'    => 'comp_admin_1',
            'email'       => 'ca1@sep.test',
            'status'      => UserModel::STATUS_ACTIVE,
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        // 4. Lower Employee (lower role target)
        $db->table('employees')->insert([
            'id'            => $this->lowerEmpId,
            'company_id'    => $this->companyId,
            'employee_code' => 'EMP-SUB-1',
            'first_name'    => 'Subordinate',
            'last_name'     => 'Staff',
            'email'         => 'sub1@sep.test',
            'status'        => EmployeeModel::STATUS_ACTIVE,
            'joining_date'  => '2025-01-01',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);
        $db->table('users')->insert([
            'id'          => $this->lowerUserId,
            'company_id'  => $this->companyId,
            'role_id'     => 'role-sep-emp',
            'employee_id' => $this->lowerEmpId,
            'username'    => 'sub_staff_1',
            'email'       => 'sub1@sep.test',
            'status'      => UserModel::STATUS_ACTIVE,
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        // 5. Software App Admin
        $db->table('employees')->insert([
            'id'            => $this->saEmpId,
            'company_id'    => $this->companyId,
            'employee_code' => 'EMP-SA-1',
            'first_name'    => 'Software',
            'last_name'     => 'SuperAdmin',
            'email'         => 'sa1@sep.test',
            'status'        => EmployeeModel::STATUS_ACTIVE,
            'joining_date'  => '2025-01-01',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);
        $db->table('users')->insert([
            'id'          => $this->saUserId,
            'company_id'  => $this->companyId,
            'role_id'     => 'role-sep-sa',
            'employee_id' => $this->saEmpId,
            'username'    => 'sa_admin_1',
            'email'       => 'sa1@sep.test',
            'status'      => UserModel::STATUS_ACTIVE,
            'created_at'  => date('Y-m-d H:i:s'),
        ]);
    }

    /**
     * Test 1: Self-termination is blocked (by employee_id and by user_id)
     */
    public function testSelfTerminationIsBlocked()
    {
        $actor = [
            'id'          => 'usr-actor-1',
            'employee_id' => 'emp-same-1',
            'role_code'   => 'hr_admin',
        ];
        $targetEmployee = [
            'id'      => 'emp-same-1',
            'user_id' => 'usr-other',
        ];

        $this->expectException(\SecurityException::class);
        $this->expectExceptionMessage('403 Forbidden: You cannot terminate your own employee record.');
        EmployeeSeparationService::assertActorMayActOn($actor, $targetEmployee, 'terminate');
    }

    public function testSelfTerminationByUserIdIsBlocked()
    {
        $actor = [
            'id'          => 'usr-shared-id',
            'employee_id' => 'emp-actor',
            'role_code'   => 'hr_admin',
        ];
        $targetEmployee = [
            'id'      => 'emp-target',
            'user_id' => 'usr-shared-id',
        ];

        $this->expectException(\SecurityException::class);
        $this->expectExceptionMessage('403 Forbidden: You cannot terminate your own employee record.');
        EmployeeSeparationService::assertActorMayActOn($actor, $targetEmployee, 'terminate');
    }

    /**
     * Test 2: Self-resignation is blocked
     */
    public function testSelfResignationIsBlocked()
    {
        $actor = [
            'id'          => 'usr-actor-2',
            'employee_id' => 'emp-same-2',
            'role_code'   => 'hr_admin',
        ];
        $targetEmployee = [
            'id'      => 'emp-same-2',
            'user_id' => 'usr-other',
        ];

        $this->expectException(\SecurityException::class);
        $this->expectExceptionMessage('403 Forbidden: You cannot process resignation for your own employee record.');
        EmployeeSeparationService::assertActorMayActOn($actor, $targetEmployee, 'resign');
    }

    /**
     * Test 3: Equal-role termination is blocked
     */
    public function testEqualRoleTerminationIsBlocked()
    {
        $actor = [
            'id'          => 'usr-hr-1',
            'employee_id' => 'emp-hr-1',
            'role_code'   => 'hr_admin',
        ];
        $targetEmployee = [
            'id'   => 'emp-hr-2',
            'user' => [
                'id'        => 'usr-hr-2',
                'role_code' => 'hr_admin',
            ],
        ];

        $this->expectException(\SecurityException::class);
        $this->expectExceptionMessage("403 Forbidden: You cannot terminate a user with a higher or equal role ('hr_admin').");
        EmployeeSeparationService::assertActorMayActOn($actor, $targetEmployee, 'terminate');
    }

    /**
     * Test 4: Equal-role resignation is blocked
     */
    public function testEqualRoleResignationIsBlocked()
    {
        $actor = [
            'id'          => 'usr-hr-1',
            'employee_id' => 'emp-hr-1',
            'role_code'   => 'hr_admin',
        ];
        $targetEmployee = [
            'id'   => 'emp-hr-2',
            'user' => [
                'id'        => 'usr-hr-2',
                'role_code' => 'hr_admin',
            ],
        ];

        $this->expectException(\SecurityException::class);
        $this->expectExceptionMessage("403 Forbidden: You cannot manage resignation for a user with a higher or equal role ('hr_admin').");
        EmployeeSeparationService::assertActorMayActOn($actor, $targetEmployee, 'resign');
    }

    /**
     * Test 5: Higher-role termination is blocked
     */
    public function testHigherRoleTerminationIsBlocked()
    {
        $actor = [
            'id'          => 'usr-bm-1',
            'employee_id' => 'emp-bm-1',
            'role_code'   => 'branch_manager',
        ];
        $targetEmployee = [
            'id'   => 'emp-hr-1',
            'user' => [
                'id'        => 'usr-hr-1',
                'role_code' => 'hr_admin',
            ],
        ];

        $this->expectException(\SecurityException::class);
        $this->expectExceptionMessage("403 Forbidden: You cannot terminate a user with a higher or equal role ('hr_admin').");
        EmployeeSeparationService::assertActorMayActOn($actor, $targetEmployee, 'terminate');
    }

    /**
     * Test 6: Higher-role resignation is blocked
     */
    public function testHigherRoleResignationIsBlocked()
    {
        $actor = [
            'id'          => 'usr-mgr-1',
            'employee_id' => 'emp-mgr-1',
            'role_code'   => 'manager',
        ];
        $targetEmployee = [
            'id'   => 'emp-admin-1',
            'user' => [
                'id'        => 'usr-admin-1',
                'role_code' => 'company_admin',
            ],
        ];

        $this->expectException(\SecurityException::class);
        $this->expectExceptionMessage("403 Forbidden: You cannot manage resignation for a user with a higher or equal role ('company_admin').");
        EmployeeSeparationService::assertActorMayActOn($actor, $targetEmployee, 'resign');
    }

    /**
     * Test 7: Lower-role action is allowed (no exception thrown)
     */
    public function testLowerRoleActionIsAllowed()
    {
        $actor = [
            'id'          => 'usr-hr-1',
            'employee_id' => 'emp-hr-1',
            'role_code'   => 'hr_admin',
        ];
        $targetEmployee = [
            'id'   => 'emp-sub-1',
            'user' => [
                'id'        => 'usr-sub-1',
                'role_code' => 'employee',
            ],
        ];

        EmployeeSeparationService::assertActorMayActOn($actor, $targetEmployee, 'terminate');
        EmployeeSeparationService::assertActorMayActOn($actor, $targetEmployee, 'resign');
        $this->assertTrue(true, 'Lower-role action must be permitted without throwing exception.');
    }

    /**
     * Test 8: Software App Admin is allowed to act across roles
     */
    public function testSoftwareAppAdminIsAllowed()
    {
        $actor = [
            'id'          => 'usr-sa-1',
            'employee_id' => 'emp-sa-1',
            'role_code'   => 'software_app_admin',
        ];
        $targetEmployee = [
            'id'   => 'emp-ca-1',
            'user' => [
                'id'        => 'usr-ca-1',
                'role_code' => 'company_admin',
            ],
        ];

        EmployeeSeparationService::assertActorMayActOn($actor, $targetEmployee, 'terminate');
        EmployeeSeparationService::assertActorMayActOn($actor, $targetEmployee, 'resign');
        $this->assertTrue(true, 'Software app admin must be permitted without throwing exception.');
    }

    /**
     * Test 9: Real terminate() entry point enforces self-action guard
     */
    public function testTerminateEntryPointEnforcesSelfActionGuard()
    {
        $service = new EmployeeSeparationService();
        $actorUser = [
            'id'          => $this->hrAdminUserId,
            'employee_id' => $this->hrAdminEmpId,
            'role_code'   => 'hr_admin',
            'company_id'  => $this->companyId,
        ];

        $this->expectException(\SecurityException::class);
        $this->expectExceptionMessage('403 Forbidden: You cannot terminate your own employee record.');

        $service->terminate(
            $this->hrAdminEmpId,
            ['termination_date' => date('Y-m-d')],
            $this->hrAdminUserId,
            $actorUser,
            $this->companyId
        );
    }

    /**
     * Test 10: Real terminate() entry point enforces equal-role guard
     */
    public function testTerminateEntryPointEnforcesEqualRoleGuard()
    {
        $service = new EmployeeSeparationService();
        $actorUser = [
            'id'          => $this->hrAdminUserId,
            'employee_id' => $this->hrAdminEmpId,
            'role_code'   => 'hr_admin',
            'company_id'  => $this->companyId,
        ];

        $this->expectException(\SecurityException::class);
        $this->expectExceptionMessage("403 Forbidden: You cannot terminate a user with a higher or equal role ('hr_admin').");

        $service->terminate(
            $this->hrAdmin2EmpId,
            ['termination_date' => date('Y-m-d')],
            $this->hrAdminUserId,
            $actorUser,
            $this->companyId
        );
    }

    /**
     * Test 11: Real terminate() entry point enforces higher-role guard
     */
    public function testTerminateEntryPointEnforcesHigherRoleGuard()
    {
        $service = new EmployeeSeparationService();
        $actorUser = [
            'id'          => $this->hrAdminUserId,
            'employee_id' => $this->hrAdminEmpId,
            'role_code'   => 'hr_admin',
            'company_id'  => $this->companyId,
        ];

        $this->expectException(\SecurityException::class);
        $this->expectExceptionMessage("403 Forbidden: You cannot terminate a user with a higher or equal role ('company_admin').");

        $service->terminate(
            $this->companyAdminEmpId,
            ['termination_date' => date('Y-m-d')],
            $this->hrAdminUserId,
            $actorUser,
            $this->companyId
        );
    }

    /**
     * Test 12: Real resign() entry point enforces self-resignation guard
     */
    public function testResignEntryPointEnforcesSelfActionGuard()
    {
        $service = new EmployeeSeparationService();
        $actorUser = [
            'id'          => $this->hrAdminUserId,
            'employee_id' => $this->hrAdminEmpId,
            'role_code'   => 'hr_admin',
            'company_id'  => $this->companyId,
        ];

        $this->expectException(\SecurityException::class);
        $this->expectExceptionMessage('403 Forbidden: You cannot process resignation for your own employee record.');

        $service->resign(
            $this->hrAdminEmpId,
            ['reason' => 'Self resignation attempt'],
            $this->hrAdminUserId,
            $actorUser,
            $this->companyId
        );
    }

    /**
     * Test 13: Real resign() entry point enforces equal-role guard
     */
    public function testResignEntryPointEnforcesEqualRoleGuard()
    {
        $service = new EmployeeSeparationService();
        $actorUser = [
            'id'          => $this->hrAdminUserId,
            'employee_id' => $this->hrAdminEmpId,
            'role_code'   => 'hr_admin',
            'company_id'  => $this->companyId,
        ];

        $this->expectException(\SecurityException::class);
        $this->expectExceptionMessage("403 Forbidden: You cannot manage resignation for a user with a higher or equal role ('hr_admin').");

        $service->resign(
            $this->hrAdmin2EmpId,
            ['reason' => 'Equal role resignation attempt'],
            $this->hrAdminUserId,
            $actorUser,
            $this->companyId
        );
    }

    /**
     * Test 14: Real resign() entry point enforces higher-role guard
     */
    public function testResignEntryPointEnforcesHigherRoleGuard()
    {
        $service = new EmployeeSeparationService();
        $actorUser = [
            'id'          => $this->hrAdminUserId,
            'employee_id' => $this->hrAdminEmpId,
            'role_code'   => 'hr_admin',
            'company_id'  => $this->companyId,
        ];

        $this->expectException(\SecurityException::class);
        $this->expectExceptionMessage("403 Forbidden: You cannot manage resignation for a user with a higher or equal role ('company_admin').");

        $service->resign(
            $this->companyAdminEmpId,
            ['reason' => 'Higher role resignation attempt'],
            $this->hrAdminUserId,
            $actorUser,
            $this->companyId
        );
    }

    /**
     * Test 15: Lower-role action succeeds through service entry points
     */
    public function testTerminateAndResignEntryPointsAllowLowerRole()
    {
        $service = new EmployeeSeparationService();
        $actorUser = [
            'id'          => $this->hrAdminUserId,
            'employee_id' => $this->hrAdminEmpId,
            'role_code'   => 'hr_admin',
            'company_id'  => $this->companyId,
        ];

        // Resign on lower employee passes guard and returns success
        $res = $service->resign(
            $this->lowerEmpId,
            ['reason' => 'Career progression', 'notice_date' => date('Y-m-d')],
            $this->hrAdminUserId,
            $actorUser,
            $this->companyId
        );

        $this->assertTrue($res['success']);
        $this->assertEquals('Pending', $res['data']['status']);
    }

    /**
     * Test 16: Software App Admin is allowed across role hierarchies in service entry points
     */
    public function testTerminateAndResignEntryPointsAllowSoftwareAppAdmin()
    {
        $service = new EmployeeSeparationService();
        $saActorUser = [
            'id'          => $this->saUserId,
            'employee_id' => $this->saEmpId,
            'role_code'   => 'software_app_admin',
            'company_id'  => $this->companyId,
        ];

        // Software App Admin can process resignation for Company Admin without role hierarchy blockage
        $res = $service->resign(
            $this->companyAdminEmpId,
            ['reason' => 'Platform executive decision', 'notice_date' => date('Y-m-d')],
            $this->saUserId,
            $saActorUser,
            null
        );

        $this->assertTrue($res['success']);
        $this->assertEquals('Pending', $res['data']['status']);
    }
}
