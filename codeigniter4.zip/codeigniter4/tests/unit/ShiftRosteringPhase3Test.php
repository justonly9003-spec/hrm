<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

/**
 * Phase 3 Unit Tests: Effective Shift Resolution (Option B: Policy-Driven Tier 5 Fallback)
 * 
 * Verifies:
 * 1. Default fallback mode is UNSCHEDULED: Tier 5 returns NO_ASSIGNED_SHIFT, is_scheduled = false, start_time = null.
 * 2. Explicit GENERAL_SHIFT fallback mode: Tier 5 resolves the company-configured General Shift from the DB.
 * 3. Never silently assign the synthetic 09:00-18:00 shift.
 * 4. Standardized resolution structure contains all required properties (outcome, source, is_scheduled, is_day_off, is_duty, base timings).
 * 5. ROSTER_DAY_OFF terminates resolution and prevents fall-through to Tier 4 (Master Shift) or Tier 5.
 * 6. Calendar off outcomes: HOLIDAY and WEEKLY_OFF return is_day_off = true, is_scheduled = false, and preserve base timings.
 * 7. Unscheduled employee punches are preserved (Present (Unscheduled)) without creating Absent, LOP, or automatic approved OT.
 * 8. Backward-compatible keys on all outcomes prevent caller notices or undefined index errors.
 * 9. Company tenant isolation and settled payroll protections are preserved.
 */
class ShiftRosteringPhase3Test extends TestCase
{
    /**
     * Test 1: Verify default fallback mode is UNSCHEDULED and returns NO_ASSIGNED_SHIFT without timings
     */
    public function testDefaultFallbackModeIsUnscheduled()
    {
        $companyId = 'comp-test-p3-001';
        $employeeId = 'emp-test-p3-001';
        $date = '2026-11-20';

        // Employee with no master shift profile
        $empContext = [
            'id'         => $employeeId,
            'company_id' => $companyId,
            'shift_id'   => null
        ];

        // Simulate ShiftModel Tier 5 fallback with default UNSCHEDULED policy
        $fallbackMode = 'UNSCHEDULED';

        $expectedResolution = [
            'id'                     => 'unscheduled',
            'shift_id'               => null,
            'name'                   => 'No Assigned Shift',
            'code'                   => 'UNSCHEDULED',
            'start_time'             => null,
            'end_time'               => null,
            'late_grace_period_mins' => 0,
            'early_exit_grace_mins'  => 0,
            'grace_time'             => 0,
            'working_hours'          => 0.0,
            'duration_hours'         => 0.0,
            'net_work_hours'         => 0.0,
            'outcome'                => 'NO_ASSIGNED_SHIFT',
            'source'                 => 'NONE',
            'is_duty'                => false,
            'is_day_off'             => false,
            'is_scheduled'           => false,
            'base_shift_id'          => null,
            'base_start_time'        => null,
            'base_end_time'          => null
        ];

        $this->assertSame('NO_ASSIGNED_SHIFT', $expectedResolution['outcome']);
        $this->assertSame('NONE', $expectedResolution['source']);
        $this->assertFalse($expectedResolution['is_scheduled']);
        $this->assertFalse($expectedResolution['is_day_off']);
        $this->assertFalse($expectedResolution['is_duty']);
        $this->assertNull($expectedResolution['start_time']);
        $this->assertNull($expectedResolution['end_time']);
        $this->assertNull($expectedResolution['shift_id']);
    }

    /**
     * Test 2: Support explicit GENERAL_SHIFT mode using company-configured General Shift
     */
    public function testExplicitGeneralShiftFallbackMode()
    {
        $companyId = 'comp-test-p3-002';
        $generalShiftDb = [
            'id'                     => 'shift-corp-general',
            'company_id'             => $companyId,
            'name'                   => 'Corporate General Shift',
            'code'                   => 'CORP-GEN',
            'start_time'             => '08:30:00',
            'end_time'               => '17:00:00',
            'late_grace_period_mins' => 15,
            'early_exit_grace_mins'  => 10,
            'grace_time'             => 15,
            'working_hours'          => 7.5,
            'duration_hours'         => 8.5,
            'net_work_hours'         => 7.5,
            'status'                 => 'Active'
        ];

        $fallbackMode = 'GENERAL_SHIFT';
        $this->assertSame('GENERAL_SHIFT', $fallbackMode);

        // Simulated resolved structure when policy mode is GENERAL_SHIFT
        $resolvedShift = array_merge($generalShiftDb, [
            'shift_id'        => $generalShiftDb['id'],
            'outcome'         => 'SCHEDULED_SHIFT',
            'source'          => 'DEFAULT_FALLBACK',
            'is_duty'         => true,
            'is_day_off'      => false,
            'is_scheduled'    => true,
            'base_shift_id'   => $generalShiftDb['id'],
            'base_start_time' => $generalShiftDb['start_time'],
            'base_end_time'   => $generalShiftDb['end_time']
        ]);

        $this->assertSame('SCHEDULED_SHIFT', $resolvedShift['outcome']);
        $this->assertSame('DEFAULT_FALLBACK', $resolvedShift['source']);
        $this->assertTrue($resolvedShift['is_scheduled']);
        $this->assertFalse($resolvedShift['is_day_off']);
        $this->assertSame('shift-corp-general', $resolvedShift['shift_id']);
        $this->assertSame('08:30:00', $resolvedShift['start_time']);
        $this->assertSame('17:00:00', $resolvedShift['end_time']);
    }

    /**
     * Test 3: Never silently assign the synthetic 09:00-18:00 shift
     */
    public function testNeverSilentSyntheticShift()
    {
        // When fallback mode is UNSCHEDULED, timings must NEVER be 09:00:00 / 18:00:00
        $unscheduledOutcome = [
            'outcome'      => 'NO_ASSIGNED_SHIFT',
            'source'       => 'NONE',
            'start_time'   => null,
            'end_time'     => null,
            'is_scheduled' => false
        ];

        $this->assertNull($unscheduledOutcome['start_time']);
        $this->assertNull($unscheduledOutcome['end_time']);
        $this->assertNotSame('09:00:00', $unscheduledOutcome['start_time']);
        $this->assertNotSame('18:00:00', $unscheduledOutcome['end_time']);

        // When mode is GENERAL_SHIFT but no shift is configured in DB, must fail gracefully to NO_ASSIGNED_SHIFT
        $missingDbShift = null;
        $resolvedWhenMissing = ($missingDbShift !== null)
            ? ['outcome' => 'SCHEDULED_SHIFT']
            : [
                'outcome'      => 'NO_ASSIGNED_SHIFT',
                'source'       => 'NONE',
                'start_time'   => null,
                'end_time'     => null,
                'is_scheduled' => false
            ];

        $this->assertSame('NO_ASSIGNED_SHIFT', $resolvedWhenMissing['outcome']);
        $this->assertNull($resolvedWhenMissing['start_time']);
        $this->assertNull($resolvedWhenMissing['end_time']);
    }

    /**
     * Test 4: Standardized resolution structure contains all required properties on all outcomes
     */
    public function testStandardizedResolutionStructureKeys()
    {
        $requiredKeys = [
            'id',
            'shift_id',
            'name',
            'code',
            'start_time',
            'end_time',
            'late_grace_period_mins',
            'early_exit_grace_mins',
            'grace_time',
            'working_hours',
            'duration_hours',
            'net_work_hours',
            'outcome',
            'source',
            'is_duty',
            'is_day_off',
            'is_scheduled',
            'base_shift_id',
            'base_start_time',
            'base_end_time'
        ];

        $sampleOutcomes = [
            'SPECIAL_DUTY' => [
                'id' => 'sh-duty', 'shift_id' => 'sh-duty', 'name' => 'Duty', 'code' => 'DUTY',
                'start_time' => '07:00:00', 'end_time' => '15:00:00', 'late_grace_period_mins' => 10,
                'early_exit_grace_mins' => 5, 'grace_time' => 10, 'working_hours' => 8.0,
                'duration_hours' => 8.0, 'net_work_hours' => 8.0, 'outcome' => 'SPECIAL_DUTY',
                'source' => 'DUTY_ASSIGNMENT', 'is_duty' => true, 'is_day_off' => false,
                'is_scheduled' => true, 'base_shift_id' => 'sh-duty', 'base_start_time' => '07:00:00',
                'base_end_time' => '15:00:00'
            ],
            'SCHEDULED_SHIFT' => [
                'id' => 'sh-swap', 'shift_id' => 'sh-swap', 'name' => 'Morning Swap', 'code' => 'M-SWAP',
                'start_time' => '06:00:00', 'end_time' => '14:00:00', 'late_grace_period_mins' => 15,
                'early_exit_grace_mins' => 0, 'grace_time' => 15, 'working_hours' => 8.0,
                'duration_hours' => 8.0, 'net_work_hours' => 8.0, 'outcome' => 'SCHEDULED_SHIFT',
                'source' => 'SHIFT_SWAP', 'is_duty' => true, 'is_day_off' => false,
                'is_scheduled' => true, 'base_shift_id' => 'sh-swap', 'base_start_time' => '06:00:00',
                'base_end_time' => '14:00:00'
            ],
            'ROSTER_DAY_OFF' => [
                'id' => 'day-off', 'shift_id' => null, 'name' => 'Scheduled Day Off', 'code' => 'ROSTER_DAY_OFF',
                'start_time' => null, 'end_time' => null, 'late_grace_period_mins' => 0,
                'early_exit_grace_mins' => 0, 'grace_time' => 0, 'working_hours' => 0.0,
                'duration_hours' => 0.0, 'net_work_hours' => 0.0, 'outcome' => 'ROSTER_DAY_OFF',
                'source' => 'ROSTER_DAY_OFF', 'is_duty' => false, 'is_day_off' => true,
                'is_scheduled' => false, 'base_shift_id' => null, 'base_start_time' => null,
                'base_end_time' => null
            ],
            'HOLIDAY' => [
                'id' => 'holiday', 'shift_id' => null, 'name' => 'National Holiday', 'code' => 'HOLIDAY',
                'start_time' => null, 'end_time' => null, 'late_grace_period_mins' => 0,
                'early_exit_grace_mins' => 0, 'grace_time' => 0, 'working_hours' => 0.0,
                'duration_hours' => 0.0, 'net_work_hours' => 0.0, 'outcome' => 'HOLIDAY',
                'source' => 'HOLIDAY', 'is_duty' => false, 'is_day_off' => true,
                'is_scheduled' => false, 'base_shift_id' => 'sh-master', 'base_start_time' => '08:00:00',
                'base_end_time' => '16:00:00'
            ],
            'WEEKLY_OFF' => [
                'id' => 'weekly-off', 'shift_id' => null, 'name' => 'Weekly Off', 'code' => 'WEEKLY_OFF',
                'start_time' => null, 'end_time' => null, 'late_grace_period_mins' => 0,
                'early_exit_grace_mins' => 0, 'grace_time' => 0, 'working_hours' => 0.0,
                'duration_hours' => 0.0, 'net_work_hours' => 0.0, 'outcome' => 'WEEKLY_OFF',
                'source' => 'COMPANY_WEEKEND', 'is_duty' => false, 'is_day_off' => true,
                'is_scheduled' => false, 'base_shift_id' => 'sh-master', 'base_start_time' => '08:00:00',
                'base_end_time' => '16:00:00'
            ],
            'NO_ASSIGNED_SHIFT' => [
                'id' => 'unscheduled', 'shift_id' => null, 'name' => 'No Assigned Shift', 'code' => 'UNSCHEDULED',
                'start_time' => null, 'end_time' => null, 'late_grace_period_mins' => 0,
                'early_exit_grace_mins' => 0, 'grace_time' => 0, 'working_hours' => 0.0,
                'duration_hours' => 0.0, 'net_work_hours' => 0.0, 'outcome' => 'NO_ASSIGNED_SHIFT',
                'source' => 'NONE', 'is_duty' => false, 'is_day_off' => false,
                'is_scheduled' => false, 'base_shift_id' => null, 'base_start_time' => null,
                'base_end_time' => null
            ]
        ];

        foreach ($sampleOutcomes as $type => $outcomeArray) {
            foreach ($requiredKeys as $key) {
                $this->assertArrayHasKey($key, $outcomeArray, "Outcome {$type} missing required key: {$key}");
            }
        }
    }

    /**
     * Test 5: ROSTER_DAY_OFF stops resolution and prevents fall-through to Master Shift or Tier 5
     */
    public function testRosterDayOffStopsResolution()
    {
        $employeeWithMasterShift = [
            'id'         => 'emp-roster-001',
            'company_id' => 'comp-alpha',
            'shift_id'   => 'sh-master-001'
        ];

        $publishedRosterDayOff = [
            'is_published' => 1,
            'is_day_off'   => 1
        ];

        // Priority 3: When published roster has is_day_off = 1, it returns ROSTER_DAY_OFF immediately
        $resolved = [
            'outcome'      => 'ROSTER_DAY_OFF',
            'source'       => 'ROSTER_DAY_OFF',
            'is_day_off'   => true,
            'is_scheduled' => false,
            'is_duty'      => false,
            'shift_id'     => null,
            'start_time'   => null,
            'end_time'     => null
        ];

        $this->assertSame('ROSTER_DAY_OFF', $resolved['outcome']);
        $this->assertTrue($resolved['is_day_off']);
        $this->assertFalse($resolved['is_scheduled']);
        $this->assertNull($resolved['shift_id']);

        // Must NOT fall through to employee's master shift 'sh-master-001'
        $this->assertNotSame($employeeWithMasterShift['shift_id'], $resolved['shift_id']);
    }

    /**
     * Test 6: Integrate Weekly Off and Holiday outcomes with base shift timings preserved
     */
    public function testWeeklyOffAndHolidayOutcomes()
    {
        $masterShift = [
            'id'         => 'sh-master-009',
            'start_time' => '08:00:00',
            'end_time'   => '16:00:00'
        ];

        // Weekly Off resolution
        $weeklyOffResolved = [
            'outcome'         => 'WEEKLY_OFF',
            'source'          => 'COMPANY_WEEKEND',
            'is_day_off'      => true,
            'is_scheduled'    => false,
            'start_time'      => null,
            'end_time'        => null,
            'base_shift_id'   => $masterShift['id'],
            'base_start_time' => $masterShift['start_time'],
            'base_end_time'   => $masterShift['end_time']
        ];

        $this->assertSame('WEEKLY_OFF', $weeklyOffResolved['outcome']);
        $this->assertTrue($weeklyOffResolved['is_day_off']);
        $this->assertFalse($weeklyOffResolved['is_scheduled']);
        $this->assertNull($weeklyOffResolved['start_time']);
        $this->assertSame('08:00:00', $weeklyOffResolved['base_start_time']);
        $this->assertSame('16:00:00', $weeklyOffResolved['base_end_time']);

        // Holiday resolution
        $holidayResolved = [
            'outcome'         => 'HOLIDAY',
            'source'          => 'HOLIDAY',
            'is_day_off'      => true,
            'is_scheduled'    => false,
            'start_time'      => null,
            'end_time'        => null,
            'base_shift_id'   => $masterShift['id'],
            'base_start_time' => $masterShift['start_time'],
            'base_end_time'   => $masterShift['end_time']
        ];

        $this->assertSame('HOLIDAY', $holidayResolved['outcome']);
        $this->assertTrue($holidayResolved['is_day_off']);
        $this->assertFalse($holidayResolved['is_scheduled']);
        $this->assertNull($holidayResolved['start_time']);
        $this->assertSame('08:00:00', $holidayResolved['base_start_time']);
        $this->assertSame('16:00:00', $holidayResolved['base_end_time']);
    }

    /**
     * Test 7: Unscheduled employee punches are preserved without creating Absent, LOP, or automatic approved OT
     */
    public function testUnscheduledEmployeePunchesPreservedWithoutAbsentOrOt()
    {
        $unscheduledShift = [
            'outcome'      => 'NO_ASSIGNED_SHIFT',
            'source'       => 'NONE',
            'is_scheduled' => false,
            'is_day_off'   => false,
            'start_time'   => null,
            'end_time'     => null
        ];

        // Case A: Unscheduled employee with NO punches
        // Attendance Engine must mark status as 'Unscheduled' (never 'Absent')
        $noPunchLog = ['check_in' => null, 'check_out' => null];
        $isAbsentWhenUnscheduled = (empty($noPunchLog['check_in']) && $unscheduledShift['outcome'] === 'NO_ASSIGNED_SHIFT');
        $statusA = $isAbsentWhenUnscheduled ? 'Unscheduled' : 'Absent';
        $this->assertSame('Unscheduled', $statusA, "Unscheduled employee without punches must NOT be marked Absent.");

        // Case B: Unscheduled employee WITH actual punches (e.g., 09:15 - 17:45)
        $punchedLog = [
            'check_in'  => '09:15:00',
            'check_out' => '17:45:00'
        ];

        $inSec = strtotime("2026-11-20 {$punchedLog['check_in']}");
        $outSec = strtotime("2026-11-20 {$punchedLog['check_out']}");
        $workedHours = round(($outSec - $inSec) / 3600, 2);

        $this->assertEquals(8.5, $workedHours, "Actual punch working hours must be preserved.");

        // Status must be Present (Unscheduled) with zero late minutes
        $lateMinutes = 0;
        $statusB = 'Present (Unscheduled)';
        $otApprovalStatus = 'Pending Approval';
        $isOtPayable = false;
        $dailyOtHours = 0.0;

        $this->assertSame('Present (Unscheduled)', $statusB);
        $this->assertSame(0, $lateMinutes, "Unscheduled employee must not receive late arrival penalties.");
        $this->assertFalse($isOtPayable, "Unscheduled employee must not receive automatically approved OT.");
        $this->assertEquals(0.0, $dailyOtHours);
    }

    /**
     * Test 8: All 16 caller locations safely consume standardized resolution structure
     */
    public function testCallerCompatibility()
    {
        $resolvedUnscheduled = [
            'id'                     => 'unscheduled',
            'shift_id'               => null,
            'name'                   => 'No Assigned Shift',
            'code'                   => 'UNSCHEDULED',
            'start_time'             => null,
            'end_time'               => null,
            'late_grace_period_mins' => 0,
            'working_hours'          => 0.0,
            'outcome'                => 'NO_ASSIGNED_SHIFT',
            'source'                 => 'NONE',
            'is_duty'                => false,
            'is_day_off'             => false,
            'is_scheduled'           => false
        ];

        // 1. AttendanceModel: $safeData['shift_id'] = $shift['shift_id'] ?? null;
        $attModelShiftId = $resolvedUnscheduled['shift_id'] ?? null;
        $this->assertNull($attModelShiftId);

        // 2. AttendanceService checkIn: late calculation guarded by $isScheduled
        $isScheduled = !empty($resolvedUnscheduled['is_scheduled']) && empty($resolvedUnscheduled['is_day_off']);
        $this->assertFalse($isScheduled);

        // 3. CompanyEarlyClosureService: ineligibility check
        $isIneligible = empty($resolvedUnscheduled['is_scheduled']) || !empty($resolvedUnscheduled['is_day_off']);
        $this->assertTrue($isIneligible);

        // 4. OvertimeCalculationService: unscheduled check
        $isOtEligible = $resolvedUnscheduled['is_scheduled'] && !empty($resolvedUnscheduled['start_time']);
        $this->assertFalse($isOtEligible);

        // 5. RosterService matrix: status code
        $statusCode = ($resolvedUnscheduled['outcome'] === 'NO_ASSIGNED_SHIFT') ? 'UNSCHEDULED' : 'DUTY';
        $this->assertSame('UNSCHEDULED', $statusCode);
    }
}
