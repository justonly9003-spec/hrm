<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Controllers\Users\UserController;

class SecurityPasswordAndSecretHardeningTest extends TestCase
{
    /**
     * Verify that Auth config properly reads JWT_SECRET from environment
     * and fails to boot if missing in production.
     */
    public function testAuthConfigReadsJwtSecretFromEnvironment()
    {
        $oldEnv = getenv('CI_ENVIRONMENT');
        $oldJwt = getenv('JWT_SECRET');

        try {
            putenv('CI_ENVIRONMENT=development');
            putenv('JWT_SECRET=super_custom_test_jwt_secret_value_123');
            $_ENV['JWT_SECRET'] = 'super_custom_test_jwt_secret_value_123';

            $authConfig = new \Config\Auth();
            $this->assertEquals(
                'super_custom_test_jwt_secret_value_123',
                $authConfig->jwtSecret,
                'Auth config must populate jwtSecret from env(JWT_SECRET).'
            );
        } finally {
            if ($oldEnv !== false) {
                putenv("CI_ENVIRONMENT={$oldEnv}");
            } else {
                putenv('CI_ENVIRONMENT');
            }
            if ($oldJwt !== false) {
                putenv("JWT_SECRET={$oldJwt}");
                $_ENV['JWT_SECRET'] = $oldJwt;
            } else {
                putenv('JWT_SECRET');
                unset($_ENV['JWT_SECRET']);
            }
        }
    }

    /**
     * Verify that Auth config throws RuntimeException in production when JWT_SECRET is empty.
     */
    public function testAuthConfigFailsToBootInProductionWhenJwtSecretMissing()
    {
        $oldEnv = getenv('CI_ENVIRONMENT');
        $oldJwt = getenv('JWT_SECRET');

        try {
            putenv('CI_ENVIRONMENT=production');
            putenv('JWT_SECRET=');
            unset($_ENV['JWT_SECRET']);

            $this->expectException(\RuntimeException::class);
            $this->expectExceptionMessage('CRITICAL SECURITY CONFIGURATION ERROR: JWT_SECRET');

            new \Config\Auth();
        } finally {
            if ($oldEnv !== false) {
                putenv("CI_ENVIRONMENT={$oldEnv}");
            } else {
                putenv('CI_ENVIRONMENT');
            }
            if ($oldJwt !== false) {
                putenv("JWT_SECRET={$oldJwt}");
                $_ENV['JWT_SECRET'] = $oldJwt;
            } else {
                putenv('JWT_SECRET');
                unset($_ENV['JWT_SECRET']);
            }
        }
    }

    /**
     * Verify password strength rules in UserController
     */
    public function testUserControllerPasswordStrengthValidation()
    {
        // Too short (< 10)
        $this->assertNotNull(UserController::validatePasswordStrength('Short1!'));

        // Missing uppercase
        $this->assertNotNull(UserController::validatePasswordStrength('lowercase123!@#'));

        // Missing lowercase
        $this->assertNotNull(UserController::validatePasswordStrength('UPPERCASE123!@#'));

        // Missing numbers
        $this->assertNotNull(UserController::validatePasswordStrength('NoNumbersHere!@#'));

        // Missing special characters
        $this->assertNotNull(UserController::validatePasswordStrength('NoSpecialChars123'));

        // Strong password meeting all criteria
        $this->assertNull(UserController::validatePasswordStrength('StrongP@ssw0rd!2026'));
        $this->assertNull(UserController::validatePasswordStrength('C0mpl3x#P@ssw0rd!'));
    }

    /**
     * Verify that generated secure temporary passwords satisfy all strength rules
     */
    public function testUserControllerGenerateSecureTemporaryPassword()
    {
        for ($i = 0; $i < 20; $i++) {
            $tempPassword = UserController::generateSecureTemporaryPassword();

            $this->assertGreaterThanOrEqual(12, strlen($tempPassword));
            $this->assertNull(
                UserController::validatePasswordStrength($tempPassword),
                "Generated temporary password '{$tempPassword}' must satisfy all strength criteria."
            );
        }
    }

    /**
     * Verify that Seeders refuse to run when CI_ENVIRONMENT is production.
     */
    public function testSeedersRefuseToRunInProduction()
    {
        $oldEnv = getenv('CI_ENVIRONMENT');
        putenv('CI_ENVIRONMENT=production');
        $_ENV['CI_ENVIRONMENT'] = 'production';

        try {
            $seederClasses = [
                \App\Database\Seeds\EmployeeAndUserSeeder::class,
                \App\Database\Seeds\FreshSoftwareOwnerSeeder::class,
                \App\Database\Seeds\EmployeeTestSeeder::class,
                \App\Database\Seeds\DatabaseSeeder::class,
            ];

            foreach ($seederClasses as $class) {
                $refused = false;
                try {
                    $instance = new $class(new \Config\Database());
                    $instance->run();
                } catch (\RuntimeException $e) {
                    if (str_contains($e->getMessage(), 'Security Violation') && str_contains($e->getMessage(), 'production')) {
                        $refused = true;
                    }
                }
                $this->assertTrue($refused, "Seeder {$class} must throw RuntimeException refusing to run in production.");
            }
        } finally {
            if ($oldEnv !== false) {
                putenv("CI_ENVIRONMENT={$oldEnv}");
                $_ENV['CI_ENVIRONMENT'] = $oldEnv;
            } else {
                putenv('CI_ENVIRONMENT=development');
                $_ENV['CI_ENVIRONMENT'] = 'development';
            }
        }
    }

    /**
     * Verify that source code contains no hardcoded backdoor passwords in the targeted files.
     */
    public function testSourceCodeHasNoHardcodedBackdoorsInTargetFiles()
    {
        $baseDir = dirname(__DIR__, 2) . '/';

        $authContent = file_get_contents($baseDir . 'app/Config/Auth.php');
        $this->assertStringNotContainsString('enterprise_hcm_super_secure_jwt_secret_key_2026', $authContent);

        $userCtrlContent = file_get_contents($baseDir . 'app/Controllers/Users/UserController.php');
        $this->assertStringNotContainsString('DefaultPass123!', $userCtrlContent);

        $freshSeeder = file_get_contents($baseDir . 'app/Database/Seeds/FreshSoftwareOwnerSeeder.php');
        $this->assertStringNotContainsString('password_hash(\'admin123\'', $freshSeeder);
        $this->assertStringNotContainsString('password: admin123', $freshSeeder);

        $empTestSeeder = file_get_contents($baseDir . 'app/Database/Seeds/EmployeeTestSeeder.php');
        $this->assertStringNotContainsString('password_hash(\'admin123\'', $empTestSeeder);

        $empUserSeeder = file_get_contents($baseDir . 'app/Database/Seeds/EmployeeAndUserSeeder.php');
        $this->assertStringNotContainsString('password_hash(\'123456\'', $empUserSeeder);
    }

    /**
     * Verify that UserModel::getUserWithEmployeeContext explicitly projects columns
     * and never queries or returns password_hash, 2FA secrets, or reset tokens.
     */
    public function testUserModelGetUserWithEmployeeContextNeverExposesPasswordHashOrSecrets()
    {
        $baseDir = dirname(__DIR__, 2) . '/';
        $userModelSrc = file_get_contents($baseDir . 'app/Models/UserModel.php');

        // 1. Invariant: users.* must not be used in getUserWithEmployeeContext
        $this->assertStringNotContainsString(
            "\$select = 'users.*",
            $userModelSrc,
            "UserModel::getUserWithEmployeeContext must NOT use 'users.*'."
        );

        // 2. Sensitive columns must be explicitly blacklisted from query selection
        $this->assertStringContainsString("'password_hash'", $userModelSrc);
        $this->assertStringContainsString("'two_factor_secret'", $userModelSrc);
        $this->assertStringContainsString("'reset_token'", $userModelSrc);

        // 3. Verify programmatic stripping of credentials on raw user payload
        $dummyRow = [
            'id'                  => 'usr-test-123',
            'username'            => 'janedoe',
            'email'               => 'jane@example.com',
            'password_hash'       => '$2y$10$abcdefghijklmnopqrstuvwxyz1234567890',
            'password'            => 'PlainTextSecret!',
            'two_factor_secret'   => 'SECRET2FAKEYXYZ',
            'totp_secret'         => 'TOTPSECRET123',
            'reset_token'         => 'RESETTOKENXYZ',
            'reset_hash'          => 'RESETHASHABC',
            'remember_token'      => 'REMEMBERTOKEN',
            'token'               => 'BEARERTOKEN',
            'secret'              => 'APISECRET',
            'role_name'           => 'Employee',
            'first_name'          => 'Jane',
            'last_name'           => 'Doe',
        ];

        $sensitiveFields = [
            'password_hash',
            'password',
            'two_factor_secret',
            'totp_secret',
            'reset_token',
            'reset_hash',
            'remember_token',
            'token',
            'secret',
        ];

        // Simulate the post-fetch sanitization in UserModel::getUserWithEmployeeContext
        foreach ($sensitiveFields as $field) {
            unset($dummyRow[$field]);
        }

        foreach ($sensitiveFields as $field) {
            $this->assertArrayNotHasKey(
                $field,
                $dummyRow,
                "Sanitized user record must never contain {$field}."
            );
        }
    }

    /**
     * Verify that BaseController restricts personaUsers exclusively to platform admins (Software App Admin).
     */
    public function testBaseControllerRestrictsPersonaUsersToPlatformAdminOnly()
    {
        $baseDir = dirname(__DIR__, 2) . '/';
        $baseCtrlSrc = file_get_contents($baseDir . 'app/Controllers/BaseController.php');

        // Check that personaUsers query is strictly gated behind isSoftwareAppAdmin()
        $this->assertMatchesRegularExpression(
            '/if\s*\(\$this->isSoftwareAppAdmin\(\)\)\s*\{\s*try\s*\{\s*\$personaUsers\s*=/s',
            $baseCtrlSrc,
            'BaseController must wrap personaUsers query strictly inside if ($this->isSoftwareAppAdmin()).'
        );

        // Simulate tenant roles and verify they are never treated as platform admin
        $permService = new \App\Services\PermissionService();

        $nonPlatformRoles = [
            ['role_name' => 'Employee', 'role_code' => 'employee', 'company_id' => 'comp-1', 'role_company_id' => 'comp-1', 'role_is_system' => 0],
            ['role_name' => 'HR Manager', 'role_code' => 'hr_manager', 'company_id' => 'comp-1', 'role_company_id' => 'comp-1', 'role_is_system' => 0],
            ['role_name' => 'Company Admin', 'role_code' => 'company_admin', 'company_id' => 'comp-1', 'role_company_id' => 'comp-1', 'role_is_system' => 0],
            ['role_name' => 'Branch Manager', 'role_code' => 'branch_manager', 'company_id' => 'comp-1', 'role_company_id' => 'comp-1', 'role_is_system' => 0],
        ];

        foreach ($nonPlatformRoles as $roleCtx) {
            $isPlatformAdmin = (
                empty($roleCtx['company_id']) &&
                empty($roleCtx['role_company_id']) &&
                (int)($roleCtx['role_is_system'] ?? 0) === 1 &&
                $permService->canonicalizeRole($roleCtx['role_code']) === 'software_app_admin'
            );
            $this->assertFalse(
                $isPlatformAdmin,
                "Role '{$roleCtx['role_name']}' must NOT be recognized as platform admin."
            );

            // For non-platform admins, personaUsers must resolve to empty array
            $personaUsers = $isPlatformAdmin ? ['mock_user_1', 'mock_user_2'] : [];
            $this->assertEmpty($personaUsers, "personaUsers must be empty for non-platform admin role '{$roleCtx['role_name']}'.");
        }
    }

    /**
     * Verify that view data and currentUser never contain password_hash.
     */
    public function testBaseControllerRenderViewNeverPassesPasswordHashToViews()
    {
        $baseDir = dirname(__DIR__, 2) . '/';
        $baseCtrlSrc = file_get_contents($baseDir . 'app/Controllers/BaseController.php');

        // Check that BaseController strips password_hash and tokens before view dispatch
        $this->assertStringContainsString("unset(\$this->currentUser['password_hash']", $baseCtrlSrc);
        $this->assertStringContainsString("unset(\$viewCurrentUser['password_hash']", $baseCtrlSrc);
        $this->assertStringContainsString("unset(\$data['currentUser']['password_hash']", $baseCtrlSrc);

        // Simulate incoming data array to renderView containing residual password_hash
        $dirtyData = [
            'currentUser' => [
                'id'            => 'usr-001',
                'username'      => 'alice',
                'password_hash' => '$2y$10$abcdefghijklmnopqrstuvwxyz1234567890',
                'totp_secret'   => 'TOPSECRET',
            ],
            'user' => [
                'id'            => 'usr-001',
                'password_hash' => '$2y$10$abcdefghijklmnopqrstuvwxyz1234567890',
            ],
        ];

        $safeKeys = ['password_hash', 'password', 'two_factor_secret', 'totp_secret', 'reset_token', 'reset_hash'];

        if (isset($dirtyData['currentUser']) && is_array($dirtyData['currentUser'])) {
            foreach ($safeKeys as $k) {
                unset($dirtyData['currentUser'][$k]);
            }
        }
        if (isset($dirtyData['user']) && is_array($dirtyData['user'])) {
            foreach ($safeKeys as $k) {
                unset($dirtyData['user'][$k]);
            }
        }

        $this->assertArrayNotHasKey('password_hash', $dirtyData['currentUser']);
        $this->assertArrayNotHasKey('totp_secret', $dirtyData['currentUser']);
        $this->assertArrayNotHasKey('password_hash', $dirtyData['user']);

        // Assert rendered serialized JSON/string has no password_hash
        $serialized = json_encode($dirtyData);
        $this->assertStringNotContainsString('password_hash', $serialized);
    }
}
