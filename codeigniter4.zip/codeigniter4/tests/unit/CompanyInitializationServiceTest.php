<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class CompanyInitializationServiceTest extends TestCase
{
    public function testRequiredMasterDataCategoriesList()
    {
        $expectedCategories = [
            'departments',
            'designations',
            'salary_grades',
            'security_policies',
            'work_shifts',
            'holidays',
            'employment_types',
            'leave_types',
        ];

        $serviceClass = '\App\Services\CompanyInitializationService';
        $this->assertTrue(class_exists($serviceClass), "CompanyInitializationService class must exist.");

        $reflection = new \ReflectionClass($serviceClass);
        $this->assertTrue($reflection->hasMethod('initializeCompany'), "Service must have initializeCompany method.");
        $this->assertTrue($reflection->hasMethod('initializeDepartments'), "Service must have initializeDepartments method.");
        $this->assertTrue($reflection->hasMethod('initializeDesignations'), "Service must have initializeDesignations method.");
        $this->assertTrue($reflection->hasMethod('initializeSalaryGrades'), "Service must have initializeSalaryGrades method.");
        $this->assertTrue($reflection->hasMethod('initializeSecurityPolicies'), "Service must have initializeSecurityPolicies method.");
        $this->assertTrue($reflection->hasMethod('initializeWorkShifts'), "Service must have initializeWorkShifts method.");
        $this->assertTrue($reflection->hasMethod('initializeHolidayCalendar'), "Service must have initializeHolidayCalendar method.");
        $this->assertTrue($reflection->hasMethod('initializeEmploymentTypes'), "Service must have initializeEmploymentTypes method.");
        $this->assertTrue($reflection->hasMethod('initializeLeaveTypesAndQuotas'), "Service must have initializeLeaveTypesAndQuotas method.");
    }

    public function testTenantIsolationAssertion()
    {
        $tenantA = 'COMP-101';
        $tenantB = 'COMP-102';

        $recordA = ['company_id' => $tenantA, 'code' => 'HR', 'name' => 'Human Resources'];
        $recordB = ['company_id' => $tenantB, 'code' => 'HR', 'name' => 'Human Resources'];

        $this->assertNotEquals($recordA['company_id'], $recordB['company_id']);
        $this->assertEquals($tenantA, $recordA['company_id']);
        $this->assertEquals($tenantB, $recordB['company_id']);
    }

    public function testIdempotencyLogicContracts()
    {
        // Simulate checking existing codes before insertion
        $existingCodes = ['EXEC', 'HR', 'FIN'];
        $defaultDepts = ['EXEC', 'HR', 'FIN', 'IT', 'OPS', 'MKT'];

        $created = [];
        $skipped = [];

        foreach ($defaultDepts as $dept) {
            if (in_array($dept, $existingCodes, true)) {
                $skipped[] = $dept;
            } else {
                $created[] = $dept;
                $existingCodes[] = $dept;
            }
        }

        $this->assertEquals(['IT', 'OPS', 'MKT'], $created);
        $this->assertEquals(['EXEC', 'HR', 'FIN'], $skipped);

        // Run second time
        $secondCreated = [];
        $secondSkipped = [];
        foreach ($defaultDepts as $dept) {
            if (in_array($dept, $existingCodes, true)) {
                $secondSkipped[] = $dept;
            } else {
                $secondCreated[] = $dept;
            }
        }

        $this->assertEmpty($secondCreated, "Second initialization must NOT insert any duplicate records.");
        $this->assertEquals($defaultDepts, $secondSkipped, "All default items must be safely skipped on second run.");
    }
}
