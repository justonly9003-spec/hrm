<?php

namespace Tests\Unit\Reports;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use Config\Database;
use App\Services\Concerns\JoinsActiveSalary;
use App\Services\PayrollReportService;
use App\Services\TaxReportService;
use App\Services\LoanAdvanceReportService;
use App\Services\OvertimeBonusReportService;
use ReflectionClass;

class TestServiceHarness
{
    use JoinsActiveSalary;

    protected $db;

    public function __construct($db)
    {
        $this->db = $db;
    }

    public function publicActiveSalaryJoin(string $empAlias = 'e', string $salAlias = 'es'): string
    {
        return $this->getActiveSalaryJoin($empAlias, $salAlias);
    }
}

/**
 * Characterization test for JoinsActiveSalary trait across:
 * - App\Services\PayrollReportService
 * - App\Services\TaxReportService
 * - App\Services\LoanAdvanceReportService
 * - App\Services\OvertimeBonusReportService
 */
class JoinsActiveSalaryCharacterizationTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected $migrate = false;
    protected $db;
    protected string $companyId = 'comp-test-jas-001';
    protected string $employeeId = 'emp-test-jas-001';

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->seedFixtures();
    }

    protected function tearDown(): void
    {
        $this->cleanFixtures();
        parent::tearDown();
    }

    protected function seedFixtures(): void
    {
        $this->cleanFixtures();

        // Ensure company exists
        if ($this->db->tableExists('companies')) {
            $this->db->table('companies')->ignore(true)->insert([
                'id'         => $this->companyId,
                'name'       => 'JAS Test Company',
                'created_at' => date('Y-m-d H:i:s'),
            ]);
        }

        // Ensure employee exists
        if ($this->db->tableExists('employees')) {
            $this->db->table('employees')->ignore(true)->insert([
                'id'            => $this->employeeId,
                'company_id'    => $this->companyId,
                'employee_code' => 'JAS-001',
                'first_name'    => 'SalaryJoin',
                'last_name'     => 'Tester',
                'status'        => 'Active',
                'joining_date'  => '2023-01-01',
                'created_at'    => date('Y-m-d H:i:s'),
            ]);
        }

        // Insert two employee_salaries rows: 1 Inactive (old), 1 Active (current)
        if ($this->db->tableExists('employee_salaries')) {
            $fields = $this->db->getFieldNames('employee_salaries');

            // Older inactive salary
            $oldSalary = [
                'id'             => 'es-old-' . bin2hex(random_bytes(4)),
                'company_id'     => $this->companyId,
                'employee_id'    => $this->employeeId,
                'base_amount'    => 50000.00,
                'effective_from' => '2023-01-01',
                'effective_to'   => '2023-12-31',
                'created_at'     => date('Y-m-d H:i:s'),
            ];
            if (in_array('status', $fields, true)) {
                $oldSalary['status'] = 'Inactive';
            }
            if (in_array('is_active', $fields, true)) {
                $oldSalary['is_active'] = 0;
            }
            $this->db->table('employee_salaries')->insert($oldSalary);

            // Current active salary
            $activeSalary = [
                'id'             => 'es-act-' . bin2hex(random_bytes(4)),
                'company_id'     => $this->companyId,
                'employee_id'    => $this->employeeId,
                'base_amount'    => 75000.00,
                'effective_from' => '2024-01-01',
                'effective_to'   => null,
                'created_at'     => date('Y-m-d H:i:s'),
            ];
            if (in_array('status', $fields, true)) {
                $activeSalary['status'] = 'Active';
            }
            if (in_array('is_active', $fields, true)) {
                $activeSalary['is_active'] = 1;
            }
            $this->db->table('employee_salaries')->insert($activeSalary);
        }
    }

    protected function cleanFixtures(): void
    {
        if ($this->db->tableExists('employee_salaries')) {
            $this->db->table('employee_salaries')->where('company_id', $this->companyId)->delete();
        }
        if ($this->db->tableExists('employees')) {
            $this->db->table('employees')->where('company_id', $this->companyId)->delete();
        }
        if ($this->db->tableExists('companies')) {
            $this->db->table('companies')->where('id', $this->companyId)->delete();
        }
    }

    protected function invokeGetActiveSalaryJoin(object $service, string $empAlias = 'e', string $salAlias = 'es'): string
    {
        $ref = new ReflectionClass($service);
        $method = $ref->getMethod('getActiveSalaryJoin');
        $method->setAccessible(true);
        return $method->invoke($service, $empAlias, $salAlias);
    }

    public function testTraitGeneratesExpectedCondition()
    {
        $harness = new TestServiceHarness($this->db);
        $condition = $harness->publicActiveSalaryJoin('e', 'es');

        $this->assertNotEmpty($condition);
        $this->assertStringContainsString('es.employee_id = e.id', $condition);

        $fields = $this->db->getFieldNames('employee_salaries');
        if (in_array('status', $fields, true)) {
            $this->assertEquals("es.employee_id = e.id AND (es.status = 'Active' OR es.status = 'active')", $condition);
        } elseif (in_array('is_active', $fields, true)) {
            $this->assertEquals("es.employee_id = e.id AND es.is_active = 1", $condition);
        } else {
            $this->assertEquals("es.employee_id = e.id", $condition);
        }

        // Custom aliases
        $custom = $harness->publicActiveSalaryJoin('emp', 'sal');
        $this->assertStringContainsString('sal.employee_id = emp.id', $custom);
    }

    public function testPayrollReportServiceActiveSalaryJoin()
    {
        $service = new PayrollReportService();
        $joinSql = $this->invokeGetActiveSalaryJoin($service, 'e', 'es');

        $builder = $this->db->table('employees e')
            ->select('e.id as emp_id, es.base_amount')
            ->join('employee_salaries es', $joinSql, 'inner')
            ->where('e.id', $this->employeeId);

        $results = $builder->get()->getResultArray();

        $this->assertCount(1, $results, 'Join condition must select ONLY the active salary record');
        $this->assertEquals(75000.00, (float)$results[0]['base_amount']);
    }

    public function testTaxReportServiceActiveSalaryJoin()
    {
        $service = new TaxReportService();
        $joinSql = $this->invokeGetActiveSalaryJoin($service, 'e', 'es');

        $builder = $this->db->table('employees e')
            ->select('e.id as emp_id, es.base_amount')
            ->join('employee_salaries es', $joinSql, 'inner')
            ->where('e.id', $this->employeeId);

        $results = $builder->get()->getResultArray();

        $this->assertCount(1, $results, 'TaxReportService active salary join must match only the active row');
        $this->assertEquals(75000.00, (float)$results[0]['base_amount']);
    }

    public function testLoanAdvanceReportServiceActiveSalaryJoin()
    {
        $service = new LoanAdvanceReportService();
        $joinSql = $this->invokeGetActiveSalaryJoin($service, 'e', 'es');

        $builder = $this->db->table('employees e')
            ->select('e.id as emp_id, es.base_amount')
            ->join('employee_salaries es', $joinSql, 'inner')
            ->where('e.id', $this->employeeId);

        $results = $builder->get()->getResultArray();

        $this->assertCount(1, $results, 'LoanAdvanceReportService active salary join must match only the active row');
        $this->assertEquals(75000.00, (float)$results[0]['base_amount']);
    }

    public function testOvertimeBonusReportServiceActiveSalaryJoin()
    {
        $service = new OvertimeBonusReportService();
        $joinSql = $this->invokeGetActiveSalaryJoin($service, 'e', 'es');

        $builder = $this->db->table('employees e')
            ->select('e.id as emp_id, es.base_amount')
            ->join('employee_salaries es', $joinSql, 'inner')
            ->where('e.id', $this->employeeId);

        $results = $builder->get()->getResultArray();

        $this->assertCount(1, $results, 'OvertimeBonusReportService active salary join must match only the active row');
        $this->assertEquals(75000.00, (float)$results[0]['base_amount']);
    }
}
