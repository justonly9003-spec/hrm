<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use App\Filters\AuthFilter;
use App\Models\EmployeeModel;
use App\Models\UserModel;
use Config\Database;

/**
 * DB-backed feature tests for AuthFilter Session Invalidation and Employee Lifecycle Status.
 *
 * Requirements:
 * 1. Create a user linked to an employee, put the user id in a session.
 * 2. Active employee session must pass through AuthFilter::before() unchanged (returns null, session intact).
 * 3. Soft-delete the employee (deleted_at set): AuthFilter destroys session and returns 403 JSON for AJAX or redirect to /auth/login for non-AJAX.
 * 4. Set employee status to Terminated: AuthFilter destroys session and returns 403 JSON for AJAX or redirect to /auth/login for non-AJAX.
 * 5. Deactivated user (users.status = 'Inactive') destroys session and rejects request.
 */
class EmployeeSessionInvalidationTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected static bool $schemaInitialized = false;

    protected string $companyId = 'comp-sess-test-01';
    protected string $branchId  = 'branch-sess-test-01';
    protected string $deptId    = 'dept-sess-test-01';
    protected string $desgId    = 'desg-sess-test-01';
    protected string $roleId    = 'role-sess-emp';
    protected string $userId    = 'usr-sess-target-01';
    protected string $empId     = 'emp-sess-target-01';

    protected string $otherUserId = 'usr-sess-active-02';
    protected string $otherEmpId  = 'emp-sess-active-02';

    public static function setUpBeforeClass(): void
    {
        parent::setUpBeforeClass();
        static::ensureSchema();
    }

    public static function registerSqliteFunctions($db): void
    {
        try {
            $rawConn = $db->connID ?? null;
            if ($rawConn instanceof \SQLite3) {
                $rawConn->createFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->createFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            } elseif (is_object($rawConn) && method_exists($rawConn, 'sqliteCreateFunction')) {
                $rawConn->sqliteCreateFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->sqliteCreateFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            }
        } catch (\Throwable $e) {
            // ignore
        }
    }

    protected static function ensureSchema(): void
    {
        $db = Database::connect();
        static::registerSqliteFunctions($db);

        $schemaFile = __DIR__ . '/Rules/schema.sqlite.sql';
        if (file_exists($schemaFile)) {
            $sql = file_get_contents($schemaFile);
            $statements = array_filter(array_map('trim', explode(';', $sql)));
            foreach ($statements as $stmt) {
                if (!empty($stmt)) {
                    try {
                        $db->query($stmt);
                    } catch (\Throwable $e) {
                        // ignore
                    }
                }
            }
        }

        static::$schemaInitialized = true;
    }

    protected function setUp(): void
    {
        parent::setUp();
        static::ensureSchema();

        $db = Database::connect();
        static::registerSqliteFunctions($db);

        // Seed Company
        $db->table('companies')->replace([
            'id'     => $this->companyId,
            'name'   => 'Session Invalidation Test Corp',
            'code'   => 'SITC',
            'status' => 'Active',
        ]);

        // Seed Branch, Department, Designation
        $db->table('branches')->replace([
            'id'         => $this->branchId,
            'company_id' => $this->companyId,
            'name'       => 'Session Main Branch',
            'code'       => 'SMB',
            'status'     => 'Active',
        ]);

        $db->table('departments')->replace([
            'id'         => $this->deptId,
            'company_id' => $this->companyId,
            'name'       => 'Engineering',
            'code'       => 'ENG-SESS',
            'status'     => 'Active',
        ]);

        $db->table('designations')->replace([
            'id'         => $this->desgId,
            'company_id' => $this->companyId,
            'name'       => 'Software Developer',
            'code'       => 'DEV-SESS',
            'status'     => 'Active',
        ]);

        // Seed Role: Employee
        $db->table('roles')->replace([
            'id'         => $this->roleId,
            'company_id' => $this->companyId,
            'name'       => 'Employee',
            'code'       => 'employee',
            'status'     => 'Active',
            'is_system'  => 1,
        ]);

        // Clean up test records
        $db->table('employees')->whereIn('id', [$this->empId, $this->otherEmpId])->delete();
        $db->table('users')->whereIn('id', [$this->userId, $this->otherUserId])->delete();

        // Seed Target Employee (Active, not soft-deleted)
        $db->table('employees')->insert([
            'id'                   => $this->empId,
            'company_id'           => $this->companyId,
            'branch_id'            => $this->branchId,
            'department_id'        => $this->deptId,
            'designation_id'       => $this->desgId,
            'employee_code'        => 'EMP-SESS-01',
            'first_name'           => 'Alice',
            'last_name'            => 'SessionTest',
            'email'                => 'alice.session@test.local',
            'basic_salary'         => 45000.00,
            'gross_salary'         => 45000.00,
            'status'               => EmployeeModel::STATUS_ACTIVE,
            'joining_date'         => '2025-01-01',
            'deleted_at'           => null,
            'created_at'           => date('Y-m-d H:i:s'),
        ]);

        // Seed User linked to Target Employee
        $db->table('users')->insert([
            'id'                   => $this->userId,
            'company_id'           => $this->companyId,
            'branch_id'            => $this->branchId,
            'role_id'              => $this->roleId,
            'employee_id'          => $this->empId,
            'username'             => 'alice_session',
            'email'                => 'alice.session@test.local',
            'status'               => UserModel::STATUS_ACTIVE,
            'must_change_password' => 0,
            'created_at'           => date('Y-m-d H:i:s'),
        ]);

        // Seed Second (Coworker) Employee & User
        $db->table('employees')->insert([
            'id'                   => $this->otherEmpId,
            'company_id'           => $this->companyId,
            'branch_id'            => $this->branchId,
            'department_id'        => $this->deptId,
            'designation_id'       => $this->desgId,
            'employee_code'        => 'EMP-SESS-02',
            'first_name'           => 'Bob',
            'last_name'            => 'ActiveCoworker',
            'email'                => 'bob.coworker@test.local',
            'basic_salary'         => 48000.00,
            'gross_salary'         => 48000.00,
            'status'               => EmployeeModel::STATUS_ACTIVE,
            'joining_date'         => '2025-01-01',
            'deleted_at'           => null,
            'created_at'           => date('Y-m-d H:i:s'),
        ]);

        $db->table('users')->insert([
            'id'                   => $this->otherUserId,
            'company_id'           => $this->companyId,
            'branch_id'            => $this->branchId,
            'role_id'              => $this->roleId,
            'employee_id'          => $this->otherEmpId,
            'username'             => 'bob_active',
            'email'                => 'bob.coworker@test.local',
            'status'               => UserModel::STATUS_ACTIVE,
            'must_change_password' => 0,
            'created_at'           => date('Y-m-d H:i:s'),
        ]);

        // Reset URI path to dashboard (a protected endpoint requiring auth)
        service('uri')->setPath('dashboard');
    }

    /**
     * Helper to populate user session
     */
    protected function initializeSession(string $userId, string $empId): void
    {
        $session = \Config\Services::session();
        $session->set([
            'id'          => $userId,
            'user_id'     => $userId,
            'username'    => 'alice_session',
            'company_id'  => $this->companyId,
            'branch_id'   => $this->branchId,
            'role_id'     => $this->roleId,
            'role_code'   => 'employee',
            'employee_id' => $empId,
        ]);
    }

    /**
     * Test 1: Active employee's session passes AuthFilter without interception
     */
    public function testActiveEmployeeSessionPassesAuthFilter()
    {
        $this->initializeSession($this->userId, $this->empId);

        $request = \Config\Services::request();
        $authFilter = new AuthFilter();

        $result = $authFilter->before($request);

        // When permitted, before() returns null
        $this->assertNull($result, 'Active employee request must pass through AuthFilter without early return');

        $session = \Config\Services::session();
        $this->assertTrue($session->has('user_id'), 'Session must remain intact for active employee');
        $this->assertEquals($this->userId, $session->get('user_id'));
    }

    /**
     * Test 2: Soft-deleted employee destroys session and returns 403 JSON for AJAX
     */
    public function testSoftDeletedEmployeeDestroysSessionAndReturns403JsonForAjax()
    {
        // Soft delete the employee
        $db = Database::connect();
        $db->table('employees')->where('id', $this->empId)->update([
            'deleted_at' => date('Y-m-d H:i:s'),
            'status'     => EmployeeModel::STATUS_ACTIVE,
        ]);

        $this->initializeSession($this->userId, $this->empId);

        $_SERVER['HTTP_X_REQUESTED_WITH'] = 'xmlhttprequest';
        $request = \Config\Services::request();
        $request->setHeader('X-Requested-With', 'XMLHttpRequest');

        $authFilter = new AuthFilter();
        $response = $authFilter->before($request);

        $this->assertInstanceOf(\CodeIgniter\HTTP\ResponseInterface::class, $response);
        $this->assertEquals(403, $response->getStatusCode());

        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success'] ?? true);
        $this->assertStringContainsString('deleted', strtolower($body['message'] ?? ''));

        // Verify session was destroyed
        $session = \Config\Services::session();
        $this->assertFalse($session->has('user_id'), 'Session must be destroyed when employee is soft-deleted');
    }

    /**
     * Test 3: Soft-deleted employee destroys session and redirects to /auth/login for non-AJAX
     */
    public function testSoftDeletedEmployeeDestroysSessionAndRedirectsToLoginForNonAjax()
    {
        $db = Database::connect();
        $db->table('employees')->where('id', $this->empId)->update([
            'deleted_at' => date('Y-m-d H:i:s'),
            'status'     => EmployeeModel::STATUS_ACTIVE,
        ]);

        $this->initializeSession($this->userId, $this->empId);

        unset($_SERVER['HTTP_X_REQUESTED_WITH']);
        $request = \Config\Services::request();

        $authFilter = new AuthFilter();
        $response = $authFilter->before($request);

        $this->assertInstanceOf(\CodeIgniter\HTTP\ResponseInterface::class, $response);

        // Verify redirect
        $location = $response->getHeaderLine('Location');
        $isRedirect = ($response instanceof \CodeIgniter\HTTP\RedirectResponse) || !empty($location) || in_array($response->getStatusCode(), [301, 302, 303, 307], true);
        $this->assertTrue($isRedirect, 'Non-AJAX request must be redirected');
        $this->assertStringContainsString('login', strtolower($location ?: 'login'));

        // Verify session was destroyed
        $session = \Config\Services::session();
        $this->assertFalse($session->has('user_id'), 'Session must be destroyed when employee is soft-deleted');
    }

    /**
     * Test 4: Terminated employee destroys session and returns 403 JSON for AJAX
     */
    public function testTerminatedEmployeeDestroysSessionAndReturns403JsonForAjax()
    {
        // Mark employee as Terminated
        $db = Database::connect();
        $db->table('employees')->where('id', $this->empId)->update([
            'deleted_at' => null,
            'status'     => EmployeeModel::STATUS_TERMINATED,
        ]);

        $this->initializeSession($this->userId, $this->empId);

        $_SERVER['HTTP_X_REQUESTED_WITH'] = 'xmlhttprequest';
        $request = \Config\Services::request();
        $request->setHeader('X-Requested-With', 'XMLHttpRequest');

        $authFilter = new AuthFilter();
        $response = $authFilter->before($request);

        $this->assertInstanceOf(\CodeIgniter\HTTP\ResponseInterface::class, $response);
        $this->assertEquals(403, $response->getStatusCode());

        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success'] ?? true);
        $this->assertStringContainsString('terminated', strtolower($body['message'] ?? ''));

        // Verify session was destroyed
        $session = \Config\Services::session();
        $this->assertFalse($session->has('user_id'), 'Session must be destroyed when employee is terminated');
    }

    /**
     * Test 5: Terminated employee destroys session and redirects to /auth/login for non-AJAX
     */
    public function testTerminatedEmployeeDestroysSessionAndRedirectsToLoginForNonAjax()
    {
        $db = Database::connect();
        $db->table('employees')->where('id', $this->empId)->update([
            'deleted_at' => null,
            'status'     => EmployeeModel::STATUS_TERMINATED,
        ]);

        $this->initializeSession($this->userId, $this->empId);

        unset($_SERVER['HTTP_X_REQUESTED_WITH']);
        $request = \Config\Services::request();

        $authFilter = new AuthFilter();
        $response = $authFilter->before($request);

        $this->assertInstanceOf(\CodeIgniter\HTTP\ResponseInterface::class, $response);

        $location = $response->getHeaderLine('Location');
        $isRedirect = ($response instanceof \CodeIgniter\HTTP\RedirectResponse) || !empty($location) || in_array($response->getStatusCode(), [301, 302, 303, 307], true);
        $this->assertTrue($isRedirect, 'Non-AJAX request must be redirected');
        $this->assertStringContainsString('login', strtolower($location ?: 'login'));

        $session = \Config\Services::session();
        $this->assertFalse($session->has('user_id'), 'Session must be destroyed when employee is terminated');
    }

    /**
     * Test 6: Deactivated user account destroys session and rejects request
     */
    public function testDeactivatedUserDestroysSessionAndRejectsRequest()
    {
        $db = Database::connect();
        $db->table('users')->where('id', $this->userId)->update([
            'status' => UserModel::STATUS_INACTIVE,
        ]);

        $this->initializeSession($this->userId, $this->empId);

        $_SERVER['HTTP_X_REQUESTED_WITH'] = 'xmlhttprequest';
        $request = \Config\Services::request();
        $request->setHeader('X-Requested-With', 'XMLHttpRequest');

        $authFilter = new AuthFilter();
        $response = $authFilter->before($request);

        $this->assertInstanceOf(\CodeIgniter\HTTP\ResponseInterface::class, $response);
        $this->assertEquals(403, $response->getStatusCode());

        $session = \Config\Services::session();
        $this->assertFalse($session->has('user_id'), 'Session must be destroyed when user is deactivated');
    }

    /**
     * Test 7: Other active users remain completely unaffected when one user/employee is invalidated
     */
    public function testOtherActiveUsersSessionsUnaffected()
    {
        // Alice is terminated
        $db = Database::connect();
        $db->table('employees')->where('id', $this->empId)->update([
            'status' => EmployeeModel::STATUS_TERMINATED,
        ]);

        // Bob is active
        $this->initializeSession($this->otherUserId, $this->otherEmpId);

        $request = \Config\Services::request();
        $authFilter = new AuthFilter();
        $result = $authFilter->before($request);

        $this->assertNull($result, 'Bob (active coworker) must pass through AuthFilter without interruption');

        $session = \Config\Services::session();
        $this->assertTrue($session->has('user_id'));
        $this->assertEquals($this->otherUserId, $session->get('user_id'));
    }
}
