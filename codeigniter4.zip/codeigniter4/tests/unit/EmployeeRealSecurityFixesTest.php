<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use App\Models\EmployeeModel;
use App\Models\UserModel;
use App\Controllers\Employee\EmployeeController;
use Config\Database;

/**
 * Real Database and Controller Tests for Security Fixes:
 * 1. EmployeeController::exportCsv() audit log contains actor email, username, and ID.
 * 2. EmployeeController::update() permits users without salary permission when allowances
 *    are unchanged (resolved against real active salary components or defaults).
 * 3. EmployeeController::update() returns 403 Forbidden when a user without salary permission
 *    attempts to alter an allowance value.
 */
class EmployeeRealSecurityFixesTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected static bool $schemaInitialized = false;

    protected string $companyId   = 'comp-real-sec-01';
    protected string $branchId    = 'branch-real-sec-01';
    protected string $deptId      = 'dept-real-sec-01';
    protected string $desgId      = 'desg-real-sec-01';
    protected string $shiftId     = 'shift-real-sec-01';
    protected string $etypeId     = 'etype-real-sec-01';

    protected string $targetEmpId = 'emp-real-sec-001';
    protected string $actorUserId = 'usr-real-sec-01';

    public static function setUpBeforeClass(): void
    {
        parent::setUpBeforeClass();
        static::ensureSchema();
    }

    public static function registerSqliteFunctions($db): void
    {
        try {
            $rawConn = $db->connID ?? null;
            if ($rawConn instanceof \SQLite3) {
                $rawConn->createFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->createFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            } elseif (is_object($rawConn) && method_exists($rawConn, 'sqliteCreateFunction')) {
                $rawConn->sqliteCreateFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->sqliteCreateFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            }
        } catch (\Throwable $e) {
            // ignore
        }
    }

    protected static function ensureSchema(): void
    {
        $db = Database::connect();
        static::registerSqliteFunctions($db);

        $schemaFile = __DIR__ . '/Rules/schema.sqlite.sql';
        if (file_exists($schemaFile)) {
            $sql = file_get_contents($schemaFile);
            $statements = array_filter(array_map('trim', explode(';', $sql)));
            foreach ($statements as $stmt) {
                if (!empty($stmt)) {
                    try {
                        $db->query($stmt);
                    } catch (\Throwable $e) {
                        // ignore
                    }
                }
            }
        }

        // Ensure audit_logs table exists
        $db->query("CREATE TABLE IF NOT EXISTS audit_logs (
            id VARCHAR(36) PRIMARY KEY,
            user_id VARCHAR(36),
            module VARCHAR(50),
            action VARCHAR(50),
            record_id VARCHAR(36),
            entity_id VARCHAR(36),
            entity_type VARCHAR(50),
            details TEXT,
            old_values LONGTEXT,
            new_values LONGTEXT,
            ip_address VARCHAR(45),
            user_agent TEXT,
            created_at DATETIME
        )");

        // Ensure employee columns needed by EmployeeModel and export
        $empCols = [
            'basic_salary'         => 'DECIMAL(15,2) DEFAULT 0.00',
            'gross_salary'         => 'DECIMAL(15,2) DEFAULT 0.00',
            'salary_status'        => "VARCHAR(50) DEFAULT 'NOT_CONFIGURED'",
            'house_rent_allowance' => 'DECIMAL(15,2) DEFAULT 0.00',
            'medical_allowance'    => 'DECIMAL(15,2) DEFAULT 0.00',
            'conveyance_allowance' => 'DECIMAL(15,2) DEFAULT 0.00',
            'transport_allowance'  => 'DECIMAL(15,2) DEFAULT 0.00',
            'bank_name'            => 'VARCHAR(100)',
            'bank_account'         => 'VARCHAR(100)',
        ];

        foreach ($empCols as $col => $typeDef) {
            try {
                $db->query("ALTER TABLE employees ADD COLUMN {$col} {$typeDef}");
            } catch (\Throwable $e) {
                // column already exists
            }
        }

        static::$schemaInitialized = true;
    }

    protected function setUp(): void
    {
        parent::setUp();
        static::ensureSchema();

        $db = Database::connect();
        static::registerSqliteFunctions($db);

        // Seed Company
        $db->table('companies')->replace([
            'id'     => $this->companyId,
            'name'   => 'Security Corp Test',
            'code'   => 'SCT',
            'status' => 'Active',
        ]);

        // Seed Branch
        $db->table('branches')->replace([
            'id'         => $this->branchId,
            'company_id' => $this->companyId,
            'name'       => 'HQ Branch',
            'code'       => 'HQ-01',
            'status'     => 'Active',
        ]);

        // Seed Department
        $db->table('departments')->replace([
            'id'         => $this->deptId,
            'company_id' => $this->companyId,
            'name'       => 'Engineering',
            'code'       => 'ENG',
            'status'     => 'Active',
        ]);

        // Seed Designation
        $db->table('designations')->replace([
            'id'         => $this->desgId,
            'company_id' => $this->companyId,
            'name'       => 'Staff Engineer',
            'code'       => 'STF-ENG',
            'status'     => 'Active',
        ]);

        // Seed Shift
        $db->table('shifts')->replace([
            'id'         => $this->shiftId,
            'company_id' => $this->companyId,
            'name'       => 'General Shift',
            'status'     => 'Active',
        ]);

        // Seed Employment Type
        $db->table('employment_types')->replace([
            'id'         => $this->etypeId,
            'company_id' => $this->companyId,
            'name'       => 'Permanent',
            'code'       => 'PERM',
            'status'     => 'Active',
        ]);

        // Seed Permissions
        $permissions = [
            ['id' => 'p-emp-v',  'code' => 'employees.view',     'module' => 'employees', 'action' => 'view',   'name' => 'View Employees'],
            ['id' => 'p-emp-e',  'code' => 'employees.edit',     'module' => 'employees', 'action' => 'edit',   'name' => 'Edit Employees'],
            ['id' => 'p-emp-ex', 'code' => 'employee.export',    'module' => 'employees', 'action' => 'export', 'name' => 'Export Employees'],
            ['id' => 'p-dir-v',  'code' => 'directory.view',     'module' => 'directory', 'action' => 'view',   'name' => 'View Directory'],
        ];
        foreach ($permissions as $p) {
            $db->table('permissions')->replace($p);
        }

        // Seed Role: HR Officer without salary permissions
        $db->table('roles')->replace([
            'id'         => 'role-hr-no-salary',
            'company_id' => $this->companyId,
            'name'       => 'HR Officer No Salary',
            'code'       => 'hr_officer',
            'status'     => 'Active',
        ]);

        $db->table('role_permissions')->where('role_id', 'role-hr-no-salary')->delete();
        $db->table('role_permissions')->insertBatch([
            ['id' => 'rp-r1', 'role_id' => 'role-hr-no-salary', 'permission_id' => 'p-emp-v',  'scope_level' => 'company'],
            ['id' => 'rp-r2', 'role_id' => 'role-hr-no-salary', 'permission_id' => 'p-emp-e',  'scope_level' => 'company'],
            ['id' => 'rp-r3', 'role_id' => 'role-hr-no-salary', 'permission_id' => 'p-emp-ex', 'scope_level' => 'company'],
            ['id' => 'rp-r4', 'role_id' => 'role-hr-no-salary', 'permission_id' => 'p-dir-v',  'scope_level' => 'company'],
        ]);

        // Seed Actor User
        $db->table('users')->replace([
            'id'         => $this->actorUserId,
            'company_id' => $this->companyId,
            'branch_id'  => $this->branchId,
            'username'   => 'auditor_officer',
            'email'      => 'auditor_officer@security.test',
            'role_id'    => 'role-hr-no-salary',
            'status'     => 'Active',
        ]);

        // Seed Target Employee
        $db->table('employees')->replace([
            'id'                 => $this->targetEmpId,
            'company_id'         => $this->companyId,
            'branch_id'          => $this->branchId,
            'department_id'      => $this->deptId,
            'designation_id'     => $this->desgId,
            'shift_id'           => $this->shiftId,
            'employment_type_id' => $this->etypeId,
            'employee_code'      => 'EMP-RSEC-001',
            'first_name'         => 'TargetFirst',
            'last_name'          => 'TargetLast',
            'email'              => 'target.worker@security.test',
            'phone'              => '+8801700000000',
            'basic_salary'       => 40000.00,
            'gross_salary'       => 60000.00,
            'salary_status'      => 'CONFIGURED',
            'status'             => 'active',
            'joining_date'       => '2025-01-01',
            'join_date'          => '2025-01-01',
            'created_at'         => date('Y-m-d H:i:s'),
        ]);

        // Seed Active Salary Record for Target Employee
        $db->table('employee_salaries')->where('employee_id', $this->targetEmpId)->delete();
        $db->table('employee_salaries')->insert([
            'id'                     => 'sal-real-sec-01',
            'employee_id'            => $this->targetEmpId,
            'company_id'             => $this->companyId,
            'basic_salary'           => 40000.00,
            'gross_salary'           => 60000.00,
            'status'                 => 'Active',
            'effective_from'         => '2025-01-01',
            'custom_components_json' => json_encode([
                'basic_salary' => 40000.00,
                'gross_salary' => 60000.00,
                'components'   => [
                    'house_rent'          => 15000.00,
                    'medical'             => 3000.00,
                    'conveyance'          => 2000.00,
                    'transport_allowance' => 0.00,
                ],
                'earnings'     => [
                    ['code' => 'BASIC', 'amount' => 40000.00],
                    ['code' => 'HRA',   'amount' => 15000.00],
                    ['code' => 'MED',   'amount' => 3000.00],
                    ['code' => 'CONV',  'amount' => 2000.00],
                ],
            ]),
            'created_at'             => date('Y-m-d H:i:s'),
        ]);
    }

    /**
     * Helper to configure EmployeeController with real actor session and request data
     */
    protected function setupController(array $postData = [], array $getData = [], bool $isAjax = true): EmployeeController
    {
        \App\Services\PermissionService::clearCache();
        \App\Services\PermissionService::flushCache();

        $actorUser = [
            'id'                  => $this->actorUserId,
            'user_id'             => $this->actorUserId,
            'username'            => 'auditor_officer',
            'name'                => 'Auditor Officer',
            'email'               => 'auditor_officer@security.test',
            'role'                => 'hr_officer',
            'role_code'           => 'hr_officer',
            'role_id'             => 'role-hr-no-salary',
            'company_id'          => $this->companyId,
            'branch_id'           => $this->branchId,
            'selected_company_id' => $this->companyId,
            'permissions'         => ['employees.view', 'employees.edit', 'employee.export', 'directory.view'],
        ];

        $session = \Config\Services::session();
        $session->set($actorUser);

        $_GET = $getData;
        $_POST = $postData;
        $_SERVER['REQUEST_METHOD'] = !empty($postData) ? 'POST' : 'GET';
        if ($isAjax) {
            $_SERVER['HTTP_X_REQUESTED_WITH'] = 'xmlhttprequest';
            $_SERVER['HTTP_ACCEPT'] = 'application/json';
        }

        $request = \Config\Services::request();
        if (!empty($postData)) {
            $refPost = new \ReflectionProperty($request, 'body');
            $refPost->setAccessible(true);
            $refPost->setValue($request, $postData);
        }

        $response = \Config\Services::response();
        $logger   = \Config\Services::logger();

        $controller = new EmployeeController();
        $controller->initController($request, $response, $logger);

        $refUser = new \ReflectionProperty(\App\Controllers\BaseController::class, 'currentUser');
        $refUser->setAccessible(true);
        $refUser->setValue($controller, $actorUser);

        return $controller;
    }

    /**
     * Requirement 1: Audit row for exportCsv contains actor email, username, and ID
     */
    public function testExportAuditRowContainsActorEmailAndUsername()
    {
        $db = Database::connect();
        $db->table('audit_logs')->where('action', 'employee.export_csv')->delete();

        $controller = $this->setupController([], ['status' => 'all'], true);
        $response = $controller->exportCsv();

        $this->assertNotNull($response, 'exportCsv must return a valid response object.');
        $this->assertEquals(200, $response->getStatusCode(), 'exportCsv must return HTTP 200.');

        // Query the real audit_logs table for the created record
        $auditRow = $db->table('audit_logs')
            ->where('action', 'employee.export_csv')
            ->where('user_id', $this->actorUserId)
            ->orderBy('created_at', 'DESC')
            ->get()
            ->getRowArray();

        $this->assertNotNull($auditRow, 'Real audit log record must be inserted in audit_logs table.');

        $newValues = json_decode($auditRow['new_values'] ?? '{}', true);
        $this->assertIsArray($newValues, 'Audit new_values must be valid JSON payload.');
        $this->assertArrayHasKey('actor', $newValues, 'Audit payload must contain actor group.');

        $actorPayload = $newValues['actor'];
        $this->assertEquals($this->actorUserId, $actorPayload['id'], 'Audit log actor ID must match authenticated actor ID.');
        $this->assertEquals('auditor_officer@security.test', $actorPayload['email'], 'Audit log actor email must match authenticated actor email.');
        $this->assertEquals('auditor_officer', $actorPayload['username'], 'Audit log actor username must match authenticated actor username.');
    }

    /**
     * Requirement 2: A user without salary permission can save an employee edit that leaves allowances unchanged
     */
    public function testUserWithoutSalaryPermissionCanSaveEditLeavingAllowancesUnchanged()
    {
        $db = Database::connect();

        // Active salary has: house_rent = 15000, medical = 3000, conveyance = 2000
        $postData = [
            'first_name'           => 'UpdatedTargetName',
            'phone'                => '+8801711122233',
            'house_rent_allowance' => '15000.00',
            'medical_allowance'    => '3000.00',
            'conveyance_allowance' => '2000.00',
        ];

        $controller = $this->setupController($postData, [], true);
        $response = $controller->update($this->targetEmpId);

        $this->assertNotNull($response, 'update must return a response.');
        $this->assertEquals(200, $response->getStatusCode(), 'Unchanged allowances must be permitted with HTTP 200.');

        $body = json_decode($response->getBody(), true);
        $this->assertTrue($body['success'] ?? false, 'Response body must indicate success = true.');

        // Verify database employee record updated first_name
        $updatedEmp = $db->table('employees')->where('id', $this->targetEmpId)->get()->getRowArray();
        $this->assertEquals('UpdatedTargetName', $updatedEmp['first_name'], 'Employee first name must be updated.');
    }

    /**
     * Requirement 3: A user without salary permission gets 403 when they change an allowance
     */
    public function testUserWithoutSalaryPermissionGets403WhenChangingAllowance()
    {
        $db = Database::connect();

        // Current house_rent is 15000.00, actor attempts to change it to 25000.00
        $postData = [
            'first_name'           => 'TamperedName',
            'house_rent_allowance' => '25000.00',
        ];

        $controller = $this->setupController($postData, [], true);
        $response = $controller->update($this->targetEmpId);

        $this->assertNotNull($response, 'update must return a response on rejection.');
        $this->assertEquals(403, $response->getStatusCode(), 'Changing allowance without permission must return HTTP 403.');

        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success'] ?? true, 'Response body must indicate success = false.');
        $this->assertStringContainsString('403 Forbidden', $body['message'] ?? '', 'Error message must explain forbidden permission.');

        // Verify database employee record was NOT updated
        $emp = $db->table('employees')->where('id', $this->targetEmpId)->get()->getRowArray();
        $this->assertNotEquals('TamperedName', $emp['first_name'], 'Tampered first name must NOT be persisted.');
    }
}
