<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Controllers\Leave\LeaveController;
use App\Controllers\Attendance\AttendanceController;
use App\Services\PermissionService;

class StaffLeaveAbsenceCalendarTest extends TestCase
{
    private PermissionService $permissionService;

    protected function setUp(): void
    {
        parent::setUp();
        $this->permissionService = new PermissionService();
    }

    /**
     * Helper to invoke protected sanitizeCalendarMatrix on LeaveController.
     */
    private function invokeSanitizeMatrix(
        array &$matrix,
        ?string $currentEmpId,
        bool $isHRAdmin,
        $approveDecision,
        ?string $targetCompanyId,
        string $viewScope,
        ?string $userDepartmentId
    ): void {
        $controller = new LeaveController();
        $ref = new \ReflectionMethod(LeaveController::class, 'sanitizeCalendarMatrix');
        $ref->setAccessible(true);
        $ref->invokeArgs($controller, [
            &$matrix,
            $currentEmpId,
            $isHRAdmin,
            $approveDecision,
            $targetCompanyId,
            $viewScope,
            $userDepartmentId,
        ]);
    }

    /**
     * Build a sample monthly calendar matrix containing Approved, Pending, Endorsed,
     * Rejected, Cancelled, and Withdrawn leaves across two departments (DEPT-ENG and DEPT-FIN).
     */
    private function buildSampleMatrix(): array
    {
        $rawLeaves = [
            [
                'id'              => 'LV-ENG-APPROVED',
                'employee_id'     => 'EMP-ENG-1',
                'employee_code'   => 'E101',
                'employee_name'   => 'Rafiqul Islam',
                'department_id'   => 'DEPT-ENG',
                'department_name' => 'Software Engineering',
                'leave_type'      => 'Annual Leave',
                'leave_type_name' => 'Annual Leave',
                'start_date'      => '2026-11-10',
                'end_date'        => '2026-11-12',
                'from_date'       => '2026-11-10',
                'to_date'         => '2026-11-12',
                'status'          => 'Approved',
                'reason'          => 'Personal vacation',
            ],
            [
                'id'              => 'LV-ENG-PENDING',
                'employee_id'     => 'EMP-ENG-2',
                'employee_code'   => 'E102',
                'employee_name'   => 'Mehedi Hasan',
                'department_id'   => 'DEPT-ENG',
                'department_name' => 'Software Engineering',
                'leave_type'      => 'Casual Leave',
                'leave_type_name' => 'Casual Leave',
                'start_date'      => '2026-11-10',
                'end_date'        => '2026-11-10',
                'from_date'       => '2026-11-10',
                'to_date'         => '2026-11-10',
                'status'          => 'Pending',
                'reason'          => 'Family event',
            ],
            [
                'id'              => 'LV-ENG-ENDORSED',
                'employee_id'     => 'EMP-ENG-3',
                'employee_code'   => 'E103',
                'employee_name'   => 'Nusrat Jahan',
                'department_id'   => 'DEPT-ENG',
                'department_name' => 'Software Engineering',
                'leave_type'      => 'Sick Leave',
                'leave_type_name' => 'Sick Leave',
                'start_date'      => '2026-11-10',
                'end_date'        => '2026-11-11',
                'from_date'       => '2026-11-10',
                'to_date'         => '2026-11-11',
                'status'          => 'Endorsed',
                'reason'          => 'Medical checkup',
            ],
            [
                'id'              => 'LV-FIN-APPROVED',
                'employee_id'     => 'EMP-FIN-1',
                'employee_code'   => 'F201',
                'employee_name'   => 'Kazi Nazrul',
                'department_id'   => 'DEPT-FIN',
                'department_name' => 'Finance & Accounts',
                'leave_type'      => 'Casual Leave',
                'leave_type_name' => 'Casual Leave',
                'start_date'      => '2026-11-10',
                'end_date'        => '2026-11-11',
                'from_date'       => '2026-11-10',
                'to_date'         => '2026-11-11',
                'status'          => 'Approved',
                'reason'          => 'Bank work',
            ],
            [
                'id'              => 'LV-ENG-REJECTED',
                'employee_id'     => 'EMP-ENG-1',
                'employee_code'   => 'E101',
                'employee_name'   => 'Rafiqul Islam',
                'department_id'   => 'DEPT-ENG',
                'department_name' => 'Software Engineering',
                'leave_type'      => 'Casual Leave',
                'leave_type_name' => 'Casual Leave',
                'start_date'      => '2026-11-10',
                'end_date'        => '2026-11-10',
                'from_date'       => '2026-11-10',
                'to_date'         => '2026-11-10',
                'status'          => 'Rejected',
                'reason'          => 'Rejected leave',
            ],
            [
                'id'              => 'LV-ENG-CANCELLED',
                'employee_id'     => 'EMP-ENG-2',
                'employee_code'   => 'E102',
                'employee_name'   => 'Mehedi Hasan',
                'department_id'   => 'DEPT-ENG',
                'department_name' => 'Software Engineering',
                'leave_type'      => 'Sick Leave',
                'leave_type_name' => 'Sick Leave',
                'start_date'      => '2026-11-10',
                'end_date'        => '2026-11-10',
                'from_date'       => '2026-11-10',
                'to_date'         => '2026-11-10',
                'status'          => 'Cancelled',
                'reason'          => 'Cancelled leave',
            ],
            [
                'id'              => 'LV-FIN-WITHDRAWN',
                'employee_id'     => 'EMP-FIN-1',
                'employee_code'   => 'F201',
                'employee_name'   => 'Kazi Nazrul',
                'department_id'   => 'DEPT-FIN',
                'department_name' => 'Finance & Accounts',
                'leave_type'      => 'Annual Leave',
                'leave_type_name' => 'Annual Leave',
                'start_date'      => '2026-11-10',
                'end_date'        => '2026-11-10',
                'from_date'       => '2026-11-10',
                'to_date'         => '2026-11-10',
                'status'          => 'Withdrawn',
                'reason'          => 'Withdrawn leave',
            ],
        ];

        return [
            'year'   => 2026,
            'month'  => 11,
            'leaves' => $rawLeaves,
            'days'   => [
                [
                    'day'         => 10,
                    'date'        => '2026-11-10',
                    'leaves'      => $rawLeaves,
                    'leave_count' => count($rawLeaves),
                ],
            ],
        ];
    }

    /**
     * Requirement 1 & 3:
     * Admin / HR sees all authorized company employees' Approved and Pending leaves across all departments,
     * while Rejected, Cancelled, and Withdrawn leaves are strictly excluded.
     */
    public function testAdminHrSeesAllDepartmentsApprovedAndPendingOnly(): void
    {
        $matrix = $this->buildSampleMatrix();

        $this->invokeSanitizeMatrix(
            $matrix,
            'EMP-HR-1',
            true, // isHRAdmin
            null,
            'COMP-001',
            'company',
            'DEPT-HR'
        );

        $dayLeaves = $matrix['days'][0]['leaves'];
        $ids = array_column($dayLeaves, 'id');

        // Must include Approved and Pending (including Endorsed normalized to Pending) from both DEPT-ENG and DEPT-FIN
        $this->assertContains('LV-ENG-APPROVED', $ids);
        $this->assertContains('LV-ENG-PENDING', $ids);
        $this->assertContains('LV-ENG-ENDORSED', $ids);
        $this->assertContains('LV-FIN-APPROVED', $ids);

        // Must NOT include Rejected, Cancelled, or Withdrawn
        $this->assertNotContains('LV-ENG-REJECTED', $ids);
        $this->assertNotContains('LV-ENG-CANCELLED', $ids);
        $this->assertNotContains('LV-FIN-WITHDRAWN', $ids);

        // Verify required calendar fields on each leave item
        foreach ($dayLeaves as $lv) {
            $this->assertNotEmpty($lv['employee_name']);
            $this->assertNotEmpty($lv['department_name']);
            $this->assertNotEmpty($lv['leave_type_name']);
            $this->assertNotEmpty($lv['start_date']);
            $this->assertNotEmpty($lv['end_date']);
            $this->assertContains($lv['status'], ['Approved', 'Pending']);
        }
    }

    /**
     * Requirement 2, 3 & 4:
     * Department Manager and Employee see ONLY their own Department's Approved and Pending leaves,
     * and cannot see leaves from other Departments or Rejected/Cancelled/Withdrawn leaves.
     */
    public function testEmployeeAndDepartmentManagerSeeOwnDepartmentOnly(): void
    {
        $matrix = $this->buildSampleMatrix();

        $this->invokeSanitizeMatrix(
            $matrix,
            'EMP-ENG-1',
            false, // not HR/Admin
            null,
            'COMP-001',
            'department',
            'DEPT-ENG'
        );

        $dayLeaves = $matrix['days'][0]['leaves'];
        $ids = array_column($dayLeaves, 'id');

        // Own department (DEPT-ENG) Approved + Pending leaves are visible
        $this->assertContains('LV-ENG-APPROVED', $ids);
        $this->assertContains('LV-ENG-PENDING', $ids);
        $this->assertContains('LV-ENG-ENDORSED', $ids);

        // Other department (DEPT-FIN) leaves are strictly hidden
        $this->assertNotContains('LV-FIN-APPROVED', $ids);
        $this->assertNotContains('LV-FIN-WITHDRAWN', $ids);

        // Rejected & Cancelled in own department are strictly hidden
        $this->assertNotContains('LV-ENG-REJECTED', $ids);
        $this->assertNotContains('LV-ENG-CANCELLED', $ids);

        // Colleague personal reason is stripped for non-approver peer, while status and dates remain visible
        foreach ($dayLeaves as $lv) {
            $this->assertSame('DEPT-ENG', $lv['department_id']);
            $this->assertContains($lv['status'], ['Approved', 'Pending']);
            if ($lv['employee_id'] !== 'EMP-ENG-1') {
                $this->assertSame('', $lv['reason']);
            }
        }
    }

    /**
     * Requirement 4:
     * Verify URL/API parameter tampering guard blocks Department Manager and Employee
     * from accessing another department's data.
     */
    public function testCrossDepartmentTamperingIsRejectedForManagerAndEmployee(): void
    {
        $checkDepartmentAccess = static function (bool $isAdminHR, string $userDeptId, ?string $requestedDeptId, ?string $targetEmpDeptId = null): int {
            if (!$isAdminHR) {
                if ($requestedDeptId !== null && $requestedDeptId !== '' && $requestedDeptId !== 'all') {
                    if ($userDeptId === '' || $requestedDeptId !== $userDeptId) {
                        return 403;
                    }
                }
                if ($targetEmpDeptId !== null && $targetEmpDeptId !== $userDeptId) {
                    return 403;
                }
            }
            return 200;
        };

        // Admin / HR can query any department
        $this->assertSame(200, $checkDepartmentAccess(true, 'DEPT-HR', 'DEPT-ENG'));
        $this->assertSame(200, $checkDepartmentAccess(true, 'DEPT-HR', 'DEPT-FIN'));
        $this->assertSame(200, $checkDepartmentAccess(true, 'DEPT-HR', 'all'));

        // Department Manager in DEPT-ENG can query DEPT-ENG, but gets 403 for DEPT-FIN
        $this->assertSame(200, $checkDepartmentAccess(false, 'DEPT-ENG', 'DEPT-ENG'));
        $this->assertSame(403, $checkDepartmentAccess(false, 'DEPT-ENG', 'DEPT-FIN'));
        $this->assertSame(403, $checkDepartmentAccess(false, 'DEPT-ENG', null, 'DEPT-FIN'));

        // Employee in DEPT-FIN can query DEPT-FIN, but gets 403 for DEPT-ENG
        $this->assertSame(200, $checkDepartmentAccess(false, 'DEPT-FIN', 'DEPT-FIN'));
        $this->assertSame(403, $checkDepartmentAccess(false, 'DEPT-FIN', 'DEPT-ENG'));
        $this->assertSame(403, $checkDepartmentAccess(false, 'DEPT-FIN', null, 'DEPT-ENG'));
    }
}
