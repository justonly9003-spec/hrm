<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\ZKTecoService;

class ZKTecoRawPacketParserTest extends TestCase
{
    private ZKTecoService $service;

    protected function setUp(): void
    {
        parent::setUp();
        $this->service = new ZKTecoService();
    }

    /**
     * Helper to encode standard ZKTeco 32-bit packed integer timestamp
     */
    private function encodeZkTime(int $year, int $month, int $day, int $hour, int $minute, int $second): int
    {
        $t = $year - 2000;
        $t = ($t * 12) + ($month - 1);
        $t = ($t * 31) + ($day - 1);
        $t = ($t * 24) + $hour;
        $t = ($t * 60) + $minute;
        $t = ($t * 60) + $second;
        return $t;
    }

    /**
     * Helper to construct a standard 40-byte ZKTeco TFT binary record
     * Format: vuid (2) + a24userid (24) + Cstate (1) + Vtime (4) + Cpunch (1) + a8space (8) = 40 bytes
     */
    private function create40ByteRecord(int $uid, string $userId, int $state, int $timeInt, int $punch): string
    {
        $uidBin = pack('v', $uid);
        $userIdBin = pack('a24', $userId);
        $stateBin = pack('C', $state);
        $timeBin = pack('V', $timeInt);
        $punchBin = pack('C', $punch);
        $spaceBin = pack('a8', '');

        return $uidBin . $userIdBin . $stateBin . $timeBin . $punchBin . $spaceBin;
    }

    /**
     * @testdox Decodes standard 40-byte record with normal numeric user PIN
     */
    public function testDecodeStandard40ByteRecord()
    {
        $timestampInt = $this->encodeZkTime(2026, 9, 17, 8, 30, 45);
        $binary = $this->create40ByteRecord(5, '100005', 1, $timestampInt, 0);

        $this->assertSame(40, strlen($binary));

        $parsed = $this->service->parseSingleAttendanceRecord($binary);

        $this->assertNotNull($parsed);
        $this->assertSame('100005', $parsed['device_user_id']);
        $this->assertSame('2026-09-17 08:30:45', $parsed['event_time']);
        $this->assertSame(1, $parsed['verify_mode']);
        $this->assertSame(0, $parsed['punch_status']);
        $this->assertSame(bin2hex($binary), $parsed['raw_payload']);
    }

    /**
     * @testdox Preserves leading zeros in device user ID (e.g. 0001050)
     */
    public function testPreservesLeadingZerosInUserId()
    {
        $timestampInt = $this->encodeZkTime(2026, 9, 17, 9, 15, 0);
        $binary = $this->create40ByteRecord(12, '0001050', 1, $timestampInt, 0);

        $parsed = $this->service->parseSingleAttendanceRecord($binary);

        $this->assertNotNull($parsed);
        $this->assertSame('0001050', $parsed['device_user_id'], 'Leading zeros in user ID must not be trimmed or cast to int');
        $this->assertSame('2026-09-17 09:15:00', $parsed['event_time']);
    }

    /**
     * @testdox Decodes alphanumeric employee codes correctly without trailing null bytes
     */
    public function testDecodeAlphanumericUserId()
    {
        $timestampInt = $this->encodeZkTime(2026, 9, 17, 18, 0, 10);
        $binary = $this->create40ByteRecord(42, 'EMP-9021-HQ', 4, $timestampInt, 1);

        $parsed = $this->service->parseSingleAttendanceRecord($binary);

        $this->assertNotNull($parsed);
        $this->assertSame('EMP-9021-HQ', $parsed['device_user_id']);
        $this->assertSame('2026-09-17 18:00:10', $parsed['event_time']);
        $this->assertSame(1, $parsed['punch_status']);
    }

    /**
     * @testdox Reconstructs correct user ID from raw hex payload matching corrupted real-world cases
     */
    public function testReconstructsFromHexPayload()
    {
        $timestampInt = $this->encodeZkTime(2026, 9, 16, 17, 45, 22);
        $binary = $this->create40ByteRecord(10, '100010', 1, $timestampInt, 1);
        $hex = bin2hex($binary);

        $parsed = $this->service->parseSingleAttendanceRecord($hex);

        $this->assertNotNull($parsed);
        $this->assertSame('100010', $parsed['device_user_id']);
        $this->assertSame('2026-09-16 17:45:22', $parsed['event_time']);
    }

    /**
     * @testdox Fallback to device enrollment UID when alphanumeric string is blank
     */
    public function testFallbackToDeviceUidWhenUserIdEmpty()
    {
        $timestampInt = $this->encodeZkTime(2026, 9, 17, 8, 0, 0);
        $binary = $this->create40ByteRecord(77, '', 1, $timestampInt, 0);

        $parsed = $this->service->parseSingleAttendanceRecord($binary);

        $this->assertNotNull($parsed);
        $this->assertSame('77', $parsed['device_user_id']);
        $this->assertSame('2026-09-17 08:00:00', $parsed['event_time']);
    }

    /**
     * @testdox Safely rejects records with invalid or corrupted timestamps
     */
    public function testRejectsInvalidTimestamps()
    {
        // Zero timestamp
        $zeroTimeBin = $this->create40ByteRecord(1, '1001', 1, 0, 0);
        $this->assertNull($this->service->parseSingleAttendanceRecord($zeroTimeBin));

        // Negative / overflow timestamp resulting in invalid year
        $corruptTimeBin = pack('v', 1) . pack('a24', '1001') . pack('C', 1) . pack('V', 0xFFFFFFFF) . pack('C', 0) . pack('a8', '');
        $this->assertNull($this->service->parseSingleAttendanceRecord($corruptTimeBin));
    }

    /**
     * @testdox DecodeTime accurately handles date boundaries and leap years
     */
    public function testDecodeTimeAccuracy()
    {
        // Leap year: 2024-02-29 23:59:59
        $leapInt = $this->encodeZkTime(2024, 2, 29, 23, 59, 59);
        $this->assertSame('2024-02-29 23:59:59', $this->service->decodeTime($leapInt));

        // Year end: 2025-12-31 23:59:59
        $yearEndInt = $this->encodeZkTime(2025, 12, 31, 23, 59, 59);
        $this->assertSame('2025-12-31 23:59:59', $this->service->decodeTime($yearEndInt));

        // Invalid date: Feb 30 (must return null)
        $invalidDayInt = $this->encodeZkTime(2026, 2, 30, 10, 0, 0);
        $this->assertNull($this->service->decodeTime($invalidDayInt));
    }

    /**
     * @testdox Parse batch payload with prepended 4-byte count header
     */
    public function testParseBatchPayloadWithHeader()
    {
        $time1 = $this->encodeZkTime(2026, 9, 17, 8, 0, 0);
        $time2 = $this->encodeZkTime(2026, 9, 17, 8, 5, 0);

        $rec1 = $this->create40ByteRecord(1, '100001', 1, $time1, 0);
        $rec2 = $this->create40ByteRecord(2, '100002', 1, $time2, 0);

        // Prepend 4-byte header (e.g. record count = 2)
        $header = pack('V', 2);
        $payload = $header . $rec1 . $rec2;

        $results = $this->service->parseAttendanceRecords($payload);

        $this->assertCount(2, $results);
        $this->assertSame('100001', $results[0]['device_user_id']);
        $this->assertSame('2026-09-17 08:00:00', $results[0]['event_time']);
        $this->assertSame('100002', $results[1]['device_user_id']);
        $this->assertSame('2026-09-17 08:05:00', $results[1]['event_time']);
    }

    /**
     * @testdox Parse legacy 14-byte and 16-byte records
     */
    public function testParseLegacyRecords()
    {
        $timeInt = $this->encodeZkTime(2026, 9, 17, 9, 0, 0);
        // vpin(2) + Cverify(1) + Cstatus(1) + Vtimestamp(4) + 6 bytes padding = 14 bytes
        $legacy14 = pack('v', 555) . pack('C', 1) . pack('C', 0) . pack('V', $timeInt) . pack('a6', '');
        $this->assertSame(14, strlen($legacy14));

        $parsed = $this->service->parseSingleAttendanceRecord($legacy14);
        $this->assertNotNull($parsed);
        $this->assertSame('555', $parsed['device_user_id']);
        $this->assertSame('2026-09-17 09:00:00', $parsed['event_time']);
    }
}
