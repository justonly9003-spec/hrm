<?php

namespace Tests\Unit\Gratuity;

use App\Services\Gratuity\GratuityCalculator;
use App\Services\Rules\RuleResolver;
use PHPUnit\Framework\TestCase;

class FakeGratuityRuleModel
{
    /** @var array<int, array<string, mixed>> */
    public array $rows;

    public function __construct(array $rows = [])
    {
        $this->rows = $rows;
    }

    public function getActiveRules(string $companyId, string $domain): array
    {
        $filtered = [];
        foreach ($this->rows as $r) {
            if (($r['company_id'] ?? null) === $companyId &&
                ($r['domain'] ?? null) === $domain &&
                ($r['status'] ?? 'Active') === 'Active') {
                $filtered[] = $r;
            }
        }
        return $filtered;
    }

    public function paramsOf(?array $row): array
    {
        if (empty($row) || !isset($row['params_json'])) {
            return [];
        }
        if (is_array($row['params_json'])) {
            return $row['params_json'];
        }
        $decoded = json_decode((string)$row['params_json'], true);
        return is_array($decoded) ? $decoded : [];
    }
}

class GratuityCalculatorTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        RuleResolver::resetMemo();
    }

    protected function getBaseCompanyRule(array $overrides = []): array
    {
        $defaultParams = [
            'enabled'                   => true,
            'eligibility_min_years'     => 5.0,
            'calculation_basis'         => 'Basic',
            'days_per_year'             => 15.0,
            'days_per_year_after_10y'   => 30.0,
            'divisor_days'              => 26,
            'rounding_rule'             => 'RoundUpSixMonths',
            'max_ceiling'               => 2000000.00,
            'tax_exemption_limit'       => 2500000.00,
            'tax_rate_on_excess'        => 5.0,
            'service_end_inclusive'     => true,
            'provision_mode'            => 'MonthlyAccrual',
            'provision_start'           => 'FromJoining',
            'eligible_employment_types' => [],
            'separation_rules'          => [
                ['separation_type' => 'Resignation', 'eligible' => true, 'min_years_override' => null],
                ['separation_type' => 'Dismissal', 'eligible' => false, 'min_years_override' => null],
                ['separation_type' => 'DeathOrDisability', 'eligible' => true, 'min_years_override' => 0.0],
            ],
            'custom_monthly_amount'     => null,
        ];

        $params = array_merge($defaultParams, $overrides);

        return [
            'id'             => 'rule-grat-comp-01',
            'company_id'     => 'comp-01',
            'domain'         => 'GRATUITY',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2020-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode($params),
        ];
    }

    public function testStandardGratuityAccrualFromJoining()
    {
        $model = new FakeGratuityRuleModel([$this->getBaseCompanyRule()]);
        $resolver = new RuleResolver($model);
        $calc = new GratuityCalculator($resolver);

        // Employee joined 1 year ago (50,000 basic)
        $employee = [
            'id'           => 'emp-01',
            'joining_date' => '2025-01-01',
        ];

        $res = $calc->calculateAccrual('comp-01', $employee, '2026-01-01', 50000);

        // (50000 / 26) * 15 / 12 = 2403.85
        $this->assertSame(2403.85, $res['monthly_provision_accrual']);
        $this->assertFalse($res['is_eligible']); // < 5 years
        $this->assertSame(0.00, $res['gratuity_amount']); // Not eligible for exit settlement yet
        $this->assertArrayHasKey('rules_snapshot', $res);
        $this->assertArrayHasKey('GRATUITY', $res['rules_snapshot']);
    }

    public function testEligibleEmployeeSettlementAndRounding()
    {
        $model = new FakeGratuityRuleModel([$this->getBaseCompanyRule()]);
        $resolver = new RuleResolver($model);
        $calc = new GratuityCalculator($resolver);

        // Joined 5 years and 7 months ago => RoundUpSixMonths => 6 years
        $employee = [
            'id'           => 'emp-02',
            'joining_date' => '2020-01-01',
        ];

        $res = $calc->calculateFinalSettlement('comp-01', $employee, '2025-08-01', 52000);

        $this->assertTrue($res['is_eligible']);
        $this->assertSame(6, $res['rounded_gratuity_years']);

        // Daily rate = 52000 / 26 = 2000.00
        // Annual multiplier = 2000 * 15 = 30,000.00
        // Total lump sum = 6 * 30000 = 180,000.00
        $this->assertSame(180000.00, $res['gratuity_amount']);
    }

    public function testSeparationRuleDismissalAndDeath()
    {
        $model = new FakeGratuityRuleModel([$this->getBaseCompanyRule()]);
        $resolver = new RuleResolver($model);
        $calc = new GratuityCalculator($resolver);

        // Joined 6 years ago
        $employee = [
            'id'           => 'emp-03',
            'joining_date' => '2019-01-01',
        ];

        // Dismissal => Ineligible per rule
        $resDismissal = $calc->calculateFinalSettlement('comp-01', $employee, '2025-01-01', 50000, 'Dismissal');
        $this->assertFalse($resDismissal['is_eligible']);
        $this->assertSame(0.00, $resDismissal['gratuity_amount']);

        // Death with only 1 year of service => Eligible because min_years_override = 0
        $empShort = [
            'id'           => 'emp-04',
            'joining_date' => '2024-01-01',
        ];
        $resDeath = $calc->calculateFinalSettlement('comp-01', $empShort, '2025-01-01', 50000, 'DeathOrDisability');
        $this->assertTrue($resDeath['is_eligible']);
        $this->assertGreaterThan(0, $resDeath['gratuity_amount']);
    }

    public function testEmployeeScopeCustomOverride()
    {
        $compRule = $this->getBaseCompanyRule();
        $empRule = [
            'id'             => 'rule-grat-emp-01',
            'company_id'     => 'comp-01',
            'domain'         => 'GRATUITY',
            'scope_level'    => 'Employee',
            'scope_id'       => 'emp-override-1',
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'change_reason'  => 'Executive contractual fixed gratuity provision',
            'params_json'    => json_encode([
                'custom_monthly_amount' => 5000.00,
            ]),
        ];

        $model = new FakeGratuityRuleModel([$compRule, $empRule]);
        $resolver = new RuleResolver($model);
        $calc = new GratuityCalculator($resolver);

        $employee = [
            'id'           => 'emp-override-1',
            'joining_date' => '2024-01-01',
        ];

        $res = $calc->calculateAccrual('comp-01', $employee, '2025-06-01', 60000);

        $this->assertTrue($res['is_override']);
        $this->assertSame('Executive contractual fixed gratuity provision', $res['override_reason']);
        $this->assertSame(5000.00, $res['monthly_provision_accrual']);
    }

    public function testTwoSlabGratuityCalculationOver10Years()
    {
        $model = new FakeGratuityRuleModel([$this->getBaseCompanyRule()]);
        $resolver = new RuleResolver($model);
        $calc = new GratuityCalculator($resolver);

        // Employee joined 13 years ago (Basic 52,000, 26 divisor => Daily rate 2,000.00)
        // Bangladesh Labour Act / Rule requirement:
        // First 10 years @ 15 days/yr: 10 * (2,000 * 15) = 300,000.00
        // Remaining 3 years @ 30 days/yr: 3 * (2,000 * 30) = 180,000.00
        // Total lump sum = 480,000.00 (Single-rate 15 days would have been only 390,000.00)
        $employee = [
            'id'           => 'emp-senior-13y',
            'joining_date' => '2012-01-01',
        ];

        $res = $calc->calculateFinalSettlement('comp-01', $employee, '2025-01-01', 52000);

        $this->assertTrue($res['is_eligible']);
        $this->assertSame(13, $res['rounded_gratuity_years']);
        $this->assertEquals(10.0, $res['tier1_years']);
        $this->assertEquals(3.0, $res['tier2_years']);
        $this->assertSame(300000.00, $res['tier1_amount']);
        $this->assertSame(180000.00, $res['tier2_amount']);
        $this->assertSame(480000.00, $res['gratuity_amount']);
        $this->assertStringContainsString('Slab 1', $res['formula_description']);
        $this->assertStringContainsString('Slab 2', $res['formula_description']);
    }

    public function testGratuityTaxExemptionUnderLimitReturnsZeroTax()
    {
        $model = new FakeGratuityRuleModel([$this->getBaseCompanyRule([
            'tax_exemption_limit' => 2500000.00,
            'tax_rate_on_excess'  => 5.0,
        ])]);
        $resolver = new RuleResolver($model);
        $calc = new GratuityCalculator($resolver);

        $employee = [
            'id'           => 'emp-under-tax',
            'joining_date' => '2015-01-01',
        ];

        // 10 years @ 15 days, 52k basic => 300k gratuity (well under 2.5m tax exemption limit)
        $res = $calc->calculateFinalSettlement('comp-01', $employee, '2025-01-01', 52000);

        $this->assertSame(300000.00, $res['gratuity_amount']);
        $this->assertSame(2500000.00, $res['tax_exemption_limit']);
        $this->assertSame(5.0, $res['tax_rate_on_excess']);
        $this->assertSame(0.00, $res['taxable_gratuity_excess']);
        $this->assertSame(0.00, $res['gratuity_tax_deduction']);
        $this->assertSame(300000.00, $res['net_gratuity_amount']);
    }

    public function testGratuityTaxExemptionOnExcessCalculatesFavorableTax()
    {
        // High earner with 15 years service:
        // Basic: 260,000 / 26 = 10,000 daily rate.
        // Slab 1: 10 yrs * 15 days * 10,000 = 1,500,000
        // Slab 2: 5 yrs * 30 days * 10,000 = 1,500,000
        // Total Gratuity: 3,000,000.
        // Tax Exemption: 2,500,000.
        // Taxable Excess: 500,000.
        // Tax @ 5%: 25,000.
        // Net Gratuity: 2,975,000.
        $model = new FakeGratuityRuleModel([$this->getBaseCompanyRule([
            'max_ceiling'         => 0, // un-capped for this test
            'tax_exemption_limit' => 2500000.00,
            'tax_rate_on_excess'  => 5.0,
        ])]);
        $resolver = new RuleResolver($model);
        $calc = new GratuityCalculator($resolver);

        $employee = [
            'id'           => 'emp-high-exec',
            'joining_date' => '2010-01-01',
        ];

        $res = $calc->calculateFinalSettlement('comp-01', $employee, '2025-01-01', 260000);

        $this->assertSame(3000000.00, $res['gratuity_amount']);
        $this->assertSame(2500000.00, $res['tax_exemption_limit']);
        $this->assertSame(5.0, $res['tax_rate_on_excess']);
        $this->assertSame(500000.00, $res['taxable_gratuity_excess']);
        $this->assertSame(25000.00, $res['gratuity_tax_deduction']);
        $this->assertSame(2975000.00, $res['net_gratuity_amount']);
        $this->assertStringContainsString('Tax Exemption Limit: 2,500,000.00', $res['formula_description']);
        $this->assertStringContainsString('Taxable Excess: 500,000.00 @ 5% = 25,000.00 Tax Withheld', $res['formula_description']);
    }
}
