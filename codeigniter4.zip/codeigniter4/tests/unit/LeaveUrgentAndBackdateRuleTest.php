<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\LeaveService;
use App\Services\Leave\LeaveApplicationService;

class LeaveUrgentAndBackdateRuleTest extends TestCase
{
    /**
     * Test 1: Same-day sick leave is exempt from notice period even when min_notice_days > 0.
     */
    public function testSameDaySickLeaveExemptFromNoticePeriod()
    {
        $leaveService = new LeaveService();
        $today = date('Y-m-d');

        $emp = [
            'id'             => 'emp-sick-01',
            'company_id'     => 'comp-01',
            'branch_id'      => null,
            'department_id'  => null,
            'designation_id' => null,
            'shift_id'       => null,
            'joining_date'   => '2023-01-01',
        ];

        $sickLeaveType = [
            'id'                          => 'lt-sl-01',
            'company_id'                  => 'comp-01',
            'name'                        => 'Sick Leave',
            'code'                        => 'SL',
            'is_paid'                     => 1,
            'min_notice_days'             => 3, // Policy requires 3 days notice
            'allow_backdated_application' => 1,
            'max_backdate_days'           => 7,
            'allow_future_application'    => 1,
            'max_future_days'             => 30,
            'allow_half_day'              => 1,
            'allow_hourly_leave'          => 0,
            'max_consecutive_days'        => 14,
            'allow_negative_balance'      => 0,
            'max_negative_days'           => 0,
        ];

        // Same-day sick leave application
        $params = [
            'from_date' => $today,
            'to_date'   => $today,
            'reason'    => 'Sudden high fever and medical consultation',
        ];

        $sim = $leaveService->simulateLeaveApplication($emp, $sickLeaveType, $params);

        // Verify no notice period warning/error is raised for same-day sick leave
        $hasNoticeWarning = false;
        foreach ($sim['warnings'] as $w) {
            if (stripos($w, 'Notice Period Warning') !== false) {
                $hasNoticeWarning = true;
                break;
            }
        }
        $this->assertFalse($hasNoticeWarning, "Same-day sick leave must be exempt from advance notice period warning.");
    }

    /**
     * Test 2: Emergency absence (is_emergency) is exempt from notice period requirements.
     */
    public function testEmergencyAbsenceExemptFromNoticePeriod()
    {
        $leaveService = new LeaveService();
        $today = date('Y-m-d');

        $emp = [
            'id'             => 'emp-emg-01',
            'company_id'     => 'comp-01',
            'branch_id'      => null,
            'department_id'  => null,
            'designation_id' => null,
            'shift_id'       => null,
            'joining_date'   => '2023-01-01',
        ];

        $annualLeaveType = [
            'id'                          => 'lt-al-01',
            'company_id'                  => 'comp-01',
            'name'                        => 'Annual Leave',
            'code'                        => 'AL',
            'is_paid'                     => 1,
            'min_notice_days'             => 5, // 5 days notice required
            'allow_emergency_absence'     => 1, // Emergency allowed for this test
            'allow_backdated_application' => 1,
            'max_backdate_days'           => 7,
            'allow_future_application'    => 1,
            'max_future_days'             => 60,
            'allow_half_day'              => 1,
            'allow_hourly_leave'          => 0,
            'max_consecutive_days'        => 14,
            'allow_negative_balance'      => 0,
            'max_negative_days'           => 0,
        ];

        // Emergency leave applied with 0 days advance notice
        $params = [
            'from_date'    => $today,
            'to_date'      => $today,
            'is_emergency' => true,
            'reason'       => 'Urgent family hospitalization emergency',
        ];

        $sim = $leaveService->simulateLeaveApplication($emp, $annualLeaveType, $params);

        $hasNoticeWarning = false;
        foreach ($sim['warnings'] as $w) {
            if (stripos($w, 'Notice Period Warning') !== false) {
                $hasNoticeWarning = true;
                break;
            }
        }
        $this->assertFalse($hasNoticeWarning, "Emergency absence must be exempt from advance notice warning.");
    }

    /**
     * Test 3: HR can record urgent leave bypassing min_notice_days.
     */
    public function testHrCanRecordUrgentLeaveBypassingNotice()
    {
        $leaveService = new LeaveService();
        $today = date('Y-m-d');

        $emp = [
            'id'             => 'emp-hr-01',
            'company_id'     => 'comp-01',
            'branch_id'      => null,
            'department_id'  => null,
            'designation_id' => null,
            'shift_id'       => null,
            'joining_date'   => '2023-01-01',
        ];

        $leaveType = [
            'id'                          => 'lt-casual-01',
            'company_id'                  => 'comp-01',
            'name'                        => 'Casual Leave',
            'code'                        => 'CL',
            'is_paid'                     => 1,
            'min_notice_days'             => 2,
            'allow_backdated_application' => 1,
            'max_backdate_days'           => 7,
            'allow_future_application'    => 1,
            'max_future_days'             => 30,
            'allow_half_day'              => 1,
            'allow_hourly_leave'          => 0,
            'max_consecutive_days'        => 3,
            'allow_negative_balance'      => 0,
            'max_negative_days'           => 0,
        ];

        // HR entering urgent leave on the same day for employee
        $params = [
            'from_date'        => $today,
            'to_date'          => $today,
            'can_manage_leave' => true,
            'reason'           => 'HR recording urgent employee absence',
        ];

        $sim = $leaveService->simulateLeaveApplication($emp, $leaveType, $params);

        $hasNoticeWarning = false;
        foreach ($sim['warnings'] as $w) {
            if (stripos($w, 'Notice Period Warning') !== false) {
                $hasNoticeWarning = true;
                break;
            }
        }
        $this->assertFalse($hasNoticeWarning, "HR managing urgent leave must be exempt from notice period checks.");
    }

    /**
     * Test 4: Backdated 'Manager and HR' does not block normal employee application,
     * but warns that both Manager and HR approval are required.
     */
    public function testBackdatedManagerAndHrDoesNotBlockApplicant()
    {
        $leaveService = new LeaveService();
        $pastDate = date('Y-m-d', strtotime('-2 days'));

        $emp = [
            'id'             => 'emp-regular-01',
            'company_id'     => 'comp-01',
            'branch_id'      => null,
            'department_id'  => null,
            'designation_id' => null,
            'shift_id'       => null,
            'joining_date'   => '2023-01-01',
        ];

        $leaveType = [
            'id'                          => 'lt-backdated-01',
            'company_id'                  => 'comp-01',
            'name'                        => 'Earned Leave',
            'code'                        => 'EL',
            'is_paid'                     => 1,
            'allow_backdated_application' => 1,
            'max_backdate_days'           => 7,
            'backdated_role_requirement'  => 'Manager and HR',
            'min_notice_days'             => 0,
            'allow_future_application'    => 1,
            'max_future_days'             => 60,
            'allow_half_day'              => 1,
            'allow_hourly_leave'          => 0,
            'max_consecutive_days'        => 18,
            'allow_negative_balance'      => 0,
            'max_negative_days'           => 0,
        ];

        // Regular employee submitting backdated leave (user_id is regular employee, not HR or manager)
        $params = [
            'from_date'        => $pastDate,
            'to_date'          => $pastDate,
            'can_manage_leave' => false,
            'user_id'          => 'user-regular-01',
            'reason'           => 'Submitting leave for day absent due to personal situation',
        ];

        $sim = $leaveService->simulateLeaveApplication($emp, $leaveType, $params);

        // Employee must NOT be rejected with "requires Manager or HR/Admin privileges" error
        $hasPrivilegeError = false;
        foreach ($sim['errors'] as $err) {
            if (stripos($err, 'requires Manager or HR/Admin privileges') !== false) {
                $hasPrivilegeError = true;
                break;
            }
        }
        $this->assertFalse($hasPrivilegeError, "Regular employee must not be blocked at application time by Manager and HR requirement.");

        // Instead, a warning/notice should clarify that Manager and HR approval are required
        $hasWorkflowNotice = false;
        foreach ($sim['warnings'] as $w) {
            if (stripos($w, 'requires both Manager endorsement and HR Admin approval') !== false) {
                $hasWorkflowNotice = true;
                break;
            }
        }
        $this->assertTrue($hasWorkflowNotice, "Backdated leave simulation must inform that both Manager and HR approvals are required.");
    }

    /**
     * Test 5: Regular employee cannot submit emergency absence when the leave type disallows it.
     */
    public function testEmergencyAbsenceBlockedForRegularEmployeeWhenTypeDisallowsIt()
    {
        $leaveService = new LeaveService();
        $today = date('Y-m-d');

        $emp = [
            'id'             => 'emp-reg-disallowed-01',
            'company_id'     => 'comp-01',
            'branch_id'      => null,
            'department_id'  => null,
            'designation_id' => null,
            'shift_id'       => null,
            'joining_date'   => '2023-01-01',
        ];

        $leaveType = [
            'id'                          => 'lt-study-01',
            'company_id'                  => 'comp-01',
            'name'                        => 'Study Leave',
            'code'                        => 'STL',
            'is_paid'                     => 1,
            'allow_emergency_absence'     => 0, // Emergency disabled for Study Leave
            'min_notice_days'             => 14,
            'allow_backdated_application' => 0,
            'max_backdate_days'           => 0,
            'allow_future_application'    => 1,
            'max_future_days'             => 60,
            'allow_half_day'              => 0,
            'allow_hourly_leave'          => 0,
            'max_consecutive_days'        => 30,
            'allow_negative_balance'      => 0,
            'max_negative_days'           => 0,
        ];

        $params = [
            'from_date'        => $today,
            'to_date'          => $today,
            'is_emergency'     => true,
            'can_manage_leave' => false,
            'reason'           => 'Urgent study exam scheduled unexpectedly',
        ];

        $sim = $leaveService->simulateLeaveApplication($emp, $leaveType, $params);

        $hasError = false;
        foreach ($sim['errors'] as $err) {
            if (stripos($err, 'Emergency absence is not permitted') !== false) {
                $hasError = true;
                break;
            }
        }
        $this->assertTrue($hasError, "Regular employee must be blocked from emergency absence when the leave type disallows it.");
    }

    /**
     * Test 6: HR can submit emergency absence even when the leave type disallows it for employees.
     */
    public function testHrCanSubmitEmergencyAbsenceEvenWhenTypeDisallowsIt()
    {
        $leaveService = new LeaveService();
        $today = date('Y-m-d');

        $emp = [
            'id'             => 'emp-target-01',
            'company_id'     => 'comp-01',
            'branch_id'      => null,
            'department_id'  => null,
            'designation_id' => null,
            'shift_id'       => null,
            'joining_date'   => '2023-01-01',
        ];

        $leaveType = [
            'id'                          => 'lt-study-01',
            'company_id'                  => 'comp-01',
            'name'                        => 'Study Leave',
            'code'                        => 'STL',
            'is_paid'                     => 1,
            'allow_emergency_absence'     => 0, // Disabled for regular staff
            'min_notice_days'             => 14,
            'allow_backdated_application' => 0,
            'max_backdate_days'           => 0,
            'allow_future_application'    => 1,
            'max_future_days'             => 60,
            'allow_half_day'              => 0,
            'allow_hourly_leave'          => 0,
            'max_consecutive_days'        => 30,
            'allow_negative_balance'      => 0,
            'max_negative_days'           => 0,
        ];

        $params = [
            'from_date'        => $today,
            'to_date'          => $today,
            'is_emergency'     => true,
            'can_manage_leave' => true, // HR Admin applying
            'reason'           => 'HR recording emergency administrative study leave exception',
        ];

        $sim = $leaveService->simulateLeaveApplication($emp, $leaveType, $params);

        $hasDisallowedError = false;
        foreach ($sim['errors'] as $err) {
            if (stripos($err, 'Emergency absence is not permitted') !== false) {
                $hasDisallowedError = true;
                break;
            }
        }
        $this->assertFalse($hasDisallowedError, "HR must not be blocked by the leave type emergency permission check.");
    }

    /**
     * Test 7: Regular employee cannot bypass max_backdate_days using emergency absence.
     */
    public function testRegularEmployeeCannotBypassMaxBackdateDaysWithEmergency()
    {
        $leaveService = new LeaveService();
        $pastDate = date('Y-m-d', strtotime('-10 days'));

        $emp = [
            'id'             => 'emp-reg-backdate-01',
            'company_id'     => 'comp-01',
            'branch_id'      => null,
            'department_id'  => null,
            'designation_id' => null,
            'shift_id'       => null,
            'joining_date'   => '2023-01-01',
        ];

        $leaveType = [
            'id'                          => 'lt-sl-02',
            'company_id'                  => 'comp-01',
            'name'                        => 'Sick Leave',
            'code'                        => 'SL',
            'is_paid'                     => 1,
            'allow_emergency_absence'     => 1, // Emergency allowed
            'allow_backdated_application' => 1,
            'max_backdate_days'           => 3, // Allowed up to 3 days ago only
            'min_notice_days'             => 0,
            'allow_future_application'    => 1,
            'max_future_days'             => 30,
            'allow_half_day'              => 1,
            'allow_hourly_leave'          => 0,
            'max_consecutive_days'        => 14,
            'allow_negative_balance'      => 0,
            'max_negative_days'           => 0,
        ];

        $params = [
            'from_date'        => $pastDate, // 10 days ago (> 3 max days)
            'to_date'          => $pastDate,
            'is_emergency'     => true,
            'can_manage_leave' => false, // Regular employee
            'reason'           => 'Severe accident and hospitalization lasting 10 days',
        ];

        $sim = $leaveService->simulateLeaveApplication($emp, $leaveType, $params);

        $hasBackdateError = false;
        foreach ($sim['errors'] as $err) {
            if (stripos($err, 'Backdated limit exceeded') !== false) {
                $hasBackdateError = true;
                break;
            }
        }
        $this->assertTrue($hasBackdateError, "Emergency absence by regular employee must NOT bypass the max_backdate_days limit.");
    }

    /**
     * Test 8: Emergency absence requires a valid, detailed explanation.
     */
    public function testEmergencyAbsenceRequiresDetailedReason()
    {
        $leaveService = new LeaveService();
        $today = date('Y-m-d');

        $emp = [
            'id'             => 'emp-reg-reason-01',
            'company_id'     => 'comp-01',
            'branch_id'      => null,
            'department_id'  => null,
            'designation_id' => null,
            'shift_id'       => null,
            'joining_date'   => '2023-01-01',
        ];

        $leaveType = [
            'id'                          => 'lt-cl-02',
            'company_id'                  => 'comp-01',
            'name'                        => 'Casual Leave',
            'code'                        => 'CL',
            'is_paid'                     => 1,
            'allow_emergency_absence'     => 1,
            'min_notice_days'             => 3,
            'allow_backdated_application' => 1,
            'max_backdate_days'           => 7,
            'allow_future_application'    => 1,
            'max_future_days'             => 30,
            'allow_half_day'              => 1,
            'allow_hourly_leave'          => 0,
            'max_consecutive_days'        => 5,
            'allow_negative_balance'      => 0,
            'max_negative_days'           => 0,
        ];

        $params = [
            'from_date'        => $today,
            'to_date'          => $today,
            'is_emergency'     => true,
            'can_manage_leave' => false,
            'reason'           => 'Sick', // Only 4 characters (< 5)
        ];

        $sim = $leaveService->simulateLeaveApplication($emp, $leaveType, $params);

        $hasReasonWarning = false;
        foreach ($sim['warnings'] as $w) {
            if (stripos($w, 'A valid, detailed reason explaining the emergency absence is required') !== false) {
                $hasReasonWarning = true;
                break;
            }
        }
        $this->assertTrue($hasReasonWarning, "Emergency absence without detailed explanation must trigger a warning/error.");
    }

    /**
     * Test 9: Manager applying for their own leave CANNOT bypass notice period.
     */
    public function testManagerApplyingForOwnLeaveCannotBypassNoticePeriod()
    {
        $leaveService = new LeaveService();
        $today = date('Y-m-d');

        $mgrEmp = [
            'id'             => 'emp-mgr-01',
            'company_id'     => 'comp-01',
            'branch_id'      => null,
            'department_id'  => null,
            'designation_id' => null,
            'shift_id'       => null,
            'joining_date'   => '2023-01-01',
        ];

        $leaveType = [
            'id'                          => 'lt-cl-03',
            'company_id'                  => 'comp-01',
            'name'                        => 'Casual Leave',
            'code'                        => 'CL',
            'is_paid'                     => 1,
            'allow_emergency_absence'     => 1,
            'min_notice_days'             => 3,
            'allow_backdated_application' => 1,
            'max_backdate_days'           => 7,
            'allow_future_application'    => 1,
            'max_future_days'             => 30,
            'allow_half_day'              => 1,
            'allow_hourly_leave'          => 0,
            'max_consecutive_days'        => 5,
            'allow_negative_balance'      => 0,
            'max_negative_days'           => 0,
        ];

        // Manager applying for self (applied_by / user_id matches target employee id)
        $params = [
            'from_date'          => $today, // 0 days notice (< 3 days required)
            'to_date'            => $today,
            'is_manager'         => true,
            'can_manage_leave'   => true,
            'applied_by'         => 'emp-mgr-01',
            'user_id'            => 'emp-mgr-01',
            'is_own_application' => true,
            'reason'             => 'Personal rest and recovery',
        ];

        $sim = $leaveService->simulateLeaveApplication($mgrEmp, $leaveType, $params);

        $hasNoticeWarning = false;
        foreach ($sim['warnings'] as $w) {
            if (stripos($w, 'Notice Period Warning') !== false) {
                $hasNoticeWarning = true;
                break;
            }
        }
        $this->assertTrue($hasNoticeWarning, "Manager applying for their own leave must be subject to advance notice period warning.");
    }

    /**
     * Test 10: Manager applying for their own leave CANNOT mark emergency when type disallows it.
     */
    public function testManagerApplyingForOwnLeaveCannotBypassDisallowedEmergency()
    {
        $leaveService = new LeaveService();
        $today = date('Y-m-d');

        $mgrEmp = [
            'id'             => 'emp-mgr-02',
            'company_id'     => 'comp-01',
            'branch_id'      => null,
            'department_id'  => null,
            'designation_id' => null,
            'shift_id'       => null,
            'joining_date'   => '2023-01-01',
        ];

        $leaveType = [
            'id'                          => 'lt-study-02',
            'company_id'                  => 'comp-01',
            'name'                        => 'Study Leave',
            'code'                        => 'STL',
            'is_paid'                     => 1,
            'allow_emergency_absence'     => 0, // Disallowed
            'min_notice_days'             => 14,
            'allow_backdated_application' => 0,
            'max_backdate_days'           => 0,
            'allow_future_application'    => 1,
            'max_future_days'             => 60,
            'allow_half_day'              => 0,
            'allow_hourly_leave'          => 0,
            'max_consecutive_days'        => 30,
            'allow_negative_balance'      => 0,
            'max_negative_days'           => 0,
        ];

        $params = [
            'from_date'          => $today,
            'to_date'            => $today,
            'is_emergency'       => true,
            'is_manager'         => true,
            'can_manage_leave'   => true,
            'applied_by'         => 'emp-mgr-02',
            'user_id'            => 'emp-mgr-02',
            'is_own_application' => true,
            'reason'             => 'Urgent study preparation requirement',
        ];

        $sim = $leaveService->simulateLeaveApplication($mgrEmp, $leaveType, $params);

        $hasEmergencyError = false;
        foreach ($sim['errors'] as $err) {
            if (stripos($err, 'Emergency absence is not permitted') !== false) {
                $hasEmergencyError = true;
                break;
            }
        }
        $this->assertTrue($hasEmergencyError, "Manager applying for their own leave cannot mark emergency when leave type disallows it.");
    }

    /**
     * Test 11: Normal employee applying for own leave with auto_approve_under_days=3 and 2 days -> auto-approved.
     */
    public function testEmployeeOwnLeaveAutoApprovedUnderDaysThreshold()
    {
        $leaveService = new LeaveService();
        $fromDate = date('Y-m-d', strtotime('+3 days'));
        $toDate = date('Y-m-d', strtotime('+4 days')); // 2 days

        $emp = [
            'id'             => 'emp-norm-01',
            'company_id'     => 'comp-01',
            'branch_id'      => null,
            'department_id'  => null,
            'designation_id' => null,
            'shift_id'       => null,
            'joining_date'   => '2023-01-01',
        ];

        $leaveType = [
            'id'                      => 'lt-cl-auto-01',
            'company_id'              => 'comp-01',
            'name'                    => 'Casual Leave',
            'code'                    => 'CL',
            'is_paid'                 => 1,
            'approval_required'       => 1,
            'is_auto_approved'        => 0,
            'auto_approve_under_days' => 3.0,
            'min_notice_days'         => 0,
        ];

        $params = [
            'from_date'          => $fromDate,
            'to_date'            => $toDate,
            'applied_by'         => 'emp-norm-01',
            'user_id'            => 'emp-norm-01',
            'is_own_application' => true,
            'is_manager'         => false,
            'can_manage_leave'   => false,
            'reason'             => 'Family ceremony attendance',
        ];

        $sim = $leaveService->simulateLeaveApplication($emp, $leaveType, $params);
        $this->assertTrue($sim['is_auto_approved'], "Normal employee applying for own leave under auto_approve_under_days threshold must be auto-approved.");
        $this->assertTrue($sim['validation']['is_auto_approved']);

        $autoDecision = LeaveApplicationService::determineAutoApproval([
            'is_backdated'            => false,
            'backdated_role'          => '',
            'is_own_application'      => true,
            'is_hr'                   => false,
            'is_manager'              => false,
            'approval_required'       => true,
            'is_auto_approved'        => false,
            'auto_approve_under_days' => 3.0,
            'chargeable_days'         => 2.0,
            'is_emergency'            => false,
        ]);
        $this->assertTrue($autoDecision, "LeaveApplicationService::determineAutoApproval must return true for employee under threshold.");
    }

    /**
     * Test 12: Normal employee applying for own leave with is_auto_approved=true -> auto-approved.
     */
    public function testEmployeeOwnLeaveExplicitlyAutoApprovedRule()
    {
        $leaveService = new LeaveService();
        $fromDate = date('Y-m-d', strtotime('+7 days'));
        $toDate = date('Y-m-d', strtotime('+10 days')); // 4 days

        $emp = [
            'id'             => 'emp-norm-02',
            'company_id'     => 'comp-01',
            'branch_id'      => null,
            'department_id'  => null,
            'designation_id' => null,
            'shift_id'       => null,
            'joining_date'   => '2023-01-01',
        ];

        $leaveType = [
            'id'                      => 'lt-fl-auto-02',
            'company_id'              => 'comp-01',
            'name'                    => 'Festival Leave',
            'code'                    => 'FL',
            'is_paid'                 => 1,
            'approval_required'       => 1,
            'is_auto_approved'        => 1, // Rule explicitly auto-approves
            'auto_approve_under_days' => 0.0,
            'min_notice_days'         => 0,
        ];

        $params = [
            'from_date'          => $fromDate,
            'to_date'            => $toDate,
            'applied_by'         => 'emp-norm-02',
            'user_id'            => 'emp-norm-02',
            'is_own_application' => true,
            'is_manager'         => false,
            'can_manage_leave'   => false,
            'reason'             => 'Festival celebration and travel',
        ];

        $sim = $leaveService->simulateLeaveApplication($emp, $leaveType, $params);
        $this->assertTrue($sim['is_auto_approved'], "Normal employee applying for own leave where is_auto_approved=true must be auto-approved.");
        $this->assertTrue($sim['validation']['is_auto_approved']);

        $autoDecision = LeaveApplicationService::determineAutoApproval([
            'is_backdated'            => false,
            'backdated_role'          => '',
            'is_own_application'      => true,
            'is_hr'                   => false,
            'is_manager'              => false,
            'approval_required'       => true,
            'is_auto_approved'        => true,
            'auto_approve_under_days' => 0.0,
            'chargeable_days'         => 4.0,
            'is_emergency'            => false,
        ]);
        $this->assertTrue($autoDecision, "LeaveApplicationService::determineAutoApproval must return true when is_auto_approved is set.");
    }

    /**
     * Test 13: Manager applying for own leave with approval_required=true -> NOT auto-approved.
     */
    public function testManagerOwnLeaveCannotAutoApprove()
    {
        $leaveService = new LeaveService();
        $fromDate = date('Y-m-d', strtotime('+5 days'));
        $toDate = date('Y-m-d', strtotime('+6 days')); // 2 days (< 5 days threshold)

        $mgrEmp = [
            'id'             => 'emp-mgr-03',
            'company_id'     => 'comp-01',
            'branch_id'      => null,
            'department_id'  => null,
            'designation_id' => null,
            'shift_id'       => null,
            'joining_date'   => '2023-01-01',
        ];

        $leaveType = [
            'id'                      => 'lt-cl-auto-03',
            'company_id'              => 'comp-01',
            'name'                    => 'Casual Leave',
            'code'                    => 'CL',
            'is_paid'                 => 1,
            'approval_required'       => 1,
            'is_auto_approved'        => 1, // Even if is_auto_approved is true
            'auto_approve_under_days' => 5.0, // Or under auto_approve_under_days
            'min_notice_days'         => 0,
        ];

        // Manager applying for self
        $params = [
            'from_date'          => $fromDate,
            'to_date'            => $toDate,
            'applied_by'         => 'emp-mgr-03',
            'user_id'            => 'emp-mgr-03',
            'is_own_application' => true,
            'is_manager'         => true,
            'can_manage_leave'   => true,
            'reason'             => 'Executive leadership personal leave',
        ];

        $sim = $leaveService->simulateLeaveApplication($mgrEmp, $leaveType, $params);
        $this->assertFalse($sim['is_auto_approved'], "Manager applying for own leave when approval_required=true must NOT be auto-approved.");
        $this->assertFalse($sim['validation']['is_auto_approved']);

        $autoDecision = LeaveApplicationService::determineAutoApproval([
            'is_backdated'            => false,
            'backdated_role'          => '',
            'is_own_application'      => true,
            'is_hr'                   => false,
            'is_manager'              => true,
            'approval_required'       => true,
            'is_auto_approved'        => true,
            'auto_approve_under_days' => 5.0,
            'chargeable_days'         => 2.0,
            'is_emergency'            => false,
        ]);
        $this->assertFalse($autoDecision, "LeaveApplicationService::determineAutoApproval must return false for manager applying for own leave.");
    }

    /**
     * Test 14: Emergency leave -> NOT auto-approved.
     */
    public function testEmergencyLeaveCannotAutoApprove()
    {
        $leaveService = new LeaveService();
        $today = date('Y-m-d');

        $emp = [
            'id'             => 'emp-norm-04',
            'company_id'     => 'comp-01',
            'branch_id'      => null,
            'department_id'  => null,
            'designation_id' => null,
            'shift_id'       => null,
            'joining_date'   => '2023-01-01',
        ];

        $leaveType = [
            'id'                      => 'lt-cl-auto-04',
            'company_id'              => 'comp-01',
            'name'                    => 'Casual Leave',
            'code'                    => 'CL',
            'is_paid'                 => 1,
            'approval_required'       => 1,
            'is_auto_approved'        => 1, // Auto-approved normally
            'auto_approve_under_days' => 5.0,
            'allow_emergency_absence' => 1,
            'min_notice_days'         => 0,
        ];

        $params = [
            'from_date'          => $today,
            'to_date'            => $today,
            'applied_by'         => 'emp-norm-04',
            'user_id'            => 'emp-norm-04',
            'is_own_application' => true,
            'is_manager'         => false,
            'can_manage_leave'   => false,
            'is_emergency'       => true, // Emergency marked
            'reason'             => 'Acute dental emergency hospital procedure',
        ];

        $sim = $leaveService->simulateLeaveApplication($emp, $leaveType, $params);
        $this->assertFalse($sim['is_auto_approved'], "Emergency leave must NOT be auto-approved.");
        $this->assertFalse($sim['validation']['is_auto_approved']);

        $autoDecision = LeaveApplicationService::determineAutoApproval([
            'is_backdated'            => false,
            'backdated_role'          => '',
            'is_own_application'      => true,
            'is_hr'                   => false,
            'is_manager'              => false,
            'approval_required'       => true,
            'is_auto_approved'        => true,
            'auto_approve_under_days' => 5.0,
            'chargeable_days'         => 1.0,
            'is_emergency'            => true,
        ]);
        $this->assertFalse($autoDecision, "LeaveApplicationService::determineAutoApproval must return false for emergency leave.");
    }
}
