<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use App\Controllers\Employee\EmployeeController;
use App\Models\EmployeeModel;
use App\Models\UserModel;
use App\Models\EmployeeBankAccountModel;
use App\Models\EmployeeSalaryModel;
use Config\Database;

/**
 * Tests for Atomic Employee Registration in EmployeeController::store()
 *
 * Verifies real DB-backed behavior:
 * (a) when the generated code is already taken by another row, store creates the employee with
 *     a new code and all dependent rows (user, bank, salary) exist;
 * (b) when the retry also fails, nothing is left in employees/users/bank/salary tables;
 * (c) an FK failure (invalid department_id) leaves no rows.
 */
class EmployeeStoreAtomicTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected static bool $schemaInitialized = false;

    protected string $tenantCompanyId = 'comp-atom-01';
    protected string $tenantBranchId = 'branch-atom-01';
    protected string $tenantDeptId = 'dept-atom-01';
    protected string $tenantDesgId = 'desg-atom-01';
    protected string $tenantShiftId = 'shift-atom-01';
    protected string $tenantEmpTypeId = 'emptype-atom-01';
    protected string $tenantRoleId = 'role-emp-atom-01';
    protected array $adminUser = [];

    public static function setUpBeforeClass(): void
    {
        parent::setUpBeforeClass();
        static::ensureSchema();
    }

    public static function registerSqliteFunctions($db): void
    {
        try {
            $rawConn = $db->connID ?? null;
            if ($rawConn instanceof \SQLite3) {
                $rawConn->createFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
            } elseif (is_object($rawConn) && method_exists($rawConn, 'sqliteCreateFunction')) {
                $rawConn->sqliteCreateFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
            }
        } catch (\Throwable $e) {
            // ignore if not sqlite or already registered
        }
    }

    protected static function ensureSchema(): void
    {
        $db = Database::connect();
        static::registerSqliteFunctions($db);

        $schemaFile = __DIR__ . '/Rules/schema.sqlite.sql';
        if (file_exists($schemaFile)) {
            $sql = file_get_contents($schemaFile);
            $statements = array_filter(array_map('trim', explode(';', $sql)));
            foreach ($statements as $stmt) {
                if (!empty($stmt)) {
                    try {
                        $db->query($stmt);
                    } catch (\Throwable $e) {
                        // ignore if already exists
                    }
                }
            }
        }

        // Ensure employee_bank_accounts table exists
        $db->query("CREATE TABLE IF NOT EXISTS employee_bank_accounts (
            id VARCHAR(36) PRIMARY KEY,
            employee_id VARCHAR(36) NOT NULL,
            company_id VARCHAR(36),
            bank_name VARCHAR(150),
            bank VARCHAR(150),
            account_name VARCHAR(150),
            account_number VARCHAR(100),
            routing_number VARCHAR(50),
            branch_name VARCHAR(150),
            branch VARCHAR(150),
            swift_code VARCHAR(50),
            swift VARCHAR(50),
            mobile_banking VARCHAR(50),
            payment_method VARCHAR(50),
            is_primary INT DEFAULT 1,
            primary_account INT DEFAULT 1,
            status VARCHAR(20) DEFAULT 'Active',
            created_at DATETIME,
            updated_at DATETIME
        )");

        // Ensure employment_histories table exists for period sync
        $db->query("CREATE TABLE IF NOT EXISTS employment_histories (
            id VARCHAR(36) PRIMARY KEY,
            employee_id VARCHAR(36) NOT NULL,
            company_id VARCHAR(36),
            employment_type_id VARCHAR(36),
            employment_type_name VARCHAR(100),
            start_date DATE,
            end_date DATE,
            duration_value INT,
            duration_unit VARCHAR(20),
            action_type VARCHAR(50),
            status VARCHAR(20),
            remarks TEXT,
            created_by VARCHAR(36),
            created_by_name VARCHAR(100),
            created_at DATETIME,
            updated_at DATETIME
        )");

        // Ensure audit_logs table exists
        $db->query("CREATE TABLE IF NOT EXISTS audit_logs (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            user_id VARCHAR(36),
            action VARCHAR(100),
            entity VARCHAR(100),
            entity_id VARCHAR(36),
            old_values TEXT,
            new_values TEXT,
            ip_address VARCHAR(50),
            user_agent TEXT,
            created_at DATETIME
        )");

        // Ensure unique index on employees.employee_code for real duplicate enforcement
        try {
            $db->query("CREATE UNIQUE INDEX IF NOT EXISTS uq_employees_code ON employees(employee_code)");
        } catch (\Throwable $e) {}

        static::$schemaInitialized = true;
    }

    protected function setUp(): void
    {
        parent::setUp();
        static::ensureSchema();

        $db = Database::connect();
        static::registerSqliteFunctions($db);

        // Seed tenant master records
        $db->table('companies')->replace([
            'id'     => $this->tenantCompanyId,
            'name'   => 'Atomic Corp',
            'code'   => 'ATOM',
            'status' => 'Active',
        ]);

        $db->table('branches')->replace([
            'id'         => $this->tenantBranchId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'Atomic HQ',
            'code'       => 'BR-ATOM',
            'status'     => 'Active',
        ]);

        $db->table('departments')->replace([
            'id'         => $this->tenantDeptId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'Engineering',
            'code'       => 'DEP-ENG',
            'status'     => 'Active',
        ]);

        $db->table('designations')->replace([
            'id'         => $this->tenantDesgId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'Senior Engineer',
            'code'       => 'DES-SR',
            'status'     => 'Active',
        ]);

        $db->table('shifts')->replace([
            'id'         => $this->tenantShiftId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'Morning Shift',
            'code'       => 'SH-MORN',
            'status'     => 'Active',
        ]);

        $db->table('employment_types')->replace([
            'id'         => $this->tenantEmpTypeId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'Permanent',
            'code'       => 'PERM',
            'status'     => 'Active',
        ]);

        $db->table('roles')->replace([
            'id'         => $this->tenantRoleId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'Employee',
            'role_name'  => 'Employee',
            'role_code'  => 'employee',
            'status'     => 'Active',
        ]);

        $this->adminUser = [
            'id'          => 'usr-atom-admin-01',
            'company_id'  => $this->tenantCompanyId,
            'username'    => 'admin_atom',
            'name'        => 'Atom Admin',
            'email'       => 'admin@atomic.test',
            'role'        => 'Company Admin',
            'role_code'   => 'company_admin',
            'role_id'     => 'role-atom-admin',
            'permissions' => ['*'],
        ];

        $db->table('users')->replace([
            'id'            => $this->adminUser['id'],
            'company_id'    => $this->tenantCompanyId,
            'username'      => $this->adminUser['username'],
            'email'         => $this->adminUser['email'],
            'password_hash' => password_hash('Pass123!', PASSWORD_BCRYPT),
            'role_id'       => $this->adminUser['role_id'],
            'status'        => 'Active',
        ]);
    }

    /**
     * Create and initialize EmployeeController with an authenticated actor context
     */
    protected function createController(?array $actor = null): EmployeeController
    {
        $actorUser = $actor ?? $this->adminUser;

        \App\Services\PermissionService::clearCache();
        \App\Services\PermissionService::flushCache();

        $session = \Config\Services::session();
        $session->set([
            'id'                  => $actorUser['id'],
            'user_id'             => $actorUser['id'],
            'username'            => $actorUser['username'],
            'name'                => $actorUser['name'],
            'email'               => $actorUser['email'],
            'role'                => $actorUser['role'],
            'role_code'           => $actorUser['role_code'],
            'role_id'             => $actorUser['role_id'],
            'company_id'          => $actorUser['company_id'],
            'selected_company_id' => $actorUser['company_id'],
            'permissions'         => ['*'],
        ]);

        $request = \Config\Services::request();
        $response = \Config\Services::response();
        $logger = \Config\Services::logger();

        $controller = new EmployeeController();
        $controller->initController($request, $response, $logger);

        $refUser = new \ReflectionProperty(\App\Controllers\BaseController::class, 'currentUser');
        $refUser->setAccessible(true);
        $refUser->setValue($controller, $actorUser);

        return $controller;
    }

    /**
     * Configure request post data and headers for an AJAX JSON request
     */
    protected function setRequestPost(EmployeeController $controller, array $postData): void
    {
        $_SERVER['HTTP_X_REQUESTED_WITH'] = 'xmlhttprequest';
        $_SERVER['HTTP_ACCEPT'] = 'application/json';
        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_POST = $postData;

        $request = \Config\Services::request();
        if (method_exists($request, 'setHeader')) {
            $request->setHeader('X-Requested-With', 'xmlhttprequest');
            $request->setHeader('Accept', 'application/json');
        }
        if (method_exists($request, 'setGlobal')) {
            $request->setGlobal('post', $postData);
        }

        $refReq = new \ReflectionProperty(\App\Controllers\BaseController::class, 'request');
        $refReq->setAccessible(true);
        $refReq->setValue($controller, $request);
    }

    /**
     * Test (a): When generated or provided code is already taken by another row,
     * store creates the employee with a new code and all dependent rows (user, bank, salary) exist.
     */
    public function testDuplicateCodeResolvedUpFrontAndCreatesAllDependentRows()
    {
        $db = Database::connect();

        // 1. Pre-insert an existing employee with code EMP-100
        $existingEmpId = 'emp-pre-exist-01';
        $db->table('employees')->where('id', $existingEmpId)->delete();
        $db->table('employees')->where('employee_code', 'EMP-100')->delete();
        $db->table('employees')->insert([
            'id'            => $existingEmpId,
            'company_id'    => $this->tenantCompanyId,
            'branch_id'     => $this->tenantBranchId,
            'department_id' => $this->tenantDeptId,
            'designation_id'=> $this->tenantDesgId,
            'shift_id'      => $this->tenantShiftId,
            'employee_code' => 'EMP-100',
            'first_name'    => 'Prior',
            'last_name'     => 'Worker',
            'email'         => 'prior.worker@atomic.test',
            'status'        => 'Active',
            'joining_date'  => '2025-01-01',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->createController();
        $postData = [
            'employee_code'      => 'EMP-100', // Collides with existing row
            'first_name'         => 'Tariq',
            'last_name'          => 'Islam',
            'email'              => 'tariq.islam@atomic.test',
            'gender'             => 'male',
            'dob'                => '1992-05-15',
            'company_id'         => $this->tenantCompanyId,
            'branch_id'          => $this->tenantBranchId,
            'department_id'      => $this->tenantDeptId,
            'designation_id'     => $this->tenantDesgId,
            'shift_id'           => $this->tenantShiftId,
            'employment_type_id' => $this->tenantEmpTypeId,
            'joining_date'       => '2026-01-01',
            'basic_salary'       => 60000.00,
            'bank_name'          => 'Dutch Bangla Bank',
            'bank_account'       => 'DBBL-9988776655',
        ];
        $this->setRequestPost($controller, $postData);

        // Execute store()
        $res = $controller->store();

        // 2. Verify that employee was created with an automatically resolved new code
        $newEmp = $db->table('employees')
            ->where('company_id', $this->tenantCompanyId)
            ->where('email', 'tariq.islam@atomic.test')
            ->get()
            ->getRowArray();

        $this->assertNotEmpty($newEmp, 'Employee must be inserted in database');
        $this->assertNotEquals('EMP-100', $newEmp['employee_code'], 'Colliding code EMP-100 must have been resolved to a fresh code');
        $this->assertStringStartsWith('EMP-', $newEmp['employee_code'], 'Resolved code should keep standard prefix');

        $newEmpId = (string)$newEmp['id'];

        // 3. Verify dependent user account exists
        $userRow = $db->table('users')
            ->where('employee_id', $newEmpId)
            ->get()
            ->getRowArray();
        $this->assertNotEmpty($userRow, 'User login account must exist for the newly created employee');
        $this->assertEquals('tariq.islam', $userRow['username']);
        $this->assertEquals($this->tenantCompanyId, $userRow['company_id']);

        // 4. Verify dependent primary bank account exists
        $bankRow = $db->table('employee_bank_accounts')
            ->where('employee_id', $newEmpId)
            ->get()
            ->getRowArray();
        $this->assertNotEmpty($bankRow, 'Primary bank account record must exist for the employee');
        $this->assertEquals('Dutch Bangla Bank', $bankRow['bank_name']);
        $this->assertEquals('DBBL-9988776655', $bankRow['account_number']);

        // 5. Verify dependent salary record exists
        $salaryRow = $db->table('employee_salaries')
            ->where('employee_id', $newEmpId)
            ->get()
            ->getRowArray();
        $this->assertNotEmpty($salaryRow, 'Salary record must be assigned for the employee');
        $this->assertEquals(60000.00, (float)$salaryRow['basic_salary']);
    }

    /**
     * Test (a) part 2: Race condition at insert time rolls back tainted transaction,
     * begins fresh transaction, regenerates code, retries ONCE, and commits all dependent rows.
     */
    public function testRaceConditionAtInsertTimeRetriesInFreshTransactionAndSucceeds()
    {
        $db = Database::connect();

        // Subclass EmployeeModel to simulate a race collision specifically on the first insert attempt
        $raceModel = new class extends EmployeeModel {
            public int $insertAttempts = 0;
            public array $attemptedCodes = [];

            public function insert($data = null, bool $returnID = true)
            {
                $this->insertAttempts++;
                $code = $data['employee_code'] ?? '';
                $this->attemptedCodes[] = $code;

                if ($this->insertAttempts === 1) {
                    // Simulate another process concurrently inserting this code right before us
                    $db = Database::connect();
                    $db->table('employees')->insert([
                        'id'            => 'emp-race-occupant-01',
                        'company_id'    => $data['company_id'],
                        'employee_code' => $code,
                        'first_name'    => 'Concurrent',
                        'last_name'     => 'Runner',
                        'email'         => 'concurrent@atomic.test',
                        'status'        => 'Active',
                        'created_at'    => date('Y-m-d H:i:s'),
                    ]);
                }

                return parent::insert($data, $returnID);
            }
        };

        $controller = $this->createController();

        // Inject the raceModel into the controller
        $refEmpModel = new \ReflectionProperty(EmployeeController::class, 'empModel');
        $refEmpModel->setAccessible(true);
        $refEmpModel->setValue($controller, $raceModel);

        $postData = [
            'employee_code'      => 'EMP-RACE-01',
            'first_name'         => 'Farhan',
            'last_name'          => 'Ahmed',
            'email'              => 'farhan.ahmed@atomic.test',
            'gender'             => 'male',
            'dob'                => '1990-10-20',
            'company_id'         => $this->tenantCompanyId,
            'branch_id'          => $this->tenantBranchId,
            'department_id'      => $this->tenantDeptId,
            'designation_id'     => $this->tenantDesgId,
            'shift_id'           => $this->tenantShiftId,
            'employment_type_id' => $this->tenantEmpTypeId,
            'joining_date'       => '2026-01-01',
            'basic_salary'       => 75000.00,
            'bank_name'          => 'Standard Chartered',
            'bank_account'       => 'SCB-55443322',
        ];
        $this->setRequestPost($controller, $postData);

        // Execute store()
        $controller->store();

        // Verify the model was called twice (initial collision + 1 retry in fresh transaction)
        $this->assertEquals(2, $raceModel->insertAttempts, 'Must retry insert exactly once in fresh transaction');
        $this->assertNotEquals($raceModel->attemptedCodes[0], $raceModel->attemptedCodes[1], 'Retry code must differ from collided code');

        // Verify the employee was saved with the retry code
        $savedEmp = $db->table('employees')
            ->where('email', 'farhan.ahmed@atomic.test')
            ->get()
            ->getRowArray();
        $this->assertNotEmpty($savedEmp, 'Employee must be saved after successful retry');
        $this->assertEquals($raceModel->attemptedCodes[1], $savedEmp['employee_code']);

        $empId = (string)$savedEmp['id'];

        // Verify dependent rows exist and were committed
        $user = $db->table('users')->where('employee_id', $empId)->get()->getRowArray();
        $this->assertNotEmpty($user, 'User must exist after retry');

        $bank = $db->table('employee_bank_accounts')->where('employee_id', $empId)->get()->getRowArray();
        $this->assertNotEmpty($bank, 'Bank account must exist after retry');

        $salary = $db->table('employee_salaries')->where('employee_id', $empId)->get()->getRowArray();
        $this->assertNotEmpty($salary, 'Salary record must exist after retry');
        $this->assertEquals(75000.00, (float)$salary['basic_salary']);
    }

    /**
     * Test (b): When the duplicate retry ALSO fails, the transaction rolls back completely,
     * leaving nothing in employees, users, bank, or salary tables.
     */
    public function testDuplicateRetryFailureRollsBackCleanlyLeavingNoOrphanedRows()
    {
        $db = Database::connect();

        // Model that fails on BOTH attempt 1 and retry attempt 2
        $failingModel = new class extends EmployeeModel {
            public int $attempts = 0;

            public function insert($data = null, bool $returnID = true)
            {
                $this->attempts++;
                // Set database error to 1062 (duplicate entry)
                $db = Database::connect();
                // Return false to simulate failed insert
                return false;
            }
        };

        $controller = $this->createController();
        $refEmpModel = new \ReflectionProperty(EmployeeController::class, 'empModel');
        $refEmpModel->setAccessible(true);
        $refEmpModel->setValue($controller, $failingModel);

        $testEmail = 'retry.fail@atomic.test';
        $postData = [
            'employee_code'      => 'EMP-FAIL-01',
            'first_name'         => 'Nabila',
            'last_name'          => 'Chowdhury',
            'email'              => $testEmail,
            'gender'             => 'female',
            'dob'                => '1995-04-12',
            'company_id'         => $this->tenantCompanyId,
            'branch_id'          => $this->tenantBranchId,
            'department_id'      => $this->tenantDeptId,
            'designation_id'     => $this->tenantDesgId,
            'shift_id'           => $this->tenantShiftId,
            'employment_type_id' => $this->tenantEmpTypeId,
            'joining_date'       => '2026-01-01',
            'basic_salary'       => 50000.00,
            'bank_name'          => 'Prime Bank',
            'bank_account'       => 'PB-00112233',
        ];
        $this->setRequestPost($controller, $postData);

        // Execute store()
        $response = $controller->store();

        // Verify response indicates failure
        $this->assertEquals(422, $response->getStatusCode(), 'Must return 422 Unprocessable Entity when retry fails');

        // Verify 0 rows left across all tables
        $empCount = $db->table('employees')->where('email', $testEmail)->countAllResults();
        $this->assertEquals(0, $empCount, 'No employee record must remain after retry failure');

        $userCount = $db->table('users')->where('email', $testEmail)->countAllResults();
        $this->assertEquals(0, $userCount, 'No user record must remain after retry failure');

        $bankCount = $db->table('employee_bank_accounts')->where('account_number', 'PB-00112233')->countAllResults();
        $this->assertEquals(0, $bankCount, 'No bank account must remain after retry failure');

        $salaryCount = $db->table('employee_salaries')->where('basic_salary', 50000.00)->where('company_id', $this->tenantCompanyId)->countAllResults();
        $this->assertEquals(0, $salaryCount, 'No salary record must remain after retry failure');
    }

    /**
     * Test (c): An FK or invalid reference failure (e.g. invalid department_id) leaves no rows.
     */
    public function testFkFailureLeavesNoRows()
    {
        $db = Database::connect();

        $controller = $this->createController();
        $invalidDeptId = 'dept-non-existent-9999';

        $testEmail = 'fk.fail@atomic.test';
        $postData = [
            'employee_code'      => 'EMP-FK-01',
            'first_name'         => 'Mustafa',
            'last_name'          => 'Kamal',
            'email'              => $testEmail,
            'gender'             => 'male',
            'dob'                => '1988-08-08',
            'company_id'         => $this->tenantCompanyId,
            'branch_id'          => $this->tenantBranchId,
            'department_id'      => $invalidDeptId, // Invalid FK / reference
            'designation_id'     => $this->tenantDesgId,
            'shift_id'           => $this->tenantShiftId,
            'employment_type_id' => $this->tenantEmpTypeId,
            'joining_date'       => '2026-01-01',
            'basic_salary'       => 80000.00,
            'bank_name'          => 'BRAC Bank',
            'bank_account'       => 'BRAC-44332211',
        ];
        $this->setRequestPost($controller, $postData);

        // Execute store()
        $response = $controller->store();

        // Response must reject invalid department
        $this->assertTrue(
            in_array($response->getStatusCode(), [400, 422], true),
            'Invalid reference data must be rejected with 400 or 422'
        );

        // Verify 0 rows left in employees, users, bank, salary
        $empCount = $db->table('employees')->where('email', $testEmail)->countAllResults();
        $this->assertEquals(0, $empCount, 'No employee record must be created on reference/FK failure');

        $userCount = $db->table('users')->where('email', $testEmail)->countAllResults();
        $this->assertEquals(0, $userCount, 'No user record must be created on reference/FK failure');

        $bankCount = $db->table('employee_bank_accounts')->where('account_number', 'BRAC-44332211')->countAllResults();
        $this->assertEquals(0, $bankCount, 'No bank record must be created on reference/FK failure');

        $salaryCount = $db->table('employee_salaries')->where('basic_salary', 80000.00)->where('company_id', $this->tenantCompanyId)->countAllResults();
        $this->assertEquals(0, $salaryCount, 'No salary record must be created on reference/FK failure');
    }
}
