<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\LeaveService;
use App\Services\Leave\LeaveApplicationService;

class LeaveBackdatedApplicationTest extends TestCase
{
    private LeaveService $leaveService;
    private array $defaultEmp;

    protected function setUp(): void
    {
        parent::setUp();
        $this->leaveService = new LeaveService();
        $this->defaultEmp = [
            'id'                   => 'emp-test-01',
            'company_id'           => 'comp-01',
            'branch_id'            => null,
            'department_id'        => 'dept-01',
            'designation_id'       => null,
            'shift_id'             => null,
            'reporting_to'         => 'emp-mgr-01',
            'reporting_manager_id' => 'emp-mgr-01',
            'manager_id'           => 'emp-mgr-01',
            'status'               => 'Active',
            'joining_date'         => '2023-01-01',
            'confirmation_date'    => '2023-07-01',
        ];
    }

    /**
     * Test 1: Employee, own leave, 3 days in the past, default rules -> accepted, status Pending, not auto-approved.
     */
    public function testEmployeeOwnLeaveThreeDaysInPastDefaultRulesAcceptedPendingNotAutoApproved()
    {
        $fromDate = date('Y-m-d', strtotime('-3 days'));
        $toDate = $fromDate;

        // Default rules: allow_backdated_application is not explicitly false (defaults to true), max_backdate_days = 3
        $leaveType = [
            'id'                          => 'lt-al-01',
            'company_id'                  => 'comp-01',
            'name'                        => 'Annual Leave',
            'code'                        => 'AL',
            'is_paid'                     => 1,
            'allow_backdated_application' => true,
            'max_backdate_days'           => 3,
            'backdated_role_requirement'  => 'Manager and HR',
            'is_auto_approved'            => 0,
            'approval_required'           => 1,
        ];

        $params = [
            'from_date'          => $fromDate,
            'to_date'            => $toDate,
            'applied_by'         => 'emp-test-01',
            'user_id'            => 'emp-test-01',
            'is_own_application' => true,
            'is_manager'         => false,
            'can_manage_leave'   => false,
            'reason'             => 'Regularizing previous absence due to family emergency',
        ];

        $sim = $this->leaveService->simulateLeaveApplication($this->defaultEmp, $leaveType, $params);

        $this->assertTrue($sim['validation']['isValid'], "3 days backdated request within 3-day max_backdate_days must be accepted.");
        $this->assertFalse($sim['is_auto_approved'], "Backdated leave must not be auto-approved.");
        $this->assertFalse($sim['validation']['is_auto_approved'], "Validation block must also report is_auto_approved as false.");

        $autoDecision = LeaveApplicationService::determineAutoApproval([
            'is_backdated'            => true,
            'backdated_role'          => 'Manager and HR',
            'is_own_application'      => true,
            'is_hr'                   => false,
            'is_manager'              => false,
            'approval_required'       => true,
            'is_auto_approved'        => false,
            'auto_approve_under_days' => 5.0,
            'chargeable_days'         => 1.0,
            'is_emergency'            => false,
        ]);
        $this->assertFalse($autoDecision, "Backdated leave must remain Pending and never auto-approve.");
    }

    /**
     * Test 2: Employee, own leave, past the max_backdate_days limit -> rejected.
     */
    public function testEmployeeOwnLeavePastMaxBackdateDaysLimitRejected()
    {
        // 5 days in the past when limit is 3 days
        $fromDate = date('Y-m-d', strtotime('-5 days'));
        $toDate = $fromDate;

        $leaveType = [
            'id'                          => 'lt-al-02',
            'company_id'                  => 'comp-01',
            'name'                        => 'Annual Leave',
            'code'                        => 'AL',
            'is_paid'                     => 1,
            'allow_backdated_application' => true,
            'max_backdate_days'           => 3,
            'backdated_role_requirement'  => 'Manager and HR',
        ];

        $params = [
            'from_date'          => $fromDate,
            'to_date'            => $toDate,
            'applied_by'         => 'emp-test-01',
            'user_id'            => 'emp-test-01',
            'is_own_application' => true,
            'is_manager'         => false,
            'can_manage_leave'   => false,
            'reason'             => 'Attempting to backdate beyond allowed window',
        ];

        $sim = $this->leaveService->simulateLeaveApplication($this->defaultEmp, $leaveType, $params);

        $this->assertFalse($sim['validation']['isValid'], "Employee applying past max_backdate_days limit must be rejected.");
        $hasLimitError = false;
        foreach ($sim['errors'] as $err) {
            if (strpos($err, "Backdated limit exceeded for 'Annual Leave'") !== false && strpos($err, "3 days in the past") !== false) {
                $hasLimitError = true;
                break;
            }
        }
        $this->assertTrue($hasLimitError, "Error message must name the leave type and the limit.");
    }

    /**
     * Test 3: Employee, allow_backdated_application=false -> rejected.
     */
    public function testEmployeeAllowBackdatedApplicationFalseRejected()
    {
        $fromDate = date('Y-m-d', strtotime('-1 day'));
        $toDate = $fromDate;

        $leaveType = [
            'id'                          => 'lt-sl-03',
            'company_id'                  => 'comp-01',
            'name'                        => 'Special Leave',
            'code'                        => 'SPL',
            'is_paid'                     => 1,
            'allow_backdated_application' => false, // Explicitly disabled
            'max_backdate_days'           => 7,
        ];

        $params = [
            'from_date'          => $fromDate,
            'to_date'            => $toDate,
            'applied_by'         => 'emp-test-01',
            'user_id'            => 'emp-test-01',
            'is_own_application' => true,
            'is_manager'         => false,
            'can_manage_leave'   => false,
            'reason'             => 'Employee attempting backdated leave on disabled category',
        ];

        $sim = $this->leaveService->simulateLeaveApplication($this->defaultEmp, $leaveType, $params);

        $this->assertFalse($sim['validation']['isValid'], "Employee applying when allow_backdated_application=false must be rejected.");
        $hasDisabledError = false;
        foreach ($sim['errors'] as $err) {
            if (strpos($err, "Backdated leave applications are strictly disabled for 'Special Leave'") !== false) {
                $hasDisabledError = true;
                break;
            }
        }
        $this->assertTrue($hasDisabledError, "Error message must state backdated applications are strictly disabled and name the leave category.");
    }

    /**
     * Test 4: HR recording for another employee, allow_backdated_application=false -> accepted.
     */
    public function testHrRecordingForAnotherEmployeeAllowBackdatedApplicationFalseAccepted()
    {
        $fromDate = date('Y-m-d', strtotime('-4 days'));
        $toDate = $fromDate;

        $leaveType = [
            'id'                          => 'lt-sl-04',
            'company_id'                  => 'comp-01',
            'name'                        => 'Special Leave',
            'code'                        => 'SPL',
            'is_paid'                     => 1,
            'allow_backdated_application' => false, // Disabled for employee self-application
            'max_backdate_days'           => 2,     // Would block regular employee
        ];

        // HR user recording on behalf of another employee
        $params = [
            'from_date'          => $fromDate,
            'to_date'            => $toDate,
            'applied_by'         => 'usr-hr-admin-01',
            'user_id'            => 'usr-hr-admin-01',
            'is_own_application' => false, // Recording for another staff member
            'can_manage_leave'   => true,
            'is_hr'              => true,
            'reason'             => 'HR administrative backfill for staff hospitalization and emergency',
        ];

        $sim = $this->leaveService->simulateLeaveApplication($this->defaultEmp, $leaveType, $params);

        $hasBackdatedError = false;
        foreach ($sim['errors'] as $err) {
            if (stripos($err, 'Backdated') !== false) {
                $hasBackdatedError = true;
                break;
            }
        }
        $this->assertFalse($hasBackdatedError, "HR recording for another employee must be exempt from allow_backdated_application=false and max_backdate_days.");
    }

    /**
     * Test 5: Backdated with is_auto_approved=true -> still Pending.
     */
    public function testBackdatedWithIsAutoApprovedTrueStillPending()
    {
        $fromDate = date('Y-m-d', strtotime('-2 days'));
        $toDate = $fromDate;

        $leaveType = [
            'id'                          => 'lt-cl-05',
            'company_id'                  => 'comp-01',
            'name'                        => 'Casual Leave',
            'code'                        => 'CL',
            'is_paid'                     => 1,
            'approval_required'           => 1,
            'is_auto_approved'            => 1,   // Explicitly marked auto-approved
            'auto_approve_under_days'     => 5.0, // Duration (1 day) is under threshold
            'allow_backdated_application' => true,
            'max_backdate_days'           => 7,
            'backdated_role_requirement'  => 'Manager and HR',
        ];

        $params = [
            'from_date'          => $fromDate,
            'to_date'            => $toDate,
            'applied_by'         => 'emp-test-01',
            'user_id'            => 'emp-test-01',
            'is_own_application' => true,
            'is_manager'         => false,
            'can_manage_leave'   => false,
            'reason'             => 'Casual backdated regularization',
        ];

        $sim = $this->leaveService->simulateLeaveApplication($this->defaultEmp, $leaveType, $params);

        $this->assertFalse($sim['is_auto_approved'], "Backdated leave with is_auto_approved=true must NEVER be auto-approved.");
        $this->assertFalse($sim['validation']['is_auto_approved']);

        // Directly test determineAutoApproval logic
        $autoDecision = LeaveApplicationService::determineAutoApproval([
            'is_backdated'            => true,
            'backdated_role'          => 'Manager and HR',
            'is_own_application'      => true,
            'is_hr'                   => false,
            'is_manager'              => false,
            'approval_required'       => true,
            'is_auto_approved'        => true,
            'auto_approve_under_days' => 5.0,
            'chargeable_days'         => 1.0,
            'is_emergency'            => false,
        ]);
        $this->assertFalse($autoDecision, "determineAutoApproval must strictly return false for backdated leaves.");
    }

    /**
     * Test 6: Backdated with backdated_role_requirement='Manager and HR' -> both approver steps are created.
     */
    public function testBackdatedWithBackdatedRoleRequirementManagerAndHrBothApproverStepsCreated()
    {
        $workflow = [
            'workflow_type'   => 'Multi-Tier',
            'tier_conditions' => [
                [
                    'min_days'           => 1,
                    'max_days'           => 2,
                    'required_approvers' => ['Manager'], // Standard 1-2 day duration only needs Manager
                ],
                [
                    'min_days'           => 3,
                    'max_days'           => 7,
                    'required_approvers' => ['Manager', 'HR Admin'],
                ],
            ],
        ];

        // 1.0 day leave (normally would only require ['Manager'])
        $requiredApprovers = LeaveApplicationService::resolveRequiredApproversForApplication(
            $workflow,
            1.0,
            true, // is_backdated = true
            'Manager and HR'
        );

        $this->assertContains('Manager', $requiredApprovers);
        $this->assertContains('HR Admin', $requiredApprovers);
        $this->assertCount(2, $requiredApprovers);

        // Generate approval steps
        $appService = new LeaveApplicationService($this->leaveService);
        $steps = $appService->buildApprovalSteps('lv-test-backdate-01', $requiredApprovers, $this->defaultEmp, false);

        $this->assertCount(2, $steps, "Exactly 2 approval steps must be created for 'Manager and HR'.");
        $this->assertEquals('Line Manager', $steps[0]['approver_role']);
        $this->assertEquals('Pending', $steps[0]['status']);
        $this->assertEquals('HR Administration', $steps[1]['approver_role']);
        $this->assertEquals('Pending', $steps[1]['status']);
    }
}
