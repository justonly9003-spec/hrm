<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Controllers\Employee\EmployeeController;

/**
 * Tests for Hardened EmployeeController::exportCsv()
 *
 * Requirements:
 * 1. Write an audit entry for every export: actor, filters, row count, and which sensitive
 *    column groups were included (salary / bank+TIN).
 * 2. Rename header "Role" to "Employment Type".
 * 3. Replace "Manager ID" (internal id) with the manager's employee_code and full name (using mgr join).
 * 4. sanitizeCell(): only prefix ' for cells starting with = + - @ that are NOT a plain phone number
 *    or number (keep +8801712345678 and -12.50 unchanged, still neutralise =cmd|...).
 * 5. Stream rows with a chunked query (about 1000 per page) instead of loading everything with get()->getResultArray().
 */
class EmployeeExportCsvSecurityTest extends TestCase
{
    private string $controllerSrc;

    protected function setUp(): void
    {
        parent::setUp();
        $appDir = dirname(__DIR__, 2);
        $this->controllerSrc = file_get_contents($appDir . '/app/Controllers/Employee/EmployeeController.php');
    }

    /**
     * Test 1: sanitizeCell preserves plain phone numbers and numbers
     */
    public function testSanitizeCellPreservesPlainNumbersAndPhoneNumbers()
    {
        // Phone numbers starting with +
        $this->assertEquals('+8801712345678', EmployeeController::sanitizeCell('+8801712345678'),
            'Phone number +8801712345678 must remain unchanged without a single quote prefix.');

        $this->assertEquals('+1 (555) 123-4567', EmployeeController::sanitizeCell('+1 (555) 123-4567'),
            'International formatted phone number +1 (555) 123-4567 must remain unchanged.');

        $this->assertEquals('+44 20 7946 0958', EmployeeController::sanitizeCell('+44 20 7946 0958'),
            'UK formatted phone number must remain unchanged.');

        // Negative and positive numbers
        $this->assertEquals('-12.50', EmployeeController::sanitizeCell('-12.50'),
            'Negative number -12.50 must remain unchanged without single quote prefix.');

        $this->assertEquals('+12.50', EmployeeController::sanitizeCell('+12.50'),
            'Positive number +12.50 must remain unchanged without single quote prefix.');

        $this->assertEquals('-100', EmployeeController::sanitizeCell('-100'),
            'Integer -100 must remain unchanged.');

        $this->assertEquals('+5', EmployeeController::sanitizeCell('+5'),
            'Integer +5 must remain unchanged.');

        // Standard text and empty values
        $this->assertEquals('Engineering', EmployeeController::sanitizeCell('Engineering'));
        $this->assertEquals('', EmployeeController::sanitizeCell(''));
        $this->assertEquals('', EmployeeController::sanitizeCell(null));
    }

    /**
     * Test 2: sanitizeCell neutralises dangerous formula injections
     */
    public function testSanitizeCellNeutralisesFormulasAndDdeInjections()
    {
        // Formula injection starting with =
        $this->assertEquals("'=1+1", EmployeeController::sanitizeCell('=1+1'),
            '=1+1 must be neutralised with a leading single quote.');

        // Function injection starting with @
        $this->assertEquals("'@SUM(A1)", EmployeeController::sanitizeCell('@SUM(A1)'),
            '@SUM(A1) must be neutralised with a leading single quote.');

        // DDE command execution starting with =
        $this->assertEquals("'=cmd|' /C calc'!A0", EmployeeController::sanitizeCell("=cmd|' /C calc'!A0"),
            '=cmd| command injection must be neutralised.');

        // Command execution starting with +
        $this->assertEquals("'+cmd|' /C calc'!A0", EmployeeController::sanitizeCell("+cmd|' /C calc'!A0"),
            '+cmd| command injection must be neutralised.');

        // Command execution starting with -
        $this->assertEquals("'-cmd|' /C calc'!A0", EmployeeController::sanitizeCell("-cmd|' /C calc'!A0"),
            '-cmd| command injection must be neutralised.');

        // Arithmetic expressions starting with + or - that are NOT plain numbers
        $this->assertEquals("'+1+1", EmployeeController::sanitizeCell('+1+1'),
            '+1+1 has multiple operators and must be neutralised.');

        $this->assertEquals("'-2+3*4", EmployeeController::sanitizeCell('-2+3*4'),
            '-2+3*4 is a formula and must be neutralised.');

        // Tab and carriage return characters
        $this->assertEquals("'\tDDE", EmployeeController::sanitizeCell("\tDDE"));
        $this->assertEquals("'\rDDE", EmployeeController::sanitizeCell("\rDDE"));
    }

    /**
     * Test 3: Header "Role" renamed to "Employment Type" and "Manager ID" replaced with Manager
     */
    public function testHeadersRenamedAndManagerFieldReplaced()
    {
        $startPos = strpos($this->controllerSrc, 'public function exportCsv(');
        $nextMethodPos = strpos($this->controllerSrc, 'public function confirmStatus(', $startPos);
        $exportMethodBody = substr($this->controllerSrc, $startPos, $nextMethodPos - $startPos);

        // Assert "Employment Type" replaces "Role" in headers array
        $this->assertStringContainsString("'Employment Type'", $exportMethodBody,
            'exportCsv headers must contain "Employment Type".');
        $this->assertStringNotContainsString("'Role'", $exportMethodBody,
            'exportCsv headers must NOT contain legacy "Role" header.');

        // Assert "Manager" replaces "Manager ID" in headers array
        $this->assertStringContainsString("'Manager'", $exportMethodBody,
            'exportCsv headers must contain "Manager".');
        $this->assertStringNotContainsString("'Manager ID'", $exportMethodBody,
            'exportCsv headers must NOT contain legacy "Manager ID" header.');

        // Assert manager employee code is selected from the mgr join
        $this->assertStringContainsString("mgr.employee_code as manager_code", $exportMethodBody,
            'exportCsv must select mgr.employee_code as manager_code.');

        // Assert manager cell formats manager code and full name
        $this->assertStringContainsString('$emp[\'manager_code\']', $exportMethodBody,
            'exportCsv row mapping must incorporate manager_code.');
        $this->assertStringContainsString('$emp[\'manager_name\']', $exportMethodBody,
            'exportCsv row mapping must incorporate manager_name.');
    }

    /**
     * Test 4: Chunked query streaming (approx 1000 per page) instead of loading all at once
     */
    public function testExportStreamsRowsWithChunkedQuery()
    {
        $startPos = strpos($this->controllerSrc, 'public function exportCsv(');
        $nextMethodPos = strpos($this->controllerSrc, 'public function confirmStatus(', $startPos);
        $exportMethodBody = substr($this->controllerSrc, $startPos, $nextMethodPos - $startPos);

        // Assert NO unchunked $builder->get()->getResultArray() loading all rows at once
        $this->assertStringNotContainsString('$employees = $builder', $exportMethodBody,
            'exportCsv must NOT load all employees at once into an $employees array.');

        // Assert chunk size is configured to 1000
        $this->assertStringContainsString('$chunkSize = 1000', $exportMethodBody,
            'exportCsv must configure chunk size of 1000 rows.');

        // Assert chunked query loop uses limit($chunkSize, $offset)
        $this->assertStringContainsString('limit($chunkSize, $offset)', $exportMethodBody,
            'exportCsv must execute chunked queries with limit($chunkSize, $offset).');

        // Assert builder is cloned to avoid resetting base query parameters across pages
        $this->assertStringContainsString('clone $builder', $exportMethodBody,
            'exportCsv must clone $builder for each page iteration.');
    }

    /**
     * Test 5: Audit log entry written with actor, filters, row count, and sensitive column groups
     */
    public function testExportWritesAuditTrailEntry()
    {
        $startPos = strpos($this->controllerSrc, 'public function exportCsv(');
        $nextMethodPos = strpos($this->controllerSrc, 'public function confirmStatus(', $startPos);
        $exportMethodBody = substr($this->controllerSrc, $startPos, $nextMethodPos - $startPos);

        // Assert audit method is called
        $this->assertStringContainsString('$this->audit(', $exportMethodBody,
            'exportCsv must call $this->audit().');

        // Assert action is logged
        $this->assertStringContainsString('employee.export_csv', $exportMethodBody,
            'exportCsv must log action employee.export_csv.');

        // Assert row count is recorded
        $this->assertStringContainsString('row_count', $exportMethodBody,
            'Audit record must capture row_count.');

        // Assert filters are recorded
        $this->assertStringContainsString('filters', $exportMethodBody,
            'Audit record must capture filters applied.');

        // Assert sensitive groups (salary and bank+TIN) are recorded
        $this->assertStringContainsString('sensitive_groups', $exportMethodBody,
            'Audit record must capture sensitive_groups included.');
        $this->assertStringContainsString('salary', $exportMethodBody,
            'Audit record must capture whether salary group was included.');
        $this->assertStringContainsString('bank_tin', $exportMethodBody,
            'Audit record must capture whether bank/TIN group was included.');
    }

    /**
     * Test 6: Audit row contains actor email, username, and ID extracted via $this->currentUser() method
     */
    public function testExportAuditRowContainsActorEmailAndUsername()
    {
        $startPos = strpos($this->controllerSrc, 'public function exportCsv(');
        $nextMethodPos = strpos($this->controllerSrc, 'public function confirmStatus(', $startPos);
        $exportMethodBody = substr($this->controllerSrc, $startPos, $nextMethodPos - $startPos);

        // Verify currentUser is called as a method, not accessed as a property
        $this->assertStringContainsString('$this->currentUser()', $exportMethodBody,
            'exportCsv must call $this->currentUser() as a method to obtain authenticated actor.');
        $this->assertStringNotContainsString('$this->currentUser[\'email\']', $exportMethodBody,
            'exportCsv must NOT access $this->currentUser as an array property.');
        $this->assertStringNotContainsString('$this->currentUser[\'username\']', $exportMethodBody,
            'exportCsv must NOT access $this->currentUser as an array property.');

        // Verify actor array includes email, username, and id
        $this->assertStringContainsString('\'email\'', $exportMethodBody,
            'exportCsv audit payload must contain actor email.');
        $this->assertStringContainsString('\'username\'', $exportMethodBody,
            'exportCsv audit payload must contain actor username.');
        $this->assertStringContainsString('\'id\'', $exportMethodBody,
            'exportCsv audit payload must contain actor id.');
    }
}
