<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobileAttendanceSummaryTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;
    private array $device = ['device_uid' => 'dev-summary-1', 'platform' => 'android'];

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);

        foreach (['attendance_logs', 'attendance_corrections', 'shifts', 'holidays', 'leave_applications', 'leave_types', 'company_early_closures', 'unmatched_biometric_logs'] as $t) {
            $this->db->query("DROP TABLE IF EXISTS {$t}");
        }

        $this->db->query("CREATE TABLE shifts (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            name VARCHAR(100),
            start_time TIME,
            end_time TIME,
            grace_time INT DEFAULT 15,
            late_grace_period_mins INT DEFAULT 15,
            weekly_off VARCHAR(255) DEFAULT 'Friday,Saturday',
            work_days VARCHAR(255) NULL,
            night_shift INT DEFAULT 0,
            is_active INT DEFAULT 1
        )");

        $this->db->query("CREATE TABLE attendance_logs (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            employee_id VARCHAR(36),
            employee_code VARCHAR(50) NULL,
            date DATE,
            check_in TIME NULL,
            check_out TIME NULL,
            in_time TIME NULL,
            out_time TIME NULL,
            clock_in TIME NULL,
            clock_out TIME NULL,
            working_hours DECIMAL(6,2) DEFAULT 0,
            gross_hours DECIMAL(6,2) DEFAULT 0,
            net_hours DECIMAL(6,2) DEFAULT 0,
            overtime_hours DECIMAL(6,2) DEFAULT 0,
            late_minutes INT DEFAULT 0,
            early_out_minutes INT DEFAULT 0,
            status VARCHAR(50) DEFAULT 'Present',
            day_type VARCHAR(20) DEFAULT 'Regular',
            is_approved INT DEFAULT 1,
            notes TEXT NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE attendance_corrections (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            employee_id VARCHAR(36),
            attendance_date DATE,
            check_in TIME NULL,
            check_out TIME NULL,
            working_hours DECIMAL(6,2) DEFAULT 0,
            late_minutes INT DEFAULT 0,
            early_out_minutes INT DEFAULT 0,
            status VARCHAR(20) DEFAULT 'Approved',
            reason TEXT NULL,
            approved_by VARCHAR(36) NULL,
            approved_at DATETIME NULL,
            created_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE holidays (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            name VARCHAR(100),
            from_date DATE,
            to_date DATE,
            type VARCHAR(30) DEFAULT 'public',
            is_active INT DEFAULT 1
        )");

        $this->db->query("CREATE TABLE leave_types (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            name VARCHAR(100),
            code VARCHAR(30),
            is_paid INT DEFAULT 1
        )");

        $this->db->query("CREATE TABLE leave_applications (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            employee_id VARCHAR(36),
            leave_type_id VARCHAR(36),
            start_date DATE,
            end_date DATE,
            days INT DEFAULT 1,
            status VARCHAR(20) DEFAULT 'Approved'
        )");

        // Seed a standard general shift
        $this->db->table('shifts')->insert([
            'id'                     => 's-gen',
            'company_id'             => 'c-1',
            'name'                   => 'General Shift',
            'start_time'             => '09:00:00',
            'end_time'               => '18:00:00',
            'grace_time'             => 15,
            'late_grace_period_mins' => 15,
            'weekly_off'             => 'Friday,Saturday',
            'is_active'              => 1,
        ]);

        // Link e-1 to this shift and department/designation
        $this->db->table('departments')->insert(['id' => 'dept-1', 'name' => 'Engineering']);
        $this->db->table('designations')->insert(['id' => 'desig-1', 'name' => 'Software Engineer']);
        $this->db->table('branches')->insert(['id' => 'br-1', 'name' => 'HQ Dhaka']);

        $this->db->table('employees')->where('id', 'e-1')->update([
            'shift_id'       => 's-gen',
            'department_id'  => 'dept-1',
            'designation_id' => 'desig-1',
            'branch_id'      => 'br-1',
            'joining_date'   => '2026-01-01',
        ]);
    }

    private function token(string $company = 'ACME', string $id = 'rahim'): array
    {
        $res = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => $company, 'identifier' => $id, 'password' => self::PASSWORD, 'device' => $this->device,
        ]);
        $json = json_decode($res->getJSON(), true);
        return ['Authorization' => 'Bearer ' . $json['data']['tokens']['access_token']];
    }

    private function json($res): array
    {
        return json_decode($res->getJSON(), true);
    }

    public function testUnauthenticatedRequestsReturn401(): void
    {
        // 1. Missing Authorization header
        $resNoAuth = $this->get('api/mobile/v1/attendance/summary');
        $resNoAuth->assertStatus(401);

        // 2. Garbage Bearer token
        $resBadAuth = $this->withHeaders(['Authorization' => 'Bearer mat_garbage_token'])->get('api/mobile/v1/attendance/summary');
        $resBadAuth->assertStatus(401);

        // 3. Same check for api/v1 alias
        $resAliasNoAuth = $this->get('api/v1/attendance/summary');
        $resAliasNoAuth->assertStatus(401);
    }

    public function testUserWithoutLinkedEmployeeProfileReturns403(): void
    {
        // Add a user without an employee_id
        $this->addUser('u-no-emp', 'unlinked', 'unlinked@acme.test', 'c-1', null, 'r-sa');
        $resLogin = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => 'ACME', 'identifier' => 'unlinked', 'password' => self::PASSWORD, 'device' => $this->device,
        ]);
        $token = json_decode($resLogin->getJSON(), true)['data']['tokens']['access_token'];

        $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])->get('api/mobile/v1/attendance/summary');
        $res->assertStatus(403);
        $body = $this->json($res);
        $this->assertFalse($body['success']);
        $this->assertStringContainsString('No employee profile is linked', $body['message']);
    }

    public function testDateBoundariesAndValidation(): void
    {
        $h = $this->token('ACME', 'rahim');

        // 1. Inverted dates: from > to
        $resInverted = $this->withHeaders($h)->get('api/mobile/v1/attendance/summary?from=2026-05-10&to=2026-05-01');
        $resInverted->assertStatus(422);
        $bodyInverted = $this->json($resInverted);
        $this->assertFalse($bodyInverted['success']);
        $this->assertStringContainsString('from cannot be after to', $bodyInverted['message']);

        // 2. Invalid date formats
        $resBadDate = $this->withHeaders($h)->get('api/mobile/v1/attendance/summary?from=2026/05/01&to=2026-05-10');
        $resBadDate->assertStatus(422);
        $bodyBadDate = $this->json($resBadDate);
        $this->assertFalse($bodyBadDate['success']);
        $this->assertStringContainsString('strict YYYY-MM-DD', $bodyBadDate['message']);

        // 3. Span exceeds MAX_HISTORY_DAYS (62 days)
        $resTooLong = $this->withHeaders($h)->get('api/mobile/v1/attendance/summary?from=2026-01-01&to=2026-03-15');
        $resTooLong->assertStatus(422);
        $bodyTooLong = $this->json($resTooLong);
        $this->assertFalse($bodyTooLong['success']);
        $this->assertStringContainsString('Date range cannot exceed 62 days', $bodyTooLong['message']);

        // 4. Invalid month format
        $resBadMonth = $this->withHeaders($h)->get('api/mobile/v1/attendance/summary?month=invalid-month');
        $resBadMonth->assertStatus(422);
    }

    public function testEmptyDataCalculatesAccuratelyWithoutFabrication(): void
    {
        $h = $this->token('ACME', 'rahim');

        // Query a 7-day range where no punches exist: 2026-05-01 (Friday) to 2026-05-07 (Thursday)
        $res = $this->withHeaders($h)->get('api/mobile/v1/attendance/summary?from=2026-05-01&to=2026-05-07');
        $res->assertStatus(200);
        $body = $this->json($res);

        $this->assertTrue($body['success']);
        $data = $body['data'];
        $summary = $data['summary'];

        // Total days: 7
        $this->assertSame(7, $summary['total_days']);
        // No punches recorded: 0 present, 0 working hours, 0 late
        $this->assertSame(0, $summary['present']);
        $this->assertSame(0, $summary['half_day']);
        $this->assertSame(0, $summary['present_total']);
        $this->assertSame(0.0, (float)$summary['total_working_hours']);
        $this->assertSame(0, $summary['total_late_minutes']);

        // Shift has weekly_off = 'Friday,Saturday': 2026-05-01 (Fri) and 2026-05-02 (Sat) are Weekly Off
        $this->assertSame(2, $summary['weekly_off']);

        // None of the daily breakdown entries should have fabricated clock in/out
        foreach ($data['daily_breakdown'] as $day) {
            $this->assertNull($day['check_in']);
            $this->assertNull($day['check_out']);
            $this->assertSame(0.0, (float)$day['working_hours']);
        }
    }

    public function testEmployeeJoiningDateRespected(): void
    {
        // Update e-1 joining date to 2026-05-04 (Monday)
        $this->db->table('employees')->where('id', 'e-1')->update(['joining_date' => '2026-05-04']);

        $h = $this->token('ACME', 'rahim');
        // Range: 2026-05-01 to 2026-05-07
        $res = $this->withHeaders($h)->get('api/mobile/v1/attendance/summary?from=2026-05-01&to=2026-05-07');
        $res->assertStatus(200);
        $data = $this->json($res)['data'];

        // 2026-05-01, 2026-05-02, 2026-05-03 are before joining date -> bucket 'Not Joined'
        $this->assertSame(3, $data['summary']['not_joined']);

        $breakdownByDate = [];
        foreach ($data['daily_breakdown'] as $row) {
            $breakdownByDate[$row['date']] = $row;
        }

        $this->assertSame('Not Joined', $breakdownByDate['2026-05-01']['bucket']);
        $this->assertSame('Not Joined', $breakdownByDate['2026-05-02']['bucket']);
        $this->assertSame('Not Joined', $breakdownByDate['2026-05-03']['bucket']);
    }

    public function testCompanyTimezoneRespected(): void
    {
        // c-2 is configured with 'Asia/Dhaka' timezone
        $h = $this->token('OTHER', 'karim');
        $res = $this->withHeaders($h)->get('api/mobile/v1/attendance/summary?from=2026-05-01&to=2026-05-05');
        $res->assertStatus(200);
        $data = $this->json($res)['data'];

        $this->assertSame('Asia/Dhaka', $data['timezone']);
        $this->assertNotEmpty($data['as_of']);
        $this->assertNotEmpty($data['server_time']);
    }

    public function testCrossTenantIsolation(): void
    {
        $h1 = $this->token('ACME', 'rahim');

        // Tenant 1 attempts to spoof query string with tenant 2 employee/company IDs
        $res = $this->withHeaders($h1)->get('api/mobile/v1/attendance/summary?employee_id=e-2&company_id=c-2&from=2026-05-01&to=2026-05-05');
        $res->assertStatus(200);
        $data = $this->json($res)['data'];

        // Must strictly return data for authenticated e-1 in c-1
        $this->assertSame('e-1', $data['employee']['id']);
        $this->assertSame('EMP-001', $data['employee']['employee_code']);
        $this->assertSame('Rahim Uddin', $data['employee']['full_name']);

        // Tenant 2 receives their own record
        $h2 = $this->token('OTHER', 'karim');
        $res2 = $this->withHeaders($h2)->get('api/mobile/v1/attendance/summary?from=2026-05-01&to=2026-05-05');
        $res2->assertStatus(200);
        $data2 = $this->json($res2)['data'];
        $this->assertSame('e-2', $data2['employee']['id']);
        $this->assertSame('Karim Ali', $data2['employee']['full_name']);
    }

    public function testApprovedCorrectionsReflectedInSummary(): void
    {
        // Insert an approved correction for e-1 on 2026-05-04
        $this->db->table('attendance_corrections')->insert([
            'id'              => 'corr-1',
            'company_id'      => 'c-1',
            'employee_id'     => 'e-1',
            'attendance_date' => '2026-05-04',
            'check_in'        => '09:00:00',
            'check_out'       => '18:00:00',
            'working_hours'   => 9.0,
            'late_minutes'    => 0,
            'early_out_minutes' => 0,
            'status'          => 'Approved',
            'reason'          => 'Biometric terminal offline',
            'created_at'      => '2026-05-04 19:00:00',
        ]);

        $h = $this->token('ACME', 'rahim');
        $res = $this->withHeaders($h)->get('api/mobile/v1/attendance/summary?from=2026-05-04&to=2026-05-04');
        $res->assertStatus(200);
        $data = $this->json($res)['data'];

        $this->assertSame(1, $data['summary']['present']);
        $this->assertSame(9.0, (float)$data['summary']['total_working_hours']);

        $dayRecord = $data['daily_breakdown'][0];
        $this->assertSame('2026-05-04', $dayRecord['date']);
        $this->assertSame('Present', $dayRecord['bucket']);
        $this->assertSame('09:00:00', $dayRecord['check_in']);
        $this->assertSame('18:00:00', $dayRecord['check_out']);
        $this->assertSame(9.0, (float)$dayRecord['working_hours']);
    }

    public function testOvernightShiftCalculation(): void
    {
        // Insert a night-shift attendance log: check-in 22:00:00, check-out 06:00:00
        $this->db->table('attendance_logs')->insert([
            'id'            => 'log-night-1',
            'company_id'    => 'c-1',
            'employee_id'   => 'e-1',
            'date'          => '2026-05-05',
            'check_in'      => '22:00:00',
            'check_out'     => '06:00:00',
            'working_hours' => 0.0, // test that overnight cross-midnight calculation computes 8.0 hrs
            'status'        => 'Present',
            'day_type'      => 'Regular',
            'created_at'    => '2026-05-05 22:00:00',
        ]);

        $h = $this->token('ACME', 'rahim');
        $res = $this->withHeaders($h)->get('api/mobile/v1/attendance/summary?from=2026-05-05&to=2026-05-05');
        $res->assertStatus(200);
        $data = $this->json($res)['data'];

        $this->assertSame(1, $data['summary']['present']);
        $this->assertEquals(8.0, (float)$data['summary']['total_working_hours']);
        $this->assertEquals(8.0, (float)$data['daily_breakdown'][0]['working_hours']);
    }

    public function testStandardJsonEnvelope(): void
    {
        $h = $this->token('ACME', 'rahim');
        $res = $this->withHeaders($h)->get('api/mobile/v1/attendance/summary?month=2026-05');
        $res->assertStatus(200);
        $body = $this->json($res);

        // Standard envelope verification
        $this->assertArrayHasKey('success', $body);
        $this->assertTrue($body['success']);
        $this->assertArrayHasKey('status', $body);
        $this->assertSame('success', $body['status']);
        $this->assertArrayHasKey('message', $body);
        $this->assertSame('Attendance summary retrieved successfully.', $body['message']);
        $this->assertArrayHasKey('data', $body);

        $data = $body['data'];
        $this->assertSame('2026-05-01', $data['from']);
        $this->assertSame('2026-05-31', $data['to']);
        $this->assertArrayHasKey('employee', $data);
        $this->assertArrayHasKey('summary', $data);
        $this->assertArrayHasKey('daily_breakdown', $data);
        $this->assertArrayHasKey('records', $data);
        $this->assertCount(31, $data['daily_breakdown']);
    }
}
