<?php

namespace Tests\Unit;

use App\Models\EmployeeModel;
use App\Models\UserModel;
use App\Services\Mobile\MobileAuthService;
use CodeIgniter\Test\CIUnitTestCase;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobileTokenSecurityIntegrationTest extends CIUnitTestCase
{
    use MobileTestSchema;

    protected $db;
    private array $device = ['device_uid' => 'dev-token-sec-test', 'platform' => 'android', 'device_name' => 'Pixel 9'];

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);
    }

    private function getAuthService(): MobileAuthService
    {
        return new MobileAuthService($this->db);
    }

    private function login(string $company = 'ACME', string $id = 'rahim', string $pw = self::PASSWORD): array
    {
        return $this->getAuthService()->login($company, $id, $pw, $this->device, '127.0.0.1', 'PHPUnit');
    }

    /**
     * Requirement 1 & 8: User suspension blocks login, refresh, and revokes active access/refresh tokens.
     */
    public function testUserSuspensionBlocksLoginRefreshAndRevokesTokens(): void
    {
        $auth = $this->getAuthService();

        // 1. Legitimate login issues active tokens
        $loginRes = $this->login();
        $this->assertTrue($loginRes['ok']);
        $accessToken  = $loginRes['data']['tokens']['access_token'];
        $refreshToken = $loginRes['data']['tokens']['refresh_token'];

        // Initial token authentication succeeds
        $authRes = $auth->authenticate($accessToken);
        $this->assertTrue($authRes['ok']);

        // 2. Suspend user account
        $this->db->table('users')->where('id', 'u-1')->update(['status' => UserModel::STATUS_SUSPENDED]);

        // 3. New login attempt must fail
        $loginBlocked = $this->login();
        $this->assertFalse($loginBlocked['ok']);
        $this->assertSame(401, $loginBlocked['status']);

        // 4. Authenticating with existing access token must be denied and token must be revoked
        $authBlocked = $auth->authenticate($accessToken);
        $this->assertFalse($authBlocked['ok']);
        $this->assertSame(401, $authBlocked['status']);

        $accessRow = $this->db->table('mobile_access_tokens')
            ->where('token_hash', hash('sha256', $accessToken))
            ->get()->getRowArray();
        $this->assertNotNull($accessRow['revoked_at'], 'Access token must be revoked when user is suspended');

        // 5. Attempting to refresh must be denied and refresh token family must be revoked
        $refreshBlocked = $auth->refresh($refreshToken);
        $this->assertFalse($refreshBlocked['ok']);
        $this->assertSame(401, $refreshBlocked['status']);

        $refreshRow = $this->db->table('mobile_refresh_tokens')
            ->where('token_hash', hash('sha256', $refreshToken))
            ->get()->getRowArray();
        $this->assertNotNull($refreshRow['revoked_at'], 'Refresh token family must be revoked when user is suspended');
    }

    /**
     * Requirement 2 & 8: Employee deactivation (termination/resignation/suspension) blocks access, refresh, and login.
     */
    public function testEmployeeDeactivationBlocksAccessRefreshAndLogin(): void
    {
        $auth = $this->getAuthService();

        $loginRes = $this->login();
        $this->assertTrue($loginRes['ok']);
        $accessToken  = $loginRes['data']['tokens']['access_token'];
        $refreshToken = $loginRes['data']['tokens']['refresh_token'];

        // Deactivate employee profile to Terminated
        $this->db->table('employees')->where('id', 'e-1')->update(['status' => EmployeeModel::STATUS_TERMINATED]);

        // 1. Authenticating existing access token must fail closed with 403
        $authTerminated = $auth->authenticate($accessToken);
        $this->assertFalse($authTerminated['ok']);
        $this->assertSame(403, $authTerminated['status']);
        $this->assertStringContainsString('Terminated', $authTerminated['message']);

        // Verify tokens were automatically revoked
        $accessRow = $this->db->table('mobile_access_tokens')
            ->where('token_hash', hash('sha256', $accessToken))
            ->get()->getRowArray();
        $this->assertNotNull($accessRow['revoked_at'], 'Access token must be revoked on employee termination');

        // 2. Refresh must fail closed with 403 and prevent obtaining new tokens
        $refreshTerminated = $auth->refresh($refreshToken);
        $this->assertFalse($refreshTerminated['ok']);
        $this->assertSame(403, $refreshTerminated['status']);

        // 3. New login must fail closed with 403
        $loginTerminated = $this->login();
        $this->assertFalse($loginTerminated['ok']);
        $this->assertSame(403, $loginTerminated['status']);
    }

    /**
     * Requirement 2 & 8: Soft-deleted employee profile blocks access, refresh, and login.
     */
    public function testEmployeeSoftDeletionBlocksAccess(): void
    {
        $auth = $this->getAuthService();

        $loginRes = $this->login();
        $this->assertTrue($loginRes['ok']);
        $accessToken  = $loginRes['data']['tokens']['access_token'];
        $refreshToken = $loginRes['data']['tokens']['refresh_token'];

        // Soft-delete employee
        $this->db->table('employees')->where('id', 'e-1')->update(['deleted_at' => date('Y-m-d H:i:s')]);

        // Access token denied with 403
        $authDeleted = $auth->authenticate($accessToken);
        $this->assertFalse($authDeleted['ok']);
        $this->assertSame(403, $authDeleted['status']);

        // Refresh denied with 403
        $refreshDeleted = $auth->refresh($refreshToken);
        $this->assertFalse($refreshDeleted['ok']);
        $this->assertSame(403, $refreshDeleted['status']);

        // Login denied with 403
        $loginDeleted = $this->login();
        $this->assertFalse($loginDeleted['ok']);
        $this->assertSame(403, $loginDeleted['status']);
    }

    /**
     * Requirement 2 & 8: Company deactivation blocks access, refresh, and login.
     */
    public function testCompanyDeactivationBlocksAccessRefreshAndLogin(): void
    {
        $auth = $this->getAuthService();

        $loginRes = $this->login();
        $this->assertTrue($loginRes['ok']);
        $accessToken  = $loginRes['data']['tokens']['access_token'];
        $refreshToken = $loginRes['data']['tokens']['refresh_token'];

        // Deactivate company
        $this->db->table('companies')->where('id', 'c-1')->update(['status' => 'inactive']);

        // Access token denied with 403
        $authComp = $auth->authenticate($accessToken);
        $this->assertFalse($authComp['ok']);
        $this->assertSame(403, $authComp['status']);
        $this->assertStringContainsString('organization', strtolower($authComp['message']));

        // Tokens revoked
        $accessRow = $this->db->table('mobile_access_tokens')
            ->where('token_hash', hash('sha256', $accessToken))
            ->get()->getRowArray();
        $this->assertNotNull($accessRow['revoked_at']);

        // Refresh denied with 403
        $refreshComp = $auth->refresh($refreshToken);
        $this->assertFalse($refreshComp['ok']);
        $this->assertSame(403, $refreshComp['status']);

        // Login denied
        $loginComp = $this->login();
        $this->assertFalse($loginComp['ok']);
    }

    /**
     * Requirements 5, 6 & 8: Single-use refresh token rotation, safe concurrent replay, and full family revocation on reuse.
     */
    public function testRefreshTokenSingleUseRotationAndReuseDetection(): void
    {
        $auth = $this->getAuthService();

        $loginRes = $this->login();
        $this->assertTrue($loginRes['ok']);
        $r1 = $loginRes['data']['tokens']['refresh_token'];
        $a1 = $loginRes['data']['tokens']['access_token'];

        // 1. Initial refresh with R1 succeeds and issues R2 + A2
        $refreshRes1 = $auth->refresh($r1);
        $this->assertTrue($refreshRes1['ok']);
        $r2 = $refreshRes1['data']['tokens']['refresh_token'];
        $a2 = $refreshRes1['data']['tokens']['access_token'];

        $this->assertNotSame($r1, $r2, 'New refresh token must be generated');
        $this->assertNotSame($a1, $a2, 'New access token must be generated');

        // Check DB state: R1 marked used, A1 revoked
        $r1Row = $this->db->table('mobile_refresh_tokens')->where('token_hash', hash('sha256', $r1))->get()->getRowArray();
        $this->assertNotNull($r1Row['used_at']);
        $this->assertNotNull($r1Row['replaced_by_id']);

        $a1Row = $this->db->table('mobile_access_tokens')->where('token_hash', hash('sha256', $a1))->get()->getRowArray();
        $this->assertNotNull($a1Row['revoked_at'], 'Old access token must be revoked on refresh');

        // 2. Immediate concurrent replay within grace window returns same tokens safely
        $replayRes = $auth->refresh($r1);
        $this->assertTrue($replayRes['ok'], 'Concurrent replay within grace window should succeed');
        $this->assertSame($r2, $replayRes['data']['tokens']['refresh_token']);

        // 3. Stale reuse attack: artificially set R1 used_at to 60 seconds ago (outside grace window)
        $this->db->table('mobile_refresh_tokens')
            ->where('id', $r1Row['id'])
            ->update(['used_at' => date('Y-m-d H:i:s', time() - 60)]);

        // Attempting to reuse R1 outside grace window must be flagged as reuse and revoke entire family!
        $reuseRes = $auth->refresh($r1);
        $this->assertFalse($reuseRes['ok']);
        $this->assertSame(401, $reuseRes['status']);
        $this->assertStringContainsString('Token family revoked', $reuseRes['message']);

        // Verify R2 is now revoked because the family was compromised
        $r2Row = $this->db->table('mobile_refresh_tokens')->where('token_hash', hash('sha256', $r2))->get()->getRowArray();
        $this->assertNotNull($r2Row['revoked_at'], 'Replacement token R2 must be revoked when reuse of R1 is detected');

        // Attempting to use R2 must now fail because family was revoked
        $r2Refresh = $auth->refresh($r2);
        $this->assertFalse($r2Refresh['ok']);
        $this->assertSame(401, $r2Refresh['status']);
    }

    /**
     * Requirement 4: Explicit token revocation helper methods.
     */
    public function testDirectTokenRevocationHelpers(): void
    {
        $auth = $this->getAuthService();

        $loginRes = $this->login();
        $this->assertTrue($loginRes['ok']);
        $accessToken  = $loginRes['data']['tokens']['access_token'];
        $refreshToken = $loginRes['data']['tokens']['refresh_token'];

        // Revoke tokens by employee
        $revokedCount = $auth->revokeTokensForEmployee('e-1');
        $this->assertGreaterThan(0, $revokedCount);

        // Access token is now revoked in database
        $accessRow = $this->db->table('mobile_access_tokens')
            ->where('token_hash', hash('sha256', $accessToken))
            ->get()->getRowArray();
        $this->assertNotNull($accessRow['revoked_at']);

        // Refresh token is now revoked in database
        $refreshRow = $this->db->table('mobile_refresh_tokens')
            ->where('token_hash', hash('sha256', $refreshToken))
            ->get()->getRowArray();
        $this->assertNotNull($refreshRow['revoked_at']);

        // Subsequent authentication fails
        $authRes = $auth->authenticate($accessToken);
        $this->assertFalse($authRes['ok']);
    }
}
