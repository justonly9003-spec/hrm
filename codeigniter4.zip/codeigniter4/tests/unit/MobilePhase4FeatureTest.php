<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobilePhase4FeatureTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);
        foreach (['payrolls', 'payroll_items', 'provident_fund_ledgers', 'notifications', 'employee_documents'] as $t) {
            $this->db->query("DROP TABLE IF EXISTS {$t}");
        }
        $this->db->query("CREATE TABLE payrolls (id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36), payroll_month VARCHAR(10), status VARCHAR(20), is_locked INT DEFAULT 0)");
        $this->db->query("CREATE TABLE payroll_items (id VARCHAR(36) PRIMARY KEY, payroll_id VARCHAR(36), employee_id VARCHAR(36), basic_salary DECIMAL(12,2), gross_salary DECIMAL(12,2), total_deductions DECIMAL(12,2), net_salary DECIMAL(12,2), payment_status VARCHAR(20) NULL, bank_account_no VARCHAR(50) NULL, components_breakdown_json TEXT NULL)");
        $this->db->query("CREATE TABLE provident_fund_ledgers (id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36), employee_id VARCHAR(36), payroll_month INT NULL, payroll_year INT NULL, transaction_type VARCHAR(30), employee_contribution DECIMAL(12,2) DEFAULT 0, employer_contribution DECIMAL(12,2) DEFAULT 0, total_contribution DECIMAL(12,2) DEFAULT 0, running_balance DECIMAL(12,2) DEFAULT 0, transaction_date DATE, status VARCHAR(20), reference_no VARCHAR(50) NULL, reversal_of_id VARCHAR(36) NULL, created_at DATETIME NULL)");
        $this->db->query("CREATE TABLE notifications (id VARCHAR(36) PRIMARY KEY, user_id VARCHAR(36), title VARCHAR(150), message TEXT, type VARCHAR(30) NULL, priority VARCHAR(20) NULL, related_module VARCHAR(50) NULL, icon VARCHAR(50) NULL, link VARCHAR(255) NULL, is_read INT DEFAULT 0, read_at DATETIME NULL, created_at DATETIME NULL)");
        $this->db->query("CREATE TABLE employee_documents (id VARCHAR(36) PRIMARY KEY, employee_id VARCHAR(36), document_type VARCHAR(50), title VARCHAR(150), file_path VARCHAR(255), file_size INT NULL, expiry_date DATE NULL, employee_visible INT DEFAULT 0, created_at DATETIME NULL)");
    }

    /** Rows may have different columns, which insertBatch() rejects. */
    private function insertRows(string $table, array $rows): void
    {
        foreach ($rows as $r) {
            $this->db->table($table)->insert($r);
        }
    }

    private function token(string $company = 'ACME', string $id = 'rahim'): array
    {
        $res = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => $company, 'identifier' => $id, 'password' => self::PASSWORD, 'device' => ['device_uid' => 'd1'],
        ]);
        return ['Authorization' => 'Bearer ' . json_decode($res->getJSON(), true)['data']['tokens']['access_token']];
    }

    private function json($res): array
    {
        return json_decode($res->getJSON(), true);
    }

    private function seedPayslips(): void
    {
        $this->insertRows('payrolls', [
            ['id' => 'pr-sep', 'company_id' => 'c-1', 'payroll_month' => '2026-09', 'status' => 'Approved', 'is_locked' => 0],
            ['id' => 'pr-oct', 'company_id' => 'c-1', 'payroll_month' => '2026-10', 'status' => 'Draft', 'is_locked' => 0],
            ['id' => 'pr-lock', 'company_id' => 'c-1', 'payroll_month' => '2026-08', 'status' => 'Processed', 'is_locked' => 1],
            ['id' => 'pr-oth', 'company_id' => 'c-2', 'payroll_month' => '2026-09', 'status' => 'Paid', 'is_locked' => 1],
        ]);
        $this->insertRows('payroll_items', [
            ['id' => 'pi-sep', 'payroll_id' => 'pr-sep', 'employee_id' => 'e-1', 'basic_salary' => 50000, 'gross_salary' => 80000, 'total_deductions' => 5000, 'net_salary' => 75000, 'bank_account_no' => '1234567890', 'components_breakdown_json' => '{"allowances":[{"name":"HRA","amount":20000}]}'],
            ['id' => 'pi-oct', 'payroll_id' => 'pr-oct', 'employee_id' => 'e-1', 'basic_salary' => 50000, 'gross_salary' => 80000, 'total_deductions' => 5000, 'net_salary' => 75000],
            ['id' => 'pi-lock', 'payroll_id' => 'pr-lock', 'employee_id' => 'e-1', 'basic_salary' => 50000, 'gross_salary' => 80000, 'total_deductions' => 5000, 'net_salary' => 75000],
            ['id' => 'pi-karim', 'payroll_id' => 'pr-oth', 'employee_id' => 'e-2', 'basic_salary' => 90000, 'gross_salary' => 99000, 'total_deductions' => 9000, 'net_salary' => 90000],
        ]);
    }

    public function testPayslipListShowsOnlyOwnFinalizedPayslips(): void
    {
        $this->seedPayslips();
        $res = $this->withHeaders($this->token())->get('api/mobile/v1/payslips');
        $res->assertStatus(200);
        $ids = array_column($this->json($res)['data']['payslips'], 'id');
        sort($ids);
        $this->assertSame(['pi-lock', 'pi-sep'], $ids);   // draft and the other tenant's slip are absent
    }

    public function testPayslipDetailIsolationAndNoBankNumber(): void
    {
        $this->seedPayslips();
        $h = $this->token();
        $ok = $this->withHeaders($h)->get('api/mobile/v1/payslips/pi-sep');
        $ok->assertStatus(200);
        $body = $this->json($ok)['data'];
        $this->assertEquals(75000, $body['payslip']['net_salary']);
        $this->assertSame('HRA', $body['components']['allowances'][0]['name']);
        $this->assertStringNotContainsString('1234567890', $ok->getJSON());

        $this->withHeaders($h)->get('api/mobile/v1/payslips/pi-oct')->assertStatus(404);    // draft
        $this->withHeaders($h)->get('api/mobile/v1/payslips/pi-karim')->assertStatus(404);  // another tenant/employee
    }

    public function testPfSummaryUsesLedgerBalanceAndExcludesReversedAndDraftRows(): void
    {
        $this->insertRows('provident_fund_ledgers', [
            ['id' => 'l1', 'company_id' => 'c-1', 'employee_id' => 'e-1', 'transaction_type' => 'CONTRIBUTION', 'employee_contribution' => 1000, 'employer_contribution' => 1000, 'total_contribution' => 2000, 'running_balance' => 2000, 'transaction_date' => '2026-07-31', 'status' => 'posted', 'created_at' => '2026-07-31 10:00:00'],
            ['id' => 'l2', 'company_id' => 'c-1', 'employee_id' => 'e-1', 'transaction_type' => 'CONTRIBUTION', 'employee_contribution' => 1000, 'employer_contribution' => 1000, 'total_contribution' => 2000, 'running_balance' => 4000, 'transaction_date' => '2026-08-31', 'status' => 'posted', 'created_at' => '2026-08-31 10:00:00'],
            ['id' => 'l3', 'company_id' => 'c-1', 'employee_id' => 'e-1', 'transaction_type' => 'REVERSAL', 'employee_contribution' => -1000, 'employer_contribution' => -1000, 'total_contribution' => -2000, 'running_balance' => 2000, 'transaction_date' => '2026-09-01', 'status' => 'posted', 'reversal_of_id' => 'l2', 'created_at' => '2026-09-01 10:00:00'],
            ['id' => 'l4', 'company_id' => 'c-1', 'employee_id' => 'e-1', 'transaction_type' => 'CONTRIBUTION', 'employee_contribution' => 9999, 'employer_contribution' => 9999, 'total_contribution' => 19998, 'running_balance' => 99999, 'transaction_date' => '2026-10-31', 'status' => 'draft', 'created_at' => '2026-10-31 10:00:00'],
            ['id' => 'l5', 'company_id' => 'c-2', 'employee_id' => 'e-2', 'transaction_type' => 'CONTRIBUTION', 'employee_contribution' => 5, 'employer_contribution' => 5, 'total_contribution' => 10, 'running_balance' => 10, 'transaction_date' => '2026-07-31', 'status' => 'posted', 'created_at' => '2026-07-31 10:00:00'],
        ]);
        $d = $this->json($this->withHeaders($this->token())->get('api/mobile/v1/pf/summary'))['data'];
        $this->assertTrue($d['has_pf']);
        $this->assertEquals(2000, $d['balance']);
        $this->assertEquals(1000, $d['employee_contribution']);
        $this->assertEquals(1000, $d['employer_contribution']);

        $ledger = $this->json($this->withHeaders($this->token())->get('api/mobile/v1/pf/ledger'))['data']['entries'];
        $this->assertSame(['l3', 'l2', 'l1'], array_column($ledger, 'id'));   // newest first, no draft, no other tenant
    }

    public function testNotificationsAreScopedToTheUserAndCannotBeMarkedByOthers(): void
    {
        $this->insertRows('notifications', [
            ['id' => 'n1', 'user_id' => 'u-1', 'title' => 'Mine', 'message' => 'm', 'is_read' => 0, 'created_at' => '2026-10-30 09:00:00'],
            ['id' => 'n2', 'user_id' => 'u-2', 'title' => 'Theirs', 'message' => 'm', 'is_read' => 0, 'created_at' => '2026-10-30 09:00:00'],
        ]);
        $h = $this->token();
        $d = $this->json($this->withHeaders($h)->get('api/mobile/v1/notifications'))['data'];
        $this->assertSame(1, $d['unread_count']);
        $this->assertSame(['n1'], array_column($d['notifications'], 'id'));

        $this->withHeaders($h)->call('post', 'api/mobile/v1/notifications/n2/read')->assertStatus(200);
        $this->assertSame('0', (string)$this->db->table('notifications')->where('id', 'n2')->get()->getRowArray()['is_read']);

        $this->withHeaders($h)->call('post', 'api/mobile/v1/notifications/read-all')->assertStatus(200);
        $this->assertSame('1', (string)$this->db->table('notifications')->where('id', 'n1')->get()->getRowArray()['is_read']);
        $this->assertSame('0', (string)$this->db->table('notifications')->where('id', 'n2')->get()->getRowArray()['is_read']);
    }

    public function testDocumentsAreHiddenUnlessMarkedVisibleAndNeverExposePaths(): void
    {
        $this->insertRows('employee_documents', [
            ['id' => 'd1', 'employee_id' => 'e-1', 'document_type' => 'Offer', 'title' => 'Offer Letter', 'file_path' => 'uploads/secret/a.pdf', 'employee_visible' => 1],
            ['id' => 'd2', 'employee_id' => 'e-1', 'document_type' => 'Warning', 'title' => 'Internal', 'file_path' => 'uploads/secret/b.pdf', 'employee_visible' => 0],
            ['id' => 'd3', 'employee_id' => 'e-2', 'document_type' => 'Offer', 'title' => 'Other', 'file_path' => 'uploads/secret/c.pdf', 'employee_visible' => 1],
        ]);
        $res = $this->withHeaders($this->token())->get('api/mobile/v1/documents');
        $this->assertSame(['d1'], array_column($this->json($res)['data']['documents'], 'id'));
        $this->assertStringNotContainsString('uploads/secret', $res->getJSON());
    }

    public function testAllPhase4RoutesRequireAToken(): void
    {
        foreach (['payslips', 'payslips/pi-sep', 'pf/summary', 'pf/ledger', 'notifications', 'documents'] as $p) {
            $this->get("api/mobile/v1/{$p}")->assertStatus(401);
        }
        $this->call('post', 'api/mobile/v1/notifications/read-all')->assertStatus(401);
    }
}
