<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobileDirectoryTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;
    private array $device = ['device_uid' => 'dev-dir-test-1', 'platform' => 'android'];

    public static function registerSqliteFunctions($db): void
    {
        try {
            $rawConn = $db->connID ?? null;
            if ($rawConn instanceof \SQLite3) {
                $rawConn->createFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->createFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            } elseif (is_object($rawConn) && method_exists($rawConn, 'sqliteCreateFunction')) {
                $rawConn->sqliteCreateFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->sqliteCreateFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            }
        } catch (\Throwable $e) {
            // ignore
        }
    }

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        static::registerSqliteFunctions($this->db);
        $this->buildMobileSchema($this->db);

        // Add additional schema requirements for organizational structure & hierarchy
        try {
            $this->db->query("ALTER TABLE employees ADD COLUMN reporting_manager_id VARCHAR(36) NULL");
        } catch (\Throwable $e) {
            // already exists
        }

        try {
            $this->db->query("ALTER TABLE employees ADD COLUMN employment_type_id VARCHAR(36) NULL");
        } catch (\Throwable $e) {
            // already exists
        }

        // Roles
        $this->db->table('roles')->insertBatch([
            ['id' => 'r-hr',    'code' => 'hr_admin',       'name' => 'HR Admin',       'status' => 'active'],
            ['id' => 'r-mgr',   'code' => 'manager',        'name' => 'Manager',        'status' => 'active'],
            ['id' => 'r-bm',    'code' => 'branch_manager', 'name' => 'Branch Manager', 'status' => 'active'],
            ['id' => 'r-ca',    'code' => 'company_admin',  'name' => 'Company Admin',  'status' => 'active'],
        ]);

        // Branches, Departments, Designations
        $this->db->table('branches')->insertBatch([
            ['id' => 'br-1', 'name' => 'HQ Dhaka'],
            ['id' => 'br-2', 'name' => 'Chittagong Branch'],
        ]);

        $this->db->table('departments')->insertBatch([
            ['id' => 'dept-eng', 'name' => 'Engineering'],
            ['id' => 'dept-hr',  'name' => 'Human Resources'],
            ['id' => 'dept-mkt', 'name' => 'Marketing'],
        ]);

        $this->db->table('designations')->insertBatch([
            ['id' => 'desg-mgr', 'name' => 'Engineering Manager'],
            ['id' => 'desg-dev', 'name' => 'Senior Software Engineer'],
            ['id' => 'desg-hr',  'name' => 'HR Director'],
        ]);

        // Base employee e-1 update
        $this->db->table('employees')->where('id', 'e-1')->update([
            'branch_id'      => 'br-1',
            'department_id'  => 'dept-eng',
            'designation_id' => 'desg-dev',
            'email'          => 'rahim@acme.test',
            'phone'          => '+8801700000001',
        ]);
    }

    private function token(string $company = 'ACME', string $id = 'rahim'): array
    {
        $res = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => $company, 'identifier' => $id, 'password' => self::PASSWORD, 'device' => $this->device,
        ]);
        $json = json_decode($res->getJSON(), true);
        return ['Authorization' => 'Bearer ' . ($json['data']['tokens']['access_token'] ?? '')];
    }

    private function json($res): array
    {
        return json_decode($res->getJSON(), true) ?: [];
    }

    /**
     * Test 1: Directory endpoint requires authentication (returns 401).
     */
    public function testDirectoryEndpointRequiresAuthentication(): void
    {
        $res = $this->call('get', 'api/mobile/v1/directory');
        $this->assertSame(401, $res->response()->getStatusCode());
        $body = $this->json($res);
        $this->assertFalse($body['success']);
    }

    /**
     * Test 2: Multi-tenant cross-company isolation.
     * User in company c-1 cannot discover employees in c-2.
     * Attempting to pass query parameter company_id=c-2 is rejected with 403 Forbidden.
     */
    public function testCrossCompanyIsolationEnforcement(): void
    {
        $token = $this->token('ACME', 'rahim'); // Company c-1

        // Normal request
        $res = $this->withHeaders($token)->call('get', 'api/mobile/v1/directory');
        $this->assertSame(200, $res->response()->getStatusCode());
        $body = $this->json($res);
        $this->assertTrue($body['success']);

        $returnedIds = array_column($body['data']['employees'], 'id');
        $this->assertNotContains('e-2', $returnedIds, 'Company c-2 employee e-2 must never appear in c-1 directory');

        // Query tampering: attempting to cross tenants
        $tamperRes = $this->withHeaders($token)->call('get', 'api/mobile/v1/directory?company_id=c-2');
        $this->assertSame(403, $tamperRes->response()->getStatusCode());
        $tamperBody = $this->json($tamperRes);
        $this->assertFalse($tamperBody['success']);
        $this->assertStringContainsString('Cross-tenant', $tamperBody['message']);
    }

    /**
     * Test 3: Regular employee has default 'self' scope.
     * Only their own record is returned in the directory listing.
     */
    public function testRegularEmployeeHasSelfScope(): void
    {
        // Add additional peer employees in c-1
        $this->db->table('employees')->insertBatch([
            [
                'id'            => 'e-peer-1',
                'company_id'    => 'c-1',
                'employee_code' => 'EMP-010',
                'first_name'    => 'Tariq',
                'last_name'     => 'Anam',
                'branch_id'     => 'br-1',
                'department_id' => 'dept-eng',
                'status'        => 'Active',
            ],
            [
                'id'            => 'e-peer-2',
                'company_id'    => 'c-1',
                'employee_code' => 'EMP-011',
                'first_name'    => 'Farhana',
                'last_name'     => 'Mishu',
                'branch_id'     => 'br-1',
                'department_id' => 'dept-eng',
                'status'        => 'Active',
            ],
        ]);

        $token = $this->token('ACME', 'rahim'); // Role: employee, default scope 'self'
        $res = $this->withHeaders($token)->call('get', 'api/mobile/v1/directory');
        $this->assertSame(200, $res->response()->getStatusCode());
        $body = $this->json($res);

        $this->assertTrue($body['success']);
        $employees = $body['data']['employees'];

        // Must return only Rahim (e-1)
        $this->assertCount(1, $employees);
        $this->assertSame('e-1', $employees[0]['id']);
        $this->assertSame('Rahim Uddin', $employees[0]['name']);
        $this->assertSame('self', $body['data']['scope']);
    }

    /**
     * Test 4: Manager with 'team' scope discovers self and descendants only.
     */
    public function testManagerTeamScopeReturnsSelfAndReports(): void
    {
        // Setup manager e-mgr and direct/indirect reports
        $this->db->table('employees')->insertBatch([
            [
                'id'                   => 'e-mgr',
                'company_id'           => 'c-1',
                'employee_code'        => 'EMP-MGR',
                'first_name'           => 'Sadia',
                'last_name'            => 'Kabir',
                'branch_id'            => 'br-1',
                'department_id'        => 'dept-eng',
                'designation_id'       => 'desg-mgr',
                'reporting_manager_id' => null,
                'status'               => 'Active',
            ],
            [
                'id'                   => 'e-rep-1',
                'company_id'           => 'c-1',
                'employee_code'        => 'EMP-R1',
                'first_name'           => 'Nabil',
                'last_name'            => 'Hasan',
                'branch_id'            => 'br-1',
                'department_id'        => 'dept-eng',
                'reporting_manager_id' => 'e-mgr',
                'status'               => 'Active',
            ],
            [
                'id'                   => 'e-rep-2',
                'company_id'           => 'c-1',
                'employee_code'        => 'EMP-R2',
                'first_name'           => 'Zubair',
                'last_name'            => 'Ahmed',
                'branch_id'            => 'br-1',
                'department_id'        => 'dept-eng',
                'reporting_manager_id' => 'e-rep-1',
                'status'               => 'Active',
            ],
            [
                'id'                   => 'e-other-team',
                'company_id'           => 'c-1',
                'employee_code'        => 'EMP-OTH',
                'first_name'           => 'Mahmud',
                'last_name'            => 'Hossain',
                'branch_id'            => 'br-1',
                'department_id'        => 'dept-mkt',
                'reporting_manager_id' => null,
                'status'               => 'Active',
            ],
        ]);

        $this->addUser('u-mgr', 'sadia', 'sadia@acme.test', 'c-1', 'e-mgr', 'r-mgr');
        $token = $this->token('ACME', 'sadia');

        $res = $this->withHeaders($token)->call('get', 'api/mobile/v1/directory');
        $this->assertSame(200, $res->response()->getStatusCode());
        $body = $this->json($res);

        $this->assertTrue($body['success']);
        $returnedIds = array_column($body['data']['employees'], 'id');

        $this->assertContains('e-mgr', $returnedIds, 'Manager must see herself');
        $this->assertContains('e-rep-1', $returnedIds, 'Manager must see direct report');
        $this->assertContains('e-rep-2', $returnedIds, 'Manager must see indirect report');
        $this->assertNotContains('e-other-team', $returnedIds, 'Manager must not see employees outside reporting tree');
        $this->assertSame('team', $body['data']['scope']);
    }

    /**
     * Test 5: Branch Manager with 'branch' scope sees employees in their branch only.
     * Fails closed if branch manager has no assigned branch.
     */
    public function testBranchManagerBranchScopeAndFailClosed(): void
    {
        $this->db->table('employees')->insertBatch([
            [
                'id'            => 'e-bm',
                'company_id'    => 'c-1',
                'employee_code' => 'EMP-BM',
                'first_name'    => 'Jannat',
                'last_name'     => 'Ara',
                'branch_id'     => 'br-1',
                'status'        => 'Active',
            ],
            [
                'id'            => 'e-br1-staff',
                'company_id'    => 'c-1',
                'employee_code' => 'EMP-BR1',
                'first_name'    => 'Kamal',
                'last_name'     => 'Pasha',
                'branch_id'     => 'br-1',
                'status'        => 'Active',
            ],
            [
                'id'            => 'e-br2-staff',
                'company_id'    => 'c-1',
                'employee_code' => 'EMP-BR2',
                'first_name'    => 'Shakil',
                'last_name'     => 'Khan',
                'branch_id'     => 'br-2',
                'status'        => 'Active',
            ],
        ]);

        // BM with branch br-1
        $this->addUser('u-bm', 'jannat', 'jannat@acme.test', 'c-1', 'e-bm', 'r-bm', ['branch_id' => 'br-1']);
        $token = $this->token('ACME', 'jannat');

        $res = $this->withHeaders($token)->call('get', 'api/mobile/v1/directory');
        $this->assertSame(200, $res->response()->getStatusCode());
        $body = $this->json($res);

        $returnedIds = array_column($body['data']['employees'], 'id');
        $this->assertContains('e-bm', $returnedIds);
        $this->assertContains('e-br1-staff', $returnedIds);
        $this->assertNotContains('e-br2-staff', $returnedIds, 'Staff from branch br-2 must be excluded');

        // BM with NO branch assigned fails closed (1=0)
        $this->addUser('u-bm-nobranch', 'nobranch', 'nobranch@acme.test', 'c-1', 'e-bm', 'r-bm', ['branch_id' => null]);
        $tokenNoBranch = $this->token('ACME', 'nobranch');

        $resNoBranch = $this->withHeaders($tokenNoBranch)->call('get', 'api/mobile/v1/directory');
        $this->assertSame(200, $resNoBranch->response()->getStatusCode());
        $bodyNoBranch = $this->json($resNoBranch);
        $this->assertCount(0, $bodyNoBranch['data']['employees'], 'Branch Manager with no branch must fail closed and see 0 records');
    }

    /**
     * Test 6: HR Admin and Company Admin have full company scope.
     */
    public function testHrAdminFullCompanyScope(): void
    {
        $this->db->table('employees')->insertBatch([
            [
                'id'            => 'e-hr',
                'company_id'    => 'c-1',
                'employee_code' => 'EMP-HR',
                'first_name'    => 'Tahmina',
                'last_name'     => 'Begum',
                'branch_id'     => 'br-1',
                'status'        => 'Active',
            ],
            [
                'id'            => 'e-staff-br2',
                'company_id'    => 'c-1',
                'employee_code' => 'EMP-STAFF2',
                'first_name'    => 'Monir',
                'last_name'     => 'Zaman',
                'branch_id'     => 'br-2',
                'status'        => 'Active',
            ],
        ]);

        $this->addUser('u-hr', 'tahmina', 'tahmina@acme.test', 'c-1', 'e-hr', 'r-hr');
        $token = $this->token('ACME', 'tahmina');

        $res = $this->withHeaders($token)->call('get', 'api/mobile/v1/directory');
        $this->assertSame(200, $res->response()->getStatusCode());
        $body = $this->json($res);

        $returnedIds = array_column($body['data']['employees'], 'id');
        $this->assertContains('e-1', $returnedIds);
        $this->assertContains('e-hr', $returnedIds);
        $this->assertContains('e-staff-br2', $returnedIds, 'HR Admin must see employees across all branches');
    }

    /**
     * Test 7: Inactive, terminated, resigned, and soft-deleted employees are excluded.
     */
    public function testInactiveAndSeparatedEmployeesExcluded(): void
    {
        $this->db->table('employees')->insertBatch([
            [
                'id'            => 'e-term',
                'company_id'    => 'c-1',
                'employee_code' => 'EMP-TRM',
                'first_name'    => 'Terminated',
                'last_name'     => 'Staff',
                'status'        => 'Terminated',
            ],
            [
                'id'            => 'e-resigned',
                'company_id'    => 'c-1',
                'employee_code' => 'EMP-RSG',
                'first_name'    => 'Resigned',
                'last_name'     => 'Staff',
                'status'        => 'Resigned',
            ],
            [
                'id'            => 'e-inactive',
                'company_id'    => 'c-1',
                'employee_code' => 'EMP-INA',
                'first_name'    => 'Inactive',
                'last_name'     => 'Staff',
                'status'        => 'Inactive',
            ],
            [
                'id'            => 'e-deleted',
                'company_id'    => 'c-1',
                'employee_code' => 'EMP-DEL',
                'first_name'    => 'Deleted',
                'last_name'     => 'Staff',
                'status'        => 'Active',
                'deleted_at'    => date('Y-m-d H:i:s'),
            ],
        ]);

        $this->addUser('u-ca', 'admin', 'admin@acme.test', 'c-1', null, 'r-ca');
        $token = $this->token('ACME', 'admin');

        $res = $this->withHeaders($token)->call('get', 'api/mobile/v1/directory');
        $this->assertSame(200, $res->response()->getStatusCode());
        $body = $this->json($res);

        $returnedIds = array_column($body['data']['employees'], 'id');
        $this->assertNotContains('e-term', $returnedIds, 'Terminated employee must be excluded');
        $this->assertNotContains('e-resigned', $returnedIds, 'Resigned employee must be excluded');
        $this->assertNotContains('e-inactive', $returnedIds, 'Inactive employee must be excluded');
        $this->assertNotContains('e-deleted', $returnedIds, 'Soft-deleted employee must be excluded');
    }

    /**
     * Test 8: Sensitive data is masked and explicit response allow-list is enforced.
     */
    public function testSensitiveDataMaskingAndResponseEnvelope(): void
    {
        $token = $this->token('ACME', 'rahim');
        $res = $this->withHeaders($token)->call('get', 'api/mobile/v1/directory');
        $this->assertSame(200, $res->response()->getStatusCode());
        $body = $this->json($res);

        // Standard API envelope checks
        $this->assertTrue($body['success']);
        $this->assertSame('success', $body['status']);
        $this->assertNotEmpty($body['message']);
        $this->assertArrayHasKey('data', $body);
        $this->assertArrayHasKey('employees', $body['data']);
        $this->assertArrayHasKey('pagination', $body['data']);

        $emp = $body['data']['employees'][0];

        // Forbidden sensitive fields must NEVER exist in response
        $this->assertArrayNotHasKey('basic_salary', $emp);
        $this->assertArrayNotHasKey('gross_salary', $emp);
        $this->assertArrayNotHasKey('salary', $emp);
        $this->assertArrayNotHasKey('bank_account_no', $emp);
        $this->assertArrayNotHasKey('personal_email', $emp);
        $this->assertArrayNotHasKey('personal_phone', $emp);
        $this->assertArrayNotHasKey('user_id', $emp);
        $this->assertArrayNotHasKey('password_hash', $emp);

        // Explicit allow-listed fields
        $this->assertArrayHasKey('id', $emp);
        $this->assertArrayHasKey('employee_code', $emp);
        $this->assertArrayHasKey('name', $emp);
        $this->assertArrayHasKey('full_name', $emp);
        $this->assertArrayHasKey('department_name', $emp);
        $this->assertArrayHasKey('designation_name', $emp);
        $this->assertArrayHasKey('branch_name', $emp);
        $this->assertArrayHasKey('status', $emp);
    }

    /**
     * Test 9: Database-level pagination and bounding.
     */
    public function testDatabaseLevelPaginationAndLimits(): void
    {
        // Add 5 employees for company c-1
        for ($i = 1; $i <= 5; $i++) {
            $this->db->table('employees')->insert([
                'id'            => "e-page-{$i}",
                'company_id'    => 'c-1',
                'employee_code' => "EMP-P{$i}",
                'first_name'    => "Staff{$i}",
                'last_name'     => 'Test',
                'status'        => 'Active',
            ]);
        }

        $this->addUser('u-ca-page', 'ca_page', 'ca_page@acme.test', 'c-1', null, 'r-ca');
        $token = $this->token('ACME', 'ca_page');

        // Page 1, limit 2
        $res = $this->withHeaders($token)->call('get', 'api/mobile/v1/directory?page=1&limit=2');
        $this->assertSame(200, $res->response()->getStatusCode());
        $body = $this->json($res);

        $this->assertSame(1, $body['data']['page']);
        $this->assertSame(2, $body['data']['per_page']);
        $this->assertCount(2, $body['data']['employees']);
        $this->assertGreaterThanOrEqual(6, $body['data']['total']); // 5 new + e-1
        $this->assertGreaterThanOrEqual(3, $body['data']['total_pages']);

        // Limit bounding: limit=500 clamped to 100
        $resClamped = $this->withHeaders($token)->call('get', 'api/mobile/v1/directory?limit=500');
        $bodyClamped = $this->json($resClamped);
        $this->assertSame(100, $bodyClamped['data']['per_page']);

        // Negative limit clamped to 1
        $resNeg = $this->withHeaders($token)->call('get', 'api/mobile/v1/directory?limit=-5');
        $bodyNeg = $this->json($resNeg);
        $this->assertSame(1, $bodyNeg['data']['per_page']);
    }

    /**
     * Test 10: Safe sanitized search by name and code.
     */
    public function testSanitizedSearchByNameAndCode(): void
    {
        $this->db->table('employees')->insertBatch([
            [
                'id'            => 'e-search-1',
                'company_id'    => 'c-1',
                'employee_code' => 'EMP-XYZ-99',
                'first_name'    => 'Tanvir',
                'last_name'     => 'Mahmood',
                'status'        => 'Active',
            ],
            [
                'id'            => 'e-search-2',
                'company_id'    => 'c-1',
                'employee_code' => 'EMP-ABC-88',
                'first_name'    => 'Rashid',
                'last_name'     => 'Al-Hasan',
                'status'        => 'Active',
            ],
        ]);

        $this->addUser('u-ca-search', 'ca_search', 'ca_search@acme.test', 'c-1', null, 'r-ca');
        $token = $this->token('ACME', 'ca_search');

        // Search by first name
        $res1 = $this->withHeaders($token)->call('get', 'api/mobile/v1/directory?search=Tanvir');
        $body1 = $this->json($res1);
        $ids1 = array_column($body1['data']['employees'], 'id');
        $this->assertContains('e-search-1', $ids1);
        $this->assertNotContains('e-search-2', $ids1);

        // Search by code
        $res2 = $this->withHeaders($token)->call('get', 'api/mobile/v1/directory?search=XYZ-99');
        $body2 = $this->json($res2);
        $ids2 = array_column($body2['data']['employees'], 'id');
        $this->assertContains('e-search-1', $ids2);

        // Wildcard character '%' does not dump all records
        $resWild = $this->withHeaders($token)->call('get', 'api/mobile/v1/directory?search=%25');
        $bodyWild = $this->json($resWild);
        $this->assertCount(0, $bodyWild['data']['employees'], 'Wildcard % must not match all records');
    }

    /**
     * Test 11: Directory detail route with row-level security.
     */
    public function testDirectoryDetailRouteRowLevelSecurity(): void
    {
        $this->db->table('employees')->insert([
            'id'            => 'e-detail-other',
            'company_id'    => 'c-1',
            'employee_code' => 'EMP-DET-1',
            'first_name'    => 'Secret',
            'last_name'     => 'Agent',
            'status'        => 'Active',
        ]);

        $tokenEmp = $this->token('ACME', 'rahim'); // Role: employee, self scope

        // Viewing own record: 200 OK
        $resSelf = $this->withHeaders($tokenEmp)->call('get', 'api/mobile/v1/directory/e-1');
        $this->assertSame(200, $resSelf->response()->getStatusCode());
        $bodySelf = $this->json($resSelf);
        $this->assertTrue($bodySelf['success']);
        $this->assertSame('e-1', $bodySelf['data']['employee']['id']);

        // Viewing peer's record as regular employee: 404 (Row outside authorized scope)
        $resPeer = $this->withHeaders($tokenEmp)->call('get', 'api/mobile/v1/directory/e-detail-other');
        $this->assertSame(404, $resPeer->response()->getStatusCode());

        // Cross-tenant employee e-2: 404 Not Found
        $resCross = $this->withHeaders($tokenEmp)->call('get', 'api/mobile/v1/directory/e-2');
        $this->assertSame(404, $resCross->response()->getStatusCode());

        // Non-existent ID: 404
        $resMissing = $this->withHeaders($tokenEmp)->call('get', 'api/mobile/v1/directory/non-existent-id');
        $this->assertSame(404, $resMissing->response()->getStatusCode());
    }

    /**
     * Test 12: Anti-IDOR query parameter tampering fails.
     */
    public function testAntiIdorQueryParamTampering(): void
    {
        $tokenEmp = $this->token('ACME', 'rahim');

        // Tampering with employee_id query param
        $res = $this->withHeaders($tokenEmp)->call('get', 'api/mobile/v1/directory?employee_id=e-other');
        $this->assertSame(403, $res->response()->getStatusCode());
        $body = $this->json($res);
        $this->assertFalse($body['success']);
    }
}
