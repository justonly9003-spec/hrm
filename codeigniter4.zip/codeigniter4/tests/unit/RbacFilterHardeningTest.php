<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

/**
 * Static regression invariants for authentication and tenant-admin filters.
 * These tests complement DB-backed integration tests; they do not replace them.
 */
class RbacFilterHardeningTest extends TestCase
{
    public function testAuthFilterFailsClosedForMissingOrInactiveAssignedRole(): void
    {
        $source = file_get_contents(APPPATH . 'Filters/AuthFilter.php');

        $this->assertNotFalse($source);
        $this->assertStringContainsString('strtolower((string) ($userRow[\'role_status\'] ?? \'\')) === \'active\'', $source);
        $this->assertStringContainsString('!empty($userRow[\'user_role_id\'])', $source);
        $this->assertStringContainsString('$session->destroy();', $source);
        $this->assertStringContainsString('assigned role is missing or inactive', strtolower($source));
    }

    public function testCompanyAdminFilterUsesDatabaseTenantAndFailsClosed(): void
    {
        $source = file_get_contents(APPPATH . 'Filters/CompanyAdminFilter.php');

        $this->assertNotFalse($source);
        $this->assertStringContainsString('$companyId = $userRow[\'user_company_id\'] ?? null;', $source);
        $this->assertStringNotContainsString('$userRow[\'user_company_id\'] ?: $session->get(\'company_id\')', $source);
        $this->assertStringContainsString('if (!$comp || strtolower((string) ($comp[\'status\'] ?? \'\')) !== \'active\')', $source);
        $this->assertStringContainsString('setStatusCode(503)', $source);
    }
}
