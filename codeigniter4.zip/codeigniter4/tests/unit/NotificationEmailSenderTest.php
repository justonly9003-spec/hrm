<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use App\Models\EmailQueueModel;
use App\Models\EmailLogModel;
use App\Services\NotificationService;
use App\Services\SmtpConfigResolver;
use App\Database\Migrations\AddCompanyIdAndRetryToEmailQueueAndLogs;

class NotificationEmailSenderTest extends CIUnitTestCase
{
    public function testEmailQueueAndLogModelsIncludeCompanyIdAndErrorHandling()
    {
        $queueModel = new EmailQueueModel();
        $this->assertContains('company_id', $queueModel->allowedFields ?? []);
        $this->assertContains('retry_count', $queueModel->allowedFields ?? []);

        $logModel = new EmailLogModel();
        $this->assertContains('company_id', $logModel->allowedFields ?? []);
        $this->assertContains('error_message', $logModel->allowedFields ?? []);
    }

    public function testEmailQueueSkipsWhenReceiverEmailIsMissing()
    {
        $queueModel = new EmailQueueModel();

        // Enqueue with empty receiver_email should return null and not fallback to employee@company.com
        $result = $queueModel->enqueue([
            'company_id'     => 'comp-test-01',
            'receiver_email' => '',
            'subject'        => 'Test Notification',
            'body'           => 'This should be skipped',
        ]);

        $this->assertNull($result);
    }

    public function testSmtpConfigResolverCreatesConfiguredEmailService()
    {
        $emailService = SmtpConfigResolver::createEmailService('comp-test-01');
        $this->assertInstanceOf(\CodeIgniter\Email\Email::class, $emailService);
    }

    public function testMigrationClassExistsAndHasUpAndDown()
    {
        $migration = new AddCompanyIdAndRetryToEmailQueueAndLogs();
        $this->assertTrue(method_exists($migration, 'up'));
        $this->assertTrue(method_exists($migration, 'down'));
    }

    public function testNotificationServiceHasProcessEmailQueueAndSendEmailDirect()
    {
        $service = new NotificationService();
        $this->assertTrue(method_exists($service, 'processEmailQueue'));
        $this->assertTrue(method_exists($service, 'sendEmailDirect'));
    }
}
