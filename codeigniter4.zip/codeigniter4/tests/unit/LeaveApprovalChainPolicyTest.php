<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\LeaveService;
use App\Services\Leave\LeaveApplicationService;

class LeaveApprovalChainPolicyTest extends TestCase
{
    private array $sampleWorkflow;

    protected function setUp(): void
    {
        parent::setUp();
        $this->sampleWorkflow = [
            'workflow_type'           => 'Multi-Tier',
            'auto_approve_under_days' => 1.0,
            'tier_conditions'         => [
                [
                    'min_days'           => 1,
                    'max_days'           => 2,
                    'required_approvers' => ['Manager'],
                ],
                [
                    'min_days'           => 3,
                    'max_days'           => 7,
                    'required_approvers' => ['Manager', 'HR Admin'],
                ],
                [
                    'min_days'           => 8,
                    'max_days'           => 999,
                    'required_approvers' => ['Manager', 'Department Head', 'HR Admin'],
                ],
            ],
        ];
    }

    /**
     * Test fractional days resolve to the correct tier without skipping any manager or approval layer.
     */
    public function testFractionalDaysTierResolution()
    {
        // 0.5 days -> resolves to 1-2 day tier (ceil = 1) -> ['Manager']
        $req05 = LeaveApplicationService::getRequiredApproversForDays($this->sampleWorkflow, 0.5);
        $this->assertEquals(['Manager'], $req05, '0.5 days must resolve to 1-2 day tier');
        $this->assertFalse(LeaveApplicationService::isManagerTierRequired($req05), 'Single-tier Manager does not require multi-tier endorsement');

        // 1.0 day -> ['Manager']
        $req10 = LeaveApplicationService::getRequiredApproversForDays($this->sampleWorkflow, 1.0);
        $this->assertEquals(['Manager'], $req10);

        // 2.0 days -> ['Manager']
        $req20 = LeaveApplicationService::getRequiredApproversForDays($this->sampleWorkflow, 2.0);
        $this->assertEquals(['Manager'], $req20);

        // 2.5 days -> resolves to 3-7 day tier (ceil = 3) -> ['Manager', 'HR Admin']
        $req25 = LeaveApplicationService::getRequiredApproversForDays($this->sampleWorkflow, 2.5);
        $this->assertEquals(['Manager', 'HR Admin'], $req25, '2.5 days must resolve to 3-7 day tier');
        $this->assertTrue(LeaveApplicationService::isManagerTierRequired($req25), '2.5 days requires Manager endorsement');

        // 5.0 days -> ['Manager', 'HR Admin']
        $req50 = LeaveApplicationService::getRequiredApproversForDays($this->sampleWorkflow, 5.0);
        $this->assertEquals(['Manager', 'HR Admin'], $req50);

        // 7.5 days -> resolves to 8-999 day tier (ceil = 8) -> ['Manager', 'Department Head', 'HR Admin']
        $req75 = LeaveApplicationService::getRequiredApproversForDays($this->sampleWorkflow, 7.5);
        $this->assertEquals(['Manager', 'Department Head', 'HR Admin'], $req75, '7.5 days must resolve to 8+ day tier');
        $this->assertTrue(in_array('Department Head', $req75, true), '7.5 days requires Department Head');

        // 10.0 days -> ['Manager', 'Department Head', 'HR Admin']
        $req100 = LeaveApplicationService::getRequiredApproversForDays($this->sampleWorkflow, 10.0);
        $this->assertEquals(['Manager', 'Department Head', 'HR Admin'], $req100);
    }

    /**
     * Test requiresManagerTier definition (Task 6 parity).
     */
    public function testRequiresManagerTierDefinition()
    {
        $this->assertFalse(LeaveApplicationService::isManagerTierRequired(['HR Admin', 'Finance']));
        $this->assertTrue(LeaveApplicationService::isManagerTierRequired(['Manager', 'HR Admin']));
        $this->assertFalse(LeaveApplicationService::isManagerTierRequired(['Manager']));
        $this->assertTrue(LeaveApplicationService::isManagerTierRequired(['Manager', 'Department Head', 'HR Admin']));
    }

    /**
     * Test dynamic approval steps generation.
     */
    public function testDynamicApprovalStepsStructure()
    {
        $emp = [
            'id'                   => 'EMP-001',
            'reporting_manager_id' => 'MGR-001',
            'manager_id'           => 'MGR-001',
            'reporting_to'         => 'MGR-001',
            'department_id'        => 'DEPT-001',
        ];

        // 1-tier Manager only: generates exactly 1 step
        $service = new LeaveApplicationService(new LeaveService());
        $steps1 = $service->buildApprovalSteps('lv-test1', ['Manager'], $emp, false);
        $this->assertCount(1, $steps1);
        $this->assertEquals('Line Manager', $steps1[0]['approver_role']);
        $this->assertEquals('MGR-001', $steps1[0]['approver_id']);
        $this->assertEquals('Pending', $steps1[0]['status']);

        // 2-tier Manager + HR: generates exactly 2 steps
        $steps2 = $service->buildApprovalSteps('lv-test2', ['Manager', 'HR Admin'], $emp, false);
        $this->assertCount(2, $steps2);
        $this->assertEquals('Line Manager', $steps2[0]['approver_role']);
        $this->assertEquals('HR Administration', $steps2[1]['approver_role']);

        // 3-tier Manager + Dept Head + HR: generates exactly 3 steps
        $steps3 = $service->buildApprovalSteps('lv-test3', ['Manager', 'Department Head', 'HR Admin'], $emp, false);
        $this->assertCount(3, $steps3);
        $this->assertEquals('Line Manager', $steps3[0]['approver_role']);
        $this->assertEquals('Department Head', $steps3[1]['approver_role']);
        $this->assertEquals('HR Administration', $steps3[2]['approver_role']);

        // Auto-approved steps have status Approved
        $stepsAuto = $service->buildApprovalSteps('lv-auto', ['Manager', 'HR Admin'], $emp, true);
        $this->assertCount(2, $stepsAuto);
        $this->assertEquals('Approved', $stepsAuto[0]['status']);
        $this->assertEquals('Approved', $stepsAuto[1]['status']);
    }

    /**
     * Test LeaveService resolution of auto-approval and rule parameters.
     */
    public function testResolveApplicationRulesAutoApprovalParameters()
    {
        $ruleEnt = [
            'leave_type_code'         => 'AL',
            'approval_required'       => false,
            'is_auto_approved'        => true,
            'auto_approve_under_days' => 2.0,
            'is_paid'                 => true,
            'sandwich_rule'           => false,
            'allow_negative_balance'  => false,
            'requires_attachment'     => false,
            'requires_reason'         => true,
        ];
        $leaveType = ['name' => 'Annual Leave', 'code' => 'AL'];

        $resolved = (new LeaveService())->resolveApplicationRules($ruleEnt, $leaveType);
        $this->assertFalse($resolved['approval_required']);
        $this->assertTrue($resolved['is_auto_approved']);
        $this->assertEquals(2.0, $resolved['auto_approve_under_days']);
    }

    /**
     * Test Department Head step resolution when dept_head_id is supplied directly on employee array.
     */
    public function testBuildApprovalStepsWithExplicitDeptHead()
    {
        $emp = [
            'id'                   => 'EMP-002',
            'reporting_manager_id' => 'MGR-002',
            'department_id'        => 'DEPT-ENG',
            'dept_head_id'         => 'DH-ENG-001',
        ];

        $service = new LeaveApplicationService(new LeaveService());
        $steps = $service->buildApprovalSteps('lv-test-dh', ['Manager', 'Department Head', 'HR Admin'], $emp, false);

        $this->assertCount(3, $steps);
        $this->assertEquals('Line Manager', $steps[0]['approver_role']);
        $this->assertEquals('MGR-002', $steps[0]['approver_id']);

        $this->assertEquals('Department Head', $steps[1]['approver_role']);
        $this->assertEquals('DH-ENG-001', $steps[1]['approver_id'], 'Department Head approver_id must resolve directly from employee array');

        $this->assertEquals('HR Administration', $steps[2]['approver_role']);
    }

    /**
     * Test approval steps when Manager and Department Head are the same person (dual-role deadlock prevention).
     */
    public function testDualRoleManagerAndDeptHeadSteps()
    {
        $emp = [
            'id'                   => 'EMP-003',
            'reporting_manager_id' => 'LEAD-001',
            'department_id'        => 'DEPT-SALES',
            'dept_head_id'         => 'LEAD-001', // Same individual is line manager and department head
        ];

        $service = new LeaveApplicationService(new LeaveService());
        $steps = $service->buildApprovalSteps('lv-test-dual', ['Manager', 'Department Head', 'HR Admin'], $emp, false);

        $this->assertCount(3, $steps);
        $this->assertEquals('LEAD-001', $steps[0]['approver_id']);
        $this->assertEquals('LEAD-001', $steps[1]['approver_id'], 'Line manager and Dept Head can be the same user without stepping generation failure');
    }

    /**
     * Test that "HR Admin" is not a distinct role:
     * Anyone with leave.hr_approve, leaves.hr_approve, leave.manage, or leaves.manage
     * possesses final HR approval authority (regardless of role code/title).
     * Plain leave.approve without leave.hr_approve does NOT qualify for the HR final approval step.
     */
    public function testHrStepRequiresSeparatePermissionAndIsNotRoleNameBound()
    {
        $validHrApprovalPerms = ['leave.hr_approve', 'leaves.hr_approve', 'leave.manage', 'leaves.manage'];
        foreach ($validHrApprovalPerms as $perm) {
            $isAuthority = in_array($perm, ['leave.hr_approve', 'leaves.hr_approve', 'leave.manage', 'leaves.manage'], true);
            $this->assertTrue($isAuthority, "Permission {$perm} must qualify for final HR leave approval.");
        }

        // Plain leave.approve, leave.endorse or view permissions do NOT qualify for the HR step
        $insufficientPerms = ['leave.approve', 'leaves.approve', 'leave.endorse', 'leaves.endorse', 'leave.view', 'leave.create'];
        foreach ($insufficientPerms as $perm) {
            $isAuthority = in_array($perm, ['leave.hr_approve', 'leaves.hr_approve', 'leave.manage', 'leaves.manage'], true);
            $this->assertFalse($isAuthority, "Plain permission {$perm} must NOT qualify for final HR leave approval.");
        }

        // Verify that authority is strictly permission-based, not hard-coded role names
        $userWithoutPerm = ['role_code' => 'manager', 'permissions' => ['leave.approve']];
        $hasHrStepPerm = in_array('leave.hr_approve', $userWithoutPerm['permissions'], true)
            || in_array('leave.manage', $userWithoutPerm['permissions'], true);
        $this->assertFalse($hasHrStepPerm, 'Role name manager without leave.hr_approve cannot perform HR final step.');
    }

    /**
     * Test organizational scope enforcement on final approval and rejection:
     * When an application is endorsed, final approval and rejection MUST NOT skip assertInScope.
     * An approver with branch-scoped permission cannot approve or reject an employee in a different branch.
     */
    public function testFinalApprovalAndRejectionEnforceScopeCheck()
    {
        // Approver in Branch 1
        $approverUser = [
            'id'        => 'usr-approver-01',
            'branch_id' => 'branch-01',
            'role_code' => 'hr_officer',
        ];

        // Target employee in Branch 1 (same branch)
        $employeeBranch1 = [
            'id'        => 'emp-001',
            'branch_id' => 'branch-01',
        ];

        // Target employee in Branch 2 (different branch)
        $employeeBranch2 = [
            'id'        => 'emp-002',
            'branch_id' => 'branch-02',
        ];

        // Simulated branch-scope evaluation
        $isBranch1InScope = ($approverUser['branch_id'] === $employeeBranch1['branch_id']);
        $this->assertTrue($isBranch1InScope, 'Approver should be in scope for employees in the same branch.');

        $isBranch2InScope = ($approverUser['branch_id'] === $employeeBranch2['branch_id']);
        $this->assertFalse($isBranch2InScope, 'Approver must NOT be in scope for employees outside their branch. Final approval and rejection cannot skip scope check!');
    }

    /**
     * Test separation of duties:
     * A different HR approver with leave.hr_approve can give final HR approval,
     * whereas the line manager who endorsed the request is strictly blocked by separation of duties.
     */
    public function testDifferentHrApproverCanGiveFinalApprovalWhileEndorserBlocked()
    {
        $application = [
            'id'             => 'lv-multi-tier-01',
            'employee_id'    => 'EMP-STAFF-01',
            'manager_id'     => 'EMP-MGR-01', // Manager 1 endorsed
            'manager_status' => 'Endorsed',
            'status'         => 'Endorsed',
            'total_days'     => 5.0,
        ];

        // Manager 1 (who endorsed) attempts final approval -> separation of duties blocks
        $manager1Ids = ['USR-MGR-01', 'EMP-MGR-01'];
        $isMgr1Blocked = in_array($application['manager_id'], $manager1Ids, true);
        $this->assertTrue($isMgr1Blocked, 'Line manager who endorsed must be blocked by separation of duties from final approval.');

        // HR Reviewer 2 (a different user with leave.hr_approve) attempts final approval -> allowed!
        $hrReviewer2Ids = ['USR-HR-02', 'EMP-HR-02'];
        $isHr2Blocked = in_array($application['manager_id'], $hrReviewer2Ids, true);
        $this->assertFalse($isHr2Blocked, 'A different approver with leave.hr_approve must NOT be blocked by separation of duties.');

        // Applicant self-approval is blocked
        $applicantIds = ['USR-STAFF-01', 'EMP-STAFF-01'];
        $isSelfApproval = in_array($application['employee_id'], $applicantIds, true);
        $this->assertTrue($isSelfApproval, 'Self-approval by the applicant must always be blocked.');
    }

    /**
     * 1. Direct manager with only leave.endorse approves a 1-2 day leave -> success.
     */
    public function testDirectManagerWithOnlyLeaveEndorseApprovesSingleTierLeaveSuccess()
    {
        $targetEmp = [
            'id'                   => 'EMP-STAFF-01',
            'company_id'           => 'comp-01',
            'department_id'        => 'dept-sales',
            'reporting_manager_id' => 'EMP-MGR-01',
            'manager_id'           => 'EMP-MGR-01',
        ];

        $managerUser = [
            'id'            => 'USR-MGR-01',
            'company_id'    => 'comp-01',
            'department_id' => 'dept-sales',
            'employee_id'   => 'EMP-MGR-01',
            'role_code'     => 'line_manager',
            'permissions'   => ['leave.endorse'],
        ];

        $managerEmp = [
            'id'            => 'EMP-MGR-01',
            'company_id'    => 'comp-01',
            'department_id' => 'dept-sales',
        ];

        // 1-2 day leave tier (required approvers is only ['Manager'])
        $application = [
            'id'          => 'LV-101',
            'company_id'  => 'comp-01',
            'employee_id' => 'EMP-STAFF-01',
            'total_days'  => 2.0,
            'status'      => 'Pending',
        ];

        $res = LeaveApplicationService::checkApprovalPolicy(
            $application,
            $targetEmp,
            $managerUser,
            $managerEmp,
            'USR-MGR-01',
            $this->sampleWorkflow
        );

        $this->assertTrue($res['allowed'], 'Direct manager with only leave.endorse should be allowed to approve 1-2 day leave.');
        $this->assertEquals(200, $res['code']);
    }

    /**
     * 2. Same manager tries to approve a 3-7 day leave (HR tier) -> 403.
     */
    public function testDirectManagerWithOnlyLeaveEndorseFailsOnHrTierWith403()
    {
        $targetEmp = [
            'id'                   => 'EMP-STAFF-01',
            'company_id'           => 'comp-01',
            'department_id'        => 'dept-sales',
            'reporting_manager_id' => 'EMP-MGR-01',
            'manager_id'           => 'EMP-MGR-01',
        ];

        $managerUser = [
            'id'            => 'USR-MGR-01',
            'company_id'    => 'comp-01',
            'department_id' => 'dept-sales',
            'employee_id'   => 'EMP-MGR-01',
            'role_code'     => 'line_manager',
            'permissions'   => ['leave.endorse'],
        ];

        $managerEmp = [
            'id'            => 'EMP-MGR-01',
            'company_id'    => 'comp-01',
            'department_id' => 'dept-sales',
        ];

        // 3-7 day leave tier (required approvers: ['Manager', 'HR Admin'])
        $application = [
            'id'             => 'LV-102',
            'company_id'     => 'comp-01',
            'employee_id'    => 'EMP-STAFF-01',
            'total_days'     => 4.0,
            'manager_status' => 'Pending',
            'status'         => 'Pending',
        ];

        $res = LeaveApplicationService::checkApprovalPolicy(
            $application,
            $targetEmp,
            $managerUser,
            $managerEmp,
            'USR-MGR-01',
            $this->sampleWorkflow
        );

        $this->assertFalse($res['allowed'], 'Direct manager without leave.hr_approve must be blocked from final approval on HR tier.');
        $this->assertEquals(403, $res['code']);
    }

    /**
     * 3. Manager of another department approves -> 403 (scope).
     */
    public function testManagerOfAnotherDepartmentCannotApproveReturns403Scope()
    {
        $targetEmp = [
            'id'                   => 'EMP-STAFF-01',
            'company_id'           => 'comp-01',
            'department_id'        => 'dept-sales',
            'reporting_manager_id' => 'EMP-MGR-SALES',
            'manager_id'           => 'EMP-MGR-SALES',
        ];

        // Manager in Engineering department (not target employee's direct manager)
        $otherDeptManagerUser = [
            'id'            => 'USR-MGR-ENG',
            'company_id'    => 'comp-01',
            'department_id' => 'dept-engineering',
            'employee_id'   => 'EMP-MGR-ENG',
            'role_code'     => 'line_manager',
            'permissions'   => ['leave.endorse'],
        ];

        $otherDeptManagerEmp = [
            'id'            => 'EMP-MGR-ENG',
            'company_id'    => 'comp-01',
            'department_id' => 'dept-engineering',
        ];

        $application = [
            'id'          => 'LV-103',
            'company_id'  => 'comp-01',
            'employee_id' => 'EMP-STAFF-01',
            'total_days'  => 1.5,
            'status'      => 'Pending',
        ];

        // Case A: Manager with leave.endorse outside reporting line
        $resA = LeaveApplicationService::checkApprovalPolicy(
            $application,
            $targetEmp,
            $otherDeptManagerUser,
            $otherDeptManagerEmp,
            'USR-MGR-ENG',
            $this->sampleWorkflow
        );

        $this->assertFalse($resA['allowed'], 'Manager from another department with leave.endorse must be denied approval.');
        $this->assertEquals(403, $resA['code']);

        // Case B: Manager with leave.approve but outside department scope
        $otherDeptManagerWithApprove = $otherDeptManagerUser;
        $otherDeptManagerWithApprove['permissions'] = ['leave.approve'];

        $resB = LeaveApplicationService::checkApprovalPolicy(
            $application,
            $targetEmp,
            $otherDeptManagerWithApprove,
            $otherDeptManagerEmp,
            'USR-MGR-ENG',
            $this->sampleWorkflow
        );

        $this->assertFalse($resB['allowed'], 'Manager from another department with leave.approve must be denied approval on scope.');
        $this->assertEquals(403, $resB['code']);
    }
}
