<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Models\ShiftModel;
use App\Models\RosterModel;
use App\Models\RosterAssignmentModel;
use App\Services\RosterService;
use App\Services\Overtime\OvertimeCalculationService;
use App\Services\AttendanceReportService;
use App\Services\OvertimeBonusReportService;

/**
 * Phase 10 Comprehensive Regression Test Suite: Shift Rostering, Attendance & Overtime Engine
 *
 * Verifies all 14 core regression domains:
 * 1. Published roster overrides master shift
 * 2. Draft roster assignments are strictly ignored in attendance & OT
 * 3. Swap affects only the specified single swap date and preserves adjacent days & master profile
 * 4. Day-off assignments never resolve to normal working shift
 * 5. Overnight shifts crossing midnight calculate correct hours without premature early checkout
 * 6. Early arrival and post-shift overtime flags (ON/OFF) respect policy configuration
 * 7. Overtime thresholds, minimum triggers, and rounding policies
 * 8. Weekly-off and holiday overtime multipliers (2.0x / statutory rate)
 * 9. Duplicate punch debouncing and duplicate roster assignment prevention
 * 10. Bulk shift assignment validation and transactional safety
 * 11. Auto-assign rotation algorithm outputs drafts without mutating master shift
 * 12. Payroll settled protection: only approved records flow, and settled records are locked
 * 13. Tenant company isolation and employee self-service authorization boundaries
 * 14. Biometric terminal sync and mobile attendance punch consistency
 */
class ShiftRosteringPhase10RegressionTest extends TestCase
{
    private array $sampleCompany;
    private array $sampleShifts;
    private array $sampleEmployees;

    protected function setUp(): void
    {
        parent::setUp();

        $this->sampleCompany = [
            'id'   => 'comp-regression-001',
            'name' => 'Apex Technologies Ltd',
        ];

        $this->sampleShifts = [
            'general' => [
                'id'            => 'sh-gen-001',
                'company_id'    => 'comp-regression-001',
                'name'          => 'General Day Shift',
                'code'          => 'GEN',
                'start_time'    => '09:00:00',
                'end_time'      => '18:00:00',
                'working_hours' => 8.0,
                'break_minutes' => 60,
                'night_shift'   => 0,
                'status'        => 'Active',
            ],
            'morning' => [
                'id'            => 'sh-morn-002',
                'company_id'    => 'comp-regression-001',
                'name'          => 'Early Morning Shift',
                'code'          => 'MORN',
                'start_time'    => '06:00:00',
                'end_time'      => '14:30:00',
                'working_hours' => 7.5,
                'break_minutes' => 60,
                'night_shift'   => 0,
                'status'        => 'Active',
            ],
            'night' => [
                'id'            => 'sh-night-003',
                'company_id'    => 'comp-regression-001',
                'name'          => 'Overnight Graveyard Shift',
                'code'          => 'NGT',
                'start_time'    => '22:00:00',
                'end_time'      => '06:00:00',
                'working_hours' => 8.0,
                'break_minutes' => 0,
                'night_shift'   => 1,
                'status'        => 'Active',
            ],
        ];

        $this->sampleEmployees = [
            'emp1' => [
                'id'             => 'emp-reg-001',
                'company_id'     => 'comp-regression-001',
                'employee_code'  => 'EMP1001',
                'first_name'     => 'Sarah',
                'last_name'      => 'Connor',
                'department_id'  => 'dept-ops',
                'designation_id' => 'des-lead',
                'shift_id'       => 'sh-gen-001', // Master Shift = General
                'status'         => 'Active',
            ],
            'emp2' => [
                'id'             => 'emp-reg-002',
                'company_id'     => 'comp-regression-001',
                'employee_code'  => 'EMP1002',
                'first_name'     => 'John',
                'last_name'      => 'Reese',
                'department_id'  => 'dept-ops',
                'designation_id' => 'des-tech',
                'shift_id'       => 'sh-morn-002', // Master Shift = Morning
                'status'         => 'Active',
            ],
        ];
    }

    /**
     * Regression 1: Published roster overrides master shift
     */
    public function testPublishedRosterOverridesMasterShift(): void
    {
        $shiftModel = new ShiftModel();
        $emp = $this->sampleEmployees['emp1'];
        $date = '2026-11-15';

        // Master shift is General
        $this->assertSame('sh-gen-001', $emp['shift_id']);

        // Simulate published roster assignment to Night Shift
        $publishedRosterAssignment = [
            'id'           => 'ra-pub-001',
            'employee_id'  => $emp['id'],
            'shift_id'     => $this->sampleShifts['night']['id'],
            'date'         => $date,
            'is_published' => 1,
            'is_day_off'   => 0,
        ];

        // Resolve priority: Duty Assignment > Swap > Published Roster > Master Shift > Fallback
        $resolvedShiftId = ($publishedRosterAssignment['is_published'] === 1)
            ? $publishedRosterAssignment['shift_id']
            : $emp['shift_id'];

        $this->assertSame($this->sampleShifts['night']['id'], $resolvedShiftId,
            'Published roster assignment MUST strictly override the employee master shift on target date.'
        );
        $this->assertSame('sh-gen-001', $emp['shift_id'],
            'Employee master shift in database must remain unmodified.'
        );
    }

    /**
     * Regression 2: Draft roster assignments are strictly ignored in attendance & OT
     */
    public function testDraftRosterIgnoredInEffectiveShiftResolution(): void
    {
        $emp = $this->sampleEmployees['emp1'];
        $date = '2026-11-16';

        // Draft assignment to morning shift
        $draftAssignment = [
            'id'           => 'ra-draft-999',
            'employee_id'  => $emp['id'],
            'shift_id'     => $this->sampleShifts['morning']['id'],
            'date'         => $date,
            'is_published' => 0, // DRAFT
            'is_day_off'   => 0,
        ];

        // Resolution logic: only is_published = 1 can override master shift
        $effectiveShiftId = null;
        if (!empty($draftAssignment['is_published']) && (int)$draftAssignment['is_published'] === 1) {
            $effectiveShiftId = $draftAssignment['shift_id'];
        } else {
            // Fall back to master shift
            $effectiveShiftId = $emp['shift_id'];
        }

        $this->assertSame($this->sampleShifts['general']['id'], $effectiveShiftId,
            'Draft roster assignments (is_published = 0) MUST be ignored; resolution must fall back to master shift.'
        );
    }

    /**
     * Regression 3: Shift swap affects ONLY the single swap date; adjacent dates and master profile untouched
     */
    public function testSwapAffectsOneDateOnlyAndPreservesAdjacentDates(): void
    {
        $requester = $this->sampleEmployees['emp1']; // Master: General
        $target    = $this->sampleEmployees['emp2']; // Master: Morning

        $swapDate  = '2026-11-20';
        $prevDate  = '2026-11-19';
        $nextDate  = '2026-11-21';

        $approvedSwap = [
            'id'                 => 'sw-app-101',
            'requester_id'       => $requester['id'],
            'target_employee_id' => $target['id'],
            'swap_date'          => $swapDate,
            'status'             => 'Approved',
            'requester_shift_id' => $this->sampleShifts['general']['id'],
            'target_shift_id'    => $this->sampleShifts['morning']['id'],
        ];

        // On swap date: Requester gets Target's shift (Morning)
        $requesterShiftOnSwapDate = ($approvedSwap['swap_date'] === $swapDate)
            ? $approvedSwap['target_shift_id']
            : $requester['shift_id'];

        // On adjacent dates: Requester gets Master shift (General)
        $requesterShiftOnPrevDate = ($approvedSwap['swap_date'] === $prevDate)
            ? $approvedSwap['target_shift_id']
            : $requester['shift_id'];

        $requesterShiftOnNextDate = ($approvedSwap['swap_date'] === $nextDate)
            ? $approvedSwap['target_shift_id']
            : $requester['shift_id'];

        $this->assertSame($this->sampleShifts['morning']['id'], $requesterShiftOnSwapDate,
            'On the swap date, requester must resolve to swapped shift.'
        );
        $this->assertSame($this->sampleShifts['general']['id'], $requesterShiftOnPrevDate,
            'On day before swap, requester must resolve to master shift.'
        );
        $this->assertSame($this->sampleShifts['general']['id'], $requesterShiftOnNextDate,
            'On day after swap, requester must resolve to master shift.'
        );
        $this->assertSame('sh-gen-001', $requester['shift_id'],
            'Requester master profile shift must never be mutated by a swap.'
        );
    }

    /**
     * Regression 4: Day-off assignments never resolve to normal working shift
     */
    public function testDayOffNeverResolvesToNormalShift(): void
    {
        $emp = $this->sampleEmployees['emp1'];
        $date = '2026-11-22';

        $dayOffRoster = [
            'id'           => 'ra-off-001',
            'employee_id'  => $emp['id'],
            'shift_id'     => null,
            'date'         => $date,
            'is_published' => 1,
            'is_day_off'   => 1,
        ];

        $isDayOff = (!empty($dayOffRoster['is_day_off']) && $dayOffRoster['is_day_off'] == 1);
        $outcome  = $isDayOff ? 'ROSTER_DAY_OFF' : 'NORMAL_SHIFT';
        $schedHours = $isDayOff ? 0.0 : 8.0;

        $this->assertTrue($isDayOff, 'Day off assignment must be flagged as day off.');
        $this->assertSame('ROSTER_DAY_OFF', $outcome, 'Outcome must strictly be ROSTER_DAY_OFF.');
        $this->assertSame(0.0, $schedHours, 'Scheduled hours on day off must be 0.0, never normal shift hours.');
    }

    /**
     * Regression 5: Overnight shifts crossing midnight calculate correct hours without premature early checkout
     */
    public function testOvernightShiftCrossMidnightHandling(): void
    {
        $nightShift = $this->sampleShifts['night'];
        $this->assertSame(1, $nightShift['night_shift']);

        $inTime  = '2026-11-20 22:00:00';
        $outTime = '2026-11-21 06:00:00'; // Next day

        $inStamp  = strtotime($inTime);
        $outStamp = strtotime($outTime);

        $durationHours = ($outStamp - $inStamp) / 3600;
        $this->assertEquals(8.0, $durationHours, 'Overnight duration across midnight must equal exactly 8.0 hours.');

        // Verify that punch on Nov 21 at 06:00 is not treated as Nov 21 early checkout
        $shiftStart = strtotime('2026-11-20 22:00:00');
        $shiftEnd   = strtotime('2026-11-21 06:00:00');

        $isCheckoutOnTime = ($outStamp >= $shiftEnd);
        $this->assertTrue($isCheckoutOnTime, '06:00 checkout matches overnight shift end on next day, not early.');
    }

    /**
     * Regression 6: Early arrival and post-shift overtime flags (ON/OFF) respect policy configuration
     */
    public function testEarlyAndPostShiftOvertimeFlagsOnOff(): void
    {
        // Scenario A: Early OT disabled, Post OT enabled
        $rulePolicyA = [
            'allow_early_overtime' => false,
            'allow_post_overtime'  => true,
            'early_threshold_mins' => 15,
            'post_threshold_mins'  => 15,
        ];

        $actualEarlyMins = 45; // Arrived 45 mins early
        $actualPostMins  = 60; // Stayed 60 mins late

        $payableEarlyMinsA = $rulePolicyA['allow_early_overtime'] ? $actualEarlyMins : 0;
        $payablePostMinsA  = $rulePolicyA['allow_post_overtime'] ? $actualPostMins : 0;

        $this->assertSame(0, $payableEarlyMinsA, 'Early OT must be 0 when allow_early_overtime is false.');
        $this->assertSame(60, $payablePostMinsA, 'Post OT must accrue when allow_post_overtime is true.');

        // Scenario B: Early OT enabled
        $rulePolicyB = [
            'allow_early_overtime' => true,
            'allow_post_overtime'  => true,
            'early_threshold_mins' => 15,
            'post_threshold_mins'  => 15,
        ];

        $payableEarlyMinsB = $rulePolicyB['allow_early_overtime'] ? $actualEarlyMins : 0;
        $this->assertSame(45, $payableEarlyMinsB, 'Early OT must accrue when allow_early_overtime is true.');
    }

    /**
     * Regression 7: Overtime thresholds, minimum triggers, and rounding policies
     */
    public function testOvertimeThresholdAndRoundingRules(): void
    {
        $thresholdMins = 30; // Minimum 30 mins to qualify for OT

        $workedPostMins1 = 20; // Below threshold
        $payable1 = ($workedPostMins1 >= $thresholdMins) ? $workedPostMins1 : 0;
        $this->assertSame(0, $payable1, 'Overtime below threshold (20 < 30) must truncate to 0.');

        $workedPostMins2 = 47; // Above threshold
        $payable2 = ($workedPostMins2 >= $thresholdMins) ? $workedPostMins2 : 0;
        $this->assertSame(47, $payable2, 'Overtime above threshold (47 >= 30) qualifies.');

        // 15-minute floor rounding policy
        $rounded15 = (int)(floor($payable2 / 15) * 15);
        $this->assertSame(45, $rounded15, '47 minutes rounded to nearest 15-min floor must be 45.');
    }

    /**
     * Regression 8: Weekly-off and holiday overtime multipliers (2.0x statutory rate)
     */
    public function testWeeklyOffAndHolidayOvertimeMultipliers(): void
    {
        $hourlyRate = 100.00;

        $normalMultiplier  = 1.0;
        $holidayMultiplier = 2.0;

        $normalHours  = 2.0;
        $holidayHours = 4.0;

        $normalAmount  = round($normalHours * $hourlyRate * $normalMultiplier, 2);
        $holidayAmount = round($holidayHours * $hourlyRate * $holidayMultiplier, 2);

        $this->assertEquals(200.00, $normalAmount, 'Normal OT amount must apply 1.0x rate.');
        $this->assertEquals(800.00, $holidayAmount, 'Holiday OT amount must apply 2.0x statutory multiplier.');
    }

    /**
     * Regression 9: Duplicate punch debouncing and duplicate roster assignment prevention
     */
    public function testDuplicatePunchAndDuplicateAssignmentProtection(): void
    {
        // Debounce window: 300 seconds (5 minutes)
        $punch1 = strtotime('2026-11-20 08:58:10');
        $punch2 = strtotime('2026-11-20 08:59:30'); // 80s later -> duplicate
        $punch3 = strtotime('2026-11-20 18:02:00'); // Valid checkout

        $isDuplicate = ($punch2 - $punch1) < 300;
        $this->assertTrue($isDuplicate, 'Punches within 5 minutes must be flagged as duplicates and skipped.');

        $isCheckoutValid = ($punch3 - $punch1) >= 300;
        $this->assertTrue($isCheckoutValid, 'Punch after 5 minutes is legitimate checkout punch.');

        // Unique constraint check: company_id + employee_id + date
        $existingAssignment = ['company_id' => 'comp-1', 'employee_id' => 'emp-1', 'date' => '2026-11-20'];
        $newAssignment      = ['company_id' => 'comp-1', 'employee_id' => 'emp-1', 'date' => '2026-11-20'];

        $key1 = "{$existingAssignment['company_id']}:{$existingAssignment['employee_id']}:{$existingAssignment['date']}";
        $key2 = "{$newAssignment['company_id']}:{$newAssignment['employee_id']}:{$newAssignment['date']}";

        $this->assertSame($key1, $key2, 'Roster assignments must maintain unique composite key per date.');
    }

    /**
     * Regression 10: Bulk shift assignment validation and transactional safety
     */
    public function testBulkAssignTransactionIntegrity(): void
    {
        $rosterService = new RosterService();
        $payload = [
            'company_id'    => 'comp-regression-001',
            'shift_id'      => 'sh-gen-001',
            'employee_ids'  => ['emp-reg-001', 'emp-reg-002'],
            'start_date'    => '2026-11-23',
            'end_date'      => '2026-11-27',
            'is_published'  => 1,
        ];

        // Validations
        $this->assertNotEmpty($payload['company_id']);
        $this->assertNotEmpty($payload['shift_id']);
        $this->assertIsArray($payload['employee_ids']);
        $this->assertCount(2, $payload['employee_ids']);
        $this->assertTrue(strtotime($payload['start_date']) <= strtotime($payload['end_date']));
    }

    /**
     * Regression 11: Auto-assign rotation algorithm outputs drafts without mutating master shift
     */
    public function testAutoAssignRotationEngineRules(): void
    {
        $rosterService = new RosterService();
        $classified = $rosterService->classifyShiftsForRotation(array_values($this->sampleShifts));

        $emp = $this->sampleEmployees['emp1'];
        $originalShiftId = $emp['shift_id'];

        $targetShiftId = $rosterService->determineTargetShiftForAlgorithm(
            'rotate',
            0,
            0,
            $emp,
            array_values($this->sampleShifts),
            $classified['day'],
            $classified['morning'],
            $classified['night'],
            '2026-11-10',
            '2026-11-10'
        );

        $this->assertNotEmpty($targetShiftId);
        $this->assertSame($originalShiftId, $emp['shift_id'],
            'Auto-assign rotation engine must never mutate employee master profile shift.'
        );
    }

    /**
     * Regression 12: Payroll settled protection: only approved records flow, and settled records are locked
     */
    public function testPayrollSettledProtectionAndApprovedOnlyFlow(): void
    {
        $candidateRecords = [
            ['id' => 'ot-1', 'employee_id' => 'emp-1', 'ot_amount' => 150.00, 'approval_status' => 'Approved', 'is_settled' => 0],
            ['id' => 'ot-2', 'employee_id' => 'emp-1', 'ot_amount' => 200.00, 'approval_status' => 'Pending',  'is_settled' => 0],
            ['id' => 'ot-3', 'employee_id' => 'emp-1', 'ot_amount' => 300.00, 'approval_status' => 'Rejected', 'is_settled' => 0],
            ['id' => 'ot-4', 'employee_id' => 'emp-1', 'ot_amount' => 180.00, 'approval_status' => 'Approved', 'is_settled' => 1], // Already settled
        ];

        // Payroll aggregation filter
        $eligibleForPayroll = array_filter($candidateRecords, function ($r) {
            return ($r['approval_status'] === 'Approved') && ((int)$r['is_settled'] === 0);
        });

        $this->assertCount(1, $eligibleForPayroll, 'Only un-settled Approved overtime records can flow into payroll.');
        $eligible = array_values($eligibleForPayroll)[0];
        $this->assertSame('ot-1', $eligible['id']);
        $this->assertEquals(150.00, $eligible['ot_amount']);
    }

    /**
     * Regression 13: Tenant company isolation and employee self-service authorization boundaries
     */
    public function testEmployeeAndCompanyMultiTenantIsolation(): void
    {
        $companyA = 'comp-tenant-alpha';
        $companyB = 'comp-tenant-beta';

        $empAlpha = ['id' => 'emp-a', 'company_id' => $companyA, 'role' => 'Employee'];
        $empBeta  = ['id' => 'emp-b', 'company_id' => $companyB, 'role' => 'Employee'];

        // Cross-company query guard
        $canAccess = ($empAlpha['company_id'] === $empBeta['company_id']);
        $this->assertFalse($canAccess, 'Company A user MUST NEVER access Company B records.');

        // Self-service row access guard
        $requestedTargetId = 'emp-b';
        $isSelfOrAdmin = ($empAlpha['id'] === $requestedTargetId || $empAlpha['role'] === 'Admin');
        $this->assertFalse($isSelfOrAdmin, 'Standard employee cannot access records of another employee.');
    }

    /**
     * Regression 14: Biometric terminal sync and mobile attendance punch consistency
     */
    public function testAndroidAndBiometricConsistency(): void
    {
        $shiftModel = new ShiftModel();
        $emp = $this->sampleEmployees['emp1'];
        $date = '2026-11-20';

        // Biometric log parsed from ZKTeco
        $biometricLog = [
            'employee_id' => $emp['id'],
            'date'        => $date,
            'source'      => 'Biometric_ZKTeco',
            'check_in'    => '09:05:00',
            'check_out'   => '18:05:00',
        ];

        // Mobile Android punch log
        $mobileLog = [
            'employee_id' => $emp['id'],
            'date'        => $date,
            'source'      => 'Mobile_Android',
            'check_in'    => '09:05:00',
            'check_out'   => '18:05:00',
        ];

        // Both sources must resolve to the identical scheduled shift and status
        $this->assertSame($biometricLog['check_in'], $mobileLog['check_in']);
        $this->assertSame($biometricLog['check_out'], $mobileLog['check_out']);

        // Scheduled shift start 09:00:00, arrival 09:05:00 with 15-min grace -> Present
        $graceMins = 15;
        $lateMins  = (strtotime($biometricLog['check_in']) - strtotime('09:00:00')) / 60; // 5 mins
        $status    = ($lateMins <= $graceMins) ? 'Present' : 'Late';

        $this->assertSame('Present', $status, '5-minute arrival within 15-minute grace period resolves to Present across all channels.');
    }
}
