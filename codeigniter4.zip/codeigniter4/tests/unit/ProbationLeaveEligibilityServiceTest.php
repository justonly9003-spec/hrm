<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class ProbationLeaveEligibilityServiceTest extends TestCase
{
    /**
     * Test exact date calculation for probation period:
     * Joining Date = 2026-01-01
     * Duration = 3 Months
     * Expected End Date = 2026-03-31 (Day before 3 full months)
     */
    public function testProbationEndDateCalculation()
    {
        $startDate = '2026-01-01';
        $durationValue = 3;
        $unit = 'Months';

        $dt = new \DateTime($startDate);
        $dt->modify("+{$durationValue} months");
        $dt->modify("-1 day");
        $calculatedEnd = $dt->format('Y-m-d');

        $this->assertEquals('2026-03-31', $calculatedEnd, "Probation period of 3 months starting 2026-01-01 must end on 2026-03-31.");

        $dayAfter = (new \DateTime($calculatedEnd))->modify('+1 day')->format('Y-m-d');
        $this->assertEquals('2026-04-01', $dayAfter, "First post-probation eligible day is 2026-04-01.");
    }

    /**
     * Test business rule:
     * 01-01-2026 -> 31-03-2026 = NOT ELIGIBLE
     * 01-04-2026 onward = AUTOMATICALLY ELIGIBLE
     */
    public function testAnnualLeaveEligibilityDuringAndAfterProbation()
    {
        $joinDate = '2026-01-01';
        $probationEnd = '2026-03-31';

        // Dates to test
        $midProbationDate = '2026-02-15';
        $lastProbationDate = '2026-03-31';
        $firstEligibleDate = '2026-04-01';
        $subsequentDate = '2026-06-15';

        // During probation checks:
        $this->assertTrue(strtotime($midProbationDate) <= strtotime($probationEnd), "Mid-probation date is under probation.");
        $this->assertTrue(strtotime($lastProbationDate) <= strtotime($probationEnd), "Last day of probation is under probation.");

        // Post-probation checks:
        $this->assertTrue(strtotime($firstEligibleDate) > strtotime($probationEnd), "2026-04-01 is past probation completion date.");
        $this->assertTrue(strtotime($subsequentDate) > strtotime($probationEnd), "Subsequent dates remain automatically eligible without HR intervention.");
    }

    /**
     * Test probation extension handling:
     * When probation is extended from 2026-03-31 to 2026-05-31
     */
    public function testProbationExtensionHandling()
    {
        $originalEnd = '2026-03-31';
        $extendedEnd = '2026-05-31';

        $testDate = '2026-04-15';

        // Before extension, 2026-04-15 would have been eligible:
        $this->assertTrue(strtotime($testDate) > strtotime($originalEnd));

        // After extension, 2026-04-15 is NOT eligible:
        $this->assertFalse(strtotime($testDate) > strtotime($extendedEnd));

        // New eligible date is 2026-06-01:
        $newFirstEligible = (new \DateTime($extendedEnd))->modify('+1 day')->format('Y-m-d');
        $this->assertEquals('2026-06-01', $newFirstEligible);
    }

    /**
     * Test early confirmation handling:
     * When employee is confirmed early on 2026-02-15 instead of 2026-03-31
     */
    public function testEarlyConfirmationHandling()
    {
        $confirmedDate = '2026-02-15';
        $testDate = '2026-02-20';

        // Employee confirmed early becomes eligible from confirmation date onward
        $isEligible = strtotime($testDate) >= strtotime($confirmedDate);
        $this->assertTrue($isEligible, "Employee confirmed early must be eligible on and after confirmation date.");
    }

    /**
     * Test employee-level override precedence
     */
    public function testEmployeeLevelOverridePrecedence()
    {
        $overrides = [
            [
                'leave_type_id'   => 'LT-ANNUAL',
                'override_status' => 'Eligible',
                'effective_date'  => '2026-01-15',
                'reason'          => 'Executive Board Approval'
            ]
        ];

        $leaveTypeId = 'LT-ANNUAL';
        $applicationDate = '2026-02-01';

        $matchingOverride = null;
        foreach ($overrides as $o) {
            if ($o['leave_type_id'] === $leaveTypeId && strtotime($applicationDate) >= strtotime($o['effective_date'])) {
                $matchingOverride = $o;
                break;
            }
        }

        $this->assertNotNull($matchingOverride);
        $this->assertEquals('Eligible', $matchingOverride['override_status']);
    }
}
