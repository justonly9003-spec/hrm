<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class AssetCategoryTest extends TestCase
{
    /**
     * Test AssetCategoryModel and AssetCategoryController class definitions & contracts
     */
    public function testClassesAndMethodsExist()
    {
        $modelClass = '\App\Models\AssetCategoryModel';
        $controllerClass = '\App\Controllers\Assets\AssetCategoryController';
        $assetModelClass = '\App\Models\AssetModel';
        $assetControllerClass = '\App\Controllers\Assets\AssetController';

        $this->assertTrue(class_exists($modelClass), "AssetCategoryModel class must exist.");
        $this->assertTrue(class_exists($controllerClass), "AssetCategoryController class must exist.");
        $this->assertTrue(class_exists($assetModelClass), "AssetModel class must exist.");
        $this->assertTrue(class_exists($assetControllerClass), "AssetController class must exist.");

        $modelRef = new \ReflectionClass($modelClass);
        $this->assertTrue($modelRef->hasMethod('getCategories'));
        $this->assertTrue($modelRef->hasMethod('getCategoriesWithAssetCount'));
        $this->assertTrue($modelRef->hasMethod('findInTenant'));
        $this->assertTrue($modelRef->hasMethod('hasAssets'));

        $ctrlRef = new \ReflectionClass($controllerClass);
        $this->assertTrue($ctrlRef->hasMethod('index'));
        $this->assertTrue($ctrlRef->hasMethod('apiList'));
        $this->assertTrue($ctrlRef->hasMethod('store'));
        $this->assertTrue($ctrlRef->hasMethod('update'));
        $this->assertTrue($ctrlRef->hasMethod('delete'));
    }

    /**
     * Test Tenant Isolation: categories and operations are isolated by company_id
     */
    public function testTenantIsolation()
    {
        $tenantA = 'comp-tenant-001';
        $tenantB = 'comp-tenant-002';

        $categoryA = [
            'id'         => 'astcat-001',
            'company_id' => $tenantA,
            'name'       => 'High-End Laptops',
            'code'       => 'AST-LPT',
        ];

        $categoryB = [
            'id'         => 'astcat-002',
            'company_id' => $tenantB,
            'name'       => 'High-End Laptops',
            'code'       => 'AST-LPT',
        ];

        // Unique per company allows same name in different tenants
        $this->assertNotEquals($categoryA['company_id'], $categoryB['company_id']);
        $this->assertEquals($categoryA['name'], $categoryB['name']);

        // Cross-tenant access validation: accessing categoryB from tenantA context must be prohibited
        $scopedCompanyId = $tenantA;
        $isCrossTenant = !empty($categoryB['company_id']) && $categoryB['company_id'] !== $scopedCompanyId;
        $this->assertTrue($isCrossTenant, "Cross-tenant access must be detected and rejected.");
    }

    /**
     * Test Delete Block when category has assigned assets
     */
    public function testDeleteBlockedWhenAssetsExist()
    {
        $companyId = 'comp-tenant-001';
        $categoryId = 'astcat-laptop';

        // Mock database state with assets linked to this category
        $assets = [
            ['id' => 'ast-1', 'company_id' => $companyId, 'category_id' => $categoryId, 'asset_name' => 'MacBook Pro 16'],
            ['id' => 'ast-2', 'company_id' => $companyId, 'category_id' => $categoryId, 'asset_name' => 'ThinkPad P1'],
        ];

        $assetCount = count(array_filter($assets, function ($a) use ($companyId, $categoryId) {
            return $a['company_id'] === $companyId && $a['category_id'] === $categoryId;
        }));

        $this->assertGreaterThan(0, $assetCount);

        // Deletion rule: must block deletion if hasAssets is true
        $hasAssets = ($assetCount > 0);
        $this->assertTrue($hasAssets, "hasAssets must return true when assets are assigned.");

        $canDelete = !$hasAssets;
        $this->assertFalse($canDelete, "Category deletion must be prohibited when assets are linked.");
    }

    /**
     * Test Idempotent Data Migration Logic
     */
    public function testDataMigrationIdempotency()
    {
        $companyId = 'comp-tenant-001';
        
        // Simulating legacy company_assets records with free-text category
        $assets = [
            ['id' => 'ast-1', 'company_id' => $companyId, 'category' => 'Hardware', 'category_id' => null],
            ['id' => 'ast-2', 'company_id' => $companyId, 'category' => 'Hardware', 'category_id' => null],
            ['id' => 'ast-3', 'company_id' => $companyId, 'category' => 'Monitors', 'category_id' => null],
        ];

        $existingCategories = [];

        // First migration run
        foreach ($assets as &$asset) {
            $catName = trim($asset['category']);
            if (!isset($existingCategories[$catName])) {
                $existingCategories[$catName] = 'astcat-' . md5($catName);
            }
            if (empty($asset['category_id'])) {
                $asset['category_id'] = $existingCategories[$catName];
            }
        }
        unset($asset);

        $this->assertCount(2, $existingCategories); // Hardware and Monitors
        $this->assertEquals($existingCategories['Hardware'], $assets[0]['category_id']);
        $this->assertEquals($existingCategories['Hardware'], $assets[1]['category_id']);
        $this->assertEquals($existingCategories['Monitors'], $assets[2]['category_id']);

        // Second migration run (idempotency check)
        $categoriesBefore = $existingCategories;
        foreach ($assets as &$asset) {
            $catName = trim($asset['category']);
            // Already exists in table => do not insert duplicate
            if (!isset($existingCategories[$catName])) {
                $existingCategories[$catName] = 'astcat-' . md5($catName);
            }
            if (empty($asset['category_id'])) {
                $asset['category_id'] = $existingCategories[$catName];
            }
        }
        unset($asset);

        $this->assertEquals($categoriesBefore, $existingCategories, "Re-running migration must not create duplicate categories.");
    }

    /**
     * Test Asset Create and Update Reject Invalid or Cross-Tenant Category
     */
    public function testAssetCreateRejectsInvalidCategory()
    {
        $currentCompanyId = 'comp-tenant-001';
        $otherCompanyId   = 'comp-tenant-002';

        $validCategory = [
            'id'         => 'astcat-valid',
            'company_id' => $currentCompanyId,
            'name'       => 'Laptops',
            'requires_serial' => 1
        ];

        $otherCompanyCategory = [
            'id'         => 'astcat-other',
            'company_id' => $otherCompanyId,
            'name'       => 'Vehicles',
            'requires_serial' => 0
        ];

        // Valid category in tenant passes
        $this->assertEquals($currentCompanyId, $validCategory['company_id']);

        // Category from another company fails validation
        $isValidTenantCategory = ($otherCompanyCategory['company_id'] === $currentCompanyId);
        $this->assertFalse($isValidTenantCategory, "Other company's category must be rejected.");

        // Non-existent category fails
        $categoryLookup = null;
        $this->assertNull($categoryLookup, "Non-existent category ID must be rejected.");
    }

    /**
     * Test Serial Number Requirement Enforcement
     */
    public function testSerialNumberRequirementEnforcement()
    {
        $serialCategory = [
            'id'              => 'astcat-serial',
            'name'            => 'Laptops',
            'requires_serial' => 1
        ];

        $nonSerialCategory = [
            'id'              => 'astcat-furn',
            'name'            => 'Furniture',
            'requires_serial' => 0
        ];

        $serialEmpty = '';
        $serialProvided = 'SN-2025-ABCD';

        // When requires_serial is 1 and serial_number is empty, validation must fail
        $isValid1 = !(!empty($serialCategory['requires_serial']) && empty($serialEmpty));
        $this->assertFalse($isValid1, "Serial number is mandatory when category has requires_serial = 1.");

        // When serial_number is provided, validation passes
        $isValid2 = !(!empty($serialCategory['requires_serial']) && empty($serialProvided));
        $this->assertTrue($isValid2, "Valid when serial number is provided.");

        // When requires_serial is 0, empty serial number is allowed
        $isValid3 = !(!empty($nonSerialCategory['requires_serial']) && empty($serialEmpty));
        $this->assertTrue($isValid3, "Allowed when category does not require serial number.");
    }

    /**
     * Test Default Categories Seeded by CompanyInitializationService
     */
    public function testDefaultSeedCategoriesList()
    {
        $expectedNames = [
            'Laptop',
            'Mobile',
            'Furniture',
            'Vehicle',
            'ID Card/Access',
            'Software License',
            'Other',
        ];

        $serviceClass = '\App\Services\CompanyInitializationService';
        $this->assertTrue(class_exists($serviceClass));

        $reflection = new \ReflectionClass($serviceClass);
        $this->assertTrue($reflection->hasMethod('initializeAssetCategories'), "Service must have initializeAssetCategories method.");

        // Verify count of default categories
        $this->assertCount(7, $expectedNames);
    }

    /**
     * Test Valid Condition Statuses: new, good, fair, poor, damaged, maintenance
     */
    public function testValidConditionStatuses()
    {
        $validStatuses = ['new', 'good', 'fair', 'poor', 'damaged', 'maintenance'];

        foreach ($validStatuses as $st) {
            $this->assertContains($st, $validStatuses);
        }

        // Test invalid conditions fail
        $invalidConditions = ['broken', 'unknown', 'discarded', 'used'];
        foreach ($invalidConditions as $inv) {
            $this->assertFalse(in_array($inv, $validStatuses, true));
        }
    }

    /**
     * Test Asset Code Uniqueness per Company (Compound Scope)
     */
    public function testAssetCodeUniquenessIsScopedPerCompany()
    {
        $existingAssets = [
            ['id' => 'ast-1', 'company_id' => 'comp-1', 'asset_code' => 'LAP-001'],
            ['id' => 'ast-2', 'company_id' => 'comp-2', 'asset_code' => 'LAP-001'],
        ];

        // Same asset_code in two different companies is ALLOWED
        $this->assertNotEquals($existingAssets[0]['company_id'], $existingAssets[1]['company_id']);
        $this->assertEquals($existingAssets[0]['asset_code'], $existingAssets[1]['asset_code']);

        // Same asset_code in same company is DUPLICATE and blocked
        $newAssetCode = 'LAP-001';
        $companyId = 'comp-1';

        $isDuplicateInCompany = false;
        foreach ($existingAssets as $a) {
            if ($a['company_id'] === $companyId && $a['asset_code'] === $newAssetCode) {
                $isDuplicateInCompany = true;
                break;
            }
        }
        $this->assertTrue($isDuplicateInCompany, "Duplicate asset code in same company must be blocked.");
    }

    /**
     * Test Nullable CompanyId in Model Methods for Software App Admin
     */
    public function testNullableCompanyIdInModelMethods()
    {
        $model = new \App\Models\AssetCategoryModel();

        $ref = new \ReflectionMethod($model, 'getCategories');
        $params = $ref->getParameters();
        $this->assertTrue($params[0]->allowsNull(), "getCategories first param companyId must allow null.");

        $refWithCount = new \ReflectionMethod($model, 'getCategoriesWithAssetCount');
        $paramsWithCount = $refWithCount->getParameters();
        $this->assertTrue($paramsWithCount[0]->allowsNull(), "getCategoriesWithAssetCount first param companyId must allow null.");

        $refFindInTenant = new \ReflectionMethod($model, 'findInTenant');
        $paramsFindInTenant = $refFindInTenant->getParameters();
        $this->assertTrue($paramsFindInTenant[1]->allowsNull(), "findInTenant companyId param must allow null.");

        $refHasAssets = new \ReflectionMethod($model, 'hasAssets');
        $paramsHasAssets = $refHasAssets->getParameters();
        $this->assertTrue($paramsHasAssets[1]->allowsNull(), "hasAssets companyId param must allow null.");
    }

    /**
     * Test Asset Cannot Be Registered As Assigned Without Active Assignee
     */
    public function testAssignedStatusRequiresValidAssignee()
    {
        $status = 'Assigned';
        $assignedToEmpty = '';
        $assignedToValid = 'emp-123';

        // Without assignee => invalid
        $canCreateWithoutAssignee = ($status !== 'Assigned' || !empty($assignedToEmpty));
        $this->assertFalse($canCreateWithoutAssignee, "Cannot create assigned asset with empty assignee.");

        // With assignee => valid
        $canCreateWithAssignee = ($status !== 'Assigned' || !empty($assignedToValid));
        $this->assertTrue($canCreateWithAssignee, "Can create assigned asset with valid assignee.");
    }

    /**
     * Test Soft Delete Configuration on AssetModel
     */
    public function testSoftDeleteConfiguredOnAssetModel()
    {
        $assetModel = new \App\Models\AssetModel();
        $ref = new \ReflectionClass($assetModel);

        $useSoftDeletes = $ref->getProperty('useSoftDeletes');
        $useSoftDeletes->setAccessible(true);
        $this->assertTrue($useSoftDeletes->getValue($assetModel), "AssetModel must enable soft deletes.");

        $deletedField = $ref->getProperty('deletedField');
        $deletedField->setAccessible(true);
        $this->assertEquals('deleted_at', $deletedField->getValue($assetModel));
    }

    /**
     * Test Asset Assignment Model Methods for Audit History
     */
    public function testAssetAssignmentModelStructure()
    {
        $assignmentModelClass = '\App\Models\AssetAssignmentModel';
        $this->assertTrue(class_exists($assignmentModelClass));

        $ref = new \ReflectionClass($assignmentModelClass);
        $this->assertTrue($ref->hasMethod('recordAssignment'), "Must have recordAssignment method.");
        $this->assertTrue($ref->hasMethod('recordReturn'), "Must have recordReturn method.");
        $this->assertTrue($ref->hasMethod('getActiveAssignment'), "Must have getActiveAssignment method.");
        $this->assertTrue($ref->hasMethod('getAssetHistory'), "Must have getAssetHistory method.");
        $this->assertTrue($ref->hasMethod('getEmployeeAssignments'), "Must have getEmployeeAssignments method.");
    }

    /**
     * Test Separation Clearance Blocked When Employee Holds Unreturned Assets
     */
    public function testSeparationBlockedWhenEmployeeHoldsAssets()
    {
        $unreturnedAssets = [
            ['id' => 'ast-101', 'asset_name' => 'MacBook Air M2', 'asset_code' => 'LAP-101', 'assigned_to' => 'emp-101', 'status' => 'Assigned', 'purchase_value' => 120000.00]
        ];

        $hasUnreturned = count($unreturnedAssets) > 0;
        $this->assertTrue($hasUnreturned, "Employee holds unreturned assets.");

        // Deduction calculation matches sum of purchase values
        $deduction = 0.0;
        foreach ($unreturnedAssets as $a) {
            $deduction += (float)$a['purchase_value'];
        }
        $this->assertEquals(120000.00, $deduction);
    }

    /**
     * Test AssetController Has WriteOff and History Action Endpoints
     */
    public function testAssetControllerActionMethods()
    {
        $ctrlClass = '\App\Controllers\Assets\AssetController';
        $this->assertTrue(class_exists($ctrlClass));

        $ref = new \ReflectionClass($ctrlClass);
        $this->assertTrue($ref->hasMethod('writeOff'), "AssetController must have writeOff method.");
        $this->assertTrue($ref->hasMethod('history'), "AssetController must have history method.");
        $this->assertTrue($ref->hasMethod('assign'), "AssetController must have assign method.");
        $this->assertTrue($ref->hasMethod('returnAsset'), "AssetController must have returnAsset method.");

        // Check controller constants
        $validStatuses = $ref->getConstant('VALID_STATUSES');
        $this->assertIsArray($validStatuses);
        $this->assertContains('Available', $validStatuses);
        $this->assertContains('Assigned', $validStatuses);
        $this->assertContains('Maintenance', $validStatuses);
        $this->assertContains('Written-Off', $validStatuses);

        $validConditions = $ref->getConstant('VALID_CONDITIONS');
        $this->assertIsArray($validConditions);
        $this->assertContains('new', $validConditions);
        $this->assertContains('good', $validConditions);
        $this->assertContains('fair', $validConditions);
        $this->assertContains('poor', $validConditions);
        $this->assertContains('damaged', $validConditions);
        $this->assertContains('maintenance', $validConditions);
    }

    /**
     * Test Straight-Line Depreciation Formula
     */
    public function testStraightLineDepreciationCalculation()
    {
        $purchaseValue = 100000.00;
        $usefulLifeYears = 4;
        
        // 2 years elapsed => 50% remaining book value
        $elapsedYears = 2.0;
        $factor = max(0.0, 1.0 - ($elapsedYears / $usefulLifeYears));
        $bookValue = round($purchaseValue * $factor, 2);
        $this->assertEquals(50000.00, $bookValue);

        // 5 years elapsed (> useful life) => 0 remaining book value
        $elapsedYearsOver = 5.0;
        $factorOver = max(0.0, 1.0 - ($elapsedYearsOver / $usefulLifeYears));
        $bookValueOver = round($purchaseValue * $factorOver, 2);
        $this->assertEquals(0.00, $bookValueOver);
    }

    /**
     * Test Cross-Tenant Assignment Prevention Even When Scoped Company Is Null
     */
    public function testCrossTenantAssignmentPrevention()
    {
        $asset = [
            'id' => 'ast-1',
            'company_id' => 'comp-mercury001',
            'status' => 'Available'
        ];

        $employeeOtherCompany = [
            'id' => 'emp-99',
            'company_id' => 'comp-jupiter002',
            'status' => 'active'
        ];

        // Fundamental check: asset company must match employee company
        $isCrossTenant = (!empty($asset['company_id']) && !empty($employeeOtherCompany['company_id']) && $asset['company_id'] !== $employeeOtherCompany['company_id']);
        $this->assertTrue($isCrossTenant, "Cross-company assignment must be detected and rejected.");
    }

    /**
     * Test Serial Number Requirement on Update
     */
    public function testSerialNumberMandatoryOnUpdateWhenCategoryRequiresSerial()
    {
        $categoryRequiresSerial = [
            'id' => 'cat-lpt',
            'name' => 'Laptops',
            'requires_serial' => 1
        ];

        $existingAsset = [
            'id' => 'ast-10',
            'serial_number' => 'SN-12345'
        ];

        // Update with empty serial number must be rejected
        $updatedSerialEmpty = '';
        $isUpdateValid = !(!empty($categoryRequiresSerial['requires_serial']) && empty($updatedSerialEmpty));
        $this->assertFalse($isUpdateValid, "Clearing serial number on category requiring serial must be blocked.");

        // Update with valid serial number must be allowed
        $updatedSerialValid = 'SN-99999';
        $isUpdateValid2 = !(!empty($categoryRequiresSerial['requires_serial']) && empty($updatedSerialValid));
        $this->assertTrue($isUpdateValid2, "Valid serial number on update must be accepted.");
    }

    /**
     * Test Purchase Value Redaction For Viewers Without Export/Manage Permissions
     */
    public function testPurchaseValueRedactionForStandardViewers()
    {
        $assets = [
            ['id' => 'ast-1', 'asset_name' => 'ThinkPad X1', 'purchase_value' => 150000.00],
            ['id' => 'ast-2', 'asset_name' => 'Dell Monitor', 'purchase_value' => 25000.00],
        ];

        $canExport = false;
        $canManage = false;

        // Apply redaction logic
        if (!$canExport && !$canManage) {
            foreach ($assets as &$a) {
                $a['purchase_value'] = null;
            }
            unset($a);
        }

        $this->assertNull($assets[0]['purchase_value'], "Purchase value must be redacted for standard viewers.");
        $this->assertNull($assets[1]['purchase_value'], "Purchase value must be redacted for standard viewers.");
    }

    /**
     * Test Non-Admin cannot override company_id via request params
     */
    public function testCompanyIdResolutionNonAdminVsAdmin()
    {
        $scopedCompanyId = 'comp-tenant-alpha';
        $requestedCompanyId = 'comp-tenant-bravo';

        // Non-admin resolution logic:
        $isAppAdminFalse = false;
        $resolvedNonAdmin = $isAppAdminFalse
            ? ($requestedCompanyId ?: $scopedCompanyId)
            : $scopedCompanyId;
        $this->assertEquals($scopedCompanyId, $resolvedNonAdmin, "Non-admin must ALWAYS receive scopedCompanyId, ignoring GET parameter.");

        // Software App Admin resolution logic:
        $isAppAdminTrue = true;
        $resolvedAdmin = $isAppAdminTrue
            ? ($requestedCompanyId ?: $scopedCompanyId)
            : $scopedCompanyId;
        $this->assertEquals($requestedCompanyId, $resolvedAdmin, "Software App Admin may select another organization via GET parameter.");
    }

    /**
     * Test Self-Only Visibility resolution logic
     */
    public function testResolveVisibilitySelfOnlyBehavior()
    {
        // Case 1: Standard Employee with only assets.view
        $perms1 = ['canAssign' => false, 'canExport' => false, 'canCreate' => false, 'canEdit' => false, 'canDelete' => false, 'canManage' => false];
        $isSelfOnly1 = (!$perms1['canAssign'] && !$perms1['canCreate'] && !$perms1['canEdit'] && !$perms1['canDelete'] && !$perms1['canManage'] && !$perms1['canExport']);
        $this->assertTrue($isSelfOnly1, "User with only assets.view must be classified as isSelfOnly = true.");

        // Case 2: User with assets.view and assets.export
        $perms2 = ['canAssign' => false, 'canExport' => true, 'canCreate' => false, 'canEdit' => false, 'canDelete' => false, 'canManage' => false];
        $isSelfOnly2 = (!$perms2['canAssign'] && !$perms2['canCreate'] && !$perms2['canEdit'] && !$perms2['canDelete'] && !$perms2['canManage'] && !$perms2['canExport']);
        $this->assertFalse($isSelfOnly2, "User with assets.export must not be isSelfOnly.");

        // Case 3: User with assets.assign
        $perms3 = ['canAssign' => true, 'canWriteOff' => false, 'canExport' => false, 'canCreate' => false, 'canEdit' => false, 'canDelete' => false, 'canManage' => false];
        $isSelfOnly3 = (!$perms3['canAssign'] && !$perms3['canWriteOff'] && !$perms3['canCreate'] && !$perms3['canEdit'] && !$perms3['canDelete'] && !$perms3['canManage'] && !$perms3['canExport']);
        $this->assertFalse($isSelfOnly3, "User with assets.assign must not be isSelfOnly.");

        // Case 4: User with assets.writeoff
        $perms4 = ['canAssign' => false, 'canWriteOff' => true, 'canExport' => false, 'canCreate' => false, 'canEdit' => false, 'canDelete' => false, 'canManage' => false];
        $isSelfOnly4 = (!$perms4['canAssign'] && !$perms4['canWriteOff'] && !$perms4['canCreate'] && !$perms4['canEdit'] && !$perms4['canDelete'] && !$perms4['canManage'] && !$perms4['canExport']);
        $this->assertFalse($isSelfOnly4, "User with assets.writeoff must not be isSelfOnly.");
    }

    /**
     * Test Self-Only User fails closed when employee record is absent
     */
    public function testSelfOnlyFailClosedWhenNoEmployeeId()
    {
        $isSelfOnly = true;
        $currentEmployeeId = null;

        // Assets list logic:
        if ($isSelfOnly) {
            $employees = []; // Must not load employee list
            if (empty($currentEmployeeId)) {
                $assets = []; // Fail closed: empty list
            } else {
                $assets = [['id' => 'ast-assigned-to-emp']];
            }
        } else {
            $employees = [['id' => 'emp-1'], ['id' => 'emp-2']];
            $assets = [['id' => 'ast-1'], ['id' => 'ast-2']];
        }

        $this->assertEmpty($employees, "Employee directory must never be sent to self-only viewers.");
        $this->assertEmpty($assets, "Self-only viewer without an employee record must receive an empty asset list (fail closed).");
    }

    /**
     * Test Asset History endpoint permissions: own vs other assets
     */
    public function testHistoryAccessControlForOwnVsOtherAssets()
    {
        $currentEmpId = 'emp-self-100';
        $otherEmpId   = 'emp-other-200';

        $assetOwn = [
            'id' => 'ast-laptop-1',
            'assigned_to' => $currentEmpId,
        ];

        $assetOther = [
            'id' => 'ast-laptop-2',
            'assigned_to' => $otherEmpId,
        ];

        // 1. Privileged users (canAssign = true) can view history of any asset
        $canAssign = true;
        $canViewAny = $canAssign;
        $this->assertTrue($canViewAny, "Privileged user can view any asset's history.");

        // 2. Self-only user with employee ID attempting to view own asset
        $canAssign = false;
        $canManage = false;
        $canExport = false;
        $hasPrivilegedAccess = ($canAssign || $canManage || $canExport);

        $isOwnAsset = ($assetOwn['assigned_to'] === $currentEmpId);
        $selfCanViewOwn = $hasPrivilegedAccess || $isOwnAsset;
        $this->assertTrue($selfCanViewOwn, "Self-only user can view history for equipment assigned to them.");

        // 3. Self-only user attempting to view someone else's asset
        $isOtherAsset = ($assetOther['assigned_to'] === $currentEmpId);
        $selfCanViewOther = $hasPrivilegedAccess || $isOtherAsset;
        $this->assertFalse($selfCanViewOther, "Self-only user CANNOT view custody history for someone else's asset (403 Forbidden).");
    }

    /**
     * Test Write-Off Safety: Duplicate rejection and reason validation
     */
    public function testWriteOffSafetyAndDuplicateRejection()
    {
        // 1. Duplicate write-off prohibited
        $existingWrittenOffAsset = [
            'id' => 'ast-written-off',
            'status' => 'Written-Off',
            'written_off_by_employee_id' => 'emp-culprit-001',
            'recovery_amount' => 50000.00
        ];

        $isDuplicateWriteOff = (strcasecmp($existingWrittenOffAsset['status'] ?? '', 'Written-Off') === 0);
        $this->assertTrue($isDuplicateWriteOff, "Duplicate write-off on an already Written-Off asset must be rejected.");

        // 2. Custodian preservation: never overwrite with null
        $custodian = !empty($existingWrittenOffAsset['assigned_to'])
            ? $existingWrittenOffAsset['assigned_to']
            : ($existingWrittenOffAsset['written_off_by_employee_id'] ?? null);
        $this->assertEquals('emp-culprit-001', $custodian, "Custodian must be preserved during subsequent inspection.");
    }

    /**
     * Test AssetWriteOffReasons classification and validation
     */
    public function testWriteOffReasonsClassificationAndValidation()
    {
        $liabilityReasons = \App\Libraries\AssetWriteOffReasons::LIABILITY;
        $nonLiabilityReasons = \App\Libraries\AssetWriteOffReasons::NON_LIABILITY;

        $this->assertContains('lost_by_employee', $liabilityReasons);
        $this->assertContains('damaged_by_employee', $liabilityReasons);

        $this->assertContains('damaged_beyond_repair', $nonLiabilityReasons);
        $this->assertContains('scrapped', $nonLiabilityReasons);
        $this->assertContains('stolen', $nonLiabilityReasons);

        // Validation helper checks
        $this->assertTrue(\App\Libraries\AssetWriteOffReasons::isValid('lost_by_employee'));
        $this->assertTrue(\App\Libraries\AssetWriteOffReasons::isValid('scrapped'));
        $this->assertFalse(\App\Libraries\AssetWriteOffReasons::isValid('invalid_unknown_reason'));
        $this->assertFalse(\App\Libraries\AssetWriteOffReasons::isValid(''));

        // Liability helper checks
        $this->assertTrue(\App\Libraries\AssetWriteOffReasons::isLiability('lost_by_employee'));
        $this->assertTrue(\App\Libraries\AssetWriteOffReasons::isLiability('damaged_by_employee'));
        $this->assertFalse(\App\Libraries\AssetWriteOffReasons::isLiability('scrapped'));
        $this->assertFalse(\App\Libraries\AssetWriteOffReasons::isLiability('stolen'));
    }

    /**
     * Test AssetDepreciation Library Straight-Line and Edge Cases
     */
    public function testAssetDepreciationLibraryCalculations()
    {
        $purchaseValue = 100000.00;
        $purchaseDate = '2023-01-01';
        $usefulLife = 4;

        // Exactly 2 years later: 50% remaining
        $asOf2Years = '2025-01-01';
        $bookVal2 = \App\Libraries\AssetDepreciation::bookValue($purchaseValue, $purchaseDate, $usefulLife, 'straight_line', $asOf2Years);
        $this->assertEquals(50027.38, $bookVal2); // 731 days / (4 * 365.25 = 1461) = 0.500342 * 100000 ~ 50027.38

        // Beyond useful life: book value reaches 0, never negative
        $asOf5Years = '2028-01-01';
        $bookVal5 = \App\Libraries\AssetDepreciation::bookValue($purchaseValue, $purchaseDate, $usefulLife, 'straight_line', $asOf5Years);
        $this->assertEquals(0.00, $bookVal5);

        // Method 'none': returns full purchase value regardless of elapsed time
        $bookValNone = \App\Libraries\AssetDepreciation::bookValue($purchaseValue, $purchaseDate, $usefulLife, 'none', $asOf2Years);
        $this->assertEquals(100000.00, $bookValNone);

        // Missing purchase date or life <= 0: returns full purchase value
        $bookValNoDate = \App\Libraries\AssetDepreciation::bookValue($purchaseValue, null, $usefulLife, 'straight_line', $asOf2Years);
        $this->assertEquals(100000.00, $bookValNoDate);

        // As-of date before purchase date: returns full purchase value
        $bookValBefore = \App\Libraries\AssetDepreciation::bookValue($purchaseValue, '2025-01-01', $usefulLife, 'straight_line', '2024-01-01');
        $this->assertEquals(100000.00, $bookValBefore);
    }

    /**
     * Test CSV Export Sanitization (Formula Injection Prevention)
     */
    public function testCsvExportFormulaInjectionSanitization()
    {
        $ctrl = new \App\Controllers\Assets\AssetController();
        $ref = new \ReflectionMethod($ctrl, 'sanitizeCsvField');
        $ref->setAccessible(true);

        $this->assertEquals("'=SUM(A1:A10)", $ref->invoke($ctrl, '=SUM(A1:A10)'));
        $this->assertEquals("'+123456", $ref->invoke($ctrl, '+123456'));
        $this->assertEquals("'-calc", $ref->invoke($ctrl, '-calc'));
        $this->assertEquals("'@cmd", $ref->invoke($ctrl, '@cmd'));
        $this->assertEquals("Standard Asset Name", $ref->invoke($ctrl, 'Standard Asset Name'));
        $this->assertEquals("", $ref->invoke($ctrl, null));
    }

    /**
     * Test Final Settlement Asset Liability Deductions and Recovery Linking
     * Assigned assets are excluded from settlement (guarded by EmployeeSeparationService).
     * Written-off liability assets charge only the remaining unrecovered amount (less payroll recovery).
     * Assets with zero recovery amount are not marked as settled.
     */
    public function testFinalSettlementAssetLiabilityDeductionAndCancellation()
    {
        $employeeId = 'emp-exit-001';

        // An employee with only returned assets and one liability write-off gets exactly the unrecovered amount deducted; nothing is double-charged.
        $rawAssets = [
            // Written-off with employee liability, partial recovery in monthly payroll (25000 target - 10000 recovered = 15000 remaining)
            [
                'id' => 'ast-2',
                'status' => 'Written-Off',
                'written_off_by_employee_id' => $employeeId,
                'written_off_reason' => 'lost_by_employee',
                'recovery_amount' => 25000.00,
                'recovery_recovered_amount' => 10000.00,
            ],
            // Written-off with liability but recovery_amount = 0 (decision: 0 charge, not marked as settled)
            [
                'id' => 'ast-zero',
                'status' => 'Written-Off',
                'written_off_by_employee_id' => $employeeId,
                'written_off_reason' => 'damaged_by_employee',
                'recovery_amount' => 0.00,
                'recovery_recovered_amount' => 0.00,
            ],
            // Written-off with liability, but ALREADY fully recovered through monthly payroll (12000 target, 12000 recovered)
            [
                'id' => 'ast-fully-recovered',
                'status' => 'Written-Off',
                'written_off_by_employee_id' => $employeeId,
                'written_off_reason' => 'lost_by_employee',
                'recovery_amount' => 12000.00,
                'recovery_recovered_amount' => 12000.00,
            ],
        ];

        $totalAssetDeduction = 0.0;
        $chargedAssetIds = [];
        $unreturnedAssets = [];

        foreach ($rawAssets as $ua) {
            $targetRecovery = (float)($ua['recovery_amount'] ?? 0.0);
            $alreadyCollected = (float)($ua['recovery_recovered_amount'] ?? 0.0);
            $remaining = max(0.0, round($targetRecovery - $alreadyCollected, 2));

            // Exclude already fully recovered or zero recovery assets
            if ($targetRecovery <= 0.0 || $remaining <= 0.0) {
                continue;
            }

            $ua['calculated_recovery_amount'] = $remaining;
            $totalAssetDeduction += $remaining;
            $unreturnedAssets[] = $ua;

            if (($ua['status'] ?? '') === 'Written-Off' && \App\Libraries\AssetWriteOffReasons::isLiability($ua['written_off_reason'] ?? '') && $remaining > 0.0) {
                $chargedAssetIds[] = $ua['id'];
            }
        }

        $this->assertEquals(15000.00, $totalAssetDeduction, "Total recovery deduction must charge only unrecovered remaining liability (25000 - 10000 = 15000).");
        $this->assertEquals(['ast-2'], $chargedAssetIds, "Only assets with positive remaining recovery must receive settlement linkage.");
        $this->assertCount(1, $unreturnedAssets);

        // Settlement cancellation: linked assets must have recovery_settlement_id cleared
        $settlementId = 'settle-uuid-123';
        $linkedAsset = [
            'id' => 'ast-2',
            'recovery_settlement_id' => $settlementId,
            'recovery_settled_at'    => '2026-10-20 12:00:00'
        ];

        // On cancel
        $linkedAsset['recovery_settlement_id'] = null;
        $linkedAsset['recovery_settled_at'] = null;

        $this->assertNull($linkedAsset['recovery_settlement_id'], "Cancelling settlement releases asset liability lock.");
        $this->assertNull($linkedAsset['recovery_settled_at']);
    }

    /**
     * Test Editing Saved Settlement Retains Already-Linked Asset Charges
     */
    public function testEditingSavedSettlementRetainsLinkedAssetCharges()
    {
        $currentSettlementId = 'settle-edit-001';
        $employeeId = 'emp-exit-001';

        $assetsInDb = [
            // Already linked to THIS settlement
            [
                'id' => 'ast-linked-this',
                'status' => 'Written-Off',
                'written_off_by_employee_id' => $employeeId,
                'written_off_reason' => 'lost_by_employee',
                'recovery_settlement_id' => $currentSettlementId,
                'recovery_amount' => 30000.00
            ],
            // Linked to ANOTHER settlement -> should be excluded
            [
                'id' => 'ast-linked-other',
                'status' => 'Written-Off',
                'written_off_by_employee_id' => $employeeId,
                'written_off_reason' => 'lost_by_employee',
                'recovery_settlement_id' => 'settle-other-999',
                'recovery_amount' => 15000.00
            ],
            // Unsettled liability -> should be included
            [
                'id' => 'ast-unsettled',
                'status' => 'Written-Off',
                'written_off_by_employee_id' => $employeeId,
                'written_off_reason' => 'lost_by_employee',
                'recovery_settlement_id' => null,
                'recovery_amount' => 10000.00
            ],
        ];

        // Filter matching the query in calculateSettlement:
        // (recovery_settlement_id IS NULL OR recovery_settlement_id = $currentSettlementId)
        $eligibleAssets = array_filter($assetsInDb, function ($a) use ($currentSettlementId) {
            return empty($a['recovery_settlement_id']) || $a['recovery_settlement_id'] === $currentSettlementId;
        });

        $this->assertCount(2, $eligibleAssets, "Editing settlement must retain assets linked to this settlement and include unlinked assets.");
        $eligibleIds = array_column(array_values($eligibleAssets), 'id');
        $this->assertContains('ast-linked-this', $eligibleIds);
        $this->assertContains('ast-unsettled', $eligibleIds);
        $this->assertNotContains('ast-linked-other', $eligibleIds);
    }

    /**
     * Test Unassigned Asset Liability Write-Off requires explicit employee
     * and NEVER falls back to innocent previous returned custodian
     */
    public function testWriteOffUnassignedAssetRequiresExplicitEmployeeForLiability()
    {
        $unassignedAsset = [
            'id' => 'ast-available-001',
            'status' => 'Available',
            'assigned_to' => null,
            'written_off_by_employee_id' => null,
        ];

        $previousReturnedCustodian = 'emp-innocent-999';
        $reason = 'lost_by_employee';
        $isLiability = \App\Libraries\AssetWriteOffReasons::isLiability($reason);
        $this->assertTrue($isLiability);

        // Case 1: No explicit employee provided for unassigned asset -> must be rejected
        $explicitEmpIdEmpty = null;
        $custodian = null;
        $hasError = false;
        if ($isLiability) {
            if (!empty($unassignedAsset['assigned_to'])) {
                $custodian = $unassignedAsset['assigned_to'];
            } elseif (!empty($explicitEmpIdEmpty)) {
                $custodian = $explicitEmpIdEmpty;
            } else {
                $hasError = true; // Must fail closed!
            }
        }
        $this->assertTrue($hasError, "Writing off an unassigned asset as lost_by_employee without explicit employee must fail.");
        $this->assertNull($custodian);

        // Case 2: Explicit employee provided -> accepts explicit employee
        $explicitEmpIdValid = 'emp-guilty-123';
        $custodian2 = null;
        if ($isLiability) {
            if (!empty($unassignedAsset['assigned_to'])) {
                $custodian2 = $unassignedAsset['assigned_to'];
            } elseif (!empty($explicitEmpIdValid)) {
                $custodian2 = $explicitEmpIdValid;
            }
        }
        $this->assertEquals('emp-guilty-123', $custodian2);
        $this->assertNotEquals($previousReturnedCustodian, $custodian2, "Previous returned custodian must NOT be charged.");
    }

    /**
     * Test Non-Liability Reasons (scrapped, stolen, damaged_beyond_repair) set null custodian
     */
    public function testWriteOffNonLiabilityReasonsSetNullCustodian()
    {
        $asset = [
            'id' => 'ast-scrapped-001',
            'status' => 'Available',
            'assigned_to' => null,
        ];

        $nonLiabilityReasons = ['scrapped', 'stolen', 'damaged_beyond_repair'];
        foreach ($nonLiabilityReasons as $reason) {
            $isLiability = \App\Libraries\AssetWriteOffReasons::isLiability($reason);
            $this->assertFalse($isLiability, "Reason {$reason} is a corporate loss, not employee liability.");

            $custodian = $isLiability ? 'emp-should-not-exist' : null;
            $this->assertNull($custodian, "Corporate loss must have null custodian liability.");
        }
    }

    /**
     * Test History endpoint allows users with Create, Edit, or Delete rights
     */
    public function testHistoryAllowsCreateEditDeletePrivilegedUsers()
    {
        // User with only assets.edit
        $editUserPerms = [
            'canAssign'  => false,
            'canExport'  => false,
            'canCreate'  => false,
            'canEdit'    => true,
            'canDelete'  => false,
            'canManage'  => false,
        ];
        $isSelfOnly = (!$editUserPerms['canAssign'] && !$editUserPerms['canCreate'] && !$editUserPerms['canEdit'] && !$editUserPerms['canDelete'] && !$editUserPerms['canManage'] && !$editUserPerms['canExport']);
        $this->assertFalse($isSelfOnly, "User with assets.edit is privileged and not isSelfOnly.");

        // In history():
        // If !isSelfOnly, access is granted without needing to be the assignee
        $canAccessHistory = !$isSelfOnly;
        $this->assertTrue($canAccessHistory, "User with assets.edit can view custody history for any asset in the tenant.");
    }

    /**
     * Test Production Error Handling when insert/update returns false
     */
    public function testProductionErrorHandlingWhenQueryReturnsFalse()
    {
        // When CI_ENVIRONMENT === 'production', insert failure returns false instead of throwing
        $insertResult = false;
        $dbError = ['code' => 1062, 'message' => "Duplicate entry 'AST-001' for key 'uq_company_assets_company_asset_code'"];

        $isDuplicate = (strpos($dbError['message'], 'Duplicate entry') !== false || ($dbError['code'] ?? 0) === 1062);
        $this->assertTrue($isDuplicate, "Duplicate key error must be detected when insert returns false.");

        $statusCode = ($insertResult === false && $isDuplicate) ? 422 : 200;
        $this->assertEquals(422, $statusCode, "Production duplicate key must return HTTP 422 instead of HTTP 200 success.");
    }

    /**
     * Test assets.writeoff permission configuration and authorization isolation
     */
    public function testAssetsWriteOffPermissionConfigurationAndIsolation()
    {
        $config = new \Config\Permissions();

        // 1. writeoff must be recognized as a canonical action verb
        $this->assertContains('writeoff', $config->canonicalActions, "'writeoff' must be registered in Permissions::\$canonicalActions whitelist.");

        // 2. assets.writeoff must exist in the catalogue
        $this->assertArrayHasKey('assets.writeoff', $config->catalogue, "'assets.writeoff' must be in Permissions::\$catalogue.");
        $def = $config->catalogue['assets.writeoff'];
        $this->assertEquals('assets', $def['module']);
        $this->assertEquals('writeoff', $def['action']);
        $this->assertEquals('Write Off Asset', $def['name']);

        // 3. hr_admin must have assets.writeoff in roleDefaultMatrix
        $this->assertArrayHasKey('hr_admin', $config->roleDefaultMatrix);
        $hrAdminPerms = $config->roleDefaultMatrix['hr_admin']['permissions'];
        $this->assertContains('assets.writeoff', $hrAdminPerms, "hr_admin role must be granted 'assets.writeoff'.");

        // 4. Authorization isolation: user with assets.assign but not assets.writeoff must fail check
        $assignOfficerPerms = ['assets.view', 'assets.create', 'assets.edit', 'assets.assign', 'assets.export'];
        $canAssign = in_array('assets.assign', $assignOfficerPerms, true);
        $canWriteOff = in_array('assets.writeoff', $assignOfficerPerms, true);

        $this->assertTrue($canAssign, "Officer has assets.assign.");
        $this->assertFalse($canWriteOff, "Officer does NOT have assets.writeoff, so Write-Off button is hidden and writeOff() endpoint is forbidden.");
    }

    /**
     * Test getAssetHistory self-only isolation and redaction logic
     */
    public function testGetAssetHistorySelfOnlyIsolationAndRedaction()
    {
        $allRecords = [
            [
                'id'            => 'asgn-01',
                'asset_id'      => 'ast-laptop-01',
                'employee_id'   => 'emp-other-01',
                'employee_name' => 'Alice Bob',
                'employee_code' => 'EMP-001',
                'assigned_date' => '2023-01-01',
                'returned_date' => '2023-06-01',
                'assigned_by'   => 'usr-admin-01',
                'returned_by'   => 'usr-admin-02',
                'notes'         => 'First custody',
            ],
            [
                'id'            => 'asgn-02',
                'asset_id'      => 'ast-laptop-01',
                'employee_id'   => 'emp-self-02',
                'employee_name' => 'Charlie Self',
                'employee_code' => 'EMP-002',
                'assigned_date' => '2023-06-02',
                'returned_date' => '2023-12-31',
                'assigned_by'   => 'usr-admin-01',
                'returned_by'   => 'usr-admin-03',
                'notes'         => 'Second custody',
            ],
            [
                'id'            => 'asgn-03',
                'asset_id'      => 'ast-laptop-01',
                'employee_id'   => 'emp-other-03',
                'employee_name' => 'Eve Other',
                'employee_code' => 'EMP-003',
                'assigned_date' => '2024-01-01',
                'returned_date' => null,
                'assigned_by'   => 'usr-admin-02',
                'returned_by'   => null,
                'notes'         => 'Third custody',
            ],
        ];

        // 1. Privileged users (null employeeId filter): returns all records with assigned_by and returned_by intact
        $privilegedHistory = $allRecords;
        $this->assertCount(3, $privilegedHistory);
        $this->assertEquals('usr-admin-01', $privilegedHistory[0]['assigned_by']);
        $this->assertEquals('Alice Bob', $privilegedHistory[0]['employee_name']);

        // 2. Self-only users (filtered by emp-self-02):
        $selfEmployeeId = 'emp-self-02';
        $selfHistory = array_values(array_filter($allRecords, function ($r) use ($selfEmployeeId) {
            return $r['employee_id'] === $selfEmployeeId;
        }));
        foreach ($selfHistory as &$rec) {
            unset($rec['assigned_by'], $rec['returned_by']);
        }
        unset($rec);

        // Assert self-only user sees only their own assignment record
        $this->assertCount(1, $selfHistory);
        $this->assertEquals($selfEmployeeId, $selfHistory[0]['employee_id']);
        $this->assertEquals('Charlie Self', $selfHistory[0]['employee_name']);
        $this->assertEquals('EMP-002', $selfHistory[0]['employee_code']);

        // Assert sensitive admin IDs (assigned_by, returned_by) are removed
        $this->assertArrayNotHasKey('assigned_by', $selfHistory[0]);
        $this->assertArrayNotHasKey('returned_by', $selfHistory[0]);

        // Assert other employees' records are not in the self-only list
        $employeeNames = array_column($selfHistory, 'employee_name');
        $this->assertNotContains('Alice Bob', $employeeNames);
        $this->assertNotContains('Eve Other', $employeeNames);
    }
}


