<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

/**
 * HTTP-level tests through the real router, filters and controllers.
 * Separate processes: owns the in-memory SQLite schema.
 */
#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobileApiFeatureTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;
    private array $device = ['device_uid' => 'dev-1', 'platform' => 'android'];

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);
    }

    private function loginAs(string $company, string $identifier): string
    {
        $res = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => $company, 'identifier' => $identifier, 'password' => self::PASSWORD, 'device' => $this->device,
        ]);
        $res->assertStatus(200);
        return json_decode($res->getJSON(), true)['data']['tokens']['access_token'];
    }

    public function testProtectedRoutesRejectMissingAndGarbageTokens(): void
    {
        foreach (['profile', 'auth/me', 'attendance/today', 'leaves/types', 'leaves/balances'] as $path) {
            $this->get("api/mobile/v1/{$path}")->assertStatus(401);
            $this->withHeaders(['Authorization' => 'Bearer mat_garbage'])->get("api/mobile/v1/{$path}")->assertStatus(401);
        }
        $this->withBodyFormat('json')->call('post', 'api/mobile/v1/leaves/apply', ['leave_type_id' => 'x'])->assertStatus(401);
    }

    public function testLoginDoesNotRequireCsrfAndWrongPasswordIs401(): void
    {
        $res = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => 'ACME', 'identifier' => 'rahim', 'password' => 'nope', 'device' => $this->device,
        ]);
        $res->assertStatus(401);
    }

    public function testApiV1LoginDoesNotRequireCsrfAndWrongPasswordIs401(): void
    {
        $res = $this->withBodyFormat('json')->call('post', 'api/v1/auth/login', [
            'company_code' => 'ACME', 'identifier' => 'rahim', 'password' => 'nope', 'device' => $this->device,
        ]);
        $this->assertNotSame(403, $res->response()->getStatusCode(), 'POST api/v1/auth/login without CSRF token must not return 403');
        $res->assertStatus(401);
    }

    public function testMeAndProfileAreHydratedFromTokenNotFromClientInput(): void
    {
        $token = $this->loginAs('ACME', 'rahim');

        $me = json_decode($this->withHeaders(['Authorization' => "Bearer {$token}"])->get('api/mobile/v1/auth/me')->getJSON(), true);
        $this->assertSame('c-1', $me['data']['company_id']);
        $this->assertSame('e-1', $me['data']['employee_id']);

        // A spoofed employee_id in the query string must be ignored.
        $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])->get('api/mobile/v1/profile?employee_id=e-2&company_id=c-2');
        $res->assertStatus(200);
        $p = json_decode($res->getJSON(), true)['data'];
        $this->assertSame('Rahim', $p['profile']['first_name']);
        $this->assertSame('EMP-001', $p['profile']['employee_code']);
        $this->assertSame('ACME', $p['company']['code']);
        $this->assertArrayNotHasKey('basic_salary', $p['profile']);
        $this->assertArrayNotHasKey('gross_salary', $p['profile']);
    }

    public function testTwoTenantsSeeOnlyTheirOwnProfile(): void
    {
        $a = $this->loginAs('ACME', 'rahim');
        $b = $this->loginAs('OTHER', 'karim');
        $pa = json_decode($this->withHeaders(['Authorization' => "Bearer {$a}"])->get('api/mobile/v1/profile')->getJSON(), true);
        $pb = json_decode($this->withHeaders(['Authorization' => "Bearer {$b}"])->get('api/mobile/v1/profile')->getJSON(), true);
        $this->assertSame('Rahim', $pa['data']['profile']['first_name']);
        $this->assertSame('Karim', $pb['data']['profile']['first_name']);
    }

    public function testMobileResponsesNeverSetSessionCookies(): void
    {
        $token = $this->loginAs('ACME', 'rahim');
        $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])->get('api/mobile/v1/profile');
        $this->assertFalse($res->response()->hasHeader('Set-Cookie'));
    }

    public function testLogoutInvalidatesTheToken(): void
    {
        $token = $this->loginAs('ACME', 'rahim');
        $this->withHeaders(['Authorization' => "Bearer {$token}"])->call('post', 'api/mobile/v1/auth/logout')->assertStatus(200);
        $this->withHeaders(['Authorization' => "Bearer {$token}"])->get('api/mobile/v1/profile')->assertStatus(401);
    }

    public function testMustChangePasswordBlocksEverythingButMeAndLogout(): void
    {
        $this->db->table('users')->where('id', 'u-1')->update(['must_change_password' => 1]);
        $token = $this->loginAs('ACME', 'rahim');
        $h = ['Authorization' => "Bearer {$token}"];
        $this->withHeaders($h)->get('api/mobile/v1/profile')->assertStatus(403);
        $this->withHeaders($h)->get('api/mobile/v1/auth/me')->assertStatus(200);
    }

    public function testAuditorCannotMutate(): void
    {
        $this->db->table('roles')->insert(['id' => 'r-aud', 'code' => 'auditor', 'name' => 'Auditor', 'status' => 'active']);
        $this->db->table('users')->where('id', 'u-1')->update(['role_id' => 'r-aud']);
        $token = $this->loginAs('ACME', 'rahim');
        $h = ['Authorization' => "Bearer {$token}"];
        $this->withHeaders($h)->get('api/mobile/v1/profile')->assertStatus(200);
        $this->withHeaders($h)->withBodyFormat('json')->call('post', 'api/mobile/v1/leaves/apply', ['leave_type_id' => 'x'])->assertStatus(403);
    }
}
