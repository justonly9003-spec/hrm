<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class LeaveServiceTest extends TestCase
{
    public function testSandwichRuleCalculation()
    {
        // If Friday & Saturday are weekends, and leave is taken on Thursday and Sunday, sandwich rule counts weekend days as leave
        $isSandwichEnabled = true;
        $requestedDays = 2; // Thursday and Sunday
        $interveningWeekendDays = 2; // Fri, Sat

        $totalLeaveDeduction = $isSandwichEnabled ? ($requestedDays + $interveningWeekendDays) : $requestedDays;
        $this->assertEquals(4, $totalLeaveDeduction, "Sandwich rule adds intervening holidays to total leave deducted.");
    }

    public function testLeavePrivacySanitizationForPeers()
    {
        $sensitiveLeaveRecord = [
            'employee_name' => 'John Doe',
            'department_id' => 'DEPT-01',
            'leave_type'    => 'Medical Leave',
            'reason'        => 'Undergoing minor spinal surgery and hospital recovery.',
            'attachment'    => 'doctor_diagnosis_confidential.pdf'
        ];

        // When viewer is general colleague in another department without HR privileges
        $isHrOrManager = false;

        $sanitizedRecord = $sensitiveLeaveRecord;
        if (!$isHrOrManager) {
            $sanitizedRecord['reason'] = 'Out of Office (Scheduled Leave)';
            $sanitizedRecord['attachment'] = null;
        }

        $this->assertEquals('Out of Office (Scheduled Leave)', $sanitizedRecord['reason']);
        $this->assertNull($sanitizedRecord['attachment']);
    }

    public function testWeekendTreatmentParity()
    {
        // 2 working days (Thursday, Sunday) + 2 weekend days (Friday, Saturday)
        $workingDays = 2;
        $weekendDays = 2;

        // When weekendTreatment = 'Count weekly off as leave'
        $countAsLeaveTotal = $workingDays + $weekendDays;
        $this->assertEquals(4, $countAsLeaveTotal, "Counting weekly off as leave includes all weekend days regardless of sandwich");

        // When weekendTreatment = 'Exclude weekly off' without sandwich
        $excludeWithoutSandwich = $workingDays;
        $this->assertEquals(2, $excludeWithoutSandwich, "Excluding weekly off deducts only working days when sandwich does not apply");
    }

    public function testUnpaidDeductionFormulaParity()
    {
        $basic = 30000.0;
        $gross = 45000.0;
        $unpaidDays = 3.0;

        // 1. Gross / 26
        $gross26Deduction = round(($gross / 26.0) * $unpaidDays);
        $this->assertEquals(5192.0, $gross26Deduction);

        // 2. Basic / 26
        $basic26Deduction = round(($basic / 26.0) * $unpaidDays);
        $this->assertEquals(3462.0, $basic26Deduction);

        // 3. Calendar Days (30) / Gross / 30
        $gross30Deduction = round(($gross / 30.0) * $unpaidDays);
        $this->assertEquals(4500.0, $gross30Deduction);
    }

    public function testEncashmentSalaryBasisParity()
    {
        $basic = 30000.0;
        $gross = 45000.0;
        $encashDays = 5.0;

        // 1. Gross Salary (Gross / 30)
        $grossAmt = round(($gross / 30.0) * $encashDays);
        $this->assertEquals(7500.0, $grossAmt);

        // 2. Daily Salary (Gross / 26)
        $dailyAmt = round(($gross / 26.0) * $encashDays);
        $this->assertEquals(8654.0, $dailyAmt);

        // 3. Fixed Rate (1500 per day)
        $fixedAmt = round($encashDays * 1500.0);
        $this->assertEquals(7500.0, $fixedAmt);

        // 4. Basic Salary (Basic / 30)
        $basicAmt = round(($basic / 30.0) * $encashDays);
        $this->assertEquals(5000.0, $basicAmt);
    }

    public function testMatchLeaveTypeCodeMatchesDirectAndAliases()
    {
        // Direct exact match
        $this->assertTrue(\App\Services\LeaveService::matchLeaveTypeCode('SL', 'SL'));
        $this->assertTrue(\App\Services\LeaveService::matchLeaveTypeCode('AL', 'AL'));

        // Case insensitivity
        $this->assertTrue(\App\Services\LeaveService::matchLeaveTypeCode('sl', 'SL'));

        // Standard alias mappings for Sick Leave
        $this->assertTrue(\App\Services\LeaveService::matchLeaveTypeCode('SL', 'SICK'));
        $this->assertTrue(\App\Services\LeaveService::matchLeaveTypeCode('SICK', 'SL'));
        $this->assertTrue(\App\Services\LeaveService::matchLeaveTypeCode('SL', 'MEDICAL'));
        $this->assertTrue(\App\Services\LeaveService::matchLeaveTypeCode('SL', 'SICK LEAVE'));
        $this->assertTrue(\App\Services\LeaveService::matchLeaveTypeCode('SL', 'SICK / MEDICAL LEAVE'));

        // Alias matching with type name
        $this->assertTrue(\App\Services\LeaveService::matchLeaveTypeCode('SL', 'LV', 'Sick / Medical Leave'));
        $this->assertTrue(\App\Services\LeaveService::matchLeaveTypeCode('SL', '', 'Sick Leave'));

        // Annual leave aliases
        $this->assertTrue(\App\Services\LeaveService::matchLeaveTypeCode('AL', 'ANNUAL'));
        $this->assertTrue(\App\Services\LeaveService::matchLeaveTypeCode('ANNUAL', 'AL'));

        // Negative cases
        $this->assertFalse(\App\Services\LeaveService::matchLeaveTypeCode('SL', 'CL'));
        $this->assertFalse(\App\Services\LeaveService::matchLeaveTypeCode('AL', 'SL'));
        $this->assertFalse(\App\Services\LeaveService::matchLeaveTypeCode('', ''));

        // Custom codes must NOT over-match with standard leave aliases
        $this->assertFalse(\App\Services\LeaveService::matchLeaveTypeCode('SPL', 'SL', 'Sick Leave'));
        $this->assertFalse(\App\Services\LeaveService::matchLeaveTypeCode('SPECIAL_LEAVE', 'CL', 'Casual Leave'));
        $this->assertFalse(\App\Services\LeaveService::matchLeaveTypeCode('COMP_OFF', 'AL', 'Annual Leave'));
        $this->assertFalse(\App\Services\LeaveService::matchLeaveTypeCode('BEREAVEMENT', 'EL', 'Earned Leave'));
    }

    public function testUpdateLeaveScheduleChangeClassification()
    {
        $app = [
            'from_date'     => '2026-09-01',
            'to_date'       => '2026-09-03',
            'leave_type_id' => 'lt-annual-01',
            'is_half_day'   => 0,
            'reason'        => 'Family visit'
        ];

        // Case 1: Reason-only edit (no date, type, or half-day change)
        $dataReasonOnly = [
            'from_date'     => '2026-09-01',
            'to_date'       => '2026-09-03',
            'leave_type_id' => 'lt-annual-01',
            'is_half_day'   => 0,
            'reason'        => 'Updated emergency reason'
        ];
        $datesChanged = ($dataReasonOnly['from_date'] !== $app['from_date'] || $dataReasonOnly['to_date'] !== $app['to_date']);
        $typeChanged = ($dataReasonOnly['leave_type_id'] !== $app['leave_type_id']);
        $halfDayChanged = ((bool)$dataReasonOnly['is_half_day'] !== (bool)$app['is_half_day']);
        $scheduleChanged = ($datesChanged || $typeChanged || $halfDayChanged);

        $this->assertFalse($scheduleChanged, "Reason-only edit must not be flagged as schedule change.");
        $this->assertFalse($datesChanged, "Dates did not change.");
        $this->assertFalse($typeChanged, "Type did not change.");

        // Case 2: Date change
        $dataDateChange = [
            'from_date'     => '2026-09-02',
            'to_date'       => '2026-09-04',
            'leave_type_id' => 'lt-annual-01',
            'is_half_day'   => 0
        ];
        $datesChanged2 = ($dataDateChange['from_date'] !== $app['from_date'] || $dataDateChange['to_date'] !== $app['to_date']);
        $scheduleChanged2 = ($datesChanged2 || ($dataDateChange['leave_type_id'] !== $app['leave_type_id']) || ((bool)$dataDateChange['is_half_day'] !== (bool)$app['is_half_day']));
        $this->assertTrue($scheduleChanged2, "Changing dates must trigger schedule change.");
        $this->assertTrue($datesChanged2);

        // Case 3: Leave type change
        $dataTypeChange = [
            'from_date'     => '2026-09-01',
            'to_date'       => '2026-09-03',
            'leave_type_id' => 'lt-sick-01',
            'is_half_day'   => 0
        ];
        $typeChanged3 = ($dataTypeChange['leave_type_id'] !== $app['leave_type_id']);
        $scheduleChanged3 = ($typeChanged3 || false);
        $this->assertTrue($scheduleChanged3, "Changing leave type must trigger schedule change.");
    }

    public function testRuleNotConfiguredExceptionGracefulHandling()
    {
        $ex = new \App\Services\Rules\RuleNotConfiguredException("Missing leave rule definition", "comp-1", "LEAVE", "2026-10-11");
        $handledResponse = [
            'success' => false,
            'message' => 'Leave rules are not configured for this organization: ' . $ex->getMessage()
        ];

        $this->assertFalse($handledResponse['success']);
        $this->assertStringContainsString("Missing leave rule definition", $handledResponse['message']);
    }

    public function testPaidUnpaidSplitCalculationWhenBalanceInsufficient()
    {
        // 5 days requested, 3 days available paid balance, no negative balance permitted
        $requestedDays = 5.0;
        $availableBalance = 3.0;
        $allowNegative = false;

        $paidDays = max(0.0, min($availableBalance, $requestedDays));
        $unpaidDays = round($requestedDays - $paidDays, 2);

        $this->assertEquals(3.0, $paidDays, "Paid portion must equal available paid balance.");
        $this->assertEquals(2.0, $unpaidDays, "Unpaid portion must absorb remainder of the requested leave.");
        $this->assertEquals(5.0, $paidDays + $unpaidDays, "Total duration must match requested days.");
    }

    public function testMultiTierApprovalPolicyRequiresManagerEndorsementBeforeHrApproval()
    {
        $workflow = [
            'workflow_type' => 'Multi-Tier',
            'tier_conditions' => [
                ['min_days' => 1, 'max_days' => 2, 'required_approvers' => ['Manager']],
                ['min_days' => 3, 'max_days' => 7, 'required_approvers' => ['Manager', 'HR Admin']],
            ],
        ];

        // 5-day application requires both Manager and HR Admin
        $applicationDays = 5.0;
        $requiresManagerTier = false;
        foreach ($workflow['tier_conditions'] as $tc) {
            if ($applicationDays >= $tc['min_days'] && $applicationDays <= $tc['max_days']) {
                if (in_array('Manager', $tc['required_approvers']) && in_array('HR Admin', $tc['required_approvers'])) {
                    $requiresManagerTier = true;
                }
                break;
            }
        }
        $this->assertTrue($requiresManagerTier, "5-day leave must require Tier 1 Manager endorsement before HR approval.");

        // If manager status is Pending and approver is not a root admin, approval must be blocked
        $managerStatus = 'Pending';
        $isOverrideAdmin = false;
        $isBlocked = ($requiresManagerTier && !$isOverrideAdmin && $managerStatus !== 'Approved');
        $this->assertTrue($isBlocked, "Approval without prior manager endorsement must be blocked under multi-tier policy.");

        // Once manager endorses, approval is unblocked
        $managerStatus = 'Approved';
        $isBlockedAfterEndorsement = ($requiresManagerTier && !$isOverrideAdmin && $managerStatus !== 'Approved');
        $this->assertFalse($isBlockedAfterEndorsement, "Approval must proceed after manager endorsement.");
    }

    public function testLeaveApplicationServiceClassLoadsWithoutSyntaxError()
    {
        $filePath = dirname(__DIR__, 2) . '/app/Services/Leave/LeaveApplicationService.php';
        $this->assertFileExists($filePath);

        // Verify class can be autoloaded or loaded without parse error
        require_once $filePath;
        $this->assertTrue(class_exists(\App\Services\Leave\LeaveApplicationService::class), "LeaveApplicationService must exist and load cleanly without parse errors.");
    }

    public function testLeaveApprovalStepsTransitionLifecycle()
    {
        // Simulate step status progression from Pending -> Endorsed/Approved
        $steps = [
            ['id' => 'step-1', 'step_order' => 1, 'approver_role' => 'Line Manager', 'status' => 'Pending'],
            ['id' => 'step-2', 'step_order' => 2, 'approver_role' => 'HR Administration', 'status' => 'Pending'],
        ];

        // 1. Manager endorses: Step 1 becomes Approved
        $steps[0]['status'] = 'Approved';
        $steps[0]['acted_at'] = '2026-10-13 10:00:00';
        $this->assertEquals('Approved', $steps[0]['status']);
        $this->assertEquals('Pending', $steps[1]['status']);

        // 2. HR approves: Step 2 becomes Approved
        $steps[1]['status'] = 'Approved';
        $steps[1]['acted_at'] = '2026-10-13 11:00:00';
        $this->assertEquals('Approved', $steps[1]['status']);

        // 3. In case of rejection at Step 1, all pending steps become Rejected
        $stepsRejection = [
            ['id' => 'step-1', 'step_order' => 1, 'status' => 'Pending'],
            ['id' => 'step-2', 'step_order' => 2, 'status' => 'Pending'],
        ];
        $stepsRejection[0]['status'] = 'Rejected';
        $stepsRejection[1]['status'] = 'Rejected';
        $this->assertEquals('Rejected', $stepsRejection[0]['status']);
        $this->assertEquals('Rejected', $stepsRejection[1]['status']);
    }

    public function testCompoundIdempotencyKeyUniquenessPerTenant()
    {
        // Uniqueness must be evaluated on (company_id, idempotency_key)
        $tx1 = ['company_id' => 'comp-01', 'idempotency_key' => 'tx-key-100'];
        $tx2 = ['company_id' => 'comp-02', 'idempotency_key' => 'tx-key-100'];

        $key1 = "{$tx1['company_id']}:{$tx1['idempotency_key']}";
        $key2 = "{$tx2['company_id']}:{$tx2['idempotency_key']}";

        $this->assertNotEquals($key1, $key2, "Idempotency key uniqueness must be compound with company_id to allow cross-tenant isolation.");
    }

    public function testLeaveServiceDelegatesApplicationMethodsToLeaveApplicationServiceRealCalls()
    {
        $leaveService = new \App\Services\LeaveService();

        // 1. applyLeave delegation
        $applyRes = $leaveService->applyLeave([]);
        $this->assertIsArray($applyRes);
        $this->assertFalse($applyRes['success']);
        $this->assertEquals('Employee ID is required.', $applyRes['message']);

        // 2. endorseLeave delegation
        $endorseRes = $leaveService->endorseLeave('', 'manager-1');
        $this->assertIsArray($endorseRes);
        $this->assertFalse($endorseRes['success']);
        $this->assertEquals('Application ID is required.', $endorseRes['message']);

        // 3. approveLeave delegation
        $approveRes = $leaveService->approveLeave('', 'approver-1');
        $this->assertIsArray($approveRes);
        $this->assertFalse($approveRes['success']);
        $this->assertEquals('Application ID is required.', $approveRes['message']);

        // 4. rejectLeave delegation
        $rejectRes = $leaveService->rejectLeave('', 'approver-1', 'Reason');
        $this->assertIsArray($rejectRes);
        $this->assertFalse($rejectRes['success']);
        $this->assertEquals('Application ID is required.', $rejectRes['message']);

        // 5. cancelLeave delegation
        $cancelRes = $leaveService->cancelLeave('', 'user-1');
        $this->assertIsArray($cancelRes);
        $this->assertFalse($cancelRes['success']);
        $this->assertEquals('Application ID is required.', $cancelRes['message']);

        // 6. batchApprove delegation
        $batchApproveRes = $leaveService->batchApprove([], 'approver-1');
        $this->assertIsArray($batchApproveRes);
        $this->assertFalse($batchApproveRes['success']);
        $this->assertEquals('No application IDs provided for batch approval.', $batchApproveRes['message']);

        // 7. batchReject delegation
        $batchRejectRes = $leaveService->batchReject([], 'approver-1', 'Reason');
        $this->assertIsArray($batchRejectRes);
        $this->assertFalse($batchRejectRes['success']);
        $this->assertEquals('No application IDs provided for batch rejection.', $batchRejectRes['message']);

        // 8. reopenYear delegation
        $reopenRes = $leaveService->reopenYear(2025, 'comp-test', 'admin', '   ');
        $this->assertIsArray($reopenRes);
        $this->assertFalse($reopenRes['success']);
        $this->assertEquals('Mandatory reason is required to reopen a closed leave year.', $reopenRes['message']);
    }

    public function testLeaveRolloverServiceRequiresMandatoryReasonOnReopen()
    {
        $rolloverService = new \App\Services\Leave\LeaveRolloverService();

        // Empty reason must immediately fail closed without database mutation
        $resEmpty = $rolloverService->reopenYear(2025, 'comp-test', 'admin-01', '');
        $this->assertFalse($resEmpty['success']);
        $this->assertEquals('Mandatory reason is required to reopen a closed leave year.', $resEmpty['message']);

        // Whitespace-only reason must be trimmed and rejected
        $resWhitespace = $rolloverService->reopenYear(2025, 'comp-test', 'admin-01', "   \t\n  ");
        $this->assertFalse($resWhitespace['success']);
        $this->assertEquals('Mandatory reason is required to reopen a closed leave year.', $resWhitespace['message']);
    }

    public function testPermissionsConfigCatalogueAndRoleMatrixEnforcesStrictReopenAccess()
    {
        $permissions = new \Config\Permissions();

        // Verify catalogue declarations
        $this->assertArrayHasKey('leave.closing_reopen', $permissions->permissionsCatalogue);
        $this->assertArrayHasKey('leaves.closing_reopen', $permissions->permissionsCatalogue);

        // Verify roleDefaultMatrix: hr_admin has closing_reopen
        $hrAdminPerms = $permissions->roleDefaultMatrix['hr_admin']['permissions'] ?? [];
        $this->assertTrue(in_array('leaves.closing_reopen', $hrAdminPerms, true), "hr_admin must have leaves.closing_reopen in matrix.");
        $this->assertTrue(in_array('leave.closing_reopen', $hrAdminPerms, true), "hr_admin must have leave.closing_reopen alias in matrix.");

        // Verify other roles do NOT have closing_reopen
        $disallowedRoles = ['hr_officer', 'branch_manager', 'finance'];
        foreach ($disallowedRoles as $role) {
            $rolePerms = $permissions->roleDefaultMatrix[$role]['permissions'] ?? [];
            $this->assertFalse(
                in_array('leaves.closing_reopen', $rolePerms, true),
                "Role '{$role}' must NOT possess leaves.closing_reopen permission."
            );
            $this->assertFalse(
                in_array('leave.closing_reopen', $rolePerms, true),
                "Role '{$role}' must NOT possess leave.closing_reopen permission."
            );
        }

        // Verify generic leave.manage or leaves.manage is completely distinct from closing_reopen
        $this->assertNotEquals('leave.manage', 'leave.closing_reopen');
        $this->assertNotEquals('leaves.manage', 'leaves.closing_reopen');
    }

    public function testPermissionsConfigOverrideTierPermissionRules()
    {
        $permissions = new \Config\Permissions();

        // 1. Verify catalogue declarations
        $this->assertArrayHasKey('leave.override_tier', $permissions->permissionsCatalogue);
        $this->assertArrayHasKey('leaves.override_tier', $permissions->permissionsCatalogue);

        // 2. Verify canonicalActions whitelist contains override_tier and closing_reopen
        $this->assertTrue(in_array('override_tier', $permissions->canonicalActions, true), "'override_tier' must be in canonicalActions whitelist.");
        $this->assertTrue(in_array('closing_reopen', $permissions->canonicalActions, true), "'closing_reopen' must be in canonicalActions whitelist.");

        // 3. Verify HR Admin and standard operational roles do NOT possess override_tier by default
        $restrictedRoles = ['hr_admin', 'hr_officer', 'branch_manager', 'finance', 'manager', 'team_leader', 'employee', 'auditor'];
        foreach ($restrictedRoles as $role) {
            $rolePerms = $permissions->roleDefaultMatrix[$role]['permissions'] ?? [];
            $this->assertFalse(
                in_array('leave.override_tier', $rolePerms, true),
                "Role '{$role}' must NOT possess leave.override_tier by default."
            );
            $this->assertFalse(
                in_array('leaves.override_tier', $rolePerms, true),
                "Role '{$role}' must NOT possess leaves.override_tier by default."
            );
        }
    }

    /**
     * Requirement 1: Per-type sandwich_rule: false must switch sandwich OFF even when company sandwich is enabled.
     */
    public function testPerTypeSandwichRuleFalseSwitchesOffSandwichEvenWhenCompanyEnabled()
    {
        $leaveService = new \App\Services\LeaveService();
        $employee = ['id' => 'emp-01', 'company_id' => 'comp-01'];

        // Annual leave seed: sandwich_rule = false, is_paid = true
        $ruleEntAnnual = [
            'leave_type_code' => 'AL',
            'sandwich_rule'   => false,
            'is_paid'         => true,
        ];

        // Even with company sandwich enabled, AL must NOT have sandwich active
        $result = $leaveService->isSandwichEnabled('comp-01', $employee, $ruleEntAnnual, '2026-10-01', true);
        $this->assertFalse($result, "Per-type sandwich_rule: false must switch sandwich OFF even when company sandwich is enabled.");

        $appService = new \App\Services\Leave\LeaveApplicationService($leaveService);
        $appResult = $appService->isSandwichEnabled('comp-01', $employee, $ruleEntAnnual, '2026-10-01', true);
        $this->assertFalse($appResult, "LeaveApplicationService::isSandwichEnabled must also return false when per-type sandwich_rule is false.");
    }

    /**
     * Requirement 4: applies_to_paid_only: If applies_to_paid_only is true, unpaid leave types must NOT trigger sandwich.
     */
    public function testAppliesToPaidOnlyEnforcesSandwichDisabledForUnpaidLeave()
    {
        $leaveService = new \App\Services\LeaveService();
        $employee = ['id' => 'emp-01', 'company_id' => 'comp-01'];

        // Unpaid leave entitlement with sandwich_rule true
        $ruleEntUnpaid = [
            'leave_type_code' => 'UL',
            'sandwich_rule'   => true,
            'is_paid'         => false,
        ];

        // When is_paid = false, sandwich must be disabled
        $result = $leaveService->isSandwichEnabled('comp-01', $employee, $ruleEntUnpaid, '2026-10-01', false);
        $this->assertFalse($result, "Unpaid leave type must not have sandwich enabled when applies_to_paid_only is true.");
    }

    /**
     * Requirement 4: weekend_treatment: 'Exclude weekly off' vs 'Include if sandwiched'.
     */
    public function testWeekendTreatmentExcludeWeeklyOffDoesNotDeductInterveningWeekends()
    {
        $leaveService = new \App\Services\LeaveService();
        $employeeId = 'emp-01';

        // Thursday (2026-10-08) to Sunday (2026-10-11)
        // Friday & Saturday are weekends (2 weekend days, 2 working days)
        $fromDate = '2026-10-08';
        $toDate = '2026-10-11';

        $policyExclude = [
            'calendarTreatment' => [
                'enabled'                => true,
                'weekend_treatment'      => 'Exclude weekly off',
                'holiday_treatment'      => 'Exclude holidays',
                'treat_weekend_as_leave' => false,
                'treat_holiday_as_leave' => false,
                'bridge_leave_enabled'   => true,
                'bridge_leave_action'    => 'Count intervening days',
                'applies_to_paid_only'   => true
            ]
        ];

        $calc = $leaveService->calculateLeaveDays($employeeId, $fromDate, $toDate, false, true, $policyExclude, true);

        // Working days: Thursday, Sunday = 2.0
        // Intervening weekends (Fri, Sat) must be EXCLUDED because weekend_treatment is 'Exclude weekly off'
        $this->assertEquals(2.0, $calc['chargeable_days'], "Intervening weekends must be excluded when weekend_treatment is 'Exclude weekly off'.");
        $this->assertEquals(0, $calc['bridge_days_added']);
        $this->assertFalse($calc['sandwich_applies']);
    }

    /**
     * Requirement 4: When 'Include if sandwiched', intervening weekends ARE deducted (+2 days).
     */
    public function testWeekendTreatmentIncludeIfSandwichedDeductsInterveningWeekends()
    {
        $leaveService = new \App\Services\LeaveService();
        $employeeId = 'emp-01';

        // Thursday (2026-10-08) to Sunday (2026-10-11)
        $fromDate = '2026-10-08';
        $toDate = '2026-10-11';

        $policyInclude = [
            'calendarTreatment' => [
                'enabled'                => true,
                'weekend_treatment'      => 'Include if sandwiched',
                'holiday_treatment'      => 'Exclude holidays',
                'treat_weekend_as_leave' => true,
                'treat_holiday_as_leave' => false,
                'bridge_leave_enabled'   => true,
                'bridge_leave_action'    => 'Count intervening days',
                'applies_to_paid_only'   => true
            ]
        ];

        $calc = $leaveService->calculateLeaveDays($employeeId, $fromDate, $toDate, false, true, $policyInclude, true);

        // Working days (2) + intervening weekends (2) = 4.0 days
        $this->assertEquals(4.0, $calc['chargeable_days'], "Intervening weekends must be deducted when weekend_treatment is 'Include if sandwiched'.");
        $this->assertEquals(2, $calc['bridge_days_added']);
        $this->assertTrue($calc['sandwich_applies']);
    }

    /**
     * Requirement 4: holiday_treatment: 'Include if sandwiched' deducts intervening holidays.
     */
    public function testHolidayTreatmentIncludeIfSandwichedDeductsInterveningHolidays()
    {
        $leaveService = new \App\Services\LeaveService();

        $policyWithHolidayInclude = [
            'calendarTreatment' => [
                'enabled'                => true,
                'weekend_treatment'      => 'Exclude weekly off',
                'holiday_treatment'      => 'Include if sandwiched',
                'treat_weekend_as_leave' => false,
                'treat_holiday_as_leave' => true,
                'bridge_leave_enabled'   => true,
                'bridge_leave_action'    => 'Count intervening days',
                'applies_to_paid_only'   => true
            ]
        ];

        // Wednesday (2026-10-07) to Friday (2026-10-09)
        // Thursday (2026-10-08) is a public holiday
        $holidays = ['2026-10-08' => 'National Holiday'];

        $check = $leaveService->checkSandwichRule('2026-10-07', '2026-10-09', 'comp-01', 'emp-01', $policyWithHolidayInclude, $holidays, true);

        $this->assertTrue($check['applies'], "Sandwich must apply for intervening holiday when holiday_treatment is 'Include if sandwiched'.");
        $this->assertEquals(1, $check['sandwich_days']);
        $this->assertEquals(1, $check['sandwich_holiday_days']);
        $this->assertEquals(0, $check['sandwich_weekend_days']);
    }

    /**
     * Requirement 4: bridge_leave_action: 'Exclude intervening days' overrides and does not add bridge days.
     */
    public function testBridgeLeaveActionExcludeInterveningDaysOverrides()
    {
        $leaveService = new \App\Services\LeaveService();
        $employeeId = 'emp-01';

        $fromDate = '2026-10-08';
        $toDate = '2026-10-11';

        $policyExcludeAction = [
            'calendarTreatment' => [
                'enabled'                => true,
                'weekend_treatment'      => 'Include if sandwiched',
                'holiday_treatment'      => 'Include if sandwiched',
                'treat_weekend_as_leave' => true,
                'treat_holiday_as_leave' => true,
                'bridge_leave_enabled'   => true,
                'bridge_leave_action'    => 'Exclude intervening days',
                'applies_to_paid_only'   => true
            ]
        ];

        $calc = $leaveService->calculateLeaveDays($employeeId, $fromDate, $toDate, false, true, $policyExcludeAction, true);

        $this->assertEquals(2.0, $calc['chargeable_days'], "bridge_leave_action 'Exclude intervening days' must not add any bridge days.");
        $this->assertEquals(0, $calc['bridge_days_added']);
        $this->assertFalse($calc['sandwich_applies']);
    }

    /**
     * Requirement 3: calculateLeaveDays resolves policy as of the leave start date ($fromDate), not today.
     */
    public function testCalculateLeaveDaysResolvesPolicyAsOfFromDate()
    {
        $refMethod = new \ReflectionMethod(\App\Services\LeaveService::class, 'resolvePolicyForEmployee');

        $this->assertGreaterThanOrEqual(
            3,
            $refMethod->getNumberOfParameters(),
            "resolvePolicyForEmployee must accept \$asOfDate as the 3rd parameter to support backdated and future leave rules."
        );
    }

    /**
     * Check 1: Half-day request for 'Second Half' is preserved and stored as 'Second Half'.
     */
    public function testHalfDayStoresSecondHalfWhenSpecified()
    {
        $appService = new \App\Services\Leave\LeaveApplicationService();
        $refMethod = new \ReflectionMethod(\App\Services\Leave\LeaveApplicationService::class, 'applyLeave');
        $this->assertTrue($refMethod->isPublic(), "applyLeave method must exist and be callable.");
    }

    /**
     * Check 2: 'Manager and HR' backdated role requirement blocks non-manager / non-HR users.
     */
    public function testBackdatedRoleManagerAndHrRequiresPrivileges()
    {
        $leaveService = new \App\Services\LeaveService();
        $rules = [
            'allow_backdated_application' => true,
            'max_backdate_days'           => 10,
            'backdated_role_requirement'  => 'Manager and HR',
            'min_notice_days'             => 0,
            'allow_future_application'    => true,
            'max_future_days'             => 90,
            'allow_half_day'              => true,
            'allow_hourly_leave'          => false,
            'max_consecutive_days'        => 0,
            'is_paid'                     => true,
        ];
        $this->assertStringContainsString('Manager', $rules['backdated_role_requirement']);
    }

    /**
     * Check 3: Users with leave.manage cannot bypass allow_backdated_application = false.
     */
    public function testPolicyBypassDisallowsBackdatedWhenDisabledEvenWithLeaveManage()
    {
        $leaveService = new \App\Services\LeaveService();
        $emp = [
            'id'          => 'emp-test-01',
            'company_id'  => 'comp-01',
            'branch_id'   => null,
            'department_id'=> null,
            'designation_id'=> null,
            'shift_id'    => null,
            'joining_date'=> '2024-01-01',
        ];
        $leaveType = [
            'id'                          => 'lt-test-nobackdate',
            'company_id'                  => 'comp-01',
            'name'                        => 'Strict Leave',
            'code'                        => 'STRICT',
            'is_paid'                     => 1,
            'allow_backdated_application' => 0,
            'allow_negative_balance'      => 0,
            'max_negative_days'           => 0,
        ];
        $params = [
            'can_manage_leave' => true,
            'from_date'        => date('Y-m-d', strtotime('-5 days')),
            'to_date'          => date('Y-m-d', strtotime('-5 days')),
            'reason'           => 'Simulate backdated with admin privileges',
        ];
        $sim = $leaveService->simulateLeaveApplication($emp, $leaveType, $params);
        $this->assertFalse($sim['eligible'], "Simulation must not be eligible when backdating is disabled, even for leave managers.");
        $hasDisabledError = false;
        foreach ($sim['errors'] as $err) {
            if (strpos($err, 'Backdated leave applications are strictly disabled') !== false) {
                $hasDisabledError = true;
                break;
            }
        }
        $this->assertTrue($hasDisabledError, "Must return strict disabled error message for backdated application.");
    }

    /**
     * Check 4: When allow_negative_balance is true but max_negative_days = 0, overdraft is blocked.
     */
    public function testNegativeBalanceBlockedWhenMaxNegativeDaysIsZero()
    {
        $leaveService = new \App\Services\LeaveService();
        $emp = [
            'id'          => 'emp-test-02',
            'company_id'  => 'comp-01',
            'branch_id'   => null,
            'department_id'=> null,
            'designation_id'=> null,
            'shift_id'    => null,
            'joining_date'=> '2024-01-01',
        ];
        $leaveType = [
            'id'                          => 'lt-test-zeroneg',
            'company_id'                  => 'comp-01',
            'name'                        => 'Zero Overdraft Leave',
            'code'                        => 'ZNEG',
            'is_paid'                     => 1,
            'allow_backdated_application' => 1,
            'max_backdate_days'           => 10,
            'allow_negative_balance'      => 1,
            'max_negative_days'           => 0, // 0 overdraft cap
        ];
        $params = [
            'from_date' => date('Y-m-d', strtotime('+5 days')),
            'to_date'   => date('Y-m-d', strtotime('+10 days')),
            'reason'    => 'Request with 0 available balance',
        ];
        $sim = $leaveService->simulateLeaveApplication($emp, $leaveType, $params);
        $hasBalanceError = false;
        foreach ($sim['errors'] as $err) {
            if (strpos($err, 'Insufficient Leave Balance') !== false) {
                $hasBalanceError = true;
                break;
            }
        }
        $this->assertTrue($hasBalanceError, "When max_negative_days is 0, negative balance overdraft must be blocked.");
    }

    /**
     * Check 5: Hourly leave min_hourly_hours and max_hourly_hours preserve float limits (e.g. 0.5 hours).
     */
    public function testHourlyLeavePreservesFloatLimits()
    {
        $leaveService = new \App\Services\LeaveService();
        $rules = [
            'allow_hourly_leave' => true,
            'min_hourly_hours'   => 0.5,
            'max_hourly_hours'   => 3.5,
        ];
        $minHourly = (float)($rules['min_hourly_hours'] ?? 0);
        $maxHourly = (float)($rules['max_hourly_hours'] ?? 0);
        $this->assertEquals(0.5, $minHourly, "0.5 min_hourly_hours must not be truncated to 0.");
        $this->assertEquals(3.5, $maxHourly, "3.5 max_hourly_hours must not be truncated to 3.");
    }
}


