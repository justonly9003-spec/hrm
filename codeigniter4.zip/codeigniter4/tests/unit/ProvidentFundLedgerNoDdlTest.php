<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use App\Models\ProvidentFundLedgerModel;
use App\Database\Migrations\EnsureProvidentFundLedgerSchemaAndUniqueIndex;
use App\Database\Seeds\DemoProvidentFundLedgerSeeder;
use CodeIgniter\Events\Events;
use Config\Database;

/**
 * Characterization & Verification Tests:
 * 1. Reading or writing the PF ledger on an empty table inserts no demo rows.
 * 2. ProvidentFundLedgerModel executes no ALTER TABLE / DDL statements at runtime.
 * 3. Migration EnsureProvidentFundLedgerSchemaAndUniqueIndex runs twice idempotently without error.
 * 4. DemoProvidentFundLedgerSeeder refuses to execute when ENVIRONMENT is 'production'.
 */
class ProvidentFundLedgerNoDdlTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected static bool $schemaInitialized = false;

    public static function setUpBeforeClass(): void
    {
        parent::setUpBeforeClass();
        static::ensureSchema();
    }

    protected static function ensureSchema(): void
    {
        if (static::$schemaInitialized) {
            return;
        }

        $db = Database::connect();
        $forge = Database::forge();

        if (!$db->tableExists('provident_fund_ledgers')) {
            $migration = new EnsureProvidentFundLedgerSchemaAndUniqueIndex();
            $migration->up();
        }

        static::$schemaInitialized = true;
    }

    protected function setUp(): void
    {
        parent::setUp();
        $db = Database::connect();
        if ($db->tableExists('provident_fund_ledgers')) {
            $db->table('provident_fund_ledgers')->truncate();
        }
    }

    /**
     * Test 1: Reading/writing the ledger on an empty table inserts NO demo rows
     */
    public function testEmptyTableInsertsNoDemoRowsOnReadOrWrite(): void
    {
        $db = Database::connect();
        $initialCount = (int)$db->table('provident_fund_ledgers')->countAllResults();
        $this->assertSame(0, $initialCount, 'Ledger table must start empty for this test.');

        // 1. Model instantiation on empty table must not trigger demo seed
        $model = new ProvidentFundLedgerModel();
        $countAfterConstruct = (int)$db->table('provident_fund_ledgers')->countAllResults();
        $this->assertSame(0, $countAfterConstruct, 'Instantiating model on empty table must NOT seed demo rows.');

        // 2. Read methods on empty table must return empty/zero and NOT seed demo rows
        $balance = $model->getLatestBalance('emp-alpha-001');
        $this->assertSame(0.00, $balance, 'Latest balance for non-existent employee on empty table must be 0.00.');

        $statement = $model->getEmployeeStatement('emp-alpha-001');
        $this->assertIsArray($statement);
        $this->assertSame(0, (int)($statement['transaction_count'] ?? count($statement)), 'Employee statement must be empty.');

        $countAfterReads = (int)$db->table('provident_fund_ledgers')->countAllResults();
        $this->assertSame(0, $countAfterReads, 'Read methods on empty table must NOT seed demo rows.');

        // 3. Write operation on empty table inserts ONLY the specified record
        $payroll = [
            'id'          => 'pay-item-test-1',
            'payroll_id'  => 'batch-2026-10',
            'employee_id' => 'emp-real-001',
            'company_id'  => 'comp-real-apex',
            'month'       => 10,
            'year'        => 2026,
        ];
        $pfCalc = [
            'employee_contribution' => 2500.00,
            'employer_contribution' => 2500.00,
            'total_contribution'    => 5000.00,
            'pf_base_salary'        => 50000.00,
        ];

        $inserted = $model->recordPayrollContribution($payroll, $pfCalc, 'user-admin', 'draft');
        $this->assertNotEmpty($inserted['id'] ?? null);

        $totalRowsAfterWrite = (int)$db->table('provident_fund_ledgers')->countAllResults();
        $this->assertSame(1, $totalRowsAfterWrite, 'Writing to empty table must insert exactly 1 row (no 45 demo rows).');

        $row = $db->table('provident_fund_ledgers')->where('employee_id', 'emp-real-001')->get()->getRowArray();
        $this->assertNotNull($row);
        $this->assertSame('emp-real-001', $row['employee_id']);
        $this->assertSame('comp-real-apex', $row['company_id']);
        $this->assertEquals(5000.00, (float)$row['total_contribution']);
    }

    /**
     * Test 2: Model executes NO ALTER TABLE / CREATE TABLE DDL queries at runtime
     */
    public function testModelExecutesNoAlterTableStatements(): void
    {
        $executedQueries = [];
        $queryListener = static function ($query) use (&$executedQueries) {
            $executedQueries[] = (string)$query;
        };

        Events::on('DBQuery', $queryListener);

        try {
            // Instantiate model and execute various operational methods
            $model = new ProvidentFundLedgerModel();
            $model->getLatestBalance('emp-999');
            $model->getEmployeeStatement('emp-999', 2026);

            $payroll = [
                'id'          => 'pay-item-ddl-check',
                'payroll_id'  => 'batch-ddl-check',
                'employee_id' => 'emp-ddl-001',
                'company_id'  => 'comp-ddl-test',
                'month'       => 11,
                'year'        => 2026,
            ];
            $pfCalc = [
                'employee_contribution' => 1000.00,
                'employer_contribution' => 1000.00,
                'total_contribution'    => 2000.00,
                'pf_base_salary'        => 20000.00,
            ];
            $model->recordPayrollContribution($payroll, $pfCalc, 'user-tester');

            // Assert that none of the executed queries contained DDL keywords
            $this->assertNotEmpty($executedQueries, 'Queries should have been captured.');
            foreach ($executedQueries as $sql) {
                $trimmed = trim(strtoupper($sql));
                $this->assertStringNotContainsString('ALTER TABLE', $trimmed, "Model must not execute ALTER TABLE queries at runtime: {$sql}");
                $this->assertStringNotContainsString('CREATE TABLE', $trimmed, "Model must not execute CREATE TABLE queries at runtime: {$sql}");
                $this->assertStringNotContainsString('DROP TABLE', $trimmed, "Model must not execute DROP TABLE queries at runtime: {$sql}");
                $this->assertStringNotContainsString('SHOW INDEX', $trimmed, "Model must not execute SHOW INDEX queries at runtime: {$sql}");
            }
        } finally {
            Events::removeListener('DBQuery', $queryListener);
        }
    }

    /**
     * Test 3: Migration runs twice without error (idempotency)
     */
    public function testMigrationRunsTwiceWithoutError(): void
    {
        $migration = new EnsureProvidentFundLedgerSchemaAndUniqueIndex();

        // First run
        $migration->up();

        // Second run must be completely idempotent and throw no exceptions
        $migration->up();

        $db = Database::connect();
        $this->assertTrue($db->tableExists('provident_fund_ledgers'));

        // Verify required columns exist
        $fields = $db->getFieldNames('provident_fund_ledgers');
        $this->assertContains('id', $fields);
        $this->assertContains('company_id', $fields);
        $this->assertContains('employee_id', $fields);
        $this->assertContains('payroll_id', $fields);
        $this->assertContains('payroll_month', $fields);
        $this->assertContains('payroll_year', $fields);
        $this->assertContains('transaction_type', $fields);
        $this->assertContains('running_balance', $fields);
        $this->assertContains('status', $fields);
    }

    /**
     * Test 4: Demo seeder refuses to run when ENVIRONMENT is 'production'
     */
    public function testDemoSeederRefusesToRunInProduction(): void
    {
        $seeder = new DemoProvidentFundLedgerSeeder(\Config\Database::seeder());

        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('DemoProvidentFundLedgerSeeder cannot be executed in production environment.');

        // Explicitly invoke in production environment
        $seeder->run('production');
    }

    /**
     * Test 5: Demo seeder populates development data when executed in non-production
     */
    public function testDemoSeederRunsInDevelopmentEnvironment(): void
    {
        $db = Database::connect();
        $db->table('provident_fund_ledgers')->truncate();

        $seeder = new DemoProvidentFundLedgerSeeder(\Config\Database::seeder());
        $seeder->run('development');

        $totalSeeded = (int)$db->table('provident_fund_ledgers')->countAllResults();
        // 5 demo employees * (1 opening balance + 8 monthly contributions) = 45 rows
        $this->assertSame(45, $totalSeeded, 'Demo seeder in development must seed exactly 45 rows.');

        // Verify idempotency of seeder
        $seeder->run('development');
        $totalAfterSecondRun = (int)$db->table('provident_fund_ledgers')->countAllResults();
        $this->assertSame(45, $totalAfterSecondRun, 'Running demo seeder twice in development must not duplicate records.');
    }
}
