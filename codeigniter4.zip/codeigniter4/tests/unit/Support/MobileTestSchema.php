<?php

namespace Tests\Unit\Support;

/** In-memory SQLite schema + seed data shared by the mobile API tests. */
trait MobileTestSchema
{
    private const PASSWORD = 'Str0ng!Passw0rd';

    protected function buildMobileSchema($db): void
    {
        foreach ([
            'user_permissions', 'role_permissions', 'permissions', 'user_roles', 'audit_logs', 'system_settings',
            'departments', 'designations', 'branches', 'mobile_access_tokens', 'mobile_refresh_tokens',
            'mobile_devices', 'login_history', 'users', 'employees', 'roles', 'companies'
        ] as $t) {
            $db->query("DROP TABLE IF EXISTS {$t}");
        }
        $db->query("CREATE TABLE companies (id VARCHAR(36) PRIMARY KEY, name VARCHAR(100), code VARCHAR(30), timezone VARCHAR(50) DEFAULT 'America/New_York', status VARCHAR(20) DEFAULT 'active', logo VARCHAR(255) NULL, created_at DATETIME NULL, updated_at DATETIME NULL)");
        $db->query("CREATE TABLE roles (id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36) NULL, code VARCHAR(50), name VARCHAR(100), status VARCHAR(20) DEFAULT 'active', created_at DATETIME NULL, updated_at DATETIME NULL)");
        $db->query("CREATE TABLE employees (id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36), employee_code VARCHAR(50), first_name VARCHAR(100), last_name VARCHAR(100), branch_id VARCHAR(36) NULL, department_id VARCHAR(36) NULL, designation_id VARCHAR(36) NULL, shift_id VARCHAR(36) NULL, email VARCHAR(150) NULL, phone VARCHAR(50) NULL, joining_date DATE NULL, photo VARCHAR(255) NULL, basic_salary DECIMAL(12,2) DEFAULT 50000, gross_salary DECIMAL(12,2) DEFAULT 80000, status VARCHAR(30) DEFAULT 'Active', created_at DATETIME NULL, updated_at DATETIME NULL, deleted_at DATETIME NULL)");
        $db->query("CREATE TABLE users (id VARCHAR(36) PRIMARY KEY, employee_id VARCHAR(36) NULL, name VARCHAR(100) NULL, username VARCHAR(100), email VARCHAR(150), password_hash VARCHAR(255), role_id VARCHAR(36), company_id VARCHAR(36) NULL, branch_id VARCHAR(36) NULL, department_id VARCHAR(36) NULL, failed_logins INT DEFAULT 0, locked_until DATETIME NULL, status VARCHAR(20) DEFAULT 'active', must_change_password INT DEFAULT 0, theme_mode VARCHAR(10) NULL, is_two_factor_enabled INT DEFAULT 0, last_login_at DATETIME NULL, created_at DATETIME NULL, updated_at DATETIME NULL)");
        $db->query("CREATE TABLE login_history (id VARCHAR(36) PRIMARY KEY, user_id VARCHAR(36) NULL, ip_address VARCHAR(45), user_agent VARCHAR(500), status VARCHAR(30), attempted_at DATETIME NULL, login_time DATETIME NULL, created_at DATETIME NULL)");
        $db->query("CREATE TABLE mobile_devices (id CHAR(36) PRIMARY KEY, user_id VARCHAR(36), company_id VARCHAR(36) NULL, device_uid VARCHAR(100), platform VARCHAR(20) NULL, device_name VARCHAR(150) NULL, app_version VARCHAR(30) NULL, push_token VARCHAR(512) NULL, last_seen_at DATETIME NULL, revoked_at DATETIME NULL, created_at DATETIME NULL, updated_at DATETIME NULL, UNIQUE(user_id, device_uid))");
        $db->query("CREATE TABLE mobile_refresh_tokens (id CHAR(36) PRIMARY KEY, user_id VARCHAR(36), company_id VARCHAR(36) NULL, device_id CHAR(36), family_id CHAR(36), token_hash CHAR(64) UNIQUE, expires_at DATETIME, used_at DATETIME NULL, revoked_at DATETIME NULL, replaced_by_id CHAR(36) NULL, created_ip VARCHAR(45) NULL, created_at DATETIME NULL)");
        $db->query("CREATE TABLE mobile_access_tokens (id CHAR(36) PRIMARY KEY, user_id VARCHAR(36), device_id CHAR(36), refresh_token_id CHAR(36) NULL, token_hash CHAR(64) UNIQUE, expires_at DATETIME, revoked_at DATETIME NULL, created_at DATETIME NULL)");

        $db->query("CREATE TABLE departments (id VARCHAR(36) PRIMARY KEY, name VARCHAR(100))");
        $db->query("CREATE TABLE designations (id VARCHAR(36) PRIMARY KEY, name VARCHAR(100))");
        $db->query("CREATE TABLE branches (id VARCHAR(36) PRIMARY KEY, name VARCHAR(100))");

        // RBAC Permissions Tables
        $db->query("CREATE TABLE permissions (id VARCHAR(36) PRIMARY KEY, code VARCHAR(100) UNIQUE, module VARCHAR(50) NULL, action VARCHAR(50) NULL, name VARCHAR(100), description TEXT NULL, created_at DATETIME NULL, updated_at DATETIME NULL)");
        $db->query("CREATE TABLE role_permissions (id INTEGER PRIMARY KEY AUTOINCREMENT, role_id VARCHAR(36), permission_id VARCHAR(36), scope_level VARCHAR(30) DEFAULT 'company', created_at DATETIME NULL)");
        $db->query("CREATE TABLE user_permissions (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id VARCHAR(36), permission_id VARCHAR(36), is_granted INT DEFAULT 1, expires_at DATETIME NULL, created_at DATETIME NULL)");
        $db->query("CREATE TABLE user_roles (id VARCHAR(36) PRIMARY KEY, user_id VARCHAR(36), role_id VARCHAR(36), created_at DATETIME NULL)");
        $db->query("CREATE TABLE audit_logs (id VARCHAR(36) PRIMARY KEY, user_id VARCHAR(36) NULL, company_id VARCHAR(36) NULL, module VARCHAR(50), action VARCHAR(50), record_id VARCHAR(36) NULL, old_values TEXT NULL, new_values TEXT NULL, ip_address VARCHAR(45) NULL, user_agent VARCHAR(500) NULL, notes TEXT NULL, created_at DATETIME NULL)");
        $db->query("CREATE TABLE system_settings (id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36) NULL, key_name VARCHAR(100), value_text TEXT, created_at DATETIME NULL, updated_at DATETIME NULL)");

        // Add additional columns if missing
        $alters = [
            'ALTER TABLE companies ADD COLUMN address VARCHAR(255) NULL',
            'ALTER TABLE companies ADD COLUMN email VARCHAR(150) NULL',
            'ALTER TABLE companies ADD COLUMN phone VARCHAR(50) NULL',
            'ALTER TABLE companies ADD COLUMN website VARCHAR(150) NULL',
            'ALTER TABLE roles ADD COLUMN is_system INT DEFAULT 0',
            'ALTER TABLE employees ADD COLUMN salary_status VARCHAR(30) NULL',
            'ALTER TABLE employees ADD COLUMN reporting_manager_id VARCHAR(36) NULL',
            'ALTER TABLE employees ADD COLUMN employment_type_id VARCHAR(36) NULL',
            'ALTER TABLE employees ADD COLUMN join_date DATE NULL',
        ];
        foreach ($alters as $alter) {
            try {
                $db->query($alter);
            } catch (\Throwable $e) {
                // Column may already exist
            }
        }

        $db->table('companies')->insert(['id' => 'c-1', 'name' => 'Acme Ltd', 'code' => 'ACME', 'timezone' => 'America/New_York', 'status' => 'active']);
        $db->table('companies')->insert(['id' => 'c-2', 'name' => 'Other Ltd', 'code' => 'OTHER', 'timezone' => 'Asia/Dhaka', 'status' => 'active']);
        $db->table('roles')->insert(['id' => 'r-emp', 'code' => 'employee', 'name' => 'Employee', 'status' => 'active']);
        $db->table('roles')->insert(['id' => 'r-sa', 'code' => 'software_app_admin', 'name' => 'Software App Admin', 'status' => 'active']);
        $db->table('employees')->insert(['id' => 'e-1', 'company_id' => 'c-1', 'employee_code' => 'EMP-001', 'first_name' => 'Rahim', 'last_name' => 'Uddin', 'status' => 'Active']);
        $db->table('employees')->insert(['id' => 'e-2', 'company_id' => 'c-2', 'employee_code' => 'EMP-001', 'first_name' => 'Karim', 'last_name' => 'Ali', 'status' => 'Active']);
        $this->addUser('u-1', 'rahim', 'rahim@acme.test', 'c-1', 'e-1', 'r-emp');
        $this->addUser('u-2', 'karim', 'karim@other.test', 'c-2', 'e-2', 'r-emp');

        // Seed essential employee permissions and assign to r-emp
        $empPermissions = [
            'attendance.clock'  => 'Attendance Clock In/Out',
            'attendance.view'   => 'Attendance View',
            'leave.create'      => 'Apply for Leave',
            'leave.view'        => 'View Leave Balances & Applications',
            'payroll.view'      => 'View Payslips and Payroll Summary',
            'pf.view'           => 'View Provident Fund Ledger',
            'overtime.view'     => 'View Overtime Records',
            'overtime.create'   => 'Submit Overtime Claims',
            'document.view'     => 'View Employee Documents',
            'document.download' => 'Download Employee Documents',
            'notice.view'       => 'View Company Notices',
            'directory.view'    => 'View Company Directory',
            'profile.view'      => 'View Employee Profile',
        ];

        foreach ($empPermissions as $code => $name) {
            $permId = 'perm-' . str_replace('.', '-', $code);
            $parts = explode('.', $code);
            $module = $parts[0] ?? 'general';
            $action = $parts[1] ?? 'view';

            $db->table('permissions')->insert([
                'id'          => $permId,
                'code'        => $code,
                'module'      => $module,
                'action'      => $action,
                'name'        => $name,
                'description' => $name,
            ]);

            $db->table('role_permissions')->insert([
                'role_id'       => 'r-emp',
                'permission_id' => $permId,
                'scope_level'   => 'company',
            ]);
        }
    }

    protected function addUser(string $id, string $username, string $email, string $company, ?string $emp, string $role, array $extra = []): void
    {
        $this->db->table('users')->insert(array_merge([
            'id' => $id, 'username' => $username, 'email' => $email,
            'password_hash' => password_hash(self::PASSWORD, PASSWORD_BCRYPT, ['cost' => 4]),
            'company_id' => $company, 'employee_id' => $emp, 'role_id' => $role, 'status' => 'active',
        ], $extra));
    }

    protected function setAuthContext(array $user): void
    {
        \App\Services\Mobile\MobileAuthContext::setUser($user);
    }

    /** Helper to safely extract HTTP status code from CodeIgniter TestResponse or standard ResponseInterface */
    protected function httpStatus($res): int
    {
        if ($res instanceof \CodeIgniter\Test\TestResponse) {
            return (int)$res->response()->getStatusCode();
        }
        if (is_object($res) && method_exists($res, 'response')) {
            $r = $res->response();
            if (is_object($r) && method_exists($r, 'getStatusCode')) {
                return (int)$r->getStatusCode();
            }
        }
        if (is_object($res) && method_exists($res, 'getStatusCode')) {
            $code = $res->getStatusCode();
            if ($code !== null) {
                return (int)$code;
            }
        }
        return 0;
    }
}
