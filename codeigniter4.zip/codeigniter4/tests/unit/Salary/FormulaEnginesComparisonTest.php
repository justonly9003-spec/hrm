<?php

namespace Tests\Unit\Salary;

use CodeIgniter\Test\CIUnitTestCase;
use App\Libraries\PayrollCalculator;
use App\Services\Rules\FormulaEvaluator;

/**
 * Pins the behavior of both formula engines:
 * 1. App\Libraries\PayrollCalculator::evaluateSalaryFormula() (numeric-only, used for salary structures)
 * 2. App\Services\Rules\FormulaEvaluator::evaluate() (RPN/Shunting-Yard, used for PF and Bonus rules)
 */
class FormulaEnginesComparisonTest extends CIUnitTestCase
{
    /**
     * Test basic arithmetic syntax in both engines
     */
    public function testBasicArithmeticSyntax(): void
    {
        $vars = [
            'BASIC' => 50000.0,
            'HRA'   => 20000.0,
        ];

        // PayrollCalculator
        $pcVal = PayrollCalculator::evaluateSalaryFormula('BASIC * 0.50 + HRA', $vars);
        $this->assertEquals(45000.00, $pcVal);

        // FormulaEvaluator
        $feVal = FormulaEvaluator::evaluate('BASIC * 0.50 + HRA', $vars);
        $this->assertEquals(45000.0, $feVal);
    }

    /**
     * Test case-insensitivity and variable aliases
     */
    public function testVariableAliasesAndCaseInsensitivity(): void
    {
        $vars = [
            'Basic'        => 40000.0,
            'HouseRent'    => 15000.0,
            'Gross_Salary' => 60000.0,
        ];

        // PayrollCalculator handles case-insensitivity through whole-word regex matching
        $pcVal = PayrollCalculator::evaluateSalaryFormula('basic * 0.50', $vars);
        $this->assertEquals(20000.00, $pcVal);

        // FormulaEvaluator handles standard aliases (e.g. BASIC <-> BASIC_SALARY, GROSS <-> GROSS_SALARY, HOUSE_RENT <-> HRA, MEDICAL <-> MED, CONVEYANCE <-> TRANSPORT)
        $feVal = FormulaEvaluator::evaluate('BASIC * 0.50 + HRA + MED + TRANSPORT', [
            'Basic_Salary'         => 40000.0,
            'House_Rent_Allowance' => 15000.0,
            'Medical_Allowance'    => 3000.0,
            'Conveyance_Allowance' => 2000.0,
        ]);
        $this->assertEquals(40000.0, $feVal);
    }

    /**
     * Test unknown variable handling:
     * - PayrollCalculator leaves the unknown variable in string, causing safety regex check to fail and returning 0.00
     * - FormulaEvaluator throws InvalidArgumentException for unknown variables
     */
    public function testUnknownVariableBehavior(): void
    {
        $vars = [
            'BASIC' => 50000.0,
        ];

        // PayrollCalculator: unknown variable 'NON_EXISTENT' fails safety validation -> returns 0.00
        $pcVal = PayrollCalculator::evaluateSalaryFormula('BASIC + NON_EXISTENT', $vars);
        $this->assertEquals(0.00, $pcVal);

        // FormulaEvaluator: unknown variable throws InvalidArgumentException
        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage("Unknown variable 'NON_EXISTENT'");
        FormulaEvaluator::evaluate('BASIC + NON_EXISTENT', $vars);
    }

    /**
     * Test division by zero:
     * - PayrollCalculator returns 0.00 for the entire formula
     * - FormulaEvaluator throws InvalidArgumentException on division or modulo by zero
     */
    public function testDivisionByZeroBehavior(): void
    {
        $vars = [
            'BASIC' => 50000.0,
        ];

        $pcVal1 = PayrollCalculator::evaluateSalaryFormula('BASIC / 0', $vars);
        $this->assertEquals(0.00, $pcVal1);

        $pcVal2 = PayrollCalculator::evaluateSalaryFormula('BASIC + (1000 / 0)', $vars);
        $this->assertEquals(0.00, $pcVal2);

        try {
            FormulaEvaluator::evaluate('BASIC / 0', $vars);
            $this->fail('Expected InvalidArgumentException on division by zero');
        } catch (\InvalidArgumentException $e) {
            $this->assertStringContainsString('Division by zero', $e->getMessage());
        }

        try {
            FormulaEvaluator::evaluate('BASIC + (1000 / (5 - 5))', $vars);
            $this->fail('Expected InvalidArgumentException on nested division by zero');
        } catch (\InvalidArgumentException $e) {
            $this->assertStringContainsString('Division by zero', $e->getMessage());
        }

        $this->expectException(\InvalidArgumentException::class);
        FormulaEvaluator::evaluate('BASIC % 0', $vars);
    }

    /**
     * Test rounding precision:
     * - PayrollCalculator rounds to 2 decimals
     * - FormulaEvaluator rounds to 4 decimals
     */
    public function testRoundingPrecision(): void
    {
        $vars = [
            'BASIC' => 100.0,
        ];

        // 100 / 3 = 33.333333...
        $pcVal = PayrollCalculator::evaluateSalaryFormula('BASIC / 3', $vars);
        $this->assertEquals(33.33, $pcVal);

        $feVal = FormulaEvaluator::evaluate('BASIC / 3', $vars);
        $this->assertEquals(33.3333, $feVal);
    }

    /**
     * Test math functions (MIN, MAX, ROUND, ABS):
     * - PayrollCalculator supports MIN(), MAX(), ROUND(), ABS()
     * - FormulaEvaluator does NOT support function calls and throws InvalidArgumentException
     */
    public function testMathFunctionsSupport(): void
    {
        $vars = [
            'BASIC' => 50000.0,
        ];

        // PayrollCalculator supports MIN/MAX/ROUND
        $pcVal = PayrollCalculator::evaluateSalaryFormula('MIN(BASIC * 0.10, 3000)', $vars);
        $this->assertEquals(3000.00, $pcVal); // 50000 * 0.10 = 5000, capped at 3000

        $pcRound = PayrollCalculator::evaluateSalaryFormula('ROUND(BASIC / 7, 2)', $vars);
        $this->assertEquals(7142.86, $pcRound);

        // FormulaEvaluator rejects function syntax / commas with InvalidArgumentException
        $this->expectException(\InvalidArgumentException::class);
        FormulaEvaluator::evaluate('MIN(BASIC * 0.10, 3000)', $vars);
    }

    /**
     * Test power operator (^):
     * - FormulaEvaluator supports right-associative exponentiation (^)
     * - PayrollCalculator does not support ^ (rejected by safety regex)
     */
    public function testExponentiationSupport(): void
    {
        $vars = ['BASE' => 2, 'EXP' => 3];

        $feVal = FormulaEvaluator::evaluate('BASE ^ EXP', $vars);
        $this->assertEquals(8.0, $feVal);

        // Right-associative: 2 ^ 3 ^ 2 = 2 ^ (3 ^ 2) = 2 ^ 9 = 512
        $this->assertEquals(512.0, FormulaEvaluator::evaluate('2 ^ 3 ^ 2'));

        $pcVal = PayrollCalculator::evaluateSalaryFormula('BASE ^ EXP', $vars);
        $this->assertEquals(0.00, $pcVal); // '^' is not in allowed characters regex for PayrollCalculator
    }

    /**
     * Test unary minus before parentheses and numbers
     */
    public function testUnaryMinusBeforeParentheses(): void
    {
        $this->assertEquals(-8.0, FormulaEvaluator::evaluate('2 * -(3+1)'));
        $this->assertEquals(10.0, FormulaEvaluator::evaluate('-(2 + 3) * -2'));
        $this->assertEquals(-4000.0, FormulaEvaluator::evaluate('-(BASIC + HRA) * 0.10', ['BASIC' => 30000, 'HRA' => 10000]));
    }

    /**
     * Test numeric substitution formats with 8 decimals and avoids scientific notation
     */
    public function testScientificNotationAvoidedInSubstitution(): void
    {
        // 1e-6 in PHP float string cast becomes "1.0E-6", which would fail if not formatted with number_format($v, 8, '.', '')
        $val = FormulaEvaluator::evaluate('TINY * 1000000', ['TINY' => 0.000001]);
        $this->assertEquals(1.0, $val);
    }

    /**
     * Test invalid characters throw InvalidArgumentException
     */
    public function testInvalidCharactersThrowInvalidArgumentException(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage("Invalid character '$'");
        FormulaEvaluator::evaluate('BASIC * $0.10', ['BASIC' => 50000]);
    }

    /**
     * Test unbalanced parentheses throw InvalidArgumentException
     */
    public function testUnbalancedParenthesesThrowInvalidArgumentException(): void
    {
        try {
            FormulaEvaluator::evaluate('(BASIC + 1000 * 0.10', ['BASIC' => 50000]);
            $this->fail('Expected InvalidArgumentException for unclosed opening parenthesis');
        } catch (\InvalidArgumentException $e) {
            $this->assertStringContainsString('Unbalanced parentheses', $e->getMessage());
        }

        try {
            FormulaEvaluator::evaluate('BASIC + 1000) * 0.10', ['BASIC' => 50000]);
            $this->fail('Expected InvalidArgumentException for unexpected closing parenthesis');
        } catch (\InvalidArgumentException $e) {
            $this->assertStringContainsString('Unbalanced parentheses', $e->getMessage());
        }

        $this->expectException(\InvalidArgumentException::class);
        FormulaEvaluator::evaluate('BASIC + ()', ['BASIC' => 50000]);
    }

    /**
     * Test FormulaEvaluator::testFormulaSyntax validates syntax and variable references
     */
    public function testFormulaSyntaxValidation(): void
    {
        $ok = FormulaEvaluator::testFormulaSyntax('(BASIC + HRA) * (RATE / 100)');
        $this->assertTrue($ok['valid']);
        $this->assertArrayHasKey('sample_result', $ok);

        $badVar = FormulaEvaluator::testFormulaSyntax('BASIC + NON_EXISTENT_VAR');
        $this->assertFalse($badVar['valid']);
        $this->assertStringContainsString("Unknown variable 'NON_EXISTENT_VAR'", $badVar['error'] ?? '');

        $badParen = FormulaEvaluator::testFormulaSyntax('(BASIC + HRA * 0.10');
        $this->assertFalse($badParen['valid']);
        $this->assertStringContainsString('Unbalanced parentheses', $badParen['error'] ?? '');

        $badDiv = FormulaEvaluator::testFormulaSyntax('BASIC / 0');
        $this->assertFalse($badDiv['valid']);
        $this->assertStringContainsString('Division by zero', $badDiv['error'] ?? '');

        $badChar = FormulaEvaluator::testFormulaSyntax('BASIC @ 0.10');
        $this->assertFalse($badChar['valid']);
        $this->assertStringContainsString("Invalid character '@'", $badChar['error'] ?? '');
    }
}
