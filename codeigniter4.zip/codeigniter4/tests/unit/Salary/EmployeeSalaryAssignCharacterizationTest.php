<?php

namespace Tests\Unit\Salary;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use App\Services\EmployeeSalaryService;
use App\Models\EmployeeSalaryModel;
use App\Models\EmployeeModel;
use Config\Database;

/**
 * Characterization test for EmployeeSalaryService::assignSalary()
 * Captures current behavior for:
 * - fixed components
 * - formula components
 * - formulas referencing other components
 * - formulas that error / invalid syntax
 * - allowances & deductions
 * - legacy-fields path
 * Asserts exact saved salary rows in employee_salaries and employees.
 */
class EmployeeSalaryAssignCharacterizationTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected static bool $schemaInitialized = false;

    protected string $companyId = 'comp-sal-char-01';
    protected string $branchId  = 'branch-sal-char-01';
    protected string $deptId    = 'dept-sal-char-01';
    protected string $desgId    = 'desg-sal-char-01';
    protected string $shiftId   = 'shift-sal-char-01';
    protected string $empTypeId = 'et-sal-char-01';
    protected string $empId     = 'emp-sal-char-01';

    protected array $authorizedActor = [];

    public static function setUpBeforeClass(): void
    {
        parent::setUpBeforeClass();
        static::ensureSchema();
    }

    public static function registerSqliteFunctions($db): void
    {
        try {
            $rawConn = $db->connID ?? null;
            if ($rawConn instanceof \SQLite3) {
                $rawConn->createFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->createFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            }
        } catch (\Throwable $e) {
            // ignore
        }
    }

    protected static function ensureSchema(): void
    {
        $db = Database::connect();
        static::registerSqliteFunctions($db);

        $schemaFile = dirname(__DIR__) . '/Rules/schema.sqlite.sql';
        if (file_exists($schemaFile)) {
            $sql = file_get_contents($schemaFile);
            $statements = array_filter(array_map('trim', explode(';', $sql)));
            foreach ($statements as $stmt) {
                if (!empty($stmt)) {
                    try {
                        $db->query($stmt);
                    } catch (\Throwable $e) {
                        // ignore
                    }
                }
            }
        }

        // Ensure all required columns exist in SQLite tables
        $tablesAndColumns = [
            'employees' => [
                'basic_salary'         => 'DECIMAL(15,2) DEFAULT 0',
                'gross_salary'         => 'DECIMAL(15,2) DEFAULT 0',
                'house_rent_allowance' => 'DECIMAL(15,2) DEFAULT 0',
                'medical_allowance'    => 'DECIMAL(15,2) DEFAULT 0',
                'conveyance_allowance' => 'DECIMAL(15,2) DEFAULT 0',
                'transport_allowance'  => 'DECIMAL(15,2) DEFAULT 0',
                'other_allowances'     => 'DECIMAL(15,2) DEFAULT 0',
                'salary_status'        => 'VARCHAR(50) DEFAULT "NOT_CONFIGURED"',
            ],
            'employee_salaries' => [
                'total_deductions' => 'DECIMAL(15,2) DEFAULT 0',
                'net_salary'       => 'DECIMAL(15,2) DEFAULT 0',
                'ctc'              => 'DECIMAL(15,2) DEFAULT 0',
            ],
        ];

        foreach ($tablesAndColumns as $table => $cols) {
            foreach ($cols as $col => $definition) {
                try {
                    $db->query("ALTER TABLE {$table} ADD COLUMN {$col} {$definition}");
                } catch (\Throwable $e) {
                    // Column already exists
                }
            }
        }

        static::$schemaInitialized = true;
    }

    protected function setUp(): void
    {
        parent::setUp();
        static::ensureSchema();

        $db = Database::connect();
        static::registerSqliteFunctions($db);

        // Seed Company
        $db->table('companies')->replace([
            'id'     => $this->companyId,
            'name'   => 'Characterization Test Corp',
            'code'   => 'CTC',
            'status' => 'Active',
        ]);

        // Seed Branch, Department, Designation, Shift, EmploymentType
        $db->table('branches')->replace([
            'id'         => $this->branchId,
            'company_id' => $this->companyId,
            'name'       => 'HQ Branch',
            'code'       => 'HQ',
            'status'     => 'Active',
        ]);

        $db->table('departments')->replace([
            'id'         => $this->deptId,
            'company_id' => $this->companyId,
            'name'       => 'Engineering',
            'code'       => 'ENG',
            'status'     => 'Active',
        ]);

        $db->table('designations')->replace([
            'id'         => $this->desgId,
            'company_id' => $this->companyId,
            'name'       => 'Software Engineer',
            'code'       => 'SWE',
            'status'     => 'Active',
        ]);

        $db->table('shifts')->replace([
            'id'         => $this->shiftId,
            'company_id' => $this->companyId,
            'name'       => 'Day Shift',
            'start_time' => '09:00:00',
            'end_time'   => '18:00:00',
            'status'     => 'Active',
        ]);

        $db->table('employment_types')->replace([
            'id'         => $this->empTypeId,
            'company_id' => $this->companyId,
            'name'       => 'Full-Time Permanent',
            'code'       => 'FTP',
            'status'     => 'Active',
        ]);

        // Authorized Actor (Company Admin)
        $this->authorizedActor = [
            'id'          => 'usr-admin-char-01',
            'username'    => 'char_admin',
            'company_id'  => $this->companyId,
            'branch_id'   => $this->branchId,
            'role_id'     => 'role-company-admin',
            'role_code'   => 'company_admin',
            'role_name'   => 'Company Admin',
            'permissions' => ['*'],
        ];

        // Seed Default Test Employee
        $db->table('employees')->where('id', $this->empId)->delete();
        $db->table('employees')->insert([
            'id'                   => $this->empId,
            'company_id'           => $this->companyId,
            'branch_id'            => $this->branchId,
            'department_id'        => $this->deptId,
            'designation_id'       => $this->desgId,
            'employment_type_id'   => $this->empTypeId,
            'shift_id'             => $this->shiftId,
            'employee_code'        => 'EMP-CHAR-01',
            'first_name'           => 'Alice',
            'last_name'            => 'Engineer',
            'gender'               => 'female',
            'dob'                  => '1992-05-15',
            'status'               => 'active',
            'basic_salary'         => 0.00,
            'gross_salary'         => 0.00,
            'salary_status'        => 'NOT_CONFIGURED',
            'is_pf_applicable'     => 0,
            'pf_status'            => 'Not Enrolled',
        ]);

        // Clean existing salaries for employee
        $db->table('employee_salaries')->where('employee_id', $this->empId)->delete();
        $db->table('salary_revisions')->where('employee_id', $this->empId)->delete();
    }

    /**
     * Test 1: Fixed salary components assignSalary calculation and DB persistence
     */
    public function testAssignSalaryWithFixedComponents(): void
    {
        $service = new EmployeeSalaryService();
        $db = Database::connect();

        $payload = [
            'effective_from' => '2026-01-01',
            'basic_salary'   => 50000.00,
            'components'     => [
                [
                    'code'             => 'BASIC',
                    'name'             => 'Basic Salary',
                    'type'             => 'earning',
                    'calculation_type' => 'fixed',
                    'rate_or_amount'   => 50000.00,
                    'is_enabled'       => true,
                ],
                [
                    'code'             => 'MED',
                    'name'             => 'Medical Allowance',
                    'type'             => 'earning',
                    'calculation_type' => 'fixed',
                    'rate_or_amount'   => 3000.00,
                    'is_enabled'       => true,
                ],
            ],
        ];

        $res = $service->assignSalary($this->empId, $payload, $this->companyId, $this->authorizedActor);
        $this->assertTrue($res['success'], $res['message'] ?? '');

        $salaryRow = $db->table('employee_salaries')
            ->where('employee_id', $this->empId)
            ->where('status', 'Active')
            ->get()->getRowArray();

        $this->assertNotNull($salaryRow);
        $this->assertEquals(50000.00, (float)$salaryRow['basic_salary']);
        $this->assertEquals(53000.00, (float)$salaryRow['gross_salary']);
        $this->assertEquals(0.00, (float)$salaryRow['total_deductions']);
        $this->assertEquals(53000.00, (float)$salaryRow['net_salary']);

        $revision = $db->table('salary_revisions')
            ->where('employee_id', $this->empId)
            ->orderBy('created_at', 'DESC')
            ->get()->getRowArray();
        $this->assertNotNull($revision);
        $revisionSnapshot = json_decode($revision['snapshot_json'], true);
        $this->assertIsArray($revisionSnapshot);
        $this->assertSame($this->empId, $revisionSnapshot['employee_id']);

        $empRow = $db->table('employees')->where('id', $this->empId)->get()->getRowArray();
        $this->assertEquals(50000.00, (float)$empRow['basic_salary']);
        $this->assertEquals(53000.00, (float)$empRow['gross_salary']);
        $this->assertEquals(3000.00, (float)$empRow['medical_allowance']);
        $this->assertEquals('CONFIGURED', $empRow['salary_status']);
    }

    /**
     * Test 2: Formula component evaluated via PayrollCalculator::evaluateSalaryFormula
     */
    public function testAssignSalaryWithFormulaComponent(): void
    {
        $service = new EmployeeSalaryService();
        $payload = [
            'effective_from' => '2026-01-01',
            'basic_salary'   => 60000.00,
            'components'     => [
                [
                    'code'             => 'BASIC',
                    'name'             => 'Basic Salary',
                    'type'             => 'earning',
                    'calculation_type' => 'fixed',
                    'rate_or_amount'   => 60000.00,
                    'is_enabled'       => true,
                ],
                [
                    'code'             => 'HRA',
                    'name'             => 'House Rent Allowance',
                    'type'             => 'earning',
                    'calculation_type' => 'formula',
                    'custom_formula'   => 'BASIC * 0.40', // 60,000 * 0.40 = 24,000
                    'rate_or_amount'   => 0.00,
                    'is_enabled'       => true,
                ],
            ],
        ];

        $res = $service->assignSalary($this->empId, $payload, $this->companyId, $this->authorizedActor);
        $this->assertTrue($res['success'], $res['message'] ?? '');

        $db = Database::connect();
        $salaryRow = $db->table('employee_salaries')
            ->where('employee_id', $this->empId)
            ->where('status', 'Active')
            ->get()->getRowArray();

        $this->assertNotNull($salaryRow);
        $this->assertEquals(60000.00, (float)$salaryRow['basic_salary']);
        $this->assertEquals(84000.00, (float)$salaryRow['gross_salary']);

        $empRow = $db->table('employees')->where('id', $this->empId)->get()->getRowArray();
        $this->assertEquals(24000.00, (float)$empRow['house_rent_allowance']);
    }

    /**
     * Test 3: Formulas that reference other evaluated components (variable pool propagation)
     */
    public function testAssignSalaryWithFormulasReferencingOtherComponents(): void
    {
        $service = new EmployeeSalaryService();
        $payload = [
            'effective_from' => '2026-01-01',
            'basic_salary'   => 40000.00,
            'components'     => [
                [
                    'code'             => 'BASIC',
                    'name'             => 'Basic Salary',
                    'type'             => 'earning',
                    'calculation_type' => 'fixed',
                    'rate_or_amount'   => 40000.00,
                    'is_enabled'       => true,
                ],
                [
                    'code'             => 'HRA',
                    'name'             => 'House Rent Allowance',
                    'type'             => 'earning',
                    'calculation_type' => 'fixed',
                    'rate_or_amount'   => 16000.00,
                    'is_enabled'       => true,
                ],
                [
                    'code'             => 'SPECIAL',
                    'name'             => 'Special Allowance',
                    'type'             => 'earning',
                    'calculation_type' => 'formula',
                    'custom_formula'   => '(BASIC + HRA) * 0.20', // (40000 + 16000) * 0.20 = 11200
                    'rate_or_amount'   => 0.00,
                    'is_enabled'       => true,
                ],
            ],
        ];

        $res = $service->assignSalary($this->empId, $payload, $this->companyId, $this->authorizedActor);
        $this->assertTrue($res['success'], $res['message'] ?? '');

        $db = Database::connect();
        $salaryRow = $db->table('employee_salaries')
            ->where('employee_id', $this->empId)
            ->where('status', 'Active')
            ->get()->getRowArray();

        $this->assertNotNull($salaryRow);
        // 40000 + 16000 + 11200 = 67200.00
        $this->assertEquals(67200.00, (float)$salaryRow['gross_salary']);

        $snapshot = json_decode($salaryRow['custom_components_json'], true);
        $specialComp = null;
        foreach ($snapshot['earnings'] as $e) {
            if ($e['code'] === 'SPECIAL') {
                $specialComp = $e;
                break;
            }
        }
        $this->assertNotNull($specialComp);
        $this->assertEquals(11200.00, (float)$specialComp['amount']);
    }

    /**
     * Test 4: Formula with syntax error or division by zero returns 0.00 safely
     */
    public function testAssignSalaryWithFormulaThatErrors(): void
    {
        $service = new EmployeeSalaryService();
        $payload = [
            'effective_from' => '2026-01-01',
            'basic_salary'   => 50000.00,
            'components'     => [
                [
                    'code'             => 'BASIC',
                    'name'             => 'Basic Salary',
                    'type'             => 'earning',
                    'calculation_type' => 'fixed',
                    'rate_or_amount'   => 50000.00,
                    'is_enabled'       => true,
                ],
                [
                    'code'             => 'ERR_COMP',
                    'name'             => 'Error Prone Component',
                    'type'             => 'earning',
                    'calculation_type' => 'formula',
                    'custom_formula'   => 'BASIC / 0', // Division by zero
                    'rate_or_amount'   => 0.00,
                    'is_enabled'       => true,
                ],
            ],
        ];

        $res = $service->assignSalary($this->empId, $payload, $this->companyId, $this->authorizedActor);
        $this->assertTrue($res['success'], $res['message'] ?? '');

        $db = Database::connect();
        $salaryRow = $db->table('employee_salaries')
            ->where('employee_id', $this->empId)
            ->where('status', 'Active')
            ->get()->getRowArray();

        $this->assertNotNull($salaryRow);
        // Division by zero in formula evaluates to 0.00, so gross remains basic salary 50000.00
        $this->assertEquals(50000.00, (float)$salaryRow['gross_salary']);
    }

    /**
     * Test 5: Allowances and Deductions together (asserts gross, total deductions, and net salary)
     */
    public function testAssignSalaryWithAllowancesAndDeductions(): void
    {
        $service = new EmployeeSalaryService();
        $payload = [
            'effective_from' => '2026-01-01',
            'basic_salary'   => 50000.00,
            'components'     => [
                [
                    'code'             => 'BASIC',
                    'name'             => 'Basic Salary',
                    'type'             => 'earning',
                    'calculation_type' => 'fixed',
                    'rate_or_amount'   => 50000.00,
                    'is_enabled'       => true,
                ],
                [
                    'code'             => 'HRA',
                    'name'             => 'House Rent Allowance',
                    'type'             => 'earning',
                    'calculation_type' => 'fixed',
                    'rate_or_amount'   => 20000.00,
                    'is_enabled'       => true,
                ],
                [
                    'code'             => 'CONV',
                    'name'             => 'Conveyance Allowance',
                    'type'             => 'earning',
                    'calculation_type' => 'fixed',
                    'rate_or_amount'   => 5000.00,
                    'is_enabled'       => true,
                ],
                [
                    'code'             => 'DED_PROFTAX',
                    'name'             => 'Professional Tax',
                    'type'             => 'deduction',
                    'calculation_type' => 'fixed',
                    'rate_or_amount'   => 2500.00,
                    'is_enabled'       => true,
                ],
            ],
        ];

        $res = $service->assignSalary($this->empId, $payload, $this->companyId, $this->authorizedActor);
        $this->assertTrue($res['success'], $res['message'] ?? '');

        $db = Database::connect();
        $salaryRow = $db->table('employee_salaries')
            ->where('employee_id', $this->empId)
            ->where('status', 'Active')
            ->get()->getRowArray();

        $this->assertNotNull($salaryRow);
        // Gross = 50000 + 20000 + 5000 = 75000.00
        $this->assertEquals(75000.00, (float)$salaryRow['gross_salary']);
        // Total Deductions = 2500.00
        $this->assertEquals(2500.00, (float)$salaryRow['total_deductions']);
        // Net Salary = 75000 - 2500 = 72500.00
        $this->assertEquals(72500.00, (float)$salaryRow['net_salary']);

        $empRow = $db->table('employees')->where('id', $this->empId)->get()->getRowArray();
        $this->assertEquals(20000.00, (float)$empRow['house_rent_allowance']);
        $this->assertEquals(5000.00, (float)$empRow['conveyance_allowance']);
    }

    /**
     * Test 6: Legacy fields path (no explicit components array, using legacy field inputs)
     */
    public function testAssignSalaryLegacyFieldsPath(): void
    {
        $service = new EmployeeSalaryService();
        $payload = [
            'effective_from'       => '2026-01-01',
            'basic_salary'         => 60000.00,
            'house_rent_value'     => 24000.00,
            'house_rent_type'      => 'fixed',
            'medical_value'        => 4000.00,
            'medical_type'         => 'fixed',
            'conveyance_allowance' => 2000.00,
        ];

        $res = $service->assignSalary($this->empId, $payload, $this->companyId, $this->authorizedActor);
        $this->assertTrue($res['success'], $res['message'] ?? '');

        $db = Database::connect();
        $salaryRow = $db->table('employee_salaries')
            ->where('employee_id', $this->empId)
            ->where('status', 'Active')
            ->get()->getRowArray();

        $this->assertNotNull($salaryRow);
        $this->assertEquals(60000.00, (float)$salaryRow['basic_salary']);
        // Gross = 60000 + 24000 + 4000 + 2000 = 90000.00
        $this->assertEquals(90000.00, (float)$salaryRow['gross_salary']);
        $this->assertEquals(90000.00, (float)$salaryRow['net_salary']);

        $empRow = $db->table('employees')->where('id', $this->empId)->get()->getRowArray();
        $this->assertEquals(60000.00, (float)$empRow['basic_salary']);
        $this->assertEquals(90000.00, (float)$empRow['gross_salary']);
        $this->assertEquals(24000.00, (float)$empRow['house_rent_allowance']);
        $this->assertEquals(4000.00, (float)$empRow['medical_allowance']);
        $this->assertEquals(2000.00, (float)$empRow['conveyance_allowance']);
        $this->assertEquals('CONFIGURED', $empRow['salary_status']);
    }
}
