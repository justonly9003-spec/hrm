<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

/**
 * MobilePayslipPdfApiTest
 *
 * Verifies the mobile payslip PDF endpoint:
 * - Generates and returns genuine %PDF-1.4 binary documents (not HTML under application/pdf)
 * - Content-Type: application/pdf
 * - Content-Disposition header with clean, sanitized filename
 * - Token authentication via MobileAuthFilter (401 for unauthenticated)
 * - Scoping: verified employee and company
 * - Inactive or separated employees are forbidden (403)
 * - Unapproved / Draft payslips are blocked from download (404)
 * - Other employees' payslips and other tenants' payslips are unreachable (404)
 * - Zero leaking of bank numbers, passwords, or document secrets
 */
#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobilePayslipPdfApiTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);

        foreach (['payrolls', 'payroll_items'] as $t) {
            $this->db->query("DROP TABLE IF EXISTS {$t}");
        }

        $this->db->query("CREATE TABLE payrolls (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            payroll_month VARCHAR(10),
            status VARCHAR(20),
            is_locked INT DEFAULT 0
        )");

        $this->db->query("CREATE TABLE payroll_items (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36) NULL,
            payroll_id VARCHAR(36),
            employee_id VARCHAR(36),
            basic_salary DECIMAL(15,2) DEFAULT 0.00,
            gross_salary DECIMAL(15,2) DEFAULT 0.00,
            house_rent DECIMAL(15,2) DEFAULT 0.00,
            medical DECIMAL(15,2) DEFAULT 0.00,
            conveyance DECIMAL(15,2) DEFAULT 0.00,
            allowances DECIMAL(15,2) DEFAULT 0.00,
            other_allowances DECIMAL(15,2) DEFAULT 0.00,
            overtime_amount DECIMAL(15,2) DEFAULT 0.00,
            bonus_amount DECIMAL(15,2) DEFAULT 0.00,
            arrear_amount DECIMAL(15,2) DEFAULT 0.00,
            tax_deduction DECIMAL(15,2) DEFAULT 0.00,
            pf_deduction DECIMAL(15,2) DEFAULT 0.00,
            arrear_pf_deduction DECIMAL(15,2) DEFAULT 0.00,
            loan_emi DECIMAL(15,2) DEFAULT 0.00,
            advance_recovery DECIMAL(15,2) DEFAULT 0.00,
            unpaid_leave_deduction DECIMAL(15,2) DEFAULT 0.00,
            lop_deduction DECIMAL(15,2) DEFAULT 0.00,
            late_penalty DECIMAL(15,2) DEFAULT 0.00,
            other_deductions DECIMAL(15,2) DEFAULT 0.00,
            total_deductions DECIMAL(15,2) DEFAULT 0.00,
            net_salary DECIMAL(15,2) DEFAULT 0.00,
            payment_status VARCHAR(20) DEFAULT 'Unpaid',
            bank_account_no VARCHAR(50) NULL,
            components_breakdown_json TEXT NULL
        )");
    }

    private function insertRows(string $table, array $rows): void
    {
        foreach ($rows as $r) {
            $this->db->table($table)->insert($r);
        }
    }

    private function token(string $company = 'ACME', string $id = 'rahim'): array
    {
        $res = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => $company,
            'identifier'   => $id,
            'password'     => self::PASSWORD,
            'device'       => ['device_uid' => 'dev-payslip-pdf'],
        ]);
        $json = json_decode($res->getJSON(), true);
        return ['Authorization' => 'Bearer ' . $json['data']['tokens']['access_token']];
    }

    private function seedPayslips(): void
    {
        $this->insertRows('payrolls', [
            ['id' => 'pr-sep26', 'company_id' => 'c-1', 'payroll_month' => '2026-09', 'status' => 'Paid', 'is_locked' => 1],
            ['id' => 'pr-draft', 'company_id' => 'c-1', 'payroll_month' => '2026-10', 'status' => 'Draft', 'is_locked' => 0],
            ['id' => 'pr-c2',    'company_id' => 'c-2', 'payroll_month' => '2026-09', 'status' => 'Paid', 'is_locked' => 1],
        ]);

        $this->insertRows('payroll_items', [
            [
                'id' => 'pi-sep26',
                'company_id' => 'c-1',
                'payroll_id' => 'pr-sep26',
                'employee_id' => 'e-1',
                'basic_salary' => 50000.00,
                'gross_salary' => 85000.00,
                'house_rent' => 25000.00,
                'medical' => 10000.00,
                'tax_deduction' => 5000.00,
                'pf_deduction' => 5000.00,
                'total_deductions' => 10000.00,
                'net_salary' => 75000.00,
                'payment_status' => 'Paid',
                'bank_account_no' => '9876543210',
                'components_breakdown_json' => '{"allowances":[{"name":"HRA","amount":25000,"code":"HRA"}],"deductions":[{"name":"PF","amount":5000,"code":"PF"}]}',
            ],
            [
                'id' => 'pi-draft',
                'company_id' => 'c-1',
                'payroll_id' => 'pr-draft',
                'employee_id' => 'e-1',
                'basic_salary' => 50000.00,
                'gross_salary' => 85000.00,
                'total_deductions' => 10000.00,
                'net_salary' => 75000.00,
                'payment_status' => 'Draft',
                'bank_account_no' => '9876543210',
            ],
            [
                'id' => 'pi-c2',
                'company_id' => 'c-2',
                'payroll_id' => 'pr-c2',
                'employee_id' => 'e-2',
                'basic_salary' => 60000.00,
                'gross_salary' => 95000.00,
                'total_deductions' => 5000.00,
                'net_salary' => 90000.00,
                'payment_status' => 'Paid',
                'bank_account_no' => '5555555555',
            ],
        ]);
    }

    public function testUnauthenticatedPdfAccessIsRejected(): void
    {
        $res = $this->get('api/mobile/v1/payslips/pi-sep26/pdf');
        $res->assertStatus(401);

        $res2 = $this->get('api/v1/payroll/payslips/pi-sep26/pdf');
        $res2->assertStatus(401);
    }

    public function testValidPayslipPdfReturnsRealBinaryPdfWithCorrectHeaders(): void
    {
        $this->seedPayslips();
        $token = $this->token();

        $res = $this->withHeaders($token)->get('api/mobile/v1/payslips/pi-sep26/pdf');
        $res->assertStatus(200);

        // Header assertions
        $res->assertHeader('Content-Type', 'application/pdf');
        $this->assertStringContainsString('attachment', $res->response()->getHeaderLine('Content-Disposition'));
        $this->assertStringContainsString('.pdf', $res->response()->getHeaderLine('Content-Disposition'));

        // Binary PDF format verification
        $body = $res->response()->getBody();
        $this->assertStringStartsWith('%PDF-1.4', $body);
        $this->assertStringContainsString('%%EOF', $body);

        // Anti-HTML assertion: MUST NOT serve HTML under application/pdf
        $this->assertStringNotContainsString('<!DOCTYPE html>', $body);
        $this->assertStringNotContainsString('<html', $body);
        $this->assertStringNotContainsString('<body', $body);
        $this->assertStringNotContainsString('<script', $body);

        // Content verification: employee code and net amount present in text stream
        $this->assertStringContainsString('EMP-001', $body);
        $this->assertStringContainsString('75,000.00', $body);
    }

    public function testInlineDispositionHeader(): void
    {
        $this->seedPayslips();
        $token = $this->token();

        $res = $this->withHeaders($token)->get('api/mobile/v1/payslips/pi-sep26/pdf?disposition=inline');
        $res->assertStatus(200);
        $this->assertStringContainsString('inline', $res->response()->getHeaderLine('Content-Disposition'));
    }

    public function testFormatJsonReturnsMetadata(): void
    {
        $this->seedPayslips();
        $token = $this->token();

        $res = $this->withHeaders($token)->get('api/mobile/v1/payslips/pi-sep26/pdf?format=json');
        $res->assertStatus(200);
        $res->assertHeader('Content-Type', 'application/json; charset=UTF-8');

        $json = json_decode($res->getJSON(), true);
        $this->assertTrue($json['success']);
        $this->assertSame('application/pdf', $json['data']['mime_type']);
        $this->assertSame('pi-sep26', $json['data']['payslip_id']);
        $this->assertGreaterThan(0, $json['data']['size_bytes']);
        $this->assertStringContainsString('.pdf', $json['data']['filename']);
    }

    public function testInvalidPayslipIdReturns404(): void
    {
        $this->seedPayslips();
        $token = $this->token();

        $res = $this->withHeaders($token)->get('api/mobile/v1/payslips/nonexistent-id/pdf');
        $res->assertStatus(404);
        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success']);
        $this->assertSame('Payslip not found.', $json['message']);
    }

    public function testDraftPayslipReturns404(): void
    {
        $this->seedPayslips();
        $token = $this->token();

        // Attempting to download draft payslip
        $res = $this->withHeaders($token)->get('api/mobile/v1/payslips/pi-draft/pdf');
        $res->assertStatus(404);
        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success']);
        $this->assertSame('Payslip not found.', $json['message']);
    }

    public function testCrossTenantPayslipAccessReturns404(): void
    {
        $this->seedPayslips();
        $token = $this->token();

        // Rahim (Company c-1) tries to download Karim's payslip in Company c-2
        $res = $this->withHeaders($token)->get('api/mobile/v1/payslips/pi-c2/pdf');
        $res->assertStatus(404);
        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success']);
        $this->assertSame('Payslip not found.', $json['message']);
    }

    public function testIdorQueryParamProtection(): void
    {
        $this->seedPayslips();
        $token = $this->token();

        // Attacker injects employee_id of someone else
        $res1 = $this->withHeaders($token)->get('api/mobile/v1/payslips/pi-sep26/pdf?employee_id=e-2');
        $res1->assertStatus(403);

        // Attacker injects company_id of another tenant
        $res2 = $this->withHeaders($token)->get('api/mobile/v1/payslips/pi-sep26/pdf?company_id=c-2');
        $res2->assertStatus(403);
    }

    public function testSeparatedEmployeeIsForbidden(): void
    {
        $this->seedPayslips();
        $token = $this->token();

        // Terminate employee
        $this->db->table('employees')->where('id', 'e-1')->update(['status' => 'Terminated']);

        $res = $this->withHeaders($token)->get('api/mobile/v1/payslips/pi-sep26/pdf');
        $res->assertStatus(403);
        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success']);
        $this->assertStringContainsString('inactive or separated', $json['message']);
    }

    public function testAliasesResolveIdentically(): void
    {
        $this->seedPayslips();
        $token = $this->token();

        // 1. api/mobile/v1/payslips/(:segment)/pdf
        $r1 = $this->withHeaders($token)->get('api/mobile/v1/payslips/pi-sep26/pdf');
        $r1->assertStatus(200);

        // 2. api/v1/payroll/payslips/(:segment)/pdf
        $r2 = $this->withHeaders($token)->get('api/v1/payroll/payslips/pi-sep26/pdf');
        $r2->assertStatus(200);

        // 3. api/mobile/v1/payroll/payslips/(:segment)/pdf
        $r3 = $this->withHeaders($token)->get('api/mobile/v1/payroll/payslips/pi-sep26/pdf');
        $r3->assertStatus(200);

        // 4. api/v1/payslips/(:segment)/pdf
        $r4 = $this->withHeaders($token)->get('api/v1/payslips/pi-sep26/pdf');
        $r4->assertStatus(200);
    }
}
