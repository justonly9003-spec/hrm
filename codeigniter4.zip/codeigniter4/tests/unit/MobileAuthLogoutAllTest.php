<?php

namespace Tests\Unit;

use App\Services\Mobile\MobileAuthService;
use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobileAuthLogoutAllTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;
    private array $deviceA = ['device_uid' => 'dev-user1-a', 'platform' => 'android', 'device_name' => 'Pixel 8'];
    private array $deviceB = ['device_uid' => 'dev-user1-b', 'platform' => 'ios', 'device_name' => 'iPhone 15'];
    private array $deviceC = ['device_uid' => 'dev-user2-c', 'platform' => 'android', 'device_name' => 'Galaxy S24'];

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);
    }

    private function login(string $company = 'ACME', string $identifier = 'rahim', string $pw = self::PASSWORD, ?array $device = null): array
    {
        $dev = $device ?? $this->deviceA;
        $svc = new MobileAuthService($this->db);
        return $svc->login($company, $identifier, $pw, $dev, '127.0.0.1', 'PHPUnit');
    }

    /**
     * Test 1: Unauthenticated requests to /api/v1/auth/logout-all and /api/mobile/v1/auth/logout-all return 401
     */
    public function testUnauthenticatedRequestsRejected(): void
    {
        // Missing Authorization header
        $res = $this->withBodyFormat('json')->call('post', 'api/v1/auth/logout-all', []);
        $res->assertStatus(401);
        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success'] ?? true);

        // Invalid Bearer token
        $res2 = $this->withHeaders(['Authorization' => 'Bearer mat_invalid_token_xyz'])
            ->withBodyFormat('json')
            ->call('post', 'api/v1/auth/logout-all', []);
        $res2->assertStatus(401);

        // /api/mobile/v1/auth/logout-all alias
        $res3 = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/logout-all', []);
        $res3->assertStatus(401);
    }

    /**
     * Test 2: Multi-device logout-all revokes all access and refresh tokens for the user
     */
    public function testLogoutAllRevokesAllDevicesTokensForUser(): void
    {
        // User 1 logs in from Device A
        $loginA = $this->login('ACME', 'rahim', self::PASSWORD, $this->deviceA);
        $this->assertTrue($loginA['ok'] ?? false);
        $accessA = $loginA['data']['tokens']['access_token'];
        $refreshA = $loginA['data']['tokens']['refresh_token'];

        // User 1 logs in from Device B
        $loginB = $this->login('ACME', 'rahim', self::PASSWORD, $this->deviceB);
        $this->assertTrue($loginB['ok'] ?? false);
        $accessB = $loginB['data']['tokens']['access_token'];
        $refreshB = $loginB['data']['tokens']['refresh_token'];

        // Verify both access tokens are currently valid
        $authSvc = new MobileAuthService($this->db);
        $this->assertTrue($authSvc->authenticate($accessA)['ok'] ?? false);
        $this->assertTrue($authSvc->authenticate($accessB)['ok'] ?? false);

        // Call POST /api/v1/auth/logout-all using Device A's access token
        $res = $this->withHeaders(['Authorization' => "Bearer {$accessA}"])
            ->withBodyFormat('json')
            ->call('post', 'api/v1/auth/logout-all', []);

        $res->assertStatus(200);
        $json = json_decode($res->getJSON(), true);
        $this->assertTrue($json['success'] ?? false);
        $this->assertSame('success', $json['status'] ?? '');
        $this->assertSame('Logged out from all devices successfully.', $json['message'] ?? '');

        // 1. Both access tokens must now fail authentication
        $authCheckA = $authSvc->authenticate($accessA);
        $this->assertFalse($authCheckA['ok'] ?? true);
        $this->assertSame('Invalid or revoked token.', $authCheckA['message'] ?? '');

        $authCheckB = $authSvc->authenticate($accessB);
        $this->assertFalse($authCheckB['ok'] ?? true);
        $this->assertSame('Invalid or revoked token.', $authCheckB['message'] ?? '');

        // 2. Both tokens rejected via API endpoints
        $apiCheckA = $this->withHeaders(['Authorization' => "Bearer {$accessA}"])
            ->call('get', 'api/v1/auth/me');
        $apiCheckA->assertStatus(401);

        $apiCheckB = $this->withHeaders(['Authorization' => "Bearer {$accessB}"])
            ->call('get', 'api/v1/auth/me');
        $apiCheckB->assertStatus(401);
    }

    /**
     * Test 3: Attempting to refresh with any revoked refresh token fails and triggers family revocation
     */
    public function testRefreshAfterLogoutAllIsRejected(): void
    {
        $loginA = $this->login('ACME', 'rahim', self::PASSWORD, $this->deviceA);
        $accessA = $loginA['data']['tokens']['access_token'];
        $refreshA = $loginA['data']['tokens']['refresh_token'];

        $loginB = $this->login('ACME', 'rahim', self::PASSWORD, $this->deviceB);
        $refreshB = $loginB['data']['tokens']['refresh_token'];

        // Logout all
        $res = $this->withHeaders(['Authorization' => "Bearer {$accessA}"])
            ->call('post', 'api/v1/auth/logout-all');
        $res->assertStatus(200);

        // Attempt refresh using Device A refresh token
        $authSvc = new MobileAuthService($this->db);
        $refResA = $authSvc->refresh($refreshA, '127.0.0.1');
        $this->assertFalse($refResA['ok'] ?? true);
        $this->assertSame(401, $refResA['status'] ?? 0);
        $this->assertStringContainsString('Token family revoked', $refResA['message'] ?? '');

        // Attempt refresh using Device B refresh token via API endpoint
        $refApiB = $this->withBodyFormat('json')->call('post', 'api/v1/auth/refresh', [
            'refresh_token' => $refreshB,
        ]);
        $refApiB->assertStatus(401);
        $refJsonB = json_decode($refApiB->getJSON(), true);
        $this->assertStringContainsString('Token family revoked', $refJsonB['message'] ?? '');
    }

    /**
     * Test 4: Cross-user isolation — User 1 logout-all does NOT revoke User 2's tokens
     */
    public function testCrossUserIsolation(): void
    {
        // User 1 (Rahim in ACME)
        $login1 = $this->login('ACME', 'rahim', self::PASSWORD, $this->deviceA);
        $access1 = $login1['data']['tokens']['access_token'];
        $refresh1 = $login1['data']['tokens']['refresh_token'];

        // User 2 (Karim in OTHER)
        $login2 = $this->login('OTHER', 'karim', self::PASSWORD, $this->deviceC);
        $access2 = $login2['data']['tokens']['access_token'];
        $refresh2 = $login2['data']['tokens']['refresh_token'];

        // User 1 calls logout-all (even attempting to pass a spoofed user_id or company_id)
        $res = $this->withHeaders(['Authorization' => "Bearer {$access1}"])
            ->withBodyFormat('json')
            ->call('post', 'api/v1/auth/logout-all', [
                'user_id'    => 'u-2',
                'company_id' => 'c-2',
            ]);
        $res->assertStatus(200);

        $authSvc = new MobileAuthService($this->db);

        // User 1's tokens are revoked
        $this->assertFalse($authSvc->authenticate($access1)['ok'] ?? true);

        // User 2's access token is STILL valid
        $auth2 = $authSvc->authenticate($access2);
        $this->assertTrue($auth2['ok'] ?? false);
        $this->assertSame('u-2', $auth2['data']['user']['id'] ?? '');

        // User 2 can still make authenticated requests
        $api2 = $this->withHeaders(['Authorization' => "Bearer {$access2}"])
            ->call('get', 'api/v1/auth/me');
        $api2->assertStatus(200);
        $api2Json = json_decode($api2->getJSON(), true);
        $this->assertSame('u-2', $api2Json['data']['user_id'] ?? '');

        // User 2 can still refresh tokens normally
        $ref2 = $authSvc->refresh($refresh2, '127.0.0.1');
        $this->assertTrue($ref2['ok'] ?? false);
        $this->assertNotEmpty($ref2['data']['tokens']['access_token'] ?? '');
    }

    /**
     * Test 5: User with must_change_password=1 can still access logout-all without filter trap
     */
    public function testUserWithMustChangePasswordCanLogoutAll(): void
    {
        // Set must_change_password on user 1
        $this->db->table('users')->where('id', 'u-1')->update(['must_change_password' => 1]);

        $login = $this->login('ACME', 'rahim', self::PASSWORD, $this->deviceA);
        $this->assertTrue($login['ok'] ?? false);
        $access = $login['data']['tokens']['access_token'];

        // Calling a protected non-whitelisted endpoint is blocked
        $blocked = $this->withHeaders(['Authorization' => "Bearer {$access}"])
            ->call('get', 'api/v1/profile');
        $blocked->assertStatus(403);
        $blockedJson = json_decode($blocked->getJSON(), true);
        $this->assertSame('PASSWORD_CHANGE_REQUIRED', $blockedJson['error_code'] ?? '');

        // But logout-all IS allowed
        $res = $this->withHeaders(['Authorization' => "Bearer {$access}"])
            ->call('post', 'api/v1/auth/logout-all');
        $res->assertStatus(200);
        $json = json_decode($res->getJSON(), true);
        $this->assertTrue($json['success'] ?? false);

        // And the token is now revoked
        $resAfter = $this->withHeaders(['Authorization' => "Bearer {$access}"])
            ->call('post', 'api/v1/auth/logout-all');
        $resAfter->assertStatus(401);
    }

    /**
     * Test 6: Verify MobileAuthService::logoutAll directly handles clean transactions and returns correct shape
     */
    public function testServiceLogoutAllDirectly(): void
    {
        $loginA = $this->login('ACME', 'rahim', self::PASSWORD, $this->deviceA);
        $loginB = $this->login('ACME', 'rahim', self::PASSWORD, $this->deviceB);

        $authSvc = new MobileAuthService($this->db);
        $result = $authSvc->logoutAll('u-1', 'c-1', '10.0.0.1', 'Mozilla/5.0');

        $this->assertTrue($result['ok']);
        $this->assertTrue($result['success']);
        $this->assertSame(200, $result['status']);
        $this->assertSame('Logged out from all devices successfully.', $result['message']);
        $this->assertEquals((object)[], $result['data']);

        // Check active counts in database
        $activeAccess = $this->db->table('mobile_access_tokens')
            ->where('user_id', 'u-1')
            ->where('revoked_at IS NULL')
            ->countAllResults();
        $this->assertSame(0, $activeAccess);

        $activeRefresh = $this->db->table('mobile_refresh_tokens')
            ->where('user_id', 'u-1')
            ->where('revoked_at IS NULL')
            ->countAllResults();
        $this->assertSame(0, $activeRefresh);
    }
}
