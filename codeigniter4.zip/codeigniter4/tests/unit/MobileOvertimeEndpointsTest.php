<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobileOvertimeEndpointsTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;
    private array $device = ['device_uid' => 'dev-ot-test-1', 'platform' => 'android'];

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);

        foreach ([
            'overtime_records',
            'overtime_claims',
            'overtime_settlement_locks',
            'rule_definitions',
            'rule_change_log',
            'duty_assignments',
            'shifts',
            'holidays'
        ] as $t) {
            $this->db->query("DROP TABLE IF EXISTS {$t}");
        }

        $this->db->query("CREATE TABLE overtime_records (
            id VARCHAR(64) PRIMARY KEY,
            company_id VARCHAR(64) NOT NULL,
            employee_id VARCHAR(64) NOT NULL,
            attendance_log_id VARCHAR(64) NULL,
            policy_id VARCHAR(64) NULL,
            date DATE NOT NULL,
            ot_type VARCHAR(32) NOT NULL DEFAULT 'Normal',
            shift_id VARCHAR(64) NULL,
            shift_start TIME NULL,
            shift_end TIME NULL,
            actual_in TIME NULL,
            actual_out TIME NULL,
            raw_early_minutes INT NOT NULL DEFAULT 0,
            raw_post_minutes INT NOT NULL DEFAULT 0,
            raw_total_minutes INT NOT NULL DEFAULT 0,
            payable_early_minutes INT NOT NULL DEFAULT 0,
            payable_post_minutes INT NOT NULL DEFAULT 0,
            payable_total_minutes INT NOT NULL DEFAULT 0,
            overtime_hours DECIMAL(6,2) NOT NULL DEFAULT 0.00,
            base_salary DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            hourly_rate DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            multiplier DECIMAL(4,2) NOT NULL DEFAULT 1.50,
            ot_rate DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            ot_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            approval_status VARCHAR(32) NOT NULL DEFAULT 'Pending',
            approved_by VARCHAR(64) NULL,
            approved_at DATETIME NULL,
            rejection_reason TEXT NULL,
            is_settled TINYINT(1) NOT NULL DEFAULT 0,
            payroll_id VARCHAR(64) NULL,
            settled_at DATETIME NULL,
            remarks TEXT NULL,
            calculation_metadata_json TEXT NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE overtime_claims (
            id VARCHAR(64) PRIMARY KEY,
            company_id VARCHAR(64) NOT NULL,
            employee_id VARCHAR(64) NOT NULL,
            overtime_record_id VARCHAR(64) NULL,
            date DATE NOT NULL,
            ot_type VARCHAR(32) NOT NULL DEFAULT 'Normal',
            requested_hours DECIMAL(5,2) NOT NULL DEFAULT 0.00,
            approved_hours DECIMAL(5,2) NULL,
            reason TEXT NULL,
            status VARCHAR(32) NOT NULL DEFAULT 'Pending',
            reviewed_by VARCHAR(64) NULL,
            reviewed_at DATETIME NULL,
            rejection_reason TEXT NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE overtime_settlement_locks (
            id VARCHAR(64) PRIMARY KEY,
            company_id VARCHAR(64) NOT NULL,
            payroll_id VARCHAR(64) NOT NULL,
            payroll_month VARCHAR(10) NOT NULL,
            total_records INT NOT NULL DEFAULT 0,
            total_hours DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            total_amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
            locked_by VARCHAR(64) NOT NULL,
            locked_at DATETIME NOT NULL,
            lock_hash VARCHAR(64) NOT NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE rule_definitions (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36) NOT NULL,
            domain VARCHAR(30) NOT NULL,
            scope_level VARCHAR(30) NOT NULL,
            scope_id VARCHAR(36) NULL,
            version_number INT NOT NULL,
            effective_from DATE NOT NULL,
            effective_to DATE NULL,
            status VARCHAR(20) NOT NULL,
            params_json TEXT NOT NULL,
            schema_version INT NOT NULL,
            change_reason TEXT NULL,
            created_by VARCHAR(36) NULL,
            approved_by VARCHAR(36) NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE duty_assignments (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36) NULL,
            branch_id VARCHAR(36) NULL,
            employee_id VARCHAR(36) NOT NULL,
            duty_date DATE NOT NULL,
            shift_id VARCHAR(36) NULL,
            duty_type VARCHAR(30) DEFAULT 'Regular',
            start_time TIME NULL,
            end_time TIME NULL,
            is_overtime_eligible TINYINT(1) DEFAULT 1,
            ot_treatment VARCHAR(30) DEFAULT 'Payable',
            assigned_by VARCHAR(36) NULL,
            assigned_at DATETIME NULL,
            status VARCHAR(20) DEFAULT 'Confirmed',
            remarks TEXT NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        // Seed basic rules for c-1
        $this->seedRules('c-1');
    }

    private function seedRules(string $companyId): void
    {
        // PAYROLL_BASICS rule
        $this->db->table('rule_definitions')->insert([
            'id'             => 'rd-basics-' . $companyId,
            'company_id'     => $companyId,
            'domain'         => 'PAYROLL_BASICS',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2026-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'schema_version' => 1,
            'params_json'    => json_encode([
                'daily_rate_divisor'   => 30.00,
                'standard_daily_hours' => 8.00,
            ]),
            'created_at'     => date('Y-m-d H:i:s'),
        ]);

        // OVERTIME rule
        $this->db->table('rule_definitions')->insert([
            'id'             => 'rd-ot-' . $companyId,
            'company_id'     => $companyId,
            'domain'         => 'OVERTIME',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2026-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'schema_version' => 1,
            'params_json'    => json_encode([
                'divisor_mode'                        => 'Fixed 30 Days',
                'normal_multiplier'                   => 1.50,
                'weekly_off_multiplier'               => 2.00,
                'holiday_multiplier'                  => 2.00,
                'night_multiplier'                    => 1.25,
                'salary_basis'                        => 'Basic Salary',
                'min_ot_unit_minutes'                 => 15,
                'rounding_mode'                       => 'Exact',
                'daily_threshold_hours'               => 1.00,
                'max_daily_ot_hours'                  => 4.00,
                'max_monthly_ot_hours'                => 40.00,
                'enable_early_arrival_ot'             => false,
                'early_arrival_grace_minutes'         => 15,
                'early_arrival_min_threshold_minutes' => 15,
                'post_shift_grace_minutes'            => 15,
                'post_shift_min_threshold_minutes'    => 15,
                'requires_pre_approval'               => false,
                'requires_post_approval'              => false,
                'calculation_method'                  => 'Standard',
                'conflict_policy'                     => 'Highest Rate',
            ]),
            'created_at'     => date('Y-m-d H:i:s'),
        ]);
    }

    private function token(string $company = 'ACME', string $id = 'rahim'): array
    {
        $res = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => $company, 'identifier' => $id, 'password' => self::PASSWORD, 'device' => $this->device,
        ]);
        $json = json_decode($res->getJSON(), true);
        return ['Authorization' => 'Bearer ' . ($json['data']['tokens']['access_token'] ?? '')];
    }

    private function json($res): array
    {
        return json_decode($res->getJSON(), true) ?: [];
    }

    /**
     * Test 1: Records returns only the authenticated employee's records.
     * Records for employee e-2 belonging to company c-2 must never appear.
     */
    public function testRecordsReturnsOnlyAuthenticatedEmployeeRecords(): void
    {
        $token = $this->token('ACME', 'rahim'); // e-1, c-1

        // Insert records for e-1
        $this->db->table('overtime_records')->insert([
            'id'              => 'ot-rec-1',
            'company_id'      => 'c-1',
            'employee_id'     => 'e-1',
            'date'            => '2026-10-10',
            'ot_type'         => 'Normal',
            'overtime_hours'  => 2.50,
            'multiplier'      => 1.50,
            'hourly_rate'     => 150.00,
            'ot_rate'         => 225.00,
            'ot_amount'       => 562.50,
            'approval_status' => 'Approved',
            'is_settled'      => 0,
            'created_at'      => '2026-10-10 18:30:00',
        ]);

        // Insert record for e-2 in c-2 (cross-tenant record)
        $this->db->table('overtime_records')->insert([
            'id'              => 'ot-rec-2',
            'company_id'      => 'c-2',
            'employee_id'     => 'e-2',
            'date'            => '2026-10-10',
            'ot_type'         => 'Normal',
            'overtime_hours'  => 4.00,
            'approval_status' => 'Approved',
            'created_at'      => '2026-10-10 19:00:00',
        ]);

        $res = $this->withHeaders($token)->call('get', 'api/mobile/v1/overtime/records');
        $this->assertEquals(200, $res->response()->getStatusCode());
        $data = $this->json($res);

        $this->assertTrue($data['success']);
        $this->assertEquals(1, $data['data']['count']);
        $this->assertEquals(1, $data['data']['total']);
        $this->assertEquals('ot-rec-1', $data['data']['records'][0]['id']);
        $this->assertEquals('e-1', $data['data']['records'][0]['employee_id']);
        $this->assertEquals(2.5, $data['data']['records'][0]['overtime_hours']);
    }

    /**
     * Test 2: Anti-IDOR and Cross-Tenant access controls.
     * Tampering with employee_id or company_id query params must return 403 Forbidden.
     */
    public function testRecordsCrossTenantAndAntiIdor(): void
    {
        $token = $this->token('ACME', 'rahim'); // e-1, c-1

        // Attempting to inspect e-2 records
        $res = $this->withHeaders($token)->call('get', 'api/mobile/v1/overtime/records?employee_id=e-2');
        $this->assertEquals(403, $res->response()->getStatusCode());
        $data = $this->json($res);
        $this->assertFalse($data['success']);
        $this->assertStringContainsString('Forbidden', $data['message']);

        // Attempting to query cross-tenant company c-2
        $res2 = $this->withHeaders($token)->call('get', 'api/mobile/v1/overtime/records?company_id=c-2');
        $this->assertEquals(403, $res2->response()->getStatusCode());
        $data2 = $this->json($res2);
        $this->assertFalse($data2['success']);
        $this->assertStringContainsString('Cross-tenant', $data2['message']);

        // Passing own employee_id is valid
        $res3 = $this->withHeaders($token)->call('get', 'api/mobile/v1/overtime/records?employee_id=e-1');
        $this->assertEquals(200, $res3->response()->getStatusCode());
    }

    /**
     * Test 3: Date filtering, boundaries, and validation.
     */
    public function testRecordsDateFilteringAndBoundaries(): void
    {
        $token = $this->token('ACME', 'rahim');

        $this->db->table('overtime_records')->insertBatch([
            [
                'id' => 'ot-sep', 'company_id' => 'c-1', 'employee_id' => 'e-1',
                'date' => '2026-09-30', 'ot_type' => 'Normal', 'overtime_hours' => 1.0,
                'approval_status' => 'Approved', 'created_at' => '2026-09-30 18:00:00',
            ],
            [
                'id' => 'ot-oct-1', 'company_id' => 'c-1', 'employee_id' => 'e-1',
                'date' => '2026-10-05', 'ot_type' => 'Normal', 'overtime_hours' => 2.0,
                'approval_status' => 'Approved', 'created_at' => '2026-10-05 18:00:00',
            ],
            [
                'id' => 'ot-oct-2', 'company_id' => 'c-1', 'employee_id' => 'e-1',
                'date' => '2026-10-25', 'ot_type' => 'Holiday', 'overtime_hours' => 3.0,
                'approval_status' => 'Approved', 'created_at' => '2026-10-25 18:00:00',
            ],
            [
                'id' => 'ot-nov', 'company_id' => 'c-1', 'employee_id' => 'e-1',
                'date' => '2026-11-01', 'ot_type' => 'Normal', 'overtime_hours' => 1.5,
                'approval_status' => 'Approved', 'created_at' => '2026-11-01 18:00:00',
            ],
        ]);

        // Filter by month YYYY-MM
        $res = $this->withHeaders($token)->call('get', 'api/mobile/v1/overtime/records?month=2026-10');
        $this->assertEquals(200, $res->response()->getStatusCode());
        $data = $this->json($res);
        $this->assertEquals(2, $data['data']['count']);
        $this->assertEquals(['ot-oct-2', 'ot-oct-1'], array_column($data['data']['records'], 'id'));

        // Filter by strict date range
        $resRange = $this->withHeaders($token)->call('get', 'api/mobile/v1/overtime/records?from=2026-10-01&to=2026-10-10');
        $this->assertEquals(200, $resRange->response()->getStatusCode());
        $dataRange = $this->json($resRange);
        $this->assertEquals(1, $dataRange['data']['count']);
        $this->assertEquals('ot-oct-1', $dataRange['data']['records'][0]['id']);

        // Invalid date ordering from > to -> 422
        $resInvalid = $this->withHeaders($token)->call('get', 'api/mobile/v1/overtime/records?from=2026-10-25&to=2026-10-05');
        $this->assertEquals(422, $resInvalid->response()->getStatusCode());

        // Malformed month -> 422
        $resBadMonth = $this->withHeaders($token)->call('get', 'api/mobile/v1/overtime/records?month=invalid-month');
        $this->assertEquals(422, $resBadMonth->response()->getStatusCode());
    }

    /**
     * Test 4: Status and ot_type filters.
     */
    public function testRecordsStatusAndTypeFilters(): void
    {
        $token = $this->token('ACME', 'rahim');

        $this->db->table('overtime_records')->insertBatch([
            [
                'id' => 'ot-app-norm', 'company_id' => 'c-1', 'employee_id' => 'e-1',
                'date' => '2026-10-02', 'ot_type' => 'Normal', 'overtime_hours' => 2.0,
                'approval_status' => 'Approved', 'created_at' => '2026-10-02 18:00:00',
            ],
            [
                'id' => 'ot-pend-norm', 'company_id' => 'c-1', 'employee_id' => 'e-1',
                'date' => '2026-10-03', 'ot_type' => 'Normal', 'overtime_hours' => 1.5,
                'approval_status' => 'Pending', 'created_at' => '2026-10-03 18:00:00',
            ],
            [
                'id' => 'ot-app-hol', 'company_id' => 'c-1', 'employee_id' => 'e-1',
                'date' => '2026-10-04', 'ot_type' => 'Holiday', 'overtime_hours' => 4.0,
                'approval_status' => 'Approved', 'created_at' => '2026-10-04 18:00:00',
            ],
            [
                'id' => 'ot-rej-norm', 'company_id' => 'c-1', 'employee_id' => 'e-1',
                'date' => '2026-10-05', 'ot_type' => 'Normal', 'overtime_hours' => 3.0,
                'approval_status' => 'Rejected', 'created_at' => '2026-10-05 18:00:00',
            ],
        ]);

        // Filter status=Approved
        $resApp = $this->withHeaders($token)->call('get', 'api/mobile/v1/overtime/records?status=Approved');
        $this->assertEquals(200, $resApp->response()->getStatusCode());
        $dataApp = $this->json($resApp);
        $this->assertEquals(2, $dataApp['data']['count']);
        foreach ($dataApp['data']['records'] as $r) {
            $this->assertEquals('Approved', $r['approval_status']);
        }

        // Filter ot_type=Holiday
        $resHol = $this->withHeaders($token)->call('get', 'api/mobile/v1/overtime/records?ot_type=Holiday');
        $this->assertEquals(200, $resHol->response()->getStatusCode());
        $dataHol = $this->json($resHol);
        $this->assertEquals(1, $dataHol['data']['count']);
        $this->assertEquals('ot-app-hol', $dataHol['data']['records'][0]['id']);
    }

    /**
     * Test 5: Empty results handling returns standard envelope with empty arrays and zero counts.
     */
    public function testRecordsEmptyResultsStructure(): void
    {
        $token = $this->token('ACME', 'rahim');

        $res = $this->withHeaders($token)->call('get', 'api/mobile/v1/overtime/records?month=2025-01');
        $this->assertEquals(200, $res->response()->getStatusCode());
        $data = $this->json($res);

        $this->assertTrue($data['success']);
        $this->assertEquals([], $data['data']['records']);
        $this->assertEquals(0, $data['data']['count']);
        $this->assertEquals(0, $data['data']['total']);
    }

    /**
     * Test 6: Summary calculates accurate aggregations, hours, amounts, and type breakdown.
     */
    public function testSummaryHoursAmountsAndBreakdown(): void
    {
        $token = $this->token('ACME', 'rahim');

        // Insert mix of records in 2026-10
        $this->db->table('overtime_records')->insertBatch([
            [
                'id' => 'ot-sum-1', 'company_id' => 'c-1', 'employee_id' => 'e-1',
                'date' => '2026-10-05', 'ot_type' => 'Normal', 'overtime_hours' => 2.0,
                'ot_amount' => 300.00, 'approval_status' => 'Approved', 'is_settled' => 1,
            ],
            [
                'id' => 'ot-sum-2', 'company_id' => 'c-1', 'employee_id' => 'e-1',
                'date' => '2026-10-12', 'ot_type' => 'Weekly Off', 'overtime_hours' => 3.0,
                'ot_amount' => 600.00, 'approval_status' => 'Approved', 'is_settled' => 0,
            ],
            [
                'id' => 'ot-sum-3', 'company_id' => 'c-1', 'employee_id' => 'e-1',
                'date' => '2026-10-15', 'ot_type' => 'Normal', 'overtime_hours' => 1.5,
                'ot_amount' => 225.00, 'approval_status' => 'Pending', 'is_settled' => 0,
            ],
            [
                'id' => 'ot-sum-4', 'company_id' => 'c-1', 'employee_id' => 'e-1',
                'date' => '2026-10-20', 'ot_type' => 'Holiday', 'overtime_hours' => 4.0,
                'ot_amount' => 800.00, 'approval_status' => 'Rejected', 'is_settled' => 0,
            ],
        ]);

        // Insert a claim
        $this->db->table('overtime_claims')->insert([
            'id'              => 'claim-1',
            'company_id'      => 'c-1',
            'employee_id'     => 'e-1',
            'date'            => '2026-10-18',
            'ot_type'         => 'Normal',
            'requested_hours' => 2.0,
            'approved_hours'  => null,
            'status'          => 'Pending',
        ]);

        $res = $this->withHeaders($token)->call('get', 'api/mobile/v1/overtime/summary?month=2026-10');
        $this->assertEquals(200, $res->response()->getStatusCode());
        $data = $this->json($res);

        $this->assertTrue($data['success']);
        $payload = $data['data'];

        // Period checks
        $this->assertEquals('2026-10', $payload['period']['month']);
        $this->assertEquals('2026-10-01', $payload['period']['from']);
        $this->assertEquals('2026-10-31', $payload['period']['to']);
        $this->assertFalse($payload['period']['is_locked']);

        // Hours checks: Approved = 2.0 + 3.0 = 5.0, Pending = 1.5, Rejected = 4.0, Total = 10.5
        $this->assertEquals(5.0, $payload['hours']['approved_hours']);
        $this->assertEquals(1.5, $payload['hours']['pending_hours']);
        $this->assertEquals(4.0, $payload['hours']['rejected_hours']);
        $this->assertEquals(10.5, $payload['hours']['total_hours']);

        // Amounts checks: Approved = 900.0, Pending = 225.0, Rejected = 800.0, Total = 1925.0
        $this->assertEquals(900.0, $payload['amounts']['approved_amount']);
        $this->assertEquals(225.0, $payload['amounts']['pending_amount']);
        $this->assertEquals(800.0, $payload['amounts']['rejected_amount']);
        $this->assertEquals(1925.0, $payload['amounts']['total_amount']);

        // Records count: Total = 4, Approved = 2, Pending = 1, Rejected = 1, Settled = 1
        $this->assertEquals(4, $payload['records_count']['total']);
        $this->assertEquals(2, $payload['records_count']['approved']);
        $this->assertEquals(1, $payload['records_count']['pending']);
        $this->assertEquals(1, $payload['records_count']['rejected']);
        $this->assertEquals(1, $payload['records_count']['settled']);

        // Breakdown by type
        $this->assertEquals(3.5, $payload['by_type']['Normal']['hours']);
        $this->assertEquals(3.0, $payload['by_type']['Weekly Off']['hours']);
        $this->assertEquals(4.0, $payload['by_type']['Holiday']['hours']);

        // Claims summary
        $this->assertEquals(1, $payload['claims']['total_claims']);
        $this->assertEquals(1, $payload['claims']['pending_claims']);
        $this->assertEquals(2.0, $payload['claims']['requested_hours']);
    }

    /**
     * Test 7: Policy boundaries and monthly overtime cap tracking.
     */
    public function testSummaryPolicyBoundariesAndMonthlyCap(): void
    {
        $token = $this->token('ACME', 'rahim');

        // With monthly cap at 40.0 hours (from seeded OVERTIME rule):
        // Insert 35 approved hours
        $this->db->table('overtime_records')->insert([
            'id'              => 'ot-cap-1',
            'company_id'      => 'c-1',
            'employee_id'     => 'e-1',
            'date'            => '2026-10-05',
            'ot_type'         => 'Normal',
            'overtime_hours'  => 35.0,
            'approval_status' => 'Approved',
        ]);

        $res = $this->withHeaders($token)->call('get', 'api/mobile/v1/overtime/summary?month=2026-10');
        $this->assertEquals(200, $res->response()->getStatusCode());
        $payload = $this->json($res)['data'];

        $this->assertNotNull($payload['policy']);
        $this->assertEquals(40.0, $payload['policy']['max_monthly_ot_hours']);
        $this->assertEquals(4.0, $payload['policy']['max_daily_ot_hours']);
        $this->assertEquals(1.5, $payload['policy']['normal_multiplier']);
        $this->assertEquals(2.0, $payload['policy']['weekly_off_multiplier']);
        $this->assertFalse($payload['policy']['monthly_cap_exceeded']);
        $this->assertEquals(5.0, $payload['policy']['remaining_monthly_hours']);

        // Add 10 more approved hours (now 45 total approved hours, exceeding 40.0)
        $this->db->table('overtime_records')->insert([
            'id'              => 'ot-cap-2',
            'company_id'      => 'c-1',
            'employee_id'     => 'e-1',
            'date'            => '2026-10-10',
            'ot_type'         => 'Normal',
            'overtime_hours'  => 10.0,
            'approval_status' => 'Approved',
        ]);

        $res2 = $this->withHeaders($token)->call('get', 'api/mobile/v1/overtime/summary?month=2026-10');
        $payload2 = $this->json($res2)['data'];

        $this->assertTrue($payload2['policy']['monthly_cap_exceeded']);
        $this->assertEquals(0.0, $payload2['policy']['remaining_monthly_hours']);
    }

    /**
     * Test 8: Settlement Lock status detection.
     */
    public function testSummarySettlementLockStatus(): void
    {
        $token = $this->token('ACME', 'rahim');

        // Lock payroll month 2026-10 for c-1
        $this->db->table('overtime_settlement_locks')->insert([
            'id'            => 'lock-10-2026',
            'company_id'    => 'c-1',
            'payroll_id'    => 'pay-2026-10',
            'payroll_month' => '2026-10',
            'total_records' => 10,
            'total_hours'   => 25.0,
            'total_amount'  => 3750.0,
            'locked_by'     => 'admin',
            'locked_at'     => '2026-10-31 23:59:59',
            'lock_hash'     => hash('sha256', 'lock-payload'),
        ]);

        $res = $this->withHeaders($token)->call('get', 'api/mobile/v1/overtime/summary?month=2026-10');
        $this->assertEquals(200, $res->response()->getStatusCode());
        $payload = $this->json($res)['data'];

        $this->assertTrue($payload['period']['is_locked']);
    }

    /**
     * Test 9: Anti-IDOR and cross-tenant access rejection on summary.
     */
    public function testSummaryCrossTenantAccessBlocked(): void
    {
        $token = $this->token('ACME', 'rahim'); // e-1, c-1

        $res = $this->withHeaders($token)->call('get', 'api/mobile/v1/overtime/summary?employee_id=e-2');
        $this->assertEquals(403, $res->response()->getStatusCode());

        $res2 = $this->withHeaders($token)->call('get', 'api/mobile/v1/overtime/summary?company_id=c-2');
        $this->assertEquals(403, $res2->response()->getStatusCode());
    }

    /**
     * Test 10: Unauthenticated or unlinked employee account is rejected.
     */
    public function testUnauthenticatedAndUnlinkedEmployeeAccess(): void
    {
        // 1. Missing bearer token -> 401
        $res = $this->call('get', 'api/mobile/v1/overtime/records');
        $this->assertEquals(401, $res->response()->getStatusCode());

        // 2. User without linked employee_id
        $this->addUser('u-orphan', 'orphan', 'orphan@acme.test', 'c-1', null, 'r-emp');
        $resLogin = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => 'ACME', 'identifier' => 'orphan', 'password' => self::PASSWORD, 'device' => $this->device,
        ]);
        $json = json_decode($resLogin->getJSON(), true);
        $orphanToken = ['Authorization' => 'Bearer ' . ($json['data']['tokens']['access_token'] ?? '')];

        $resOrphan = $this->withHeaders($orphanToken)->call('get', 'api/mobile/v1/overtime/records');
        $this->assertEquals(403, $resOrphan->response()->getStatusCode());
        $this->assertStringContainsString('No employee profile is linked', $this->json($resOrphan)['message']);
    }

    /**
     * Test 11: Route alias api/v1/overtime/records and summary work identically to api/mobile/v1.
     */
    public function testApiV1RouteAliasConsistency(): void
    {
        $token = $this->token('ACME', 'rahim');

        $this->db->table('overtime_records')->insert([
            'id'              => 'ot-v1-rec',
            'company_id'      => 'c-1',
            'employee_id'     => 'e-1',
            'date'            => '2026-10-15',
            'ot_type'         => 'Normal',
            'overtime_hours'  => 2.0,
            'approval_status' => 'Approved',
        ]);

        $resRec = $this->withHeaders($token)->call('get', 'api/v1/overtime/records?month=2026-10');
        $this->assertEquals(200, $resRec->response()->getStatusCode());
        $this->assertTrue($this->json($resRec)['success']);
        $this->assertEquals(1, $this->json($resRec)['data']['count']);

        $resSum = $this->withHeaders($token)->call('get', 'api/v1/overtime/summary?month=2026-10');
        $this->assertEquals(200, $resSum->response()->getStatusCode());
        $this->assertTrue($this->json($resSum)['success']);
        $this->assertEquals(2.0, $this->json($resSum)['data']['hours']['approved_hours']);
    }
}
