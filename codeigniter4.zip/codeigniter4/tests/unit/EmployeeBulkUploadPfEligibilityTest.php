<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use App\Controllers\Employee\EmployeeController;
use App\Models\EmployeeModel;
use Config\Database;
use CodeIgniter\HTTP\Files\FileCollection;

/**
 * Unit tests verifying Provident Fund (PF) eligibility configuration and processing
 * during Bulk Employee Upload.
 */
class EmployeeBulkUploadPfEligibilityTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected static bool $schemaInitialized = false;

    protected string $tenantCompanyId  = 'comp-bulk-pf-01';
    protected string $tenantBranchId   = 'branch-bulk-pf-01';
    protected string $tenantDeptId     = 'dept-bulk-pf-01';
    protected string $tenantDesgId     = 'desg-bulk-pf-01';
    protected string $tenantEmpTypeId  = 'emptype-bulk-pf-01';
    protected string $tenantShiftId    = 'shift-bulk-pf-01';
    protected string $tenantRoleId     = 'role-bulk-pf-01';

    protected array $adminUser = [];
    protected array $tempFiles = [];

    public static function setUpBeforeClass(): void
    {
        parent::setUpBeforeClass();
        static::ensureSchema();
    }

    public static function registerSqliteFunctions($db): void
    {
        try {
            $rawConn = $db->connID ?? null;
            if ($rawConn instanceof \SQLite3) {
                $rawConn->createFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->createFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            } elseif (is_object($rawConn) && method_exists($rawConn, 'sqliteCreateFunction')) {
                $rawConn->sqliteCreateFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->sqliteCreateFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            }
        } catch (\Throwable $e) {
            // ignore
        }
    }

    protected static function ensureSchema(): void
    {
        $db = Database::connect();
        static::registerSqliteFunctions($db);

        $schemaFile = __DIR__ . '/Rules/schema.sqlite.sql';
        if (file_exists($schemaFile)) {
            $sql = file_get_contents($schemaFile);
            $statements = array_filter(array_map('trim', explode(';', $sql)));
            foreach ($statements as $stmt) {
                if (!empty($stmt)) {
                    try {
                        $db->query($stmt);
                    } catch (\Throwable $e) {
                        // ignore
                    }
                }
            }
        }

        // Ensure employee_pf_eligibility_periods table exists
        try {
            $db->query("CREATE TABLE IF NOT EXISTS employee_pf_eligibility_periods (
                id VARCHAR(36) PRIMARY KEY,
                employee_id VARCHAR(36) NOT NULL,
                company_id VARCHAR(36) NOT NULL,
                status VARCHAR(20) NOT NULL,
                effective_from DATE NOT NULL,
                effective_to DATE NULL,
                reason TEXT NULL,
                created_by VARCHAR(36) NULL,
                created_at DATETIME NULL,
                updated_at DATETIME NULL
            )");
        } catch (\Throwable $e) {
            // ignore
        }
    }

    protected function setUp(): void
    {
        parent::setUp();
        static::ensureSchema();

        $db = Database::connect();
        static::registerSqliteFunctions($db);

        // Seed tenant company
        $db->table('companies')->replace([
            'id'     => $this->tenantCompanyId,
            'name'   => 'PF Bulk Test Company',
            'code'   => 'COMP-PF-01',
            'status' => 'Active',
        ]);

        // Seed branch, department, designation, employment type, shift
        $db->table('branches')->replace([
            'id'         => $this->tenantBranchId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'PF Branch',
            'code'       => 'BR-PF',
            'status'     => 'Active',
        ]);

        $db->table('departments')->replace([
            'id'         => $this->tenantDeptId,
            'company_id' => $this->tenantCompanyId,
            'branch_id'  => $this->tenantBranchId,
            'name'       => 'Accounts',
            'code'       => 'ACC',
            'status'     => 'Active',
        ]);

        $db->table('designations')->replace([
            'id'            => $this->tenantDesgId,
            'company_id'    => $this->tenantCompanyId,
            'department_id' => $this->tenantDeptId,
            'name'          => 'Accountant',
            'code'          => 'ACCT',
            'status'        => 'Active',
        ]);

        $db->table('employment_types')->replace([
            'id'         => $this->tenantEmpTypeId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'Permanent',
            'code'       => 'PERM',
            'status'     => 'Active',
        ]);

        $db->table('shifts')->replace([
            'id'         => $this->tenantShiftId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'General Shift',
            'start_time' => '09:00:00',
            'end_time'   => '17:00:00',
            'status'     => 'Active',
        ]);

        $db->table('roles')->replace([
            'id'         => $this->tenantRoleId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'Employee',
            'code'       => 'employee',
            'status'     => 'Active',
        ]);

        // Seed company admin user
        $this->adminUser = [
            'id'                  => 'usr-bulk-pf-admin-01',
            'company_id'          => $this->tenantCompanyId,
            'username'            => 'pf_bulk_admin',
            'name'                => 'PF Bulk Admin',
            'email'               => 'pf_admin@test.com',
            'role'                => 'Company Admin',
            'role_code'           => 'company_admin',
            'role_id'             => 'role-bulk-pf-admin',
            'selected_company_id' => $this->tenantCompanyId,
            'permissions'         => ['*'],
        ];

        $db->table('users')->replace([
            'id'            => $this->adminUser['id'],
            'company_id'    => $this->tenantCompanyId,
            'username'      => $this->adminUser['username'],
            'email'         => $this->adminUser['email'],
            'password_hash' => password_hash('Secret123!', PASSWORD_BCRYPT),
            'role_id'       => $this->adminUser['role_id'],
            'status'        => 'Active',
        ]);
    }

    protected function tearDown(): void
    {
        foreach ($this->tempFiles as $f) {
            if (file_exists($f)) {
                @unlink($f);
            }
        }
        $this->tempFiles = [];
        parent::tearDown();
    }

    protected function setupController(?array $jsonPayload = null): EmployeeController
    {
        $session = \Config\Services::session();
        $session->set('user', [
            'id'                  => $this->adminUser['id'],
            'username'            => $this->adminUser['username'],
            'name'                => $this->adminUser['name'],
            'email'               => $this->adminUser['email'],
            'role'                => $this->adminUser['role'],
            'role_code'           => $this->adminUser['role_code'],
            'role_id'             => $this->adminUser['role_id'],
            'company_id'          => $this->adminUser['company_id'],
            'selected_company_id' => $this->adminUser['company_id'],
            'permissions'         => ['*'],
        ]);

        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_SERVER['HTTP_ACCEPT'] = 'application/json';
        $_SERVER['HTTP_X_REQUESTED_WITH'] = 'xmlhttprequest';
        $_POST = [];
        $_FILES = [];

        $request = \Config\Services::request();
        $response = \Config\Services::response();
        $logger = \Config\Services::logger();

        $refReqFiles = new \ReflectionProperty($request, 'files');
        $refReqFiles->setAccessible(true);
        $refReqFiles->setValue($request, null);

        if (!empty($jsonPayload)) {
            $rawJson = json_encode($jsonPayload);
            $refBody = new \ReflectionProperty($request, 'body');
            $refBody->setAccessible(true);
            $refBody->setValue($request, $rawJson);
        } else {
            $refBody = new \ReflectionProperty($request, 'body');
            $refBody->setAccessible(true);
            $refBody->setValue($request, '');
        }

        $controller = new EmployeeController();
        $controller->initController($request, $response, $logger);

        return $controller;
    }

    /**
     * Test 1: downloadBulkTemplate includes 'PF Eligible' in headers and 'Yes' in sample rows.
     */
    public function testDownloadBulkTemplateIncludesPfEligible(): void
    {
        $controller = $this->setupController();
        $res = $controller->downloadBulkTemplate();
        $csv = $res->getBody();

        $this->assertStringContainsString('PF Eligible', $csv);
        $this->assertStringContainsString('Yes', $csv);
    }

    /**
     * Test 2: Bulk upload with explicit PF Eligible = 'Yes' (or '1') enrolls employee into PF
     * and records an active period in employee_pf_eligibility_periods.
     */
    public function testBulkUploadWithPfEligibleEnrollsEmployee(): void
    {
        $payload = [
            'rows' => [
                [
                    'name'          => 'Eligible PF Employee',
                    'employee_code' => 'EMP-PF-YES-01',
                    'email'         => 'pf_yes@example.com',
                    'gender'        => 'female',
                    'dob'           => '1992-04-10',
                    'department'    => 'Accounts',
                    'designation'   => 'Accountant',
                    'employee_type' => 'Permanent',
                    'join_date'     => '2024-02-01',
                    'pf_eligible'   => 'Yes',
                ]
            ]
        ];

        $controller = $this->setupController($payload);
        $res = $controller->bulkUpload();
        $body = json_decode($res->getBody(), true);

        $this->assertTrue($body['success']);
        $this->assertEquals(1, $body['data']['created_count']);
        $this->assertEquals('Eligible', $body['data']['results'][0]['pf_eligible']);
        $this->assertEquals('Enrolled', $body['data']['results'][0]['pf_status']);

        // Verify in DB
        $db = Database::connect();
        $emp = $db->table('employees')->where('employee_code', 'EMP-PF-YES-01')->get()->getRowArray();
        $this->assertNotNull($emp);
        $this->assertEquals(1, (int)$emp['is_pf_applicable']);
        $this->assertEquals('Enrolled', $emp['pf_status']);
        $this->assertNotEmpty($emp['pf_member_id']);
        $this->assertEquals('2024-02-01', $emp['pf_effective_date']);

        // Check eligibility period
        $period = $db->table('employee_pf_eligibility_periods')
            ->where('employee_id', $emp['id'])
            ->get()->getRowArray();
        if ($period !== null) {
            $this->assertEquals('Eligible', $period['status']);
            $this->assertEquals('2024-02-01', $period['effective_from']);
        }
    }

    /**
     * Test 3: Bulk upload with explicit PF Eligible = 'No' (or '0') marks employee as Not Enrolled.
     */
    public function testBulkUploadWithPfNotEligibleMarksNotEnrolled(): void
    {
        $payload = [
            'rows' => [
                [
                    'name'          => 'Non-Eligible PF Employee',
                    'employee_code' => 'EMP-PF-NO-01',
                    'email'         => 'pf_no@example.com',
                    'gender'        => 'male',
                    'dob'           => '1994-08-15',
                    'department'    => 'Accounts',
                    'designation'   => 'Accountant',
                    'employee_type' => 'Permanent',
                    'join_date'     => '2024-03-01',
                    'pf_eligible'   => '0',
                ]
            ]
        ];

        $controller = $this->setupController($payload);
        $res = $controller->bulkUpload();
        $body = json_decode($res->getBody(), true);

        $this->assertTrue($body['success']);
        $this->assertEquals(1, $body['data']['created_count']);
        $this->assertEquals('Not Eligible', $body['data']['results'][0]['pf_eligible']);
        $this->assertEquals('Not Enrolled', $body['data']['results'][0]['pf_status']);

        // Verify in DB
        $db = Database::connect();
        $emp = $db->table('employees')->where('employee_code', 'EMP-PF-NO-01')->get()->getRowArray();
        $this->assertNotNull($emp);
        $this->assertEquals(0, (int)$emp['is_pf_applicable']);
        $this->assertEquals('Not Enrolled', $emp['pf_status']);
    }

    /**
     * Test 4: Bulk upload with PF Eligible = 'exempt' marks employee as Exempt with statutory reason.
     */
    public function testBulkUploadWithPfExempt(): void
    {
        $payload = [
            'rows' => [
                [
                    'name'          => 'Exempt PF Employee',
                    'employee_code' => 'EMP-PF-EXEMPT-01',
                    'email'         => 'pf_exempt@example.com',
                    'gender'        => 'female',
                    'dob'           => '1989-11-20',
                    'department'    => 'Accounts',
                    'designation'   => 'Accountant',
                    'employee_type' => 'Permanent',
                    'join_date'     => '2024-04-01',
                    'pf_eligible'   => 'exempt',
                ]
            ]
        ];

        $controller = $this->setupController($payload);
        $res = $controller->bulkUpload();
        $body = json_decode($res->getBody(), true);

        $this->assertTrue($body['success']);
        $this->assertEquals(1, $body['data']['created_count']);
        $this->assertEquals('Exempt', $body['data']['results'][0]['pf_eligible']);
        $this->assertEquals('Exempt', $body['data']['results'][0]['pf_status']);

        // Verify in DB
        $db = Database::connect();
        $emp = $db->table('employees')->where('employee_code', 'EMP-PF-EXEMPT-01')->get()->getRowArray();
        $this->assertNotNull($emp);
        $this->assertEquals(0, (int)$emp['is_pf_applicable']);
        $this->assertEquals('Exempt', $emp['pf_status']);
    }

    /**
     * Test 5: Default PF eligibility fallback strategy when omitted in raw rows.
     */
    public function testBulkUploadDefaultPfStrategyWhenOmitted(): void
    {
        // When default_pf_eligible is false
        $payload = [
            'default_pf_eligible' => false,
            'rows' => [
                [
                    'name'          => 'Default Non-PF Employee',
                    'employee_code' => 'EMP-PF-DEF-01',
                    'email'         => 'pf_def@example.com',
                    'gender'        => 'male',
                    'dob'           => '1991-05-12',
                    'department'    => 'Accounts',
                    'designation'   => 'Accountant',
                    'employee_type' => 'Permanent',
                    'join_date'     => '2024-01-15',
                ]
            ]
        ];

        $controller = $this->setupController($payload);
        $res = $controller->bulkUpload();
        $body = json_decode($res->getBody(), true);

        $this->assertTrue($body['success']);
        $this->assertEquals('Not Eligible', $body['data']['results'][0]['pf_eligible']);
        $this->assertEquals('Not Enrolled', $body['data']['results'][0]['pf_status']);

        $db = Database::connect();
        $emp = $db->table('employees')->where('employee_code', 'EMP-PF-DEF-01')->get()->getRowArray();
        $this->assertEquals(0, (int)$emp['is_pf_applicable']);
    }
}
