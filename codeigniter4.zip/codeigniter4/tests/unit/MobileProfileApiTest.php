<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

/**
 * MobileProfileApiTest
 *
 * Verifies the authenticated employee profile and details endpoint for the ESS mobile app:
 * - Route resolution: GET /api/v1/profile, GET /api/v1/profile/details, and mobile/v1 aliases
 * - Token authentication and identity resolution
 * - Strict tenant scoping and cross-tenant isolation
 * - Exclusion of sensitive salary, banking, tax, and security fields
 * - Safe handling of missing profiles and inactive accounts
 * - Standard JSON response envelope compliance
 */
#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobileProfileApiTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;
    private array $device = ['device_uid' => 'dev-prof-test', 'platform' => 'android'];

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);

        // Emergency contacts table for testing emergency contacts integration
        $this->db->query("DROP TABLE IF EXISTS employee_emergency_contacts");
        $this->db->query("CREATE TABLE employee_emergency_contacts (
            id VARCHAR(36) PRIMARY KEY,
            employee_id VARCHAR(36),
            name VARCHAR(100),
            relationship VARCHAR(50),
            phone VARCHAR(50),
            alternate_phone VARCHAR(50) NULL,
            address VARCHAR(255) NULL,
            primary_contact INT DEFAULT 1,
            created_at DATETIME NULL
        )");

        // Set departments, designations, branches for Rahim (e-1)
        $this->db->table('departments')->insert(['id' => 'dept-1', 'name' => 'Engineering']);
        $this->db->table('designations')->insert(['id' => 'desig-1', 'name' => 'Software Engineer']);
        $this->db->table('branches')->insert(['id' => 'br-1', 'name' => 'Dhaka HQ']);

        $this->db->table('employees')->where('id', 'e-1')->update([
            'department_id'  => 'dept-1',
            'designation_id' => 'desig-1',
            'branch_id'      => 'br-1',
            'email'          => 'rahim@acme.test',
            'phone'          => '+8801700000001',
            'joining_date'   => '2023-01-15',
            'basic_salary'   => 50000.00,
            'gross_salary'   => 80000.00,
        ]);
    }

    private function login(string $company = 'ACME', string $identifier = 'rahim'): string
    {
        $res = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => $company,
            'identifier'   => $identifier,
            'password'     => self::PASSWORD,
            'device'       => $this->device,
        ]);
        $res->assertStatus(200);
        $json = json_decode($res->getJSON(), true);
        return $json['data']['tokens']['access_token'];
    }

    public function testProfileRejectsUnauthenticatedRequests(): void
    {
        $endpoints = [
            'api/v1/profile',
            'api/v1/profile/details',
            'api/mobile/v1/profile',
            'api/mobile/v1/profile/details',
        ];

        foreach ($endpoints as $endpoint) {
            // Missing Authorization header
            $res = $this->get($endpoint);
            $res->assertStatus(401);
            $json = json_decode($res->getJSON(), true);
            $this->assertFalse($json['success']);

            // Invalid / forged Bearer token
            $resBad = $this->withHeaders(['Authorization' => 'Bearer forged_token_12345'])->get($endpoint);
            $resBad->assertStatus(401);
            $jsonBad = json_decode($resBad->getJSON(), true);
            $this->assertFalse($jsonBad['success']);
        }
    }

    public function testValidAccessReturnsAuthorizedProfileStructure(): void
    {
        $token = $this->login('ACME', 'rahim');

        foreach (['api/v1/profile', 'api/v1/profile/details', 'api/mobile/v1/profile', 'api/mobile/v1/profile/details'] as $endpoint) {
            $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])->get($endpoint);
            $res->assertStatus(200);

            $payload = json_decode($res->getJSON(), true);
            $this->assertTrue($payload['success']);
            $this->assertSame('success', $payload['status']);
            $this->assertSame('Employee profile retrieved successfully.', $payload['message']);

            $data = $payload['data'];
            $this->assertIsArray($data);
            $this->assertArrayHasKey('profile', $data);
            $this->assertArrayHasKey('employee', $data);
            $this->assertArrayHasKey('company', $data);
            $this->assertArrayHasKey('user', $data);
            $this->assertSame('employee', $data['role_code']);

            $profile = $data['profile'];
            $this->assertSame('e-1', $profile['id']);
            $this->assertSame('EMP-001', $profile['employee_code']);
            $this->assertSame('Rahim', $profile['first_name']);
            $this->assertSame('Uddin', $profile['last_name']);
            $this->assertSame('Rahim Uddin', $profile['full_name']);
            $this->assertSame('rahim@acme.test', $profile['email']);
            $this->assertSame('+8801700000001', $profile['phone']);
            $this->assertSame('2023-01-15', $profile['joining_date']);
            $this->assertSame('Active', $profile['status']);
            $this->assertSame('Active', $profile['status_label']);
            $this->assertSame('Engineering', $profile['department']);
            $this->assertSame('Engineering', $profile['department_name']);
            $this->assertSame('Software Engineer', $profile['designation']);
            $this->assertSame('Software Engineer', $profile['designation_name']);
            $this->assertSame('Dhaka HQ', $profile['branch']);
            $this->assertSame('Dhaka HQ', $profile['branch_name']);

            $company = $data['company'];
            $this->assertSame('c-1', $company['id']);
            $this->assertSame('ACME', $company['code']);
            $this->assertSame('Acme Ltd', $company['name']);

            $user = $data['user'];
            $this->assertSame('u-1', $user['id']);
            $this->assertSame('rahim', $user['username']);
            $this->assertSame('active', $user['status']);
        }
    }

    public function testSensitiveDataIsStrictlyExcluded(): void
    {
        $token = $this->login('ACME', 'rahim');
        $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])->get('api/v1/profile');
        $res->assertStatus(200);

        $payload = json_decode($res->getJSON(), true);
        $data = $payload['data'];
        $profile = $data['profile'];
        $user = $data['user'];

        $forbiddenKeys = [
            'basic_salary',
            'gross_salary',
            'salary_grade_id',
            'salary_status',
            'bank_account',
            'bank_name',
            'tax_identification_number',
            'tin_no',
            'password',
            'password_hash',
            'failed_logins',
            'locked_until',
            'token_hash',
        ];

        foreach ($forbiddenKeys as $key) {
            $this->assertArrayNotHasKey($key, $profile, "Profile must not contain sensitive field: {$key}");
            $this->assertArrayNotHasKey($key, $data['employee'], "Employee alias must not contain sensitive field: {$key}");
            $this->assertArrayNotHasKey($key, $user, "User context must not contain sensitive field: {$key}");
            $this->assertArrayNotHasKey($key, $data, "Root data must not contain sensitive field: {$key}");
        }
    }

    public function testReportingManagerAndEmergencyContacts(): void
    {
        // 1. Add manager employee record
        $this->db->table('employees')->insert([
            'id'            => 'e-mgr',
            'company_id'    => 'c-1',
            'employee_code' => 'MGR-001',
            'first_name'    => 'Tariq',
            'last_name'     => 'Hasan',
            'email'         => 'tariq@acme.test',
            'phone'         => '+8801799999999',
            'status'        => 'Active',
        ]);

        // Link manager to Rahim
        $this->db->table('employees')->where('id', 'e-1')->update([
            'reporting_manager_id' => 'e-mgr',
        ]);

        // 2. Add emergency contact
        $this->db->table('employee_emergency_contacts')->insert([
            'id'              => 'emg-1',
            'employee_id'     => 'e-1',
            'name'            => 'Fatima Begum',
            'relationship'    => 'Spouse',
            'phone'           => '+8801711111111',
            'alternate_phone' => '+8801722222222',
            'address'         => 'House 12, Road 4, Dhanmondi, Dhaka',
            'primary_contact' => 1,
            'created_at'      => date('Y-m-d H:i:s'),
        ]);

        $token = $this->login('ACME', 'rahim');
        $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])->get('api/v1/profile');
        $res->assertStatus(200);

        $data = json_decode($res->getJSON(), true)['data'];

        $this->assertNotNull($data['reporting_manager']);
        $this->assertSame('e-mgr', $data['reporting_manager']['id']);
        $this->assertSame('Tariq Hasan', $data['reporting_manager']['name']);
        $this->assertSame('MGR-001', $data['reporting_manager']['employee_code']);
        $this->assertSame('tariq@acme.test', $data['reporting_manager']['email']);
        $this->assertSame('+8801799999999', $data['reporting_manager']['phone']);

        $this->assertCount(1, $data['emergency_contacts']);
        $this->assertSame('Fatima Begum', $data['emergency_contacts'][0]['name']);
        $this->assertSame('Spouse', $data['emergency_contacts'][0]['relationship']);
        $this->assertSame('+8801711111111', $data['emergency_contacts'][0]['phone']);
    }

    public function testMissingEmployeeProfileReturns404(): void
    {
        // Add a user without an employee record
        $this->addUser('u-no-emp', 'noemp', 'noemp@acme.test', 'c-1', null, 'r-emp');
        $tokenNoEmp = $this->login('ACME', 'noemp');

        $res = $this->withHeaders(['Authorization' => "Bearer {$tokenNoEmp}"])->get('api/v1/profile');
        $res->assertStatus(404);
        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success']);
        $this->assertSame('error', $json['status']);
        $this->assertSame('Employee profile not found.', $json['message']);
    }

    public function testInactiveOrSeparatedEmployeeReturns403(): void
    {
        $token = $this->login('ACME', 'rahim');

        // Test with Terminated
        $this->db->table('employees')->where('id', 'e-1')->update(['status' => 'Terminated']);
        $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])->get('api/v1/profile');
        $res->assertStatus(403);
        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success']);
        $this->assertSame('Employee profile is inactive or separated.', $json['message']);

        // Test with Inactive
        $this->db->table('employees')->where('id', 'e-1')->update(['status' => 'Inactive']);
        $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])->get('api/v1/profile');
        $res->assertStatus(403);

        // Test with Resigned
        $this->db->table('employees')->where('id', 'e-1')->update(['status' => 'Resigned']);
        $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])->get('api/v1/profile');
        $res->assertStatus(403);

        // Restore to Active succeeds
        $this->db->table('employees')->where('id', 'e-1')->update(['status' => 'Active']);
        $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])->get('api/v1/profile');
        $res->assertStatus(200);
    }

    public function testInactiveUserAccountReturns403(): void
    {
        $token = $this->login('ACME', 'rahim');

        // Mark user account as inactive
        $this->db->table('users')->where('id', 'u-1')->update(['status' => 'inactive']);

        $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])->get('api/v1/profile');
        $this->assertTrue(in_array($res->response()->getStatusCode(), [401, 403], true));
        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success']);
    }

    public function testCrossTenantIsolationAndSpoofingPrevention(): void
    {
        $tokenA = $this->login('ACME', 'rahim');
        $tokenB = $this->login('OTHER', 'karim');

        // Tenant A request
        $resA = $this->withHeaders(['Authorization' => "Bearer {$tokenA}"])->get('api/v1/profile');
        $resA->assertStatus(200);
        $dataA = json_decode($resA->getJSON(), true)['data'];
        $this->assertSame('c-1', $dataA['company']['id']);
        $this->assertSame('ACME', $dataA['company']['code']);
        $this->assertSame('e-1', $dataA['profile']['id']);
        $this->assertSame('Rahim', $dataA['profile']['first_name']);

        // Tenant A attempts to spoof another employee_id or company_id via query params
        $resSpoof = $this->withHeaders(['Authorization' => "Bearer {$tokenA}"])
            ->get('api/v1/profile?employee_id=e-2&company_id=c-2');
        $resSpoof->assertStatus(200);
        $dataSpoof = json_decode($resSpoof->getJSON(), true)['data'];
        $this->assertSame('c-1', $dataSpoof['company']['id']);
        $this->assertSame('e-1', $dataSpoof['profile']['id']);
        $this->assertSame('Rahim', $dataSpoof['profile']['first_name']);

        // Tenant B request
        $resB = $this->withHeaders(['Authorization' => "Bearer {$tokenB}"])->get('api/v1/profile');
        $resB->assertStatus(200);
        $dataB = json_decode($resB->getJSON(), true)['data'];
        $this->assertSame('c-2', $dataB['company']['id']);
        $this->assertSame('OTHER', $dataB['company']['code']);
        $this->assertSame('e-2', $dataB['profile']['id']);
        $this->assertSame('Karim', $dataB['profile']['first_name']);
    }
}
