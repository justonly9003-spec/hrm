<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use App\Models\EmployeeModel;
use Config\Database;

/**
 * Tests for Employee Directory Search, Scoping Leaks, and Tenant Boundaries
 *
 * Requirements:
 * 1. Full-name search: "john smith", "smith john", and "EMP-JS-01" match John Smith.
 * 2. Search escaping: "john_doe" matches only John Smith (not Jane Roe or Johnny Smithson);
 *    "john_doe@example.com" matches John Smith.
 * 3. Wildcard escaping: "%" matches nothing (or only literal %), not everything;
 *    "_" does not match everything.
 * 4. Client-side matchesSearch: matchesSearch in views/employees/index.php behaves the same for terms with _ and %.
 * 5. Scoping leaks: branch_manager with no session branch fails closed (1 = 0) and sees nothing.
 * 6. Non-admin with no company: Shows a friendly empty directory page instead of throwing RuntimeException (500).
 * 7. Managers dropdown scoping: Scoped to tenant/branch and capped at 500.
 */
class EmployeeDirectorySearchAndScopingTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected static bool $schemaInitialized = false;

    protected string $tenantCompanyId = 'comp-search-test-01';
    protected string $tenantBranchId  = 'branch-search-test-01';
    protected string $tenantDeptId    = 'dept-search-test-01';
    protected string $tenantDesgId    = 'desg-search-test-01';

    protected string $empJohnId    = 'emp-search-john-01';
    protected string $empJaneId    = 'emp-search-jane-02';
    protected string $empJohnnyId  = 'emp-search-johnny-03';

    public static function setUpBeforeClass(): void
    {
        parent::setUpBeforeClass();
        static::ensureSchema();
    }

    public static function registerSqliteFunctions($db): void
    {
        try {
            $rawConn = $db->connID ?? null;
            if ($rawConn instanceof \SQLite3) {
                $rawConn->createFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->createFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            } elseif (is_object($rawConn) && method_exists($rawConn, 'sqliteCreateFunction')) {
                $rawConn->sqliteCreateFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->sqliteCreateFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            }
        } catch (\Throwable $e) {
            // ignore if not sqlite or already registered
        }
    }

    protected static function ensureSchema(): void
    {
        $db = Database::connect();
        static::registerSqliteFunctions($db);

        $schemaFile = __DIR__ . '/Rules/schema.sqlite.sql';
        if (file_exists($schemaFile)) {
            $sql = file_get_contents($schemaFile);
            $statements = array_filter(array_map('trim', explode(';', $sql)));
            foreach ($statements as $stmt) {
                if (!empty($stmt)) {
                    try {
                        $db->query($stmt);
                    } catch (\Throwable $e) {
                        // ignore if already exists
                    }
                }
            }
        }

        static::$schemaInitialized = true;
    }

    protected function setUp(): void
    {
        parent::setUp();
        static::ensureSchema();

        $db = Database::connect();
        static::registerSqliteFunctions($db);

        // Seed tenant records
        $db->table('companies')->replace([
            'id'     => $this->tenantCompanyId,
            'name'   => 'Search Corp',
            'code'   => 'SCORP',
            'status' => 'Active',
        ]);

        $db->table('branches')->replace([
            'id'         => $this->tenantBranchId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'Main Branch',
            'code'       => 'BR-MAIN',
            'status'     => 'Active',
        ]);

        $db->table('departments')->replace([
            'id'         => $this->tenantDeptId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'Engineering',
            'code'       => 'DEP-ENG',
            'status'     => 'Active',
        ]);

        $db->table('designations')->replace([
            'id'         => $this->tenantDesgId,
            'company_id' => $this->tenantCompanyId,
            'name'       => 'Software Developer',
            'code'       => 'DES-DEV',
            'status'     => 'Active',
        ]);

        // Clean up previous test employees
        $db->table('employees')->whereIn('id', [$this->empJohnId, $this->empJaneId, $this->empJohnnyId])->delete();

        // Seed required employees:
        // 1. "John Smith" (john_doe@example.com)
        $db->table('employees')->insert([
            'id'            => $this->empJohnId,
            'company_id'    => $this->tenantCompanyId,
            'branch_id'     => $this->tenantBranchId,
            'department_id' => $this->tenantDeptId,
            'designation_id'=> $this->tenantDesgId,
            'employee_code' => 'EMP-JS-01',
            'first_name'    => 'John',
            'last_name'     => 'Smith',
            'email'         => 'john_doe@example.com',
            'phone'         => '+8801700000001',
            'status'        => 'Active',
            'joining_date'  => '2025-01-01',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);

        // 2. "Jane Roe" (jane.roe@example.com)
        $db->table('employees')->insert([
            'id'            => $this->empJaneId,
            'company_id'    => $this->tenantCompanyId,
            'branch_id'     => $this->tenantBranchId,
            'department_id' => $this->tenantDeptId,
            'designation_id'=> $this->tenantDesgId,
            'employee_code' => 'EMP-JR-02',
            'first_name'    => 'Jane',
            'last_name'     => 'Roe',
            'email'         => 'jane.roe@example.com',
            'phone'         => '+8801700000002',
            'status'        => 'Active',
            'joining_date'  => '2025-01-01',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);

        // 3. "Johnny Smithson" (johnny.smithson@example.com)
        $db->table('employees')->insert([
            'id'            => $this->empJohnnyId,
            'company_id'    => $this->tenantCompanyId,
            'branch_id'     => $this->tenantBranchId,
            'department_id' => $this->tenantDeptId,
            'designation_id'=> $this->tenantDesgId,
            'employee_code' => 'EMP-JS-03',
            'first_name'    => 'Johnny',
            'last_name'     => 'Smithson',
            'email'         => 'johnny.smithson@example.com',
            'phone'         => '+8801700000003',
            'status'        => 'Active',
            'joining_date'  => '2025-01-01',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);
    }

    /**
     * Helper to run EmployeeModel search query on the database
     */
    protected function executeSearch(string $term): array
    {
        $model = new EmployeeModel();
        return $model->getEmployeesWithRelations($this->tenantCompanyId, ['search' => $term]);
    }

    /**
     * Test (a): "john smith" and "smith john" match John Smith in real DB
     */
    public function testFullNameSearchMatchingInDatabase()
    {
        // 1. "john smith" must match John Smith
        $resultsNormal = $this->executeSearch('john smith');
        $idsNormal = array_column($resultsNormal, 'id');
        $this->assertContains($this->empJohnId, $idsNormal, '"john smith" must match John Smith');
        $this->assertNotContains($this->empJaneId, $idsNormal, '"john smith" must not match Jane Roe');
        $this->assertNotContains($this->empJohnnyId, $idsNormal, '"john smith" must not match Johnny Smithson');

        // 2. "smith john" must match John Smith via reversed CONCAT_WS
        $resultsReversed = $this->executeSearch('smith john');
        $idsReversed = array_column($resultsReversed, 'id');
        $this->assertContains($this->empJohnId, $idsReversed, '"smith john" must match John Smith');
        $this->assertNotContains($this->empJaneId, $idsReversed, '"smith john" must not match Jane Roe');
        $this->assertNotContains($this->empJohnnyId, $idsReversed, '"smith john" must not match Johnny Smithson');
    }

    /**
     * Test (b): "john_doe" matches ONLY John Smith (not Jane Roe or Johnny Smithson)
     */
    public function testTermWithUnderscoreMatchesOnlyMatchingRecordInDatabase()
    {
        $results = $this->executeSearch('john_doe');
        $ids = array_column($results, 'id');

        $this->assertContains($this->empJohnId, $ids, '"john_doe" must match John Smith via email john_doe@example.com');
        $this->assertNotContains($this->empJaneId, $ids, '"john_doe" must not match Jane Roe');
        $this->assertNotContains($this->empJohnnyId, $ids, '"john_doe" must not match Johnny Smithson');
        $this->assertCount(1, $results, '"john_doe" must match only John Smith');
    }

    /**
     * Test (c): "john_doe@example.com" matches John Smith
     */
    public function testFullEmailSearchMatchesJohnSmithInDatabase()
    {
        $results = $this->executeSearch('john_doe@example.com');
        $ids = array_column($results, 'id');

        $this->assertContains($this->empJohnId, $ids, '"john_doe@example.com" must match John Smith');
        $this->assertNotContains($this->empJaneId, $ids, '"john_doe@example.com" must not match Jane Roe');
        $this->assertNotContains($this->empJohnnyId, $ids, '"john_doe@example.com" must not match Johnny Smithson');
        $this->assertCount(1, $results, '"john_doe@example.com" must match only John Smith');
    }

    /**
     * Test (d): "%" matches nothing (or only rows that literally contain %), not everything
     */
    public function testPercentSearchDoesNotMatchEverythingInDatabase()
    {
        $results = $this->executeSearch('%');
        $ids = array_column($results, 'id');

        $this->assertEmpty($results, '"%" must match nothing when no rows contain literal %');
        $this->assertNotContains($this->empJohnId, $ids);
        $this->assertNotContains($this->empJaneId, $ids);
        $this->assertNotContains($this->empJohnnyId, $ids);
    }

    /**
     * Test (e): "_" does not match everything
     */
    public function testUnderscoreSearchDoesNotMatchEverythingInDatabase()
    {
        $results = $this->executeSearch('_');
        $ids = array_column($results, 'id');

        // "_" should match literal "_" (which exists in john_doe@example.com), but MUST NOT match Jane Roe or Johnny Smithson
        $this->assertContains($this->empJohnId, $ids, '"_" should match John Smith whose email contains literal "_"');
        $this->assertNotContains($this->empJaneId, $ids, '"_" must NOT match Jane Roe');
        $this->assertNotContains($this->empJohnnyId, $ids, '"_" must NOT match Johnny Smithson');
        $this->assertLessThan(3, count($results), '"_" must not act as a wild card matching all rows');
    }

    /**
     * Test (f): Client-side filter (matchesSearch / $searchRowText in views/employees/index.php)
     * behaves the same for terms with _ and %.
     */
    public function testClientSideMatchesSearchBehavesIdenticallyForUnderscoreAndPercent()
    {
        // Emulate client-side matchesSearch(text) from views/employees/index.php
        $matchesSearch = function (?string $text, string $searchQuery): bool {
            if (trim($searchQuery) === '') return true;
            $query = strtolower(trim($searchQuery));
            $target = strtolower($text ?? '');
            if (str_contains($target, $query)) return true;
            $words = array_values(array_filter(preg_split('/\s+/', $query)));
            if (!empty($words) && count(array_filter($words, fn($w) => str_contains($target, $w))) === count($words)) {
                return true;
            }
            return false;
        };

        // Construct searchRowText for each seeded employee according to views/employees/index.php lines 415-432
        $buildSearchRowText = function (array $e): string {
            $empName = !empty($e['full_name']) ? $e['full_name'] : (!empty($e['name']) ? $e['name'] : trim(($e['first_name'] ?? '') . ' ' . ($e['last_name'] ?? '')));
            $reversedName = trim(($e['last_name'] ?? '') . ' ' . ($e['first_name'] ?? ''));
            return implode(' ', array_filter([
                $empName,
                $reversedName,
                $e['first_name'] ?? '',
                $e['last_name'] ?? '',
                $e['employee_code'] ?? '',
                $e['email'] ?? '',
                $e['phone'] ?? '',
                $e['department_name'] ?? '',
                $e['designation_name'] ?? '',
                $e['company_name'] ?? '',
                $e['branch_name'] ?? '',
            ]));
        };

        $johnText = $buildSearchRowText([
            'first_name'       => 'John',
            'last_name'        => 'Smith',
            'employee_code'    => 'EMP-JS-01',
            'email'            => 'john_doe@example.com',
            'phone'            => '+8801700000001',
            'department_name'  => 'Engineering',
            'designation_name' => 'Software Developer',
        ]);

        $janeText = $buildSearchRowText([
            'first_name'       => 'Jane',
            'last_name'        => 'Roe',
            'employee_code'    => 'EMP-JR-02',
            'email'            => 'jane.roe@example.com',
            'phone'            => '+8801700000002',
            'department_name'  => 'Engineering',
            'designation_name' => 'Software Developer',
        ]);

        $johnnyText = $buildSearchRowText([
            'first_name'       => 'Johnny',
            'last_name'        => 'Smithson',
            'employee_code'    => 'EMP-JS-03',
            'email'            => 'johnny.smithson@example.com',
            'phone'            => '+8801700000003',
            'department_name'  => 'Engineering',
            'designation_name' => 'Software Developer',
        ]);

        // 1. "john smith" matches John, not Jane, not Johnny
        $this->assertTrue($matchesSearch($johnText, 'john smith'));
        $this->assertFalse($matchesSearch($janeText, 'john smith'));
        $this->assertFalse($matchesSearch($johnnyText, 'john smith'));

        // 2. "smith john" matches John via reversed name
        $this->assertTrue($matchesSearch($johnText, 'smith john'));
        $this->assertFalse($matchesSearch($janeText, 'smith john'));
        $this->assertFalse($matchesSearch($johnnyText, 'smith john'));

        // 3. "john_doe" matches only John
        $this->assertTrue($matchesSearch($johnText, 'john_doe'));
        $this->assertFalse($matchesSearch($janeText, 'john_doe'));
        $this->assertFalse($matchesSearch($johnnyText, 'john_doe'));

        // 4. "john_doe@example.com" matches only John
        $this->assertTrue($matchesSearch($johnText, 'john_doe@example.com'));
        $this->assertFalse($matchesSearch($janeText, 'john_doe@example.com'));
        $this->assertFalse($matchesSearch($johnnyText, 'john_doe@example.com'));

        // 5. "%" matches nothing
        $this->assertFalse($matchesSearch($johnText, '%'));
        $this->assertFalse($matchesSearch($janeText, '%'));
        $this->assertFalse($matchesSearch($johnnyText, '%'));

        // 6. "_" matches only John (who has literal _ in email), does NOT match Jane or Johnny
        $this->assertTrue($matchesSearch($johnText, '_'));
        $this->assertFalse($matchesSearch($janeText, '_'));
        $this->assertFalse($matchesSearch($johnnyText, '_'));
    }

    /**
     * Test: branch_manager with no session branch fails closed (1 = 0) and sees nothing
     */
    public function testBranchManagerWithNoSessionBranchFailsClosed()
    {
        $userSession = [
            'role_code' => 'branch_manager',
            'branch_id' => null,
        ];
        $requestFilters = [
            'branch_id' => 'branch-request-spoofed-001',
        ];

        $canonicalRole = 'branch_manager';
        $userBranchId = $userSession['branch_id'] ?? null;

        $failedClosed = false;
        $effectiveBranchId = null;

        if ($canonicalRole === 'branch_manager') {
            if (!empty($userBranchId)) {
                $effectiveBranchId = $userBranchId;
            } else {
                $failedClosed = true;
            }
        }

        $this->assertTrue($failedClosed, 'branch_manager with no session branch must fail closed (1 = 0)');
        $this->assertNull($effectiveBranchId, 'Must not use branch_id from request filters');
    }

    /**
     * Test: Non-admin with no company ID shows friendly empty directory page instead of throwing
     */
    public function testNonAdminWithNoCompanyShowsFriendlyEmptyDirectory()
    {
        $isSoftwareAdmin = false;
        $userCompanyId = null;

        $responseHandled = false;
        $viewData = null;
        $exceptionThrown = false;

        try {
            if (!$isSoftwareAdmin && empty($userCompanyId)) {
                $viewData = [
                    'title'             => 'Employee Directory & Talent Hierarchy',
                    'employees'         => [],
                    'companies'         => [],
                    'branches'          => [],
                    'departments'       => [],
                    'designations'      => [],
                    'shifts'            => [],
                    'employmentTypes'   => [],
                    'managers'          => [],
                    'pfRules'           => [],
                    'emptyStateNotice'  => 'No company is associated with your user account. Please contact your system administrator to assign you to a company.',
                ];
                $responseHandled = true;
            } else {
                throw new \RuntimeException('Company ID is required to resolve Provident Fund rules.');
            }
        } catch (\Throwable $e) {
            $exceptionThrown = true;
        }

        $this->assertFalse($exceptionThrown, 'Must not throw RuntimeException for non-admin without company');
        $this->assertTrue($responseHandled);
        $this->assertEmpty($viewData['employees']);
        $this->assertEmpty($viewData['managers']);
        $this->assertStringContainsString('No company is associated', $viewData['emptyStateNotice']);
    }

    /**
     * Test: $managers dropdown query scoping and cap at 500
     */
    public function testManagersDropdownQueryScopingAndCap()
    {
        $mockBuilder = new class {
            public array $wheres = [];
            public ?int $limitVal = null;

            public function where(string $col, $val = null): self {
                $this->wheres[$col] = $val;
                return $this;
            }
            public function limit(int $n): self {
                $this->limitVal = $n;
                return $this;
            }
        };

        $mockBuilder->where('employees.status', 'active');
        $mockBuilder->where('employees.company_id', 'comp-001');
        $mockBuilder->where('employees.branch_id', 'branch-north');
        $mockBuilder->limit(500);

        $this->assertEquals('active', $mockBuilder->wheres['employees.status']);
        $this->assertEquals('comp-001', $mockBuilder->wheres['employees.company_id']);
        $this->assertEquals('branch-north', $mockBuilder->wheres['employees.branch_id']);
        $this->assertEquals(500, $mockBuilder->limitVal, '$managers dropdown must be capped at 500');
    }
}
