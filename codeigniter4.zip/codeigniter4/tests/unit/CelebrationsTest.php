<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class CelebrationsTest extends TestCase
{
    public function testBirthdayDetectionFromDob()
    {
        $currentMonth = (int)date('n');
        $currentDay   = (int)date('j');
        $currentYear  = (int)date('Y');

        $todayDob = sprintf('%04d-%02d-%02d', 1995, $currentMonth, $currentDay);
        $dobTs = strtotime($todayDob);

        $isTodayBirthday = ((int)date('n', $dobTs) === $currentMonth) && ((int)date('j', $dobTs) === $currentDay);
        $this->assertTrue($isTodayBirthday, "Employee with today's birthday must be detected accurately.");
    }

    public function testWorkAnniversaryMilestones()
    {
        $currentMonth = (int)date('n');
        $currentDay   = (int)date('j');
        $currentYear  = (int)date('Y');

        $joinDate = sprintf('%04d-%02d-%02d', $currentYear - 3, $currentMonth, $currentDay);
        $joinTs = strtotime($joinDate);

        $isAnnivToday = ((int)date('n', $joinTs) === $currentMonth) && ((int)date('j', $joinTs) === $currentDay);
        $yearsCompleted = $currentYear - (int)date('Y', $joinTs);

        $this->assertTrue($isAnnivToday, "Work anniversary must be detected on exact month and day.");
        $this->assertEquals(3, $yearsCompleted, "Completed service years must equal 3.");
    }
}
