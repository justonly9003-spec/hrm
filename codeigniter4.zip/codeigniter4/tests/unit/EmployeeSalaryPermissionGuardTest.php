<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use App\Controllers\Employee\EmployeeController;
use App\Models\EmployeeModel;
use App\Services\EmployeeSalaryService;
use App\Services\PermissionService;
use Config\Database;

/**
 * DB-backed tests for Employee Salary Permission Guards in EmployeeController and EmployeeSalaryService.
 *
 * Requirements:
 * 1. hr_officer with only employee.edit posting a changed basic_salary gets 403 and the row is unchanged.
 * 2. The same user posting an unchanged salary and unchanged allowances saves other fields normally.
 * 3. The same user posting a changed allowance gets 403 and row is unchanged.
 * 4. A user with employee.view_salary + payroll.edit can change salary.
 * 5. company_admin can change salary.
 * 6. hr_officer posting salary in store() gets 403 and no employee record is created.
 * 7. hr_officer posting blank salary in store() creates employee with unconfigured salary.
 * 8. EmployeeSalaryService::isAuthorizedRole + assignSalary strictly enforces authorized roles at service layer.
 */
class EmployeeSalaryPermissionGuardTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected static bool $schemaInitialized = false;

    protected string $companyId = 'comp-sal-guard-01';
    protected string $branchId  = 'branch-sal-guard-a';
    protected string $deptId    = 'dept-sal-guard-01';
    protected string $desgId    = 'desg-sal-guard-01';
    protected string $shiftId   = 'shift-sal-guard-01';
    protected string $empTypeId = 'et-sal-guard-01';
    protected string $empId     = 'emp-sal-test-01';

    protected array $hrOfficerActor   = [];
    protected array $payrollOfficerActor = [];
    protected array $companyAdminActor   = [];

    public static function setUpBeforeClass(): void
    {
        parent::setUpBeforeClass();
        static::ensureSchema();
    }

    public static function registerSqliteFunctions($db): void
    {
        try {
            $rawConn = $db->connID ?? null;
            if ($rawConn instanceof \SQLite3) {
                $rawConn->createFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->createFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            } elseif (is_object($rawConn) && method_exists($rawConn, 'sqliteCreateFunction')) {
                $rawConn->sqliteCreateFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->sqliteCreateFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            }
        } catch (\Throwable $e) {
            // ignore
        }
    }

    protected static function ensureSchema(): void
    {
        $db = Database::connect();
        static::registerSqliteFunctions($db);

        $schemaFile = __DIR__ . '/Rules/schema.sqlite.sql';
        if (file_exists($schemaFile)) {
            $sql = file_get_contents($schemaFile);
            $statements = array_filter(array_map('trim', explode(';', $sql)));
            foreach ($statements as $stmt) {
                if (!empty($stmt)) {
                    try {
                        $db->query($stmt);
                    } catch (\Throwable $e) {
                        // ignore
                    }
                }
            }
        }

        static::$schemaInitialized = true;
    }

    protected function setUp(): void
    {
        parent::setUp();
        static::ensureSchema();

        $db = Database::connect();
        static::registerSqliteFunctions($db);

        // 1. Seed Company
        $db->table('companies')->replace([
            'id'     => $this->companyId,
            'name'   => 'Salary Guard Corporation',
            'code'   => 'SGC',
            'status' => 'Active',
        ]);

        // 2. Seed Branch, Department, Designation, Shift, EmploymentType
        $db->table('branches')->replace([
            'id'         => $this->branchId,
            'company_id' => $this->companyId,
            'name'       => 'HQ Guard Branch',
            'code'       => 'HQ-GB',
            'status'     => 'Active',
        ]);

        $db->table('departments')->replace([
            'id'         => $this->deptId,
            'company_id' => $this->companyId,
            'name'       => 'Operations Dept',
            'code'       => 'OPS-01',
            'status'     => 'Active',
        ]);

        $db->table('designations')->replace([
            'id'         => $this->desgId,
            'company_id' => $this->companyId,
            'name'       => 'Senior Associate',
            'code'       => 'SA-01',
            'status'     => 'Active',
        ]);

        $db->table('shifts')->replace([
            'id'         => $this->shiftId,
            'company_id' => $this->companyId,
            'name'       => 'Regular Day Shift',
            'start_time' => '09:00:00',
            'end_time'   => '18:00:00',
            'status'     => 'Active',
        ]);

        $db->table('employment_types')->replace([
            'id'         => $this->empTypeId,
            'company_id' => $this->companyId,
            'name'       => 'Permanent',
            'code'       => 'PERM',
            'status'     => 'Active',
        ]);

        // 3. Seed Permissions
        $db->table('permissions')->replace([
            ['id' => 'p-emp-view',  'code' => 'employees.view',        'module' => 'directory', 'action' => 'view',        'name' => 'View Employees'],
            ['id' => 'p-emp-create','code' => 'employees.create',      'module' => 'directory', 'action' => 'create',      'name' => 'Create Employees'],
            ['id' => 'p-emp-edit',  'code' => 'employees.edit',        'module' => 'directory', 'action' => 'edit',        'name' => 'Edit Employees'],
            ['id' => 'p-sal-view',  'code' => 'employee.view_salary',   'module' => 'directory', 'action' => 'view_salary', 'name' => 'View Salary'],
            ['id' => 'p-pay-view',  'code' => 'payroll.view',          'module' => 'payroll',   'action' => 'view',        'name' => 'View Payroll'],
            ['id' => 'p-pay-edit',  'code' => 'payroll.edit',          'module' => 'payroll',   'action' => 'edit',        'name' => 'Edit Payroll'],
            ['id' => 'p-pay-mng',   'code' => 'payroll.manage',        'module' => 'payroll',   'action' => 'manage',      'name' => 'Manage Payroll'],
        ]);

        // 4. Seed Roles
        // hr_officer role: has employees.view, employees.create, employees.edit ONLY
        $db->table('roles')->replace([
            'id'         => 'role-hr-officer-guard',
            'company_id' => $this->companyId,
            'name'       => 'HR Officer',
            'code'       => 'hr_officer',
            'status'     => 'Active',
        ]);
        $db->table('role_permissions')->where('role_id', 'role-hr-officer-guard')->delete();
        $db->table('role_permissions')->insertBatch([
            ['id' => 'rp-hr-g1', 'role_id' => 'role-hr-officer-guard', 'permission_id' => 'p-emp-view',   'scope_level' => 'company'],
            ['id' => 'rp-hr-g2', 'role_id' => 'role-hr-officer-guard', 'permission_id' => 'p-emp-create', 'scope_level' => 'company'],
            ['id' => 'rp-hr-g3', 'role_id' => 'role-hr-officer-guard', 'permission_id' => 'p-emp-edit',   'scope_level' => 'company'],
        ]);

        // payroll_officer role: has employee.view_salary, payroll.edit, payroll.view, employees.view
        $db->table('roles')->replace([
            'id'         => 'role-payroll-officer-guard',
            'company_id' => $this->companyId,
            'name'       => 'Payroll Officer',
            'code'       => 'payroll_officer',
            'status'     => 'Active',
        ]);
        $db->table('role_permissions')->where('role_id', 'role-payroll-officer-guard')->delete();
        $db->table('role_permissions')->insertBatch([
            ['id' => 'rp-pay-g1', 'role_id' => 'role-payroll-officer-guard', 'permission_id' => 'p-emp-view',  'scope_level' => 'company'],
            ['id' => 'rp-pay-g2', 'role_id' => 'role-payroll-officer-guard', 'permission_id' => 'p-sal-view',  'scope_level' => 'company'],
            ['id' => 'rp-pay-g3', 'role_id' => 'role-payroll-officer-guard', 'permission_id' => 'p-pay-edit',  'scope_level' => 'company'],
            ['id' => 'rp-pay-g4', 'role_id' => 'role-payroll-officer-guard', 'permission_id' => 'p-pay-view',  'scope_level' => 'company'],
        ]);

        // company_admin role: full access
        $db->table('roles')->replace([
            'id'         => 'role-company-admin-guard',
            'company_id' => $this->companyId,
            'name'       => 'Company Admin',
            'code'       => 'company_admin',
            'status'     => 'Active',
        ]);

        // 5. Seed Users
        $db->table('users')->replace([
            [
                'id'         => 'usr-hr-guard-01',
                'company_id' => $this->companyId,
                'branch_id'  => $this->branchId,
                'username'   => 'hr_officer_guard',
                'email'      => 'hr_guard@guard.test',
                'role_id'    => 'role-hr-officer-guard',
                'status'     => 'Active',
            ],
            [
                'id'         => 'usr-pay-guard-01',
                'company_id' => $this->companyId,
                'branch_id'  => $this->branchId,
                'username'   => 'payroll_officer_guard',
                'email'      => 'pay_guard@guard.test',
                'role_id'    => 'role-payroll-officer-guard',
                'status'     => 'Active',
            ],
            [
                'id'         => 'usr-ca-guard-01',
                'company_id' => $this->companyId,
                'branch_id'  => $this->branchId,
                'username'   => 'company_admin_guard',
                'email'      => 'ca_guard@guard.test',
                'role_id'    => 'role-company-admin-guard',
                'status'     => 'Active',
            ],
        ]);

        $this->hrOfficerActor = [
            'id'          => 'usr-hr-guard-01',
            'username'    => 'hr_officer_guard',
            'company_id'  => $this->companyId,
            'branch_id'   => $this->branchId,
            'role_id'     => 'role-hr-officer-guard',
            'role_code'   => 'hr_officer',
            'role_name'   => 'HR Officer',
            'permissions' => ['employees.view', 'employees.create', 'employees.edit'],
        ];

        $this->payrollOfficerActor = [
            'id'          => 'usr-pay-guard-01',
            'username'    => 'payroll_officer_guard',
            'company_id'  => $this->companyId,
            'branch_id'   => $this->branchId,
            'role_id'     => 'role-payroll-officer-guard',
            'role_code'   => 'payroll_officer',
            'role_name'   => 'Payroll Officer',
            'permissions' => ['employees.view', 'employee.view_salary', 'payroll.edit', 'payroll.view'],
        ];

        $this->companyAdminActor = [
            'id'          => 'usr-ca-guard-01',
            'username'    => 'company_admin_guard',
            'company_id'  => $this->companyId,
            'branch_id'   => $this->branchId,
            'role_id'     => 'role-company-admin-guard',
            'role_code'   => 'company_admin',
            'role_name'   => 'Company Admin',
            'permissions' => ['*'],
        ];

        // 6. Seed Target Employee with existing salary 50000.00
        $db->table('employees')->where('id', $this->empId)->delete();
        $db->table('employees')->insert([
            'id'                   => $this->empId,
            'company_id'           => $this->companyId,
            'branch_id'            => $this->branchId,
            'department_id'        => $this->deptId,
            'designation_id'       => $this->desgId,
            'employment_type_id'   => $this->empTypeId,
            'shift_id'             => $this->shiftId,
            'employee_code'        => 'EMP-GUARD-01',
            'first_name'           => 'John',
            'last_name'            => 'Doe',
            'gender'               => 'male',
            'dob'                  => '1990-01-01',
            'email'                => 'john.doe@guard.test',
            'basic_salary'         => 50000.00,
            'gross_salary'         => 68000.00,
            'net_salary'           => 68000.00,
            'house_rent_allowance' => 10000.00,
            'medical_allowance'    => 5000.00,
            'conveyance_allowance' => 3000.00,
            'status'               => EmployeeModel::STATUS_ACTIVE,
            'salary_status'        => 'CONFIGURED',
            'joining_date'         => '2025-01-01',
            'created_at'           => date('Y-m-d H:i:s'),
        ]);

        // Seed Active salary record in employee_salaries
        $db->table('employee_salaries')->where('employee_id', $this->empId)->delete();
        $db->table('employee_salaries')->insert([
            'id'                     => 'sal-guard-rec-01',
            'employee_id'            => $this->empId,
            'company_id'             => $this->companyId,
            'basic_salary'           => 50000.00,
            'gross_salary'           => 68000.00,
            'total_deductions'       => 0.00,
            'net_salary'             => 68000.00,
            'ctc'                    => 68000.00,
            'effective_from'         => '2025-01-01',
            'status'                 => 'Active',
            'custom_components_json' => json_encode([
                'basic_salary' => 50000.00,
                'components'   => [
                    'house_rent' => 10000.00,
                    'medical'    => 5000.00,
                    'conveyance' => 3000.00,
                ],
                'earnings'     => [
                    ['code' => 'BASIC', 'name' => 'Basic Salary', 'amount' => 50000.00],
                    ['code' => 'HRA',   'name' => 'House Rent Allowance', 'amount' => 10000.00],
                    ['code' => 'MED',   'name' => 'Medical Allowance', 'amount' => 5000.00],
                    ['code' => 'CONV',  'name' => 'Conveyance Allowance', 'amount' => 3000.00],
                ],
            ]),
            'created_at'             => date('Y-m-d H:i:s'),
        ]);
    }

    /**
     * Helper to instantiate EmployeeController with an authenticated user context and request payload
     */
    protected function setupEmployeeController(array $actorUser, array $postData = [], bool $isAjax = true): EmployeeController
    {
        PermissionService::clearCache();
        PermissionService::flushCache();

        $session = \Config\Services::session();
        $session->set([
            'id'                  => $actorUser['id'],
            'user_id'             => $actorUser['id'],
            'username'            => $actorUser['username'] ?? 'user_' . $actorUser['id'],
            'name'                => $actorUser['name'] ?? 'Test User',
            'email'               => $actorUser['email'] ?? 'test@guard.test',
            'role'                => $actorUser['role_code'],
            'role_code'           => $actorUser['role_code'],
            'role_name'           => $actorUser['role_name'] ?? $actorUser['role_code'],
            'role_id'             => $actorUser['role_id'],
            'company_id'          => $actorUser['company_id'],
            'branch_id'           => $actorUser['branch_id'] ?? null,
            'employee_id'         => $actorUser['employee_id'] ?? null,
            'selected_company_id' => $actorUser['company_id'],
            'permissions'         => $actorUser['permissions'] ?? [],
        ]);

        if ($isAjax) {
            $_SERVER['HTTP_X_REQUESTED_WITH'] = 'xmlhttprequest';
            $_SERVER['HTTP_ACCEPT'] = 'application/json';
        } else {
            unset($_SERVER['HTTP_X_REQUESTED_WITH']);
            $_SERVER['HTTP_ACCEPT'] = 'text/html';
        }
        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_POST = $postData;

        $request = \Config\Services::request();
        $refPost = new \ReflectionProperty($request, 'body');
        $refPost->setAccessible(true);
        $refPost->setValue($request, $postData);

        $response = \Config\Services::response();
        $logger   = \Config\Services::logger();

        $controller = new EmployeeController();
        $controller->initController($request, $response, $logger);

        $refUser = new \ReflectionProperty(\App\Controllers\BaseController::class, 'currentUser');
        $refUser->setAccessible(true);
        $refUser->setValue($controller, $actorUser);

        return $controller;
    }

    /**
     * Test 1: hr_officer with only employee.edit posting changed basic_salary gets 403 and row is unchanged
     */
    public function testHrOfficerCannotModifySalaryGets403AndRowUnchanged()
    {
        $controller = $this->setupEmployeeController($this->hrOfficerActor, [
            'first_name'   => 'John Changed',
            'basic_salary' => '65000.00',
        ]);

        $response = $controller->update($this->empId);

        $this->assertInstanceOf(\CodeIgniter\HTTP\ResponseInterface::class, $response);
        $this->assertEquals(403, $response->getStatusCode());

        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success'] ?? true);
        $this->assertStringContainsString('permission to assign or modify employee salaries', $body['message'] ?? '');

        // Verify DB record remained completely unchanged
        $db = Database::connect();
        $emp = $db->table('employees')->where('id', $this->empId)->get()->getRowArray();
        $this->assertEquals(50000.00, (float)$emp['basic_salary']);
        $this->assertEquals('John', $emp['first_name']);
    }

    /**
     * Test 2: Same user posting unchanged salary and unchanged allowances saves other fields normally
     */
    public function testHrOfficerPostingUnchangedSalaryAndAllowancesSavesOtherFieldsNormally()
    {
        $controller = $this->setupEmployeeController($this->hrOfficerActor, [
            'first_name'           => 'John UpdatedNormal',
            'basic_salary'         => '50000.00',
            'house_rent_allowance' => '10000.00',
            'medical_allowance'    => '5000.00',
            'conveyance_allowance' => '3000.00',
        ]);

        $response = $controller->update($this->empId);

        // Success response
        $this->assertTrue(
            $response === null ||
            ($response instanceof \CodeIgniter\HTTP\ResponseInterface && in_array($response->getStatusCode(), [200, 302], true))
        );

        // Verify first_name updated while basic_salary remained 50000.00
        $db = Database::connect();
        $emp = $db->table('employees')->where('id', $this->empId)->get()->getRowArray();
        $this->assertEquals('John UpdatedNormal', $emp['first_name']);
        $this->assertEquals(50000.00, (float)$emp['basic_salary']);
    }

    /**
     * Test 3: hr_officer posting a changed allowance gets 403 and row is unchanged
     */
    public function testHrOfficerPostingChangedAllowanceGets403AndRowUnchanged()
    {
        $controller = $this->setupEmployeeController($this->hrOfficerActor, [
            'first_name'           => 'John AllowanceTamper',
            'house_rent_allowance' => '25000.00', // Changed from 10000.00
        ]);

        $response = $controller->update($this->empId);

        $this->assertInstanceOf(\CodeIgniter\HTTP\ResponseInterface::class, $response);
        $this->assertEquals(403, $response->getStatusCode());

        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success'] ?? true);
        $this->assertStringContainsString('permission to assign or modify employee salaries', $body['message'] ?? '');

        // Verify row unchanged
        $db = Database::connect();
        $emp = $db->table('employees')->where('id', $this->empId)->get()->getRowArray();
        $this->assertNotEquals('John AllowanceTamper', $emp['first_name']);
        $this->assertEquals(10000.00, (float)$emp['house_rent_allowance']);
    }

    /**
     * Test 4: User with employee.view_salary + payroll.edit can change salary
     */
    public function testUserWithViewSalaryAndPayrollEditCanChangeSalary()
    {
        $controller = $this->setupEmployeeController($this->payrollOfficerActor, [
            'first_name'   => 'John Paid',
            'basic_salary' => '65000.00',
        ]);

        $response = $controller->update($this->empId);

        // Success response (status 200 JSON or 302 redirect)
        $this->assertTrue(
            $response === null ||
            ($response instanceof \CodeIgniter\HTTP\ResponseInterface && in_array($response->getStatusCode(), [200, 302], true))
        );

        // Verify salary updated in database
        $db = Database::connect();
        $emp = $db->table('employees')->where('id', $this->empId)->get()->getRowArray();
        $this->assertEquals(65000.00, (float)$emp['basic_salary']);
    }

    /**
     * Test 5: company_admin can change salary
     */
    public function testCompanyAdminCanChangeSalary()
    {
        $controller = $this->setupEmployeeController($this->companyAdminActor, [
            'first_name'   => 'John AdminChanged',
            'basic_salary' => '72000.00',
        ]);

        $response = $controller->update($this->empId);

        $this->assertTrue(
            $response === null ||
            ($response instanceof \CodeIgniter\HTTP\ResponseInterface && in_array($response->getStatusCode(), [200, 302], true))
        );

        $db = Database::connect();
        $emp = $db->table('employees')->where('id', $this->empId)->get()->getRowArray();
        $this->assertEquals(72000.00, (float)$emp['basic_salary']);
    }

    /**
     * Test 6: hr_officer posting salary in store() gets 403 and no employee record is created
     */
    public function testHrOfficerPostingSalaryInStoreGets403AndNoEmployeeCreated()
    {
        $storePayload = [
            'first_name'    => 'NewEmpWithSalary',
            'gender'        => 'male',
            'dob'           => '1995-03-20',
            'shift_id'      => $this->shiftId,
            'employee_code' => 'EMP-HR-STORE-FAIL',
            'basic_salary'  => '45000.00',
        ];

        $controller = $this->setupEmployeeController($this->hrOfficerActor, $storePayload);

        $response = $controller->store();

        $this->assertInstanceOf(\CodeIgniter\HTTP\ResponseInterface::class, $response);
        $this->assertEquals(403, $response->getStatusCode());

        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success'] ?? true);
        $this->assertStringContainsString('permission to assign or modify employee salaries', $body['message'] ?? '');

        // Verify no record inserted
        $db = Database::connect();
        $inserted = $db->table('employees')->where('employee_code', 'EMP-HR-STORE-FAIL')->first();
        $this->assertNull($inserted, 'Employee row must not be inserted when unauthorized actor attempts salary assignment');
    }

    /**
     * Test 7: hr_officer posting blank salary in store() creates employee with unconfigured salary
     */
    public function testHrOfficerPostingBlankSalaryInStoreSucceeds()
    {
        $storePayload = [
            'first_name'    => 'NewEmpBlankSalary',
            'gender'        => 'female',
            'dob'           => '1996-07-14',
            'shift_id'      => $this->shiftId,
            'employee_code' => 'EMP-HR-STORE-OK',
            'basic_salary'  => '',
        ];

        $controller = $this->setupEmployeeController($this->hrOfficerActor, $storePayload);

        $response = $controller->store();

        $this->assertTrue(
            $response === null ||
            ($response instanceof \CodeIgniter\HTTP\ResponseInterface && in_array($response->getStatusCode(), [200, 302], true))
        );

        $db = Database::connect();
        $inserted = $db->table('employees')->where('employee_code', 'EMP-HR-STORE-OK')->first();
        $this->assertNotNull($inserted, 'Employee row must be created when unauthorized actor submits blank salary');
        $this->assertEquals(0.00, (float)$inserted['basic_salary']);
        $this->assertEquals('NOT_CONFIGURED', $inserted['salary_status']);
    }

    /**
     * Test 8: EmployeeSalaryService::isAuthorizedRole and assignSalary service-layer enforcement
     */
    public function testSalaryServiceIsAuthorizedRoleAndAssignSalaryEnforcement()
    {
        $salaryService = new EmployeeSalaryService();

        // 1. HR officer is NOT authorized
        $isHrAuth = $salaryService->isAuthorizedRole($this->hrOfficerActor, $this->empId);
        $this->assertFalse($isHrAuth, 'hr_officer without view_salary + payroll.edit must not be authorized');

        $hrResult = $salaryService->assignSalary($this->empId, [
            'basic_salary'   => 55000.00,
            'effective_from' => date('Y-m-d'),
        ], $this->companyId, $this->hrOfficerActor);
        $this->assertFalse($hrResult['success']);
        $this->assertEquals(403, $hrResult['status']);

        // 2. Payroll officer is authorized
        $isPayAuth = $salaryService->isAuthorizedRole($this->payrollOfficerActor, $this->empId);
        $this->assertTrue($isPayAuth, 'payroll_officer with view_salary + payroll.edit must be authorized');

        // 3. Company admin is authorized
        $isCaAuth = $salaryService->isAuthorizedRole($this->companyAdminActor, $this->empId);
        $this->assertTrue($isCaAuth, 'company_admin must always be authorized');
    }
}
