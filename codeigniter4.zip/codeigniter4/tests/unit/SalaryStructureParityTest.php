<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Libraries\PayrollCalculator;

class SalaryStructureParityTest extends TestCase
{
    /**
     * Test formula evaluation parity for basic arithmetic, parentheses, and variables
     */
    public function testEvaluateSalaryFormulaBasicMath()
    {
        $vars = [
            'BASIC'        => 50000.0,
            'BASIC_SALARY' => 50000.0,
            'GROSS'        => 80000.0,
            'HRA'          => 20000.0,
        ];

        // 50% of Basic
        $val = PayrollCalculator::evaluateSalaryFormula('BASIC * 0.50', $vars);
        $this->assertEquals(25000.0, $val);

        // Nested arithmetic
        $val2 = PayrollCalculator::evaluateSalaryFormula('(BASIC * 0.40) + (HRA * 0.10)', $vars);
        $this->assertEquals(22000.0, $val2);

        // Case insensitivity
        $val3 = PayrollCalculator::evaluateSalaryFormula('basic * 0.25', $vars);
        $this->assertEquals(12500.0, $val3);
    }

    /**
     * Test MIN, MAX, and ROUND functions in formulas
     */
    public function testEvaluateSalaryFormulaFunctions()
    {
        $vars = [
            'BASIC' => 45000.0,
            'GROSS' => 70000.0,
        ];

        // MIN cap
        $valMin = PayrollCalculator::evaluateSalaryFormula('MIN(BASIC * 0.15, 6000)', $vars);
        $this->assertEquals(6000.0, $valMin); // 45000 * 0.15 = 6750, capped at 6000

        // MAX floor
        $valMax = PayrollCalculator::evaluateSalaryFormula('MAX(BASIC * 0.10, 5000)', $vars);
        $this->assertEquals(5000.0, $valMax); // 45000 * 0.10 = 4500, floored at 5000

        // ROUND
        $valRound = PayrollCalculator::evaluateSalaryFormula('ROUND(BASIC / 3, 2)', $vars);
        $this->assertEquals(15000.0, $valRound);
    }

    /**
     * Test formula safe parser prevents arbitrary code execution and handles errors safely
     */
    public function testEvaluateSalaryFormulaSafetyAndRobustness()
    {
        $vars = ['BASIC' => 30000.0];

        // Division by zero returns 0 without crashing
        $divZero = PayrollCalculator::evaluateSalaryFormula('BASIC / 0', $vars);
        $this->assertEquals(0.0, $divZero);

        // Invalid tokens / injection attempt
        $malicious = 'system("ls") + BASIC';
        $safeResult = PayrollCalculator::evaluateSalaryFormula($malicious, $vars);
        // Sanitizer strips letters that don't match variables/functions, safely falls back
        $this->assertIsFloat($safeResult);

        // Empty formula returns 0
        $empty = PayrollCalculator::evaluateSalaryFormula('', $vars);
        $this->assertEquals(0.0, $empty);
    }

    /**
     * Test component evaluation parity matching React SalaryRuleSystemTab calculation
     */
    public function testComponentCalculationParity()
    {
        $basicSalary = 40000.0;
        $components = [
            [
                'code'             => 'HRA',
                'name'             => 'House Rent Allowance',
                'type'             => 'earning',
                'calculation_type' => 'percentage',
                'calculation_base' => 'Basic Salary',
                'rate_or_amount'   => 40.0, // 40% of 40000 = 16000
                'is_enabled'       => true,
            ],
            [
                'code'             => 'MED',
                'name'             => 'Medical Allowance',
                'type'             => 'earning',
                'calculation_type' => 'fixed',
                'rate_or_amount'   => 3000.0,
                'is_enabled'       => true,
            ],
            [
                'code'             => 'PERF',
                'name'             => 'Performance Allowance',
                'type'             => 'earning',
                'calculation_type' => 'formula',
                'custom_formula'   => 'BASIC * 0.10', // 4000
                'is_enabled'       => true,
            ],
            [
                'code'             => 'PF',
                'name'             => 'Provident Fund (Employee)',
                'type'             => 'deduction',
                'calculation_type' => 'percentage',
                'calculation_base' => 'Basic Salary',
                'rate_or_amount'   => 7.0, // 7% of 40000 = 2800
                'is_enabled'       => true,
            ],
            [
                'code'             => 'ER_PF',
                'name'             => 'Provident Fund (Employer)',
                'type'             => 'employer_contribution',
                'calculation_type' => 'percentage',
                'calculation_base' => 'Basic Salary',
                'rate_or_amount'   => 7.0, // 7% of 40000 = 2800
                'is_enabled'       => true,
            ]
        ];

        $hra = 40000.0 * 0.40; // 16000
        $med = 3000.0;
        $perf = PayrollCalculator::evaluateSalaryFormula('BASIC * 0.10', ['BASIC' => 40000.0]); // 4000
        $gross = $basicSalary + $hra + $med + $perf; // 63000

        $pf = round(40000.0 * 0.07, 2); // 2800
        $net = round($gross - $pf, 2); // 60200

        $erPf = round(40000.0 * 0.07, 2); // 2800
        $ctc = round($gross + $erPf, 2); // 65800

        $this->assertEquals(16000.0, $hra);
        $this->assertEquals(3000.0, $med);
        $this->assertEquals(4000.0, $perf);
        $this->assertEquals(63000.0, $gross);
        $this->assertEquals(2800.0, $pf);
        $this->assertEquals(60200.0, $net);
        $this->assertEquals(2800.0, $erPf);
        $this->assertEquals(65800.0, $ctc);
    }

    /**
     * Test history snapshot structure parity with React EmployeeSalarySnapshot
     */
    public function testHistoricalSnapshotParity()
    {
        $existingSnapshot = [
            'id'                   => 'SNAP-EMP001-123456',
            'employeeId'           => 'EMP001',
            'structureId'          => 'STR-001',
            'structureName'        => 'Standard Executive',
            'version'              => 1,
            'assignmentType'       => 'template',
            'effectiveFrom'        => '2025-01-01',
            'effectiveTo'          => '2025-06-30',
            'status'               => 'Revised',
            'basicSalary'          => 40000.0,
            'grossSalary'          => 65000.0,
            'totalEarnings'        => 65000.0,
            'totalDeductions'      => 3500.0,
            'netSalary'            => 61500.0,
            'totalEmployerCost'    => 67800.0,
            'revisionReason'       => 'Annual Increment',
            'revisedBy'            => 'HR Admin',
            'revisedAt'            => '2025-06-30 18:00:00',
        ];

        // Simulate new revision snapshot bundling previous snapshot in history
        $newSnapshot = [
            'id'                => 'SNAP-EMP001-654321',
            'employeeId'        => 'EMP001',
            'structureId'       => 'STR-001',
            'structureName'     => 'Standard Executive',
            'version'           => 2,
            'assignmentType'    => 'template',
            'effectiveFrom'     => '2025-07-01',
            'status'            => 'Active',
            'basicSalary'       => 45000.0,
            'grossSalary'       => 72000.0,
            'totalEarnings'     => 72000.0,
            'totalDeductions'   => 3800.0,
            'netSalary'         => 68200.0,
            'totalEmployerCost' => 75150.0,
            'historySnapshots'  => [$existingSnapshot],
        ];

        $this->assertEquals(2, $newSnapshot['version']);
        $this->assertCount(1, $newSnapshot['historySnapshots']);
        $this->assertEquals(40000.0, $newSnapshot['historySnapshots'][0]['basicSalary']);
        $this->assertEquals('Revised', $newSnapshot['historySnapshots'][0]['status']);
    }
}
