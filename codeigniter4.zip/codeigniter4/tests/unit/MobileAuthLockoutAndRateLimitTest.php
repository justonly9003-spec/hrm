<?php

namespace Tests\Unit;

use App\Services\Auth\AccountLockoutService;
use App\Services\Auth\RateLimitService;
use App\Services\Mobile\MobileAuthService;
use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobileAuthLockoutAndRateLimitTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;
    private MobileAuthService $svc;

    protected function setUp(): void
    {
        parent::setUp();
        RateLimitService::reset();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);
        $this->svc = new MobileAuthService($this->db);
    }

    protected function tearDown(): void
    {
        RateLimitService::reset();
        parent::tearDown();
    }

    /**
     * Test 1: Central Lockout Policy Constants
     * Confirms mobile and web enforce the exact same thresholds:
     * 5 max failed attempts, 15 minutes (900 seconds) lockout duration.
     */
    public function testCentralLockoutPolicyThresholds(): void
    {
        $this->assertSame(5, AccountLockoutService::MAX_FAILED_ATTEMPTS);
        $this->assertSame(900, AccountLockoutService::LOCKOUT_DURATION_SECONDS);
    }

    /**
     * Test 2: Consecutive failed login attempts trigger account lockout on the 5th attempt.
     */
    public function testConsecutiveFailedLoginsTriggerLockout(): void
    {
        // 4 failed attempts: each returns 401 Invalid credentials
        for ($i = 1; $i <= 4; $i++) {
            $res = $this->svc->login('ACME', 'rahim', 'WrongPassword!', ['device_uid' => 'dev-lock-1'], '192.168.1.100');
            $this->assertFalse($res['ok']);
            $this->assertSame(401, $res['status']);
            $this->assertSame('Invalid credentials.', $res['message']);

            $user = $this->db->table('users')->where('id', 'u-1')->get()->getRowArray();
            $this->assertSame($i, (int)$user['failed_logins']);
            $this->assertNull($user['locked_until']);
        }

        // 5th failed attempt: triggers lockout, returns 429
        $res5 = $this->svc->login('ACME', 'rahim', 'WrongPassword!', ['device_uid' => 'dev-lock-1'], '192.168.1.100');
        $this->assertFalse($res5['ok']);
        $this->assertSame(429, $res5['status']);
        $this->assertStringContainsString('locked for 15 minutes', $res5['message']);
        $this->assertSame(900, $res5['retry_after']);

        $userLocked = $this->db->table('users')->where('id', 'u-1')->get()->getRowArray();
        $this->assertSame(5, (int)$userLocked['failed_logins']);
        $this->assertNotNull($userLocked['locked_until']);
        $this->assertTrue(strtotime($userLocked['locked_until']) > time());
    }

    /**
     * Test 3: Locked account rejects even the correct password during lockout period.
     */
    public function testLockedAccountRejectsCorrectPassword(): void
    {
        // Manually lock user u-1 for 15 minutes
        $this->db->table('users')->where('id', 'u-1')->update([
            'failed_logins' => 5,
            'locked_until'  => date('Y-m-d H:i:s', time() + 900),
        ]);

        // Attempt login with CORRECT password
        $res = $this->svc->login('ACME', 'rahim', self::PASSWORD, ['device_uid' => 'dev-lock-1'], '192.168.1.100');
        $this->assertFalse($res['ok']);
        $this->assertSame(429, $res['status']);
        $this->assertStringContainsString('Account is temporarily locked', $res['message']);
        $this->assertGreaterThan(0, $res['retry_after'] ?? 0);

        // Verify login history records 'locked' attempt
        $history = $this->db->table('login_history')
            ->where('user_id', 'u-1')
            ->orderBy('id', 'DESC')
            ->get()->getRowArray();
        $this->assertSame('locked', $history['status']);
    }

    /**
     * Test 4: Switching device IDs does not bypass lockout.
     */
    public function testSwitchingDeviceIdsDoesNotBypassLockout(): void
    {
        // Attacker attempts 4 failed logins from Device A
        for ($i = 1; $i <= 4; $i++) {
            $this->svc->login('ACME', 'rahim', 'BadPass!', ['device_uid' => "dev-attacker-A{$i}"], '192.168.2.1');
        }

        // 5th attempt from a brand-new Device B
        $resB = $this->svc->login('ACME', 'rahim', 'BadPass!', ['device_uid' => 'dev-attacker-BRAND-NEW'], '192.168.2.1');
        $this->assertSame(429, $resB['status']);
        $this->assertStringContainsString('locked for 15 minutes', $resB['message']);

        // Subsequent attempt from yet another Device C with legitimate password
        $resC = $this->svc->login('ACME', 'rahim', self::PASSWORD, ['device_uid' => 'dev-attacker-DEVICE-C'], '192.168.2.1');
        $this->assertSame(429, $resC['status']);
        $this->assertStringContainsString('temporarily locked', $resC['message']);
    }

    /**
     * Test 5: Switching request formats (JSON vs form data) via endpoint does not bypass lockout.
     */
    public function testSwitchingRequestFormatDoesNotBypassLockout(): void
    {
        // 4 failed attempts via JSON format
        for ($i = 1; $i <= 4; $i++) {
            $res = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
                'company_code' => 'ACME',
                'identifier'   => 'rahim',
                'password'     => 'BadPass!',
                'device'       => ['device_uid' => 'dev-format-json'],
            ]);
            $this->assertSame(401, $res->response()->getStatusCode());
        }

        // 5th attempt via POST form-urlencoded format
        $resForm = $this->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => 'ACME',
            'identifier'   => 'rahim',
            'password'     => 'BadPass!',
            'device'       => ['device_uid' => 'dev-format-post'],
        ]);
        $this->assertSame(429, $resForm->response()->getStatusCode());
        $body = json_decode($resForm->getJSON(), true);
        $this->assertStringContainsString('locked for 15 minutes', $body['message']);
    }

    /**
     * Test 6: Account enumeration prevention.
     * Non-existent company code and non-existent username return identical 'Invalid credentials.' 401 error.
     */
    public function testAccountEnumerationPrevention(): void
    {
        // Non-existent company code
        $resComp = $this->svc->login('INVALID_CO', 'rahim', 'Pass123!', [], '10.0.0.1');
        $this->assertFalse($resComp['ok']);
        $this->assertSame(401, $resComp['status']);
        $this->assertSame('Invalid credentials.', $resComp['message']);

        // Non-existent username in valid company
        $resUser = $this->svc->login('ACME', 'nonexistent_user', 'Pass123!', [], '10.0.0.1');
        $this->assertFalse($resUser['ok']);
        $this->assertSame(401, $resUser['status']);
        $this->assertSame('Invalid credentials.', $resUser['message']);

        // Real user with wrong password
        $resWrongPw = $this->svc->login('ACME', 'rahim', 'WrongPass!', [], '10.0.0.1');
        $this->assertFalse($resWrongPw['ok']);
        $this->assertSame(401, $resWrongPw['status']);
        $this->assertSame('Invalid credentials.', $resWrongPw['message']);
    }

    /**
     * Test 7: Automatic unlock and legitimate login after lockout expiry.
     */
    public function testLegitimateLoginSucceedsAfterLockoutExpiry(): void
    {
        // Simulate an account that was locked 20 minutes ago (expired 5 minutes ago)
        $pastLockTime = date('Y-m-d H:i:s', time() - 300);
        $this->db->table('users')->where('id', 'u-1')->update([
            'failed_logins' => 5,
            'locked_until'  => $pastLockTime,
        ]);

        // Login with correct password after lock has elapsed
        $res = $this->svc->login('ACME', 'rahim', self::PASSWORD, ['device_uid' => 'dev-legit-1'], '10.0.0.50');
        $this->assertTrue($res['ok']);
        $this->assertSame(200, $res['status']);
        $this->assertNotEmpty($res['data']['tokens']['access_token']);

        // Verify account was automatically unlocked in database
        $user = $this->db->table('users')->where('id', 'u-1')->get()->getRowArray();
        $this->assertSame(0, (int)$user['failed_logins']);
        $this->assertNull($user['locked_until']);
    }

    /**
     * Test 8: Rate limiting on login endpoint triggers 429 with Retry-After header.
     */
    public function testRateLimitingOnLogin(): void
    {
        // Set test limit to 3 requests per window to test threshold cleanly
        RateLimitService::setTestLoginIpLimit(3);

        $ip = '198.51.100.25';

        // Requests 1, 2, 3 succeed rate-check (return 401 for bad pass)
        for ($i = 1; $i <= 3; $i++) {
            $res = $this->svc->login('ACME', 'user_rate_test', 'wrong', [], $ip);
            $this->assertSame(401, $res['status']);
        }

        // 4th request from same IP is rate-limited: 429
        $res4 = $this->svc->login('ACME', 'user_rate_test', 'wrong', [], $ip);
        $this->assertSame(429, $res4['status']);
        $this->assertStringContainsString('Too many login attempts', $res4['message']);
        $this->assertGreaterThan(0, $res4['retry_after']);
    }

    /**
     * Test 9: Rate limiting on token refresh endpoint triggers 429.
     */
    public function testRateLimitingOnTokenRefresh(): void
    {
        RateLimitService::setTestRefreshLimit(2);
        $ip = '198.51.100.99';

        // 1st and 2nd refresh requests
        $r1 = $this->svc->refresh('dummy-token-1', $ip);
        $this->assertSame(401, $r1['status']); // Invalid token

        $r2 = $this->svc->refresh('dummy-token-2', $ip);
        $this->assertSame(401, $r2['status']); // Invalid token

        // 3rd refresh request is throttled
        $r3 = $this->svc->refresh('dummy-token-3', $ip);
        $this->assertSame(429, $r3['status']);
        $this->assertStringContainsString('Too many refresh requests', $r3['message']);
        $this->assertGreaterThan(0, $r3['retry_after']);
    }

    /**
     * Test 10: Refresh token rejected when user account is locked.
     */
    public function testRefreshTokenRejectedWhenUserAccountIsLocked(): void
    {
        // Log in to obtain a valid refresh token
        $loginRes = $this->svc->login('ACME', 'rahim', self::PASSWORD, ['device_uid' => 'dev-ref-lock'], '10.0.0.1');
        $refreshToken = $loginRes['data']['tokens']['refresh_token'];

        // Now lock the user account
        $this->db->table('users')->where('id', 'u-1')->update([
            'failed_logins' => 5,
            'locked_until'  => date('Y-m-d H:i:s', time() + 900),
        ]);

        // Attempt refresh
        $res = $this->svc->refresh($refreshToken, '10.0.0.1');
        $this->assertFalse($res['ok']);
        $this->assertSame(429, $res['status']);
        $this->assertStringContainsString('Account is temporarily locked', $res['message']);
    }

    /**
     * Test 11: Plaintext passwords and tokens are never logged to login_history.
     */
    public function testPlaintextPasswordsAndTokensAreNeverLogged(): void
    {
        $sensitivePassword = 'SuperSecretPlaintextPassword!999';
        $this->svc->login('ACME', 'rahim', $sensitivePassword, [], '10.0.0.1');

        $logs = $this->db->table('login_history')->get()->getResultArray();
        foreach ($logs as $log) {
            $dump = json_encode($log);
            $this->assertStringNotContainsString($sensitivePassword, $dump, 'Plaintext password must never appear in login history');
        }
    }
}
