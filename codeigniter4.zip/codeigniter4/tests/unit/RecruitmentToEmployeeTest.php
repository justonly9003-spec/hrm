<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class RecruitmentToEmployeeTest extends TestCase
{
    public function testCandidateHiredCreatesEmployeeProfileStructure()
    {
        $candidate = [
            'id'             => 'CAND-99',
            'first_name'     => 'Anika',
            'last_name'      => 'Tabassum',
            'email'          => 'anika.tabassum@example.com',
            'phone'          => '+880 1711-889900',
            'department_id'  => 'DEPT-ENG',
            'designation_id' => 'DESG-ENG-JR',
            'stage'          => 'Hired',
            'offered_salary' => 45000.0,
            'joining_date'   => date('Y-m-d')
        ];

        // Ensure conversion populates employee schema properly
        $employeeRecord = [
            'id'             => 'EMP-' . strtoupper(substr(md5(uniqid()), 0, 6)),
            'employee_code'  => 'EMP-2026-099',
            'first_name'     => $candidate['first_name'],
            'last_name'      => $candidate['last_name'],
            'email'          => $candidate['email'],
            'phone'          => $candidate['phone'],
            'department_id'  => $candidate['department_id'],
            'designation_id' => $candidate['designation_id'],
            'basic_salary'   => $candidate['offered_salary'],
            'join_date'      => $candidate['joining_date'],
            'status'         => 'Active'
        ];

        $this->assertNotEmpty($employeeRecord['employee_code']);
        $this->assertEquals('Active', $employeeRecord['status']);
        $this->assertEquals('Anika', $employeeRecord['first_name']);
        $this->assertEquals(45000.0, $employeeRecord['basic_salary']);
    }
}
