<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use App\Models\EmployeeModel;
use App\Controllers\Employee\EmployeeController;
use App\Database\Migrations\ScopeEmployeeCodeUniquePerCompany;
use App\Services\AttendanceService;
use App\Services\AttendanceEventService;
use App\Services\BiometricMappingService;
use Config\Database;
use Config\Services;

/**
 * Tests verifying company-scoped employee_code behavior across:
 * 1. Multi-tenant code collision allowance (two companies both having EMP-001)
 * 2. Intra-company duplicate rejection by store(), update(), bulkUpload(), and DB index
 * 3. generateNextAvailableCode() company-scoping (company B ignores company A)
 * 4. Soft-deleted employee code reuse blocked within same company, allowed across companies
 * 5. checkCode() privacy and tenant scoping
 * 6. Migration idempotency and loud failure on existing duplicate (company_id, employee_code)
 * 7. Attendance hardware punch & event service failing closed when code is ambiguous / un-scoped
 * 8. Biometric mapping isolation avoiding cross-tenant auto-matching
 */
class CompanyScopedEmployeeCodeTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected static bool $schemaInitialized = false;

    protected string $companyA = 'comp-tenant-alpha';
    protected string $companyB = 'comp-tenant-beta';

    public static function setUpBeforeClass(): void
    {
        parent::setUpBeforeClass();
        static::ensureSchema();
    }

    public static function registerSqliteFunctions($db): void
    {
        try {
            $rawConn = $db->connID ?? null;
            if ($rawConn instanceof \SQLite3) {
                $rawConn->createFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
            } elseif (is_object($rawConn) && method_exists($rawConn, 'sqliteCreateFunction')) {
                $rawConn->sqliteCreateFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
            }
        } catch (\Throwable $e) {
            // ignore
        }
    }

    protected static function ensureSchema(): void
    {
        $db = Database::connect();
        static::registerSqliteFunctions($db);

        // Ensure employees table exists with company_id and composite unique index
        $db->query("CREATE TABLE IF NOT EXISTS employees (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36) NOT NULL,
            employee_code VARCHAR(50) NOT NULL,
            first_name VARCHAR(100),
            last_name VARCHAR(100),
            email VARCHAR(150),
            phone VARCHAR(50),
            department_id VARCHAR(36),
            designation_id VARCHAR(36),
            shift_id VARCHAR(36),
            branch_id VARCHAR(36),
            employment_type_id VARCHAR(36),
            status VARCHAR(30) DEFAULT 'Active',
            joining_date DATE,
            created_at DATETIME,
            updated_at DATETIME,
            deleted_at DATETIME NULL
        )");

        // Ensure unique index uq_employees_company_code exists
        try {
            $db->query("CREATE UNIQUE INDEX IF NOT EXISTS uq_employees_company_code ON employees (company_id, employee_code)");
        } catch (\Throwable $e) {
            // ignore
        }

        // Users table for store/update
        $db->query("CREATE TABLE IF NOT EXISTS users (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            employee_id VARCHAR(36),
            username VARCHAR(100),
            email VARCHAR(150),
            password_hash VARCHAR(255),
            status VARCHAR(20) DEFAULT 'Active',
            role_id VARCHAR(36),
            created_at DATETIME,
            updated_at DATETIME,
            deleted_at DATETIME NULL
        )");

        // Departments, shifts, branches tables
        $db->query("CREATE TABLE IF NOT EXISTS departments (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            name VARCHAR(100),
            status VARCHAR(20) DEFAULT 'Active'
        )");

        $db->query("CREATE TABLE IF NOT EXISTS shifts (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            name VARCHAR(100),
            start_time TIME DEFAULT '09:00:00',
            end_time TIME DEFAULT '18:00:00',
            grace_period_mins INT DEFAULT 15,
            late_grace_period_minutes INT DEFAULT 15,
            status VARCHAR(20) DEFAULT 'Active'
        )");

        $db->query("CREATE TABLE IF NOT EXISTS biometric_mappings (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36) NOT NULL,
            device_id VARCHAR(50) NULL,
            biometric_user_id VARCHAR(50) NOT NULL,
            device_user_name VARCHAR(100) NULL,
            employee_id VARCHAR(36) NOT NULL,
            status VARCHAR(20) DEFAULT 'Active',
            mapped_by VARCHAR(50) NULL,
            mapped_at DATETIME NULL,
            notes TEXT NULL,
            created_at DATETIME,
            updated_at DATETIME
        )");

        $db->query("CREATE TABLE IF NOT EXISTS unmatched_biometric_identities (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36) NOT NULL,
            biometric_user_id VARCHAR(50) NOT NULL,
            device_id VARCHAR(50) NULL,
            device_name VARCHAR(100) NULL,
            name_from_device VARCHAR(100) NULL,
            first_seen_at DATETIME NULL,
            last_seen_at DATETIME NULL,
            total_events_count INT DEFAULT 1,
            sample_payload TEXT NULL,
            resolution_status VARCHAR(20) DEFAULT 'UNMATCHED',
            resolution_notes TEXT NULL,
            resolved_employee_id VARCHAR(36) NULL,
            resolved_by VARCHAR(36) NULL,
            resolved_at DATETIME NULL,
            created_at DATETIME,
            updated_at DATETIME
        )");

        $db->query("CREATE TABLE IF NOT EXISTS raw_biometric_events (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36) NOT NULL,
            device_id VARCHAR(50) NULL,
            device_name VARCHAR(100) NULL,
            device_serial VARCHAR(50) NULL,
            biometric_user_id VARCHAR(50) NOT NULL,
            name_from_device VARCHAR(100) NULL,
            punch_time DATETIME NOT NULL,
            punch_state INT DEFAULT 1,
            verify_type INT DEFAULT 1,
            raw_payload TEXT NULL,
            matching_status VARCHAR(20) DEFAULT 'PENDING',
            resolved_employee_id VARCHAR(36) NULL,
            created_at DATETIME
        )");

        $db->query("CREATE TABLE IF NOT EXISTS attendance_logs (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36) NOT NULL,
            employee_id VARCHAR(36) NOT NULL,
            date DATE NOT NULL,
            in_time TIME NULL,
            out_time TIME NULL,
            total_working_hours DECIMAL(5,2) DEFAULT 0,
            status VARCHAR(20) DEFAULT 'Present',
            is_settled INT DEFAULT 0,
            created_at DATETIME,
            updated_at DATETIME
        )");
    }

    protected function setUp(): void
    {
        parent::setUp();
        EmployeeModel::resetIndexCache();
        $db = Database::connect();
        $db->table('employees')->emptyTable();
        $db->table('users')->emptyTable();
        $db->table('biometric_mappings')->emptyTable();
        $db->table('unmatched_biometric_identities')->emptyTable();
        $db->table('raw_biometric_events')->emptyTable();
        $db->table('attendance_logs')->emptyTable();
    }

    /**
     * Test 1: Two different companies can both have EMP-001
     */
    public function testTwoCompaniesCanBothHaveSameEmployeeCode(): void
    {
        $model = new EmployeeModel();

        $idA = 'emp-a-001';
        $resA = $model->insert([
            'id'            => $idA,
            'company_id'    => $this->companyA,
            'employee_code' => 'EMP-001',
            'first_name'    => 'Alice',
            'last_name'     => 'Alpha',
            'status'        => 'Active',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);
        $this->assertNotFalse($resA);

        $idB = 'emp-b-001';
        $resB = $model->insert([
            'id'            => $idB,
            'company_id'    => $this->companyB,
            'employee_code' => 'EMP-001',
            'first_name'    => 'Bob',
            'last_name'     => 'Beta',
            'status'        => 'Active',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);
        $this->assertNotFalse($resB);

        // Assert both exist in DB
        $empA = $model->where('company_id', $this->companyA)->where('employee_code', 'EMP-001')->first();
        $empB = $model->where('company_id', $this->companyB)->where('employee_code', 'EMP-001')->first();

        $this->assertNotNull($empA);
        $this->assertNotNull($empB);
        $this->assertEquals($idA, $empA['id']);
        $this->assertEquals($idB, $empB['id']);
    }

    /**
     * Test 2: The same code twice in one company is rejected by store/update/bulkUpload and DB index
     */
    public function testDuplicateCodeWithinSameCompanyIsRejected(): void
    {
        $model = new EmployeeModel();

        // Insert first
        $model->insert([
            'id'            => 'emp-a-001',
            'company_id'    => $this->companyA,
            'employee_code' => 'EMP-001',
            'first_name'    => 'Alice',
            'status'        => 'Active',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);

        // isCodeTaken must be true for companyA, but false for companyB
        $this->assertTrue($model->isCodeTaken('EMP-001', $this->companyA));
        $this->assertFalse($model->isCodeTaken('EMP-001', $this->companyB));

        // DB level rejection on duplicate insert within companyA
        $db = Database::connect();
        $caught = false;
        try {
            $db->table('employees')->insert([
                'id'            => 'emp-a-002',
                'company_id'    => $this->companyA,
                'employee_code' => 'EMP-001',
                'first_name'    => 'Duplicate Alice',
                'status'        => 'Active',
                'created_at'    => date('Y-m-d H:i:s'),
            ]);
        } catch (\Throwable $e) {
            $caught = true;
        }
        $this->assertTrue($caught, 'Database unique index must reject duplicate (company_id, employee_code)');

        // Test update validation check: excluding itself passes, targeting another taken code fails
        $this->assertFalse($model->isCodeTaken('EMP-001', $this->companyA, 'emp-a-001'));
        $this->assertTrue($model->isCodeTaken('EMP-001', $this->companyA, 'emp-a-999'));
    }

    /**
     * Test 3: generateNextAvailableCode() for Company B ignores Company A's codes
     */
    public function testGenerateNextAvailableCodeIsCompanyScoped(): void
    {
        $model = new EmployeeModel();

        // Company A has EMP-001, EMP-002, EMP-003
        for ($i = 1; $i <= 3; $i++) {
            $model->insert([
                'id'            => "emp-a-00{$i}",
                'company_id'    => $this->companyA,
                'employee_code' => sprintf('EMP-%03d', $i),
                'first_name'    => "Emp {$i}",
                'status'        => 'Active',
                'created_at'    => date('Y-m-d H:i:s'),
            ]);
        }

        // Generating for Company A should produce EMP-004
        $nextCodeA = $model->generateNextAvailableCode('EMP-', $this->companyA);
        $this->assertEquals('EMP-004', $nextCodeA);

        // Generating for Company B must start at EMP-001 because Company B has no codes
        $nextCodeB = $model->generateNextAvailableCode('EMP-', $this->companyB);
        $this->assertEquals('EMP-001', $nextCodeB);
    }

    /**
     * Test 4: Soft-deleted employee code still blocks reuse inside its own company only
     */
    public function testSoftDeletedEmployeeCodeBlocksSameCompanyOnly(): void
    {
        $model = new EmployeeModel();

        $model->insert([
            'id'            => 'emp-a-del',
            'company_id'    => $this->companyA,
            'employee_code' => 'EMP-999',
            'first_name'    => 'Deleted Dan',
            'status'        => 'Inactive',
            'created_at'    => date('Y-m-d H:i:s'),
            'deleted_at'    => date('Y-m-d H:i:s'),
        ]);

        // Code EMP-999 must be taken in Company A even though deleted
        $this->assertTrue($model->isCodeTaken('EMP-999', $this->companyA));

        // But must be free in Company B
        $this->assertFalse($model->isCodeTaken('EMP-999', $this->companyB));
    }

    /**
     * Test 5: checkCode() answers only for the requested company and never leaks other tenants
     */
    public function testCheckCodeTenantPrivacy(): void
    {
        $model = new EmployeeModel();

        $model->insert([
            'id'            => 'emp-a-priv',
            'company_id'    => $this->companyA,
            'employee_code' => 'SECRET-01',
            'first_name'    => 'Secret',
            'status'        => 'Active',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);

        // Company A check: taken
        $this->assertTrue($model->isCodeTaken('SECRET-01', $this->companyA));

        // Company B check: available (does not reveal Company A's existence)
        $this->assertFalse($model->isCodeTaken('SECRET-01', $this->companyB));
    }

    /**
     * Test 6: Migration runs idempotently and throws loudly on intra-company duplicates
     */
    public function testMigrationIdempotencyAndLoudFailure(): void
    {
        $migration = new ScopeEmployeeCodeUniquePerCompany();

        // 1. Run up() on clean DB - should succeed without error
        $migration->up();

        // 2. Run up() again immediately - idempotent, must succeed
        $migration->up();

        // 3. Insert duplicate (company_id, employee_code) with raw DB query (bypassing model)
        // Temporarily remove index to simulate dirty legacy database state
        $db = Database::connect();
        try {
            $db->query("DROP INDEX IF EXISTS uq_employees_company_code");
        } catch (\Throwable $e) {
            // ignore
        }

        $db->table('employees')->insert([
            'id'            => 'emp-dup-1',
            'company_id'    => $this->companyA,
            'employee_code' => 'DUP-100',
            'status'        => 'Active',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);

        $db->table('employees')->insert([
            'id'            => 'emp-dup-2',
            'company_id'    => $this->companyA,
            'employee_code' => 'DUP-100',
            'status'        => 'Active',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);

        // Migration up() must now throw \RuntimeException
        $threw = false;
        try {
            $migration->up();
        } catch (\RuntimeException $re) {
            $threw = true;
            $this->assertStringContainsString('DUP-100', $re->getMessage());
        }

        $this->assertTrue($threw, 'Migration up() must throw RuntimeException when intra-company duplicate codes exist');
    }

    /**
     * Test 7: Attendance hardware punch & event processing isolation
     */
    public function testAttendancePunchScopingAndAmbiguousFailure(): void
    {
        $model = new EmployeeModel();

        // Create EMP-001 in Company A
        $model->insert([
            'id'            => 'emp-a-att',
            'company_id'    => $this->companyA,
            'employee_code' => 'EMP-001',
            'first_name'    => 'Alice',
            'status'        => 'Active',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);

        // Create EMP-001 in Company B
        $model->insert([
            'id'            => 'emp-b-att',
            'company_id'    => $this->companyB,
            'employee_code' => 'EMP-001',
            'first_name'    => 'Bob',
            'status'        => 'Active',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);

        $attService = new AttendanceService();

        // Punch with employee_code and Company A context -> maps to Company A
        $resA = $attService->recordHardwarePunch('EMP-001', 'Biometric', date('Y-m-d'), '09:00:00', true, $this->companyA);
        $this->assertTrue($resA['success'] ?? false);

        // Punch with employee_code and NO company context -> fails closed
        $resUnscoped = $attService->recordHardwarePunch('EMP-001', 'Biometric', date('Y-m-d'), '09:05:00', true, null);
        $this->assertFalse($resUnscoped['success'] ?? true);
        $this->assertStringContainsString('company context is required', $resUnscoped['message'] ?? '');
    }

    /**
     * Test 8: Biometric mapping respects tenant company and unmatched flow records identity
     */
    public function testBiometricMappingTenantIsolation(): void
    {
        $model = new EmployeeModel();

        $model->insert([
            'id'            => 'emp-a-bio',
            'company_id'    => $this->companyA,
            'employee_code' => 'BIO-777',
            'first_name'    => 'Alice Bio',
            'status'        => 'Active',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);

        $bioService = new BiometricMappingService();

        // Resolving BIO-777 in Company A resolves Alice
        $resolvedA = $bioService->resolveEmployeeForBiometricPunch('BIO-777', $this->companyA);
        $this->assertNotNull($resolvedA);
        $this->assertEquals('emp-a-bio', $resolvedA['id']);

        // Resolving BIO-777 in Company B returns null (never crosses tenant)
        $resolvedB = $bioService->resolveEmployeeForBiometricPunch('BIO-777', $this->companyB);
        $this->assertNull($resolvedB);

        // Recording unmatched punch in Company B creates unmatched record scoped to Company B
        $unmatchedRes = $bioService->recordUnmatchedPunch([
            'biometric_user_id' => 'BIO-777',
            'punch_time'        => date('Y-m-d H:i:s'),
            'punch_state'       => 1
        ], $this->companyB);

        $this->assertTrue($unmatchedRes['success'] ?? false);
        $this->assertEquals('UNMATCHED', $unmatchedRes['status'] ?? '');

        // Verify unmatched record in DB is scoped to Company B
        $db = Database::connect();
        $unmatchedRow = $db->table('unmatched_biometric_identities')
            ->where('company_id', $this->companyB)
            ->where('biometric_user_id', 'BIO-777')
            ->get()
            ->getRowArray();

        $this->assertNotNull($unmatchedRow);
        $this->assertEquals($this->companyB, $unmatchedRow['company_id']);
    }
}
