CREATE TABLE IF NOT EXISTS companies (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    code VARCHAR(50),
    logo VARCHAR(255),
    status VARCHAR(20) DEFAULT 'Active',
    created_at DATETIME,
    updated_at DATETIME,
    deleted_at DATETIME
);

CREATE TABLE IF NOT EXISTS branches (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36) NOT NULL,
    name VARCHAR(150) NOT NULL,
    code VARCHAR(50),
    status VARCHAR(20) DEFAULT 'Active',
    created_at DATETIME,
    updated_at DATETIME,
    deleted_at DATETIME
);

CREATE TABLE IF NOT EXISTS departments (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36) NOT NULL,
    name VARCHAR(150) NOT NULL,
    code VARCHAR(50),
    status VARCHAR(20) DEFAULT 'Active',
    created_at DATETIME,
    updated_at DATETIME,
    deleted_at DATETIME
);

CREATE TABLE IF NOT EXISTS designations (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36) NOT NULL,
    name VARCHAR(150) NOT NULL,
    title VARCHAR(150),
    code VARCHAR(50),
    status VARCHAR(20) DEFAULT 'Active',
    created_at DATETIME,
    updated_at DATETIME,
    deleted_at DATETIME
);

CREATE TABLE IF NOT EXISTS employment_types (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36),
    name VARCHAR(150) NOT NULL,
    code VARCHAR(50),
    duration_enabled INT DEFAULT 0,
    duration_value INT,
    duration_unit VARCHAR(20),
    status VARCHAR(20) DEFAULT 'Active',
    created_at DATETIME,
    updated_at DATETIME,
    deleted_at DATETIME
);

CREATE TABLE IF NOT EXISTS shifts (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36),
    name VARCHAR(150) NOT NULL,
    start_time TIME,
    end_time TIME,
    status VARCHAR(20) DEFAULT 'Active',
    created_at DATETIME,
    updated_at DATETIME,
    deleted_at DATETIME
);

CREATE TABLE IF NOT EXISTS roles (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    code VARCHAR(50),
    company_id VARCHAR(36),
    status VARCHAR(20) DEFAULT 'Active',
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36),
    branch_id VARCHAR(36),
    department_id VARCHAR(36),
    role_id VARCHAR(36),
    employee_id VARCHAR(36),
    username VARCHAR(100),
    email VARCHAR(100),
    password_hash VARCHAR(255),
    status VARCHAR(20) DEFAULT 'Active',
    failed_logins INT DEFAULT 0,
    locked_until DATETIME,
    last_login_at DATETIME,
    created_at DATETIME,
    updated_at DATETIME,
    deleted_at DATETIME
);

CREATE TABLE IF NOT EXISTS employees (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36),
    company_id VARCHAR(36) NOT NULL,
    branch_id VARCHAR(36),
    department_id VARCHAR(36),
    designation_id VARCHAR(36),
    employment_type_id VARCHAR(36),
    shift_id VARCHAR(36),
    reporting_manager_id VARCHAR(36),
    employee_code VARCHAR(50),
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    email VARCHAR(100),
    official_email VARCHAR(100),
    phone VARCHAR(50),
    gender VARCHAR(20),
    dob DATE,
    photo VARCHAR(255),
    joining_date DATE,
    join_date DATE,
    confirmation_date DATE,
    employment_start_date DATE,
    status VARCHAR(20) DEFAULT 'Active',
    last_working_date DATE,
    termination_date DATE,
    resignation_date DATE,
    separation_date DATE,
    probation_status VARCHAR(20),
    probation_period_months INT,
    is_pf_applicable INT DEFAULT 0,
    pf_status VARCHAR(20),
    pf_member_id VARCHAR(50),
    gratuity_settings TEXT,
    tax_category VARCHAR(50) DEFAULT 'General',
    tax_identification_number VARCHAR(100),
    tin_number VARCHAR(100),
    other_deductions DECIMAL(15,2) DEFAULT 0,
    created_at DATETIME,
    updated_at DATETIME,
    deleted_at DATETIME
);

CREATE TABLE IF NOT EXISTS employee_salaries (
    id VARCHAR(36) PRIMARY KEY,
    employee_id VARCHAR(36) NOT NULL,
    company_id VARCHAR(36) NOT NULL,
    basic_salary DECIMAL(15,2) DEFAULT 0,
    gross_salary DECIMAL(15,2) DEFAULT 0,
    house_rent DECIMAL(15,2) DEFAULT 0,
    medical_allowance DECIMAL(15,2) DEFAULT 0,
    conveyance_allowance DECIMAL(15,2) DEFAULT 0,
    other_allowances DECIMAL(15,2) DEFAULT 0,
    effective_from DATE,
    effective_to DATE,
    effective_date DATE,
    custom_components_json TEXT,
    status VARCHAR(20) DEFAULT 'Active',
    structure_id VARCHAR(36),
    structure_name VARCHAR(150),
    gratuity_settings TEXT,
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS bonus_types (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36) NOT NULL,
    name VARCHAR(150),
    type_code VARCHAR(50),
    created_at DATETIME
);

CREATE TABLE IF NOT EXISTS bonus_schemes (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36),
    name VARCHAR(150),
    title VARCHAR(150),
    code VARCHAR(50),
    category VARCHAR(50) DEFAULT 'Festival',
    calculation_type VARCHAR(50) DEFAULT 'Percentage_Basic',
    value DECIMAL(12,2) DEFAULT 0.00,
    salary_basis VARCHAR(50) DEFAULT 'Basic Salary',
    scope_level VARCHAR(50) DEFAULT 'Global',
    scope_id VARCHAR(64),
    scope_name VARCHAR(150),
    min_service_days INT DEFAULT 90,
    prorate_under_service_days INT DEFAULT 1,
    prorate_threshold_months INT DEFAULT 6,
    include_probation INT DEFAULT 1,
    priority INT DEFAULT 1,
    custom_formula TEXT,
    config_json LONGTEXT,
    status VARCHAR(30) DEFAULT 'Active',
    effective_from DATE,
    description TEXT,
    created_by VARCHAR(64),
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS bonus_records (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36) NOT NULL,
    employee_id VARCHAR(36) NOT NULL,
    employee_name VARCHAR(150),
    department_id VARCHAR(36),
    department_name VARCHAR(100),
    scheme_id VARCHAR(64),
    scheme_code VARCHAR(50),
    bonus_type_id VARCHAR(36),
    bonus_title VARCHAR(150),
    category VARCHAR(50) DEFAULT 'Festival',
    amount DECIMAL(15,2) DEFAULT 0,
    bonus_month VARCHAR(50),
    year INT,
    base_salary DECIMAL(15,2) DEFAULT 0,
    calculation_formula VARCHAR(255),
    gross_calculated_amount DECIMAL(15,2) DEFAULT 0,
    tenure_months DECIMAL(6,2) DEFAULT 0,
    prorated_ratio DECIMAL(5,4) DEFAULT 1.0000,
    attendance_penalty_ratio DECIMAL(5,4) DEFAULT 1.0000,
    duplicate_check_hash VARCHAR(128),
    payout_month VARCHAR(7),
    swept_by VARCHAR(100),
    swept_at DATETIME,
    swept_reason TEXT,
    payroll_id VARCHAR(36),
    status VARCHAR(30) DEFAULT 'Pending',
    is_settled_in_payroll INT DEFAULT 0,
    adjustment_reason TEXT,
    adjustment_json LONGTEXT,
    notes TEXT,
    rules_snapshot_json LONGTEXT,
    created_by VARCHAR(36),
    approved_by VARCHAR(100),
    approved_at DATETIME,
    rejected_by VARCHAR(100),
    rejected_at DATETIME,
    rejection_reason TEXT,
    created_at DATETIME,
    updated_at DATETIME,
    deleted_at DATETIME
);

CREATE TABLE IF NOT EXISTS weekly_bonus_records (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36) NOT NULL,
    employee_id VARCHAR(36) NOT NULL,
    week_start_date DATE NOT NULL,
    week_end_date DATE NOT NULL,
    bonus_amount DECIMAL(15,2) NOT NULL,
    is_eligible INT DEFAULT 1,
    ineligibility_reason TEXT,
    calculation_method VARCHAR(50) DEFAULT 'Disabled',
    status VARCHAR(30) DEFAULT 'Pending',
    payout_month VARCHAR(7),
    swept_by VARCHAR(100),
    swept_at DATETIME,
    swept_reason TEXT,
    payroll_id VARCHAR(36),
    rules_snapshot_json LONGTEXT,
    created_by VARCHAR(36),
    approved_by VARCHAR(100),
    approved_at DATETIME,
    rejected_by VARCHAR(100),
    rejected_at DATETIME,
    rejection_reason TEXT,
    created_at DATETIME,
    updated_at DATETIME,
    deleted_at DATETIME
);

CREATE TABLE IF NOT EXISTS payrolls (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36) NOT NULL,
    employee_id VARCHAR(36),
    batch_id VARCHAR(50),
    payroll_month VARCHAR(7) NOT NULL,
    month INT,
    year INT,
    status VARCHAR(30) DEFAULT 'Draft',
    is_locked INT DEFAULT 0,
    locked_at DATETIME,
    locked_by VARCHAR(36),
    basic_salary DECIMAL(15,2) DEFAULT 0,
    house_rent DECIMAL(15,2) DEFAULT 0,
    medical_allowance DECIMAL(15,2) DEFAULT 0,
    conveyance_allowance DECIMAL(15,2) DEFAULT 0,
    overtime_amount DECIMAL(15,2) DEFAULT 0,
    bonus DECIMAL(15,2) DEFAULT 0,
    gross_salary DECIMAL(15,2) DEFAULT 0,
    total_gross DECIMAL(15,2) DEFAULT 0,
    tax_deduction DECIMAL(15,2) DEFAULT 0,
    provident_fund DECIMAL(15,2) DEFAULT 0,
    loan_deduction DECIMAL(15,2) DEFAULT 0,
    late_deduction DECIMAL(15,2) DEFAULT 0,
    total_deductions DECIMAL(15,2) DEFAULT 0,
    net_salary DECIMAL(15,2) DEFAULT 0,
    total_net DECIMAL(15,2) DEFAULT 0,
    employee_count INT DEFAULT 0,
    prepared_by VARCHAR(36),
    created_by VARCHAR(36),
    approved_by VARCHAR(36),
    disbursed_by VARCHAR(36),
    disbursement_date DATE,
    created_at DATETIME,
    updated_at DATETIME,
    deleted_at DATETIME
);

CREATE TABLE IF NOT EXISTS payroll_items (
    id VARCHAR(36) PRIMARY KEY,
    payroll_id VARCHAR(36) NOT NULL,
    employee_id VARCHAR(36) NOT NULL,
    basic_salary DECIMAL(15,2) DEFAULT 0,
    gross_salary DECIMAL(15,2) DEFAULT 0,
    net_salary DECIMAL(15,2) DEFAULT 0,
    bonus DECIMAL(15,2) DEFAULT 0,
    bonus_amount DECIMAL(15,2) DEFAULT 0,
    house_rent DECIMAL(15,2) DEFAULT 0,
    medical DECIMAL(15,2) DEFAULT 0,
    conveyance DECIMAL(15,2) DEFAULT 0,
    allowances DECIMAL(15,2) DEFAULT 0,
    other_allowances DECIMAL(15,2) DEFAULT 0,
    overtime_amount DECIMAL(15,2) DEFAULT 0,
    incentive_amount DECIMAL(15,2) DEFAULT 0,
    arrear_amount DECIMAL(15,2) DEFAULT 0,
    leave_encashment DECIMAL(15,2) DEFAULT 0,
    tax_deduction DECIMAL(15,2) DEFAULT 0,
    pf_deduction DECIMAL(15,2) DEFAULT 0,
    arrear_pf_deduction DECIMAL(15,2) DEFAULT 0,
    arrear_pf_employer DECIMAL(15,2) DEFAULT 0,
    has_pf_arrear_recovery INT DEFAULT 0,
    loan_emi DECIMAL(15,2) DEFAULT 0,
    advance_recovery DECIMAL(15,2) DEFAULT 0,
    unpaid_leave_deduction DECIMAL(15,2) DEFAULT 0,
    lop_deduction DECIMAL(15,2) DEFAULT 0,
    late_penalty DECIMAL(15,2) DEFAULT 0,
    other_deductions DECIMAL(15,2) DEFAULT 0,
    total_deductions DECIMAL(15,2) DEFAULT 0,
    payment_status VARCHAR(30) DEFAULT 'Draft',
    is_pf_applicable INT DEFAULT 0,
    pf_status VARCHAR(30) DEFAULT 'Not Enrolled',
    pf_rule_id VARCHAR(36),
    pf_rule_name VARCHAR(150),
    pf_contribution_type VARCHAR(50),
    employer_pf_contribution DECIMAL(15,2) DEFAULT 0,
    gratuity_provision DECIMAL(15,2) DEFAULT 0,
    unapplied_tax DECIMAL(15,2) DEFAULT 0,
    unapplied_pf DECIMAL(15,2) DEFAULT 0,
    unapplied_lop DECIMAL(15,2) DEFAULT 0,
    tax_year VARCHAR(20),
    rule_version INT DEFAULT 1,
    tax_rule_version INT DEFAULT 1,
    components_breakdown_json LONGTEXT,
    rules_snapshot_json LONGTEXT,
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS rule_definitions (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36) NOT NULL,
    domain VARCHAR(30) NOT NULL,
    scope_level VARCHAR(20) NOT NULL,
    scope_id VARCHAR(36),
    version_number INT NOT NULL,
    effective_from DATE NOT NULL,
    effective_to DATE,
    status VARCHAR(20) NOT NULL,
    params_json LONGTEXT NOT NULL,
    schema_version INT NOT NULL,
    change_reason TEXT,
    created_by VARCHAR(36),
    updated_by VARCHAR(36),
    approved_by VARCHAR(36),
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS rule_change_log (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36) NOT NULL,
    rule_id VARCHAR(36) NOT NULL,
    domain VARCHAR(30) NOT NULL,
    action VARCHAR(20) NOT NULL,
    old_params_json LONGTEXT,
    new_params_json LONGTEXT,
    actor_id VARCHAR(36),
    reason TEXT,
    created_at DATETIME
);

CREATE TABLE IF NOT EXISTS audit_logs (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36),
    user_id VARCHAR(36),
    action VARCHAR(50),
    entity_type VARCHAR(50),
    entity_id VARCHAR(36),
    details TEXT,
    created_at DATETIME
);

CREATE TABLE IF NOT EXISTS provident_fund_ledgers (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36) NOT NULL,
    employee_id VARCHAR(36) NOT NULL,
    payroll_id VARCHAR(36),
    payroll_month INT,
    payroll_year INT,
    transaction_date DATE,
    transaction_type VARCHAR(50),
    employee_share DECIMAL(15,2) DEFAULT 0,
    employer_share DECIMAL(15,2) DEFAULT 0,
    interest_amount DECIMAL(15,2) DEFAULT 0,
    balance DECIMAL(15,2) DEFAULT 0,
    status VARCHAR(20) DEFAULT 'posted',
    rules_snapshot_json LONGTEXT,
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS provident_fund_ledger (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36) NOT NULL,
    employee_id VARCHAR(36) NOT NULL,
    payroll_id VARCHAR(36),
    payroll_month INT,
    payroll_year INT,
    transaction_date DATE,
    transaction_type VARCHAR(50),
    employee_share DECIMAL(15,2) DEFAULT 0,
    employer_share DECIMAL(15,2) DEFAULT 0,
    interest_amount DECIMAL(15,2) DEFAULT 0,
    balance DECIMAL(15,2) DEFAULT 0,
    status VARCHAR(20) DEFAULT 'posted',
    rules_snapshot_json LONGTEXT,
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS salary_grades (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36),
    grade_name VARCHAR(100),
    grade_code VARCHAR(50) DEFAULT 'GRD',
    minimum_salary DECIMAL(15,2) DEFAULT 0.00,
    maximum_salary DECIMAL(15,2) DEFAULT 0.00,
    min_salary DECIMAL(15,2) DEFAULT 0.00,
    max_salary DECIMAL(15,2) DEFAULT 0.00,
    default_allowances JSON,
    benefits TEXT,
    status VARCHAR(20) DEFAULT 'Active',
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS salary_components (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36),
    code VARCHAR(50),
    name VARCHAR(150),
    type VARCHAR(50),
    category VARCHAR(50),
    is_taxable INT DEFAULT 0,
    is_included_in_gross INT DEFAULT 1,
    include_in_pf_basis INT DEFAULT 0,
    is_active INT DEFAULT 1,
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS salary_structures (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36),
    name VARCHAR(150),
    code VARCHAR(50),
    description TEXT,
    is_active INT DEFAULT 1,
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS salary_structure_items (
    id VARCHAR(36) PRIMARY KEY,
    structure_id VARCHAR(36),
    component_id VARCHAR(36),
    component_code VARCHAR(50),
    type VARCHAR(50),
    calculation_type VARCHAR(50),
    value DECIMAL(15,2) DEFAULT 0,
    is_active INT DEFAULT 1,
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS loans (
    id VARCHAR(36) PRIMARY KEY,
    employee_id VARCHAR(36) NOT NULL,
    company_id VARCHAR(36) NOT NULL,
    amount DECIMAL(15,2) DEFAULT 0,
    principal_amount DECIMAL(15,2) DEFAULT 0,
    monthly_installment DECIMAL(15,2) DEFAULT 0,
    monthly_emi DECIMAL(15,2) DEFAULT 0,
    total_paid DECIMAL(15,2) DEFAULT 0,
    total_due DECIMAL(15,2) DEFAULT 0,
    disbursement_date DATE,
    status VARCHAR(30) DEFAULT 'Active',
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS employee_loans (
    id VARCHAR(36) PRIMARY KEY,
    employee_id VARCHAR(36) NOT NULL,
    company_id VARCHAR(36),
    loan_type VARCHAR(100) DEFAULT 'Corporate Loan',
    amount DECIMAL(15,2) DEFAULT 0,
    principal_amount DECIMAL(15,2) DEFAULT 0,
    loan_amount DECIMAL(15,2) DEFAULT 0,
    monthly_installment DECIMAL(15,2) DEFAULT 0,
    monthly_emi DECIMAL(15,2) DEFAULT 0,
    total_installments INT,
    remaining_installments INT,
    repayment_months INT,
    total_paid DECIMAL(15,2) DEFAULT 0,
    total_due DECIMAL(15,2) DEFAULT 0,
    total_amount DECIMAL(15,2),
    start_month VARCHAR(7),
    interest_rate DECIMAL(5,2) DEFAULT 0,
    interest_method VARCHAR(20) DEFAULT 'flat',
    disbursement_date DATE,
    disbursed_date DATE,
    status VARCHAR(30) DEFAULT 'Pending',
    purpose VARCHAR(255),
    reason TEXT,
    approved_by VARCHAR(36),
    approved_at DATETIME,
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS loan_repayments (
    id VARCHAR(36) PRIMARY KEY,
    loan_id VARCHAR(36) NOT NULL,
    employee_id VARCHAR(36) NOT NULL,
    company_id VARCHAR(36),
    payroll_item_id VARCHAR(36),
    payroll_month VARCHAR(20) NOT NULL,
    amount DECIMAL(15,2) DEFAULT 0,
    status VARCHAR(30) DEFAULT 'pending',
    settlement_id VARCHAR(36),
    created_at DATETIME,
    updated_at DATETIME,
    UNIQUE(loan_id, payroll_month)
);

CREATE TABLE IF NOT EXISTS loan_ledger_entries (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36),
    loan_id VARCHAR(36) NOT NULL,
    entry_type VARCHAR(30) NOT NULL,
    amount DECIMAL(15,2) DEFAULT 0,
    payroll_item_id VARCHAR(36),
    payroll_id VARCHAR(36),
    settlement_id VARCHAR(36),
    created_by VARCHAR(36),
    created_at DATETIME
);

CREATE TABLE IF NOT EXISTS final_settlements (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36),
    employee_id VARCHAR(36) NOT NULL,
    separation_id VARCHAR(36),
    resignation_or_termination_id VARCHAR(36),
    settlement_date DATE,
    working_days_in_month INT DEFAULT 0,
    salary_payable_days DECIMAL(5,2) DEFAULT 0,
    payable_salary DECIMAL(15,2) DEFAULT 0.00,
    leave_encashment_days DECIMAL(5,2) DEFAULT 0,
    leave_encashment_amount DECIMAL(15,2) DEFAULT 0.00,
    bonus_pending DECIMAL(15,2) DEFAULT 0.00,
    other_allowances DECIMAL(15,2) DEFAULT 0.00,
    total_payable DECIMAL(15,2) DEFAULT 0.00,
    notice_period_required_days INT DEFAULT 30,
    notice_period_served_days INT DEFAULT 30,
    notice_shortfall_days INT DEFAULT 0,
    notice_shortfall_deduction DECIMAL(15,2) DEFAULT 0.00,
    outstanding_loan_deduction DECIMAL(15,2) DEFAULT 0.00,
    outstanding_advance_deduction DECIMAL(15,2) DEFAULT 0.00,
    tax_deduction DECIMAL(15,2) DEFAULT 0.00,
    provident_fund_employee DECIMAL(15,2) DEFAULT 0.00,
    provident_fund_employer DECIMAL(15,2) DEFAULT 0.00,
    asset_recovery_deduction DECIMAL(15,2) DEFAULT 0.00,
    other_deductions DECIMAL(15,2) DEFAULT 0.00,
    total_deductions DECIMAL(15,2) DEFAULT 0.00,
    net_settlement_amount DECIMAL(15,2) DEFAULT 0.00,
    payment_status VARCHAR(30) DEFAULT 'Draft',
    disbursement_date DATE,
    disbursed_by VARCHAR(36),
    payment_method VARCHAR(50) DEFAULT 'Bank Transfer',
    transaction_reference VARCHAR(100),
    active_key VARCHAR(100),
    tax_note TEXT,
    settlement_loan_lines_json TEXT,
    settlement_leave_lines_json TEXT,
    settlement_advance_lines_json TEXT,
    rules_snapshot_json LONGTEXT,
    remarks TEXT,
    prepared_by VARCHAR(36),
    approved_by VARCHAR(36),
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS salary_advances (
    id VARCHAR(64) PRIMARY KEY,
    company_id VARCHAR(64),
    employee_id VARCHAR(64) NOT NULL,
    amount DECIMAL(15,2) DEFAULT 0,
    original_amount DECIMAL(15,2) DEFAULT 0,
    recovered_amount DECIMAL(15,2) DEFAULT 0,
    disbursed_at DATETIME,
    advance_month VARCHAR(20),
    repayment_month VARCHAR(20),
    repayment_year INT,
    reason TEXT,
    status VARCHAR(30) DEFAULT 'Pending',
    approved_by VARCHAR(64),
    approved_at DATETIME,
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS advance_recoveries (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36),
    advance_id VARCHAR(64) NOT NULL,
    payroll_item_id VARCHAR(36),
    month VARCHAR(7) NOT NULL,
    amount DECIMAL(15,2) DEFAULT 0,
    status VARCHAR(30) DEFAULT 'pending',
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS advance_salaries (
    id VARCHAR(36) PRIMARY KEY,
    employee_id VARCHAR(36) NOT NULL,
    company_id VARCHAR(36) NOT NULL,
    amount DECIMAL(15,2) DEFAULT 0,
    repayment_month VARCHAR(20),
    status VARCHAR(30) DEFAULT 'Approved',
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS payroll_generation_locks (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36) NOT NULL,
    payroll_month VARCHAR(7) NOT NULL,
    lock_token VARCHAR(64) NOT NULL,
    locked_by VARCHAR(36),
    locked_at DATETIME,
    expires_at DATETIME NOT NULL,
    created_at DATETIME
);

CREATE TABLE IF NOT EXISTS permissions (
    id VARCHAR(36) PRIMARY KEY,
    module VARCHAR(50),
    action VARCHAR(50),
    name VARCHAR(100),
    code VARCHAR(100) UNIQUE,
    description TEXT,
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS role_permissions (
    id VARCHAR(64) PRIMARY KEY,
    role_id VARCHAR(36),
    permission_id VARCHAR(36),
    scope_level VARCHAR(20) DEFAULT 'company',
    created_at DATETIME
);

CREATE TABLE IF NOT EXISTS user_permissions (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36),
    permission_id VARCHAR(36),
    is_granted TINYINT(1) DEFAULT 1,
    scope_level VARCHAR(20) DEFAULT 'company',
    expires_at DATETIME,
    created_at DATETIME
);

CREATE TABLE IF NOT EXISTS company_assets (
    id VARCHAR(36) PRIMARY KEY,
    company_id VARCHAR(36),
    category_id VARCHAR(36),
    asset_name VARCHAR(150),
    asset_code VARCHAR(100),
    serial_number VARCHAR(100),
    category VARCHAR(100),
    assigned_to VARCHAR(36),
    assigned_date DATE,
    purchase_date DATE,
    purchase_value DECIMAL(15,2),
    warranty_expiry DATE,
    condition_status VARCHAR(50) DEFAULT 'good',
    status VARCHAR(50) DEFAULT 'Available',
    notes TEXT,
    written_off_at DATETIME,
    written_off_reason VARCHAR(50),
    written_off_by_employee_id VARCHAR(36),
    recovery_amount DECIMAL(15,2),
    recovery_settlement_id VARCHAR(36),
    recovery_settled_at DATETIME,
    deleted_at DATETIME,
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS employee_resignations (
    id VARCHAR(36) PRIMARY KEY,
    employee_id VARCHAR(36),
    submission_date DATE,
    notice_date DATE,
    resignation_date DATE,
    reason TEXT,
    status VARCHAR(50) DEFAULT 'Pending',
    manager_review TEXT,
    hr_review TEXT,
    approved_by VARCHAR(255),
    clearance_status VARCHAR(50) DEFAULT 'In Progress',
    final_settlement_status VARCHAR(50) DEFAULT 'Pending',
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS employee_terminations (
    id VARCHAR(36) PRIMARY KEY,
    employee_id VARCHAR(36),
    termination_date DATE,
    termination_type VARCHAR(100),
    reason TEXT,
    notice_period_days INT DEFAULT 0,
    status VARCHAR(50) DEFAULT 'Approved',
    approved_by VARCHAR(255),
    clearance_status VARCHAR(50) DEFAULT 'In Progress',
    exit_interview_notes TEXT,
    final_settlement_status VARCHAR(50) DEFAULT 'Pending',
    terminated_by VARCHAR(36),
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS mobile_devices (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    company_id VARCHAR(36),
    device_uid VARCHAR(100) NOT NULL,
    platform VARCHAR(20),
    device_name VARCHAR(150),
    app_version VARCHAR(30),
    push_token VARCHAR(512),
    last_seen_at DATETIME,
    revoked_at DATETIME,
    created_at DATETIME,
    updated_at DATETIME,
    UNIQUE(user_id, device_uid)
);

CREATE TABLE IF NOT EXISTS mobile_refresh_tokens (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    company_id VARCHAR(36),
    device_id VARCHAR(36) NOT NULL,
    family_id VARCHAR(36) NOT NULL,
    token_hash VARCHAR(64) UNIQUE NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    revoked_at DATETIME,
    replaced_by_id VARCHAR(36),
    created_ip VARCHAR(45),
    created_at DATETIME
);

CREATE TABLE IF NOT EXISTS mobile_access_tokens (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    device_id VARCHAR(36) NOT NULL,
    refresh_token_id VARCHAR(36),
    token_hash VARCHAR(64) UNIQUE NOT NULL,
    expires_at DATETIME NOT NULL,
    revoked_at DATETIME,
    created_at DATETIME
);



