<?php

namespace Tests\Unit\Rules;

use App\Models\RuleDefinitionModel;
use App\Services\Rules\RuleParamValidator;
use App\Services\PermissionService;
use App\Services\Rules\RuleAccessPolicy;
use App\Services\Rules\RuleResolver;
use App\Services\Rules\RuleSchemaRegistry;
use App\Services\Rules\RuleWriteService;
use Config\Database;
use PHPUnit\Framework\TestCase;

/**
 * Unit tests for Rule Admin API validation logic, atomic publish overlap detection,
 * and date closure calculations.
 */
class RuleAdminApiTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        if (function_exists('session')) {
            try {
                \Config\Services::session()->destroy();
            } catch (\Throwable $e) {}
        }
        if (isset($_SESSION)) {
            $_SESSION = [];
        }
        if (class_exists(\Config\Services::class)) {
            try {
                \Config\Services::reset(true);
            } catch (\Throwable $e) {}
        }
        RuleResolver::flush(true);
        RuleResolver::resetMemo();
        RuleSchemaRegistry::init();
    }

    protected function tearDown(): void
    {
        RuleResolver::flush(true);
        RuleResolver::resetMemo();
        if (function_exists('session')) {
            try {
                \Config\Services::session()->destroy();
            } catch (\Throwable $e) {}
        }
        if (isset($_SESSION)) {
            $_SESSION = [];
        }
        if (class_exists(\Config\Services::class)) {
            try {
                \Config\Services::reset(true);
            } catch (\Throwable $e) {}
        }
        RuleWriteService::resetMakerCheckerOverrides();
        parent::tearDown();
    }

    /**
     * Test predecessor closing date calculation:
     * When Version 2 is published with effective_from = '2025-07-01',
     * the predecessor Version 1 (starting '2025-01-01', open-ended) must close at '2025-06-30'.
     */
    public function testPredecessorCloseDateCalculation()
    {
        $newEffectiveFrom = '2025-07-01';
        $closedDate = date('Y-m-d', strtotime($newEffectiveFrom . ' - 1 day'));
        $this->assertEquals('2025-06-30', $closedDate);

        // Ensure closedDate is strictly on or after predecessor's effective_from
        $predEffectiveFrom = '2025-01-01';
        $this->assertGreaterThanOrEqual($predEffectiveFrom, $closedDate);
    }

    /**
     * Test overlap rejection logic:
     * If an existing active version has range ['2026-01-01', '2026-12-31'],
     * attempting to publish a version with range ['2025-07-01', null] (open-ended) overlaps and must be rejected.
     */
    public function testActiveRangeOverlapDetection()
    {
        $infinity = '9999-12-31';

        // Existing active rule
        $existingFrom = '2026-01-01';
        $existingTo   = '2026-12-31';

        // Candidate publish
        $newFrom = '2025-07-01';
        $newTo   = null;
        $candidateEnd = $newTo ?? $infinity;

        // Overlap formula: newFrom <= existingTo && existingFrom <= candidateEnd
        $hasOverlap = ($newFrom <= $existingTo && $existingFrom <= $candidateEnd);
        $this->assertTrue($hasOverlap, 'Should detect overlap between candidate open-ended rule and future active rule');
    }

    /**
     * Test non-overlapping ranges succeed:
     * Version 1: ['2025-01-01', '2025-06-30']
     * Version 2: ['2025-07-01', '2025-12-31']
     */
    public function testNonOverlappingRangesAllowed()
    {
        $v1From = '2025-01-01';
        $v1To   = '2025-06-30';

        $v2From = '2025-07-01';
        $v2To   = '2025-12-31';

        $hasOverlap = ($v2From <= $v1To && $v1From <= $v2To);
        $this->assertFalse($hasOverlap, 'Sequential non-overlapping ranges must not trigger collision');
    }

    /**
     * Test RuleParamValidator enforcement for Company scope (requires all mandatory keys)
     */
    public function testParamValidationForCompanyScopeRejectsIncomplete()
    {
        // Company scope requires all keys defined in schema
        $incompleteParams = [
            'daily_threshold_hours' => 8.0,
            // Missing all other keys
        ];

        $res = RuleParamValidator::validate('OVERTIME', 'Company', $incompleteParams, false);
        $this->assertFalse($res['valid']);
        $this->assertNotEmpty($res['errors']);
    }

    /**
     * Test RuleParamValidator enforcement for partial override (Employee scope)
     */
    public function testParamValidationForEmployeeScopeAllowsPartial()
    {
        $partialParams = [
            'daily_threshold_hours' => 7.5,
        ];

        $res = RuleParamValidator::validate('OVERTIME', 'Employee', $partialParams, true);
        $this->assertTrue($res['valid']);
        $this->assertEquals(7.5, $res['clean']['daily_threshold_hours']);
    }

    /**
     * Test RuleParamValidator rejects invalid values even on partial scopes
     */
    public function testParamValidationRejectsInvalidTypesOnPartialScope()
    {
        $invalidParams = [
            'daily_threshold_hours' => -2.0, // min is 0.0
        ];

        $res = RuleParamValidator::validate('OVERTIME', 'Employee', $invalidParams, true);
        $this->assertFalse($res['valid']);
        $this->assertArrayHasKey('daily_threshold_hours', $res['errors']);
    }

    /**
     * Test crafted POST /rules/version/save renaming a locked scheme code gets rejected
     */
    public function testCraftedSavePostRenamingLockedSchemeCodeIsRejected()
    {
        // Locked scheme references in bonus_records (via scheme_code, scheme_id, bonus_title)
        $lockedRecord = [
            'scheme_code' => 'EID_FITR',
            'scheme_id'   => 'SCHEME-001',
            'bonus_title' => 'Eid Festival Bonus',
        ];

        $existingCompanySchemes = [
            [
                'code'             => 'EID_FITR',
                'name'             => 'Eid Festival Bonus',
                'calculation_type' => 'Percentage_Basic',
                'value'            => 100.0,
                'salary_basis'     => 'Basic Salary',
                'status'           => 'Active',
                'min_service_days' => 90,
            ]
        ];

        // Crafted payload renaming code to EID_RENAMED
        $craftedSavePayload = [
            'domain'         => 'BONUS',
            'scope_level'    => 'Company',
            'effective_from' => '2026-10-01',
            'schemes'        => [
                [
                    'code'             => 'EID_RENAMED',
                    'name'             => 'Eid Festival Bonus',
                    'calculation_type' => 'Percentage_Basic',
                    'value'            => 100.0,
                    'salary_basis'     => 'Basic Salary',
                    'status'           => 'Active',
                    'min_service_days' => 90,
                ]
            ]
        ];

        // Check columns used: scheme_code, scheme_id, bonus_title
        $lockedCodes = [
            strtoupper($lockedRecord['scheme_code']) => true,
            strtoupper($lockedRecord['scheme_id'])   => true,
            strtoupper($lockedRecord['bonus_title']) => true,
        ];

        $submittedCodes = [];
        foreach ($craftedSavePayload['schemes'] as $sc) {
            $submittedCodes[strtoupper(trim($sc['code']))] = true;
        }

        $rejectionReason = null;
        foreach ($existingCompanySchemes as $ps) {
            $oldCode = strtoupper(trim($ps['code']));
            if (isset($lockedCodes[$oldCode]) && !isset($submittedCodes[$oldCode])) {
                $rejectionReason = "Bonus scheme '{$oldCode}' cannot be deleted or have its code renamed because existing bonus records reference it. You may deactivate it by setting status to Inactive instead.";
                break;
            }
        }

        $this->assertNotNull($rejectionReason);
        $this->assertStringContainsString("Bonus scheme 'EID_FITR' cannot be deleted or have its code renamed", $rejectionReason);
    }

    /**
     * Test crafted POST /rules/version/save deleting a locked scheme in a NEW version for a future date is rejected
     */
    public function testCraftedSavePostDeletingLockedSchemeInFutureVersionIsRejected()
    {
        $lockedCode = 'EID_FITR';
        $companyHistoricalSchemes = [
            ['code' => 'EID_FITR', 'name' => 'Eid Festival Bonus', 'status' => 'Active']
        ];

        // Crafted payload for future date omitting EID_FITR
        $craftedFutureVersionSavePayload = [
            'domain'         => 'BONUS',
            'scope_level'    => 'Company',
            'effective_from' => '2028-01-01', // Future date
            'schemes'        => [
                [
                    'code'             => 'FUTURE_BONUS_2028',
                    'name'             => '2028 Special Bonus',
                    'calculation_type' => 'Flat',
                    'value'            => 15000.0,
                    'salary_basis'     => 'Basic Salary',
                    'status'           => 'Active',
                    'min_service_days' => 180,
                ]
            ]
        ];

        $newCodes = [];
        foreach ($craftedFutureVersionSavePayload['schemes'] as $s) {
            $newCodes[strtoupper(trim($s['code']))] = true;
        }

        $rejectionReason = null;
        if (!isset($newCodes[$lockedCode])) {
            $rejectionReason = "Bonus scheme '{$lockedCode}' cannot be deleted or have its code renamed because existing bonus records reference it. You may deactivate it by setting status to Inactive instead.";
        }

        $this->assertNotNull($rejectionReason);
        $this->assertStringContainsString("Bonus scheme 'EID_FITR' cannot be deleted or have its code renamed", $rejectionReason);

        // However, submitting with status = Inactive preserves the code and is accepted
        $craftedDeactivationPayload = [
            'domain'         => 'BONUS',
            'scope_level'    => 'Company',
            'effective_from' => '2028-01-01',
            'schemes'        => [
                [
                    'code'             => 'EID_FITR',
                    'name'             => 'Eid Festival Bonus',
                    'calculation_type' => 'Flat',
                    'value'            => 0.0,
                    'salary_basis'     => 'Basic Salary',
                    'status'           => 'Inactive', // Deactivated!
                    'min_service_days' => 90,
                ],
                [
                    'code'             => 'FUTURE_BONUS_2028',
                    'name'             => '2028 Special Bonus',
                    'calculation_type' => 'Flat',
                    'value'            => 15000.0,
                    'salary_basis'     => 'Basic Salary',
                    'status'           => 'Active',
                    'min_service_days' => 180,
                ]
            ]
        ];

        $deactCodes = [];
        foreach ($craftedDeactivationPayload['schemes'] as $s) {
            $deactCodes[strtoupper(trim($s['code']))] = true;
        }

        $this->assertTrue(isset($deactCodes[$lockedCode]), 'Preserving locked code as Inactive satisfies invariant');
    }

    /**
     * Rules access is resolved from assigned permissions, not hardcoded roles.
     */
    public function testRulesModuleAccessUsesAssignedPermissions()
    {
        $permissions = $this->createMock(PermissionService::class);
        $grantedPermissions = ['rules.view'];
        $permissions->expects($this->exactly(4))
            ->method('hasPermission')
            ->willReturnCallback(static function (string $userId, string $code) use (&$grantedPermissions): bool {
                return in_array($code, $grantedPermissions, true);
            });

        $this->assertTrue(RuleAccessPolicy::canView($permissions, 'user-1'));
        $this->assertFalse(RuleAccessPolicy::canManage($permissions, 'user-1'));

        $grantedPermissions[] = 'rules.manage';
        $this->assertTrue(RuleAccessPolicy::canView($permissions, 'user-1'));
        $this->assertTrue(RuleAccessPolicy::canManage($permissions, 'user-1'));
    }

    /**
     * Test scope_id validation rejects missing, non-existent, or mismatched company targets
     */
    public function testScopeIdValidationLogic()
    {
        // Rejection for non-Company scope without scope_id
        $emptyScopeId = '';
        $this->assertTrue(empty($emptyScopeId));

        // Simulated check for branch belonging to different company
        $branchRecord = [
            'id' => 'br-other',
            'company_id' => 'comp-other',
        ];
        $currentCompany = 'comp-active';
        $belongsToCompany = ($branchRecord['company_id'] === $currentCompany);
        $this->assertFalse($belongsToCompany, 'Scope entity belonging to a different company must fail validation');

        // Scope entity matching target company passes
        $validBranchRecord = [
            'id' => 'br-ours',
            'company_id' => 'comp-active',
        ];
        $this->assertTrue($validBranchRecord['company_id'] === $currentCompany);
    }

    /**
     * Test archiving the only active company-level rule of a domain is rejected
     */
    public function testArchivingLastActiveCompanyRuleIsRejected()
    {
        $activeCompanyCount = 1;
        $canArchive = ($activeCompanyCount > 1);
        $this->assertFalse($canArchive, 'Archiving the only active Company-level rule of a domain must be rejected');

        // When multiple active company rules exist, archiving is permitted
        $multipleActiveCount = 2;
        $canArchiveMultiple = ($multipleActiveCount > 1);
        $this->assertTrue($canArchiveMultiple, 'Archiving an active company rule is permitted if another active company rule exists');
    }

    /**
     * PART 3 TEST: Editing an Active rule must create a Draft and leave the Active row unchanged.
     */
    public function testEditingActiveRuleCreatesDraftAndLeavesActiveRowUnchanged()
    {
        $existingActiveRule = [
            'id'             => 'rd-active-001',
            'company_id'     => 'comp-test',
            'domain'         => 'ATTENDANCE',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'status'         => 'Active',
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'params_json'    => json_encode(['late_grace_minutes' => 15]),
            'change_reason'  => 'Initial baseline policy',
        ];

        $submittedParams = ['late_grace_minutes' => 20];
        $submittedReason = 'Increase morning grace period to 20 minutes';

        // Controller logic simulation
        $existingRowBefore = $existingActiveRule;
        $isExistingActive = ($existingActiveRule['status'] === 'Active');
        $this->assertTrue($isExistingActive, 'Rule being edited is currently Active');

        // Instead of updating in place, controller invokes createDraft:
        $newDraft = [
            'id'             => 'rd-draft-002',
            'company_id'     => $existingActiveRule['company_id'],
            'domain'         => $existingActiveRule['domain'],
            'scope_level'    => $existingActiveRule['scope_level'],
            'scope_id'       => $existingActiveRule['scope_id'],
            'version_number' => $existingActiveRule['version_number'] + 1,
            'status'         => 'Draft',
            'effective_from' => '2025-02-01',
            'effective_to'   => null,
            'params_json'    => json_encode($submittedParams),
            'change_reason'  => $submittedReason,
        ];

        // 1. Assert existing active row remained unchanged
        $this->assertEquals('Active', $existingActiveRule['status']);
        $this->assertEquals(1, $existingActiveRule['version_number']);
        $this->assertEquals($existingRowBefore['params_json'], $existingActiveRule['params_json']);
        $this->assertEquals('Initial baseline policy', $existingActiveRule['change_reason']);

        // 2. Assert new row is Draft with incremented version and submitted parameters
        $this->assertEquals('Draft', $newDraft['status']);
        $this->assertEquals(2, $newDraft['version_number']);
        $this->assertEquals(json_encode($submittedParams), $newDraft['params_json']);
        $this->assertEquals($submittedReason, $newDraft['change_reason']);
        $this->assertNotEquals($existingActiveRule['id'], $newDraft['id']);
    }

    /**
     * PART 3 TEST: Changing scope_level or scope_id on an existing rule is rejected with 422.
     */
    public function testScopeImmutabilityOnExistingRule()
    {
        $existing = [
            'id'          => 'rd-001',
            'scope_level' => 'Department',
            'scope_id'    => 'dept-it-01',
        ];

        // Attempt 1: Changing scope_level
        $inputChangeLevel = ['scope_level' => 'Branch', 'scope_id' => 'dept-it-01'];
        $levelChanged = (isset($inputChangeLevel['scope_level']) && $inputChangeLevel['scope_level'] !== $existing['scope_level']);
        $this->assertTrue($levelChanged, 'Changing scope_level must be detected and rejected');

        // Attempt 2: Changing scope_id
        $inputChangeId = ['scope_level' => 'Department', 'scope_id' => 'dept-hr-02'];
        $idChanged = (isset($inputChangeId['scope_id']) && $inputChangeId['scope_id'] !== $existing['scope_id']);
        $this->assertTrue($idChanged, 'Changing scope_id must be detected and rejected');

        // Unchanged scope passes
        $inputValid = ['scope_level' => 'Department', 'scope_id' => 'dept-it-01'];
        $levelMatches = ($inputValid['scope_level'] === $existing['scope_level']);
        $idMatches = ($inputValid['scope_id'] === $existing['scope_id']);
        $this->assertTrue($levelMatches && $idMatches, 'Preserving existing scope passes validation');
    }

    /**
     * PART 3 TEST: Only Draft rows may be updated in place via updateDraft.
     */
    public function testUpdateDraftRejectsActiveRules()
    {
        $activeRule = ['id' => 'rd-1', 'status' => 'Active'];
        $draftRule  = ['id' => 'rd-2', 'status' => 'Draft'];

        $canUpdateActiveInPlace = ($activeRule['status'] === 'Draft');
        $this->assertFalse($canUpdateActiveInPlace, 'Active rule must not be eligible for in-place update');

        $canUpdateDraftInPlace = ($draftRule['status'] === 'Draft');
        $this->assertTrue($canUpdateDraftInPlace, 'Draft rule must be eligible for in-place update');
    }

    /**
     * PART 4 TEST: When scope is Employee, validateScopeIdExistsAndBelongsToCompany and RuleWriteService
     * look the employee up by id or employee_code within the company and store canonical id as scope_id.
     */
    public function testSaveDraftByEmployeeCodeCanonicalizesToEmployeeId()
    {
        $companyId = 'comp-tenant-01';
        $canonicalEmpId = 'emp-uuid-888';
        $empCode = 'EMP-CODE-888';

        // Mock employee record in company
        $employeeRecord = [
            'id'            => $canonicalEmpId,
            'company_id'    => $companyId,
            'employee_code' => $empCode,
            'first_name'    => 'Sarah',
            'last_name'     => 'Connor',
        ];

        // 1. Simulating validateScopeIdExistsAndBelongsToCompany logic with employee_code input
        $submittedScopeId = $empCode;
        $matchedEmp = null;
        if ($submittedScopeId === $employeeRecord['id'] || $submittedScopeId === $employeeRecord['employee_code']) {
            if ($employeeRecord['company_id'] === $companyId) {
                $matchedEmp = $employeeRecord;
            }
        }
        $this->assertNotNull($matchedEmp, 'Employee must be found by employee_code within company');

        // Mutates submittedScopeId to canonical id
        $canonicalStoredScopeId = (string)$matchedEmp['id'];
        $this->assertSame($canonicalEmpId, $canonicalStoredScopeId, 'Must canonicalize employee_code to canonical employee id');

        // 2. Cross-tenant check: if employee belongs to different company, must reject
        $otherCompanyEmp = [
            'id'            => 'emp-other-999',
            'company_id'    => 'comp-other-99',
            'employee_code' => 'EMP-OTHER',
        ];
        $crossTenantMatch = ($otherCompanyEmp['company_id'] === $companyId);
        $this->assertFalse($crossTenantMatch, 'Must reject employee belonging to another company');
    }

    /**
     * PART 4 TEST: Save-by-code canonicalization enables resolve-by-id in RuleResolver.
     */
    public function testResolveByIdMatchesCanonicalScopeIdFromSaveByCode()
    {
        $companyId = 'comp-alpha';
        $canonicalEmpId = 'emp-uuid-777';
        $empCode = 'EMP-777';

        // Base Company rule
        $companyRule = [
            'id'             => 'rule-comp-base',
            'company_id'     => $companyId,
            'domain'         => 'OVERTIME',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'daily_threshold_hours' => 8.0,
                'rate_multiplier'       => 1.5,
            ]),
        ];

        // Rule saved with canonical employee ID (after save-by-code canonicalization)
        $empOverrideRule = [
            'id'             => 'rule-emp-override',
            'company_id'     => $companyId,
            'domain'         => 'OVERTIME',
            'scope_level'    => 'Employee',
            'scope_id'       => $canonicalEmpId, // canonical id, NOT employee_code
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'daily_threshold_hours' => 6.0,
            ]),
        ];

        // RuleResolver extracts 'id' from employee array:
        $employee = [
            'id'            => $canonicalEmpId,
            'employee_code' => $empCode,
            'company_id'    => $companyId,
        ];

        // Employee scope matching: $rule['scope_id'] === $employee['id']
        $this->assertSame($empOverrideRule['scope_id'], $employee['id'], 'Canonical scope_id matches employee id');

        // Negative check: If rule had been saved with raw employee_code, resolution would fail:
        $rawCodeScopeRule = $empOverrideRule;
        $rawCodeScopeRule['scope_id'] = $empCode;
        $this->assertNotSame($rawCodeScopeRule['scope_id'], $employee['id'], 'Raw employee_code scope_id does not match employee id');
    }

    /**
     * PART 4 TEST: In RuleWriteService::publishRule, require a reason for any non-Company scope (not just Employee).
     */
    public function testPublishRuleRequiresReasonForAnyNonCompanyScope()
    {
        $nonCompanyScopes = ['Branch', 'Department', 'Designation', 'Shift', 'Employee'];

        foreach ($nonCompanyScopes as $scopeLevel) {
            // 1. Empty reason must be rejected
            $emptyReason = '';
            $trimmedEmpty = trim($emptyReason);
            $emptyIsRejected = ($scopeLevel !== 'Company' && ($trimmedEmpty === '' || strcasecmp($trimmedEmpty, \App\Services\Rules\RuleWriteService::SEED_REASON) === 0));
            $this->assertTrue($emptyIsRejected, "Empty reason must be rejected for scope {$scopeLevel}");

            // 2. Whitespace-only reason must be rejected
            $wsReason = '    ';
            $trimmedWs = trim($wsReason);
            $wsIsRejected = ($scopeLevel !== 'Company' && ($trimmedWs === '' || strcasecmp($trimmedWs, \App\Services\Rules\RuleWriteService::SEED_REASON) === 0));
            $this->assertTrue($wsIsRejected, "Whitespace reason must be rejected for scope {$scopeLevel}");

            // 3. System seed default reason must be rejected for overrides
            $seedReason = \App\Services\Rules\RuleWriteService::SEED_REASON;
            $trimmedSeed = trim($seedReason);
            $seedIsRejected = ($scopeLevel !== 'Company' && ($trimmedSeed === '' || strcasecmp($trimmedSeed, \App\Services\Rules\RuleWriteService::SEED_REASON) === 0));
            $this->assertTrue($seedIsRejected, "Default seed reason must be rejected for scope {$scopeLevel}");

            // 4. Valid custom override reason must pass
            $validReason = "Operational necessity for {$scopeLevel} override";
            $trimmedValid = trim($validReason);
            $validPasses = !($scopeLevel !== 'Company' && ($trimmedValid === '' || strcasecmp($trimmedValid, \App\Services\Rules\RuleWriteService::SEED_REASON) === 0));
            $this->assertTrue($validPasses, "Valid override reason must pass for scope {$scopeLevel}");
        }

        // Company scope: empty reason does NOT trigger override reason exception
        $companyScope = 'Company';
        $companyEmpty = '';
        $companyRequiresOverrideReason = ($companyScope !== 'Company' && (trim($companyEmpty) === '' || strcasecmp(trim($companyEmpty), \App\Services\Rules\RuleWriteService::SEED_REASON) === 0));
        $this->assertFalse($companyRequiresOverrideReason, 'Company base scope does not require override reason');
    }

    /**
     * PART 4 TEST: Migration converts existing Employee-scope rows whose scope_id is an employee_code into employee id,
     * logging each change in rule_change_log.
     */
    public function testMigrationConvertsEmployeeCodeScopeIdToCanonicalId()
    {
        $companyId = 'comp-migration-test';
        $employee = [
            'id'            => 'emp-canonical-12345',
            'company_id'    => $companyId,
            'employee_code' => 'EMP-LEGACY-001',
        ];

        $legacyRuleRow = [
            'id'             => 'rd-legacy-001',
            'company_id'     => $companyId,
            'domain'         => 'LEAVE',
            'scope_level'    => 'Employee',
            'scope_id'       => 'EMP-LEGACY-001', // old employee_code
            'version_number' => 1,
            'params_json'    => json_encode(['annual_leave_days' => 20]),
        ];

        // Step 1: Detect that scope_id is NOT a canonical id
        $isCanonical = ($legacyRuleRow['scope_id'] === $employee['id']);
        $this->assertFalse($isCanonical, 'Old scope_id is not yet canonical id');

        // Step 2: Match by employee_code within company
        $matchedByCode = ($legacyRuleRow['scope_id'] === $employee['employee_code'] && $employee['company_id'] === $companyId);
        $this->assertTrue($matchedByCode, 'Matches employee by employee_code and tenant company');

        // Step 3: Migration updates scope_id to canonical employee ID
        $updatedScopeId = $employee['id'];
        $this->assertSame('emp-canonical-12345', $updatedScopeId);

        // Step 4: Migration creates audit entry in rule_change_log
        $now = date('Y-m-d H:i:s');
        $changeLogEntry = [
            'id'              => 'rcl-test-uuid',
            'company_id'      => $companyId,
            'rule_id'         => $legacyRuleRow['id'],
            'domain'          => $legacyRuleRow['domain'],
            'action'          => 'update',
            'old_params_json' => $legacyRuleRow['params_json'],
            'new_params_json' => $legacyRuleRow['params_json'],
            'actor_id'        => 'migration_employee_scope_id',
            'reason'          => "Converted Employee scope_id from code '{$legacyRuleRow['scope_id']}' to canonical id '{$updatedScopeId}'",
            'created_at'      => $now,
        ];

        $this->assertSame('update', $changeLogEntry['action']);
        $this->assertSame($legacyRuleRow['id'], $changeLogEntry['rule_id']);
        $this->assertStringContainsString('EMP-LEGACY-001', $changeLogEntry['reason']);
        $this->assertStringContainsString('emp-canonical-12345', $changeLogEntry['reason']);
    }

    /**
     * PART 8 TEST: RuleWriteService::SEED_REASON constant is defined and equals canonical seed reason.
     */
    public function testSeedReasonConstantIsDefined()
    {
        $this->assertSame('Initial system default seed v1', \App\Services\Rules\RuleWriteService::SEED_REASON);
    }

    /**
     * PART 8 TEST: RuleSeeder::seedCompany determines status as Active only for domains without confirm:true keys
     * and Draft for domains with confirm:true keys.
     */
    public function testSeedCompanyStatusByConfirmKeys()
    {
        RuleSchemaRegistry::init();
        $domains = RuleSchemaRegistry::domains();

        foreach ($domains as $domain) {
            $confirmKeys = RuleSchemaRegistry::confirmKeys($domain);
            $requiresConfirmation = !empty($confirmKeys);
            $expectedStatus = $requiresConfirmation ? 'Draft' : 'Active';

            if (in_array($domain, ['ATTENDANCE', 'TAX'], true)) {
                $this->assertFalse($requiresConfirmation, "Domain {$domain} should have no confirm:true keys");
                $this->assertSame('Active', $expectedStatus);
            } else {
                $this->assertTrue($requiresConfirmation, "Domain {$domain} should have confirm:true keys");
                $this->assertSame('Draft', $expectedStatus);
            }
        }
    }

    /**
     * PART 8 TEST: Maker-checker is off by default, independent of PAYROLL_BASICS,
     * blocks creator from self-publishing unless Software App Admin, and allows different publisher.
     */
    public function testMakerCheckerEnforcementAndSuperAdminBypass()
    {
        \App\Services\Rules\RuleWriteService::resetMakerCheckerOverrides();

        $companyId = 'comp-maker-checker-01';
        $ruleId = 'rd-draft-mc-01';
        $creatorId = 'user-hr-maker';
        $checkerId = 'user-hr-checker';

        $draftRule = [
            'id'             => $ruleId,
            'company_id'     => $companyId,
            'domain'         => 'ATTENDANCE',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2026-01-01',
            'effective_to'   => null,
            'status'         => 'Draft',
            'params_json'    => json_encode(RuleSchemaRegistry::seedValues('ATTENDANCE')),
            'change_reason'  => 'Updated attendance grace policy',
            'created_by'     => $creatorId,
        ];

        $mockModel = $this->createMock(RuleDefinitionModel::class);
        $mockModel->method('find')->with($ruleId)->willReturn($draftRule);
        $mockModel->method('paramsOf')->willReturn(RuleSchemaRegistry::seedValues('ATTENDANCE'));

        $mockDb = $this->createMock(\CodeIgniter\Database\BaseConnection::class);
        $mockDb->method('tableExists')->willReturn(false);

        $writeService = new \App\Services\Rules\RuleWriteService($mockDb, $mockModel);

        // 1. Off by default
        $this->assertFalse($writeService->isMakerCheckerEnabled($companyId));

        // 2. Enable maker-checker for company
        $writeService->setMakerCheckerEnabled($companyId, true);
        $this->assertTrue($writeService->isMakerCheckerEnabled($companyId));

        // 3. Creator attempting to publish own rule when not Software App Admin -> throws RuntimeException
        try {
            $writeService->publishExistingVersion($ruleId, $creatorId, 'Self-Approving Draft', null, null, false);
            $this->fail('Expected RuntimeException when creator attempts to publish own rule under maker-checker.');
        } catch (\RuntimeException $e) {
            $this->assertStringContainsString('Maker-checker policy violation', $e->getMessage());
        }

        // 4. Software App Admin is allowed past the maker-checker guard even if creator === publisher
        // (fails later on mocked DB table call rather than maker-checker guard)
        try {
            $writeService->publishExistingVersion($ruleId, $creatorId, 'Superadmin Override Publish', null, null, true);
        } catch (\Throwable $e) {
            $this->assertStringNotContainsString('Maker-checker policy violation', $e->getMessage());
        }

        // 5. Different user (checkerId !== creatorId) is allowed past the maker-checker guard
        try {
            $writeService->publishExistingVersion($ruleId, $checkerId, 'Approved by second HR manager', null, null, false);
        } catch (\Throwable $e) {
            $this->assertStringNotContainsString('Maker-checker policy violation', $e->getMessage());
        }

        \App\Services\Rules\RuleWriteService::resetMakerCheckerOverrides();
    }

    /**
     * PART 8 TEST: validateNoLockedBonusSchemeDeletion in RuleWriteService fails closed when DB throws or table unavailable.
     */
    public function testValidateNoLockedBonusSchemeDeletionFailsClosedOnException()
    {
        $mockDb = $this->createMock(\CodeIgniter\Database\BaseConnection::class);
        $mockDb->method('tableExists')->willThrowException(new \RuntimeException('Simulated DB connection failure'));

        $mockModel = $this->createMock(RuleDefinitionModel::class);
        $writeService = new \App\Services\Rules\RuleWriteService($mockDb, $mockModel);
        $err = $writeService->validateNoLockedBonusSchemeDeletion('comp-001', []);
        $this->assertNotNull($err, 'validateNoLockedBonusSchemeDeletion must fail closed and return an error message on exception');
        $this->assertStringContainsString('blocked for safety', $err);
    }

    /**
     * Helper to initialize rule_definitions and rule_change_log in memory if needed.
     */
    protected function ensureRuleSchema($db): void
    {
        if (!$db->tableExists('rule_definitions')) {
            $db->query("CREATE TABLE IF NOT EXISTS rule_definitions (
                id VARCHAR(36) PRIMARY KEY,
                company_id VARCHAR(36) NOT NULL,
                domain VARCHAR(30) NOT NULL,
                scope_level VARCHAR(20) NOT NULL,
                scope_id VARCHAR(36),
                version_number INT NOT NULL,
                effective_from DATE NOT NULL,
                effective_to DATE,
                status VARCHAR(20) NOT NULL,
                params_json LONGTEXT NOT NULL,
                schema_version INT NOT NULL,
                change_reason TEXT,
                created_by VARCHAR(36),
                updated_by VARCHAR(36),
                approved_by VARCHAR(36),
                created_at DATETIME,
                updated_at DATETIME
            )");
        }
        if (!$db->fieldExists('updated_by', 'rule_definitions')) {
            try {
                $db->query("ALTER TABLE rule_definitions ADD COLUMN updated_by VARCHAR(36) NULL");
            } catch (\Throwable $e) {}
        }
        if (!$db->tableExists('rule_change_log')) {
            $db->query("CREATE TABLE IF NOT EXISTS rule_change_log (
                id VARCHAR(36) PRIMARY KEY,
                company_id VARCHAR(36) NOT NULL,
                rule_id VARCHAR(36) NOT NULL,
                domain VARCHAR(30) NOT NULL,
                action VARCHAR(20) NOT NULL,
                old_params_json LONGTEXT,
                new_params_json LONGTEXT,
                actor_id VARCHAR(36),
                reason TEXT,
                created_at DATETIME
            )");
        }
    }

    /**
     * TASK 12D TEST: When archiving an Active Company rule, require that another Active Company rule covers today.
     * A future-dated Active rule (effective_from > today) must not count, and archiving must be refused.
     */
    public function testArchiveWithOnlyFutureDatedOtherRuleMustBeRefused()
    {
        $db = Database::connect();
        $this->ensureRuleSchema($db);

        $companyId = 'comp-archive-test-12d';
        $domain = 'ATTENDANCE';
        $today = date('Y-m-d');
        $futureDate = date('Y-m-d', strtotime('+30 days'));

        // Clean any existing test rows
        $db->table('rule_definitions')->where('company_id', $companyId)->delete();

        // 1. Current Active Company rule covering today
        $currentRuleId = 'rd-active-current-12d';
        $db->table('rule_definitions')->insert([
            'id'             => $currentRuleId,
            'company_id'     => $companyId,
            'domain'         => $domain,
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode(RuleSchemaRegistry::seedValues($domain)),
            'schema_version' => 1,
            'change_reason'  => 'Initial current baseline',
            'created_by'     => 'user-admin-1',
            'created_at'     => date('Y-m-d H:i:s'),
            'updated_at'     => date('Y-m-d H:i:s'),
        ]);

        // 2. Future-dated Active Company rule (starts in 30 days)
        $futureRuleId = 'rd-active-future-12d';
        $db->table('rule_definitions')->insert([
            'id'             => $futureRuleId,
            'company_id'     => $companyId,
            'domain'         => $domain,
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 2,
            'effective_from' => $futureDate,
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode(RuleSchemaRegistry::seedValues($domain)),
            'schema_version' => 1,
            'change_reason'  => 'Future upcoming policy',
            'created_by'     => 'user-admin-1',
            'created_at'     => date('Y-m-d H:i:s'),
            'updated_at'     => date('Y-m-d H:i:s'),
        ]);

        $model = new RuleDefinitionModel();
        $writeService = new RuleWriteService($db, $model);

        // Attempting to archive the current Active Company rule MUST be refused because the only other Active rule is future-dated!
        try {
            $writeService->archiveRule($currentRuleId, 'user-admin-1', 'Attempt archive current rule');
            $this->fail('Expected RuntimeException when archiving Active Company rule with only future-dated other rule.');
        } catch (\RuntimeException $e) {
            $this->assertStringContainsString('At least one other active Company-level rule covering today must be maintained', $e->getMessage());
        }

        // Verify current rule remained Active
        $currentInDb = $db->table('rule_definitions')->where('id', $currentRuleId)->get()->getRowArray();
        $this->assertSame('Active', $currentInDb['status']);

        // 3. Now insert a replacement Active Company rule that DOES cover today
        $replacementRuleId = 'rd-active-replacement-12d';
        $db->table('rule_definitions')->insert([
            'id'             => $replacementRuleId,
            'company_id'     => $companyId,
            'domain'         => $domain,
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 3,
            'effective_from' => date('Y-m-d', strtotime('-5 days')),
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode(RuleSchemaRegistry::seedValues($domain)),
            'schema_version' => 1,
            'change_reason'  => 'Replacement covering today',
            'created_by'     => 'user-admin-1',
            'created_at'     => date('Y-m-d H:i:s'),
            'updated_at'     => date('Y-m-d H:i:s'),
        ]);

        // Archiving current rule should now succeed because replacement rule covers today
        $archived = $writeService->archiveRule($currentRuleId, 'user-admin-1', 'Archive now with valid replacement');
        $this->assertSame('Archived', $archived['status']);

        // Clean up
        $db->table('rule_definitions')->where('company_id', $companyId)->delete();
    }

    /**
     * TASK 12D TEST: updateDraft keeps original created_by and fills updated_by with the editor.
     */
    public function testUpdateDraftPreservesCreatedByAndFillsUpdatedBy()
    {
        $db = Database::connect();
        $this->ensureRuleSchema($db);

        $companyId = 'comp-draft-update-12d';
        $domain = 'ATTENDANCE';
        $originalCreator = 'user-original-maker-001';
        $editor = 'user-editor-updater-002';

        $db->table('rule_definitions')->where('company_id', $companyId)->delete();

        $draftId = 'rd-draft-preserve-test';
        $initialParams = RuleSchemaRegistry::seedValues($domain);
        $db->table('rule_definitions')->insert([
            'id'             => $draftId,
            'company_id'     => $companyId,
            'domain'         => $domain,
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2026-01-01',
            'effective_to'   => null,
            'status'         => 'Draft',
            'params_json'    => json_encode($initialParams),
            'schema_version' => 1,
            'change_reason'  => 'Initial draft created by maker',
            'created_by'     => $originalCreator,
            'updated_by'     => null,
            'created_at'     => date('Y-m-d H:i:s'),
            'updated_at'     => date('Y-m-d H:i:s'),
        ]);

        $model = new RuleDefinitionModel();
        $writeService = new RuleWriteService($db, $model);

        $updatedParams = $initialParams;
        $updatedParams['late_grace_minutes'] = 25;

        // Editor calls updateDraft
        $res = $writeService->updateDraft($draftId, $updatedParams, $editor, 'Adjusted grace period for company');

        // Assert 1: created_by stays original
        $this->assertSame($originalCreator, $res['created_by'], 'created_by must remain the original creator');

        // Assert 2: updated_by is set to the editor
        $this->assertSame($editor, $res['updated_by'], 'updated_by must be set to the editor');

        // Assert 3: verify persisted values in database table
        $rowInDb = $db->table('rule_definitions')->where('id', $draftId)->get()->getRowArray();
        $this->assertSame($originalCreator, $rowInDb['created_by'], 'DB created_by must remain original');
        $this->assertSame($editor, $rowInDb['updated_by'], 'DB updated_by must be set to editor');

        // Clean up
        $db->table('rule_definitions')->where('company_id', $companyId)->delete();
    }

    /**
     * TASK 12D TEST: Maker-checker check compares publisher with original creator even after updateDraft.
     */
    public function testMakerCheckerComparesPublisherWithOriginalCreatorAfterUpdateDraft()
    {
        $db = Database::connect();
        $this->ensureRuleSchema($db);

        $companyId = 'comp-mc-check-12d';
        $domain = 'ATTENDANCE';
        $makerId = 'user-maker-alpha';
        $editorId = 'user-editor-beta';
        $checkerId = 'user-checker-gamma';

        $db->table('rule_definitions')->where('company_id', $companyId)->delete();

        $draftId = 'rd-draft-mc-test';
        $initialParams = RuleSchemaRegistry::seedValues($domain);
        $db->table('rule_definitions')->insert([
            'id'             => $draftId,
            'company_id'     => $companyId,
            'domain'         => $domain,
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2026-01-01',
            'effective_to'   => null,
            'status'         => 'Draft',
            'params_json'    => json_encode($initialParams),
            'schema_version' => 1,
            'change_reason'  => 'Created by Maker Alpha',
            'created_by'     => $makerId,
            'updated_by'     => null,
            'created_at'     => date('Y-m-d H:i:s'),
            'updated_at'     => date('Y-m-d H:i:s'),
        ]);

        $model = new RuleDefinitionModel();
        $writeService = new RuleWriteService($db, $model);

        // Enable maker-checker for the company
        $writeService->setMakerCheckerEnabled($companyId, true);
        $this->assertTrue($writeService->isMakerCheckerEnabled($companyId));

        // Editor Beta modifies the draft
        $updatedParams = $initialParams;
        $updatedParams['late_grace_minutes'] = 18;
        $writeService->updateDraft($draftId, $updatedParams, $editorId, 'Editor Beta tweaks grace period');

        // Verify draft now has created_by = makerId and updated_by = editorId
        $draftRow = $model->find($draftId);
        $this->assertSame($makerId, $draftRow['created_by']);
        $this->assertSame($editorId, $draftRow['updated_by']);

        // 1. Original Maker Alpha attempts to publish: MUST be refused because Maker Alpha is the original creator!
        try {
            $writeService->publishExistingVersion($draftId, $makerId, 'Maker Alpha tries to approve own draft', null, null, false);
            $this->fail('Expected RuntimeException when original maker attempts to publish draft edited by someone else.');
        } catch (\RuntimeException $e) {
            $this->assertStringContainsString('Maker-checker policy violation', $e->getMessage());
        }

        // 2. Checker Gamma (or Editor Beta) who is NOT the original creator attempts to publish: maker-checker check passes!
        // (Allowed through maker-checker check without throwing "Maker-checker policy violation")
        try {
            $writeService->publishExistingVersion($draftId, $checkerId, 'Approved by independent checker Gamma', null, null, false);
        } catch (\Throwable $e) {
            $this->assertStringNotContainsString('Maker-checker policy violation', $e->getMessage());
        }

        // Clean up
        RuleWriteService::resetMakerCheckerOverrides();
        $db->table('rule_definitions')->where('company_id', $companyId)->delete();
    }

    /**
     * TASK 12D TEST: Verify double transRollback is removed so transaction failure invokes rollback once.
     */
    public function testNoDoubleTransRollbackOnFailure()
    {
        $mockDb = $this->createMock(\CodeIgniter\Database\BaseConnection::class);
        $mockDb->method('tableExists')->willReturn(true);
        $mockDb->method('fieldExists')->willReturn(true);
        $mockDb->method('transBegin')->willReturn(true);
        $mockDb->method('transStatus')->willReturn(false); // simulates failure

        // transRollback should be called exactly once by the catch block
        $mockDb->expects($this->once())->method('transRollback');

        $mockBuilder = $this->createMock(\CodeIgniter\Database\BaseBuilder::class);
        $mockBuilder->method('where')->willReturnSelf();
        $mockBuilder->method('groupStart')->willReturnSelf();
        $mockBuilder->method('orWhere')->willReturnSelf();
        $mockBuilder->method('groupEnd')->willReturnSelf();
        $mockBuilder->method('countAllResults')->willReturn(2); // >0 so active rule check passes
        $mockBuilder->method('update')->willReturn(true);
        $mockBuilder->method('insert')->willReturn(true);

        $mockDb->method('table')->willReturn($mockBuilder);

        $mockModel = $this->createMock(RuleDefinitionModel::class);
        $mockModel->method('find')->with('rd-mock-1')->willReturn([
            'id'             => 'rd-mock-1',
            'company_id'     => 'comp-mock',
            'domain'         => 'ATTENDANCE',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'status'         => 'Active',
            'params_json'    => '{}',
            'change_reason'  => 'Test',
        ]);
        $mockModel->method('paramsOf')->willReturn([]);

        $writeService = new RuleWriteService($mockDb, $mockModel);

        try {
            $writeService->archiveRule('rd-mock-1', 'user-admin', 'Archive test');
            $this->fail('Expected RuntimeException on transStatus false');
        } catch (\RuntimeException $e) {
            $this->assertStringContainsString('Transaction failed while archiving rule', $e->getMessage());
        }
    }
}

