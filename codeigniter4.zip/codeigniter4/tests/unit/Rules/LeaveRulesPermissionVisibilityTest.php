<?php

namespace Tests\Unit\Rules;

use App\Services\PermissionService;
use App\Services\Rules\RuleAccessPolicy;
use App\Services\Rules\RuleResolver;
use PHPUnit\Framework\TestCase;

/**
 * Tests Leave Management "Leave Rules (Rule Engine) →" visibility & RBAC rules.
 *
 * Requirements:
 * 1. Logged in employee cannot see "Leave Rules (Rule Engine) →" (canViewRules = false).
 * 2. Software Owner and Company Admin have permission by default (canViewRules = true).
 * 3. Any user granted permission in Security & RBAC (rules.view or rules.manage) can see it.
 */
class LeaveRulesPermissionVisibilityTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        if (function_exists('session')) {
            try {
                \Config\Services::session()->destroy();
            } catch (\Throwable $e) {}
        }
        if (isset($_SESSION)) {
            $_SESSION = [];
        }
        if (class_exists(\Config\Services::class)) {
            try {
                \Config\Services::reset(true);
            } catch (\Throwable $e) {}
        }
        RuleResolver::flush(true);
        RuleResolver::resetMemo();
    }

    protected function tearDown(): void
    {
        RuleResolver::flush(true);
        RuleResolver::resetMemo();
        if (function_exists('session')) {
            try {
                \Config\Services::session()->destroy();
            } catch (\Throwable $e) {}
        }
        if (isset($_SESSION)) {
            $_SESSION = [];
        }
        if (class_exists(\Config\Services::class)) {
            try {
                \Config\Services::reset(true);
            } catch (\Throwable $e) {}
        }
        parent::tearDown();
    }
    /**
     * Test RuleAccessPolicy handles employee role by denying view access
     */
    public function testEmployeeCannotViewRulesByDefault()
    {
        $permService = $this->createMock(PermissionService::class);
        $permService->method('canonicalizeRole')->willReturn('employee');
        $permService->method('isSoftwareAppAdmin')->willReturn(false);
        $permService->method('isCompanyAdmin')->willReturn(false);
        $permService->method('checkDefaultRoleAccess')->with('employee', 'rules', 'view')->willReturn(false);

        $this->assertFalse(RuleAccessPolicy::canView('employee', $permService));
        $this->assertFalse(RuleAccessPolicy::canManage('employee', $permService));
    }

    /**
     * Test Software Owner (software_app_admin) has default view and manage permission
     */
    public function testSoftwareOwnerHasDefaultRulesAccess()
    {
        $permService = $this->createMock(PermissionService::class);
        $permService->method('canonicalizeRole')->willReturn('software_app_admin');
        $permService->method('isSoftwareAppAdmin')->willReturn(true);

        $this->assertTrue(RuleAccessPolicy::canView('software_app_admin', $permService));
        $this->assertTrue(RuleAccessPolicy::canManage('software_app_admin', $permService));
    }

    /**
     * Test Company Admin (company_admin) has default view and manage permission
     */
    public function testCompanyAdminHasDefaultRulesAccess()
    {
        $permService = $this->createMock(PermissionService::class);
        $permService->method('canonicalizeRole')->willReturn('company_admin');
        $permService->method('isSoftwareAppAdmin')->willReturn(false);
        $permService->method('isCompanyAdmin')->willReturn(true);

        $this->assertTrue(RuleAccessPolicy::canView('company_admin', $permService));
        $this->assertTrue(RuleAccessPolicy::canManage('company_admin', $permService));
    }

    /**
     * Test custom user granted rules.view in RBAC can see rules
     */
    public function testUserWithGrantedRbacPermissionCanViewRules()
    {
        $permService = $this->createMock(PermissionService::class);
        $permService->method('canonicalizeRole')->willReturn('custom_role');
        $permService->method('isSoftwareAppAdmin')->willReturn(false);
        $permService->method('isCompanyAdmin')->willReturn(false);
        $permService->method('hasPermission')->willReturnCallback(function ($userId, $permCode) {
            return $permCode === 'rules.view';
        });

        $this->assertTrue(RuleAccessPolicy::canView('usr-test-user-123', $permService));
        $this->assertFalse(RuleAccessPolicy::canManage('usr-test-user-123', $permService));
    }

    /**
     * Test canViewRules controller resolution logic
     */
    public function testCanViewRulesResolutionMatrix()
    {
        // 1. Employee: not software admin, not company admin, no rules.view, no rules.manage
        $isSoftwareAppAdmin = false;
        $isCompanyAdmin = false;
        $canRulesView = false;
        $canRulesManage = false;
        $canViewRulesEmployee = $isSoftwareAppAdmin || $isCompanyAdmin || $canRulesView || $canRulesManage;
        $this->assertFalse($canViewRulesEmployee, 'Employee must not resolve canViewRules to true');

        // 2. Software Owner
        $isSoftwareAppAdmin = true;
        $canViewRulesOwner = $isSoftwareAppAdmin || $isCompanyAdmin || $canRulesView || $canRulesManage;
        $this->assertTrue($canViewRulesOwner, 'Software Owner must resolve canViewRules to true');

        // 3. Company Admin
        $isSoftwareAppAdmin = false;
        $isCompanyAdmin = true;
        $canViewRulesCompanyAdmin = $isSoftwareAppAdmin || $isCompanyAdmin || $canRulesView || $canRulesManage;
        $this->assertTrue($canViewRulesCompanyAdmin, 'Company Admin must resolve canViewRules to true');

        // 4. Role or user granted rules.view
        $isCompanyAdmin = false;
        $canRulesView = true;
        $canViewRulesGranted = $isSoftwareAppAdmin || $isCompanyAdmin || $canRulesView || $canRulesManage;
        $this->assertTrue($canViewRulesGranted, 'User granted rules.view must resolve canViewRules to true');
    }

    /**
     * Test Leave Management view hides "Leave Rules (Rule Engine) →" when canViewRules is false
     */
    public function testLeaveViewTemplateGuardsLeaveRulesButton()
    {
        $viewFile = realpath(__DIR__ . '/../../../app/Views/leave/index.php');
        $this->assertNotEmpty($viewFile);
        $content = file_get_contents($viewFile);

        // Confirm the tab link is guarded by canViewRules
        $expectedGuardedPattern = '/<\?php\s+if\s*\(!empty\(\$canViewRules\)\):\s*\?>\s*<a\s+href="<\?=\s*base_url\(\'rules\?domain=LEAVE\'\)\s*\?>"[^>]*>\s*<svg[^>]*>.*?<\/svg>\s*Leave Rules \(Rule Engine\)\s*&rarr;\s*<\/a>\s*<\?php\s*endif;\s*\?>/s';
        $this->assertMatchesRegularExpression($expectedGuardedPattern, $content, 'Leave Rules (Rule Engine) -> tab must be guarded by canViewRules');

        // Confirm policyModal is also guarded by canViewRules
        $expectedModalGuardedPattern = '/<\?php\s+if\s*\(!empty\(\$canViewRules\)\):\s*\?>\s*<div\s+id="policyModal"/s';
        $this->assertMatchesRegularExpression($expectedModalGuardedPattern, $content, 'policyModal must be guarded by canViewRules');
    }
}
