<?php

namespace Tests\Unit\Rules;

use App\Models\RuleDefinitionModel;
use App\Services\Rules\RuleParamValidator;
use App\Services\Rules\RuleResolver;
use App\Services\Rules\RuleSchemaRegistry;
use App\Services\Rules\RuleWriteService;
use Config\Database;
use PHPUnit\Framework\TestCase;

class RuleParamValidatorTest extends TestCase
{
    protected static function ensureSchema(): void
    {
        $db = Database::connect();
        try {
            $rawConn = $db->connID ?? null;
            if ($rawConn instanceof \SQLite3) {
                $rawConn->createFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
            } elseif (is_object($rawConn) && method_exists($rawConn, 'sqliteCreateFunction')) {
                $rawConn->sqliteCreateFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
            }
        } catch (\Throwable $e) {
        }

        if (!$db->tableExists('rule_definitions')) {
            $schemaFile = __DIR__ . '/schema.sqlite.sql';
            if (file_exists($schemaFile)) {
                $sql = file_get_contents($schemaFile);
                $statements = array_filter(array_map('trim', explode(';', $sql)));
                foreach ($statements as $stmt) {
                    if (!empty($stmt)) {
                        try {
                            $db->query($stmt);
                        } catch (\Throwable $e) {
                        }
                    }
                }
            }
        }
    }

    protected function setUp(): void
    {
        parent::setUp();
        if (function_exists('session')) {
            try {
                \Config\Services::session()->destroy();
            } catch (\Throwable $e) {}
        }
        if (isset($_SESSION)) {
            $_SESSION = [];
        }
        if (class_exists(\Config\Services::class)) {
            try {
                \Config\Services::reset(true);
            } catch (\Throwable $e) {}
        }
        RuleResolver::flush(true);
        RuleResolver::resetMemo();
        RuleSchemaRegistry::init();
    }

    protected function tearDown(): void
    {
        RuleResolver::flush(true);
        RuleResolver::resetMemo();
        if (function_exists('session')) {
            try {
                \Config\Services::session()->destroy();
            } catch (\Throwable $e) {}
        }
        if (isset($_SESSION)) {
            $_SESSION = [];
        }
        if (class_exists(\Config\Services::class)) {
            try {
                \Config\Services::reset(true);
            } catch (\Throwable $e) {}
        }
        parent::tearDown();
    }

    /**
     * 1. Disallowed scope level for domain
     */
    public function testDisallowedScopeLevel()
    {
        $res = RuleParamValidator::validate('PAYROLL_BASICS', 'Branch', ['currency_code' => 'BDT'], true);
        $this->assertFalse($res['valid']);
        $this->assertArrayHasKey('scope_level', $res['errors']);
        $this->assertStringContainsString("Scope level 'Branch' is not allowed", $res['errors']['scope_level']);
    }

    /**
     * 2. Reject unknown parameter keys
     */
    public function testUnknownKeyRejection()
    {
        $res = RuleParamValidator::validate('PAYROLL_BASICS', 'Company', [
            'currency_code'     => 'BDT',
            'unsupported_field' => 'xyz'
        ], true);

        $this->assertFalse($res['valid']);
        $this->assertArrayHasKey('unsupported_field', $res['errors']);
        $this->assertStringContainsString("Unknown parameter 'unsupported_field'", $res['errors']['unsupported_field']);
    }

    /**
     * 3. Partial vs Full mode
     */
    public function testPartialVsFullMode()
    {
        // Partial mode: passing only 1 parameter is valid for overrides
        $partialRes = RuleParamValidator::validate('PAYROLL_BASICS', 'Company', [
            'currency_code' => 'USD'
        ], true);

        $this->assertTrue($partialRes['valid'], "Partial mode must allow missing parameters for overrides");
        $this->assertEmpty($partialRes['errors']);
        $this->assertSame('USD', $partialRes['clean']['currency_code']);

        // Full mode: missing required parameters must fail
        $fullRes = RuleParamValidator::validate('PAYROLL_BASICS', 'Company', [
            'currency_code' => 'USD'
        ], false);

        $this->assertFalse($fullRes['valid'], "Full mode must require all parameters for company scope");
        $this->assertArrayHasKey('daily_rate_mode', $fullRes['errors']);
        $this->assertArrayHasKey('standard_daily_hours', $fullRes['errors']);
    }

    public function testPartialModeValidatesNestedObjectWithoutUndefinedVariable(): void
    {
        $res = RuleParamValidator::validate('LEAVE', 'Company', [
            'sandwich' => [
                'enabled' => true,
            ],
        ], true);

        $this->assertTrue($res['valid'], json_encode($res['errors']));
        $this->assertSame(['enabled' => true], $res['clean']['sandwich']);
    }

    public function testLeaveEntitlementsPreservePaidPercentageAndDropLegacyDisplayName(): void
    {
        $res = RuleParamValidator::validate('LEAVE', 'Company', [
            'entitlements' => [[
                'leave_type_code' => 'ANNUAL',
                'leave_type_name' => 'Annual Leave',
                'is_paid' => true,
                'paid_percentage' => 80,
                'monthly_accrual_rate' => 1.5,
            ]],
        ], true);

        $this->assertTrue($res['valid'], json_encode($res['errors']));
        $this->assertSame([
            'leave_type_code' => 'ANNUAL',
            'is_paid' => true,
            'paid_percentage' => 80,
            'accrual_rate_per_month' => 1.5,
        ], $res['clean']['entitlements'][0]);
    }

    public function testNormalizeLegacyKeysDoesNotMutateInput(): void
    {
        $original = [
            'entitlements' => [
                [
                    'leave_type_code'      => 'ANNUAL',
                    'leave_type_name'      => 'Annual Leave',
                    'paid_percentage'      => 50,
                    'is_paid'              => true,
                    'monthly_accrual_rate' => 1.5,
                ]
            ]
        ];
        $inputCopy = $original;

        $normalized = RuleParamValidator::normalizeLegacyKeys('LEAVE', $original);

        // Input must not be mutated
        $this->assertSame($inputCopy, $original, 'normalizeLegacyKeys must not mutate input array');

        // Normalized must map monthly_accrual_rate to accrual_rate_per_month and drop leave_type_name, preserving paid_percentage
        $this->assertArrayHasKey('accrual_rate_per_month', $normalized['entitlements'][0]);
        $this->assertSame(1.5, $normalized['entitlements'][0]['accrual_rate_per_month']);
        $this->assertArrayNotHasKey('monthly_accrual_rate', $normalized['entitlements'][0]);
        $this->assertArrayNotHasKey('leave_type_name', $normalized['entitlements'][0]);
        $this->assertArrayHasKey('paid_percentage', $normalized['entitlements'][0]);
        $this->assertSame(50, $normalized['entitlements'][0]['paid_percentage']);
    }

    public function testValidateDoesNotMutateInput(): void
    {
        $original = [
            'entitlements' => [
                [
                    'leave_type_code'      => 'ANNUAL',
                    'leave_type_name'      => 'Annual Leave',
                    'paid_percentage'      => 50,
                    'is_paid'              => true,
                    'monthly_accrual_rate' => 1.5,
                ]
            ]
        ];
        $inputCopy = $original;

        $res = RuleParamValidator::validate('LEAVE', 'Company', $original, true);

        $this->assertTrue($res['valid'], json_encode($res['errors']));
        $this->assertSame($inputCopy, $original, 'validate() must not mutate its input');
    }

    public function testEntitlementPaidPercentageRoundTripThroughValidate(): void
    {
        $params = [
            'entitlements' => [
                [
                    'leave_type_code' => 'HALF_PAY_SICK',
                    'is_paid'         => true,
                    'paid_percentage' => 50,
                ]
            ]
        ];

        $res = RuleParamValidator::validate('LEAVE', 'Department', $params, true);

        $this->assertTrue($res['valid'], json_encode($res['errors']));
        $this->assertArrayHasKey('entitlements', $res['clean']);
        $this->assertSame(50, $res['clean']['entitlements'][0]['paid_percentage']);
    }

    public function testEntitlementPaidPercentageRoundTripThroughPublishRule(): void
    {
        self::ensureSchema();
        $db = Database::connect();
        $ruleModel = new RuleDefinitionModel($db);
        $writeService = new RuleWriteService($db, $ruleModel);

        $companyId = 'comp-test-p50-' . bin2hex(random_bytes(4));
        $params = [
            'entitlements' => [
                [
                    'leave_type_code' => 'HALF_PAY_SICK',
                    'is_paid'         => true,
                    'paid_percentage' => 50,
                ],
            ],
        ];

        try {
            $published = $writeService->publishRule(
                $companyId,
                'LEAVE',
                'Department',
                'dept-001',
                $params,
                'usr-test-01',
                'Set half-pay sick leave entitlement to 50%',
                '2026-01-01'
            );

            $this->assertNotEmpty($published['id']);
            $this->assertIsArray($published['params']);
            $this->assertArrayHasKey('entitlements', $published['params']);
            $this->assertSame(50, $published['params']['entitlements'][0]['paid_percentage']);

            // Verify persistence in rule_definitions table
            $row = $db->table('rule_definitions')->where('id', $published['id'])->get()->getRowArray();
            $this->assertNotNull($row);
            $savedParams = json_decode((string)$row['params_json'], true);
            $this->assertIsArray($savedParams);
            $this->assertSame(50, $savedParams['entitlements'][0]['paid_percentage']);
        } finally {
            try {
                $db->table('rule_definitions')->where('company_id', $companyId)->delete();
                $db->table('rule_change_log')->where('company_id', $companyId)->delete();
            } catch (\Throwable $e) {
            }
        }
    }

    /**
     * 4. Valid boolean type (including truthy string)
     */
    public function testValidBoolean()
    {
        $res = RuleParamValidator::validate('ATTENDANCE', 'Company', [
            'break_enabled' => true,
            'late_enabled'  => '1',
        ], true);

        $this->assertTrue($res['valid']);
        $this->assertSame(true, $res['clean']['break_enabled']);
        $this->assertSame(true, $res['clean']['late_enabled']);
    }

    /**
     * 5. Invalid boolean type
     */
    public function testInvalidBoolean()
    {
        $res = RuleParamValidator::validate('ATTENDANCE', 'Company', [
            'break_enabled' => 'not_a_boolean'
        ], true);

        $this->assertFalse($res['valid']);
        $this->assertArrayHasKey('break_enabled', $res['errors']);
        $this->assertStringContainsString('must be a boolean', $res['errors']['break_enabled']);
    }

    /**
     * 6. Valid integer with min/max
     */
    public function testValidIntegerWithMinMax()
    {
        $res = RuleParamValidator::validate('PAYROLL_BASICS', 'Company', [
            'money_decimals' => 2
        ], true);

        $this->assertTrue($res['valid']);
        $this->assertSame(2, $res['clean']['money_decimals']);
    }

    /**
     * 7. Invalid integer exceeding max
     */
    public function testInvalidIntegerExceedsMax()
    {
        $res = RuleParamValidator::validate('PAYROLL_BASICS', 'Company', [
            'money_decimals' => 10 // max is 4
        ], true);

        $this->assertFalse($res['valid']);
        $this->assertArrayHasKey('money_decimals', $res['errors']);
        $this->assertStringContainsString('at most 4', $res['errors']['money_decimals']);
    }

    /**
     * 8. Invalid integer not numeric
     */
    public function testInvalidIntegerNonNumeric()
    {
        $res = RuleParamValidator::validate('PAYROLL_BASICS', 'Company', [
            'money_decimals' => 'two'
        ], true);

        $this->assertFalse($res['valid']);
        $this->assertArrayHasKey('money_decimals', $res['errors']);
        $this->assertStringContainsString('must be an integer', $res['errors']['money_decimals']);
    }

    /**
     * 9. Valid decimal type
     */
    public function testValidDecimal()
    {
        $res = RuleParamValidator::validate('PAYROLL_BASICS', 'Company', [
            'standard_daily_hours' => 8.5
        ], true);

        $this->assertTrue($res['valid']);
        $this->assertSame(8.5, $res['clean']['standard_daily_hours']);
    }

    /**
     * 10. Invalid decimal type
     */
    public function testInvalidDecimal()
    {
        $res = RuleParamValidator::validate('PAYROLL_BASICS', 'Company', [
            'standard_daily_hours' => 'eight_point_five'
        ], true);

        $this->assertFalse($res['valid']);
        $this->assertArrayHasKey('standard_daily_hours', $res['errors']);
        $this->assertStringContainsString('must be a decimal', $res['errors']['standard_daily_hours']);
    }

    /**
     * 11. Valid money type
     */
    public function testValidMoney()
    {
        $res = RuleParamValidator::validate('ATTENDANCE', 'Company', [
            'late_penalty_per_minute' => 2.50
        ], true);

        $this->assertTrue($res['valid']);
        $this->assertSame(2.5, $res['clean']['late_penalty_per_minute']);
    }

    /**
     * 12. Invalid money below minimum
     */
    public function testInvalidMoneyBelowMin()
    {
        $res = RuleParamValidator::validate('ATTENDANCE', 'Company', [
            'late_penalty_per_minute' => -5.0 // min is 0
        ], true);

        $this->assertFalse($res['valid']);
        $this->assertArrayHasKey('late_penalty_per_minute', $res['errors']);
        $this->assertStringContainsString('at least 0', $res['errors']['late_penalty_per_minute']);
    }

    /**
     * 13. Valid string pattern match (HH:MM)
     */
    public function testValidStringPattern()
    {
        $res = RuleParamValidator::validate('ATTENDANCE', 'Company', [
            'office_start_time' => '09:15'
        ], true);

        $this->assertTrue($res['valid']);
        $this->assertSame('09:15', $res['clean']['office_start_time']);
    }

    /**
     * 14. Invalid string pattern mismatch
     */
    public function testInvalidStringPattern()
    {
        $res = RuleParamValidator::validate('ATTENDANCE', 'Company', [
            'office_start_time' => '9:15 AM' // does not match ^\d{2}:\d{2}$
        ], true);

        $this->assertFalse($res['valid']);
        $this->assertArrayHasKey('office_start_time', $res['errors']);
        $this->assertStringContainsString('does not match required pattern', $res['errors']['office_start_time']);
    }

    /**
     * 15. Valid enum selection
     */
    public function testValidEnum()
    {
        $res = RuleParamValidator::validate('PAYROLL_BASICS', 'Company', [
            'daily_rate_mode' => 'Fixed'
        ], true);

        $this->assertTrue($res['valid']);
        $this->assertSame('Fixed', $res['clean']['daily_rate_mode']);
    }

    /**
     * 16. Invalid enum selection
     */
    public function testInvalidEnum()
    {
        $res = RuleParamValidator::validate('PAYROLL_BASICS', 'Company', [
            'daily_rate_mode' => 'Quarterly'
        ], true);

        $this->assertFalse($res['valid']);
        $this->assertArrayHasKey('daily_rate_mode', $res['errors']);
        $this->assertStringContainsString('must be one of: Fixed, Calendar', $res['errors']['daily_rate_mode']);
    }

    /**
     * 17. Valid enum list
     */
    public function testValidEnumList()
    {
        $res = RuleParamValidator::validate('ATTENDANCE', 'Company', [
            'weekly_off_days' => ['Friday', 'Saturday']
        ], true);

        $this->assertTrue($res['valid']);
        $this->assertEquals(['Friday', 'Saturday'], $res['clean']['weekly_off_days']);
    }

    /**
     * 18. Invalid enum list element
     */
    public function testInvalidEnumList()
    {
        $res = RuleParamValidator::validate('ATTENDANCE', 'Company', [
            'weekly_off_days' => ['Friday', 'NotADay']
        ], true);

        $this->assertFalse($res['valid']);
        $this->assertArrayHasKey('weekly_off_days', $res['errors']);
        $this->assertStringContainsString("Invalid value 'NotADay'", $res['errors']['weekly_off_days']);
    }

    /**
     * 19. Nested item error path in array_of_objects (entitlements.0.days_per_year)
     */
    public function testNestedItemErrorPath()
    {
        $res = RuleParamValidator::validate('LEAVE', 'Company', [
            'entitlements' => [
                [
                    'leave_type_code' => 'ANNUAL',
                    'days_per_year'   => -5, // min is 0
                ]
            ]
        ], true);

        $this->assertFalse($res['valid']);
        $this->assertArrayHasKey('entitlements.0.days_per_year', $res['errors']);
        $this->assertStringContainsString('at least 0', $res['errors']['entitlements.0.days_per_year']);
    }

    /**
     * 20. Nested item required field missing (entitlements.0.leave_type_code)
     */
    public function testNestedItemRequiredFieldMissing()
    {
        $res = RuleParamValidator::validate('LEAVE', 'Company', [
            'entitlements' => [
                [
                    'days_per_year' => 10
                    // missing required 'leave_type_code'
                ]
            ]
        ], true);

        $this->assertFalse($res['valid']);
        $this->assertArrayHasKey('entitlements.0.leave_type_code', $res['errors']);
        $this->assertStringContainsString("Parameter 'entitlements.0.leave_type_code' is required", $res['errors']['entitlements.0.leave_type_code']);
    }

    /**
     * 21. Nullable parameter accepts null
     */
    public function testNullableParameterAcceptsNull()
    {
        $res = RuleParamValidator::validate('OVERTIME', 'Company', [
            'daily_threshold_hours' => null // nullable: true
        ], true);

        $this->assertTrue($res['valid']);
        $this->assertNull($res['clean']['daily_threshold_hours']);
    }

    /**
     * 22. Non-nullable parameter rejects null
     */
    public function testNonNullableParameterRejectsNull()
    {
        $res = RuleParamValidator::validate('PAYROLL_BASICS', 'Company', [
            'currency_code' => null
        ], true);

        $this->assertFalse($res['valid']);
        $this->assertArrayHasKey('currency_code', $res['errors']);
        $this->assertStringContainsString('cannot be null', $res['errors']['currency_code']);
    }

    /**
     * 23. Pending inventory accepts string/object
     */
    public function testPendingInventoryAcceptsObjectOrString()
    {
        $res = RuleParamValidator::validate('LEAVE', 'Company', [
            'probation' => [
                'allow_during_probation' => false,
                'min_service_months'     => 3
            ]
        ], true);

        $this->assertTrue($res['valid']);
        $this->assertIsArray($res['clean']['probation']);
    }

    /**
     * 24. component_ref_list accepts valid company salary components
     */
    public function testComponentRefListAcceptsValidCodes()
    {
        RuleSchemaRegistry::setComponentOptionsResolver(function (string $companyId) {
            return [
                ['code' => 'BASIC', 'name' => 'Basic Salary', 'type' => 'earning'],
                ['code' => 'HRA', 'name' => 'House Rent Allowance', 'type' => 'earning'],
            ];
        });

        $res = RuleParamValidator::validate('BONUS', 'Company', [
            'schemes' => [
                [
                    'code'                       => 'EID_FITR',
                    'name'                       => 'Eid ul-Fitr Bonus',
                    'salary_basis'               => 'Selected Components',
                    'included_component_codes'   => ['BASIC', 'HRA'],
                    'calculation_type'           => 'Percentage_Basic',
                    'value'                      => 50.0,
                    'min_service_months'         => 6,
                    'prorate_under_service_days' => false,
                    'prorate_threshold_months'   => 12,
                    'prorate_min_ratio'          => 0.0,
                    'gender_scope'               => 'All',
                    'religion_scope'             => 'Islam',
                    'employment_types'           => ['Permanent'],
                    'department_ids'             => [],
                    'designation_ids'            => [],
                    'payout_month'               => 4,
                    'description'                => 'Test bonus',
                ]
            ]
        ], true, 'comp-test');

        $this->assertTrue($res['valid'], 'Validation should pass when valid component codes are provided');
        $this->assertSame(['BASIC', 'HRA'], $res['clean']['schemes'][0]['included_component_codes']);
    }

    /**
     * 25. component_ref_list rejects unknown component code
     */
    public function testComponentRefListRejectsUnknownCode()
    {
        RuleSchemaRegistry::setComponentOptionsResolver(function (string $companyId) {
            return [
                ['code' => 'BASIC', 'name' => 'Basic Salary', 'type' => 'earning'],
            ];
        });

        $res = RuleParamValidator::validate('BONUS', 'Company', [
            'schemes' => [
                [
                    'code'                       => 'EID_FITR',
                    'name'                       => 'Eid ul-Fitr Bonus',
                    'salary_basis'               => 'Selected Components',
                    'included_component_codes'   => ['UNKNOWN_CODE'],
                    'calculation_type'           => 'Percentage_Basic',
                    'value'                      => 50.0,
                    'min_service_months'         => 6,
                    'prorate_under_service_days' => false,
                    'prorate_threshold_months'   => 12,
                    'prorate_min_ratio'          => 0.0,
                    'gender_scope'               => 'All',
                    'religion_scope'             => 'Islam',
                    'employment_types'           => ['Permanent'],
                    'department_ids'             => [],
                    'designation_ids'            => [],
                    'payout_month'               => 4,
                    'description'                => 'Test bonus',
                ]
            ]
        ], true, 'comp-test');

        $this->assertFalse($res['valid']);
        $this->assertArrayHasKey('schemes.0.included_component_codes', $res['errors']);
        $this->assertStringContainsString("Unknown component code 'UNKNOWN_CODE'", $res['errors']['schemes.0.included_component_codes']);
    }

    /**
     * 26. component_ref_list required when salary_basis is 'Selected Components'
     */
    public function testComponentRefListRequiredWhenSelectedComponents()
    {
        $res = RuleParamValidator::validate('BONUS', 'Company', [
            'schemes' => [
                [
                    'code'                       => 'EID_FITR',
                    'name'                       => 'Eid ul-Fitr Bonus',
                    'salary_basis'               => 'Selected Components',
                    'included_component_codes'   => [],
                    'calculation_type'           => 'Percentage_Basic',
                    'value'                      => 50.0,
                    'min_service_months'         => 6,
                    'prorate_under_service_days' => false,
                    'prorate_threshold_months'   => 12,
                    'prorate_min_ratio'          => 0.0,
                    'gender_scope'               => 'All',
                    'religion_scope'             => 'Islam',
                    'employment_types'           => ['Permanent'],
                    'department_ids'             => [],
                    'designation_ids'            => [],
                    'payout_month'               => 4,
                    'description'                => 'Test bonus',
                ]
            ]
        ], true, 'comp-test');

        $this->assertFalse($res['valid']);
        $this->assertArrayHasKey('schemes.0.included_component_codes', $res['errors']);
        $this->assertStringContainsString("cannot be empty when salary_basis is 'Selected Components'", $res['errors']['schemes.0.included_component_codes']);
    }

    /**
     * 27. PF Domain - Valid Full Company Scope Parameters
     */
    public function testPfParametersValidationFullCompany()
    {
        $pfParams = [
            'contribution_type'     => 'percentage',
            'employee_rate'         => 7.0,
            'employer_rate'         => 7.0,
            'employee_fixed_amount' => 0.0,
            'employer_fixed_amount' => 0.0,
            'calculation_basis'     => 'Basic',
            'basis_components'      => ['Basic'],
            'custom_formula'        => null,
            'employer_formula'      => null,
            'min_salary_limit'      => 0.0,
            'max_salary_limit'      => 0.0,
            'min_deduction_limit'   => 0.0,
            'max_deduction_limit'   => 0.0,
        ];

        $res = RuleParamValidator::validate('PF', 'Company', $pfParams, false);
        $this->assertTrue($res['valid'], "Full company PF parameters must validate successfully: " . json_encode($res['errors'] ?? []));
        $this->assertSame('percentage', $res['clean']['contribution_type']);
        $this->assertSame(7.0, $res['clean']['employee_rate']);
        $this->assertSame(7.0, $res['clean']['employer_rate']);
        $this->assertSame('Basic', $res['clean']['calculation_basis']);
    }

    /**
     * 28. PF Domain - Employee Scope Partial Override Validation
     */
    public function testPfParametersEmployeeOverridePartial()
    {
        $overrideParams = [
            'employee_rate' => 10.0,
            'employer_rate' => 10.0,
        ];

        $res = RuleParamValidator::validate('PF', 'Employee', $overrideParams, true);
        $this->assertTrue($res['valid'], "Partial employee override parameters for PF must validate successfully");
        $this->assertSame(10.0, $res['clean']['employee_rate']);
        $this->assertSame(10.0, $res['clean']['employer_rate']);
    }

    /**
     * 29. PF Domain - Disallowed Scope Level (e.g. Branch or Department)
     */
    public function testPfDisallowedScopeLevel()
    {
        $res = RuleParamValidator::validate('PF', 'Branch', [
            'employee_rate' => 8.0
        ], true);

        $this->assertFalse($res['valid']);
        $this->assertArrayHasKey('scope_level', $res['errors']);
        $this->assertStringContainsString("Scope level 'Branch' is not allowed for domain 'PF'", $res['errors']['scope_level']);
    }

    /**
     * 30. Leave Domain - Sandwich Parameters Typo Rejection
     */
    public function testSandwichTypoRejection()
    {
        // Typo in weekend_treatment
        $res1 = RuleParamValidator::validate('LEAVE', 'Company', [
            'sandwich' => [
                'weekend_treatment' => 'Include if sandwitched',
            ]
        ], true);

        $this->assertFalse($res1['valid']);
        $this->assertArrayHasKey('sandwich.weekend_treatment', $res1['errors']);
        $this->assertStringContainsString('must be one of: Exclude weekly off, Include if sandwiched, Count weekly off as leave', $res1['errors']['sandwich.weekend_treatment']);

        // Typo in holiday_treatment
        $res2 = RuleParamValidator::validate('LEAVE', 'Company', [
            'sandwich' => [
                'holiday_treatment' => 'Exclude holdiays',
            ]
        ], true);

        $this->assertFalse($res2['valid']);
        $this->assertArrayHasKey('sandwich.holiday_treatment', $res2['errors']);
        $this->assertStringContainsString('must be one of: Exclude holidays, Include if sandwiched', $res2['errors']['sandwich.holiday_treatment']);

        // Typo in bridge_leave_action
        $res3 = RuleParamValidator::validate('LEAVE', 'Company', [
            'sandwich' => [
                'bridge_leave_action' => 'Invalid action',
            ]
        ], true);

        $this->assertFalse($res3['valid']);
        $this->assertArrayHasKey('sandwich.bridge_leave_action', $res3['errors']);
        $this->assertStringContainsString('must be one of: Count intervening days, Exclude intervening days', $res3['errors']['sandwich.bridge_leave_action']);

        // Unknown key inside sandwich object
        $res4 = RuleParamValidator::validate('LEAVE', 'Company', [
            'sandwich' => [
                'invalid_nested_key' => true,
            ]
        ], true);

        $this->assertFalse($res4['valid']);
        $this->assertArrayHasKey('sandwich.invalid_nested_key', $res4['errors']);
        $this->assertStringContainsString("Unknown parameter 'invalid_nested_key'", $res4['errors']['sandwich.invalid_nested_key']);
    }

    /**
     * 31. Leave Domain - Sandwich Case Normalization
     */
    public function testSandwichCaseNormalization()
    {
        $res = RuleParamValidator::validate('LEAVE', 'Company', [
            'sandwich' => [
                'enabled'              => true,
                'weekend_treatment'    => 'include if sandwiched',
                'holiday_treatment'    => 'INCLUDE IF SANDWICHED',
                'bridge_leave_enabled' => true,
                'bridge_leave_action'  => 'count intervening days',
            ]
        ], true);

        $this->assertTrue($res['valid'], "Case variations of valid enum options must normalize cleanly: " . json_encode($res['errors'] ?? []));
        $this->assertSame('Include if sandwiched', $res['clean']['sandwich']['weekend_treatment']);
        $this->assertSame('Include if sandwiched', $res['clean']['sandwich']['holiday_treatment']);
        $this->assertSame('Count intervening days', $res['clean']['sandwich']['bridge_leave_action']);
    }

    /**
     * 32. Overtime Domain - Old Alias Keys Rejected Without Sync
     */
    public function testOvertimeOldAliasKeysRejected()
    {
        $res = RuleParamValidator::validate('OVERTIME', 'Branch', [
            'enable_early_checkin_ot'      => true,
            'early_checkin_ot_minutes'     => 30,
            'enable_post_checkout_ot'      => true,
            'post_checkout_ot_min_minutes' => 30,
        ], true);

        $this->assertFalse($res['valid']);
        $this->assertArrayHasKey('enable_early_checkin_ot', $res['errors']);
        $this->assertArrayHasKey('early_checkin_ot_minutes', $res['errors']);
        $this->assertArrayHasKey('enable_post_checkout_ot', $res['errors']);
        $this->assertArrayHasKey('post_checkout_ot_min_minutes', $res['errors']);
    }

    /**
     * 33. PF and BONUS Domains - Formula Fields Validated at Save Time via testFormulaSyntax
     */
    public function testFormulaFieldsValidatedAtSaveTime(): void
    {
        // Valid PF custom_formula and employer_formula
        $validPf = RuleParamValidator::validate('PF', 'Company', [
            'contribution_type'   => 'formula',
            'custom_formula'      => '(BASIC + HRA) * 0.075',
            'employer_formula'    => 'BASIC * 0.075',
        ], true);
        $this->assertTrue($validPf['valid'], json_encode($validPf['errors']));

        // Invalid PF custom_formula (unknown variable & unbalanced parens)
        $badPf = RuleParamValidator::validate('PF', 'Company', [
            'contribution_type'   => 'formula',
            'custom_formula'      => 'UNKNOWN_VAR * 0.10',
            'employer_formula'    => '(BASIC + 100',
        ], true);
        $this->assertFalse($badPf['valid']);
        $this->assertArrayHasKey('custom_formula', $badPf['errors']);
        $this->assertArrayHasKey('employer_formula', $badPf['errors']);
        $this->assertStringContainsString("Unknown variable 'UNKNOWN_VAR'", $badPf['errors']['custom_formula']);
        $this->assertStringContainsString('Unbalanced parentheses', $badPf['errors']['employer_formula']);

        // Missing custom_formula when contribution_type is 'formula'
        $missingPfFormula = RuleParamValidator::validate('PF', 'Company', [
            'contribution_type' => 'formula',
            'custom_formula'    => '',
        ], true);
        $this->assertFalse($missingPfFormula['valid']);
        $this->assertArrayHasKey('custom_formula', $missingPfFormula['errors']);

        // Invalid BONUS scheme custom_formula (division by zero)
        $badBonus = RuleParamValidator::validate('BONUS', 'Company', [
            'schemes' => [[
                'code'                       => 'FEST_1',
                'name'                       => 'Festival Bonus',
                'calculation_type'           => 'Formula',
                'value'                      => 100,
                'custom_formula'             => 'BASIC / 0',
                'min_service_days'           => 180,
                'eligible_employment_types'  => ['Permanent'],
            ]],
        ], true);
        $this->assertFalse($badBonus['valid']);
        $this->assertArrayHasKey('schemes.0.custom_formula', $badBonus['errors']);
        $this->assertStringContainsString('Division by zero', $badBonus['errors']['schemes.0.custom_formula']);
    }
}
