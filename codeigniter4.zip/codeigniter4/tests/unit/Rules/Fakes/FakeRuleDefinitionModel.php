<?php

namespace Tests\Unit\Rules\Fakes;

/**
 * Fake model providing in-memory rule rows for testing RuleResolver and DailyRateResolver in isolation.
 */
class FakeRuleDefinitionModel
{
    /** @var array<int, array<string, mixed>> */
    public array $rows;

    public function __construct(array $rows = [])
    {
        $this->rows = $rows;
    }

    public function getActiveRules(string $companyId, string $domain): array
    {
        $filtered = [];
        foreach ($this->rows as $r) {
            $rComp = isset($r['company_id']) ? (string)$r['company_id'] : null;
            $rDom  = isset($r['domain']) ? strtoupper((string)$r['domain']) : null;
            $rStat = isset($r['status']) ? (string)$r['status'] : 'Active';

            if ($rComp === $companyId && $rDom === $domain && $rStat === 'Active') {
                $filtered[] = $r;
            }
        }
        return $filtered;
    }

    public function paramsOf(?array $row): array
    {
        if (empty($row) || !isset($row['params_json'])) {
            return [];
        }
        if (is_array($row['params_json'])) {
            return $row['params_json'];
        }
        $decoded = json_decode((string)$row['params_json'], true);
        return is_array($decoded) ? $decoded : [];
    }
}

if (!class_exists('Tests\Unit\Rules\FakeRuleDefinitionModel', false)) {
    class_alias(FakeRuleDefinitionModel::class, 'Tests\Unit\Rules\FakeRuleDefinitionModel');
}
