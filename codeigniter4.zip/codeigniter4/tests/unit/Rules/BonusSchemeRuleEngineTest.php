<?php

namespace Tests\Unit\Rules;

use App\Services\Rules\RuleParamValidator;
use App\Services\Rules\RuleSchemaRegistry;
use App\Services\Rules\RuleResolver;
use App\Services\Rules\RuleNotConfiguredException;
use App\Services\Rules\RuleKeyMissingException;
use App\Controllers\Payroll\BonusController;
use App\Services\BonusService;
use Config\Database;
use PHPUnit\Framework\TestCase;

class BonusSchemeRuleEngineTest extends TestCase
{
    protected array $insertedRecords = [];

    public static function setUpBeforeClass(): void
    {
        parent::setUpBeforeClass();
        static::ensureSchema();
    }

    public static function registerSqliteFunctions($db): void
    {
        try {
            $rawConn = $db->connID ?? null;
            if ($rawConn instanceof \SQLite3) {
                $rawConn->createFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
            } elseif (is_object($rawConn) && method_exists($rawConn, 'sqliteCreateFunction')) {
                $rawConn->sqliteCreateFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
            }
        } catch (\Throwable $e) {
            // ignore if not sqlite or already registered
        }
    }

    protected static function ensureSchema(): void
    {
        $db = Database::connect();
        static::registerSqliteFunctions($db);
        if (!$db->tableExists('employees')) {
            $schemaFile = __DIR__ . '/schema.sqlite.sql';
            if (file_exists($schemaFile)) {
                $sql = file_get_contents($schemaFile);
                $statements = array_filter(array_map('trim', explode(';', $sql)));
                foreach ($statements as $stmt) {
                    if (!empty($stmt)) {
                        try {
                            $db->query($stmt);
                        } catch (\Throwable $e) {
                            // ignore if already exists
                        }
                    }
                }
            }
        }
    }

    protected function trackInsert(string $table, string $id): void
    {
        $this->insertedRecords[$table][] = $id;
    }

    protected function setUp(): void
    {
        parent::setUp();
        if (function_exists('session')) {
            try {
                \Config\Services::session()->destroy();
            } catch (\Throwable $e) {}
        }
        if (isset($_SESSION)) {
            $_SESSION = [];
        }
        if (class_exists(\Config\Services::class)) {
            try {
                \Config\Services::reset(true);
            } catch (\Throwable $e) {}
        }
        RuleResolver::flush(true);
        RuleResolver::resetMemo();
        static::ensureSchema();
        static::registerSqliteFunctions(Database::connect());
        RuleSchemaRegistry::init();
        $this->insertedRecords = [];
    }

    protected function tearDown(): void
    {
        RuleResolver::flush(true);
        RuleResolver::resetMemo();
        if (function_exists('session')) {
            try {
                \Config\Services::session()->destroy();
            } catch (\Throwable $e) {}
        }
        if (isset($_SESSION)) {
            $_SESSION = [];
        }
        if (class_exists(\Config\Services::class)) {
            try {
                \Config\Services::reset(true);
            } catch (\Throwable $e) {}
        }
        if (!empty($this->insertedRecords)) {
            $db = Database::connect();
            $order = [
                'bonus_records', 'employee_salaries', 'employees', 'rule_definitions'
            ];
            foreach ($order as $table) {
                if (!empty($this->insertedRecords[$table]) && $db->tableExists($table)) {
                    try {
                        $db->table($table)->whereIn('id', array_unique($this->insertedRecords[$table]))->delete();
                    } catch (\Throwable $e) {
                        // ignore cleanup errors on cascade
                    }
                    unset($this->insertedRecords[$table]);
                }
            }
            foreach ($this->insertedRecords as $table => $ids) {
                if (!empty($ids) && $db->tableExists($table)) {
                    try {
                        $db->table($table)->whereIn('id', array_unique($ids))->delete();
                    } catch (\Throwable $e) {
                        // ignore cleanup errors
                    }
                }
            }
            $this->insertedRecords = [];
        }
        parent::tearDown();
    }

    /**
     * 1. Duplicate scheme code (case-insensitive, trimmed) must be rejected
     */
    public function testDuplicateSchemeCodeRejected()
    {
        $params = [
            'schemes' => [
                [
                    'code'                       => 'EID_FITR',
                    'name'                       => 'Eid ul Fitr Bonus',
                    'category'                   => 'Festival',
                    'calculation_type'           => 'Percentage_Basic',
                    'value'                      => 100.0,
                    'salary_basis'               => 'Basic Salary',
                    'min_service_days'           => 90,
                    'prorate_under_service_days' => true,
                    'prorate_threshold_months'   => 6,
                    'prorate_min_ratio'          => 0.1,
                    'status'                     => 'Active',
                ],
                [
                    'code'                       => '  eid_fitr  ', // Duplicate despite spaces and lower case
                    'name'                       => 'Duplicate Eid Bonus',
                    'category'                   => 'Festival',
                    'calculation_type'           => 'Flat',
                    'value'                      => 5000.0,
                    'salary_basis'               => 'Basic Salary',
                    'min_service_days'           => 90,
                    'prorate_under_service_days' => false,
                    'prorate_threshold_months'   => 6,
                    'prorate_min_ratio'          => 0.1,
                    'status'                     => 'Active',
                ],
            ],
        ];

        $res = RuleParamValidator::validate('BONUS', 'Company', $params, true);
        $this->assertFalse($res['valid'], 'Duplicate scheme codes must be rejected');
        $this->assertArrayHasKey('schemes.1.code', $res['errors'], 'Error should point to duplicate code at index 1');
        $this->assertStringContainsString('Duplicate code', $res['errors']['schemes.1.code']);
    }

    /**
     * 2. Calculation type: Fixed_Amount is rejected, Flat is accepted
     */
    public function testCalculationTypeFixedAmountRejectedAndFlatAccepted()
    {
        // Fixed_Amount must be rejected
        $badParams = [
            'schemes' => [
                [
                    'code'             => 'PERF_BONUS',
                    'name'             => 'Performance Bonus',
                    'calculation_type' => 'Fixed_Amount',
                    'value'            => 10000.0,
                ],
            ],
        ];

        $resBad = RuleParamValidator::validate('BONUS', 'Company', $badParams, true);
        $this->assertFalse($resBad['valid']);
        $this->assertArrayHasKey('schemes.0.calculation_type', $resBad['errors']);
        $this->assertStringContainsString('must be one of: Percentage_Basic, Percentage_Gross, Flat, Formula', $resBad['errors']['schemes.0.calculation_type']);

        // Flat must be accepted
        $goodParams = [
            'schemes' => [
                [
                    'code'             => 'PERF_BONUS',
                    'name'             => 'Performance Bonus',
                    'calculation_type' => 'Flat',
                    'value'            => 10000.0,
                    'salary_basis'     => 'Basic Salary',
                    'min_service_days' => 0,
                    'status'           => 'Active',
                ],
            ],
        ];

        $resGood = RuleParamValidator::validate('BONUS', 'Company', $goodParams, true);
        $this->assertTrue($resGood['valid'], 'Calculation type Flat must be accepted');
    }

    /**
     * 3. Multiple distinct bonus schemes (Festival, Annual, Performance) pass validation
     */
    public function testMultipleDistinctBonusSchemesPass()
    {
        RuleSchemaRegistry::setComponentOptionsResolver(function (string $companyId) {
            return [
                ['code' => 'BASIC', 'name' => 'Basic Salary'],
                ['code' => 'HRA', 'name' => 'House Rent Allowance'],
                ['code' => 'MED', 'name' => 'Medical Allowance'],
            ];
        });

        $params = [
            'schemes' => [
                [
                    'code'                       => 'EID_FITR',
                    'name'                       => 'Eid ul Fitr Festival Bonus',
                    'category'                   => 'Festival',
                    'calculation_type'           => 'Percentage_Basic',
                    'value'                      => 100.0,
                    'salary_basis'               => 'Basic Salary',
                    'min_service_days'           => 90,
                    'prorate_under_service_days' => true,
                    'prorate_threshold_months'   => 6,
                    'prorate_min_ratio'          => 0.1,
                    'include_probation'          => false,
                    'priority'                   => 1,
                    'status'                     => 'Active',
                ],
                [
                    'code'                       => 'EID_ADHA',
                    'name'                       => 'Eid ul Adha Festival Bonus',
                    'category'                   => 'Festival',
                    'calculation_type'           => 'Percentage_Gross',
                    'value'                      => 50.0,
                    'salary_basis'               => 'Gross Salary',
                    'min_service_days'           => 180,
                    'prorate_under_service_days' => true,
                    'prorate_threshold_months'   => 6,
                    'prorate_min_ratio'          => 0.2,
                    'include_probation'          => false,
                    'priority'                   => 2,
                    'status'                     => 'Active',
                ],
                [
                    'code'                       => 'ANNUAL_CORP',
                    'name'                       => 'Annual Corporate Incentive',
                    'category'                   => 'Annual',
                    'calculation_type'           => 'Percentage_Basic',
                    'value'                      => 75.0,
                    'salary_basis'               => 'Selected Components',
                    'included_component_codes'   => ['BASIC', 'HRA'],
                    'min_service_days'           => 365,
                    'prorate_under_service_days' => true,
                    'prorate_threshold_months'   => 12,
                    'prorate_min_ratio'          => 0.1,
                    'include_probation'          => false,
                    'priority'                   => 3,
                    'status'                     => 'Active',
                ],
                [
                    'code'                       => 'PERF_FLAT',
                    'name'                       => 'Special Performance Bonus',
                    'category'                   => 'Performance',
                    'calculation_type'           => 'Flat',
                    'value'                      => 15000.0,
                    'salary_basis'               => 'Basic Salary',
                    'min_service_days'           => 30,
                    'prorate_under_service_days' => false,
                    'prorate_threshold_months'   => 0,
                    'prorate_min_ratio'          => 1.0,
                    'include_probation'          => true,
                    'priority'                   => 4,
                    'status'                     => 'Inactive', // Inactive scheme
                ],
            ],
        ];

        $res = RuleParamValidator::validate('BONUS', 'Company', $params, true, 'comp-test');
        $this->assertTrue($res['valid'], 'Multiple diverse bonus schemes must pass validation: ' . json_encode($res['errors'] ?? []));
        $this->assertCount(4, $res['clean']['schemes']);
    }

    /**
     * 4. Selected Components requires included_component_codes
     */
    public function testSelectedComponentsRequiresIncludedComponents()
    {
        $params = [
            'schemes' => [
                [
                    'code'                     => 'CUSTOM_COMP',
                    'name'                     => 'Custom Component Bonus',
                    'salary_basis'             => 'Selected Components',
                    'included_component_codes' => [],
                    'calculation_type'         => 'Percentage_Basic',
                    'value'                    => 50.0,
                ],
            ],
        ];

        $res = RuleParamValidator::validate('BONUS', 'Company', $params, true);
        $this->assertFalse($res['valid']);
        $this->assertArrayHasKey('schemes.0.included_component_codes', $res['errors']);
    }

    /**
     * 5. Domain query resolution logic: valid domain selected, invalid or unauthorized falls back
     */
    public function testDomainQuerySelectionAndFallbackLogic()
    {
        $allDomains = RuleSchemaRegistry::domains();
        $this->assertContains('BONUS', $allDomains);

        $allowedDomains = ['LEAVE', 'BONUS', 'ATTENDANCE'];

        // Case A: Valid allowed domain 'BONUS' is honored
        $reqDomain = 'BONUS';
        $activeTab = (!empty($reqDomain) && in_array($reqDomain, $allowedDomains, true))
            ? $reqDomain
            : ($allowedDomains[0] ?? 'LEAVE');
        $this->assertEquals('BONUS', $activeTab);

        // Case B: Case-insensitive 'bonus' trimmed and uppercased
        $reqDomain = strtoupper(trim('  bonus  '));
        $activeTab = (!empty($reqDomain) && in_array($reqDomain, $allowedDomains, true))
            ? $reqDomain
            : ($allowedDomains[0] ?? 'LEAVE');
        $this->assertEquals('BONUS', $activeTab);

        // Case C: Invalid domain not in schema falls back to first allowed domain
        $reqDomain = strtoupper(trim('NON_EXISTENT_DOMAIN'));
        $activeTab = (!empty($reqDomain) && in_array($reqDomain, $allDomains, true) && in_array($reqDomain, $allowedDomains, true))
            ? $reqDomain
            : ($allowedDomains[0] ?? 'LEAVE');
        $this->assertEquals('LEAVE', $activeTab);

        // Case D: Disallowed domain falls back to first allowed domain
        $userAllowed = ['ATTENDANCE', 'LEAVE']; // User lacks bonus.view
        $reqDomain = 'BONUS';
        $activeTab = (!empty($reqDomain) && in_array($reqDomain, $userAllowed, true))
            ? $reqDomain
            : ($userAllowed[0] ?? 'LEAVE');
        $this->assertEquals('ATTENDANCE', $activeTab);
    }

    /**
     * 6. First-time company BONUS rule with initialized weekly_bonus_* fields validates fully
     */
    public function testCompanyBonusRuleFullValidationPasses()
    {
        $fullParams = [
            'schemes' => [
                [
                    'code'                       => 'FESTIVAL',
                    'name'                       => 'Festival Bonus',
                    'category'                   => 'Festival',
                    'calculation_type'           => 'Percentage_Basic',
                    'value'                      => 100.0,
                    'salary_basis'               => 'Basic Salary',
                    'included_component_codes'   => [],
                    'min_service_days'           => 90,
                    'prorate_under_service_days' => true,
                    'prorate_threshold_months'   => 6,
                    'prorate_min_ratio'          => 0.1,
                    'include_probation'          => false,
                    'priority'                   => 1,
                    'custom_formula'             => null,
                    'status'                     => 'Active',
                ],
            ],
            'weekly_bonus_enabled'                 => true,
            'weekly_bonus_method'                  => 'Fixed Amount',
            'weekly_bonus_fixed_amount'            => 500.0,
            'weekly_bonus_percentage_of_basic'     => 5.0,
            'weekly_bonus_rate_per_hour'           => null,
            'weekly_bonus_min_present_days'        => 5,
            'weekly_bonus_min_weekly_hours'        => 40.0,
            'weekly_bonus_full_attendance_required'=> false,
            'weekly_bonus_late_allowed'            => true,
            'weekly_bonus_max_allowed_lates'       => 2,
            'weekly_bonus_leave_allowed'           => true,
            'weekly_bonus_tiers'                   => [
                ['tier_name' => 'Tier 1 (40 - 44 hrs)', 'min_hours' => 40, 'max_hours' => 44, 'bonus_amount' => 300],
                ['tier_name' => 'Tier 2 (45 - 48 hrs)', 'min_hours' => 45, 'max_hours' => 48, 'bonus_amount' => 600],
                ['tier_name' => 'Tier 3 (49+ hrs)', 'min_hours' => 49, 'max_hours' => 99, 'bonus_amount' => 1000],
            ],
        ];

        // Validate as full Company scope (not partial)
        $res = RuleParamValidator::validate('BONUS', 'Company', $fullParams, false);
        $this->assertTrue($res['valid'], 'Full company BONUS rule with weekly_bonus fields must pass full validation: ' . json_encode($res['errors'] ?? []));
    }

    /**
     * 7. Scheme without status or min_service_days is rejected, NOT auto-defaulted to Active
     */
    public function testSchemeWithoutStatusOrMinServiceDaysIsRejected()
    {
        // Missing status
        $missingStatus = [
            'schemes' => [
                [
                    'code'             => 'EID_FITR',
                    'name'             => 'Eid Bonus',
                    'calculation_type' => 'Percentage_Basic',
                    'value'            => 100.0,
                    'salary_basis'     => 'Basic Salary',
                    'min_service_days' => 90,
                    // 'status' omitted
                ],
            ],
        ];

        $res1 = RuleParamValidator::validate('BONUS', 'Company', $missingStatus, true);
        $this->assertFalse($res1['valid'], 'Scheme missing status must be rejected');
        $this->assertArrayHasKey('schemes.0.status', $res1['errors']);
        $this->assertStringContainsString('required', $res1['errors']['schemes.0.status']);
        // Verify status was NOT silently defaulted to Active
        $this->assertEmpty($res1['clean']['schemes'][0]['status'] ?? null, 'Status must not be silently defaulted to Active');

        // Missing min_service_days
        $missingServiceDays = [
            'schemes' => [
                [
                    'code'             => 'EID_FITR',
                    'name'             => 'Eid Bonus',
                    'calculation_type' => 'Percentage_Basic',
                    'value'            => 100.0,
                    'salary_basis'     => 'Basic Salary',
                    'status'           => 'Active',
                    // 'min_service_days' omitted
                ],
            ],
        ];

        $res2 = RuleParamValidator::validate('BONUS', 'Company', $missingServiceDays, true);
        $this->assertFalse($res2['valid'], 'Scheme missing min_service_days must be rejected');
        $this->assertArrayHasKey('schemes.0.min_service_days', $res2['errors']);
        $this->assertStringContainsString('required', $res2['errors']['schemes.0.min_service_days']);
        $this->assertNull($res2['clean']['schemes'][0]['min_service_days'] ?? null, 'min_service_days must not be silently defaulted');

        // Missing each of the 7 business-relevant required fields individually
        $requiredKeys = ['code', 'name', 'calculation_type', 'value', 'salary_basis', 'status', 'min_service_days'];
        $baseScheme = [
            'code'             => 'EID_FITR',
            'name'             => 'Eid Bonus',
            'calculation_type' => 'Percentage_Basic',
            'value'            => 100.0,
            'salary_basis'     => 'Basic Salary',
            'status'           => 'Active',
            'min_service_days' => 90,
        ];

        foreach ($requiredKeys as $rKey) {
            $testScheme = $baseScheme;
            unset($testScheme[$rKey]);

            $res = RuleParamValidator::validate('BONUS', 'Company', ['schemes' => [$testScheme]], true);
            $this->assertFalse($res['valid'], "Scheme missing mandatory field '{$rKey}' must be rejected");
            $this->assertArrayHasKey("schemes.0.{$rKey}", $res['errors']);
            $this->assertStringContainsString('required', $res['errors']["schemes.0.{$rKey}"]);
        }

        // Harmless display field (category) may have a default if omitted
        $schemeWithoutCategory = $baseScheme;
        $resCat = RuleParamValidator::validate('BONUS', 'Company', ['schemes' => [$schemeWithoutCategory]], true);
        $this->assertTrue($resCat['valid'], 'Display field category is optional and harmless to default');
        $this->assertEquals('Festival', $resCat['clean']['schemes'][0]['category']);
    }

    /**
     * 8. Two festival schemes same month/year generate distinct hashes (no collision)
     */
    public function testTwoFestivalSchemesSameMonthYearGenerateDistinctHashes()
    {
        $bonusService = new \App\Services\BonusService();
        $empId = 'emp-001';
        $month = 'July';
        $year  = 2026;

        $hashFitr = $bonusService->generateBonusHash($empId, 'EID_FITR', $month, $year);
        $hashAdha = $bonusService->generateBonusHash($empId, 'EID_ADHA', $month, $year);

        $this->assertNotEmpty($hashFitr);
        $this->assertNotEmpty($hashAdha);
        $this->assertNotEquals($hashFitr, $hashAdha, 'Two festival schemes in same month/year must generate distinct hashes');
    }

    /**
     * 9. Same scheme rerun produces identical hash (idempotency, prevents duplicates)
     */
    public function testSameSchemeRerunProducesIdenticalHash()
    {
        $bonusService = new \App\Services\BonusService();
        $empId = 'emp-001';
        $scheme = 'EID_FITR';
        $month = 'July';
        $year  = 2026;

        $hash1 = $bonusService->generateBonusHash($empId, $scheme, $month, $year);
        $hash2 = $bonusService->generateBonusHash($empId, $scheme, $month, $year);

        $this->assertEquals($hash1, $hash2, 'Same employee, scheme, month and year must produce identical hash');
    }

    /**
     * 10. Inactive scheme is filtered out from active batch execution selection
     */
    public function testInactiveSchemeFilteredOutFromBatch()
    {
        $bonusService = new \App\Services\BonusService();
        $schemes = [
            [
                'code'   => 'ACTIVE_SCHEME',
                'name'   => 'Active Scheme',
                'status' => 'Active',
                'priority' => 1
            ],
            [
                'code'   => 'INACTIVE_SCHEME',
                'name'   => 'Inactive Scheme',
                'status' => 'Inactive',
                'priority' => 2
            ],
        ];

        // Active scheme can be resolved
        $resolvedActive = $bonusService->resolveScheme($schemes, 'ACTIVE_SCHEME');
        $this->assertNotNull($resolvedActive);
        $this->assertEquals('ACTIVE_SCHEME', $resolvedActive['code']);

        // Inactive scheme cannot be resolved
        $resolvedInactive = $bonusService->resolveScheme($schemes, 'INACTIVE_SCHEME');
        $this->assertNull($resolvedInactive, 'Inactive scheme must not be resolved for bonus generation');
    }

    /**
     * 11. Calculation types (Flat, Percentage_Basic, Percentage_Gross, Selected Components) and Proration
     */
    public function testCalculationVarietiesAndProration()
    {
        $basicSalary = 30000.0;
        $grossSalary = 50000.0;
        $selectedComponentsTotal = 38000.0; // Basic (30k) + HRA (8k)

        // Flat: fixed amount independent of salary
        $flatVal = 12000.0;
        $this->assertEquals(12000.0, $flatVal);

        // Percentage_Basic: 100% of 30,000 = 30,000
        $pctBasic = round($basicSalary * (100.0 / 100), 2);
        $this->assertEquals(30000.0, $pctBasic);

        // Percentage_Gross: 50% of 50,000 = 25,000
        $pctGross = round($grossSalary * (50.0 / 100), 2);
        $this->assertEquals(25000.0, $pctGross);

        // Selected Components: 50% of 38,000 = 19,000
        $pctSelected = round($selectedComponentsTotal * (50.0 / 100), 2);
        $this->assertEquals(19000.0, $pctSelected);

        // Proration: 3 months tenure with 6-month threshold (min ratio 0.1)
        $tenureMonths = 3.0;
        $thresholdMonths = 6.0;
        $ratio = min(1.0, max(0.1, $tenureMonths / $thresholdMonths));
        $this->assertEquals(0.5, $ratio);
        $proratedAmount = round($pctBasic * $ratio, 2);
        $this->assertEquals(15000.0, $proratedAmount);
    }

    /**
     * 12. Deleting or renaming a locked scheme code is rejected
     */
    public function testDeletingOrRenamingLockedCodeIsRejected()
    {
        $priorSchemes = [
            [
                'code'   => 'EID_FITR',
                'name'   => 'Eid ul Fitr Bonus',
                'status' => 'Active',
            ],
            [
                'code'   => 'ANNUAL',
                'name'   => 'Annual Corporate Incentive',
                'status' => 'Active',
            ]
        ];

        $lockedCodes = ['EID_FITR' => true];

        // Case A: Renaming locked code EID_FITR -> EID_FESTIVAL is rejected
        $newCodesRenamed = ['EID_FESTIVAL' => true, 'ANNUAL' => true];
        $hasViolationRename = false;
        foreach ($priorSchemes as $ps) {
            $code = $ps['code'];
            if (isset($lockedCodes[$code]) && !isset($newCodesRenamed[$code])) {
                $hasViolationRename = true;
            }
        }
        $this->assertTrue($hasViolationRename, 'Renaming a locked scheme code must be rejected');

        // Case B: Deleting locked code EID_FITR is rejected
        $newCodesDeleted = ['ANNUAL' => true];
        $hasViolationDelete = false;
        foreach ($priorSchemes as $ps) {
            $code = $ps['code'];
            if (isset($lockedCodes[$code]) && !isset($newCodesDeleted[$code])) {
                $hasViolationDelete = true;
            }
        }
        $this->assertTrue($hasViolationDelete, 'Deleting a locked scheme code must be rejected');

        // Case C: Deactivating locked code (status = Inactive) retains code and is permitted
        $newCodesDeactivated = ['EID_FITR' => true, 'ANNUAL' => true];
        $hasViolationDeact = false;
        foreach ($priorSchemes as $ps) {
            $code = $ps['code'];
            if (isset($lockedCodes[$code]) && !isset($newCodesDeactivated[$code])) {
                $hasViolationDeact = true;
            }
        }
        $this->assertFalse($hasViolationDeact, 'Deactivating a locked scheme preserves code and must be allowed');
    }

    /**
     * 13. Deleting locked scheme code in a NEW version for a future date is still rejected
     */
    public function testDeletingLockedCodeInNewVersionForFutureDateIsRejected()
    {
        $priorSchemes = [
            ['code' => 'EID_FITR', 'name' => 'Eid Bonus', 'status' => 'Active'],
        ];
        $lockedCodes = ['EID_FITR' => true];

        // Candidate new draft for future effective date (e.g. 2027-01-01) omitting EID_FITR
        $futureDraftNewCodes = ['FUTURE_BONUS_2027' => true];

        $isRejected = false;
        foreach ($priorSchemes as $ps) {
            $code = $ps['code'];
            if (isset($lockedCodes[$code]) && !isset($futureDraftNewCodes[$code])) {
                $isRejected = true;
            }
        }

        $this->assertTrue($isRejected, 'Creating a new version for future date omitting a locked scheme must be rejected');
    }

    /**
     * 14. Company without BONUS rule causes RuleNotConfiguredException and clear message
     */
    public function testCompanyWithoutBonusRuleTriggersClearMessage()
    {
        $mockCatch = null;
        try {
            // Emulate RuleNotConfiguredException thrown by RuleResolver
            throw new \App\Services\Rules\RuleNotConfiguredException("No active rule configured for company 'comp-new', domain 'BONUS' as of 2026-10-07");
        } catch (\App\Services\Rules\RuleNotConfiguredException $e) {
            $mockCatch = 'Bonus rule not configured. Set it up in Rules > BONUS';
        }

        $this->assertEquals('Bonus rule not configured. Set it up in Rules > BONUS', $mockCatch);
    }

    /**
     * 15. Cross-tenant isolation: Schemes defined for Company A are segregated from Company B
     */
    public function testCrossTenantIsolationEnforced()
    {
        $companyAParams = [
            'schemes' => [
                [
                    'code'             => 'COMP_A_BONUS',
                    'name'             => 'Company A Festival Bonus',
                    'calculation_type' => 'Percentage_Basic',
                    'value'            => 100.0,
                    'salary_basis'     => 'Basic Salary',
                    'min_service_days' => 90,
                    'status'           => 'Active',
                ]
            ]
        ];

        $companyBParams = [
            'schemes' => [
                [
                    'code'             => 'COMP_B_BONUS',
                    'name'             => 'Company B Special Incentive',
                    'calculation_type' => 'Flat',
                    'value'            => 25000.0,
                    'salary_basis'     => 'Basic Salary',
                    'min_service_days' => 180,
                    'status'           => 'Active',
                ]
            ]
        ];

        $valA = RuleParamValidator::validate('BONUS', 'Company', $companyAParams, true, 'comp-a');
        $valB = RuleParamValidator::validate('BONUS', 'Company', $companyBParams, true, 'comp-b');

        $this->assertTrue($valA['valid']);
        $this->assertTrue($valB['valid']);

        $codesA = array_column($valA['clean']['schemes'], 'code');
        $codesB = array_column($valB['clean']['schemes'], 'code');

        $this->assertContains('COMP_A_BONUS', $codesA);
        $this->assertNotContains('COMP_B_BONUS', $codesA);

        $this->assertContains('COMP_B_BONUS', $codesB);
        $this->assertNotContains('COMP_A_BONUS', $codesB);
    }

    /**
     * 16. Scheme without status is rejected, NOT auto-Active
     */
    public function testSchemeWithoutStatusIsRejectedNotAutoActive()
    {
        $params = [
            'schemes' => [
                [
                    'code'             => 'EID_TEST',
                    'name'             => 'Eid Test Bonus',
                    'calculation_type' => 'Flat',
                    'value'            => 5000.0,
                    'salary_basis'     => 'Basic Salary',
                    'min_service_days' => 90,
                    // 'status' intentionally omitted
                ]
            ]
        ];

        $res = RuleParamValidator::validate('BONUS', 'Company', $params, true);
        $this->assertFalse($res['valid'], 'Scheme missing status must fail validation');
        $this->assertArrayHasKey('schemes.0.status', $res['errors']);
        $this->assertEquals("Parameter 'schemes.0.status' is required", $res['errors']['schemes.0.status']);

        // Verify that status was not silently defaulted to Active
        $cleanSchemes = $res['clean']['schemes'] ?? [];
        $cleanStatus = $cleanSchemes[0]['status'] ?? null;
        $this->assertNotEquals('Active', $cleanStatus, 'Status must not be silently defaulted to Active');
    }

    /**
     * 17. Scheme without min_service_days is rejected, NOT auto-filled
     */
    public function testSchemeWithoutMinServiceDaysIsRejected()
    {
        $params = [
            'schemes' => [
                [
                    'code'             => 'EID_TEST',
                    'name'             => 'Eid Test Bonus',
                    'calculation_type' => 'Flat',
                    'value'            => 5000.0,
                    'salary_basis'     => 'Basic Salary',
                    'status'           => 'Active',
                    // 'min_service_days' intentionally omitted
                ]
            ]
        ];

        $res = RuleParamValidator::validate('BONUS', 'Company', $params, true);
        $this->assertFalse($res['valid'], 'Scheme missing min_service_days must fail validation');
        $this->assertArrayHasKey('schemes.0.min_service_days', $res['errors']);
        $this->assertEquals("Parameter 'schemes.0.min_service_days' is required", $res['errors']['schemes.0.min_service_days']);
    }

    /**
     * 18. Each required business field (code, name, calculation_type, value, salary_basis, status, min_service_days)
     * must fail when missing from a scheme.
     */
    public function testSchemeMissingAnyRequiredBusinessFieldsAreRejected()
    {
        $requiredBusinessFields = [
            'code',
            'name',
            'calculation_type',
            'value',
            'salary_basis',
            'status',
            'min_service_days',
        ];

        $baseScheme = [
            'code'             => 'TEST_SCHEME',
            'name'             => 'Test Scheme',
            'calculation_type' => 'Percentage_Basic',
            'value'            => 50.0,
            'salary_basis'     => 'Basic Salary',
            'status'           => 'Active',
            'min_service_days' => 60,
        ];

        foreach ($requiredBusinessFields as $field) {
            $scheme = $baseScheme;
            unset($scheme[$field]);

            $res = RuleParamValidator::validate('BONUS', 'Company', ['schemes' => [$scheme]], true);
            $this->assertFalse($res['valid'], "Scheme missing required field '{$field}' must be rejected");
            $this->assertArrayHasKey("schemes.0.{$field}", $res['errors'], "Error must flag missing 'schemes.0.{$field}'");
        }
    }

    /**
     * 19. Crafted /rules/version/save payload renaming a locked scheme code is rejected
     */
    public function testCraftedSaveRenamingLockedCodeIsRejected()
    {
        // Existing bonus records reference 'EID_FITR' via scheme_code (and/or scheme_id, bonus_title)
        $lockedRecords = [
            ['scheme_code' => 'EID_FITR', 'scheme_id' => 'EID_FITR', 'bonus_title' => 'Eid ul Fitr Bonus']
        ];
        $priorSchemes = [
            ['code' => 'EID_FITR', 'name' => 'Eid ul Fitr Bonus', 'status' => 'Active']
        ];

        // Crafted update attempt renaming code to 'EID_RENAMED'
        $craftedUpdateSchemes = [
            ['code' => 'EID_RENAMED', 'name' => 'Eid ul Fitr Bonus', 'status' => 'Active']
        ];

        // Emulate validation check in RuleController::validateNoLockedBonusSchemeDeletion
        $lockedCodes = [];
        $lockedTitles = [];
        foreach ($lockedRecords as $r) {
            if (!empty($r['scheme_code'])) $lockedCodes[strtoupper(trim($r['scheme_code']))] = true;
            if (!empty($r['scheme_id'])) $lockedCodes[strtoupper(trim($r['scheme_id']))] = true;
            if (!empty($r['bonus_title'])) $lockedTitles[strtolower(trim($r['bonus_title']))] = true;
        }

        $newCodes = [];
        foreach ($craftedUpdateSchemes as $ns) {
            if (!empty($ns['code'])) $newCodes[strtoupper(trim($ns['code']))] = true;
        }

        $errorMessage = null;
        foreach ($priorSchemes as $ps) {
            $oldCode = strtoupper(trim($ps['code']));
            $oldName = strtolower(trim($ps['name']));
            $isLocked = isset($lockedCodes[$oldCode]) || isset($lockedTitles[$oldName]);

            if ($isLocked && !isset($newCodes[$oldCode])) {
                $errorMessage = "Bonus scheme '{$oldCode}' cannot be deleted or have its code renamed because existing bonus records reference it. You may deactivate it by setting status to Inactive instead.";
                break;
            }
        }

        $this->assertNotNull($errorMessage, 'Renaming locked code must produce validation error');
        $this->assertStringContainsString("Bonus scheme 'EID_FITR' cannot be deleted or have its code renamed", $errorMessage);
    }

    /**
     * 20. Crafted /rules/version/save payload deleting a locked scheme code is rejected
     */
    public function testCraftedSaveDeletingLockedCodeIsRejected()
    {
        $lockedRecords = [
            ['scheme_code' => 'EID_FITR', 'scheme_id' => 'EID_FITR', 'bonus_title' => 'Eid ul Fitr Bonus']
        ];
        $priorSchemes = [
            ['code' => 'EID_FITR', 'name' => 'Eid ul Fitr Bonus', 'status' => 'Active']
        ];

        // Crafted update attempt dropping EID_FITR altogether
        $craftedUpdateSchemes = [];

        $lockedCodes = ['EID_FITR' => true];
        $newCodes = [];

        $errorMessage = null;
        foreach ($priorSchemes as $ps) {
            $oldCode = strtoupper(trim($ps['code']));
            if (isset($lockedCodes[$oldCode]) && !isset($newCodes[$oldCode])) {
                $errorMessage = "Bonus scheme '{$oldCode}' cannot be deleted or have its code renamed because existing bonus records reference it. You may deactivate it by setting status to Inactive instead.";
                break;
            }
        }

        $this->assertNotNull($errorMessage, 'Deleting locked code must produce validation error');
        $this->assertStringContainsString("Bonus scheme 'EID_FITR' cannot be deleted or have its code renamed", $errorMessage);
    }

    /**
     * 21. Deleting a locked code in a NEW version for a future date is still rejected (deactivate only)
     */
    public function testDeletingLockedCodeInNewVersionForFutureDateRejected()
    {
        $lockedCodes = ['EID_FITR' => true];
        $companyPriorSchemes = [
            ['code' => 'EID_FITR', 'name' => 'Eid ul Fitr Bonus', 'status' => 'Active']
        ];

        // New version draft for 2027-01-01 omitting EID_FITR
        $newVersionPayloadFutureDate = [
            'effective_from' => '2027-01-01',
            'schemes' => [
                [
                    'code'             => 'PERFORMANCE_2027',
                    'name'             => 'Performance Bonus 2027',
                    'calculation_type' => 'Flat',
                    'value'            => 10000.0,
                    'salary_basis'     => 'Basic Salary',
                    'status'           => 'Active',
                    'min_service_days' => 180
                ]
            ]
        ];

        $newCodes = [];
        foreach ($newVersionPayloadFutureDate['schemes'] as $ns) {
            $newCodes[strtoupper(trim($ns['code']))] = true;
        }

        $errorMessage = null;
        foreach ($companyPriorSchemes as $ps) {
            $oldCode = strtoupper(trim($ps['code']));
            if (isset($lockedCodes[$oldCode]) && !isset($newCodes[$oldCode])) {
                $errorMessage = "Bonus scheme '{$oldCode}' cannot be deleted or have its code renamed because existing bonus records reference it. You may deactivate it by setting status to Inactive instead.";
                break;
            }
        }

        $this->assertNotNull($errorMessage, 'Future date new version must not drop historically locked schemes');

        // Deactivating the scheme (preserving code) is accepted
        $newVersionWithDeactivated = [
            'effective_from' => '2027-01-01',
            'schemes' => [
                [
                    'code'             => 'EID_FITR',
                    'name'             => 'Eid ul Fitr Bonus (Deprecated)',
                    'calculation_type' => 'Flat',
                    'value'            => 0.0,
                    'salary_basis'     => 'Basic Salary',
                    'status'           => 'Inactive', // Deactivated!
                    'min_service_days' => 90
                ],
                [
                    'code'             => 'PERFORMANCE_2027',
                    'name'             => 'Performance Bonus 2027',
                    'calculation_type' => 'Flat',
                    'value'            => 10000.0,
                    'salary_basis'     => 'Basic Salary',
                    'status'           => 'Active',
                    'min_service_days' => 180
                ]
            ]
        ];

        $deactCodes = [];
        foreach ($newVersionWithDeactivated['schemes'] as $ns) {
            $deactCodes[strtoupper(trim($ns['code']))] = true;
        }

        $deactErrorMessage = null;
        foreach ($companyPriorSchemes as $ps) {
            $oldCode = strtoupper(trim($ps['code']));
            if (isset($lockedCodes[$oldCode]) && !isset($deactCodes[$oldCode])) {
                $deactErrorMessage = "Error";
                break;
            }
        }

        $this->assertNull($deactErrorMessage, 'Deactivating a locked scheme in future version preserves code and is accepted');
    }

    /**
     * 22. Two festival schemes (EID_FITR, EID_ADHA) in the same month and year both create records
     * for the same employee without hash collision.
     */
    public function testTwoFestivalSchemesInSameMonthAndYearDoNotCollide()
    {
        $bonusService = new \App\Services\BonusService();
        $empId = 'EMP-1001';
        $month = 'July';
        $year  = 2026;

        $hashFitr = $bonusService->generateBonusHash($empId, 'EID_FITR', $month, $year);
        $hashAdha = $bonusService->generateBonusHash($empId, 'EID_ADHA', $month, $year);

        $this->assertNotEquals($hashFitr, $hashAdha, 'Two distinct bonus schemes in the same month and year must generate distinct hashes');
        $this->assertEquals(32, strlen($hashFitr));
        $this->assertEquals(32, strlen($hashAdha));
    }

    /**
     * 23. Re-running the same scheme + month + year generates identical hash and creates no duplicates
     */
    public function testRerunningSameSchemeMonthYearCreatesNoDuplicates()
    {
        $bonusService = new \App\Services\BonusService();
        $empId = 'EMP-1001';
        $scheme = 'EID_FITR';
        $month = 'July';
        $year  = 2026;

        $hashRun1 = $bonusService->generateBonusHash($empId, $scheme, $month, $year);
        $hashRun2 = $bonusService->generateBonusHash($empId, $scheme, $month, $year);

        $this->assertEquals($hashRun1, $hashRun2, 'Running the exact same scheme, month, year, and employee produces identical hash');

        // Emulate batch idempotency check against duplicate_check_hash
        $existingRecords = [
            $hashRun1 => ['id' => 'BNS-001', 'employee_id' => $empId, 'scheme_code' => $scheme]
        ];

        $isDuplicate = isset($existingRecords[$hashRun2]);
        $this->assertTrue($isDuplicate, 'Existing hash match must skip generation to prevent duplicate records');
    }

    /**
     * 24. Bonus page with no BONUS rule shows clear message and a disabled selector
     */
    public function testBonusPageWithNoBonusRuleShowsClearMessageAndDisabledSelector()
    {
        // When RuleResolver throws RuleNotConfiguredException for BONUS
        $bonusRuleError = null;
        $schemes = [];
        $activeSchemes = [];

        try {
            throw new \App\Services\Rules\RuleNotConfiguredException("No active rule configured for company 'comp-xyz', domain 'BONUS'");
        } catch (\App\Services\Rules\RuleNotConfiguredException $e) {
            $bonusRuleError = 'Bonus rule not configured. Set it up in Rules > BONUS';
            $schemes = [];
            $activeSchemes = [];
        }

        $this->assertEquals('Bonus rule not configured. Set it up in Rules > BONUS', $bonusRuleError);
        $this->assertEmpty($activeSchemes);

        // Verify view contract: when activeSchemes is empty, selector is disabled and shows explanatory text
        $selectorDisabled = empty($activeSchemes);
        $this->assertTrue($selectorDisabled, 'Scheme selector must be disabled when no active schemes exist');
    }

    /**
     * 25. Backfill migration runs twice with no duplicates, does not touch an existing BONUS rule,
     * creates Inactive schemes, and down() removes only its own rows.
     */
    public function testBackfillMigrationRunsTwiceWithNoDuplicatesDoesNotTouchExistingAndCreatesInactive()
    {
        $seedMarker = 'Migration 2026-10-07-000002: Seed initial BONUS rule for company with none';
        $creatorMarker = 'migration_20261007_000002';

        // Mock database state with Company A (has existing active rule) and Company B (has none)
        $dbRules = [
            'comp-a' => [
                'id'             => 'rd-preexisting01',
                'company_id'     => 'comp-a',
                'domain'         => 'BONUS',
                'status'         => 'Active',
                'change_reason'  => 'HR Manual setup',
                'created_by'     => 'user-admin',
                'schemes'        => [
                    ['code' => 'CUSTOM_PREEXISTING', 'status' => 'Active']
                ]
            ]
        ];

        $companies = ['comp-a', 'comp-b'];

        // FIRST RUN of backfill
        $createdFirstRun = [];
        foreach ($companies as $comp) {
            if (isset($dbRules[$comp])) {
                // Existing rule present: MUST NOT TOUCH!
                continue;
            }

            // Create Inactive schemes for company with none
            $seedSchemes = [
                ['code' => 'FESTIVAL', 'status' => 'Inactive'],
                ['code' => 'PERFORMANCE', 'status' => 'Inactive'],
            ];

            $newRule = [
                'id'            => 'rd-seeded-' . $comp,
                'company_id'    => $comp,
                'domain'        => 'BONUS',
                'status'        => 'Active',
                'change_reason' => $seedMarker,
                'created_by'    => $creatorMarker,
                'schemes'       => $seedSchemes,
            ];
            $dbRules[$comp] = $newRule;
            $createdFirstRun[] = $newRule;
        }

        $this->assertCount(1, $createdFirstRun, 'First run should seed only Company B');
        $this->assertEquals('Inactive', $dbRules['comp-b']['schemes'][0]['status'], 'Backfilled schemes must have Inactive status');
        $this->assertEquals('Active', $dbRules['comp-a']['schemes'][0]['status'], 'Existing company schemes must remain untouched');

        // SECOND RUN of backfill (Idempotency test)
        $createdSecondRun = [];
        foreach ($companies as $comp) {
            if (isset($dbRules[$comp])) {
                // Already exists: skipped
                continue;
            }
            $createdSecondRun[] = $comp;
        }

        $this->assertCount(0, $createdSecondRun, 'Second run must perform 0 inserts (strictly idempotent)');

        // DOWN() migration test
        $deletedRules = [];
        foreach ($dbRules as $comp => $rule) {
            if ($rule['change_reason'] === $seedMarker && $rule['created_by'] === $creatorMarker) {
                $deletedRules[] = $rule['id'];
                unset($dbRules[$comp]);
            }
        }

        $this->assertContains('rd-seeded-comp-b', $deletedRules, 'down() must remove only rows it created');
        $this->assertArrayHasKey('comp-a', $dbRules, 'down() must NEVER delete pre-existing or user-created rules');
    }

    /**
     * 26. Batch calculation with Selected Components, Flat, Percentage_Basic, Percentage_Gross,
     * proration, and min_service_days are all evaluated correctly.
     */
    public function testBatchCalculationsForSelectedComponentsFlatPercentageBasicGrossProrationAndMinServiceDays()
    {
        $basicSalary = 40000.0;
        $grossSalary = 70000.0;
        $components = [
            ['code' => 'BASIC', 'amount' => 40000.0],
            ['code' => 'HRA',   'amount' => 15000.0],
            ['code' => 'MED',   'amount' => 5000.0],
        ];

        // 1. Flat amount calculation
        $flatScheme = ['calculation_type' => 'Flat', 'value' => 12500.0, 'salary_basis' => 'Basic Salary'];
        $flatAmount = (float)$flatScheme['value'];
        $this->assertEquals(12500.0, $flatAmount);

        // 2. Percentage_Basic
        $pctBasicScheme = ['calculation_type' => 'Percentage_Basic', 'value' => 75.0, 'salary_basis' => 'Basic Salary'];
        $pctBasicAmount = round(($basicSalary * $pctBasicScheme['value']) / 100, 2);
        $this->assertEquals(30000.0, $pctBasicAmount);

        // 3. Percentage_Gross
        $pctGrossScheme = ['calculation_type' => 'Percentage_Gross', 'value' => 50.0, 'salary_basis' => 'Gross Salary'];
        $pctGrossAmount = round(($grossSalary * $pctGrossScheme['value']) / 100, 2);
        $this->assertEquals(35000.0, $pctGrossAmount);

        // 4. Selected Components (BASIC + HRA = 55,000)
        $selectedScheme = [
            'calculation_type'         => 'Percentage_Basic',
            'value'                    => 50.0,
            'salary_basis'             => 'Selected Components',
            'included_component_codes' => ['BASIC', 'HRA']
        ];
        $selectedBase = 0.0;
        foreach ($components as $c) {
            if (in_array($c['code'], $selectedScheme['included_component_codes'], true)) {
                $selectedBase += $c['amount'];
            }
        }
        $this->assertEquals(55000.0, $selectedBase);
        $selectedAmount = round(($selectedBase * $selectedScheme['value']) / 100, 2);
        $this->assertEquals(27500.0, $selectedAmount);

        // 5. Min service days check
        $schemeMinDays = 90;
        $tenureDaysEligible = 120;
        $tenureDaysIneligible = 60;
        $this->assertTrue($tenureDaysEligible >= $schemeMinDays);
        $this->assertFalse($tenureDaysIneligible >= $schemeMinDays, 'Employee under min_service_days must be skipped');

        // 6. Proration: 4 months tenure under 6-month threshold (min ratio 0.1)
        $tenureMonths = 4.0;
        $thresholdMonths = 6;
        $prorateMinRatio = 0.1;
        $ratio = min(1.0, max($prorateMinRatio, $tenureMonths / 12.0));
        $this->assertEquals(round(4.0 / 12.0, 4), round($ratio, 4));
        $proratedNet = round($pctBasicAmount * $ratio, 2);
        $this->assertEquals(round(30000.0 * (4.0 / 12.0), 2), $proratedNet);
    }

    /**
     * 27. Controller / Feature Test for BonusController::index() view data and resolution behavior:
     * (a) no BONUS rule
     * (b) a BONUS rule missing the 'schemes' key
     * (c) no PAYROLL_BASICS rule
     * (d) a valid rule with 1 Active + 1 Inactive scheme
     *
     * Asserts:
     * - HTTP 200 (view rendered without unhandled exception)
     * - Right messages in the view data
     * - Selector disabled in (a) and (b) (activeSchemes is empty)
     * - Only Active schemes in the dropdown in (d)
     * - Cards/schemes list show both Active and Inactive schemes in (d)
     */
    public function testBonusControllerIndexScenariosViewDataContract()
    {
        $db = Database::connect();

        // Ensure database tables exist for BonusController
        $bonusService = new BonusService();
        $bonusService->ensureTablesExist();

        // -------------------------------------------------------------
        // (a) Scenario: Company with NO BONUS rule
        // -------------------------------------------------------------
        $companyNoBonus = 'comp-test-nobonus-' . bin2hex(random_bytes(4));
        // Clean any existing rule
        $db->table('rule_definitions')->where('company_id', $companyNoBonus)->delete();

        // Setup session and user context
        $session = \Config\Services::session();
        $session->set([
            'user_id'    => 'usr-' . bin2hex(random_bytes(4)),
            'company_id' => $companyNoBonus,
            'role'       => 'Super Admin',
            'role_code'  => 'SUPER_ADMIN',
            'permissions'=> ['bonus.view'],
        ]);

        $controller = new BonusController();
        $controller->ensureInitialized();

        // Execute index()
        $viewOutput = $controller->index();
        $this->assertNotEmpty($viewOutput, 'Controller index() must return rendered view (HTTP 200 equivalent)');
        $this->assertIsString($viewOutput);

        // Verify message and view contract:
        $this->assertStringContainsString('Bonus rule not configured. Set it up in Rules &gt; BONUS', $viewOutput);
        $this->assertStringContainsString('No active bonus schemes available', $viewOutput);
        $this->assertStringContainsString('disabled', $viewOutput, 'Scheme selector must be disabled when no bonus rule');

        // -------------------------------------------------------------
        // (b) Scenario: BONUS rule present but missing 'schemes' key
        // -------------------------------------------------------------
        $companyMissingKey = 'comp-test-missingkey-' . bin2hex(random_bytes(4));
        $db->table('rule_definitions')->where('company_id', $companyMissingKey)->delete();

        // Insert BONUS rule with missing 'schemes' key (e.g. only other attributes or empty JSON object)
        $db->table('rule_definitions')->insert([
            'id'             => 'rd-' . bin2hex(random_bytes(8)),
            'company_id'     => $companyMissingKey,
            'domain'         => 'BONUS',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode(['unrelated_key' => true]),
            'schema_version' => 1,
            'change_reason'  => 'Test missing schemes key',
            'created_at'     => date('Y-m-d H:i:s'),
            'updated_at'     => date('Y-m-d H:i:s'),
        ]);

        $session->set('company_id', $companyMissingKey);
        RuleResolver::resetMemo();

        $controllerMissing = new BonusController();
        $controllerMissing->ensureInitialized();
        $viewOutputMissing = $controllerMissing->index();

        $this->assertIsString($viewOutputMissing);
        $this->assertStringContainsString('Bonus rule is incomplete (missing key: schemes). Fix it in Rules &gt; BONUS', $viewOutputMissing);
        $this->assertStringContainsString('No active bonus schemes available', $viewOutputMissing);

        // -------------------------------------------------------------
        // (c) Scenario: Company with NO PAYROLL_BASICS rule
        // -------------------------------------------------------------
        $companyNoBasics = 'comp-test-nobasics-' . bin2hex(random_bytes(4));
        $db->table('rule_definitions')->where('company_id', $companyNoBasics)->delete();

        // Give it a valid BONUS rule so only PAYROLL_BASICS is missing
        $db->table('rule_definitions')->insert([
            'id'             => 'rd-' . bin2hex(random_bytes(8)),
            'company_id'     => $companyNoBasics,
            'domain'         => 'BONUS',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'schemes' => [
                    [
                        'code'             => 'FEST_ACTIVE',
                        'name'             => 'Active Festival',
                        'calculation_type' => 'Flat',
                        'value'            => 10000.0,
                        'salary_basis'     => 'Basic Salary',
                        'status'           => 'Active',
                        'min_service_days' => 90,
                    ]
                ]
            ]),
            'schema_version' => 1,
            'change_reason'  => 'Test valid bonus without basics',
            'created_at'     => date('Y-m-d H:i:s'),
            'updated_at'     => date('Y-m-d H:i:s'),
        ]);

        $session->set('company_id', $companyNoBasics);
        RuleResolver::resetMemo();

        $controllerNoBasics = new BonusController();
        $controllerNoBasics->ensureInitialized();
        $viewOutputNoBasics = $controllerNoBasics->index();

        $this->assertIsString($viewOutputNoBasics);
        $this->assertStringContainsString('Payroll basics rule not configured. Currency cannot be determined.', $viewOutputNoBasics);
        $this->assertStringContainsString('Configure Currency', $viewOutputNoBasics);
        // Ensure no raw blank currency or missing-currency amount formatting:
        $this->assertStringContainsString('Currency missing', $viewOutputNoBasics);

        // -------------------------------------------------------------
        // (d) Scenario: Valid BONUS rule with 1 Active + 1 Inactive scheme and valid PAYROLL_BASICS
        // -------------------------------------------------------------
        $companyValid = 'comp-test-valid-' . bin2hex(random_bytes(4));
        $db->table('rule_definitions')->where('company_id', $companyValid)->delete();

        // Valid PAYROLL_BASICS
        $db->table('rule_definitions')->insert([
            'id'             => 'rd-' . bin2hex(random_bytes(8)),
            'company_id'     => $companyValid,
            'domain'         => 'PAYROLL_BASICS',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'currency_code' => 'USD',
                'pay_cycle'     => 'Monthly',
            ]),
            'schema_version' => 1,
            'change_reason'  => 'Test valid payroll basics',
            'created_at'     => date('Y-m-d H:i:s'),
            'updated_at'     => date('Y-m-d H:i:s'),
        ]);

        // Valid BONUS rule: 1 Active (EID_ACTIVE) + 1 Inactive (PERF_INACTIVE)
        $db->table('rule_definitions')->insert([
            'id'             => 'rd-' . bin2hex(random_bytes(8)),
            'company_id'     => $companyValid,
            'domain'         => 'BONUS',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'schemes' => [
                    [
                        'code'             => 'EID_ACTIVE',
                        'name'             => 'Eid Active Scheme',
                        'calculation_type' => 'Flat',
                        'value'            => 15000.0,
                        'salary_basis'     => 'Basic Salary',
                        'status'           => 'Active',
                        'min_service_days' => 90,
                    ],
                    [
                        'code'             => 'PERF_INACTIVE',
                        'name'             => 'Performance Inactive Scheme',
                        'calculation_type' => 'Percentage_Basic',
                        'value'            => 50.0,
                        'salary_basis'     => 'Basic Salary',
                        'status'           => 'Inactive',
                        'min_service_days' => 180,
                    ],
                ]
            ]),
            'schema_version' => 1,
            'change_reason'  => 'Test active and inactive schemes',
            'created_at'     => date('Y-m-d H:i:s'),
            'updated_at'     => date('Y-m-d H:i:s'),
        ]);

        $session->set('company_id', $companyValid);
        RuleResolver::resetMemo();

        $controllerValid = new BonusController();
        $controllerValid->ensureInitialized();
        $viewOutputValid = $controllerValid->index();

        $this->assertIsString($viewOutputValid);
        // Header cards must display BOTH schemes
        $this->assertStringContainsString('EID_ACTIVE', $viewOutputValid);
        $this->assertStringContainsString('Eid Active Scheme', $viewOutputValid);
        $this->assertStringContainsString('PERF_INACTIVE', $viewOutputValid);
        $this->assertStringContainsString('Performance Inactive Scheme', $viewOutputValid);

        // Status badges for both
        $this->assertStringContainsString('Active', $viewOutputValid);
        $this->assertStringContainsString('Inactive', $viewOutputValid);

        // Currency is rendered properly with currency code 'USD'
        $this->assertStringContainsString('USD 15,000.00', $viewOutputValid);

        // The batch dropdown selector MUST list the Active scheme
        $this->assertStringContainsString('value="EID_ACTIVE"', $viewOutputValid);

        // The batch dropdown selector MUST NOT offer the Inactive scheme as an option in the select
        // In bonuses.php: dropdown loops over $activeSchemes
        $this->assertStringNotContainsString('value="PERF_INACTIVE"', $viewOutputValid);

        // Clean up test rows
        $db->table('rule_definitions')->whereIn('company_id', [
            $companyNoBonus, $companyMissingKey, $companyNoBasics, $companyValid
        ])->delete();
    }

    /**
     * 28. Real Test Database test through BonusService::generateBonusBatch:
     * - Two schemes EID_FITR and EID_ADHA, same employee, same month and year => 2 bonus_records, no collision
     * - Run the same scheme/month/year twice => still 1 record, second run reports skipped
     */
    public function testBonusBatchTwoSchemesSameMonthYearAndIdempotentSkipInDb()
    {
        $db = Database::connect();
        $bonusService = new BonusService();
        $bonusService->ensureTablesExist();

        $companyId = 'comp-batch-test-' . bin2hex(random_bytes(4));
        $empId = 'emp-batch-test-' . bin2hex(random_bytes(4));

        // Setup rules in DB for the company: PAYROLL_BASICS with currency
        $db->table('rule_definitions')->insert([
            'id'             => 'rd-' . bin2hex(random_bytes(8)),
            'company_id'     => $companyId,
            'domain'         => 'PAYROLL_BASICS',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'currency_code' => 'USD',
                'pay_cycle'     => 'Monthly',
            ]),
            'schema_version' => 1,
            'change_reason'  => 'Batch test PAYROLL_BASICS',
            'created_at'     => date('Y-m-d H:i:s'),
            'updated_at'     => date('Y-m-d H:i:s'),
        ]);

        // BONUS rule with BOTH EID_FITR and EID_ADHA Active
        $db->table('rule_definitions')->insert([
            'id'             => 'rd-' . bin2hex(random_bytes(8)),
            'company_id'     => $companyId,
            'domain'         => 'BONUS',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'schemes' => [
                    [
                        'code'                       => 'EID_FITR',
                        'name'                       => 'Eid ul Fitr Bonus',
                        'calculation_type'           => 'Flat',
                        'value'                      => 20000.0,
                        'salary_basis'               => 'Basic Salary',
                        'min_service_days'           => 30,
                        'prorate_under_service_days' => false,
                        'prorate_threshold_months'   => 6,
                        'prorate_min_ratio'          => 0.1,
                        'status'                     => 'Active',
                    ],
                    [
                        'code'                       => 'EID_ADHA',
                        'name'                       => 'Eid ul Adha Bonus',
                        'calculation_type'           => 'Flat',
                        'value'                      => 25000.0,
                        'salary_basis'               => 'Basic Salary',
                        'min_service_days'           => 30,
                        'prorate_under_service_days' => false,
                        'prorate_threshold_months'   => 6,
                        'prorate_min_ratio'          => 0.1,
                        'status'                     => 'Active',
                    ],
                ]
            ]),
            'schema_version' => 1,
            'change_reason'  => 'Batch test BONUS',
            'created_at'     => date('Y-m-d H:i:s'),
            'updated_at'     => date('Y-m-d H:i:s'),
        ]);

        // Insert test employee into database
        $db->table('employees')->insert([
            'id'           => $empId,
            'company_id'   => $companyId,
            'first_name'   => 'Rahim',
            'last_name'    => 'Ahmed',
            'email'        => 'rahim.' . bin2hex(random_bytes(3)) . '@example.com',
            'status'       => 'Active',
            'joining_date' => '2024-01-01', // well beyond 30 days
            'created_at'   => date('Y-m-d H:i:s'),
        ]);

        // Ensure active salary exists for employee
        if ($db->tableExists('employee_salaries')) {
            $db->table('employee_salaries')->insert([
                'id'             => 'sal-' . bin2hex(random_bytes(6)),
                'employee_id'    => $empId,
                'company_id'     => $companyId,
                'basic_salary'   => 30000.0,
                'gross_salary'   => 50000.0,
                'effective_date' => '2024-01-01',
                'status'         => 'Active',
                'created_at'     => date('Y-m-d H:i:s'),
            ]);
        }

        RuleResolver::resetMemo();
        $currentUser = ['id' => 'usr-1', 'company_id' => $companyId];

        // 1. Run batch for EID_FITR, Month: July, Year: 2026
        $resFitr = $bonusService->generateBonusBatch([
            'company_id' => $companyId,
            'scheme_id'  => 'EID_FITR',
            'title'      => 'Eid-ul-Fitr Bonus',
            'month'      => 'July',
            'year'       => 2026,
            'target'     => 'individual',
            'employee_id'=> $empId,
        ], $currentUser);

        $this->assertTrue($resFitr['success'], 'First batch run for EID_FITR must succeed');
        $this->assertEquals(1, $resFitr['data']['created'], 'Should create 1 record for EID_FITR');

        // 2. Run batch for EID_ADHA, Same Month (July), Same Year (2026), Same Employee
        $resAdha = $bonusService->generateBonusBatch([
            'company_id' => $companyId,
            'scheme_id'  => 'EID_ADHA',
            'title'      => 'Eid-ul-Adha Bonus',
            'month'      => 'July',
            'year'       => 2026,
            'target'     => 'individual',
            'employee_id'=> $empId,
        ], $currentUser);

        $this->assertTrue($resAdha['success'], 'Second batch run for EID_ADHA must succeed without colliding');
        $this->assertEquals(1, $resAdha['data']['created'], 'Should create 1 record for EID_ADHA');

        // Assert DB has EXACTLY 2 records for this employee in July 2026
        $records = $db->table('bonus_records')
            ->where('employee_id', $empId)
            ->where('bonus_month', 'July')
            ->where('year', 2026)
            ->get()->getResultArray();

        $this->assertCount(2, $records, 'Both EID_FITR and EID_ADHA records must exist side-by-side without hash collision');
        $schemesRecorded = array_column($records, 'scheme_code');
        $this->assertContains('EID_FITR', $schemesRecorded);
        $this->assertContains('EID_ADHA', $schemesRecorded);

        // 3. Re-run EID_FITR batch for July 2026: MUST NOT duplicate, must report skipped
        $resFitrRetry = $bonusService->generateBonusBatch([
            'company_id' => $companyId,
            'scheme_id'  => 'EID_FITR',
            'title'      => 'Eid-ul-Fitr Bonus Repeat',
            'month'      => 'July',
            'year'       => 2026,
            'target'     => 'individual',
            'employee_id'=> $empId,
        ], $currentUser);

        $this->assertTrue($resFitrRetry['success'] || $resFitrRetry['data']['skipped'] > 0);
        $this->assertEquals(0, $resFitrRetry['data']['created'], 'Re-run must create 0 new records');
        $this->assertEquals(1, $resFitrRetry['data']['skipped'], 'Re-run must report 1 skipped record');
        $this->assertStringContainsString('already generated', $resFitrRetry['message']);

        // Verify still exactly 2 records total in DB
        $recordsAfter = $db->table('bonus_records')
            ->where('employee_id', $empId)
            ->where('bonus_month', 'July')
            ->where('year', 2026)
            ->get()->getResultArray();
        $this->assertCount(2, $recordsAfter, 'Total records must remain 2 after re-run');

        // Clean up
        $db->table('bonus_records')->where('employee_id', $empId)->delete();
        $db->table('employees')->where('id', $empId)->delete();
        if ($db->tableExists('employee_salaries')) {
            $db->table('employee_salaries')->where('employee_id', $empId)->delete();
        }
        $db->table('rule_definitions')->where('company_id', $companyId)->delete();
    }

    /**
     * 29. Test generateBonusBatch refuses to run when PAYROLL_BASICS currency is missing
     */
    public function testGenerateBonusBatchRefusesToRunWhenPayrollBasicsCurrencyMissing()
    {
        $db = Database::connect();
        $bonusService = new BonusService();
        $bonusService->ensureTablesExist();

        $companyId = 'comp-nocurrency-' . bin2hex(random_bytes(4));

        // Company has BONUS rule but NO PAYROLL_BASICS rule
        $db->table('rule_definitions')->insert([
            'id'             => 'rd-' . bin2hex(random_bytes(8)),
            'company_id'     => $companyId,
            'domain'         => 'BONUS',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'schemes' => [
                    [
                        'code'             => 'TEST_SCHEME',
                        'name'             => 'Test Scheme',
                        'calculation_type' => 'Flat',
                        'value'            => 1000.0,
                        'salary_basis'     => 'Basic Salary',
                        'min_service_days' => 30,
                        'status'           => 'Active',
                    ]
                ]
            ]),
            'schema_version' => 1,
            'change_reason'  => 'Missing currency test',
            'created_at'     => date('Y-m-d H:i:s'),
            'updated_at'     => date('Y-m-d H:i:s'),
        ]);

        RuleResolver::resetMemo();
        $currentUser = ['id' => 'usr-1', 'company_id' => $companyId];

        $res = $bonusService->generateBonusBatch([
            'company_id' => $companyId,
            'scheme_id'  => 'TEST_SCHEME',
            'title'      => 'Test',
            'month'      => 'July',
            'year'       => 2026,
            'target'     => 'all',
        ], $currentUser);

        $this->assertFalse($res['success'], 'generateBonusBatch must fail when PAYROLL_BASICS rule is missing');
        $this->assertStringContainsString('Payroll basics rule not configured. Currency cannot be determined.', $res['message']);

        // Clean up
        $db->table('rule_definitions')->where('company_id', $companyId)->delete();
    }

    /**
     * 31. Company-scoped bonus hash prevents cross-tenant collisions and guarantees idempotency
     */
    public function testCompanyScopedBonusHashDeduplication()
    {
        $bonusService = new \App\Services\BonusService();
        $empId = 'EMP-1001';
        $scheme = 'FESTIVAL';
        $month = 'July';
        $year = 2026;

        $hashCompA = $bonusService->generateBonusHash($empId, $scheme, $month, $year, 'comp-alpha');
        $hashCompB = $bonusService->generateBonusHash($empId, $scheme, $month, $year, 'comp-beta');
        $hashRerun = $bonusService->generateBonusHash($empId, $scheme, $month, $year, 'comp-alpha');

        $this->assertNotEmpty($hashCompA);
        $this->assertNotEmpty($hashCompB);
        $this->assertNotEquals($hashCompA, $hashCompB, 'Different companies must generate distinct hashes even for same emp, scheme, month and year');
        $this->assertEquals($hashCompA, $hashRerun, 'Rerunning for the same tenant must generate identical hash for idempotency');
    }

    /**
     * 32. Service tenure cutoff boundary behavior (exact cutoff, day before, day after)
     */
    public function testTenureBoundaryCalculationCutoff()
    {
        $minServiceDays = 90;
        $asOfDate = '2026-07-01';
        $bonusTimestamp = strtotime($asOfDate);

        // Day before cutoff (89 days tenure) -> Ineligible
        $joinDate89 = date('Y-m-d', $bonusTimestamp - (89 * 86400));
        $tenure89 = (int)floor(($bonusTimestamp - strtotime($joinDate89)) / 86400);
        $this->assertEquals(89, $tenure89);
        $this->assertLessThan($minServiceDays, $tenure89, '89 days tenure must be below 90-day requirement');

        // Exactly on cutoff (90 days tenure) -> Eligible
        $joinDate90 = date('Y-m-d', $bonusTimestamp - (90 * 86400));
        $tenure90 = (int)floor(($bonusTimestamp - strtotime($joinDate90)) / 86400);
        $this->assertEquals(90, $tenure90);
        $this->assertGreaterThanOrEqual($minServiceDays, $tenure90, '90 days tenure must meet 90-day cutoff exactly');

        // Day after cutoff (91 days tenure) -> Eligible
        $joinDate91 = date('Y-m-d', $bonusTimestamp - (91 * 86400));
        $tenure91 = (int)floor(($bonusTimestamp - strtotime($joinDate91)) / 86400);
        $this->assertEquals(91, $tenure91);
        $this->assertGreaterThanOrEqual($minServiceDays, $tenure91, '91 days tenure must exceed 90-day cutoff');
    }

    /**
     * 33. Proration calculation matches policy threshold months and minimum ratio
     */
    public function testProrationCalculationMatchesThresholdAndMinRatio()
    {
        $thresholdMonths = 6;
        $minRatio = 0.20;

        // 3 months tenure out of 6 months threshold: 3/6 = 0.50
        $tenureMonths3 = 3.0;
        $ratio3 = min(1.0, max($minRatio, $tenureMonths3 / (float)$thresholdMonths));
        $this->assertEquals(0.50, $ratio3);

        // 1 month tenure (1/6 = 0.1667) capped below min ratio -> should equal minRatio (0.20)
        $tenureMonths1 = 1.0;
        $ratio1 = min(1.0, max($minRatio, $tenureMonths1 / (float)$thresholdMonths));
        $this->assertEquals(0.20, $ratio1);

        // 6 months tenure -> exactly 1.0
        $tenureMonths6 = 6.0;
        $ratio6 = min(1.0, max($minRatio, $tenureMonths6 / (float)$thresholdMonths));
        $this->assertEquals(1.0, $ratio6);

        // 9 months tenure -> capped at 1.0
        $tenureMonths9 = 9.0;
        $ratio9 = min(1.0, max($minRatio, $tenureMonths9 / (float)$thresholdMonths));
        $this->assertEquals(1.0, $ratio9);
    }

    /**
     * 34. Probation exclusion rule: probationer excluded when include_probation is false
     */
    public function testProbationExclusionRuleLogic()
    {
        $schemeExcludeProbation = [
            'code'              => 'FESTIVAL',
            'name'              => 'Festival Bonus',
            'include_probation' => false,
        ];
        $schemeIncludeProbation = [
            'code'              => 'FESTIVAL_ALL',
            'name'              => 'Festival Bonus All Staff',
            'include_probation' => true,
        ];

        $employeeOnProbation = [
            'id'               => 'EMP-PROB-1',
            'status'           => 'probation',
            'probation_status' => 'Active',
        ];
        $employeeConfirmed = [
            'id'                => 'EMP-CONF-1',
            'status'            => 'active',
            'probation_status'  => 'Confirmed',
            'confirmation_date' => '2025-01-01',
        ];

        // Helper check matching BonusService logic
        $checkEligible = function ($scheme, $emp, $asOfDate = '2026-10-15') {
            $includeProbation = !empty($scheme['include_probation']);
            if (!$includeProbation) {
                $status = strtolower(trim((string)($emp['status'] ?? '')));
                $probStatus = trim((string)($emp['probation_status'] ?? ''));
                $bonusTimestamp = strtotime($asOfDate);
                $confirmedDate = $emp['confirmation_date'] ?? $emp['probation_confirmed_date'] ?? null;
                $isConfirmed = (!empty($confirmedDate) && strtotime($confirmedDate) <= $bonusTimestamp)
                    || in_array(strtolower($probStatus), ['completed', 'confirmed', 'not applicable', 'cancelled'], true)
                    || !empty($emp['probation_early_confirmed']);

                $isProbation = false;
                if (!$isConfirmed) {
                    if (in_array($status, ['probation', 'on probation', 'on_probation'], true)) {
                        $isProbation = true;
                    } elseif (in_array(strtolower($probStatus), ['on probation', 'extended'], true)) {
                        $isProbation = true;
                    } elseif (!empty($emp['probation_end_date']) && strtotime($emp['probation_end_date']) >= $bonusTimestamp) {
                        $isProbation = true;
                    }
                }

                if ($isProbation) {
                    return false; // Ineligible
                }
            }
            return true; // Eligible
        };

        $employeeActiveDefault = [
            'id'               => 'EMP-ACT-1',
            'status'           => 'active',
            'probation_status' => 'Active',
        ];

        $this->assertFalse($checkEligible($schemeExcludeProbation, $employeeOnProbation), 'Probationer must be excluded when include_probation is false');
        $this->assertTrue($checkEligible($schemeIncludeProbation, $employeeOnProbation), 'Probationer must be included when include_probation is true');
        $this->assertTrue($checkEligible($schemeExcludeProbation, $employeeConfirmed), 'Confirmed staff must be included');
        $this->assertTrue($checkEligible($schemeExcludeProbation, $employeeActiveDefault), 'Active employee with default probation_status must not be treated as on probation');
    }

    /**
     * 35. Adjustment history preservation and audit structure
     */
    public function testAdjustmentHistoryPreservation()
    {
        $initialAmount = 10000.0;
        $adjustedAmount1 = 12500.0;
        $adjustedAmount2 = 12000.0;

        $history = [];

        // First adjustment
        $diff1 = round($adjustedAmount1 - $initialAmount, 2);
        $history[] = [
            'original_amount' => $initialAmount,
            'adjusted_amount' => $adjustedAmount1,
            'difference'      => $diff1,
            'reason'          => 'Performance incentive addition',
            'adjusted_by'     => 'HR Manager',
            'adjusted_at'     => '2026-07-05 10:00:00',
        ];

        // Second adjustment
        $diff2 = round($adjustedAmount2 - $adjustedAmount1, 2);
        $history[] = [
            'original_amount' => $adjustedAmount1,
            'adjusted_amount' => $adjustedAmount2,
            'difference'      => $diff2,
            'reason'          => 'Tax correction adjustment',
            'adjusted_by'     => 'Finance Lead',
            'adjusted_at'     => '2026-07-06 14:00:00',
        ];

        $this->assertCount(2, $history);
        $this->assertEquals(2500.0, $history[0]['difference']);
        $this->assertEquals(-500.0, $history[1]['difference']);
        $this->assertEquals(10000.0, $history[0]['original_amount']);
        $this->assertEquals(12000.0, $history[1]['adjusted_amount']);
    }

    /**
     * 36. Company-scoped duplicate check hash generation ensures multi-tenant isolation
     */
    public function testCompanyScopedDuplicateCheckHash()
    {
        $bonusService = new \App\Services\BonusService();
        $empId = 'emp-001';
        $scheme = 'EID_FITR';
        $month = 'July';
        $year = 2026;

        $hashTenantA = $bonusService->generateBonusHash($empId, $scheme, $month, $year, 'comp-tenant-a');
        $hashTenantB = $bonusService->generateBonusHash($empId, $scheme, $month, $year, 'comp-tenant-b');

        $this->assertNotEmpty($hashTenantA);
        $this->assertNotEmpty($hashTenantB);
        $this->assertNotEquals($hashTenantA, $hashTenantB, 'Hashes for different company tenants must be isolated and distinct');

        // Same tenant returns identical hash
        $hashTenantA2 = $bonusService->generateBonusHash($empId, $scheme, $month, $year, 'comp-tenant-a');
        $this->assertEquals($hashTenantA, $hashTenantA2, 'Same tenant and employee must produce deterministic hash');
    }

    /**
     * 37. Status lifecycle guards reject invalid transitions
     */
    public function testStatusLifecycleTransitionGuards()
    {
        $canApprove = function(array $record): array {
            if (!empty($record['is_settled_in_payroll']) || in_array($record['status'], ['Settled', 'Paid'], true)) {
                return ['allowed' => false, 'error' => 'settled_or_paid'];
            }
            if ($record['status'] === 'Approved') {
                return ['allowed' => false, 'error' => 'already_approved'];
            }
            if ($record['status'] === 'Rejected') {
                return ['allowed' => false, 'error' => 'cannot_approve_rejected'];
            }
            if ($record['status'] !== 'Pending') {
                return ['allowed' => false, 'error' => 'not_pending'];
            }
            return ['allowed' => true];
        };

        $this->assertTrue($canApprove(['status' => 'Pending', 'is_settled_in_payroll' => 0])['allowed']);
        $this->assertFalse($canApprove(['status' => 'Approved', 'is_settled_in_payroll' => 0])['allowed']);
        $this->assertFalse($canApprove(['status' => 'Rejected', 'is_settled_in_payroll' => 0])['allowed']);
        $this->assertFalse($canApprove(['status' => 'Settled', 'is_settled_in_payroll' => 1])['allowed']);
        $this->assertFalse($canApprove(['status' => 'Paid', 'is_settled_in_payroll' => 1])['allowed']);
    }

    /**
     * 38. Adjustment validation enforces non-negative amount and mandatory justification reason
     */
    public function testAdjustmentValidationRules()
    {
        $validateAdjustment = function($amount, $reason): array {
            if (!is_numeric($amount) || (float)$amount < 0) {
                return ['valid' => false, 'error' => 'invalid_amount'];
            }
            if (empty(trim((string)$reason))) {
                return ['valid' => false, 'error' => 'mandatory_reason_missing'];
            }
            return ['valid' => true, 'amount' => round((float)$amount, 2), 'reason' => trim((string)$reason)];
        };

        $this->assertFalse($validateAdjustment(-500, 'Correction')['valid']);
        $this->assertFalse($validateAdjustment('abc', 'Correction')['valid']);
        $this->assertFalse($validateAdjustment(1500, '')['valid']);
        $this->assertFalse($validateAdjustment(1500, '   ')['valid']);

        $valid = $validateAdjustment(2500.50, 'Annual performance merit bump');
        $this->assertTrue($valid['valid']);
        $this->assertEquals(2500.50, $valid['amount']);
        $this->assertEquals('Annual performance merit bump', $valid['reason']);
    }

    /**
     * 39. Soft deletion retires duplicate check hash and protects audit trail
     */
    public function testSoftDeleteRetiresHashForAuditTrail()
    {
        $originalHash = 'e10adc3949ba59abbe56e057f20f883e';
        $now = date('Y-m-d H:i:s');
        $uniqueSuffix = '-del-' . time() . '-abcdef';
        $retiredHash = $originalHash . $uniqueSuffix;

        $this->assertNotEquals($originalHash, $retiredHash);
        $this->assertStringStartsWith($originalHash, $retiredHash);
        $this->assertStringContainsString('-del-', $retiredHash);
    }

    /**
     * 40. Payroll bonus settlement and un-settlement lifecycle
     */
    public function testPayrollBonusSettlementLifecycle()
    {
        $record = [
            'id' => 'BNS-001',
            'status' => 'Approved',
            'is_settled_in_payroll' => 0,
            'payroll_id' => null,
        ];

        // Settle in payroll batch
        $payrollId = 'PAY-2026-07-001';
        $settledRecord = array_merge($record, [
            'status' => 'Settled',
            'is_settled_in_payroll' => 1,
            'payroll_id' => $payrollId,
        ]);

        $this->assertEquals('Settled', $settledRecord['status']);
        $this->assertEquals(1, $settledRecord['is_settled_in_payroll']);
        $this->assertEquals($payrollId, $settledRecord['payroll_id']);

        // Unsettle / Reopen payroll batch back to Draft
        $revertedRecord = array_merge($settledRecord, [
            'status' => 'Approved',
            'is_settled_in_payroll' => 0,
            'payroll_id' => null,
        ]);

        $this->assertEquals('Approved', $revertedRecord['status']);
        $this->assertEquals(0, $revertedRecord['is_settled_in_payroll']);
        $this->assertNull($revertedRecord['payroll_id']);
    }

    /**
     * 41. Batch generation cannot bypass approval workflow: client-supplied Approved status is ignored
     */
    public function testBatchGenerationCannotBypassApprovalWorkflow()
    {
        // Simulate batch generation record creation parameters where an attacker or client sends status = 'Approved'
        $params = [
            'status' => 'Approved',
            'month'  => 'July',
            'year'   => 2026
        ];

        // Ensure service always forces Pending and null approver details
        $initialStatus = 'Pending';
        $approvedBy = null;
        $approvedAt = null;

        $record = [
            'id'          => 'BNS-TEST-001',
            'status'      => $initialStatus,
            'approved_by' => $approvedBy,
            'approved_at' => $approvedAt,
        ];

        $this->assertEquals('Pending', $record['status'], 'Batch-generated bonus must always be created in Pending status');
        $this->assertNull($record['approved_by'], 'Approved by must remain null upon generation');
        $this->assertNull($record['approved_at'], 'Approved at must remain null upon generation');
    }

    /**
     * 42. Segregation of duties prevents self-approval and self-rejection
     */
    public function testApprovalSegregationOfDuties()
    {
        $bonusRecord = [
            'id'          => 'BNS-001',
            'employee_id' => 'emp-101',
            'status'      => 'Pending'
        ];

        $validateApprover = function(array $record, array $currentUser): array {
            if (!empty($currentUser['employee_id']) && (string)$currentUser['employee_id'] === (string)$record['employee_id']) {
                return ['allowed' => false, 'code' => 403, 'message' => 'Segregation of Duties Violation: You cannot approve your own bonus allocation.'];
            }
            return ['allowed' => true, 'code' => 200];
        };

        // Self-approval attempt
        $selfUser = ['id' => 'usr-1', 'employee_id' => 'emp-101', 'name' => 'Self User'];
        $selfRes = $validateApprover($bonusRecord, $selfUser);
        $this->assertFalse($selfRes['allowed']);
        $this->assertEquals(403, $selfRes['code']);
        $this->assertStringContainsString('Segregation of Duties Violation', $selfRes['message']);

        // Different user approval
        $otherUser = ['id' => 'usr-2', 'employee_id' => 'emp-999', 'name' => 'HR Approver'];
        $otherRes = $validateApprover($bonusRecord, $otherUser);
        $this->assertTrue($otherRes['allowed']);
        $this->assertEquals(200, $otherRes['code']);
    }

    /**
     * 43. Approval atomic state guards and conflict handling
     */
    public function testApprovalAtomicStateGuardsAndConflictHandling()
    {
        $validateTransition = function(array $record, int $affectedRows): array {
            if (!empty($record['is_settled_in_payroll']) || in_array($record['status'], ['Settled', 'Paid'], true)) {
                return ['allowed' => false, 'code' => 409, 'message' => 'Settled in payroll'];
            }
            if ($record['status'] === 'Approved') {
                return ['allowed' => false, 'code' => 409, 'message' => 'Already approved'];
            }
            if ($record['status'] === 'Rejected') {
                return ['allowed' => false, 'code' => 409, 'message' => 'Rejected cannot be directly approved'];
            }
            if ($record['status'] !== 'Pending') {
                return ['allowed' => false, 'code' => 409, 'message' => 'Only pending records can be approved'];
            }
            if ($affectedRows !== 1) {
                return ['allowed' => false, 'code' => 409, 'message' => 'Conflict (409): Concurrent update detected'];
            }
            return ['allowed' => true, 'code' => 200];
        };

        // Normal pending approval with 1 affected row
        $res1 = $validateTransition(['status' => 'Pending', 'is_settled_in_payroll' => 0], 1);
        $this->assertTrue($res1['allowed']);

        // Concurrent collision (affected rows = 0 because another request approved first)
        $res2 = $validateTransition(['status' => 'Pending', 'is_settled_in_payroll' => 0], 0);
        $this->assertFalse($res2['allowed']);
        $this->assertEquals(409, $res2['code']);
        $this->assertStringContainsString('Concurrent update', $res2['message']);

        // Rejected record cannot be approved
        $res3 = $validateTransition(['status' => 'Rejected', 'is_settled_in_payroll' => 0], 1);
        $this->assertFalse($res3['allowed']);
        $this->assertEquals(409, $res3['code']);

        // Settled record cannot be approved
        $res4 = $validateTransition(['status' => 'Settled', 'is_settled_in_payroll' => 1], 1);
        $this->assertFalse($res4['allowed']);
        $this->assertEquals(409, $res4['code']);
    }

    /**
     * 44. Rejection atomic state guards and mandatory reason
     */
    public function testRejectionAtomicStateGuardsAndMandatoryReason()
    {
        $validateRejection = function(string $reason, array $record, int $affectedRows): array {
            $r = trim($reason);
            if ($r === '') {
                return ['allowed' => false, 'code' => 422, 'message' => 'Rejection reason is mandatory'];
            }
            if (!empty($record['is_settled_in_payroll']) || in_array($record['status'], ['Settled', 'Paid'], true)) {
                return ['allowed' => false, 'code' => 409, 'message' => 'Settled records cannot be rejected'];
            }
            if ($record['status'] !== 'Pending') {
                return ['allowed' => false, 'code' => 409, 'message' => 'Only pending records can be rejected'];
            }
            if ($affectedRows !== 1) {
                return ['allowed' => false, 'code' => 409, 'message' => 'Conflict: Concurrent modification'];
            }
            return ['allowed' => true, 'code' => 200];
        };

        // Empty reason rejected
        $this->assertEquals(422, $validateRejection('', ['status' => 'Pending'], 1)['code']);
        $this->assertEquals(422, $validateRejection('   ', ['status' => 'Pending'], 1)['code']);

        // Valid rejection
        $valid = $validateRejection('Performance criteria unmet', ['status' => 'Pending', 'is_settled_in_payroll' => 0], 1);
        $this->assertTrue($valid['allowed']);

        // Approved record cannot be rejected directly
        $badStatus = $validateRejection('Reason', ['status' => 'Approved', 'is_settled_in_payroll' => 0], 1);
        $this->assertFalse($badStatus['allowed']);
        $this->assertEquals(409, $badStatus['code']);
    }

    /**
     * 45. Complete adjustment state policy and re-approval enforcement
     */
    public function testAdjustmentCompleteStatePolicyAndReapproval()
    {
        $executeAdjustment = function(array $record, float $newAmount, string $reason, int $affectedRows): array {
            if ($newAmount < 0) {
                return ['allowed' => false, 'code' => 422, 'message' => 'Amount must be non-negative'];
            }
            if (empty(trim($reason))) {
                return ['allowed' => false, 'code' => 422, 'message' => 'Reason mandatory'];
            }
            if (!empty($record['is_settled_in_payroll']) || in_array($record['status'], ['Settled', 'Paid'], true)) {
                return ['allowed' => false, 'code' => 409, 'message' => 'Settled records cannot be adjusted'];
            }
            if ($record['status'] === 'Rejected') {
                return ['allowed' => false, 'code' => 409, 'message' => 'Rejected records cannot be adjusted'];
            }
            if (!in_array($record['status'], ['Pending', 'Approved'], true)) {
                return ['allowed' => false, 'code' => 409, 'message' => 'Invalid status for adjustment'];
            }
            if ($affectedRows !== 1) {
                return ['allowed' => false, 'code' => 409, 'message' => 'Conflict: record modified concurrently'];
            }

            $priorStatus = $record['status'];
            $reapprovalRequired = ($priorStatus === 'Approved');

            return [
                'allowed'             => true,
                'code'                => 200,
                'new_amount'          => round($newAmount, 2),
                'new_status'          => $reapprovalRequired ? 'Pending' : $priorStatus,
                'reapproval_required' => $reapprovalRequired,
                'approved_by'         => $reapprovalRequired ? null : ($record['approved_by'] ?? null),
                'approved_at'         => $reapprovalRequired ? null : ($record['approved_at'] ?? null),
            ];
        };

        // 1. Adjusting Pending record stays Pending
        $pendingRecord = ['status' => 'Pending', 'amount' => 5000, 'approved_by' => null, 'approved_at' => null];
        $adj1 = $executeAdjustment($pendingRecord, 5500, 'Tenure bump', 1);
        $this->assertTrue($adj1['allowed']);
        $this->assertEquals('Pending', $adj1['new_status']);
        $this->assertFalse($adj1['reapproval_required']);

        // 2. Adjusting Approved record invalidates approval, transitions back to Pending, resets approver
        $approvedRecord = ['status' => 'Approved', 'amount' => 5000, 'approved_by' => 'Manager Dave', 'approved_at' => '2026-07-01 10:00:00'];
        $adj2 = $executeAdjustment($approvedRecord, 6000, 'Executive correction', 1);
        $this->assertTrue($adj2['allowed']);
        $this->assertEquals('Pending', $adj2['new_status'], 'Approved record must revert to Pending upon financial adjustment');
        $this->assertTrue($adj2['reapproval_required'], 'Re-approval must be explicitly required');
        $this->assertNull($adj2['approved_by'], 'Approved by must be cleared');
        $this->assertNull($adj2['approved_at'], 'Approved at must be cleared');

        // 3. Adjusting Settled record is strictly blocked
        $settledRecord = ['status' => 'Settled', 'amount' => 5000, 'is_settled_in_payroll' => 1];
        $adj3 = $executeAdjustment($settledRecord, 6000, 'Adjustment attempt', 1);
        $this->assertFalse($adj3['allowed']);
        $this->assertEquals(409, $adj3['code']);

        // 4. Adjusting Rejected record is blocked
        $rejectedRecord = ['status' => 'Rejected', 'amount' => 5000];
        $adj4 = $executeAdjustment($rejectedRecord, 6000, 'Adjustment attempt', 1);
        $this->assertFalse($adj4['allowed']);
        $this->assertEquals(409, $adj4['code']);
    }

    /**
     * 46. Soft deletion retires hash and frees business key for regeneration
     */
    public function testSoftDeleteRetiresHashForRegenerationPolicy()
    {
        $bonusService = new \App\Services\BonusService();
        $originalHash = $bonusService->generateBonusHash('emp-101', 'FESTIVAL', 'July', 2026, 'comp-test');

        // Simulate soft deletion retirement
        $retiredHash = $originalHash . '-retired-BNS-101-' . time() . '-a1b2c3';

        $this->assertNotEquals($originalHash, $retiredHash);
        $this->assertStringStartsWith($originalHash, $retiredHash);
        $this->assertStringContainsString('-retired-', $retiredHash);

        // Subsequent regeneration produces the clean original hash without colliding with the retired hash
        $regeneratedHash = $bonusService->generateBonusHash('emp-101', 'FESTIVAL', 'July', 2026, 'comp-test');
        $this->assertEquals($originalHash, $regeneratedHash);
        $this->assertNotEquals($retiredHash, $regeneratedHash);
    }

    /**
     * 47. No prohibited business-rule fallbacks: missing scheme name or unauthenticated creator rejects cleanly
     */
    public function testNoIllegalRuleFallbacksInBonusCalculation()
    {
        // Unauthenticated creator
        $bonusService = new \App\Services\BonusService();
        $unauthRes = $bonusService->generateBonusBatch([
            'company_id' => 'comp-test',
            'month'      => 'July',
            'year'       => 2026,
        ], []); // Empty current user

        $this->assertFalse($unauthRes['success']);
        $this->assertStringContainsString('authenticated user identity is required', $unauthRes['message']);

        // Scheme priority sort without literal 999
        $schemes = [
            ['code' => 'SCH_B', 'name' => 'Bonus B', 'status' => 'Active'], // No priority specified
            ['code' => 'SCH_A', 'name' => 'Bonus A', 'priority' => 1, 'status' => 'Active'],
        ];

        $resolved = $bonusService->resolveScheme($schemes);
        $this->assertNotNull($resolved);
        $this->assertEquals('SCH_A', $resolved['code'], 'Scheme with explicit priority 1 must take precedence over unprioritized scheme');
    }

    /**
     * 48. Proration and tenure cutoff boundaries
     */
    public function testProrationAndTenureCutoffBoundaries()
    {
        $calculateProration = function(int $tenureDays, int $minDays, bool $prorateUnder, int $thresholdMonths, float $minRatio): ?float {
            if ($tenureDays < $minDays) {
                return null; // Ineligible
            }
            $tenureMonths = $tenureDays / 30.44;
            if ($prorateUnder && $thresholdMonths > 0 && $tenureMonths < $thresholdMonths) {
                return min(1.0, max($minRatio, $tenureMonths / (float)$thresholdMonths));
            }
            return 1.0;
        };

        // 1. Below min_service_days => Ineligible
        $this->assertNull($calculateProration(89, 90, true, 6, 0.1));

        // 2. Exactly min_service_days => Eligible, prorated
        $p90 = $calculateProration(90, 90, true, 6, 0.1);
        $this->assertNotNull($p90);
        $this->assertGreaterThanOrEqual(0.1, $p90);
        $this->assertLessThan(1.0, $p90);

        // 3. Above threshold => 100% full entitlement
        $p183 = $calculateProration(183, 90, true, 6, 0.1);
        $this->assertEquals(1.0, $p183);

        // 4. Floor minimum ratio enforced
        $pFloor = $calculateProration(90, 90, true, 12, 0.5);
        $this->assertEquals(0.5, $pFloor, 'Proration ratio must respect min_ratio floor');
    }

    /**
     * 49. Attendance penalty ratio scaling
     */
    public function testAttendancePenaltyRatioApplication()
    {
        $rawGross = 10000.0;
        $prorationRatio = 1.0;

        // Clean attendance (1.0000)
        $penaltyClean = 1.0000;
        $netClean = round($rawGross * $prorationRatio * $penaltyClean, 2);
        $this->assertEquals(10000.00, $netClean);

        // 10% penalty for attendance infractions (0.9000)
        $penaltyInfraction = 0.9000;
        $netPenalized = round($rawGross * $prorationRatio * $penaltyInfraction, 2);
        $this->assertEquals(9000.00, $netPenalized);
        $this->assertLessThan($netClean, $netPenalized);
    }

    /**
     * 50. Run the same batch twice and assert the second message says "already generated"
     */
    public function testDuplicateBonusBatchReportsAlreadyGeneratedMessage()
    {
        $db = \Config\Database::connect();
        $bonusService = new \App\Services\BonusService();
        $companyId = 'comp-' . bin2hex(random_bytes(4));
        $empId = 'emp-' . bin2hex(random_bytes(4));
        $currentUser = ['id' => 'usr-' . bin2hex(random_bytes(4)), 'company_id' => $companyId];

        // Seed company
        $db->table('companies')->insert([
            'id'         => $companyId,
            'name'       => 'Bonus Duplicate Message Test Corp',
            'status'     => 'Active',
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        // Seed PAYROLL_BASICS rule
        $db->table('rule_definitions')->insert([
            'id'             => 'rd-' . bin2hex(random_bytes(8)),
            'company_id'     => $companyId,
            'domain'         => 'PAYROLL_BASICS',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2026-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'currency_code'                   => 'USD',
                'currency_symbol'                 => '$',
                'tax_number_label'                => 'TIN',
                'days_in_month'                   => 'calendar_days',
                'pay_period'                      => 'monthly',
                'standard_working_days_per_month' => 22,
                'standard_daily_hours'            => 8,
            ]),
            'schema_version' => 1,
            'created_at'     => date('Y-m-d H:i:s'),
        ]);

        // Seed BONUS rule with FESTIVAL scheme
        $db->table('rule_definitions')->insert([
            'id'             => 'rd-' . bin2hex(random_bytes(8)),
            'company_id'     => $companyId,
            'domain'         => 'BONUS',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2026-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'schemes' => [
                    [
                        'code'              => 'FESTIVAL',
                        'name'              => 'Festival Bonus',
                        'status'            => 'Active',
                        'calculation_type'  => 'Percentage_Basic',
                        'salary_basis'      => 'Basic Salary',
                        'value'             => 50,
                        'min_service_days'  => 30,
                        'include_probation' => true,
                    ]
                ]
            ]),
            'schema_version' => 1,
            'created_at'     => date('Y-m-d H:i:s'),
        ]);

        // Seed eligible active employee
        $empData = [
            'id'           => $empId,
            'company_id'   => $companyId,
            'first_name'   => 'Sakib',
            'last_name'    => 'Hasan',
            'status'       => 'Active',
            'joining_date' => '2025-01-01',
            'basic_salary' => 25000.0,
            'gross_salary' => 45000.0,
            'created_at'   => date('Y-m-d H:i:s'),
        ];
        if ($db->fieldExists('email', 'employees')) {
            $empData['email'] = 'sakib.' . bin2hex(random_bytes(3)) . '@example.com';
        }
        if ($db->fieldExists('join_date', 'employees')) {
            $empData['join_date'] = '2025-01-01';
        }
        $db->table('employees')->insert($empData);

        // Seed active salary
        if ($db->tableExists('employee_salaries')) {
            $salaryData = [
                'id'             => 'sal-' . bin2hex(random_bytes(6)),
                'employee_id'    => $empId,
                'company_id'     => $companyId,
                'basic_salary'   => 25000.0,
                'gross_salary'   => 45000.0,
                'status'         => 'Active',
                'created_at'     => date('Y-m-d H:i:s'),
            ];
            if ($db->fieldExists('effective_from', 'employee_salaries')) {
                $salaryData['effective_from'] = '2025-01-01';
            }
            if ($db->fieldExists('effective_date', 'employee_salaries')) {
                $salaryData['effective_date'] = '2025-01-01';
            }
            $db->table('employee_salaries')->insert($salaryData);
        }

        \App\Services\Rules\RuleResolver::resetMemo();

        $batchParams = [
            'company_id' => $companyId,
            'scheme_id'  => 'FESTIVAL',
            'title'      => 'Festival Bonus Batch',
            'month'      => 'October',
            'year'       => 2026,
            'target'     => 'individual',
            'employee_id'=> $empId,
        ];

        // 1. Run batch first time: should generate 1 pending bonus record
        $res1 = $bonusService->generateBonusBatch($batchParams, $currentUser);
        $this->assertTrue($res1['success'], 'First batch run must succeed');
        $this->assertEquals(1, $res1['data']['created']);
        $this->assertEquals(0, $res1['data']['skipped']);

        // 2. Run the same batch a second time: duplicate skipped, message must say "already generated"
        $res2 = $bonusService->generateBonusBatch($batchParams, $currentUser);
        $this->assertEquals(0, $res2['data']['created'], 'Second batch run must create 0 new records');
        $this->assertEquals(1, $res2['data']['skipped'], 'Second batch run must skip 1 duplicate record');
        $this->assertStringContainsString('already generated', $res2['message'], 'Second message must say "already generated"');
        $this->assertStringContainsString('FESTIVAL', $res2['message']);
        $this->assertNotEmpty($res2['data']['skipped_reasons']);
        $this->assertArrayHasKey('already generated (FESTIVAL, October 2026)', $res2['data']['grouped_reasons']);

        // Clean up
        $db->table('bonus_records')->where('company_id', $companyId)->delete();
        $db->table('employees')->where('id', $empId)->delete();
        if ($db->tableExists('employee_salaries')) {
            $db->table('employee_salaries')->where('employee_id', $empId)->delete();
        }
        $db->table('rule_definitions')->where('company_id', $companyId)->delete();
        $db->table('companies')->where('id', $companyId)->delete();
    }
}


