<?php

namespace Tests\Unit\Rules;

use App\Services\Rules\ResolvedRule;
use App\Services\Rules\RuleKeyMissingException;
use App\Services\Rules\RuleNotConfiguredException;
use App\Services\Rules\RuleResolver;
use App\Services\Rules\RuleSchemaRegistry;
use PHPUnit\Framework\TestCase;
use Tests\Unit\Rules\Fakes\FakeRuleDefinitionModel;

require_once __DIR__ . '/Fakes/FakeRuleDefinitionModel.php';

class RuleResolverTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        if (function_exists('session')) {
            try {
                \Config\Services::session()->destroy();
            } catch (\Throwable $e) {}
        }
        if (isset($_SESSION)) {
            $_SESSION = [];
        }
        if (class_exists(\Config\Services::class)) {
            try {
                \Config\Services::reset(true);
            } catch (\Throwable $e) {}
        }
        RuleResolver::flush(true);
        RuleResolver::resetMemo();
    }

    protected function tearDown(): void
    {
        RuleResolver::flush(true);
        RuleResolver::resetMemo();
        if (function_exists('session')) {
            try {
                \Config\Services::session()->destroy();
            } catch (\Throwable $e) {}
        }
        if (isset($_SESSION)) {
            $_SESSION = [];
        }
        if (class_exists(\Config\Services::class)) {
            try {
                \Config\Services::reset(true);
            } catch (\Throwable $e) {}
        }
        parent::tearDown();
    }

    /**
     * 1. Company only resolution
     */
    public function testCompanyOnlyResolution()
    {
        $rows = [
            [
                'id'             => 'rule-comp-1',
                'company_id'     => 'comp-1',
                'domain'         => 'OVERTIME',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode([
                    'multiplier' => 1.5,
                    'basis'      => 'Basic',
                ]),
            ],
        ];

        $fakeModel = new FakeRuleDefinitionModel($rows);
        $resolver  = new RuleResolver($fakeModel, true);

        $resolved = $resolver->resolve('comp-1', 'OVERTIME', '2025-06-01');

        $this->assertInstanceOf(ResolvedRule::class, $resolved);
        $this->assertSame(1.5, $resolved->get('multiplier'));
        $this->assertSame('Basic', $resolved->get('basis'));

        // Snapshot checks
        $snapshot = $resolved->snapshot();
        $this->assertArrayHasKey('layers', $snapshot);
        $this->assertArrayHasKey('sha1', $snapshot);
        $this->assertCount(1, $snapshot['layers']);
        $this->assertSame('Company', $snapshot['layers'][0]['scope_level']);
        $this->assertSame(1, $snapshot['layers'][0]['version_number']);
        $this->assertSame('rule-comp-1', $snapshot['layers'][0]['rule_id']);

        // Explain checks
        $explained = $resolver->explain('comp-1', 'OVERTIME', '2025-06-01');
        $this->assertArrayHasKey('multiplier', $explained);
        $this->assertSame(1.5, $explained['multiplier']['value']);
        $this->assertSame('Company', $explained['multiplier']['origin']['scope_level']);
        $this->assertNull($explained['multiplier']['origin']['scope_id']);
        $this->assertSame(1, $explained['multiplier']['origin']['version_number']);
        $this->assertSame('rule-comp-1', $explained['multiplier']['origin']['rule_id']);
    }

    /**
     * 2. Department override
     */
    public function testDepartmentOverride()
    {
        $rows = [
            [
                'id'             => 'rule-comp-1',
                'company_id'     => 'comp-1',
                'domain'         => 'OVERTIME',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode([
                    'multiplier'    => 1.5,
                    'basis'         => 'Basic',
                    'grace_minutes' => 15,
                ]),
            ],
            [
                'id'             => 'rule-dept-eng',
                'company_id'     => 'comp-1',
                'domain'         => 'OVERTIME',
                'scope_level'    => 'Department',
                'scope_id'       => 'dept-eng',
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode([
                    'multiplier' => 2.0, // Partial override
                ]),
            ],
        ];

        $fakeModel = new FakeRuleDefinitionModel($rows);
        $resolver  = new RuleResolver($fakeModel, true);

        $employee = [
            'id'            => 'emp-001',
            'department_id' => 'dept-eng',
        ];

        $resolved = $resolver->resolve('comp-1', 'OVERTIME', '2025-06-01', $employee);

        $this->assertEquals(2.0, $resolved->get('multiplier'), 'Department override must supersede Company value');
        $this->assertSame('Basic', $resolved->get('basis'), 'Untouched Company value must remain');
        $this->assertSame(15, $resolved->get('grace_minutes'), 'Untouched Company value must remain');

        $explained = $resolved->explain();
        $this->assertSame('Department', $explained['multiplier']['origin']['scope_level']);
        $this->assertSame('dept-eng', $explained['multiplier']['origin']['scope_id']);
        $this->assertSame('Company', $explained['basis']['origin']['scope_level']);
        $this->assertNull($explained['basis']['origin']['scope_id']);

        $snapshot = $resolved->snapshot();
        $this->assertCount(2, $snapshot['layers']);
        $this->assertSame('Company', $snapshot['layers'][0]['scope_level']);
        $this->assertSame('Department', $snapshot['layers'][1]['scope_level']);
    }

    /**
     * 3. Employee override
     */
    public function testEmployeeOverride()
    {
        $rows = [
            [
                'id'             => 'rule-comp-1',
                'company_id'     => 'comp-1',
                'domain'         => 'OVERTIME',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode([
                    'multiplier' => 1.5,
                    'basis'      => 'Basic',
                ]),
            ],
            [
                'id'             => 'rule-dept-eng',
                'company_id'     => 'comp-1',
                'domain'         => 'OVERTIME',
                'scope_level'    => 'Department',
                'scope_id'       => 'dept-eng',
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode([
                    'multiplier' => 2.0,
                ]),
            ],
            [
                'id'             => 'rule-emp-99',
                'company_id'     => 'comp-1',
                'domain'         => 'OVERTIME',
                'scope_level'    => 'Employee',
                'scope_id'       => 'emp-99',
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode([
                    'multiplier' => 2.5,
                ]),
            ],
        ];

        $fakeModel = new FakeRuleDefinitionModel($rows);
        $resolver  = new RuleResolver($fakeModel, true);

        $employee = [
            'id'            => 'emp-99',
            'department_id' => 'dept-eng',
        ];

        $resolved = $resolver->resolve('comp-1', 'OVERTIME', '2025-06-01', $employee);

        $this->assertSame(2.5, $resolved->get('multiplier'), 'Employee override must supersede Department and Company');
        $this->assertSame('Basic', $resolved->get('basis'));

        $explained = $resolved->explain();
        $this->assertSame('Employee', $explained['multiplier']['origin']['scope_level']);
        $this->assertSame('emp-99', $explained['multiplier']['origin']['scope_id']);
        $this->assertSame('rule-emp-99', $explained['multiplier']['origin']['rule_id']);

        $snapshot = $resolved->snapshot();
        $this->assertCount(3, $snapshot['layers']);
        $this->assertSame('Company', $snapshot['layers'][0]['scope_level']);
        $this->assertSame('Department', $snapshot['layers'][1]['scope_level']);
        $this->assertSame('Employee', $snapshot['layers'][2]['scope_level']);
    }

    /**
     * 4. Array replaced whole (not merged or appended)
     */
    public function testArrayReplacedWhole()
    {
        $rows = [
            [
                'id'             => 'rule-comp-1',
                'company_id'     => 'comp-1',
                'domain'         => 'OVERTIME',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode([
                    'basis' => 'Basic',
                    'tiers' => [
                        ['tier' => 1, 'rate' => 1.5],
                        ['tier' => 2, 'rate' => 2.0],
                    ],
                ]),
            ],
            [
                'id'             => 'rule-dept-sales',
                'company_id'     => 'comp-1',
                'domain'         => 'OVERTIME',
                'scope_level'    => 'Department',
                'scope_id'       => 'dept-sales',
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode([
                    'tiers' => [
                        ['tier' => 1, 'rate' => 3.0],
                    ],
                ]),
            ],
        ];

        $fakeModel = new FakeRuleDefinitionModel($rows);
        $resolver  = new RuleResolver($fakeModel, true);

        $employee = ['department_id' => 'dept-sales'];
        $resolved = $resolver->resolve('comp-1', 'OVERTIME', '2025-06-01', $employee);

        $tiers = $resolved->get('tiers');
        $this->assertIsArray($tiers);
        $this->assertCount(1, $tiers, 'Array parameter must be replaced whole, not appended or merged');
        $this->assertEquals(3.0, $tiers[0]['rate']);
        $this->assertSame('Basic', $resolved->get('basis'));
    }

    /**
     * 5. Date before first version throws RuleNotConfiguredException
     */
    public function testDateBeforeFirstVersionThrowsException()
    {
        $rows = [
            [
                'id'             => 'rule-comp-1',
                'company_id'     => 'comp-1',
                'domain'         => 'OVERTIME',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode(['multiplier' => 1.5]),
            ],
        ];

        $fakeModel = new FakeRuleDefinitionModel($rows);
        $resolver  = new RuleResolver($fakeModel, true);

        $this->expectException(RuleNotConfiguredException::class);
        $this->expectExceptionMessageMatches('/before first effective version/i');

        $resolver->resolve('comp-1', 'OVERTIME', '2024-12-31');
    }

    /**
     * 6. No Company layer throws RuleNotConfiguredException
     */
    public function testNoCompanyLayerThrowsException()
    {
        $rows = [
            [
                'id'             => 'rule-dept-only',
                'company_id'     => 'comp-1',
                'domain'         => 'OVERTIME',
                'scope_level'    => 'Department',
                'scope_id'       => 'dept-sales',
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode(['multiplier' => 2.0]),
            ],
        ];

        $fakeModel = new FakeRuleDefinitionModel($rows);
        $resolver  = new RuleResolver($fakeModel, true);

        $this->expectException(RuleNotConfiguredException::class);
        $this->expectExceptionMessageMatches('/No active Company-level rule configured/i');

        $resolver->resolve('comp-1', 'OVERTIME', '2025-06-01', ['department_id' => 'dept-sales']);
    }

    /**
     * 7. Other company's rows are completely ignored
     */
    public function testOtherCompanyRowsIgnored()
    {
        $rows = [
            [
                'id'             => 'rule-comp-2',
                'company_id'     => 'comp-2',
                'domain'         => 'OVERTIME',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode(['multiplier' => 2.5]),
            ],
        ];

        $fakeModel = new FakeRuleDefinitionModel($rows);
        $resolver  = new RuleResolver($fakeModel, true);

        // Resolving for comp-1 must NOT see comp-2 rules
        $this->expectException(RuleNotConfiguredException::class);
        $resolver->resolve('comp-1', 'OVERTIME', '2025-06-01');
    }

    /**
     * 8. Missing key throws RuleKeyMissingException
     */
    public function testMissingKeyThrowsRuleKeyMissingException()
    {
        $rows = [
            [
                'id'             => 'rule-comp-1',
                'company_id'     => 'comp-1',
                'domain'         => 'OVERTIME',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode(['multiplier' => 1.5]),
            ],
        ];

        $fakeModel = new FakeRuleDefinitionModel($rows);
        $resolver  = new RuleResolver($fakeModel, true);
        $resolved  = $resolver->resolve('comp-1', 'OVERTIME', '2025-06-01');

        $this->expectException(RuleKeyMissingException::class);
        $this->expectExceptionMessageMatches('/not found/i');

        $resolved->get('non_existent_key');
    }

    /**
     * 9. Canonical JSON sha1 is deterministic regardless of key insertion order
     */
    public function testCanonicalSha1Deterministic()
    {
        $resolvedA = new ResolvedRule('c1', 'DOM', '2025-01-01', ['b' => 2, 'a' => 1], [], []);
        $resolvedB = new ResolvedRule('c1', 'DOM', '2025-01-01', ['a' => 1, 'b' => 2], [], []);

        $this->assertSame($resolvedA->sha1(), $resolvedB->sha1());
        $this->assertSame(40, strlen($resolvedA->sha1()));
    }

    /**
     * 10. Per-request memoization returns cached instance
     */
    public function testPerRequestMemoization()
    {
        $rows = [
            [
                'id'             => 'rule-comp-1',
                'company_id'     => 'comp-1',
                'domain'         => 'OVERTIME',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode(['multiplier' => 1.5]),
            ],
        ];

        $fakeModel = new FakeRuleDefinitionModel($rows);
        $resolver  = new RuleResolver($fakeModel, true);

        $res1 = $resolver->resolve('comp-1', 'OVERTIME', '2025-06-01');
        $res2 = $resolver->resolve('comp-1', 'OVERTIME', '2025-06-01');

        $this->assertSame($res1, $res2, 'Subsequent identical resolution calls must return memoized instance');

        $resolver->clearMemo();
        $res3 = $resolver->resolve('comp-1', 'OVERTIME', '2025-06-01');
        $this->assertEquals($res1->params(), $res3->params());
    }

    /**
     * 11. Effective rule id and version resolution across hierarchy layers
     */
    public function testEffectiveRuleIdAndVersion()
    {
        $rows = [
            [
                'id'             => 'rule-comp-base',
                'company_id'     => 'comp-1',
                'domain'         => 'PF',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 2,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode([
                    'employee_rate' => 8.0,
                    'employer_rate' => 8.0,
                ]),
            ],
            [
                'id'             => 'rule-emp-override',
                'company_id'     => 'comp-1',
                'domain'         => 'PF',
                'scope_level'    => 'Employee',
                'scope_id'       => 'emp-100',
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode([
                    'employee_rate' => 10.0,
                ]),
            ],
        ];

        $fakeModel = new FakeRuleDefinitionModel($rows);
        $resolver  = new RuleResolver($fakeModel, true);

        // Without employee context -> base company rule
        $resolvedBase = $resolver->resolve('comp-1', 'PF', '2025-06-01');
        $this->assertSame('rule-comp-base', $resolvedBase->effectiveRuleId());
        $this->assertSame('rule-comp-base', $resolvedBase->companyRuleId());
        $this->assertSame(2, $resolvedBase->effectiveVersion());
        $this->assertSame('rule-comp-base', $resolvedBase->effective_rule_id);
        $this->assertSame(2, $resolvedBase->effective_version);

        // With employee context -> employee override rule
        $resolvedEmp = $resolver->resolve('comp-1', 'PF', '2025-06-01', ['id' => 'emp-100']);
        $this->assertSame('rule-emp-override', $resolvedEmp->effectiveRuleId());
        $this->assertSame('rule-comp-base', $resolvedEmp->companyRuleId());
        $this->assertSame(1, $resolvedEmp->effectiveVersion());
        $this->assertSame('rule-emp-override', $resolvedEmp->effective_rule_id);
    }

    /**
     * 12. Tenant Safety: Empty companyId throws InvalidArgumentException without fallback to arbitrary DB rows
     */
    public function testEmptyCompanyIdThrowsInvalidArgumentException()
    {
        $rows = [
            [
                'id'             => 'rule-comp-default',
                'company_id'     => 'comp-default',
                'domain'         => 'ATTENDANCE',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode(['daily_required_hours' => 8.0]),
            ],
        ];

        $fakeModel = new FakeRuleDefinitionModel($rows);
        $resolver  = new RuleResolver($fakeModel, true);

        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessageMatches('/Company ID is required for rule resolution/i');

        $resolver->resolve('', 'ATTENDANCE', '2025-06-01');
    }

    /**
     * 13. Employee scope rule saved by code canonicalizes to ID and resolves by ID
     */
    public function testEmployeeScopeSavedByCodeCanonicalizesToIdAndResolvesById()
    {
        // 1. Employee identity: id vs employee_code
        $empId     = 'emp-canonical-007';
        $empCode   = 'EMP-007';
        $companyId = 'comp-1';

        // 2. Base Company rule
        $companyRule = [
            'id'             => 'rule-comp-ot-01',
            'company_id'     => $companyId,
            'domain'         => 'OVERTIME',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'multiplier'            => 1.5,
                'basis'                 => 'Basic',
                'daily_threshold_hours' => 8.0,
            ]),
        ];

        // 3. When an Employee-scope rule is created by code ('EMP-007'), it canonicalizes to 'emp-canonical-007'
        $empOverrideRule = [
            'id'             => 'rule-emp-override-007',
            'company_id'     => $companyId,
            'domain'         => 'OVERTIME',
            'scope_level'    => 'Employee',
            'scope_id'       => $empId, // Stored canonical ID
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'multiplier' => 2.5,
            ]),
        ];

        $fakeModel = new FakeRuleDefinitionModel([$companyRule, $empOverrideRule]);
        $resolver  = new RuleResolver($fakeModel, true);

        // Resolve passing employee context array with id and employee_code
        $employee = [
            'id'            => $empId,
            'employee_code' => $empCode,
            'company_id'    => $companyId,
        ];
        $resolved = $resolver->resolve($companyId, 'OVERTIME', '2025-06-01', $employee);

        // Assert employee override is applied because scope_id was stored as canonical id
        $this->assertSame(2.5, $resolved->get('multiplier'), 'Employee override saved with canonical ID must resolve successfully');
        $this->assertSame('rule-emp-override-007', $resolved->effectiveRuleId());

        // Negative check: If rule had been stored with raw employee_code instead of id,
        // RuleResolver (which matches on employee id) would not match:
        $unmatchedRule = [
            'id'             => 'rule-emp-by-code',
            'company_id'     => $companyId,
            'domain'         => 'OVERTIME',
            'scope_level'    => 'Employee',
            'scope_id'       => $empCode, // non-canonical code
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'multiplier' => 3.0,
            ]),
        ];

        $fakeModelUnmatched = new FakeRuleDefinitionModel([$companyRule, $unmatchedRule]);
        $resolverUnmatched  = new RuleResolver($fakeModelUnmatched, true);
        $resolvedFallback   = $resolverUnmatched->resolve($companyId, 'OVERTIME', '2025-06-01', $employee);

        // Falls back to Company rule (1.5) because scope_id 'EMP-007' does not match employee id 'emp-canonical-007'
        $this->assertSame(1.5, $resolvedFallback->get('multiplier'), 'Rule stored with raw code does not match employee id');
    }

    /**
     * 14. Stop new RuleResolver($model) from overwriting global state: make activeInstance opt-in
     */
    public function testNewResolverDoesNotOverwriteActiveInstanceUnlessOptedIn()
    {
        $compA = 'comp-active-a';
        $modelA = new FakeRuleDefinitionModel([
            [
                'id'             => 'rule-a',
                'company_id'     => $compA,
                'domain'         => 'OVERTIME',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode(['multiplier' => 1.5]),
            ],
        ]);

        $resolverA = new RuleResolver($modelA, true); // Opt-in
        $this->assertSame($resolverA, RuleResolver::getActiveInstance(), 'Opt-in resolver must be registered as active');

        $compB = 'comp-active-b';
        $modelB = new FakeRuleDefinitionModel([
            [
                'id'             => 'rule-b',
                'company_id'     => $compB,
                'domain'         => 'OVERTIME',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode(['multiplier' => 2.5]),
            ],
        ]);

        // Default construction without opt-in
        $resolverB = new RuleResolver($modelB);
        $this->assertSame($resolverA, RuleResolver::getActiveInstance(), 'New instance must NOT overwrite global activeInstance when opt-in is false');

        // Explicitly make B active
        $resolverB->makeActive();
        $this->assertSame($resolverB, RuleResolver::getActiveInstance(), 'makeActive() must register instance as active');
    }

    /**
     * 15. Fix weekEndDay so it is strictly the day before weekStartDay
     */
    public function testWeekEndDayCalculatedAsStrictlyDayBeforeWeekStartDay()
    {
        $companyId = 'comp-week-test';
        $testCases = [
            'Sunday'   => 'Saturday',
            'Saturday' => 'Friday',
            'Monday'   => 'Sunday',
            'Friday'   => 'Thursday',
            'Tuesday'  => 'Monday',
        ];

        foreach ($testCases as $startDay => $expectedEndDay) {
            RuleResolver::resetMemo();
            $attRow = [
                'id'             => 'rule-att-' . $startDay,
                'company_id'     => $companyId,
                'domain'         => 'ATTENDANCE',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode([
                    'week_start_day'               => $startDay,
                    'weekly_off_days'              => ['Friday'],
                    'daily_required_hours'         => 8.0,
                    'half_day_threshold_hours'     => 4.0,
                    'min_work_hours_for_present'   => 4.0,
                    'office_start_time'            => '09:00:00',
                    'office_end_time'              => '17:00:00',
                    'half_day_time'                => '13:00:00',
                    'break_enabled'                => false,
                    'break_duration_minutes'       => 0,
                    'break_is_paid'                => true,
                    'unpaid_break_treatment'       => 'Deduct from gross hours',
                    'break_auto_deduct'            => false,
                    'late_enabled'                 => false,
                    'late_grace_minutes'           => 15,
                    'late_penalty_method'          => 'Warning',
                    'late_penalty_per_minute'      => 0.0,
                    'late_consecutive_days_threshold' => 3,
                    'late_consecutive_penalty_leave_days' => 1.0,
                    'early_out_enabled'            => false,
                    'early_out_threshold_minutes'  => 0,
                    'early_out_penalty_method'     => 'Warning',
                    'early_out_penalty_per_minute' => 0.0,
                    'missing_day_policy'           => 'Actual Hours Only',
                    'missing_day_allow_weekly_bonus_if_hours_met' => false,
                    'holiday_counts_as_working_hours' => true,
                    'holiday_credited_hours'       => 8.0,
                    'holiday_counts_toward_weekly_requirement' => true,
                    'leave_treatments'             => [
                        [
                            'leave_type_code' => 'CASUAL',
                            'leave_type_name' => 'Casual Leave',
                            'counts_as_working_day' => true,
                            'counts_as_working_hours' => true,
                            'credited_hours_per_day' => 8.0,
                        ],
                    ],
                ]),
            ];

            $otRow = [
                'id'             => 'rule-ot-' . $startDay,
                'company_id'     => $companyId,
                'domain'         => 'OVERTIME',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode([
                    'enable_daily_ot'                 => true,
                    'enable_weekly_ot'                => false,
                    'enable_early_arrival_ot'         => false,
                    'early_arrival_grace_minutes'     => 0,
                    'early_arrival_min_threshold_minutes' => 0,
                    'post_shift_grace_minutes'        => 0,
                    'post_shift_min_threshold_minutes' => 0,
                    'normal_multiplier'               => 1.5,
                    'weekly_off_multiplier'           => 2.0,
                    'holiday_multiplier'              => 2.0,
                    'special_multiplier'              => 2.0,
                    'night_multiplier'                => 1.0,
                    'min_ot_unit_minutes'             => 15,
                    'min_ot_minutes_to_qualify'       => 30,
                    'daily_threshold_hours'           => 8.0,
                    'rounding_mode'                   => 'None',
                    'calculation_method'              => 'Hourly',
                    'conflict_policy'                 => 'Highest',
                    'salary_basis'                    => 'Basic',
                    'divisor_mode'                    => 'Fixed 30 Days',
                    'divisor_hours'                   => 8.0,
                    'requires_pre_approval'           => false,
                    'requires_post_approval'          => false,
                    'max_daily_ot_hours'              => 4.0,
                    'max_monthly_ot_hours'            => 60.0,
                ]),
            ];

            $bonusRow = [
                'id'             => 'rule-bn-' . $startDay,
                'company_id'     => $companyId,
                'domain'         => 'BONUS',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode([
                    'weekly_bonus_enabled'                 => false,
                    'weekly_bonus_method'                  => 'Fixed',
                    'weekly_bonus_fixed_amount'            => 0.0,
                    'weekly_bonus_percentage_of_basic'     => 0.0,
                    'weekly_bonus_rate_per_hour'           => null,
                    'weekly_bonus_min_present_days'        => 5,
                    'weekly_bonus_min_weekly_hours'        => 40.0,
                    'weekly_bonus_full_attendance_required'=> false,
                    'weekly_bonus_late_allowed'            => true,
                    'weekly_bonus_max_allowed_lates'       => 0,
                    'weekly_bonus_leave_allowed'           => false,
                    'weekly_bonus_tiers'                   => [],
                ]),
            ];

            $leaveRow = [
                'id'             => 'rule-lv-' . $startDay,
                'company_id'     => $companyId,
                'domain'         => 'LEAVE',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode([
                    'entitlements' => [
                        [
                            'leave_type_code'       => 'CASUAL',
                            'leave_type_name'       => 'Casual Leave',
                            'is_paid'               => true,
                            'counts_as_working_day' => true,
                        ],
                    ],
                ]),
            ];

            $pbRow = [
                'id'             => 'rule-pb-' . $startDay,
                'company_id'     => $companyId,
                'domain'         => 'PAYROLL_BASICS',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode([
                    'currency_code'            => 'BDT',
                    'money_decimals'           => 2,
                    'daily_rate_mode'          => 'Fixed',
                    'daily_rate_divisor'       => 30,
                    'standard_daily_hours'     => 8.0,
                    'proration_basis'          => 'Calendar',
                    'minimum_net_salary_floor' => 0.0,
                ]),
            ];

            $fakeModel = new FakeRuleDefinitionModel([$attRow, $otRow, $bonusRow, $leaveRow, $pbRow]);
            new RuleResolver($fakeModel, true);

            $profile = RuleResolver::attendanceProfile(['company_id' => $companyId], '2025-06-01');
            $this->assertSame($startDay, $profile['workingWeek']['weekStartDay']);
            $this->assertSame($expectedEndDay, $profile['workingWeek']['weekEndDay'], "weekEndDay for start {$startDay} must strictly be {$expectedEndDay}");
            $this->assertArrayNotHasKey('working_week', $profile, 'Redundant snake_case working_week must not be in profile');
        }
    }

    /**
     * 16. Remove silent catch around OVERTIME, BONUS, LEAVE in attendanceProfile: fail loud
     */
    public function testAttendanceProfilePropagatesExceptionWhenOvertimeBonusOrLeaveMissing()
    {
        RuleResolver::resetMemo();
        $companyId = 'comp-fail-loud';

        // Only ATTENDANCE row, OVERTIME/BONUS/LEAVE missing
        $attRow = [
            'id'             => 'rule-att-only',
            'company_id'     => $companyId,
            'domain'         => 'ATTENDANCE',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'week_start_day'               => 'Sunday',
                'weekly_off_days'              => ['Friday'],
                'daily_required_hours'         => 8.0,
                'half_day_threshold_hours'     => 4.0,
                'min_work_hours_for_present'   => 4.0,
                'office_start_time'            => '09:00:00',
                'office_end_time'              => '17:00:00',
                'half_day_time'                => '13:00:00',
                'break_enabled'                => false,
                'break_duration_minutes'       => 0,
                'break_is_paid'                => true,
                'unpaid_break_treatment'       => 'Deduct from gross hours',
                'break_auto_deduct'            => false,
                'late_enabled'                 => false,
                'late_grace_minutes'           => 15,
                'late_penalty_method'          => 'Warning',
                'late_penalty_per_minute'      => 0.0,
                'late_consecutive_days_threshold' => 3,
                'late_consecutive_penalty_leave_days' => 1.0,
                'early_out_enabled'            => false,
                'early_out_threshold_minutes'  => 0,
                'early_out_penalty_method'     => 'Warning',
                'early_out_penalty_per_minute' => 0.0,
                'missing_day_policy'           => 'Actual Hours Only',
                'missing_day_allow_weekly_bonus_if_hours_met' => false,
                'holiday_counts_as_working_hours' => true,
                'holiday_credited_hours'       => 8.0,
                'holiday_counts_toward_weekly_requirement' => true,
            ]),
        ];

        $fakeModel = new FakeRuleDefinitionModel([$attRow]);
        new RuleResolver($fakeModel, true);

        $this->expectException(RuleNotConfiguredException::class);
        $this->expectExceptionMessageMatches('/OVERTIME/i');
        RuleResolver::attendanceProfile(['company_id' => $companyId], '2025-06-01');
    }

    /**
     * 17. Resolve leave treatments from LEAVE rule when missing in ATTENDANCE, or throw
     */
    public function testAttendanceProfileResolvesLeaveTreatmentsFromLeaveRuleEntitlements()
    {
        RuleResolver::resetMemo();
        $companyId = 'comp-entitlements-test';

        // ATTENDANCE has NO leave_treatments
        $attRow = [
            'id'             => 'rule-att-notreatments',
            'company_id'     => $companyId,
            'domain'         => 'ATTENDANCE',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'week_start_day'               => 'Sunday',
                'weekly_off_days'              => ['Friday', 'Saturday'],
                'daily_required_hours'         => 8.0,
                'half_day_threshold_hours'     => 4.0,
                'min_work_hours_for_present'   => 4.0,
                'office_start_time'            => '09:00:00',
                'office_end_time'              => '17:00:00',
                'half_day_time'                => '13:00:00',
                'break_enabled'                => false,
                'break_duration_minutes'       => 0,
                'break_is_paid'                => true,
                'unpaid_break_treatment'       => 'Deduct from gross hours',
                'break_auto_deduct'            => false,
                'late_enabled'                 => false,
                'late_grace_minutes'           => 15,
                'late_penalty_method'          => 'Warning',
                'late_penalty_per_minute'      => 0.0,
                'late_consecutive_days_threshold' => 3,
                'late_consecutive_penalty_leave_days' => 1.0,
                'early_out_enabled'            => false,
                'early_out_threshold_minutes'  => 0,
                'early_out_penalty_method'     => 'Warning',
                'early_out_penalty_per_minute' => 0.0,
                'missing_day_policy'           => 'Actual Hours Only',
                'missing_day_allow_weekly_bonus_if_hours_met' => false,
                'holiday_counts_as_working_hours' => true,
                'holiday_credited_hours'       => 8.0,
                'holiday_counts_toward_weekly_requirement' => true,
            ]),
        ];

        $otRow = [
            'id'             => 'rule-ot-std',
            'company_id'     => $companyId,
            'domain'         => 'OVERTIME',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'enable_daily_ot'                 => true,
                'enable_weekly_ot'                => false,
                'enable_early_arrival_ot'         => false,
                'early_arrival_grace_minutes'     => 0,
                'early_arrival_min_threshold_minutes' => 0,
                'post_shift_grace_minutes'        => 0,
                'post_shift_min_threshold_minutes' => 0,
                'normal_multiplier'               => 1.5,
                'weekly_off_multiplier'           => 2.0,
                'holiday_multiplier'              => 2.0,
                'special_multiplier'              => 2.0,
                'night_multiplier'                => 1.0,
                'min_ot_unit_minutes'             => 15,
                'min_ot_minutes_to_qualify'       => 30,
                'daily_threshold_hours'           => 8.0,
                'rounding_mode'                   => 'None',
                'calculation_method'              => 'Hourly',
                'conflict_policy'                 => 'Highest',
                'salary_basis'                    => 'Basic',
                'divisor_mode'                    => 'Fixed 30 Days',
                'divisor_hours'                   => 8.0,
                'requires_pre_approval'           => false,
                'requires_post_approval'          => false,
                'max_daily_ot_hours'              => 4.0,
                'max_monthly_ot_hours'            => 60.0,
            ]),
        ];

        $bonusRow = [
            'id'             => 'rule-bn-std',
            'company_id'     => $companyId,
            'domain'         => 'BONUS',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'weekly_bonus_enabled'                 => false,
                'weekly_bonus_method'                  => 'Fixed',
                'weekly_bonus_fixed_amount'            => 0.0,
                'weekly_bonus_percentage_of_basic'     => 0.0,
                'weekly_bonus_rate_per_hour'           => null,
                'weekly_bonus_min_present_days'        => 5,
                'weekly_bonus_min_weekly_hours'        => 40.0,
                'weekly_bonus_full_attendance_required'=> false,
                'weekly_bonus_late_allowed'            => true,
                'weekly_bonus_max_allowed_lates'       => 0,
                'weekly_bonus_leave_allowed'           => false,
                'weekly_bonus_tiers'                   => [],
            ]),
        ];

        $leaveRow = [
            'id'             => 'rule-lv-entitlements',
            'company_id'     => $companyId,
            'domain'         => 'LEAVE',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'entitlements' => [
                    [
                        'leave_type_code'       => 'CASUAL',
                        'leave_type_name'       => 'Casual Leave',
                        'is_paid'               => true,
                        'counts_as_working_day' => true,
                    ],
                    [
                        'leave_type_code'       => 'MEDICAL',
                        'leave_type_name'       => 'Medical Leave',
                        'is_paid'               => true,
                        'counts_as_working_day' => true,
                    ],
                    [
                        'leave_type_code'       => 'LWP',
                        'leave_type_name'       => 'Leave Without Pay',
                        'is_paid'               => false,
                        'counts_as_working_day' => false,
                    ],
                ],
            ]),
        ];

        $pbRow = [
            'id'             => 'rule-pb-std',
            'company_id'     => $companyId,
            'domain'         => 'PAYROLL_BASICS',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'currency_code'            => 'BDT',
                'money_decimals'           => 2,
                'daily_rate_mode'          => 'Fixed',
                'daily_rate_divisor'       => 30,
                'standard_daily_hours'     => 8.0,
                'proration_basis'          => 'Calendar',
                'minimum_net_salary_floor' => 0.0,
            ]),
        ];

        $fakeModel = new FakeRuleDefinitionModel([$attRow, $otRow, $bonusRow, $leaveRow, $pbRow]);
        new RuleResolver($fakeModel, true);

        $profile = RuleResolver::attendanceProfile(['company_id' => $companyId], '2025-06-01');
        $this->assertNotEmpty($profile['leaveTreatments']);
        $this->assertCount(3, $profile['leaveTreatments']);

        $codes = array_column($profile['leaveTreatments'], 'leaveTypeCode');
        $this->assertContains('CASUAL', $codes);
        $this->assertContains('MEDICAL', $codes);
        $this->assertContains('LWP', $codes);

        $lwp = null;
        foreach ($profile['leaveTreatments'] as $lt) {
            if ($lt['leaveTypeCode'] === 'LWP') {
                $lwp = $lt;
                break;
            }
        }
        $this->assertNotNull($lwp);
        $this->assertFalse($lwp['countsAsWorkingHours']);
        $this->assertSame(0.0, $lwp['creditedWorkingHoursPerDay']);
    }

    /**
     * 18. RuleResolver::flush() clears memos, rows cache, and attendance profile cache
     */
    public function testRuleResolverFlushClearsAllMemosAndCaches()
    {
        RuleResolver::resetMemo();
        $companyId = 'comp-flush-test';

        $row = [
            'id'             => 'rule-flush-1',
            'company_id'     => $companyId,
            'domain'         => 'OVERTIME',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode(['multiplier' => 1.5]),
        ];

        $fakeModel = new FakeRuleDefinitionModel([$row]);
        $resolver = new RuleResolver($fakeModel, true);

        // Resolve rule into memo
        $res = RuleResolver::resolve($companyId, 'OVERTIME', '2025-06-01');
        $this->assertSame(1.5, $res->get('multiplier'));

        // Calling flush clears caches without resetting activeInstance
        RuleResolver::flush();
        $this->assertSame($resolver, RuleResolver::getActiveInstance(), 'activeInstance must remain intact across flush()');

        // Resolve again succeeds from fresh model query
        $res2 = RuleResolver::resolve($companyId, 'OVERTIME', '2025-06-01');
        $this->assertSame(1.5, $res2->get('multiplier'));
    }

    /**
     * 19. ResolvedRule does not fallback special_multiplier to night_multiplier
     */
    public function testSpecialMultiplierDoesNotFallbackToNightMultiplier()
    {
        RuleResolver::resetMemo();
        $companyId = 'comp-ot-no-fallback';

        $row = [
            'id'             => 'rule-ot-1',
            'company_id'     => $companyId,
            'domain'         => 'OVERTIME',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'night_multiplier' => 1.5,
            ]),
        ];

        $fakeModel = new FakeRuleDefinitionModel([$row]);
        new RuleResolver($fakeModel, true);

        $res = RuleResolver::resolve($companyId, 'OVERTIME', '2025-06-01');
        $this->assertSame(1.5, $res->get('night_multiplier'));
        $this->assertFalse($res->has('special_multiplier'));

        $this->expectException(\App\Services\Rules\RuleKeyMissingException::class);
        $res->get('special_multiplier');
    }

    /**
     * 20. Two resolvers with different fake models and the same company/domain/date return their own rules without calling flush().
     */
    public function testTwoResolversWithDifferentModelsReturnOwnRulesWithoutFlush()
    {
        $companyId = 'comp-model-isolation';
        $domain    = 'OVERTIME';
        $date      = '2025-06-01';

        $modelA = new FakeRuleDefinitionModel([
            [
                'id'             => 'rule-model-a',
                'company_id'     => $companyId,
                'domain'         => $domain,
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode(['multiplier' => 1.5]),
            ],
        ]);

        $modelB = new FakeRuleDefinitionModel([
            [
                'id'             => 'rule-model-b',
                'company_id'     => $companyId,
                'domain'         => $domain,
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode(['multiplier' => 2.5]),
            ],
        ]);

        // Resolver A with model A
        $resolverA = new RuleResolver($modelA, true);
        $resA = $resolverA->resolve($companyId, $domain, $date);
        $this->assertEquals(1.5, $resA->get('multiplier'));
        $this->assertSame('rule-model-a', $resA->effectiveRuleId());

        // Resolver B with model B without calling RuleResolver::flush()
        $resolverB = new RuleResolver($modelB, true);
        $resB = $resolverB->resolve($companyId, $domain, $date);
        $this->assertEquals(2.5, $resB->get('multiplier'));
        $this->assertSame('rule-model-b', $resB->effectiveRuleId());

        // Also verify instance resolution directly without calling flush()
        $instA = $resolverA->resolveInstance($companyId, $domain, $date);
        $instB = $resolverB->resolveInstance($companyId, $domain, $date);
        $this->assertEquals(1.5, $instA->get('multiplier'));
        $this->assertSame('rule-model-a', $instA->effectiveRuleId());
        $this->assertEquals(2.5, $instB->get('multiplier'));
        $this->assertSame('rule-model-b', $instB->effectiveRuleId());
    }
}



