<?php

namespace Tests\Unit\Rules;

use App\Services\Rules\DailyRateResolver;
use App\Services\Rules\ResolvedRule;
use App\Services\Rules\RuleNotConfiguredException;
use App\Services\Rules\RuleResolver;
use App\Services\PayrollService;
use PHPUnit\Framework\TestCase;
use Tests\Unit\Rules\Fakes\FakeRuleDefinitionModel;

require_once __DIR__ . '/Fakes/FakeRuleDefinitionModel.php';

class DailyRateResolverTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        if (function_exists('session')) {
            try {
                \Config\Services::session()->destroy();
            } catch (\Throwable $e) {}
        }
        if (isset($_SESSION)) {
            $_SESSION = [];
        }
        if (class_exists(\Config\Services::class)) {
            try {
                \Config\Services::reset(true);
            } catch (\Throwable $e) {}
        }
        RuleResolver::flush(true);
        RuleResolver::resetMemo();
    }

    protected function tearDown(): void
    {
        RuleResolver::flush(true);
        RuleResolver::resetMemo();
        if (function_exists('session')) {
            try {
                \Config\Services::session()->destroy();
            } catch (\Throwable $e) {}
        }
        if (isset($_SESSION)) {
            $_SESSION = [];
        }
        if (class_exists(\Config\Services::class)) {
            try {
                \Config\Services::reset(true);
            } catch (\Throwable $e) {}
        }
        parent::tearDown();
    }

    /**
     * Test Fixed 26 daily rate and divisor resolution
     */
    public function testFixed26DailyRateResolution()
    {
        $rows = [
            [
                'id'             => 'rule-pb-26',
                'company_id'     => 'comp-fixed-26',
                'domain'         => 'PAYROLL_BASICS',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode([
                    'currency_code'            => 'BDT',
                    'money_decimals'           => 2,
                    'daily_rate_mode'          => 'Fixed',
                    'daily_rate_divisor'       => 26,
                    'standard_daily_hours'     => 8.0,
                    'proration_basis'          => 'Calendar',
                    'minimum_net_salary_floor' => 0.0,
                ]),
            ],
        ];

        new RuleResolver(new FakeRuleDefinitionModel($rows), true);

        $result = DailyRateResolver::resolve('comp-fixed-26', null, '2026-03-15', '2026-03', 52000.0);

        $this->assertSame(26.0, $result['divisor_days']);
        $this->assertSame('Fixed', $result['divisor_mode']);
        $this->assertSame(2000.0, $result['daily_rate']);
        $this->assertSame(31, $result['days_in_month']);
        $this->assertSame(2000.0, $result['rate']);
        $this->assertSame(26.0, $result['divisor']);
    }

    /**
     * Test Fixed 30 daily rate and divisor resolution
     */
    public function testFixed30DailyRateResolution()
    {
        $rows = [
            [
                'id'             => 'rule-pb-30',
                'company_id'     => 'comp-fixed-30',
                'domain'         => 'PAYROLL_BASICS',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode([
                    'currency_code'            => 'USD',
                    'money_decimals'           => 2,
                    'daily_rate_mode'          => 'Fixed',
                    'daily_rate_divisor'       => 30,
                    'standard_daily_hours'     => 8.0,
                    'proration_basis'          => 'Calendar',
                    'minimum_net_salary_floor' => 0.0,
                ]),
            ],
        ];

        new RuleResolver(new FakeRuleDefinitionModel($rows), true);

        $result = DailyRateResolver::resolve('comp-fixed-30', null, '2026-04-10', null, 60000.0);

        $this->assertSame(30.0, $result['divisor_days']);
        $this->assertSame('Fixed', $result['divisor_mode']);
        $this->assertSame(2000.0, $result['daily_rate']);
        $this->assertSame(30, $result['days_in_month']);
    }

    /**
     * Test Calendar mode divisor across different months (Feb 28, Feb 29 leap, March 31, April 30)
     */
    public function testCalendarModeDailyRateResolution()
    {
        $rows = [
            [
                'id'             => 'rule-pb-cal',
                'company_id'     => 'comp-calendar',
                'domain'         => 'PAYROLL_BASICS',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2020-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode([
                    'currency_code'            => 'BDT',
                    'money_decimals'           => 2,
                    'daily_rate_mode'          => 'Calendar',
                    'daily_rate_divisor'       => 30,
                    'standard_daily_hours'     => 8.0,
                    'proration_basis'          => 'Calendar',
                    'minimum_net_salary_floor' => 0.0,
                ]),
            ],
        ];

        new RuleResolver(new FakeRuleDefinitionModel($rows), true);

        // March (31 days)
        $resMar = DailyRateResolver::resolve('comp-calendar', null, '2026-03-01', '2026-03', 31000.0);
        $this->assertSame(31.0, $resMar['divisor_days']);
        $this->assertSame('Calendar', $resMar['divisor_mode']);
        $this->assertSame(1000.0, $resMar['daily_rate']);
        $this->assertSame(31, $resMar['days_in_month']);

        // April (30 days)
        $resApr = DailyRateResolver::resolve('comp-calendar', null, '2026-04-01', '2026-04', 30000.0);
        $this->assertSame(30.0, $resApr['divisor_days']);
        $this->assertSame('Calendar', $resApr['divisor_mode']);
        $this->assertSame(1000.0, $resApr['daily_rate']);
        $this->assertSame(30, $resApr['days_in_month']);

        // Feb 2025 non-leap (28 days)
        $resFeb25 = DailyRateResolver::resolve('comp-calendar', null, '2025-02-15', '2025-02', 28000.0);
        $this->assertSame(28.0, $resFeb25['divisor_days']);
        $this->assertSame('Calendar', $resFeb25['divisor_mode']);
        $this->assertSame(1000.0, $resFeb25['daily_rate']);
        $this->assertSame(28, $resFeb25['days_in_month']);

        // Feb 2024 leap year (29 days)
        $resFeb24 = DailyRateResolver::resolve('comp-calendar', null, '2024-02-15', '2024-02', 29000.0);
        $this->assertSame(29.0, $resFeb24['divisor_days']);
        $this->assertSame('Calendar', $resFeb24['divisor_mode']);
        $this->assertSame(1000.0, $resFeb24['daily_rate']);
        $this->assertSame(29, $resFeb24['days_in_month']);
    }

    /**
     * Test explicit override divisor mode (e.g. from OVERTIME divisor_mode)
     */
    public function testOverrideDivisorModeResolution()
    {
        $rows = [
            [
                'id'             => 'rule-pb-base',
                'company_id'     => 'comp-override',
                'domain'         => 'PAYROLL_BASICS',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode([
                    'currency_code'            => 'BDT',
                    'money_decimals'           => 2,
                    'daily_rate_mode'          => 'Fixed',
                    'daily_rate_divisor'       => 30,
                    'standard_daily_hours'     => 8.0,
                    'proration_basis'          => 'Calendar',
                    'minimum_net_salary_floor' => 0.0,
                ]),
            ],
        ];

        new RuleResolver(new FakeRuleDefinitionModel($rows), true);

        // Override with Fixed 26 Days
        $res26 = DailyRateResolver::resolve('comp-override', null, '2026-03-01', null, 52000.0, 'Fixed 26 Days');
        $this->assertSame(26.0, $res26['divisor_days']);
        $this->assertSame(2000.0, $res26['daily_rate']);

        // Override with Calendar Days
        $resCal = DailyRateResolver::resolve('comp-override', null, '2026-03-01', null, 31000.0, 'Calendar Days');
        $this->assertSame(31.0, $resCal['divisor_days']);
        $this->assertSame(1000.0, $resCal['daily_rate']);

        // 'Basics' inherits PAYROLL_BASICS configuration (Fixed 30)
        $resBasics = DailyRateResolver::resolve('comp-override', null, '2026-03-01', null, 60000.0, 'Basics');
        $this->assertSame(30.0, $resBasics['divisor_days']);
        $this->assertSame(2000.0, $resBasics['daily_rate']);
    }

    /**
     * Test missing PAYROLL_BASICS rule throws RuleNotConfiguredException
     */
    public function testMissingRuleThrowsRuleNotConfiguredException()
    {
        new RuleResolver(new FakeRuleDefinitionModel([]), true);

        $this->expectException(RuleNotConfiguredException::class);
        DailyRateResolver::resolve('comp-missing', null, '2026-03-01', null, 50000.0);
    }

    /**
     * Test PayrollService::resolveDailySalaryRate integration with DailyRateResolver
     */
    public function testPayrollServiceResolveDailySalaryRateIntegration()
    {
        $rows = [
            [
                'id'             => 'rule-pb-payroll',
                'company_id'     => 'comp-ps-test',
                'domain'         => 'PAYROLL_BASICS',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode([
                    'currency_code'            => 'BDT',
                    'money_decimals'           => 2,
                    'daily_rate_mode'          => 'Fixed',
                    'daily_rate_divisor'       => 26,
                    'standard_daily_hours'     => 8.0,
                    'proration_basis'          => 'Calendar',
                    'minimum_net_salary_floor' => 0.0,
                ]),
            ],
        ];

        new RuleResolver(new FakeRuleDefinitionModel($rows), true);

        $payrollService = new PayrollService();
        $rateInfo = $payrollService->resolveDailySalaryRate(52000.0, '2026-03', [], 'comp-ps-test');

        $this->assertSame(26.0, $rateInfo['divisor_days']);
        $this->assertSame(2000.0, $rateInfo['daily_rate']);
        $this->assertSame('Fixed', $rateInfo['divisor_mode']);
        $this->assertSame(31, $rateInfo['days_in_month']);
    }
}
