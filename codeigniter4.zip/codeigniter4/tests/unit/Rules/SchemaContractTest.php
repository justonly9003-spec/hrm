<?php

namespace Tests\Unit\Rules;

use App\Services\Rules\RuleParamValidator;
use App\Services\Rules\RuleResolver;
use App\Services\Rules\RuleSchemaRegistry;
use PHPUnit\Framework\TestCase;

class SchemaContractTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        if (function_exists('session')) {
            try {
                \Config\Services::session()->destroy();
            } catch (\Throwable $e) {}
        }
        if (isset($_SESSION)) {
            $_SESSION = [];
        }
        if (class_exists(\Config\Services::class)) {
            try {
                \Config\Services::reset(true);
            } catch (\Throwable $e) {}
        }
        RuleResolver::flush(true);
        RuleResolver::resetMemo();
        RuleSchemaRegistry::init();
    }

    protected function tearDown(): void
    {
        RuleResolver::flush(true);
        RuleResolver::resetMemo();
        if (function_exists('session')) {
            try {
                \Config\Services::session()->destroy();
            } catch (\Throwable $e) {}
        }
        if (isset($_SESSION)) {
            $_SESSION = [];
        }
        if (class_exists(\Config\Services::class)) {
            try {
                \Config\Services::reset(true);
            } catch (\Throwable $e) {}
        }
        parent::tearDown();
    }

    /**
     * Helper to load all PHP files from given directories relative to APPPATH or __DIR__
     *
     * @param array<string> $directories
     * @return array<string, string> filepath => file contents
     */
    protected function loadEngineCode(array $directories): array
    {
        $base = defined('APPPATH') ? APPPATH : dirname(__DIR__, 2) . '/app/';
        $files = [];

        foreach ($directories as $dir) {
            $path = rtrim($base, '/\\') . '/' . trim($dir, '/\\');
            if (!is_dir($path)) {
                continue;
            }

            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($path, \FilesystemIterator::SKIP_DOTS)
            );

            foreach ($iterator as $file) {
                if ($file->isFile() && $file->getExtension() === 'php') {
                    $files[$file->getPathname()] = file_get_contents($file->getPathname());
                }
            }
        }

        return $files;
    }

    /**
     * Requirement 1a: For every param in RuleSchema.json, assert the seeder writes it.
     */
    public function testSeederWritesEveryParam(): void
    {
        $domains = RuleSchemaRegistry::domains();
        $this->assertNotEmpty($domains, "Schema domains must not be empty.");

        foreach ($domains as $domain) {
            $params = RuleSchemaRegistry::params($domain);
            $seedValues = RuleSchemaRegistry::seedValues($domain);

            foreach ($params as $param) {
                $key = $param['key'] ?? '';
                $this->assertNotEmpty($key, "Parameter key in domain {$domain} must not be empty.");

                $this->assertArrayHasKey(
                    $key,
                    $seedValues,
                    "RuleSeeder must write seed value for domain '{$domain}' param '{$key}'."
                );
            }
        }
    }

    /**
     * Requirement 1b: For every param in RuleSchema.json, assert the validator accepts a valid value.
     */
    public function testValidatorAcceptsValidValueForEveryParam(): void
    {
        $domains = RuleSchemaRegistry::domains();

        foreach ($domains as $domain) {
            $params = RuleSchemaRegistry::params($domain);

            foreach ($params as $param) {
                $key = $param['key'];
                $seedVal = $param['seed'] ?? null;

                // Validate single parameter override (partial mode = true)
                $result = RuleParamValidator::validate($domain, 'Company', [$key => $seedVal], true);

                $this->assertArrayNotHasKey(
                    $key,
                    $result['errors'] ?? [],
                    "RuleParamValidator must accept valid seed value for '{$domain}.{$key}'. Errors: " . json_encode($result['errors'] ?? [])
                );

                $this->assertTrue(
                    $result['valid'],
                    "RuleParamValidator validation must be valid for '{$domain}.{$key}'."
                );
            }
        }
    }

    /**
     * Requirement 1c: Assert that at least one engine class in app/Services or app/Libraries
     * references every param key. A param with no consumer fails the test.
     */
    public function testEveryParamHasAtLeastOneEngineConsumer(): void
    {
        $engineFiles = $this->loadEngineCode(['Services', 'Libraries']);
        $this->assertNotEmpty($engineFiles, "Engine code files in Services/Libraries must be found.");

        $combinedCode = implode("\n", array_values($engineFiles));
        $missingConsumers = [];

        $domains = RuleSchemaRegistry::domains();
        foreach ($domains as $domain) {
            $params = RuleSchemaRegistry::params($domain);

            foreach ($params as $param) {
                $key = $param['key'];

                // Check for ->get('key'), ->get("key"), ['key'], ["key"], 'key', "key"
                $pattern = "/(?:->get\(\s*['\"]" . preg_quote($key, '/') . "['\"]\)|['\"]" . preg_quote($key, '/') . "['\"])/";

                if (!preg_match($pattern, $combinedCode)) {
                    $missingConsumers[] = "{$domain}.{$key}";
                }
            }
        }

        $this->assertEmpty(
            $missingConsumers,
            "Every param in RuleSchema.json must have at least one consumer in app/Services or app/Libraries. Missing: " . implode(', ', $missingConsumers)
        );
    }

    /**
     * Requirement 2: Assert no service under app/Services and app/Libraries contains
     * ?? <number> or ?? '<literal>' applied to a variable named like a rule param,
     * unless explicitly permitted in fallback_allowlist.json with a valid reason.
     */
    public function testNoUnallowlistedLiteralFallbacksInServices(): void
    {
        $allowlistPath = __DIR__ . '/fallback_allowlist.json';
        $this->assertFileExists($allowlistPath, "fallback_allowlist.json must exist in tests/unit/Rules/");

        $allowlistJson = file_get_contents($allowlistPath);
        $allowlistData = json_decode($allowlistJson, true);
        $this->assertIsArray($allowlistData, "fallback_allowlist.json must contain a valid JSON array.");

        // Build set of allowlisted signatures and ensure all have non-empty reason
        $allowlistSnippets = [];
        foreach ($allowlistData as $entry) {
            $this->assertNotEmpty($entry['reason'] ?? '', "Allowlist entry must have a non-empty reason: " . json_encode($entry));
            if (!empty($entry['code_snippet'])) {
                $allowlistSnippets[trim($entry['code_snippet'])] = $entry['reason'];
            }
        }

        // Collect all schema rule keys
        $allRuleKeys = [];
        foreach (RuleSchemaRegistry::domains() as $domain) {
            foreach (RuleSchemaRegistry::params($domain) as $param) {
                $allRuleKeys[$param['key']] = true;
            }
        }

        $engineFiles = $this->loadEngineCode(['Services', 'Libraries']);
        $violations = [];

        foreach ($engineFiles as $filePath => $content) {
            $relPath = str_replace('\\', '/', $filePath);
            $lines = explode("\n", $content);

            foreach ($lines as $lineIndex => $line) {
                $trimmedLine = trim($line);

                // Check for ?? <number> or ?? '<literal>' or ?? "<literal>"
                if (preg_match('/\?\?\s*(-?[0-9]+(?:\.[0-9]+)?|[\'"][^\'"]*[\'"])/', $line, $matches)) {
                    // Check if line references a rule parameter key
                    $matchedKey = null;
                    foreach (array_keys($allRuleKeys) as $k) {
                        $keyPattern = '/([\$\'\"\[\->]' . preg_quote($k, '/') . '[\'\"\]]|\b' . preg_quote($k, '/') . '\b)/';
                        if (preg_match($keyPattern, $line)) {
                            $matchedKey = $k;
                            break;
                        }
                    }

                    if ($matchedKey !== null) {
                        // Must be in allowlist
                        if (!isset($allowlistSnippets[$trimmedLine])) {
                            $violations[] = [
                                'file'     => $relPath,
                                'line'     => $lineIndex + 1,
                                'key'      => $matchedKey,
                                'fallback' => $matches[1],
                                'code'     => $trimmedLine,
                            ];
                        }
                    }
                }
            }
        }

        $this->assertEmpty(
            $violations,
            "Found unallowlisted literal fallback(s) on rule parameters: " . json_encode($violations, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)
        );
    }

    /**
     * Contract test: verify that every Views/rules/domains/*.php template
     * uses only valid formParams keys and valid static enum <option value>s matching RuleSchema.json
     */
    public function testDomainViewsFormParamsAndSelectOptionsConformToSchema()
    {
        $schemaPath = APPPATH . 'Config/RuleSchema.json';
        $this->assertFileExists($schemaPath);
        $schemaData = json_decode(file_get_contents($schemaPath), true);
        $this->assertIsArray($schemaData);
        $domains = $schemaData['domains'] ?? [];

        $viewsDir = APPPATH . 'Views/rules/domains';
        $this->assertDirectoryExists($viewsDir);
        $domainFiles = glob($viewsDir . '/*.php');
        $this->assertNotEmpty($domainFiles, "No domain view files found in {$viewsDir}");

        $invalidKeysFound = [];
        $invalidOptionsFound = [];

        foreach ($domainFiles as $file) {
            $baseName = basename($file, '.php');
            $domainUpper = strtoupper($baseName);
            $this->assertArrayHasKey($domainUpper, $domains, "Domain file {$baseName}.php has no matching domain in RuleSchema.json");

            $domainDef = $domains[$domainUpper];
            $validKeys = [];
            $enumOptions = [];
            foreach ($domainDef['params'] as $p) {
                $validKeys[$p['key']] = true;
                if ($p['type'] === 'enum' && isset($p['options']) && is_array($p['options'])) {
                    $enumOptions[$p['key']] = $p['options'];
                }
            }

            $content = file_get_contents($file);

            // 1. Check formParams keys
            // Pattern matches formParams['key'] or formParams["key"] or formParams.key
            if (preg_match_all('/formParams\[[\'\"]([a-zA-Z0-9_]+)[\'\"]\]/', $content, $matches1)) {
                foreach ($matches1[1] as $k) {
                    if (!isset($validKeys[$k])) {
                        $invalidKeysFound[] = [
                            'file' => basename($file),
                            'domain' => $domainUpper,
                            'invalid_key' => $k,
                        ];
                    }
                }
            }
            if (preg_match_all('/formParams\.([a-zA-Z0-9_]+)/', $content, $matches2)) {
                foreach ($matches2[1] as $k) {
                    if (!isset($validKeys[$k])) {
                        $invalidKeysFound[] = [
                            'file' => basename($file),
                            'domain' => $domainUpper,
                            'invalid_key' => $k,
                        ];
                    }
                }
            }

            // 2. Check static <option value="..."> inside <select ... x-model="formParams[.key]">
            $selectPattern = '/<select[^>]*x-model=[\'\"](?:formParams\.|formParams\[[\'\"])([a-zA-Z0-9_]+)[\'\"]?[\'\"][^>]*>(.*?)<\/select>/s';
            if (preg_match_all($selectPattern, $content, $selectMatches, PREG_SET_ORDER)) {
                foreach ($selectMatches as $sm) {
                    $paramKey = $sm[1];
                    $selectBody = $sm[2];

                    if (isset($enumOptions[$paramKey])) {
                        $allowed = $enumOptions[$paramKey];
                        if (preg_match_all('/<option[^>]*value=[\'\"]([^\'\"]*)[\'\"]/', $selectBody, $optMatches)) {
                            foreach ($optMatches[1] as $val) {
                                if (!in_array($val, $allowed, true)) {
                                    $invalidOptionsFound[] = [
                                        'file' => basename($file),
                                        'domain' => $domainUpper,
                                        'param_key' => $paramKey,
                                        'invalid_option' => $val,
                                        'allowed_options' => $allowed,
                                    ];
                                }
                            }
                        }
                    }
                }
            }
        }

        $this->assertEmpty(
            $invalidKeysFound,
            "Found invalid formParams keys not present in RuleSchema.json: " . json_encode($invalidKeysFound, JSON_PRETTY_PRINT)
        );

        $this->assertEmpty(
            $invalidOptionsFound,
            "Found static option values not in RuleSchema.json enum options: " . json_encode($invalidOptionsFound, JSON_PRETTY_PRINT)
        );
    }
}

