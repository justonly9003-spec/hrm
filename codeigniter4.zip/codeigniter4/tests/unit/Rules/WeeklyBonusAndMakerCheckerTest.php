<?php

namespace Tests\Unit\Rules;

use App\Services\Rules\RuleSchemaRegistry;
use App\Services\Rules\FormulaEvaluator;
use App\Services\Rules\RuleResolver;
use App\Services\BonusService;
use App\Services\PayrollService;
use App\Controllers\Payroll\BonusController;
use App\Controllers\Payroll\PayrollGenerationController;
use App\Filters\PermissionFilter;
use App\Models\WeeklyBonusRecordModel;
use Config\Database;
use PHPUnit\Framework\TestCase;

// Explicitly require migration files since CodeIgniter's autoloader does not autoload timestamp-prefixed migration classes
require_once defined('APPPATH')
    ? APPPATH . 'Database/Migrations/2026-10-16-000004_AddRejectedFieldsAndHardenUniqueIndexOnBonusRecords.php'
    : __DIR__ . '/../../app/Database/Migrations/2026-10-16-000004_AddRejectedFieldsAndHardenUniqueIndexOnBonusRecords.php';
require_once defined('APPPATH')
    ? APPPATH . 'Database/Migrations/2026-10-17-000002_BackfillPfLedgerPayrollIdFromItems.php'
    : __DIR__ . '/../../app/Database/Migrations/2026-10-17-000002_BackfillPfLedgerPayrollIdFromItems.php';

use App\Database\Migrations\AddRejectedFieldsAndHardenUniqueIndexOnBonusRecords;
use App\Database\Migrations\BackfillPfLedgerPayrollIdFromItems;

/**
 * Unit Test: Weekly Attendance Bonuses, Maker-Checker Dual-Control,
 * FormulaEvaluator, and Payroll Ceiling & Linkage Invariants.
 */
class WeeklyBonusAndMakerCheckerTest extends TestCase
{
    protected array $insertedRecords = [];

    public static function setUpBeforeClass(): void
    {
        parent::setUpBeforeClass();
        static::ensureSchema();
    }

    public static function registerSqliteFunctions($db): void
    {
        try {
            $rawConn = $db->connID ?? null;
            if ($rawConn instanceof \SQLite3) {
                $rawConn->createFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
            } elseif (is_object($rawConn) && method_exists($rawConn, 'sqliteCreateFunction')) {
                $rawConn->sqliteCreateFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
            }
        } catch (\Throwable $e) {
            // ignore if not sqlite or already registered
        }
    }

    protected static function ensureSchema(): void
    {
        $db = Database::connect();
        static::registerSqliteFunctions($db);
        if (!$db->tableExists('employees')) {
            $schemaFile = __DIR__ . '/schema.sqlite.sql';
            if (file_exists($schemaFile)) {
                $sql = file_get_contents($schemaFile);
                $statements = array_filter(array_map('trim', explode(';', $sql)));
                foreach ($statements as $stmt) {
                    if (!empty($stmt)) {
                        try {
                            $db->query($stmt);
                        } catch (\Throwable $e) {
                            // ignore if already exists
                        }
                    }
                }
            }
        }
        if ($db->tableExists('employees') && !$db->fieldExists('user_id', 'employees')) {
            try {
                $db->query("ALTER TABLE employees ADD COLUMN user_id VARCHAR(36) NULL");
            } catch (\Throwable $e) {}
        }
        if ($db->tableExists('rule_definitions') && !$db->fieldExists('updated_by', 'rule_definitions')) {
            try {
                $db->query("ALTER TABLE rule_definitions ADD COLUMN updated_by VARCHAR(36) NULL");
            } catch (\Throwable $e) {}
        }
        if (!$db->tableExists('permissions')) {
            $db->query("CREATE TABLE IF NOT EXISTS permissions (
                id VARCHAR(36) PRIMARY KEY,
                module VARCHAR(50),
                action VARCHAR(50),
                name VARCHAR(100),
                code VARCHAR(100) UNIQUE,
                description TEXT,
                created_at DATETIME,
                updated_at DATETIME
            )");
        }
        if (!$db->tableExists('role_permissions')) {
            $db->query("CREATE TABLE IF NOT EXISTS role_permissions (
                id VARCHAR(64) PRIMARY KEY,
                role_id VARCHAR(36),
                permission_id VARCHAR(36),
                scope_level VARCHAR(20) DEFAULT 'company',
                created_at DATETIME
            )");
        }
        if (!$db->tableExists('user_permissions')) {
            $db->query("CREATE TABLE IF NOT EXISTS user_permissions (
                id VARCHAR(36) PRIMARY KEY,
                user_id VARCHAR(36),
                permission_id VARCHAR(36),
                is_granted TINYINT(1) DEFAULT 1,
                scope_level VARCHAR(20) DEFAULT 'company',
                expires_at DATETIME,
                created_at DATETIME
            )");
        }
    }

    protected function setUp(): void
    {
        parent::setUp();
        if (function_exists('session')) {
            try {
                \Config\Services::session()->destroy();
            } catch (\Throwable $e) {}
        }
        if (isset($_SESSION)) {
            $_SESSION = [];
        }
        if (class_exists(\Config\Services::class)) {
            try {
                \Config\Services::reset(true);
            } catch (\Throwable $e) {}
        }
        RuleResolver::flush(true);
        RuleResolver::resetMemo();
        static::ensureSchema();
        static::registerSqliteFunctions(Database::connect());
        RuleSchemaRegistry::init();
        $this->insertedRecords = [];
    }

    protected function trackInsert(string $table, string $id): void
    {
        $this->insertedRecords[$table][] = $id;
    }

    protected function tearDown(): void
    {
        $db = Database::connect();
        try {
            $refDepth = new \ReflectionProperty($db, 'transDepth');
            $refDepth->setAccessible(true);
            while ($refDepth->getValue($db) > 0) {
                $db->transRollback();
            }

            $refStatus = new \ReflectionProperty($db, 'transStatus');
            $refStatus->setAccessible(true);
            $refStatus->setValue($db, true);

            $refFail = new \ReflectionProperty($db, 'transFailure');
            $refFail->setAccessible(true);
            $refFail->setValue($db, false);
        } catch (\Throwable $e) {}
        if (!empty($this->insertedRecords)) {
            $order = [
                'user_permissions', 'role_permissions', 'users', 'roles', 'companies',
                'payroll_items', 'payrolls', 'bonus_records', 'weekly_bonus_records',
                'provident_fund_ledgers', 'provident_fund_ledger', 'employee_salaries',
                'audit_logs', 'employees', 'rule_definitions'
            ];
            foreach ($order as $table) {
                if (!empty($this->insertedRecords[$table]) && $db->tableExists($table)) {
                    try {
                        $db->table($table)->whereIn('id', array_unique($this->insertedRecords[$table]))->delete();
                    } catch (\Throwable $e) {
                        // ignore cleanup errors on cascade
                    }
                    unset($this->insertedRecords[$table]);
                }
            }
            foreach ($this->insertedRecords as $table => $ids) {
                if (!empty($ids) && $db->tableExists($table)) {
                    try {
                        $db->table($table)->whereIn('id', array_unique($ids))->delete();
                    } catch (\Throwable $e) {
                        // ignore cleanup errors
                    }
                }
            }
            $this->insertedRecords = [];
        }
        RuleResolver::flush(true);
        RuleResolver::resetMemo();
        if (function_exists('session')) {
            try {
                \Config\Services::session()->destroy();
            } catch (\Throwable $e) {}
        }
        if (isset($_SESSION)) {
            $_SESSION = [];
        }
        if (class_exists(\Config\Services::class)) {
            try {
                \Config\Services::reset(true);
            } catch (\Throwable $e) {}
        }
        parent::tearDown();
    }

    // -------------------------------------------------------------------------
    // Insertion & Context Helpers
    // -------------------------------------------------------------------------

    private function insertEmployee(string $companyId, array $overrides = []): string
    {
        $db = Database::connect();
        $id = $overrides['id'] ?? ('emp-test-' . bin2hex(random_bytes(4)));
        $data = array_merge([
            'id'           => $id,
            'company_id'   => $companyId,
            'first_name'   => 'Test',
            'last_name'    => 'Employee',
            'email'        => 'emp.' . bin2hex(random_bytes(3)) . '@example.com',
            'status'       => 'Active',
            'joining_date' => '2024-01-01',
            'created_at'   => date('Y-m-d H:i:s'),
        ], $overrides);
        $data['id'] = $id;
        $db->table('employees')->insert($data);
        $this->trackInsert('employees', $id);
        return $id;
    }

    private function insertBonusRecord(string $companyId, string $employeeId, array $overrides = []): string
    {
        $db = Database::connect();
        $id = $overrides['id'] ?? ('bon-test-' . bin2hex(random_bytes(4)));
        $data = array_merge([
            'id'                    => $id,
            'company_id'            => $companyId,
            'employee_id'           => $employeeId,
            'amount'                => 5000.00,
            'bonus_month'           => 'October',
            'year'                  => 2026,
            'status'                => 'Pending',
            'is_settled_in_payroll' => 0,
            'created_at'            => date('Y-m-d H:i:s'),
        ], $overrides);
        $data['id'] = $id;
        $db->table('bonus_records')->insert($data);
        $this->trackInsert('bonus_records', $id);
        return $id;
    }

    private function insertWeeklyBonusRecord(string $companyId, string $employeeId, array $overrides = []): string
    {
        $db = Database::connect();
        $id = $overrides['id'] ?? ('wb-test-' . bin2hex(random_bytes(4)));
        $data = array_merge([
            'id'              => $id,
            'company_id'      => $companyId,
            'employee_id'     => $employeeId,
            'week_start_date' => '2026-10-01',
            'week_end_date'   => '2026-10-07',
            'bonus_amount'    => 1200.00,
            'is_eligible'     => 1,
            'status'          => 'Pending',
            'created_at'      => date('Y-m-d H:i:s'),
        ], $overrides);
        $data['id'] = $id;
        $db->table('weekly_bonus_records')->insert($data);
        $this->trackInsert('weekly_bonus_records', $id);
        return $id;
    }

    private function insertSalary(string $companyId, string $employeeId, float $gross = 60000.0, float $basic = 40000.0): ?string
    {
        $db = Database::connect();
        if (!$db->tableExists('employee_salaries')) {
            return null;
        }
        $id = 'sal-test-' . bin2hex(random_bytes(6));
        $db->table('employee_salaries')->insert([
            'id'             => $id,
            'employee_id'    => $employeeId,
            'company_id'     => $companyId,
            'basic_salary'   => $basic,
            'gross_salary'   => $gross,
            'effective_date' => '2024-01-01',
            'status'         => 'Active',
            'created_at'     => date('Y-m-d H:i:s'),
        ]);
        $this->trackInsert('employee_salaries', $id);
        return $id;
    }

    private function insertPayrollBasicsRule(string $companyId): string
    {
        $db = Database::connect();
        $id = 'rd-test-' . bin2hex(random_bytes(6));
        $db->table('rule_definitions')->insert([
            'id'             => $id,
            'company_id'     => $companyId,
            'domain'         => 'PAYROLL_BASICS',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2025-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'currency_code' => 'BDT',
                'pay_cycle'     => 'Monthly',
            ]),
            'schema_version' => 1,
            'change_reason'  => 'Test Payroll Basics Rule',
            'created_at'     => date('Y-m-d H:i:s'),
            'updated_at'     => date('Y-m-d H:i:s'),
        ]);
        $this->trackInsert('rule_definitions', $id);
        RuleResolver::resetMemo();
        return $id;
    }

    private function insertPayrollBatch(string $companyId, string $payrollMonth, array $overrides = []): string
    {
        $db = Database::connect();
        $id = $overrides['id'] ?? ('pay-test-' . bin2hex(random_bytes(6)));
        $data = array_merge([
            'id'            => $id,
            'company_id'    => $companyId,
            'payroll_month' => $payrollMonth,
            'status'        => 'Draft',
            'is_locked'     => 0,
            'created_at'    => date('Y-m-d H:i:s'),
        ], $overrides);
        $data['id'] = $id;
        $db->table('payrolls')->insert($data);
        $this->trackInsert('payrolls', $id);
        return $id;
    }

    /**
     * Helper to initialize a BonusController instance with mock session, user context, and AJAX headers
     */
    private function createInitializedBonusController(string $companyId, string $userId = 'usr-admin-001', array $extraUser = []): BonusController
    {
        $db = Database::connect();

        // 1. Ensure company row exists
        $comp = $db->table('companies')->where('id', $companyId)->get()->getRowArray();
        if (!$comp) {
            $db->table('companies')->insert([
                'id'         => $companyId,
                'name'       => 'Test Company ' . substr($companyId, -8),
                'status'     => 'Active',
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            $this->trackInsert('companies', $companyId);
        }

        // 2. Ensure role row exists in DB
        $roleName = $extraUser['role'] ?? 'Bonus Approver';
        $roleCode = $extraUser['role_code'] ?? 'BONUS_APPROVER';
        $roleId   = $extraUser['role_id'] ?? ('role-' . substr(md5($companyId . '-' . $roleCode), 0, 16));

        $roleRow = $db->table('roles')->where('id', $roleId)->get()->getRowArray();
        if (!$roleRow) {
            $db->table('roles')->insert([
                'id'         => $roleId,
                'name'       => $roleName,
                'code'       => $roleCode,
                'company_id' => $companyId,
                'status'     => 'Active',
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            $this->trackInsert('roles', $roleId);
        }

        // 3. Ensure user row exists in DB
        $userRow = $db->table('users')->where('id', $userId)->get()->getRowArray();
        $userDataToDb = [
            'id'          => $userId,
            'company_id'  => $companyId,
            'role_id'     => $roleId,
            'username'    => $extraUser['username'] ?? ($userId . '_user'),
            'email'       => $extraUser['email'] ?? ($userId . '@test.example.com'),
            'status'      => 'Active',
            'created_at'  => date('Y-m-d H:i:s'),
        ];
        if (!$userRow) {
            $db->table('users')->insert($userDataToDb);
            $this->trackInsert('users', $userId);
        } else {
            $db->table('users')->where('id', $userId)->update($userDataToDb);
        }

        // 4. Grant bonus.view / bonus.create / bonus.approve / bonus.edit / bonus.delete (routes at app/Config/Routes.php lines 436-452)
        $permsToGrant = [
            'bonus.view',
            'bonus.create',
            'bonus.approve',
            'bonus.edit',
            'bonus.delete',
        ];
        if (!empty($extraUser['permissions']) && is_array($extraUser['permissions'])) {
            $permsToGrant = array_values(array_unique(array_merge($permsToGrant, $extraUser['permissions'])));
        }

        foreach ($permsToGrant as $pCode) {
            $pRow = $db->table('permissions')->where('code', $pCode)->get()->getRowArray();
            if (!$pRow) {
                $parts = explode('.', $pCode);
                $mod = $parts[0];
                $act = $parts[1] ?? 'view';
                $pId = 'perm-' . str_replace('.', '-', $pCode);
                $db->table('permissions')->insert([
                    'id'          => $pId,
                    'module'      => $mod,
                    'action'      => $act,
                    'name'        => $pCode,
                    'code'        => $pCode,
                    'created_at'  => date('Y-m-d H:i:s'),
                ]);
                $pRow = ['id' => $pId];
            }

            $permId = $pRow['id'];

            // Grant via user_permissions
            $upExists = $db->table('user_permissions')
                ->where('user_id', $userId)
                ->where('permission_id', $permId)
                ->get()->getRowArray();
            if (!$upExists) {
                $upId = 'up-' . bin2hex(random_bytes(6));
                $db->table('user_permissions')->insert([
                    'id'            => $upId,
                    'user_id'       => $userId,
                    'permission_id' => $permId,
                    'is_granted'    => 1,
                    'scope_level'   => 'company',
                    'created_at'    => date('Y-m-d H:i:s'),
                ]);
                $this->trackInsert('user_permissions', $upId);
            }

            // Grant via role_permissions
            $rpExists = $db->table('role_permissions')
                ->where('role_id', $roleId)
                ->where('permission_id', $permId)
                ->get()->getRowArray();
            if (!$rpExists) {
                $rpId = 'rp-' . bin2hex(random_bytes(6));
                $db->table('role_permissions')->insert([
                    'id'            => $rpId,
                    'role_id'       => $roleId,
                    'permission_id' => $permId,
                    'scope_level'   => 'company',
                    'created_at'    => date('Y-m-d H:i:s'),
                ]);
                $this->trackInsert('role_permissions', $rpId);
            }
        }
        \App\Services\PermissionService::clearCache();
        \App\Services\PermissionService::flushCache();

        // 5. Set session user_id BEFORE initController
        $session = \Config\Services::session();
        $sessionData = array_merge([
            'id'          => $userId,
            'user_id'     => $userId,
            'username'    => $userDataToDb['username'],
            'name'        => $extraUser['name'] ?? ('User ' . $userId),
            'email'       => $userDataToDb['email'],
            'role'        => $roleName,
            'role_code'   => $roleCode,
            'role_id'     => $roleId,
            'company_id'  => $companyId,
            'permissions' => $permsToGrant,
        ], $extraUser);
        $session->set($sessionData);

        // 6. Build controller and call initController
        $_SERVER['HTTP_X_REQUESTED_WITH'] = 'xmlhttprequest';
        $request = \Config\Services::request();
        if (method_exists($request, 'setHeader')) {
            $request->setHeader('X-Requested-With', 'xmlhttprequest');
        }
        $response = \Config\Services::response();
        if (method_exists($response, 'setStatusCode')) {
            $response->setStatusCode(200);
        }
        $logger   = \Config\Services::logger();

        $controller = new BonusController();
        $controller->initController($request, $response, $logger);

        // 7. Make sure BaseController::currentUser() (line 75) returns that user
        $resolvedUser = $controller->currentUser();
        $this->assertNotNull($resolvedUser, 'currentUser() must return authenticated user');
        $this->assertEquals($userId, $resolvedUser['id']);

        return $controller;
    }

    /**
     * Helper to initialize a PayrollGenerationController instance
     */
    private function createInitializedPayrollGenerationController(string $companyId, string $userId = 'usr-admin-001', array $permissions = ['payroll.view', 'payroll.approve', 'payroll.delete']): PayrollGenerationController
    {
        $db = Database::connect();

        $comp = $db->table('companies')->where('id', $companyId)->get()->getRowArray();
        if (!$comp) {
            $db->table('companies')->insert([
                'id'         => $companyId,
                'name'       => 'Test Company ' . substr($companyId, -8),
                'status'     => 'Active',
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            $this->trackInsert('companies', $companyId);
        }

        $roleName = 'Payroll Operator';
        $roleCode = 'PAYROLL_OPERATOR';
        $roleId   = 'role-' . substr(md5($companyId . '-' . $roleCode), 0, 16);

        $roleRow = $db->table('roles')->where('id', $roleId)->get()->getRowArray();
        if (!$roleRow) {
            $db->table('roles')->insert([
                'id'         => $roleId,
                'name'       => $roleName,
                'code'       => $roleCode,
                'company_id' => $companyId,
                'status'     => 'Active',
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            $this->trackInsert('roles', $roleId);
        }

        $userRow = $db->table('users')->where('id', $userId)->get()->getRowArray();
        $userDataToDb = [
            'id'          => $userId,
            'company_id'  => $companyId,
            'role_id'     => $roleId,
            'username'    => $userId . '_user',
            'email'       => $userId . '@test.example.com',
            'status'      => 'Active',
            'created_at'  => date('Y-m-d H:i:s'),
        ];
        if (!$userRow) {
            $db->table('users')->insert($userDataToDb);
            $this->trackInsert('users', $userId);
        } else {
            $db->table('users')->where('id', $userId)->update($userDataToDb);
        }

        // Grant only the specified permissions
        foreach ($permissions as $pCode) {
            $pRow = $db->table('permissions')->where('code', $pCode)->get()->getRowArray();
            if (!$pRow) {
                $parts = explode('.', $pCode);
                $mod = $parts[0];
                $act = $parts[1] ?? 'view';
                $pId = 'perm-' . str_replace('.', '-', $pCode);
                $db->table('permissions')->insert([
                    'id'          => $pId,
                    'module'      => $mod,
                    'action'      => $act,
                    'name'        => $pCode,
                    'code'        => $pCode,
                    'created_at'  => date('Y-m-d H:i:s'),
                ]);
                $pRow = ['id' => $pId];
            }

            $permId = $pRow['id'];
            $upExists = $db->table('user_permissions')
                ->where('user_id', $userId)
                ->where('permission_id', $permId)
                ->get()->getRowArray();
            if (!$upExists) {
                $upId = 'up-' . bin2hex(random_bytes(6));
                $db->table('user_permissions')->insert([
                    'id'            => $upId,
                    'user_id'       => $userId,
                    'permission_id' => $permId,
                    'is_granted'    => 1,
                    'scope_level'   => 'company',
                    'created_at'    => date('Y-m-d H:i:s'),
                ]);
                $this->trackInsert('user_permissions', $upId);
            }
        }
        \App\Services\PermissionService::clearCache();
        \App\Services\PermissionService::flushCache();

        $session = \Config\Services::session();
        $sessionData = [
            'id'          => $userId,
            'user_id'     => $userId,
            'username'    => $userDataToDb['username'],
            'name'        => 'Payroll User ' . $userId,
            'email'       => $userDataToDb['email'],
            'role'        => $roleName,
            'role_code'   => $roleCode,
            'role_id'     => $roleId,
            'company_id'  => $companyId,
            'permissions' => $permissions,
        ];
        $session->set($sessionData);

        $_SERVER['HTTP_X_REQUESTED_WITH'] = 'xmlhttprequest';
        $request = \Config\Services::request();
        if (method_exists($request, 'setHeader')) {
            $request->setHeader('X-Requested-With', 'xmlhttprequest');
        }
        $response = \Config\Services::response();
        $logger   = \Config\Services::logger();

        $controller = new PayrollGenerationController();
        $controller->initController($request, $response, $logger);

        return $controller;
    }

    /**
     * Helper to simulate an AJAX POST request on the controller
     */
    private function setRequestPost($controller, array $postData): void
    {
        $_SERVER['HTTP_X_REQUESTED_WITH'] = 'xmlhttprequest';
        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_POST = $postData;

        $request = \Config\Services::request();
        if (method_exists($request, 'setHeader')) {
            $request->setHeader('X-Requested-With', 'xmlhttprequest');
        }
        if (method_exists($request, 'setGlobal')) {
            $request->setGlobal('post', $postData);
        }
        $refReq = new \ReflectionProperty(\App\Controllers\BaseController::class, 'request');
        $refReq->setAccessible(true);
        $refReq->setValue($controller, $request);
    }

    // -------------------------------------------------------------------------
    // Tests
    // -------------------------------------------------------------------------

    /**
     * 1. Weekly Bonus Record model allows approved_by, approved_at, rejected_by, rejected_at, and rejection_reason
     */
    public function testWeeklyBonusRecordModelAllowedFields()
    {
        $model = new WeeklyBonusRecordModel();
        $ref = new \ReflectionClass($model);
        $prop = $ref->getProperty('allowedFields');
        $prop->setAccessible(true);
        $fields = $prop->getValue($model);

        $this->assertContains('approved_by', $fields, 'approved_by must be in allowedFields');
        $this->assertContains('approved_at', $fields, 'approved_at must be in allowedFields');
        $this->assertContains('rejected_by', $fields, 'rejected_by must be in allowedFields');
        $this->assertContains('rejected_at', $fields, 'rejected_at must be in allowedFields');
        $this->assertContains('rejection_reason', $fields, 'rejection_reason must be in allowedFields');
        $this->assertContains('payroll_id', $fields, 'payroll_id must be in allowedFields');
        $this->assertContains('status', $fields, 'status must be in allowedFields');
        $this->assertContains('deleted_at', $fields, 'deleted_at must be in allowedFields');
        $this->assertContains('payout_month', $fields, 'payout_month must be in allowedFields');
        $this->assertContains('swept_by', $fields, 'swept_by must be in allowedFields');
        $this->assertContains('swept_at', $fields, 'swept_at must be in allowedFields');
        $this->assertContains('swept_reason', $fields, 'swept_reason must be in allowedFields');
    }

    /**
     * 2. FormulaEvaluator executes real mathematical formulas, parentheses, precedence, and variable substitution
     */
    public function testFormulaEvaluatorCalculations()
    {
        $res1 = FormulaEvaluator::evaluate('BASIC * 0.50', ['BASIC' => 30000]);
        $this->assertEquals(15000.00, $res1);

        $res2 = FormulaEvaluator::evaluate('BASIC * 0.10 + 500', ['BASIC' => 20000]);
        $this->assertEquals(2500.00, $res2);

        $res3 = FormulaEvaluator::evaluate('(BASIC + HRA) * 0.20', ['BASIC_SALARY' => 20000, 'HOUSE_RENT' => 10000]);
        $this->assertEquals(6000.00, $res3);

        $res3b = FormulaEvaluator::evaluate('(BASIC_SALARY + HOUSE_RENT + MED + TRANSPORT) * 0.10', [
            'BASIC'      => 20000,
            'HRA'        => 10000,
            'MEDICAL'    => 5000,
            'CONVEYANCE' => 5000,
        ]);
        $this->assertEquals(4000.00, $res3b);

        // Unary minus before parentheses: 2 * -(3+1) must equal -8
        $this->assertEquals(-8.0, FormulaEvaluator::evaluate('2 * -(3+1)'));

        // Right-associative exponentiation: 2 ^ 3 ^ 2 = 2 ^ 9 = 512
        $this->assertEquals(512.0, FormulaEvaluator::evaluate('2 ^ 3 ^ 2'));

        // Small float value formatted without scientific notation
        $this->assertEquals(1.0, FormulaEvaluator::evaluate('SMALL_VAL * 100000', ['SMALL_VAL' => 0.00001]));

        // Unknown variable throws InvalidArgumentException
        $this->expectException(\InvalidArgumentException::class);
        FormulaEvaluator::evaluate('UNKNOWN_VAR * 0.10', ['BASIC' => 10000]);
    }

    /**
     * 3. PayrollService Statutory 50% Deduction Ceiling Engine
     */
    public function testPayrollServiceStatutoryDeductionCeiling()
    {
        $service = new PayrollService();
        $gross = 100000.00;
        $requested = [
            'tax'      => 15000.00,
            'pf'       => 10000.00,
            'lop'      => 5000.00,
            'advance'  => 10000.00,
            'loan'     => 15000.00,
            'other'    => 5000.00,
        ];

        $result = $service->applyStatutoryDeductionCeiling($gross, $requested, 0.50);

        $this->assertTrue($result['ceiling_breached']);
        $this->assertEquals(50000.00, $result['ceiling_amount']);
        $this->assertEquals(55000.00, $result['total_deductions']);
        $this->assertEquals(45000.00, $result['net_salary']);

        $this->assertEquals(15000.00, $result['applied']['tax']);
        $this->assertEquals(10000.00, $result['applied']['pf']);
        $this->assertEquals(5000.00, $result['applied']['lop']);
        $this->assertEquals(10000.00, $result['applied']['advance']);
        $this->assertEquals(15000.00, $result['applied']['loan']);
        $this->assertEquals(0.00, $result['applied']['other']);

        $this->assertEquals(0.00, $result['unapplied']['lop']);
        $this->assertEquals(0.00, $result['unapplied']['loan']);
        $this->assertEquals(5000.00, $result['unapplied']['other']);
    }

    /**
     * 4. BonusService batch disbursal requires explicit scheme identification
     */
    public function testBonusServiceBatchRequiresExplicitScheme()
    {
        $bonusService = new BonusService();
        $paramsMissingScheme = [
            'company_id' => 'comp-test-01',
            'month'      => 'October',
            'year'       => 2026,
            'target'     => 'all',
        ];

        $res = $bonusService->generateBonusBatch($paramsMissingScheme, ['id' => 'usr-test', 'company_id' => 'comp-test-01']);
        $this->assertFalse($res['success']);
        $this->assertEquals(422, $res['code']);
        $this->assertStringContainsString('scheme', strtolower($res['message']));
    }

    /**
     * 5. Stuck bonus detection calculates authoritative 12-month cutoff dates
     */
    public function testPayrollServiceStuckBonusesCutoffDates()
    {
        $service = new PayrollService();
        $res = $service->getStuckBonuses('comp-test-empty', '2026-10-15');

        $this->assertEquals('2025-10-01', $res['cutoff_date']);
        $this->assertEquals('2025-10', $res['cutoff_period']);
        $this->assertIsArray($res['regular']);
        $this->assertIsArray($res['weekly']);
        $this->assertEquals(0, $res['total_count']);
        $this->assertEquals(0.0, $res['total_amount']);
    }

    /**
     * 6. Segregation of Duties: Maker-checker policy prohibits the officer who swept from approving
     */
    public function testMakerCheckerSweptBySegregationOfDuties()
    {
        $db = Database::connect();
        $bonusService = new BonusService();

        $companyId = 'comp-mc-' . bin2hex(random_bytes(4));
        $empId = $this->insertEmployee($companyId, ['first_name' => 'Tariq', 'last_name' => 'Islam']);
        $bonusId = $this->insertBonusRecord($companyId, $empId, [
            'amount'       => 5000.00,
            'bonus_month'  => 'October',
            'year'         => 2026,
            'status'       => 'Pending',
            'created_by'   => 'usr-creator-001',
            'swept_by'     => 'usr-sweeper-001 (Audit Officer)',
            'swept_at'     => date('Y-m-d H:i:s'),
            'swept_reason' => 'Audited monthly sweep',
        ]);

        // 1. Sweeping officer attempts approval -> MUST be rejected with 403
        $resSweeper = $bonusService->approveBonusRecord($bonusId, $companyId, ['id' => 'usr-sweeper-001', 'name' => 'Audit Officer']);
        $this->assertFalse($resSweeper['success'], 'Sweeping officer must not be permitted to approve swept bonus');
        $this->assertEquals(403, $resSweeper['code']);
        $this->assertStringContainsString('Maker-checker policy prohibits the officer who scheduled the sweep from approving it', $resSweeper['message']);

        // 2. A second authorized officer attempts approval -> MUST succeed
        $resChecker = $bonusService->approveBonusRecord($bonusId, $companyId, ['id' => 'usr-checker-002', 'name' => 'Second Approver']);
        $this->assertTrue($resChecker['success'], 'A second authorized officer must be permitted to approve');
        $this->assertEquals(200, $resChecker['code']);

        $updatedRec = $db->table('bonus_records')->where('id', $bonusId)->get()->getRowArray();
        $this->assertEquals('Approved', $updatedRec['status']);
        $this->assertStringContainsString('usr-checker-002', (string)$updatedRec['approved_by']);
    }

    /**
     * 7. Target payout month validation rejects past months and upper bound violations
     */
    public function testTargetPayoutMonthRejectsPastMonths()
    {
        $db = Database::connect();
        $companyId = 'comp-tm-' . bin2hex(random_bytes(4));
        $empId = $this->insertEmployee($companyId, ['first_name' => 'Karim', 'last_name' => 'Chowdhury']);
        $bonusId = $this->insertBonusRecord($companyId, $empId, [
            'amount'      => 7500.00,
            'bonus_month' => 'October',
            'year'        => 2026,
            'status'      => 'Pending',
        ]);

        $controller = $this->createInitializedBonusController($companyId, 'usr-approver-999');

        // 1. Past month
        $pastMonth = date('Y-m', strtotime('-1 month'));
        $this->setRequestPost($controller, [
            'id'           => $bonusId,
            'type'         => 'regular',
            'action'       => 'sweep',
            'reason'       => 'Audited sweep justification',
            'target_month' => $pastMonth,
        ]);
        $responsePast = $controller->resolveStuck();
        $this->assertEquals(422, $responsePast->getStatusCode());
        $bodyPast = json_decode($responsePast->getBody(), true);
        $this->assertFalse($bodyPast['success']);
        $this->assertStringContainsString('Target payout month cannot be in the past', $bodyPast['message']);

        // 2. Beyond 12-month upper bound
        $futureExceeded = date('Y-m', strtotime('+14 months'));
        $this->setRequestPost($controller, [
            'id'           => $bonusId,
            'type'         => 'regular',
            'action'       => 'sweep',
            'reason'       => 'Audited sweep justification',
            'target_month' => $futureExceeded,
        ]);
        $responseFuture = $controller->resolveStuck();
        $this->assertEquals(422, $responseFuture->getStatusCode());
        $bodyFuture = json_decode($responseFuture->getBody(), true);
        $this->assertFalse($bodyFuture['success']);
        $this->assertStringContainsString('cannot exceed 12 months in the future', $bodyFuture['message']);

        // 3. Valid target month within upper limit
        $validTargetMonth = date('Y-m', strtotime('+1 month'));
        $this->setRequestPost($controller, [
            'id'           => $bonusId,
            'type'         => 'regular',
            'action'       => 'sweep',
            'reason'       => 'Valid audited sweep to next month',
            'target_month' => $validTargetMonth,
        ]);
        $responseValid = $controller->resolveStuck();
        $this->assertEquals(200, $responseValid->getStatusCode());
        $bodyValid = json_decode($responseValid->getBody(), true);
        $this->assertTrue($bodyValid['success']);
        $this->assertStringContainsString('scheduled for payout in ' . $validTargetMonth, $bodyValid['message']);

        $updatedRec = $db->table('bonus_records')->where('id', $bonusId)->get()->getRowArray();
        $this->assertEquals($validTargetMonth, $updatedRec['payout_month']);
        $this->assertEquals('Pending', $updatedRec['status']);
    }

    /**
     * 8. Invariant: payout_month cannot pull bonus earlier than its month & overdue payout_month is paid
     */
    public function testPayoutMonthCannotPullBonusEarlierThanItsMonth()
    {
        $db = Database::connect();
        $payrollService = new PayrollService();

        $companyId = 'comp-pb-' . bin2hex(random_bytes(4));
        $this->insertPayrollBasicsRule($companyId);
        $empId = $this->insertEmployee($companyId, ['first_name' => 'Selim', 'last_name' => 'Reza']);
        $this->insertSalary($companyId, $empId, 60000.0, 40000.0);

        // Case A: Future bonus (December 2026) with payout_month = '2026-10' must NOT be pulled into October
        $futureBonusId = $this->insertBonusRecord($companyId, $empId, [
            'amount'                => 10000.00,
            'bonus_month'           => 'December',
            'year'                  => 2026,
            'status'                => 'Approved',
            'payout_month'          => '2026-10',
            'is_settled_in_payroll' => 0,
        ]);

        $batchOctober = $payrollService->generatePayrollBatch('2026-10', $companyId, null, 'usr-tester', false);
        $this->assertTrue($batchOctober['success'], $batchOctober['message'] ?? 'no message');
        $this->trackInsert('payrolls', $batchOctober['payroll_id']);

        $octoberItem = $db->table('payroll_items')
            ->where('payroll_id', $batchOctober['payroll_id'])
            ->where('employee_id', $empId)
            ->get()->getRowArray();
        $this->assertEquals(0.00, (float)($octoberItem['bonus_amount'] ?? $octoberItem['bonus'] ?? 0.0), 'Future December bonus must not be pulled into October payroll');

        // Case B: Overdue swept bonus (swept to October, approved in November)
        $overdueBonusId = $this->insertBonusRecord($companyId, $empId, [
            'amount'                => 15000.00,
            'bonus_month'           => 'August',
            'year'                  => 2026,
            'status'                => 'Approved',
            'payout_month'          => '2026-10',
            'is_settled_in_payroll' => 0,
        ]);

        $batchNovember = $payrollService->generatePayrollBatch('2026-11', $companyId, null, 'usr-tester', false);
        $this->assertTrue($batchNovember['success']);
        $this->trackInsert('payrolls', $batchNovember['payroll_id']);

        $novItem = $db->table('payroll_items')
            ->where('payroll_id', $batchNovember['payroll_id'])
            ->where('employee_id', $empId)
            ->get()->getRowArray();
        $this->assertEquals(15000.00, (float)($novItem['bonus_amount'] ?? $novItem['bonus'] ?? 0.0), 'Overdue swept bonus must be paid in November payroll');
    }

    /**
     * 9. getStuckBonuses returns structure containing held_deleted_regular, held_deleted_weekly, and held_deleted_count
     */
    public function testGetStuckBonusesSeparatesDeletedPayrollHolds()
    {
        $service = new PayrollService();
        $res = $service->getStuckBonuses('comp-test-empty', '2026-10-15');

        $this->assertArrayHasKey('held_deleted_regular', $res);
        $this->assertArrayHasKey('held_deleted_weekly', $res);
        $this->assertArrayHasKey('held_deleted_count', $res);
        $this->assertArrayHasKey('held_deleted_amount', $res);
        $this->assertArrayHasKey('held_regular', $res);
        $this->assertArrayHasKey('held_weekly', $res);
        $this->assertArrayHasKey('regular', $res);
        $this->assertArrayHasKey('weekly', $res);

        $this->assertEquals(0, $res['held_deleted_count']);
        $this->assertEquals(0.0, $res['held_deleted_amount']);
    }

    /**
     * 10. Real Carry-forward: A bonus swept to October is paid in November payroll batch (payout_month <= payroll_month)
     */
    public function testSweptBonusEligibilityPayoutMonthLessThanOrEqual()
    {
        $db = Database::connect();
        $payrollService = new PayrollService();

        $companyId = 'comp-cf-' . bin2hex(random_bytes(4));
        $this->insertPayrollBasicsRule($companyId);
        $empId = $this->insertEmployee($companyId, ['first_name' => 'Rafiq', 'last_name' => 'Hasan']);
        $this->insertSalary($companyId, $empId, 50000.0, 30000.0);

        // Insert bonus swept to October 2026
        $sweptBonusId = $this->insertBonusRecord($companyId, $empId, [
            'amount'                => 12500.00,
            'bonus_month'           => 'July',
            'year'                  => 2026,
            'status'                => 'Approved',
            'payout_month'          => '2026-10',
            'is_settled_in_payroll' => 0,
        ]);

        // Insert another bonus scheduled for future December 2026
        $futureBonusId = $this->insertBonusRecord($companyId, $empId, [
            'amount'                => 8000.00,
            'bonus_month'           => 'July',
            'year'                  => 2026,
            'status'                => 'Approved',
            'payout_month'          => '2026-12',
            'is_settled_in_payroll' => 0,
        ]);

        // Generate payroll batch for November 2026
        $batchNov = $payrollService->generatePayrollBatch('2026-11', $companyId, null, 'usr-tester', false);
        $this->assertTrue($batchNov['success']);
        $this->trackInsert('payrolls', $batchNov['payroll_id']);

        $itemNov = $db->table('payroll_items')
            ->where('payroll_id', $batchNov['payroll_id'])
            ->where('employee_id', $empId)
            ->get()->getRowArray();

        // The swept bonus (12500.00) must be paid because payout_month ('2026-10') <= payroll_month ('2026-11')
        // The future bonus (8000.00) must be skipped because '2026-12' > '2026-11'
        $this->assertEquals(12500.00, (float)($itemNov['bonus_amount'] ?? $itemNov['bonus'] ?? 0.0), 'Swept bonus with payout_month <= payroll_month must be paid in November batch');

        $updatedSwept = $db->table('bonus_records')->where('id', $sweptBonusId)->get()->getRowArray();
        $this->assertEquals(1, (int)$updatedSwept['is_settled_in_payroll']);

        $updatedFuture = $db->table('bonus_records')->where('id', $futureBonusId)->get()->getRowArray();
        $this->assertEquals(0, (int)$updatedFuture['is_settled_in_payroll']);
    }

    /**
     * 11. Stuck Bonus Detection: Unswept records older than 12 months require action and appear in getStuckBonuses;
     * swept records have payout_month set and are paid automatically by the next payroll (needs no action, not marked stuck).
     */
    public function testStuckBonusDetectionLogicForPassedPayoutMonths()
    {
        $payrollService = new PayrollService();

        $companyId = 'comp-stk-' . bin2hex(random_bytes(4));
        $empId = $this->insertEmployee($companyId, ['first_name' => 'Nayeem', 'last_name' => 'Chowdhury']);

        // Case A: Unswept record older than 12 months -> MUST appear in stuck list
        $oldUnsweptBonusId = $this->insertBonusRecord($companyId, $empId, [
            'amount'                => 9000.00,
            'bonus_month'           => 'January',
            'year'                  => 2025,
            'status'                => 'Approved',
            'payout_month'          => null, // Unswept
            'is_settled_in_payroll' => 0,
        ]);

        $res = $payrollService->getStuckBonuses($companyId, '2026-10-15');
        $stuckIds = array_column($res['regular'], 'id');
        $this->assertContains($oldUnsweptBonusId, $stuckIds, 'Unswept record older than 12 months must appear in stuck list');

        // Case B: Swept approved bonus (payout_month is set)
        // Under carry-forward rule, next payroll pays it automatically -> needs no action, must NOT be marked stuck
        $sweptBonusId = $this->insertBonusRecord($companyId, $empId, [
            'amount'                => 6000.00,
            'bonus_month'           => 'June',
            'year'                  => 2026,
            'status'                => 'Approved',
            'payout_month'          => '2026-08',
            'is_settled_in_payroll' => 0,
        ]);

        $resAfterSweep = $payrollService->getStuckBonuses($companyId, '2026-10-15');
        $stuckAfterIds = array_column($resAfterSweep['regular'], 'id');
        $this->assertNotContains($sweptBonusId, $stuckAfterIds, 'Swept approved bonus must not be marked as stuck because next payroll pays it automatically');
    }

    /**
     * 12. Real Controller Test: Discard Draft enforces payroll.delete permission and cleanly discards unlocked batch
     */
    public function testDiscardDraftRequiresPayrollDeleteAndRejectsApproveOnly()
    {
        $db = Database::connect();
        $companyId = 'comp-dd-' . bin2hex(random_bytes(4));
        $empId = $this->insertEmployee($companyId);

        // 1. Controller initialized with only payroll.approve (lacking payroll.delete)
        $controllerApproveOnly = $this->createInitializedPayrollGenerationController($companyId, 'usr-appr-only', ['payroll.approve', 'payroll.view']);
        $this->assertFalse($controllerApproveOnly->hasPermission('payroll.delete'), 'User with only payroll.approve must not have payroll.delete');
        $this->assertTrue($controllerApproveOnly->hasPermission('payroll.approve'));

        // 2. Controller initialized with payroll.delete discards unlocked draft batch and releases held bonus
        $controllerAuthorized = $this->createInitializedPayrollGenerationController($companyId, 'usr-del-auth', ['payroll.delete', 'payroll.view']);
        $this->assertTrue($controllerAuthorized->hasPermission('payroll.delete'));

        $draftBatchId = $this->insertPayrollBatch($companyId, '2026-10', [
            'status'    => 'Draft',
            'is_locked' => 0,
        ]);
        $heldBonusId = $this->insertBonusRecord($companyId, $empId, [
            'payroll_id' => $draftBatchId,
            'status'     => 'Approved',
        ]);

        $this->setRequestPost($controllerAuthorized, [
            'payroll_id' => $draftBatchId,
            'company_id' => $companyId,
        ]);

        $res = $controllerAuthorized->discardDraft();
        $this->assertEquals(200, $res->getStatusCode());
        $body = json_decode($res->getBody(), true);
        $this->assertTrue($body['success']);
        $this->assertStringContainsString('discarded', strtolower($body['message']));

        // Verify draft batch deleted in DB
        $deletedBatch = $db->table('payrolls')->where('id', $draftBatchId)->get()->getRowArray();
        $this->assertNull($deletedBatch, 'Draft batch must be deleted from payrolls table');

        // Verify held bonus had payroll_id cleared
        $updatedBonus = $db->table('bonus_records')->where('id', $heldBonusId)->get()->getRowArray();
        $this->assertNull($updatedBonus['payroll_id'], 'Bonus held by draft must have payroll_id cleared back to NULL');
    }

    /**
     * 13. Real Controller Test: Release hold or cancel when employee item is missing in draft allows decoupling without sync
     */
    public function testReleaseHoldWhenDraftItemMissingAllowsReleaseWithoutSync()
    {
        $db = Database::connect();
        $companyId = 'comp-im-' . bin2hex(random_bytes(4));
        $empId = $this->insertEmployee($companyId);

        // Create a draft payroll batch in DB
        $draftBatchId = $this->insertPayrollBatch($companyId, '2026-10', [
            'status'    => 'Draft',
            'is_locked' => 0,
        ]);

        $controller = $this->createInitializedBonusController($companyId, 'usr-admin-resolve');

        // ---------------------------------------------------------------------
        // Case A: Regular bonus linked to draft payroll, but employee has NO item in payroll_items
        // ---------------------------------------------------------------------
        $regBonusId = $this->insertBonusRecord($companyId, $empId, [
            'payroll_id' => $draftBatchId,
            'status'     => 'Approved',
        ]);

        $this->setRequestPost($controller, [
            'id'     => $regBonusId,
            'type'   => 'regular',
            'action' => 'release_hold',
            'reason' => 'Draft item missing hold release test',
        ]);

        $resReg = $controller->resolveStuck();
        $this->assertEquals(200, $resReg->getStatusCode());
        $bodyReg = json_decode($resReg->getBody(), true);
        $this->assertTrue($bodyReg['success']);
        $this->assertStringContainsString('without a sync (draft payroll exists but employee item was missing)', $bodyReg['message']);

        $updatedReg = $db->table('bonus_records')->where('id', $regBonusId)->get()->getRowArray();
        $this->assertNull($updatedReg['payroll_id']);

        // ---------------------------------------------------------------------
        // Case B: Cancel action with missing draft item
        // ---------------------------------------------------------------------
        $cancelBonusId = $this->insertBonusRecord($companyId, $empId, [
            'payroll_id' => $draftBatchId,
            'status'     => 'Pending',
        ]);

        $this->setRequestPost($controller, [
            'id'     => $cancelBonusId,
            'type'   => 'regular',
            'action' => 'cancel',
            'reason' => 'Draft item missing cancel test',
        ]);

        $resCancel = $controller->resolveStuck();
        $this->assertEquals(200, $resCancel->getStatusCode());
        $bodyCancel = json_decode($resCancel->getBody(), true);
        $this->assertTrue($bodyCancel['success']);
        $this->assertStringContainsString('without a sync (draft payroll exists but employee item was missing)', $bodyCancel['message']);

        $updatedCancel = $db->table('bonus_records')->where('id', $cancelBonusId)->get()->getRowArray();
        $this->assertNull($updatedCancel['payroll_id']);
        $this->assertEquals('Rejected', $updatedCancel['status']);

        // ---------------------------------------------------------------------
        // Case C: Weekly bonus with missing draft item
        // ---------------------------------------------------------------------
        $wbId = $this->insertWeeklyBonusRecord($companyId, $empId, [
            'payroll_id' => $draftBatchId,
            'status'     => 'Approved',
        ]);

        $this->setRequestPost($controller, [
            'id'     => $wbId,
            'type'   => 'weekly',
            'action' => 'release_hold',
            'reason' => 'Weekly missing item release test',
        ]);

        $resWb = $controller->resolveStuck();
        $this->assertEquals(200, $resWb->getStatusCode());
        $bodyWb = json_decode($resWb->getBody(), true);
        $this->assertTrue($bodyWb['success']);
        $this->assertStringContainsString('without a sync (draft payroll exists but employee item was missing)', $bodyWb['message']);

        $updatedWb = $db->table('weekly_bonus_records')->where('id', $wbId)->get()->getRowArray();
        $this->assertNull($updatedWb['payroll_id']);
    }

    /**
     * 14. Batch approve weekly attendance bonuses with maker-checker sweep segregation and upper bound rule
     */
    public function testBatchApproveWeeklyMakerCheckerSweepRuleInDb()
    {
        $db = Database::connect();
        $companyId = 'comp-wbmc-' . bin2hex(random_bytes(4));
        $empId = $this->insertEmployee($companyId, ['first_name' => 'Jamal', 'last_name' => 'Uddin']);

        $wbSweptId = $this->insertWeeklyBonusRecord($companyId, $empId, [
            'bonus_amount' => 1200.00,
            'status'       => 'Pending',
            'swept_by'     => 'usr-sweeper-888 (Sweep Officer)',
            'payout_month' => date('Y-m', strtotime('+1 month')),
        ]);

        $wbOtherId = $this->insertWeeklyBonusRecord($companyId, $empId, [
            'bonus_amount' => 1200.00,
            'status'       => 'Pending',
        ]);

        $wbExceededId = $this->insertWeeklyBonusRecord($companyId, $empId, [
            'bonus_amount' => 1200.00,
            'status'       => 'Pending',
            'payout_month' => date('Y-m', strtotime('+15 months')),
        ]);

        // 1. Sweeping officer usr-sweeper-888 attempts approval -> 403
        $controllerSweeper = $this->createInitializedBonusController($companyId, 'usr-sweeper-888');
        $this->setRequestPost($controllerSweeper, [
            'company_id'   => $companyId,
            'selected_ids' => [$wbSweptId],
        ]);
        $resSweeper = $controllerSweeper->batchApproveWeekly();
        $this->assertEquals(403, $resSweeper->getStatusCode());
        $bodySweeper = json_decode($resSweeper->getBody(), true);
        $this->assertFalse($bodySweeper['success']);
        $this->assertStringContainsString('Maker-checker policy prohibits the officer who scheduled the sweep from approving it', $bodySweeper['message']);

        // 2. Second approver usr-checker-999 approves -> Success
        $controllerChecker = $this->createInitializedBonusController($companyId, 'usr-checker-999');
        $this->setRequestPost($controllerChecker, [
            'company_id'   => $companyId,
            'selected_ids' => [$wbSweptId, $wbOtherId],
        ]);
        $resChecker = $controllerChecker->batchApproveWeekly();
        $this->assertEquals(200, $resChecker->getStatusCode());
        $bodyChecker = json_decode($resChecker->getBody(), true);
        $this->assertTrue($bodyChecker['success']);
        $this->assertEquals(2, $bodyChecker['data']['approved_count']);

        $recSwept = $db->table('weekly_bonus_records')->where('id', $wbSweptId)->get()->getRowArray();
        $recOther = $db->table('weekly_bonus_records')->where('id', $wbOtherId)->get()->getRowArray();
        $this->assertEquals('Approved', $recSwept['status']);
        $this->assertEquals('Approved', $recOther['status']);

        // 3. Record with payout_month exceeding 12 months is excluded and reported
        $this->setRequestPost($controllerChecker, [
            'company_id'   => $companyId,
            'selected_ids' => [$wbExceededId],
        ]);
        $resExceeded = $controllerChecker->batchApproveWeekly();
        $bodyExceeded = json_decode($resExceeded->getBody(), true);
        $this->assertEquals(0, $bodyExceeded['data']['approved_count'] ?? 0);
        $this->assertGreaterThanOrEqual(1, $bodyExceeded['data']['dropped_bound_count'] ?? 0);
    }

    /**
     * 15. resolveStuck on a deleted payroll releases hold or cancels cleanly
     */
    public function testResolveStuckOnDeletedPayrollReleasesHoldInDb()
    {
        $db = Database::connect();
        $companyId = 'comp-delpay-' . bin2hex(random_bytes(4));
        $empId = $this->insertEmployee($companyId, ['first_name' => 'Mamun', 'last_name' => 'Rashid']);

        $deletedPayrollId = 'pay-deleted-nonexistent-' . bin2hex(random_bytes(4));
        $db->table('payrolls')->where('id', $deletedPayrollId)->delete();

        $controller = $this->createInitializedBonusController($companyId, 'usr-approver-777');

        // Case A: Regular bonus held by deleted payroll -> release_hold
        $regBonusId = $this->insertBonusRecord($companyId, $empId, [
            'amount'                => 8000.00,
            'status'                => 'Approved',
            'payroll_id'            => $deletedPayrollId,
            'is_settled_in_payroll' => 0,
        ]);

        $this->setRequestPost($controller, [
            'id'     => $regBonusId,
            'type'   => 'regular',
            'action' => 'release_hold',
            'reason' => 'Draft payroll was discarded by user',
        ]);
        $resReg = $controller->resolveStuck();
        $this->assertEquals(200, $resReg->getStatusCode());
        $bodyReg = json_decode($resReg->getBody(), true);
        $this->assertTrue($bodyReg['success']);
        $this->assertStringContainsString('linked payroll was deleted', $bodyReg['message']);

        $updatedReg = $db->table('bonus_records')->where('id', $regBonusId)->get()->getRowArray();
        $this->assertNull($updatedReg['payroll_id']);

        // Case B: Weekly bonus held by deleted payroll -> release_hold
        $weeklyBonusId = $this->insertWeeklyBonusRecord($companyId, $empId, [
            'bonus_amount' => 1500.00,
            'status'       => 'Approved',
            'payroll_id'   => $deletedPayrollId,
        ]);

        $this->setRequestPost($controller, [
            'id'     => $weeklyBonusId,
            'type'   => 'weekly',
            'action' => 'release_hold',
            'reason' => 'Draft payroll was discarded',
        ]);
        $resWeekly = $controller->resolveStuck();
        $this->assertEquals(200, $resWeekly->getStatusCode());
        $bodyWeekly = json_decode($resWeekly->getBody(), true);
        $this->assertTrue($bodyWeekly['success']);
        $this->assertStringContainsString('linked payroll was deleted', $bodyWeekly['message']);

        $updatedWeekly = $db->table('weekly_bonus_records')->where('id', $weeklyBonusId)->get()->getRowArray();
        $this->assertNull($updatedWeekly['payroll_id']);

        // Case C: Regular bonus held by deleted payroll -> cancel
        $cancelBonusId = $this->insertBonusRecord($companyId, $empId, [
            'amount'                => 6000.00,
            'status'                => 'Pending',
            'payroll_id'            => $deletedPayrollId,
            'is_settled_in_payroll' => 0,
        ]);

        $this->setRequestPost($controller, [
            'id'     => $cancelBonusId,
            'type'   => 'regular',
            'action' => 'cancel',
            'reason' => 'Cancel stuck orphaned bonus',
        ]);
        $resCancel = $controller->resolveStuck();
        $this->assertEquals(200, $resCancel->getStatusCode());
        $bodyCancel = json_decode($resCancel->getBody(), true);
        $this->assertTrue($bodyCancel['success']);
        $this->assertStringContainsString('previously linked to deleted payroll', $bodyCancel['message']);

        $updatedCancel = $db->table('bonus_records')->where('id', $cancelBonusId)->get()->getRowArray();
        $this->assertNull($updatedCancel['payroll_id']);
        $this->assertEquals('Rejected', $updatedCancel['status']);
    }

    /**
     * 16. Duplicate-Retire Migration Invariant: Stop if two or more rows in duplicate group are settled/paid;
     * only retire unsettled duplicates and never set is_settled_in_payroll = 0.
     */
    public function testDuplicateRetireMigrationHandlesSettledAndExcessDuplicates()
    {
        $db = Database::connect();
        $companyId = 'comp-mig-' . bin2hex(random_bytes(4));
        $empId = $this->insertEmployee($companyId);

        $migration = new AddRejectedFieldsAndHardenUniqueIndexOnBonusRecords();

        // ---------------------------------------------------------------------
        // Case 1: Pre-scan Atomicity:
        // Group A: 1 settled + 1 unsettled
        // Group B: 2 settled rows
        // Pre-scan must detect Group B's conflict and abort BEFORE mutating Group A!
        // ---------------------------------------------------------------------
        $emp2Id = $this->insertEmployee($companyId);

        $groupA_settled = $this->insertBonusRecord($companyId, $empId, [
            'amount'                => 4000.00,
            'bonus_month'           => 'November',
            'year'                  => 2026,
            'payout_month'          => '2026-11',
            'status'                => 'Paid',
            'is_settled_in_payroll' => 1,
        ]);
        $groupA_unsettled = $this->insertBonusRecord($companyId, $empId, [
            'amount'                => 4000.00,
            'bonus_month'           => 'November',
            'year'                  => 2026,
            'payout_month'          => '2026-11',
            'status'                => 'Pending',
            'is_settled_in_payroll' => 0,
        ]);

        $groupB_settled1 = $this->insertBonusRecord($companyId, $emp2Id, [
            'amount'                => 5000.00,
            'bonus_month'           => 'October',
            'year'                  => 2026,
            'payout_month'          => '2026-10',
            'status'                => 'Paid',
            'is_settled_in_payroll' => 1,
        ]);
        $groupB_settled2 = $this->insertBonusRecord($companyId, $emp2Id, [
            'amount'                => 5000.00,
            'bonus_month'           => 'October',
            'year'                  => 2026,
            'payout_month'          => '2026-10',
            'status'                => 'Settled',
            'is_settled_in_payroll' => 1,
        ]);

        $caught = false;
        try {
            $migration->up();
        } catch (\RuntimeException $e) {
            $caught = true;
            $this->assertStringContainsString('two or more settled/paid records', $e->getMessage());
            $this->assertStringContainsString($groupB_settled1, $e->getMessage());
            $this->assertStringContainsString($groupB_settled2, $e->getMessage());
        }
        $this->assertTrue($caught, 'Migration must throw RuntimeException during pre-scan');

        // Pre-scan Atomicity Check: Group A's unsettled record MUST NOT have been retired or altered!
        $groupA_check = $db->table('bonus_records')->where('id', $groupA_unsettled)->get()->getRowArray();
        $this->assertEquals('Pending', $groupA_check['status'], 'Group A unsettled row must remain Pending (untouched) due to atomic pre-scan abort');
        $this->assertNull($groupA_check['deleted_at'], 'Group A unsettled row must not be soft-deleted');

        // Delete the second settled row in Group B to resolve the conflict
        $db->table('bonus_records')->where('id', $groupB_settled2)->delete();

        // ---------------------------------------------------------------------
        // Case 2: Clean resolution:
        // Now both groups have at most 1 settled row; migration retires unsettled duplicates.
        // ---------------------------------------------------------------------
        $migration->up();

        // Group A: settled row kept, unsettled retired
        $keptA = $db->table('bonus_records')->where('id', $groupA_settled)->get()->getRowArray();
        $this->assertEquals(1, (int)$keptA['is_settled_in_payroll']);
        $this->assertEquals('Paid', $keptA['status']);

        $retiredA = $db->table('bonus_records')->where('id', $groupA_unsettled)->get()->getRowArray();
        $this->assertEquals('Cancelled', $retiredA['status']);
        $this->assertNotNull($retiredA['deleted_at']);
        $this->assertStringContainsString('Retired duplicate record', (string)$retiredA['adjustment_reason']);
    }

    /**
     * 17. PermissionFilter Argument Forms: Supports single, comma-separated, pipe-separated, bare module forms, and blocks auditor mutations
     */
    public function testPermissionFilterSupportsVariousArgumentFormsAndAuditorRole()
    {
        $session = \Config\Services::session();
        $filter = new PermissionFilter();
        $request = \Config\Services::request();

        // Case 1: Unauthenticated -> redirects to /auth/login
        $session->remove('user_id');
        $resUnauth = $filter->before($request, ['payroll.delete']);
        $this->assertNotNull($resUnauth, 'Unauthenticated user must be redirected');

        // Case 2: Auditor role mutation blocked
        $session->set([
            'user_id'   => 'usr-auditor-99',
            'role'      => 'Auditor',
            'role_code' => 'AUDITOR',
        ]);
        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_SERVER['HTTP_X_REQUESTED_WITH'] = 'xmlhttprequest';
        $resAuditor = $filter->before($request, ['payroll.view']);
        $this->assertNotNull($resAuditor);
        $this->assertTrue(in_array($resAuditor->getStatusCode(), [302, 403], true), 'PermissionFilter returns 302 redirect for standard requests or 403 for AJAX');
        if ($resAuditor->getStatusCode() === 403 && method_exists($resAuditor, 'getJSON')) {
            $bodyAuditor = json_decode($resAuditor->getJSON() ?: '{}', true);
            $this->assertStringContainsString('Auditor role is strictly read-only', $bodyAuditor['message'] ?? '');
        } else {
            $this->assertEquals(302, $resAuditor->getStatusCode());
        }

        // Case 3: Verify candidate parsing helper logic for different argument formats
        // Comma-separated: ['payroll.approve,payroll.delete']
        // Pipe-separated: ['payroll.approve|payroll.delete']
        // Bare module: ['payroll']
        $refMethod = new \ReflectionMethod(PermissionFilter::class, 'before');
        $refMethod->setAccessible(true);

        // Standard user session
        $session->set([
            'user_id'     => 'usr-manager-01',
            'role'        => 'Manager',
            'role_code'   => 'MANAGER',
            'permissions' => ['payroll.view', 'bonus.approve'],
        ]);
        $_SERVER['REQUEST_METHOD'] = 'GET';
        $_SERVER['HTTP_X_REQUESTED_WITH'] = '';

        // Form A: Comma-separated with matching permission 'bonus.approve'
        $resComma = $filter->before($request, ['bonus.view,bonus.approve']);
        // If user has permission, filter returns void/null
        $this->assertNull($resComma, 'Comma-separated form must allow access when user has at least one matching permission');

        // Form B: Pipe-separated with matching permission 'payroll.view'
        $resPipe = $filter->before($request, ['payroll.view|payroll.manage']);
        $this->assertNull($resPipe, 'Pipe-separated form must allow access when user has at least one matching permission');

        // Form C: Bare module format 'payroll' (maps to payroll.view)
        $resBare = $filter->before($request, ['payroll']);
        $this->assertNull($resBare, 'Bare module form must map to module.view');
    }

    /**
     * 18. Weekly Overdue Case and 12-Month Bound:
     * - Unswept weekly bonuses older than 12 months appear in stuck list
     * - Swept weekly bonuses with payout_month <= lastLocked appear in stuck list
     * - Weekly bonus candidates exceeding 12 months from sweep date are dropped by batchApproveWeekly
     */
    public function testWeeklyOverdueCaseAndTwelveMonthLimitInStuckBonusesAndBatchApprove()
    {
        $payrollService = new PayrollService();

        $companyId = 'comp-wkov-' . bin2hex(random_bytes(4));
        $empId = $this->insertEmployee($companyId);

        // 1. Unswept weekly bonus older than 12 months -> Must appear in getStuckBonuses
        $overdueWeeklyId = $this->insertWeeklyBonusRecord($companyId, $empId, [
            'week_start_date' => date('Y-m-d', strtotime('-14 months')),
            'week_end_date'   => date('Y-m-d', strtotime('-14 months +6 days')),
            'bonus_amount'    => 2000.00,
            'status'          => 'Approved',
        ]);

        $stuckRes = $payrollService->getStuckBonuses($companyId);
        $stuckWkIds = array_column($stuckRes['weekly'], 'id');
        $this->assertContains($overdueWeeklyId, $stuckWkIds, 'Unswept weekly bonus older than 12 months must appear in stuck list');

        // 2. Swept weekly bonus with payout_month <= lastLocked
        // Under the current carry-forward rule (payout_month <= payroll month is eligible),
        // the next payroll pays it automatically, so it needs no action and must NOT be marked stuck.
        $lockedBatchId = $this->insertPayrollBatch($companyId, '2026-07', [
            'status'    => 'Locked',
            'is_locked' => 1,
        ]);
        $sweptWeeklyId = $this->insertWeeklyBonusRecord($companyId, $empId, [
            'week_start_date' => '2026-07-01',
            'week_end_date'   => '2026-07-07',
            'bonus_amount'    => 1800.00,
            'status'          => 'Approved',
            'payout_month'    => '2026-07',
        ]);
        $stuckRes2 = $payrollService->getStuckBonuses($companyId);
        $stuckWkIds2 = array_column($stuckRes2['weekly'], 'id');
        $this->assertNotContains($sweptWeeklyId, $stuckWkIds2, 'Swept weekly bonus must not be marked as stuck because next payroll pays it automatically');

        // 3. batchApproveWeekly drops candidate exceeding 12 months from original sweep date
        $wbExceededId = $this->insertWeeklyBonusRecord($companyId, $empId, [
            'bonus_amount' => 1500.00,
            'status'       => 'Pending',
            'swept_at'     => date('Y-m-d H:i:s'),
            'payout_month' => date('Y-m', strtotime('+16 months')),
        ]);

        $controller = $this->createInitializedBonusController($companyId, 'usr-checker-wk');
        $this->setRequestPost($controller, [
            'company_id'   => $companyId,
            'selected_ids' => [$wbExceededId],
        ]);
        $resApprove = $controller->batchApproveWeekly();
        $bodyApprove = json_decode($resApprove->getBody(), true);
        $this->assertEquals(0, $bodyApprove['data']['approved_count'] ?? 0);
        $this->assertGreaterThanOrEqual(1, $bodyApprove['data']['dropped_bound_count'] ?? 0);
        $this->assertStringContainsString('12-month bound rule', implode(', ', $bodyApprove['data']['dropped_reasons'] ?? []));
    }

    /**
     * 19. Settle Payroll Bonuses: Queries payroll_items using bonus_amount AS bonus,
     * settles linked approved records and updates is_settled_in_payroll = 1.
     */
    public function testSettlePayrollBonusesSelectsBonusAmountAndSettles()
    {
        $db = Database::connect();
        $payrollService = new PayrollService();

        $companyId = 'comp-spb-' . bin2hex(random_bytes(4));
        $empId = $this->insertEmployee($companyId);
        $payrollId = $this->insertPayrollBatch($companyId, '2026-10', [
            'status'    => 'Approved',
            'is_locked' => 1,
        ]);

        $bonusId = $this->insertBonusRecord($companyId, $empId, [
            'amount'                => 7500.00,
            'status'                => 'Approved',
            'payroll_id'            => $payrollId,
            'is_settled_in_payroll' => 0,
        ]);

        // Insert payroll item with bonus_amount and components_breakdown_json
        $itemId = 'pi-test-' . bin2hex(random_bytes(4));
        $db->table('payroll_items')->insert([
            'id'                        => $itemId,
            'payroll_id'                => $payrollId,
            'employee_id'               => $empId,
            'bonus_amount'              => 7500.00,
            'components_breakdown_json' => json_encode(['bonus_record_ids' => [$bonusId]]),
            'created_at'                => date('Y-m-d H:i:s'),
        ]);
        $this->trackInsert('payroll_items', $itemId);

        // Settle payroll bonuses
        $settledIds = $payrollService->settlePayrollBonuses($payrollId, '2026-10', $companyId);
        $this->assertContains($bonusId, $settledIds, 'Approved bonus record must be returned as settled');

        $updatedBonus = $db->table('bonus_records')->where('id', $bonusId)->get()->getRowArray();
        $this->assertEquals('Settled', $updatedBonus['status']);
        $this->assertEquals(1, (int)$updatedBonus['is_settled_in_payroll']);
    }

    /**
     * 20. Currency Guard: Payroll generation message safely omits missing currency without throwing
     */
    public function testPayrollGenerationCurrencyGuardGracefullyHandlesMissingRule()
    {
        $db = Database::connect();
        $payrollService = new PayrollService();
        $companyId = 'comp-nocurr-' . bin2hex(random_bytes(4));

        // Company has employee and salary, but NO PAYROLL_BASICS rule
        $empId = $this->insertEmployee($companyId, ['first_name' => 'Kalam', 'last_name' => 'Uddin']);
        $this->insertSalary($companyId, $empId, 60000.0, 40000.0);

        // Ensure memoization is clean
        RuleResolver::resetMemo();

        // Call payroll generation
        $res = $payrollService->generatePayrollBatch('2026-11', $companyId, null, 'usr-tester-001', false);

        $this->assertIsArray($res);
        $this->assertTrue($res['success'], 'Payroll draft generation must succeed even without PAYROLL_BASICS');
        if (!empty($res['payroll_id'])) {
            $this->trackInsert('payrolls', $res['payroll_id']);
        }
        $this->assertStringContainsString('Net Disbursed: ', $res['message']);
        $this->assertStringNotContainsString('Net Disbursed:  ', $res['message'], 'Message must not contain double space');
    }

    /**
     * 21. Scheduled-Unpaid query: Only status='Approved' swept records with payout_month <= latest locked payroll are flagged
     */
    public function testGetStuckBonusesScheduledUnpaidFilterLogic()
    {
        $db = Database::connect();
        $payrollService = new PayrollService();
        $companyId = 'comp-schedunpaid-' . bin2hex(random_bytes(4));
        $empId = $this->insertEmployee($companyId);

        // Create locked payroll for 2026-08
        $this->insertPayrollBatch($companyId, '2026-08', ['is_locked' => 1, 'status' => 'Locked']);

        // 1. Approved swept regular bonus scheduled for 2026-08 (<= locked month) -> flagged
        $b1 = $this->insertBonusRecord($companyId, $empId, [
            'status'       => 'Approved',
            'payout_month' => '2026-08',
            'amount'       => 2000.00,
        ]);

        // 2. Approved swept regular bonus scheduled for 2026-09 (> locked month) -> NOT flagged
        $b2 = $this->insertBonusRecord($companyId, $empId, [
            'status'       => 'Approved',
            'payout_month' => '2026-09',
            'amount'       => 3000.00,
        ]);

        // 3. Pending regular bonus scheduled for 2026-08 -> NOT flagged (must be Approved)
        $b3 = $this->insertBonusRecord($companyId, $empId, [
            'status'       => 'Pending',
            'payout_month' => '2026-08',
            'amount'       => 4000.00,
        ]);

        // 4. Rejected regular bonus scheduled for 2026-08 -> NOT flagged
        $b4 = $this->insertBonusRecord($companyId, $empId, [
            'status'       => 'Rejected',
            'payout_month' => '2026-08',
            'amount'       => 5000.00,
        ]);

        // 5. Approved weekly bonus scheduled for 2026-08 (<= locked month) -> flagged
        $w1 = $this->insertWeeklyBonusRecord($companyId, $empId, [
            'status'       => 'Approved',
            'payout_month' => '2026-08',
            'bonus_amount' => 1500.00,
        ]);

        // 6. Cancelled weekly bonus scheduled for 2026-08 -> NOT flagged
        $w2 = $this->insertWeeklyBonusRecord($companyId, $empId, [
            'status'       => 'Cancelled',
            'payout_month' => '2026-08',
            'bonus_amount' => 1800.00,
        ]);

        $stuck = $payrollService->getStuckBonuses($companyId, '2026-10-01');

        $this->assertEquals('2026-08', $stuck['latest_locked_month']);
        $this->assertEquals(2, $stuck['scheduled_unpaid_count'], 'Only Approved records scheduled for locked months must be flagged');
        $this->assertEquals(3500.00, (float)$stuck['scheduled_unpaid_amount']);

        $regIds = array_column($stuck['scheduled_unpaid_regular'], 'id');
        $this->assertContains($b1, $regIds);
        $this->assertNotContains($b2, $regIds);
        $this->assertNotContains($b3, $regIds);
        $this->assertNotContains($b4, $regIds);

        $weeklyIds = array_column($stuck['scheduled_unpaid_weekly'], 'id');
        $this->assertContains($w1, $weeklyIds);
        $this->assertNotContains($w2, $weeklyIds);
    }

    /**
     * 22. PF Migration: BackfillPfLedgerPayrollIdFromItems updates ledger rows referencing payroll item IDs to parent payroll ID
     */
    public function testBackfillPfLedgerPayrollIdFromItemsMigration()
    {
        $db = Database::connect();
        $companyId = 'comp-pfbackfill-' . bin2hex(random_bytes(4));
        $empId = $this->insertEmployee($companyId);

        $payrollId = $this->insertPayrollBatch($companyId, '2026-09');

        $itemId = 'pi-test-' . bin2hex(random_bytes(4));
        $db->table('payroll_items')->insert([
            'id'          => $itemId,
            'payroll_id'  => $payrollId,
            'employee_id' => $empId,
            'basic_salary'=> 30000.0,
            'created_at'  => date('Y-m-d H:i:s'),
        ]);
        $this->trackInsert('payroll_items', $itemId);

        // Insert PF ledger row where payroll_id points to the item ID (erroneous legacy link)
        $ledgerId = 'pfl-test-' . bin2hex(random_bytes(4));
        $targetTable = $db->tableExists('provident_fund_ledgers') ? 'provident_fund_ledgers' : 'provident_fund_ledger';
        $db->table($targetTable)->insert([
            'id'               => $ledgerId,
            'company_id'       => $companyId,
            'employee_id'      => $empId,
            'payroll_id'       => $itemId,
            'transaction_date' => '2026-09-30',
            'transaction_type' => 'Monthly Contribution',
            'employee_share'   => 3000.00,
            'employer_share'   => 3000.00,
            'created_at'       => date('Y-m-d H:i:s'),
        ]);
        $this->trackInsert($targetTable, $ledgerId);

        // Run the backfill migration
        $migration = new \App\Database\Migrations\BackfillPfLedgerPayrollIdFromItems();
        $migration->up();

        // Verify the PF ledger row now points to the parent payroll ID
        $updated = $db->table($targetTable)->where('id', $ledgerId)->get()->getRowArray();
        $this->assertEquals($payrollId, $updated['payroll_id'], 'PF ledger payroll_id must be backfilled to parent payroll ID');
    }

    /**
     * 23. PF Revert Paths: revertBatchContributions purges monthly contributions and decouples Arrear records
     */
    public function testPfLedgerRevertDraftBatchAndBatchContributions()
    {
        $db = Database::connect();
        $pfLedgerModel = new \App\Models\ProvidentFundLedgerModel();
        $companyId = 'comp-pfrevert-' . bin2hex(random_bytes(4));
        $empId = $this->insertEmployee($companyId);
        $payrollId = $this->insertPayrollBatch($companyId, '2026-07');

        $targetTable = $db->tableExists('provident_fund_ledgers') ? 'provident_fund_ledgers' : 'provident_fund_ledger';

        // 1. Insert standard monthly contribution
        $mcId = 'pfl-mc-' . bin2hex(random_bytes(4));
        $db->table($targetTable)->insert([
            'id'               => $mcId,
            'company_id'       => $companyId,
            'employee_id'      => $empId,
            'payroll_id'       => $payrollId,
            'payroll_month'    => 7,
            'payroll_year'     => 2026,
            'transaction_date' => '2026-07-31',
            'transaction_type' => 'Monthly Contribution',
            'employee_share'   => 2500.00,
            'employer_share'   => 2500.00,
            'created_at'       => date('Y-m-d H:i:s'),
        ]);
        $this->trackInsert($targetTable, $mcId);

        // 2. Insert Arrear entry linked to the batch
        $arId = 'pfl-ar-' . bin2hex(random_bytes(4));
        $db->table($targetTable)->insert([
            'id'               => $arId,
            'company_id'       => $companyId,
            'employee_id'      => $empId,
            'payroll_id'       => $payrollId,
            'payroll_month'    => 7,
            'payroll_year'     => 2026,
            'transaction_date' => '2026-07-31',
            'transaction_type' => 'Arrear',
            'employee_share'   => 500.00,
            'employer_share'   => 500.00,
            'created_at'       => date('Y-m-d H:i:s'),
        ]);
        $this->trackInsert($targetTable, $arId);

        // Revert batch contributions
        $purgedCount = $pfLedgerModel->revertBatchContributions($companyId, 7, 2026, $payrollId);
        $this->assertGreaterThanOrEqual(1, $purgedCount);

        // Monthly contribution must be purged
        $checkMc = $db->table($targetTable)->where('id', $mcId)->get()->getRowArray();
        $this->assertNull($checkMc, 'Monthly contribution must be deleted on batch revert');

        // Arrear record must NOT be deleted, but its payroll_id decoupled to null
        $checkAr = $db->table($targetTable)->where('id', $arId)->get()->getRowArray();
        $this->assertNotNull($checkAr, 'Arrear entry must not be deleted on batch revert');
        $this->assertNull($checkAr['payroll_id'], 'Arrear entry payroll_id must be decoupled (set to null) on batch revert');
    }
}

