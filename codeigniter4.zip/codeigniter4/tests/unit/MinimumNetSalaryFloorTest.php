<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

/**
 * Option C Unit Test Suite:
 * LOP outside 50% statutory deduction ceiling + Minimum Net Salary Floor + Warnings
 */
class MinimumNetSalaryFloorTest extends TestCase
{
    /**
     * Helper to simulate applyStatutoryDeductionCeiling pure logic
     */
    private function calculateCeiling(float $gross, array $requestedDeductions, float $ceilingRatio = 0.50, float $minNetSalaryFloor = 0.0, ?array $empInfo = null): array
    {
        $gross = round(max(0.0, $gross), 2);
        $statutoryCeilingAmount = round($gross * $ceilingRatio, 2);
        $remainingCeiling = $statutoryCeilingAmount;

        // 1. Mandatory Tax
        $taxRequested = round(max(0.0, (float)($requestedDeductions['tax'] ?? 0.0)), 2);
        $taxApplied = min($taxRequested, $remainingCeiling);
        $remainingCeiling = max(0.0, round($remainingCeiling - $taxApplied, 2));
        $unappliedTax = round($taxRequested - $taxApplied, 2);

        // 2. Mandatory PF
        $pfRequested = round(max(0.0, (float)($requestedDeductions['pf'] ?? 0.0)), 2);
        $pfApplied = min($pfRequested, $remainingCeiling);
        $remainingCeiling = max(0.0, round($remainingCeiling - $pfApplied, 2));
        $unappliedPf = round($pfRequested - $pfApplied, 2);

        // 3. Advance Recovery
        $advanceRequested = round(max(0.0, (float)($requestedDeductions['advance'] ?? 0.0)), 2);
        $advanceApplied = min($advanceRequested, $remainingCeiling);
        $remainingCeiling = max(0.0, round($remainingCeiling - $advanceApplied, 2));
        $unrecoveredAdvance = round($advanceRequested - $advanceApplied, 2);

        // 4. Loan EMI
        $loanRequested = round(max(0.0, (float)($requestedDeductions['loan'] ?? 0.0)), 2);
        $loanApplied = min($loanRequested, $remainingCeiling);
        $remainingCeiling = max(0.0, round($remainingCeiling - $loanApplied, 2));
        $unrecoveredLoan = round($loanRequested - $loanApplied, 2);

        // 5. Other Deductions
        $otherRequested = round(max(0.0, (float)($requestedDeductions['other'] ?? 0.0)), 2);
        $otherApplied = min($otherRequested, $remainingCeiling);
        $remainingCeiling = max(0.0, round($remainingCeiling - $otherApplied, 2));
        $unappliedOther = round($otherRequested - $otherApplied, 2);

        // 6. LOP (applied in full outside the ceiling - Option C)
        $lopRequested = round(max(0.0, (float)($requestedDeductions['lop'] ?? 0.0)), 2);
        $lopApplied = $lopRequested;
        $unappliedLop = 0.0;

        $totalApplied = round($taxApplied + $pfApplied + $lopApplied + $advanceApplied + $loanApplied + $otherApplied, 2);
        $net = max(0.0, round($gross - $totalApplied, 2));

        $otherDeductionsApplied = round($taxApplied + $pfApplied + $advanceApplied + $loanApplied + $otherApplied, 2);

        $warnings = [];
        $floorWarning = null;
        $minNetSalaryFloor = round(max(0.0, (float)$minNetSalaryFloor), 2);

        if ($minNetSalaryFloor > 0.0 && $net < $minNetSalaryFloor) {
            $shortfall = round($minNetSalaryFloor - $net, 2);
            $empName = $empInfo['employee_name'] ?? ($empInfo['name'] ?? 'John Doe');
            $floorWarning = [
                'employee'         => $empName,
                'employee_id'      => $empInfo['id'] ?? 'EMP-001',
                'employee_name'    => $empName,
                'employee_code'    => $empInfo['employee_code'] ?? 'EMP-001',
                'gross'            => $gross,
                'lop_amount'       => $lopApplied,
                'other_deductions' => $otherDeductionsApplied,
                'net'              => $net,
                'floor'            => $minNetSalaryFloor,
                'shortfall'        => $shortfall,
                'message'          => "Employee {$empName} net salary ({$net}) is below minimum net salary floor ({$minNetSalaryFloor}). Shortfall: {$shortfall}."
            ];
            $warnings[] = $floorWarning;
        }

        return [
            'gross'                    => $gross,
            'applied'                  => [
                'tax'     => $taxApplied,
                'pf'      => $pfApplied,
                'lop'     => $lopApplied,
                'advance' => $advanceApplied,
                'loan'    => $loanApplied,
                'other'   => $otherApplied,
            ],
            'unapplied'                => [
                'tax'     => $unappliedTax,
                'pf'      => $unappliedPf,
                'lop'     => $unappliedLop,
                'advance' => $unrecoveredAdvance,
                'loan'    => $unrecoveredLoan,
                'other'   => $unappliedOther,
            ],
            'total_deductions'         => $totalApplied,
            'net_salary'               => $net,
            'minimum_net_salary_floor' => $minNetSalaryFloor,
            'warnings'                 => $warnings,
            'floor_warning'            => $floorWarning,
            'is_below_floor'           => ($floorWarning !== null),
        ];
    }

    /**
     * Requirement: no LOP, floor 0 -> same result as before, no warning
     */
    public function testNoLopFloorZeroSameResultNoWarning()
    {
        $gross = 50000.0;
        $requested = [
            'tax'     => 2000.0,
            'pf'      => 2500.0,
            'lop'     => 0.0,
            'advance' => 0.0,
            'loan'    => 1000.0,
            'other'   => 500.0,
        ];

        $res = $this->calculateCeiling($gross, $requested, 0.50, 0.0);

        $this->assertEquals(50000.0, $res['gross']);
        $this->assertEquals(6000.0, $res['total_deductions']);
        $this->assertEquals(44000.0, $res['net_salary']);
        $this->assertEquals(0.0, $res['applied']['lop']);
        $this->assertFalse($res['is_below_floor']);
        $this->assertNull($res['floor_warning']);
        $this->assertEmpty($res['warnings']);
    }

    /**
     * Requirement: LOP present, net above floor -> no warning
     */
    public function testLopPresentNetAboveFloorNoWarning()
    {
        $gross = 50000.0;
        $requested = [
            'tax'     => 2000.0,
            'pf'      => 2500.0,
            'lop'     => 5000.0, // LOP present
            'advance' => 0.0,
            'loan'    => 0.0,
            'other'   => 0.0,
        ];
        $floor = 30000.0;

        $res = $this->calculateCeiling($gross, $requested, 0.50, $floor);

        // Net = 50000 - (2000 + 2500 + 5000) = 40500.0
        $this->assertEquals(40500.0, $res['net_salary']);
        $this->assertTrue($res['net_salary'] >= $floor);
        $this->assertFalse($res['is_below_floor']);
        $this->assertNull($res['floor_warning']);
        $this->assertEmpty($res['warnings']);
    }

    /**
     * Requirement: LOP present, net below floor -> amounts unchanged, warning with correct shortfall
     */
    public function testLopPresentNetBelowFloorAmountsUnchangedWarningWithCorrectShortfall()
    {
        $gross = 50000.0;
        $requested = [
            'tax'     => 2000.0,
            'pf'      => 2500.0,
            'lop'     => 25000.0, // High LOP
            'advance' => 0.0,
            'loan'    => 0.0,
            'other'   => 0.0,
        ];
        $floor = 25000.0;

        $empInfo = [
            'id'            => 'emp-101',
            'employee_name' => 'Alice Rahman',
            'employee_code' => 'EMP-0101'
        ];

        $res = $this->calculateCeiling($gross, $requested, 0.50, $floor, $empInfo);

        // Total applied deductions = 2000 + 2500 + 25000 = 29500.0
        // Net = 50000 - 29500 = 20500.0
        // Expected shortfall = 25000 - 20500 = 4500.0
        $this->assertEquals(50000.0, $res['gross'], 'Gross salary must remain unchanged.');
        $this->assertEquals(29500.0, $res['total_deductions'], 'Deductions must remain unchanged.');
        $this->assertEquals(20500.0, $res['net_salary'], 'Net salary amount must not be altered.');
        $this->assertTrue($res['is_below_floor']);
        $this->assertNotNull($res['floor_warning']);

        $warning = $res['floor_warning'];
        $this->assertEquals('Alice Rahman', $warning['employee']);
        $this->assertEquals(50000.0, $warning['gross']);
        $this->assertEquals(25000.0, $warning['lop_amount']);
        $this->assertEquals(4500.0, $warning['other_deductions']); // 2000 + 2500
        $this->assertEquals(20500.0, $warning['net']);
        $this->assertEquals(25000.0, $warning['floor']);
        $this->assertEquals(4500.0, $warning['shortfall']);
    }

    /**
     * Requirement: LOP larger than gross -> net 0, warning
     */
    public function testLopLargerThanGrossNetZeroWarning()
    {
        $gross = 30000.0;
        $requested = [
            'tax'     => 0.0,
            'pf'      => 0.0,
            'lop'     => 45000.0, // LOP larger than gross
            'advance' => 0.0,
            'loan'    => 0.0,
            'other'   => 0.0,
        ];
        $floor = 10000.0;

        $res = $this->calculateCeiling($gross, $requested, 0.50, $floor);

        // Net salary must never go below 0 (existing max(0, ...) behavior)
        $this->assertEquals(0.0, $res['net_salary'], 'Net salary must be 0 and never negative when LOP > gross.');
        $this->assertEquals(45000.0, $res['applied']['lop'], 'LOP is deducted in full outside the ceiling.');
        $this->assertTrue($res['is_below_floor']);
        $this->assertNotNull($res['floor_warning']);
        $this->assertEquals(10000.0, $res['floor_warning']['shortfall']); // floor - net = 10000 - 0 = 10000
    }

    /**
     * Requirement: LOP plus loan deduction -> loan still capped by the 50% ceiling, LOP still full
     */
    public function testLopPlusLoanDeductionLoanCappedByFiftyPercentCeilingLopStillFull()
    {
        $gross = 100000.0;
        // 50% statutory ceiling = 50,000.0
        $requested = [
            'tax'     => 15000.0, // Takes 15k, rem 35k
            'pf'      => 10000.0, // Takes 10k, rem 25k
            'advance' => 0.0,
            'loan'    => 35000.0, // Requested 35k, but only 25k remaining ceiling
            'other'   => 5000.0,  // Zeroed out
            'lop'     => 20000.0, // LOP is outside ceiling, deducted in full
        ];
        $floor = 35000.0;

        $res = $this->calculateCeiling($gross, $requested, 0.50, $floor);

        // Loan must be capped by 50% ceiling:
        $this->assertEquals(15000.0, $res['applied']['tax']);
        $this->assertEquals(10000.0, $res['applied']['pf']);
        $this->assertEquals(25000.0, $res['applied']['loan'], 'Loan EMI must be capped at 25,000 to respect 50% statutory ceiling.');
        $this->assertEquals(10000.0, $res['unapplied']['loan'], '10,000 of requested loan deduction remains unapplied due to ceiling.');
        $this->assertEquals(0.0, $res['applied']['other']);

        // LOP must be applied in full:
        $this->assertEquals(20000.0, $res['applied']['lop'], 'LOP is intentionally outside the 50% ceiling and deducted in full.');
        $this->assertEquals(0.0, $res['unapplied']['lop']);

        // Total applied = 15k + 10k + 25k + 0k + 20k = 70,000.0
        $this->assertEquals(70000.0, $res['total_deductions']);
        // Net = 100,000 - 70,000 = 30,000.0
        $this->assertEquals(30000.0, $res['net_salary']);

        // Floor warning: Net 30,000 < Floor 35,000 -> Shortfall 5,000
        $this->assertTrue($res['is_below_floor']);
        $this->assertEquals(5000.0, $res['floor_warning']['shortfall']);
    }

    /**
     * Requirement: floor not set -> no warning ever
     */
    public function testFloorNotSetNoWarningEver()
    {
        $gross = 50000.0;
        $requested = [
            'tax'     => 5000.0,
            'pf'      => 5000.0,
            'lop'     => 35000.0, // Massive LOP reducing net to 5,000
            'advance' => 0.0,
            'loan'    => 0.0,
            'other'   => 0.0,
        ];

        // Case A: floor = 0.0
        $resA = $this->calculateCeiling($gross, $requested, 0.50, 0.0);
        $this->assertEquals(5000.0, $resA['net_salary']);
        $this->assertFalse($resA['is_below_floor']);
        $this->assertNull($resA['floor_warning']);
        $this->assertEmpty($resA['warnings']);

        // Case B: LOP larger than gross, net = 0.0, floor = 0.0
        $requestedB = [
            'tax' => 0.0,
            'pf'  => 0.0,
            'lop' => 60000.0,
        ];
        $resB = $this->calculateCeiling($gross, $requestedB, 0.50, 0.0);
        $this->assertEquals(0.0, $resB['net_salary']);
        $this->assertFalse($resB['is_below_floor']);
        $this->assertNull($resB['floor_warning']);
        $this->assertEmpty($resB['warnings']);
    }

    /**
     * Requirement: Validate setting: a number, zero or more, and never greater than company's lowest gross salary in the run
     * (if it is, show a settings warning instead of failing).
     */
    public function testSettingValidationFloorGreaterThanLowestGrossProducesWarningWithoutFailing()
    {
        $lowestGrossInBatch = 25000.0;
        $configuredFloor = 30000.0; // Greater than lowest gross

        $settingsWarning = null;
        if ($configuredFloor > 0.0 && $lowestGrossInBatch !== null && $configuredFloor > $lowestGrossInBatch) {
            $settingsWarning = sprintf(
                'Configured minimum net salary floor (%s) is greater than the company\'s lowest gross salary in this run (%s).',
                number_format($configuredFloor, 2),
                number_format($lowestGrossInBatch, 2)
            );
        }

        $this->assertNotNull($settingsWarning);
        $this->assertStringContainsString('greater than the company\'s lowest gross salary', $settingsWarning);
    }
}
