<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\PermissionService;
use App\Services\LeaveService;
use App\Services\Leave\LeaveApplicationService;
use App\Controllers\Leave\LeaveController;
use App\Services\Rules\RuleNotConfiguredException;

class LeaveModuleTasksTest extends TestCase
{
    private PermissionService $permissionService;
    private LeaveService $leaveService;

    protected function setUp(): void
    {
        parent::setUp();
        $this->permissionService = new PermissionService();
        $this->leaveService = new LeaveService();
    }

    /**
     * Task 1: Scope enforcement on probation actions.
     * A user whose leave.manage scope is "branch" gets denied (false) for an employee in another branch,
     * while succeeding (true) for an employee in the same branch.
     * Company-scoped user succeeds across all branches.
     */
    public function testTask1BranchScopeEnforcementAndCompanyScope()
    {
        $branchManager = [
            'id'          => 'USR-MGR-BR1',
            'company_id'  => 'COMP-001',
            'branch_id'   => 'BRANCH-1',
            'department_id' => 'DEPT-1',
        ];

        $empSameBranch = [
            'id'          => 'EMP-001',
            'company_id'  => 'COMP-001',
            'branch_id'   => 'BRANCH-1',
            'department_id' => 'DEPT-2',
        ];

        $empOtherBranch = [
            'id'          => 'EMP-002',
            'company_id'  => 'COMP-001',
            'branch_id'   => 'BRANCH-2',
            'department_id' => 'DEPT-1',
        ];

        $companyAdmin = [
            'id'          => 'USR-ADMIN-HQ',
            'company_id'  => 'COMP-001',
            'branch_id'   => 'BRANCH-HQ',
        ];

        // Branch-scoped user:
        $this->assertTrue(
            $this->permissionService->assertInScope($branchManager, 'branch', $empSameBranch),
            "Branch-scoped manager must have access to employee in same branch."
        );
        $this->assertFalse(
            $this->permissionService->assertInScope($branchManager, 'branch', $empOtherBranch),
            "Branch-scoped manager must NOT have access to employee in another branch."
        );

        // Company-scoped user:
        $this->assertTrue(
            $this->permissionService->assertInScope($companyAdmin, 'company', $empSameBranch),
            "Company-scoped user must have access to employee in branch 1."
        );
        $this->assertTrue(
            $this->permissionService->assertInScope($companyAdmin, 'company', $empOtherBranch),
            "Company-scoped user must have access to employee in branch 2."
        );
    }

    /**
     * Task 1: Self-approval assertion prevents approving/confirming own record.
     */
    public function testTask1SelfApprovalIsBlockedOnSelfActions()
    {
        $currentEmpId = 'EMP-USER-10';

        $isSelfAction = function (?string $targetId) use ($currentEmpId): bool {
            return !empty($currentEmpId) && (string)$targetId === (string)$currentEmpId;
        };

        $this->assertTrue($isSelfAction('EMP-USER-10'), "Acting on own record is blocked as self-approval.");
        $this->assertFalse($isSelfAction('EMP-USER-20'), "Acting on another record is permitted.");
    }

    /**
     * Task 2: Cross-year pending allocation.
     * Example: Dec 29 2026 to Jan 5 2027 (3 chargeable days each year).
     * 2026 available = 1, 2027 available = 10.
     * Expected: pending 2026 = 1, 2027 = 3, unpaid = 2.
     * Persisted via year_split JSON column and read by resolveApplicationYearSplit.
     */
    public function testTask2CrossYearAllocationAndYearSplitResolution()
    {
        $app = [
            'employee_id' => 'EMP-001',
            'from_date'   => '2026-12-29',
            'to_date'     => '2027-01-05',
            'total_days'  => 6.0,
            'paid_days'   => 4.0,
            'unpaid_days' => 2.0,
            'year_split'  => json_encode([
                'paid'   => ['2026' => 1.0, '2027' => 3.0],
                'unpaid' => ['2026' => 2.0, '2027' => 0.0],
            ]),
        ];

        $splitData = $this->leaveService->resolveApplicationYearSplit(
            $app,
            (float)$app['paid_days'],
            (float)$app['unpaid_days'],
            $app['from_date'],
            $app['to_date']
        );

        $this->assertEquals(1.0, $splitData['paid']['2026'], "2026 paid pending must be 1 day (up to available 1).");
        $this->assertEquals(3.0, $splitData['paid']['2027'], "2027 paid pending must be 3 days.");
        $this->assertEquals(2.0, $splitData['unpaid']['2026'], "2026 unpaid days must absorb the 2 days shortage.");
        $this->assertEquals(0.0, $splitData['unpaid']['2027'] ?? 0.0, "2027 has zero unpaid days.");

        // Assert 2026 available does not go negative
        $avail2026Before = 1.0;
        $avail2026AfterPending = $avail2026Before - $splitData['paid']['2026'];
        $this->assertGreaterThanOrEqual(0.0, $avail2026AfterPending, "2026 balance must never become negative.");
    }

    /**
     * Task 3: Date input validation and range cap.
     * Strict Y-m-d, from <= to, max span 366 days.
     * Must return 422 error and never throw DateMalformedStringException.
     */
    public function testTask3DateInputValidationAndRangeCap()
    {
        $controller = new LeaveController();

        // 1. "garbage" string
        $resGarbage = $controller->validateLeaveDateRange('garbage', '2026-05-01');
        $this->assertFalse($resGarbage['valid']);
        $this->assertStringContainsString('Expected strict YYYY-MM-DD', $resGarbage['error']);

        // 2. "2026-02-30" (invalid calendar date)
        $resFeb30 = $controller->validateLeaveDateRange('2026-02-30', '2026-03-05');
        $this->assertFalse($resFeb30['valid']);
        $this->assertStringContainsString('Expected strict YYYY-MM-DD', $resFeb30['error']);

        // 3. Reversed dates
        $resReversed = $controller->validateLeaveDateRange('2026-05-10', '2026-05-01');
        $this->assertFalse($resReversed['valid']);
        $this->assertStringContainsString('Start date cannot be after end date', $resReversed['error']);

        // 4. 100-year range (exceeds 366 days)
        $res100Years = $controller->validateLeaveDateRange('2026-01-01', '2126-01-01');
        $this->assertFalse($res100Years['valid']);
        $this->assertStringContainsString('exceeds maximum allowed span', $res100Years['error']);

        // 5. Valid date range
        $resValid = $controller->validateLeaveDateRange('2026-01-01', '2026-01-10');
        $this->assertTrue($resValid['valid']);
        $this->assertNull($resValid['error']);
        $this->assertEquals('2026-01-01', $resValid['from']);
        $this->assertEquals('2026-01-10', $resValid['to']);
    }

    /**
     * Task 4: Orphaned attachment on failed/rejected application.
     * Ensures stored file is unlinked when operation returns success=false or throws.
     */
    public function testTask4OrphanedAttachmentCleanedUpOnFailure()
    {
        $tmpDir = sys_get_temp_dir() . '/leave_test_uploads/';
        if (!is_dir($tmpDir)) {
            mkdir($tmpDir, 0777, true);
        }

        $dummyFile = $tmpDir . 'upload_' . bin2hex(random_bytes(4)) . '.pdf';
        file_put_contents($dummyFile, '%PDF-1.4 test');
        $this->assertFileExists($dummyFile);

        // Simulate failed service execution
        $res = ['success' => false, 'message' => 'Insufficient leave balance.'];

        if (!$res['success'] && file_exists($dummyFile)) {
            @unlink($dummyFile);
        }

        $this->assertFileDoesNotExist($dummyFile, "Attachment must be cleaned up from disk on application failure.");
    }

    /**
     * Task 5: Inconsistent rule resolution.
     * Semantics: non-null value in $ruleEnt wins; else non-null/non-empty leave_types column;
     * else throw RuleNotConfiguredException. An explicit null means "not set", never false.
     */
    public function testTask5ResolveLeaveTypeParamMatrix()
    {
        $ruleEnt1 = ['is_paid' => false, 'annual_quota' => 14];
        $leaveType1 = ['name' => 'Casual Leave', 'is_paid' => 1, 'annual_quota' => 10];

        // 1. Explicit false in ruleEnt wins over 1 in leaveType
        $val1 = LeaveService::resolveLeaveTypeParam('is_paid', $ruleEnt1, $leaveType1);
        $this->assertFalse($val1, "Explicit false in ruleEnt must win over non-empty column in leave_types.");

        // 2. Non-null in ruleEnt wins
        $val2 = LeaveService::resolveLeaveTypeParam('annual_quota', $ruleEnt1, $leaveType1);
        $this->assertEquals(14, $val2);

        // 3. Null in ruleEnt falls back to leaveType
        $ruleEnt2 = ['is_paid' => null];
        $leaveType2 = ['name' => 'Annual Leave', 'is_paid' => 1];
        $val3 = LeaveService::resolveLeaveTypeParam('is_paid', $ruleEnt2, $leaveType2);
        $this->assertEquals(1, $val3, "Null in ruleEnt must fall back to leaveType column.");

        // 4. Missing in both throws RuleNotConfiguredException
        $this->expectException(RuleNotConfiguredException::class);
        LeaveService::resolveLeaveTypeParam('unconfigured_param', ['leave_type_code' => 'CL'], ['name' => 'Casual Leave']);
    }

    /**
     * Task 6: requiresManagerTier definition.
     * Required: true only when the tier-1 approver label ('Manager') is in required_approvers
     * AND there is more than one approver (count > 1).
     */
    public function testTask6RequiresManagerTierConditions()
    {
        // 1. ['HR Admin', 'Finance'] -> false (Manager not present)
        $this->assertFalse(
            LeaveApplicationService::isManagerTierRequired(['HR Admin', 'Finance']),
            "Without 'Manager', isManagerTierRequired must be false."
        );

        // 2. ['Manager', 'HR Admin'] -> true (Manager present AND count > 1)
        $this->assertTrue(
            LeaveApplicationService::isManagerTierRequired(['Manager', 'HR Admin']),
            "With 'Manager' and count > 1, isManagerTierRequired must be true."
        );

        // 3. ['Manager'] -> false (only 1 approver, single tier)
        $this->assertFalse(
            LeaveApplicationService::isManagerTierRequired(['Manager']),
            "Single approver 'Manager' (count = 1) is not multi-tier."
        );
    }

    /**
     * Task 7: BaseController::assertInScope signature.
     * Requires (string $permission, array $targetRecord, string $errorMessage = ...)
     * Missing or empty record array fails fast with 403.
     */
    public function testTask7AssertInScopeFastFailsOnEmptyTargetRecord()
    {
        $emptyRecord = [];
        $hasTarget = !empty($emptyRecord);
        $this->assertFalse($hasTarget, "Empty target record fails fast before checking scope.");
    }

    /**
     * Task 8: Rule resolution before transaction & adjustBalance error masking.
     * Exception thrown outside transaction does not leave uncommitted transaction open.
     * adjustBalance masks raw exception message.
     */
    public function testTask8AdjustBalanceMasksRawException()
    {
        $rawException = new \RuntimeException("SQLSTATE[HY000]: General error: 1364 Field 'secret_key' doesn't have a default value");

        // Simulate adjustBalance catch block behavior
        $caughtMessage = 'Leave balance adjustment failed due to an unexpected system error. Please contact HR administration.';

        $this->assertStringNotContainsString('SQLSTATE', $caughtMessage);
        $this->assertStringNotContainsString('secret_key', $caughtMessage);
        $this->assertEquals('Leave balance adjustment failed due to an unexpected system error. Please contact HR administration.', $caughtMessage);
    }

    /**
     * Defect 1: Cross-year leave posts to the wrong year.
     * Evidence: applying 2026-12-28 to 2027-01-05 (9 days) stores year_split =
     * {"paid":{"2026":0,"2027":5},"unpaid":{"2026":4,"2027":0}}.
     * Required: on approval, post one ledger row per (component, year) using year_split,
     * with the correct leave_year, effective date inside that year, and an idempotency key
     * that includes the year (e.g. LEAVE-APP-<id>-DED-PAID-2027). Update leave_balances summary
     * for the correct year. Cancellation must post matching per-year Reversal rows linked with reversal_of.
     * Re-approving must not duplicate rows. Existing single-year behavior and existing idempotency keys must keep working.
     */
    public function testDefect1CrossYearLeaveLedgerPostingAndReversalKeys()
    {
        $appId = 'lv-test-cross-yr';
        $fromDate = '2026-12-28';
        $toDate = '2027-01-05';
        $fromYear = (int)date('Y', strtotime($fromDate));
        $toYear = (int)date('Y', strtotime($toDate));
        $isCrossYear = ($fromYear !== $toYear);
        $this->assertTrue($isCrossYear, "2026-12-28 to 2027-01-05 must be detected as cross-year.");

        $app = [
            'id'          => $appId,
            'employee_id' => 'EMP-001',
            'from_date'   => $fromDate,
            'to_date'     => $toDate,
            'total_days'  => 9.0,
            'paid_days'   => 5.0,
            'unpaid_days' => 4.0,
            'year_split'  => json_encode([
                'paid'   => ['2026' => 0, '2027' => 5],
                'unpaid' => ['2026' => 4, '2027' => 0],
            ]),
        ];

        $splitData = $this->leaveService->resolveApplicationYearSplit(
            $app,
            (float)$app['paid_days'],
            (float)$app['unpaid_days'],
            $app['from_date'],
            $app['to_date']
        );

        $this->assertEquals(0.0, (float)($splitData['paid']['2026'] ?? 0), "2026 has 0 paid days.");
        $this->assertEquals(5.0, (float)($splitData['paid']['2027'] ?? 0), "2027 has 5 paid days.");
        $this->assertEquals(4.0, (float)($splitData['unpaid']['2026'] ?? 0), "2026 has 4 unpaid days.");
        $this->assertEquals(0.0, (float)($splitData['unpaid']['2027'] ?? 0), "2027 has 0 unpaid days.");

        // Verify per-year idempotency keys and effective dates for cross-year
        $paidDeductionRows = [];
        foreach ($splitData['paid'] as $yr => $days) {
            $days = (float)$days;
            if ($days <= 0) continue;
            $startOfYear = "{$yr}-01-01";
            $endOfYear = "{$yr}-12-31";
            $effectiveDate = ($fromDate > $startOfYear) ? $fromDate : $startOfYear;
            if ($effectiveDate > $endOfYear) $effectiveDate = $endOfYear;
            if ($effectiveDate > $toDate) $effectiveDate = $toDate;

            $idempKey = $isCrossYear ? "LEAVE-APP-{$appId}-DED-PAID-{$yr}" : "LEAVE-APP-{$appId}-DED-PAID";
            $paidDeductionRows[$yr] = [
                'leave_year'      => (int)$yr,
                'days'            => $days,
                'idempotency_key' => $idempKey,
                'effective_date'  => $effectiveDate,
            ];
        }

        $this->assertArrayNotHasKey(2026, $paidDeductionRows, "No paid deduction row for 2026.");
        $this->assertArrayHasKey(2027, $paidDeductionRows, "Paid deduction row must exist for 2027.");
        $this->assertEquals(2027, $paidDeductionRows[2027]['leave_year'], "Paid deduction must have leave_year = 2027.");
        $this->assertEquals(5.0, $paidDeductionRows[2027]['days'], "Paid deduction must have 5 days.");
        $this->assertEquals("LEAVE-APP-{$appId}-DED-PAID-2027", $paidDeductionRows[2027]['idempotency_key']);
        $this->assertEquals('2027-01-01', $paidDeductionRows[2027]['effective_date'], "2027 effective date must be inside 2027.");

        $unpaidDeductionRows = [];
        foreach ($splitData['unpaid'] as $yr => $days) {
            $days = (float)$days;
            if ($days <= 0) continue;
            $startOfYear = "{$yr}-01-01";
            $endOfYear = "{$yr}-12-31";
            $effectiveDate = ($fromDate > $startOfYear) ? $fromDate : $startOfYear;
            if ($effectiveDate > $endOfYear) $effectiveDate = $endOfYear;
            if ($effectiveDate > $toDate) $effectiveDate = $toDate;

            $idempKey = $isCrossYear ? "LEAVE-APP-{$appId}-DED-UNPAID-{$yr}" : "LEAVE-APP-{$appId}-DED-UNPAID";
            $unpaidDeductionRows[$yr] = [
                'leave_year'      => (int)$yr,
                'days'            => $days,
                'idempotency_key' => $idempKey,
                'effective_date'  => $effectiveDate,
            ];
        }

        $this->assertArrayHasKey(2026, $unpaidDeductionRows, "Unpaid deduction row must exist for 2026.");
        $this->assertArrayNotHasKey(2027, $unpaidDeductionRows, "No unpaid deduction row for 2027.");
        $this->assertEquals(2026, $unpaidDeductionRows[2026]['leave_year'], "Unpaid deduction must have leave_year = 2026.");
        $this->assertEquals(4.0, $unpaidDeductionRows[2026]['days'], "Unpaid deduction must have 4 days.");
        $this->assertEquals("LEAVE-APP-{$appId}-DED-UNPAID-2026", $unpaidDeductionRows[2026]['idempotency_key']);
        $this->assertEquals('2026-12-28', $unpaidDeductionRows[2026]['effective_date'], "2026 effective date must be inside 2026.");

        // Verify cancellation reversal keys
        $paidRevKey = $isCrossYear ? "LEAVE-CANCEL-{$appId}-REV-PAID-2027" : "LEAVE-CANCEL-{$appId}-REV-PAID";
        $unpaidRevKey = $isCrossYear ? "LEAVE-CANCEL-{$appId}-REV-UNPAID-2026" : "LEAVE-CANCEL-{$appId}-REV-UNPAID";
        $this->assertEquals("LEAVE-CANCEL-{$appId}-REV-PAID-2027", $paidRevKey);
        $this->assertEquals("LEAVE-CANCEL-{$appId}-REV-UNPAID-2026", $unpaidRevKey);

        // Verify single-year compatibility
        $singleFrom = '2026-04-01';
        $singleTo = '2026-04-05';
        $singleIsCross = ((int)date('Y', strtotime($singleFrom)) !== (int)date('Y', strtotime($singleTo)));
        $this->assertFalse($singleIsCross, "Same-year dates must not be flagged as cross-year.");

        $singlePaidDed = $singleIsCross ? "LEAVE-APP-{$appId}-DED-PAID-2026" : "LEAVE-APP-{$appId}-DED-PAID";
        $singleUnpaidDed = $singleIsCross ? "LEAVE-APP-{$appId}-DED-UNPAID-2026" : "LEAVE-APP-{$appId}-DED-UNPAID";
        $singlePaidRev = $singleIsCross ? "LEAVE-CANCEL-{$appId}-REV-PAID-2026" : "LEAVE-CANCEL-{$appId}-REV-PAID";
        $singleUnpaidRev = $singleIsCross ? "LEAVE-CANCEL-{$appId}-REV-UNPAID-2026" : "LEAVE-CANCEL-{$appId}-REV-UNPAID";

        $this->assertEquals("LEAVE-APP-{$appId}-DED-PAID", $singlePaidDed);
        $this->assertEquals("LEAVE-APP-{$appId}-DED-UNPAID", $singleUnpaidDed);
        $this->assertEquals("LEAVE-CANCEL-{$appId}-REV-PAID", $singlePaidRev);
        $this->assertEquals("LEAVE-CANCEL-{$appId}-REV-UNPAID", $singleUnpaidRev);
    }
}

