<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class AssetFixesAndImprovementsTest extends TestCase
{
    /**
     * 1. store(): Assignment email uses asset_name instead of name
     */
    public function testStoreEmailUsesAssetName()
    {
        $data = [
            'id'            => 'ast-test-1',
            'asset_name'    => 'MacBook Pro M3 Max',
            'asset_code'    => 'AST-MBP-001',
            'serial_number' => 'SN-12345678',
        ];

        // Ensure key is asset_name
        $resolvedName = $data['asset_name'] ?? ($data['name'] ?? 'Company Equipment');
        $this->assertEquals('MacBook Pro M3 Max', $resolvedName);
        $this->assertNotEquals('Company Equipment', $resolvedName);
    }

    /**
     * 2. assign(): $actor undefined fix uses currentUser and currentUserId
     */
    public function testAssignUsesCurrentUserInsteadOfActor()
    {
        $userId = 'usr-admin-123';
        $user = ['id' => $userId, 'name' => 'Sarah Connor'];

        $senderId = $userId;
        $senderName = $user['name'] ?? 'Asset Operations';

        $this->assertEquals('usr-admin-123', $senderId);
        $this->assertEquals('Sarah Connor', $senderName);
    }

    /**
     * 3. store(): Wrap asset insert + recordAssignment in one transaction
     */
    public function testStoreTransactionIntegrity()
    {
        // When initial status is 'Assigned', both asset insert and assignment record must be recorded
        $status = 'Assigned';
        $assignedTo = 'emp-001';

        $requiresTransaction = ($status === 'Assigned' && !empty($assignedTo));
        $this->assertTrue($requiresTransaction);
    }

    /**
     * 4. AssetCategoryController: Whitelist depreciation_method and validate useful_life_years
     */
    public function testCategoryDepreciationValidation()
    {
        $allowedMethods = ['none', 'straight_line'];

        // Valid cases
        $this->assertTrue(in_array('none', $allowedMethods, true));
        $this->assertTrue(in_array('straight_line', $allowedMethods, true));

        // Invalid methods
        $this->assertFalse(in_array('double_declining', $allowedMethods, true));
        $this->assertFalse(in_array('sum_of_years', $allowedMethods, true));

        // Rule: when method is straight_line, useful_life_years must be > 0
        $validateMethodAndLife = function ($method, $life) use ($allowedMethods) {
            if (!in_array($method, $allowedMethods, true)) {
                return ['valid' => false, 'code' => 422, 'error' => 'Invalid depreciation method'];
            }
            if ($method === 'straight_line' && ($life === null || $life <= 0)) {
                return ['valid' => false, 'code' => 422, 'error' => 'Useful life must be > 0'];
            }
            return ['valid' => true, 'code' => 200];
        };

        $resNone = $validateMethodAndLife('none', null);
        $this->assertTrue($resNone['valid']);

        $resSLValid = $validateMethodAndLife('straight_line', 5);
        $this->assertTrue($resSLValid['valid']);

        $resSLZero = $validateMethodAndLife('straight_line', 0);
        $this->assertFalse($resSLZero['valid']);
        $this->assertEquals(422, $resSLZero['code']);

        $resSLNull = $validateMethodAndLife('straight_line', null);
        $this->assertFalse($resSLNull['valid']);
        $this->assertEquals(422, $resSLNull['code']);

        $resInvalid = $validateMethodAndLife('other', 5);
        $this->assertFalse($resInvalid['valid']);
        $this->assertEquals(422, $resInvalid['code']);
    }

    /**
     * 5. exportCsv(): Warranty Expiry, Written-Off At, Write-Off Reason, Recovery Amount columns
     * and purchase_value redacted without assets.export
     */
    public function testExportCsvColumnsAndRedaction()
    {
        $expectedHeaders = [
            'Asset ID', 'Asset Code', 'Asset Name', 'Category Code', 'Category', 'Serial Number',
            'Status', 'Condition', 'Assignee Code', 'Assignee Name', 'Assigned Date', 'Purchase Date', 'Purchase Value',
            'Warranty Expiry', 'Written-Off At', 'Write-Off Reason', 'Recovery Amount'
        ];

        $this->assertContains('Warranty Expiry', $expectedHeaders);
        $this->assertContains('Written-Off At', $expectedHeaders);
        $this->assertContains('Write-Off Reason', $expectedHeaders);
        $this->assertContains('Recovery Amount', $expectedHeaders);

        // Permission redaction test
        $canExport = false;
        $rowValWithNoExport = $canExport ? '1500.00' : '';
        $this->assertSame('', $rowValWithNoExport);

        $canExport = true;
        $rowValWithExport = $canExport ? '1500.00' : '';
        $this->assertSame('1500.00', $rowValWithExport);

        // Sanitize check
        $sanitize = function ($val) {
            if ($val === null) return '';
            $str = (string)$val;
            if (in_array(substr($str, 0, 1), ['=', '+', '-', '@', "\t", "\r"], true)) {
                return "'" . $str;
            }
            return $str;
        };

        $this->assertEquals("'=1+2", $sanitize('=1+2'));
        $this->assertEquals('Clean Value', $sanitize('Clean Value'));
    }

    /**
     * 6. apiStats(): Exclude Written-Off from total_purchase_value and count unknown statuses separately
     */
    public function testApiStatsExcludesWrittenOffAndCountsUnknown()
    {
        $assets = [
            ['status' => 'Available', 'purchase_value' => 1000.0],
            ['status' => 'Assigned', 'purchase_value' => 2000.0],
            ['status' => 'Maintenance', 'purchase_value' => 500.0],
            ['status' => 'Written-Off', 'purchase_value' => 1200.0],
            ['status' => 'Disposed', 'purchase_value' => 300.0], // Unknown / other status
            ['status' => '', 'purchase_value' => 200.0],         // Unknown / other status
        ];

        $total = count($assets);
        $assigned = 0;
        $available = 0;
        $maintenance = 0;
        $writtenOff = 0;
        $unknown = 0;
        $totalValue = 0.0;
        $writtenOffValue = 0.0;

        foreach ($assets as $a) {
            $st = strtolower(trim((string)($a['status'] ?? '')));
            if ($st === 'assigned') {
                $assigned++;
                $totalValue += (float)($a['purchase_value'] ?? 0.0);
            } elseif ($st === 'maintenance') {
                $maintenance++;
                $totalValue += (float)($a['purchase_value'] ?? 0.0);
            } elseif ($st === 'available') {
                $available++;
                $totalValue += (float)($a['purchase_value'] ?? 0.0);
            } elseif ($st === 'written-off') {
                $writtenOff++;
                $writtenOffValue += (float)($a['purchase_value'] ?? 0.0);
            } else {
                $unknown++;
                $totalValue += (float)($a['purchase_value'] ?? 0.0);
            }
        }

        $this->assertEquals(6, $total);
        $this->assertEquals(1, $available);
        $this->assertEquals(1, $assigned);
        $this->assertEquals(1, $maintenance);
        $this->assertEquals(1, $writtenOff);
        $this->assertEquals(2, $unknown); // Disposed and empty are not counted as available!
        $this->assertEquals(4000.0, $totalValue); // Excludes 1200.0 written off!
        $this->assertEquals(1200.0, $writtenOffValue);
    }

    /**
     * 7. delete(): Block deleting a Written-Off asset with 422 to protect recovery records and history
     */
    public function testDeleteBlocksWrittenOffAssetWith422()
    {
        $writtenOffAsset1 = [
            'id'             => 'ast-wo-01',
            'asset_name'     => 'Damaged Laptop',
            'status'         => 'Written-Off',
            'written_off_at' => '2026-11-01 10:00:00',
        ];

        $writtenOffAsset2 = [
            'id'             => 'ast-wo-02',
            'asset_name'     => 'Obsolete Phone',
            'status'         => 'written-off',
            'written_off_at' => null,
        ];

        $availableAsset = [
            'id'             => 'ast-avail-01',
            'asset_name'     => 'Available Display',
            'status'         => 'Available',
            'assigned_to'    => null,
            'written_off_at' => null,
        ];

        $checkDeleteAllowed = function (array $asset) {
            if (strcasecmp($asset['status'] ?? '', 'Written-Off') === 0 || !empty($asset['written_off_at'])) {
                return ['allowed' => false, 'code' => 422, 'message' => 'Deletion prohibited: Cannot delete a Written-Off asset so recovery records and history are not lost.'];
            }
            if (strtolower($asset['status'] ?? '') === 'assigned' || !empty($asset['assigned_to'])) {
                return ['allowed' => false, 'code' => 400, 'message' => 'Deletion prohibited: Cannot delete an asset currently assigned to an employee. Return custody to inventory first.'];
            }
            return ['allowed' => true, 'code' => 200];
        };

        $res1 = $checkDeleteAllowed($writtenOffAsset1);
        $this->assertFalse($res1['allowed']);
        $this->assertEquals(422, $res1['code']);

        $res2 = $checkDeleteAllowed($writtenOffAsset2);
        $this->assertFalse($res2['allowed']);
        $this->assertEquals(422, $res2['code']);

        $res3 = $checkDeleteAllowed($availableAsset);
        $this->assertTrue($res3['allowed']);
        $this->assertEquals(200, $res3['code']);
    }

    /**
     * 8. Write-Off button eligibility: Available, Maintenance or Assigned (not Written-Off) when user has assets.writeoff
     */
    public function testWriteOffButtonVisibilityAndLiabilitySelectorLogic()
    {
        $canWriteOff = true;

        $isWriteOffVisible = function ($status, $hasPerm) {
            return !empty($hasPerm) && in_array($status, ['Available', 'Maintenance', 'Assigned'], true) && ($status !== 'Written-Off');
        };

        $this->assertTrue($isWriteOffVisible('Available', $canWriteOff));
        $this->assertTrue($isWriteOffVisible('Maintenance', $canWriteOff));
        $this->assertTrue($isWriteOffVisible('Assigned', $canWriteOff));
        $this->assertFalse($isWriteOffVisible('Written-Off', $canWriteOff));
        $this->assertFalse($isWriteOffVisible('Available', false));

        // Write-off modal employee selector: only for liability reasons when asset is not assigned
        $showEmployeeSelector = function ($assignedTo, $reason) {
            $isNotAssigned = empty($assignedTo);
            $isLiability = in_array($reason, ['lost_by_employee', 'damaged_by_employee'], true);
            return $isNotAssigned && $isLiability;
        };

        // When asset is unassigned:
        $this->assertTrue($showEmployeeSelector(null, 'lost_by_employee'));
        $this->assertTrue($showEmployeeSelector(null, 'damaged_by_employee'));
        $this->assertFalse($showEmployeeSelector(null, 'damaged_beyond_repair'));
        $this->assertFalse($showEmployeeSelector(null, 'scrapped'));
        $this->assertFalse($showEmployeeSelector(null, 'stolen'));

        // When asset is assigned:
        $this->assertFalse($showEmployeeSelector('emp-001', 'lost_by_employee'));
        $this->assertFalse($showEmployeeSelector('emp-001', 'damaged_by_employee'));
        $this->assertFalse($showEmployeeSelector('emp-001', 'damaged_beyond_repair'));
    }
}
