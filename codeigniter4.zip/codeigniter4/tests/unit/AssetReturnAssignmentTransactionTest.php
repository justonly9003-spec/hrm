<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use App\Controllers\Assets\AssetController;
use App\Models\AssetModel;
use App\Models\AssetAssignmentModel;
use Config\Database;

/**
 * DB-backed unit tests for AssetController and AssetAssignmentModel transaction integrity:
 * 1. returnAsset() requires status == 'Assigned', assigned_to not empty, and active assignment record.
 * 2. Returning a Written-Off asset returns 422 and does NOT change status to Available.
 * 3. Returning an Available asset returns 422 and changes nothing in DB.
 * 4. Returning an asset without active assignment record returns 422 and changes nothing in DB.
 * 5. Successful returnAsset() updates asset to Available and closes active assignment history atomically.
 * 6. assign() rejects Written-Off assets with 422.
 * 7. assign() rejects already assigned assets with 400.
 * 8. writeOff() on an assigned asset properly updates asset to Written-Off and closes assignment history.
 * 9. recordAssignment() returns null on failure instead of always returning UUID.
 */
class AssetReturnAssignmentTransactionTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected static bool $schemaInitialized = false;

    protected string $tenantCompanyId = 'comp-asset-tx-01';
    protected string $tenantBranchId  = 'branch-asset-tx-01';
    protected string $tenantDeptId    = 'dept-asset-tx-01';
    protected string $tenantDesgId    = 'desg-asset-tx-01';
    protected string $tenantEmpId     = 'emp-asset-tx-01';
    protected string $tenantCatId     = 'cat-asset-tx-01';

    protected array $adminUser = [];

    public static function setUpBeforeClass(): void
    {
        parent::setUpBeforeClass();
        static::ensureSchema();
    }

    public static function registerSqliteFunctions($db): void
    {
        try {
            $rawConn = $db->connID ?? null;
            if ($rawConn instanceof \SQLite3) {
                $rawConn->createFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->createFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            } elseif (is_object($rawConn) && method_exists($rawConn, 'sqliteCreateFunction')) {
                $rawConn->sqliteCreateFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->sqliteCreateFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            }
        } catch (\Throwable $e) {
            // ignore
        }
    }

    protected static function ensureSchema(): void
    {
        $db = Database::connect();
        static::registerSqliteFunctions($db);

        $schemaFile = __DIR__ . '/Rules/schema.sqlite.sql';
        if (file_exists($schemaFile)) {
            $sql = file_get_contents($schemaFile);
            $statements = array_filter(array_map('trim', explode(';', $sql)));
            foreach ($statements as $stmt) {
                if (!empty($stmt)) {
                    try {
                        $db->query($stmt);
                    } catch (\Throwable $e) {
                        // ignore
                    }
                }
            }
        }

        // Ensure asset tables exist
        try {
            $db->query("CREATE TABLE IF NOT EXISTS company_assets (
                id VARCHAR(36) PRIMARY KEY,
                company_id VARCHAR(36) NOT NULL,
                name VARCHAR(150) NOT NULL,
                asset_code VARCHAR(50) NOT NULL,
                category_id VARCHAR(36) NULL,
                category VARCHAR(100) NULL,
                serial_number VARCHAR(100) NULL,
                purchase_date DATE NULL,
                purchase_value DECIMAL(15,2) DEFAULT 0.00,
                warranty_expiry DATE NULL,
                status VARCHAR(30) DEFAULT 'Available',
                condition_status VARCHAR(30) DEFAULT 'good',
                assigned_to VARCHAR(36) NULL,
                assigned_date DATE NULL,
                written_off_at DATETIME NULL,
                written_off_reason VARCHAR(100) NULL,
                written_off_by_employee_id VARCHAR(36) NULL,
                recovery_amount DECIMAL(15,2) DEFAULT 0.00,
                notes TEXT NULL,
                deleted_at DATETIME NULL,
                created_at DATETIME NULL,
                updated_at DATETIME NULL
            )");

            $db->query("CREATE TABLE IF NOT EXISTS asset_assignments (
                id VARCHAR(36) PRIMARY KEY,
                company_id VARCHAR(36) NOT NULL,
                asset_id VARCHAR(36) NOT NULL,
                employee_id VARCHAR(36) NOT NULL,
                assigned_date DATE NOT NULL,
                returned_date DATE NULL,
                condition_on_assign VARCHAR(30) DEFAULT 'good',
                condition_on_return VARCHAR(30) NULL,
                assigned_by VARCHAR(36) NULL,
                returned_by VARCHAR(36) NULL,
                notes TEXT NULL,
                created_at DATETIME NULL,
                updated_at DATETIME NULL
            )");

            $db->query("CREATE TABLE IF NOT EXISTS asset_categories (
                id VARCHAR(36) PRIMARY KEY,
                company_id VARCHAR(36) NOT NULL,
                name VARCHAR(100) NOT NULL,
                code VARCHAR(30) NULL,
                depreciation_method VARCHAR(30) DEFAULT 'none',
                useful_life_years INT NULL,
                salvage_value_percent DECIMAL(5,2) DEFAULT 0.00,
                status VARCHAR(20) DEFAULT 'active',
                created_at DATETIME NULL,
                updated_at DATETIME NULL
            )");
        } catch (\Throwable $e) {
            // ignore
        }
    }

    protected function setUp(): void
    {
        parent::setUp();
        static::ensureSchema();

        $db = Database::connect();
        static::registerSqliteFunctions($db);

        // Seed company
        $db->table('companies')->replace([
            'id'     => $this->tenantCompanyId,
            'name'   => 'Asset TX Test Co',
            'code'   => 'COMP-ASTX',
            'status' => 'Active',
        ]);

        // Seed employee
        $db->table('employees')->replace([
            'id'            => $this->tenantEmpId,
            'company_id'    => $this->tenantCompanyId,
            'employee_code' => 'EMP-ASTX-01',
            'first_name'    => 'John',
            'last_name'     => 'AssetHolder',
            'email'         => 'holder@test.com',
            'gender'        => 'male',
            'dob'           => '1990-01-01',
            'status'        => 'active',
            'created_at'    => date('Y-m-d H:i:s'),
            'updated_at'    => date('Y-m-d H:i:s'),
        ]);

        // Seed category
        $db->table('asset_categories')->replace([
            'id'                  => $this->tenantCatId,
            'company_id'          => $this->tenantCompanyId,
            'name'                => 'IT Hardware',
            'code'                => 'ITHW',
            'depreciation_method' => 'straight_line',
            'useful_life_years'   => 3,
            'status'              => 'active',
        ]);

        // Seed admin user
        $this->adminUser = [
            'id'                  => 'usr-astx-admin-01',
            'company_id'          => $this->tenantCompanyId,
            'username'            => 'astx_admin',
            'name'                => 'Asset Admin',
            'email'               => 'admin@test.com',
            'role'                => 'Company Admin',
            'role_code'           => 'company_admin',
            'role_id'             => 'role-astx-admin',
            'selected_company_id' => $this->tenantCompanyId,
            'permissions'         => ['*'],
        ];

        $db->table('users')->replace([
            'id'            => $this->adminUser['id'],
            'company_id'    => $this->tenantCompanyId,
            'username'      => $this->adminUser['username'],
            'email'         => $this->adminUser['email'],
            'password_hash' => password_hash('Secret123!', PASSWORD_BCRYPT),
            'role_id'       => $this->adminUser['role_id'],
            'status'        => 'Active',
        ]);
    }

    protected function setupController(array $postData = [], bool $isAjax = true): AssetController
    {
        $session = \Config\Services::session();
        $session->set('user', [
            'id'                  => $this->adminUser['id'],
            'username'            => $this->adminUser['username'],
            'name'                => $this->adminUser['name'],
            'email'               => $this->adminUser['email'],
            'role'                => $this->adminUser['role'],
            'role_code'           => $this->adminUser['role_code'],
            'role_id'             => $this->adminUser['role_id'],
            'company_id'          => $this->adminUser['company_id'],
            'selected_company_id' => $this->adminUser['company_id'],
            'permissions'         => ['*'],
        ]);

        $_SERVER['REQUEST_METHOD'] = 'POST';
        if ($isAjax) {
            $_SERVER['HTTP_ACCEPT'] = 'application/json';
            $_SERVER['HTTP_X_REQUESTED_WITH'] = 'xmlhttprequest';
        } else {
            unset($_SERVER['HTTP_ACCEPT'], $_SERVER['HTTP_X_REQUESTED_WITH']);
        }
        $_POST = $postData;

        $request = \Config\Services::request();
        $response = \Config\Services::response();
        $logger = \Config\Services::logger();

        $controller = new AssetController();
        $controller->initController($request, $response, $logger);

        return $controller;
    }

    /**
     * Test 1: Returning a Written-Off asset returns 422 and does NOT change status to Available.
     */
    public function testReturnWrittenOffAssetReturns422AndDoesNotModifyDb(): void
    {
        $db = Database::connect();
        $assetId = 'ast-written-off-01';
        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'name'             => 'Decommissioned Server',
            'asset_code'       => 'SRV-WO-01',
            'status'           => 'Written-Off',
            'condition_status' => 'damaged',
            'assigned_to'      => null,
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->setupController(['condition_status' => 'good']);
        $res = $controller->returnAsset($assetId);
        $body = json_decode($res->getBody(), true);

        $this->assertEquals(422, $res->getStatusCode());
        $this->assertFalse($body['success']);
        $this->assertEquals('Written-Off assets cannot be returned.', $body['message']);

        // Assert DB unchanged
        $asset = $db->table('company_assets')->where('id', $assetId)->get()->getRowArray();
        $this->assertEquals('Written-Off', $asset['status'], 'Status must remain Written-Off');
        $this->assertEquals('damaged', $asset['condition_status']);
    }

    /**
     * Test 2: Returning an Available asset returns 422 and changes nothing in DB.
     */
    public function testReturnAvailableAssetReturns422AndDoesNotModifyDb(): void
    {
        $db = Database::connect();
        $assetId = 'ast-available-01';
        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'name'             => 'In-Stock Keyboard',
            'asset_code'       => 'KBD-AVL-01',
            'status'           => 'Available',
            'condition_status' => 'new',
            'assigned_to'      => null,
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->setupController(['condition_status' => 'good']);
        $res = $controller->returnAsset($assetId);
        $body = json_decode($res->getBody(), true);

        $this->assertEquals(422, $res->getStatusCode());
        $this->assertFalse($body['success']);
        $this->assertEquals('Only assigned assets can be returned.', $body['message']);

        // Assert DB unchanged
        $asset = $db->table('company_assets')->where('id', $assetId)->get()->getRowArray();
        $this->assertEquals('Available', $asset['status']);
        $this->assertEquals('new', $asset['condition_status']);
    }

    /**
     * Test 3: Returning an asset without an active assignment record returns 422 and changes nothing in DB.
     */
    public function testReturnAssetWithoutActiveAssignmentReturns422(): void
    {
        $db = Database::connect();
        $assetId = 'ast-missing-history-01';
        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'name'             => 'Assigned Monitor Without History',
            'asset_code'       => 'MON-MH-01',
            'status'           => 'Assigned',
            'condition_status' => 'good',
            'assigned_to'      => $this->tenantEmpId,
            'assigned_date'    => '2024-01-15',
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        // Ensure no active assignment exists for this asset in asset_assignments
        $db->table('asset_assignments')->where('asset_id', $assetId)->delete();

        $controller = $this->setupController(['condition_status' => 'good']);
        $res = $controller->returnAsset($assetId);
        $body = json_decode($res->getBody(), true);

        $this->assertEquals(422, $res->getStatusCode());
        $this->assertFalse($body['success']);
        $this->assertEquals('No active assignment record found for this asset.', $body['message']);

        // Assert DB unchanged: asset still Assigned to tenantEmpId
        $asset = $db->table('company_assets')->where('id', $assetId)->get()->getRowArray();
        $this->assertEquals('Assigned', $asset['status']);
        $this->assertEquals($this->tenantEmpId, $asset['assigned_to']);
    }

    /**
     * Test 4: Successful returnAsset() updates asset to Available and closes active assignment history atomically.
     */
    public function testSuccessfulReturnUpdatesAssetAndClosesAssignment(): void
    {
        $db = Database::connect();
        $assetId = 'ast-valid-return-01';
        $assignmentId = 'asgn-valid-01';

        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'name'             => 'Corporate Laptop',
            'asset_code'       => 'LAP-VR-01',
            'status'           => 'Assigned',
            'condition_status' => 'good',
            'assigned_to'      => $this->tenantEmpId,
            'assigned_date'    => '2024-01-10',
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $db->table('asset_assignments')->replace([
            'id'                  => $assignmentId,
            'company_id'          => $this->tenantCompanyId,
            'asset_id'            => $assetId,
            'employee_id'         => $this->tenantEmpId,
            'assigned_date'       => '2024-01-10',
            'returned_date'       => null,
            'condition_on_assign' => 'good',
            'assigned_by'         => $this->adminUser['id'],
            'created_at'          => date('Y-m-d H:i:s'),
            'updated_at'          => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->setupController([
            'condition_status' => 'good',
            'notes'            => 'Returned in pristine condition'
        ]);
        $res = $controller->returnAsset($assetId);
        $body = json_decode($res->getBody(), true);

        $this->assertEquals(200, $res->getStatusCode());
        $this->assertTrue($body['success']);

        // Assert DB asset updated
        $asset = $db->table('company_assets')->where('id', $assetId)->get()->getRowArray();
        $this->assertEquals('Available', $asset['status']);
        $this->assertNull($asset['assigned_to']);
        $this->assertNull($asset['assigned_date']);

        // Assert assignment history closed
        $asgn = $db->table('asset_assignments')->where('id', $assignmentId)->get()->getRowArray();
        $this->assertNotNull($asgn['returned_date']);
        $this->assertEquals('good', $asgn['condition_on_return']);
    }

    /**
     * Test 5: assign() rejects Written-Off assets with 422.
     */
    public function testAssignWrittenOffAssetReturns422(): void
    {
        $db = Database::connect();
        $assetId = 'ast-assign-wo-01';
        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'name'             => 'Scrapped Laptop',
            'asset_code'       => 'LAP-SCRAP-01',
            'status'           => 'Written-Off',
            'condition_status' => 'damaged',
            'assigned_to'      => null,
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->setupController([
            'asset_id'         => $assetId,
            'employee_id'      => $this->tenantEmpId,
            'assigned_date'    => date('Y-m-d'),
            'condition_status' => 'good',
        ]);
        $res = $controller->assign();
        $body = json_decode($res->getBody(), true);

        $this->assertEquals(422, $res->getStatusCode());
        $this->assertFalse($body['success']);
        $this->assertEquals('Written-Off assets cannot be assigned.', $body['message']);

        // Assert DB unchanged
        $asset = $db->table('company_assets')->where('id', $assetId)->get()->getRowArray();
        $this->assertEquals('Written-Off', $asset['status']);
        $this->assertNull($asset['assigned_to']);
    }

    /**
     * Test 6: assign() rejects already assigned assets with 400.
     */
    public function testAssignAlreadyAssignedAssetReturns400(): void
    {
        $db = Database::connect();
        $assetId = 'ast-already-assigned-01';
        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'name'             => 'Assigned Desktop',
            'asset_code'       => 'DSK-AA-01',
            'status'           => 'Assigned',
            'condition_status' => 'good',
            'assigned_to'      => $this->tenantEmpId,
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->setupController([
            'asset_id'         => $assetId,
            'employee_id'      => $this->tenantEmpId,
            'assigned_date'    => date('Y-m-d'),
            'condition_status' => 'good',
        ]);
        $res = $controller->assign();
        $body = json_decode($res->getBody(), true);

        $this->assertEquals(400, $res->getStatusCode());
        $this->assertFalse($body['success']);
        $this->assertEquals('Asset is currently assigned. Please return it to inventory before re-allocating.', $body['message']);
    }

    /**
     * Test 7: writeOff() on an assigned asset properly updates asset to Written-Off and closes assignment history.
     */
    public function testWriteOffAssignedAssetClosesAssignmentHistory(): void
    {
        $db = Database::connect();
        $assetId = 'ast-wo-assigned-01';
        $assignmentId = 'asgn-wo-01';

        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'category_id'      => $this->tenantCatId,
            'name'             => 'Damaged Smartphone',
            'asset_code'       => 'PHN-DAM-01',
            'status'           => 'Assigned',
            'condition_status' => 'good',
            'assigned_to'      => $this->tenantEmpId,
            'assigned_date'    => '2024-02-01',
            'purchase_date'    => '2023-01-01',
            'purchase_value'   => 50000.00,
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $db->table('asset_assignments')->replace([
            'id'                  => $assignmentId,
            'company_id'          => $this->tenantCompanyId,
            'asset_id'            => $assetId,
            'employee_id'         => $this->tenantEmpId,
            'assigned_date'       => '2024-02-01',
            'returned_date'       => null,
            'condition_on_assign' => 'good',
            'assigned_by'         => $this->adminUser['id'],
            'created_at'          => date('Y-m-d H:i:s'),
            'updated_at'          => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->setupController([
            'reason' => 'damaged_beyond_repair',
            'notes'  => 'Crushed during transit'
        ]);
        $res = $controller->writeOff($assetId);
        $body = json_decode($res->getBody(), true);

        $this->assertEquals(200, $res->getStatusCode());
        $this->assertTrue($body['success']);

        // Assert asset Written-Off and assigned_to cleared
        $asset = $db->table('company_assets')->where('id', $assetId)->get()->getRowArray();
        $this->assertEquals('Written-Off', $asset['status']);
        $this->assertNull($asset['assigned_to']);

        // Assert assignment closed
        $asgn = $db->table('asset_assignments')->where('id', $assignmentId)->get()->getRowArray();
        $this->assertNotNull($asgn['returned_date']);
        $this->assertEquals('damaged', $asgn['condition_on_return']);
    }

    /**
     * Test 8: AssetAssignmentModel::recordAssignment() returns valid ID on success.
     */
    public function testRecordAssignmentReturnsIdOnSuccess(): void
    {
        $model = new AssetAssignmentModel();
        $assetId = 'ast-rec-01';

        $id = $model->recordAssignment(
            $this->tenantCompanyId,
            $assetId,
            $this->tenantEmpId,
            date('Y-m-d'),
            'good',
            $this->adminUser['id'],
            'Test assign'
        );

        $this->assertNotNull($id);
        $this->assertIsString($id);

        $db = Database::connect();
        $row = $db->table('asset_assignments')->where('id', $id)->get()->getRowArray();
        $this->assertNotNull($row);
        $this->assertEquals($assetId, $row['asset_id']);
    }

    /**
     * Test 9: assign() rejects Maintenance assets with 400.
     */
    public function testAssignMaintenanceAssetReturns400(): void
    {
        $db = Database::connect();
        $assetId = 'ast-assign-maint-01';
        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'name'             => 'Server in Maintenance',
            'asset_code'       => 'SRV-MNT-01',
            'status'           => 'Maintenance',
            'condition_status' => 'maintenance',
            'assigned_to'      => null,
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->setupController([
            'asset_id'         => $assetId,
            'employee_id'      => $this->tenantEmpId,
            'assigned_date'    => date('Y-m-d'),
            'condition_status' => 'good',
        ]);
        $res = $controller->assign();
        $body = json_decode($res->getBody(), true);

        $this->assertEquals(400, $res->getStatusCode());
        $this->assertFalse($body['success']);
        $this->assertEquals('Maintenance assets cannot be assigned.', $body['message']);

        // Assert DB unchanged
        $asset = $db->table('company_assets')->where('id', $assetId)->get()->getRowArray();
        $this->assertEquals('Maintenance', $asset['status']);
        $this->assertNull($asset['assigned_to']);
    }

    /**
     * Test 10: assign() rejects soft-deleted assets with 400.
     */
    public function testAssignSoftDeletedAssetReturns400(): void
    {
        $db = Database::connect();
        $assetId = 'ast-assign-deleted-01';
        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'name'             => 'Soft-Deleted Asset',
            'asset_code'       => 'AST-DEL-01',
            'status'           => 'Available',
            'condition_status' => 'good',
            'assigned_to'      => null,
            'deleted_at'       => date('Y-m-d H:i:s'),
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->setupController([
            'asset_id'         => $assetId,
            'employee_id'      => $this->tenantEmpId,
            'assigned_date'    => date('Y-m-d'),
            'condition_status' => 'good',
        ]);
        $res = $controller->assign();
        $body = json_decode($res->getBody(), true);

        $this->assertEquals(400, $res->getStatusCode());
        $this->assertFalse($body['success']);
        $this->assertEquals('Deleted assets cannot be assigned.', $body['message']);
    }

    /**
     * Test 11: assign() rejects when asset already has an open unclosed assignment record.
     */
    public function testAssignAssetWithOpenAssignmentReturns400(): void
    {
        $db = Database::connect();
        $assetId = 'ast-open-asgn-01';
        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'name'             => 'Available Asset with Dangling Open Assignment',
            'asset_code'       => 'AST-DANG-01',
            'status'           => 'Available',
            'condition_status' => 'good',
            'assigned_to'      => null,
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $db->table('asset_assignments')->replace([
            'id'                  => 'asgn-open-dangling-01',
            'company_id'          => $this->tenantCompanyId,
            'asset_id'            => $assetId,
            'employee_id'         => $this->tenantEmpId,
            'assigned_date'       => '2024-01-01',
            'returned_date'       => null,
            'condition_on_assign' => 'good',
            'assigned_by'         => $this->adminUser['id'],
            'created_at'          => date('Y-m-d H:i:s'),
            'updated_at'          => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->setupController([
            'asset_id'         => $assetId,
            'employee_id'      => $this->tenantEmpId,
            'assigned_date'    => date('Y-m-d'),
            'condition_status' => 'good',
        ]);
        $res = $controller->assign();
        $body = json_decode($res->getBody(), true);

        $this->assertEquals(400, $res->getStatusCode());
        $this->assertFalse($body['success']);
        $this->assertEquals('Asset already has an active open assignment record.', $body['message']);
    }

    /**
     * Test 12: assign() allows employees with status 'probation'.
     */
    public function testAssignProbationEmployeeSucceeds(): void
    {
        $db = Database::connect();
        $probEmpId = 'emp-probation-01';
        $db->table('employees')->replace([
            'id'            => $probEmpId,
            'company_id'    => $this->tenantCompanyId,
            'employee_code' => 'EMP-PROB-01',
            'first_name'    => 'Probation',
            'last_name'     => 'Staff',
            'email'         => 'prob@test.com',
            'gender'        => 'female',
            'dob'           => '1995-01-01',
            'status'        => 'probation',
            'created_at'    => date('Y-m-d H:i:s'),
            'updated_at'    => date('Y-m-d H:i:s'),
        ]);

        $assetId = 'ast-prob-assign-01';
        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'name'             => 'Probation Desk Monitor',
            'asset_code'       => 'MON-PROB-01',
            'status'           => 'Available',
            'condition_status' => 'good',
            'assigned_to'      => null,
            'purchase_date'    => '2023-01-01',
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->setupController([
            'asset_id'         => $assetId,
            'employee_id'      => $probEmpId,
            'assigned_date'    => date('Y-m-d'),
            'condition_status' => 'good',
        ]);
        $res = $controller->assign();
        $body = json_decode($res->getBody(), true);

        $this->assertEquals(200, $res->getStatusCode());
        $this->assertTrue($body['success']);

        $asset = $db->table('company_assets')->where('id', $assetId)->get()->getRowArray();
        $this->assertEquals('Assigned', $asset['status']);
        $this->assertEquals($probEmpId, $asset['assigned_to']);
    }

    /**
     * Test 13: assign() rejects future assigned_date with 422.
     */
    public function testAssignFutureDateReturns422(): void
    {
        $db = Database::connect();
        $assetId = 'ast-future-date-01';
        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'name'             => 'Future Date Asset',
            'asset_code'       => 'AST-FUT-01',
            'status'           => 'Available',
            'condition_status' => 'good',
            'assigned_to'      => null,
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $futureDate = date('Y-m-d', strtotime('+5 days'));
        $controller = $this->setupController([
            'asset_id'         => $assetId,
            'employee_id'      => $this->tenantEmpId,
            'assigned_date'    => $futureDate,
            'condition_status' => 'good',
        ]);
        $res = $controller->assign();
        $body = json_decode($res->getBody(), true);

        $this->assertEquals(422, $res->getStatusCode());
        $this->assertFalse($body['success']);
        $this->assertEquals('Assignment date cannot be in the future.', $body['message']);
    }

    /**
     * Test 14: assign() rejects assigned_date earlier than purchase_date with 422.
     */
    public function testAssignDateBeforePurchaseDateReturns422(): void
    {
        $db = Database::connect();
        $assetId = 'ast-pre-purchase-01';
        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'name'             => 'Purchase Date Asset',
            'asset_code'       => 'AST-PUR-01',
            'status'           => 'Available',
            'condition_status' => 'good',
            'assigned_to'      => null,
            'purchase_date'    => '2024-06-01',
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->setupController([
            'asset_id'         => $assetId,
            'employee_id'      => $this->tenantEmpId,
            'assigned_date'    => '2024-05-15',
            'condition_status' => 'good',
        ]);
        $res = $controller->assign();
        $body = json_decode($res->getBody(), true);

        $this->assertEquals(422, $res->getStatusCode());
        $this->assertFalse($body['success']);
        $this->assertStringContainsString('Assignment date cannot be earlier than the asset purchase date (2024-06-01).', $body['message']);
    }

    /**
     * Test 15: store() allows registering an asset directly as Assigned to an employee on probation.
     */
    public function testStoreAllowsProbationEmployee(): void
    {
        $db = Database::connect();
        $probEmpId = 'emp-prob-store-01';
        $db->table('employees')->replace([
            'id'            => $probEmpId,
            'company_id'    => $this->tenantCompanyId,
            'employee_code' => 'EMP-PSTR-01',
            'first_name'    => 'ProbationStore',
            'last_name'     => 'Staff',
            'email'         => 'probstore@test.com',
            'gender'        => 'male',
            'dob'           => '1992-01-01',
            'status'        => 'probation',
            'created_at'    => date('Y-m-d H:i:s'),
            'updated_at'    => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->setupController([
            'asset_name'       => 'New Onboarding Laptop',
            'category_id'      => $this->tenantCatId,
            'asset_code'       => 'LAP-PROB-STR-01',
            'serial_number'    => 'SN-PROB-001',
            'status'           => 'Assigned',
            'assigned_to'      => $probEmpId,
            'assigned_date'    => date('Y-m-d'),
            'condition_status' => 'new',
        ]);
        $res = $controller->store();
        $body = json_decode($res->getBody(), true);

        $this->assertEquals(200, $res->getStatusCode());
        $this->assertTrue($body['success']);
    }

    /**
     * Test 16: getAssetHistory filters by employeeId for self-only users and redacts admin user IDs
     */
    public function testSelfOnlyAssetHistoryFilteringAndRedactionWithModel(): void
    {
        $db = Database::connect();
        $assetId = 'ast-hist-test-01';

        $otherEmpId = 'emp-hist-other-01';
        $db->table('employees')->replace([
            'id'            => $otherEmpId,
            'company_id'    => $this->tenantCompanyId,
            'employee_code' => 'EMP-HST-02',
            'first_name'    => 'Other',
            'last_name'     => 'Employee',
            'email'         => 'other@test.com',
            'status'        => 'active',
            'created_at'    => date('Y-m-d H:i:s'),
            'updated_at'    => date('Y-m-d H:i:s'),
        ]);

        $db->table('company_assets')->replace([
            'id'             => $assetId,
            'company_id'     => $this->tenantCompanyId,
            'name'           => 'Shared Monitor',
            'asset_code'     => 'MON-HIST-01',
            'category_id'    => $this->tenantCatId,
            'status'         => 'Assigned',
            'assigned_to'    => $otherEmpId,
            'assigned_date'  => '2024-03-01',
            'purchase_value' => 20000.00,
            'created_at'     => date('Y-m-d H:i:s'),
            'updated_at'     => date('Y-m-d H:i:s'),
        ]);

        // First assignment: to tenantEmpId in 2023
        $asgn1 = 'asgn-hist-01';
        $db->table('asset_assignments')->replace([
            'id'                  => $asgn1,
            'company_id'          => $this->tenantCompanyId,
            'asset_id'            => $assetId,
            'employee_id'         => $this->tenantEmpId,
            'assigned_date'       => '2023-01-01',
            'returned_date'       => '2023-12-31',
            'condition_on_assign' => 'good',
            'condition_on_return' => 'good',
            'assigned_by'         => $this->adminUser['id'],
            'returned_by'         => $this->adminUser['id'],
            'created_at'          => date('Y-m-d H:i:s'),
            'updated_at'          => date('Y-m-d H:i:s'),
        ]);

        // Second assignment: to otherEmpId in 2024
        $asgn2 = 'asgn-hist-02';
        $db->table('asset_assignments')->replace([
            'id'                  => $asgn2,
            'company_id'          => $this->tenantCompanyId,
            'asset_id'            => $assetId,
            'employee_id'         => $otherEmpId,
            'assigned_date'       => '2024-03-01',
            'returned_date'       => null,
            'condition_on_assign' => 'good',
            'assigned_by'         => $this->adminUser['id'],
            'created_at'          => date('Y-m-d H:i:s'),
            'updated_at'          => date('Y-m-d H:i:s'),
        ]);

        $assignmentModel = new \App\Models\AssetAssignmentModel();

        // 1. Privileged call without employee filter: returns all rows with assigned_by
        $fullHistory = $assignmentModel->getAssetHistory($assetId);
        $this->assertCount(2, $fullHistory);
        $this->assertArrayHasKey('assigned_by', $fullHistory[0]);

        // 2. Self-only call with tenantEmpId filter: returns only tenantEmpId's row and unsets assigned_by/returned_by
        $selfHistory = $assignmentModel->getAssetHistory($assetId, $this->tenantEmpId);
        $this->assertCount(1, $selfHistory);
        $this->assertEquals($this->tenantEmpId, $selfHistory[0]['employee_id']);
        $this->assertArrayNotHasKey('assigned_by', $selfHistory[0]);
        $this->assertArrayNotHasKey('returned_by', $selfHistory[0]);
    }

    /**
     * Test: delete() blocks deleting a Written-Off asset with 422 to protect recovery records and history.
     */
    public function testDeleteWrittenOffAssetReturns422AndDoesNotDeleteRow(): void
    {
        $db = Database::connect();
        $assetId = 'ast-written-off-del-01';
        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'name'             => 'Decommissioned Server',
            'asset_code'       => 'SRV-WO-DEL-01',
            'status'           => 'Written-Off',
            'condition_status' => 'damaged',
            'assigned_to'      => null,
            'written_off_at'   => date('Y-m-d H:i:s'),
            'recovery_amount'  => 15000.00,
            'deleted_at'       => null,
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->setupController([]);
        $res = $controller->delete($assetId);
        $body = json_decode($res->getBody(), true);

        $this->assertEquals(422, $res->getStatusCode());
        $this->assertFalse($body['success']);
        $this->assertStringContainsString('Written-Off', $body['message']);

        // Assert DB unchanged and row not soft-deleted
        $asset = $db->table('company_assets')->where('id', $assetId)->get()->getRowArray();
        $this->assertNotNull($asset, 'Asset record must not be deleted');
        $this->assertEquals('Written-Off', $asset['status']);
        $this->assertNull($asset['deleted_at'], 'deleted_at must remain NULL');
    }
}


