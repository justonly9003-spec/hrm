<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\RuleEngineService;
use App\Services\Rules\RuleResolver;

/**
 * Fake rule model for testing LEAVE rule resolution in RuleEngineService
 */
class LeaveTestRuleDefinitionModel
{
    /** @var array<int, array<string, mixed>> */
    public array $rows;

    public function __construct(array $rows = [])
    {
        $this->rows = $rows;
    }

    public function getActiveRules(string $companyId, string $domain): array
    {
        $filtered = [];
        foreach ($this->rows as $r) {
            $rComp = isset($r['company_id']) ? (string)$r['company_id'] : null;
            $rDom  = isset($r['domain']) ? strtoupper((string)$r['domain']) : null;
            $rStat = isset($r['status']) ? (string)$r['status'] : 'Active';

            if ($rComp === $companyId && $rDom === $domain && $rStat === 'Active') {
                $filtered[] = $r;
            }
        }
        return $filtered;
    }

    public function paramsOf(?array $row): array
    {
        if (empty($row) || !isset($row['params_json'])) {
            return [];
        }
        if (is_array($row['params_json'])) {
            return $row['params_json'];
        }
        $decoded = json_decode((string)$row['params_json'], true);
        return is_array($decoded) ? $decoded : [];
    }
}

/**
 * Unit Test: Leave Credited Working Hours and Attendance Status
 *
 * Verifies that:
 * 1. An approved paid leave day produces credited working hours equal to standard daily hours (e.g. 8.0)
 *    and status 'On Leave'.
 * 2. An approved unpaid leave day produces 0.0 credited working hours and status 'On Leave'.
 * 3. leave_type_name is read from leave applications (prioritized over legacy leave_type).
 * 4. leave_is_paid is used directly when no profile treatment exists.
 * 5. RuleResolver::resolve($companyId, 'LEAVE', $logDate, $employee) correctly uses $logDate
 *    when leave_is_paid is not directly provided, resolving entitlements properly.
 * 6. RuleResolver exceptions are caught and logged without breaking calculation.
 */
class LeaveCreditedHoursAttendanceTest extends TestCase
{
    protected RuleEngineService $engine;
    protected string $companyId = 'comp-leave-test';
    protected array $standardShift;

    protected function setUp(): void
    {
        parent::setUp();
        RuleResolver::resetMemo();
        $this->engine = new RuleEngineService();

        $this->standardShift = [
            'id'             => 'shift-std',
            'name'           => 'Regular Day Shift',
            'start_time'     => '09:00:00',
            'end_time'       => '17:00:00',
            'working_hours'  => 8.0,
            'duration_hours' => 8.0,
            'grace_time'     => 15,
            'weekly_off'     => ['Friday', 'Saturday']
        ];
    }

    protected function tearDown(): void
    {
        RuleResolver::resetMemo();
        parent::tearDown();
    }

    /**
     * Test 1: Approved paid leave with direct leave_is_paid = 1
     * Must produce status 'On Leave', is_paid_leave = true, credited_hours = 8.0.
     */
    public function testPaidLeaveProducesCreditedHoursAndOnLeaveStatusWithDirectLeaveIsPaid(): void
    {
        $employee = [
            'id'            => 'emp-paid-01',
            'company_id'    => $this->companyId,
            'name'          => 'Paid Leave Worker',
            'joining_date'  => '2025-01-01',
            'status'        => 'Active',
            'basic_salary'  => 30000.0,
            'gross_salary'  => 50000.0,
        ];

        $workday = '2026-11-04'; // Wednesday (scheduled working day)

        $leaves = [
            [
                'id'              => 'la-001',
                'employee_id'     => 'emp-paid-01',
                'company_id'      => $this->companyId,
                'status'          => 'Approved',
                'start_date'      => '2026-11-01',
                'end_date'        => '2026-11-07',
                'leave_type_name' => 'Earned / Annual Leave',
                'leave_is_paid'   => 1,
            ]
        ];

        $calc = $this->engine->calculateDailyAttendance(
            $workday,
            $employee,
            null, // no punch log
            [],
            $this->standardShift,
            $leaves,
            []
        );

        $this->assertSame('On Leave', $calc['status']);
        $this->assertTrue($calc['is_on_leave']);
        $this->assertTrue($calc['is_paid_leave']);
        $this->assertSame('Earned / Annual Leave', $calc['leave_type']);
        $this->assertEquals(8.0, $calc['credited_hours']);
        $this->assertEquals(0.0, $calc['net_hours']);
        $this->assertEquals(8.0, $calc['total_effective_hours']);
    }

    /**
     * Test 2: Approved unpaid leave with direct leave_is_paid = 0
     * Must produce status 'On Leave', is_paid_leave = false, credited_hours = 0.0.
     */
    public function testUnpaidLeaveProducesZeroCreditedHoursAndOnLeaveStatusWithDirectLeaveIsPaid(): void
    {
        $employee = [
            'id'            => 'emp-unpaid-01',
            'company_id'    => $this->companyId,
            'name'          => 'Unpaid Leave Worker',
            'joining_date'  => '2025-01-01',
            'status'        => 'Active',
            'basic_salary'  => 30000.0,
            'gross_salary'  => 50000.0,
        ];

        $workday = '2026-11-04'; // Wednesday

        $leaves = [
            [
                'id'              => 'la-002',
                'employee_id'     => 'emp-unpaid-01',
                'company_id'      => $this->companyId,
                'status'          => 'Approved',
                'start_date'      => '2026-11-01',
                'end_date'        => '2026-11-07',
                'leave_type_name' => 'Loss of Pay (Unpaid Leave)',
                'leave_is_paid'   => 0,
            ]
        ];

        $calc = $this->engine->calculateDailyAttendance(
            $workday,
            $employee,
            null,
            [],
            $this->standardShift,
            $leaves,
            []
        );

        $this->assertSame('On Leave', $calc['status']);
        $this->assertTrue($calc['is_on_leave']);
        $this->assertFalse($calc['is_paid_leave']);
        $this->assertSame('Loss of Pay (Unpaid Leave)', $calc['leave_type']);
        $this->assertEquals(0.0, $calc['credited_hours']);
        $this->assertEquals(0.0, $calc['net_hours']);
        $this->assertEquals(0.0, $calc['total_effective_hours']);
    }

    /**
     * Test 3: leave_type_name takes precedence over legacy leave_type
     * Verifies that if leave_type is 'Annual' but leave_type_name is 'Casual Leave',
     * leave_type_name is correctly read and populated.
     */
    public function testLeaveTypeNameTakesPrecedenceOverLegacyField(): void
    {
        $employee = [
            'id'            => 'emp-precedence-01',
            'company_id'    => $this->companyId,
            'name'          => 'Precedence Worker',
            'joining_date'  => '2025-01-01',
            'status'        => 'Active',
        ];

        $workday = '2026-11-04';

        $leaves = [
            [
                'id'              => 'la-003',
                'employee_id'     => 'emp-precedence-01',
                'status'          => 'Approved',
                'start_date'      => '2026-11-04',
                'end_date'        => '2026-11-04',
                'leave_type_name' => 'Special Sick Leave',
                'leave_type'      => 'Annual', // legacy key that should be overridden by leave_type_name
                'leave_is_paid'   => 1,
            ]
        ];

        $calc = $this->engine->calculateDailyAttendance(
            $workday,
            $employee,
            null,
            [],
            $this->standardShift,
            $leaves,
            []
        );

        $this->assertSame('On Leave', $calc['status']);
        $this->assertSame('Special Sick Leave', $calc['leave_type']);
        $this->assertTrue($calc['is_paid_leave']);
        $this->assertEquals(8.0, $calc['credited_hours']);
    }

    /**
     * Test 4: When leave_is_paid is omitted, RuleResolver::resolve($companyId, 'LEAVE', $logDate, $employee)
     * resolves the paid status from configured LEAVE entitlements using $logDate without crashing.
     */
    public function testLeavePaidResolutionViaRuleResolverWhenLeaveIsPaidNotProvided(): void
    {
        $ruleRows = [
            [
                'id'             => 'rule-leave-comp',
                'company_id'     => $this->companyId,
                'domain'         => 'LEAVE',
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'effective_from' => '2025-01-01',
                'effective_to'   => null,
                'status'         => 'Active',
                'params_json'    => json_encode([
                    'entitlements' => [
                        [
                            'leave_type_code' => 'CL',
                            'leave_type_name' => 'Casual Leave',
                            'is_paid'         => true,
                        ],
                        [
                            'leave_type_code' => 'LWP',
                            'leave_type_name' => 'Leave Without Pay',
                            'is_paid'         => false,
                        ],
                    ]
                ]),
            ]
        ];

        $fakeModel = new LeaveTestRuleDefinitionModel($ruleRows);
        new RuleResolver($fakeModel);

        $employee = [
            'id'            => 'emp-resolve-01',
            'company_id'    => $this->companyId,
            'name'          => 'Resolver Test Worker',
            'joining_date'  => '2025-01-01',
            'status'        => 'Active',
        ];

        $workday = '2026-11-04';

        // 4a. Paid Casual Leave via RuleResolver
        $leavesPaid = [
            [
                'id'              => 'la-004',
                'employee_id'     => 'emp-resolve-01',
                'status'          => 'Approved',
                'start_date'      => '2026-11-04',
                'end_date'        => '2026-11-04',
                'leave_type_name' => 'Casual Leave',
                // Note: leave_is_paid is intentionally omitted to exercise RuleResolver resolution
            ]
        ];

        $calcPaid = $this->engine->calculateDailyAttendance(
            $workday,
            $employee,
            null,
            [],
            $this->standardShift,
            $leavesPaid,
            []
        );

        $this->assertSame('On Leave', $calcPaid['status']);
        $this->assertTrue($calcPaid['is_on_leave']);
        $this->assertTrue($calcPaid['is_paid_leave']);
        $this->assertEquals(8.0, $calcPaid['credited_hours']);

        // 4b. Unpaid Leave Without Pay via RuleResolver
        $leavesUnpaid = [
            [
                'id'              => 'la-005',
                'employee_id'     => 'emp-resolve-01',
                'status'          => 'Approved',
                'start_date'      => '2026-11-04',
                'end_date'        => '2026-11-04',
                'leave_type_name' => 'Leave Without Pay',
                // leave_is_paid intentionally omitted
            ]
        ];

        $calcUnpaid = $this->engine->calculateDailyAttendance(
            $workday,
            $employee,
            null,
            [],
            $this->standardShift,
            $leavesUnpaid,
            []
        );

        $this->assertSame('On Leave', $calcUnpaid['status']);
        $this->assertTrue($calcUnpaid['is_on_leave']);
        $this->assertFalse($calcUnpaid['is_paid_leave']);
        $this->assertEquals(0.0, $calcUnpaid['credited_hours']);
    }

    /**
     * Test 5: Missing or failing LEAVE rule resolution logs error and falls back gracefully to unpaid
     * without throwing an unhandled exception.
     */
    public function testMissingLeaveRuleGracefulFallbackAndLogging(): void
    {
        // Empty fake model => RuleNotConfiguredException will be thrown by RuleResolver
        $fakeModel = new LeaveTestRuleDefinitionModel([]);
        new RuleResolver($fakeModel);

        $employee = [
            'id'            => 'emp-fallback-01',
            'company_id'    => 'comp-unconfigured',
            'name'          => 'Fallback Worker',
            'joining_date'  => '2025-01-01',
            'status'        => 'Active',
        ];

        $workday = '2026-11-04';

        $leaves = [
            [
                'id'              => 'la-006',
                'employee_id'     => 'emp-fallback-01',
                'status'          => 'Approved',
                'start_date'      => '2026-11-04',
                'end_date'        => '2026-11-04',
                'leave_type_name' => 'Unknown Leave',
                // leave_is_paid omitted
            ]
        ];

        $calc = $this->engine->calculateDailyAttendance(
            $workday,
            $employee,
            null,
            [],
            $this->standardShift,
            $leaves,
            []
        );

        $this->assertSame('On Leave', $calc['status']);
        $this->assertTrue($calc['is_on_leave']);
        $this->assertFalse($calc['is_paid_leave']);
        $this->assertEquals(0.0, $calc['credited_hours']);
    }
}
