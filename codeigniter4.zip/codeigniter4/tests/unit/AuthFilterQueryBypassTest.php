<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\HTTP\URI;
use App\Filters\AuthFilter;

/**
 * Verification that query-string injection (e.g. ?x=push-punch) cannot bypass authentication.
 */
class AuthFilterQueryBypassTest extends CIUnitTestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $session = \Config\Services::session();
        $session->destroy();
    }

    /**
     * Protected URLs with 'push-punch' in query string must still require login (non-AJAX => redirect).
     */
    public function testProtectedUrlWithPushPunchInQueryStringRequiresLogin()
    {
        $testUris = [
            'http://example.com/attendance/sync?x=push-punch',
            'http://example.com/attendance/sync?x=api/attendance/push-punch',
            'http://example.com/dashboard?filter=push-punch',
            'http://example.com/employees?q=push-punch',
            'http://example.com/attendance/live-control?device=push-punch',
            'http://example.com/some/protected/route?x=push-punch',
            'http://example.com/attendance?key=api/attendance/zk-push',
            'http://example.com/payroll?tag=attendance/sync/api',
        ];

        $filter = new AuthFilter();

        foreach ($testUris as $url) {
            $request = \Config\Services::request(null, false);
            $request->setUri(new URI($url));

            $result = $filter->before($request);

            $this->assertNotNull(
                $result,
                "Unauthenticated request to '{$url}' MUST NOT bypass AuthFilter (must return redirect or 401)."
            );
            $this->assertTrue(
                $result instanceof \CodeIgniter\HTTP\RedirectResponse || $result->getStatusCode() === 401,
                "Result for '{$url}' must be a redirect or 401 response."
            );
        }
    }

    /**
     * Protected AJAX requests with 'push-punch' in query string must return 401 Unauthorized.
     */
    public function testProtectedAjaxRequestWithPushPunchInQueryStringReturns401()
    {
        $request = \Config\Services::request(null, false);
        $request->setUri(new URI('http://example.com/attendance/corrections-ajax?filter=push-punch'));
        $request->setHeader('X-Requested-With', 'XMLHttpRequest');

        $filter = new AuthFilter();
        $result = $filter->before($request);

        $this->assertNotNull($result, 'Unauthenticated AJAX request must not pass AuthFilter.');
        $this->assertEquals(401, $result->getStatusCode(), 'Unauthenticated AJAX request must receive 401 status.');

        $body = json_decode($result->getBody(), true);
        $this->assertIsArray($body);
        $this->assertEquals('error', $body['status'] ?? null);
    }

    /**
     * Verify AuthFilter source code no longer contains URI substring bypasses.
     */
    public function testAuthFilterContainsNoSubstringBypasses()
    {
        $filterSource = file_get_contents(APPPATH . 'Filters/AuthFilter.php');

        $this->assertStringNotContainsString(
            "str_contains(\$uri, 'api/attendance/push-punch')",
            $filterSource,
            'AuthFilter must not bypass authentication using str_contains on push-punch'
        );
        $this->assertStringNotContainsString(
            "str_contains(\$uri, 'api/attendance/zk-push')",
            $filterSource,
            'AuthFilter must not bypass authentication using str_contains on zk-push'
        );
        $this->assertStringNotContainsString(
            "str_contains(\$uri, 'attendance/sync/api')",
            $filterSource,
            'AuthFilter must not bypass authentication using str_contains on sync api'
        );
    }

    /**
     * Verify AttendanceSyncController enforces header-only keys without query string ?key= / ?api_key=.
     */
    public function testAttendanceSyncControllerDoesNotAcceptQueryStringApiKey()
    {
        $controllerSource = file_get_contents(APPPATH . 'Controllers/Attendance/AttendanceSyncController.php');

        $this->assertStringNotContainsString(
            "\$this->request->getGet('key')",
            $controllerSource,
            "AttendanceSyncController must not read API keys from ?key= query string"
        );
        $this->assertStringNotContainsString(
            "\$this->request->getGet('api_key')",
            $controllerSource,
            "AttendanceSyncController must not read API keys from ?api_key= query string"
        );
    }

    /**
     * Verify Routes.php does not place sync/api/push-punch inside the attendance auth group.
     */
    public function testDevicePushPunchRouteNotInAuthGroup()
    {
        $routesSource = file_get_contents(APPPATH . 'Config/Routes.php');

        // sync/api/push-punch must not be defined inside the attendance auth group
        $attendanceGroupPattern = '/\$routes->group\(\s*\'attendance\'\s*,\s*\[\'filter\'\s*=>\s*\'auth\'\].*?\$routes->post\(\s*\'sync\/api\/push-punch\'/s';
        $this->assertMatchesRegularExpression(
            '/\$routes->match\(.*?\'attendance\/sync\/api\/push-punch\'.*?pushPunch/',
            $routesSource,
            'Public device push-punch route must be registered outside the auth group'
        );
        $this->assertDoesNotMatchRegularExpression(
            $attendanceGroupPattern,
            $routesSource,
            'sync/api/push-punch must not exist inside the attendance auth group'
        );
    }
}
