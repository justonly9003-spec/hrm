<?php

namespace Tests\Unit;

use App\Services\Pf\PfCalculator;
use App\Services\Rules\RuleResolver;
use PHPUnit\Framework\TestCase;

class FakePfRuleModel
{
    /** @var array<int, array<string, mixed>> */
    public array $rows;

    public function __construct(array $rows = [])
    {
        $this->rows = $rows;
    }

    public function getActiveRules(string $companyId, string $domain): array
    {
        $filtered = [];
        foreach ($this->rows as $r) {
            if (($r['company_id'] ?? null) === $companyId &&
                ($r['domain'] ?? null) === $domain &&
                ($r['status'] ?? 'Active') === 'Active') {
                $filtered[] = $r;
            }
        }
        return $filtered;
    }

    public function paramsOf(?array $row): array
    {
        if (empty($row) || !isset($row['params_json'])) {
            return [];
        }
        if (is_array($row['params_json'])) {
            return $row['params_json'];
        }
        $decoded = json_decode((string)$row['params_json'], true);
        return is_array($decoded) ? $decoded : [];
    }
}

class PfCalculatorTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        RuleResolver::resetMemo();
    }

    protected function getCompanyPfRule(string $companyId = 'comp-1'): array
    {
        return [
            'id'             => 'pf-rule-001',
            'company_id'     => $companyId,
            'domain'         => 'PF',
            'scope_level'    => 'Company',
            'scope_id'       => null,
            'version_number' => 1,
            'effective_from' => '2020-01-01',
            'effective_to'   => null,
            'status'         => 'Active',
            'params_json'    => json_encode([
                'contribution_type'     => 'percentage',
                'employee_rate'         => 7.0,
                'employer_rate'         => 7.0,
                'employee_fixed_amount' => 0.0,
                'employer_fixed_amount' => 0.0,
                'calculation_basis'     => 'Basic',
                'basis_components'      => ['Basic'],
                'custom_formula'        => null,
                'employer_formula'      => null,
                'min_salary_limit'      => 0.0,
                'max_salary_limit'      => 0.0,
                'min_deduction_limit'   => 0.0,
                'max_deduction_limit'   => 0.0,
            ]),
        ];
    }

    /**
     * TEST 1: New employee, PF not enrolled.
     * Expected: PF deduction = 0, Employer contribution = 0, is_eligible = false, status = 'Not Enrolled'
     */
    public function testNotEnrolledEmployeeReceivesZeroDeduction()
    {
        $fakeModel = new FakePfRuleModel([$this->getCompanyPfRule()]);
        $resolver  = new RuleResolver($fakeModel);
        $calc      = new PfCalculator($resolver);

        $res = $calc->calculate([
            'company_id'     => 'comp-1',
            'employee'       => [
                'id'               => 'emp-1',
                'is_pf_applicable' => 0,
                'pf_status'        => 'Not Enrolled',
                'basic_salary'     => 50000.00,
            ],
            'effective_date' => '2026-03-31',
            'basic'          => 50000.00,
        ]);

        $this->assertFalse($res['is_eligible']);
        $this->assertSame(0.00, (float)$res['employee_deduction']);
        $this->assertSame(0.00, (float)$res['employer_contribution']);
        $this->assertSame('Not Enrolled', $res['status']);
    }

    /**
     * TEST 2: Eligible employee manually enrolled.
     * Expected: PF payroll starts from effective date.
     */
    public function testEnrolledAndEffectiveDateArrivedAppliesPolicy()
    {
        $fakeModel = new FakePfRuleModel([$this->getCompanyPfRule()]);
        $resolver  = new RuleResolver($fakeModel);
        $calc      = new PfCalculator($resolver);

        $res = $calc->calculate([
            'company_id'     => 'comp-1',
            'employee'       => [
                'id'                => 'emp-5',
                'is_pf_applicable'  => 1,
                'pf_status'         => 'Enrolled',
                'pf_effective_date' => '2026-01-01',
                'basic_salary'      => 50000.00,
            ],
            'effective_date' => '2026-03-31', // Payroll is after PF effective date
            'basic'          => 50000.00,
        ]);

        $this->assertTrue($res['is_eligible']);
        $this->assertSame(3500.00, (float)$res['employee_deduction']); // 7% of 50000
        $this->assertSame(3500.00, (float)$res['employer_contribution']); // 7% of 50000
        $this->assertSame(7000.00, (float)$res['total_pf']);
        $this->assertSame('Enrolled', $res['status']);
    }

    /**
     * TEST 3: Close active PF (Effective Date = 01-01-2026, Close Date = 01-10-2026).
     * Before 01-10-2026: PF active (September payroll applies).
     * From 01-10-2026: Employee PF = 0, Employer PF = 0 (October payroll does NOT apply).
     */
    public function testCloseActivePfBeforeCloseDateIsActive()
    {
        $fakeModel = new FakePfRuleModel([$this->getCompanyPfRule()]);
        $resolver  = new RuleResolver($fakeModel);
        $calc      = new PfCalculator($resolver);

        $employee = [
            'id'                => 'emp-close-1',
            'is_pf_applicable'  => 0,
            'pf_status'         => 'Not Enrolled',
            'pf_member_id'      => 'PF-EMP-001',
            'pf_effective_date' => '2026-01-01',
            'pf_close_date'     => '2026-10-01',
            'pf_close_reason'   => 'Mutual settlement',
            'basic_salary'      => 50000.00,
        ];

        // September 2026 payroll (before 2026-10-01) -> PF applies
        $resSept = $calc->calculate([
            'company_id'     => 'comp-1',
            'employee'       => $employee,
            'effective_date' => '2026-09-30',
            'basic'          => 50000.00,
        ]);

        $this->assertTrue($resSept['is_eligible']);
        $this->assertSame(3500.00, (float)$resSept['employee_deduction']);
        $this->assertSame(3500.00, (float)$resSept['employer_contribution']);
        $this->assertSame('Enrolled', $resSept['status']);
    }

    public function testCloseActivePfFromCloseDateIsInactive()
    {
        $fakeModel = new FakePfRuleModel([$this->getCompanyPfRule()]);
        $resolver  = new RuleResolver($fakeModel);
        $calc      = new PfCalculator($resolver);

        $employee = [
            'id'                => 'emp-close-1',
            'is_pf_applicable'  => 0,
            'pf_status'         => 'Not Enrolled',
            'pf_member_id'      => 'PF-EMP-001',
            'pf_effective_date' => '2026-01-01',
            'pf_close_date'     => '2026-10-01',
            'pf_close_reason'   => 'Mutual settlement',
            'basic_salary'      => 50000.00,
        ];

        // October 2026 payroll (on/after 2026-10-01) -> PF deduction = 0, Employer = 0
        $resOct = $calc->calculate([
            'company_id'     => 'comp-1',
            'employee'       => $employee,
            'effective_date' => '2026-10-31',
            'basic'          => 50000.00,
        ]);

        $this->assertFalse($resOct['is_eligible']);
        $this->assertSame(0.00, (float)$resOct['employee_deduction']);
        $this->assertSame(0.00, (float)$resOct['employer_contribution']);
        $this->assertSame('Closed', $resOct['status']);

        // Boundary test: exactly on 2026-10-01
        $resBoundary = $calc->calculate([
            'company_id'     => 'comp-1',
            'employee'       => $employee,
            'effective_date' => '2026-10-01',
            'basic'          => 50000.00,
        ]);
        $this->assertFalse($resBoundary['is_eligible']);
        $this->assertSame(0.00, (float)$resBoundary['employee_deduction']);
        $this->assertSame('Closed', $resBoundary['status']);
    }

    /**
     * TEST 4: Close PF preserves PF Member ID and history.
     */
    public function testPfMemberIdPreservedOnClosedEmployee()
    {
        $employee = [
            'id'                => 'emp-close-1',
            'is_pf_applicable'  => 0,
            'pf_status'         => 'Not Enrolled',
            'pf_member_id'      => 'PF-MEMBER-999',
            'pf_effective_date' => '2026-01-01',
            'pf_close_date'     => '2026-10-01',
        ];

        $this->assertSame('PF-MEMBER-999', $employee['pf_member_id']);
        $this->assertSame('2026-01-01', $employee['pf_effective_date']);
        $this->assertSame('2026-10-01', $employee['pf_close_date']);
    }

    /**
     * TEST 5: Future effective date receives zero deduction.
     */
    public function testFutureEffectiveDateReceivesZeroDeduction()
    {
        $fakeModel = new FakePfRuleModel([$this->getCompanyPfRule()]);
        $resolver  = new RuleResolver($fakeModel);
        $calc      = new PfCalculator($resolver);

        $res = $calc->calculate([
            'company_id'     => 'comp-1',
            'employee'       => [
                'id'                => 'emp-4',
                'is_pf_applicable'  => 1,
                'pf_status'         => 'Enrolled',
                'pf_effective_date' => '2026-06-01',
                'basic_salary'      => 40000.00,
            ],
            'effective_date' => '2026-03-31', // Payroll before PF effective date
            'basic'          => 40000.00,
        ]);

        $this->assertFalse($res['is_eligible']);
        $this->assertSame(0.00, (float)$res['employee_deduction']);
        $this->assertSame(0.00, (float)$res['employer_contribution']);
        $this->assertSame('Pending Effective Date', $res['status']);
    }

    /**
     * TEST 6: Ineligible employee receives zero deduction.
     */
    public function testIneligibleEmployeeReceivesZeroDeduction()
    {
        $fakeModel = new FakePfRuleModel([$this->getCompanyPfRule()]);
        $resolver  = new RuleResolver($fakeModel);
        $calc      = new PfCalculator($resolver);

        $res = $calc->calculate([
            'company_id'     => 'comp-1',
            'employee'       => [
                'id'               => 'emp-3',
                'is_pf_applicable' => 0,
                'pf_status'        => 'Ineligible',
                'basic_salary'     => 30000.00,
            ],
            'effective_date' => '2026-03-31',
            'basic'          => 30000.00,
        ]);

        $this->assertFalse($res['is_eligible']);
        $this->assertSame(0.00, (float)$res['employee_deduction']);
        $this->assertSame(0.00, (float)$res['employer_contribution']);
        $this->assertSame('Ineligible', $res['status']);
    }

    /**
     * TEST 7: Exempt employee receives zero deduction.
     */
    public function testExemptEmployeeReceivesZeroDeduction()
    {
        $fakeModel = new FakePfRuleModel([$this->getCompanyPfRule()]);
        $resolver  = new RuleResolver($fakeModel);
        $calc      = new PfCalculator($resolver);

        $res = $calc->calculate([
            'company_id'     => 'comp-1',
            'employee'       => [
                'id'                  => 'emp-2',
                'is_pf_applicable'    => 0,
                'pf_status'           => 'Exempt',
                'pf_exemption_reason' => 'Statutory international pension exemption',
                'basic_salary'        => 60000.00,
            ],
            'effective_date' => '2026-03-31',
            'basic'          => 60000.00,
        ]);

        $this->assertFalse($res['is_eligible']);
        $this->assertSame(0.00, (float)$res['employee_deduction']);
        $this->assertSame(0.00, (float)$res['employer_contribution']);
        $this->assertSame('Exempt', $res['status']);
    }

    /**
     * TEST 8: Software App Admin / SUPER_ADMIN is strictly excluded from PF.
     */
    public function testSoftwareAppAdminExcluded()
    {
        $fakeModel = new FakePfRuleModel([$this->getCompanyPfRule()]);
        $resolver  = new RuleResolver($fakeModel);
        $calc      = new PfCalculator($resolver);

        $res = $calc->calculate([
            'company_id'     => 'comp-1',
            'employee'       => [
                'id'               => 'admin-1',
                'role'             => 'Software App Admin',
                'is_pf_applicable' => 1,
                'pf_status'        => 'Enrolled',
                'basic_salary'     => 100000.00,
            ],
            'effective_date' => '2026-03-31',
            'basic'          => 100000.00,
        ]);

        $this->assertFalse($res['is_eligible']);
        $this->assertSame(0.00, (float)$res['employee_deduction']);
        $this->assertSame('Excluded', $res['status']);
    }

    /**
     * TEST 9: PfCalculator save-time formula validation and fail-loud evaluation on invalid formulas.
     */
    public function testPfCalculatorFormulaValidationAndFailLoudEvaluation(): void
    {
        $fakeModel = new FakePfRuleModel([$this->getCompanyPfRule()]);
        $resolver  = new RuleResolver($fakeModel);
        $calc      = new PfCalculator($resolver);

        // Save-time validation passes for valid formula
        $validCheck = PfCalculator::validateFormulaFields([
            'contribution_type' => 'formula',
            'custom_formula'    => 'BASIC * 0.08 + HRA * 0.02',
            'employer_formula'  => 'BASIC * 0.08',
        ]);
        $this->assertTrue($validCheck['valid']);

        // Save-time validation fails for invalid formula (unknown variable, division by zero)
        $invalidCheck = PfCalculator::validateFormulaFields([
            'contribution_type' => 'formula',
            'custom_formula'    => 'NON_EXISTENT * 0.08',
            'employer_formula'  => 'BASIC / 0',
        ]);
        $this->assertFalse($invalidCheck['valid']);
        $this->assertArrayHasKey('custom_formula', $invalidCheck['errors']);
        $this->assertArrayHasKey('employer_formula', $invalidCheck['errors']);

        // Runtime evaluation throws InvalidArgumentException on broken formula override
        $this->expectException(\InvalidArgumentException::class);
        $calc->calculate([
            'company_id'     => 'comp-1',
            'employee'       => [
                'id'               => 'emp-1',
                'is_pf_applicable' => 1,
                'pf_status'        => 'Enrolled',
                'basic_salary'     => 50000.00,
            ],
            'effective_date' => '2026-03-31',
            'basic'          => 50000.00,
            'rule_override'  => [
                'contribution_type' => 'formula',
                'custom_formula'    => 'BASIC / 0',
            ],
        ]);
    }
}
