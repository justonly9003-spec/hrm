<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Models\RawBiometricEventModel;
use App\Models\UnmatchedBiometricModel;
use App\Services\BiometricMappingService;
use App\Services\ZKTecoService;

class BiometricUnmatchedResolutionTest extends TestCase
{
    private BiometricMappingService $mappingService;

    protected function setUp(): void
    {
        parent::setUp();
        $this->mappingService = new BiometricMappingService();
    }

    /**
     * @testdox Verifies RawBiometricEventModel methods exist
     */
    public function testRawBiometricEventModelRepairMethodsExist()
    {
        $this->assertTrue(
            method_exists(RawBiometricEventModel::class, 'hasCorruptedEvents'),
            'RawBiometricEventModel must implement hasCorruptedEvents()'
        );
        $this->assertTrue(
            method_exists(RawBiometricEventModel::class, 'repairCorruptedEvents'),
            'RawBiometricEventModel must implement repairCorruptedEvents()'
        );
        $this->assertTrue(
            method_exists(RawBiometricEventModel::class, 'getUnprocessedRawCount'),
            'RawBiometricEventModel must implement getUnprocessedRawCount()'
        );
    }

    /**
     * @testdox Verifies UnmatchedBiometricModel rebuild method exists
     */
    public function testUnmatchedBiometricModelRebuildMethodExists()
    {
        $this->assertTrue(
            method_exists(UnmatchedBiometricModel::class, 'rebuildIdentitiesFromRawEvents'),
            'UnmatchedBiometricModel must implement rebuildIdentitiesFromRawEvents()'
        );
    }

    /**
     * @testdox Verifies payload extraction extracts PINs accurately from sample records
     */
    public function testPayloadExtractionFromSampleRecords()
    {
        // Sample 1: device_user_id 100013 from user sample
        $samplePayload1 = json_encode([
            'device_user_id' => '100013',
            'event_time'     => '2025-10-23 14:25:17',
            'punch_state'    => 'CheckIn'
        ]);

        $decoded1 = json_decode($samplePayload1, true);
        $pin1 = trim((string)($decoded1['device_user_id'] ?? ''));
        $time1 = trim((string)($decoded1['event_time'] ?? ''));

        $this->assertSame('100013', $pin1);
        $this->assertSame('2025-10-23 14:25:17', $time1);

        // Sample 2: device_user_id 1054 from user sample
        $samplePayload2 = json_encode([
            'device_user_id' => '1054',
            'event_time'     => '2025-10-23 15:00:36',
            'punch_state'    => 'CheckIn'
        ]);

        $decoded2 = json_decode($samplePayload2, true);
        $pin2 = trim((string)($decoded2['device_user_id'] ?? ''));
        $time2 = trim((string)($decoded2['event_time'] ?? ''));

        $this->assertSame('1054', $pin2);
        $this->assertSame('2025-10-23 15:00:36', $time2);

        // Sample 3: device_user_id 1041 from user sample
        $samplePayload3 = json_encode([
            'device_user_id' => '1041',
            'event_time'     => '2025-10-23 14:56:37',
            'punch_state'    => 'CheckIn'
        ]);

        $decoded3 = json_decode($samplePayload3, true);
        $pin3 = trim((string)($decoded3['device_user_id'] ?? ''));
        $time3 = trim((string)($decoded3['event_time'] ?? ''));

        $this->assertSame('1041', $pin3);
        $this->assertSame('2025-10-23 14:56:37', $time3);
    }

    /**
     * @testdox Verifies that distinct biometric PINs remain distinct and do not collide
     */
    public function testDistinctPinsNeverCollide()
    {
        $pins = ['100013', '1054', '1041', '1054', '100013', '1041', '1054'];
        $distinctIdentities = [];

        foreach ($pins as $pin) {
            if (!isset($distinctIdentities[$pin])) {
                $distinctIdentities[$pin] = 0;
            }
            $distinctIdentities[$pin]++;
        }

        $this->assertCount(3, $distinctIdentities);
        $this->assertSame(2, $distinctIdentities['100013']);
        $this->assertSame(3, $distinctIdentities['1054']);
        $this->assertSame(2, $distinctIdentities['1041']);
    }

    /**
     * @testdox Verifies fallback identifier generation when PIN is completely missing
     */
    public function testFallbackIdentifierGenerationPreventsConsolidation()
    {
        $corruptedEventId1 = '067ee4bf-7f8a-4a09-b301-3ee0d3b1d1dc';
        $corruptedEventId2 = '0a919278-eeab-4450-be3e-746ac0a6b114';

        $fallback1 = 'UNKNOWN_' . substr($corruptedEventId1, 0, 8);
        $fallback2 = 'UNKNOWN_' . substr($corruptedEventId2, 0, 8);

        $this->assertNotSame($fallback1, $fallback2);
        $this->assertSame('UNKNOWN_067ee4bf', $fallback1);
        $this->assertSame('UNKNOWN_0a919278', $fallback2);
    }
}
