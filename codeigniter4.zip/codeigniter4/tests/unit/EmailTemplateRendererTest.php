<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use App\Services\EmailTemplateRenderer;
use App\Models\EmailTemplateModel;
use App\Database\Migrations\EnhanceEmailTemplatesSchemaAndIndexes;
use HTMLPurifier;

class EmailTemplateRendererTest extends CIUnitTestCase
{
    public function testPlaceholderReplacementMatchesAllTokens()
    {
        $renderer = new EmailTemplateRenderer();
        $template = "Hello {employee_name} ({employee_code}), your {leave_type} from {from_date} to {to_date} ({days} days) is approved by {manager_name}.";
        $vars = [
            'employee_name' => 'John Doe',
            'employee_code' => 'EMP-100',
            'leave_type'    => 'Casual Leave',
            'from_date'     => '2026-11-01',
            'to_date'       => '2026-11-03',
            'days'          => 3,
            'manager_name'  => 'Jane Smith',
        ];

        $rendered = $renderer->replacePlaceholders($template, $vars);
        $this->assertEquals("Hello John Doe (EMP-100), your Casual Leave from 2026-11-01 to 2026-11-03 (3 days) is approved by Jane Smith.", $rendered);
    }

    public function testHTMLPurifierStripsMaliciousScriptsWhilePreservingSafeTags()
    {
        $purifier = new HTMLPurifier();
        $dirty = '<p>Welcome <strong>Employee</strong></p><script>alert("hacked")</script><a href="javascript:alert(1)">Click</a>';
        $clean = $purifier->purify($dirty);

        $this->assertStringNotContainsString('<script>', $clean);
        $this->assertStringNotContainsString('alert(', $clean);
        $this->assertStringNotContainsString('javascript:', $clean);
        $this->assertStringContainsString('<p>Welcome <strong>Employee</strong></p>', $clean);
    }

    public function testTemplateModelAllowedFieldsIncludesModuleAndCompanyId()
    {
        $model = new EmailTemplateModel();
        $this->assertContains('company_id', $model->allowedFields ?? []);
        $this->assertContains('module', $model->allowedFields ?? []);
        $this->assertContains('is_active', $model->allowedFields ?? []);
        $this->assertContains('title', $model->allowedFields ?? []);
        $this->assertContains('subject', $model->allowedFields ?? []);
        $this->assertContains('body', $model->allowedFields ?? []);
    }

    public function testModuleSpecificRenderingMethodsExistAndReturnSubjectAndBody()
    {
        $renderer = new EmailTemplateRenderer();

        // 1. Welcome module
        $this->assertTrue(method_exists($renderer, 'renderWelcome'));

        // 2. Leave module
        $this->assertTrue(method_exists($renderer, 'renderLeaveApplied'));
        $this->assertTrue(method_exists($renderer, 'renderLeaveApproved'));
        $this->assertTrue(method_exists($renderer, 'renderLeaveRejected'));

        // 3. Payroll module
        $this->assertTrue(method_exists($renderer, 'renderPayslipReady'));

        // 4. Asset module
        $this->assertTrue(method_exists($renderer, 'renderAssetAssignment'));
    }

    public function testMigrationEnhanceEmailTemplatesSchemaAndIndexesExists()
    {
        $migration = new EnhanceEmailTemplatesSchemaAndIndexes();
        $this->assertTrue(method_exists($migration, 'up'));
        $this->assertTrue(method_exists($migration, 'down'));
    }
}
