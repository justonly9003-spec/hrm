<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use App\Database\Migrations\EnsureProvidentFundLedgerSchemaAndUniqueIndex;
use Config\Database;

/**
 * Real DB-backed test for EnsureProvidentFundLedgerSchemaAndUniqueIndex migration:
 * 1. Table with a NON-unique index on (employee_id, payroll_month, payroll_year, transaction_type) gets the unique index added.
 * 2. Table that already has the unique index is left untouched.
 * 3. Duplicate rows make the migration fail with clear message and change nothing.
 * 4. Running the migration twice is a complete no-op.
 */
class ProvidentFundLedgerUniqueIndexMigrationTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected function setUp(): void
    {
        parent::setUp();
        $this->dropLedgerTable();
    }

    protected function tearDown(): void
    {
        $this->dropLedgerTable();
        parent::tearDown();
    }

    protected function dropLedgerTable(): void
    {
        $db = Database::connect();
        if ($db->tableExists('provident_fund_ledgers')) {
            $forge = Database::forge();
            $forge->dropTable('provident_fund_ledgers', true);
        }
    }

    /**
     * Helper to create a bare provident_fund_ledgers table without unique index
     */
    protected function createBaseLedgerTable(): void
    {
        $db = Database::connect();
        $forge = Database::forge();

        $forge->addField([
            'id'                    => ['type' => 'VARCHAR', 'constraint' => 36],
            'company_id'            => ['type' => 'VARCHAR', 'constraint' => 36],
            'employee_id'           => ['type' => 'VARCHAR', 'constraint' => 36],
            'payroll_id'            => ['type' => 'VARCHAR', 'constraint' => 36, 'null' => true],
            'payroll_month'         => ['type' => 'INT', 'constraint' => 2, 'null' => true],
            'payroll_year'          => ['type' => 'INT', 'constraint' => 4, 'null' => true],
            'pf_rule_id'            => ['type' => 'VARCHAR', 'constraint' => 36, 'null' => true],
            'transaction_type'      => ['type' => 'VARCHAR', 'constraint' => 50, 'default' => 'CONTRIBUTION'],
            'pf_base_salary'        => ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => 0.00],
            'employee_contribution' => ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => 0.00],
            'employer_contribution' => ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => 0.00],
            'total_contribution'    => ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => 0.00],
            'running_balance'       => ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => 0.00],
            'transaction_date'      => ['type' => 'DATE'],
            'status'                => ['type' => 'VARCHAR', 'constraint' => 30, 'default' => 'draft'],
            'reference_no'          => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'reversal_of_id'        => ['type' => 'VARCHAR', 'constraint' => 36, 'null' => true],
            'notes'                 => ['type' => 'TEXT', 'null' => true],
            'created_by'            => ['type' => 'VARCHAR', 'constraint' => 36, 'null' => true],
            'created_at'            => ['type' => 'DATETIME', 'null' => true],
            'updated_at'            => ['type' => 'DATETIME', 'null' => true],
        ]);
        $forge->addKey('id', true);
        $forge->createTable('provident_fund_ledgers', true);
    }

    /**
     * Test 1: Table with a NON-unique index on those columns gets the unique index added
     */
    public function testTableWithNonUniqueIndexGetsUniqueIndexAdded(): void
    {
        $db = Database::connect();
        $this->createBaseLedgerTable();

        // Create a plain non-unique index on the 4 columns
        if ($db->DBDriver === 'SQLite3') {
            $db->query("CREATE INDEX idx_pf_plain_composite ON provident_fund_ledgers (employee_id, payroll_month, payroll_year, transaction_type)");
        } else {
            $db->query("ALTER TABLE provident_fund_ledgers ADD INDEX idx_pf_plain_composite (employee_id, payroll_month, payroll_year, transaction_type)");
        }

        // Verify the plain index exists and is non-unique ('INDEX')
        $indexesBefore = $db->getIndexData('provident_fund_ledgers');
        $foundPlainIndex = false;
        foreach ($indexesBefore as $idx) {
            $fields = array_map('strtolower', (array)($idx->fields ?? []));
            if ($fields === ['employee_id', 'payroll_month', 'payroll_year', 'transaction_type']) {
                $foundPlainIndex = true;
                $this->assertSame('INDEX', strtoupper((string)$idx->type), 'Index must initially be non-unique INDEX');
            }
        }
        $this->assertTrue($foundPlainIndex, 'Non-unique composite index must exist prior to migration.');

        // Run migration
        $migration = new EnsureProvidentFundLedgerSchemaAndUniqueIndex();
        $migration->up();

        // Verify unique index uq_pf_emp_m_y_type has been created and is UNIQUE
        $indexesAfter = $db->getIndexData('provident_fund_ledgers');
        $foundUniqueIndex = false;
        foreach ($indexesAfter as $idx) {
            if ($idx->name === 'uq_pf_emp_m_y_type') {
                $foundUniqueIndex = true;
                $this->assertSame('UNIQUE', strtoupper((string)$idx->type), 'Index uq_pf_emp_m_y_type must be UNIQUE');
            }
        }
        $this->assertTrue($foundUniqueIndex, 'Unique index uq_pf_emp_m_y_type must be added by migration.');
    }

    /**
     * Test 2: Table that already has the unique index is left untouched
     */
    public function testTableWithExistingUniqueIndexIsLeftUntouched(): void
    {
        $db = Database::connect();
        $this->createBaseLedgerTable();

        // Create the unique index beforehand
        if ($db->DBDriver === 'SQLite3') {
            $db->query("CREATE UNIQUE INDEX uq_pf_emp_m_y_type ON provident_fund_ledgers (employee_id, payroll_month, payroll_year, transaction_type)");
        } else {
            $db->query("ALTER TABLE provident_fund_ledgers ADD UNIQUE KEY uq_pf_emp_m_y_type (employee_id, payroll_month, payroll_year, transaction_type)");
        }

        // Run migration
        $migration = new EnsureProvidentFundLedgerSchemaAndUniqueIndex();
        $migration->up();

        // Assert unique index is still intact
        $indexes = $db->getIndexData('provident_fund_ledgers');
        $foundUniqueIndex = false;
        foreach ($indexes as $idx) {
            if ($idx->name === 'uq_pf_emp_m_y_type') {
                $foundUniqueIndex = true;
                $this->assertSame('UNIQUE', strtoupper((string)$idx->type));
            }
        }
        $this->assertTrue($foundUniqueIndex);
    }

    /**
     * Test 3: Duplicate rows make the migration fail with clear message and change nothing
     */
    public function testDuplicateRowsMakeMigrationFailWithClearMessageAndChangeNothing(): void
    {
        $db = Database::connect();
        $this->createBaseLedgerTable();

        // Insert duplicate rows on (employee_id, payroll_month, payroll_year, transaction_type)
        $db->table('provident_fund_ledgers')->insertBatch([
            [
                'id'                    => 'pf-dup-001',
                'company_id'            => 'comp-dup',
                'employee_id'           => 'emp-dup-01',
                'payroll_month'         => 10,
                'payroll_year'          => 2026,
                'transaction_type'      => 'CONTRIBUTION',
                'transaction_date'      => '2026-10-31',
                'status'                => 'posted',
                'employee_contribution' => 2000.00,
                'employer_contribution' => 2000.00,
                'total_contribution'    => 4000.00,
            ],
            [
                'id'                    => 'pf-dup-002',
                'company_id'            => 'comp-dup',
                'employee_id'           => 'emp-dup-01',
                'payroll_month'         => 10,
                'payroll_year'          => 2026,
                'transaction_type'      => 'CONTRIBUTION',
                'transaction_date'      => '2026-10-31',
                'status'                => 'posted',
                'employee_contribution' => 2000.00,
                'employer_contribution' => 2000.00,
                'total_contribution'    => 4000.00,
            ],
        ]);

        $initialRowCount = (int)$db->table('provident_fund_ledgers')->countAllResults();
        $this->assertSame(2, $initialRowCount);

        $migration = new EnsureProvidentFundLedgerSchemaAndUniqueIndex();

        try {
            $migration->up();
            $this->fail('Migration must throw RuntimeException when duplicate rows prevent creating unique index.');
        } catch (\RuntimeException $e) {
            $this->assertStringContainsString("Cannot create unique index 'uq_pf_emp_m_y_type' on provident_fund_ledgers", $e->getMessage());
            $this->assertStringContainsString("found 1 duplicate group(s) on (employee_id, payroll_month, payroll_year, transaction_type)", $e->getMessage());
            $this->assertStringContainsString("Please resolve duplicate rows before running this migration.", $e->getMessage());
        }

        // Verify table data is completely unchanged
        $rowCountAfter = (int)$db->table('provident_fund_ledgers')->countAllResults();
        $this->assertSame(2, $rowCountAfter, 'Row count must remain unchanged after migration fails.');

        // Verify unique index was NOT created
        $indexes = $db->getIndexData('provident_fund_ledgers');
        $hasUniqueIndex = false;
        foreach ($indexes as $idx) {
            if ($idx->name === 'uq_pf_emp_m_y_type' && strtoupper((string)$idx->type) === 'UNIQUE') {
                $hasUniqueIndex = true;
            }
        }
        $this->assertFalse($hasUniqueIndex, 'Unique index must not exist when duplicate rows caused failure.');
    }

    /**
     * Test 4: Running the migration twice is a no-op
     */
    public function testRunningMigrationTwiceIsNoOp(): void
    {
        $migration = new EnsureProvidentFundLedgerSchemaAndUniqueIndex();

        // First run
        $migration->up();

        // Second run must succeed seamlessly without error
        $migration->up();

        $db = Database::connect();
        $this->assertTrue($db->tableExists('provident_fund_ledgers'));

        $indexes = $db->getIndexData('provident_fund_ledgers');
        $hasUniqueIndex = false;
        foreach ($indexes as $idx) {
            if ($idx->name === 'uq_pf_emp_m_y_type' && strtoupper((string)$idx->type) === 'UNIQUE') {
                $hasUniqueIndex = true;
            }
        }
        $this->assertTrue($hasUniqueIndex, 'Unique index must remain valid and intact after second run.');
    }
}
