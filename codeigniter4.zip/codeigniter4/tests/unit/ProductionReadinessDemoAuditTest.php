<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use App\Models\NoticeModel;
use App\Models\ShiftSwapModel;
use App\Services\Payroll\PayslipPdfGenerator;
use App\Database\Seeds\PayrollSeeder;
use App\Database\Seeds\DemoProvidentFundLedgerSeeder;
use App\Database\Seeds\NoticeAndNotificationSeeder;
use App\Database\Seeds\AttendanceAndLeaveSeeder;
use App\Database\Seeds\YearAttendanceSeeder;
use App\Database\Seeds\CompanySeeder;
use App\Database\Seeds\DepartmentAndDesignationSeeder;
use App\Database\Seeds\ShiftSeeder;
use App\Database\Seeds\LeavePoliciesAndTypesSeeder;
use App\Database\Seeds\EmployeeAndUserSeeder;
use App\Database\Seeds\EmployeeTestSeeder;
use App\Database\Seeds\DatabaseSeeder;
use Config\Database;

/**
 * ProductionReadinessDemoAuditTest
 *
 * Verifies that:
 * 1. NoticeModel returns empty data and 0 count on empty/missing notices instead of fake townhall notices.
 * 2. ShiftSwapModel returns empty array and 0 count on empty shift swaps instead of fake demo swaps.
 * 3. PayslipPdfGenerator does not insert hardcoded fake company branding when company metadata is omitted.
 * 4. All business demo seeders refuse to execute in production mode.
 */
class ProductionReadinessDemoAuditTest extends CIUnitTestCase
{
    /**
     * 1. NoticeModel must NOT return hardcoded fake notices when table is empty.
     */
    public function testNoticeModelReturnsEmptyWhenNoNoticesExist(): void
    {
        $db = Database::connect();
        if ($db->tableExists('notices')) {
            $db->table('notices')->truncate();
        }

        $model = new NoticeModel();
        $notices = $model->getNotices('non-existent-comp');
        $this->assertIsArray($notices);
        $this->assertEmpty($notices, 'NoticeModel must return empty array, not fake townhall notices.');

        // Test with null company_id (system/admin scope)
        $adminNotices = $model->getNotices(null);
        $this->assertIsArray($adminNotices);
        $this->assertEmpty($adminNotices, 'NoticeModel must return empty array for null company_id when DB is empty.');

        $count = $model->getActiveNoticesCount(null);
        $this->assertSame(0, $count, 'NoticeModel active count must be 0, not 3 from getDefaultNotices.');
    }

    /**
     * 2. ShiftSwapModel must NOT return hardcoded demo swaps when table is empty.
     */
    public function testShiftSwapModelReturnsEmptyWhenNoSwapsExist(): void
    {
        $db = Database::connect();
        if ($db->tableExists('shift_swap_requests')) {
            $db->table('shift_swap_requests')->truncate();
        }

        $model = new ShiftSwapModel();
        $swaps = $model->getSwapRequestsWithDetails('comp-real-001');
        $this->assertIsArray($swaps);
        $this->assertEmpty($swaps, 'ShiftSwapModel must return empty array, not fake demo swaps.');

        $pendingCount = $model->getPendingCount('comp-real-001');
        $this->assertSame(0, $pendingCount, 'Pending shift swaps count must be 0, not 1.');
    }

    /**
     * 3. PayslipPdfGenerator must NOT output "Enterprise Global HRMS" or "Corporate Headquarters".
     */
    public function testPayslipPdfGeneratorDoesNotSubstituteFakeCompanyData(): void
    {
        $generator = new PayslipPdfGenerator();
        $item = [
            'id'            => 'pay-item-001',
            'payroll_month' => '2026-05',
            'basic_salary'  => 50000.00,
            'gross_salary'  => 50000.00,
            'net_salary'    => 50000.00,
        ];
        $employee = [
            'first_name'    => 'John',
            'last_name'     => 'Doe',
            'employee_code' => 'EMP-REAL-01',
        ];
        $emptyCompany = [
            'name'    => '',
            'address' => '',
            'email'   => '',
            'phone'   => '',
        ];

        $pdfString = $generator->generate($item, $employee, $emptyCompany);
        $this->assertNotEmpty($pdfString);
        $this->assertStringNotContainsString('Enterprise Global HRMS', $pdfString, 'PDF must not contain fake company name fallback.');
        $this->assertStringNotContainsString('Corporate Headquarters', $pdfString, 'PDF must not contain fake address fallback.');
    }

    /**
     * 4. Helper to test production safety guard on a seeder class.
     */
    private function assertSeederBlockedInProduction(string $seederClass): void
    {
        $origEnv = getenv('CI_ENVIRONMENT');
        putenv('CI_ENVIRONMENT=production');

        try {
            $seeder = new $seederClass(Database::connect());
            $this->expectException(\RuntimeException::class);
            $seeder->run();
        } finally {
            if ($origEnv !== false) {
                putenv("CI_ENVIRONMENT={$origEnv}");
            } else {
                putenv('CI_ENVIRONMENT');
            }
        }
    }

    public function testPayrollSeederBlockedInProduction(): void
    {
        $this->assertSeederBlockedInProduction(PayrollSeeder::class);
    }

    public function testDemoProvidentFundLedgerSeederBlockedInProduction(): void
    {
        $this->assertSeederBlockedInProduction(DemoProvidentFundLedgerSeeder::class);
    }

    public function testNoticeAndNotificationSeederBlockedInProduction(): void
    {
        $this->assertSeederBlockedInProduction(NoticeAndNotificationSeeder::class);
    }

    public function testAttendanceAndLeaveSeederBlockedInProduction(): void
    {
        $this->assertSeederBlockedInProduction(AttendanceAndLeaveSeeder::class);
    }

    public function testYearAttendanceSeederBlockedInProduction(): void
    {
        $this->assertSeederBlockedInProduction(YearAttendanceSeeder::class);
    }

    public function testCompanySeederBlockedInProduction(): void
    {
        $this->assertSeederBlockedInProduction(CompanySeeder::class);
    }

    public function testDepartmentAndDesignationSeederBlockedInProduction(): void
    {
        $this->assertSeederBlockedInProduction(DepartmentAndDesignationSeeder::class);
    }

    public function testShiftSeederBlockedInProduction(): void
    {
        $this->assertSeederBlockedInProduction(ShiftSeeder::class);
    }

    public function testLeavePoliciesAndTypesSeederBlockedInProduction(): void
    {
        $this->assertSeederBlockedInProduction(LeavePoliciesAndTypesSeeder::class);
    }

    public function testEmployeeAndUserSeederBlockedInProduction(): void
    {
        $this->assertSeederBlockedInProduction(EmployeeAndUserSeeder::class);
    }

    public function testEmployeeTestSeederBlockedInProduction(): void
    {
        $this->assertSeederBlockedInProduction(EmployeeTestSeeder::class);
    }

    public function testDatabaseSeederBlockedInProduction(): void
    {
        $this->assertSeederBlockedInProduction(DatabaseSeeder::class);
    }
}
