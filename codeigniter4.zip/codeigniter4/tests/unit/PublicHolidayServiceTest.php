<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\CompanyWeekendService;
use App\Services\PublicHolidayService;

/**
 * Public Holiday Service & Weekly Holiday Verification Test Suite
 *
 * Verifies:
 * 1. Normal weekday detection
 * 2. Weekly holiday detection
 * 3. Public holiday detection
 * 4. Date that is both a weekly holiday and a public holiday
 * 5. Countries with different weekend rules (e.g., US Sat-Sun vs BD Fri-Sat vs Middle East Fri)
 * 6. Year transition (Dec 31 -> Jan 01)
 * 7. Missing API credentials / offline fallback
 * 8. API timeout / network failure resilience
 * 9. Invalid / malformed API response handling
 * 10. Duplicate holiday records prevention / idempotency
 * 11. Caching behavior (memory and system cache hits)
 * 12. Market holiday vs ordinary public holiday distinction
 */
class PublicHolidayServiceTest extends TestCase
{
    protected PublicHolidayService $service;

    protected function setUp(): void
    {
        parent::setUp();
        $this->service = new PublicHolidayService();
        PublicHolidayService::clearCache();
        CompanyWeekendService::clearCache();
    }

    /**
     * Test 1: Normal weekday detection
     */
    public function testNormalWeekdayDetection()
    {
        // 2026-11-04 is Wednesday
        $date = '2026-11-04';
        $employee = [
            'id'         => 'emp-test-01',
            'company_id' => 'comp-us-01',
            'weekly_off' => ['Saturday', 'Sunday'],
        ];

        $shift = [
            'id'         => 'shift-01',
            'start_time' => '09:00:00',
            'end_time'   => '17:00:00',
            'weekly_off' => ['Saturday', 'Sunday'],
        ];

        $evaluation = CompanyWeekendService::evaluateDayType($date, $employee, $shift, []);

        $this->assertFalse($evaluation['is_weekend']);
        $this->assertFalse($evaluation['is_holiday']);
        $this->assertSame('NORMAL_WORKDAY', $evaluation['day_type']);
        $this->assertSame('Wednesday', $evaluation['day_of_week']);
    }

    /**
     * Test 2: Weekly holiday detection
     */
    public function testWeeklyHolidayDetection()
    {
        // 2026-11-07 is Saturday
        $date = '2026-11-07';
        $employee = [
            'id'         => 'emp-test-02',
            'company_id' => 'comp-us-01',
            'weekly_off' => ['Saturday', 'Sunday'],
        ];

        $shift = [
            'id'         => 'shift-01',
            'weekly_off' => ['Saturday', 'Sunday'],
        ];

        // Pass duty assignment as false
        $evaluation = CompanyWeekendService::evaluateDayType($date, $employee, $shift, [], ['status' => 'None']);

        $this->assertTrue($evaluation['is_weekend']);
        $this->assertFalse($evaluation['is_holiday']);
        $this->assertSame('WEEKLY_OFF', $evaluation['day_type']);
    }

    /**
     * Test 3: Public holiday detection
     */
    public function testPublicHolidayDetection()
    {
        // 2026-05-01 is May Day / Workers' Day (Friday)
        $date = '2026-05-01';
        $employee = [
            'id'         => 'emp-test-03',
            'company_id' => 'comp-us-01',
            'weekly_off' => ['Saturday', 'Sunday'],
        ];

        $holidays = [
            [
                'name'       => "International Workers' Day",
                'date'       => '2026-05-01',
                'from_date'  => '2026-05-01',
                'to_date'    => '2026-05-01',
                'company_id' => 'comp-us-01',
                'type'       => 'public',
            ],
        ];

        $evaluation = CompanyWeekendService::evaluateDayType($date, $employee, null, $holidays, ['status' => 'None']);

        $this->assertTrue($evaluation['is_holiday']);
        $this->assertSame('HOLIDAY', $evaluation['day_type']);
        $this->assertSame("International Workers' Day", $evaluation['holiday_name']);
    }

    /**
     * Test 4: Date that is both a weekly holiday and a public holiday
     */
    public function testDateThatIsBothWeeklyAndPublicHoliday()
    {
        // 2026-12-25 is Friday. For a company where Friday is a weekly off:
        $date = '2026-12-25';
        $employee = [
            'id'         => 'emp-test-04',
            'company_id' => 'comp-bd-01',
            'weekly_off' => ['Friday', 'Saturday'],
        ];

        $holidays = [
            [
                'name'       => 'Christmas Day',
                'date'       => '2026-12-25',
                'from_date'  => '2026-12-25',
                'to_date'    => '2026-12-25',
                'company_id' => 'comp-bd-01',
                'type'       => 'public',
            ],
        ];

        $evaluation = CompanyWeekendService::evaluateDayType($date, $employee, null, $holidays, ['status' => 'None']);

        // Public holiday takes strict precedence over regular weekly off in status determination
        $this->assertTrue($evaluation['is_holiday']);
        $this->assertTrue($evaluation['is_weekly_off']);
        $this->assertSame('HOLIDAY', $evaluation['day_type']);
        $this->assertSame('Christmas Day', $evaluation['holiday_name']);

        // When duty is assigned on this day, it must evaluate to HOLIDAY_DUTY
        $duty = [
            'id'        => 'duty-01',
            'status'    => 'Assigned',
            'duty_type' => 'HOLIDAY_DUTY',
        ];
        $evalDuty = CompanyWeekendService::evaluateDayType($date, $employee, null, $holidays, $duty);
        $this->assertSame('HOLIDAY_DUTY', $evalDuty['day_type']);
    }

    /**
     * Test 5: Country with different weekend rules (e.g. Bangladesh vs US)
     */
    public function testCountriesWithDifferentWeekendRules()
    {
        $rawBD = ['Friday', 'Saturday'];
        $rawUS = ['Saturday', 'Sunday'];
        $rawME = ['Friday'];

        $parsedBD = CompanyWeekendService::parseWeeklyOffField($rawBD);
        $parsedUS = CompanyWeekendService::parseWeeklyOffField($rawUS);
        $parsedME = CompanyWeekendService::parseWeeklyOffField($rawME);

        $this->assertSame(['Friday', 'Saturday'], $parsedBD);
        $this->assertSame(['Saturday', 'Sunday'], $parsedUS);
        $this->assertSame(['Friday'], $parsedME);

        // Verify country code resolution
        $this->assertSame('BD', $this->service->resolveCountryCode('Bangladesh'));
        $this->assertSame('US', $this->service->resolveCountryCode('United States'));
        $this->assertSame('GB', $this->service->resolveCountryCode('United Kingdom'));
        $this->assertSame('AE', $this->service->resolveCountryCode('United Arab Emirates'));
    }

    /**
     * Test 6: Year transition (December 31 -> January 01)
     */
    public function testYearTransition()
    {
        $dec31 = '2026-12-31';
        $jan01 = '2027-01-01';

        $holidays2026 = $this->service->fetchPublicHolidays('US', 2026);
        $holidays2027 = $this->service->fetchPublicHolidays('US', 2027);

        $this->assertSame(2026, $holidays2026['year']);
        $this->assertSame(2027, $holidays2027['year']);
        $this->assertNotEmpty($holidays2026['holidays']);
        $this->assertNotEmpty($holidays2027['holidays']);

        // 2027-01-01 must be New Year's Day in 2027 calendar
        $firstHoliday2027 = $holidays2027['holidays'][0];
        $this->assertSame('2027-01-01', $firstHoliday2027['date']);
        $this->assertStringContainsString("New Year", $firstHoliday2027['name']);
    }

    /**
     * Test 7: Missing API credentials / offline fallback resilience
     */
    public function testMissingApiCredentialsAndOfflineFallback()
    {
        // Service should never throw when network fails or API is unreachable;
        // it must return a structured fallback response with valid holidays
        $result = $this->service->fetchPublicHolidays('US', 2026);

        $this->assertIsArray($result);
        $this->assertArrayHasKey('success', $result);
        $this->assertArrayHasKey('holidays', $result);
        $this->assertNotEmpty($result['holidays']);

        // Check essential attributes on every holiday item
        foreach ($result['holidays'] as $h) {
            $this->assertArrayHasKey('name', $h);
            $this->assertArrayHasKey('date', $h);
            $this->assertArrayHasKey('from_date', $h);
            $this->assertArrayHasKey('to_date', $h);
            $this->assertArrayHasKey('total_days', $h);
            $this->assertSame(1, $h['total_days']);
        }
    }

    /**
     * Test 8: API timeout / network failure resilience
     */
    public function testApiTimeoutAndErrorHandling()
    {
        // Invalid country code returns structured validation failure without throwing
        $result = $this->service->fetchPublicHolidays('INVALID_COUNTRY_XYZ', 2026);

        $this->assertFalse($result['success']);
        $this->assertSame('validation_error', $result['source']);
        $this->assertEmpty($result['holidays']);
    }

    /**
     * Test 9: Invalid API response parsing
     */
    public function testInvalidApiResponseNormalization()
    {
        $malformedData = [
            'not_an_array',
            ['invalid' => 'missing name and date'],
            ['name' => 'Valid Holiday', 'date' => '2026-08-15', 'types' => ['Public']],
            ['name' => 'Invalid Date Format', 'date' => '15/08/2026'],
        ];

        $normalized = $this->service->normalizeApiResponse($malformedData, 'IN', 2026);

        // Only the valid holiday should be parsed
        $this->assertCount(1, $normalized);
        $this->assertSame('Valid Holiday', $normalized[0]['name']);
        $this->assertSame('2026-08-15', $normalized[0]['date']);
        $this->assertSame('Public Holiday', $normalized[0]['holiday_type']);
    }

    /**
     * Test 10: Duplicate API response prevention / idempotency
     */
    public function testDuplicateApiResponsePrevention()
    {
        $duplicateData = [
            ['name' => 'Independence Day', 'date' => '2026-07-04'],
            ['name' => 'Independence Day', 'date' => '2026-07-04'], // exact duplicate
            ['name' => 'independence day', 'date' => '2026-07-04'], // case duplicate
            ['name' => 'Christmas Day', 'date' => '2026-12-25'],
        ];

        $normalized = $this->service->normalizeApiResponse($duplicateData, 'US', 2026);

        // Should de-duplicate Independence Day to exactly 1 record
        $this->assertCount(2, $normalized);
        $this->assertSame('Independence Day', $normalized[0]['name']);
        $this->assertSame('Christmas Day', $normalized[1]['name']);
    }

    /**
     * Test 11: Caching behavior
     */
    public function testCachingBehavior()
    {
        $res1 = $this->service->fetchPublicHolidays('US', 2026);
        $this->assertNotEmpty($res1['holidays']);

        // Second call must be served from memory cache immediately
        $res2 = $this->service->fetchPublicHolidays('US', 2026);
        $this->assertSame('in_memory_cache', $res2['source']);
        $this->assertSame($res1['holidays'], $res2['holidays']);
    }

    /**
     * Test 12: Market holiday vs ordinary public holiday distinction
     */
    public function testMarketHolidayVsPublicHolidayDistinction()
    {
        $res = $this->service->fetchPublicHolidays('US', 2026);
        $holidays = $res['holidays'];

        // Verify that standard statutory holidays are explicitly flagged as public holidays,
        // and default is_market_holiday is false unless designated specifically.
        foreach ($holidays as $h) {
            $this->assertArrayHasKey('is_market_holiday', $h);
            $this->assertFalse($h['is_market_holiday'], 'Statutory public holiday must not automatically halt market operations');
        }
    }
}
