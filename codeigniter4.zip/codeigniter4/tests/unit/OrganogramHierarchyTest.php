<?php

namespace Tests\Unit;

use App\Models\EmployeeOrganogramModel;
use App\Services\OrganogramService;
use PHPUnit\Framework\TestCase;

/**
 * Pure-logic tests for the organogram tree builder and manager validation.
 * No database: the model is replaced by an in-memory stub.
 */
class OrganogramHierarchyTest extends TestCase
{
    private function emp(string $id, ?string $manager, string $status = 'active', string $company = 'c1'): array
    {
        return [
            'id' => $id, 'first_name' => $id, 'last_name' => 'T', 'name' => $id . ' T',
            'employee_code' => 'E-' . $id, 'company_id' => $company, 'status' => $status,
            'reporting_manager_id' => $manager, 'manager_id' => $manager,
            'department_id' => 'd1', 'department_name' => 'Dept', 'branch_id' => 'b1', 'branch_name' => 'HQ',
        ];
    }

    private function service(array $rows): OrganogramService
    {
        $byId = [];
        foreach ($rows as $r) {
            $byId[$r['id']] = $r;
        }

        $model = new class($rows, $byId) extends EmployeeOrganogramModel {
            private array $rows;
            private array $byId;

            public function __construct(array $rows, array $byId)
            {
                $this->rows = $rows;
                $this->byId = $byId;
            }

            public function getEmployeesForOrganogram(array $filters = [], ?string $companyId = null): array
            {
                return $this->rows;
            }

            public function getEmployeeWithHierarchy(string $id, ?string $companyId = null): ?array
            {
                $e = $this->byId[$id] ?? null;
                if ($e === null || ($companyId !== null && $e['company_id'] !== $companyId)) {
                    return null;
                }
                $mgr = $e['reporting_manager_id'] ? ($this->byId[$e['reporting_manager_id']] ?? null) : null;
                $e['manager_id_raw']  = $e['reporting_manager_id'];
                $e['manager_name']    = $mgr['name'] ?? '';
                return $e;
            }
        };

        $svc = (new \ReflectionClass(OrganogramService::class))->newInstanceWithoutConstructor();
        $prop = new \ReflectionProperty(OrganogramService::class, 'organogramModel');
        $prop->setAccessible(true);
        $prop->setValue($svc, $model);
        return $svc;
    }

    private function countNodes(array $nodes): int
    {
        $n = 0;
        foreach ($nodes as $node) {
            $n += 1 + $this->countNodes($node['children'] ?? []);
        }
        return $n;
    }

    private function assertEveryoneAccountedFor(array $result): void
    {
        $shown = $this->countNodes($result['tree']) + $this->countNodes($result['unassigned']) + count($result['cyclic']);
        $this->assertSame($result['total_employees'], $shown, 'tree + unassigned + cyclic must equal total_employees');
    }

    public function testHealthyTreeHasNoCyclicNodes(): void
    {
        $r = $this->service([$this->emp('ceo', null), $this->emp('a', 'ceo'), $this->emp('b', 'a')])->getOrganogramTree();
        $this->assertCount(1, $r['tree']);
        $this->assertSame([], $r['cyclic']);
        $this->assertSame(3, $r['max_depth']);
        $this->assertEveryoneAccountedFor($r);
    }

    public function testTwoPersonLoopIsReportedNotDropped(): void
    {
        $r = $this->service([$this->emp('ceo', null), $this->emp('x1', 'x2'), $this->emp('x2', 'x1')])->getOrganogramTree();
        $ids = array_column($r['cyclic'], 'id');
        sort($ids);
        $this->assertSame(['x1', 'x2'], $ids);
        $this->assertTrue($r['cyclic'][0]['is_cyclic']);
        $this->assertEveryoneAccountedFor($r);
    }

    public function testSelfManagerIsReportedAsCyclic(): void
    {
        $r = $this->service([$this->emp('ceo', null), $this->emp('s', 's')])->getOrganogramTree();
        $this->assertSame(['s'], array_column($r['cyclic'], 'id'));
        $this->assertEveryoneAccountedFor($r);
    }

    public function testEveryoneInALoopStillShowsUp(): void
    {
        $r = $this->service([$this->emp('x1', 'x2'), $this->emp('x2', 'x1')])->getOrganogramTree();
        $this->assertSame([], $r['tree']);
        $this->assertCount(2, $r['cyclic']);
        $this->assertEveryoneAccountedFor($r);
    }

    public function testManagerOutsideTheViewGoesToUnassigned(): void
    {
        $r = $this->service([$this->emp('ceo', null), $this->emp('b', 'gone'), $this->emp('c', 'b')])->getOrganogramTree();
        $this->assertSame(['b'], array_column($r['unassigned'], 'id'));
        $this->assertSame([], $r['cyclic']);
        $this->assertEveryoneAccountedFor($r);
    }

    public function testUnassigningManagerIsAlwaysValid(): void
    {
        $v = $this->service([$this->emp('a', null)])->validateManagerAssignment('a', null, 'c1');
        $this->assertTrue($v['valid']);
        $this->assertNull($v['sanitized_manager_id']);
    }

    public function testSelfAssignmentRejected(): void
    {
        $v = $this->service([$this->emp('a', null)])->validateManagerAssignment('a', 'a', 'c1');
        $this->assertFalse($v['valid']);
    }

    public function testCycleThroughIntermediateInactiveEmployeeIsRejected(): void
    {
        // a manages b (inactive), b manages c. Making c the manager of a would close the loop.
        $svc = $this->service([$this->emp('a', null), $this->emp('b', 'a', 'inactive'), $this->emp('c', 'b')]);
        $v = $svc->validateManagerAssignment('a', 'c', 'c1');
        $this->assertFalse($v['valid']);
        $this->assertStringContainsString('Circular', $v['error']);
    }

    public function testInactiveOrSuspendedManagerRejected(): void
    {
        foreach (['terminated', 'resigned', 'inactive', 'suspended'] as $status) {
            $svc = $this->service([$this->emp('a', null), $this->emp('m', null, $status)]);
            $this->assertFalse($svc->validateManagerAssignment('a', 'm', 'c1')['valid'], $status);
        }
    }

    public function testCrossCompanyManagerRejected(): void
    {
        $svc = $this->service([$this->emp('a', null, 'active', 'c1'), $this->emp('m', null, 'active', 'c2')]);
        $this->assertFalse($svc->validateManagerAssignment('a', 'm', 'c1')['valid']);
        $this->assertFalse($svc->validateManagerAssignment('a', 'm', null)['valid'], 'null company must not bypass the company check');
    }

    public function testNewEmployeeWithoutIdCanPickAValidManager(): void
    {
        $svc = $this->service([$this->emp('m', null)]);
        $v = $svc->validateManagerAssignment('', 'm', 'c1');
        $this->assertTrue($v['valid']);
        $this->assertSame('m', $v['sanitized_manager_id']);
    }

    public function testValidReassignmentAccepted(): void
    {
        $svc = $this->service([$this->emp('ceo', null), $this->emp('a', 'ceo'), $this->emp('b', 'ceo')]);
        $this->assertTrue($svc->validateManagerAssignment('b', 'a', 'c1')['valid']);
    }
}
