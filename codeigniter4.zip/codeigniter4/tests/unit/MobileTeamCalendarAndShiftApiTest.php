<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobileTeamCalendarAndShiftApiTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;
    private array $device = ['device_uid' => 'dev-shift-team-1', 'platform' => 'android'];

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);

        foreach (['leave_applications', 'leave_types', 'holidays', 'shifts', 'shift_swap_requests', 'duty_assignments', 'roster_assignments', 'rosters'] as $t) {
            $this->db->query("DROP TABLE IF EXISTS {$t}");
        }

        $this->db->query("CREATE TABLE leave_types (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            name VARCHAR(100),
            code VARCHAR(30),
            is_paid INT DEFAULT 1,
            days_allowed INT DEFAULT 14,
            allow_carry_forward INT DEFAULT 0,
            status VARCHAR(30) DEFAULT 'Active'
        )");

        $this->db->query("CREATE TABLE leave_applications (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            employee_id VARCHAR(36),
            leave_type_id VARCHAR(36),
            from_date DATE,
            to_date DATE,
            start_date DATE,
            end_date DATE,
            total_days DECIMAL(5,2) DEFAULT 1,
            paid_days DECIMAL(5,2) DEFAULT 1,
            unpaid_days DECIMAL(5,2) DEFAULT 0,
            half_day VARCHAR(20) DEFAULT 'None',
            is_half_day INT DEFAULT 0,
            is_emergency INT DEFAULT 0,
            reason TEXT,
            status VARCHAR(30) DEFAULT 'Pending',
            applied_at DATETIME NULL,
            approved_by VARCHAR(36) NULL,
            approved_at DATETIME NULL,
            rejection_reason TEXT NULL,
            cancellation_reason TEXT NULL,
            manager_status VARCHAR(30) DEFAULT 'Pending',
            dept_head_status VARCHAR(30) DEFAULT 'Pending',
            hr_status VARCHAR(30) DEFAULT 'Pending',
            covering_employee_id VARCHAR(36) NULL,
            attachment_path VARCHAR(255) NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE holidays (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36) NULL,
            branch_id VARCHAR(36) NULL,
            department_id VARCHAR(36) NULL,
            employee_id VARCHAR(36) NULL,
            scope VARCHAR(30) DEFAULT 'Global',
            name VARCHAR(100),
            date DATE NULL,
            from_date DATE NULL,
            to_date DATE NULL,
            total_days INT DEFAULT 1,
            holiday_type VARCHAR(30) DEFAULT 'public',
            type VARCHAR(30) DEFAULT 'public',
            description TEXT NULL,
            is_working_day INT DEFAULT 0,
            status VARCHAR(30) DEFAULT 'Active',
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE shifts (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36) NULL,
            branch_id VARCHAR(36) NULL,
            name VARCHAR(100),
            code VARCHAR(30),
            start_time TIME,
            end_time TIME,
            break_start TIME NULL,
            break_end TIME NULL,
            break_duration_minutes INT DEFAULT 60,
            grace_time INT DEFAULT 15,
            late_grace_period_mins INT DEFAULT 15,
            late_grace_period_minutes INT DEFAULT 15,
            late_threshold_minutes INT DEFAULT 60,
            early_out_threshold_minutes INT DEFAULT 15,
            minimum_working_hours DECIMAL(5,2) DEFAULT 8.00,
            half_day_threshold_hours DECIMAL(5,2) DEFAULT 4.00,
            absent_threshold_hours DECIMAL(5,2) DEFAULT 2.00,
            overtime_start TIME NULL,
            weekly_off VARCHAR(255) NULL,
            work_days VARCHAR(255) NULL,
            night_shift INT DEFAULT 0,
            flexible_shift INT DEFAULT 0,
            color VARCHAR(30) DEFAULT '#3b82f6',
            min_staffing_required INT DEFAULT 1,
            description TEXT NULL,
            status VARCHAR(30) DEFAULT 'Active',
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE shift_swap_requests (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36) NOT NULL,
            branch_id VARCHAR(36) NULL,
            requester_id VARCHAR(36) NOT NULL,
            requester_shift_id VARCHAR(36) NULL,
            target_employee_id VARCHAR(36) NOT NULL,
            target_employee_shift_id VARCHAR(36) NULL,
            requested_shift_id VARCHAR(36) NULL,
            swap_date DATE NOT NULL,
            reason TEXT NULL,
            status VARCHAR(30) DEFAULT 'Pending',
            reviewed_by VARCHAR(36) NULL,
            reviewed_at DATETIME NULL,
            rejection_reason TEXT NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE rosters (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36) NOT NULL,
            branch_id VARCHAR(36) NULL,
            department_id VARCHAR(36) NULL,
            name VARCHAR(100),
            start_date DATE NOT NULL,
            end_date DATE NOT NULL,
            status VARCHAR(30) DEFAULT 'published',
            created_by VARCHAR(36) NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE roster_assignments (
            id VARCHAR(36) PRIMARY KEY,
            roster_id VARCHAR(36) NULL,
            company_id VARCHAR(36) NOT NULL,
            employee_id VARCHAR(36) NOT NULL,
            date DATE NOT NULL,
            shift_id VARCHAR(36) NOT NULL,
            is_published INT DEFAULT 1,
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $this->db->table('branches')->insert(['id' => 'br-dhaka', 'name' => 'Dhaka HQ']);
        $this->db->table('departments')->insert(['id' => 'dept-tech', 'name' => 'Engineering']);
        $this->db->table('departments')->insert(['id' => 'dept-sales', 'name' => 'Sales']);
        $this->db->table('designations')->insert(['id' => 'desig-eng', 'name' => 'Software Engineer']);
    }

    private function issueAuth(string $email, string $companyId = 'comp-acme', string $empId = 'emp-1'): array
    {
        return $this->issueTokenPair(
            $this->db,
            $this->device,
            $companyId,
            $empId,
            'user-' . $empId,
            ['employee', 'staff'],
            ['leave.view', 'leave.create', 'shift.view', 'attendance.view', 'rostering.view']
        );
    }

    public function testTeamCalendarAccessibleViaV1AndTypoPath(): void
    {
        $this->seedEmployee($this->db, 'emp-1', 'comp-acme', 'Rahim', 'Ali', 'dept-tech', 'desig-eng', 'br-dhaka');
        $this->seedEmployee($this->db, 'emp-2', 'comp-acme', 'Karim', 'Uddin', 'dept-tech', 'desig-eng', 'br-dhaka');

        $tokens = $this->issueAuth('rahim@test.local', 'comp-acme', 'emp-1');

        $this->db->table('leave_types')->insert([
            'id' => 'lt-annual', 'company_id' => 'comp-acme', 'name' => 'Annual Leave', 'code' => 'AL', 'is_paid' => 1
        ]);

        // Karim's approved leave with personal reason
        $this->db->table('leave_applications')->insert([
            'id'            => 'app-karim-1',
            'company_id'    => 'comp-acme',
            'employee_id'   => 'emp-2',
            'leave_type_id' => 'lt-annual',
            'from_date'     => '2026-11-05',
            'to_date'       => '2026-11-07',
            'start_date'    => '2026-11-05',
            'end_date'      => '2026-11-07',
            'total_days'    => 3,
            'reason'        => 'Highly confidential medical appointment',
            'status'        => 'Approved',
            'created_at'    => '2026-11-01 10:00:00'
        ]);

        // 1. Correct path /api/v1/leave/team-calendar
        $res = $this->withHeaders(['Authorization' => 'Bearer ' . $tokens['access_token']])
            ->get('/api/v1/leave/team-calendar?from=2026-11-01&to=2026-11-30');

        $res->assertStatus(200);
        $json = json_decode($res->getJSON(), true);
        $this->assertTrue($json['success']);
        $this->assertEquals('2026-11-01', $json['data']['from']);
        $this->assertEquals('2026-11-30', $json['data']['to']);
        $this->assertEquals('dept-tech', $json['data']['department_id']);
        $this->assertCount(1, $json['data']['leaves']);
        $this->assertEquals('emp-2', $json['data']['leaves'][0]['employee_id']);
        $this->assertEquals('Karim Uddin', $json['data']['leaves'][0]['employee_name']);

        // 2. Client typo path /api/v1/lleave/team-calendar also resolves seamlessly
        $resTypo = $this->withHeaders(['Authorization' => 'Bearer ' . $tokens['access_token']])
            ->get('/api/v1/lleave/team-calendar?from=2026-11-01&to=2026-11-30');
        $resTypo->assertStatus(200);

        // 3. Mobile prefix /api/mobile/v1/leave/team-calendar
        $resMobile = $this->withHeaders(['Authorization' => 'Bearer ' . $tokens['access_token']])
            ->get('/api/mobile/v1/leave/team-calendar?from=2026-11-01&to=2026-11-30');
        $resMobile->assertStatus(200);

        // 4. Leave history endpoint /api/v1/leave/history and /api/v1/leaves/history
        $resHistory = $this->withHeaders(['Authorization' => 'Bearer ' . $tokens['access_token']])
            ->get('/api/v1/leave/history');
        $resHistory->assertStatus(200);
        $jsonHist = json_decode($resHistory->getJSON(), true);
        $this->assertTrue($jsonHist['success']);
        $this->assertArrayHasKey('applications', $jsonHist['data']);
        $this->assertArrayHasKey('history', $jsonHist['data']);
    }

    public function testTeamCalendarHidesUnapprovedColleagueLeaves(): void
    {
        $this->seedEmployee($this->db, 'emp-1', 'comp-acme', 'Rahim', 'Ali', 'dept-tech', 'desig-eng', 'br-dhaka');
        $this->seedEmployee($this->db, 'emp-2', 'comp-acme', 'Karim', 'Uddin', 'dept-tech', 'desig-eng', 'br-dhaka');

        $tokens = $this->issueAuth('rahim@test.local', 'comp-acme', 'emp-1');

        $this->db->table('leave_types')->insert([
            'id' => 'lt-casual', 'company_id' => 'comp-acme', 'name' => 'Casual Leave', 'code' => 'CL', 'is_paid' => 1
        ]);

        // Karim's pending leave - should NOT be visible to peer Rahim
        $this->db->table('leave_applications')->insert([
            'id'            => 'app-karim-pending',
            'company_id'    => 'comp-acme',
            'employee_id'   => 'emp-2',
            'leave_type_id' => 'lt-casual',
            'from_date'     => '2026-11-12',
            'to_date'       => '2026-11-12',
            'start_date'    => '2026-11-12',
            'end_date'      => '2026-11-12',
            'total_days'    => 1,
            'reason'        => 'Personal draft reason',
            'status'        => 'Pending',
            'created_at'    => '2026-11-01 10:00:00'
        ]);

        $res = $this->withHeaders(['Authorization' => 'Bearer ' . $tokens['access_token']])
            ->get('/api/v1/leave/team-calendar?from=2026-11-01&to=2026-11-30');

        $res->assertStatus(200);
        $json = json_decode($res->getJSON(), true);
        $this->assertCount(0, $json['data']['leaves']);
    }

    public function testShiftApiEndpoints(): void
    {
        $this->seedEmployee($this->db, 'emp-1', 'comp-acme', 'Rahim', 'Ali', 'dept-tech', 'desig-eng', 'br-dhaka');
        $tokens = $this->issueAuth('rahim@test.local', 'comp-acme', 'emp-1');

        $this->db->table('shifts')->insert([
            'id'                     => 'sh-morning',
            'company_id'             => 'comp-acme',
            'branch_id'              => 'br-dhaka',
            'name'                   => 'Morning Shift',
            'code'                   => 'MORN',
            'start_time'             => '08:00:00',
            'end_time'               => '17:00:00',
            'working_hours'          => 8.0,
            'break_duration_minutes' => 60,
            'grace_time'             => 15,
            'status'                 => 'Active',
            'color'                  => '#10b981',
            'created_at'             => '2026-01-01 00:00:00'
        ]);

        $this->db->table('shifts')->insert([
            'id'                     => 'sh-other-comp',
            'company_id'             => 'comp-other',
            'name'                   => 'Other Company Shift',
            'code'                   => 'OTHER',
            'start_time'             => '09:00:00',
            'end_time'               => '18:00:00',
            'status'                 => 'Active',
            'created_at'             => '2026-01-01 00:00:00'
        ]);

        // 1. GET /api/v1/shifts (tenant scoped)
        $res = $this->withHeaders(['Authorization' => 'Bearer ' . $tokens['access_token']])
            ->get('/api/v1/shifts');

        $res->assertStatus(200);
        $json = json_decode($res->getJSON(), true);
        $this->assertTrue($json['success']);
        $this->assertCount(1, $json['data']['shifts']);
        $this->assertEquals('Morning Shift', $json['data']['shifts'][0]['name']);

        // 2. GET /api/v1/shifts/{id}
        $resDetail = $this->withHeaders(['Authorization' => 'Bearer ' . $tokens['access_token']])
            ->get('/api/v1/shifts/sh-morning');
        $resDetail->assertStatus(200);
        $jsonDetail = json_decode($resDetail->getJSON(), true);
        $this->assertEquals('Morning Shift', $jsonDetail['data']['shift']['name']);

        // 3. Cross-tenant access denied
        $resCross = $this->withHeaders(['Authorization' => 'Bearer ' . $tokens['access_token']])
            ->get('/api/v1/shifts/sh-other-comp');
        $resCross->assertStatus(404);

        // 4. GET /api/v1/shifts/current
        $resCurrent = $this->withHeaders(['Authorization' => 'Bearer ' . $tokens['access_token']])
            ->get('/api/v1/shifts/current?date=2026-11-02');
        $resCurrent->assertStatus(200);
        $jsonCurrent = json_decode($resCurrent->getJSON(), true);
        $this->assertTrue($jsonCurrent['success']);
        $this->assertEquals('2026-11-02', $jsonCurrent['data']['date']);

        // 5. GET /api/v1/shifts/upcoming
        $resUpcoming = $this->withHeaders(['Authorization' => 'Bearer ' . $tokens['access_token']])
            ->get('/api/v1/shifts/upcoming?days=7');
        $resUpcoming->assertStatus(200);
        $jsonUpcoming = json_decode($resUpcoming->getJSON(), true);
        $this->assertTrue($jsonUpcoming['success']);
        $this->assertEquals(7, $jsonUpcoming['data']['count']);
    }
}
