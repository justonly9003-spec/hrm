<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use App\Controllers\Assets\AssetController;
use App\Models\AssetModel;
use App\Models\AssetAssignmentModel;
use Config\Database;

class AssetUpdateAndMaintenanceStatusTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected static bool $schemaInitialized = false;

    protected string $tenantCompanyId = 'comp-asset-test-01';
    protected string $tenantEmpId     = 'emp-asset-test-01';
    protected string $tenantCatId     = 'cat-asset-test-01';

    protected array $adminUser = [];
    protected array $redactedUser = [];

    public static function setUpBeforeClass(): void
    {
        parent::setUpBeforeClass();
        static::ensureSchema();
    }

    public static function registerSqliteFunctions($db): void
    {
        try {
            $rawConn = $db->connID ?? null;
            if ($rawConn instanceof \SQLite3) {
                $rawConn->createFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->createFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->createFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            } elseif (is_object($rawConn) && method_exists($rawConn, 'sqliteCreateFunction')) {
                $rawConn->sqliteCreateFunction('CONCAT', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('concat', function (...$args) {
                    return implode('', array_map(fn($a) => (string)($a ?? ''), $args));
                });
                $rawConn->sqliteCreateFunction('CONCAT_WS', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
                $rawConn->sqliteCreateFunction('concat_ws', function ($sep, ...$args) {
                    $filtered = array_filter($args, fn($a) => $a !== null);
                    return implode((string)$sep, $filtered);
                });
            }
        } catch (\Throwable $e) {
            // ignore
        }
    }

    protected static function ensureSchema(): void
    {
        $db = Database::connect();
        static::registerSqliteFunctions($db);

        $schemaFile = __DIR__ . '/Rules/schema.sqlite.sql';
        if (file_exists($schemaFile)) {
            $sql = file_get_contents($schemaFile);
            $statements = array_filter(array_map('trim', explode(';', $sql)));
            foreach ($statements as $stmt) {
                if (!empty($stmt)) {
                    try {
                        $db->query($stmt);
                    } catch (\Throwable $e) {
                        // ignore
                    }
                }
            }
        }

        try {
            $db->query("CREATE TABLE IF NOT EXISTS company_assets (
                id VARCHAR(36) PRIMARY KEY,
                company_id VARCHAR(36) NOT NULL,
                asset_name VARCHAR(150) NOT NULL,
                name VARCHAR(150) NULL,
                asset_code VARCHAR(50) NOT NULL,
                code VARCHAR(50) NULL,
                category_id VARCHAR(36) NULL,
                category VARCHAR(100) NULL,
                serial_number VARCHAR(100) NULL,
                purchase_date DATE NULL,
                purchase_value DECIMAL(15,2) DEFAULT 0.00,
                warranty_expiry DATE NULL,
                status VARCHAR(30) DEFAULT 'Available',
                condition_status VARCHAR(30) DEFAULT 'good',
                assigned_to VARCHAR(36) NULL,
                assigned_date DATE NULL,
                written_off_at DATETIME NULL,
                written_off_reason VARCHAR(100) NULL,
                written_off_by_employee_id VARCHAR(36) NULL,
                recovery_amount DECIMAL(15,2) DEFAULT 0.00,
                recovery_recovered_amount DECIMAL(15,2) DEFAULT 0.00,
                recovery_payroll_item_id VARCHAR(36) NULL,
                notes TEXT NULL,
                deleted_at DATETIME NULL,
                created_at DATETIME NULL,
                updated_at DATETIME NULL
            )");

            $db->query("CREATE TABLE IF NOT EXISTS asset_assignments (
                id VARCHAR(36) PRIMARY KEY,
                company_id VARCHAR(36) NOT NULL,
                asset_id VARCHAR(36) NOT NULL,
                employee_id VARCHAR(36) NOT NULL,
                assigned_date DATE NOT NULL,
                returned_date DATE NULL,
                condition_on_assign VARCHAR(30) DEFAULT 'good',
                condition_on_return VARCHAR(30) NULL,
                assigned_by VARCHAR(36) NULL,
                returned_by VARCHAR(36) NULL,
                notes TEXT NULL,
                created_at DATETIME NULL,
                updated_at DATETIME NULL
            )");

            $db->query("CREATE TABLE IF NOT EXISTS asset_categories (
                id VARCHAR(36) PRIMARY KEY,
                company_id VARCHAR(36) NOT NULL,
                name VARCHAR(100) NOT NULL,
                code VARCHAR(30) NULL,
                depreciation_method VARCHAR(30) DEFAULT 'straight_line',
                useful_life_years INT DEFAULT 3,
                salvage_value_percent DECIMAL(5,2) DEFAULT 0.00,
                requires_serial TINYINT DEFAULT 0,
                status VARCHAR(20) DEFAULT 'active',
                created_at DATETIME NULL,
                updated_at DATETIME NULL
            )");
        } catch (\Throwable $e) {
            // ignore
        }
    }

    protected function setUp(): void
    {
        parent::setUp();
        static::ensureSchema();

        $db = Database::connect();
        static::registerSqliteFunctions($db);

        // Seed company
        $db->table('companies')->replace([
            'id'     => $this->tenantCompanyId,
            'name'   => 'Asset Test Org',
            'code'   => 'COMP-AST-TEST',
            'status' => 'Active',
        ]);

        // Seed employee
        $db->table('employees')->replace([
            'id'            => $this->tenantEmpId,
            'company_id'    => $this->tenantCompanyId,
            'employee_code' => 'EMP-AST-01',
            'first_name'    => 'Alice',
            'last_name'     => 'Engineer',
            'email'         => 'alice@test.com',
            'gender'        => 'female',
            'dob'           => '1992-05-15',
            'status'        => 'active',
            'created_at'    => date('Y-m-d H:i:s'),
            'updated_at'    => date('Y-m-d H:i:s'),
        ]);

        // Seed category
        $db->table('asset_categories')->replace([
            'id'                  => $this->tenantCatId,
            'company_id'          => $this->tenantCompanyId,
            'name'                => 'Laptops',
            'code'                => 'LAPTOP',
            'depreciation_method' => 'straight_line',
            'useful_life_years'   => 3,
            'status'              => 'active',
        ]);

        // Admin User (all permissions)
        $this->adminUser = [
            'id'                  => 'usr-ast-admin-01',
            'company_id'          => $this->tenantCompanyId,
            'username'            => 'ast_admin',
            'name'                => 'Asset Admin',
            'email'               => 'admin@test.com',
            'role'                => 'Company Admin',
            'role_code'           => 'company_admin',
            'role_id'             => 'role-ast-admin',
            'selected_company_id' => $this->tenantCompanyId,
            'permissions'         => ['*'],
        ];

        // Redacted User (has assets.view and assets.edit, but NOT assets.manage and NOT assets.export)
        $this->redactedUser = [
            'id'                  => 'usr-ast-editor-01',
            'company_id'          => $this->tenantCompanyId,
            'username'            => 'ast_editor',
            'name'                => 'Asset Editor',
            'email'               => 'editor@test.com',
            'role'                => 'Inventory Clerk',
            'role_code'           => 'inventory_clerk',
            'role_id'             => 'role-ast-editor',
            'selected_company_id' => $this->tenantCompanyId,
            'permissions'         => ['assets.view', 'assets.edit'],
        ];

        $db->table('users')->replace([
            'id'            => $this->adminUser['id'],
            'company_id'    => $this->tenantCompanyId,
            'username'      => $this->adminUser['username'],
            'email'         => $this->adminUser['email'],
            'password_hash' => password_hash('Secret123!', PASSWORD_BCRYPT),
            'role_id'       => $this->adminUser['role_id'],
            'status'        => 'Active',
        ]);

        $db->table('users')->replace([
            'id'            => $this->redactedUser['id'],
            'company_id'    => $this->tenantCompanyId,
            'username'      => $this->redactedUser['username'],
            'email'         => $this->redactedUser['email'],
            'password_hash' => password_hash('Secret123!', PASSWORD_BCRYPT),
            'role_id'       => $this->redactedUser['role_id'],
            'status'        => 'Active',
        ]);
    }

    protected function setupController(array $user, array $postData = [], bool $isAjax = true): AssetController
    {
        $session = \Config\Services::session();
        $session->set('user', $user);

        $_SERVER['REQUEST_METHOD'] = 'POST';
        if ($isAjax) {
            $_SERVER['HTTP_ACCEPT'] = 'application/json';
            $_SERVER['HTTP_X_REQUESTED_WITH'] = 'xmlhttprequest';
        } else {
            unset($_SERVER['HTTP_ACCEPT'], $_SERVER['HTTP_X_REQUESTED_WITH']);
        }
        $_POST = $postData;

        $request = \Config\Services::request();
        $response = \Config\Services::response();
        $logger = \Config\Services::logger();

        $controller = new AssetController();
        $controller->initController($request, $response, $logger);

        return $controller;
    }

    /**
     * Test 1: update() accepts purchase_date, purchase_value, and warranty_expiry
     */
    public function testUpdateAcceptsPurchaseDateValueAndWarrantyExpiry(): void
    {
        $db = Database::connect();
        $assetId = 'ast-test-update-01';

        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'asset_name'       => 'ThinkPad X1 Carbon',
            'asset_code'       => 'TP-X1-01',
            'category_id'      => $this->tenantCatId,
            'category'         => 'Laptops',
            'serial_number'    => 'SN-TP-01',
            'purchase_date'    => '2023-01-01',
            'purchase_value'   => 1200.00,
            'warranty_expiry'  => '2025-01-01',
            'status'           => 'Available',
            'condition_status' => 'good',
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->setupController($this->adminUser, [
            'asset_name'      => 'ThinkPad X1 Carbon Gen 11',
            'purchase_date'   => '2024-03-15',
            'purchase_value'  => '1850.50',
            'warranty_expiry' => '2027-03-15',
        ]);

        $response = $controller->update($assetId);
        $this->assertEquals(200, $response->getStatusCode());

        $asset = $db->table('company_assets')->where('id', $assetId)->get()->getRowArray();
        $this->assertEquals('ThinkPad X1 Carbon Gen 11', $asset['asset_name']);
        $this->assertEquals('2024-03-15', substr($asset['purchase_date'], 0, 10));
        $this->assertEquals(1850.50, (float)$asset['purchase_value']);
        $this->assertEquals('2027-03-15', substr($asset['warranty_expiry'], 0, 10));
    }

    /**
     * Test 2: Fixing a typo in purchase date recalculates write-off depreciated book value
     */
    public function testFixingPurchaseDateTypoUpdatesWriteOffDepreciatedBookValue(): void
    {
        $db = Database::connect();
        $assetId = 'ast-test-typo-01';

        // Typo: purchase_date was entered as 2010-01-01 (14 years ago, book value = 0)
        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'asset_name'       => 'MacBook Pro 16',
            'asset_code'       => 'MBP-16-01',
            'category_id'      => $this->tenantCatId,
            'category'         => 'Laptops',
            'serial_number'    => 'SN-MBP-01',
            'purchase_date'    => '2010-01-01',
            'purchase_value'   => 3000.00,
            'status'           => 'Available',
            'condition_status' => 'good',
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        // Fix typo: purchase_date was actually yesterday
        $yesterday = date('Y-m-d', strtotime('-1 day'));
        $controller = $this->setupController($this->adminUser, [
            'asset_name'    => 'MacBook Pro 16',
            'purchase_date' => $yesterday,
        ]);
        $response = $controller->update($assetId);
        $this->assertEquals(200, $response->getStatusCode());

        // Now write off asset as damaged beyond repair
        $writeOffController = $this->setupController($this->adminUser, [
            'reason' => 'damaged_beyond_repair',
            'notes'  => 'Liquid spill on motherboard',
        ]);
        $woResponse = $writeOffController->writeOff($assetId);
        $this->assertEquals(200, $woResponse->getStatusCode());

        $woData = json_decode($woResponse->getBody(), true);
        $this->assertTrue($woData['success']);
        // Since purchased yesterday, depreciated book value must be very close to full 3000.00 (not 0!)
        $this->assertGreaterThan(2900.00, (float)$woData['data']['book_value']);
    }

    /**
     * Test 3: update() rejects future purchase_date with 422
     */
    public function testUpdateRejectsFuturePurchaseDateWith422(): void
    {
        $db = Database::connect();
        $assetId = 'ast-test-future-01';

        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'asset_name'       => 'Office Projector',
            'asset_code'       => 'PROJ-01',
            'status'           => 'Available',
            'condition_status' => 'good',
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $futureDate = date('Y-m-d', strtotime('+30 days'));
        $controller = $this->setupController($this->adminUser, [
            'asset_name'    => 'Office Projector',
            'purchase_date' => $futureDate,
        ]);

        $response = $controller->update($assetId);
        $this->assertEquals(422, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success']);
        $this->assertStringContainsString('future', $body['message']);
    }

    /**
     * Test 4: update() rejects negative purchase_value with 422
     */
    public function testUpdateRejectsNegativePurchaseValueWith422(): void
    {
        $db = Database::connect();
        $assetId = 'ast-test-neg-01';

        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'asset_name'       => 'Office Desk',
            'asset_code'       => 'DESK-01',
            'purchase_value'   => 500.00,
            'status'           => 'Available',
            'condition_status' => 'good',
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->setupController($this->adminUser, [
            'asset_name'     => 'Office Desk',
            'purchase_value' => '-50.00',
        ]);

        $response = $controller->update($assetId);
        $this->assertEquals(422, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success']);
        $this->assertStringContainsString('greater than or equal to 0', $body['message']);
    }

    /**
     * Test 5: Redacted user editing asset_name does NOT wipe purchase_value
     */
    public function testRedactedUserEditingNameDoesNotErasePurchaseValue(): void
    {
        $db = Database::connect();
        $assetId = 'ast-test-redact-01';

        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'asset_name'       => 'Original Asset Name',
            'asset_code'       => 'RED-01',
            'purchase_value'   => 75000.00,
            'purchase_date'    => '2023-05-01',
            'status'           => 'Available',
            'condition_status' => 'good',
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        // Redacted user has assets.edit but lacks assets.manage and assets.export
        // They submit an update with purchase_value = '' (as would happen from redacted view)
        $controller = $this->setupController($this->redactedUser, [
            'asset_name'     => 'Renamed Asset Without Financials',
            'purchase_value' => '',
        ]);

        $response = $controller->update($assetId);
        $this->assertEquals(200, $response->getStatusCode());

        $asset = $db->table('company_assets')->where('id', $assetId)->get()->getRowArray();
        $this->assertEquals('Renamed Asset Without Financials', $asset['asset_name']);
        // Critical: purchase_value must remain intact at 75000.00 and NOT be wiped to NULL or 0!
        $this->assertEquals(75000.00, (float)$asset['purchase_value']);
    }

    /**
     * Test 6: update() on Written-Off asset is rejected with 422
     */
    public function testUpdateRejectsWrittenOffAssetsWith422(): void
    {
        $db = Database::connect();
        $assetId = 'ast-test-wo-blocked-01';

        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'asset_name'       => 'Written Off Laptop',
            'asset_code'       => 'WO-BLK-01',
            'status'           => 'Written-Off',
            'written_off_at'   => date('Y-m-d H:i:s'),
            'condition_status' => 'damaged',
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->setupController($this->adminUser, [
            'asset_name' => 'Attempted Edit on Written-Off Asset',
        ]);

        $response = $controller->update($assetId);
        $this->assertEquals(422, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success']);
        $this->assertStringContainsString('Written-Off assets cannot be edited', $body['message']);

        // Check DB was not modified
        $asset = $db->table('company_assets')->where('id', $assetId)->get()->getRowArray();
        $this->assertEquals('Written Off Laptop', $asset['asset_name']);
    }

    /**
     * Test 7: POST assets/status/(:segment) transitions Available -> Maintenance
     */
    public function testStatusTransitionAvailableToMaintenance(): void
    {
        $db = Database::connect();
        $assetId = 'ast-test-status-maint-01';

        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'asset_name'       => 'Developer Workstation',
            'asset_code'       => 'WS-01',
            'status'           => 'Available',
            'condition_status' => 'good',
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->setupController($this->adminUser, [
            'status' => 'Maintenance',
            'notes'  => 'Cooling fan failure repair',
        ]);

        $response = $controller->status($assetId);
        $this->assertEquals(200, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertTrue($body['success']);
        $this->assertEquals('Maintenance', $body['data']['status']);

        $asset = $db->table('company_assets')->where('id', $assetId)->get()->getRowArray();
        $this->assertEquals('Maintenance', $asset['status']);
        $this->assertEquals('maintenance', $asset['condition_status']);
        $this->assertStringContainsString('Cooling fan failure repair', $asset['notes']);
    }

    /**
     * Test 8: POST assets/status/(:segment) transitions Maintenance -> Available
     */
    public function testStatusTransitionMaintenanceToAvailable(): void
    {
        $db = Database::connect();
        $assetId = 'ast-test-status-avail-01';

        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'asset_name'       => 'Repaired Monitor',
            'asset_code'       => 'MON-REP-01',
            'status'           => 'Maintenance',
            'condition_status' => 'maintenance',
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->setupController($this->adminUser, [
            'status'           => 'Available',
            'condition_status' => 'good',
            'notes'            => 'Power supply replaced and tested',
        ]);

        $response = $controller->status($assetId);
        $this->assertEquals(200, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertTrue($body['success']);
        $this->assertEquals('Available', $body['data']['status']);

        $asset = $db->table('company_assets')->where('id', $assetId)->get()->getRowArray();
        $this->assertEquals('Available', $asset['status']);
        $this->assertEquals('good', $asset['condition_status']);
        $this->assertStringContainsString('Power supply replaced and tested', $asset['notes']);
    }

    /**
     * Test 9: POST assets/status rejects Assigned asset with 422
     */
    public function testStatusTransitionRejectsAssignedAssetWith422(): void
    {
        $db = Database::connect();
        $assetId = 'ast-test-status-asgn-01';

        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'asset_name'       => 'Assigned Phone',
            'asset_code'       => 'PHN-01',
            'status'           => 'Assigned',
            'assigned_to'      => $this->tenantEmpId,
            'condition_status' => 'good',
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->setupController($this->adminUser, [
            'status' => 'Maintenance',
        ]);

        $response = $controller->status($assetId);
        $this->assertEquals(422, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success']);
        $this->assertStringContainsString('returned', $body['message']);
    }

    /**
     * Test 10: POST assets/status rejects Written-Off asset with 422
     */
    public function testStatusTransitionRejectsWrittenOffAssetWith422(): void
    {
        $db = Database::connect();
        $assetId = 'ast-test-status-wo-01';

        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'asset_name'       => 'Written-Off Tablet',
            'asset_code'       => 'TAB-01',
            'status'           => 'Written-Off',
            'written_off_at'   => date('Y-m-d H:i:s'),
            'condition_status' => 'damaged',
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->setupController($this->adminUser, [
            'status' => 'Available',
        ]);

        $response = $controller->status($assetId);
        $this->assertEquals(422, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success']);
        $this->assertStringContainsString('Written-Off', $body['message']);
    }

    /**
     * Test 11: POST assets/status rejects illegal transitions (e.g. Available -> Available)
     */
    public function testStatusTransitionRejectsIllegalTransitions(): void
    {
        $db = Database::connect();
        $assetId = 'ast-test-status-same-01';

        $db->table('company_assets')->replace([
            'id'               => $assetId,
            'company_id'       => $this->tenantCompanyId,
            'asset_name'       => 'Conference Webcam',
            'asset_code'       => 'CAM-01',
            'status'           => 'Available',
            'condition_status' => 'good',
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        $controller = $this->setupController($this->adminUser, [
            'status' => 'Available',
        ]);

        $response = $controller->status($assetId);
        $this->assertEquals(422, $response->getStatusCode());
        $body = json_decode($response->getBody(), true);
        $this->assertFalse($body['success']);
        $this->assertStringContainsString('Invalid status transition', $body['message']);
    }
}
