<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

/**
 * MobileSalaryApiTest
 *
 * Verifies the authenticated employee salary and compensation endpoints for the ESS mobile app:
 * - Route resolution: GET /api/mobile/v1/salary, GET /api/v1/salary, and /payroll/salary aliases
 * - Token authentication and identity resolution via MobileAuthFilter
 * - Return salary information only to the authorized employee (no IDOR)
 * - Reuse established payroll/compensation calculation logic
 * - Scoping by employee_id and tenant company_id
 * - Strict enforcement of effective dates (effective_from <= date <= effective_to|open)
 * - Safe handling of missing salary records (404) and inactive/separated employees (403)
 * - Explicit allow-listing of returned fields
 * - Exclusion of sensitive banking, security, tax identification, and internal actor fields
 * - Standard JSON response envelope compliance
 */
#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobileSalaryApiTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;
    private array $device = ['device_uid' => 'dev-sal-test', 'platform' => 'android'];

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);

        foreach (['employee_salaries', 'salary_revisions', 'salary_structures', 'salary_structure_items', 'salary_components'] as $t) {
            $this->db->query("DROP TABLE IF EXISTS {$t}");
        }

        $this->db->query("CREATE TABLE employee_salaries (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            employee_id VARCHAR(36),
            structure_id VARCHAR(36) NULL,
            basic_salary DECIMAL(15,2) DEFAULT 0.00,
            gross_salary DECIMAL(15,2) DEFAULT 0.00,
            total_deductions DECIMAL(15,2) DEFAULT 0.00,
            net_salary DECIMAL(15,2) DEFAULT 0.00,
            ctc DECIMAL(15,2) DEFAULT 0.00,
            custom_components_json TEXT NULL,
            effective_from DATE,
            effective_to DATE NULL,
            status VARCHAR(20) DEFAULT 'Active',
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE salary_revisions (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            employee_id VARCHAR(36),
            revision_type VARCHAR(50),
            effective_date DATE,
            previous_basic DECIMAL(15,2) DEFAULT 0.00,
            new_basic DECIMAL(15,2) DEFAULT 0.00,
            previous_gross DECIMAL(15,2) DEFAULT 0.00,
            new_gross DECIMAL(15,2) DEFAULT 0.00,
            total_arrear_calculated DECIMAL(15,2) DEFAULT 0.00,
            status VARCHAR(20) DEFAULT 'Approved',
            remarks TEXT NULL,
            snapshot_json TEXT NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE salary_structures (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            branch_id VARCHAR(36) NULL,
            name VARCHAR(100),
            description TEXT NULL,
            status VARCHAR(20) DEFAULT 'Active',
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE salary_structure_items (
            id VARCHAR(36) PRIMARY KEY,
            structure_id VARCHAR(36),
            component_id VARCHAR(36),
            calculation_type VARCHAR(30) DEFAULT 'fixed',
            default_value DECIMAL(15,2) DEFAULT 0.00,
            percentage DECIMAL(5,2) NULL,
            sort_order INT DEFAULT 0
        )");

        $this->db->query("CREATE TABLE salary_components (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            branch_id VARCHAR(36) NULL,
            name VARCHAR(100),
            code VARCHAR(50),
            type VARCHAR(30) DEFAULT 'earning',
            calculation_type VARCHAR(30) DEFAULT 'fixed',
            amount DECIMAL(15,2) DEFAULT 0.00,
            is_taxable INT DEFAULT 1,
            include_in_pf_basis INT DEFAULT 1,
            is_pf_applicable INT DEFAULT 1,
            status VARCHAR(20) DEFAULT 'Active',
            is_active INT DEFAULT 1,
            display_order INT DEFAULT 0
        )");

        // Set departments, designations, branches for Rahim (e-1)
        $this->db->table('departments')->insert(['id' => 'dept-1', 'name' => 'Engineering']);
        $this->db->table('designations')->insert(['id' => 'desig-1', 'name' => 'Software Engineer']);
        $this->db->table('branches')->insert(['id' => 'br-1', 'name' => 'Dhaka HQ']);

        $this->db->table('employees')->where('id', 'e-1')->update([
            'department_id'  => 'dept-1',
            'designation_id' => 'desig-1',
            'branch_id'      => 'br-1',
            'email'          => 'rahim@acme.test',
            'phone'          => '+8801700000001',
            'joining_date'   => '2023-01-15',
            'status'         => 'Active',
            'salary_status'  => 'CONFIGURED',
        ]);

        $this->db->table('employees')->where('id', 'e-2')->update([
            'status'         => 'Active',
            'salary_status'  => 'CONFIGURED',
        ]);

        // Seed salary records for Rahim (e-1) in Acme Ltd (c-1)
        // 1. Initial salary: 2026-01-01 to 2026-06-30 (Basic: 40k, Gross: 65k, Net: 62k)
        $oldSnapshot = [
            'basic_salary'     => 40000.00,
            'gross_salary'     => 65000.00,
            'total_deductions' => 3000.00,
            'net_salary'       => 62000.00,
            'ctc'              => 68000.00,
            'earnings'         => [
                ['code' => 'BASIC', 'name' => 'Basic Salary', 'type' => 'earning', 'amount' => 40000.00],
                ['code' => 'HRA', 'name' => 'House Rent Allowance (HRA)', 'type' => 'earning', 'amount' => 16000.00],
                ['code' => 'MED', 'name' => 'Medical Allowance', 'type' => 'earning', 'amount' => 5000.00],
                ['code' => 'CONV', 'name' => 'Conveyance Allowance', 'type' => 'earning', 'amount' => 4000.00],
            ],
            'deductions'       => [
                ['code' => 'PF', 'name' => 'Provident Fund', 'type' => 'deduction', 'amount' => 3000.00],
            ],
            'employer_contributions' => [
                ['code' => 'ER_PF', 'name' => 'Employer PF Match', 'type' => 'employer_contribution', 'amount' => 3000.00],
            ],
        ];

        $this->db->table('employee_salaries')->insert([
            'id'                     => 'sal-rahim-old',
            'company_id'             => 'c-1',
            'employee_id'            => 'e-1',
            'structure_id'           => 'CUSTOM',
            'basic_salary'           => 40000.00,
            'gross_salary'           => 65000.00,
            'total_deductions'       => 3000.00,
            'net_salary'             => 62000.00,
            'ctc'                    => 68000.00,
            'custom_components_json' => json_encode($oldSnapshot),
            'effective_from'         => '2026-01-01',
            'effective_to'           => '2026-06-30',
            'status'                 => 'Revised',
            'created_at'             => '2026-01-01 08:00:00',
            'updated_at'             => '2026-06-30 23:59:59',
        ]);

        // 2. Revised active salary: 2026-07-01 to open (Basic: 50k, Gross: 80k, Net: 75k)
        $currentSnapshot = [
            'structure_name'   => 'Executive Tech Grade 1',
            'basic_salary'     => 50000.00,
            'gross_salary'     => 80000.00,
            'total_deductions' => 5000.00,
            'net_salary'       => 75000.00,
            'ctc'              => 85000.00,
            'earnings'         => [
                ['code' => 'BASIC', 'name' => 'Basic Salary', 'type' => 'earning', 'amount' => 50000.00],
                ['code' => 'HRA', 'name' => 'House Rent Allowance (HRA)', 'type' => 'earning', 'amount' => 20000.00],
                ['code' => 'MED', 'name' => 'Medical Allowance', 'type' => 'earning', 'amount' => 6000.00],
                ['code' => 'CONV', 'name' => 'Conveyance Allowance', 'type' => 'earning', 'amount' => 4000.00],
            ],
            'deductions'       => [
                ['code' => 'PF', 'name' => 'Provident Fund', 'type' => 'deduction', 'amount' => 5000.00],
            ],
            'employer_contributions' => [
                ['code' => 'ER_PF', 'name' => 'Employer PF Match', 'type' => 'employer_contribution', 'amount' => 5000.00],
            ],
        ];

        $this->db->table('employee_salaries')->insert([
            'id'                     => 'sal-rahim-current',
            'company_id'             => 'c-1',
            'employee_id'            => 'e-1',
            'structure_id'           => 'CUSTOM',
            'basic_salary'           => 50000.00,
            'gross_salary'           => 80000.00,
            'total_deductions'       => 5000.00,
            'net_salary'             => 75000.00,
            'ctc'                    => 85000.00,
            'custom_components_json' => json_encode($currentSnapshot),
            'effective_from'         => '2026-07-01',
            'effective_to'           => null,
            'status'                 => 'Active',
            'created_at'             => '2026-07-01 09:00:00',
            'updated_at'             => '2026-07-01 09:00:00',
        ]);

        // Seed salary revision history
        $this->db->table('salary_revisions')->insert([
            'id'                      => 'rev-1',
            'company_id'              => 'c-1',
            'employee_id'             => 'e-1',
            'revision_type'           => 'Annual Increment',
            'effective_date'          => '2026-07-01',
            'previous_basic'          => 40000.00,
            'new_basic'               => 50000.00,
            'previous_gross'          => 65000.00,
            'new_gross'               => 80000.00,
            'total_arrear_calculated' => 0.00,
            'status'                  => 'Approved',
            'remarks'                 => 'Merit performance increment',
            'created_at'              => '2026-07-01 09:30:00',
            'updated_at'              => '2026-07-01 09:30:00',
        ]);

        // Seed separate company salary for Karim (e-2) in Other Ltd (c-2)
        $karimSnapshot = [
            'basic_salary'     => 90000.00,
            'gross_salary'     => 120000.00,
            'total_deductions' => 10000.00,
            'net_salary'       => 110000.00,
            'ctc'              => 125000.00,
            'earnings'         => [
                ['code' => 'BASIC', 'name' => 'Basic Salary', 'type' => 'earning', 'amount' => 90000.00],
                ['code' => 'HRA', 'name' => 'House Rent Allowance', 'type' => 'earning', 'amount' => 30000.00],
            ],
            'deductions'       => [
                ['code' => 'PF', 'name' => 'Provident Fund', 'type' => 'deduction', 'amount' => 10000.00],
            ],
        ];

        $this->db->table('employee_salaries')->insert([
            'id'                     => 'sal-karim-other',
            'company_id'             => 'c-2',
            'employee_id'            => 'e-2',
            'structure_id'           => 'CUSTOM',
            'basic_salary'           => 90000.00,
            'gross_salary'           => 120000.00,
            'total_deductions'       => 10000.00,
            'net_salary'             => 110000.00,
            'ctc'                    => 125000.00,
            'custom_components_json' => json_encode($karimSnapshot),
            'effective_from'         => '2026-01-01',
            'effective_to'           => null,
            'status'                 => 'Active',
            'created_at'             => '2026-01-01 08:00:00',
            'updated_at'             => '2026-01-01 08:00:00',
        ]);
    }

    private function login(string $company = 'ACME', string $identifier = 'rahim'): string
    {
        $res = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => $company,
            'identifier'   => $identifier,
            'password'     => self::PASSWORD,
            'device'       => $this->device,
        ]);
        $res->assertStatus(200);
        $json = json_decode($res->getJSON(), true);
        return $json['data']['tokens']['access_token'];
    }

    /**
     * Requirement 1 & 2: Unauthenticated requests are rejected with 401 across all salary endpoints.
     */
    public function testSalaryRejectsUnauthenticatedRequests(): void
    {
        $endpoints = [
            'api/mobile/v1/salary',
            'api/mobile/v1/payroll/salary',
            'api/v1/salary',
            'api/v1/payroll/salary',
        ];

        foreach ($endpoints as $endpoint) {
            // Missing Authorization header
            $res = $this->get($endpoint);
            $res->assertStatus(401);
            $json = json_decode($res->getJSON(), true);
            $this->assertFalse($json['success']);

            // Forged/invalid token
            $resBad = $this->withHeaders(['Authorization' => 'Bearer forged_token_abc123'])->get($endpoint);
            $resBad->assertStatus(401);
            $jsonBad = json_decode($resBad->getJSON(), true);
            $this->assertFalse($jsonBad['success']);
        }
    }

    /**
     * Requirement 2, 3, 6, 9: Authorized employee receives own salary with standard envelope and allow-listed fields.
     */
    public function testAuthorizedEmployeeReceivesOwnSalaryData(): void
    {
        $token = $this->login('ACME', 'rahim');

        foreach (['api/mobile/v1/salary', 'api/v1/salary', 'api/mobile/v1/payroll/salary', 'api/v1/payroll/salary'] as $endpoint) {
            $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])->get($endpoint);
            $res->assertStatus(200);

            $payload = json_decode($res->getJSON(), true);
            $this->assertTrue($payload['success']);
            $this->assertSame('success', $payload['status']);
            $this->assertSame('Employee salary details retrieved successfully.', $payload['message']);

            $data = $payload['data'];
            $this->assertIsArray($data);

            // Allow-listed top-level figures
            $this->assertEquals(50000.00, $data['basic_salary']);
            $this->assertEquals(80000.00, $data['gross_salary']);
            $this->assertEquals(5000.00, $data['total_deductions']);
            $this->assertEquals(75000.00, $data['net_salary']);
            $this->assertEquals(85000.00, $data['ctc']);
            $this->assertSame('Active', $data['status']);
            $this->assertSame('2026-07-01', $data['effective_from']);
            $this->assertNull($data['effective_to']);

            // Nested salary structure object
            $salary = $data['salary'];
            $this->assertSame('sal-rahim-current', $salary['id']);
            $this->assertSame('Executive Tech Grade 1', $salary['structure_name']);
            $this->assertEquals(50000.00, $salary['basic_salary']);
            $this->assertEquals(80000.00, $salary['gross_salary']);
            $this->assertEquals(75000.00, $salary['net_salary']);

            // Allowance breakdown summary
            $summary = $salary['summary'];
            $this->assertEquals(50000.00, $summary['basic_salary']);
            $this->assertEquals(20000.00, $summary['house_rent']);
            $this->assertEquals(6000.00, $summary['medical']);
            $this->assertEquals(4000.00, $summary['conveyance']);

            // Employee identity
            $emp = $data['employee'];
            $this->assertSame('e-1', $emp['id']);
            $this->assertSame('EMP-001', $emp['employee_code']);
            $this->assertSame('Rahim Uddin', $emp['name']);
            $this->assertSame('Engineering', $emp['department']);
            $this->assertSame('Software Engineer', $emp['designation']);
            $this->assertSame('Dhaka HQ', $emp['branch']);

            // Earnings breakdown
            $this->assertIsArray($data['earnings']);
            $codes = array_column($data['earnings'], 'code');
            $this->assertContains('BASIC', $codes);
            $this->assertContains('HRA', $codes);
            $this->assertContains('MED', $codes);
            $this->assertContains('CONV', $codes);

            // Deductions breakdown
            $this->assertIsArray($data['deductions']);
            $dedCodes = array_column($data['deductions'], 'code');
            $this->assertContains('PF', $dedCodes);
        }
    }

    /**
     * Requirement 4 & 7: Cross-tenant isolation and IDOR prevention.
     */
    public function testCrossTenantIsolationAndIdorPrevention(): void
    {
        $rahimToken = $this->login('ACME', 'rahim');
        $karimToken = $this->login('OTHER', 'karim');

        // Rahim attempting IDOR by querying Karim's employee_id or company_id
        $idor1 = $this->withHeaders(['Authorization' => "Bearer {$rahimToken}"])
            ->get('api/v1/salary?employee_id=e-2');
        $idor1->assertStatus(403);
        $jsonIdor1 = json_decode($idor1->getJSON(), true);
        $this->assertFalse($jsonIdor1['success']);

        $idor2 = $this->withHeaders(['Authorization' => "Bearer {$rahimToken}"])
            ->get('api/v1/salary?company_id=c-2');
        $idor2->assertStatus(403);

        // Rahim's response must NEVER contain Karim's salary values (120,000 gross, 110,000 net)
        $rahimRes = $this->withHeaders(['Authorization' => "Bearer {$rahimToken}"])
            ->get('api/v1/salary');
        $this->assertStringNotContainsString('120000', $rahimRes->getJSON());
        $this->assertStringNotContainsString('110000', $rahimRes->getJSON());
        $this->assertStringNotContainsString('sal-karim-other', $rahimRes->getJSON());

        // Karim's response must contain Karim's salary in Other Ltd
        $karimRes = $this->withHeaders(['Authorization' => "Bearer {$karimToken}"])
            ->get('api/v1/salary');
        $karimRes->assertStatus(200);
        $karimData = json_decode($karimRes->getJSON(), true)['data'];
        $this->assertEquals(90000.00, $karimData['basic_salary']);
        $this->assertEquals(120000.00, $karimData['gross_salary']);
        $this->assertEquals(110000.00, $karimData['net_salary']);
    }

    /**
     * Requirement 5: Respect effective dates and point-in-time salary versions.
     */
    public function testEffectiveDatesRespectSalaryRevisions(): void
    {
        $token = $this->login('ACME', 'rahim');

        // Query point-in-time: 2026-05-15 (falls in initial salary: Basic 40k, Gross 65k, Net 62k)
        $pastRes = $this->withHeaders(['Authorization' => "Bearer {$token}"])
            ->get('api/v1/salary?as_of_date=2026-05-15');
        $pastRes->assertStatus(200);
        $pastData = json_decode($pastRes->getJSON(), true)['data'];
        $this->assertEquals(40000.00, $pastData['basic_salary']);
        $this->assertEquals(65000.00, $pastData['gross_salary']);
        $this->assertEquals(62000.00, $pastData['net_salary']);
        $this->assertSame('2026-01-01', $pastData['effective_from']);
        $this->assertSame('2026-06-30', $pastData['effective_to']);

        // Query point-in-time: 2026-08-01 (falls in revised salary: Basic 50k, Gross 80k, Net 75k)
        $currentRes = $this->withHeaders(['Authorization' => "Bearer {$token}"])
            ->get('api/v1/salary?as_of_date=2026-08-01');
        $currentRes->assertStatus(200);
        $currentData = json_decode($currentRes->getJSON(), true)['data'];
        $this->assertEquals(50000.00, $currentData['basic_salary']);
        $this->assertEquals(80000.00, $currentData['gross_salary']);
        $this->assertEquals(75000.00, $currentData['net_salary']);
        $this->assertSame('2026-07-01', $currentData['effective_from']);
        $this->assertNull($currentData['effective_to']);

        // Query date prior to joining / effective date (2025-10-01) -> 404
        $preRes = $this->withHeaders(['Authorization' => "Bearer {$token}"])
            ->get('api/v1/salary?as_of_date=2025-10-01');
        $preRes->assertStatus(404);
        $preJson = json_decode($preRes->getJSON(), true);
        $this->assertFalse($preJson['success']);
    }

    /**
     * Requirement 5: Future salary revisions are not visible prior to their effective date.
     */
    public function testFutureSalaryNotActiveYet(): void
    {
        // Add future revision effective 2027-01-01
        $this->db->table('employee_salaries')->insert([
            'id'                     => 'sal-rahim-future',
            'company_id'             => 'c-1',
            'employee_id'            => 'e-1',
            'structure_id'           => 'CUSTOM',
            'basic_salary'           => 60000.00,
            'gross_salary'           => 95000.00,
            'total_deductions'       => 6000.00,
            'net_salary'             => 89000.00,
            'ctc'                    => 101000.00,
            'custom_components_json' => json_encode(['basic_salary' => 60000.00, 'gross_salary' => 95000.00]),
            'effective_from'         => '2027-01-01',
            'effective_to'           => null,
            'status'                 => 'Active',
            'created_at'             => '2026-10-01 10:00:00',
        ]);

        $token = $this->login('ACME', 'rahim');

        // Query today's date (2026-10-30) -> must return current 50k/80k salary, NOT future 60k/95k
        $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])
            ->get('api/v1/salary?as_of_date=2026-10-30');
        $res->assertStatus(200);
        $data = json_decode($res->getJSON(), true)['data'];
        $this->assertEquals(50000.00, $data['basic_salary']);
        $this->assertEquals(80000.00, $data['gross_salary']);
        $this->assertSame('sal-rahim-current', $data['salary']['id']);
    }

    /**
     * Requirement 5 & 10: Missing salary configuration returns 404.
     */
    public function testMissingSalaryRecordReturns404(): void
    {
        // Insert new employee in Acme with unconfigured salary
        $this->db->table('employees')->insert([
            'id'            => 'e-unconfigured',
            'company_id'    => 'c-1',
            'employee_code' => 'EMP-999',
            'first_name'    => 'Nabila',
            'last_name'     => 'Hasan',
            'status'        => 'Active',
            'salary_status' => 'NOT_CONFIGURED',
            'basic_salary'  => 0.00,
            'gross_salary'  => 0.00,
        ]);
        $this->addUser('u-unconfigured', 'nabila', 'nabila@acme.test', 'c-1', 'e-unconfigured', 'r-emp');

        $token = $this->login('ACME', 'nabila');
        $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])->get('api/v1/salary');
        $res->assertStatus(404);

        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success']);
        $this->assertSame('Salary record not found for this employee.', $json['message']);
    }

    /**
     * Requirement 2 & 7: Separated or inactive employee is blocked with 403.
     */
    public function testSeparatedOrInactiveEmployeeBlockedWith403(): void
    {
        // Insert terminated employee
        $this->db->table('employees')->insert([
            'id'            => 'e-terminated',
            'company_id'    => 'c-1',
            'employee_code' => 'EMP-EX',
            'first_name'    => 'Separated',
            'last_name'     => 'Staff',
            'status'        => 'Terminated',
            'salary_status' => 'CONFIGURED',
        ]);
        $this->addUser('u-terminated', 'separated', 'separated@acme.test', 'c-1', 'e-terminated', 'r-emp');

        $token = $this->login('ACME', 'separated');
        $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])->get('api/v1/salary');
        $res->assertStatus(403);

        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success']);
        $this->assertSame('Employee profile is inactive or separated.', $json['message']);
    }

    /**
     * Requirement 6 & 7: Sensitive database columns and banking details are never exposed.
     */
    public function testSensitiveDataIsNeverExposed(): void
    {
        $token = $this->login('ACME', 'rahim');
        $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])->get('api/v1/salary');
        $res->assertStatus(200);

        $rawJson = $res->getJSON();

        // Bank credentials / account numbers
        $this->assertStringNotContainsString('bank_account_no', $rawJson);
        $this->assertStringNotContainsString('account_number', $rawJson);
        $this->assertStringNotContainsString('routing_number', $rawJson);
        $this->assertStringNotContainsString('iban', $rawJson);

        // Security / auth internals
        $this->assertStringNotContainsString('password', $rawJson);
        $this->assertStringNotContainsString('password_hash', $rawJson);
        $this->assertStringNotContainsString('token_hash', $rawJson);
        $this->assertStringNotContainsString('device_uid', $rawJson);

        // Raw internal JSON dump fields
        $this->assertStringNotContainsString('custom_components_json', $rawJson);
        $this->assertStringNotContainsString('tax_settings_json', $rawJson);
    }

    /**
     * Requirement 10: Salary revision history returns approved revisions for authorized employee.
     */
    public function testSalaryRevisionHistoryEndpoint(): void
    {
        $token = $this->login('ACME', 'rahim');

        foreach (['api/mobile/v1/salary/history', 'api/v1/salary/history', 'api/mobile/v1/payroll/salary/history', 'api/v1/payroll/salary/history'] as $endpoint) {
            $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])->get($endpoint);
            $res->assertStatus(200);

            $payload = json_decode($res->getJSON(), true);
            $this->assertTrue($payload['success']);
            $this->assertSame('success', $payload['status']);

            $data = $payload['data'];
            $this->assertSame(1, $data['count']);
            $this->assertCount(1, $data['revisions']);

            $rev = $data['revisions'][0];
            $this->assertSame('rev-1', $rev['id']);
            $this->assertSame('Annual Increment', $rev['revision_type']);
            $this->assertSame('2026-07-01', $rev['effective_date']);
            $this->assertEquals(40000.00, $rev['previous_basic']);
            $this->assertEquals(50000.00, $rev['new_basic']);
            $this->assertEquals(65000.00, $rev['previous_gross']);
            $this->assertEquals(80000.00, $rev['new_gross']);
            $this->assertSame('Approved', $rev['status']);
        }
    }

    /**
     * Requirement 5: Invalid date format returns 422.
     */
    public function testInvalidDateFormatReturns422(): void
    {
        $token = $this->login('ACME', 'rahim');
        $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])
            ->get('api/v1/salary?as_of_date=invalid-date-string');
        $res->assertStatus(422);

        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success']);
        $this->assertSame('Invalid date format. Expected YYYY-MM-DD.', $json['message']);
    }
}
