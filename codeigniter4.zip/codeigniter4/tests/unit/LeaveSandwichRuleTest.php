<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\LeaveService;
use App\Services\Leave\LeaveApplicationService;

class LeaveSandwichRuleTest extends TestCase
{
    /**
     * Requirement 1:
     * isSandwichEnabled returns true if the company-level sandwich.enabled is on.
     * The per-type sandwich_rule: false (as in the Annual leave seed) cannot switch it off.
     * FIX: Per-type sandwich_rule: false MUST switch it off.
     */
    public function testPerTypeSandwichRuleFalseSwitchesOffSandwichEvenWhenCompanyEnabled()
    {
        $leaveService = new LeaveService();
        $employee = ['id' => 'emp-01', 'company_id' => 'comp-01'];

        // Annual leave seed: sandwich_rule = false, is_paid = true
        $ruleEntAnnual = [
            'leave_type_code' => 'AL',
            'sandwich_rule'   => false,
            'is_paid'         => true,
        ];

        // Even with company sandwich enabled, AL must NOT have sandwich active
        $result = $leaveService->isSandwichEnabled('comp-01', $employee, $ruleEntAnnual, '2026-10-01', true);
        $this->assertFalse($result, "Per-type sandwich_rule: false must switch sandwich OFF even when company sandwich is enabled.");

        $appService = new LeaveApplicationService($leaveService);
        $appResult = $appService->isSandwichEnabled('comp-01', $employee, $ruleEntAnnual, '2026-10-01', true);
        $this->assertFalse($appResult, "LeaveApplicationService::isSandwichEnabled must also return false when per-type sandwich_rule is false.");
    }

    /**
     * Requirement 1 continued:
     * When per-type is true, but company sandwich is disabled, sandwich must be OFF.
     */
    public function testCompanySandwichDisabledSwitchesOffSandwichEvenWhenPerTypeTrue()
    {
        $leaveService = new LeaveService();
        $employee = ['id' => 'emp-01', 'company_id' => 'comp-disabled'];

        $ruleEntSick = [
            'leave_type_code' => 'SL',
            'sandwich_rule'   => true,
            'is_paid'         => true,
        ];

        // Fallback or disabled company rule: if company disabled sandwich, must return false
        // Let's test with a mock company rule where enabled is false:
        $policy = [
            'calendarTreatment' => [
                'enabled'              => false,
                'weekend_treatment'    => 'Exclude weekly off',
                'holiday_treatment'    => 'Exclude holidays',
                'bridge_leave_enabled' => false,
                'bridge_leave_action'  => 'Exclude intervening days',
                'applies_to_paid_only' => true
            ]
        ];

        $check = $leaveService->checkSandwichRule('2026-10-08', '2026-10-11', 'comp-disabled', 'emp-01', $policy, [], true);
        $this->assertFalse($check['applies'], "Sandwich rule must not apply when company sandwich is disabled.");
        $this->assertEquals(0, $check['sandwich_days']);
    }

    /**
     * Requirement 4:
     * applies_to_paid_only: If applies_to_paid_only is true, unpaid leave types must NOT trigger sandwich.
     */
    public function testAppliesToPaidOnlyEnforcesSandwichDisabledForUnpaidLeave()
    {
        $leaveService = new LeaveService();
        $employee = ['id' => 'emp-01', 'company_id' => 'comp-01'];

        // Unpaid leave entitlement with sandwich_rule true
        $ruleEntUnpaid = [
            'leave_type_code' => 'UL',
            'sandwich_rule'   => true,
            'is_paid'         => false,
        ];

        // When is_paid = false, sandwich must be disabled
        $result = $leaveService->isSandwichEnabled('comp-01', $employee, $ruleEntUnpaid, '2026-10-01', false);
        $this->assertFalse($result, "Unpaid leave type must not have sandwich enabled when applies_to_paid_only is true.");
    }

    /**
     * Requirement 4:
     * weekend_treatment: 'Exclude weekly off' vs 'Include if sandwiched'.
     * When 'Exclude weekly off', intervening weekends must NOT be deducted.
     */
    public function testWeekendTreatmentExcludeWeeklyOffDoesNotDeductInterveningWeekends()
    {
        $leaveService = new LeaveService();
        $employeeId = 'emp-01';

        // Thursday (2026-10-08) to Sunday (2026-10-11)
        // Friday & Saturday are weekends (2 weekend days, 2 working days)
        $fromDate = '2026-10-08';
        $toDate = '2026-10-11';

        $policyExclude = [
            'calendarTreatment' => [
                'enabled'                => true,
                'weekend_treatment'      => 'Exclude weekly off',
                'holiday_treatment'      => 'Exclude holidays',
                'treat_weekend_as_leave' => false,
                'treat_holiday_as_leave' => false,
                'bridge_leave_enabled'   => true,
                'bridge_leave_action'    => 'Count intervening days',
                'applies_to_paid_only'   => true
            ]
        ];

        $calc = $leaveService->calculateLeaveDays($employeeId, $fromDate, $toDate, false, true, $policyExclude, true);

        // Working days: Thursday, Sunday = 2.0
        // Intervening weekends (Fri, Sat) must be EXCLUDED because weekend_treatment is 'Exclude weekly off'
        $this->assertEquals(2.0, $calc['chargeable_days'], "Intervening weekends must be excluded when weekend_treatment is 'Exclude weekly off'.");
        $this->assertEquals(0, $calc['bridge_days_added']);
        $this->assertFalse($calc['sandwich_applies']);
    }

    /**
     * Requirement 4:
     * When 'Include if sandwiched', intervening weekends ARE deducted (+2 days).
     */
    public function testWeekendTreatmentIncludeIfSandwichedDeductsInterveningWeekends()
    {
        $leaveService = new LeaveService();
        $employeeId = 'emp-01';

        // Thursday (2026-10-08) to Sunday (2026-10-11)
        $fromDate = '2026-10-08';
        $toDate = '2026-10-11';

        $policyInclude = [
            'calendarTreatment' => [
                'enabled'                => true,
                'weekend_treatment'      => 'Include if sandwiched',
                'holiday_treatment'      => 'Exclude holidays',
                'treat_weekend_as_leave' => true,
                'treat_holiday_as_leave' => false,
                'bridge_leave_enabled'   => true,
                'bridge_leave_action'    => 'Count intervening days',
                'applies_to_paid_only'   => true
            ]
        ];

        $calc = $leaveService->calculateLeaveDays($employeeId, $fromDate, $toDate, false, true, $policyInclude, true);

        // Working days (2) + intervening weekends (2) = 4.0 days
        $this->assertEquals(4.0, $calc['chargeable_days'], "Intervening weekends must be deducted when weekend_treatment is 'Include if sandwiched'.");
        $this->assertEquals(2, $calc['bridge_days_added']);
        $this->assertTrue($calc['sandwich_applies']);
    }

    /**
     * Requirement 4:
     * holiday_treatment: 'Exclude holidays' vs 'Include if sandwiched'.
     */
    public function testHolidayTreatmentIncludeIfSandwichedDeductsInterveningHolidays()
    {
        $leaveService = new LeaveService();

        // Check sandwich rule with mock holiday on intervening day
        $policyWithHolidayInclude = [
            'calendarTreatment' => [
                'enabled'                => true,
                'weekend_treatment'      => 'Exclude weekly off',
                'holiday_treatment'      => 'Include if sandwiched',
                'treat_weekend_as_leave' => false,
                'treat_holiday_as_leave' => true,
                'bridge_leave_enabled'   => true,
                'bridge_leave_action'    => 'Count intervening days',
                'applies_to_paid_only'   => true
            ]
        ];

        // Wednesday (2026-10-07) to Friday (2026-10-09)
        // Suppose Thursday (2026-10-08) is a public holiday
        $holidays = ['2026-10-08' => 'National Holiday'];

        $check = $leaveService->checkSandwichRule('2026-10-07', '2026-10-09', 'comp-01', 'emp-01', $policyWithHolidayInclude, $holidays, true);

        $this->assertTrue($check['applies'], "Sandwich must apply for intervening holiday when holiday_treatment is 'Include if sandwiched'.");
        $this->assertEquals(1, $check['sandwich_days']);
        $this->assertEquals(1, $check['sandwich_holiday_days']);
        $this->assertEquals(0, $check['sandwich_weekend_days']);
    }

    /**
     * Requirement 4:
     * bridge_leave_action: 'Exclude intervening days' overrides and does not add bridge days.
     */
    public function testBridgeLeaveActionExcludeInterveningDaysOverrides()
    {
        $leaveService = new LeaveService();
        $employeeId = 'emp-01';

        $fromDate = '2026-10-08';
        $toDate = '2026-10-11';

        $policyExcludeAction = [
            'calendarTreatment' => [
                'enabled'                => true,
                'weekend_treatment'      => 'Include if sandwiched',
                'holiday_treatment'      => 'Include if sandwiched',
                'treat_weekend_as_leave' => true,
                'treat_holiday_as_leave' => true,
                'bridge_leave_enabled'   => true,
                'bridge_leave_action'    => 'Exclude intervening days',
                'applies_to_paid_only'   => true
            ]
        ];

        $calc = $leaveService->calculateLeaveDays($employeeId, $fromDate, $toDate, false, true, $policyExcludeAction, true);

        $this->assertEquals(2.0, $calc['chargeable_days'], "bridge_leave_action 'Exclude intervening days' must not add any bridge days.");
        $this->assertEquals(0, $calc['bridge_days_added']);
        $this->assertFalse($calc['sandwich_applies']);
    }

    /**
     * Requirement 3:
     * calculateLeaveDays resolves the policy as of the leave start date ($fromDate), not today.
     */
    public function testCalculateLeaveDaysResolvesPolicyAsOfFromDate()
    {
        $leaveService = new LeaveService();
        $refMethod = new \ReflectionMethod(LeaveService::class, 'resolvePolicyForEmployee');

        $this->assertGreaterThanOrEqual(
            3,
            $refMethod->getNumberOfParameters(),
            "resolvePolicyForEmployee must accept \$asOfDate as the 3rd parameter to support backdated and future leave rules."
        );
    }

    /**
     * Requirement: Seeded defaults must actively deduct intervening weekends when sandwiched.
     */
    public function testSeededDefaultsDeductInterveningWeekendsWhenSandwiched()
    {
        $leaveService = new LeaveService();
        $employeeId = 'emp-01';

        // Thursday (2026-10-08) to Sunday (2026-10-11)
        // With seeded defaults: enabled=true, weekend_treatment='Include if sandwiched',
        // holiday_treatment='Include if sandwiched', bridge_leave_action='Count intervening days'
        $policySeededDefaults = [
            'calendarTreatment' => [
                'enabled'                => true,
                'weekend_treatment'      => 'Include if sandwiched',
                'holiday_treatment'      => 'Include if sandwiched',
                'treat_weekend_as_leave' => false,
                'treat_holiday_as_leave' => false,
                'bridge_leave_enabled'   => true,
                'bridge_leave_action'    => 'Count intervening days',
                'applies_to_paid_only'   => true
            ]
        ];

        $calc = $leaveService->calculateLeaveDays($employeeId, '2026-10-08', '2026-10-11', false, true, $policySeededDefaults, true);

        // 2 working days (Thu, Sun) + 2 intervening weekend days (Fri, Sat) = 4 chargeable days
        $this->assertEquals(4.0, $calc['chargeable_days'], "Seeded defaults must deduct intervening weekends when sandwiched.");
        $this->assertEquals(2, $calc['bridge_days_added']);
        $this->assertTrue($calc['sandwich_applies']);
    }

    /**
     * Requirement: Treatment comparisons must be case-insensitive and handle whitespace.
     */
    public function testCaseInsensitiveWeekendAndHolidayTreatmentMatching()
    {
        $leaveService = new LeaveService();
        $employeeId = 'emp-01';

        // Lowercase and irregular casing: "include if sandwiched"
        $policyLowercase = [
            'calendarTreatment' => [
                'enabled'                => true,
                'weekend_treatment'      => 'include if sandwiched',
                'holiday_treatment'      => 'Include If Sandwiched',
                'treat_weekend_as_leave' => false,
                'treat_holiday_as_leave' => false,
                'bridge_leave_enabled'   => true,
                'bridge_leave_action'    => 'count intervening days',
                'applies_to_paid_only'   => true
            ]
        ];

        $calc = $leaveService->calculateLeaveDays($employeeId, '2026-10-08', '2026-10-11', false, true, $policyLowercase, true);

        $this->assertEquals(4.0, $calc['chargeable_days'], "Case-insensitive treatment strings must match successfully.");
        $this->assertEquals(2, $calc['bridge_days_added']);
        $this->assertTrue($calc['sandwich_applies']);

        // Check checkSandwichRule method with mixed-casing
        $check = $leaveService->checkSandwichRule('2026-10-08', '2026-10-11', 'comp-01', $employeeId, $policyLowercase, [], true);
        $this->assertTrue($check['applies']);
        $this->assertEquals(2, $check['sandwich_days']);
    }
}

