<?php

namespace Tests\Unit;

use App\Services\Mobile\MobileAuthService;
use App\Services\Mobile\MobileDashboardService;
use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobileDashboardApiTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;
    private array $device = ['device_uid' => 'dev-mobile-dash', 'platform' => 'android'];

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);

        // Additional operational tables for comprehensive dashboard tests
        foreach ([
            'attendance_logs', 'leave_types', 'leave_balances', 'leave_applications',
            'payrolls', 'payroll_items', 'notifications', 'notices'
        ] as $t) {
            $this->db->query("DROP TABLE IF EXISTS {$t}");
        }

        $this->db->query("CREATE TABLE attendance_logs (
            id VARCHAR(36) PRIMARY KEY, employee_id VARCHAR(36), company_id VARCHAR(36),
            date DATE, clock_in DATETIME NULL, clock_out DATETIME NULL,
            in_time TIME NULL, out_time TIME NULL, late_minutes INT DEFAULT 0,
            working_hours DECIMAL(5,2) DEFAULT 0.00, status VARCHAR(30) DEFAULT 'Present',
            created_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE leave_types (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36) NULL,
            name VARCHAR(100), code VARCHAR(20), is_paid INT DEFAULT 1, status VARCHAR(20) DEFAULT 'active'
        )");

        $this->db->query("CREATE TABLE leave_balances (
            id VARCHAR(36) PRIMARY KEY, employee_id VARCHAR(36), leave_type_id VARCHAR(36),
            year INT, allocated_days DECIMAL(5,2) DEFAULT 0, used_days DECIMAL(5,2) DEFAULT 0,
            pending_days DECIMAL(5,2) DEFAULT 0, balance DECIMAL(5,2) DEFAULT 0
        )");

        $this->db->query("CREATE TABLE leave_applications (
            id VARCHAR(36) PRIMARY KEY, employee_id VARCHAR(36), company_id VARCHAR(36) NULL,
            leave_type_id VARCHAR(36), from_date DATE, to_date DATE, total_days DECIMAL(5,2),
            reason TEXT, status VARCHAR(20) DEFAULT 'pending', created_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE payrolls (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36), payroll_month VARCHAR(10),
            status VARCHAR(20), is_locked INT DEFAULT 0
        )");

        $this->db->query("CREATE TABLE payroll_items (
            id VARCHAR(36) PRIMARY KEY, payroll_id VARCHAR(36), employee_id VARCHAR(36),
            company_id VARCHAR(36) NULL, basic_salary DECIMAL(12,2), gross_salary DECIMAL(12,2),
            total_deductions DECIMAL(12,2), net_salary DECIMAL(12,2), payment_status VARCHAR(20) NULL,
            bank_account_no VARCHAR(50) NULL, components_breakdown_json TEXT NULL
        )");

        $this->db->query("CREATE TABLE notifications (
            id VARCHAR(36) PRIMARY KEY, user_id VARCHAR(36), company_id VARCHAR(36) NULL,
            title VARCHAR(150), message TEXT, type VARCHAR(30) NULL, priority VARCHAR(20) NULL,
            related_module VARCHAR(50) NULL, icon VARCHAR(50) NULL, link VARCHAR(255) NULL,
            is_read INT DEFAULT 0, read_at DATETIME NULL, created_at DATETIME NULL
        )");

        $this->db->query("CREATE TABLE notices (
            id VARCHAR(36) PRIMARY KEY, company_id VARCHAR(36), title VARCHAR(150),
            content TEXT NULL, description TEXT NULL, type VARCHAR(50) NULL, category VARCHAR(50) NULL,
            status VARCHAR(20) DEFAULT 'published', published_date DATE NULL, expiry_date DATE NULL,
            created_at DATETIME NULL
        )");
    }

    private function login(string $company = 'ACME', string $identifier = 'rahim'): string
    {
        $res = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => $company,
            'identifier'   => $identifier,
            'password'     => self::PASSWORD,
            'device'       => $this->device,
        ]);
        $res->assertStatus(200);
        $json = json_decode($res->getJSON(), true);
        return $json['data']['tokens']['access_token'];
    }

    /**
     * Test 1: Unauthenticated requests to /api/v1/dashboard and alias /api/mobile/v1/dashboard return 401
     */
    public function testUnauthenticatedRequestsReturn401(): void
    {
        // Missing Authorization header
        $res = $this->call('get', 'api/v1/dashboard');
        $res->assertStatus(401);
        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success'] ?? true);

        // Invalid Bearer token
        $res2 = $this->withHeaders(['Authorization' => 'Bearer mat_invalid_token_xyz'])
            ->call('get', 'api/v1/dashboard');
        $res2->assertStatus(401);

        // Alias endpoint /api/mobile/v1/dashboard
        $res3 = $this->call('get', 'api/mobile/v1/dashboard');
        $res3->assertStatus(401);
    }

    /**
     * Test 2: Successful dashboard data retrieval for authenticated employee
     */
    public function testSuccessfulDashboardRetrieval(): void
    {
        $today = date('Y-m-d');
        $year = (int)date('Y');

        // Seed department and designation for Rahim
        $this->db->table('departments')->insert(['id' => 'dept-1', 'name' => 'Engineering']);
        $this->db->table('designations')->insert(['id' => 'desig-1', 'name' => 'Software Engineer']);
        $this->db->table('branches')->insert(['id' => 'br-1', 'name' => 'HQ']);
        $this->db->table('employees')->where('id', 'e-1')->update([
            'department_id'  => 'dept-1',
            'designation_id' => 'desig-1',
            'branch_id'      => 'br-1',
        ]);

        // Seed today's attendance for Rahim (e-1)
        $this->db->table('attendance_logs')->insert([
            'id'            => 'att-today-1',
            'employee_id'   => 'e-1',
            'company_id'    => 'c-1',
            'date'          => $today,
            'clock_in'      => "{$today} 09:05:00",
            'in_time'       => '09:05:00',
            'late_minutes'  => 5,
            'working_hours' => 0.00,
            'status'        => 'Present',
            'created_at'    => "{$today} 09:05:00",
        ]);

        // Seed leave type and balance for Rahim
        $this->db->table('leave_types')->insert([
            'id'         => 'lt-ann',
            'company_id' => 'c-1',
            'name'       => 'Annual Leave',
            'code'       => 'AL',
            'is_paid'    => 1,
            'status'     => 'active',
        ]);
        $this->db->table('leave_balances')->insert([
            'id'             => 'lb-1',
            'employee_id'    => 'e-1',
            'leave_type_id'  => 'lt-ann',
            'year'           => $year,
            'allocated_days' => 15.00,
            'used_days'      => 3.00,
            'pending_days'   => 1.00,
            'balance'        => 11.00,
        ]);
        $this->db->table('leave_applications')->insert([
            'id'            => 'la-1',
            'employee_id'   => 'e-1',
            'company_id'    => 'c-1',
            'leave_type_id' => 'lt-ann',
            'from_date'     => "{$year}-11-01",
            'to_date'       => "{$year}-11-02",
            'total_days'    => 1.00,
            'reason'        => 'Personal matter',
            'status'        => 'pending',
            'created_at'    => date('Y-m-d H:i:s'),
        ]);

        // Seed finalized payslip for Rahim
        $this->db->table('payrolls')->insert([
            'id'            => 'pr-1',
            'company_id'    => 'c-1',
            'payroll_month' => '2026-09',
            'status'        => 'Approved',
            'is_locked'     => 1,
        ]);
        $this->db->table('payroll_items')->insert([
            'id'               => 'pi-1',
            'payroll_id'       => 'pr-1',
            'employee_id'      => 'e-1',
            'company_id'       => 'c-1',
            'basic_salary'     => 50000.00,
            'gross_salary'     => 80000.00,
            'total_deductions' => 5000.00,
            'net_salary'       => 75000.00,
            'payment_status'   => 'Paid',
            'bank_account_no'  => 'SECRET-ACCOUNT-12345',
        ]);

        // Seed notification for User 1
        $this->db->table('notifications')->insert([
            'id'         => 'notif-1',
            'user_id'    => 'u-1',
            'company_id' => 'c-1',
            'title'      => 'Payslip Released',
            'message'    => 'Your payslip for 2026-09 is now available.',
            'is_read'    => 0,
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        // Seed company announcement
        $this->db->table('notices')->insert([
            'id'             => 'notice-1',
            'company_id'     => 'c-1',
            'title'          => 'Office Townhall',
            'content'        => 'Townhall meeting this Friday at 3 PM.',
            'status'         => 'published',
            'published_date' => $today,
            'created_at'     => date('Y-m-d H:i:s'),
        ]);

        // Execute request to GET /api/v1/dashboard
        $token = $this->login('ACME', 'rahim');
        $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])
            ->call('get', 'api/v1/dashboard');

        $res->assertStatus(200);
        $json = json_decode($res->getJSON(), true);

        // Envelope validation
        $this->assertTrue($json['success'] ?? false);
        $this->assertSame('success', $json['status'] ?? '');
        $this->assertSame('Dashboard data retrieved successfully.', $json['message'] ?? '');
        $data = $json['data'] ?? [];

        // 1. Employee profile check
        $this->assertSame('e-1', $data['employee']['id']);
        $this->assertSame('EMP-001', $data['employee']['employee_code']);
        $this->assertSame('Rahim', $data['employee']['first_name']);
        $this->assertSame('Engineering', $data['employee']['department']);
        $this->assertSame('Software Engineer', $data['employee']['designation']);
        $this->assertSame('HQ', $data['employee']['branch']);

        // Salary and bank details MUST NOT be exposed in employee object
        $this->assertArrayNotHasKey('basic_salary', $data['employee']);
        $this->assertArrayNotHasKey('gross_salary', $data['employee']);
        $this->assertArrayNotHasKey('bank_account_no', $data['employee']);

        // 2. Company check
        $this->assertSame('c-1', $data['company']['id']);
        $this->assertSame('ACME', $data['company']['code']);

        // 3. Attendance today check
        $this->assertTrue($data['attendance_today']['checked_in']);
        $this->assertFalse($data['attendance_today']['checked_out']);
        $this->assertSame('09:05:00', $data['attendance_today']['check_in_time']);
        $this->assertSame('Present', $data['attendance_today']['status']);
        $this->assertSame(5, $data['attendance_today']['late_minutes']);

        // 4. Leave summary check
        $this->assertTrue($data['leave_summary']['is_authorized']);
        $this->assertEquals(11.0, $data['leave_summary']['total_available_balance']);
        $this->assertSame(1, $data['leave_summary']['pending_applications_count']);
        $this->assertNotEmpty($data['leave_summary']['balances']);
        $this->assertNotEmpty($data['leave_summary']['recent_applications']);

        // 5. Latest payslip check
        $this->assertNotNull($data['latest_payslip']);
        $this->assertSame('pi-1', $data['latest_payslip']['id']);
        $this->assertSame('2026-09', $data['latest_payslip']['payroll_month']);
        $this->assertEquals(75000.0, $data['latest_payslip']['net_salary']);
        $this->assertEquals(80000.0, $data['latest_payslip']['gross_salary']);
        $this->assertEquals(5000.0, $data['latest_payslip']['total_deductions']);
        $this->assertStringNotContainsString('SECRET-ACCOUNT', $res->getJSON());

        // 6. Notifications check
        $this->assertSame(1, $data['notifications']['unread_count']);
        $this->assertCount(1, $data['notifications']['recent']);
        $this->assertSame('Payslip Released', $data['notifications']['recent'][0]['title']);

        // 7. Announcements check
        $this->assertCount(1, $data['announcements']);
        $this->assertSame('Office Townhall', $data['announcements'][0]['title']);

        // 8. KPI summary check
        $this->assertSame('Present', $data['summary']['attendance_status']);
        $this->assertTrue($data['summary']['is_checked_in']);
        $this->assertEquals(11.0, $data['summary']['total_available_leaves']);
        $this->assertSame(1, $data['summary']['pending_leave_requests']);
        $this->assertSame(1, $data['summary']['unread_notifications_count']);

        // Alias /api/mobile/v1/dashboard also works identically
        $resAlias = $this->withHeaders(['Authorization' => "Bearer {$token}"])
            ->call('get', 'api/mobile/v1/dashboard');
        $resAlias->assertStatus(200);
    }

    /**
     * Test 3: Gracefully handles empty data without errors
     */
    public function testGracefulHandlingOfEmptyData(): void
    {
        $token = $this->login('ACME', 'rahim');
        $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])
            ->call('get', 'api/v1/dashboard');

        $res->assertStatus(200);
        $json = json_decode($res->getJSON(), true);
        $data = $json['data'] ?? [];

        // When no attendance log exists for today
        $this->assertFalse($data['attendance_today']['checked_in']);
        $this->assertFalse($data['attendance_today']['checked_out']);
        $this->assertSame('Not Marked', $data['attendance_today']['status']);

        // When no payslip exists
        $this->assertNull($data['latest_payslip']);

        // When no notifications exist
        $this->assertSame(0, $data['notifications']['unread_count']);
        $this->assertSame([], $data['notifications']['recent']);

        // When no announcements exist
        $this->assertSame([], $data['announcements']);

        // When no leave applications or balances exist
        $this->assertSame(0, $data['leave_summary']['pending_applications_count']);
        $this->assertEquals(0.0, $data['leave_summary']['total_available_balance']);
    }

    /**
     * Test 4: Cross-tenant and cross-user isolation
     * User 1 in ACME (c-1) MUST NOT see data belonging to User 2 in OTHER (c-2)
     */
    public function testCrossTenantAndCrossUserIsolation(): void
    {
        $today = date('Y-m-d');

        // Seed data for Karim (e-2, c-2, u-2)
        $this->db->table('attendance_logs')->insert([
            'id'            => 'att-karim',
            'employee_id'   => 'e-2',
            'company_id'    => 'c-2',
            'date'          => $today,
            'clock_in'      => "{$today} 08:30:00",
            'in_time'       => '08:30:00',
            'status'        => 'Present',
        ]);
        $this->db->table('payrolls')->insert([
            'id'            => 'pr-other',
            'company_id'    => 'c-2',
            'payroll_month' => '2026-09',
            'status'        => 'Paid',
            'is_locked'     => 1,
        ]);
        $this->db->table('payroll_items')->insert([
            'id'               => 'pi-karim',
            'payroll_id'       => 'pr-other',
            'employee_id'      => 'e-2',
            'company_id'       => 'c-2',
            'basic_salary'     => 90000.00,
            'gross_salary'     => 100000.00,
            'total_deductions' => 10000.00,
            'net_salary'       => 90000.00,
        ]);
        $this->db->table('notifications')->insert([
            'id'         => 'notif-karim',
            'user_id'    => 'u-2',
            'company_id' => 'c-2',
            'title'      => 'Other Company Notice',
            'message'    => 'Confidential for Karim',
            'is_read'    => 0,
        ]);
        $this->db->table('notices')->insert([
            'id'         => 'notice-c2',
            'company_id' => 'c-2',
            'title'      => 'OTHER Company Memo',
            'content'    => 'Confidential memo for c-2',
            'status'     => 'published',
        ]);

        // Login as Rahim (u-1, e-1, c-1)
        $token = $this->login('ACME', 'rahim');

        // Attempt parameter tampering by passing spoofed employee_id and company_id
        $res = $this->withHeaders(['Authorization' => "Bearer {$token}"])
            ->call('get', 'api/v1/dashboard?employee_id=e-2&company_id=c-2');

        $res->assertStatus(200);
        $json = json_decode($res->getJSON(), true);
        $data = $json['data'] ?? [];

        // Must still strictly return Rahim's profile
        $this->assertSame('e-1', $data['employee']['id']);
        $this->assertSame('c-1', $data['company']['id']);

        // Must not see Karim's attendance
        $this->assertFalse($data['attendance_today']['checked_in']);
        $this->assertSame('Not Marked', $data['attendance_today']['status']);

        // Must not see Karim's payslip
        $this->assertNull($data['latest_payslip']);

        // Must not see Karim's notifications
        $this->assertSame(0, $data['notifications']['unread_count']);
        $this->assertSame([], $data['notifications']['recent']);

        // Must not see c-2 announcements
        $this->assertSame([], $data['announcements']);
    }

    /**
     * Test 5: User without linked employee record returns 404
     */
    public function testAccountWithoutEmployeeReturns404(): void
    {
        // Add user without employee_id
        $this->addUser('u-admin', 'sysadmin', 'admin@acme.test', 'c-1', null, 'r-sa');

        $res = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => 'ACME',
            'identifier'   => 'sysadmin',
            'password'     => self::PASSWORD,
            'device'       => $this->device,
        ]);
        $res->assertStatus(200);
        $token = json_decode($res->getJSON(), true)['data']['tokens']['access_token'];

        $dashRes = $this->withHeaders(['Authorization' => "Bearer {$token}"])
            ->call('get', 'api/v1/dashboard');

        $dashRes->assertStatus(404);
        $json = json_decode($dashRes->getJSON(), true);
        $this->assertFalse($json['success'] ?? true);
        $this->assertSame('No employee profile is linked to this account.', $json['message'] ?? '');
    }

    /**
     * Test 6: MobileDashboardService directly handles database and scopes
     */
    public function testDashboardServiceDirectly(): void
    {
        $service = new MobileDashboardService($this->db);

        // Missing arguments
        $err = $service->getDashboard('', 'c-1', 'e-1');
        $this->assertFalse($err['ok']);
        $this->assertSame(404, $err['status']);

        // Non-existent employee
        $notFound = $service->getDashboard('u-1', 'c-1', 'non-existent-emp');
        $this->assertFalse($notFound['ok']);
        $this->assertSame(404, $notFound['status']);

        // Valid employee
        $ok = $service->getDashboard('u-1', 'c-1', 'e-1');
        $this->assertTrue($ok['ok']);
        $this->assertSame(200, $ok['status']);
        $this->assertArrayHasKey('employee', $ok['data']);
        $this->assertArrayHasKey('summary', $ok['data']);
        $this->assertArrayHasKey('attendance_today', $ok['data']);
        $this->assertArrayHasKey('leave_summary', $ok['data']);
    }
}
