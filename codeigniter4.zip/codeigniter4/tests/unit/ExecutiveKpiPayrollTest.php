<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\DashboardWidgetRegistry;

/**
 * Unit Test for Executive KPI Card Monthly Payroll Integration & RBAC
 *
 * Covers:
 * 1. Widget 'company_executive_kpis' registers 'monthly_payroll' in data_dependencies.
 * 2. View logic displays company currency and formatted amount when authorized.
 * 3. View logic displays '—' when user lacks payroll view permissions.
 * 4. Zero hardcoded '$' symbols in executive KPI view.
 */
class ExecutiveKpiPayrollTest extends TestCase
{
    /**
     * Verify that 'company_executive_kpis' declares 'monthly_payroll' in its dependencies.
     */
    public function testRegistryIncludesMonthlyPayrollDependency()
    {
        $catalog = DashboardWidgetRegistry::getCatalog();
        $this->assertArrayHasKey('company_executive_kpis', $catalog, "Widget 'company_executive_kpis' must exist in catalog.");

        $widgetDef = $catalog['company_executive_kpis'];
        $deps = $widgetDef['data_dependencies'] ?? [];

        $this->assertContains(
            'monthly_payroll',
            $deps,
            "Widget 'company_executive_kpis' data_dependencies must include 'monthly_payroll'."
        );

        $expectedDeps = ['stats', 'attendance_stats', 'department_count', 'branch_count', 'monthly_payroll'];
        foreach ($expectedDeps as $dep) {
            $this->assertContains($dep, $deps, "Expected dependency '{$dep}' missing from company_executive_kpis.");
        }
    }

    /**
     * Verify view template renders company currency and formatted amount for authorized user.
     */
    public function testExecutiveKpiViewRendersAmountAndCompanyCurrencyForAuthorizedUser()
    {
        $metrics = [
            'data' => [
                'can_view_payroll' => true,
                'monthly_payroll'  => 85200.50,
                'total_employees'  => 120,
                'active_employees' => 118,
                'present_today'    => 110,
                'late_today'       => 5,
                'on_leave_today'   => 3,
                'absent_today'     => 0,
                'total_branches'   => 4,
                'total_departments'=> 8,
            ]
        ];
        $company = [
            'currency' => 'EUR',
            'currency_symbol' => '€'
        ];

        ob_start();
        include APPPATH . 'Views/dashboard/widgets/executive_kpis.php';
        $output = ob_get_clean();

        $this->assertStringContainsString('85,200.50', $output, "Output must contain formatted payroll amount.");
        $this->assertStringContainsString('EUR', $output, "Output must render company currency 'EUR'.");
        $this->assertStringNotContainsString('—', $output, "Authorized user with valid payroll should not see '—' for payroll.");
    }

    /**
     * Verify view template renders '—' when user lacks payroll permission.
     */
    public function testExecutiveKpiViewRendersEmDashForUnauthorizedUser()
    {
        $metrics = [
            'data' => [
                'can_view_payroll' => false,
                'monthly_payroll'  => null,
                'total_employees'  => 50,
                'active_employees' => 50,
                'present_today'    => 45,
                'late_today'       => 2,
                'on_leave_today'   => 2,
                'absent_today'     => 1,
                'total_branches'   => 2,
                'total_departments'=> 4,
            ]
        ];
        $company = [
            'currency' => 'BDT',
            'currency_symbol' => '৳'
        ];

        ob_start();
        include APPPATH . 'Views/dashboard/widgets/executive_kpis.php';
        $output = ob_get_clean();

        $this->assertStringContainsString('—', $output, "Unauthorized user must see '—' for monthly payroll.");
        $this->assertStringNotContainsString('85,200', $output, "Unauthorized user must not see any payroll amounts.");
    }

    /**
     * Verify view template handles empty or missing company currency gracefully without falling back to '$'.
     */
    public function testExecutiveKpiViewNoDollarHardcoding()
    {
        $metrics = [
            'data' => [
                'can_view_payroll' => true,
                'monthly_payroll'  => 15000.00,
            ]
        ];
        $company = [
            'currency' => 'GBP',
            'currency_symbol' => '£'
        ];

        ob_start();
        include APPPATH . 'Views/dashboard/widgets/executive_kpis.php';
        $output = ob_get_clean();

        $this->assertStringContainsString('GBP', $output, "Output must display 'GBP'.");
        $this->assertStringContainsString('15,000.00', $output);
        $this->assertStringNotContainsString('$', $output, "View must not contain literal '$' currency symbol.");
    }
}
