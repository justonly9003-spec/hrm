<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

/**
 * MobilePayslipDetailSecurityTest
 *
 * Validates data security and access control for the mobile payslip detail endpoint:
 * - Strict authentication via MobileAuthFilter (401 for unauthenticated)
 * - Anti-IDOR: Cross-employee access returns 404
 * - Cross-tenant isolation: Cross-company access returns 404
 * - Query string parameter tampering protection (403 for unauthorized employee/company overrides)
 * - Inactive or separated employees are forbidden (403)
 * - Draft / unapproved payslips are rejected (404)
 * - Explicit allow-list enforcement: internal IDs, raw JSON, employer costs, and audit keys are stripped
 * - Component breakdown filtering: employer contributions (PF matching, Gratuity provisions, CTC) and inactive components are excluded
 * - Zero leaking of sensitive data (bank account, national ID, personal email/phone, formulas, snapshots)
 */
#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobilePayslipDetailSecurityTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);

        foreach (['payrolls', 'payroll_items', 'salary_components'] as $t) {
            $this->db->query("DROP TABLE IF EXISTS {$t}");
        }

        $this->db->query("CREATE TABLE payrolls (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            payroll_month VARCHAR(10),
            status VARCHAR(20),
            is_locked INT DEFAULT 0
        )");

        $this->db->query("CREATE TABLE payroll_items (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36) NULL,
            payroll_id VARCHAR(36),
            employee_id VARCHAR(36),
            basic_salary DECIMAL(15,2) DEFAULT 0.00,
            gross_salary DECIMAL(15,2) DEFAULT 0.00,
            house_rent DECIMAL(15,2) DEFAULT 0.00,
            medical DECIMAL(15,2) DEFAULT 0.00,
            conveyance DECIMAL(15,2) DEFAULT 0.00,
            allowances DECIMAL(15,2) DEFAULT 0.00,
            other_allowances DECIMAL(15,2) DEFAULT 0.00,
            overtime_amount DECIMAL(15,2) DEFAULT 0.00,
            bonus_amount DECIMAL(15,2) DEFAULT 0.00,
            arrear_amount DECIMAL(15,2) DEFAULT 0.00,
            tax_deduction DECIMAL(15,2) DEFAULT 0.00,
            pf_deduction DECIMAL(15,2) DEFAULT 0.00,
            arrear_pf_deduction DECIMAL(15,2) DEFAULT 0.00,
            loan_emi DECIMAL(15,2) DEFAULT 0.00,
            advance_recovery DECIMAL(15,2) DEFAULT 0.00,
            unpaid_leave_deduction DECIMAL(15,2) DEFAULT 0.00,
            lop_deduction DECIMAL(15,2) DEFAULT 0.00,
            late_penalty DECIMAL(15,2) DEFAULT 0.00,
            other_deductions DECIMAL(15,2) DEFAULT 0.00,
            total_deductions DECIMAL(15,2) DEFAULT 0.00,
            net_salary DECIMAL(15,2) DEFAULT 0.00,
            payment_status VARCHAR(20) DEFAULT 'Unpaid',
            bank_account_no VARCHAR(50) NULL,
            rules_snapshot_json LONGTEXT NULL,
            statutory_snapshot_json LONGTEXT NULL,
            components_breakdown_json LONGTEXT NULL
        )");

        $this->db->query("CREATE TABLE salary_components (
            id VARCHAR(36) PRIMARY KEY,
            company_id VARCHAR(36),
            name VARCHAR(150),
            code VARCHAR(50),
            type VARCHAR(30) DEFAULT 'earning',
            status VARCHAR(20) DEFAULT 'Active'
        )");
    }

    private function insertRows(string $table, array $rows): void
    {
        foreach ($rows as $r) {
            $this->db->table($table)->insert($r);
        }
    }

    private function token(string $company = 'ACME', string $id = 'rahim'): array
    {
        $res = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => $company,
            'identifier'   => $id,
            'password'     => self::PASSWORD,
            'device'       => ['device_uid' => 'dev-payslip-detail'],
        ]);
        $json = json_decode($res->getJSON(), true);
        return ['Authorization' => 'Bearer ' . $json['data']['tokens']['access_token']];
    }

    private function seedPayslips(): void
    {
        $this->insertRows('payrolls', [
            ['id' => 'pr-sep26', 'company_id' => 'c-1', 'payroll_month' => '2026-09', 'status' => 'Paid', 'is_locked' => 1],
            ['id' => 'pr-draft', 'company_id' => 'c-1', 'payroll_month' => '2026-10', 'status' => 'Draft', 'is_locked' => 0],
            ['id' => 'pr-c2',    'company_id' => 'c-2', 'payroll_month' => '2026-09', 'status' => 'Paid', 'is_locked' => 1],
        ]);

        $richBreakdown = json_encode([
            'structure_id'   => 'struct-uuid-1234',
            'structure_name' => 'Standard Executive Structure',
            'earnings' => [
                ['code' => 'BASIC', 'name' => 'Basic Salary', 'amount' => 50000.00, 'type' => 'earning'],
                ['code' => 'HRA', 'name' => 'House Rent Allowance', 'amount' => 25000.00, 'type' => 'earning'],
                ['code' => 'MED', 'name' => 'Medical Allowance', 'amount' => 10000.00, 'type' => 'earning'],
            ],
            'deductions' => [
                ['code' => 'TAX', 'name' => 'Income Tax (TDS)', 'amount' => 5000.00, 'type' => 'deduction'],
                ['code' => 'PF', 'name' => 'Provident Fund (PF)', 'amount' => 5000.00, 'type' => 'deduction'],
            ],
            // Sensitive internal data that must NOT be leaked
            'employer_contributions' => [
                [
                    'code'   => 'PF_EMPLOYER',
                    'name'   => 'Employer Provident Fund Matching',
                    'amount' => 5000.00,
                    'type'   => 'employer_contribution',
                ],
                [
                    'code'              => 'GRATUITY_PROVISION',
                    'name'              => 'Statutory Gratuity Provision',
                    'amount'            => 2403.85,
                    'type'              => 'employer_contribution',
                    'multiplier_days'   => 15,
                    'divisor_days'      => 26,
                    'eligibility_years' => 5,
                ],
            ],
            'gratuity_provision'        => 2403.85,
            'gratuity_details'          => ['rate' => 0.05, 'basis' => 'basic'],
            'tax_details'               => ['mode' => 'auto', 'override_reason' => 'Confidential executive adjustment'],
            'total_employer_cost'       => 92403.85,
            'ctc'                       => 92403.85,
            'annual_ctc'                => 1108846.20,
            'statutory_ceiling_applied' => false,
            'minimum_net_salary_floor'  => 5000.00,
            'floor_warning'             => null,
            'warnings'                  => ['Internal reconciliation notice'],
            'is_below_floor'            => false,
            'unapplied_deductions'      => ['tax' => 0.0, 'pf' => 0.0],
            'bonus_record_ids'          => ['bon-internal-999'],
            'weekly_bonus_record_ids'   => ['wbon-internal-888'],
            'leave_encashment_ids'      => ['enc-internal-777'],
        ]);

        $this->insertRows('payroll_items', [
            [
                'id'                        => 'pi-sep26',
                'company_id'                => 'c-1',
                'payroll_id'                => 'pr-sep26',
                'employee_id'               => 'e-1',
                'basic_salary'              => 50000.00,
                'gross_salary'              => 85000.00,
                'house_rent'                => 25000.00,
                'medical'                   => 10000.00,
                'tax_deduction'             => 5000.00,
                'pf_deduction'              => 5000.00,
                'total_deductions'          => 10000.00,
                'net_salary'                => 75000.00,
                'payment_status'            => 'Paid',
                'bank_account_no'           => '9876543210-SECRET',
                'rules_snapshot_json'       => '{"PAYROLL_BASICS":{"layers":[{"rule_id":"rd-secret"}]}}',
                'statutory_snapshot_json'   => '{"pf_member_id":"mem-secret-123"}',
                'components_breakdown_json' => $richBreakdown,
            ],
            // Another employee in company c-1 (for IDOR check)
            [
                'id'                        => 'pi-other-emp',
                'company_id'                => 'c-1',
                'payroll_id'                => 'pr-sep26',
                'employee_id'               => 'e-other-colleague',
                'basic_salary'              => 70000.00,
                'gross_salary'              => 110000.00,
                'total_deductions'          => 15000.00,
                'net_salary'                => 95000.00,
                'payment_status'            => 'Paid',
                'bank_account_no'           => '1111222233-COLLEAGUE',
                'components_breakdown_json' => '{}',
            ],
            // Draft payslip for e-1
            [
                'id'                        => 'pi-draft',
                'company_id'                => 'c-1',
                'payroll_id'                => 'pr-draft',
                'employee_id'               => 'e-1',
                'basic_salary'              => 50000.00,
                'gross_salary'              => 85000.00,
                'total_deductions'          => 10000.00,
                'net_salary'                => 75000.00,
                'payment_status'            => 'Draft',
            ],
            // Another tenant's payslip
            [
                'id'                        => 'pi-c2',
                'company_id'                => 'c-2',
                'payroll_id'                => 'pr-c2',
                'employee_id'               => 'e-2',
                'basic_salary'              => 60000.00,
                'gross_salary'              => 95000.00,
                'total_deductions'          => 5000.00,
                'net_salary'                => 90000.00,
                'payment_status'            => 'Paid',
                'bank_account_no'           => '5555555555-CROSS',
            ],
        ]);

        $this->insertRows('salary_components', [
            ['id' => 'sc-1', 'company_id' => 'c-1', 'name' => 'Basic Salary', 'code' => 'BASIC', 'type' => 'earning', 'status' => 'Active'],
            ['id' => 'sc-2', 'company_id' => 'c-1', 'name' => 'House Rent Allowance', 'code' => 'HRA', 'type' => 'earning', 'status' => 'Active'],
            ['id' => 'sc-3', 'company_id' => 'c-1', 'name' => 'Medical Allowance', 'code' => 'MED', 'type' => 'earning', 'status' => 'Active'],
            ['id' => 'sc-4', 'company_id' => 'c-1', 'name' => 'Income Tax', 'code' => 'TAX', 'type' => 'deduction', 'status' => 'Active'],
            ['id' => 'sc-5', 'company_id' => 'c-1', 'name' => 'Provident Fund', 'code' => 'PF', 'type' => 'deduction', 'status' => 'Active'],
            ['id' => 'sc-6', 'company_id' => 'c-1', 'name' => 'Employer PF Matching', 'code' => 'PF_EMPLOYER', 'type' => 'employer_contribution', 'status' => 'Active'],
            ['id' => 'sc-7', 'company_id' => 'c-1', 'name' => 'Gratuity Provision', 'code' => 'GRATUITY_PROVISION', 'type' => 'employer_contribution', 'status' => 'Active'],
        ]);
    }

    public function testUnauthenticatedAccessIsRejectedWith401(): void
    {
        $res = $this->get('api/mobile/v1/payslips/pi-sep26');
        $res->assertStatus(401);

        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success']);
        $this->assertSame('error', $json['status']);

        // Check alias
        $res2 = $this->get('api/v1/payroll/payslips/pi-sep26');
        $res2->assertStatus(401);
    }

    public function testValidPayslipDetailAccessReturnsApprovedAllowList(): void
    {
        $this->seedPayslips();
        $token = $this->token();

        $res = $this->withHeaders($token)->get('api/mobile/v1/payslips/pi-sep26');
        $res->assertStatus(200);

        $json = json_decode($res->getJSON(), true);
        $this->assertTrue($json['success']);
        $this->assertSame('success', $json['status']);
        $this->assertSame('OK', $json['message']);

        $data = $json['data'];
        $this->assertArrayHasKey('payslip', $data);
        $this->assertArrayHasKey('components', $data);
        $this->assertArrayHasKey('employee', $data);
        $this->assertArrayHasKey('company', $data);

        // Verify approved payslip fields
        $payslip = $data['payslip'];
        $this->assertSame('pi-sep26', $payslip['id']);
        $this->assertSame('2026-09', $payslip['payroll_month']);
        $this->assertSame('Paid', $payslip['payment_status']);
        $this->assertTrue($payslip['is_paid']);
        $this->assertEquals(85000.00, $payslip['gross_salary']);
        $this->assertEquals(10000.00, $payslip['total_deductions']);
        $this->assertEquals(75000.00, $payslip['net_salary']);
        $this->assertEquals(50000.00, $payslip['basic_salary']);
        $this->assertEquals(35000.00, $payslip['total_allowances']);
        $this->assertEquals(5000.00, $payslip['tax_deduction']);
        $this->assertEquals(5000.00, $payslip['pf_deduction']);
        $this->assertNotEmpty($payslip['currency']);
        $this->assertStringContainsString('api/mobile/v1/payslips/pi-sep26/pdf', $payslip['pdf_url']);

        // Verify components breakdown structure
        $components = $data['components'];
        $this->assertArrayHasKey('earnings', $components);
        $this->assertArrayHasKey('deductions', $components);
        $this->assertIsArray($components['earnings']);
        $this->assertIsArray($components['deductions']);

        // Earnings items have only allowed keys (code, name, amount)
        foreach ($components['earnings'] as $earning) {
            $this->assertArrayHasKey('code', $earning);
            $this->assertArrayHasKey('name', $earning);
            $this->assertArrayHasKey('amount', $earning);
            $this->assertArrayNotHasKey('type', $earning);
            $this->assertArrayNotHasKey('formula', $earning);
        }

        // Deductions items have only allowed keys (code, name, amount)
        foreach ($components['deductions'] as $deduction) {
            $this->assertArrayHasKey('code', $deduction);
            $this->assertArrayHasKey('name', $deduction);
            $this->assertArrayHasKey('amount', $deduction);
            $this->assertArrayNotHasKey('type', $deduction);
            $this->assertArrayNotHasKey('formula', $deduction);
        }

        // Employee safe profile fields
        $emp = $data['employee'];
        $this->assertSame('EMP-001', $emp['employee_code']);
        $this->assertSame('Rahim Ahmed', $emp['name']);
        $this->assertArrayHasKey('designation', $emp);
        $this->assertArrayHasKey('department', $emp);
        $this->assertArrayHasKey('branch', $emp);

        // Company safe profile fields
        $company = $data['company'];
        $this->assertSame('Acme Global HRMS', $company['name']);
        $this->assertSame('ACME', $company['code']);
    }

    public function testUnauthorizedFieldsAreStrictlyOmitted(): void
    {
        $this->seedPayslips();
        $token = $this->token();

        $res = $this->withHeaders($token)->get('api/mobile/v1/payslips/pi-sep26');
        $res->assertStatus(200);

        $json = json_decode($res->getJSON(), true);
        $data = $json['data'];
        $payslip = $data['payslip'];
        $components = $data['components'];
        $employee = $data['employee'];

        // 1. Payslip object must NOT leak internal DB keys or raw dumps
        $this->assertArrayNotHasKey('payroll_id', $payslip, 'Internal payroll batch UUID must not be exposed');
        $this->assertArrayNotHasKey('bank_account_no', $payslip, 'Bank account number must not be exposed');
        $this->assertArrayNotHasKey('rules_snapshot_json', $payslip, 'Raw rules snapshot must not be exposed');
        $this->assertArrayNotHasKey('statutory_snapshot_json', $payslip, 'Raw statutory snapshot must not be exposed');
        $this->assertArrayNotHasKey('tax_snapshot_json', $payslip, 'Raw tax snapshot must not be exposed');
        $this->assertArrayNotHasKey('components_breakdown_json', $payslip, 'Raw components JSON must not be exposed');
        $this->assertArrayNotHasKey('arrear_pf_employer', $payslip, 'Employer arrear PF must not be exposed');
        $this->assertArrayNotHasKey('has_pf_arrear_recovery', $payslip, 'Internal arrear recovery flag must not be exposed');
        $this->assertArrayNotHasKey('is_pf_applicable', $payslip, 'Internal eligibility flag must not be exposed');

        // 2. Components object must NOT leak employer overhead, CTC, or internal calculation objects
        $this->assertArrayNotHasKey('employer_contributions', $components, 'Employer contributions must not be exposed');
        $this->assertArrayNotHasKey('gratuity_provision', $components, 'Gratuity provision must not be exposed');
        $this->assertArrayNotHasKey('gratuity_details', $components, 'Internal gratuity calculation must not be exposed');
        $this->assertArrayNotHasKey('tax_details', $components, 'Internal tax computation trace must not be exposed');
        $this->assertArrayNotHasKey('total_employer_cost', $components, 'Employer overhead cost must not be exposed');
        $this->assertArrayNotHasKey('ctc', $components, 'Cost to Company must not be exposed');
        $this->assertArrayNotHasKey('annual_ctc', $components, 'Annual CTC must not be exposed');
        $this->assertArrayNotHasKey('statutory_ceiling_applied', $components, 'Internal statutory ceiling flag must not be exposed');
        $this->assertArrayNotHasKey('minimum_net_salary_floor', $components, 'Internal salary floor must not be exposed');
        $this->assertArrayNotHasKey('floor_warning', $components, 'Internal floor warning must not be exposed');
        $this->assertArrayNotHasKey('warnings', $components, 'Internal warning array must not be exposed');
        $this->assertArrayNotHasKey('is_below_floor', $components, 'Internal below-floor flag must not be exposed');
        $this->assertArrayNotHasKey('unapplied_deductions', $components, 'Internal unapplied deductions must not be exposed');
        $this->assertArrayNotHasKey('bonus_record_ids', $components, 'Database bonus IDs must not be exposed');
        $this->assertArrayNotHasKey('weekly_bonus_record_ids', $components, 'Database weekly bonus IDs must not be exposed');
        $this->assertArrayNotHasKey('leave_encashment_ids', $components, 'Database leave encashment IDs must not be exposed');
        $this->assertArrayNotHasKey('structure_id', $components, 'Salary structure database UUID must not be exposed');

        // 3. Employee object must NOT leak personal secrets
        $this->assertArrayNotHasKey('id', $employee, 'Employee database UUID must not be exposed');
        $this->assertArrayNotHasKey('company_id', $employee, 'Company database UUID must not be exposed');
        $this->assertArrayNotHasKey('email', $employee, 'Employee personal email must not be exposed');
        $this->assertArrayNotHasKey('phone', $employee, 'Employee personal phone must not be exposed');
        $this->assertArrayNotHasKey('bank_account_no', $employee, 'Bank account number must not be exposed');
        $this->assertArrayNotHasKey('national_id', $employee, 'National ID must not be exposed');
        $this->assertArrayNotHasKey('salary', $employee, 'Raw base salary must not be exposed in employee profile');
    }

    public function testEmployerContributionComponentsAreFilteredOut(): void
    {
        $this->seedPayslips();
        $token = $this->token();

        $res = $this->withHeaders($token)->get('api/mobile/v1/payslips/pi-sep26');
        $res->assertStatus(200);

        $json = json_decode($res->getJSON(), true);
        $components = $json['data']['components'];

        // Verify neither PF_EMPLOYER nor GRATUITY_PROVISION appear in earnings
        $earningCodes = array_column($components['earnings'], 'code');
        $this->assertNotContains('PF_EMPLOYER', $earningCodes);
        $this->assertNotContains('GRATUITY_PROVISION', $earningCodes);

        // Verify neither appear in deductions
        $deductionCodes = array_column($components['deductions'], 'code');
        $this->assertNotContains('PF_EMPLOYER', $deductionCodes);
        $this->assertNotContains('GRATUITY_PROVISION', $deductionCodes);
    }

    public function testInactiveComponentsAreExcludedByPolicy(): void
    {
        $this->seedPayslips();
        // Mark HRA inactive in company salary policy
        $this->db->table('salary_components')
            ->where('company_id', 'c-1')
            ->where('code', 'HRA')
            ->update(['status' => 'Inactive']);

        $token = $this->token();
        $res = $this->withHeaders($token)->get('api/mobile/v1/payslips/pi-sep26');
        $res->assertStatus(200);

        $json = json_decode($res->getJSON(), true);
        $earningCodes = array_column($json['data']['components']['earnings'], 'code');
        $this->assertNotContains('HRA', $earningCodes, 'Inactive salary component must be omitted per payroll policy');
    }

    public function testCrossEmployeeIdorAccessReturns404(): void
    {
        $this->seedPayslips();
        $token = $this->token();

        // Rahim (e-1) attempts to access colleague's payslip in the same company
        $res = $this->withHeaders($token)->get('api/mobile/v1/payslips/pi-other-emp');
        $res->assertStatus(404);

        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success']);
        $this->assertSame('error', $json['status']);
        $this->assertSame('Payslip not found.', $json['message']);
    }

    public function testCrossTenantPayslipAccessReturns404(): void
    {
        $this->seedPayslips();
        $token = $this->token();

        // Rahim (Company c-1) attempts to view Company c-2 payslip
        $res = $this->withHeaders($token)->get('api/mobile/v1/payslips/pi-c2');
        $res->assertStatus(404);

        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success']);
        $this->assertSame('error', $json['status']);
        $this->assertSame('Payslip not found.', $json['message']);
    }

    public function testDraftPayslipReturns404(): void
    {
        $this->seedPayslips();
        $token = $this->token();

        // Rahim attempts to view an unfinalized draft payslip
        $res = $this->withHeaders($token)->get('api/mobile/v1/payslips/pi-draft');
        $res->assertStatus(404);

        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success']);
        $this->assertSame('error', $json['status']);
        $this->assertSame('Payslip not found.', $json['message']);
    }

    public function testQueryStringIdorTamperingReturns403(): void
    {
        $this->seedPayslips();
        $token = $this->token();

        // Tampering with employee_id query param
        $res1 = $this->withHeaders($token)->get('api/mobile/v1/payslips/pi-sep26?employee_id=e-other');
        $res1->assertStatus(403);
        $json1 = json_decode($res1->getJSON(), true);
        $this->assertFalse($json1['success']);
        $this->assertStringContainsString('Forbidden', $json1['message']);

        // Tampering with company_id query param
        $res2 = $this->withHeaders($token)->get('api/mobile/v1/payslips/pi-sep26?company_id=c-2');
        $res2->assertStatus(403);
        $json2 = json_decode($res2->getJSON(), true);
        $this->assertFalse($json2['success']);
        $this->assertStringContainsString('Cross-tenant', $json2['message']);
    }

    public function testSeparatedEmployeeReturns403(): void
    {
        $this->seedPayslips();
        $token = $this->token();

        // Terminate employee
        $this->db->table('employees')->where('id', 'e-1')->update(['status' => 'Terminated']);

        $res = $this->withHeaders($token)->get('api/mobile/v1/payslips/pi-sep26');
        $res->assertStatus(403);

        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success']);
        $this->assertStringContainsString('inactive or separated', $json['message']);
    }

    public function testAllRouteAliasesResolveConsistently(): void
    {
        $this->seedPayslips();
        $token = $this->token();

        $routes = [
            'api/mobile/v1/payslips/pi-sep26',
            'api/mobile/v1/payroll/payslips/pi-sep26',
            'api/v1/payroll/payslips/pi-sep26',
            'api/v1/payslips/pi-sep26',
        ];

        foreach ($routes as $route) {
            $res = $this->withHeaders($token)->get($route);
            $res->assertStatus(200);
            $json = json_decode($res->getJSON(), true);
            $this->assertTrue($json['success'], "Failed on route {$route}");
            $this->assertSame('pi-sep26', $json['data']['payslip']['id']);
        }
    }
}
