<?php

namespace Tests\Unit;

use App\Models\EmployeeModel;
use App\Models\OvertimeRecordModel;
use App\Services\Overtime\OvertimeCalculationService;
use App\Services\OvertimeService;
use App\Services\Rules\RuleResolver;
use Config\Database;
use PHPUnit\Framework\TestCase;

class OvertimeCountingPolicyTest extends TestCase
{
    protected OvertimeCalculationService $otService;
    protected OvertimeService $facadeService;

    protected function setUp(): void
    {
        parent::setUp();
        $db = Database::connect();

        $db->query("CREATE TABLE IF NOT EXISTS holidays (
            id VARCHAR(64) PRIMARY KEY,
            company_id VARCHAR(64),
            name VARCHAR(128),
            start_date DATE,
            end_date DATE,
            status VARCHAR(32) DEFAULT 'Published'
        )");

        $db->query("CREATE TABLE IF NOT EXISTS overtime_records (
            id VARCHAR(64) PRIMARY KEY,
            company_id VARCHAR(64) NOT NULL,
            employee_id VARCHAR(64) NOT NULL,
            attendance_log_id VARCHAR(64) NULL,
            policy_id VARCHAR(64) NULL,
            date DATE NOT NULL,
            ot_type VARCHAR(32) NOT NULL DEFAULT 'Normal',
            shift_id VARCHAR(64) NULL,
            shift_start TIME NULL,
            shift_end TIME NULL,
            actual_in TIME NULL,
            actual_out TIME NULL,
            raw_early_minutes INT NOT NULL DEFAULT 0,
            raw_post_minutes INT NOT NULL DEFAULT 0,
            raw_total_minutes INT NOT NULL DEFAULT 0,
            payable_early_minutes INT NOT NULL DEFAULT 0,
            payable_post_minutes INT NOT NULL DEFAULT 0,
            payable_total_minutes INT NOT NULL DEFAULT 0,
            overtime_minutes INT NULL DEFAULT 0,
            overtime_hours DECIMAL(6,2) NOT NULL DEFAULT 0.00,
            base_salary DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            hourly_rate DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            multiplier DECIMAL(4,2) NOT NULL DEFAULT 1.50,
            ot_rate DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            ot_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            approval_status VARCHAR(32) NOT NULL DEFAULT 'Pending',
            approved_by VARCHAR(64) NULL,
            approved_at DATETIME NULL,
            rejection_reason TEXT NULL,
            is_settled TINYINT(1) NOT NULL DEFAULT 0,
            payroll_id VARCHAR(64) NULL,
            payroll_item_id VARCHAR(64) NULL,
            settled_at DATETIME NULL,
            remarks TEXT NULL,
            calculation_metadata_json LONGTEXT NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL
        )");

        $this->otService = new OvertimeCalculationService();
        $this->facadeService = new OvertimeService();
    }

    protected function tearDown(): void
    {
        $db = Database::connect();
        $db->table('overtime_records')->truncate();
        parent::tearDown();
    }

    /**
     * Test 1: Early Check-in Overtime When Disabled
     * Even if employee checks in 45m early, early OT is 0 when toggle is disabled.
     */
    public function testEarlyCheckinOvertimeWhenDisabled(): void
    {
        $policy = [
            'id'                                  => 'test-pol-1',
            'company_id'                          => 'comp-100',
            'enable_early_arrival_ot'             => false,
            'early_arrival_min_threshold_minutes' => 30,
            'early_arrival_grace_minutes'         => 0,
            'enable_post_shift_ot'                => true,
            'post_shift_min_threshold_minutes'    => 30,
            'post_shift_grace_minutes'            => 0,
            'min_ot_unit_minutes'                 => 1,
            'rounding_mode'                       => 'exact',
            'normal_multiplier'                   => 1.5,
            'weekly_off_multiplier'               => 2.0,
            'holiday_multiplier'                  => 2.0,
            'special_multiplier'                  => 2.0,
            'max_daily_ot_hours'                  => 8.0,
        ];

        $employee = [
            'id'         => 'emp-001',
            'company_id' => 'comp-100',
        ];

        // Shift 09:00 - 17:00, Actual In 08:15 (45 mins early), Actual Out 17:00
        $attendanceLog = [
            'id'        => 'att-001',
            'date'      => '2026-11-01',
            'clock_in'  => '08:15',
            'clock_out' => '17:00',
        ];

        $shift = [
            'id'         => 'shift-001',
            'start_time' => '09:00',
            'end_time'   => '17:00',
        ];

        $res = $this->otService->calculateDailyOvertime($employee, $attendanceLog, $shift, $policy, []);

        $this->assertEquals(45, $res['raw_early_minutes']);
        $this->assertEquals(0, $res['payable_early_minutes']);
        $this->assertEquals(0, $res['payable_total_minutes']);
        $this->assertEquals(0.00, $res['overtime_hours']);
    }

    /**
     * Test 2: Early Check-in Overtime Below Configured Threshold
     * Example: Threshold is 30m. Employee checks in 20m early -> does NOT qualify (0 OT).
     */
    public function testEarlyCheckinOvertimeBelowConfiguredThreshold(): void
    {
        $policy = [
            'id'                                  => 'test-pol-2',
            'company_id'                          => 'comp-100',
            'enable_early_arrival_ot'             => true,
            'early_arrival_min_threshold_minutes' => 30,
            'early_arrival_grace_minutes'         => 0,
            'enable_post_shift_ot'                => false,
            'post_shift_min_threshold_minutes'    => 30,
            'min_ot_unit_minutes'                 => 1,
            'rounding_mode'                       => 'exact',
            'normal_multiplier'                   => 1.5,
            'max_daily_ot_hours'                  => 8.0,
        ];

        $employee = ['id' => 'emp-002', 'company_id' => 'comp-100'];

        // In at 08:40 (20 mins early), threshold is 30 mins
        $attendanceLog = [
            'id'        => 'att-002',
            'date'      => '2026-11-01',
            'clock_in'  => '08:40',
            'clock_out' => '17:00',
        ];
        $shift = [
            'id'         => 'shift-001',
            'start_time' => '09:00',
            'end_time'   => '17:00',
        ];

        $res = $this->otService->calculateDailyOvertime($employee, $attendanceLog, $shift, $policy, []);

        $this->assertEquals(20, $res['raw_early_minutes']);
        $this->assertEquals(0, $res['payable_early_minutes']);
        $this->assertEquals(0, $res['payable_total_minutes']);
    }

    /**
     * Test 3: Early Check-in Overtime Meets Configured Threshold
     * Threshold is 30m. Employee checks in 35m early -> meets threshold and qualifies.
     */
    public function testEarlyCheckinOvertimeMeetsConfiguredThreshold(): void
    {
        $policy = [
            'id'                                  => 'test-pol-3',
            'company_id'                          => 'comp-100',
            'enable_early_arrival_ot'             => true,
            'early_arrival_min_threshold_minutes' => 30,
            'early_arrival_grace_minutes'         => 0,
            'enable_post_shift_ot'                => false,
            'post_shift_min_threshold_minutes'    => 30,
            'min_ot_unit_minutes'                 => 1,
            'rounding_mode'                       => 'exact',
            'normal_multiplier'                   => 1.5,
            'max_daily_ot_hours'                  => 8.0,
        ];

        $employee = ['id' => 'emp-003', 'company_id' => 'comp-100'];

        // In at 08:25 (35 mins early), meets 30m threshold
        $attendanceLog = [
            'id'        => 'att-003',
            'date'      => '2026-11-01',
            'clock_in'  => '08:25',
            'clock_out' => '17:00',
        ];
        $shift = [
            'id'         => 'shift-001',
            'start_time' => '09:00',
            'end_time'   => '17:00',
        ];

        $res = $this->otService->calculateDailyOvertime($employee, $attendanceLog, $shift, $policy, []);

        $this->assertEquals(35, $res['raw_early_minutes']);
        $this->assertEquals(35, $res['payable_early_minutes']);
        $this->assertEquals(35, $res['payable_total_minutes']);
        $this->assertEquals(round(35 / 60, 2), $res['overtime_hours']);
    }

    /**
     * Test 4: Post Check-out Overtime When Disabled
     * Employee stays 60m after shift, but post check-out OT is disabled -> 0 OT.
     */
    public function testPostCheckoutOvertimeWhenDisabled(): void
    {
        $policy = [
            'id'                                  => 'test-pol-4',
            'company_id'                          => 'comp-100',
            'enable_early_arrival_ot'             => false,
            'early_arrival_min_threshold_minutes' => 30,
            'enable_post_shift_ot'                => false,
            'post_shift_min_threshold_minutes'    => 30,
            'min_ot_unit_minutes'                 => 1,
            'rounding_mode'                       => 'exact',
            'normal_multiplier'                   => 1.5,
            'max_daily_ot_hours'                  => 8.0,
        ];

        $employee = ['id' => 'emp-004', 'company_id' => 'comp-100'];

        // Out at 18:00 (60 mins post shift)
        $attendanceLog = [
            'id'        => 'att-004',
            'date'      => '2026-11-01',
            'clock_in'  => '09:00',
            'clock_out' => '18:00',
        ];
        $shift = [
            'id'         => 'shift-001',
            'start_time' => '09:00',
            'end_time'   => '17:00',
        ];

        $res = $this->otService->calculateDailyOvertime($employee, $attendanceLog, $shift, $policy, []);

        $this->assertEquals(60, $res['raw_post_minutes']);
        $this->assertEquals(0, $res['payable_post_minutes']);
        $this->assertEquals(0, $res['payable_total_minutes']);
    }

    /**
     * Test 5: Post Check-out Overtime Below Minimum Duration (Default 30 mins)
     * Employee stays 25m after shift -> does not meet 30m condition -> 0 OT.
     */
    public function testPostCheckoutOvertimeBelowMinimumDuration(): void
    {
        $policy = [
            'id'                                  => 'test-pol-5',
            'company_id'                          => 'comp-100',
            'enable_early_arrival_ot'             => false,
            'early_arrival_min_threshold_minutes' => 30,
            'enable_post_shift_ot'                => true,
            'post_shift_min_threshold_minutes'    => 30, // default 30 mins
            'post_shift_grace_minutes'            => 0,
            'min_ot_unit_minutes'                 => 1,
            'rounding_mode'                       => 'exact',
            'normal_multiplier'                   => 1.5,
            'max_daily_ot_hours'                  => 8.0,
        ];

        $employee = ['id' => 'emp-005', 'company_id' => 'comp-100'];

        // Out at 17:25 (25 mins post shift)
        $attendanceLog = [
            'id'        => 'att-005',
            'date'      => '2026-11-01',
            'clock_in'  => '09:00',
            'clock_out' => '17:25',
        ];
        $shift = [
            'id'         => 'shift-001',
            'start_time' => '09:00',
            'end_time'   => '17:00',
        ];

        $res = $this->otService->calculateDailyOvertime($employee, $attendanceLog, $shift, $policy, []);

        $this->assertEquals(25, $res['raw_post_minutes']);
        $this->assertEquals(0, $res['payable_post_minutes']);
        $this->assertEquals(0, $res['payable_total_minutes']);
    }

    /**
     * Test 6: Post Check-out Overtime Meets Minimum Duration
     * Employee stays 45m after shift -> meets 30m condition -> counts 45 minutes OT.
     */
    public function testPostCheckoutOvertimeMeetsMinimumDuration(): void
    {
        $policy = [
            'id'                                  => 'test-pol-6',
            'company_id'                          => 'comp-100',
            'enable_early_arrival_ot'             => false,
            'early_arrival_min_threshold_minutes' => 30,
            'enable_post_shift_ot'                => true,
            'post_shift_min_threshold_minutes'    => 30,
            'post_shift_grace_minutes'            => 0,
            'min_ot_unit_minutes'                 => 1,
            'rounding_mode'                       => 'exact',
            'normal_multiplier'                   => 1.5,
            'max_daily_ot_hours'                  => 8.0,
        ];

        $employee = ['id' => 'emp-006', 'company_id' => 'comp-100'];

        // Out at 17:45 (45 mins post shift)
        $attendanceLog = [
            'id'        => 'att-006',
            'date'      => '2026-11-01',
            'clock_in'  => '09:00',
            'clock_out' => '17:45',
        ];
        $shift = [
            'id'         => 'shift-001',
            'start_time' => '09:00',
            'end_time'   => '17:00',
        ];

        $res = $this->otService->calculateDailyOvertime($employee, $attendanceLog, $shift, $policy, []);

        $this->assertEquals(45, $res['raw_post_minutes']);
        $this->assertEquals(45, $res['payable_post_minutes']);
        $this->assertEquals(45, $res['payable_total_minutes']);
        $this->assertEquals(round(45 / 60, 2), $res['overtime_hours']);
    }

    /**
     * Test 7: Prevent Duplicate Overtime Counting
     * Persisting multiple calculations on the same date for the same employee
     * updates the existing record and eliminates duplicates.
     */
    public function testPreventDuplicateOvertimeCounting(): void
    {
        $calc1 = [
            'company_id'            => 'comp-100',
            'employee_id'           => 'emp-dup-01',
            'date'                  => '2026-11-01',
            'ot_type'               => 'Normal',
            'shift_start'           => '09:00',
            'shift_end'             => '17:00',
            'actual_in'             => '09:00',
            'actual_out'            => '18:00',
            'raw_early_minutes'     => 0,
            'raw_post_minutes'      => 60,
            'raw_total_minutes'     => 60,
            'payable_early_minutes' => 0,
            'payable_post_minutes'  => 60,
            'payable_total_minutes' => 60,
            'overtime_minutes'      => 60,
            'overtime_hours'        => 1.00,
            'base_salary'           => 30000.00,
            'hourly_rate'           => 125.00,
            'multiplier'            => 1.50,
            'ot_rate'               => 187.50,
            'ot_amount'             => 187.50,
            'approval_status'       => 'Pending',
            'is_settled'            => 0,
        ];

        $saved1 = $this->otService->persistRecord($calc1);

        $calc2 = $calc1;
        $calc2['payable_total_minutes'] = 90;
        $calc2['overtime_hours']        = 1.50;
        $calc2['ot_amount']             = 281.25;

        $saved2 = $this->otService->persistRecord($calc2);

        $db = Database::connect();
        $count = $db->table('overtime_records')
            ->where('employee_id', 'emp-dup-01')
            ->where('date', '2026-11-01')
            ->countAllResults();

        $this->assertEquals(1, $count, "Must prevent duplicate overtime records on the same calendar day");
        $this->assertEquals($saved1['id'], $saved2['id'], "Must reuse existing record ID");
        $this->assertEquals(1.50, (float)$saved2['overtime_hours']);
    }

    /**
     * Test 8: Ensure Payroll Uses Approved Overtime Amount Only
     * Records with 'Pending' or 'Rejected' status must not be included in payroll summaries.
     */
    public function testPayrollUsesApprovedOvertimeOnly(): void
    {
        $db = Database::connect();

        // 1. Approved record: 2.0 hrs, BDT 300
        $db->table('overtime_records')->insert([
            'id'                    => 'ot-rec-app-1',
            'company_id'            => 'comp-100',
            'employee_id'           => 'emp-pay-01',
            'date'                  => '2026-11-05',
            'ot_type'               => 'Normal',
            'payable_total_minutes' => 120,
            'overtime_hours'        => 2.00,
            'ot_amount'             => 300.00,
            'approval_status'       => 'Approved',
            'is_settled'            => 0,
        ]);

        // 2. Pending record: 1.5 hrs, BDT 225
        $db->table('overtime_records')->insert([
            'id'                    => 'ot-rec-pen-1',
            'company_id'            => 'comp-100',
            'employee_id'           => 'emp-pay-01',
            'date'                  => '2026-11-06',
            'ot_type'               => 'Normal',
            'payable_total_minutes' => 90,
            'overtime_hours'        => 1.50,
            'ot_amount'             => 225.00,
            'approval_status'       => 'Pending',
            'is_settled'            => 0,
        ]);

        // 3. Rejected record: 1.0 hr, BDT 150
        $db->table('overtime_records')->insert([
            'id'                    => 'ot-rec-rej-1',
            'company_id'            => 'comp-100',
            'employee_id'           => 'emp-pay-01',
            'date'                  => '2026-11-07',
            'ot_type'               => 'Normal',
            'payable_total_minutes' => 60,
            'overtime_hours'        => 1.00,
            'ot_amount'             => 150.00,
            'approval_status'       => 'Rejected',
            'is_settled'            => 0,
        ]);

        $summary = $this->otService->getSummaryForPayroll('emp-pay-01', '2026-11', 'comp-100');

        $this->assertEquals(2.00, $summary['approved_hours']);
        $this->assertEquals(300.00, $summary['ot_amount']);
        $this->assertEquals(1, $summary['record_count']);
        $this->assertEquals(['ot-rec-app-1'], $summary['record_ids']);
    }

    /**
     * Test 9: Threshold is an ELIGIBILITY condition, not a deduction.
     * Specification: shift end 16:00, checkout 17:00, min threshold 30 => eligible OT = 60 minutes (not 30).
     * If checkout 16:20 with min 30 => eligible OT = 0 minutes.
     */
    public function testThresholdIsEligibilityConditionNotDeduction(): void
    {
        $policy = [
            'id'                                  => 'test-pol-eligibility',
            'company_id'                          => 'comp-100',
            'enable_early_arrival_ot'             => false,
            'early_arrival_min_threshold_minutes' => 30,
            'enable_post_shift_ot'                => true,
            'post_shift_min_threshold_minutes'    => 30,
            'post_shift_grace_minutes'            => 0,
            'min_ot_unit_minutes'                 => 1,
            'rounding_mode'                       => 'exact',
            'normal_multiplier'                   => 1.5,
            'max_daily_ot_hours'                  => 8.0,
            'requires_post_approval'              => true,
        ];

        $employee = ['id' => 'emp-eligibility-01', 'company_id' => 'comp-100'];

        // Case A: Shift 08:00 - 16:00, Check-in 08:00, Checkout 17:00 (60 minutes post shift)
        $logA = [
            'id'        => 'att-elig-a',
            'date'      => '2026-11-01',
            'clock_in'  => '08:00',
            'clock_out' => '17:00',
        ];
        $shift = [
            'id'         => 'shift-001',
            'start_time' => '08:00',
            'end_time'   => '16:00',
        ];

        $resA = $this->otService->calculateDailyOvertime($employee, $logA, $shift, $policy, []);

        // Threshold of 30 was met; all 60 minutes qualify (NOT 60 - 30 = 30)
        $this->assertEquals(60, $resA['raw_post_minutes']);
        $this->assertEquals(60, $resA['payable_post_minutes'], "Threshold is eligibility condition, not deduction: must be 60 mins");
        $this->assertEquals(60, $resA['payable_total_minutes']);
        $this->assertEquals(1.00, $resA['overtime_hours'], "Must be exactly 1.00 hour of overtime (not 0.50)");

        $metaA = json_decode($resA['calculation_metadata_json'], true);
        $this->assertTrue($metaA['threshold_is_eligibility_condition']);
        $this->assertTrue($metaA['post_threshold_met']);

        // Case B: Shift 08:00 - 16:00, Check-in 08:00, Checkout 16:20 (20 minutes post shift, below 30 threshold)
        $logB = [
            'id'        => 'att-elig-b',
            'date'      => '2026-11-01',
            'clock_in'  => '08:00',
            'clock_out' => '16:20',
        ];

        $resB = $this->otService->calculateDailyOvertime($employee, $logB, $shift, $policy, []);

        $this->assertEquals(20, $resB['raw_post_minutes']);
        $this->assertEquals(0, $resB['payable_post_minutes'], "Below threshold must yield 0 payable minutes");
        $this->assertEquals(0, $resB['payable_total_minutes']);
        $this->assertEquals(0.00, $resB['overtime_hours']);

        $metaB = json_decode($resB['calculation_metadata_json'], true);
        $this->assertFalse($metaB['post_threshold_met']);
    }

    /**
     * Test 10: Weekly-Off Overtime Calculation
     * All worked hours on a weekly off day are counted as OT at the weekly_off_multiplier (2.0x).
     */
    public function testWeeklyOffOvertimeCalculation(): void
    {
        $policy = [
            'id'                                  => 'test-pol-woff',
            'company_id'                          => 'comp-100',
            'salary_basis'                        => 'Basic Salary',
            'divisor_mode'                        => 'Calendar Days',
            'standard_daily_hours'                => 8.0,
            'normal_multiplier'                   => 1.5,
            'weekly_off_multiplier'               => 2.0,
            'holiday_multiplier'                  => 2.0,
            'special_multiplier'                  => 2.5,
            'min_ot_unit_minutes'                 => 1,
            'rounding_mode'                       => 'exact',
            'max_daily_ot_hours'                  => 12.0,
            'requires_post_approval'              => true,
            'money_decimals'                      => 2,
        ];

        $employee = [
            'id'           => 'emp-woff-01',
            'company_id'   => 'comp-100',
            'basic_salary' => 30000.00,
        ];

        // Sunday (weekly off) - worked 09:00 to 17:00 (8 hours = 480 mins)
        $attendanceLog = [
            'id'        => 'att-woff-01',
            'date'      => '2026-11-08', // Sunday
            'clock_in'  => '09:00',
            'clock_out' => '17:00',
        ];

        $shift = [
            'id'           => 'shift-woff',
            'start_time'   => '09:00',
            'end_time'     => '17:00',
            'is_day_off'   => 1,
            'outcome'      => 'ROSTER_DAY_OFF',
            'weekend_days' => 'Sunday',
        ];

        $res = $this->otService->calculateDailyOvertime($employee, $attendanceLog, $shift, $policy, []);

        $this->assertEquals('Weekly Off', $res['ot_type']);
        $this->assertEquals(2.0, $res['multiplier']);
        $this->assertEquals(480, $res['payable_total_minutes']);
        $this->assertEquals(8.00, $res['overtime_hours']);
        $this->assertEquals('Pending', $res['approval_status']);
    }

    /**
     * Test 11: Holiday Overtime Calculation
     * Worked hours on a gazetted holiday are counted as OT at the holiday_multiplier (2.0x).
     */
    public function testHolidayOvertimeCalculation(): void
    {
        $policy = [
            'id'                                  => 'test-pol-hol',
            'company_id'                          => 'comp-100',
            'salary_basis'                        => 'Basic Salary',
            'divisor_mode'                        => 'Calendar Days',
            'standard_daily_hours'                => 8.0,
            'normal_multiplier'                   => 1.5,
            'weekly_off_multiplier'               => 2.0,
            'holiday_multiplier'                  => 2.0,
            'special_multiplier'                  => 2.5,
            'min_ot_unit_minutes'                 => 1,
            'rounding_mode'                       => 'exact',
            'max_daily_ot_hours'                  => 12.0,
            'requires_post_approval'              => true,
            'money_decimals'                      => 2,
        ];

        $employee = [
            'id'           => 'emp-hol-01',
            'company_id'   => 'comp-100',
            'basic_salary' => 30000.00,
        ];

        $attendanceLog = [
            'id'        => 'att-hol-01',
            'date'      => '2026-12-16', // Victory Day Holiday
            'clock_in'  => '09:00',
            'clock_out' => '15:00',      // 6 hours worked
        ];

        $shift = [
            'id'         => 'shift-normal',
            'start_time' => '09:00',
            'end_time'   => '17:00',
        ];

        $holidays = [
            [
                'id'         => 'hol-vic-2026',
                'company_id' => 'comp-100',
                'name'       => 'Victory Day',
                'start_date' => '2026-12-16',
                'end_date'   => '2026-12-16',
                'status'     => 'Published',
            ],
        ];

        $res = $this->otService->calculateDailyOvertime($employee, $attendanceLog, $shift, $policy, $holidays);

        $this->assertEquals('Holiday', $res['ot_type']);
        $this->assertEquals(2.0, $res['multiplier']);
        $this->assertEquals(360, $res['payable_total_minutes']);
        $this->assertEquals(6.00, $res['overtime_hours']);
        $this->assertEquals('Pending', $res['approval_status']);
    }

    /**
     * Test 12: Special Duty Overtime Calculation
     * Special duty uses special_multiplier (2.5x) and treats worked hours as OT.
     */
    public function testSpecialDutyOvertimeCalculation(): void
    {
        $policy = [
            'id'                                  => 'test-pol-sd',
            'company_id'                          => 'comp-100',
            'salary_basis'                        => 'Basic Salary',
            'divisor_mode'                        => 'Calendar Days',
            'standard_daily_hours'                => 8.0,
            'normal_multiplier'                   => 1.5,
            'weekly_off_multiplier'               => 2.0,
            'holiday_multiplier'                  => 2.0,
            'special_multiplier'                  => 2.5,
            'min_ot_unit_minutes'                 => 1,
            'rounding_mode'                       => 'exact',
            'max_daily_ot_hours'                  => 12.0,
            'requires_post_approval'              => true,
            'money_decimals'                      => 2,
        ];

        $employee = [
            'id'           => 'emp-sd-01',
            'company_id'   => 'comp-100',
            'basic_salary' => 30000.00,
        ];

        $attendanceLog = [
            'id'        => 'att-sd-01',
            'date'      => '2026-11-10',
            'clock_in'  => '10:00',
            'clock_out' => '16:00', // 6 hours
        ];

        $shift = [
            'id'         => 'shift-normal',
            'start_time' => '09:00',
            'end_time'   => '17:00',
        ];

        // Seed duty assignment table mock if table exists or mock dutyModel
        $dutyMock = $this->createMock(\App\Models\DutyAssignmentModel::class);
        $dutyMock->method('getDutyForEmployeeDate')->willReturn([
            'id'           => 'duty-spec-01',
            'duty_type'    => 'SPECIAL_DUTY',
            'ot_treatment' => 'All Worked Hours as OT',
        ]);
        $dutyMock->method('isEmployeeOvertimeEligible')->willReturn(true);

        // Inject duty mock
        $ref = new \ReflectionClass($this->otService);
        $prop = $ref->getProperty('dutyModel');
        $prop->setAccessible(true);
        $prop->setValue($this->otService, $dutyMock);

        $res = $this->otService->calculateDailyOvertime($employee, $attendanceLog, $shift, $policy, []);

        $this->assertEquals('Special Duty', $res['ot_type']);
        $this->assertEquals(2.5, $res['multiplier']);
        $this->assertEquals(360, $res['payable_total_minutes']);
        $this->assertEquals(6.00, $res['overtime_hours']);
        $this->assertEquals('Pending', $res['approval_status']);

        $meta = json_decode($res['calculation_metadata_json'], true);
        $this->assertTrue($meta['is_special_duty']);
    }

    /**
     * Test 13: Overnight Shift Overlap Anti-Double-Counting
     * Yesterday's shift ended overnight with checkout at 07:00 today.
     * Today's shift starts at 08:00, and employee checks in at 06:30.
     * The 30 minutes from 06:30 to 07:00 belongs to yesterday's checkout interval.
     * OvertimeCalculationService clamps today's early check-in start to 07:00.
     * Result: Only 60 minutes (07:00 to 08:00) qualifies for today's early check-in OT,
     * preventing 30 minutes of double counting.
     */
    public function testOvernightShiftAndOverlapWithPreviousNightShift(): void
    {
        $policy = [
            'id'                                  => 'test-pol-overlap',
            'company_id'                          => 'comp-100',
            'enable_early_arrival_ot'             => true,
            'early_arrival_min_threshold_minutes' => 30,
            'early_arrival_grace_minutes'         => 0,
            'enable_post_shift_ot'                => false,
            'post_shift_min_threshold_minutes'    => 30,
            'min_ot_unit_minutes'                 => 1,
            'rounding_mode'                       => 'exact',
            'normal_multiplier'                   => 1.5,
            'max_daily_ot_hours'                  => 8.0,
            'requires_post_approval'              => true,
        ];

        $employee = ['id' => 'emp-overnight-01', 'company_id' => 'comp-100'];

        // Today's attendance log with previous log attached
        $attendanceLog = [
            'id'                  => 'att-today-01',
            'date'                => '2026-11-02',
            'clock_in'            => '06:30',
            'clock_out'           => '16:00',
            'prev_attendance_log' => [
                'id'            => 'att-yest-01',
                'date'          => '2026-11-01',
                'check_in'      => '23:00',
                'check_out'     => '07:00', // Overnight checkout into today
                'checkout_date' => '2026-11-02',
            ],
        ];

        // Shift 08:00 - 16:00
        $shift = [
            'id'         => 'shift-day-01',
            'start_time' => '08:00',
            'end_time'   => '16:00',
        ];

        $res = $this->otService->calculateDailyOvertime($employee, $attendanceLog, $shift, $policy, []);

        // Effective early arrival is from 07:00 to 08:00 = 60 minutes (not 90 minutes)
        $this->assertEquals(60, $res['raw_early_minutes'], "Raw early minutes must exclude the 30 mins overlapping previous day's shift");
        $this->assertEquals(60, $res['payable_early_minutes']);
        $this->assertEquals(60, $res['payable_total_minutes']);
        $this->assertEquals(1.00, $res['overtime_hours']);

        $meta = json_decode($res['calculation_metadata_json'], true);
        $this->assertTrue($meta['anti_double_counting']['overnight_overlap_detected']);
        $this->assertEquals('07:00', $meta['anti_double_counting']['prev_day_checkout']);
        $this->assertEquals(30, $meta['anti_double_counting']['overlap_deducted_minutes']);
    }

    /**
     * Test 14: Overtime Not Auto-Approved and Stores Complete Breakdown
     * Overtime must never be auto-approved (defaults to Pending).
     * Calculation breakdown must be stored in calculation_metadata_json.
     */
    public function testOvertimeNotAutoApprovedAndStoresCalculationBreakdown(): void
    {
        $policy = [
            'id'                                  => 'test-pol-noauto',
            'company_id'                          => 'comp-100',
            'enable_early_arrival_ot'             => true,
            'early_arrival_min_threshold_minutes' => 30,
            'enable_post_shift_ot'                => true,
            'post_shift_min_threshold_minutes'    => 30,
            'min_ot_unit_minutes'                 => 1,
            'rounding_mode'                       => 'exact',
            'normal_multiplier'                   => 1.5,
            'max_daily_ot_hours'                  => 8.0,
            'requires_post_approval'              => true,
        ];

        $employee = ['id' => 'emp-noauto-01', 'company_id' => 'comp-100'];

        $attendanceLog = [
            'id'        => 'att-noauto-01',
            'date'      => '2026-11-01',
            'clock_in'  => '08:15', // 45m early
            'clock_out' => '17:45', // 45m post
        ];
        $shift = [
            'id'         => 'shift-001',
            'start_time' => '09:00',
            'end_time'   => '17:00',
        ];

        $res = $this->otService->calculateDailyOvertime($employee, $attendanceLog, $shift, $policy, []);

        // Status MUST be 'Pending', not 'Approved'
        $this->assertEquals('Pending', $res['approval_status'], "Overtime must NOT be auto-approved");
        $this->assertEquals(1.50, $res['overtime_hours']);

        // Persist record
        $saved = $this->otService->persistRecord($res);
        $this->assertEquals('Pending', $saved['approval_status']);
        $this->assertNotNull($saved['calculation_metadata_json']);

        $meta = json_decode($saved['calculation_metadata_json'], true);
        $this->assertIsArray($meta);
        $this->assertEquals(45, $meta['raw_early_minutes']);
        $this->assertEquals(45, $meta['raw_post_minutes']);
        $this->assertEquals(45, $meta['payable_early_minutes']);
        $this->assertEquals(45, $meta['payable_post_minutes']);
        $this->assertTrue($meta['early_threshold_met']);
        $this->assertTrue($meta['post_threshold_met']);
        $this->assertTrue($meta['threshold_is_eligibility_condition']);
    }

    /**
     * Test 15: OvertimeService facade operates with identical API
     */
    public function testOvertimeServiceFacade(): void
    {
        $this->assertInstanceOf(OvertimeCalculationService::class, $this->facadeService);
        $this->assertTrue(method_exists($this->facadeService, 'calculateDailyOvertime'));
        $this->assertTrue(method_exists($this->facadeService, 'resolvePolicy'));
        $this->assertTrue(method_exists($this->facadeService, 'persistRecord'));
        $this->assertTrue(method_exists($this->facadeService, 'approveRecord'));
        $this->assertTrue(method_exists($this->facadeService, 'getSummaryForPayroll'));
    }
}

