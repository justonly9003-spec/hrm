<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobileDocumentDownloadTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;
    private array $testFilesCreated = [];

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);

        $this->db->query("DROP TABLE IF EXISTS employee_documents");
        $this->db->query("CREATE TABLE employee_documents (
            id VARCHAR(36) PRIMARY KEY,
            employee_id VARCHAR(36),
            company_id VARCHAR(36) NULL,
            document_type VARCHAR(50),
            title VARCHAR(150),
            file_path VARCHAR(255),
            file_size INT NULL,
            expiry_date DATE NULL,
            employee_visible INT DEFAULT 0,
            created_at DATETIME NULL
        )");
    }

    protected function tearDown(): void
    {
        foreach ($this->testFilesCreated as $file) {
            if (is_file($file)) {
                @unlink($file);
            }
        }
        parent::tearDown();
    }

    private function token(string $company = 'ACME', string $id = 'rahim'): array
    {
        $res = $this->withBodyFormat('json')->call('post', 'api/mobile/v1/auth/login', [
            'company_code' => $company,
            'identifier'   => $id,
            'password'     => self::PASSWORD,
            'device'       => ['device_uid' => 'dev-doc-1'],
        ]);
        $json = json_decode($res->getJSON(), true);
        return ['Authorization' => 'Bearer ' . ($json['data']['tokens']['access_token'] ?? '')];
    }

    private function json($res): array
    {
        return json_decode($res->getJSON(), true) ?? [];
    }

    private function createPhysicalFile(string $subpath, string $content): string
    {
        $targetDir = rtrim(WRITEPATH, '/\\') . '/uploads/documents/' . dirname($subpath);
        if (!is_dir($targetDir)) {
            @mkdir($targetDir, 0750, true);
        }
        $fullPath = rtrim(WRITEPATH, '/\\') . '/uploads/documents/' . $subpath;
        file_put_contents($fullPath, $content);
        $this->testFilesCreated[] = $fullPath;
        return $fullPath;
    }

    public function testDocumentDownloadRequiresAuthentication(): void
    {
        $res = $this->get('api/mobile/v1/documents/doc-1/download');
        $res->assertStatus(401);

        $resV1 = $this->get('api/v1/documents/doc-1/download');
        $resV1->assertStatus(401);
    }

    public function testValidDocumentDownloadReturnsCorrectFileAndHeaders(): void
    {
        $content = "%PDF-1.4\n%Authentic document content for Rahim\n%%EOF";
        $relPath = 'c-1/e-1/rahim_offer.pdf';
        $this->createPhysicalFile($relPath, $content);

        $this->db->table('employee_documents')->insert([
            'id'               => 'doc-offer-1',
            'employee_id'      => 'e-1',
            'company_id'       => 'c-1',
            'document_type'    => 'Offer',
            'title'            => 'Official Offer Letter',
            'file_path'        => 'uploads/documents/' . $relPath,
            'file_size'        => strlen($content),
            'employee_visible' => 1,
            'created_at'       => date('Y-m-d H:i:s'),
        ]);

        $res = $this->withHeaders($this->token())->get('api/mobile/v1/documents/doc-offer-1/download');
        $res->assertStatus(200);

        // Verification of safe download headers
        $this->assertStringContainsString('attachment', (string)$res->response()->getHeaderLine('Content-Disposition'));
        $this->assertStringContainsString('Official_Offer_Letter.pdf', (string)$res->response()->getHeaderLine('Content-Disposition'));
        $this->assertSame('nosniff', (string)$res->response()->getHeaderLine('X-Content-Type-Options'));
        $this->assertStringContainsString('private', (string)$res->response()->getHeaderLine('Cache-Control'));
        $this->assertSame((string)strlen($content), (string)$res->response()->getHeaderLine('Content-Length'));

        // Response body matches raw file bytes
        $this->assertSame($content, $res->response()->getBody());
    }

    public function testDocumentDownloadInlineDisposition(): void
    {
        $content = "Sample text compliance document";
        $relPath = 'c-1/e-1/policy.txt';
        $this->createPhysicalFile($relPath, $content);

        $this->db->table('employee_documents')->insert([
            'id'               => 'doc-inline-1',
            'employee_id'      => 'e-1',
            'company_id'       => 'c-1',
            'document_type'    => 'Policy',
            'title'            => 'Employee Handbook',
            'file_path'        => 'uploads/documents/' . $relPath,
            'file_size'        => strlen($content),
            'employee_visible' => 1,
            'created_at'       => date('Y-m-d H:i:s'),
        ]);

        $res = $this->withHeaders($this->token())->get('api/mobile/v1/documents/doc-inline-1/download?disposition=inline');
        $res->assertStatus(200);
        $this->assertStringContainsString('inline', (string)$res->response()->getHeaderLine('Content-Disposition'));
    }

    public function testDocumentDownloadJsonMetadataFormat(): void
    {
        $content = "Metadata test document bytes";
        $relPath = 'c-1/e-1/meta_test.pdf';
        $this->createPhysicalFile($relPath, $content);

        $this->db->table('employee_documents')->insert([
            'id'               => 'doc-meta-1',
            'employee_id'      => 'e-1',
            'company_id'       => 'c-1',
            'document_type'    => 'Contract',
            'title'            => 'Contract Agreement',
            'file_path'        => 'uploads/documents/' . $relPath,
            'file_size'        => strlen($content),
            'employee_visible' => 1,
            'created_at'       => '2026-10-30 10:00:00',
        ]);

        $res = $this->withHeaders($this->token())->get('api/mobile/v1/documents/doc-meta-1/download?format=json');
        $res->assertStatus(200);

        $json = $this->json($res);
        $this->assertTrue($json['success']);
        $this->assertSame('doc-meta-1', $json['data']['document_id']);
        $this->assertStringContainsString('Contract_Agreement.pdf', $json['data']['title']);
        $this->assertSame(strlen($content), $json['data']['file_size']);
        $this->assertStringContainsString('api/mobile/v1/documents/doc-meta-1/download', $json['data']['download_url']);
    }

    public function testDocumentShowDetailEndpoint(): void
    {
        $this->db->table('employee_documents')->insert([
            'id'               => 'doc-show-1',
            'employee_id'      => 'e-1',
            'company_id'       => 'c-1',
            'document_type'    => 'ID_Proof',
            'title'            => 'National ID Card',
            'file_path'        => 'uploads/documents/c-1/e-1/nid.jpg',
            'file_size'        => 54321,
            'employee_visible' => 1,
            'created_at'       => '2026-10-30 12:00:00',
        ]);

        $res = $this->withHeaders($this->token())->get('api/mobile/v1/documents/doc-show-1');
        $res->assertStatus(200);

        $json = $this->json($res);
        $this->assertTrue($json['success']);
        $this->assertSame('doc-show-1', $json['data']['document']['id']);
        $this->assertStringContainsString('National_ID_Card', $json['data']['document']['title']);
        $this->assertStringContainsString('api/mobile/v1/documents/doc-show-1/download', $json['data']['document']['download_url']);
    }

    public function testHiddenDocumentCannotBeDownloadedAndReturns404(): void
    {
        $content = "Secret internal evaluation";
        $relPath = 'c-1/e-1/secret_review.pdf';
        $this->createPhysicalFile($relPath, $content);

        $this->db->table('employee_documents')->insert([
            'id'               => 'doc-secret-1',
            'employee_id'      => 'e-1',
            'company_id'       => 'c-1',
            'document_type'    => 'Performance',
            'title'            => 'Confidential HR Review',
            'file_path'        => 'uploads/documents/' . $relPath,
            'file_size'        => strlen($content),
            'employee_visible' => 0, // HR-only, hidden from mobile app
            'created_at'       => date('Y-m-d H:i:s'),
        ]);

        $res = $this->withHeaders($this->token())->get('api/mobile/v1/documents/doc-secret-1/download');
        $res->assertStatus(404);
        $this->assertFalse($this->json($res)['success']);

        // Show endpoint also rejects hidden document
        $resShow = $this->withHeaders($this->token())->get('api/mobile/v1/documents/doc-secret-1');
        $resShow->assertStatus(404);
    }

    public function testOtherEmployeeDocumentInSameCompanyReturns404(): void
    {
        // Add another employee e-colleague in the same company c-1
        $this->db->table('employees')->insert([
            'id'            => 'e-colleague',
            'company_id'    => 'c-1',
            'employee_code' => 'EMP-COL-1',
            'first_name'    => 'Faruk',
            'last_name'     => 'Hossain',
            'status'        => 'Active',
        ]);

        $content = "Colleague personal payslip/doc";
        $relPath = 'c-1/e-colleague/colleague_doc.pdf';
        $this->createPhysicalFile($relPath, $content);

        $this->db->table('employee_documents')->insert([
            'id'               => 'doc-colleague-1',
            'employee_id'      => 'e-colleague',
            'company_id'       => 'c-1',
            'document_type'    => 'Tax',
            'title'            => 'Colleague Tax Certificate',
            'file_path'        => 'uploads/documents/' . $relPath,
            'file_size'        => strlen($content),
            'employee_visible' => 1,
            'created_at'       => date('Y-m-d H:i:s'),
        ]);

        // Rahim (e-1) attempts to download Faruk's (e-colleague) document
        $res = $this->withHeaders($this->token('ACME', 'rahim'))->get('api/mobile/v1/documents/doc-colleague-1/download');
        $res->assertStatus(404);
    }

    public function testCrossTenantDocumentAccessReturns404(): void
    {
        $content = "Karim's document in company OTHER (c-2)";
        $relPath = 'c-2/e-2/karim_doc.pdf';
        $this->createPhysicalFile($relPath, $content);

        $this->db->table('employee_documents')->insert([
            'id'               => 'doc-other-tenant',
            'employee_id'      => 'e-2',
            'company_id'       => 'c-2',
            'document_type'    => 'Contract',
            'title'            => 'Other Tenant Contract',
            'file_path'        => 'uploads/documents/' . $relPath,
            'file_size'        => strlen($content),
            'employee_visible' => 1,
            'created_at'       => date('Y-m-d H:i:s'),
        ]);

        // Rahim (c-1 / e-1) attempts to access document belonging to c-2 / e-2
        $res = $this->withHeaders($this->token('ACME', 'rahim'))->get('api/mobile/v1/documents/doc-other-tenant/download');
        $res->assertStatus(404);
    }

    public function testMissingDatabaseRecordReturns404(): void
    {
        $res = $this->withHeaders($this->token())->get('api/mobile/v1/documents/non-existent-doc-id/download');
        $res->assertStatus(404);
    }

    public function testMissingPhysicalFileOnDiskReturns404WithoutLeakingPaths(): void
    {
        $this->db->table('employee_documents')->insert([
            'id'               => 'doc-missing-file',
            'employee_id'      => 'e-1',
            'company_id'       => 'c-1',
            'document_type'    => 'Certificate',
            'title'            => 'Graduation Certificate',
            'file_path'        => 'uploads/documents/c-1/e-1/ghost_file.pdf',
            'file_size'        => 12345,
            'employee_visible' => 1,
            'created_at'       => date('Y-m-d H:i:s'),
        ]);

        $res = $this->withHeaders($this->token())->get('api/mobile/v1/documents/doc-missing-file/download');
        $res->assertStatus(404);

        $rawBody = $res->getJSON();
        $this->assertStringNotContainsString('ghost_file.pdf', $rawBody);
        $this->assertStringNotContainsString(WRITEPATH, $rawBody);
        $this->assertStringNotContainsString('writable', $rawBody);
    }

    public function testPathTraversalAttemptInFilePathRejected(): void
    {
        $this->db->table('employee_documents')->insert([
            'id'               => 'doc-traversal-1',
            'employee_id'      => 'e-1',
            'company_id'       => 'c-1',
            'document_type'    => 'System',
            'title'            => 'System Passwd Attempt',
            'file_path'        => '../../../../etc/passwd',
            'file_size'        => 500,
            'employee_visible' => 1,
            'created_at'       => date('Y-m-d H:i:s'),
        ]);

        $res = $this->withHeaders($this->token())->get('api/mobile/v1/documents/doc-traversal-1/download');
        $res->assertStatus(404);
        $this->assertStringNotContainsString('root:', (string)$res->response()->getBody());
    }

    public function testPathTraversalAttemptInDocumentIdRejected(): void
    {
        $res = $this->withHeaders($this->token())->get('api/mobile/v1/documents/..%2f..%2fetc%2fpasswd/download');
        // Traversal route or sanitized ID is rejected (404)
        $this->assertTrue(in_array($res->response()->getStatusCode(), [400, 404], true));
    }

    public function testInactiveOrSeparatedEmployeeCannotDownloadDocument(): void
    {
        $content = "Separated employee doc";
        $relPath = 'c-1/e-1/separated_doc.pdf';
        $this->createPhysicalFile($relPath, $content);

        $this->db->table('employee_documents')->insert([
            'id'               => 'doc-separated-1',
            'employee_id'      => 'e-1',
            'company_id'       => 'c-1',
            'document_type'    => 'General',
            'title'            => 'General Document',
            'file_path'        => 'uploads/documents/' . $relPath,
            'file_size'        => strlen($content),
            'employee_visible' => 1,
            'created_at'       => date('Y-m-d H:i:s'),
        ]);

        // Change employee status to Terminated
        $this->db->table('employees')->where('id', 'e-1')->update(['status' => 'Terminated']);

        $res = $this->withHeaders($this->token())->get('api/mobile/v1/documents/doc-separated-1/download');
        $res->assertStatus(403);
    }

    public function testIdorTamperingViaQueryParamRejected(): void
    {
        $content = "IDOR probe doc";
        $relPath = 'c-1/e-1/idor_probe.pdf';
        $this->createPhysicalFile($relPath, $content);

        $this->db->table('employee_documents')->insert([
            'id'               => 'doc-idor-1',
            'employee_id'      => 'e-1',
            'company_id'       => 'c-1',
            'document_type'    => 'General',
            'title'            => 'General Document',
            'file_path'        => 'uploads/documents/' . $relPath,
            'file_size'        => strlen($content),
            'employee_visible' => 1,
            'created_at'       => date('Y-m-d H:i:s'),
        ]);

        // Attempting to specify employee_id of another employee via query string
        $res = $this->withHeaders($this->token())->get('api/mobile/v1/documents/doc-idor-1/download?employee_id=e-2');
        $this->assertTrue(in_array($res->response()->getStatusCode(), [403, 404], true));

        // Attempting to specify company_id of another tenant via query string
        $resTenant = $this->withHeaders($this->token())->get('api/mobile/v1/documents/doc-idor-1/download?company_id=c-2');
        $this->assertTrue(in_array($resTenant->response()->getStatusCode(), [403, 404], true));
    }
}
