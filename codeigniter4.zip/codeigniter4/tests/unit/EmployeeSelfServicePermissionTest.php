<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\PermissionService;
use App\Services\PermissionDecision;
use Config\Permissions as PermissionsConfig;

/**
 * Unit Tests for Employee Self-Service Permissions & Scope Isolation
 */
class EmployeeSelfServicePermissionTest extends TestCase
{
    /**
     * Test that isImplicitSelfService() does NOT grant module-wide 'view'
     * for leaves, payroll, attendance, etc., and only grants dashboard.view or self-actions.
     */
    public function testIsImplicitSelfServiceTightened()
    {
        $permService = new PermissionService();
        $ref = new \ReflectionClass($permService);
        $method = $ref->getMethod('isImplicitSelfService');
        $method->setAccessible(true);

        // Module-wide 'view' MUST NOT be implicit
        $this->assertFalse($method->invoke($permService, 'leave', 'view'), "leave.view must not be implicit");
        $this->assertFalse($method->invoke($permService, 'leaves', 'view'), "leaves.view must not be implicit");
        $this->assertFalse($method->invoke($permService, 'payroll', 'view'), "payroll.view must not be implicit");
        $this->assertFalse($method->invoke($permService, 'attendance', 'view'), "attendance.view must not be implicit");
        $this->assertFalse($method->invoke($permService, 'pf', 'view'), "pf.view must not be implicit");
        $this->assertFalse($method->invoke($permService, 'bonus', 'view'), "bonus.view must not be implicit");

        // Personal dashboard view is allowed
        $this->assertTrue($method->invoke($permService, 'dashboard', 'view'), "dashboard.view is implicit for linked employee");

        // Genuinely self-scoped actions remain allowed
        $this->assertTrue($method->invoke($permService, 'attendance', 'clock'), "attendance.clock is implicit self-action");
        $this->assertTrue($method->invoke($permService, 'attendance', 'regularize'), "attendance.regularize is implicit self-action");
        $this->assertTrue($method->invoke($permService, 'payroll', 'payslip'), "payroll.payslip is implicit self-action");
        $this->assertTrue($method->invoke($permService, 'payslip', 'own'), "payslip.own is implicit self-action");
    }

    /**
     * Test that Config\Permissions::$roleDefaultMatrix['employee'] defines the canonical
     * 18 self-service permissions with scope='self'.
     */
    public function testCanonicalEmployeePermissionsDefined()
    {
        $config = new PermissionsConfig();
        $employeeSpec = $config->roleDefaultMatrix['employee'] ?? null;

        $this->assertNotNull($employeeSpec, "roleDefaultMatrix must define 'employee'");
        $this->assertEquals('self', $employeeSpec['scope'] ?? '', "Employee role default scope must be 'self'");

        $requiredCodes = [
            'dashboard.view',
            'directory.view',
            'attendance.view', 'attendance.clock', 'attendance.regularize',
            'rostering.view',
            'leaves.view', 'leaves.create', 'leaves.cancel',
            'payroll.view',
            'bonus.view',
            'loans.view', 'loans.create',
            'assets.view',
            'training.view',
            'performance.view', 'performance.create',
            'medical_insurance.view', 'medical_insurance.create',
            'company_expense.view', 'company_expense.create',
            'notices.view',
            'notifications.view',
        ];

        $perms = $employeeSpec['permissions'] ?? [];
        foreach ($requiredCodes as $code) {
            $this->assertContains($code, $perms, "Employee role must explicitly have permission {$code}");
        }
    }

    /**
     * Test that assertInScope() strictly enforces scope='self':
     * An employee can access their own record, but is DENIED other employees' records.
     */
    public function testAssertInScopeEnforcesSelfScope()
    {
        $permService = new PermissionService();

        $user = [
            'id'          => 'usr-emp-01',
            'username'    => 'john.doe',
            'role_code'   => 'employee',
            'company_id'  => 'comp-alpha',
            'employee_id' => 'emp-101',
        ];

        $selfDecision = new PermissionDecision(true, 'self', 'employee', 'leaves.view');

        // 1. Own employee record -> MUST BE ALLOWED
        $ownRecord = ['id' => 'emp-101', 'company_id' => 'comp-alpha'];
        $this->assertTrue(
            $permService->assertInScope($user, $selfDecision, $ownRecord),
            "assertInScope must allow employee accessing own employee record by id"
        );

        $ownRecordByEmpId = ['employee_id' => 'emp-101', 'company_id' => 'comp-alpha'];
        $this->assertTrue(
            $permService->assertInScope($user, $selfDecision, $ownRecordByEmpId),
            "assertInScope must allow employee accessing own record by employee_id"
        );

        // 2. Other employee's record -> MUST BE DENIED
        $otherRecord = ['id' => 'emp-102', 'company_id' => 'comp-alpha'];
        $this->assertFalse(
            $permService->assertInScope($user, $selfDecision, $otherRecord),
            "assertInScope must DENY employee accessing another employee's record"
        );

        $otherRecordByEmpId = ['employee_id' => 'emp-999', 'company_id' => 'comp-alpha'];
        $this->assertFalse(
            $permService->assertInScope($user, $selfDecision, $otherRecordByEmpId),
            "assertInScope must DENY employee accessing record belonging to employee emp-999"
        );
    }

    /**
     * Test that the employee role matrix strictly excludes all administrative permissions.
     */
    public function testEmployeeRoleDeniedAdministrativeActions()
    {
        $config = new PermissionsConfig();
        $perms = $config->roleDefaultMatrix['employee']['permissions'] ?? [];

        $adminPermissions = [
            'leave.manage',
            'leaves.manage',
            'leave.hr_approve',
            'leaves.hr_approve',
            'leave.balance_adjust',
            'payroll.generate',
            'payroll.disburse',
            'payroll.manage',
            'attendance.create',
            'attendance.device_manage',
            'attendance.manage',
            'system.manage',
            'platform.admin',
            'settings.manage',
        ];

        foreach ($adminPermissions as $adminPerm) {
            $this->assertNotContains(
                $adminPerm,
                $perms,
                "Employee role must NOT contain administrative permission {$adminPerm}"
            );
        }
    }
}
