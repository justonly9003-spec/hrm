<?php

namespace Tests\Unit;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;
use Config\Database;
use Tests\Unit\Support\MobileTestSchema;

require_once __DIR__ . '/Support/MobileTestSchema.php';

/**
 * Validates CSRF exemption rules and mobileAuth protection for Mobile API v1 routes.
 */
#[\PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses]
#[\PHPUnit\Framework\Attributes\PreserveGlobalState(false)]
class MobileApiCsrfExemptionTest extends CIUnitTestCase
{
    use FeatureTestTrait;
    use MobileTestSchema;

    protected $db;
    private array $device = ['device_uid' => 'dev-test-1', 'platform' => 'android'];

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Database::connect();
        $this->buildMobileSchema($this->db);
    }

    private function readConfigFile(string $relativePath): string
    {
        $base = dirname(__DIR__, 2);
        $full = $base . '/' . ltrim($relativePath, '/');
        $this->assertFileExists($full);
        return (string)file_get_contents($full);
    }

    /**
     * Confirms that Filters.php exempts token-authenticated mobile paths,
     * but strictly avoids exempting blanket api/v1/*
     */
    public function testCsrfFilterExemptsOnlySpecifiedMobileV1Paths(): void
    {
        $content = $this->readConfigFile('app/Config/Filters.php');

        $requiredExemptions = [
            'api/v1/auth/*',
            'api/v1/attendance/*',
            'api/v1/leave/*',
            'api/v1/overtime/*',
            'api/v1/notifications/*',
        ];

        foreach ($requiredExemptions as $pattern) {
            $this->assertStringContainsString(
                "'{$pattern}'",
                $content,
                "CSRF except list in Filters.php must contain '{$pattern}'"
            );
        }

        // Must NOT exempt all of api/v1/* because biometric, scheduled-jobs, system diagnose have distinct rules
        $this->assertDoesNotMatchRegularExpression(
            "/['\"]api\\/v1\\/\\*['\"]/",
            $content,
            "Filters.php must NOT contain blanket 'api/v1/*' in CSRF exemptions"
        );
    }

    /**
     * Confirms every exempted route under api/v1 except auth/login and auth/refresh
     * is protected by the mobileAuth filter.
     */
    public function testEveryExemptedRouteExceptLoginAndRefreshIsBehindMobileAuth(): void
    {
        $routesContent = $this->readConfigFile('app/Config/Routes.php');

        // Locate the api/v1 route group block
        $this->assertMatchesRegularExpression(
            '/\\$routes->group\\(\'api\\/v1\',\s*\\[\'namespace\'\s*=>\s*\'App\\\\Controllers\\\\Mobile\'\\]/',
            $routesContent
        );

        // Public authentication routes
        $this->assertMatchesRegularExpression(
            "/\\$routes->post\\('auth\\/login',\\s*'MobileAuthController::login'\\);/",
            $routesContent
        );
        $this->assertMatchesRegularExpression(
            "/\\$routes->post\\('auth\\/refresh',\\s*'MobileAuthController::refresh'\\);/",
            $routesContent
        );

        // All other routes within the exempted path prefixes must enforce mobileAuth filter
        $guardedMobileRoutes = [
            'auth/logout',
            'auth/me',
            'attendance/today',
            'attendance/history',
            'attendance/check-in',
            'attendance/check-out',
            'leave/types',
            'leave/balances',
            'leave/applications',
            'leave/apply',
            'leave/(:segment)/cancel',
            'overtime/claims',
            'notifications',
            'notifications/read-all',
            'notifications/(:segment)/read',
        ];

        foreach ($guardedMobileRoutes as $routePath) {
            $pattern = '#\\$routes->(get|post)\\(\'' . preg_quote($routePath, '#') . '\'[^\\n]*\'filter\' => \'mobileAuth\'#';
            $this->assertMatchesRegularExpression(
                $pattern,
                $routesContent,
                "Route {$routePath} must be guarded by 'filter' => 'mobileAuth'"
            );
        }
    }

    /**
     * Tests that POST api/v1/auth/login without a CSRF token does not return 403 from CSRF.
     */
    public function testPostLoginWithoutCsrfTokenDoesNotReturn403(): void
    {
        // Issue POST request to api/v1/auth/login with NO CSRF token
        $res = $this->withBodyFormat('json')->call('post', 'api/v1/auth/login', [
            'company_code' => 'ACME',
            'identifier'   => 'rahim',
            'password'     => 'wrong-password',
            'device'       => $this->device,
        ]);

        $statusCode = $res->response()->getStatusCode();

        // If CSRF blocked it, it would be 403. It must not be 403.
        $this->assertNotSame(
            403,
            $statusCode,
            "POST api/v1/auth/login without a CSRF token must not return 403 from CSRF filter"
        );

        // Invalid credentials should return 401 Unauthorized from the controller
        $this->assertSame(401, $statusCode);

        $json = json_decode($res->getJSON(), true);
        $this->assertFalse($json['success']);
    }
}
