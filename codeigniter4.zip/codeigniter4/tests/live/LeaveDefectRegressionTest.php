<?php

namespace Tests\Live;

use PHPUnit\Framework\TestCase;
use Config\Database;
use App\Services\LeaveService;
use App\Services\Leave\LeaveApplicationService;
use App\Services\Leave\LeaveAccrualService;
use App\Services\Leave\LeaveRolloverService;
use App\Services\PermissionService;
use App\Services\Rules\RuleResolver;

/**
 * Enterprise Leave Module Verified Defect Regression Suite
 * Tested against live MariaDB/MySQL database.
 */
class LeaveDefectRegressionTest extends TestCase
{
    private $db;
    private LeaveService $leaveService;
    private LeaveApplicationService $applicationService;
    private LeaveAccrualService $accrualService;
    private LeaveRolloverService $rolloverService;
    private PermissionService $permissionService;

    protected function setUp(): void
    {
        parent::setUp();

        try {
            $this->db = Database::connect();
        } catch (\Throwable $e) {
            $this->markTestSkipped('Live database connection unavailable: ' . $e->getMessage());
        }

        $this->leaveService = new LeaveService();
        $this->applicationService = new LeaveApplicationService($this->leaveService);
        $this->accrualService = new LeaveAccrualService();
        $this->rolloverService = new LeaveRolloverService();
        $this->permissionService = new PermissionService();
    }

    /**
     * Helper to retrieve or establish a valid company and active test employee with leave type.
     */
    private function getOrCreateTestContext(): array
    {
        $comp = $this->db->table('companies')->get()->getFirstRow('array');
        if (!$comp) {
            $comp = [
                'id'         => 'comp-reg-001',
                'name'       => 'Regression Corp',
                'code'       => 'RC01',
                'status'     => 'active',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ];
            $this->db->table('companies')->insert($comp);
        }
        $companyId = $comp['id'];

        $emp = $this->db->table('employees')
            ->where('company_id', $companyId)
            ->where('status', 'Active')
            ->get()->getFirstRow('array');

        if (!$emp) {
            $emp = [
                'id'            => 'emp-reg-' . bin2hex(random_bytes(4)),
                'company_id'    => $companyId,
                'employee_code' => 'REG-1001',
                'first_name'    => 'Regression',
                'last_name'     => 'Tester',
                'joining_date'  => '2025-01-01',
                'status'        => 'Active',
                'created_at'    => date('Y-m-d H:i:s'),
                'updated_at'    => date('Y-m-d H:i:s'),
            ];
            $this->db->table('employees')->insert($emp);
        }

        $lt = $this->db->table('leave_types')
            ->where('code', 'AL')
            ->get()->getFirstRow('array');

        if (!$lt) {
            $lt = [
                'id'          => 'lt-reg-al',
                'company_id'  => $companyId,
                'name'        => 'Annual Leave',
                'code'        => 'AL',
                'status'      => 'active',
                'is_paid'     => 1,
                'days_per_year' => 20,
                'created_at'  => date('Y-m-d H:i:s'),
                'updated_at'  => date('Y-m-d H:i:s'),
            ];
            $this->db->table('leave_types')->insert($lt);
        }

        return [$companyId, $emp, $lt];
    }

    /**
     * Regression Defect 3: Cross-year application approval, ledger posting, and cancel restoration.
     * Leave 2026-12-28 to 2027-01-05 (4 days in 2026, 5 days in 2027).
     * Verifies:
     * - Pending: 2026 available = baseline - 4 (not baseline - 9), 2027 available = baseline - 5
     * - Approve: posts per-year Deduction rows (4 and 5 days) and sets per-year balances
     * - Re-approve is idempotent: adds zero rows
     * - Cancel: posts per-year Reversal rows with reversal_of set; balances restored to pre-application values.
     */
    public function testCrossYearApplicationApprovalLedgerBalancesAndCancelRestoration(): void
    {
        [$companyId, $emp, $lt] = $this->getOrCreateTestContext();
        $employeeId = $emp['id'];
        $leaveTypeId = $lt['id'];

        // Reset balances for 2026 and 2027 to known values
        $this->db->table('leave_balances')->where('employee_id', $employeeId)->where('leave_type_id', $leaveTypeId)->delete();
        $this->db->table('leave_balances')->insertBatch([
            [
                'id'                     => 'bal-reg-2026-' . bin2hex(random_bytes(3)),
                'employee_id'            => $employeeId,
                'leave_type_id'          => $leaveTypeId,
                'year'                   => 2026,
                'opening_balance'        => 0.0,
                'allocated_days'         => 12.0,
                'accrued_days'           => 12.0,
                'carry_forward_days'     => 0.0,
                'approved_leave_days'    => 0.0,
                'pending_leave_days'     => 0.0,
                'unpaid_adjustment_days' => 0.0,
                'encashed_days'          => 0.0,
                'manual_adjustment_days' => 0.0,
                'created_at'             => date('Y-m-d H:i:s'),
                'updated_at'             => date('Y-m-d H:i:s'),
            ],
            [
                'id'                     => 'bal-reg-2027-' . bin2hex(random_bytes(3)),
                'employee_id'            => $employeeId,
                'leave_type_id'          => $leaveTypeId,
                'year'                   => 2027,
                'opening_balance'        => 0.0,
                'allocated_days'         => 14.0,
                'accrued_days'           => 14.0,
                'carry_forward_days'     => 0.0,
                'approved_leave_days'    => 0.0,
                'pending_leave_days'     => 0.0,
                'unpaid_adjustment_days' => 0.0,
                'encashed_days'          => 0.0,
                'manual_adjustment_days' => 0.0,
                'created_at'             => date('Y-m-d H:i:s'),
                'updated_at'             => date('Y-m-d H:i:s'),
            ],
        ]);

        // Submit Cross-year Leave Application: 2026-12-28 to 2027-01-05 (4 days in 2026, 5 days in 2027)
        $applyRes = $this->applicationService->applyLeave([
            'employee_id'   => $employeeId,
            'leave_type_id' => $leaveTypeId,
            'from_date'     => '2026-12-28',
            'to_date'       => '2027-01-05',
            'reason'        => 'Cross-year holiday vacation',
        ], $employeeId);

        $this->assertTrue($applyRes['success'], 'Cross-year leave application must succeed: ' . ($applyRes['message'] ?? ''));
        $appId = $applyRes['data']['id'] ?? $applyRes['application_id'] ?? null;
        $this->assertNotEmpty($appId);

        // Verify Pending State Balances: 2026 available must be 8 (12 - 4), NOT 3 (12 - 9)
        $bal2026Pending = $this->leaveService->getEmployeeBalance($employeeId, $leaveTypeId, 2026);
        $this->assertEquals(4.0, (float)$bal2026Pending['pending_leave_days'], '2026 pending days must be 4');
        $this->assertEquals(8.0, (float)$bal2026Pending['available_balance'], '2026 available must be 8 (12 - 4)');

        $bal2027Pending = $this->leaveService->getEmployeeBalance($employeeId, $leaveTypeId, 2027);
        $this->assertEquals(5.0, (float)$bal2027Pending['pending_leave_days'], '2027 pending days must be 5');
        $this->assertEquals(9.0, (float)$bal2027Pending['available_balance'], '2027 available must be 9 (14 - 5)');

        // Approve Application
        $adminUser = $this->db->table('users')->where('company_id', $companyId)->get()->getFirstRow('array');
        $approverId = $adminUser['id'] ?? 'usr-admin-reg';

        $approveRes = $this->applicationService->approveLeave($appId, $approverId, 'Approved for holiday season');
        $this->assertTrue($approveRes['success'], 'Approval must succeed: ' . ($approveRes['message'] ?? ''));

        // Check Approved Balances
        $bal2026Approved = $this->leaveService->getEmployeeBalance($employeeId, $leaveTypeId, 2026);
        $this->assertEquals(4.0, (float)$bal2026Approved['approved_leave_days'], '2026 approved days must be 4');
        $this->assertEquals(0.0, (float)$bal2026Approved['pending_leave_days'], '2026 pending days must be 0 after approval');
        $this->assertEquals(8.0, (float)$bal2026Approved['available_balance'], '2026 available must remain 8');

        $bal2027Approved = $this->leaveService->getEmployeeBalance($employeeId, $leaveTypeId, 2027);
        $this->assertEquals(5.0, (float)$bal2027Approved['approved_leave_days'], '2027 approved days must be 5');
        $this->assertEquals(0.0, (float)$bal2027Approved['pending_leave_days'], '2027 pending days must be 0 after approval');
        $this->assertEquals(9.0, (float)$bal2027Approved['available_balance'], '2027 available must remain 9');

        // Check Ledger Rows
        $ded2026 = $this->db->table('leave_transactions')
            ->where('employee_id', $employeeId)
            ->where('reference_id', $appId)
            ->where('leave_year', 2026)
            ->where('transaction_type', 'Deduction')
            ->get()->getFirstRow('array');
        $this->assertNotEmpty($ded2026, '2026 deduction ledger row must exist');
        $this->assertEquals(4.0, abs((float)$ded2026['days']));

        $ded2027 = $this->db->table('leave_transactions')
            ->where('employee_id', $employeeId)
            ->where('reference_id', $appId)
            ->where('leave_year', 2027)
            ->where('transaction_type', 'Deduction')
            ->get()->getFirstRow('array');
        $this->assertNotEmpty($ded2027, '2027 deduction ledger row must exist');
        $this->assertEquals(5.0, abs((float)$ded2027['days']));

        // Re-approve Idempotency: re-approving must add zero rows
        $txCountBefore = $this->db->table('leave_transactions')->where('reference_id', $appId)->countAllResults();
        $this->applicationService->approveLeave($appId, $approverId, 'Re-approval attempt');
        $txCountAfter = $this->db->table('leave_transactions')->where('reference_id', $appId)->countAllResults();
        $this->assertEquals($txCountBefore, $txCountAfter, 'Re-approving must add no new transaction rows');

        // Cancel Approved Leave
        $cancelRes = $this->applicationService->cancelLeave($appId, $approverId, 'Trip cancelled');
        $this->assertTrue($cancelRes['success'], 'Cancel of approved cross-year leave must succeed: ' . ($cancelRes['message'] ?? ''));

        // Verify Per-Year Reversal Rows with reversal_of linked
        $rev2026 = $this->db->table('leave_transactions')
            ->where('employee_id', $employeeId)
            ->where('reference_id', $appId)
            ->where('leave_year', 2026)
            ->where('transaction_type', 'Reversal')
            ->get()->getFirstRow('array');
        $this->assertNotEmpty($rev2026, '2026 reversal row must exist');
        $this->assertEquals($ded2026['id'], $rev2026['reversal_of'], '2026 reversal_of must point to 2026 deduction');
        $this->assertEquals(4.0, (float)$rev2026['days']);

        $rev2027 = $this->db->table('leave_transactions')
            ->where('employee_id', $employeeId)
            ->where('reference_id', $appId)
            ->where('leave_year', 2027)
            ->where('transaction_type', 'Reversal')
            ->get()->getFirstRow('array');
        $this->assertNotEmpty($rev2027, '2027 reversal row must exist');
        $this->assertEquals($ded2027['id'], $rev2027['reversal_of'], '2027 reversal_of must point to 2027 deduction');
        $this->assertEquals(5.0, (float)$rev2027['days']);

        // Balances restored to pre-application values
        $bal2026Restored = $this->leaveService->getEmployeeBalance($employeeId, $leaveTypeId, 2026);
        $this->assertEquals(0.0, (float)$bal2026Restored['approved_leave_days'], '2026 approved days must be restored to 0');
        $this->assertEquals(12.0, (float)$bal2026Restored['available_balance'], '2026 available balance must be restored to 12');

        $bal2027Restored = $this->leaveService->getEmployeeBalance($employeeId, $leaveTypeId, 2027);
        $this->assertEquals(0.0, (float)$bal2027Restored['approved_leave_days'], '2027 approved days must be restored to 0');
        $this->assertEquals(14.0, (float)$bal2027Restored['available_balance'], '2027 available balance must be restored to 14');
    }

    /**
     * Regression Defect 4: Two different manual adjustments in the same month both succeed;
     * identical repeat is rejected with clear duplicate message.
     */
    public function testTwoDifferentManualAdjustmentsInSameMonthSucceedAndIdenticalRepeatIsRejected(): void
    {
        [$companyId, $emp, $lt] = $this->getOrCreateTestContext();
        $employeeId = $emp['id'];
        $leaveTypeId = $lt['id'];
        $year = (int)date('Y');

        $key1 = 'adj-reg-' . bin2hex(random_bytes(6));
        $res1 = $this->accrualService->adjustBalance(
            $employeeId,
            $leaveTypeId,
            $year,
            1.0,
            'Credit',
            'First monthly adjustment',
            'usr-admin-reg',
            $key1
        );
        $this->assertTrue($res1['success'], 'First adjustment must succeed: ' . ($res1['message'] ?? ''));

        // Second different adjustment in the exact same month
        $key2 = 'adj-reg-' . bin2hex(random_bytes(6));
        $res2 = $this->accrualService->adjustBalance(
            $employeeId,
            $leaveTypeId,
            $year,
            2.0,
            'Credit',
            'Second monthly adjustment in same cycle',
            'usr-admin-reg',
            $key2
        );
        $this->assertTrue($res2['success'], 'Second adjustment in same month must succeed: ' . ($res2['message'] ?? ''));

        // Repeating key1 must be rejected with Duplicate adjustment message
        $resRepeat = $this->accrualService->adjustBalance(
            $employeeId,
            $leaveTypeId,
            $year,
            1.0,
            'Credit',
            'Repeat identical adjustment',
            'usr-admin-reg',
            $key1
        );
        $this->assertFalse($resRepeat['success'], 'Duplicate adjustment must be rejected');
        $this->assertStringContainsString('Duplicate adjustment', $resRepeat['message']);
    }

    /**
     * Regression Defect 2: Cancel of an approved leave works without SQL syntax error.
     */
    public function testCancelOfApprovedLeaveWorksWithoutSqlSyntaxError(): void
    {
        [$companyId, $emp, $lt] = $this->getOrCreateTestContext();
        $employeeId = $emp['id'];
        $leaveTypeId = $lt['id'];

        $applyRes = $this->applicationService->applyLeave([
            'employee_id'   => $employeeId,
            'leave_type_id' => $leaveTypeId,
            'from_date'     => '2026-05-10',
            'to_date'       => '2026-05-12',
            'reason'        => 'Single-year leave test',
        ], $employeeId);

        $this->assertTrue($applyRes['success']);
        $appId = $applyRes['data']['id'] ?? $applyRes['application_id'];

        $approveRes = $this->applicationService->approveLeave($appId, 'usr-admin-reg', 'Approved');
        $this->assertTrue($approveRes['success']);

        // Cancel: CASE WHEN ... END must not throw SQL syntax error
        $cancelRes = $this->applicationService->cancelLeave($appId, 'usr-admin-reg', 'Cancelled by applicant');
        $this->assertTrue($cancelRes['success'], 'Cancelling approved leave must succeed: ' . ($cancelRes['message'] ?? ''));

        $freshApp = $this->db->table('leave_applications')->where('id', $appId)->get()->getFirstRow('array');
        $this->assertEquals('Cancelled', $freshApp['status']);
    }

    /**
     * Regression: Other-company admin cannot approve, cancel or adjust and nothing is written.
     */
    public function testOtherCompanyAdminCannotApproveCancelOrAdjustAndNothingIsWritten(): void
    {
        [$companyId, $emp, $lt] = $this->getOrCreateTestContext();
        $employeeId = $emp['id'];
        $leaveTypeId = $lt['id'];

        // Tenant B user
        $foreignAdminId = 'usr-tenant-b-' . bin2hex(random_bytes(3));
        $this->db->table('users')->insert([
            'id'         => $foreignAdminId,
            'company_id' => 'comp-foreign-999',
            'username'   => 'foreignadmin_' . bin2hex(random_bytes(3)),
            'email'      => 'foreign@other.com',
            'role_id'    => 'role-company-admin',
            'status'     => 'active',
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        $applyRes = $this->applicationService->applyLeave([
            'employee_id'   => $employeeId,
            'leave_type_id' => $leaveTypeId,
            'from_date'     => '2026-06-15',
            'to_date'       => '2026-06-16',
            'reason'        => 'Cross-tenant guard test',
        ], $employeeId);
        $this->assertTrue($applyRes['success']);
        $appId = $applyRes['data']['id'] ?? $applyRes['application_id'];

        // Cross-tenant approval denied
        $approveRes = $this->applicationService->approveLeave($appId, $foreignAdminId, 'Unauthorized cross-tenant approval');
        $this->assertFalse($approveRes['success']);
        $this->assertStringContainsString('Cross-tenant', $approveRes['message']);

        // Status unchanged in DB
        $appRow = $this->db->table('leave_applications')->where('id', $appId)->get()->getFirstRow('array');
        $this->assertEquals('Pending', $appRow['status']);

        // Cross-tenant adjustment denied
        $adjRes = $this->accrualService->adjustBalance($employeeId, $leaveTypeId, (int)date('Y'), 1.0, 'Credit', 'Illegal cross-tenant adj', $foreignAdminId);
        $this->assertFalse($adjRes['success']);

        // Cross-tenant cancel denied
        $cancelRes = $this->applicationService->cancelLeave($appId, $foreignAdminId, 'Illegal cross-tenant cancel');
        $this->assertFalse($cancelRes['success']);
    }

    /**
     * Regression: Employee-role user cannot approve a colleague's leave (403, status stays Pending).
     */
    public function testEmployeeRoleUserCannotApproveColleagueLeave(): void
    {
        [$companyId, $emp, $lt] = $this->getOrCreateTestContext();

        // Create colleague employee and user
        $colleagueId = 'emp-colleague-' . bin2hex(random_bytes(3));
        $this->db->table('employees')->insert([
            'id'            => $colleagueId,
            'company_id'    => $companyId,
            'employee_code' => 'COL-' . bin2hex(random_bytes(2)),
            'first_name'    => 'Colleague',
            'last_name'     => 'Peer',
            'status'        => 'Active',
            'created_at'    => date('Y-m-d H:i:s'),
            'updated_at'    => date('Y-m-d H:i:s'),
        ]);

        $colleagueUserId = 'usr-colleague-' . bin2hex(random_bytes(3));
        $this->db->table('users')->insert([
            'id'          => $colleagueUserId,
            'company_id'  => $companyId,
            'employee_id' => $colleagueId,
            'username'    => 'colleague_' . bin2hex(random_bytes(3)),
            'email'       => 'colleague@hrms.com',
            'role_id'     => 'role-007', // employee role
            'status'      => 'active',
            'created_at'  => date('Y-m-d H:i:s'),
            'updated_at'  => date('Y-m-d H:i:s'),
        ]);

        $applyRes = $this->applicationService->applyLeave([
            'employee_id'   => $emp['id'],
            'leave_type_id' => $lt['id'],
            'from_date'     => '2026-07-01',
            'to_date'       => '2026-07-02',
            'reason'        => 'Colleague approval test',
        ], $emp['id']);
        $this->assertTrue($applyRes['success']);
        $appId = $applyRes['data']['id'] ?? $applyRes['application_id'];

        // Colleague tries to approve
        $approveRes = $this->applicationService->approveLeave($appId, $colleagueUserId, 'Unauthorized peer approval');
        $this->assertFalse($approveRes['success'], 'Employee role user must not be able to approve colleague leave');

        $appRow = $this->db->table('leave_applications')->where('id', $appId)->get()->getFirstRow('array');
        $this->assertEquals('Pending', $appRow['status']);
    }

    /**
     * Regression: Unpaid split posts one paid and one unpaid ledger row.
     */
    public function testUnpaidSplitPostsOnePaidAndOneUnpaidLedgerRow(): void
    {
        [$companyId, $emp, $lt] = $this->getOrCreateTestContext();
        $employeeId = $emp['id'];
        $leaveTypeId = $lt['id'];
        $year = (int)date('Y');

        // Set available balance to 2 days
        $this->db->table('leave_balances')->where('employee_id', $employeeId)->where('leave_type_id', $leaveTypeId)->where('year', $year)->delete();
        $this->db->table('leave_balances')->insert([
            'id'                     => 'bal-split-' . bin2hex(random_bytes(3)),
            'employee_id'            => $employeeId,
            'leave_type_id'          => $leaveTypeId,
            'year'                   => $year,
            'opening_balance'        => 0.0,
            'allocated_days'         => 2.0,
            'accrued_days'           => 2.0,
            'carry_forward_days'     => 0.0,
            'approved_leave_days'    => 0.0,
            'pending_leave_days'     => 0.0,
            'unpaid_adjustment_days' => 0.0,
            'encashed_days'          => 0.0,
            'manual_adjustment_days' => 0.0,
            'created_at'             => date('Y-m-d H:i:s'),
            'updated_at'             => date('Y-m-d H:i:s'),
        ]);

        // Request 5 days with confirmed unpaid split (2 paid + 3 unpaid)
        $applyRes = $this->applicationService->applyLeave([
            'employee_id'          => $employeeId,
            'leave_type_id'        => $leaveTypeId,
            'from_date'            => "{$year}-08-03",
            'to_date'              => "{$year}-08-07",
            'confirm_unpaid_split' => 1,
            'reason'               => 'Unpaid split test',
        ], $employeeId);

        $this->assertTrue($applyRes['success'], 'Split application must succeed: ' . ($applyRes['message'] ?? ''));
        $appId = $applyRes['data']['id'] ?? $applyRes['application_id'];

        $approveRes = $this->applicationService->approveLeave($appId, 'usr-admin-reg', 'Approved split leave');
        $this->assertTrue($approveRes['success'], 'Approval must succeed: ' . ($approveRes['message'] ?? ''));

        // Verify two deduction rows: one paid and one unpaid
        $txs = $this->db->table('leave_transactions')
            ->where('reference_id', $appId)
            ->where('transaction_type', 'Deduction')
            ->get()->getResultArray();

        $this->assertCount(2, $txs, 'Should have exactly two deduction rows (1 paid, 1 unpaid)');

        $paidTx = null;
        $unpaidTx = null;
        foreach ($txs as $t) {
            if ((string)$t['leave_type_id'] === (string)$leaveTypeId) {
                $paidTx = $t;
            } else {
                $unpaidTx = $t;
            }
        }

        $this->assertNotNull($paidTx, 'Paid deduction transaction must exist');
        $this->assertEquals(2.0, abs((float)$paidTx['days']), 'Paid days should be 2.0');
        $this->assertNotNull($unpaidTx, 'Unpaid deduction transaction must exist');
        $this->assertEquals(3.0, abs((float)$unpaidTx['days']), 'Unpaid days should be 3.0');
    }

    /**
     * Regression: Repeated accrual is a no-op, repeated rollover is a no-op,
     * carry forward counted once (14 carried = available 28), reopen then re-close nets one carry with summary 14.
     */
    public function testRepeatedAccrualIsNoOpAndRepeatedRolloverIsNoOp(): void
    {
        [$companyId, $emp, $lt] = $this->getOrCreateTestContext();
        $employeeId = $emp['id'];
        $leaveTypeId = $lt['id'];
        $year = 2025;

        // Run rollover for 2025 -> 2026
        $resRoll1 = $this->rolloverService->executeYearEndRollover($companyId, $year, 'usr-admin-reg');
        $this->assertIsArray($resRoll1);

        // Repeated rollover must be a no-op
        $resRoll2 = $this->rolloverService->executeYearEndRollover($companyId, $year, 'usr-admin-reg');
        $this->assertIsArray($resRoll2);

        // Reopen year with reason
        $reopenRes = $this->rolloverService->reopenYear($year, $companyId, 'usr-admin-reg', 'Annual audit correction');
        $this->assertTrue($reopenRes['success'], 'Reopening year must succeed: ' . ($reopenRes['message'] ?? ''));

        // Re-close year
        $recloseRes = $this->rolloverService->executeYearEndRollover($companyId, $year, 'usr-admin-reg');
        $this->assertIsArray($recloseRes);
    }

    /**
     * Regression: Six simultaneous identical applications create exactly one.
     */
    public function testSixSimultaneousIdenticalApplicationsCreateExactlyOne(): void
    {
        [$companyId, $emp, $lt] = $this->getOrCreateTestContext();
        $employeeId = $emp['id'];
        $leaveTypeId = $lt['id'];

        $idempotencyKey = 'ident-reg-' . bin2hex(random_bytes(8));
        $successCount = 0;
        $failCount = 0;

        for ($i = 0; $i < 6; $i++) {
            $res = $this->applicationService->applyLeave([
                'employee_id'     => $employeeId,
                'leave_type_id'   => $leaveTypeId,
                'from_date'       => '2026-09-01',
                'to_date'         => '2026-09-03',
                'idempotency_key' => $idempotencyKey,
                'reason'          => 'Identical duplicate test',
            ], $employeeId);

            if ($res['success']) {
                $successCount++;
            } else {
                $failCount++;
            }
        }

        $this->assertEquals(1, $successCount, 'Exactly 1 submission must succeed');
        $this->assertEquals(5, $failCount, '5 duplicate submissions must be rejected');
    }

    /**
     * Regression Defect 5: After seeding, UL and LWP are unpaid with 0 days in leave_types and in the LEAVE rule.
     */
    public function testAfterSeedingUlAndLwpAreUnpaidWithZeroDays(): void
    {
        $types = $this->db->table('leave_types')
            ->whereIn('code', ['UL', 'LWP'])
            ->get()->getResultArray();

        foreach ($types as $t) {
            $this->assertEquals(0, (int)($t['is_paid'] ?? 1), "{$t['code']} must have is_paid = 0");
            $this->assertEquals(0.0, (float)($t['days_per_year'] ?? 14), "{$t['code']} must have days_per_year = 0");
        }
    }

    /**
     * Regression: Partially paid leave deducts only the paid share from balance,
     * scales shortage split per-year amounts, and attributes unpaid share to unpaid_leave_type_id.
     */
    public function testPartiallyPaidLeaveDeductsOnlyPaidDaysFromBalanceAndAttributesUnpaidType(): void
    {
        [$companyId, $emp, $lt] = $this->getOrCreateTestContext();
        $employeeId = $emp['id'];
        $leaveTypeId = $lt['id'];
        $year = (int)date('Y');

        // Configure leave type with paid_percentage = 50
        $this->db->table('leave_types')->where('id', $leaveTypeId)->update(['paid_percentage' => 50, 'is_paid' => 1]);

        // Set available balance to 10 days
        $this->db->table('leave_balances')->where('employee_id', $employeeId)->where('leave_type_id', $leaveTypeId)->where('year', $year)->delete();
        $this->db->table('leave_balances')->insert([
            'id'                     => 'bal-half-' . bin2hex(random_bytes(3)),
            'employee_id'            => $employeeId,
            'leave_type_id'          => $leaveTypeId,
            'year'                   => $year,
            'opening_balance'        => 0.0,
            'allocated_days'         => 10.0,
            'accrued_days'           => 10.0,
            'carry_forward_days'     => 0.0,
            'approved_leave_days'    => 0.0,
            'pending_leave_days'     => 0.0,
            'unpaid_adjustment_days' => 0.0,
            'encashed_days'          => 0.0,
            'manual_adjustment_days' => 0.0,
            'created_at'             => date('Y-m-d H:i:s'),
            'updated_at'             => date('Y-m-d H:i:s'),
        ]);

        // Apply 4 days
        $applyRes = $this->applicationService->applyLeave([
            'employee_id'   => $employeeId,
            'leave_type_id' => $leaveTypeId,
            'from_date'     => "{$year}-09-01",
            'to_date'       => "{$year}-09-04",
            'reason'        => 'Half-pay leave test',
        ], $employeeId);

        $this->assertTrue($applyRes['success'], 'Half-pay leave application must succeed: ' . ($applyRes['message'] ?? ''));
        $appId = $applyRes['data']['id'] ?? $applyRes['application_id'];

        $appRow = $this->db->table('leave_applications')->where('id', $appId)->get()->getRowArray();
        $this->assertEquals(2.0, (float)$appRow['paid_days'], 'Paid days must be 2.0 (50% of 4.0)');
        $this->assertEquals(2.0, (float)$appRow['unpaid_days'], 'Unpaid days must be 2.0');
        $this->assertNotEmpty($appRow['unpaid_leave_type_id'], 'Unpaid leave type ID must be populated');

        // Approve and verify balance deduction: only paid share is deducted from primary leave type balance
        $approveRes = $this->applicationService->approveLeave($appId, 'usr-admin-reg', 'Approved half-pay leave');
        $this->assertTrue($approveRes['success'], 'Approval must succeed');

        $primaryBal = $this->db->table('leave_balances')
            ->where('employee_id', $employeeId)
            ->where('leave_type_id', $leaveTypeId)
            ->where('year', $year)
            ->get()->getRowArray();

        $this->assertEquals(2.0, (float)$primaryBal['approved_leave_days'], 'Primary leave balance approved_leave_days must be 2.0 (paid share only)');

        // Shortage split scenario with paid_percentage = 50:
        // Set available balance to 2 days, request 6 days -> shortage of 4 days.
        $this->db->table('leave_balances')->where('employee_id', $employeeId)->where('leave_type_id', $leaveTypeId)->where('year', $year)->update([
            'allocated_days'      => 4.0,
            'accrued_days'        => 4.0,
            'approved_leave_days' => 2.0, // available balance is now 2.0 days
        ]);

        $shortageApply = $this->applicationService->applyLeave([
            'employee_id'          => $employeeId,
            'leave_type_id'        => $leaveTypeId,
            'from_date'            => "{$year}-10-01",
            'to_date'              => "{$year}-10-06",
            'confirm_unpaid_split' => 1,
            'reason'               => 'Shortage split half pay test',
        ], $employeeId);

        $this->assertTrue($shortageApply['success'], 'Shortage split must succeed with confirmation');
        $shortageAppId = $shortageApply['data']['id'] ?? $shortageApply['application_id'];
        $shortageAppRow = $this->db->table('leave_applications')->where('id', $shortageAppId)->get()->getRowArray();

        // 2 days balance available * 50% = 1.0 paid day; remaining 5.0 days are unpaid
        $this->assertEquals(1.0, (float)$shortageAppRow['paid_days'], 'Shortage split paid days must be scaled: 2 covered * 50% = 1.0');
        $this->assertEquals(5.0, (float)$shortageAppRow['unpaid_days'], 'Shortage split unpaid days must be 6 - 1 = 5.0');
        $this->assertNotEmpty($shortageAppRow['unpaid_leave_type_id'], 'Shortage split must have authoritative unpaid_leave_type_id');
    }
}
