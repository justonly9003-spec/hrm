<?php
$baseUrl = 'http://127.0.0.1:8080';
$cookieDir = sys_get_temp_dir() . '/gate_cookies_' . uniqid();
mkdir($cookieDir, 0777, true);

$pdo = new PDO('mysql:host=localhost;dbname=enterprise_hrms;charset=utf8mb4', 'root', '', [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
]);

function randomizeCsrfHash(string $hash): string {
    $keyBinary = random_bytes(16);
    $hashBinary = hex2bin($hash);
    return bin2hex(($hashBinary ^ $keyBinary) . $keyBinary);
}

function getOrFetchCsrfToken($baseUrl, $cookieDir, $sessionUser = null) {
    $cookieFile = $sessionUser !== null 
        ? ($cookieDir . '/' . preg_replace('/[^a-zA-Z0-9_-]/', '', $sessionUser) . '.txt')
        : ($cookieDir . '/anon.txt');

    if (file_exists($cookieFile)) {
        $content = file_get_contents($cookieFile);
        if (preg_match('/csrf_cookie_name\s+([^\r\n\s]+)/', $content, $m)) {
            return randomizeCsrfHash(trim($m[1]));
        }
    }

    $ch = curl_init($baseUrl . '/auth/login');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $html = curl_exec($ch);
    curl_close($ch);

    if (file_exists($cookieFile)) {
        $content = file_get_contents($cookieFile);
        if (preg_match('/csrf_cookie_name\s+([^\r\n\s]+)/', $content, $m)) {
            return randomizeCsrfHash(trim($m[1]));
        }
    }

    if (preg_match('/name=["\']csrf_token_name["\']\s+value=["\']([^"\']+)["\']/', (string)$html, $m)) {
        return $m[1];
    }
    return '';
}

function req($baseUrl, $cookieDir, $path, $method = 'GET', $data = [], $sessionUser = null) {
    $url = $baseUrl . '/' . ltrim($path, '/');
    $ch = curl_init();
    $cookieFile = $sessionUser ? ($cookieDir . '/' . preg_replace('/[^a-zA-Z0-9_-]/', '', $sessionUser) . '.txt') : null;

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);

    if ($cookieFile) {
        curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    }

    if (strtoupper($method) === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        $token = getOrFetchCsrfToken($baseUrl, $cookieDir, $sessionUser);
        if (!empty($token)) {
            $data['csrf_token_name'] = $token;
            $data['csrf_test_name'] = $token;
        }
        $headers = [
            'X-Requested-With: XMLHttpRequest',
            'X-CSRF-TOKEN: ' . ($token ?: '')
        ];
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    }

    $raw = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $hSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    curl_close($ch);

    $headerStr = substr((string)$raw, 0, $hSize);
    $body = substr((string)$raw, $hSize);
    $location = null;
    if (preg_match('/Location:\s*([^\r\n]+)/i', $headerStr, $m)) {
        $location = trim($m[1]);
    }
    return ['code' => $code, 'location' => $location, 'body' => $body];
}

// Ensure fixture exists
$pdo->exec("INSERT IGNORE INTO companies (id, name, code, status) VALUES ('comp-gate-a', 'Company Alpha Gate', 'CMPA-GATE', 'Active')");
$pdo->exec("INSERT IGNORE INTO branches (id, company_id, name, code, status) VALUES ('branch-gate-a', 'comp-gate-a', 'Alpha HQ', 'BR-A', 'Active')");
$pdo->exec("INSERT IGNORE INTO departments (id, name, code, status) VALUES ('dept-gate-a', 'Engineering', 'D-ENG', 'Active')");
$pdo->exec("INSERT IGNORE INTO designations (id, name, code, status) VALUES ('desig-gate-a', 'Engineer', 'DES-ENG', 'Active')");

$pass = password_hash('Pass123!', PASSWORD_BCRYPT);
$pdo->exec("DELETE FROM users WHERE username IN ('admin_tenanta', 'user_term')");
$pdo->exec("DELETE FROM employees WHERE id IN ('emp-gate-a1', 'emp-gate-term')");

$pdo->prepare("INSERT INTO employees (id, company_id, branch_id, department_id, designation_id, employee_code, first_name, last_name, email, status, joining_date) VALUES 
    ('emp-gate-a1', 'comp-gate-a', 'branch-gate-a', 'dept-gate-a', 'desig-gate-a', 'EMP-A-01', 'Alice', 'Admin', 'alice@alpha.gate', 'Active', '2025-01-01'),
    ('emp-gate-term', 'comp-gate-a', 'branch-gate-a', 'dept-gate-a', 'desig-gate-a', 'EMP-TERM-01', 'Tom', 'Terminated', 'tom@alpha.gate', 'Active', '2025-01-01')
")->execute();

$pdo->prepare("INSERT INTO users (id, employee_id, username, email, password_hash, role_id, company_id, status, is_two_factor_enabled) VALUES 
    ('usr-gate-a-admin', 'emp-gate-a1', 'admin_tenanta', 'alice@alpha.gate', ?, 'role-002', 'comp-gate-a', 'active', 0),
    ('usr-gate-term', 'emp-gate-term', 'user_term', 'tom@alpha.gate', ?, 'role-008', 'comp-gate-a', 'active', 0)
")->execute([$pass, $pass]);

// Login admin
$csrf = getOrFetchCsrfToken($baseUrl, $cookieDir, 'admin_tenanta');
echo "Fetched CSRF token: " . var_export($csrf, true) . "\n";
$cookieContent = file_exists($cookieDir . '/admin_tenanta.txt') ? file_get_contents($cookieDir . '/admin_tenanta.txt') : 'NONE';
echo "Cookie file content before login:\n" . $cookieContent . "\n";

$rLogin = req($baseUrl, $cookieDir, '/auth/login', 'POST', [
    'csrf_token_name' => $csrf,
    'csrf_test_name' => $csrf,
    'username' => 'admin_tenanta',
    'password' => 'Pass123!'
], 'admin_tenanta');
echo "Admin login response: Code=" . $rLogin['code'] . ", Location=" . $rLogin['location'] . "\n";

// Test termination
$rTerm = req($baseUrl, $cookieDir, '/employees/profile/emp-gate-term/termination/save', 'POST', [
    'termination_date' => date('Y-m-d'),
    'reason' => 'Gross misconduct',
    'notice_period_days' => 0,
    'approved_by' => 'Board',
    'clearance_status' => 'Completed'
], 'admin_tenanta');
echo "Termination response: Code=" . $rTerm['code'] . ", Location=" . $rTerm['location'] . "\n";
echo "Termination body snippet: " . substr(strip_tags($rTerm['body']), 0, 200) . "\n";

// Check DB
$empStatus = $pdo->query("SELECT status FROM employees WHERE id = 'emp-gate-term'")->fetchColumn();
$userStatus = $pdo->query("SELECT status FROM users WHERE id = 'usr-gate-term'")->fetchColumn();
echo "DB status: emp=" . $empStatus . ", user=" . $userStatus . "\n";
