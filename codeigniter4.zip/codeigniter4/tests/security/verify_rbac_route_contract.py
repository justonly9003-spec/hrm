#!/usr/bin/env python3
"""Static regression checks for route-level RBAC contracts."""
from pathlib import Path
import re

routes = Path('app/Config/Routes.php').read_text(encoding='utf-8')
controller = Path('app/Controllers/Employee/EmployeeSalaryController.php').read_text(encoding='utf-8')
checks = []

def check(name, condition):
    checks.append((name, bool(condition)))

# Feature groups must not impose a blanket VIEW permission in addition to each
# endpoint's own permission. That AND behavior blocks users with legitimate
# create/manage grants but no view grant.
for module in ('employees', 'payroll', 'assets', 'training', 'performance'):
    m = re.search(r"\$routes->group\('" + re.escape(module) + r"'.*?function \(\$routes\) \{", routes, re.S)
    check(f'{module} group exists', m is not None)
    if m:
        header = m.group(0)
        check(f'{module} group only enforces authentication', "'filter' => 'auth'" in header and 'permission:' not in header)

# Employee group has no routes relying solely on inherited authorization.
m = re.search(r"\$routes->group\('employees'.*?function \(\$routes\) \{(.*?)\n\s*\}\);", routes, re.S)
check('employees group parsed', m is not None)
if m:
    unfiltered = [ln.strip() for ln in m.group(1).splitlines() if re.search(r"\$routes->(get|post|put|delete|match)\(", ln) and 'filter' not in ln]
    check('all employee endpoints have explicit route permissions', not unfiltered)

check('employee salary GET route has sensitive/payroll permission', bool(re.search(r"\$routes->get\('\(:segment\)/salary'.*permission:employee\.view_salary\|payroll\.view", routes)))
check('employee salary history GET route has sensitive/payroll permission', bool(re.search(r"\$routes->get\('\(:segment\)/salary-history'.*permission:employee\.view_salary\|payroll\.view", routes)))
check('salary controller authorizes either permitted read grant', controller.count("$this->authorizeAny(['employee.view_salary', 'payroll.view']);") >= 2)

# Payroll group routes all carry endpoint-specific permissions; no route may
# accidentally inherit a blanket payroll.view requirement.
m = re.search(r"\$routes->group\('payroll'.*?function \(\$routes\) \{(.*?)\n\s*\}\);", routes, re.S)
check('payroll group parsed', m is not None)
if m:
    unfiltered = [ln.strip() for ln in m.group(1).splitlines() if re.search(r"\$routes->(get|post|put|delete|match)\(", ln) and 'filter' not in ln]
    check('all core payroll endpoints have explicit route permissions', not unfiltered)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(('PASS' if ok else 'FAIL') + ': ' + name)
print(f'RESULT: {len(checks)-len(failed)}/{len(checks)} passed')
raise SystemExit(1 if failed else 0)
