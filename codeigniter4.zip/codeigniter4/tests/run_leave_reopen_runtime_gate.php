<?php
/**
 * Zero-Trust Database Runtime Gate for Leave Closing, Reopen, and Ledger Reversals
 * Verifies:
 * 1. Migration 000001 & 000002 schema & column existence
 * 2. Backfill verification of company_id and leave_year on leave_transactions
 * 3. Compound unique constraint on (company_id, idempotency_key) & tenant isolation
 * 4. Real database reversal execution via LeaveRolloverService::reopenYear
 * 5. Re-open guardrails (non-closed rejection, double-reversal prevention)
 * 6. Permission guardrails: company_admin, hr_admin vs unprivileged roles
 */

define('CLI_RUN', true);

class LeaveReopenRuntimeGate
{
    private PDO $pdo;
    private array $results = [];

    public function __construct(string $dsn = 'mysql:host=localhost;dbname=enterprise_hrms;charset=utf8mb4', string $user = 'root', string $pass = '')
    {
        $this->pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    }

    public function record(string $section, string $testId, string $testName, string $status, array $evidence = []): void
    {
        $this->results[] = [
            'section'   => $section,
            'id'        => $testId,
            'test'      => $testName,
            'status'    => $status,
            'evidence'  => $evidence,
            'timestamp' => date('Y-m-d H:i:s')
        ];
        $tag = $status === 'PASS' ? "\033[32m[PASS]\033[0m" : "\033[31m[FAIL]\033[0m";
        echo "{$tag} [{$testId}] [{$section}] {$testName}\n";
        if ($status !== 'PASS') {
            echo "   >>> EVIDENCE: " . json_encode($evidence, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . "\n";
        }
    }

    public function runAll(): bool
    {
        echo "========================================================================\n";
        echo "LEAVE REOPEN & LEDGER INTEGRITY RUNTIME GATE EXECUTION\n";
        echo "========================================================================\n";

        $this->testSchemaAndMigrations();
        $this->testCompoundIdempotencyKeyAndTenantIsolation();
        $this->testRealLeaveYearClosingAndReopenReversals();
        $this->testRolePermissionsMatrixAndReopenAuthorization();

        echo "\n========================================================================\n";
        echo "SUMMARY EVALUATION\n";
        echo "========================================================================\n";
        $total = count($this->results);
        $passCount = count(array_filter($this->results, fn($r) => $r['status'] === 'PASS'));
        $failCount = count(array_filter($this->results, fn($r) => $r['status'] === 'FAIL'));

        echo "TOTAL TESTS: {$total} | PASS: {$passCount} | FAIL: {$failCount}\n";
        return ($failCount === 0);
    }

    private function testSchemaAndMigrations(): void
    {
        $pdo = $this->pdo;

        // 1. leave_transactions ledger columns
        $stmt = $pdo->query("SHOW COLUMNS FROM leave_transactions");
        $cols = array_column($stmt->fetchAll(), 'Field');
        $requiredTxCols = ['company_id', 'leave_year', 'idempotency_key', 'reversal_of', 'related_application_id', 'policy_version'];
        $missingTxCols = array_diff($requiredTxCols, $cols);
        $this->record(
            '1. Schema',
            'GATE-LV-01',
            'Migration 000001: leave_transactions columns present',
            empty($missingTxCols) ? 'PASS' : 'FAIL',
            ['missing' => array_values($missingTxCols)]
        );

        // 2. Compound unique index on (company_id, idempotency_key)
        $stmt = $pdo->query("SHOW INDEX FROM leave_transactions");
        $indexes = $stmt->fetchAll();
        $compoundIndexFound = false;
        foreach ($indexes as $idx) {
            if ($idx['Key_name'] === 'uq_leave_tx_company_idempotency') {
                $compoundIndexFound = true;
                break;
            }
        }
        $this->record(
            '1. Schema',
            'GATE-LV-02',
            'Migration 000001: compound unique index uq_leave_tx_company_idempotency present',
            $compoundIndexFound ? 'PASS' : 'FAIL',
            ['found' => $compoundIndexFound]
        );

        // 3. leave_year_closings table
        $tables = array_column($pdo->query("SHOW TABLES")->fetchAll(), 'Tables_in_enterprise_hrms');
        $hasClosingTable = in_array('leave_year_closings', $tables, true);
        $this->record(
            '1. Schema',
            'GATE-LV-03',
            'Migration 000001: leave_year_closings table exists',
            $hasClosingTable ? 'PASS' : 'FAIL',
            ['exists' => $hasClosingTable]
        );

        // 4. Migration 000002 permissions
        $stmt = $pdo->query("SELECT code FROM permissions WHERE code IN ('leave.closing_reopen', 'leaves.closing_reopen')");
        $foundPerms = array_column($stmt->fetchAll(), 'code');
        $hasBothPerms = (count($foundPerms) === 2);
        $this->record(
            '1. Schema',
            'GATE-LV-04',
            'Migration 000002: leave.closing_reopen and leaves.closing_reopen in permissions table',
            $hasBothPerms ? 'PASS' : 'FAIL',
            ['found' => $foundPerms]
        );
    }

    private function testCompoundIdempotencyKeyAndTenantIsolation(): void
    {
        $pdo = $this->pdo;
        $companyA = 'comp-gate-tenant-a';
        $companyB = 'comp-gate-tenant-b';
        $empA = 'emp-gate-a1';
        $empB = 'emp-gate-b1';
        $leaveTypeId = 'lt-annual-test';
        $idempotencyKey = 'IDEM-TEST-' . bin2hex(random_bytes(6));

        // Ensure prerequisite tenant companies exist
        $pdo->exec("INSERT IGNORE INTO companies (id, name, code, status) VALUES ('{$companyA}', 'Tenant A', 'T-A', 'Active')");
        $pdo->exec("INSERT IGNORE INTO companies (id, name, code, status) VALUES ('{$companyB}', 'Tenant B', 'T-B', 'Active')");

        // 1. Insert first transaction under Tenant A
        $txId1 = 'tx-test-idemp-01';
        $pdo->prepare("
            INSERT INTO leave_transactions (id, company_id, employee_id, leave_type_id, leave_year, transaction_type, days, idempotency_key, created_at)
            VALUES (?, ?, ?, ?, ?, 'Credit', 5.0, ?, NOW())
        ")->execute([$txId1, $companyA, $empA, $leaveTypeId, 2026, $idempotencyKey]);

        // 2. Concurrent duplicate under same Tenant A must fail
        $txIdDup = 'tx-test-idemp-dup';
        $duplicateRejected = false;
        try {
            $pdo->prepare("
                INSERT INTO leave_transactions (id, company_id, employee_id, leave_type_id, leave_year, transaction_type, days, idempotency_key, created_at)
                VALUES (?, ?, ?, ?, ?, 'Credit', 5.0, ?, NOW())
            ")->execute([$txIdDup, $companyA, $empA, $leaveTypeId, 2026, $idempotencyKey]);
        } catch (\PDOException $e) {
            $duplicateRejected = (strpos($e->getMessage(), 'Duplicate entry') !== false || $e->getCode() == 23000);
        }

        $this->record(
            '2. Concurrency & Idempotency',
            'GATE-LV-05',
            'Duplicate (company_id, idempotency_key) strictly rejected by database constraint',
            $duplicateRejected ? 'PASS' : 'FAIL',
            ['duplicate_rejected' => $duplicateRejected]
        );

        // 3. Same idempotency_key under Tenant B must succeed (cross-tenant isolation)
        $txIdTenantB = 'tx-test-idemp-tb';
        $tenantBSuccess = false;
        try {
            $pdo->prepare("
                INSERT INTO leave_transactions (id, company_id, employee_id, leave_type_id, leave_year, transaction_type, days, idempotency_key, created_at)
                VALUES (?, ?, ?, ?, ?, 'Credit', 5.0, ?, NOW())
            ")->execute([$txIdTenantB, $companyB, $empB, $leaveTypeId, 2026, $idempotencyKey]);
            $tenantBSuccess = true;
        } catch (\PDOException $e) {
            $tenantBSuccess = false;
        }

        $this->record(
            '2. Concurrency & Idempotency',
            'GATE-LV-06',
            'Cross-tenant isolation: identical idempotency_key allowed across distinct company_ids',
            $tenantBSuccess ? 'PASS' : 'FAIL',
            ['tenant_b_success' => $tenantBSuccess]
        );

        // Cleanup test keys
        $pdo->prepare("DELETE FROM leave_transactions WHERE id IN (?, ?, ?)")->execute([$txId1, $txIdDup, $txIdTenantB]);
    }

    private function testRealLeaveYearClosingAndReopenReversals(): void
    {
        $pdo = $this->pdo;
        $companyId = 'comp-gate-reopen-test';
        $employeeId = 'emp-gate-reopen-1';
        $leaveTypeId = 'lt-gate-reopen-1';
        $year = 2025;
        $toYear = 2026;
        $closingVersion = 1;

        // Ensure prerequisite company
        $pdo->exec("INSERT IGNORE INTO companies (id, name, code, status) VALUES ('{$companyId}', 'Reopen Company', 'RC-01', 'Active')");

        // 1. Create a closed fiscal year record in leave_year_closings
        $closingId = 'lyc-test-reopen-' . bin2hex(random_bytes(4));
        $summaryJson = json_encode(['to_year' => $toYear, 'employees_processed' => 1]);
        $pdo->prepare("
            INSERT INTO leave_year_closings (id, company_id, leave_year, version, status, closed_at, closed_by, summary_json, created_at)
            VALUES (?, ?, ?, ?, 'Closed', NOW(), 'admin-wizard', ?, NOW())
        ")->execute([$closingId, $companyId, $year, $closingVersion, $summaryJson]);

        // 2. Create original Carry Forward ledger entry in target year (2026)
        $origCfTxId = 'tx-cf-gate-001';
        $pdo->prepare("
            INSERT INTO leave_transactions (id, company_id, employee_id, leave_type_id, leave_year, transaction_type, days, cycle_no, idempotency_key, created_at)
            VALUES (?, ?, ?, ?, ?, 'Carry Forward', 5.0, ?, ?, NOW())
        ")->execute([
            $origCfTxId,
            $companyId,
            $employeeId,
            $leaveTypeId,
            $toYear,
            "ROLLOVER-CF-{$year}-{$toYear}-v{$closingVersion}-seed",
            "ROLLOVER-{$companyId}-{$employeeId}-{$leaveTypeId}-{$year}-{$toYear}-v{$closingVersion}"
        ]);

        // 3. Create original Expiration ledger entry in closing year (2025)
        $origExpTxId = 'tx-exp-gate-001';
        $pdo->prepare("
            INSERT INTO leave_transactions (id, company_id, employee_id, leave_type_id, leave_year, transaction_type, days, cycle_no, idempotency_key, created_at)
            VALUES (?, ?, ?, ?, ?, 'Expiration', -3.0, ?, ?, NOW())
        ")->execute([
            $origExpTxId,
            $companyId,
            $employeeId,
            $leaveTypeId,
            $year,
            "ROLLOVER-EXP-{$year}-v{$closingVersion}-seed",
            "EXPIRE-{$companyId}-{$employeeId}-{$leaveTypeId}-{$year}-v{$closingVersion}"
        ]);

        // 4. Ensure target year balance exists in leave_balances
        $pdo->prepare("
            INSERT INTO leave_balances (id, company_id, employee_id, leave_type_id, year, opening_balance, carry_forward_days, accrued_days, used_days, balance)
            VALUES (?, ?, ?, ?, ?, 5.0, 5.0, 10.0, 0.0, 15.0)
            ON DUPLICATE KEY UPDATE carry_forward_days = 5.0, opening_balance = 5.0
        ")->execute(['lb-gate-test-01', $companyId, $employeeId, $leaveTypeId, $toYear]);

        // 5. Execute LeaveRolloverService::reopenYear through CodeIgniter service
        require_once dirname(__DIR__) . '/tests/bootstrap.php';
        $rolloverService = new \App\Services\Leave\LeaveRolloverService();
        $reopenResult = $rolloverService->reopenYear($year, $companyId, 'auditor-01', 'Audit reconciliation for 2025');

        $this->record(
            '3. Reopen Ledger Reversal',
            'GATE-LV-07',
            'LeaveRolloverService::reopenYear execution returns success=true',
            ($reopenResult['success'] === true) ? 'PASS' : 'FAIL',
            $reopenResult
        );

        // 6. Verify leave_year_closings status updated to Reopened
        $closingRow = $pdo->query("SELECT status, reopened_by, reopen_reason FROM leave_year_closings WHERE id = '{$closingId}'")->fetch();
        $isReopened = ($closingRow['status'] === 'Reopened');
        $this->record(
            '3. Reopen Ledger Reversal',
            'GATE-LV-08',
            'leave_year_closings status atomically transitioned to Reopened',
            $isReopened ? 'PASS' : 'FAIL',
            $closingRow ?: []
        );

        // 7. Verify reversal transaction for Carry Forward exists with reversal_of pointing to original
        $cfRevTx = $pdo->query("SELECT * FROM leave_transactions WHERE reversal_of = '{$origCfTxId}'")->fetch();
        $cfRevValid = ($cfRevTx && $cfRevTx['transaction_type'] === 'Reversal' && (float)$cfRevTx['days'] === -5.0);
        $this->record(
            '3. Reopen Ledger Reversal',
            'GATE-LV-09',
            'Carry-Forward reversal transaction posted with days=-5.0 and reversal_of reference',
            $cfRevValid ? 'PASS' : 'FAIL',
            $cfRevTx ?: []
        );

        // 8. Verify reversal transaction for Expiration exists with positive restoration
        $expRevTx = $pdo->query("SELECT * FROM leave_transactions WHERE reversal_of = '{$origExpTxId}'")->fetch();
        $expRevValid = ($expRevTx && $expRevTx['transaction_type'] === 'Reversal' && (float)$expRevTx['days'] === 3.0);
        $this->record(
            '3. Reopen Ledger Reversal',
            'GATE-LV-10',
            'Expiration reversal transaction restores expired days with positive days=+3.0',
            $expRevValid ? 'PASS' : 'FAIL',
            $expRevTx ?: []
        );

        // 9. Verify target leave_balances was atomically deducted
        $balRow = $pdo->query("SELECT carry_forward_days, opening_balance FROM leave_balances WHERE employee_id = '{$employeeId}' AND leave_type_id = '{$leaveTypeId}' AND year = {$toYear}")->fetch();
        $balanceDeducted = ($balRow && (float)$balRow['carry_forward_days'] === 0.0 && (float)$balRow['opening_balance'] === 0.0);
        $this->record(
            '3. Reopen Ledger Reversal',
            'GATE-LV-11',
            'Target year leave_balances carry_forward_days & opening_balance atomically deducted',
            $balanceDeducted ? 'PASS' : 'FAIL',
            $balRow ?: []
        );

        // 10. Re-running reopenYear on already reopened year must be blocked
        $secondReopen = $rolloverService->reopenYear($year, $companyId, 'auditor-01', 'Second attempt');
        $secondBlocked = ($secondReopen['success'] === false);
        $this->record(
            '3. Reopen Ledger Reversal',
            'GATE-LV-12',
            'Double-reversal prevention: Re-opening already reopened year is blocked',
            $secondBlocked ? 'PASS' : 'FAIL',
            $secondReopen
        );

        // Cleanup
        $pdo->exec("DELETE FROM leave_transactions WHERE company_id = '{$companyId}'");
        $pdo->exec("DELETE FROM leave_year_closings WHERE id = '{$closingId}'");
        $pdo->exec("DELETE FROM leave_balances WHERE employee_id = '{$employeeId}'");
    }

    private function testRolePermissionsMatrixAndReopenAuthorization(): void
    {
        $pdo = $this->pdo;

        // Query role_permissions join
        $stmt = $pdo->query("
            SELECT r.code as role_code, p.code as perm_code
            FROM role_permissions rp
            JOIN roles r ON r.id = rp.role_id
            JOIN permissions p ON p.id = rp.permission_id
            WHERE p.code IN ('leave.closing_reopen', 'leaves.closing_reopen')
        ");
        $grants = $stmt->fetchAll();
        $grantedRoles = array_unique(array_column($grants, 'role_code'));

        $hasCompanyAdmin = in_array('company_admin', $grantedRoles, true);
        $hasHrAdmin = in_array('hr_admin', $grantedRoles, true);

        $this->record(
            '4. Role Permissions',
            'GATE-LV-13',
            'Migration 000002: role_permissions grants closing_reopen to company_admin & hr_admin',
            ($hasCompanyAdmin && $hasHrAdmin) ? 'PASS' : 'FAIL',
            ['granted_roles' => $grantedRoles]
        );

        // Verify unprivileged roles (hr_officer, branch_manager, employee, finance) do NOT have grant
        $unauthorizedGranted = array_intersect(['hr_officer', 'branch_manager', 'employee', 'finance'], $grantedRoles);
        $this->record(
            '4. Role Permissions',
            'GATE-LV-14',
            'Unprivileged roles (hr_officer, branch_manager, employee, finance) strictly lack closing_reopen',
            empty($unauthorizedGranted) ? 'PASS' : 'FAIL',
            ['unauthorized_found' => array_values($unauthorizedGranted)]
        );
    }
}

if (php_sapi_name() === 'cli' && basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    try {
        $gate = new LeaveReopenRuntimeGate();
        $success = $gate->runAll();
        exit($success ? 0 : 1);
    } catch (\Throwable $e) {
        echo "\033[31m[FATAL ERROR] " . $e->getMessage() . "\033[0m\n";
        exit(1);
    }
}
