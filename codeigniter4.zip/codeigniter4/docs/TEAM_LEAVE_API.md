# Department Leave Calendar API (Team Calendar)

## Overview
The Team Leave Calendar API enables employees to view approved and upcoming leave schedules of colleagues within their own department. This powers the Department Leave Calendar view in the mobile Android HRMS app (Attendance tab).

---

## Endpoints

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/v1/leave/team-calendar` | Primary ESS team leave calendar endpoint |
| `GET` | `/api/v1/leaves/team-calendar` | Plural route alias |
| `GET` | `/api/mobile/v1/leave/team-calendar` | Mobile v1 prefixed route |
| `GET` | `/api/mobile/v1/leaves/team-calendar` | Mobile v1 plural prefixed route |

*(Aliases `/leave/calendar`, `/leaves/calendar`, and `/lleave/team-calendar` are also mapped for client resilience.)*

---

## Authentication & Authorization
- **Header:** `Authorization: Bearer <access_token>`
- **Permissions:** Requires `leave.view` or `leave.create` (implicit self-service read grant).
- **Tenant Scoping:** Strictly isolated to the authenticated caller's `company_id`.
- **Department Boundary:** Automatically restricted to the caller's assigned `department_id`. The client cannot widen the scope to other departments or tenants.

---

## Query Parameters

| Parameter | Type | Required | Default | Description |
|---|---|---|---|---|
| `from` | string | No | First day of current month | Range start date in strict `YYYY-MM-DD` format. |
| `to` | string | No | Last day of current month | Range end date in strict `YYYY-MM-DD` format. |
| `from_date` | string | No | - | Alias for `from`. |
| `to_date` | string | No | - | Alias for `to`. |
| `month` | string / int | No | Current month | `YYYY-MM` or integer `1`-`12`. If provided without `from`/`to`, resolves full month. |
| `year` | int | No | Current year | `YYYY` integer format. |

**Constraints:**
- `from` cannot be after `to`.
- Maximum query span: 366 days.

---

## Privacy & Guardrails
1. **Colleague Privacy:** Unapproved leave applications (`Pending`, `Rejected`, `Cancelled`) of peer colleagues are **strictly hidden**. Peers on the team calendar only see colleagues' `Approved` leaves.
2. **Caller Transparency:** The authenticated caller can see their own `Pending`, `Endorsed`, and `Approved` leaves within the requested date range.
3. **Confidentiality:** Personal leave reasons (`reason`, `remarks`, `rejection_reason`) are omitted from team calendar responses to protect employee medical and personal privacy.
4. **Photo URLs:** If an employee has a profile photo stored as a relative filesystem path (e.g. `uploads/employee_photos/...`), it is automatically normalized to a fully qualified URL using `base_url()`.

---

## Response Contract

### Success Response (`200 OK`)
```json
{
  "success": true,
  "message": "Team leave calendar retrieved successfully.",
  "data": {
    "from": "2026-11-01",
    "to": "2026-11-30",
    "department_id": "dept-tech",
    "leaves": [
      {
        "id": "app-karim-1",
        "employee_id": "emp-2",
        "employee_name": "Karim Uddin",
        "photo_url": "https://hrms.example.com/uploads/employee_photos/karim.jpg",
        "leave_type": "Annual Leave",
        "from_date": "2026-11-05",
        "to_date": "2026-11-07",
        "status": "Approved"
      }
    ]
  }
}
```

### Empty Department State (`200 OK`)
If the employee has no department assigned:
```json
{
  "success": true,
  "message": "No department assigned.",
  "data": {
    "from": "2026-11-01",
    "to": "2026-11-30",
    "department_id": null,
    "leaves": []
  }
}
```

### Error Responses
- **`401 Unauthorized`:** Missing or expired Bearer token.
- **`403 Forbidden`:** Missing `leave.view`/`leave.create` permission or unlinked employee profile.
- **`422 Unprocessable Entity`:** Invalid date format (`from`/`to` not `YYYY-MM-DD`), `from > to`, or span exceeds 366 days.
