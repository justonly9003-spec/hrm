# Attendance Engine Comparison: `RuleEngineService::calculateDailyAttendance` vs `AttendanceRuleEngine::calculateAttendanceForDate`

## 1. Executive Summary

This document provides a comparative analysis of two attendance calculation routines within the CodeIgniter 4 HRMS:
- `App\Services\RuleEngineService::calculateDailyAttendance`
- `App\Services\AttendanceRuleEngine::calculateAttendanceForDate`

Rather than being redundant or conflicting implementations, these two methods operate at complementary layers of the application architecture:
- **`RuleEngineService::calculateDailyAttendance`** is a **pure, fine-grained domain calculation function** for a single employee on a single date.
- **`AttendanceRuleEngine::calculateAttendanceForDate`** is a **coarse-grained batch orchestration and repository service** that loads company/branch/department datasets, manages caching and multi-tenant partitioning, delegates employee evaluation to `RuleEngineService::calculateDailyAttendance`, aggregates summary KPIs, and optionally synchronizes records to the database (`$autoHealDb`).

---

## 2. Method Signatures & Layer Responsibilities

### 2.1 `RuleEngineService::calculateDailyAttendance`
- **Location:** `codeigniter4/app/Services/RuleEngineService.php` (Line ~85)
- **Signature:**
```php
public function calculateDailyAttendance(
    string $date,
    array $employee,
    ?array $log,
    array $ruleProfile = [],
    ?array $shift = null,
    array $leaves = [],
    array $holidays = [],
    ?array $dutyAssignmentLookup = null,
    ?array $weeklyOffLookup = null
): array
```
- **Scope & Responsibility:**
  - Evaluates business rules for exactly **one employee** on **one calendar date**.
  - Side-effect free (in-memory; performs zero database mutations).
  - Enforces joining date restrictions (`BEFORE_JOINING`), future dates (`FUTURE_DATE`), duty roster assignments, dynamic weekend off-days, company/branch holidays, approved leaves, biometric punch pairings, grace periods, half-day / early-out / late thresholds, sandwich rule consequences, and company early closure protections.
  - Returns an associative array containing ~40 calculated fields (`date`, `employee_id`, `status`, `check_in`, `check_out`, `gross_hours`, `break_hours`, `net_hours`, `credited_hours`, `total_effective_hours`, `late_minutes`, `is_late`, `early_out_minutes`, `is_early_out`, `daily_overtime_hours`, `off_day_overtime_hours`, `holiday_overtime_hours`, `loss_of_pay_days`, `payable_days`, etc.).

### 2.2 `AttendanceRuleEngine::calculateAttendanceForDate`
- **Location:** `codeigniter4/app/Services/AttendanceRuleEngine.php` (Line ~48)
- **Signature:**
```php
public function calculateAttendanceForDate(
    string $date,
    ?string $branchId = null,
    ?string $deptId = null,
    ?string $companyId = null,
    ?string $statusFilter = null,
    ?string $search = null,
    ?array $preloadedEmployees = null,
    bool $autoHealDb = false,
    bool $exceptHolidaysWeekends = false
): array
```
- **Scope & Responsibility:**
  - Evaluates attendance across **all employees** in a company, branch, or department for a given date.
  - Handles multi-tenant company isolation: if `$companyId` is omitted, partitions employees and delegates per-company via `calculateAttendanceForDateMultiCompany()`.
  - Maintains per-request in-memory cache keyed by `{$companyId}|{$branchId}|{$deptId}|{$date}|{$exceptHolidaysWeekends}`.
  - Batch queries and preloads employees, shifts, duty assignments, holidays, leave applications, and raw biometric punches (`unmatched_biometric_logs` / punch events).
  - Iterates over each employee and delegates row evaluation directly to:
    ```php
    $calc = $this->ruleEngine->calculateDailyAttendance($date, $emp, $empLog, $profile, $shift, $leaves, $candidateHolidays, $dutyLookup, $weeklyOffLookup);
    ```
  - Aggregates daily KPI metrics (Total Staff, Present, Late, Early Out, Absent, On Leave, Weekly Off, Holiday, and Average Work Hours).
  - Supports persistence / auto-healing (`$autoHealDb = true`), creating or updating rows in the `attendance` table.

---

## 3. Inventory of Callers

### 3.1 Callers of `AttendanceRuleEngine::calculateAttendanceForDate`
1. **`App\Controllers\Attendance\AttendanceController::index`** (Line ~329) — Powers the web UI Daily Attendance view.
2. **`App\Controllers\Attendance\AttendanceController::exportDailyReport`** (Line ~1955) — Powers daily attendance PDF and CSV exports.
3. **`App\Models\AttendanceModel::getAttendanceSummaryForDate`** (Line ~356) — Supplies summary KPI cards for dashboards.
4. **`App\Services\DashboardWidgetDataProvider::getAttendanceOverview`** (Line ~579) — Dashboard widget statistics.
5. **`App\Services\DashboardWidgetDataProvider::getExecutiveSummary`** (Line ~1192) — Executive dashboard attendance metrics.
6. **`App\Commands\VerifyAttendanceBuckets`** (Lines ~234, ~349) — CLI verification test suite.
7. **`App\Commands\VerifyDashboardAttendanceParity`** (Lines ~189, ~303) — CLI dashboard parity audit.
8. **`Tests\Unit\CompanyEarlyClosureTest`** (Line ~779) — Unit test for DB auto-heal workflow.
9. **`Tests\Unit\AttendancePointInTimeTenureTest`** (Lines ~70, ~89, ~176, ~191) — Unit tests for tenure-based calculation.

### 3.2 Callers of `RuleEngineService::calculateDailyAttendance`
1. **`App\Services\AttendanceRuleEngine::calculateAttendanceForDate`** (Line ~640) — **Primary orchestrator caller!** Evaluates each employee's daily metrics.
2. **`Tests\Unit\CompanyEarlyClosureTest`** (Lines ~638, ~655, ~670, ~801) — Unit tests verifying early closure hour preservation and status protection.
3. **`Tests\Unit\LeaveCreditedHoursAttendanceTest`** (Lines ~327, ~375) — Unit tests verifying credited hours on leave days.
4. **`Tests\Unit\AttendanceMultiTenantScopingTest`** (Lines ~109, ~110, ~377, ~378, ~427, ~428, ~485, ~492) — Unit tests verifying tenant isolation in daily evaluations.
5. **`Tests\Unit\CompanyWeekendPolicyTest`** (Lines ~66, ~78, ~85, ~121, ~132, ~139) — Unit tests verifying weekend policy rules across dates.

---

## 4. Key Differences Matrix

| Feature | `RuleEngineService::calculateDailyAttendance` | `AttendanceRuleEngine::calculateAttendanceForDate` |
|---|---|---|
| **Architectural Layer** | Domain Service (Mathematical Rules Evaluator) | Application Service / Orchestrator |
| **Input Cardinality** | 1 employee, 1 date | N employees, 1 date (or date range) |
| **Side Effects / DB Writes** | None (pure in-memory) | Optional write-back (`$autoHealDb = true`) to `attendance` table |
| **Data Fetching / Lookups** | Relies on preloaded arrays passed by caller | Queries database models (`EmployeeModel`, `ShiftModel`, `LeaveModel`, etc.) |
| **Tenant Isolation** | Evaluates provided tenant profile | Enforces tenant scope and partitions multi-tenant batches |
| **Caching** | None (caller manages cache) | In-memory static `$calculationCache` keyed by scope and filters |
| **Output** | Single employee attendance calculation record (~40 keys) | Aggregated response with `summary` KPIs + `detailedLogs` list |
| **Relationship** | Called by `AttendanceRuleEngine` | Caller of `RuleEngineService` |

---

## 5. Keep vs. Merge Recommendation

### Recommendation: **KEEP BOTH (Do Not Merge)**

### Technical Justification:
1. **Clean Separation of Concerns:**
   `calculateDailyAttendance` is a pure business computation. It does not perform I/O, SQL queries, or HTTP caching. Keeping this decoupled from database access enables rapid, deterministic unit testing and ensures business rule logic can be reused in non-web contexts (such as payroll runs, retroactive salary simulations, or biometric sync events).
2. **Existing Composition:**
   `AttendanceRuleEngine::calculateAttendanceForDate` already invokes `RuleEngineService::calculateDailyAttendance` internally at line 640. Merging them into a single monolithic method would pollute the pure mathematical evaluation with data loading, query building, filter loops, and database update logic.
3. **Refactoring Roadmap:**
   In future architecture cleanups, `RuleEngineService::calculateDailyAttendance` should be migrated to `App\Services\Rules\Attendance\DailyAttendanceCalculator` under the Single Rule Store hierarchy (`rule_definitions`), while `AttendanceRuleEngine` remains the top-level repository facade and reporting orchestrator.
