#!/usr/bin/env bash
set -e

# Resolve directory to codeigniter4 root
if [ -d "codeigniter4/app" ]; then
    BASE_DIR="codeigniter4"
elif [ -d "app" ]; then
    BASE_DIR="."
else
    echo "Error: Cannot locate CodeIgniter 4 root directory."
    exit 1
fi

cd "$BASE_DIR"

echo "============================================================"
echo "  Enterprise HRMS - Single Source of Truth Rule Verification"
echo "============================================================"
echo ""

TOTAL_FAILURES=0

run_check() {
    local check_title="$1"
    local command="$2"
    
    local count
    count=$(eval "$command" | grep -v "^$" | wc -l | tr -d ' ')
    
    if [ "$count" -eq 0 ]; then
        printf " [PASS] %-55s (count: %s)\n" "$check_title" "$count"
    else
        printf " [FAIL] %-55s (count: %s)\n" "$check_title" "$count"
        echo "   Command: $command"
        eval "$command" | head -n 10 | sed 's/^/   > /'
        TOTAL_FAILURES=$((TOTAL_FAILURES + 1))
    fi
}

# 1. RuleResolver has no literal fallbacks
run_check "RuleResolver literal fallbacks (?? [0-9'\"])" \
    'grep -nE "\\?\\? [0-9'\''\"]" app/Services/Rules/RuleResolver.php || true'

# 2. No legacy final-settlement hyphenated routes
run_check "Legacy final-settlement route calls" \
    "grep -rn \"final-settlement\" app || true"

# 3. No legacy TaxRuleModel outside migrations
run_check "Legacy TaxRuleModel in Services/Controllers" \
    "grep -rn \"TaxRuleModel\" app/Services app/Controllers --include=*.php || true"

# 4. No ProvidentFundRuleModel in services
run_check "ProvidentFundRuleModel in Services" \
    "grep -rn \"ProvidentFundRuleModel\" app/Services --include=*.php || true"

# 5. No OvertimePolicyModel in services
run_check "OvertimePolicyModel in Services" \
    "grep -rn \"OvertimePolicyModel\" app/Services --include=*.php || true"

# 6. No legacy bonus_schemes table query in BonusService
run_check "Legacy bonus_schemes in BonusService" \
    "grep -rn \"bonus_schemes\" app/Services/BonusService.php || true"

# 7. No legacy AttendanceRuleProfileModel in services or controllers
run_check "Legacy AttendanceRuleProfileModel in Services/Controllers" \
    "grep -rn \"AttendanceRuleProfileModel\" app/Services app/Controllers --include=*.php || true"

# 8. Fallback allowlist verification
if [ -f "tests/unit/Rules/fallback_allowlist.json" ]; then
    printf " [PASS] %-55s (exists)\n" "Fallback allowlist configuration"
else
    printf " [FAIL] %-55s (missing)\n" "Fallback allowlist configuration"
    TOTAL_FAILURES=$((TOTAL_FAILURES + 1))
fi

# 9. Route-level permission/role/admin filter verification on POST/PUT/DELETE routes
if command -v python3 >/dev/null 2>&1 && [ -f "verify_route_filters.py" ]; then
    if python3 verify_route_filters.py >/dev/null 2>&1; then
        printf " [PASS] %-55s (count: 0)\n" "Write routes missing permission/role/admin filter"
    else
        printf " [FAIL] %-55s\n" "Write routes missing permission/role/admin filter"
        python3 verify_route_filters.py | sed 's/^/   > /' || true
        TOTAL_FAILURES=$((TOTAL_FAILURES + 1))
    fi
fi

# 10. PHP syntax verification check (php -l)
if command -v php >/dev/null 2>&1; then
    run_check "PHP syntax verification (php -l)" \
        "find app -name '*.php' | xargs -n1 php -l 2>&1 | grep -v 'No syntax errors' || true"
fi

echo ""
if command -v php >/dev/null 2>&1 && [ -f "vendor/bin/phpunit" ]; then
    echo "Running PHPUnit SchemaContractTest..."
    if vendor/bin/phpunit tests/unit/Rules/SchemaContractTest.php; then
        printf " [PASS] %-55s\n" "SchemaContractTest"
    else
        printf " [FAIL] %-55s\n" "SchemaContractTest"
        TOTAL_FAILURES=$((TOTAL_FAILURES + 1))
    fi
else
    echo "Notice: PHP/PHPUnit binary not present in environment; automated PHP execution skipped."
fi

echo ""
echo "============================================================"
if [ "$TOTAL_FAILURES" -eq 0 ]; then
    echo "  ALL CHECKS PASSED: Single Source of Truth rules verified."
    echo "============================================================"
    exit 0
else
    echo "  VERIFICATION FAILED: $TOTAL_FAILURES check(s) failed."
    echo "============================================================"
    exit 1
fi
