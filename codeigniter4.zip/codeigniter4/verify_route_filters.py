#!/usr/bin/env python3
"""
Verify that every POST/PUT/PATCH/DELETE route in app/Config/Routes.php has an
explicit permission/role/admin filter and is not covered only by a '.view'
filter or bare auth filter.

Exits with code 1 if any unprotected write route is found.
"""

import os
import re
import sys
from typing import Dict, List, Optional, Set, Tuple

# Public unauthenticated auth, hardware API-key ingestion, & external X-Cron-Key webhook routes
PUBLIC_WRITE_ALLOWLIST: Set[str] = {
    "login",
    "logout",
    "forgot-password",
    "reset-password",
    "verify-reset-code",
    "change-password",
    "auth/verify-2fa",
    "auth/login",
    "auth/logout",
    "auth/forgot-password",
    "auth/reset-password",
    "auth/verify-reset-code",
    "auth/change-password",
    "api/mobile/v1/auth/login",
    "api/mobile/v1/auth/refresh",
    "api/v1/auth/login",
    "api/v1/auth/refresh",
    "api/attendance/zk-push",
    "api/attendance/push-punch",
    "api/biometrics/enroll",
    "attendance/sync/api/push-punch",
    "attendance/sync/api/enroll",
    "cron/scheduler",
    "cron/daily",
    "cron/weekly",
    "cron/monthly",
}

WRITE_METHODS = {"post", "put", "patch", "delete"}


def extract_filters_from_options(options_str: str) -> List[str]:
    """Extract filter strings from a PHP options array snippet like ['filter' => ...]."""
    if not options_str or "'filter'" not in options_str and '"filter"' not in options_str:
        return []

    # Match ['filter' => ['a', 'b']] or ['filter' => 'a']
    arr_match = re.search(
        r"""['"]filter['"]\s*=>\s*\[([^\]]*)\]""", options_str
    )
    if arr_match:
        inner = arr_match.group(1)
        return re.findall(r"""['"]([^'"]+)['"]""", inner)

    str_match = re.search(
        r"""['"]filter['"]\s*=>\s*['"]([^'"]+)['"]""", options_str
    )
    if str_match:
        return [str_match.group(1)]

    return []


def has_qualifying_write_filter(
    route_filters: List[str], group_filters: List[str]
) -> Tuple[bool, str]:
    """
    Determine whether a write route has a valid permission/role/admin filter
    and is not covered solely by a '.view' filter or bare auth filter.
    """
    all_filters = list(group_filters) + list(route_filters)

    authz_filters: List[str] = []
    for f in all_filters:
        f_clean = f.strip()
        if (
            f_clean in ("platformAdmin", "companyAdmin", "admin", "role", "mobileAuth")
            or f_clean.startswith("permission:")
            or f_clean.startswith("role:")
        ):
            authz_filters.append(f_clean)

    if not authz_filters:
        return False, "missing permission/role/admin filter"

    # Check if any admin, role, or mobileAuth filter is present
    for f in authz_filters:
        if f in ("platformAdmin", "companyAdmin", "admin", "mobileAuth") or f.startswith("role:"):
            return True, ""

    # Check permission filters: ensure at least one non-.view permission is required on the route
    # and if the group only provides a .view filter, the route itself must declare a write permission.
    route_authz = [
        f.strip()
        for f in route_filters
        if f.strip() in ("platformAdmin", "companyAdmin", "admin", "mobileAuth")
        or f.strip().startswith("permission:")
        or f.strip().startswith("role:")
    ]

    if not route_authz:
        return False, f"covered only by group filter(s) {group_filters} without route-level write filter"

    non_view_perms: List[str] = []
    for f in route_authz:
        if f in ("platformAdmin", "companyAdmin", "admin") or f.startswith("role:"):
            non_view_perms.append(f)
            continue
        if f.startswith("permission:"):
            codes = [
                c.strip()
                for c in re.split(r"[|,]", f[len("permission:") :])
                if c.strip()
            ]
            for c in codes:
                if not c.endswith(".view"):
                    non_view_perms.append(c)

    if not non_view_perms:
        return False, f"covered only by '.view' permission filter ({route_authz})"

    return True, ""


def join_uri(prefix: str, path: str) -> str:
    prefix = prefix.strip("/")
    path = path.strip("/")
    if prefix and path:
        return f"{prefix}/{path}"
    return prefix or path or "/"


def parse_routes_file(filepath: str) -> List[Dict]:
    with open(filepath, "r", encoding="utf-8") as f:
        lines = f.readlines()

    # First pass: collect named closure definitions like $leaveRoutesDefinition = function ($routes) { ... };
    named_closures: Dict[str, List[Tuple[int, str]]] = {}
    in_named_closure: Optional[str] = None
    named_closure_depth = 0

    for idx, raw_line in enumerate(lines, start=1):
        stripped = raw_line.strip()
        if stripped.startswith("//") or stripped.startswith("#") or stripped.startswith("*"):
            continue

        if in_named_closure is None:
            m = re.match(
                r"^\$([A-Za-z0-9_]+)\s*=\s*function\s*\(\s*\$routes\s*\)\s*\{",
                stripped,
            )
            if m:
                in_named_closure = m.group(1)
                named_closures[in_named_closure] = []
                named_closure_depth = raw_line.count("{") - raw_line.count("}")
                continue
        else:
            named_closure_depth += raw_line.count("{") - raw_line.count("}")
            if named_closure_depth <= 0:
                in_named_closure = None
            else:
                named_closures[in_named_closure].append((idx, raw_line))

    routes_found: List[Dict] = []

    def parse_route_line(
        line_no: int,
        line: str,
        current_prefix: str,
        current_group_filters: List[str],
    ) -> None:
        stripped = line.strip()
        if stripped.startswith("//") or stripped.startswith("#"):
            return

        # Direct verb: $routes->(post|put|patch|delete)('uri', 'handler', [options]);
        m_verb = re.match(
            r"""^\$routes->(post|put|patch|delete)\s*\(\s*['"]([^'"]*)['"]\s*,\s*['"][^'"]+['"]\s*(?:,\s*(\[.*\]))?\s*\)\s*;""",
            stripped,
            re.IGNORECASE,
        )
        if m_verb:
            verb = m_verb.group(1).lower()
            uri = join_uri(current_prefix, m_verb.group(2))
            opts = m_verb.group(3) or ""
            r_filters = extract_filters_from_options(opts)
            routes_found.append(
                {
                    "line": line_no,
                    "methods": [verb.upper()],
                    "uri": uri,
                    "group_filters": list(current_group_filters),
                    "route_filters": r_filters,
                }
            )
            return

        # Match verb: $routes->match(['post', ...], 'uri', 'handler', [options]);
        m_match = re.match(
            r"""^\$routes->match\s*\(\s*\[([^\]]+)\]\s*,\s*['"]([^'"]*)['"]\s*,\s*['"][^'"]+['"]\s*(?:,\s*(\[.*\]))?\s*\)\s*;""",
            stripped,
            re.IGNORECASE,
        )
        if m_match:
            methods_raw = re.findall(r"""['"]([^'"]+)['"]""", m_match.group(1))
            methods_lower = [m.lower() for m in methods_raw]
            if any(m in WRITE_METHODS for m in methods_lower):
                uri = join_uri(current_prefix, m_match.group(2))
                opts = m_match.group(3) or ""
                r_filters = extract_filters_from_options(opts)
                routes_found.append(
                    {
                        "line": line_no,
                        "methods": [m.upper() for m in methods_lower if m in WRITE_METHODS],
                        "uri": uri,
                        "group_filters": list(current_group_filters),
                        "route_filters": r_filters,
                    }
                )

    # Second pass: walk group stack
    # Stack items: (prefix, group_filters, brace_depth_at_entry)
    group_stack: List[Tuple[str, List[str], int]] = []
    brace_depth = 0
    skip_named_closure_depth = 0

    for idx, raw_line in enumerate(lines, start=1):
        stripped = raw_line.strip()
        if stripped.startswith("//") or stripped.startswith("#") or stripped.startswith("*"):
            continue

        # Skip body of named closure definitions (expanded when referenced by $routes->group)
        if skip_named_closure_depth > 0:
            skip_named_closure_depth += raw_line.count("{") - raw_line.count("}")
            if skip_named_closure_depth <= 0:
                skip_named_closure_depth = 0
            continue

        if re.match(
            r"^\$([A-Za-z0-9_]+)\s*=\s*function\s*\(\s*\$routes\s*\)\s*\{",
            stripped,
        ):
            skip_named_closure_depth = raw_line.count("{") - raw_line.count("}")
            continue

        current_prefix = ""
        current_filters: List[str] = []
        for g_prefix, g_filters, _ in group_stack:
            current_prefix = join_uri(current_prefix, g_prefix)
            current_filters.extend(g_filters)

        # Group with named closure variable: $routes->group('leave', ['filter' => ...], $leaveRoutesDefinition);
        m_group_var = re.match(
            r"""^\$routes->group\s*\(\s*['"]([^'"]*)['"]\s*,\s*(?:(\[.*\])\s*,\s*)?\$([A-Za-z0-9_]+)\s*\)\s*;""",
            stripped,
        )
        if m_group_var:
            grp_prefix = m_group_var.group(1)
            grp_opts = m_group_var.group(2) or ""
            var_name = m_group_var.group(3)
            grp_filters = extract_filters_from_options(grp_opts)
            combined_prefix = join_uri(current_prefix, grp_prefix)
            combined_filters = current_filters + grp_filters
            for c_line_no, c_line in named_closures.get(var_name, []):
                parse_route_line(c_line_no, c_line, combined_prefix, combined_filters)
            continue

        # Group with inline closure: $routes->group('...', ..., function ($routes) {
        m_group_inline = re.match(
            r"""^\$routes->group\s*\(\s*['"]([^'"]*)['"]\s*,\s*(?:(\[.*\])\s*,\s*)?function\s*\(\s*\$routes\s*\)\s*\{""",
            stripped,
        )
        if m_group_inline:
            grp_prefix = m_group_inline.group(1)
            grp_opts = m_group_inline.group(2) or ""
            grp_filters = extract_filters_from_options(grp_opts)
            group_stack.append((grp_prefix, grp_filters, brace_depth))
            brace_depth += raw_line.count("{") - raw_line.count("}")
            continue

        parse_route_line(idx, raw_line, current_prefix, current_filters)

        brace_depth += raw_line.count("{") - raw_line.count("}")
        while group_stack and brace_depth <= group_stack[-1][2]:
            group_stack.pop()

    return routes_found


def main() -> int:
    script_dir = os.path.dirname(os.path.abspath(__file__))
    routes_path = os.path.join(script_dir, "app", "Config", "Routes.php")
    if not os.path.isfile(routes_path):
        routes_path = os.path.join(
            script_dir, "codeigniter4", "app", "Config", "Routes.php"
        )

    if not os.path.isfile(routes_path):
        print(f"ERROR: Could not find Routes.php at {routes_path}", file=sys.stderr)
        return 1

    write_routes = parse_routes_file(routes_path)
    violations: List[Dict] = []
    checked_count = 0

    for r in write_routes:
        uri = r["uri"].strip("/")
        if uri in PUBLIC_WRITE_ALLOWLIST:
            continue

        checked_count += 1
        ok, reason = has_qualifying_write_filter(
            r["route_filters"], r["group_filters"]
        )
        if not ok:
            violations.append({**r, "reason": reason})

    if violations:
        print(
            f"[FAIL] Found {len(violations)} write route(s) missing a route-level permission/role/admin filter:"
        )
        for v in violations:
            methods_str = "|".join(v["methods"])
            print(
                f"  - Line {v['line']:4d}: [{methods_str}] /{v['uri']} -> {v['reason']}"
            )
        return 1

    print(
        f"[PASS] Verified {checked_count} protected POST/PUT/PATCH/DELETE write routes in app/Config/Routes.php; 0 missing permission/role/admin filters."
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
