<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class Auth extends BaseConfig
{
    /**
     * Secret key for signing JSON Web Tokens (JWT).
     *
     * SECURITY & KEY ROTATION:
     * Previously, a default key ('enterprise_hcm_super_secure_jwt_secret_key_2026') was hardcoded here.
     * To rotate the key:
     * 1. Generate a strong, cryptographically secure secret (e.g. `openssl rand -hex 32` or `bin2hex(random_bytes(32))`).
     * 2. Set the `JWT_SECRET` environment variable in your production environment or `.env` file:
     *    `JWT_SECRET=<new_secret_key>`
     * 3. Restart the server/daemon process.
     * 4. Any previously signed tokens using the old secret key will fail signature verification,
     *    requiring clients and devices to re-authenticate with the server.
     */
    public string $jwtSecret = '';

    /**
     * JWT Expiry time in seconds (default 24 hours)
     */
    public int $jwtExpiry = 86400;

    /**
     * Password hash algorithm
     */
    public string $hashAlgorithm = PASSWORD_BCRYPT;

    /**
     * Password hash options
     */
    public array $hashOptions = [
        'cost' => 12,
    ];

    public function __construct()
    {
        parent::__construct();

        $secret = env('JWT_SECRET');
        if (is_string($secret)) {
            $secret = trim($secret);
        }

        $environment = defined('ENVIRONMENT') ? ENVIRONMENT : (env('CI_ENVIRONMENT') ?: 'development');
        $isProduction = (strtolower((string)$environment) === 'production');

        if (empty($secret)) {
            if ($isProduction) {
                throw new \RuntimeException(
                    'CRITICAL SECURITY CONFIGURATION ERROR: JWT_SECRET environment variable is missing or empty in production. ' .
                    'A secure JWT_SECRET must be configured in your environment or .env file before the application can boot.'
                );
            }

            // In non-production environments (development/testing), fallback to a non-production development secret
            $secret = 'development_only_jwt_secret_key_not_for_production';
        }

        $this->jwtSecret = (string)$secret;
    }
}

