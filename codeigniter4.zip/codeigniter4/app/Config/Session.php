<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class Session extends BaseConfig
{
    /**
     * Session Driver
     */
    public string $driver = 'CodeIgniter\Session\Handlers\FileHandler';

    /**
     * Session Cookie Name
     */
    public string $cookieName = 'ci_session';

    /**
     * Session Expiration (in seconds, 7200 = 2 hours)
     */
    public int $expiration = 7200;

    /**
     * Session Save Path (default WRITEPATH . 'session')
     */
    public string $savePath = WRITEPATH . 'session';

    /**
     * Match IP
     */
    public bool $matchIP = false;

    /**
     * Time to update session ID
     */
    public int $timeToUpdate = 300;

    /**
     * Regenerate Destroy
     */
    public bool $regenerateDestroy = true;

    /**
     * Session Database Group (when using DatabaseHandler)
     */
    public ?string $DBGroup = null;

    /**
     * Bind active session to the client User-Agent fingerprint
     */
    public bool $bindUserAgent = true;

    public function __construct()
    {
        parent::__construct();

        $driver = env('session.driver', env('app.sessionDriver'));
        if (is_string($driver) && $driver !== '') {
            $this->driver = trim($driver, "\"'");
        }

        $cookieName = env('session.cookieName', env('app.sessionCookieName'));
        if (is_string($cookieName) && $cookieName !== '') {
            $this->cookieName = trim($cookieName, "\"'");
        }

        $expiration = env('session.expiration', env('app.sessionExpiration'));
        if ($expiration !== null && $expiration !== '') {
            $this->expiration = (int) $expiration;
        }

        $savePath = env('session.savePath', env('app.sessionSavePath'));
        if (is_string($savePath) && $savePath !== '') {
            $this->savePath = $savePath;
        }

        $matchIP = env('session.matchIP', env('app.sessionMatchIP'));
        if ($matchIP !== null && $matchIP !== '') {
            $this->matchIP = filter_var($matchIP, FILTER_VALIDATE_BOOLEAN);
        }

        $timeToUpdate = env('session.timeToUpdate', env('app.sessionTimeToUpdate'));
        if ($timeToUpdate !== null && $timeToUpdate !== '') {
            $this->timeToUpdate = (int) $timeToUpdate;
        }

        $regenerateDestroy = env('session.regenerateDestroy', env('app.sessionRegenerateDestroy'));
        if ($regenerateDestroy !== null && $regenerateDestroy !== '') {
            $this->regenerateDestroy = filter_var($regenerateDestroy, FILTER_VALIDATE_BOOLEAN);
        }

        $dbGroup = env('session.DBGroup', env('app.sessionDBGroup'));
        if (is_string($dbGroup) && $dbGroup !== '') {
            $this->DBGroup = $dbGroup;
        }

        $bindUserAgent = env('session.bindUserAgent', env('app.sessionBindUserAgent'));
        if ($bindUserAgent !== null && $bindUserAgent !== '') {
            $this->bindUserAgent = filter_var($bindUserAgent, FILTER_VALIDATE_BOOLEAN);
        }
    }
}

