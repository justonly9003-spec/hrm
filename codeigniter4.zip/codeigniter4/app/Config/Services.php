<?php

namespace Config;

use CodeIgniter\Config\BaseService;

/**
 * Services Configuration file.
 *
 * Services are simply other classes/libraries that the system uses
 * to do its job. This is used by CodeIgniter to allow the core of the
 * framework to be swapped out easily without affecting the usage within
 * the rest of your application.
 *
 * This file holds any application-specific services, or service overrides
 * that you might need. An example has been included with the general
 * method format you should use for your service methods. For more examples,
 * see the core Services file at system/Config/Services.php.
 */
class Services extends BaseService
{
    public static function salary(bool $getShared = true)
    {
        if ($getShared) {
            return static::getSharedInstance('salary');
        }

        return new \App\Services\EmployeeSalaryService();
    }

    public static function menuVisibility(bool $getShared = true)
    {
        if ($getShared) {
            return static::getSharedInstance('menuVisibility');
        }

        return new \App\Services\MenuVisibilityService();
    }

    public static function rbac(bool $getShared = true)
    {
        if ($getShared) {
            return static::getSharedInstance('rbac');
        }

        return new \App\Services\PermissionService();
    }

    public static function permission(bool $getShared = true)
    {
        if ($getShared) {
            return static::getSharedInstance('permission');
        }

        return new \App\Services\PermissionService();
    }

    public static function permissionService(bool $getShared = true)
    {
        if ($getShared) {
            return static::getSharedInstance('permissionService');
        }

        return new \App\Services\PermissionService();
    }
}
