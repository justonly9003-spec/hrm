<?php

namespace Config;

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Dashboard\DashboardController');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(false);

// Favicon Direct Routes
$routes->get('favicon.ico', static function () {
    $paths = [
        FCPATH . 'favicon.ico',
        ROOTPATH . 'public/favicon.ico',
        ROOTPATH . '../public/favicon.ico'
    ];
    foreach ($paths as $path) {
        if (file_exists($path)) {
            return service('response')
                ->setHeader('Content-Type', 'image/x-icon')
                ->setHeader('Cache-Control', 'public, max-age=86400')
                ->setBody(file_get_contents($path));
        }
    }
    return service('response')->setStatusCode(404);
});

$routes->get('favicon.svg', static function () {
    $paths = [
        FCPATH . 'favicon.svg',
        ROOTPATH . 'public/favicon.svg',
        ROOTPATH . '../public/favicon.svg'
    ];
    foreach ($paths as $path) {
        if (file_exists($path)) {
            return service('response')
                ->setHeader('Content-Type', 'image/svg+xml')
                ->setHeader('Cache-Control', 'public, max-age=86400')
                ->setBody(file_get_contents($path));
        }
    }
    return service('response')->setStatusCode(404);
});

// Top-level Auth Aliases
$routes->get('login', 'Auth\AuthController::login');
$routes->post('login', 'Auth\AuthController::attemptLogin');
$routes->post('logout', 'Auth\AuthController::logout');
$routes->get('forgot-password', 'Auth\PasswordController::forgotPassword');
$routes->post('forgot-password', 'Auth\PasswordController::sendResetLink');
$routes->get('reset-password', 'Auth\PasswordController::showResetPassword');
$routes->post('reset-password', 'Auth\PasswordController::attemptResetPassword');
$routes->post('verify-reset-code', 'Auth\PasswordController::verifyResetCode');
$routes->get('change-password', 'Auth\PasswordController::showChangePassword');
$routes->post('change-password', 'Auth\PasswordController::changePassword');
$routes->get('auth/verify-2fa', 'Auth\AuthController::showTwoFactor');
$routes->post('auth/verify-2fa', 'Auth\AuthController::verifyTwoFactor');

// Mobile API v1 (token-authenticated; see App\Filters\MobileAuthFilter)
$routes->group('api/mobile/v1', ['namespace' => 'App\Controllers\Mobile'], function ($routes) {
    $routes->post('auth/login', 'MobileAuthController::login');
    $routes->post('auth/refresh', 'MobileAuthController::refresh');
    $routes->post('auth/logout', 'MobileAuthController::logout', ['filter' => 'mobileAuth']);
    $routes->post('auth/logout-all', 'MobileAuthController::logoutAll', ['filter' => 'mobileAuth']);
    $routes->get('auth/me', 'MobileAuthController::me', ['filter' => 'mobileAuth']);
    $routes->post('auth/change-password', 'MobileAuthController::changePassword', ['filter' => 'mobileAuth']);
    $routes->get('company/details/(:segment)', 'MobileCompanyController::details/$1');
    $routes->get('company/details', 'MobileCompanyController::details');
    $routes->get('company/(:segment)', 'MobileCompanyController::details/$1');

    $routes->get('dashboard', 'MobileDashboardController::index', ['filter' => 'mobileAuth']);
    $routes->get('profile', 'MobileProfileController::show', ['filter' => 'mobileAuth']);
    $routes->get('profile/details', 'MobileProfileController::details', ['filter' => 'mobileAuth']);
    $routes->post('profile/photo', 'MobileProfileController::uploadPhoto', ['filter' => 'mobileAuth']);

    $routes->get('attendance/today', 'MobileAttendanceController::today', ['filter' => 'mobileAuth']);
    $routes->get('attendance/effective-shift', 'MobileAttendanceController::effectiveShift', ['filter' => 'mobileAuth']);
    $routes->get('attendance/roster', 'MobileAttendanceController::myRoster', ['filter' => 'mobileAuth']);
    $routes->get('roster/my', 'MobileAttendanceController::myRoster', ['filter' => 'mobileAuth']);
    $routes->get('attendance/shifts/upcoming', 'MobileAttendanceController::upcomingShifts', ['filter' => 'mobileAuth']);
    $routes->get('roster/upcoming', 'MobileAttendanceController::upcomingShifts', ['filter' => 'mobileAuth']);
    $routes->get('attendance/shift-changes', 'MobileAttendanceController::shiftChanges', ['filter' => 'mobileAuth']);
    $routes->get('roster/shift-changes', 'MobileAttendanceController::shiftChanges', ['filter' => 'mobileAuth']);
    $routes->get('attendance/history', 'MobileAttendanceController::history', ['filter' => 'mobileAuth']);
    $routes->get('attendance/summary', 'MobileAttendanceController::summary', ['filter' => 'mobileAuth']);
    $routes->post('attendance/check-in', 'MobileAttendanceController::checkIn', ['filter' => 'mobileAuth']);
    $routes->post('attendance/check-out', 'MobileAttendanceController::checkOut', ['filter' => 'mobileAuth']);
    $routes->get('attendance/reconciliation', 'MobileAttendanceController::reconciliations', ['filter' => 'mobileAuth']);
    $routes->post('attendance/reconciliation', 'MobileAttendanceController::reconcile', ['filter' => 'mobileAuth']);
    $routes->get('attendance/reconciliation/approvals', 'MobileAttendanceController::reconApprovals', ['filter' => 'mobileAuth']);
    $routes->post('attendance/reconciliation/(:segment)/approve', 'MobileAttendanceController::approveRecon/$1', ['filter' => 'mobileAuth']);
    $routes->post('attendance/reconciliation/(:segment)/reject', 'MobileAttendanceController::rejectRecon/$1', ['filter' => 'mobileAuth']);

    $routes->get('salary', 'MobileSalaryController::show', ['filter' => 'mobileAuth']);
    $routes->get('salary/history', 'MobileSalaryController::history', ['filter' => 'mobileAuth']);
    $routes->get('payroll/salary', 'MobileSalaryController::show', ['filter' => 'mobileAuth']);
    $routes->get('payroll/salary/history', 'MobileSalaryController::history', ['filter' => 'mobileAuth']);

    $routes->get('payroll/summary', 'MobilePayslipController::summary', ['filter' => 'mobileAuth']);
    $routes->get('payslips/summary', 'MobilePayslipController::summary', ['filter' => 'mobileAuth']);
    $routes->get('payroll/history', 'MobilePayslipController::index', ['filter' => 'mobileAuth']);
    $routes->get('payslips/history', 'MobilePayslipController::index', ['filter' => 'mobileAuth']);
    $routes->get('payroll/payslips', 'MobilePayslipController::index', ['filter' => 'mobileAuth']);
    $routes->get('payslips', 'MobilePayslipController::index', ['filter' => 'mobileAuth']);
    $routes->get('statements/salary', 'MobileStatementController::salary', ['filter' => 'mobileAuth']);
    $routes->get('statements/tax', 'MobileStatementController::tax', ['filter' => 'mobileAuth']);
    $routes->get('statements/pf', 'MobileStatementController::pf', ['filter' => 'mobileAuth']);
    $routes->get('statements/(:segment)', 'MobileStatementController::show/$1', ['filter' => 'mobileAuth']);
    $routes->get('statements', 'MobileStatementController::salary', ['filter' => 'mobileAuth']);
    $routes->get('payroll/payslips/(:segment)/pdf', 'MobilePayslipController::pdf/$1', ['filter' => 'mobileAuth']);
    $routes->get('payslips/(:segment)/pdf', 'MobilePayslipController::pdf/$1', ['filter' => 'mobileAuth']);
    $routes->get('payroll/payslips/(:segment)', 'MobilePayslipController::show/$1', ['filter' => 'mobileAuth']);
    $routes->get('payslips/(:segment)', 'MobilePayslipController::show/$1', ['filter' => 'mobileAuth']);
    $routes->get('pf', 'MobilePfController::summary', ['filter' => 'mobileAuth']);
    $routes->post('pf', 'MobilePfController::summary', ['filter' => 'mobileAuth']);
    $routes->get('pf/summary', 'MobilePfController::summary', ['filter' => 'mobileAuth']);
    $routes->post('pf/summary', 'MobilePfController::summary', ['filter' => 'mobileAuth']);
    $routes->get('pf/ledger', 'MobilePfController::ledger', ['filter' => 'mobileAuth']);
    $routes->post('pf/ledger', 'MobilePfController::ledger', ['filter' => 'mobileAuth']);
    $routes->get('pf-ledger', 'MobilePfController::ledger', ['filter' => 'mobileAuth']);
    $routes->get('pf/history', 'MobilePfController::ledger', ['filter' => 'mobileAuth']);
    $routes->get('pf/transactions', 'MobilePfController::ledger', ['filter' => 'mobileAuth']);
    $routes->get('pf/statement', 'MobilePfController::ledger', ['filter' => 'mobileAuth']);
    $routes->get('pf/membership', 'MobilePfController::membership', ['filter' => 'mobileAuth']);
    $routes->post('pf/membership', 'MobilePfController::membership', ['filter' => 'mobileAuth']);
    $routes->get('pf/status', 'MobilePfController::membership', ['filter' => 'mobileAuth']);
    $routes->get('pf/contributions', 'MobilePfController::contributions', ['filter' => 'mobileAuth']);
    $routes->post('pf/contributions', 'MobilePfController::contributions', ['filter' => 'mobileAuth']);
    $routes->get('pf/interest', 'MobilePfController::interest', ['filter' => 'mobileAuth']);
    $routes->post('pf/interest', 'MobilePfController::interest', ['filter' => 'mobileAuth']);
    $routes->get('payroll/pf', 'MobilePfController::summary', ['filter' => 'mobileAuth']);
    $routes->get('payroll/pf/ledger', 'MobilePfController::ledger', ['filter' => 'mobileAuth']);
    $routes->get('payroll/pf/summary', 'MobilePfController::summary', ['filter' => 'mobileAuth']);
    $routes->get('notifications', 'MobileNotificationController::index', ['filter' => 'mobileAuth']);
    $routes->post('notifications/read-all', 'MobileNotificationController::markAllRead', ['filter' => 'mobileAuth']);
    $routes->post('notifications/(:segment)/read', 'MobileNotificationController::markRead/$1', ['filter' => 'mobileAuth']);
    $routes->get('documents', 'MobileDocumentController::index', ['filter' => 'mobileAuth']);
    $routes->get('documents/(:segment)/download', 'MobileDocumentController::download/$1', ['filter' => 'mobileAuth']);
    $routes->get('documents/(:segment)', 'MobileDocumentController::show/$1', ['filter' => 'mobileAuth']);
    $routes->get('directory', 'MobileDirectoryController::index', ['filter' => 'mobileAuth']);
    $routes->get('directory/(:segment)', 'MobileDirectoryController::show/$1', ['filter' => 'mobileAuth']);
    $routes->get('notices', 'MobileNoticeController::index', ['filter' => 'mobileAuth']);
    $routes->get('notices/(:segment)', 'MobileNoticeController::show/$1', ['filter' => 'mobileAuth']);

    $routes->get('system/health', 'MobileSystemController::health');
    $routes->post('auth/push-token', 'MobileAuthController::updatePushToken', ['filter' => 'mobileAuth']);
    $routes->get('auth/devices', 'MobileAuthController::devices', ['filter' => 'mobileAuth']);
    $routes->post('auth/devices/(:segment)/revoke', 'MobileAuthController::revokeDevice/$1', ['filter' => 'mobileAuth']);

    $routes->get('payroll/payslips', 'MobilePayslipController::index', ['filter' => 'mobileAuth']);
    $routes->get('payroll/payslips/(:segment)', 'MobilePayslipController::show/$1', ['filter' => 'mobileAuth']);

    $routes->get('leaves/types', 'MobileLeaveController::types', ['filter' => 'mobileAuth']);
    $routes->get('leaves/balances', 'MobileLeaveController::balances', ['filter' => 'mobileAuth']);
    $routes->get('leaves/applications', 'MobileLeaveController::applications', ['filter' => 'mobileAuth']);
    $routes->get('leaves/applications/(:segment)', 'MobileLeaveController::show/$1', ['filter' => 'mobileAuth']);
    $routes->get('leaves/history', 'MobileLeaveController::applications', ['filter' => 'mobileAuth']);
    $routes->get('leaves/holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('leaves/team-calendar', 'MobileLeaveController::teamCalendar', ['filter' => 'mobileAuth']);
    $routes->get('leaves/team_calendar', 'MobileLeaveController::teamCalendar', ['filter' => 'mobileAuth']);
    $routes->get('leaves/calendar', 'MobileLeaveController::teamCalendar', ['filter' => 'mobileAuth']);
    $routes->get('leaves/(:segment)/attachment', 'MobileLeaveController::attachment/$1', ['filter' => 'mobileAuth']);
    $routes->get('leave/(:segment)/attachment', 'MobileLeaveController::attachment/$1', ['filter' => 'mobileAuth']);
    $routes->get('leaves/(:segment)', 'MobileLeaveController::show/$1', ['filter' => 'mobileAuth']);
    $routes->post('leaves/apply', 'MobileLeaveController::apply', ['filter' => 'mobileAuth']);
    $routes->post('leaves/(:segment)/cancel', 'MobileLeaveController::cancel/$1', ['filter' => 'mobileAuth']);

    $routes->get('leave/types', 'MobileLeaveController::types', ['filter' => 'mobileAuth']);
    $routes->get('leave/balances', 'MobileLeaveController::balances', ['filter' => 'mobileAuth']);
    $routes->get('leave/applications', 'MobileLeaveController::applications', ['filter' => 'mobileAuth']);
    $routes->get('leave/applications/(:segment)', 'MobileLeaveController::show/$1', ['filter' => 'mobileAuth']);
    $routes->get('leave/history', 'MobileLeaveController::applications', ['filter' => 'mobileAuth']);
    $routes->get('leave/holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('leave/team-calendar', 'MobileLeaveController::teamCalendar', ['filter' => 'mobileAuth']);
    $routes->get('leave/team_calendar', 'MobileLeaveController::teamCalendar', ['filter' => 'mobileAuth']);
    $routes->get('leave/calendar', 'MobileLeaveController::teamCalendar', ['filter' => 'mobileAuth']);
    $routes->get('lleave/team-calendar', 'MobileLeaveController::teamCalendar', ['filter' => 'mobileAuth']);
    $routes->get('leave/(:segment)/attachment', 'MobileLeaveController::attachment/$1', ['filter' => 'mobileAuth']);
    $routes->get('leaves/(:segment)/attachment', 'MobileLeaveController::attachment/$1', ['filter' => 'mobileAuth']);
    $routes->get('leave/(:segment)', 'MobileLeaveController::show/$1', ['filter' => 'mobileAuth']);
    $routes->post('leave/apply', 'MobileLeaveController::apply', ['filter' => 'mobileAuth']);
    $routes->post('leave/(:segment)/cancel', 'MobileLeaveController::cancel/$1', ['filter' => 'mobileAuth']);
    // Public Holidays & Calendar
    $routes->get('holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('holiday', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('holidays/public', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('holidays/list', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('public-holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('public_holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('leave/holiday', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('leave/public-holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('leave/public_holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('leaves/holiday', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('leaves/public-holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('leaves/public_holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('attendance/holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('attendance/holiday', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('attendance/public-holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('attendance/public_holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('shifts/holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('shifts/holiday', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('shift/holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('shift/holiday', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('roster/holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('roster/holiday', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('roster/public-holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('roster/public_holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/holiday', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/public-holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/public_holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('company/holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('company/holiday', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('company/public-holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('company/public_holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/events', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/summary', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/month', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);

    // Weekends & Weekly Holidays
    $routes->get('weekends', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('weekend', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('weekly-holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('weekly_holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('weekly-off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('weekly_off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('weekly-off-days', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('weekly_off_days', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('holidays/weekly', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('holiday/weekly', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leave/weekly-holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leave/weekly_holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leave/weekly-off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leave/weekly_off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leave/weekends', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leave/weekend', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leaves/weekly-holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leaves/weekly_holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leaves/weekly-off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leaves/weekly_off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leaves/weekends', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leaves/weekend', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('attendance/weekends', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('attendance/weekend', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('attendance/weekly-holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('attendance/weekly_holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('attendance/weekly-off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('attendance/weekly_off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shifts/weekends', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shifts/weekend', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shifts/weekly-holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shifts/weekly_holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shifts/weekly-off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shifts/weekly_off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shift/weekends', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shift/weekend', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shift/weekly-holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shift/weekly_holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shift/weekly-off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shift/weekly_off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('roster/weekends', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('roster/weekend', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('roster/weekly-holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('roster/weekly_holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('roster/weekly-off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('roster/weekly_off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/weekends', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/weekend', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/weekly-holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/weekly_holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/weekly-off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/weekly_off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('company/weekends', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('company/weekend', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('company/weekly-holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('company/weekly_holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('company/weekly-off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('company/weekly_off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);

    // Shifts & Rostering
    $routes->get('shifts', 'MobileShiftController::index', ['filter' => 'mobileAuth']);
    $routes->get('shifts/current', 'MobileShiftController::current', ['filter' => 'mobileAuth']);
    $routes->get('shifts/today', 'MobileShiftController::current', ['filter' => 'mobileAuth']);
    $routes->get('shifts/effective', 'MobileShiftController::effective', ['filter' => 'mobileAuth']);
    $routes->get('shifts/roster', 'MobileShiftController::roster', ['filter' => 'mobileAuth']);
    $routes->get('shifts/my-roster', 'MobileShiftController::roster', ['filter' => 'mobileAuth']);
    $routes->get('shifts/upcoming', 'MobileShiftController::upcoming', ['filter' => 'mobileAuth']);
    $routes->get('shifts/changes', 'MobileShiftController::changes', ['filter' => 'mobileAuth']);
    $routes->get('shifts/swaps', 'MobileShiftController::swaps', ['filter' => 'mobileAuth']);
    $routes->post('shifts/swaps', 'MobileShiftController::createSwap', ['filter' => 'mobileAuth']);
    $routes->get('shifts/(:segment)', 'MobileShiftController::show/$1', ['filter' => 'mobileAuth']);

    $routes->get('shift', 'MobileShiftController::current', ['filter' => 'mobileAuth']);
    $routes->get('shift/current', 'MobileShiftController::current', ['filter' => 'mobileAuth']);
    $routes->get('shift/today', 'MobileShiftController::current', ['filter' => 'mobileAuth']);
    $routes->get('shift/effective', 'MobileShiftController::effective', ['filter' => 'mobileAuth']);
    $routes->get('shift/roster', 'MobileShiftController::roster', ['filter' => 'mobileAuth']);
    $routes->get('shift/upcoming', 'MobileShiftController::upcoming', ['filter' => 'mobileAuth']);
    $routes->get('shift/changes', 'MobileShiftController::changes', ['filter' => 'mobileAuth']);
    $routes->get('shift/swaps', 'MobileShiftController::swaps', ['filter' => 'mobileAuth']);
    $routes->post('shift/swaps', 'MobileShiftController::createSwap', ['filter' => 'mobileAuth']);
    $routes->get('shift/(:segment)', 'MobileShiftController::show/$1', ['filter' => 'mobileAuth']);

    $routes->get('overtime', 'MobileOvertimeController::records', ['filter' => 'mobileAuth']);
    $routes->get('overtime/records', 'MobileOvertimeController::records', ['filter' => 'mobileAuth']);
    $routes->get('overtime/history', 'MobileOvertimeController::records', ['filter' => 'mobileAuth']);
    $routes->get('overtime/summary', 'MobileOvertimeController::summary', ['filter' => 'mobileAuth']);
    $routes->get('overtime/claims', 'MobileOvertimeController::claims', ['filter' => 'mobileAuth']);
    $routes->post('overtime/claims', 'MobileOvertimeController::submit', ['filter' => 'mobileAuth']);
});

// Secure ESS API v1 (same token-authenticated business logic; required by Android ESS app)
$routes->group('api/v1', ['namespace' => 'App\Controllers\Mobile'], function ($routes) {
    $routes->post('auth/login', 'MobileAuthController::login');
    $routes->post('auth/refresh', 'MobileAuthController::refresh');
    $routes->post('auth/logout', 'MobileAuthController::logout', ['filter' => 'mobileAuth']);
    $routes->post('auth/logout-all', 'MobileAuthController::logoutAll', ['filter' => 'mobileAuth']);
    $routes->get('auth/me', 'MobileAuthController::me', ['filter' => 'mobileAuth']);
    $routes->post('auth/change-password', 'MobileAuthController::changePassword', ['filter' => 'mobileAuth']);

    $routes->get('system/health', 'MobileSystemController::health');
    $routes->get('company/details/(:segment)', 'MobileCompanyController::details/$1');
    $routes->get('company/details', 'MobileCompanyController::details');
    $routes->get('company/(:segment)', 'MobileCompanyController::details/$1');
    $routes->post('auth/push-token', 'MobileAuthController::updatePushToken', ['filter' => 'mobileAuth']);
    $routes->get('auth/devices', 'MobileAuthController::devices', ['filter' => 'mobileAuth']);
    $routes->post('auth/devices/(:segment)/revoke', 'MobileAuthController::revokeDevice/$1', ['filter' => 'mobileAuth']);

    $routes->get('dashboard', 'MobileDashboardController::index', ['filter' => 'mobileAuth']);
    $routes->get('profile', 'MobileProfileController::show', ['filter' => 'mobileAuth']);
    $routes->get('profile/details', 'MobileProfileController::details', ['filter' => 'mobileAuth']);
    $routes->post('profile/photo', 'MobileProfileController::uploadPhoto', ['filter' => 'mobileAuth']);

    $routes->get('attendance/today', 'MobileAttendanceController::today', ['filter' => 'mobileAuth']);
    $routes->get('attendance/effective-shift', 'MobileAttendanceController::effectiveShift', ['filter' => 'mobileAuth']);
    $routes->get('attendance/roster', 'MobileAttendanceController::myRoster', ['filter' => 'mobileAuth']);
    $routes->get('roster/my', 'MobileAttendanceController::myRoster', ['filter' => 'mobileAuth']);
    $routes->get('attendance/shifts/upcoming', 'MobileAttendanceController::upcomingShifts', ['filter' => 'mobileAuth']);
    $routes->get('roster/upcoming', 'MobileAttendanceController::upcomingShifts', ['filter' => 'mobileAuth']);
    $routes->get('attendance/shift-changes', 'MobileAttendanceController::shiftChanges', ['filter' => 'mobileAuth']);
    $routes->get('roster/shift-changes', 'MobileAttendanceController::shiftChanges', ['filter' => 'mobileAuth']);
    $routes->get('attendance/history', 'MobileAttendanceController::history', ['filter' => 'mobileAuth']);
    $routes->get('attendance/summary', 'MobileAttendanceController::summary', ['filter' => 'mobileAuth']);
    $routes->post('attendance/check-in', 'MobileAttendanceController::checkIn', ['filter' => 'mobileAuth']);
    $routes->post('attendance/check-out', 'MobileAttendanceController::checkOut', ['filter' => 'mobileAuth']);
    $routes->get('attendance/reconciliation', 'MobileAttendanceController::reconciliations', ['filter' => 'mobileAuth']);
    $routes->post('attendance/reconciliation', 'MobileAttendanceController::reconcile', ['filter' => 'mobileAuth']);
    $routes->get('attendance/reconciliation/approvals', 'MobileAttendanceController::reconApprovals', ['filter' => 'mobileAuth']);
    $routes->post('attendance/reconciliation/(:segment)/approve', 'MobileAttendanceController::approveRecon/$1', ['filter' => 'mobileAuth']);
    $routes->post('attendance/reconciliation/(:segment)/reject', 'MobileAttendanceController::rejectRecon/$1', ['filter' => 'mobileAuth']);

    $routes->get('leave/types', 'MobileLeaveController::types', ['filter' => 'mobileAuth']);
    $routes->get('leave/balances', 'MobileLeaveController::balances', ['filter' => 'mobileAuth']);
    $routes->get('leave/applications', 'MobileLeaveController::applications', ['filter' => 'mobileAuth']);
    $routes->get('leave/applications/(:segment)', 'MobileLeaveController::show/$1', ['filter' => 'mobileAuth']);
    $routes->get('leave/history', 'MobileLeaveController::applications', ['filter' => 'mobileAuth']);
    $routes->get('leave/holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('leave/team-calendar', 'MobileLeaveController::teamCalendar', ['filter' => 'mobileAuth']);
    $routes->get('leave/team_calendar', 'MobileLeaveController::teamCalendar', ['filter' => 'mobileAuth']);
    $routes->get('leave/calendar', 'MobileLeaveController::teamCalendar', ['filter' => 'mobileAuth']);
    $routes->get('lleave/team-calendar', 'MobileLeaveController::teamCalendar', ['filter' => 'mobileAuth']);
    $routes->get('leave/(:segment)/attachment', 'MobileLeaveController::attachment/$1', ['filter' => 'mobileAuth']);
    $routes->get('leaves/(:segment)/attachment', 'MobileLeaveController::attachment/$1', ['filter' => 'mobileAuth']);
    $routes->get('leave/(:segment)', 'MobileLeaveController::show/$1', ['filter' => 'mobileAuth']);
    $routes->post('leave/apply', 'MobileLeaveController::apply', ['filter' => 'mobileAuth']);
    $routes->post('leave/(:segment)/cancel', 'MobileLeaveController::cancel/$1', ['filter' => 'mobileAuth']);

    $routes->get('leaves/types', 'MobileLeaveController::types', ['filter' => 'mobileAuth']);
    $routes->get('leaves/balances', 'MobileLeaveController::balances', ['filter' => 'mobileAuth']);
    $routes->get('leaves/applications', 'MobileLeaveController::applications', ['filter' => 'mobileAuth']);
    $routes->get('leaves/applications/(:segment)', 'MobileLeaveController::show/$1', ['filter' => 'mobileAuth']);
    $routes->get('leaves/history', 'MobileLeaveController::applications', ['filter' => 'mobileAuth']);
    $routes->get('leaves/holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('leaves/team-calendar', 'MobileLeaveController::teamCalendar', ['filter' => 'mobileAuth']);
    $routes->get('leaves/team_calendar', 'MobileLeaveController::teamCalendar', ['filter' => 'mobileAuth']);
    $routes->get('leaves/calendar', 'MobileLeaveController::teamCalendar', ['filter' => 'mobileAuth']);
    $routes->get('leaves/(:segment)/attachment', 'MobileLeaveController::attachment/$1', ['filter' => 'mobileAuth']);
    $routes->get('leave/(:segment)/attachment', 'MobileLeaveController::attachment/$1', ['filter' => 'mobileAuth']);
    $routes->get('leaves/(:segment)', 'MobileLeaveController::show/$1', ['filter' => 'mobileAuth']);
    $routes->post('leaves/apply', 'MobileLeaveController::apply', ['filter' => 'mobileAuth']);
    $routes->post('leaves/(:segment)/cancel', 'MobileLeaveController::cancel/$1', ['filter' => 'mobileAuth']);
    // Public Holidays & Calendar
    $routes->get('holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('holiday', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('holidays/public', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('holidays/list', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('public-holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('public_holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('leave/holiday', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('leave/public-holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('leave/public_holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('leaves/holiday', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('leaves/public-holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('leaves/public_holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('attendance/holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('attendance/holiday', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('attendance/public-holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('attendance/public_holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('shifts/holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('shifts/holiday', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('shift/holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('shift/holiday', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('roster/holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('roster/holiday', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('roster/public-holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('roster/public_holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/holiday', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/public-holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/public_holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('company/holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('company/holiday', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('company/public-holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('company/public_holidays', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/events', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/summary', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/month', 'MobileLeaveController::holidays', ['filter' => 'mobileAuth']);

    // Weekends & Weekly Holidays
    $routes->get('weekends', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('weekend', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('weekly-holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('weekly_holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('weekly-off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('weekly_off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('weekly-off-days', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('weekly_off_days', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('holidays/weekly', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('holiday/weekly', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leave/weekly-holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leave/weekly_holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leave/weekly-off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leave/weekly_off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leave/weekends', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leave/weekend', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leaves/weekly-holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leaves/weekly_holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leaves/weekly-off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leaves/weekly_off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leaves/weekends', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('leaves/weekend', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('attendance/weekends', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('attendance/weekend', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('attendance/weekly-holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('attendance/weekly_holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('attendance/weekly-off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('attendance/weekly_off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shifts/weekends', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shifts/weekend', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shifts/weekly-holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shifts/weekly_holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shifts/weekly-off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shifts/weekly_off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shift/weekends', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shift/weekend', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shift/weekly-holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shift/weekly_holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shift/weekly-off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('shift/weekly_off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('roster/weekends', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('roster/weekend', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('roster/weekly-holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('roster/weekly_holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('roster/weekly-off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('roster/weekly_off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/weekends', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/weekend', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/weekly-holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/weekly_holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/weekly-off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('calendar/weekly_off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('company/weekends', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('company/weekend', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('company/weekly-holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('company/weekly_holidays', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('company/weekly-off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);
    $routes->get('company/weekly_off', 'MobileLeaveController::weeklyHolidays', ['filter' => 'mobileAuth']);

    // Shifts & Rostering
    $routes->get('shifts', 'MobileShiftController::index', ['filter' => 'mobileAuth']);
    $routes->get('shifts/current', 'MobileShiftController::current', ['filter' => 'mobileAuth']);
    $routes->get('shifts/today', 'MobileShiftController::current', ['filter' => 'mobileAuth']);
    $routes->get('shifts/effective', 'MobileShiftController::effective', ['filter' => 'mobileAuth']);
    $routes->get('shifts/roster', 'MobileShiftController::roster', ['filter' => 'mobileAuth']);
    $routes->get('shifts/my-roster', 'MobileShiftController::roster', ['filter' => 'mobileAuth']);
    $routes->get('shifts/upcoming', 'MobileShiftController::upcoming', ['filter' => 'mobileAuth']);
    $routes->get('shifts/changes', 'MobileShiftController::changes', ['filter' => 'mobileAuth']);
    $routes->get('shifts/swaps', 'MobileShiftController::swaps', ['filter' => 'mobileAuth']);
    $routes->post('shifts/swaps', 'MobileShiftController::createSwap', ['filter' => 'mobileAuth']);
    $routes->get('shifts/(:segment)', 'MobileShiftController::show/$1', ['filter' => 'mobileAuth']);

    $routes->get('shift', 'MobileShiftController::current', ['filter' => 'mobileAuth']);
    $routes->get('shift/current', 'MobileShiftController::current', ['filter' => 'mobileAuth']);
    $routes->get('shift/today', 'MobileShiftController::current', ['filter' => 'mobileAuth']);
    $routes->get('shift/effective', 'MobileShiftController::effective', ['filter' => 'mobileAuth']);
    $routes->get('shift/roster', 'MobileShiftController::roster', ['filter' => 'mobileAuth']);
    $routes->get('shift/upcoming', 'MobileShiftController::upcoming', ['filter' => 'mobileAuth']);
    $routes->get('shift/changes', 'MobileShiftController::changes', ['filter' => 'mobileAuth']);
    $routes->get('shift/swaps', 'MobileShiftController::swaps', ['filter' => 'mobileAuth']);
    $routes->post('shift/swaps', 'MobileShiftController::createSwap', ['filter' => 'mobileAuth']);
    $routes->get('shift/(:segment)', 'MobileShiftController::show/$1', ['filter' => 'mobileAuth']);

    $routes->get('salary', 'MobileSalaryController::show', ['filter' => 'mobileAuth']);
    $routes->get('salary/history', 'MobileSalaryController::history', ['filter' => 'mobileAuth']);
    $routes->get('payroll/salary', 'MobileSalaryController::show', ['filter' => 'mobileAuth']);
    $routes->get('payroll/salary/history', 'MobileSalaryController::history', ['filter' => 'mobileAuth']);

    $routes->get('payroll/summary', 'MobilePayslipController::summary', ['filter' => 'mobileAuth']);
    $routes->get('payslips/summary', 'MobilePayslipController::summary', ['filter' => 'mobileAuth']);
    $routes->get('payroll/history', 'MobilePayslipController::index', ['filter' => 'mobileAuth']);
    $routes->get('payslips/history', 'MobilePayslipController::index', ['filter' => 'mobileAuth']);
    $routes->get('payroll/payslips', 'MobilePayslipController::index', ['filter' => 'mobileAuth']);
    $routes->get('payslips', 'MobilePayslipController::index', ['filter' => 'mobileAuth']);
    $routes->get('payroll/payslips/(:segment)/pdf', 'MobilePayslipController::pdf/$1', ['filter' => 'mobileAuth']);
    $routes->get('payslips/(:segment)/pdf', 'MobilePayslipController::pdf/$1', ['filter' => 'mobileAuth']);
    $routes->get('payroll/payslips/(:segment)', 'MobilePayslipController::show/$1', ['filter' => 'mobileAuth']);
    $routes->get('payslips/(:segment)', 'MobilePayslipController::show/$1', ['filter' => 'mobileAuth']);
    $routes->get('statements/salary', 'MobileStatementController::salary', ['filter' => 'mobileAuth']);
    $routes->get('statements/tax', 'MobileStatementController::tax', ['filter' => 'mobileAuth']);
    $routes->get('statements/pf', 'MobileStatementController::pf', ['filter' => 'mobileAuth']);
    $routes->get('statements/(:segment)', 'MobileStatementController::show/$1', ['filter' => 'mobileAuth']);
    $routes->get('statements', 'MobileStatementController::salary', ['filter' => 'mobileAuth']);

    $routes->get('pf', 'MobilePfController::summary', ['filter' => 'mobileAuth']);
    $routes->post('pf', 'MobilePfController::summary', ['filter' => 'mobileAuth']);
    $routes->get('pf/summary', 'MobilePfController::summary', ['filter' => 'mobileAuth']);
    $routes->post('pf/summary', 'MobilePfController::summary', ['filter' => 'mobileAuth']);
    $routes->get('pf/ledger', 'MobilePfController::ledger', ['filter' => 'mobileAuth']);
    $routes->post('pf/ledger', 'MobilePfController::ledger', ['filter' => 'mobileAuth']);
    $routes->get('pf-ledger', 'MobilePfController::ledger', ['filter' => 'mobileAuth']);
    $routes->get('pf/history', 'MobilePfController::ledger', ['filter' => 'mobileAuth']);
    $routes->get('pf/transactions', 'MobilePfController::ledger', ['filter' => 'mobileAuth']);
    $routes->get('pf/statement', 'MobilePfController::ledger', ['filter' => 'mobileAuth']);
    $routes->get('pf/membership', 'MobilePfController::membership', ['filter' => 'mobileAuth']);
    $routes->post('pf/membership', 'MobilePfController::membership', ['filter' => 'mobileAuth']);
    $routes->get('pf/status', 'MobilePfController::membership', ['filter' => 'mobileAuth']);
    $routes->get('pf/contributions', 'MobilePfController::contributions', ['filter' => 'mobileAuth']);
    $routes->post('pf/contributions', 'MobilePfController::contributions', ['filter' => 'mobileAuth']);
    $routes->get('pf/interest', 'MobilePfController::interest', ['filter' => 'mobileAuth']);
    $routes->post('pf/interest', 'MobilePfController::interest', ['filter' => 'mobileAuth']);
    $routes->get('payroll/pf', 'MobilePfController::summary', ['filter' => 'mobileAuth']);
    $routes->get('payroll/pf/ledger', 'MobilePfController::ledger', ['filter' => 'mobileAuth']);
    $routes->get('payroll/pf/summary', 'MobilePfController::summary', ['filter' => 'mobileAuth']);

    $routes->get('overtime', 'MobileOvertimeController::records', ['filter' => 'mobileAuth']);
    $routes->get('overtime/records', 'MobileOvertimeController::records', ['filter' => 'mobileAuth']);
    $routes->get('overtime/history', 'MobileOvertimeController::records', ['filter' => 'mobileAuth']);
    $routes->get('overtime/summary', 'MobileOvertimeController::summary', ['filter' => 'mobileAuth']);
    $routes->get('overtime/claims', 'MobileOvertimeController::claims', ['filter' => 'mobileAuth']);
    $routes->post('overtime/claims', 'MobileOvertimeController::submit', ['filter' => 'mobileAuth']);

    $routes->get('notifications', 'MobileNotificationController::index', ['filter' => 'mobileAuth']);
    $routes->post('notifications/read-all', 'MobileNotificationController::markAllRead', ['filter' => 'mobileAuth']);
    $routes->post('notifications/(:segment)/read', 'MobileNotificationController::markRead/$1', ['filter' => 'mobileAuth']);
    $routes->get('notices', 'MobileNoticeController::index', ['filter' => 'mobileAuth']);
    $routes->get('notices/(:segment)', 'MobileNoticeController::show/$1', ['filter' => 'mobileAuth']);

    $routes->get('documents', 'MobileDocumentController::index', ['filter' => 'mobileAuth']);
    $routes->get('documents/(:segment)/download', 'MobileDocumentController::download/$1', ['filter' => 'mobileAuth']);
    $routes->get('documents/(:segment)', 'MobileDocumentController::show/$1', ['filter' => 'mobileAuth']);
    $routes->get('directory', 'MobileDirectoryController::index', ['filter' => 'mobileAuth']);
    $routes->get('directory/(:segment)', 'MobileDirectoryController::show/$1', ['filter' => 'mobileAuth']);
});

// Authentication Routes (Public)
$routes->group('auth', function ($routes) {
    $routes->get('login', 'Auth\AuthController::login');
    $routes->post('login', 'Auth\AuthController::attemptLogin');
    $routes->post('logout', 'Auth\AuthController::logout');
    $routes->get('forgot-password', 'Auth\PasswordController::forgotPassword');
    $routes->post('forgot-password', 'Auth\PasswordController::sendResetLink');
    $routes->get('reset-password', 'Auth\PasswordController::showResetPassword');
    $routes->post('reset-password', 'Auth\PasswordController::attemptResetPassword');
    $routes->post('verify-reset-code', 'Auth\PasswordController::verifyResetCode');
    $routes->get('change-password', 'Auth\PasswordController::showChangePassword');
    $routes->post('change-password', 'Auth\PasswordController::changePassword');
});

// Public Biometric Hardware Ingestion & ZKFinger SDK 5.3.0.33 APIs (API-Key Authenticated)
$routes->match(['get', 'post', 'options'], 'api/attendance/zk-push', 'Attendance\AttendanceSyncController::pushPunch');
$routes->match(['get', 'post', 'options'], 'api/attendance/push-punch', 'Attendance\AttendanceSyncController::pushPunch');
$routes->match(['get', 'post', 'options'], 'api/biometrics/enroll', 'Attendance\AttendanceSyncController::enrollTemplate');
$routes->match(['get', 'post', 'options'], 'attendance/sync/api/push-punch', 'Attendance\AttendanceSyncController::pushPunch');
$routes->match(['get', 'post', 'options'], 'attendance/sync/api/enroll', 'Attendance\AttendanceSyncController::enrollTemplate');

// Public Company Lookup & Branding APIs
$routes->get('api/company/details/(:segment)', 'Mobile\MobileCompanyController::details/$1');
$routes->get('api/company/details', 'Mobile\MobileCompanyController::details');

// Protected Enterprise Routes (Require Authentication)
$routes->group('', ['filter' => 'authFilter'], function ($routes) {

    // Unified Role-Based Dashboards & ESS Portal
    $routes->get('/', 'Dashboard\DashboardController::index');
    $routes->get('dashboard', 'Dashboard\DashboardController::index');
    $routes->get('dashboard/appadmin', 'Dashboard\DashboardController::index', ['filter' => 'platformAdmin']);
    $routes->get('dashboard/company-admin', 'Dashboard\DashboardController::index', ['filter' => 'companyAdmin']);
    $routes->get('dashboard/company', 'Dashboard\DashboardController::index', ['filter' => 'companyAdmin']);
    $routes->get('dashboard/hr', 'Dashboard\DashboardController::index', ['filter' => 'role:hr_admin,hr_officer']);
    $routes->get('dashboard/manager', 'Dashboard\DashboardController::index', ['filter' => 'role:manager,team_leader']);
    $routes->get('dashboard/employee', 'Dashboard\DashboardController::index');
    $routes->post('auth/switch-persona/(:segment)', 'Auth\AuthController::switchPersona/$1', ['filter' => 'platformAdmin']);
    $routes->post('switch-persona/(:segment)', 'Auth\AuthController::switchPersona/$1', ['filter' => 'platformAdmin']);
    $routes->post('auth/stop-impersonation', 'Auth\AuthController::stopImpersonation', ['filter' => 'permission:profile.edit|dashboard.view|profile.view']);
    $routes->post('stop-impersonation', 'Auth\AuthController::stopImpersonation', ['filter' => 'permission:profile.edit|dashboard.view|profile.view']);
    $routes->get('ess', 'Dashboard\DashboardController::ess');
    $routes->post('ess/update-profile', 'Dashboard\DashboardController::updateProfile', ['filter' => 'permission:profile.edit|employees.edit']);
    $routes->get('profile', function () {
        $empId = session()->get('employee_id');
        return redirect()->to(base_url($empId ? 'employees/profile/' . $empId : 'employees/profile'));
    }, ['filter' => 'auth']);
    $routes->get('profile/(:segment)', function ($id) {
        return redirect()->to(base_url('employees/profile/' . $id));
    }, ['filter' => 'auth']);
    $routes->get('employees/profile', 'Employee\ProfileController::show', ['filter' => 'auth']);
    $routes->get('employees/profile/(:segment)', 'Employee\ProfileController::show/$1', ['filter' => 'auth']);
    $routes->get('api/dashboard/stats', 'Dashboard\DashboardController::getStatsAjax');
    // Phase 2 & 3: Asynchronous Lazy Loading for Dashboard Category Widgets
    $routes->get('api/dashboard/category-widgets', 'Dashboard\DashboardController::getCategoryWidgetsAjax', ['filter' => 'auth']);

    // Theme & Navigation Layout Preference APIs
    $routes->post('theme/layout', 'System\ThemeController::setLayout', ['filter' => 'permission:settings.edit|settings.manage|profile.edit']);
    $routes->post('theme/save-preference', 'System\ThemeController::save', ['filter' => 'permission:settings.edit|settings.manage|profile.edit']);

    // Dashboard Widget Management Hub & AJAX APIs
    $routes->get('dashboard/widgets', 'Dashboard\DashboardWidgetController::index', ['filter' => 'permission:dashboard.manage|dashboard.view']);
    $routes->get('dashboard/manage', 'Dashboard\DashboardWidgetController::index', ['filter' => 'permission:dashboard.manage|dashboard.view']);
    $routes->post('api/dashboard/widgets/toggle', 'Dashboard\DashboardWidgetController::toggle', ['filter' => 'permission:dashboard.manage|dashboard.view']);
    $routes->post('api/dashboard/widgets/reorder', 'Dashboard\DashboardWidgetController::reorder', ['filter' => 'permission:dashboard.manage|dashboard.view']);
    $routes->post('api/dashboard/widgets/reset-override', 'Dashboard\DashboardWidgetController::resetOverride', ['filter' => 'permission:dashboard.manage|dashboard.view']);
    $routes->post('api/dashboard/widgets/assign-role', 'Dashboard\DashboardWidgetController::assignRole', ['filter' => 'permission:dashboard.manage|dashboard.view']);
    $routes->post('api/dashboard/widgets/remove-role', 'Dashboard\DashboardWidgetController::removeRole', ['filter' => 'permission:dashboard.manage|dashboard.view']);
    $routes->post('api/dashboard/widgets/update-width', 'Dashboard\DashboardWidgetController::updateWidth', ['filter' => 'permission:dashboard.manage|dashboard.view']);

    // Phase 18: User Customization APIs (Show/Hide, Reorder, Resize, Reset, Save Preferences)
    $routes->get('api/dashboard/customizable-widgets', 'Dashboard\DashboardWidgetController::customizableWidgets', ['filter' => 'auth']);
    $routes->get('api/dashboard/preferences/customizable-widgets', 'Dashboard\DashboardWidgetController::customizableWidgets', ['filter' => 'auth']);
    $routes->post('api/dashboard/preferences/toggle', 'Dashboard\DashboardWidgetController::toggleUserPreference', ['filter' => 'auth']);
    $routes->post('api/dashboard/preferences/reorder', 'Dashboard\DashboardWidgetController::reorderUserPreferences', ['filter' => 'auth']);
    $routes->post('api/dashboard/preferences/resize', 'Dashboard\DashboardWidgetController::resizeUserPreference', ['filter' => 'auth']);
    $routes->post('api/dashboard/preferences/reset', 'Dashboard\DashboardWidgetController::resetUserPreferences', ['filter' => 'auth']);
    $routes->post('api/dashboard/preferences/save', 'Dashboard\DashboardWidgetController::saveUserPreferences', ['filter' => 'auth']);

    // Employees Directory & Profile Subtabs
    $routes->group('employees', ['filter' => 'auth'], function ($routes) {
        $routes->get('/', 'Employee\EmployeeController::index', ['filter' => 'permission:employees.view']);

        // Static Module Tabs (Declared before dynamic profile segments)
        $routes->get('hierarchy', 'EmployeeOrganogramController::index', ['filter' => 'permission:organogram.view|employees.view']);
        $routes->get('hierarchy/tree', 'EmployeeOrganogramController::tree', ['filter' => 'permission:organogram.view|employees.view']);
        $routes->get('hierarchy/employee/(:segment)', 'EmployeeOrganogramController::employee/$1', ['filter' => 'permission:organogram.view|employees.view']);
        $routes->get('hierarchy/department/(:segment)', 'EmployeeOrganogramController::department/$1', ['filter' => 'permission:organogram.view|employees.view']);
        $routes->post('hierarchy/manager/update', 'EmployeeOrganogramController::updateManager', ['filter' => 'permission:organogram.manage|employee.transfer|employees.movement|employees.edit']);
        $routes->get('hierarchy/export/pdf', 'EmployeeOrganogramController::exportPdf', ['filter' => 'permission:organogram.export|employees.export|employees.view']);

        $routes->get('probation', 'Employee\EmployeeProbationController::index', ['filter' => 'permission:employees.view']);
        $routes->post('probation/confirm/(:segment)', 'Employee\EmployeeProbationController::confirm/$1', ['filter' => 'permission:employees.probation|employees.edit']);
        $routes->post('probation/extend/(:segment)', 'Employee\EmployeeProbationController::extend/$1', ['filter' => 'permission:employees.probation|employees.edit']);
        $routes->post('probation/cancel/(:segment)', 'Employee\EmployeeProbationController::cancel/$1', ['filter' => 'permission:employees.probation|employees.edit']);

        $routes->get('movements', 'Employee\EmployeeMovementController::index', ['filter' => 'permission:employees.view']);

        $routes->get('separation', 'Employee\EmployeeSeparationController::index', ['filter' => 'permission:employees.view']);
        $routes->get('separation/(:segment)', 'Employee\EmployeeSeparationController::index/$1', ['filter' => 'permission:employees.view']);
        $routes->post('separation/resignation/submit', 'Employee\EmployeeSeparationController::submitResignation', ['filter' => 'permission:employees.separate|employees.edit']);
        $routes->post('separation/resignation/approve/(:segment)', 'Employee\EmployeeSeparationController::approveResignation/$1', ['filter' => 'permission:employee.approve_resignation|employees.separate|employees.edit']);
        $routes->post('separation/resignation/reject/(:segment)', 'Employee\EmployeeSeparationController::rejectResignation/$1', ['filter' => 'permission:employee.approve_resignation|employees.separate|employees.edit']);
        $routes->post('separation/termination/save', 'Employee\EmployeeSeparationController::saveTermination', ['filter' => 'permission:employee.terminate|employees.separate|employees.delete']);

        $routes->get('reports', 'Employee\EmployeeReportController::index', ['filter' => 'permission:employees.view']);
        $routes->get('reports/(:segment)', 'Employee\EmployeeReportController::viewReport/$1', ['filter' => 'permission:employees.view']);
        $routes->get('reports/export/(:segment)', 'Employee\EmployeeReportController::exportCsv/$1', ['filter' => 'permission:employees.export|reports.export|employees.view']);

        $routes->get('export/csv', 'Employee\EmployeeController::exportCsv', ['filter' => 'permission:employees.export|employees.view']);
        $routes->get('bulk-template', 'Employee\EmployeeController::downloadBulkTemplate', ['filter' => 'permission:employees.create|employees.bulk|employees.view']);
        $routes->post('bulk-upload', 'Employee\EmployeeController::bulkUpload', ['filter' => 'permission:employees.create|employees.bulk']);
        $routes->get('next-code', 'Employee\EmployeeController::nextCode', ['filter' => 'permission:employees.view']);
        $routes->get('check-code', 'Employee\EmployeeController::checkCode', ['filter' => 'permission:employees.view']);
        $routes->get('branches-by-company/(:segment)', 'Employee\EmployeeController::branchesByCompany/$1', ['filter' => 'permission:employees.view']);
        $routes->get('employment-types-by-company/(:segment)', 'Employee\EmployeeController::employmentTypesByCompany/$1', ['filter' => 'permission:employees.view']);
        $routes->get('create', 'Employee\EmployeeController::create', ['filter' => 'permission:employees.create']);
        $routes->post('store', 'Employee\EmployeeController::store', ['filter' => 'permission:employees.create']);
        $routes->post('update/(:segment)', 'Employee\EmployeeController::update/$1', ['filter' => 'permission:employees.edit']);
        $routes->post('promote', 'Employee\EmployeeController::promote', ['filter' => 'permission:employee.promote|employees.movement|employees.edit']);
        $routes->post('transfer', 'Employee\EmployeeController::transfer', ['filter' => 'permission:employee.transfer|employees.movement|employees.edit']);
        $routes->post('terminate', 'Employee\EmployeeController::terminate', ['filter' => 'permission:employee.terminate|employees.separate|employees.delete']);
        $routes->post('confirm/(:segment)', 'Employee\EmployeeController::confirmStatus/$1', ['filter' => 'permission:employees.probation|employees.edit']);
        $routes->get('(:segment)/edit-data', 'Employee\EmployeeController::editData/$1', ['filter' => 'permission:employees.edit|employees.view']);
        $routes->get('(:segment)/salary', 'Employee\EmployeeSalaryController::getSalary/$1', ['filter' => 'permission:employee.view_salary|payroll.view']);
        $routes->post('(:segment)/salary', 'Employee\EmployeeSalaryController::saveSalary/$1', ['filter' => 'permission:employees.edit|payroll.manage|payroll.create|payroll.edit']);
        $routes->post('(:segment)/copy-structure', 'Employee\EmployeeSalaryController::copyStructure/$1', ['filter' => 'permission:employees.edit|payroll.manage|payroll.create|payroll.edit']);
        $routes->post('(:segment)/resync-salary', 'Employee\EmployeeSalaryController::resyncSalary/$1', ['filter' => 'permission:employees.edit|payroll.manage|payroll.create|payroll.edit']);
        $routes->get('(:segment)/salary-history', 'Employee\EmployeeSalaryController::getSalaryHistory/$1', ['filter' => 'permission:employee.view_salary|payroll.view']);
        $routes->post('profile/(:segment)/update-pf', 'Employee\ProfileController::updateProvidentFund/$1', ['filter' => 'permission:employees.edit|pf.manage']);
        $routes->post('bulk-pf-assign', 'Employee\EmployeeController::bulkPfAssign', ['filter' => 'permission:employees.edit|employees.bulk|pf.manage']);
        $routes->post('profile/(:segment)/update-tab', 'Employee\ProfileController::updateTab/$1', ['filter' => 'permission:employees.edit|profile.edit']);
        $routes->post('profile/(:segment)/update-personal', 'Employee\ProfileController::updatePersonal/$1', ['filter' => 'permission:employees.edit|profile.edit']);
        $routes->post('profile/(:segment)/update-contact', 'Employee\ProfileController::updateContact/$1', ['filter' => 'permission:employees.edit|profile.edit']);
        $routes->post('profile/(:segment)/update-address', 'Employee\ProfileController::updateAddress/$1', ['filter' => 'permission:employees.edit|profile.edit']);
        $routes->post('profile/(:segment)/update-employment', 'Employee\ProfileController::updateEmployment/$1', ['filter' => 'permission:employees.edit']);
        $routes->post('profile/(:segment)/update-bank', 'Employee\ProfileController::updateBank/$1', ['filter' => 'permission:employees.edit|profile.edit']);
        $routes->post('profile/(:segment)/update-skills', 'Employee\ProfileController::updateSkills/$1', ['filter' => 'permission:employees.edit|profile.edit']);
        $routes->post('profile/(:segment)/update-performance', 'Employee\ProfileController::updatePerformance/$1', ['filter' => 'permission:employees.edit|performance.edit']);
        $routes->post('profile/(:segment)/education/add', 'Employee\ProfileController::addEducation/$1', ['filter' => 'permission:employees.edit|profile.edit']);
        $routes->post('profile/(:segment)/education/delete/(:segment)', 'Employee\ProfileController::deleteEducation/$1/$2', ['filter' => 'permission:employees.delete|employees.edit|profile.edit']);
        $routes->post('profile/(:segment)/experience/add', 'Employee\ProfileController::addExperience/$1', ['filter' => 'permission:employees.edit|profile.edit']);
        $routes->post('profile/(:segment)/experience/delete/(:segment)', 'Employee\ProfileController::deleteExperience/$1/$2', ['filter' => 'permission:employees.delete|employees.edit|profile.edit']);
        $routes->post('profile/(:segment)/family/save', 'Employee\ProfileController::saveFamily/$1', ['filter' => 'permission:employees.edit|profile.edit']);
        $routes->post('profile/(:segment)/emergency/add', 'Employee\ProfileController::addEmergencyContact/$1', ['filter' => 'permission:employees.edit|profile.edit']);
        $routes->post('profile/(:segment)/emergency/delete/(:segment)', 'Employee\ProfileController::deleteEmergencyContact/$1/$2', ['filter' => 'permission:employees.delete|employees.edit|profile.edit']);
        $routes->post('profile/(:segment)/documents/upload', 'Employee\ProfileController::uploadDocument/$1', ['filter' => 'permission:employees.create|employees.edit|profile.edit']);
        $routes->post('profile/(:segment)/documents/delete/(:segment)', 'Employee\ProfileController::deleteDocument/$1/$2', ['filter' => 'permission:employees.delete|employees.edit|profile.edit']);
        $routes->post('profile/(:segment)/documents/visibility/(:segment)', 'Employee\ProfileController::toggleDocumentVisibility/$1/$2', ['filter' => 'permission:employees.edit']);
        $routes->get('profile/(:segment)/documents/download/(:segment)', 'Employee\ProfileController::downloadDocument/$1/$2', ['filter' => 'permission:employees.view']);
        $routes->post('profile/(:segment)/promotion/add', 'Employee\ProfileController::addPromotion/$1', ['filter' => 'permission:employee.promote|employees.movement|employees.edit']);
        $routes->post('profile/(:segment)/transfer/add', 'Employee\ProfileController::addTransfer/$1', ['filter' => 'permission:employee.transfer|employees.movement|employees.edit']);
        $routes->post('profile/(:segment)/resignation/save', 'Employee\ProfileController::saveResignation/$1', ['filter' => 'permission:employees.separate|employees.edit']);
        $routes->post('profile/(:segment)/termination/save', 'Employee\ProfileController::saveTermination/$1', ['filter' => 'permission:employee.terminate|employees.separate|employees.delete']);
        $routes->post('profile/(:segment)/training/add', 'Employee\ProfileController::addTraining/$1', ['filter' => 'permission:employees.edit|training.create']);
        $routes->post('profile/(:segment)/reset-password', 'Employee\ProfileController::resetPassword/$1', ['filter' => 'permission:employees.edit|users.edit']);
        $routes->post('delete/(:segment)', 'Employee\EmployeeController::delete/$1', ['filter' => 'permission:employees.delete']);
    });

    // Employee Organogram & Organizational Hierarchy Module (/organogram redirects to /employees/hierarchy)
    $routes->get('organogram', function () {
        return redirect()->to(base_url('employees/hierarchy'));
    });
    $routes->group('organogram', ['filter' => ['auth', 'permission:organogram.view|directory.view|employees.view']], function ($routes) {
        $routes->get('tree', 'EmployeeOrganogramController::tree');
        $routes->get('employee/(:segment)', 'EmployeeOrganogramController::employee/$1');
        $routes->get('department/(:segment)', 'EmployeeOrganogramController::department/$1');
        $routes->post('manager/update', 'EmployeeOrganogramController::updateManager', ['filter' => 'permission:organogram.manage|employee.transfer|employees.movement|employees.edit']);
        $routes->get('export/pdf', 'EmployeeOrganogramController::exportPdf', ['filter' => 'permission:organogram.export|employees.export|employees.view']);
    });

    // Attendance & Working Shifts
    $routes->group('attendance', ['filter' => 'auth'], function ($routes) {
        $routes->get('/', 'Attendance\AttendanceController::index', ['filter' => 'permission:attendance.view']);
        $routes->get('live-control', 'Attendance\LiveAttendanceController::index', ['filter' => 'permission:attendance.view']);
        $routes->post('run-diagnostic-tests', 'Attendance\AttendanceController::runDiagnosticTests', ['filter' => 'platformAdmin']);
        $routes->get('live-summary', 'Attendance\LiveAttendanceController::summary', ['filter' => 'permission:attendance.view']);
        $routes->get('live-employees', 'Attendance\LiveAttendanceController::employeeList', ['filter' => 'permission:attendance.view']);
        $routes->post('live-trigger-single', 'Attendance\LiveAttendanceController::triggerSingle', ['filter' => 'permission:attendance.manage']);
        $routes->post('live-trigger-bulk', 'Attendance\LiveAttendanceController::triggerBulk', ['filter' => 'permission:attendance.manage']);
        $routes->post('live-simulate', 'Attendance\LiveAttendanceController::triggerSimulation', ['filter' => 'permission:attendance.manage']);
        $routes->post('live-reset', 'Attendance\LiveAttendanceController::resetTestAttendance', ['filter' => 'permission:attendance.manage']);
        $routes->post('check-in', 'Attendance\AttendanceController::checkIn', ['filter' => 'permission:attendance.clock|attendance.create|attendance.manage']);
        $routes->post('check-out', 'Attendance\AttendanceController::checkOut', ['filter' => 'permission:attendance.clock|attendance.create|attendance.manage']);
        $routes->post('start-break', 'Attendance\AttendanceController::startBreak', ['filter' => 'permission:attendance.clock|attendance.create|attendance.manage']);
        $routes->post('end-break', 'Attendance\AttendanceController::endBreak', ['filter' => 'permission:attendance.clock|attendance.create|attendance.manage']);
        $routes->post('hardware-punch', 'Attendance\AttendanceController::hardwarePunch', ['filter' => 'permission:attendance.create']);
        $routes->post('manual-entry', 'Attendance\AttendanceController::manualEntry', ['filter' => 'permission:attendance.create']);
        $routes->post('correction/submit', 'Attendance\AttendanceController::submitCorrection', ['filter' => 'permission:attendance.regularize|attendance.create|attendance.manage']);
        $routes->post('correction/approve/(:segment)', 'Attendance\AttendanceController::approveCorrection/$1', ['filter' => 'permission:attendance.regularize_approve']);
        $routes->post('correction/reject/(:segment)', 'Attendance\AttendanceController::rejectCorrection/$1', ['filter' => 'permission:attendance.regularize_approve']);
        $routes->get('corrections-ajax', 'Attendance\AttendanceController::getCorrectionsAjax', ['filter' => 'permission:attendance.view']);
        $routes->get('getCorrectionsAjax', 'Attendance\AttendanceController::getCorrectionsAjax', ['filter' => 'permission:attendance.view']);
        $routes->post('recalculate', 'Attendance\AttendanceController::recalculate', ['filter' => 'permission:attendance.manage']);

        // Company Early Closure & Full-Day Credits Routes
        $routes->get('early-closures', 'Attendance\CompanyEarlyClosureController::index', ['filter' => 'permission:attendance.early_closures|attendance.early_closure_manage']);
        $routes->post('early-closures/preview', 'Attendance\CompanyEarlyClosureController::preview', ['filter' => 'permission:attendance.early_closure_manage']);
        $routes->post('early-closures/create', 'Attendance\CompanyEarlyClosureController::create', ['filter' => 'permission:attendance.early_closure_manage']);
        $routes->post('early-closures/submit/(:segment)', 'Attendance\CompanyEarlyClosureController::submit/$1', ['filter' => 'permission:attendance.early_closure_manage']);
        $routes->post('early-closures/approve/(:segment)', 'Attendance\CompanyEarlyClosureController::approve/$1', ['filter' => 'permission:attendance.early_closure_manage']);
        $routes->post('early-closures/reject/(:segment)', 'Attendance\CompanyEarlyClosureController::reject/$1', ['filter' => 'permission:attendance.early_closure_manage']);
        $routes->post('early-closures/cancel/(:segment)', 'Attendance\CompanyEarlyClosureController::cancel/$1', ['filter' => 'permission:attendance.early_closure_manage']);
        $routes->get('early-closures/details/(:segment)', 'Attendance\CompanyEarlyClosureController::details/$1', ['filter' => 'permission:attendance.early_closures|attendance.early_closure_manage']);
        $routes->post('settings/save', 'Attendance\AttendanceController::saveSettings', ['filter' => 'permission:attendance.manage']);
        $routes->post('zkteco/test', 'Attendance\AttendanceController::testZKTeco', ['filter' => 'permission:attendance.device_manage']);
        $routes->post('zkteco/sync', 'Attendance\AttendanceController::syncZKTeco', ['filter' => 'permission:attendance.sync']);
        $routes->get('employee-ajax', 'Attendance\AttendanceController::getEmployeeAttendanceAjax', ['filter' => 'permission:attendance.view']);
        $routes->get('getEmployeeAttendanceAjax', 'Attendance\AttendanceController::getEmployeeAttendanceAjax', ['filter' => 'permission:attendance.view']);
        $routes->get('group-ajax', 'Attendance\AttendanceController::getGroupAttendanceAjax', ['filter' => 'permission:attendance.view']);
        $routes->get('getGroupAttendanceAjax', 'Attendance\AttendanceController::getGroupAttendanceAjax', ['filter' => 'permission:attendance.view']);
        $routes->get('muster-ajax', 'Attendance\AttendanceController::getMonthlyMusterAjax', ['filter' => 'permission:attendance.view']);
        $routes->get('getMonthlyMusterAjax', 'Attendance\AttendanceController::getMonthlyMusterAjax', ['filter' => 'permission:attendance.view']);
        $routes->get('calendar-leaves-ajax', 'Attendance\AttendanceController::getCalendarLeavesAjax', ['filter' => 'permission:attendance.view|leave.view']);
        $routes->get('getCalendarLeavesAjax', 'Attendance\AttendanceController::getCalendarLeavesAjax', ['filter' => 'permission:attendance.view|leave.view']);
        $routes->get('report-api', 'Attendance\AttendanceController::getReportAjax', ['filter' => 'permission:attendance.view']);
        $routes->get('reports-catalog', 'Attendance\AttendanceController::getReportsCatalogAjax', ['filter' => 'permission:attendance.view']);
        $routes->post('test-summary-rules', 'Attendance\AttendanceController::runSummaryAcceptanceTests', ['filter' => 'permission:attendance.manage']);
        $routes->get('rules', 'Attendance\AttendanceRuleEngineController::index', ['filter' => 'permission:attendance.view']);
        $routes->get('export', 'Attendance\AttendanceController::export', ['filter' => 'permission:attendance.export']);
        $routes->get('print-report', 'Attendance\AttendanceController::printReport', ['filter' => 'permission:attendance.view']);
        $routes->get('roster', 'Attendance\RosterController::index', ['filter' => 'permission:rostering.view|attendance.view']);
        $routes->get('roster/my', 'Attendance\RosterController::myRoster');
        $routes->get('my-roster', 'Attendance\RosterController::myRoster');
        $routes->get('roster/data', 'Attendance\RosterController::data', ['filter' => 'permission:rostering.view|attendance.view']);
        $routes->post('roster/assign', 'Attendance\RosterController::assign', ['filter' => 'permission:rostering.manage|rostering.assign|rostering.create|rostering.edit']);
        $routes->post('roster/bulk-assign', 'Attendance\RosterController::bulkAssign', ['filter' => 'permission:rostering.manage|rostering.assign|rostering.create|rostering.edit']);
        $routes->post('roster/auto-assign', 'Attendance\RosterController::autoAssign', ['filter' => 'permission:rostering.manage|rostering.assign|rostering.create|rostering.edit']);
        $routes->post('roster/swap/create', 'Attendance\RosterController::createSwap', ['filter' => 'permission:rostering.manage|rostering.create|rostering.edit']);
        $routes->post('roster/swap/approve/(:segment)', 'Attendance\RosterController::approveSwap/$1', ['filter' => 'permission:rostering.manage|rostering.edit']);
        $routes->post('roster/swap/reject/(:segment)', 'Attendance\RosterController::rejectSwap/$1', ['filter' => 'permission:rostering.manage|rostering.edit']);
        $routes->post('roster/publish', 'Attendance\RosterController::publish', ['filter' => 'permission:rostering.publish|rostering.manage|rostering.create']);
        $routes->post('roster/copy-week', 'Attendance\RosterController::copyWeek', ['filter' => 'permission:rostering.manage|rostering.create|rostering.edit']);
        $routes->get('roster/conflicts', 'Attendance\RosterController::conflicts', ['filter' => 'permission:rostering.view|attendance.view']);
        $routes->get('roster/history', 'Attendance\RosterController::history', ['filter' => 'permission:rostering.view|attendance.view']);
        $routes->get('roster/export', 'Attendance\RosterController::export', ['filter' => 'permission:rostering.export|rostering.view']);
        $routes->get('duty-assignments', 'Attendance\DutyAssignmentController::index', ['filter' => 'permission:attendance.view|rostering.view']);
        $routes->get('duty-assignments/data', 'Attendance\DutyAssignmentController::data', ['filter' => 'permission:attendance.view|rostering.view']);
        $routes->post('duty-assignments/store', 'Attendance\DutyAssignmentController::store', ['filter' => 'permission:attendance.manage|rostering.manage']);
        $routes->post('duty-assignments/update/(:segment)', 'Attendance\DutyAssignmentController::update/$1', ['filter' => 'permission:attendance.manage|rostering.manage']);
        $routes->post('duty-assignments/delete/(:segment)', 'Attendance\DutyAssignmentController::delete/$1', ['filter' => 'permission:attendance.manage|rostering.manage']);
        $routes->post('duty-assignments/bulk-assign', 'Attendance\DutyAssignmentController::bulkAssign', ['filter' => 'permission:attendance.manage|rostering.manage']);

        $routes->get('duty_assignments', 'Attendance\DutyAssignmentController::index', ['filter' => 'permission:attendance.view|rostering.view']);
        $routes->get('duty_assignments/data', 'Attendance\DutyAssignmentController::data', ['filter' => 'permission:attendance.view|rostering.view']);
        $routes->post('duty_assignments/store', 'Attendance\DutyAssignmentController::store', ['filter' => 'permission:attendance.manage|rostering.manage']);
        $routes->post('duty_assignments/update/(:segment)', 'Attendance\DutyAssignmentController::update/$1', ['filter' => 'permission:attendance.manage|rostering.manage']);
        $routes->post('duty_assignments/delete/(:segment)', 'Attendance\DutyAssignmentController::delete/$1', ['filter' => 'permission:attendance.manage|rostering.manage']);
        $routes->post('duty_assignments/bulk-assign', 'Attendance\DutyAssignmentController::bulkAssign', ['filter' => 'permission:attendance.manage|rostering.manage']);
        $routes->get('sync', 'Attendance\AttendanceSyncController::index', ['filter' => 'permission:attendance.sync']);
        $routes->post('sync/trigger', 'Attendance\AttendanceSyncController::trigger', ['filter' => 'permission:attendance.sync']);
        $routes->post('sync/upload', 'Attendance\AttendanceSyncController::upload', ['filter' => 'permission:attendance.sync']);
        $routes->post('sync/cron', 'Attendance\AttendanceSyncController::cron', ['filter' => 'permission:attendance.sync|attendance.manage']);
        $routes->post('sync/device/save', 'Attendance\AttendanceSyncController::saveDevice', ['filter' => 'permission:attendance.device_manage']);
        $routes->post('sync/device/delete/(:segment)', 'Attendance\AttendanceSyncController::deleteDevice/$1', ['filter' => 'permission:attendance.device_manage']);
        $routes->post('sync/device/test/(:segment)', 'Attendance\AttendanceSyncController::testConnection/$1', ['filter' => 'permission:attendance.device_manage']);
        $routes->post('sync/device/sync-now/(:segment)', 'Attendance\AttendanceSyncController::syncDeviceNow/$1', ['filter' => 'permission:attendance.sync']);
        $routes->post('sync/device/test-raw-ip', 'Attendance\AttendanceSyncController::testRawIp', ['filter' => 'permission:attendance.device_manage']);
        $routes->get('sync/download-agent/(:segment)', 'Attendance\AttendanceSyncController::downloadAgent/$1', ['filter' => 'permission:attendance.sync']);
        $routes->get('sync/download-agent', 'Attendance\AttendanceSyncController::downloadAgent', ['filter' => 'permission:attendance.sync']);
        $routes->post('sync/reprocess', 'Attendance\AttendanceSyncController::reprocessEvents', ['filter' => 'permission:attendance.sync']);

        // Unmatched Biometric Staff & Identity Mapping Hub
        $routes->get('unmatched', 'Attendance\UnmatchedBiometricController::index', ['filter' => 'permission:attendance.view']);
        $routes->post('unmatched/repair', 'Attendance\UnmatchedBiometricController::repair', ['filter' => 'permission:attendance.manage']);
        $routes->get('unmatched/events/(:segment)', 'Attendance\UnmatchedBiometricController::events/$1', ['filter' => 'permission:attendance.view']);
        $routes->post('unmatched/link', 'Attendance\UnmatchedBiometricController::link', ['filter' => 'permission:attendance.manage']);
        $routes->post('unmatched/map', 'Attendance\UnmatchedBiometricController::link', ['filter' => 'permission:attendance.manage']);
        $routes->post('unmatched/ignore', 'Attendance\UnmatchedBiometricController::ignore', ['filter' => 'permission:attendance.manage']);
        $routes->post('unmatched/reprocess', 'Attendance\UnmatchedBiometricController::reprocess', ['filter' => 'permission:attendance.manage']);
        $routes->post('unmatched/unmap', 'Attendance\UnmatchedBiometricController::unmap', ['filter' => 'permission:attendance.manage']);
        $routes->get('unmatched/api', 'Attendance\UnmatchedBiometricController::apiIndex', ['filter' => 'permission:attendance.view']);

        // ZKTeco Hardware Manager
        $routes->get('zkteco', 'Attendance\ZKTecoController::index', ['filter' => 'permission:attendance.device_manage']);
        $routes->post('zkteco/save', 'Attendance\ZKTecoController::saveDevice', ['filter' => 'permission:attendance.device_manage']);
        $routes->post('zkteco/ping/(:segment)', 'Attendance\ZKTecoController::pingDevice/$1', ['filter' => 'permission:attendance.device_manage']);
        $routes->post('zkteco/sync/(:segment)', 'Attendance\ZKTecoController::syncDevice/$1', ['filter' => 'permission:attendance.sync']);
        $routes->post('zkteco/sync-all', 'Attendance\ZKTecoController::syncAll', ['filter' => 'permission:attendance.sync']);
        $routes->post('zkteco/delete/(:segment)', 'Attendance\ZKTecoController::deleteDevice/$1', ['filter' => 'permission:attendance.device_manage']);

        // New Overtime Engine Routes
        $routes->get('overtime', 'Attendance\OvertimeController::index', ['filter' => 'permission:overtime.view|attendance.view']);
        $routes->get('overtime/policy', 'Attendance\OvertimeController::policy', ['filter' => 'permission:overtime.view|attendance.view']);
        $routes->post('overtime/policy/save', 'Attendance\OvertimeController::savePolicy', ['filter' => 'permission:rules.manage']);
        $routes->post('overtime/save-rules', 'Attendance\OvertimeController::saveRules', ['filter' => 'permission:rules.manage']);
        $routes->get('overtime/records', 'Attendance\OvertimeController::records', ['filter' => 'permission:overtime.view|attendance.view']);
        $routes->post('overtime/calculate', 'Attendance\OvertimeController::calculate', ['filter' => 'permission:overtime.manage|attendance.manage']);
        $routes->post('overtime/approve/(:segment)', 'Attendance\OvertimeController::approve/$1', ['filter' => 'permission:overtime.approve']);
        $routes->post('overtime/reject/(:segment)', 'Attendance\OvertimeController::reject/$1', ['filter' => 'permission:overtime.approve']);
        $routes->post('overtime/batch-approve', 'Attendance\OvertimeController::batchApprove', ['filter' => 'permission:overtime.approve']);
        $routes->post('overtime/batch-reject', 'Attendance\OvertimeController::batchReject', ['filter' => 'permission:overtime.approve']);
        $routes->get('overtime/claims', 'Attendance\OvertimeController::claims', ['filter' => 'permission:overtime.view|attendance.view']);
        $routes->post('overtime/request', 'Attendance\OvertimeController::submitClaim', ['filter' => 'permission:overtime.create|overtime.manage']);
        $routes->post('overtime/claims/submit', 'Attendance\OvertimeController::submitClaim', ['filter' => 'permission:overtime.create|overtime.manage']);
        $routes->post('overtime/claims/review/(:segment)', 'Attendance\OvertimeController::reviewClaim/$1', ['filter' => 'permission:overtime.approve']);
        $routes->post('overtime/locks', 'Attendance\OvertimeController::locks', ['filter' => 'permission:overtime.manage|payroll.manage|attendance.manage']);
        $routes->post('overtime/release-lock/(:segment)', 'Attendance\OvertimeController::releaseLock/$1', ['filter' => 'permission:overtime.manage|payroll.manage|attendance.manage']);
        $routes->get('overtime/export', 'Attendance\OvertimeController::export', ['filter' => 'permission:overtime.export|attendance.export']);
        $routes->post('overtime/rate/save', 'Attendance\OvertimeController::saveEmployeeRate', ['filter' => 'permission:overtime.manage|payroll.manage|attendance.manage']);
    });

    // Dedicated Live Attendance Testing & Simulation Direct Aliases
    $routes->get('live-attendance', 'Attendance\LiveAttendanceController::index', ['filter' => ['auth', 'permission:attendance.view']]);
    $routes->get('live-control', 'Attendance\LiveAttendanceController::index', ['filter' => ['auth', 'permission:attendance.view']]);
    $routes->get('attendance-simulation', 'Attendance\LiveAttendanceController::index', ['filter' => ['auth', 'permission:attendance.view']]);

    // ZKTeco Direct Routes
    $routes->group('zkteco', ['filter' => ['auth']], function ($routes) {
        $routes->get('/', 'Attendance\ZKTecoController::index', ['filter' => 'permission:attendance.device_manage']);
        $routes->post('save', 'Attendance\ZKTecoController::saveDevice', ['filter' => 'permission:attendance.device_manage']);
        $routes->post('ping/(:segment)', 'Attendance\ZKTecoController::pingDevice/$1', ['filter' => 'permission:attendance.device_manage']);
        $routes->post('sync/(:segment)', 'Attendance\ZKTecoController::syncDevice/$1', ['filter' => 'permission:attendance.sync']);
        $routes->post('sync-all', 'Attendance\ZKTecoController::syncAll', ['filter' => 'permission:attendance.sync']);
        $routes->post('delete/(:segment)', 'Attendance\ZKTecoController::deleteDevice/$1', ['filter' => 'permission:attendance.device_manage']);
    });

    // Shift Scheduling & Rosters (Direct Route)
    $routes->group('roster', ['filter' => ['auth', 'permission:rostering.view']], function ($routes) {
        $routes->get('/', 'Roster\RosterController::index');
        $routes->post('assign', 'Roster\RosterController::assign', ['filter' => 'permission:rostering.manage|rostering.assign|rostering.create|rostering.edit']);
        $routes->post('auto-assign', 'Roster\RosterController::autoAssign', ['filter' => 'permission:rostering.manage|rostering.assign|rostering.create|rostering.edit']);
        $routes->post('swap/create', 'Roster\RosterController::createSwap', ['filter' => 'permission:rostering.manage|rostering.create|rostering.edit']);
        $routes->post('swap/approve/(:segment)', 'Roster\RosterController::approveSwap/$1', ['filter' => 'permission:rostering.manage|rostering.edit']);
        $routes->post('swap/reject/(:segment)', 'Roster\RosterController::rejectSwap/$1', ['filter' => 'permission:rostering.manage|rostering.edit']);
        $routes->post('publish', 'Roster\RosterController::publish', ['filter' => 'permission:rostering.publish|rostering.manage|rostering.create']);
        $routes->get('export', 'Roster\RosterController::export', ['filter' => 'permission:rostering.export|rostering.view']);
    });

    // Weekend, Holiday & Special Duty Assignments (Direct Root Routes & Aliases)
    $dutyAssignmentRoutes = function ($routes) {
        $routes->get('/', 'Attendance\DutyAssignmentController::index', ['filter' => 'permission:attendance.view|rostering.view']);
        $routes->get('', 'Attendance\DutyAssignmentController::index', ['filter' => 'permission:attendance.view|rostering.view']);
        $routes->get('data', 'Attendance\DutyAssignmentController::data', ['filter' => 'permission:attendance.view|rostering.view']);
        $routes->post('store', 'Attendance\DutyAssignmentController::store', ['filter' => 'permission:attendance.manage|rostering.manage']);
        $routes->post('update/(:segment)', 'Attendance\DutyAssignmentController::update/$1', ['filter' => 'permission:attendance.manage|rostering.manage']);
        $routes->post('delete/(:segment)', 'Attendance\DutyAssignmentController::delete/$1', ['filter' => 'permission:attendance.manage|rostering.manage']);
        $routes->post('bulk-assign', 'Attendance\DutyAssignmentController::bulkAssign', ['filter' => 'permission:attendance.manage|rostering.manage']);
    };

    $routes->group('duty-assignments', ['filter' => ['auth', 'permission:attendance.view|rostering.view']], $dutyAssignmentRoutes);
    $routes->group('duty_assignments', ['filter' => ['auth', 'permission:attendance.view|rostering.view']], $dutyAssignmentRoutes);
    $routes->get('duty-assignments', 'Attendance\DutyAssignmentController::index', ['filter' => ['auth', 'permission:attendance.view|rostering.view']]);
    $routes->get('duty_assignments', 'Attendance\DutyAssignmentController::index', ['filter' => ['auth', 'permission:attendance.view|rostering.view']]);

    // Subdirectory /hrm alias routes (when accessed through reverse proxy or subfolder base URI)
    $routes->group('hrm/duty-assignments', ['filter' => ['auth', 'permission:attendance.view|rostering.view']], $dutyAssignmentRoutes);
    $routes->group('hrm/duty_assignments', ['filter' => ['auth', 'permission:attendance.view|rostering.view']], $dutyAssignmentRoutes);
    $routes->get('hrm/duty-assignments', 'Attendance\DutyAssignmentController::index', ['filter' => ['auth', 'permission:attendance.view|rostering.view']]);
    $routes->get('hrm/duty_assignments', 'Attendance\DutyAssignmentController::index', ['filter' => ['auth', 'permission:attendance.view|rostering.view']]);
    $routes->group('hrm/attendance/duty-assignments', ['filter' => ['auth', 'permission:attendance.view|rostering.view']], $dutyAssignmentRoutes);
    $routes->group('hrm/attendance/duty_assignments', ['filter' => ['auth', 'permission:attendance.view|rostering.view']], $dutyAssignmentRoutes);

    // Leave Management (Unified Route Group & Aliases for 'leave' and 'leaves')
    $leaveRoutesDefinition = function ($routes) {
        $routes->get('/', 'Leave\LeaveController::index', ['filter' => 'permission:leave.view']);
        $routes->post('apply', 'Leave\LeaveController::apply', ['filter' => 'permission:leave.create']);
        $routes->post('endorse/(:segment)', 'Leave\LeaveController::endorse/$1', ['filter' => 'permission:leave.endorse']);
        $routes->post('endorse-dept-head/(:segment)', 'Leave\LeaveController::endorseDeptHead/$1', ['filter' => 'permission:leave.endorse|leave.approve|leave.manage']);
        $routes->post('approve/(:segment)', 'Leave\LeaveController::approve/$1', ['filter' => 'permission:leave.approve|leave.endorse|leave.hr_approve|leave.manage']);
        $routes->post('reject/(:segment)', 'Leave\LeaveController::reject/$1', ['filter' => 'permission:leave.approve|leave.reject|leave.endorse|leave.hr_approve|leave.manage']);
        $routes->post('cancel/(:segment)', 'Leave\LeaveController::cancel/$1', ['filter' => 'permission:leave.cancel|leave.approve|leave.manage|leave.create']);
        $routes->post('batch-approve', 'Leave\LeaveController::batchApprove', ['filter' => 'permission:leave.approve|leave.endorse|leave.hr_approve|leave.manage']);
        $routes->post('batch-reject', 'Leave\LeaveController::batchReject', ['filter' => 'permission:leave.approve|leave.reject|leave.endorse|leave.hr_approve|leave.manage']);
        $routes->post('balance-adjust', 'Leave\LeaveController::adjustBalance', ['filter' => 'permission:leave.manage|leave.balance_adjust|leave.adjust']);
        $routes->post('encash', 'Leave\LeaveController::encash', ['filter' => 'permission:leave.encash']);
        $routes->post('accrue-monthly', 'Leave\LeaveController::accrueMonthly', ['filter' => 'permission:leave.manage']);
        $routes->post('rollover-year-end', 'Leave\LeaveController::rolloverYearEnd', ['filter' => 'permission:leave.manage']);
        $routes->post('reopen-year', 'Leave\LeaveController::reopenYear', ['filter' => 'permission:leave.closing_reopen']);
        $routes->get('ledger', 'Leave\LeaveController::ledger', ['filter' => 'permission:leave.view']);
        $routes->get('attachment/(:segment)', 'Leave\LeaveController::downloadAttachment/$1', ['filter' => 'permission:leave.view']);
        $routes->get('slip/(:segment)', 'Leave\LeaveController::printSlip/$1', ['filter' => 'permission:leave.view']);
        $routes->get('print/(:segment)', 'Leave\LeaveController::printSlip/$1', ['filter' => 'permission:leave.view']);
        $routes->post('type/save', 'Leave\LeaveController::saveType', ['filter' => 'permission:leave.manage']);
        $routes->post('type/delete/(:segment)', 'Leave\LeaveController::deleteType/$1', ['filter' => 'permission:leave.manage']);
        $routes->get('calculate-encashment', 'Leave\LeaveController::calculateEncashment', ['filter' => 'permission:leave.encash']);
        $routes->post('calculate-days', 'Leave\LeaveController::calculateDays', ['filter' => 'permission:leave.create|leave.manage|leave.view']);
        $routes->match(['get', 'post'], 'simulate', 'Leave\LeaveController::simulate', ['filter' => 'permission:leave.create|leave.manage|leave.view']);
        $routes->get('get-balance', 'Leave\LeaveController::getBalance', ['filter' => 'permission:leave.view']);
        $routes->get('calendar-matrix', 'Leave\LeaveController::calendarMatrix', ['filter' => 'permission:leave.view']);
        $routes->get('export', 'Leave\LeaveController::export', ['filter' => 'permission:leave.export']);
        $routes->post('update/(:segment)', 'Leave\LeaveController::update/$1', ['filter' => 'permission:leave.create']);
        $routes->match(['get', 'post'], 'check-eligibility', 'Leave\LeaveController::checkEligibility', ['filter' => 'permission:leave.create|leave.manage|leave.view']);
        $routes->match(['get', 'post'], 'eligible-types', 'Leave\LeaveController::eligibleTypes', ['filter' => 'permission:leave.create|leave.manage|leave.view']);
        $routes->get('probation-state', 'Leave\LeaveController::getProbationState', ['filter' => 'permission:leave.view']);
        $routes->post('extend-probation', 'Leave\LeaveController::extendProbation', ['filter' => 'permission:leave.manage']);
        $routes->post('early-confirm', 'Leave\LeaveController::earlyConfirm', ['filter' => 'permission:leave.manage']);
        $routes->post('complete-probation', 'Leave\LeaveController::completeProbation', ['filter' => 'permission:leave.manage']);
        $routes->post('cancel-probation', 'Leave\LeaveController::cancelProbation', ['filter' => 'permission:leave.manage']);
        $routes->post('change-employment-type', 'Leave\LeaveController::changeEmploymentType', ['filter' => 'permission:leave.manage']);
        $routes->post('set-eligibility-override', 'Leave\LeaveController::setEligibilityOverride', ['filter' => 'permission:leave.manage']);
        $routes->post('remove-eligibility-override', 'Leave\LeaveController::removeEligibilityOverride', ['filter' => 'permission:leave.manage']);
        $routes->get('probation-audit-logs', 'Leave\LeaveController::getProbationAuditLogs', ['filter' => 'permission:leave.manage']);
        $routes->get('reconciliation/data', 'Leave\LeaveController::reconciliationData', ['filter' => 'permission:leave.manage']);
        $routes->post('reconciliation/auto-reconcile', 'Leave\LeaveController::autoReconcile', ['filter' => 'permission:leave.manage']);
    };
    $routes->group('leave', ['filter' => 'permission:leave.view'], $leaveRoutesDefinition);
    $routes->group('leaves', ['filter' => 'permission:leave.view'], $leaveRoutesDefinition);

    // Bonuses & Incentives (Isolated from payroll.view)
    $routes->group('payroll/bonuses', ['filter' => 'auth'], function ($routes) {
        $routes->get('/', 'Payroll\BonusController::index', ['filter' => 'permission:bonus.view']);
        $routes->get('', 'Payroll\BonusController::index', ['filter' => 'permission:bonus.view']);
        $routes->post('create', 'Payroll\BonusController::create', ['filter' => 'permission:bonus.create']);
        $routes->post('approve/(:segment)', 'Payroll\BonusController::approve/$1', ['filter' => 'permission:bonus.approve']);
        $routes->post('reject/(:segment)', 'Payroll\BonusController::reject/$1', ['filter' => 'permission:bonus.approve']);
        $routes->post('adjust/(:segment)', 'Payroll\BonusController::adjust/$1', ['filter' => 'permission:bonus.edit']);
        $routes->post('delete/(:segment)', 'Payroll\BonusController::delete/$1', ['filter' => 'permission:bonus.delete']);
        $routes->post('approve-weekly/(:segment)', 'Payroll\BonusController::approveWeekly/$1', ['filter' => 'permission:bonus.approve']);
        $routes->post('reject-weekly/(:segment)', 'Payroll\BonusController::rejectWeekly/$1', ['filter' => 'permission:bonus.approve']);
        $routes->post('batch-approve-weekly', 'Payroll\BonusController::batchApproveWeekly', ['filter' => 'permission:bonus.approve']);
        $routes->post('resolve-stuck', 'Payroll\BonusController::resolveStuck', ['filter' => 'permission:bonus.approve']);
    });

    // Employee Loans & Salary Advances (Isolated from payroll.view)
    $routes->group('payroll/loans', ['filter' => 'auth'], function ($routes) {
        $routes->get('/', 'Payroll\LoanController::index', ['filter' => 'permission:loans.view']);
        $routes->get('', 'Payroll\LoanController::index', ['filter' => 'permission:loans.view']);
        $routes->get('(:segment)', 'Payroll\LoanController::show/$1', ['filter' => 'permission:loans.view']);
        $routes->post('apply', 'Payroll\LoanController::apply', ['filter' => 'permission:loans.create']);
        $routes->post('approve/(:segment)', 'Payroll\LoanController::approve/$1', ['filter' => 'permission:loans.approve']);
        $routes->post('reject/(:segment)', 'Payroll\LoanController::reject/$1', ['filter' => 'permission:loans.approve']);
        $routes->post('advance/approve/(:segment)', 'Payroll\LoanController::approveAdvance/$1', ['filter' => 'permission:loans.approve']);
        $routes->post('advance/reject/(:segment)', 'Payroll\LoanController::rejectAdvance/$1', ['filter' => 'permission:loans.approve']);
    });

    // Loan Amortization & Simulation
    $routes->group('payroll/loan', ['filter' => 'auth'], function ($routes) {
        $routes->get('schedule', 'Payroll\PayrollSimulationController::getLoanAmortizationSchedule', ['filter' => 'permission:loans.view|payroll.loans|payroll.view']);
        $routes->post('simulate', 'Payroll\PayrollSimulationController::simulateLoanEMI', ['filter' => 'permission:loans.create|loans.manage|loans.view|payroll.loans|payroll.view']);
    });

    // Provident Fund Ledger, Statements & Reports (Accessible by PF or Payroll permissions)
    $routes->group('payroll/pf', ['filter' => 'auth'], function ($routes) {
        $routes->get('ledger', 'Payroll\PayrollSettingsController::getPFLedgerAjax', ['filter' => 'permission:pf.view|payroll.view']);
        $routes->get('ledger/statement/(:segment)', 'Payroll\PayrollSettingsController::getEmployeePFStatementAjax/$1', ['filter' => 'permission:pf.view|payroll.view']);
        $routes->post('ledger/adjust', 'Payroll\PayrollSettingsController::adjustPFLedgerAjax', ['filter' => 'permission:pf.manage|settings.manage|payroll.manage']);
        $routes->post('ledger/reverse/(:segment)', 'Payroll\PayrollSettingsController::reversePFLedgerAjax/$1', ['filter' => 'permission:pf.manage|settings.manage|payroll.manage']);
        $routes->get('export-ledger', 'Payroll\PayrollSettingsController::exportPFLedgerCsv', ['filter' => 'permission:pf.export|payroll.export|pf.view|payroll.view']);
        $routes->get('reports/summary', 'Payroll\PfReportController::summary', ['filter' => 'permission:pf.view|payroll.view']);
        $routes->get('reports/details', 'Payroll\PfReportController::details', ['filter' => 'permission:pf.view|payroll.view']);
        $routes->get('reports/eligibility', 'Payroll\PfReportController::eligibility', ['filter' => 'permission:pf.view|payroll.view']);
        $routes->get('reports/reconciliation', 'Payroll\PfReportController::reconciliation', ['filter' => 'permission:pf.view|payroll.view']);
        $routes->get('reports/export-summary', 'Payroll\PfReportController::exportSummaryCsv', ['filter' => 'permission:pf.export|payroll.export|pf.view|payroll.view']);
        $routes->get('reports/export-details', 'Payroll\PfReportController::exportDetailsCsv', ['filter' => 'permission:pf.export|payroll.export|pf.view|payroll.view']);
        $routes->get('reports/export-eligibility', 'Payroll\PfReportController::exportEligibilityCsv', ['filter' => 'permission:pf.export|payroll.export|pf.view|payroll.view']);
    });

    // Standalone PF rules & simulation routes under payroll
    $routes->get('payroll/pf-rules', 'Payroll\PayrollSettingsController::getPFRulesAjax', ['filter' => ['auth', 'permission:pf.view|payroll.view|rules.view']]);
    $routes->post('payroll/pf-rule/save', 'Payroll\PayrollSettingsController::savePFRule', ['filter' => ['auth', 'permission:rules.manage|payroll.manage|pf.manage']]);
    $routes->post('payroll/pf-rule/delete/(:segment)', 'Payroll\PayrollSettingsController::deletePFRule/$1', ['filter' => ['auth', 'permission:rules.manage|payroll.manage|pf.manage']]);
    $routes->post('payroll/pf-simulation-matrix', 'Payroll\PayrollSimulationController::getPFSimulationMatrixAjax', ['filter' => ['auth', 'permission:pf.manage|payroll.manage|pf.view|payroll.view']]);

    // Root-level aliases for tax rule endpoints
    $routes->post('tax-rule/save', 'Payroll\PayrollSettingsController::saveTaxRule', ['filter' => ['auth', 'permission:rules.manage|payroll.manage']]);
    $routes->post('tax-rule/delete/(:segment)', 'Payroll\PayrollSettingsController::deleteTaxRule/$1', ['filter' => ['auth', 'permission:rules.manage|payroll.manage']]);

    // Payroll modal loan/advance grant endpoints
    $routes->post('payroll/grant-loan', 'Payroll\LoanAdvanceController::grantLoan', ['filter' => ['auth', 'permission:payroll.loans|loans.create|loans.manage|payroll.manage']]);
    $routes->post('payroll/add-advance', 'Payroll\LoanAdvanceController::addAdvance', ['filter' => ['auth', 'permission:payroll.loans|loans.create|loans.manage|payroll.manage']]);
    $routes->post('payroll/update-advance-status/(:segment)/(:segment)', 'Payroll\LoanAdvanceController::updateAdvanceStatus/$1/$2', ['filter' => ['auth', 'permission:payroll.approve|loans.approve|payroll.manage']]);

    // Core Payroll Processing & Administration
    $routes->group('payroll', ['filter' => 'auth'], function ($routes) {
        $routes->get('/', 'Payroll\PayrollController::index', ['filter' => 'permission:payroll.view']);
        $routes->get('', 'Payroll\PayrollController::index', ['filter' => 'permission:payroll.view']);

        // Salary Component Master (Company & Branch Scoped)
        $routes->get('salary-components', 'Payroll\SalaryComponentMasterController::index', ['filter' => 'permission:payroll.view']);
        $routes->post('salary-components/store', 'Payroll\SalaryComponentMasterController::store', ['filter' => 'permission:payroll.manage']);
        $routes->post('salary-components/update/(:segment)', 'Payroll\SalaryComponentMasterController::update/$1', ['filter' => 'permission:payroll.manage']);
        $routes->post('salary-components/toggle-status/(:segment)', 'Payroll\SalaryComponentMasterController::toggleStatus/$1', ['filter' => 'permission:payroll.manage']);
        $routes->post('salary-components/delete/(:segment)', 'Payroll\SalaryComponentMasterController::delete/$1', ['filter' => 'permission:payroll.manage']);
        $routes->post('salary-components/initialize-defaults', 'Payroll\SalaryComponentMasterController::initializeDefaults', ['filter' => 'permission:payroll.manage']);

        // Salary Structure Master (Templates & Item Collections)
        $routes->get('salary-structures', 'Payroll\SalaryStructureMasterController::index', ['filter' => 'permission:payroll.view']);
        $routes->post('salary-structures/preview', 'Payroll\SalaryStructureMasterController::preview', ['filter' => 'permission:payroll.manage|payroll.view']);
        $routes->get('salary-structures/(:segment)', 'Payroll\SalaryStructureMasterController::show/$1', ['filter' => 'permission:payroll.view']);
        $routes->post('salary-structures/store', 'Payroll\SalaryStructureMasterController::store', ['filter' => 'permission:payroll.manage']);
        $routes->post('salary-structures/update/(:segment)', 'Payroll\SalaryStructureMasterController::update/$1', ['filter' => 'permission:payroll.manage']);
        $routes->post('salary-structures/delete/(:segment)', 'Payroll\SalaryStructureMasterController::delete/$1', ['filter' => 'permission:payroll.manage']);
        $routes->post('salary-structures/copy', 'Payroll\SalaryStructureMasterController::copy', ['filter' => 'permission:payroll.manage']);

        // Processing & Exports
        $routes->post('generate', 'Payroll\PayrollGenerationController::generate', ['filter' => 'permission:payroll.generate']);
        $routes->post('adjust', 'Payroll\PayrollGenerationController::adjust', ['filter' => 'permission:payroll.adjust']);
        $routes->post('adjust-preview', 'Payroll\PayrollGenerationController::adjustPreviewAjax', ['filter' => 'permission:payroll.adjust|payroll.manage|payroll.view']);
        $routes->post('simulate-tax', 'Payroll\PayrollSimulationController::simulateTax', ['filter' => 'permission:payroll.manage|payroll.view']);
        $routes->post('advance-stage', 'Payroll\PayrollGenerationController::advanceStage', ['filter' => 'permission:payroll.approve']);
        $routes->post('unlock', 'Payroll\PayrollGenerationController::unlock', ['filter' => 'permission:payroll.lock']);
        $routes->post('discard-draft', 'Payroll\PayrollGenerationController::discardDraft', ['filter' => 'permission:payroll.delete']);
        $routes->post('update-item-status', 'Payroll\PayrollGenerationController::updateItemStatus', ['filter' => 'permission:payroll.approve']);

        // Dynamic Tax Engine & Policy Settings
        $routes->post('tax-rule/save', 'Payroll\PayrollSettingsController::saveTaxRule', ['filter' => 'permission:rules.manage|payroll.manage']);
        $routes->post('tax-rule/delete/(:segment)', 'Payroll\PayrollSettingsController::deleteTaxRule/$1', ['filter' => 'permission:rules.manage|payroll.manage']);
        $routes->post('save-settings', 'Payroll\PayrollSettingsController::saveSettings', ['filter' => 'permission:rules.manage|payroll.manage']);

        $routes->get('export-csv', 'Payroll\PayrollGenerationController::exportCsv', ['filter' => 'permission:payroll.export']);
        $routes->get('export-bank-csv', 'Payroll\PayrollGenerationController::exportBankCsv', ['filter' => 'permission:payroll.export']);
        $routes->get('bank-export-history-ajax', 'Payroll\PayrollGenerationController::getBankExportHistoryAjax', ['filter' => 'permission:payroll.view']);
        $routes->post('bank-export-update-status-ajax', 'Payroll\PayrollGenerationController::updateBankExportStatusAjax', ['filter' => 'permission:payroll.edit']);
        $routes->get('show/(:segment)', 'Payroll\PayrollGenerationController::show/$1', ['filter' => 'permission:payroll.view']);
        $routes->get('draft-summary/(:segment)', 'Payroll\PayrollGenerationController::getDraftSummaryAjax/$1', ['filter' => 'permission:payroll.view']);
        $routes->post('update-status/(:segment)/(:segment)', 'Payroll\PayrollGenerationController::updateStatus/$1/$2', ['filter' => 'permission:payroll.approve']);
        $routes->post('toggle-lock/(:segment)', 'Payroll\PayrollGenerationController::toggleLock/$1', ['filter' => 'permission:payroll.lock']);
        $routes->get('payslip-view/(:segment)', 'Payroll\PayrollGenerationController::payslip/$1', ['filter' => 'permission:payroll.view']);
        $routes->post('disburse/(:segment)', 'Payroll\PayrollGenerationController::disburse/$1', ['filter' => 'permission:payroll.disburse']);
        $routes->get('payslip/(:segment)', 'Payroll\PayslipController::generatePdf/$1', ['filter' => 'permission:payroll.view']);

        // Retroactive Arrears Engine
        $routes->get('arrears/revisions', 'Payroll\PayrollGenerationController::getSalaryRevisionsAjax', ['filter' => 'permission:payroll.view']);
        $routes->get('arrears/ledger', 'Payroll\PayrollGenerationController::getSalaryArrearsAjax', ['filter' => 'permission:payroll.view']);
        $routes->post('arrears/create-revision', 'Payroll\PayrollGenerationController::createSalaryRevision', ['filter' => 'permission:payroll.manage']);
        $routes->post('arrears/approve-revision/(:segment)', 'Payroll\PayrollGenerationController::approveSalaryRevision/$1', ['filter' => 'permission:payroll.manage']);
        $routes->post('arrears/calculate-preview', 'Payroll\PayrollGenerationController::calculateArrearPreview', ['filter' => 'permission:payroll.manage|payroll.view']);
        $routes->post('arrears/approve/(:segment)', 'Payroll\PayrollGenerationController::approveArrear/$1', ['filter' => 'permission:payroll.manage']);
        $routes->post('arrears/disburse/(:segment)', 'Payroll\PayrollGenerationController::disburseArrear/$1', ['filter' => 'permission:payroll.manage']);

        // Final Settlement & Gratuity
        $routes->get('settlement/list', 'Payroll\PayrollGenerationController::getSettlementsAjax', ['filter' => 'permission:payroll.view']);
        $routes->post('settlement/calculate', 'Payroll\PayrollGenerationController::calculateSettlementAjax', ['filter' => 'permission:payroll.manage|payroll.view']);
        $routes->post('settlement/save', 'Payroll\PayrollGenerationController::saveSettlementAjax', ['filter' => 'permission:payroll.manage']);
        $routes->post('settlement/approve/(:segment)', 'Payroll\PayrollGenerationController::approveSettlementAjax/$1', ['filter' => 'permission:payroll.manage']);
        $routes->post('settlement/disburse/(:segment)', 'Payroll\PayrollGenerationController::disburseSettlementAjax/$1', ['filter' => 'permission:payroll.manage']);
        $routes->get('settlement/statement/(:segment)', 'Payroll\PayrollGenerationController::settlementStatement/$1', ['filter' => 'permission:payroll.view']);

        // Cross-Module Reconciliation
        $routes->get('reconciliation/data', 'Payroll\PayrollGenerationController::getReconciliationDataAjax', ['filter' => 'permission:payroll.view']);
        $routes->post('reconciliation/auto-reconcile', 'Payroll\PayrollGenerationController::autoReconcileAjax', ['filter' => 'permission:payroll.manage']);

        // Sandbox Simulator & 16-Scenario QA Suite
        $routes->get('config', 'Payroll\PayrollSettingsController::getConfigAjax', ['filter' => 'permission:payroll.view']);
        $routes->post('simulator/calculate', 'Payroll\PayrollSimulationController::simulateSalaryBreakdownAjax', ['filter' => 'permission:payroll.manage|payroll.view']);
        $routes->post('test-runner/run', 'Payroll\PayrollSimulationController::runQA16TestSuiteAjax', ['filter' => 'permission:payroll.manage']);
    });

    // Provident Fund Reports & Statement Routes (Self-Service + Admin)
    $routes->group('pf/reports', ['filter' => 'auth'], function ($routes) {
        $routes->get('summary', 'Payroll\PfReportController::summary', ['filter' => 'permission:pf.view|payroll.view']);
        $routes->get('details', 'Payroll\PfReportController::details', ['filter' => 'permission:pf.view|payroll.view']);
        $routes->get('eligibility', 'Payroll\PfReportController::eligibility', ['filter' => 'permission:pf.view|payroll.view']);
        $routes->get('reconciliation', 'Payroll\PfReportController::reconciliation', ['filter' => 'permission:pf.view|payroll.view']);
        $routes->get('export-summary', 'Payroll\PfReportController::exportSummaryCsv', ['filter' => 'permission:pf.export|payroll.export|pf.view|payroll.view']);
        $routes->get('export-details', 'Payroll\PfReportController::exportDetailsCsv', ['filter' => 'permission:pf.export|payroll.export|pf.view|payroll.view']);
        $routes->get('export-eligibility', 'Payroll\PfReportController::exportEligibilityCsv', ['filter' => 'permission:pf.export|payroll.export|pf.view|payroll.view']);
        $routes->post('commit-drafts', 'Payroll\PfReportController::commitDrafts', ['filter' => 'permission:pf.manage|payroll.manage|payroll.approve|payroll.lock']);
    });

    // Unified Business Rules Engine API & UI (P04, P05)
    $routes->group('rules', ['filter' => 'auth'], function ($routes) {
        $routes->get('', 'Rules\RuleController::index', ['filter' => 'permission:rules.view']);
        $routes->get('/', 'Rules\RuleController::index', ['filter' => 'permission:rules.view']);
        $routes->get('overview', 'Rules\RuleController::overview', ['filter' => 'permission:rules.view']);
        $routes->get('domains', 'Rules\RuleController::domains', ['filter' => 'permission:rules.view']);
        $routes->get('masters', 'Rules\RuleController::masters', ['filter' => 'permission:rules.view']);
        $routes->get('component-options', 'Rules\RuleController::componentOptions', ['filter' => 'permission:rules.view']);
        $routes->get('list/(:segment)', 'Rules\RuleController::list/$1', ['filter' => 'permission:rules.view']);
        $routes->post('version/save', 'Rules\RuleController::saveVersion', ['filter' => 'permission:rules.manage']);
        $routes->post('version/publish/(:segment)', 'Rules\RuleController::publishVersion/$1', ['filter' => 'permission:rules.manage']);
        $routes->post('version/archive/(:segment)', 'Rules\RuleController::archiveVersion/$1', ['filter' => 'permission:rules.manage']);
        $routes->match(['get', 'post'], 'explain', 'Rules\RuleController::explain', ['filter' => 'permission:rules.manage|rules.view']);
    });

    // Assets, Training, Performance & Recruitment
    $routes->group('assets', ['filter' => 'auth'], function ($routes) {
        $routes->get('/', 'Assets\AssetController::index', ['filter' => 'permission:assets.view']);
        $routes->post('assign', 'Assets\AssetController::assign', ['filter' => 'permission:assets.assign']);
        $routes->post('return/(:segment)', 'Assets\AssetController::returnAsset/$1', ['filter' => 'permission:assets.assign']);
        $routes->post('write-off/(:segment)', 'Assets\AssetController::writeOff/$1', ['filter' => 'permission:assets.writeoff']);
        $routes->post('status/(:segment)', 'Assets\AssetController::status/$1', ['filter' => 'permission:assets.edit']);
        $routes->get('history/(:segment)', 'Assets\AssetController::history/$1', ['filter' => 'permission:assets.view']);
        $routes->post('store', 'Assets\AssetController::store', ['filter' => 'permission:assets.create']);
        $routes->post('update/(:segment)', 'Assets\AssetController::update/$1', ['filter' => 'permission:assets.edit']);
        $routes->post('delete/(:segment)', 'Assets\AssetController::delete/$1', ['filter' => 'permission:assets.delete']);
        $routes->get('export-csv', 'Assets\AssetController::exportCsv', ['filter' => 'permission:assets.export']);
        $routes->get('api/list', 'Assets\AssetController::apiList', ['filter' => 'permission:assets.view']);
        $routes->get('api/stats', 'Assets\AssetController::apiStats', ['filter' => 'permission:assets.view']);
        $routes->get('categories', 'Assets\AssetCategoryController::index', ['filter' => 'permission:assets.view']);
        $routes->get('categories/list', 'Assets\AssetCategoryController::apiList', ['filter' => 'permission:assets.view']);
        $routes->post('categories/store', 'Assets\AssetCategoryController::store', ['filter' => 'permission:assets.manage']);
        $routes->post('categories/update/(:segment)', 'Assets\AssetCategoryController::update/$1', ['filter' => 'permission:assets.manage']);
        $routes->post('categories/delete/(:segment)', 'Assets\AssetCategoryController::delete/$1', ['filter' => 'permission:assets.manage']);
    });

    // Alias / redirect legacy company-assets route group to assets
    $routes->addRedirect('company-assets', 'assets');
    $routes->addRedirect('company-assets/(:any)', 'assets/$1');

    $routes->group('training', ['filter' => 'auth'], function ($routes) {
        $routes->get('/', 'Training\TrainingController::index', ['filter' => 'permission:training.view']);
        $routes->post('create-session', 'Training\TrainingController::create', ['filter' => 'permission:training.create|training.manage']);
        $routes->post('enroll', 'Training\TrainingController::enroll', ['filter' => 'permission:training.enroll|training.create|training.manage']);
        $routes->post('unenroll/(:segment)', 'Training\TrainingController::unenroll/$1', ['filter' => 'permission:training.enroll|training.edit|training.manage']);
        $routes->post('complete-session/(:segment)', 'Training\TrainingController::completeSession/$1', ['filter' => 'permission:training.edit|training.manage']);
        $routes->post('mark-attendance', 'Training\TrainingController::markAttendance', ['filter' => 'permission:training.edit|training.manage']);
        $routes->get('certificate/(:segment)', 'Training\TrainingController::certificatePdf/$1', ['filter' => 'permission:training.view']);
        $routes->get('export-csv', 'Training\TrainingController::exportCsv', ['filter' => 'permission:training.export|training.view']);
        $routes->get('api/sessions', 'Training\TrainingController::apiSessions', ['filter' => 'permission:training.view']);
        $routes->get('api/enrollments', 'Training\TrainingController::apiEnrollments', ['filter' => 'permission:training.view']);
    });

    $routes->group('performance', ['filter' => 'auth'], function ($routes) {
        $routes->get('/', 'Performance\PerformanceController::index', ['filter' => 'permission:performance.view']);
        $routes->post('submit-360', 'Performance\PerformanceController::submit360', ['filter' => 'permission:performance.create|performance.edit']);
        $routes->post('submit-kpi', 'Performance\PerformanceController::submitKpi', ['filter' => 'permission:performance.create|performance.edit']);
        $routes->post('advance-stage/(:segment)', 'Performance\PerformanceController::advanceStage/$1', ['filter' => 'permission:performance.approve|performance.edit']);
        
        // Goals / OKRs
        $routes->post('goal/create', 'Performance\PerformanceController::createGoal', ['filter' => 'permission:performance.create|performance.edit']);
        $routes->post('goal/update-progress/(:segment)', 'Performance\PerformanceController::updateGoalProgress/$1', ['filter' => 'permission:performance.edit|performance.create']);
        $routes->post('goal/delete/(:segment)', 'Performance\PerformanceController::deleteGoal/$1', ['filter' => 'permission:performance.delete|performance.edit']);

        // Designation KPIs
        $routes->post('kpi/save', 'Performance\PerformanceController::saveKpiMetric', ['filter' => 'permission:performance.edit|performance.create']);
        $routes->post('kpi/delete/(:segment)', 'Performance\PerformanceController::deleteKpiMetric/$1', ['filter' => 'permission:performance.delete|performance.edit']);

        // Promotion & Increment Pipeline
        $routes->post('promotion/initiate', 'Performance\PerformanceController::initiatePromotion', ['filter' => 'permission:performance.create|performance.edit|performance.approve']);
        $routes->post('promotion/approve/(:segment)', 'Performance\PerformanceController::approvePromotion/$1', ['filter' => 'permission:performance.approve']);
        $routes->post('promotion/reject/(:segment)', 'Performance\PerformanceController::rejectPromotion/$1', ['filter' => 'permission:performance.approve']);

        // Export & Reporting
        $routes->get('export-csv', 'Performance\PerformanceController::exportCsv', ['filter' => 'permission:performance.export|performance.view']);

        // REST APIs
        $routes->get('api/reviews', 'Performance\PerformanceController::apiReviews', ['filter' => 'permission:performance.view']);
        $routes->get('api/goals', 'Performance\PerformanceController::apiGoals', ['filter' => 'permission:performance.view']);
        $routes->get('api/kpis', 'Performance\PerformanceController::apiKpis', ['filter' => 'permission:performance.view']);
        $routes->get('api/promotions', 'Performance\PerformanceController::apiPromotions', ['filter' => 'permission:performance.view']);
        $routes->get('api/stats', 'Performance\PerformanceController::apiStats', ['filter' => 'permission:performance.view']);
    });

    $routes->group('recruitment', ['filter' => ['auth', 'permission:recruitment.view']], function ($routes) {
        $routes->get('/', 'Recruitment\RecruitmentController::index');
        $routes->post('job-post', 'Recruitment\RecruitmentController::createJob', ['filter' => 'permission:recruitment.create|recruitment.manage']);
        $routes->post('job-update/(:segment)', 'Recruitment\RecruitmentController::updateJob/$1', ['filter' => 'permission:recruitment.edit|recruitment.manage']);
        $routes->post('job-delete/(:segment)', 'Recruitment\RecruitmentController::deleteJob/$1', ['filter' => 'permission:recruitment.delete|recruitment.manage']);
        $routes->post('candidate-add', 'Recruitment\RecruitmentController::addCandidate', ['filter' => 'permission:recruitment.create|recruitment.manage']);
        $routes->post('interview-schedule', 'Recruitment\RecruitmentController::scheduleInterview', ['filter' => 'permission:recruitment.edit|recruitment.manage']);
        $routes->post('candidate-stage', 'Recruitment\RecruitmentController::updateStage', ['filter' => 'permission:recruitment.edit|recruitment.manage']);
        $routes->post('convert/(:segment)', 'Recruitment\RecruitmentController::convertCandidate/$1', ['filter' => 'permission:recruitment.convert|recruitment.approve|recruitment.manage']);
        $routes->post('convert-candidate/(:segment)', 'Recruitment\RecruitmentController::convertCandidate/$1', ['filter' => 'permission:recruitment.convert|recruitment.approve|recruitment.manage']);
        $routes->get('export-csv', 'Recruitment\RecruitmentController::exportCsv', ['filter' => 'permission:recruitment.export|recruitment.view']);
        $routes->get('api/jobs', 'Recruitment\RecruitmentController::apiJobs');
        $routes->get('api/candidates', 'Recruitment\RecruitmentController::apiCandidates');
    });

    // Notice Board & Notifications
    $routes->group('notices', ['filter' => ['auth', 'permission:notices.view']], function ($routes) {
        $routes->get('/', 'Notices\NoticeController::index');
        $routes->post('create', 'Notices\NoticeController::create', ['filter' => 'permission:notices.create|notices.manage']);
    });

    $routes->group('notifications', ['filter' => 'permission:notifications.view'], function ($routes) {
        $routes->get('/', 'Notifications\NotificationController::index');
        $routes->get('recent', 'Notifications\NotificationController::recent');
        $routes->get('unread-count', 'Notifications\NotificationController::unreadCount');
        $routes->get('data', 'Notifications\NotificationController::data');
        $routes->post('mark-read/(:segment)', 'Notifications\NotificationController::markRead/$1', ['filter' => 'permission:notifications.manage|notifications.view']);
        $routes->post('mark-all-read', 'Notifications\NotificationController::markAllRead', ['filter' => 'permission:notifications.manage|notifications.view']);
        $routes->post('delete/(:segment)', 'Notifications\NotificationController::delete/$1', ['filter' => 'permission:notifications.manage|notifications.view']);
        $routes->post('clear-all', 'Notifications\NotificationController::clearAll', ['filter' => 'permission:notifications.manage|notifications.view']);
        $routes->post('broadcast', 'Notifications\NotificationController::broadcast', ['filter' => 'permission:notifications.manage']);
        $routes->post('settings', 'Notifications\NotificationController::saveSettings', ['filter' => 'permission:notifications.manage']);
        $routes->post('flush-queue', 'Notifications\NotificationController::flushQueue', ['filter' => 'platformAdmin']);
        $routes->post('trigger-workflow', 'Notifications\NotificationController::triggerWorkflow', ['filter' => 'permission:notifications.manage']);
        $routes->get('department-leaves', 'Notifications\NotificationController::departmentLeaves');
        $routes->get('branch-birthdays', 'Notifications\NotificationController::branchBirthdays');
        $routes->get('branch-anniversaries', 'Notifications\NotificationController::branchAnniversaries');
        $routes->post('send-wish', 'Notifications\NotificationController::sendWish', ['filter' => 'permission:notifications.manage|notifications.view']);
        $routes->get('db-table/(notifications|notification_settings|notification_templates|email_queue|email_logs)', 'Notifications\NotificationController::getDbTableData/$1', ['filter' => 'platformAdmin']);
    });

    // Custom Reports Hub
    $routes->group('reports', ['filter' => ['auth', 'permission:reports.view']], function ($routes) {
        $routes->get('/', 'Reports\ReportController::index');
        $routes->get('upload', 'Reports\ReportController::uploadHub');
        $routes->post('upload', 'Reports\ReportController::handleUpload', ['filter' => 'permission:reports.create|reports.upload|reports.manage']);
        $routes->post('upload/delete/(:segment)', 'Reports\ReportController::deleteDocument/$1', ['filter' => 'permission:reports.delete|reports.manage']);
        $routes->get('upload/download/(:segment)', 'Reports\ReportController::downloadDocument/$1');
        $routes->post('upload/apply-branding/(:segment)', 'Reports\ReportController::applyBranding/$1', ['filter' => 'permission:reports.edit|reports.manage']);
        $routes->get('upload/sample/(:segment)', 'Reports\ReportController::downloadSampleTemplate/$1');
        $routes->post('upload/ingest-biometric/(:segment)', 'Reports\ReportController::ingestBiometricPunches/$1', ['filter' => 'permission:attendance.create|attendance.sync|reports.manage']);
        $routes->get('upload/preview-json/(:segment)', 'Reports\ReportController::previewJson/$1');
        $routes->post('branding/save', 'Reports\ReportController::saveBranding', ['filter' => 'permission:reports.edit|reports.manage|settings.edit']);
        $routes->match(['get', 'post'], 'export-csv', 'Reports\ReportController::exportCsv', ['filter' => 'permission:reports.export']);
        $routes->get('export-pdf', 'Reports\ReportController::exportPdf', ['filter' => 'permission:reports.export|reports.view']);
        $routes->get('print-view', 'Reports\ReportController::printView');
        $routes->get('view/(:segment)', 'Reports\ReportController::index/$1');
    });

    // Medical Insurance Module
    $routes->group('insurance', ['filter' => ['auth', 'permission:medical_insurance.view|insurance.view']], function ($routes) {
        $routes->get('/', 'MedicalInsurance\MedicalInsuranceController::index');
        $routes->get('dashboard', 'MedicalInsurance\MedicalInsuranceController::dashboard');

        // Providers
        $routes->get('providers', 'MedicalInsurance\MedicalInsuranceController::providers');
        $routes->get('providers/(:segment)', 'MedicalInsurance\MedicalInsuranceController::getProvider/$1');
        $routes->post('providers/save', 'MedicalInsurance\MedicalInsuranceController::saveProvider', ['filter' => 'permission:medical_insurance.create|medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->post('providers/delete/(:segment)', 'MedicalInsurance\MedicalInsuranceController::deleteProvider/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.manage|insurance.manage']);

        // Plans
        $routes->get('plans', 'MedicalInsurance\MedicalInsuranceController::plans');
        $routes->get('plans/(:segment)', 'MedicalInsurance\MedicalInsuranceController::getPlan/$1');
        $routes->post('plans/save', 'MedicalInsurance\MedicalInsuranceController::savePlan', ['filter' => 'permission:medical_insurance.create|medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->post('plans/delete/(:segment)', 'MedicalInsurance\MedicalInsuranceController::deletePlan/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.manage|insurance.manage']);

        // Enrollments & Coverage
        $routes->get('enrollments', 'MedicalInsurance\MedicalInsuranceController::enrollments');
        $routes->post('enroll', 'MedicalInsurance\MedicalInsuranceController::enrollIndividual', ['filter' => 'permission:medical_insurance.create|medical_insurance.manage|insurance.manage']);
        $routes->post('enroll/bulk', 'MedicalInsurance\MedicalInsuranceController::enrollBulk', ['filter' => 'permission:medical_insurance.create|medical_insurance.manage|insurance.manage']);
        $routes->post('enroll/all-active', 'MedicalInsurance\MedicalInsuranceController::enrollAllActive', ['filter' => 'permission:medical_insurance.create|medical_insurance.manage|insurance.manage']);
        $routes->post('enrollments/update/(:segment)', 'MedicalInsurance\MedicalInsuranceController::updateEnrollment/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->post('enrollments/status/(:segment)', 'MedicalInsurance\MedicalInsuranceController::updateEnrollmentStatus/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->post('enrollments/delete/(:segment)', 'MedicalInsurance\MedicalInsuranceController::deleteEnrollment/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.manage|insurance.manage']);
        $routes->get('coverage/(:segment)', 'MedicalInsurance\MedicalInsuranceController::coverage/$1');

        // Dependents
        $routes->get('dependents', 'MedicalInsurance\MedicalInsuranceController::dependents');
        $routes->post('dependents/save', 'MedicalInsurance\MedicalInsuranceController::saveDependent', ['filter' => 'permission:medical_insurance.create|medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->post('dependents/delete/(:segment)', 'MedicalInsurance\MedicalInsuranceController::deleteDependent/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.manage|insurance.manage']);

        // Claims
        $routes->get('claims', 'MedicalInsurance\MedicalInsuranceController::claims');
        $routes->get('claims/(:segment)', 'MedicalInsurance\MedicalInsuranceController::getClaim/$1');
        $routes->post('claims/create', 'MedicalInsurance\MedicalInsuranceController::createClaim', ['filter' => 'permission:medical_insurance.create|medical_insurance.manage|insurance.manage']);
        $routes->post('claims/update/(:segment)', 'MedicalInsurance\MedicalInsuranceController::updateClaim/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->post('claims/transition/(:segment)', 'MedicalInsurance\MedicalInsuranceController::transitionClaim/$1', ['filter' => 'permission:medical_insurance.approve|medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->post('claims/delete/(:segment)', 'MedicalInsurance\MedicalInsuranceController::deleteClaim/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.manage|insurance.manage']);

        // Documents
        $routes->post('claims/(:segment)/documents', 'MedicalInsurance\MedicalInsuranceController::uploadDocument/$1', ['filter' => 'permission:medical_insurance.create|medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->get('documents/(:segment)/download', 'MedicalInsurance\MedicalInsuranceController::downloadDocument/$1');
        $routes->post('documents/(:segment)/delete', 'MedicalInsurance\MedicalInsuranceController::deleteDocument/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.edit|medical_insurance.manage|insurance.manage']);

        // Reports
        $routes->get('reports/employees', 'MedicalInsurance\MedicalInsuranceController::reportEmployees');
        $routes->get('reports/expiring', 'MedicalInsurance\MedicalInsuranceController::reportExpiring');
        $routes->get('reports/claims', 'MedicalInsurance\MedicalInsuranceController::reportClaims');
        $routes->get('reports/contributions', 'MedicalInsurance\MedicalInsuranceController::reportContributions');
    });

    // Medical Insurance REST API Endpoints (Section 20)
    $routes->group('api/insurance', ['filter' => ['auth', 'permission:medical_insurance.view|insurance.view']], function ($routes) {
        $routes->get('dashboard', 'MedicalInsurance\MedicalInsuranceController::dashboard');

        // Providers
        $routes->get('providers', 'MedicalInsurance\ProviderController::index');
        $routes->post('providers', 'MedicalInsurance\ProviderController::create', ['filter' => 'permission:medical_insurance.create|medical_insurance.manage|insurance.manage']);
        $routes->get('providers/(:segment)', 'MedicalInsurance\ProviderController::show/$1');
        $routes->match(['put', 'post'], 'providers/(:segment)/update', 'MedicalInsurance\ProviderController::update/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->put('providers/(:segment)', 'MedicalInsurance\ProviderController::update/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->delete('providers/(:segment)', 'MedicalInsurance\ProviderController::delete/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.manage|insurance.manage']);
        $routes->post('providers/(:segment)/delete', 'MedicalInsurance\ProviderController::delete/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.manage|insurance.manage']);

        // Plans
        $routes->get('plans', 'MedicalInsurance\PlanController::index');
        $routes->post('plans', 'MedicalInsurance\PlanController::create', ['filter' => 'permission:medical_insurance.create|medical_insurance.manage|insurance.manage']);
        $routes->get('plans/(:segment)', 'MedicalInsurance\PlanController::show/$1');
        $routes->match(['put', 'post'], 'plans/(:segment)/update', 'MedicalInsurance\PlanController::update/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->put('plans/(:segment)', 'MedicalInsurance\PlanController::update/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->delete('plans/(:segment)', 'MedicalInsurance\PlanController::delete/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.manage|insurance.manage']);
        $routes->post('plans/(:segment)/delete', 'MedicalInsurance\PlanController::delete/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.manage|insurance.manage']);

        // Enrollments & Coverage
        $routes->get('enrollments', 'MedicalInsurance\EnrollmentController::index');
        $routes->post('enrollments', 'MedicalInsurance\EnrollmentController::create', ['filter' => 'permission:medical_insurance.create|medical_insurance.manage|insurance.manage']);
        $routes->get('enrollments/(:segment)', 'MedicalInsurance\EnrollmentController::show/$1');
        $routes->match(['put', 'post'], 'enrollments/(:segment)/update', 'MedicalInsurance\EnrollmentController::update/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->put('enrollments/(:segment)', 'MedicalInsurance\EnrollmentController::update/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->delete('enrollments/(:segment)', 'MedicalInsurance\EnrollmentController::delete/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.manage|insurance.manage']);
        $routes->post('enrollments/(:segment)/delete', 'MedicalInsurance\EnrollmentController::delete/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.manage|insurance.manage']);
        $routes->post('enrollments/bulk', 'MedicalInsurance\EnrollmentController::bulk', ['filter' => 'permission:medical_insurance.create|medical_insurance.manage|insurance.manage']);
        $routes->post('enrollments/all-active', 'MedicalInsurance\EnrollmentController::allActive', ['filter' => 'permission:medical_insurance.create|medical_insurance.manage|insurance.manage']);
        $routes->match(['put', 'post'], 'enrollments/(:segment)/status', 'MedicalInsurance\EnrollmentController::updateStatus/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->get('coverage/(:segment)', 'MedicalInsurance\EnrollmentController::employeeCoverage/$1');

        // Dependents
        $routes->get('dependents', 'MedicalInsurance\DependentController::index');
        $routes->post('dependents', 'MedicalInsurance\DependentController::create', ['filter' => 'permission:medical_insurance.create|medical_insurance.manage|insurance.manage']);
        $routes->get('dependents/(:segment)', 'MedicalInsurance\DependentController::show/$1');
        $routes->match(['put', 'post'], 'dependents/(:segment)/update', 'MedicalInsurance\DependentController::update/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->put('dependents/(:segment)', 'MedicalInsurance\DependentController::update/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->delete('dependents/(:segment)', 'MedicalInsurance\DependentController::delete/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.manage|insurance.manage']);
        $routes->post('dependents/(:segment)/delete', 'MedicalInsurance\DependentController::delete/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.manage|insurance.manage']);

        // Claims
        $routes->get('claims', 'MedicalInsurance\ClaimController::index');
        $routes->post('claims', 'MedicalInsurance\ClaimController::create', ['filter' => 'permission:medical_insurance.create|medical_insurance.manage|insurance.manage']);
        $routes->get('claims/(:segment)', 'MedicalInsurance\ClaimController::show/$1');
        $routes->match(['put', 'post'], 'claims/(:segment)/update', 'MedicalInsurance\ClaimController::update/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->put('claims/(:segment)', 'MedicalInsurance\ClaimController::update/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->delete('claims/(:segment)', 'MedicalInsurance\ClaimController::delete/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.manage|insurance.manage']);
        $routes->post('claims/(:segment)/delete', 'MedicalInsurance\ClaimController::delete/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.manage|insurance.manage']);
        $routes->post('claims/(:segment)/review', 'MedicalInsurance\ClaimController::review/$1', ['filter' => 'permission:medical_insurance.approve|medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->post('claims/(:segment)/approve', 'MedicalInsurance\ClaimController::approve/$1', ['filter' => 'permission:medical_insurance.approve|medical_insurance.manage|insurance.manage']);
        $routes->post('claims/(:segment)/reject', 'MedicalInsurance\ClaimController::reject/$1', ['filter' => 'permission:medical_insurance.approve|medical_insurance.manage|insurance.manage']);
        $routes->post('claims/(:segment)/pay', 'MedicalInsurance\ClaimController::pay/$1', ['filter' => 'permission:medical_insurance.approve|medical_insurance.manage|insurance.manage']);

        // Documents
        $routes->post('claims/(:segment)/documents', 'MedicalInsurance\ClaimController::uploadDocument/$1', ['filter' => 'permission:medical_insurance.create|medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->get('documents/(:segment)/download', 'MedicalInsurance\ClaimController::downloadDocument/$1');
        $routes->delete('documents/(:segment)', 'MedicalInsurance\ClaimController::deleteDocument/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->post('documents/(:segment)/delete', 'MedicalInsurance\ClaimController::deleteDocument/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.edit|medical_insurance.manage|insurance.manage']);

        // Reports
        $routes->get('reports/employees', 'MedicalInsurance\MedicalInsuranceController::reportEmployees');
        $routes->get('reports/expiring', 'MedicalInsurance\MedicalInsuranceController::reportExpiring');
        $routes->get('reports/claims', 'MedicalInsurance\MedicalInsuranceController::reportClaims');
        $routes->get('reports/contributions', 'MedicalInsurance\MedicalInsuranceController::reportContributions');
    });

    // Medical Insurance Aliases (/medical-insurance and /api/medical-insurance)
    $routes->group('medical-insurance', ['filter' => ['auth', 'permission:medical_insurance.view|insurance.view']], function ($routes) {
        $routes->get('/', 'MedicalInsurance\MedicalInsuranceController::index');
        $routes->get('dashboard', 'MedicalInsurance\MedicalInsuranceController::dashboard');
        $routes->get('providers', 'MedicalInsurance\MedicalInsuranceController::providers');
        $routes->get('plans', 'MedicalInsurance\MedicalInsuranceController::plans');
        $routes->get('enrollments', 'MedicalInsurance\MedicalInsuranceController::enrollments');
        $routes->get('dependents', 'MedicalInsurance\MedicalInsuranceController::dependents');
        $routes->get('claims', 'MedicalInsurance\MedicalInsuranceController::claims');
    });
    $routes->group('api/medical-insurance', ['filter' => ['auth', 'permission:medical_insurance.view|insurance.view']], function ($routes) {
        $routes->get('dashboard', 'MedicalInsurance\MedicalInsuranceController::dashboard');
        $routes->get('providers', 'MedicalInsurance\ProviderController::index');
        $routes->post('providers', 'MedicalInsurance\ProviderController::create', ['filter' => 'permission:medical_insurance.create|medical_insurance.manage|insurance.manage']);
        $routes->get('providers/(:segment)', 'MedicalInsurance\ProviderController::show/$1');
        $routes->match(['put', 'post'], 'providers/(:segment)/update', 'MedicalInsurance\ProviderController::update/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->put('providers/(:segment)', 'MedicalInsurance\ProviderController::update/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->delete('providers/(:segment)', 'MedicalInsurance\ProviderController::delete/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.manage|insurance.manage']);
        $routes->get('plans', 'MedicalInsurance\PlanController::index');
        $routes->post('plans', 'MedicalInsurance\PlanController::create', ['filter' => 'permission:medical_insurance.create|medical_insurance.manage|insurance.manage']);
        $routes->get('plans/(:segment)', 'MedicalInsurance\PlanController::show/$1');
        $routes->match(['put', 'post'], 'plans/(:segment)/update', 'MedicalInsurance\PlanController::update/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->put('plans/(:segment)', 'MedicalInsurance\PlanController::update/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->delete('plans/(:segment)', 'MedicalInsurance\PlanController::delete/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.manage|insurance.manage']);
        $routes->get('enrollments', 'MedicalInsurance\EnrollmentController::index');
        $routes->post('enrollments', 'MedicalInsurance\EnrollmentController::create', ['filter' => 'permission:medical_insurance.create|medical_insurance.manage|insurance.manage']);
        $routes->get('enrollments/(:segment)', 'MedicalInsurance\EnrollmentController::show/$1');
        $routes->match(['put', 'post'], 'enrollments/(:segment)/update', 'MedicalInsurance\EnrollmentController::update/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->put('enrollments/(:segment)', 'MedicalInsurance\EnrollmentController::update/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->delete('enrollments/(:segment)', 'MedicalInsurance\EnrollmentController::delete/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.manage|insurance.manage']);
        $routes->post('enrollments/bulk', 'MedicalInsurance\EnrollmentController::bulk', ['filter' => 'permission:medical_insurance.create|medical_insurance.manage|insurance.manage']);
        $routes->post('enrollments/all-active', 'MedicalInsurance\EnrollmentController::allActive', ['filter' => 'permission:medical_insurance.create|medical_insurance.manage|insurance.manage']);
        $routes->match(['put', 'post'], 'enrollments/(:segment)/status', 'MedicalInsurance\EnrollmentController::updateStatus/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->get('coverage/(:segment)', 'MedicalInsurance\EnrollmentController::employeeCoverage/$1');
        $routes->get('dependents', 'MedicalInsurance\DependentController::index');
        $routes->post('dependents', 'MedicalInsurance\DependentController::create', ['filter' => 'permission:medical_insurance.create|medical_insurance.manage|insurance.manage']);
        $routes->get('dependents/(:segment)', 'MedicalInsurance\DependentController::show/$1');
        $routes->match(['put', 'post'], 'dependents/(:segment)/update', 'MedicalInsurance\DependentController::update/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->put('dependents/(:segment)', 'MedicalInsurance\DependentController::update/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->delete('dependents/(:segment)', 'MedicalInsurance\DependentController::delete/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.manage|insurance.manage']);
        $routes->get('claims', 'MedicalInsurance\ClaimController::index');
        $routes->post('claims', 'MedicalInsurance\ClaimController::create', ['filter' => 'permission:medical_insurance.create|medical_insurance.manage|insurance.manage']);
        $routes->get('claims/(:segment)', 'MedicalInsurance\ClaimController::show/$1');
        $routes->match(['put', 'post'], 'claims/(:segment)/update', 'MedicalInsurance\ClaimController::update/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->put('claims/(:segment)', 'MedicalInsurance\ClaimController::update/$1', ['filter' => 'permission:medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->delete('claims/(:segment)', 'MedicalInsurance\ClaimController::delete/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.manage|insurance.manage']);
        $routes->post('claims/(:segment)/review', 'MedicalInsurance\ClaimController::review/$1', ['filter' => 'permission:medical_insurance.approve|medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->post('claims/(:segment)/approve', 'MedicalInsurance\ClaimController::approve/$1', ['filter' => 'permission:medical_insurance.approve|medical_insurance.manage|insurance.manage']);
        $routes->post('claims/(:segment)/reject', 'MedicalInsurance\ClaimController::reject/$1', ['filter' => 'permission:medical_insurance.approve|medical_insurance.manage|insurance.manage']);
        $routes->post('claims/(:segment)/pay', 'MedicalInsurance\ClaimController::pay/$1', ['filter' => 'permission:medical_insurance.approve|medical_insurance.manage|insurance.manage']);
        $routes->post('claims/(:segment)/documents', 'MedicalInsurance\ClaimController::uploadDocument/$1', ['filter' => 'permission:medical_insurance.create|medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->get('documents/(:segment)/download', 'MedicalInsurance\ClaimController::downloadDocument/$1');
        $routes->delete('documents/(:segment)', 'MedicalInsurance\ClaimController::deleteDocument/$1', ['filter' => 'permission:medical_insurance.delete|medical_insurance.edit|medical_insurance.manage|insurance.manage']);
        $routes->get('reports/employees', 'MedicalInsurance\MedicalInsuranceController::reportEmployees');
        $routes->get('reports/expiring', 'MedicalInsurance\MedicalInsuranceController::reportExpiring');
        $routes->get('reports/claims', 'MedicalInsurance\MedicalInsuranceController::reportClaims');
        $routes->get('reports/contributions', 'MedicalInsurance\MedicalInsuranceController::reportContributions');
    });

    // Daily Company Expense Management Module (REST APIs)
    $routes->group('api/company-expenses', ['filter' => ['auth', 'permission:company_expense.view']], function ($routes) {
        // Dashboard & Analytics
        $routes->get('dashboard', 'CompanyExpense\ExpenseReportController::dashboard');

        // Reports
        $routes->get('reports/daily', 'CompanyExpense\ExpenseReportController::daily');
        $routes->get('reports/category', 'CompanyExpense\ExpenseReportController::category');
        $routes->get('reports/monthly', 'CompanyExpense\ExpenseReportController::monthly');
        $routes->get('reports/payment', 'CompanyExpense\ExpenseReportController::payment');

        // Categories
        $routes->get('categories', 'CompanyExpense\ExpenseCategoryController::index');
        $routes->post('categories', 'CompanyExpense\ExpenseCategoryController::create', ['filter' => 'permission:company_expense.manage|company_expense.create']);
        $routes->get('categories/(:segment)', 'CompanyExpense\ExpenseCategoryController::show/$1');
        $routes->match(['put', 'post'], 'categories/(:segment)/update', 'CompanyExpense\ExpenseCategoryController::update/$1', ['filter' => 'permission:company_expense.manage|company_expense.edit']);
        $routes->put('categories/(:segment)', 'CompanyExpense\ExpenseCategoryController::update/$1', ['filter' => 'permission:company_expense.manage|company_expense.edit']);
        $routes->delete('categories/(:segment)', 'CompanyExpense\ExpenseCategoryController::delete/$1', ['filter' => 'permission:company_expense.manage|company_expense.delete']);
        $routes->post('categories/(:segment)/delete', 'CompanyExpense\ExpenseCategoryController::delete/$1', ['filter' => 'permission:company_expense.manage|company_expense.delete']);

        // Expenses CRUD
        $routes->get('/', 'CompanyExpense\CompanyExpenseController::index');
        $routes->post('/', 'CompanyExpense\CompanyExpenseController::create', ['filter' => 'permission:company_expense.create|company_expense.manage']);
        $routes->get('(:segment)', 'CompanyExpense\CompanyExpenseController::show/$1');
        $routes->match(['put', 'post'], '(:segment)/update', 'CompanyExpense\CompanyExpenseController::update/$1', ['filter' => 'permission:company_expense.edit|company_expense.manage']);
        $routes->put('(:segment)', 'CompanyExpense\CompanyExpenseController::update/$1', ['filter' => 'permission:company_expense.edit|company_expense.manage']);
        $routes->delete('(:segment)', 'CompanyExpense\CompanyExpenseController::delete/$1', ['filter' => 'permission:company_expense.delete|company_expense.manage']);
        $routes->post('(:segment)/delete', 'CompanyExpense\CompanyExpenseController::delete/$1', ['filter' => 'permission:company_expense.delete|company_expense.manage']);

        // Workflow Transitions
        $routes->post('(:segment)/submit', 'CompanyExpense\ExpenseWorkflowController::submit/$1', ['filter' => 'permission:company_expense.create|company_expense.edit|company_expense.manage']);
        $routes->post('(:segment)/approve', 'CompanyExpense\ExpenseWorkflowController::approve/$1', ['filter' => 'permission:company_expense.approve|company_expense.manage']);
        $routes->post('(:segment)/reject', 'CompanyExpense\ExpenseWorkflowController::reject/$1', ['filter' => 'permission:company_expense.approve|company_expense.manage']);
        $routes->post('(:segment)/cancel', 'CompanyExpense\ExpenseWorkflowController::cancel/$1', ['filter' => 'permission:company_expense.delete|company_expense.edit|company_expense.approve|company_expense.manage']);

        // Payments
        $routes->get('(:segment)/payment', 'CompanyExpense\ExpensePaymentController::show/$1');
        $routes->post('(:segment)/payment', 'CompanyExpense\ExpensePaymentController::pay/$1', ['filter' => 'permission:company_expense.approve|company_expense.manage']);

        // Documents
        $routes->get('(:segment)/documents', 'CompanyExpense\ExpenseDocumentController::index/$1');
        $routes->post('(:segment)/documents', 'CompanyExpense\ExpenseDocumentController::upload/$1', ['filter' => 'permission:company_expense.create|company_expense.edit|company_expense.manage']);
        $routes->get('documents/(:segment)/download', 'CompanyExpense\ExpenseDocumentController::download/$1');
        $routes->delete('(:segment)/documents/(:segment)', 'CompanyExpense\ExpenseDocumentController::delete/$1/$2', ['filter' => 'permission:company_expense.delete|company_expense.edit|company_expense.manage']);
        $routes->post('(:segment)/documents/(:segment)/delete', 'CompanyExpense\ExpenseDocumentController::delete/$1/$2', ['filter' => 'permission:company_expense.delete|company_expense.edit|company_expense.manage']);
    });

    // Also support alias routes under api/expenses
    $routes->group('api/expenses', ['filter' => ['auth', 'permission:company_expense.view']], function ($routes) {
        $routes->get('dashboard', 'CompanyExpense\ExpenseReportController::dashboard');
        $routes->get('reports/daily', 'CompanyExpense\ExpenseReportController::daily');
        $routes->get('reports/category', 'CompanyExpense\ExpenseReportController::category');
        $routes->get('reports/monthly', 'CompanyExpense\ExpenseReportController::monthly');
        $routes->get('reports/payment', 'CompanyExpense\ExpenseReportController::payment');
        $routes->get('categories', 'CompanyExpense\ExpenseCategoryController::index');
        $routes->post('categories', 'CompanyExpense\ExpenseCategoryController::create', ['filter' => 'permission:company_expense.manage|company_expense.create']);
        $routes->get('categories/(:segment)', 'CompanyExpense\ExpenseCategoryController::show/$1');
        $routes->match(['put', 'post'], 'categories/(:segment)/update', 'CompanyExpense\ExpenseCategoryController::update/$1', ['filter' => 'permission:company_expense.manage|company_expense.edit']);
        $routes->put('categories/(:segment)', 'CompanyExpense\ExpenseCategoryController::update/$1', ['filter' => 'permission:company_expense.manage|company_expense.edit']);
        $routes->delete('categories/(:segment)', 'CompanyExpense\ExpenseCategoryController::delete/$1', ['filter' => 'permission:company_expense.manage|company_expense.delete']);
        $routes->get('/', 'CompanyExpense\CompanyExpenseController::index');
        $routes->post('/', 'CompanyExpense\CompanyExpenseController::create', ['filter' => 'permission:company_expense.create|company_expense.manage']);
        $routes->get('(:segment)', 'CompanyExpense\CompanyExpenseController::show/$1');
        $routes->match(['put', 'post'], '(:segment)/update', 'CompanyExpense\CompanyExpenseController::update/$1', ['filter' => 'permission:company_expense.edit|company_expense.manage']);
        $routes->put('(:segment)', 'CompanyExpense\CompanyExpenseController::update/$1', ['filter' => 'permission:company_expense.edit|company_expense.manage']);
        $routes->delete('(:segment)', 'CompanyExpense\CompanyExpenseController::delete/$1', ['filter' => 'permission:company_expense.delete|company_expense.manage']);
        $routes->post('(:segment)/submit', 'CompanyExpense\ExpenseWorkflowController::submit/$1', ['filter' => 'permission:company_expense.create|company_expense.edit|company_expense.manage']);
        $routes->post('(:segment)/approve', 'CompanyExpense\ExpenseWorkflowController::approve/$1', ['filter' => 'permission:company_expense.approve|company_expense.manage']);
        $routes->post('(:segment)/reject', 'CompanyExpense\ExpenseWorkflowController::reject/$1', ['filter' => 'permission:company_expense.approve|company_expense.manage']);
        $routes->post('(:segment)/cancel', 'CompanyExpense\ExpenseWorkflowController::cancel/$1', ['filter' => 'permission:company_expense.delete|company_expense.edit|company_expense.approve|company_expense.manage']);
        $routes->get('(:segment)/payment', 'CompanyExpense\ExpensePaymentController::show/$1');
        $routes->post('(:segment)/payment', 'CompanyExpense\ExpensePaymentController::pay/$1', ['filter' => 'permission:company_expense.approve|company_expense.manage']);
        $routes->get('(:segment)/documents', 'CompanyExpense\ExpenseDocumentController::index/$1');
        $routes->post('(:segment)/documents', 'CompanyExpense\ExpenseDocumentController::upload/$1', ['filter' => 'permission:company_expense.create|company_expense.edit|company_expense.manage']);
        $routes->get('documents/(:segment)/download', 'CompanyExpense\ExpenseDocumentController::download/$1');
        $routes->delete('(:segment)/documents/(:segment)', 'CompanyExpense\ExpenseDocumentController::delete/$1/$2', ['filter' => 'permission:company_expense.delete|company_expense.edit|company_expense.manage']);
    });

    // Company Profile & Entity Management
    $routes->group('company', ['filter' => ['auth', 'permission:master.view|settings.view']], function ($routes) {
        $routes->get('create', 'Master\CompanyController::create', ['filter' => 'platformAdmin']);
        $routes->post('create', 'Master\CompanyController::store', ['filter' => 'platformAdmin']);
        $routes->get('branding', 'Master\CompanyController::branding');
        $routes->post('branding', 'Master\CompanyController::saveBranding', ['filter' => 'permission:settings.edit|settings.manage|master.edit|master.manage']);
        $routes->post('select/(:segment)', 'Master\CompanyController::selectCompany/$1', ['filter' => 'platformAdmin']);
        $routes->post('switch/(:segment)', 'Master\CompanyController::selectCompany/$1', ['filter' => 'platformAdmin']);
        $routes->get('profile', 'Master\CompanyController::profile');
        $routes->get('profile/(:segment)', 'Master\CompanyController::profile/$1');
        $routes->match(['post', 'put', 'patch'], 'profile', 'Master\CompanyController::saveProfile', ['filter' => 'permission:settings.edit|settings.manage|master.edit|master.manage']);
        $routes->match(['post', 'put', 'patch'], 'profile/(:segment)', 'Master\CompanyController::saveProfile/$1', ['filter' => 'permission:settings.edit|settings.manage|master.edit|master.manage']);
        $routes->match(['post', 'put', 'patch'], 'profile/save', 'Master\CompanyController::saveProfile', ['filter' => 'permission:settings.edit|settings.manage|master.edit|master.manage']);
        $routes->match(['post', 'put', 'patch'], 'profile/save/(:segment)', 'Master\CompanyController::saveProfile/$1', ['filter' => 'permission:settings.edit|settings.manage|master.edit|master.manage']);
        $routes->match(['post', 'put', 'patch'], 'profile/admin', 'Master\CompanyController::saveAdmin', ['filter' => 'platformAdmin']);
        $routes->match(['post', 'put', 'patch'], 'profile/admin/(:segment)', 'Master\CompanyController::saveAdmin/$1', ['filter' => 'platformAdmin']);
        $routes->match(['post', 'put', 'patch'], 'profile/(:segment)/admin', 'Master\CompanyController::saveAdmin/$1', ['filter' => 'platformAdmin']);
        $routes->match(['post', 'put', 'patch'], 'save-admin', 'Master\CompanyController::saveAdmin', ['filter' => 'platformAdmin']);
        $routes->match(['post', 'put', 'patch'], 'save-admin/(:segment)', 'Master\CompanyController::saveAdmin/$1', ['filter' => 'platformAdmin']);
        $routes->match(['post', 'put', 'patch'], 'update-admin/(:segment)', 'Master\CompanyController::saveAdmin/$1', ['filter' => 'platformAdmin']);
        $routes->match(['post', 'put', 'patch'], 'save-profile', 'Master\CompanyController::saveProfile', ['filter' => 'permission:settings.edit|settings.manage|master.edit|master.manage']);
        $routes->match(['post', 'put', 'patch'], 'save-profile/(:segment)', 'Master\CompanyController::saveProfile/$1', ['filter' => 'permission:settings.edit|settings.manage|master.edit|master.manage']);
        $routes->match(['post', 'put', 'patch'], 'update/(:segment)', 'Master\CompanyController::update/$1', ['filter' => 'permission:settings.edit|settings.manage|master.edit|master.manage']);
        $routes->match(['post', 'put'], 'toggle-break-policy/(:segment)', 'Master\CompanyController::toggleBreakPolicy/$1', ['filter' => 'permission:settings.edit|settings.manage|master.edit|master.manage|attendance.manage']);
        $routes->match(['post', 'put'], 'toggle-break-policy', 'Master\CompanyController::toggleBreakPolicy', ['filter' => 'permission:settings.edit|settings.manage|master.edit|master.manage|attendance.manage']);
    });

    // Master Data Console (HRMS CRUD)
    $routes->group('master', ['filter' => ['auth', 'permission:master.view|settings.view']], function ($routes) {
        $routes->get('/', 'Master\MasterController::index');
        $routes->get('console', 'Master\MasterController::index');
        $routes->get('email', 'Master\MasterController::index');
        $routes->get('smtp', 'Master\MasterController::index');
        $routes->get('export-config', 'Master\MasterController::exportConfig', ['filter' => 'permission:master.export|settings.view|master.view']);
        $routes->post('security-policy', 'Master\MasterController::saveSecurityPolicy', ['filter' => 'permission:security.manage|settings.manage|master.manage']);
        $routes->post('toggle-status/(:segment)/(:segment)', 'Master\MasterController::toggleStatus/$1/$2', ['filter' => 'permission:master.edit|master.manage|settings.edit|settings.manage']);

        // Master Console Outbound SMTP Gateway Management (Company Admin + Software App Admin)
        $routes->post('smtp/save', 'System\SmtpController::save', ['filter' => 'permission:email.smtp.edit|settings.edit|settings.manage|master.manage']);
        $routes->post('smtp/test', 'System\SmtpController::testConnection', ['filter' => 'permission:email.smtp.edit|settings.edit|settings.manage|master.manage']);
        $routes->post('smtp/reset', 'System\SmtpController::resetCompanyConfig', ['filter' => 'permission:email.smtp.edit|settings.edit|settings.manage|master.manage']);
        $routes->post('smtp/reset/(:segment)', 'System\SmtpController::resetCompanyConfig/$1', ['filter' => 'permission:email.smtp.edit|settings.edit|settings.manage|master.manage']);

        // Master Console Transactional Email Templates Management (Company Admin + Software App Admin)
        $routes->post('templates/create', 'System\EmailTemplateController::store', ['filter' => 'permission:email.template.edit|settings.edit|settings.manage|master.manage']);
        $routes->post('templates/save/(:segment)', 'System\EmailTemplateController::save/$1', ['filter' => 'permission:email.template.edit|settings.edit|settings.manage|master.manage']);
        $routes->match(['post', 'delete'], 'templates/delete/(:segment)', 'System\EmailTemplateController::delete/$1', ['filter' => 'permission:email.template.edit|settings.edit|settings.manage|master.manage']);
        $routes->post('templates/reset', 'System\EmailTemplateController::resetDefaults', ['filter' => 'permission:email.template.edit|settings.edit|settings.manage|master.manage']);

        $routes->get('companies', 'Master\CompanyController::index');
        $routes->get('companies/create', 'Master\CompanyController::create', ['filter' => 'platformAdmin']);
        $routes->post('companies/create', 'Master\CompanyController::store', ['filter' => 'platformAdmin']);
        $routes->get('companies/profile', 'Master\CompanyController::profile');
        $routes->get('companies/profile/(:segment)', 'Master\CompanyController::profile/$1');
        $routes->match(['post', 'put', 'patch'], 'companies/profile', 'Master\CompanyController::saveProfile', ['filter' => 'permission:settings.edit|settings.manage|master.edit|master.manage']);
        $routes->match(['post', 'put', 'patch'], 'companies/profile/(:segment)', 'Master\CompanyController::saveProfile/$1', ['filter' => 'permission:settings.edit|settings.manage|master.edit|master.manage']);
        $routes->match(['post', 'put', 'patch'], 'companies/profile/save', 'Master\CompanyController::saveProfile', ['filter' => 'permission:settings.edit|settings.manage|master.edit|master.manage']);
        $routes->match(['post', 'put', 'patch'], 'companies/profile/save/(:segment)', 'Master\CompanyController::saveProfile/$1', ['filter' => 'permission:settings.edit|settings.manage|master.edit|master.manage']);
        $routes->match(['post', 'put', 'patch'], 'companies/profile/admin', 'Master\CompanyController::saveAdmin', ['filter' => 'platformAdmin']);
        $routes->match(['post', 'put', 'patch'], 'companies/profile/admin/(:segment)', 'Master\CompanyController::saveAdmin/$1', ['filter' => 'platformAdmin']);
        $routes->match(['post', 'put', 'patch'], 'companies/save-admin', 'Master\CompanyController::saveAdmin', ['filter' => 'platformAdmin']);
        $routes->match(['post', 'put', 'patch'], 'companies/save-admin/(:segment)', 'Master\CompanyController::saveAdmin/$1', ['filter' => 'platformAdmin']);
        $routes->post('companies/store', 'Master\CompanyController::store', ['filter' => 'platformAdmin']);
        $routes->match(['post', 'put', 'patch'], 'companies/update/(:segment)', 'Master\CompanyController::update/$1', ['filter' => 'permission:settings.edit|settings.manage|master.edit|master.manage']);
        $routes->match(['post', 'delete'], 'companies/delete/(:segment)', 'Master\CompanyController::delete/$1', ['filter' => 'platformAdmin']);
        $routes->post('companies/toggle-status/(:segment)', 'Master\MasterController::toggleStatus/company/$1', ['filter' => 'permission:master.edit|master.manage|settings.edit|settings.manage']);
        $routes->post('companies/initialize-all', 'Master\CompanyController::initializeAllMasterData', ['filter' => 'platformAdmin']);
        $routes->post('companies/initialize/(:segment)', 'Master\CompanyController::initializeMasterData/$1', ['filter' => 'platformAdmin']);
        $routes->match(['post', 'put'], 'companies/toggle-break-policy/(:segment)', 'Master\CompanyController::toggleBreakPolicy/$1', ['filter' => 'permission:settings.edit|settings.manage|master.edit|master.manage|attendance.manage']);
        $routes->match(['post', 'put'], 'companies/toggle-break-policy', 'Master\CompanyController::toggleBreakPolicy', ['filter' => 'permission:settings.edit|settings.manage|master.edit|master.manage|attendance.manage']);

        $routes->get('branches', 'Master\BranchController::index');
        $routes->post('branches/store', 'Master\BranchController::store', ['filter' => 'permission:master.create|master.manage|settings.edit|settings.manage']);
        $routes->post('branches/update/(:segment)', 'Master\BranchController::update/$1', ['filter' => 'permission:master.edit|master.manage|settings.edit|settings.manage']);
        $routes->post('branches/delete/(:segment)', 'Master\BranchController::delete/$1', ['filter' => 'permission:master.delete|master.manage|settings.edit|settings.manage']);
        $routes->post('branches/toggle-status/(:segment)', 'Master\MasterController::toggleStatus/branch/$1', ['filter' => 'permission:master.edit|master.manage|settings.edit|settings.manage']);

        $routes->get('departments', 'Master\DepartmentController::index');
        $routes->post('departments/store', 'Master\DepartmentController::store', ['filter' => 'permission:master.create|master.manage|settings.edit|settings.manage']);
        $routes->post('departments/update/(:segment)', 'Master\DepartmentController::update/$1', ['filter' => 'permission:master.edit|master.manage|settings.edit|settings.manage']);
        $routes->post('departments/delete/(:segment)', 'Master\DepartmentController::delete/$1', ['filter' => 'permission:master.delete|master.manage|settings.edit|settings.manage']);
        $routes->post('departments/toggle-status/(:segment)', 'Master\MasterController::toggleStatus/department/$1', ['filter' => 'permission:master.edit|master.manage|settings.edit|settings.manage']);

        $routes->get('designations', 'Master\DesignationController::index');
        $routes->post('designations/store', 'Master\DesignationController::store', ['filter' => 'permission:master.create|master.manage|settings.edit|settings.manage']);
        $routes->post('designations/update/(:segment)', 'Master\DesignationController::update/$1', ['filter' => 'permission:master.edit|master.manage|settings.edit|settings.manage']);
        $routes->post('designations/delete/(:segment)', 'Master\DesignationController::delete/$1', ['filter' => 'permission:master.delete|master.manage|settings.edit|settings.manage']);
        $routes->post('designations/toggle-status/(:segment)', 'Master\MasterController::toggleStatus/designation/$1', ['filter' => 'permission:master.edit|master.manage|settings.edit|settings.manage']);

        $routes->get('shifts', 'Master\ShiftController::index');
        $routes->post('shifts/store', 'Master\ShiftController::store', ['filter' => 'permission:master.create|master.manage|settings.edit|settings.manage']);
        $routes->post('shifts/update/(:segment)', 'Master\ShiftController::update/$1', ['filter' => 'permission:master.edit|master.manage|settings.edit|settings.manage']);
        $routes->post('shifts/delete/(:segment)', 'Master\ShiftController::delete/$1', ['filter' => 'permission:master.delete|master.manage|settings.edit|settings.manage']);
        $routes->post('shifts/toggle-status/(:segment)', 'Master\MasterController::toggleStatus/shift/$1', ['filter' => 'permission:master.edit|master.manage|settings.edit|settings.manage']);

        $routes->get('holidays', 'Master\HolidayController::index');
        $routes->get('holidays/list', 'Master\HolidayController::listJson');
        $routes->get('holidays/weekly', 'Master\HolidayController::weeklyHolidaysJson');
        $routes->get('holidays/api-countries', 'Master\HolidayController::apiCountries');
        $routes->post('holidays/sync-api', 'Master\HolidayController::syncApi', ['filter' => 'permission:master.create|master.manage|settings.edit|settings.manage']);
        $routes->post('holidays/store', 'Master\HolidayController::store', ['filter' => 'permission:master.create|master.manage|settings.edit|settings.manage']);
        $routes->post('holidays/update/(:segment)', 'Master\HolidayController::update/$1', ['filter' => 'permission:master.edit|master.manage|settings.edit|settings.manage']);
        $routes->post('holidays/delete/(:segment)', 'Master\HolidayController::delete/$1', ['filter' => 'permission:master.delete|master.manage|settings.edit|settings.manage']);
        $routes->post('holidays/toggle-status/(:segment)', 'Master\MasterController::toggleStatus/holiday/$1', ['filter' => 'permission:master.edit|master.manage|settings.edit|settings.manage']);

        $routes->get('employment-types', 'Master\EmploymentTypeController::index');
        $routes->post('employment-types/store', 'Master\EmploymentTypeController::store', ['filter' => 'permission:master.create|master.manage|settings.edit|settings.manage']);
        $routes->post('employment-types/update/(:segment)', 'Master\EmploymentTypeController::update/$1', ['filter' => 'permission:master.edit|master.manage|settings.edit|settings.manage']);
        $routes->post('employment-types/delete/(:segment)', 'Master\EmploymentTypeController::delete/$1', ['filter' => 'permission:master.delete|master.manage|settings.edit|settings.manage']);
        $routes->post('employment-types/toggle-status/(:segment)', 'Master\MasterController::toggleStatus/employment_type/$1', ['filter' => 'permission:master.edit|master.manage|settings.edit|settings.manage']);
        $routes->post('employment-types/calculate-end-date', 'Master\EmploymentTypeController::calculateEndDateAjax', ['filter' => 'permission:master.edit|master.manage|settings.edit|settings.manage']);
        $routes->get('employment-types/periods', 'Master\EmploymentTypeController::periodsJson');
        $routes->post('employment-types/run-expiry-scan', 'Master\EmploymentTypeController::runExpiryScan', ['filter' => 'permission:master.edit|master.manage|settings.edit|settings.manage']);
        $routes->post('employment-types/extend-period/(:segment)', 'Master\EmploymentTypeController::extendPeriod/$1', ['filter' => 'permission:master.edit|master.manage|settings.edit|settings.manage']);
        $routes->get('employment-types/history/(:segment)', 'Master\EmploymentTypeController::employeeHistory/$1');

        $routes->get('grades', 'Master\SalaryGradeController::index');
        $routes->post('grades/store', 'Master\SalaryGradeController::store', ['filter' => 'permission:master.create|master.manage|settings.edit|settings.manage']);
        $routes->post('grades/update/(:segment)', 'Master\SalaryGradeController::update/$1', ['filter' => 'permission:master.edit|master.manage|settings.edit|settings.manage']);
        $routes->post('grades/delete/(:segment)', 'Master\SalaryGradeController::delete/$1', ['filter' => 'permission:master.delete|master.manage|settings.edit|settings.manage']);
        $routes->post('grades/toggle-status/(:segment)', 'Master\MasterController::toggleStatus/grade/$1', ['filter' => 'permission:master.edit|master.manage|settings.edit|settings.manage']);
    });

    // User & Permission Suite (RBAC) - Strictly Protected (Company Admin & Root SA Only)
    $routes->group('users', ['filter' => 'companyAdmin'], function ($routes) {
        $routes->get('/', 'Users\UserController::index');
        $routes->post('create', 'Users\UserController::store');
        $routes->post('update/(:segment)', 'Users\UserController::update/$1');
        $routes->post('toggle-status/(:segment)/(:segment)', 'Users\UserController::toggleStatus/$1/$2');
        $routes->post('toggle-2fa/(:segment)', 'Users\UserController::toggle2FA/$1');
        $routes->post('toggle-lock/(:segment)', 'Users\UserController::toggleLock/$1');
        $routes->post('lock/(:segment)', 'Users\UserController::toggleLock/$1');
        $routes->post('unlock/(:segment)', 'Users\UserController::toggleLock/$1');
        $routes->post('reactivate/(:segment)', 'Users\UserController::toggleStatus/$1/active');
        $routes->post('suspend/(:segment)', 'Users\UserController::toggleStatus/$1/suspended');
        $routes->post('reset-2fa/(:segment)', 'Users\UserController::toggle2FA/$1');
        $routes->post('reset-password/(:segment)', 'Users\UserController::resetPassword/$1');
        $routes->post('delete/(:segment)', 'Users\UserController::delete/$1');
        $routes->get('login-history', 'Users\UserController::loginHistory');
        $routes->get('permissions/(:segment)', 'Users\UserController::userPermissions/$1');
        $routes->get('(:segment)/permissions', 'Users\UserController::userPermissions/$1');
        $routes->post('permissions/save', 'Users\UserController::saveUserPermissionOverrides');
        $routes->post('permissions/reset/(:segment)', 'Users\UserController::resetUserPermissionOverrides/$1');
        $routes->post('(:segment)/permissions/reset', 'Users\UserController::resetUserPermissionOverrides/$1');
        $routes->post('ajax-simulate', 'Users\UserController::ajaxSimulate');
        $routes->get('api/effective-permissions/(:segment)', 'Users\UserController::getEffectivePermissionsApi/$1');
        $routes->get('(:segment)/effective-permissions', 'Users\UserController::getEffectivePermissionsApi/$1');

        $routes->get('menu-access', 'Users\RolePermissionController::menuAccess');
        $routes->post('menu-access/save', 'Users\RolePermissionController::saveMenuAccess');
        $routes->post('menu-access/reset-user', 'Users\RolePermissionController::resetUserMenuAccess');

        $routes->get('roles', 'Users\RolePermissionController::index');
        $routes->post('roles/ajax-simulate', 'Users\RolePermissionController::ajaxSimulate');
        $routes->post('roles/create', 'Users\RoleController::store');
        $routes->post('roles/update/(:segment)', 'Users\RoleController::update/$1');
        $routes->post('roles/toggle-status/(:segment)/(:segment)', 'Users\RoleController::toggleStatus/$1/$2');
        $routes->post('roles/clone', 'Users\RoleController::cloneFromPost');
        $routes->post('roles/clone/(:segment)', 'Users\RoleController::cloneRole/$1');
        $routes->post('roles/update-permissions', 'Users\RolePermissionController::saveMatrix', ['filter' => 'companyAdmin']);
        $routes->get('roles/update-permissions', function () {
            return redirect()->to(base_url('users/roles'));
        });
        $routes->post('roles/delete/(:segment)', 'Users\RoleController::delete/$1');
    });
    $routes->post('roles/update-permissions', 'Users\RolePermissionController::saveMatrix', ['filter' => 'companyAdmin']);
    $routes->get('roles/update-permissions', function () {
        return redirect()->to(base_url('users/roles'));
    });

    // Direct Security & Governance Suite Route Aliases (Company Admin / Platform Admin Guarded)
    $routes->get('roles', 'Users\RolePermissionController::index', ['filter' => 'companyAdmin']);
    $routes->get('role-permissions', 'Users\RolePermissionController::index', ['filter' => 'companyAdmin']);
    $routes->get('system-audit', 'System\AuditController::index', ['filter' => 'platformAdmin']);
    $routes->get('system-settings', 'System\SettingsController::index', ['filter' => 'platformAdmin']);
    $routes->get('security-policy', 'System\SecurityController::index', ['filter' => 'platformAdmin']);

    // System Administration & Maintenance Hub (Root Software App Admin Console Only)
    // Registered under 'system', 'system-administration', and 'system-admin' to prevent Apache physical directory collisions
    $systemRoutesHandler = function ($routes) {
        $routes->get('/', 'System\SystemController::index');
        $routes->get('manager', 'System\SystemController::index');
        $routes->get('software-app-admin', 'System\SystemController::index');

        $routes->get('theme', 'System\ThemeController::index');
        $routes->post('theme/save', 'System\ThemeController::save');

        $routes->get('backups', 'System\BackupController::index');
        $routes->post('backups/create', 'System\BackupController::createBackup');
        $routes->get('backups/download/(:segment)', 'System\BackupController::downloadBackup/$1');
        $routes->post('backups/delete/(:segment)', 'System\BackupController::deleteBackup/$1');
        $routes->post('backups/restore', 'System\BackupController::restoreBackup');
        $routes->post('backups/upload-restore', 'System\BackupController::uploadAndRestore');

        $routes->get('smtp', 'System\SmtpController::index');
        $routes->post('smtp/save', 'System\SmtpController::save');
        $routes->post('smtp/test', 'System\SmtpController::testConnection');
        $routes->post('smtp/reset', 'System\SmtpController::resetCompanyConfig');
        $routes->post('smtp/reset/(:segment)', 'System\SmtpController::resetCompanyConfig/$1');

        $routes->get('templates', 'System\EmailTemplateController::index');
        $routes->post('templates/create', 'System\EmailTemplateController::store');
        $routes->post('templates/save/(:segment)', 'System\EmailTemplateController::save/$1');
        $routes->match(['post', 'delete'], 'templates/delete/(:segment)', 'System\EmailTemplateController::delete/$1');
        $routes->post('templates/reset', 'System\EmailTemplateController::resetDefaults');

        $routes->get('audit', 'System\AuditController::index');
        $routes->get('audit-logs', 'System\AuditController::index');
        $routes->get('audit/exports', 'System\AuditController::exportAudit');
        $routes->get('audit/export', 'System\AuditController::exportCsv');
        $routes->post('audit/purge', 'System\AuditController::purge');
        $routes->post('audit/clear', 'System\AuditController::clearAll');

        $routes->get('settings', 'System\SettingsController::index');
        $routes->post('settings/save', 'System\SettingsController::save');
        $routes->get('security', 'System\SecurityController::index');
        $routes->post('security/save', 'System\SecurityController::save');

        $routes->get('diagnose', 'System\DiagnosticController::index');
        $routes->post('diagnose/fix', 'System\DiagnosticController::autoFix');
        $routes->post('diagnose/seed-attendance', 'System\DiagnosticController::seedAttendanceYear');

        // Scheduled Jobs & Automation Engine (P8)
        $routes->get('scheduled-jobs', 'System\ScheduledJobsController::index');
        $routes->get('scheduled-jobs/jobs', 'System\ScheduledJobsController::getJobs');
        $routes->post('scheduled-jobs/run-daily', 'System\ScheduledJobsController::runDaily');
        $routes->post('scheduled-jobs/run-weekly', 'System\ScheduledJobsController::runWeekly');
        $routes->post('scheduled-jobs/run-monthly', 'System\ScheduledJobsController::runMonthly');
    };

    $routes->group('system', ['filter' => 'platformAdmin'], $systemRoutesHandler);
    $routes->group('system-administration', ['filter' => 'platformAdmin'], $systemRoutesHandler);
    $routes->group('system-admin', ['filter' => 'platformAdmin'], $systemRoutesHandler);

    // Scheduled Jobs & Automation API Endpoints (Enforces Platform Admin Filter)
    $routes->get('api/v1/scheduled-jobs', 'System\ScheduledJobsController::getJobs', ['filter' => 'platformAdmin']);
    $routes->post('api/v1/scheduled-jobs/run-daily', 'System\ScheduledJobsController::runDaily', ['filter' => 'platformAdmin']);
    $routes->post('api/v1/scheduled-jobs/run-weekly', 'System\ScheduledJobsController::runWeekly', ['filter' => 'platformAdmin']);
    $routes->post('api/v1/scheduled-jobs/run-monthly', 'System\ScheduledJobsController::runMonthly', ['filter' => 'platformAdmin']);

    // Database & Schema Diagnostic API Endpoints
    $routes->get('api/v1/system/diagnose', 'System\DiagnosticController::index', ['filter' => 'platformAdmin']);
    $routes->post('api/v1/system/diagnose/fix', 'System\DiagnosticController::autoFix', ['filter' => 'platformAdmin']);
    $routes->post('api/v1/system/diagnose/seed-attendance', 'System\DiagnosticController::seedAttendanceYear', ['filter' => 'platformAdmin']);

    // Explicit Root URL Aliases & API Protection
    $routes->get('system-administration/software-app-admin', 'System\SystemController::index', ['filter' => 'platformAdmin']);
    $routes->get('api/system/software-app-admin', 'System\SystemController::index', ['filter' => 'platformAdmin']);
});

// Web Cron & Scheduler Endpoints (Outside session-only authFilter group; enforces X-Cron-Key, X-API-Key, Bearer Token, or Platform Admin Session in ScheduledJobsController::verifyCronOrAdminAuth)
$routes->post('cron/scheduler', 'System\ScheduledJobsController::runSchedulerHeartbeat');
$routes->post('cron/daily', 'System\ScheduledJobsController::runDaily');
$routes->post('cron/weekly', 'System\ScheduledJobsController::runWeekly');
$routes->post('cron/monthly', 'System\ScheduledJobsController::runMonthly');
$routes->get('cron/status', 'System\ScheduledJobsController::getJobs');
$routes->get('cron/jobs', 'System\ScheduledJobsController::getJobs');