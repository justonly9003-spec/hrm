<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class CORS extends BaseConfig
{
    /**
     * CORS is handled by App\Filters\CorsFilter using the CORS_ALLOWED_ORIGINS environment allowlist.
     * Wildcard origins are never combined with credentials.
     */
    public array $default = [];
}

