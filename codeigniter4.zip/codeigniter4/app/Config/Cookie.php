<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class Cookie extends BaseConfig
{
    /**
     * Cookie Prefix
     */
    public string $prefix = '';

    /**
     * Cookie Lifetime
     */
    public int $expires = 0;

    /**
     * Cookie Path
     */
    public string $path = '/';

    /**
     * Cookie Domain
     */
    public string $domain = '';

    /**
     * Secure Cookie (Automatically enabled when baseURL uses HTTPS)
     */
    public bool $secure = false;

    /**
     * HTTP Only
     */
    public bool $httponly = true;

    /**
     * SameSite attribute ('Lax', 'Strict', 'None', or '')
     */
    public ?string $samesite = 'Lax';

    /**
     * Raw Cookie
     */
    public bool $raw = false;

    public function __construct()
    {
        parent::__construct();

        $baseUrl = (string) (env('app.baseURL') ?: (config(App::class)->baseURL ?? ''));
        if (str_starts_with(strtolower(trim($baseUrl)), 'https://')) {
            $this->secure = true;
        }

        $explicitSecure = env('cookie.secure', env('app.cookieSecure'));
        if ($explicitSecure !== null && $explicitSecure !== '') {
            $this->secure = filter_var($explicitSecure, FILTER_VALIDATE_BOOLEAN);
            if (str_starts_with(strtolower(trim($baseUrl)), 'https://')) {
                $this->secure = true;
            }
        }
    }
}

