<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;
use CodeIgniter\Filters\CSRF;
use CodeIgniter\Filters\DebugToolbar;
use CodeIgniter\Filters\Honeypot;
use CodeIgniter\Filters\InvalidChars;
use CodeIgniter\Filters\SecureHeaders;
use App\Filters\AuthFilter;
use App\Filters\PermissionFilter;
use App\Filters\RoleFilter;
use App\Filters\CorsFilter;
use App\Filters\PlatformAdminFilter;
use App\Filters\CompanyAdminFilter;
use App\Filters\MobileAuthFilter;
use App\Filters\AuditFilter;

class Filters extends BaseConfig
{
    /**
     * Configures aliases for Filter classes to
     * make reading things nicer and simpler.
     */
    public array $aliases = [
        'csrf'          => CSRF::class,
        'toolbar'       => DebugToolbar::class,
        'honeypot'      => Honeypot::class,
        'invalidchars'  => InvalidChars::class,
        'secureheaders' => SecureHeaders::class,
        'auth'          => AuthFilter::class,
        'authFilter'    => AuthFilter::class,
        'permission'    => PermissionFilter::class,
        'permissionFilter' => PermissionFilter::class,
        'role'          => RoleFilter::class,
        'roleFilter'    => RoleFilter::class,
        'cors'          => CorsFilter::class,
        'platformAdmin' => PlatformAdminFilter::class,
        'companyAdmin'  => CompanyAdminFilter::class,
        'mobileAuth'    => MobileAuthFilter::class,
        'rateLimit'     => \App\Filters\RateLimitFilter::class,
        'audit'         => AuditFilter::class,
        'auditFilter'   => AuditFilter::class,
    ];

    /**
     * List of filter aliases that are always
     * applied before and after every request.
     */
    public array $globals = [
        'before' => [
            'cors',
            'csrf' => [
                'except' => [
                    // SEC-ATT-01: Exact biometric hardware device endpoints (strictly X-API-Key authenticated)
                    'api/attendance/zk-push',
                    'api/attendance/push-punch',
                    'api/biometrics/enroll',
                    'attendance/sync/api/push-punch',
                    'attendance/sync/api/enroll',
                    // External cron webhook endpoints (authenticated via X-Cron-Key / X-API-Key / Bearer secret header)
                    'cron/scheduler',
                    'cron/daily',
                    'cron/weekly',
                    'cron/monthly',
                    // Mobile API is token-authenticated (Bearer), not cookie/session based
                    'api/mobile/*',
                    'api/mobile/v1/*',
                    'api/v1/*',
                    'api/v1/auth/*',
                    'api/v1/attendance/*',
                    'api/v1/leave/*',
                    'api/v1/leaves/*',
                    'api/v1/overtime/*',
                    'api/v1/notifications/*',
                    'api/v1/shifts/*',
                    'api/v1/shift/*',
                    'api/v1/profile/*',
                    'api/v1/pf*',
                    'api/v1/payroll*',
                    'api/v1/statements*',
                ]
            ],
            'invalidchars',
        ],
        'after' => [
            'toolbar',
            'secureheaders',
            'audit',
        ],
    ];

    /**
     * List of filter aliases that works on a
     * particular HTTP method (GET, POST, etc.).
     */
    public array $methods = [];

    /**
     * List of filter aliases that should run on any
     * before or after URI patterns.
     */
    public array $filters = [
        'auth' => [
            'before' => [
                'api/employees*',
                'api/leave*',
                'api/payroll*',
                'api/performance*',
                'api/training*',
                'api/recruitment*',
                'api/assets*',
                'api/bonuses*',
                'api/branches*',
                'api/holidays*',
                'api/notices*',
                'api/shift-rosters*',
                'api/company-settings*',
                'api/users*',
                'api/dashboard*',
                'dashboard*',
                'employees*',
                'live-attendance*',
                'live-control*',
                'attendance-simulation*',
                'zkteco*',
                'roster*',
                'leaves*',
                'payroll*',
                'performance*',
                'training*',
                'recruitment*',
                'settings*',
                'users*',
                'master*',
                'organogram*',
                'company*',
            ],
        ],
        'rateLimit' => [
            'before' => [
                'api/mobile/v1/auth/login',
                'api/mobile/v1/auth/refresh',
                'api/v1/auth/login',
                'api/v1/auth/refresh',
            ],
        ],
    ];
}
