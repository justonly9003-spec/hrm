<?php

namespace Config;

/**
 * Paths
 *
 * Holds the paths that are used by the system to
 * locate and load other Files.
 */
class Paths
{
    /**
     * The path to the application directory.
     */
    public string $appDirectory = __DIR__ . '/..';

    /**
     * The path to the system directory.
     */
    public string $systemDirectory = __DIR__ . '/../../vendor/codeigniter4/framework/system';

    /**
     * The path to the writable directory.
     */
    public string $writableDirectory = __DIR__ . '/../../writable';

    /**
     * The path to the views directory.
     */
    public string $viewDirectory = __DIR__ . '/../Views';

    /**
     * The path to the tests directory.
     */
    public string $testsDirectory = __DIR__ . '/../../tests';

    /**
     * The path to the root directory.
     */
    public string $rootDirectory = __DIR__ . '/../..';

    /**
     * Constructor to auto-detect system directory location
     */
    public function __construct()
    {
        $root = realpath(__DIR__ . '/../..') ?: (__DIR__ . '/../..');
        $this->rootDirectory   = $root;
        $this->appDirectory    = realpath(__DIR__ . '/..') ?: (__DIR__ . '/..');
        $this->viewDirectory   = realpath(__DIR__ . '/../Views') ?: (__DIR__ . '/../Views');

        // Auto-detect system directory location
        $candidatePaths = [
            $root . '/vendor/codeigniter4/framework/system',
            $root . '/system',
            dirname($root) . '/vendor/codeigniter4/framework/system',
            dirname($root) . '/system',
        ];

        foreach ($candidatePaths as $candidate) {
            if (is_dir($candidate) && (is_file($candidate . '/Boot.php') || is_file($candidate . '/bootstrap.php') || is_file($candidate . '/CodeIgniter.php'))) {
                $this->systemDirectory = $candidate;
                break;
            }
        }

        // Auto-detect writable directory
        $writableCandidate = $root . '/writable';
        if (is_dir($writableCandidate)) {
            $this->writableDirectory = $writableCandidate;
        }
    }
}
