<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class Hrms extends BaseConfig
{
    /**
     * Centralized system default password for new / reset user accounts.
     */
    public const DEFAULT_PASSWORD = '123456';

    public string $defaultPassword = self::DEFAULT_PASSWORD;
}
