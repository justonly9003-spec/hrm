<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class Permissions extends BaseConfig
{
    /**
     * Whitelist of canonical action verbs recognized across the HRMS RBAC system.
     * Any permission action outside this vocabulary will log a warning and fail-closed (DENY).
     */
    public array $canonicalActions = [
        'view',
        'create',
        'edit',
        'delete',
        'approve',
        'endorse',
        'reject',
        'cancel',
        'manage',
        'export',
        'import',
        'assign',
        'publish',
        'run',
        'sync',
        'adjust',
        'punch',
        'clock',
        'regularize',
        'request',
        'encash',
        'early_closures',
        'recommend',
        'disburse',
        'generate',
        'balance_adjust',
        'regularize_approve',
        'early_closure_manage',
        'device_manage',
        'transfer',
        'promote',
        'terminate',
        'approve_resignation',
        'view_salary',
        'view_sensitive',
        'override_tier',
        'closing_reopen',
        'hr_approve',
        'writeoff',
    ];

    /**
     * Action aliases mapped to canonical verbs
     */
    public array $actionAliases = [
        'upload'                 => 'create',
        'update'                 => 'edit',
        'export_excel'           => 'export',
        'export_pdf'             => 'export',
        'print'                  => 'export',
        'restore'                => 'edit',
        'lock_unlock'            => 'manage',
        'disburse'               => 'disburse',
        'view_salary'            => 'view_salary',
        'view_sensitive'         => 'view_sensitive',
        'recalculate'            => 'run',
        'generate'               => 'generate',
        'settle'                 => 'approve',
        'read'                   => 'view',
        'history'                => 'view',
        'early_closure'          => 'early_closures',
        'early-closure'          => 'early_closures',
        'early-closures'         => 'early_closures',
        'early_closure_manage'   => 'early_closure_manage',
        'regularize_approve'     => 'regularize_approve',
        'device_manage'          => 'device_manage',
        'balance_adjust'         => 'balance_adjust',
        'hr_approval'            => 'hr_approve',
        'approve_hr'             => 'hr_approve',
    ];

    /**
     * Recognized system modules
     */
    public array $modules = [
        'dashboard'         => 'Executive & Operational Dashboard',
        'directory'         => 'Workforce Directory & Employee Profiles',
        'employees'         => 'Workforce Directory & Employee Profiles',
        'attendance'        => 'Attendance, Clocking & Biometrics',
        'overtime'          => 'Overtime Claims & Calculations',
        'rostering'         => 'Duty Shifts & Shift Rostering',
        'roster'            => 'Duty Shifts & Shift Rostering',
        'leaves'            => 'Leave Management & Quota Accruals',
        'leave'             => 'Leave Management & Quota Accruals',
        'payroll'           => 'Payroll Processing & Salary Generation',
        'pf'                => 'Provident Fund Statutory Scheme & Ledgers',
        'bonus'             => 'Discretionary & Festival Bonus Runs',
        'loans'             => 'Employee Loans & Salary Advances',
        'assets'            => 'Corporate Assets & Equipment Inventory',
        'training'          => 'Employee Training Programs & Certifications',
        'performance'       => '360 Appraisals, Goals & Performance Reviews',
        'recruitment'       => 'Job Postings & Candidate Pipeline',
        'reports'           => 'Enterprise Reports & Document Upload Hub',
        'rules'             => 'Single Source Business Rules Engine',
        'notices'           => 'Company Broadcasts & Bulletin Notices',
        'notifications'     => 'Notification Templates & System Alerts',
        'medical_insurance' => 'Medical & Healthcare Insurance Suite',
        'insurance'         => 'Medical & Healthcare Insurance Suite',
        'company_expense'   => 'Company Expense Claims & Approvals',
        'expenses'          => 'Company Expense Claims & Approvals',
        'master'            => 'Organizational Structure & Master Data',
        'email'             => 'Email Gateway & Notification Templates',
        'settings'          => 'System Governance & Company Settings',
        'security'          => 'Security Safeguards & Access Control',
        'system_audit'      => 'Forensic Audit Logs & Trails',
        'system'            => 'Platform Kernel & Multi-Tenant Infrastructure',
        'platform'          => 'Platform Administration',
        'user'              => 'User Account Management',
        'role'              => 'RBAC Roles & Matrix Configuration',
        'rbac'              => 'RBAC Governance & Assignment',
    ];

    /**
     * Canonical 10 System Roles
     */
    public array $systemRoles = [
        'software_app_admin' => [
            'id'          => 'role-001',
            'name'        => 'Software App Admin',
            'code'        => 'software_app_admin',
            'description' => 'Root technical application administrator with unrestricted platform control',
        ],
        'company_admin' => [
            'id'          => 'role-002',
            'name'        => 'Company Admin',
            'code'        => 'company_admin',
            'description' => 'Top organizational executive and tenant administrative controller',
        ],
        'hr_admin' => [
            'id'          => 'role-003',
            'name'        => 'HR Admin',
            'code'        => 'hr_admin',
            'description' => 'Full human resources, policies, and employee lifecycle management',
        ],
        'hr_officer' => [
            'id'          => 'role-004',
            'name'        => 'HR Officer',
            'code'        => 'hr_officer',
            'description' => 'Day-to-day HR operations, onboarding, and leaves record-keeping',
        ],
        'branch_manager' => [
            'id'          => 'role-010',
            'name'        => 'Branch Manager',
            'code'        => 'branch_manager',
            'description' => 'Branch executive overseeing branch operations, attendance, and branch personnel',
        ],
        'finance' => [
            'id'          => 'role-005',
            'name'        => 'Finance',
            'code'        => 'finance',
            'description' => 'Payroll runs, bonus calculations, and loan disbursement authority',
        ],
        'manager' => [
            'id'          => 'role-006',
            'name'        => 'Manager',
            'code'        => 'manager',
            'description' => 'Department head with staff approval, rosters, and KPI assessment authority',
        ],
        'team_leader' => [
            'id'          => 'role-007',
            'name'        => 'Team Leader',
            'code'        => 'team_leader',
            'description' => 'Operational unit supervisor with shift and attendance verification',
        ],
        'employee' => [
            'id'          => 'role-008',
            'name'        => 'Employee',
            'code'        => 'employee',
            'description' => 'Staff member self-service portal, clocking, and leave requests',
        ],
        'auditor' => [
            'id'          => 'role-009',
            'name'        => 'Auditor',
            'code'        => 'auditor',
            'description' => 'Compliance reviewer with read-only audit and analytics export access',
        ],
    ];

    /**
     * Alias for $catalogue to support test suites and legacy integrations expecting $permissionsCatalogue
     */
    public array $permissionsCatalogue = [];

    /**
     * Complete Permission Catalogue (module.action) with default scopes and sensitive/platform flags
     */
    public array $catalogue = [
        // Dashboard
        'dashboard.view'            => ['module' => 'dashboard', 'action' => 'view', 'name' => 'View Dashboard', 'desc' => 'Access personal and operational KPI dashboard', 'default_scope' => 'company'],
        'dashboard.manage'          => ['module' => 'dashboard', 'action' => 'manage', 'name' => 'Manage Dashboard', 'desc' => 'Configure system dashboard widgets and role layouts', 'default_scope' => 'company'],

        // Directory / Employees
        'directory.view'            => ['module' => 'directory', 'action' => 'view', 'name' => 'View Directory', 'desc' => 'View employee directory, organogram, and profiles', 'default_scope' => 'company'],
        'directory.create'          => ['module' => 'directory', 'action' => 'create', 'name' => 'Create Employees', 'desc' => 'Onboard new employees and create profile records', 'default_scope' => 'company'],
        'directory.edit'            => ['module' => 'directory', 'action' => 'edit', 'name' => 'Edit Employees', 'desc' => 'Modify employee personal, job, and salary details', 'default_scope' => 'company'],
        'directory.delete'          => ['module' => 'directory', 'action' => 'delete', 'name' => 'Delete Employees', 'desc' => 'Terminate or purge employee records', 'default_scope' => 'company'],
        'directory.export'          => ['module' => 'directory', 'action' => 'export', 'name' => 'Export Directory', 'desc' => 'Export employee lists and biodata to CSV/PDF', 'default_scope' => 'company'],
        'directory.manage'          => ['module' => 'directory', 'action' => 'manage', 'name' => 'Manage Directory', 'desc' => 'Full administrative control over staff directory', 'default_scope' => 'company'],
        'employees.view'            => ['module' => 'employees', 'action' => 'view', 'name' => 'View Employees', 'desc' => 'View employee directory, organogram, and profiles', 'default_scope' => 'company'],
        'employees.create'          => ['module' => 'employees', 'action' => 'create', 'name' => 'Create Employees', 'desc' => 'Onboard new employees and create profile records', 'default_scope' => 'company'],
        'employees.edit'            => ['module' => 'employees', 'action' => 'edit', 'name' => 'Edit Employees', 'desc' => 'Modify employee personal, job, and salary details', 'default_scope' => 'company'],
        'employees.delete'          => ['module' => 'employees', 'action' => 'delete', 'name' => 'Delete Employees', 'desc' => 'Terminate or purge employee records', 'default_scope' => 'company'],
        'employees.export'          => ['module' => 'employees', 'action' => 'export', 'name' => 'Export Employees', 'desc' => 'Export employee lists and biodata to CSV/PDF', 'default_scope' => 'company'],
        'employee.export'           => ['module' => 'directory', 'action' => 'export', 'name' => 'Export Employees', 'desc' => 'Export employee directory lists and biodata to CSV/PDF', 'default_scope' => 'company'],
        'employee.view_salary'      => ['module' => 'directory', 'action' => 'view_salary', 'name' => 'View Employee Salary', 'desc' => 'View employee salary and compensation figures', 'default_scope' => 'company', 'is_sensitive' => true],
        'employee.view_sensitive'   => ['module' => 'directory', 'action' => 'view_sensitive', 'name' => 'View Sensitive Details', 'desc' => 'View employee sensitive records like NID, passport, and bank accounts', 'default_scope' => 'company', 'is_sensitive' => true],
        'employees.view_salary'     => ['module' => 'employees', 'action' => 'view_salary', 'name' => 'View Employee Salary', 'desc' => 'View employee salary and compensation figures', 'default_scope' => 'company', 'is_sensitive' => true],
        'employees.view_sensitive'  => ['module' => 'employees', 'action' => 'view_sensitive', 'name' => 'View Sensitive Details', 'desc' => 'View employee sensitive records like NID, passport, and bank accounts', 'default_scope' => 'company', 'is_sensitive' => true],
        'directory.view_salary'     => ['module' => 'directory', 'action' => 'view_salary', 'name' => 'View Employee Salary', 'desc' => 'View employee salary and compensation figures', 'default_scope' => 'company', 'is_sensitive' => true],
        'directory.view_sensitive'  => ['module' => 'directory', 'action' => 'view_sensitive', 'name' => 'View Sensitive Details', 'desc' => 'View employee sensitive records like NID, passport, and bank accounts', 'default_scope' => 'company', 'is_sensitive' => true],
        'employees.manage'          => ['module' => 'employees', 'action' => 'manage', 'name' => 'Manage Employees', 'desc' => 'Full administrative control over staff directory', 'default_scope' => 'company'],
        'employees.salary.view'     => ['module' => 'employees', 'action' => 'view', 'name' => 'View Compensation & Salary', 'desc' => 'View employee salary, bank, and provident fund figures', 'default_scope' => 'company', 'is_sensitive' => true],
        'employees.movement'        => ['module' => 'employees', 'action' => 'edit', 'name' => 'Manage Promotions & Transfers', 'desc' => 'Promote and transfer employees across positions and branches', 'default_scope' => 'company'],
        'employees.separate'        => ['module' => 'employees', 'action' => 'delete', 'name' => 'Manage Separations & Exits', 'desc' => 'Process employee resignations, terminations, and settlements', 'default_scope' => 'company'],
        'employee.transfer'         => ['module' => 'directory', 'action' => 'transfer', 'name' => 'Transfer Employees', 'desc' => 'Transfer employees across branches, departments, and designations', 'default_scope' => 'company'],
        'directory.transfer'        => ['module' => 'directory', 'action' => 'transfer', 'name' => 'Transfer Employees', 'desc' => 'Transfer employees across branches, departments, and designations', 'default_scope' => 'company'],
        'employee.promote'          => ['module' => 'directory', 'action' => 'promote', 'name' => 'Promote Employees', 'desc' => 'Promote employees to higher designations and revised compensation', 'default_scope' => 'company'],
        'directory.promote'         => ['module' => 'directory', 'action' => 'promote', 'name' => 'Promote Employees', 'desc' => 'Promote employees to higher designations and revised compensation', 'default_scope' => 'company'],
        'employee.terminate'        => ['module' => 'directory', 'action' => 'terminate', 'name' => 'Terminate Employees', 'desc' => 'Initiate and approve official employee termination and separations', 'default_scope' => 'company', 'is_sensitive' => true],
        'directory.terminate'       => ['module' => 'directory', 'action' => 'terminate', 'name' => 'Terminate Employees', 'desc' => 'Initiate and approve official employee termination and separations', 'default_scope' => 'company', 'is_sensitive' => true],
        'employee.approve_resignation' => ['module' => 'directory', 'action' => 'approve_resignation', 'name' => 'Approve Employee Resignation', 'desc' => 'Review and formally approve employee resignation notices', 'default_scope' => 'company', 'is_sensitive' => true],
        'directory.approve_resignation' => ['module' => 'directory', 'action' => 'approve_resignation', 'name' => 'Approve Employee Resignation', 'desc' => 'Review and formally approve employee resignation notices', 'default_scope' => 'company', 'is_sensitive' => true],
        'employees.probation'       => ['module' => 'employees', 'action' => 'manage', 'name' => 'Manage Employee Probation', 'desc' => 'Evaluate, extend, confirm, or cancel employee probation', 'default_scope' => 'company'],
        'employees.bulk'            => ['module' => 'employees', 'action' => 'manage', 'name' => 'Bulk Workforce Operations', 'desc' => 'Perform bulk uploads, mass updates, and bulk PF assignments', 'default_scope' => 'company'],
        'profile.view'              => ['module' => 'profile', 'action' => 'view', 'name' => 'View Own Profile', 'desc' => 'View personal profile and employment details', 'default_scope' => 'self'],
        'profile.edit'              => ['module' => 'profile', 'action' => 'edit', 'name' => 'Edit Own Profile', 'desc' => 'Update personal contact and emergency details', 'default_scope' => 'self'],
        'organogram.view'           => ['module' => 'organogram', 'action' => 'view', 'name' => 'View Organogram', 'desc' => 'View organizational reporting hierarchy chart', 'default_scope' => 'company'],
        'organogram.manage'         => ['module' => 'organogram', 'action' => 'manage', 'name' => 'Manage Organogram', 'desc' => 'Update reporting managers and organizational hierarchy structure', 'default_scope' => 'company'],
        'organogram.export'         => ['module' => 'organogram', 'action' => 'export', 'name' => 'Export Organogram', 'desc' => 'Export organizational hierarchy chart to PDF or image', 'default_scope' => 'company'],
        'zkteco.view'               => ['module' => 'zkteco', 'action' => 'view', 'name' => 'View Biometric Devices', 'desc' => 'View ZKTeco biometric devices and sync logs', 'default_scope' => 'company'],
        'zkteco.manage'             => ['module' => 'zkteco', 'action' => 'manage', 'name' => 'Manage Biometric Devices', 'desc' => 'Manage ZKTeco biometric terminals and sync queues', 'default_scope' => 'company'],

        // Attendance
        'attendance.view'                 => ['module' => 'attendance', 'action' => 'view', 'name' => 'View Attendance', 'desc' => 'View attendance muster, daily logs, and employee punch history', 'default_scope' => 'company'],
        'attendance.clock'                => ['module' => 'attendance', 'action' => 'clock', 'name' => 'Web Punch & Clock', 'desc' => 'Punch check-in, check-out, and break intervals in ESS', 'default_scope' => 'self'],
        'attendance.punch'                => ['module' => 'attendance', 'action' => 'punch', 'name' => 'Biometric Punch Ingest', 'desc' => 'Ingest physical hardware punches from biometric terminals', 'default_scope' => 'company'],
        'attendance.regularize'           => ['module' => 'attendance', 'action' => 'regularize', 'name' => 'Attendance Regularization Request', 'desc' => 'Submit attendance correction requests', 'default_scope' => 'self'],
        'attendance.approve'              => ['module' => 'attendance', 'action' => 'approve', 'name' => 'Approve Attendance Corrections', 'desc' => 'Approve or reject manual punch adjustments and corrections', 'default_scope' => 'company'],
        'attendance.regularize_approve'   => ['module' => 'attendance', 'action' => 'regularize_approve', 'name' => 'Approve Regularization', 'desc' => 'Granular approval of attendance regularization requests', 'default_scope' => 'company'],
        'attendance.create'               => ['module' => 'attendance', 'action' => 'create', 'name' => 'Create Attendance Log', 'desc' => 'Manually add punch logs or duty records', 'default_scope' => 'company'],
        'attendance.edit'                 => ['module' => 'attendance', 'action' => 'edit', 'name' => 'Edit Attendance Log', 'desc' => 'Edit recorded check-in, check-out, or status', 'default_scope' => 'company'],
        'attendance.delete'               => ['module' => 'attendance', 'action' => 'delete', 'name' => 'Delete Attendance Log', 'desc' => 'Remove erroneous attendance entries', 'default_scope' => 'company'],
        'attendance.export'               => ['module' => 'attendance', 'action' => 'export', 'name' => 'Export Attendance Muster', 'desc' => 'Export monthly attendance sheets and reports', 'default_scope' => 'company'],
        'attendance.sync'                 => ['module' => 'attendance', 'action' => 'sync', 'name' => 'Sync Biometric Devices', 'desc' => 'Poll and synchronize ZKTeco / biometric hardware', 'default_scope' => 'company'],
        'attendance.manage'               => ['module' => 'attendance', 'action' => 'manage', 'name' => 'Manage Attendance Hub', 'desc' => 'Early closures, device management, and terminal control', 'default_scope' => 'company'],
        'attendance.early_closures'       => ['module' => 'attendance', 'action' => 'early_closures', 'name' => 'View Early Closures', 'desc' => 'Declare, view, and inspect company emergency or early closures', 'default_scope' => 'company'],
        'attendance.early_closure_manage' => ['module' => 'attendance', 'action' => 'early_closure_manage', 'name' => 'Manage Early Closures', 'desc' => 'Create, approve, credit, and revoke company early closures', 'default_scope' => 'company'],
        'attendance.device_manage'        => ['module' => 'attendance', 'action' => 'device_manage', 'name' => 'Manage Biometric Devices', 'desc' => 'Configure and calibrate physical biometric terminal fleet', 'default_scope' => 'company'],

        // Overtime
        'overtime.view'             => ['module' => 'overtime', 'action' => 'view', 'name' => 'View Overtime', 'desc' => 'View overtime claims, logs, and approved hours', 'default_scope' => 'company'],
        'overtime.create'           => ['module' => 'overtime', 'action' => 'create', 'name' => 'Submit OT Claim', 'desc' => 'Submit employee overtime work requests and claims', 'default_scope' => 'company'],
        'overtime.edit'             => ['module' => 'overtime', 'action' => 'edit', 'name' => 'Edit Overtime Hours', 'desc' => 'Adjust requested or computed overtime duration', 'default_scope' => 'company'],
        'overtime.approve'          => ['module' => 'overtime', 'action' => 'approve', 'name' => 'Approve Overtime', 'desc' => 'Final sign-off and approval of overtime claims', 'default_scope' => 'company'],
        'overtime.recommend'        => ['module' => 'overtime', 'action' => 'recommend', 'name' => 'Recommend Overtime', 'desc' => 'Team leader recommendation of overtime hours', 'default_scope' => 'team'],
        'overtime.delete'           => ['module' => 'overtime', 'action' => 'delete', 'name' => 'Delete Overtime Claim', 'desc' => 'Cancel or purge unapproved overtime requests', 'default_scope' => 'company'],
        'overtime.export'           => ['module' => 'overtime', 'action' => 'export', 'name' => 'Export Overtime Data', 'desc' => 'Export overtime ledger and settlement reports to CSV', 'default_scope' => 'company'],
        'overtime.manage'           => ['module' => 'overtime', 'action' => 'manage', 'name' => 'Manage Overtime Rules', 'desc' => 'Configure overtime rate formulas, caps, and settlement locks', 'default_scope' => 'company'],

        // Rostering / Roster
        'roster.view'               => ['module' => 'roster', 'action' => 'view', 'name' => 'View Shift Rosters', 'desc' => 'Inspect shift rosters, duty schedules, and calendar', 'default_scope' => 'company'],
        'roster.create'             => ['module' => 'roster', 'action' => 'create', 'name' => 'Create Roster Assignment', 'desc' => 'Schedule employees to shifts and duty rosters', 'default_scope' => 'company'],
        'roster.edit'               => ['module' => 'roster', 'action' => 'edit', 'name' => 'Edit Shift Rosters', 'desc' => 'Update shift schedules and resolve roster conflicts', 'default_scope' => 'company'],
        'roster.delete'             => ['module' => 'roster', 'action' => 'delete', 'name' => 'Delete Shift Roster', 'desc' => 'Remove roster assignments', 'default_scope' => 'company'],
        'roster.assign'             => ['module' => 'roster', 'action' => 'assign', 'name' => 'Bulk Assign Rosters', 'desc' => 'Batch assign departments or teams to shift schedules', 'default_scope' => 'company'],
        'roster.publish'            => ['module' => 'roster', 'action' => 'publish', 'name' => 'Publish Shift Roster', 'desc' => 'Publish and lock monthly or weekly shift rosters', 'default_scope' => 'company'],
        'roster.export'             => ['module' => 'roster', 'action' => 'export', 'name' => 'Export Shift Rosters', 'desc' => 'Export roster calendars to CSV or print view', 'default_scope' => 'company'],
        'roster.manage'             => ['module' => 'roster', 'action' => 'manage', 'name' => 'Manage Shift Rules', 'desc' => 'Configure rotation patterns, swap policies, and shift masters', 'default_scope' => 'company'],
        'rostering.view'            => ['module' => 'rostering', 'action' => 'view', 'name' => 'View Shift Rosters', 'desc' => 'Inspect shift rosters, duty schedules, and calendar', 'default_scope' => 'company'],
        'rostering.create'          => ['module' => 'rostering', 'action' => 'create', 'name' => 'Create Roster Assignment', 'desc' => 'Schedule employees to shifts and duty rosters', 'default_scope' => 'company'],
        'rostering.edit'            => ['module' => 'rostering', 'action' => 'edit', 'name' => 'Edit Shift Rosters', 'desc' => 'Update shift schedules and resolve roster conflicts', 'default_scope' => 'company'],
        'rostering.delete'          => ['module' => 'rostering', 'action' => 'delete', 'name' => 'Delete Shift Roster', 'desc' => 'Remove roster assignments', 'default_scope' => 'company'],
        'rostering.assign'          => ['module' => 'rostering', 'action' => 'assign', 'name' => 'Bulk Assign Rosters', 'desc' => 'Batch assign departments or teams to shift schedules', 'default_scope' => 'company'],
        'rostering.publish'         => ['module' => 'rostering', 'action' => 'publish', 'name' => 'Publish Shift Roster', 'desc' => 'Publish and lock monthly or weekly shift rosters', 'default_scope' => 'company'],
        'rostering.export'          => ['module' => 'rostering', 'action' => 'export', 'name' => 'Export Shift Rosters', 'desc' => 'Export roster calendars to CSV or print view', 'default_scope' => 'company'],
        'rostering.manage'          => ['module' => 'rostering', 'action' => 'manage', 'name' => 'Manage Shift Rules', 'desc' => 'Configure rotation patterns, swap policies, and shift masters', 'default_scope' => 'company'],

        // Leaves / Leave
        'leave.view'                => ['module' => 'leave', 'action' => 'view', 'name' => 'View Leave Records', 'desc' => 'View own leave applications and remaining quotas', 'default_scope' => 'company'],
        'leave.view_all'            => ['module' => 'leave', 'action' => 'view_all', 'name' => 'View All Leave Records', 'desc' => 'Inspect organization-wide leave records across departments', 'default_scope' => 'company'],
        'leave.create'              => ['module' => 'leave', 'action' => 'create', 'name' => 'Apply for Leave', 'desc' => 'Submit leave requests and applications', 'default_scope' => 'company'],
        'leave.endorse'             => ['module' => 'leave', 'action' => 'endorse', 'name' => 'Endorse Leave Application', 'desc' => 'Tier 1 supervisor endorsement of team member leaves', 'default_scope' => 'team'],
        'leave.approve'             => ['module' => 'leave', 'action' => 'approve', 'name' => 'Approve Leave Application', 'desc' => 'Tier 2 HR/Admin approval of leave applications', 'default_scope' => 'company'],
        'leave.reject'              => ['module' => 'leave', 'action' => 'reject', 'name' => 'Reject Leave Application', 'desc' => 'Decline leave requests with mandatory reason', 'default_scope' => 'company'],
        'leave.cancel'              => ['module' => 'leave', 'action' => 'cancel', 'name' => 'Cancel Leave Application', 'desc' => 'Revoke approved or pending leave requests', 'default_scope' => 'company'],
        'leave.adjust'              => ['module' => 'leave', 'action' => 'adjust', 'name' => 'Adjust Leave Quota', 'desc' => 'Credit or debit employee leave quota balances manually', 'default_scope' => 'company'],
        'leave.balance_adjust'      => ['module' => 'leave', 'action' => 'balance_adjust', 'name' => 'Balance Add/Adjust', 'desc' => 'Granular quota adjustments with payroll lock protection', 'default_scope' => 'company'],
        'leave.encash'              => ['module' => 'leave', 'action' => 'encash', 'name' => 'Encash Leave Balance', 'desc' => 'Request or disburse leave balance encashment', 'default_scope' => 'company'],
        'leave.export'              => ['module' => 'leave', 'action' => 'export', 'name' => 'Export Leave Ledgers', 'desc' => 'Export leave transaction ledger and yearly balances', 'default_scope' => 'company'],
        'leave.manage'              => ['module' => 'leave', 'action' => 'manage', 'name' => 'Manage Leave Policies', 'desc' => 'Define leave types, eligibility rules, and accrual policies', 'default_scope' => 'company'],
        'leave.override_tier'       => ['module' => 'leave', 'action' => 'override_tier', 'name' => 'Override Approval Tier', 'desc' => 'Final-approve leave without Tier-1 endorsement (emergency/admin override)', 'default_scope' => 'company'],
        'leave.closing_reopen'      => ['module' => 'leave', 'action' => 'closing_reopen', 'name' => 'Reopen Closed Leave Year', 'desc' => 'Reopen a finalized and closed leave fiscal year for audit adjustments', 'default_scope' => 'company'],
        'leave.hr_approve'          => ['module' => 'leave', 'action' => 'hr_approve', 'name' => 'HR Leave Approval', 'desc' => 'Final HR approval/sanction step for multi-tier leave applications', 'default_scope' => 'company'],
        'leaves.view'               => ['module' => 'leaves', 'action' => 'view', 'name' => 'View Leave Records', 'desc' => 'View own leave applications and remaining quotas', 'default_scope' => 'company'],
        'leaves.view_all'           => ['module' => 'leaves', 'action' => 'view_all', 'name' => 'View All Leave Records', 'desc' => 'Inspect organization-wide leave records across departments', 'default_scope' => 'company'],
        'leaves.create'             => ['module' => 'leaves', 'action' => 'create', 'name' => 'Apply for Leave', 'desc' => 'Submit leave requests and applications', 'default_scope' => 'company'],
        'leaves.endorse'            => ['module' => 'leaves', 'action' => 'endorse', 'name' => 'Endorse Leave Application', 'desc' => 'Tier 1 supervisor endorsement of team member leaves', 'default_scope' => 'team'],
        'leaves.approve'            => ['module' => 'leaves', 'action' => 'approve', 'name' => 'Approve Leave Application', 'desc' => 'Tier 2 HR/Admin approval of leave applications', 'default_scope' => 'company'],
        'leaves.reject'             => ['module' => 'leaves', 'action' => 'reject', 'name' => 'Reject Leave Application', 'desc' => 'Decline leave requests with mandatory reason', 'default_scope' => 'company'],
        'leaves.cancel'             => ['module' => 'leaves', 'action' => 'cancel', 'name' => 'Cancel Leave Application', 'desc' => 'Revoke approved or pending leave requests', 'default_scope' => 'company'],
        'leaves.adjust'             => ['module' => 'leaves', 'action' => 'adjust', 'name' => 'Adjust Leave Quota', 'desc' => 'Credit or debit employee leave quota balances manually', 'default_scope' => 'company'],
        'leaves.balance_adjust'     => ['module' => 'leaves', 'action' => 'balance_adjust', 'name' => 'Balance Add/Adjust', 'desc' => 'Granular quota adjustments with payroll lock protection', 'default_scope' => 'company'],
        'leaves.encash'             => ['module' => 'leaves', 'action' => 'encash', 'name' => 'Encash Leave Balance', 'desc' => 'Request or disburse leave balance encashment', 'default_scope' => 'company'],
        'leaves.export'             => ['module' => 'leaves', 'action' => 'export', 'name' => 'Export Leave Ledgers', 'desc' => 'Export leave transaction ledger and yearly balances', 'default_scope' => 'company'],
        'leaves.manage'             => ['module' => 'leaves', 'action' => 'manage', 'name' => 'Manage Leave Policies', 'desc' => 'Define leave types, eligibility rules, and accrual policies', 'default_scope' => 'company'],
        'leaves.override_tier'      => ['module' => 'leaves', 'action' => 'override_tier', 'name' => 'Override Approval Tier', 'desc' => 'Final-approve leave without Tier-1 endorsement (emergency/admin override)', 'default_scope' => 'company'],
        'leaves.closing_reopen'     => ['module' => 'leaves', 'action' => 'closing_reopen', 'name' => 'Reopen Closed Leave Year', 'desc' => 'Reopen a finalized and closed leave fiscal year for audit adjustments', 'default_scope' => 'company'],
        'leaves.hr_approve'         => ['module' => 'leaves', 'action' => 'hr_approve', 'name' => 'HR Leave Approval', 'desc' => 'Final HR approval/sanction step for multi-tier leave applications', 'default_scope' => 'company'],

        // Payroll
        'payroll.view'              => ['module' => 'payroll', 'action' => 'view', 'name' => 'View Payroll', 'desc' => 'View payroll batches, salary sheets, and payslips', 'default_scope' => 'company'],
        'payroll.view_all'          => ['module' => 'payroll', 'action' => 'view_all', 'name' => 'View All Payroll', 'desc' => 'View organization-wide payroll records across all branches', 'default_scope' => 'company'],
        'payroll.lock'              => ['module' => 'payroll', 'action' => 'lock', 'name' => 'Lock Payroll Batch', 'desc' => 'Lock monthly payroll batch against modifications', 'default_scope' => 'company'],
        'payroll.create'            => ['module' => 'payroll', 'action' => 'create', 'name' => 'Create Payroll Batch', 'desc' => 'Initialize monthly payroll cycle records', 'default_scope' => 'company'],
        'payroll.edit'              => ['module' => 'payroll', 'action' => 'edit', 'name' => 'Edit Payroll Items', 'desc' => 'Adjust individual salary component amounts before locking', 'default_scope' => 'company'],
        'payroll.generate'          => ['module' => 'payroll', 'action' => 'generate', 'name' => 'Generate Payroll Batch', 'desc' => 'Execute salary computations and automated payroll runs', 'default_scope' => 'company'],
        'payroll.run'               => ['module' => 'payroll', 'action' => 'run', 'name' => 'Execute Payroll Calculations', 'desc' => 'Run salary calculations, tax estimations, and PF basis', 'default_scope' => 'company'],
        'payroll.approve'           => ['module' => 'payroll', 'action' => 'approve', 'name' => 'Approve & Lock Payroll', 'desc' => 'Advance payroll approval stages and lock batches', 'default_scope' => 'company'],
        'payroll.disburse'          => ['module' => 'payroll', 'action' => 'disburse', 'name' => 'Disburse Salaries', 'desc' => 'Mark payroll batch as paid and disburse salaries', 'default_scope' => 'company'],
        'payroll.delete'            => ['module' => 'payroll', 'action' => 'delete', 'name' => 'Delete Payroll Batch', 'desc' => 'Delete draft unapproved payroll batches', 'default_scope' => 'company'],
        'payroll.export'            => ['module' => 'payroll', 'action' => 'export', 'name' => 'Export Bank Sheets', 'desc' => 'Generate bank payment export files and payslip PDFs', 'default_scope' => 'company'],
        'payroll.manage'            => ['module' => 'payroll', 'action' => 'manage', 'name' => 'Manage Payroll Engine', 'desc' => 'Configure salary structures, tax slabs, and PF policies', 'default_scope' => 'company'],
        'payroll.adjust'            => ['module' => 'payroll', 'action' => 'adjust', 'name' => 'Adjust Payroll', 'desc' => 'Apply manual adjustments to generated payroll items', 'default_scope' => 'company'],
        'payroll.loans'             => ['module' => 'payroll', 'action' => 'loans', 'name' => 'Grant Loans & Advances via Payroll', 'desc' => 'Grant salary loans/advances and view amortization from payroll screens', 'default_scope' => 'company'],

        // Provident Fund
        'pf.view'                   => ['module' => 'pf', 'action' => 'view', 'name' => 'View Provident Fund', 'desc' => 'View provident fund summary, ledger accumulation, and census', 'default_scope' => 'company'],
        'pf.export'                 => ['module' => 'pf', 'action' => 'export', 'name' => 'Export Provident Fund', 'desc' => 'Export provident fund summary and details reports', 'default_scope' => 'company'],
        'pf.manage'                 => ['module' => 'pf', 'action' => 'manage', 'name' => 'Manage Provident Fund', 'desc' => 'Manage employee PF enrolments and configurations', 'default_scope' => 'company'],

        // Bonus
        'bonus.view'                => ['module' => 'bonus', 'action' => 'view', 'name' => 'View Bonus Runs', 'desc' => 'View bonus batches and disbursement records', 'default_scope' => 'company'],
        'bonus.create'              => ['module' => 'bonus', 'action' => 'create', 'name' => 'Calculate Bonus Batch', 'desc' => 'Generate festival or performance bonus runs', 'default_scope' => 'company'],
        'bonus.edit'                => ['module' => 'bonus', 'action' => 'edit', 'name' => 'Edit Bonus Amounts', 'desc' => 'Modify employee bonus amounts before disbursement', 'default_scope' => 'company'],
        'bonus.approve'             => ['module' => 'bonus', 'action' => 'approve', 'name' => 'Approve Bonus Batch', 'desc' => 'Approve bonus disbursements for payment', 'default_scope' => 'company'],
        'bonus.delete'              => ['module' => 'bonus', 'action' => 'delete', 'name' => 'Delete Bonus Batch', 'desc' => 'Delete unapproved bonus batches', 'default_scope' => 'company'],
        'bonus.export'              => ['module' => 'bonus', 'action' => 'export', 'name' => 'Export Bonus Records', 'desc' => 'Export bonus payment sheets to CSV', 'default_scope' => 'company'],
        'bonus.manage'              => ['module' => 'bonus', 'action' => 'manage', 'name' => 'Manage Bonus Schemes', 'desc' => 'Configure bonus types and calculation parameters', 'default_scope' => 'company'],

        // Loans & Advances
        'loans.view'                => ['module' => 'loans', 'action' => 'view', 'name' => 'View Loans & Advances', 'desc' => 'View loan applications, repayment schedules, and ledgers', 'default_scope' => 'company'],
        'loans.create'              => ['module' => 'loans', 'action' => 'create', 'name' => 'Apply for Loan/Advance', 'desc' => 'Submit salary advance or company loan request', 'default_scope' => 'company'],
        'loans.edit'                => ['module' => 'loans', 'action' => 'edit', 'name' => 'Edit Loan Repayment', 'desc' => 'Modify installment amount or repayment terms', 'default_scope' => 'company'],
        'loans.approve'             => ['module' => 'loans', 'action' => 'approve', 'name' => 'Approve Loan/Advance', 'desc' => 'Authorize loan disbursement and installment plan', 'default_scope' => 'company'],
        'loans.delete'              => ['module' => 'loans', 'action' => 'delete', 'name' => 'Cancel Loan', 'desc' => 'Cancel or purge loan request', 'default_scope' => 'company'],
        'loans.export'              => ['module' => 'loans', 'action' => 'export', 'name' => 'Export Loan Statements', 'desc' => 'Export loan ledgers and deduction statements', 'default_scope' => 'company'],
        'loans.manage'              => ['module' => 'loans', 'action' => 'manage', 'name' => 'Manage Loan Policies', 'desc' => 'Configure maximum loan limits, interest rates, and tenures', 'default_scope' => 'company'],

        // Company Expenses
        'company_expense.view'      => ['module' => 'company_expense', 'action' => 'view', 'name' => 'View Expenses', 'desc' => 'View corporate expense requests and settlement vouchers', 'default_scope' => 'company'],
        'company_expense.create'    => ['module' => 'company_expense', 'action' => 'create', 'name' => 'Submit Expense Claim', 'desc' => 'Submit business expense vouchers with receipts', 'default_scope' => 'company'],
        'company_expense.edit'      => ['module' => 'company_expense', 'action' => 'edit', 'name' => 'Edit Expense Claim', 'desc' => 'Modify voucher amounts and attached documents', 'default_scope' => 'company'],
        'company_expense.approve'   => ['module' => 'company_expense', 'action' => 'approve', 'name' => 'Approve Expense Claim', 'desc' => 'Authorize expense claims through multi-tier workflow', 'default_scope' => 'company'],
        'company_expense.delete'    => ['module' => 'company_expense', 'action' => 'delete', 'name' => 'Cancel / Delete Expense', 'desc' => 'Purge rejected expense claims', 'default_scope' => 'company'],
        'company_expense.export'    => ['module' => 'company_expense', 'action' => 'export', 'name' => 'Export Expense Sheets', 'desc' => 'Export expense ledgers and payment receipts to CSV', 'default_scope' => 'company'],
        'company_expense.manage'    => ['module' => 'company_expense', 'action' => 'manage', 'name' => 'Manage Expense Categories', 'desc' => 'Configure expense categories, caps, and approval tiers', 'default_scope' => 'company'],
        'expenses.view'             => ['module' => 'expenses', 'action' => 'view', 'name' => 'View Expenses', 'desc' => 'View corporate expense requests and settlement vouchers', 'default_scope' => 'company'],
        'expenses.create'           => ['module' => 'expenses', 'action' => 'create', 'name' => 'Submit Expense Claim', 'desc' => 'Submit business expense vouchers with receipts', 'default_scope' => 'company'],
        'expenses.edit'             => ['module' => 'expenses', 'action' => 'edit', 'name' => 'Edit Expense Claim', 'desc' => 'Modify voucher amounts and attached documents', 'default_scope' => 'company'],
        'expenses.approve'          => ['module' => 'expenses', 'action' => 'approve', 'name' => 'Approve Expense Claim', 'desc' => 'Authorize expense claims through multi-tier workflow', 'default_scope' => 'company'],
        'expenses.delete'           => ['module' => 'expenses', 'action' => 'delete', 'name' => 'Cancel / Delete Expense', 'desc' => 'Purge rejected expense claims', 'default_scope' => 'company'],
        'expenses.export'           => ['module' => 'expenses', 'action' => 'export', 'name' => 'Export Expense Sheets', 'desc' => 'Export expense ledgers and payment receipts to CSV', 'default_scope' => 'company'],
        'expenses.manage'           => ['module' => 'expenses', 'action' => 'manage', 'name' => 'Manage Expense Categories', 'desc' => 'Configure expense categories, caps, and approval tiers', 'default_scope' => 'company'],

        // Medical Insurance
        'medical_insurance.view'    => ['module' => 'medical_insurance', 'action' => 'view', 'name' => 'View Medical Insurance', 'desc' => 'Inspect insurance plans, providers, enrollments, and claims', 'default_scope' => 'company'],
        'medical_insurance.create'  => ['module' => 'medical_insurance', 'action' => 'create', 'name' => 'Create Insurance Records', 'desc' => 'Submit insurance claims or enroll staff in plans', 'default_scope' => 'company'],
        'medical_insurance.edit'    => ['module' => 'medical_insurance', 'action' => 'edit', 'name' => 'Edit Insurance Records', 'desc' => 'Modify provider data, enrollment tier, or claim info', 'default_scope' => 'company'],
        'medical_insurance.approve' => ['module' => 'medical_insurance', 'action' => 'approve', 'name' => 'Approve Insurance Claims', 'desc' => 'Settle and approve healthcare reimbursement claims', 'default_scope' => 'company'],
        'medical_insurance.delete'  => ['module' => 'medical_insurance', 'action' => 'delete', 'name' => 'Delete Insurance Records', 'desc' => 'Purge canceled claims or retired insurance plans', 'default_scope' => 'company'],
        'medical_insurance.export'  => ['module' => 'medical_insurance', 'action' => 'export', 'name' => 'Export Insurance Ledgers', 'desc' => 'Export healthcare coverage and claim reports to CSV', 'default_scope' => 'company'],
        'medical_insurance.manage'  => ['module' => 'medical_insurance', 'action' => 'manage', 'name' => 'Manage Insurance Policies', 'desc' => 'Full administration of corporate healthcare schemes', 'default_scope' => 'company'],
        'insurance.view'            => ['module' => 'insurance', 'action' => 'view', 'name' => 'View Medical Insurance', 'desc' => 'Inspect insurance plans, providers, enrollments, and claims', 'default_scope' => 'company'],
        'insurance.create'          => ['module' => 'insurance', 'action' => 'create', 'name' => 'Create Insurance Records', 'desc' => 'Submit insurance claims or enroll staff in plans', 'default_scope' => 'company'],
        'insurance.edit'            => ['module' => 'insurance', 'action' => 'edit', 'name' => 'Edit Insurance Records', 'desc' => 'Modify provider data, enrollment tier, or claim info', 'default_scope' => 'company'],
        'insurance.approve'         => ['module' => 'insurance', 'action' => 'approve', 'name' => 'Approve Insurance Claims', 'desc' => 'Settle and approve healthcare reimbursement claims', 'default_scope' => 'company'],
        'insurance.delete'          => ['module' => 'insurance', 'action' => 'delete', 'name' => 'Delete Insurance Records', 'desc' => 'Purge canceled claims or retired insurance plans', 'default_scope' => 'company'],
        'insurance.export'          => ['module' => 'insurance', 'action' => 'export', 'name' => 'Export Insurance Ledgers', 'desc' => 'Export healthcare coverage and claim reports to CSV', 'default_scope' => 'company'],
        'insurance.manage'          => ['module' => 'insurance', 'action' => 'manage', 'name' => 'Manage Insurance Policies', 'desc' => 'Full administration of corporate healthcare schemes', 'default_scope' => 'company'],

        // Assets
        'assets.view'               => ['module' => 'assets', 'action' => 'view', 'name' => 'View Company Assets', 'desc' => 'View equipment inventory and employee asset handovers', 'default_scope' => 'company'],
        'assets.create'             => ['module' => 'assets', 'action' => 'create', 'name' => 'Add Company Asset', 'desc' => 'Register new hardware, vehicles, or equipment', 'default_scope' => 'company'],
        'assets.edit'               => ['module' => 'assets', 'action' => 'edit', 'name' => 'Edit Asset Details', 'desc' => 'Update asset serial numbers, warranty, or condition', 'default_scope' => 'company'],
        'assets.delete'             => ['module' => 'assets', 'action' => 'delete', 'name' => 'Dispose / Delete Asset', 'desc' => 'Retire or remove asset records', 'default_scope' => 'company'],
        'assets.assign'             => ['module' => 'assets', 'action' => 'assign', 'name' => 'Allocate / Return Asset', 'desc' => 'Handover asset to employee or record asset return', 'default_scope' => 'company'],
        'assets.writeoff'           => ['module' => 'assets', 'action' => 'writeoff', 'name' => 'Write Off Asset', 'desc' => 'Retire asset with financial write-off or employee liability recovery', 'default_scope' => 'company'],
        'assets.export'             => ['module' => 'assets', 'action' => 'export', 'name' => 'Export Asset Inventory', 'desc' => 'Export equipment lists to CSV/PDF', 'default_scope' => 'company'],
        'assets.manage'             => ['module' => 'assets', 'action' => 'manage', 'name' => 'Manage Asset Categories', 'desc' => 'Configure asset categories, vendors, and policies', 'default_scope' => 'company'],

        // Training
        'training.view'             => ['module' => 'training', 'action' => 'view', 'name' => 'View Training Programs', 'desc' => 'Inspect training courses and enrolled employee records', 'default_scope' => 'company'],
        'training.create'           => ['module' => 'training', 'action' => 'create', 'name' => 'Create Training Course', 'desc' => 'Design new skills development workshops and courses', 'default_scope' => 'company'],
        'training.edit'             => ['module' => 'training', 'action' => 'edit', 'name' => 'Edit Training Program', 'desc' => 'Update course details, trainers, and schedules', 'default_scope' => 'company'],
        'training.delete'           => ['module' => 'training', 'action' => 'delete', 'name' => 'Delete Training Program', 'desc' => 'Remove scheduled training sessions', 'default_scope' => 'company'],
        'training.assign'           => ['module' => 'training', 'action' => 'assign', 'name' => 'Enroll Employees', 'desc' => 'Enroll staff in training programs and issue certificates', 'default_scope' => 'company'],
        'training.export'           => ['module' => 'training', 'action' => 'export', 'name' => 'Export Training Records', 'desc' => 'Export participant lists and training hours to CSV', 'default_scope' => 'company'],
        'training.manage'           => ['module' => 'training', 'action' => 'manage', 'name' => 'Manage Training Academy', 'desc' => 'Full control over corporate learning programs', 'default_scope' => 'company'],

        // Performance
        'performance.view'          => ['module' => 'performance', 'action' => 'view', 'name' => 'View Appraisals & KPIs', 'desc' => 'View performance review cycles and personal goals', 'default_scope' => 'company'],
        'performance.create'        => ['module' => 'performance', 'action' => 'create', 'name' => 'Submit KPI / Appraisal', 'desc' => 'Submit 360 reviews, goal self-evaluations, and KPIs', 'default_scope' => 'company'],
        'performance.edit'          => ['module' => 'performance', 'action' => 'edit', 'name' => 'Edit Review Feedback', 'desc' => 'Update scores, manager ratings, and goal milestones', 'default_scope' => 'company'],
        'performance.approve'       => ['module' => 'performance', 'action' => 'approve', 'name' => 'Approve Appraisals', 'desc' => 'Sign off on appraisal cycles and performance promotions', 'default_scope' => 'company'],
        'performance.delete'        => ['module' => 'performance', 'action' => 'delete', 'name' => 'Delete Appraisal Cycle', 'desc' => 'Purge review cycles or unsubmitted goals', 'default_scope' => 'company'],
        'performance.export'        => ['module' => 'performance', 'action' => 'export', 'name' => 'Export Performance Data', 'desc' => 'Export review matrices and scorecard metrics to CSV', 'default_scope' => 'company'],
        'performance.manage'        => ['module' => 'performance', 'action' => 'manage', 'name' => 'Manage Appraisal Cycles', 'desc' => 'Configure evaluation templates, rating scales, and promotion criteria', 'default_scope' => 'company'],

        // Recruitment
        'recruitment.view'          => ['module' => 'recruitment', 'action' => 'view', 'name' => 'View Job Pipeline', 'desc' => 'Inspect job openings and candidate applications', 'default_scope' => 'company'],
        'recruitment.create'        => ['module' => 'recruitment', 'action' => 'create', 'name' => 'Post Job Opening', 'desc' => 'Publish job openings and record applicants', 'default_scope' => 'company'],
        'recruitment.edit'          => ['module' => 'recruitment', 'action' => 'edit', 'name' => 'Update Candidate Stage', 'desc' => 'Move applicants across recruitment pipeline stages', 'default_scope' => 'company'],
        'recruitment.delete'        => ['module' => 'recruitment', 'action' => 'delete', 'name' => 'Close Job / Delete Applicant', 'desc' => 'Archive job positions and delete candidate profiles', 'default_scope' => 'company'],
        'recruitment.approve'       => ['module' => 'recruitment', 'action' => 'approve', 'name' => 'Convert to Employee', 'desc' => 'Convert selected candidate into an active employee', 'default_scope' => 'company'],
        'recruitment.export'        => ['module' => 'recruitment', 'action' => 'export', 'name' => 'Export Recruitment Data', 'desc' => 'Export candidate resumes and recruitment metrics to CSV', 'default_scope' => 'company'],
        'recruitment.manage'        => ['module' => 'recruitment', 'action' => 'manage', 'name' => 'Manage Hiring Pipeline', 'desc' => 'Full administrative governance over hiring stages', 'default_scope' => 'company'],

        // Reports
        'reports.view'              => ['module' => 'reports', 'action' => 'view', 'name' => 'View Reports Hub', 'desc' => 'Access enterprise analytics and reporting modules', 'default_scope' => 'company'],
        'reports.export'            => ['module' => 'reports', 'action' => 'export', 'name' => 'Export Analytical Reports', 'desc' => 'Export statutory reports and custom data summaries', 'default_scope' => 'company'],
        'reports.create'            => ['module' => 'reports', 'action' => 'create', 'name' => 'Upload Report Document', 'desc' => 'Upload compliance sheets and biometric punch logs', 'default_scope' => 'company'],
        'reports.delete'            => ['module' => 'reports', 'action' => 'delete', 'name' => 'Delete Stored Document', 'desc' => 'Purge uploaded audit documents and reports', 'default_scope' => 'company'],
        'reports.manage'            => ['module' => 'reports', 'action' => 'manage', 'name' => 'Manage Report Branding', 'desc' => 'Configure report header/footer branding and templates', 'default_scope' => 'company'],

        // Rules Engine
        'rules.view'                => ['module' => 'rules', 'action' => 'view', 'name' => 'View Business Rules', 'desc' => 'Inspect single-source business rule definitions and layer hierarchy', 'default_scope' => 'company'],
        'rules.manage'              => ['module' => 'rules', 'action' => 'manage', 'name' => 'Manage Business Rules', 'desc' => 'Create rule drafts, publish new versions, and archive rule sets', 'default_scope' => 'company'],

        // Notices & Bulletin
        'notices.view'              => ['module' => 'notices', 'action' => 'view', 'name' => 'View Notices', 'desc' => 'Read corporate announcements and bulletin notices', 'default_scope' => 'company'],
        'notices.create'            => ['module' => 'notices', 'action' => 'create', 'name' => 'Publish Notice', 'desc' => 'Post announcements to company or branch billboards', 'default_scope' => 'company'],
        'notices.edit'              => ['module' => 'notices', 'action' => 'edit', 'name' => 'Edit Notice', 'desc' => 'Update announcement content and targeting', 'default_scope' => 'company'],
        'notices.delete'            => ['module' => 'notices', 'action' => 'delete', 'name' => 'Delete Notice', 'desc' => 'Remove outdated bulletin notices', 'default_scope' => 'company'],
        'notices.publish'           => ['module' => 'notices', 'action' => 'publish', 'name' => 'Broadcast Notice', 'desc' => 'Publish company-wide announcements', 'default_scope' => 'company'],
        'notices.manage'            => ['module' => 'notices', 'action' => 'manage', 'name' => 'Manage Bulletin Board', 'desc' => 'Full administrative broadcast control', 'default_scope' => 'company'],

        // Notifications
        'notifications.view'        => ['module' => 'notifications', 'action' => 'view', 'name' => 'View Notifications', 'desc' => 'View in-app alerts and notifications stream', 'default_scope' => 'company'],
        'notifications.manage'      => ['module' => 'notifications', 'action' => 'manage', 'name' => 'Manage Alerts & Templates', 'desc' => 'Configure notification email templates and alert triggers', 'default_scope' => 'company'],

        // Master Data
        'master.view'               => ['module' => 'master', 'action' => 'view', 'name' => 'View Master Data', 'desc' => 'View branches, departments, designations, shifts, and holidays', 'default_scope' => 'company'],
        'master.create'             => ['module' => 'master', 'action' => 'create', 'name' => 'Create Master Records', 'desc' => 'Add new branch, department, designation, or shift', 'default_scope' => 'company'],
        'master.edit'               => ['module' => 'master', 'action' => 'edit', 'name' => 'Edit Master Records', 'desc' => 'Modify branch properties, department names, or shifts', 'default_scope' => 'company'],
        'master.delete'             => ['module' => 'master', 'action' => 'delete', 'name' => 'Delete Master Records', 'desc' => 'Remove unused master entities', 'default_scope' => 'company'],
        'master.manage'             => ['module' => 'master', 'action' => 'manage', 'name' => 'Manage Master Infrastructure', 'desc' => 'Full administrative control over organizational hierarchy', 'default_scope' => 'company'],

        // Users & Roles (RBAC Suite)
        'user.view'                 => ['module' => 'user', 'action' => 'view', 'name' => 'View User Accounts', 'desc' => 'Inspect registered system users and login history', 'default_scope' => 'company'],
        'user.create'               => ['module' => 'user', 'action' => 'create', 'name' => 'Provision User Accounts', 'desc' => 'Create new user logins and bind to employee profiles', 'default_scope' => 'company'],
        'user.edit'                 => ['module' => 'user', 'action' => 'edit', 'name' => 'Edit User Accounts', 'desc' => 'Update usernames, emails, and reset passwords', 'default_scope' => 'company'],
        'user.delete'               => ['module' => 'user', 'action' => 'delete', 'name' => 'Deactivate / Delete Users', 'desc' => 'Suspend or delete user logins', 'default_scope' => 'company'],
        'user.manage'               => ['module' => 'user', 'action' => 'manage', 'name' => 'Manage User Accounts', 'desc' => 'Full administrative control over user accounts', 'default_scope' => 'company'],
        'users.view'                => ['module' => 'users', 'action' => 'view', 'name' => 'View User Accounts', 'desc' => 'Inspect registered system users and login history', 'default_scope' => 'company'],
        'users.create'              => ['module' => 'users', 'action' => 'create', 'name' => 'Provision User Accounts', 'desc' => 'Create new user logins and bind to employee profiles', 'default_scope' => 'company'],
        'users.edit'                => ['module' => 'users', 'action' => 'edit', 'name' => 'Edit User Accounts', 'desc' => 'Update usernames, emails, and reset passwords', 'default_scope' => 'company'],
        'users.delete'              => ['module' => 'users', 'action' => 'delete', 'name' => 'Deactivate / Delete Users', 'desc' => 'Suspend or delete user logins', 'default_scope' => 'company'],
        'users.manage'              => ['module' => 'users', 'action' => 'manage', 'name' => 'Manage User Accounts', 'desc' => 'Full administrative control over user accounts', 'default_scope' => 'company'],

        'role.view'                 => ['module' => 'role', 'action' => 'view', 'name' => 'View RBAC Roles', 'desc' => 'View role definitions, permissions, and visibility trees', 'default_scope' => 'company'],
        'role.create'               => ['module' => 'role', 'action' => 'create', 'name' => 'Create RBAC Roles', 'desc' => 'Define new custom tenant roles with zero initial permissions', 'default_scope' => 'company'],
        'role.edit'                 => ['module' => 'role', 'action' => 'edit', 'name' => 'Edit RBAC Roles', 'desc' => 'Modify role names and descriptions', 'default_scope' => 'company'],
        'role.manage'               => ['module' => 'role', 'action' => 'manage', 'name' => 'Manage RBAC Matrix', 'desc' => 'Configure role permissions matrix, overrides, and role lifecycles', 'default_scope' => 'company'],
        'roles.view'                => ['module' => 'roles', 'action' => 'view', 'name' => 'View RBAC Roles', 'desc' => 'View role definitions, permissions, and visibility trees', 'default_scope' => 'company'],
        'roles.create'              => ['module' => 'roles', 'action' => 'create', 'name' => 'Create RBAC Roles', 'desc' => 'Define new custom tenant roles with zero initial permissions', 'default_scope' => 'company'],
        'roles.edit'                => ['module' => 'roles', 'action' => 'edit', 'name' => 'Edit RBAC Roles', 'desc' => 'Modify role names and descriptions', 'default_scope' => 'company'],
        'roles.delete'              => ['module' => 'roles', 'action' => 'delete', 'name' => 'Delete RBAC Roles', 'desc' => 'Remove custom tenant roles', 'default_scope' => 'company'],
        'roles.manage'              => ['module' => 'roles', 'action' => 'manage', 'name' => 'Manage RBAC Matrix', 'desc' => 'Configure role permissions matrix, overrides, and role lifecycles', 'default_scope' => 'company'],
        'rbac.view'                 => ['module' => 'rbac', 'action' => 'view', 'name' => 'View RBAC Governance', 'desc' => 'View user overrides and permission matrix', 'default_scope' => 'company'],
        'rbac.assign'               => ['module' => 'rbac', 'action' => 'assign', 'name' => 'Assign Roles & Overrides', 'desc' => 'Grant or deny individual permissions to users or roles', 'default_scope' => 'company'],

        // Email Module
        'email.smtp.view'           => ['module' => 'email', 'action' => 'view', 'name' => 'View SMTP Settings', 'desc' => 'Inspect company SMTP and email transport configuration', 'default_scope' => 'company'],
        'email.smtp.edit'           => ['module' => 'email', 'action' => 'edit', 'name' => 'Edit SMTP Settings', 'desc' => 'Configure company SMTP host, credentials, and test connection', 'default_scope' => 'company'],
        'email.template.view'       => ['module' => 'email', 'action' => 'view', 'name' => 'View Email Templates', 'desc' => 'View system and notification email templates', 'default_scope' => 'company'],
        'email.template.edit'       => ['module' => 'email', 'action' => 'edit', 'name' => 'Edit Email Templates', 'desc' => 'Modify notification email template placeholders and content', 'default_scope' => 'company'],

        // Settings & Governance
        'settings.view'             => ['module' => 'settings', 'action' => 'view', 'name' => 'View Company Settings', 'desc' => 'Inspect company profile, branding, and timezone settings', 'default_scope' => 'company'],
        'settings.edit'             => ['module' => 'settings', 'action' => 'edit', 'name' => 'Edit Company Settings', 'desc' => 'Modify company branding, logo, and general preferences', 'default_scope' => 'company'],
        'settings.manage'           => ['module' => 'settings', 'action' => 'manage', 'name' => 'Manage Governance Settings', 'desc' => 'Configure system safeguards, email templates, and backups', 'default_scope' => 'company'],

        // Security & Audit
        'audit.view'                => ['module' => 'audit', 'action' => 'view', 'name' => 'View Audit Logs', 'desc' => 'Inspect immutable system audit trails', 'default_scope' => 'company'],
        'audit.export'              => ['module' => 'audit', 'action' => 'export', 'name' => 'Export Audit Logs', 'desc' => 'Export immutable system audit trails to CSV', 'default_scope' => 'company'],
        'security.view'             => ['module' => 'security', 'action' => 'view', 'name' => 'View Security Audit', 'desc' => 'Inspect audit logs, login history, and security telemetry', 'default_scope' => 'company'],
        'security.manage'           => ['module' => 'security', 'action' => 'manage', 'name' => 'Manage Security Policies', 'desc' => 'Configure password complexity, session timeouts, and MFA', 'default_scope' => 'company'],
        'system_audit.view'         => ['module' => 'system_audit', 'action' => 'view', 'name' => 'View Forensic Audit', 'desc' => 'Examine forensic audit trail and access decision events', 'default_scope' => 'company'],
        'system_audit.manage'       => ['module' => 'system_audit', 'action' => 'manage', 'name' => 'Manage Audit Storage', 'desc' => 'Configure audit archival and log rotation policies', 'default_scope' => 'company'],

        // System Kernel (Platform only)
        'system.view'               => ['module' => 'system', 'action' => 'view', 'name' => 'View System Status', 'desc' => 'Inspect application runtime status and scheduled job logs', 'default_scope' => 'all', 'is_platform' => 1],
        'system.manage'             => ['module' => 'system', 'action' => 'manage', 'name' => 'Manage Platform Kernel', 'desc' => 'Database diagnostics, scheduled job runners, and system upgrades', 'default_scope' => 'all', 'is_platform' => 1],
        'system.delete'             => ['module' => 'system', 'action' => 'delete', 'name' => 'Purge System Logs', 'desc' => 'Purge historical execution logs and telemetry', 'default_scope' => 'all', 'is_platform' => 1],
        'platform.admin'            => ['module' => 'platform', 'action' => 'admin', 'name' => 'Platform Administration', 'desc' => 'Cross-tenant management, company provisioning, and tenant activation', 'default_scope' => 'all', 'is_platform' => 1],
    ];

    /**
     * Platform-only permissions restricted exclusively to software_app_admin
     */
    public array $platformOnlyPermissions = [
        'system.view',
        'system.manage',
        'system.delete',
        'company.create',
        'company.provision',
        'company.delete',
        'companies.create',
        'companies.delete',
        'platform.admin',
        'module_toggle.manage',
        'global_rbac.manage',
        'global_security.view',
        'global_security.manage',
    ];

    /**
     * Canonical Default Role x Permission Matrix (Section 4 of MASTER_INSTRUCTION_RBAC_and_Attendance.md).
     * Root roles (software_app_admin, company_admin) are evaluated via root rules.
     * Employee has 0 permissions in the matrix (own-data self-service is implicit).
     */
    public array $roleDefaultMatrix = [
        'hr_admin' => [
            'scope' => 'company',
            'permissions' => [
                'dashboard.view', 'dashboard.manage',
                'directory.view', 'directory.create', 'directory.edit', 'directory.export',
                'organogram.view', 'organogram.manage',
                'directory.transfer', 'directory.promote', 'directory.terminate', 'directory.approve_resignation',
                'employee.transfer', 'employee.promote', 'employee.terminate', 'employee.approve_resignation',
                'employees.view', 'employees.create', 'employees.edit', 'employees.export',
                'employees.probation', 'employees.movement', 'employees.separate',
                'employee.export', 'employee.view_salary', 'employee.view_sensitive',
                'employees.view_salary', 'employees.view_sensitive',
                'attendance.view', 'attendance.create', 'attendance.edit', 'attendance.approve',
                'attendance.regularize_approve', 'attendance.export', 'attendance.manage',
                'attendance.early_closure_manage', 'attendance.device_manage', 'zkteco.view', 'zkteco.manage',
                'overtime.view', 'overtime.approve', 'overtime.export', 'overtime.manage',
                'rostering.view', 'rostering.create', 'rostering.edit', 'rostering.publish',
                'leaves.view', 'leaves.create', 'leaves.endorse', 'leaves.approve', 'leaves.reject',
                'leaves.export', 'leaves.manage', 'leaves.balance_adjust', 'leaves.closing_reopen', 'leave.closing_reopen',
                'leave.view', 'leave.view_all', 'leaves.view_all', 'leave.create', 'leave.endorse', 'leave.approve', 'leave.reject',
                'leave.cancel', 'leaves.cancel', 'leave.adjust', 'leaves.adjust', 'leave.encash', 'leaves.encash', 'leave.export', 'leave.manage',
                'leave.override_tier', 'leaves.override_tier', 'leave.balance_adjust',
                'leave.hr_approve', 'leaves.hr_approve',
                'payroll.view', 'payroll.view_all', 'payroll.create', 'payroll.edit', 'payroll.manage',
                'payroll.generate', 'payroll.run', 'payroll.approve', 'payroll.disburse', 'payroll.adjust',
                'payroll.lock', 'payroll.export', 'payroll.loans',
                'pf.view', 'pf.export', 'pf.manage',
                'bonus.view', 'bonus.approve', 'loans.view', 'expenses.view',
                'insurance.view', 'insurance.manage',
                'assets.view', 'assets.create', 'assets.edit', 'assets.delete', 'assets.assign', 'assets.writeoff', 'assets.export', 'assets.manage',
                'training.view', 'training.create', 'training.edit', 'training.manage',
                'performance.view', 'performance.create', 'performance.edit', 'performance.manage',
                'recruitment.view', 'recruitment.create', 'recruitment.edit', 'recruitment.manage',
                'notices.view', 'notices.create', 'notices.edit', 'notices.publish',
                'reports.view', 'reports.export',
                'rules.view', 'rules.manage',
                'audit.view',
            ],
        ],
        'hr_officer' => [
            'scope' => 'company',
            'permissions' => [
                'directory.view', 'directory.create', 'directory.edit',
                'organogram.view',
                'employees.view', 'employees.create', 'employees.edit',
                'attendance.view', 'attendance.create', 'attendance.edit', 'attendance.export',
                'overtime.view', 'overtime.create',
                'rostering.view', 'rostering.create', 'rostering.edit',
                'leaves.view', 'leaves.create', 'leaves.endorse', 'leaves.export',
                'insurance.view',
                'assets.view', 'assets.create', 'assets.edit', 'assets.assign', 'assets.export',
                'training.view', 'training.create', 'training.edit',
                'performance.view', 'performance.create', 'performance.edit',
                'recruitment.view',
                'notices.view', 'notices.create',
                'reports.view', 'reports.export',
            ],
        ],
        'branch_manager' => [
            'scope' => 'branch',
            'permissions' => [
                'directory.view', 'directory.edit', 'organogram.view', 'employees.view', 'employees.edit',
                'attendance.view', 'attendance.approve', 'attendance.regularize_approve', 'attendance.export',
                'overtime.view', 'overtime.approve',
                'rostering.view', 'rostering.create', 'rostering.edit', 'rostering.publish',
                'leaves.view', 'leaves.endorse', 'leaves.approve', 'leaves.reject',
                'assets.view', 'assets.assign', 'assets.export',
                'training.view', 'training.create', 'training.edit',
                'performance.view', 'performance.create', 'performance.edit',
                'notices.view',
                'reports.view', 'reports.export',
            ],
        ],
        'finance' => [
            'scope' => 'company',
            'permissions' => [
                'directory.view', 'organogram.view', 'employees.view', 'employee.view_salary', 'employees.view_salary',
                'attendance.view', 'attendance.export',
                'overtime.view', 'overtime.export',
                'leaves.view',
                'payroll.view', 'payroll.create', 'payroll.edit', 'payroll.generate',
                'payroll.run', 'payroll.approve', 'payroll.disburse', 'payroll.export',
                'pf.view', 'pf.export', 'pf.manage',
                'bonus.view', 'bonus.create', 'bonus.edit', 'bonus.approve', 'bonus.export',
                'loans.view', 'loans.create', 'loans.edit', 'loans.approve', 'loans.export',
                'expenses.view', 'expenses.create', 'expenses.edit', 'expenses.approve', 'expenses.export',
                'insurance.view', 'insurance.export',
                'assets.view', 'assets.export',
                'notices.view',
                'reports.view', 'reports.export',
            ],
        ],
        'manager' => [
            'scope' => 'team',
            'permissions' => [
                'directory.view', 'organogram.view', 'employees.view',
                'attendance.view', 'attendance.approve', 'attendance.regularize_approve',
                'overtime.view', 'overtime.approve',
                'rostering.view',
                'leaves.view', 'leaves.endorse', 'leaves.approve', 'leaves.reject',
                'training.view', 'training.create', 'training.edit',
                'performance.view', 'performance.create', 'performance.edit',
                'recruitment.view', 'recruitment.create',
                'notices.view',
                'reports.view',
            ],
        ],
        'team_leader' => [
            'scope' => 'team',
            'permissions' => [
                'directory.view', 'organogram.view', 'employees.view',
                'attendance.view',
                'overtime.view', 'overtime.recommend',
                'leaves.view', 'leaves.endorse',
                'training.view', 'training.create',
                'performance.view', 'performance.create',
                'notices.view',
            ],
        ],
        'auditor' => [
            'scope' => 'company',
            'permissions' => [
                'directory.view', 'directory.export', 'organogram.view',
                'employees.view', 'employees.export',
                'attendance.view', 'attendance.export',
                'overtime.view', 'overtime.export',
                'rostering.view',
                'leaves.view', 'leaves.export',
                'payroll.view', 'payroll.export',
                'pf.view', 'pf.export',
                'bonus.view', 'bonus.export',
                'loans.view', 'loans.export',
                'expenses.view', 'expenses.export',
                'insurance.view', 'insurance.export',
                'assets.view',
                'training.view', 'performance.view',
                'recruitment.view',
                'notices.view',
                'reports.view', 'reports.export',
                'audit.view', 'audit.export',
                'users.view', 'roles.view', 'rbac.view',
                'settings.view',
            ],
        ],
        'employee' => [
            'scope' => 'self',
            'permissions' => [
                'dashboard.view',
                'directory.view',
                'attendance.view', 'attendance.clock', 'attendance.regularize',
                'rostering.view',
                'leaves.view', 'leaves.create', 'leaves.cancel',
                'payroll.view',
                'bonus.view',
                'loans.view', 'loans.create',
                'assets.view',
                'training.view',
                'performance.view', 'performance.create',
                'medical_insurance.view', 'medical_insurance.create',
                'company_expense.view', 'company_expense.create',
                'notices.view',
                'notifications.view',
            ],
        ],
    ];

    public function __construct()
    {
        parent::__construct();
        $this->permissionsCatalogue = &$this->catalogue;
    }
}
