<?php

namespace Config;

use CodeIgniter\Database\Config;

/**
 * Database Configuration
 */
class Database extends Config
{
    /**
     * The directory that contains the Seeds directory.
     */
    public string $filesPath = APPPATH . 'Database' . DIRECTORY_SEPARATOR;

    /**
     * The default database connection group.
     */
    public string $defaultGroup = 'default';

    /**
     * The default database connection parameters.
     */
    public array $default = [
        'DSN'          => '',
        'hostname'     => 'localhost',
        'username'     => 'root',
        'password'     => '',
        'database'     => 'hr_manage',
        'DBDriver'     => 'MySQLi',
        'DBPrefix'     => '',
        'pConnect'     => false,
        'DBDebug'      => true,
        'charset'      => 'utf8mb4',
        'DBCollat'     => 'utf8mb4_unicode_ci',
        'swapPre'      => '',
        'encrypt'      => false,
        'compress'     => false,
        'strictOn'     => false,
        'failover'     => [],
        'port'         => 3306,
        'numberNative' => false,
        'dateFormat'   => [
            'date'     => 'Y-m-d',
            'datetime' => 'Y-m-d H:i:s',
            'time'     => 'H:i:s',
        ],
    ];

    /**
     * This database connection is used when
     * running PHPUnit database tests.
     */
    public array $tests = [
        'DSN'         => '',
        'hostname'    => '127.0.0.1',
        'username'    => '',
        'password'    => '',
        'database'    => ':memory:',
        'DBDriver'    => 'SQLite3',
        'DBPrefix'    => '',
        'pConnect'    => false,
        'DBDebug'     => true,
        'charset'     => 'utf8',
        'DBCollat'    => '',
        'swapPre'     => '',
        'encrypt'     => false,
        'compress'    => false,
        'strictOn'    => false,
        'failover'    => [],
        'port'        => 3306,
        'foreignKeys' => true,
        'busyTimeout' => 1000,
        'dateFormat'  => [
            'date'     => 'Y-m-d',
            'datetime' => 'Y-m-d H:i:s',
            'time'     => 'H:i:s',
        ],
    ];

    public function __construct()
    {
        parent::__construct();

        // Environment overrides
        if ($envHost = getenv('database.default.hostname')) {
            $this->default['hostname'] = $envHost;
        }
        if ($envUser = getenv('database.default.username')) {
            $this->default['username'] = $envUser;
        }
        if (($envPass = getenv('database.default.password')) !== false && $envPass !== null) {
            $this->default['password'] = $envPass;
        }
        if ($envDb = getenv('database.default.database') ?: getenv('DB_DATABASE')) {
            $this->default['database'] = $envDb;
        }
        if ($envPort = getenv('database.default.port')) {
            $this->default['port'] = (int)$envPort;
        }

        if (defined('ENVIRONMENT')) {
            $this->default['DBDebug'] = (ENVIRONMENT !== 'production');
            if (ENVIRONMENT === 'testing') {
                $this->defaultGroup = 'tests';
            }
        }
    }
}
