<?php

namespace App\Services;

use App\Models\SystemSettingModel;
use Config\Services;

class SmtpConfigResolver
{
    public const SMTP_KEYS = [
        'smtp_host',
        'smtp_port',
        'smtp_user',
        'smtp_pass',
        'smtp_crypto',
        'from_email',
        'from_name',
        'reply_to_email',
        'smtp_is_active',
        'smtp_timeout',
    ];

    public const DEFAULTS = [
        'smtp_host'       => 'smtp.example.com',
        'smtp_port'       => '587',
        'smtp_user'       => 'apikey',
        'smtp_pass'       => '',
        'smtp_crypto'     => 'tls',
        'from_email'      => 'hrms-noreply@enterprise.internal',
        'from_name'       => 'Corporate Smart HRMS',
        'reply_to_email'  => 'support@corporate.com',
        'smtp_is_active'  => '1',
        'smtp_timeout'    => '10',
    ];

    /**
     * Resolve SMTP configuration for a company with fallback to global settings.
     *
     * Hierarchy:
     * 1. Company-specific config (company_id = $companyId)
     * 2. Global platform config (company_id IS NULL or '')
     * 3. System hardcoded defaults
     *
     * @param string|null $companyId
     * @param bool $decryptPassword Whether to decrypt smtp_pass in returned array
     * @return array
     */
    public static function resolve(?string $companyId = null, bool $decryptPassword = true): array
    {
        $settingModel = new SystemSettingModel();

        // 1. Fetch Global Settings (company_id IS NULL or empty)
        $globalConfig = [];
        try {
            $globalRows = $settingModel
                ->whereIn('setting_key', self::SMTP_KEYS)
                ->groupStart()
                    ->where('company_id', null)
                    ->orWhere('company_id', '')
                ->groupEnd()
                ->findAll();

            foreach ($globalRows as $row) {
                if (in_array($row['setting_key'], self::SMTP_KEYS, true)) {
                    $globalConfig[$row['setting_key']] = $row['setting_value'];
                }
            }
        } catch (\Throwable $e) {
            log_message('warning', 'SmtpConfigResolver: Failed to fetch global settings: ' . $e->getMessage());
        }

        // 2. Fetch Company-Specific Settings
        $companyConfig = [];
        $hasCompanyConfig = false;
        if (!empty($companyId)) {
            try {
                $companyRows = $settingModel
                    ->whereIn('setting_key', self::SMTP_KEYS)
                    ->where('company_id', $companyId)
                    ->findAll();

                foreach ($companyRows as $row) {
                    if (in_array($row['setting_key'], self::SMTP_KEYS, true)) {
                        $companyConfig[$row['setting_key']] = $row['setting_value'];
                        $hasCompanyConfig = true;
                    }
                }
            } catch (\Throwable $e) {
                log_message('warning', 'SmtpConfigResolver: Failed to fetch company settings for ' . $companyId . ': ' . $e->getMessage());
            }
        }

        // 3. Merge: Defaults -> Global -> Company
        $resolved = self::DEFAULTS;
        foreach ($globalConfig as $k => $v) {
            if ($v !== null && $v !== '') {
                $resolved[$k] = (string)$v;
            }
        }
        foreach ($companyConfig as $k => $v) {
            if ($v !== null && $v !== '') {
                $resolved[$k] = (string)$v;
            }
        }
        $resolved['_is_company_override'] = $hasCompanyConfig;
        $resolved['_source'] = $hasCompanyConfig ? 'company' : (!empty($globalConfig) ? 'global' : 'default');

        // 4. Decrypt password if requested
        if ($decryptPassword && !empty($resolved['smtp_pass'])) {
            $resolved['smtp_pass'] = self::decryptPassword($resolved['smtp_pass']);
        }

        return $resolved;
    }

    /**
     * Get resolved SMTP configuration with password masked for UI display.
     *
     * @param string|null $companyId
     * @return array
     */
    public static function getMasked(?string $companyId = null): array
    {
        $config = self::resolve($companyId, false);
        if (!empty($config['smtp_pass'])) {
            $config['smtp_pass'] = '••••••••';
        }
        return $config;
    }

    /**
     * Encrypt SMTP password using CI4 encrypter service.
     *
     * @param string $password
     * @return string Encrypted string prefixed with enc:
     */
    public static function encryptPassword(string $password): string
    {
        if ($password === '' || $password === '••••••••' || $password === '********') {
            return '';
        }

        try {
            $encrypter = Services::encrypter();
            $ciphertext = $encrypter->encrypt($password);
            return 'enc:' . base64_encode($ciphertext);
        } catch (\Throwable $e) {
            log_message('warning', 'SmtpConfigResolver::encryptPassword failed: ' . $e->getMessage());
            // Fallback base64 marker if encryption service fails
            return 'enc_b64:' . base64_encode($password);
        }
    }

    /**
     * Decrypt SMTP password using CI4 encrypter service.
     *
     * @param string $ciphertext
     * @return string Plaintext password
     */
    public static function decryptPassword(string $ciphertext): string
    {
        if ($ciphertext === '' || $ciphertext === '••••••••' || $ciphertext === '********') {
            return '';
        }

        // Prefixed with enc: (CI4 Encrypter standard output)
        if (str_starts_with($ciphertext, 'enc:')) {
            $raw = base64_decode(substr($ciphertext, 4), true);
            if ($raw !== false) {
                try {
                    $encrypter = Services::encrypter();
                    return $encrypter->decrypt($raw);
                } catch (\Throwable $e) {
                    log_message('warning', 'SmtpConfigResolver::decryptPassword failed: ' . $e->getMessage());
                }
            }
        } elseif (str_starts_with($ciphertext, 'enc_b64:')) {
            $raw = base64_decode(substr($ciphertext, 8), true);
            if ($raw !== false) {
                return $raw;
            }
        } else {
            // Check if it might be raw encrypted binary base64-encoded without prefix
            $raw = base64_decode($ciphertext, true);
            if ($raw !== false) {
                try {
                    $encrypter = Services::encrypter();
                    $dec = $encrypter->decrypt($raw);
                    if ($dec !== false && $dec !== '') {
                        return $dec;
                    }
                } catch (\Throwable $e) {
                    // Not encrypted, fall through
                }
            }
        }

        // Return as plain text if not recognized as ciphertext
        return $ciphertext;
    }

    /**
     * Create and configure a CodeIgniter Email service instance using resolved SMTP config.
     *
     * @param string|null $companyId
     * @return \CodeIgniter\Email\Email
     */
    public static function createEmailService(?string $companyId = null): \CodeIgniter\Email\Email
    {
        $smtp = self::resolve($companyId, true);

        $crypto = strtolower(trim((string)($smtp['smtp_crypto'] ?? 'tls')));
        if ($crypto === 'none' || $crypto === 'null' || $crypto === 'plain' || $crypto === '') {
            $crypto = '';
        }

        $emailConfig = [
            'protocol'    => 'smtp',
            'SMTPHost'    => $smtp['smtp_host'] ?? 'localhost',
            'SMTPPort'    => (int)($smtp['smtp_port'] ?? 587),
            'SMTPUser'    => $smtp['smtp_user'] ?? '',
            'SMTPPass'    => $smtp['smtp_pass'] ?? '',
            'SMTPCrypto'  => $crypto,
            'mailType'    => 'html',
            'charset'     => 'utf-8',
            'newline'     => "\r\n",
            'CRLF'        => "\r\n",
            'SMTPTimeout' => (int)($smtp['smtp_timeout'] ?? 10),
            'wordWrap'    => true,
            'validate'    => false,
        ];

        /** @var \CodeIgniter\Email\Email $email */
        $email = Services::email();
        $email->initialize($emailConfig);

        $fromEmail = !empty($smtp['from_email']) ? $smtp['from_email'] : 'hrms-noreply@enterprise.internal';
        $fromName  = !empty($smtp['from_name']) ? $smtp['from_name'] : 'Corporate Smart HRMS';
        $email->setFrom($fromEmail, $fromName);

        if (!empty($smtp['reply_to_email'])) {
            $email->setReplyTo($smtp['reply_to_email'], $fromName);
        }

        return $email;
    }
}

