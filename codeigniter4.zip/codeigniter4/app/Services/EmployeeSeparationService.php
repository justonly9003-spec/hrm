<?php

namespace App\Services;

use App\Models\EmployeeModel;
use App\Models\EmployeeTerminationModel;
use App\Models\EmployeeResignationModel;
use App\Services\AuditService;
use App\Exceptions\UnreturnedAssetsException;
use Config\Database;

/**
 * Service consolidating employee separation operations:
 * Terminations and Resignations with unified schema values, atomic transactions,
 * user deactivation, and audit logging.
 */
class EmployeeSeparationService
{
    protected EmployeeModel $employeeModel;
    protected EmployeeTerminationModel $terminationModel;
    protected EmployeeResignationModel $resignationModel;
    protected AuditService $auditService;

    public function __construct(
        ?EmployeeModel $employeeModel = null,
        ?EmployeeTerminationModel $terminationModel = null,
        ?EmployeeResignationModel $resignationModel = null,
        ?AuditService $auditService = null
    ) {
        $this->employeeModel    = $employeeModel ?? new EmployeeModel();
        $this->terminationModel = $terminationModel ?? new EmployeeTerminationModel();
        $this->resignationModel = $resignationModel ?? new EmployeeResignationModel();
        $this->auditService     = $auditService ?? new AuditService();
    }

    /**
     * Asserts that an actor is authorized to act on a target employee for separation (terminate/resign).
     *
     * Guards enforced:
     * 1. Self-action guard: Cannot terminate or process resignation for your own employee record.
     * 2. Role hierarchy guard: Cannot act on a user with a higher or equal role (unless software_app_admin).
     *
     * @param array $actor Current user array (must include role_code/role, employee_id, id/user_id)
     * @param array $targetEmployee Target employee array (must include id/employee_id, email, etc.)
     * @param string $actionType 'terminate' | 'resign' | 'resignation'
     * @throws \SecurityException If actor is self or has lower/equal rank to target user
     */
    public static function assertActorMayActOn(array $actor, array $targetEmployee, string $actionType = 'terminate'): void
    {
        $targetEmpId = (string)($targetEmployee['id'] ?? $targetEmployee['employee_id'] ?? '');
        $actorEmpId  = (string)($actor['employee_id'] ?? '');
        $actorUserId = (string)($actor['id'] ?? $actor['user_id'] ?? '');

        // 1. Target user lookup
        $targetUser = null;
        if (!empty($targetEmployee['user']) && is_array($targetEmployee['user'])) {
            $targetUser = $targetEmployee['user'];
        } elseif (!empty($targetEmployee['user_id'])) {
            $targetUser = (new \App\Models\UserModel())->find($targetEmployee['user_id']);
        }
        if (!$targetUser && !empty($targetEmpId)) {
            $targetUser = (new \App\Models\UserModel())->where('employee_id', $targetEmpId)->first();
        }
        if (!$targetUser && !empty($targetEmployee['email'])) {
            $targetUser = (new \App\Models\UserModel())->where('email', $targetEmployee['email'])->first();
        }
        if (!$targetUser && !empty($targetEmployee['role_code'])) {
            $targetUser = [
                'id'        => $targetEmployee['user_id'] ?? ('usr-' . $targetEmpId),
                'role_code' => $targetEmployee['role_code'],
            ];
        }

        $targetUserId = (string)($targetUser['id'] ?? $targetEmployee['user_id'] ?? '');

        // 2. Block acting on yourself
        $isSelf = (!empty($actorEmpId) && !empty($targetEmpId) && $actorEmpId === $targetEmpId)
            || (!empty($actorUserId) && !empty($targetUserId) && $actorUserId === $targetUserId);

        if ($isSelf) {
            $isResign = ($actionType === 'resign' || $actionType === 'resignation');
            $msg = $isResign
                ? '403 Forbidden: You cannot process resignation for your own employee record.'
                : '403 Forbidden: You cannot terminate your own employee record.';
            throw new \SecurityException($msg);
        }

        // 3. Block acting on a user with higher or equal role
        if ($targetUser) {
            $permService = new \App\Services\PermissionService();
            $actorRole = $actor['role_code'] ?? $actor['role_name'] ?? $actor['role'] ?? '';
            $roleModel = new \App\Models\RoleModel();
            $targetRole = !empty($targetUser['role_id']) ? $roleModel->find($targetUser['role_id']) : null;
            $targetRoleCode = $targetRole['code'] ?? $targetUser['role_code'] ?? $targetUser['role'] ?? 'employee';

            $actorCanonical = $permService->canonicalizeRole($actorRole);
            $targetCanonical = $permService->canonicalizeRole($targetRoleCode);

            $roleRanks = [
                'software_app_admin' => 100,
                'company_admin'      => 80,
                'hr_admin'           => 60,
                'hr_officer'         => 50,
                'branch_manager'     => 40,
                'finance'            => 40,
                'manager'            => 30,
                'team_leader'        => 20,
                'employee'           => 10,
                'auditor'            => 30,
            ];
            $actorRank = $roleRanks[$actorCanonical] ?? 10;
            $targetRank = $roleRanks[$targetCanonical] ?? 10;

            $isHigherOrEqual = ($targetRank >= $actorRank) || ($actorCanonical === $targetCanonical) || (!$permService->canManageRole($actorRole, $targetRoleCode) && !($actorCanonical === 'hr_admin' && $targetRank < $actorRank));

            if (!$permService->isSoftwareAppAdmin($actorCanonical) && $isHigherOrEqual) {
                $isResign = ($actionType === 'resign' || $actionType === 'resignation');
                $verb = $isResign ? 'manage resignation for' : 'terminate';
                throw new \SecurityException("403 Forbidden: You cannot {$verb} a user with a higher or equal role ('{$targetRoleCode}').");
            }
        }
    }

    /**
     * Asserts that target employee holds no unreturned active company assets.
     * Blocks only when company_assets.status = 'Assigned' and assigned_to = $employeeId.
     * Ignores status 'Written-Off' and soft-deleted assets (deleted_at IS NOT NULL).
     *
     * @param string $employeeId
     * @throws UnreturnedAssetsException
     */
    public static function assertNoUnreturnedAssets(string $employeeId): void
    {
        $db = Database::connect();
        if (!$db->tableExists('company_assets')) {
            return;
        }

        $builder = $db->table('company_assets')
            ->where('assigned_to', $employeeId)
            ->where('status', 'Assigned');

        if ($db->fieldExists('deleted_at', 'company_assets')) {
            $builder->where('deleted_at IS NULL', null, false);
        }

        $unreturned = $builder->get()->getResultArray();
        if (!empty($unreturned)) {
            throw new UnreturnedAssetsException($unreturned);
        }
    }

    /**
     * Process an employee termination.
     *
     * @param string $employeeId
     * @param array $data Expected: [termination_date?, termination_type?, reason?, notice_period_days?, approved_by?, clearance_status?, exit_interview_notes?]
     * @param string|null $actorId
     * @param array|null $actorUser
     * @param string|null $scopedCompanyId Null if software app admin
     * @return array ['success' => bool, 'message' => string, 'data' => array]
     * @throws \SecurityException|\InvalidArgumentException|\RuntimeException
     */
    public function terminate(
        string $employeeId,
        array $data,
        ?string $actorId = null,
        ?array $actorUser = null,
        ?string $scopedCompanyId = null
    ): array {
        $emp = $this->employeeModel->find($employeeId);
        if (!$emp) {
            throw new \InvalidArgumentException('Employee not found.');
        }

        // Multi-tenant isolation: verify target employee belongs to scoped company
        if (!empty($scopedCompanyId) && !empty($emp['company_id']) && (string)$emp['company_id'] !== (string)$scopedCompanyId) {
            throw new \SecurityException('403 Forbidden: Cross-tenant operation unauthorized.');
        }

        // Block if already terminated
        if (\App\Models\EmployeeModel::normalizeStatus($emp['status'] ?? '', true) === \App\Models\EmployeeModel::STATUS_TERMINATED) {
            throw new \InvalidArgumentException('Employee is already terminated.');
        }

        // De-duplicated authorization guard: self and role hierarchy checks
        $actorArray = $actorUser ?? ['id' => $actorId];
        $this->assertActorMayActOn($actorArray, $emp, 'terminate');

        // Unreturned company assets guard: block only company_assets.status = 'Assigned' with assigned_to = employee
        $this->assertNoUnreturnedAssets($employeeId);

        $termDate   = !empty($data['termination_date']) ? (string)$data['termination_date'] : date('Y-m-d');
        $termType   = !empty($data['termination_type']) ? (string)$data['termination_type'] : 'Termination';
        $reason     = trim((string)($data['reason'] ?? ''));
        $noticeDays = (int)($data['notice_period_days'] ?? 0);
        // Never take approved_by from POST; use logged-in user identity
        $approver   = !empty($actorUser['name']) ? (string)$actorUser['name'] : (!empty($actorUser['username']) ? (string)$actorUser['username'] : (string)$actorId);
        $exitNotes  = $data['exit_interview_notes'] ?? null;

        // Standardized clearance & settlement status (schema varchar defaults, never int)
        $clearanceRaw = $data['clearance_status'] ?? 'In Progress';
        if ($clearanceRaw === 1 || $clearanceRaw === '1' || empty($clearanceRaw)) {
            $clearanceStatus = 'In Progress';
        } else {
            $clearanceStatus = trim((string)$clearanceRaw);
        }
        $finalSettlementStatus = 'Pending';

        $db = Database::connect();
        $db->transBegin();

        try {
            $existing = $this->terminationModel->where('employee_id', $employeeId)->first();
            $recordData = [
                'termination_date'        => $termDate,
                'termination_type'        => $termType,
                'reason'                  => $reason,
                'notice_period_days'      => $noticeDays,
                'status'                  => 'Approved',
                'approved_by'             => $approver,
                'clearance_status'        => $clearanceStatus,
                'final_settlement_status' => $finalSettlementStatus,
                'exit_interview_notes'    => $exitNotes,
                'terminated_by'           => $actorId,
            ];

            if ($existing) {
                $terminationId = $existing['id'];
                $this->terminationModel->update($existing['id'], $recordData);
            } else {
                $terminationId = 'term-' . bin2hex(random_bytes(8));
                $recordData['id'] = $terminationId;
                $recordData['employee_id'] = $employeeId;
                $this->terminationModel->insert($recordData);
            }

            // Update employee status and separation date fields
            $empUpdate = ['status' => \App\Models\EmployeeModel::STATUS_TERMINATED];
            if ($this->db->fieldExists('termination_date', 'employees')) {
                $empUpdate['termination_date'] = $terminationDate;
            }
            if ($this->db->fieldExists('last_working_date', 'employees')) {
                $empUpdate['last_working_date'] = $lastWorkingDate ?: $terminationDate;
            }
            if ($this->db->fieldExists('separation_date', 'employees')) {
                $empUpdate['separation_date'] = $lastWorkingDate ?: $terminationDate;
            }
            $this->employeeModel->update($employeeId, $empUpdate);

            // Cascade deactivation to user account using shared helper
            self::syncUserStatusForEmployee($employeeId, \App\Models\EmployeeModel::STATUS_TERMINATED, $emp['email'] ?? null);

            $db->transCommit();
        } catch (\Throwable $e) {
            $db->transRollback();
            throw $e;
        }

        // Unified audit log
        $this->auditService->log(
            $actorId,
            'employee',
            'employee.terminated',
            $employeeId,
            ['status' => $emp['status'] ?? \App\Models\EmployeeModel::STATUS_ACTIVE],
            ['status' => \App\Models\EmployeeModel::STATUS_TERMINATED, 'clearance_status' => $clearanceStatus, 'final_settlement_status' => $finalSettlementStatus, 'reason' => $reason],
            null,
            null,
            "Terminated employee {$employeeId}. User account revoked. Reason: {$reason}"
        );

        // Automatically prepare a draft final settlement record for the separated employee
        $settlementResult = null;
        try {
            $settlementResult = $this->startSettlement($employeeId, $termType, $terminationId, $termDate, $actorId, $scopedCompanyId);
        } catch (\Throwable $e) {
            log_message('warning', 'Auto-draft final settlement on termination skipped: ' . $e->getMessage());
        }

        return [
            'success' => true,
            'message' => 'Employee terminated, user account disabled, and separation recorded.',
            'data'    => [
                'termination_id'          => $terminationId,
                'employee_id'             => $employeeId,
                'status'                  => 'Terminated',
                'clearance_status'        => $clearanceStatus,
                'final_settlement_status' => $finalSettlementStatus,
                'termination_date'        => $termDate,
                'settlement'              => $settlementResult['data'] ?? null
            ]
        ];
    }

    /**
     * Process an employee resignation submission.
     * Keeps resignation history: blocks new submission only while an existing record is Pending or Approved.
     * New submissions are always created with status 'Pending'.
     *
     * @param string $employeeId
     * @param array $data Expected: [submission_date?, notice_date?, resignation_date?, reason?, manager_review?]
     * @param string|null $actorId
     * @param array|null $actorUser
     * @param string|null $scopedCompanyId Null if software app admin
     * @return array ['success' => bool, 'message' => string, 'data' => array]
     * @throws \SecurityException|\InvalidArgumentException|\RuntimeException
     */
    public function resign(
        string $employeeId,
        array $data,
        ?string $actorId = null,
        ?array $actorUser = null,
        ?string $scopedCompanyId = null
    ): array {
        $emp = $this->employeeModel->find($employeeId);
        if (!$emp) {
            throw new \InvalidArgumentException('Employee not found.');
        }

        // Multi-tenant isolation: verify target employee belongs to scoped company
        if (!empty($scopedCompanyId) && !empty($emp['company_id']) && (string)$emp['company_id'] !== (string)$scopedCompanyId) {
            throw new \SecurityException('403 Forbidden: Cross-tenant operation unauthorized.');
        }

        // Block if already terminated or separated
        $canonStatus = \App\Models\EmployeeModel::normalizeStatus($emp['status'] ?? '', false);
        if (in_array($canonStatus, [\App\Models\EmployeeModel::STATUS_TERMINATED, \App\Models\EmployeeModel::STATUS_RESIGNED], true)) {
            throw new \InvalidArgumentException("Employee is already separated ({$emp['status']}).");
        }

        // De-duplicated authorization guard: self and role hierarchy checks
        $actorArray = $actorUser ?? ['id' => $actorId];
        $this->assertActorMayActOn($actorArray, $emp, 'resign');

        // Allow multiple resignation records per employee: block new submission only while one is Pending or Approved
        $activeRes = $this->resignationModel
            ->where('employee_id', $employeeId)
            ->whereIn('status', ['Pending', 'Approved'])
            ->first();
        if ($activeRes) {
            throw new \InvalidArgumentException("Employee already has an active ({$activeRes['status']}) resignation record (ID: {$activeRes['id']}). Wait until resolved or archived.");
        }

        $subDate  = !empty($data['submission_date']) ? (string)$data['submission_date'] : date('Y-m-d');
        $notDate  = !empty($data['notice_date']) ? (string)$data['notice_date'] : date('Y-m-d');
        $resDate  = !empty($data['resignation_date']) ? (string)$data['resignation_date'] : null;
        $reason   = trim((string)($data['reason'] ?? ''));
        $mgrRev   = $data['manager_review'] ?? null;

        // New resignations are ALWAYS 'Pending'. Never accept approved_by or hr_review on initial submission.
        $resignationId = 'res-' . bin2hex(random_bytes(8));
        $recordData = [
            'id'                      => $resignationId,
            'employee_id'             => $employeeId,
            'submission_date'         => $subDate,
            'notice_date'             => $notDate,
            'resignation_date'        => $resDate,
            'reason'                  => $reason,
            'status'                  => 'Pending',
            'manager_review'          => $mgrRev,
            'hr_review'               => null,
            'approved_by'             => null,
            'clearance_status'        => 'In Progress',
            'final_settlement_status' => 'Pending',
            'created_at'              => date('Y-m-d H:i:s'),
            'updated_at'              => date('Y-m-d H:i:s'),
        ];

        $this->resignationModel->insert($recordData);

        // Unified audit log
        $this->auditService->log(
            $actorId,
            'employee',
            'employee.resigned',
            $employeeId,
            ['status' => $emp['status'] ?? \App\Models\EmployeeModel::STATUS_ACTIVE],
            ['status' => $emp['status'] ?? \App\Models\EmployeeModel::STATUS_ACTIVE, 'resignation_status' => 'Pending', 'reason' => $reason],
            null,
            null,
            "Resignation notice submitted for employee {$employeeId}. Status: Pending"
        );

        return [
            'success' => true,
            'message' => 'Resignation submitted successfully and is pending HR approval.',
            'data'    => [
                'resignation_id' => $resignationId,
                'employee_id'    => $employeeId,
                'status'         => 'Pending',
                'notice_date'    => $notDate,
                'settlement'     => null
            ]
        ];
    }

    /**
     * Formally approve a specific employee resignation record.
     * State machine: only 'Pending' records can transition to 'Approved'.
     * Preserves original submission date, notice date, and reason.
     * Runs in a DB transaction with employee status and user account deactivation sync.
     *
     * @param string $resignationId
     * @param array $data Expected: [last_working_day?, hr_review?]
     * @param string|null $actorId
     * @param array|null $actorUser
     * @param string|null $scopedCompanyId
     * @return array
     * @throws \SecurityException|\InvalidArgumentException|\RuntimeException
     */
    public function approveResignation(
        string $resignationId,
        array $data = [],
        ?string $actorId = null,
        ?array $actorUser = null,
        ?string $scopedCompanyId = null
    ): array {
        $resignation = $this->resignationModel->find($resignationId);
        if (!$resignation) {
            throw new \InvalidArgumentException('Resignation record not found.');
        }

        // State Machine Guard: only Pending can become Approved
        $currentStatus = (string)($resignation['status'] ?? '');
        if ($currentStatus !== 'Pending') {
            throw new \InvalidArgumentException("State machine violation: Only 'Pending' resignations can be approved. Current status is '{$currentStatus}'.");
        }

        $employeeId = $resignation['employee_id'];
        $emp = $this->employeeModel->find($employeeId);
        if (!$emp) {
            throw new \InvalidArgumentException('Target employee record not found.');
        }

        // Tenant scope verification
        if (!empty($scopedCompanyId) && !empty($emp['company_id']) && (string)$emp['company_id'] !== (string)$scopedCompanyId) {
            throw new \SecurityException('403 Forbidden: Cross-tenant operation unauthorized.');
        }

        // De-duplicated authorization guard: self and role hierarchy checks
        $actorArray = $actorUser ?? ['id' => $actorId];
        $this->assertActorMayActOn($actorArray, $emp, 'resign');

        // Unreturned company assets guard
        $this->assertNoUnreturnedAssets($employeeId);

        $lastWorkingDay = !empty($data['last_working_day']) ? (string)$data['last_working_day'] : ($resignation['resignation_date'] ?: date('Y-m-d'));
        $hrReview       = trim((string)($data['hr_review'] ?? 'Resignation approved by HR executive.'));
        $approver       = !empty($actorUser['name']) ? (string)$actorUser['name'] : (!empty($actorUser['username']) ? (string)$actorUser['username'] : (string)$actorId);

        $db = Database::connect();
        $db->transBegin();

        try {
            // Keep original reason, submission_date and notice_date intact
            $this->resignationModel->update($resignationId, [
                'status'           => 'Approved',
                'resignation_date' => $lastWorkingDay,
                'hr_review'        => $hrReview,
                'approved_by'      => $approver,
                'clearance_status' => 'In Progress',
                'updated_at'       => date('Y-m-d H:i:s'),
            ]);

            // Set employee status to Resigned and sync separation dates
            $empUpdate = [
                'status' => \App\Models\EmployeeModel::STATUS_RESIGNED,
            ];
            if ($this->db->fieldExists('resignation_date', 'employees')) {
                $empUpdate['resignation_date'] = $lastWorkingDay;
            }
            if ($this->db->fieldExists('last_working_date', 'employees')) {
                $empUpdate['last_working_date'] = $lastWorkingDay;
            }
            if ($this->db->fieldExists('separation_date', 'employees')) {
                $empUpdate['separation_date'] = $lastWorkingDay;
            }
            $this->employeeModel->update($employeeId, $empUpdate);

            // Cascade deactivation to user account inside the same atomic transaction
            self::syncUserStatusForEmployee($employeeId, \App\Models\EmployeeModel::STATUS_RESIGNED, $emp['email'] ?? null);

            $db->transCommit();
        } catch (\Throwable $e) {
            $db->transRollback();
            throw $e;
        }

        // Unified audit log
        $this->auditService->log(
            $actorId,
            'employee',
            'employee.resignation_approved',
            $employeeId,
            ['status' => $emp['status'] ?? \App\Models\EmployeeModel::STATUS_ACTIVE, 'resignation_status' => 'Pending'],
            ['status' => \App\Models\EmployeeModel::STATUS_RESIGNED, 'resignation_status' => 'Approved', 'last_working_day' => $lastWorkingDay],
            null,
            null,
            "Resignation {$resignationId} approved for employee {$employeeId}. User account revoked. Last working day: {$lastWorkingDay}"
        );

        // Auto-draft final settlement statement
        $settlementResult = null;
        try {
            $settlementResult = $this->startSettlement($employeeId, 'Resignation', $resignationId, $lastWorkingDay, $actorId, $scopedCompanyId);
        } catch (\Throwable $e) {
            log_message('warning', 'Auto-draft final settlement on resignation approval skipped: ' . $e->getMessage());
        }

        return [
            'success' => true,
            'message' => 'Resignation approved, employee status updated to Resigned, and final settlement draft prepared.',
            'data'    => [
                'resignation_id'   => $resignationId,
                'employee_id'      => $employeeId,
                'status'           => 'Approved',
                'last_working_day' => $lastWorkingDay,
                'settlement'       => $settlementResult['data'] ?? null
            ]
        ];
    }

    /**
     * Reject an employee resignation record.
     * State machine: only 'Pending' records can transition to 'Rejected'.
     * Leaves employee and user status completely untouched.
     *
     * @param string $resignationId
     * @param string $reason
     * @param string|null $actorId
     * @param array|null $actorUser
     * @param string|null $scopedCompanyId
     * @return array
     * @throws \SecurityException|\InvalidArgumentException|\RuntimeException
     */
    public function rejectResignation(
        string $resignationId,
        string $reason = '',
        ?string $actorId = null,
        ?array $actorUser = null,
        ?string $scopedCompanyId = null
    ): array {
        $resignation = $this->resignationModel->find($resignationId);
        if (!$resignation) {
            throw new \InvalidArgumentException('Resignation record not found.');
        }

        // State Machine Guard: only Pending can become Rejected
        $currentStatus = (string)($resignation['status'] ?? '');
        if ($currentStatus !== 'Pending') {
            throw new \InvalidArgumentException("State machine violation: Only 'Pending' resignations can be rejected. Current status is '{$currentStatus}'.");
        }

        $employeeId = $resignation['employee_id'];
        $emp = $this->employeeModel->find($employeeId);
        if (!$emp) {
            throw new \InvalidArgumentException('Target employee record not found.');
        }

        // Tenant scope verification
        if (!empty($scopedCompanyId) && !empty($emp['company_id']) && (string)$emp['company_id'] !== (string)$scopedCompanyId) {
            throw new \SecurityException('403 Forbidden: Cross-tenant operation unauthorized.');
        }

        // Self-rejection guard
        $isSelf = (!empty($actorUser['employee_id']) && (string)$actorUser['employee_id'] === (string)$employeeId)
            || (!empty($actorId) && !empty($emp['user_id']) && (string)$emp['user_id'] === (string)$actorId);
        if ($isSelf) {
            throw new \SecurityException('403 Forbidden: You cannot reject your own resignation record.');
        }

        $rejectReason = trim($reason) ?: 'Resignation request rejected by HR.';

        // Update resignation record. Employee status and user status stay UNTOUCHED.
        $this->resignationModel->update($resignationId, [
            'status'     => 'Rejected',
            'hr_review'  => $rejectReason,
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        // Audit log
        $this->auditService->log(
            $actorId,
            'employee',
            'employee.resignation_rejected',
            $employeeId,
            ['resignation_status' => 'Pending'],
            ['resignation_status' => 'Rejected', 'reason' => $rejectReason],
            null,
            null,
            "Resignation {$resignationId} rejected for employee {$employeeId}. Employee status unchanged."
        );

        return [
            'success' => true,
            'message' => 'Resignation request rejected. Employee status remains unchanged.',
            'data'    => [
                'resignation_id' => $resignationId,
                'employee_id'    => $employeeId,
                'status'         => 'Rejected',
            ]
        ];
    }

    /**
     * Start and draft final settlement for an employee separation.
     *
     * @param string $employeeId
     * @param string $separationType
     * @param string $separationId
     * @param string|null $lastWorkingDay
     * @param string|null $actorId
     * @param string|null $scopedCompanyId
     * @return array
     */
    public function startSettlement(
        string $employeeId,
        string $separationType,
        string $separationId,
        ?string $lastWorkingDay = null,
        ?string $actorId = null,
        ?string $scopedCompanyId = null
    ): array {
        $emp = $this->employeeModel->find($employeeId);
        if (!$emp) {
            throw new \InvalidArgumentException('Employee record not found for settlement drafting.');
        }

        if (!empty($scopedCompanyId) && !empty($emp['company_id']) && (string)$emp['company_id'] !== (string)$scopedCompanyId) {
            throw new \SecurityException('403 Forbidden: Cross-tenant operation unauthorized.');
        }

        $lwd = !empty($lastWorkingDay) ? $lastWorkingDay : date('Y-m-d');

        $finalSettlementService = new \App\Services\FinalSettlementService();
        $calcData = [
            'employee_id'                   => $employeeId,
            'separation_type'               => $separationType,
            'separation_id'                 => $separationId,
            'resignation_or_termination_id' => $separationId,
            'last_working_day'              => $lwd,
            'separation_date'               => $lwd,
            'payment_status'                => 'Draft'
        ];

        return $finalSettlementService->saveSettlement($calcData, null, $actorId);
    }

    /**
     * Shared helper to synchronize linked user account status when employee status changes.
     * Delegates to canonical EmployeeModel::syncUserAccountStatus.
     *
     * @param string $employeeId
     * @param string $employeeStatus
     * @param string|null $employeeEmail
     */
    public static function syncUserStatusForEmployee(string $employeeId, string $employeeStatus, ?string $employeeEmail = null): void
    {
        \App\Models\EmployeeModel::syncUserAccountStatus($employeeId, $employeeStatus, $employeeEmail);
    }
}

