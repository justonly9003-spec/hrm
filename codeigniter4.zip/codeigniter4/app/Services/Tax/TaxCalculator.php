<?php

namespace App\Services\Tax;

use App\Models\EmployeeModel;
use App\Models\RuleDefinitionModel;
use App\Services\Rules\RuleNotConfiguredException;
use App\Services\Rules\ResolvedRule;
use App\Services\Rules\RuleResolver;

class TaxCalculator
{
    protected RuleResolver $resolver;

    public function __construct(?RuleResolver $resolver = null)
    {
        $this->resolver = $resolver ?? new RuleResolver();
    }

    /**
     * Helper to compute Bangladesh Fiscal Year (July 1 - June 30)
     */
    public static function getFiscalYear(?string $date = null): string
    {
        $time = !empty($date) ? strtotime($date) : time();
        $m = (int)date('n', $time);
        $y = (int)date('Y', $time);
        return ($m >= 7) ? "{$y}-" . ($y + 1) : ($y - 1) . "-{$y}";
    }

    /**
     * Main calculation entry point
     */
    public function calculateTax(float $monthlyGross, array $context = []): array
    {
        return $this->calculate($monthlyGross, $context);
    }

    /**
     * Universal calculation implementation
     */
    public function calculate(float $monthlyGross, array $context = []): array
    {
        $companyId = $context['company_id'] ?? null;
        $employee = $context['employee'] ?? null;
        $employeeId = $context['employee_id'] ?? null;
        $effectiveDate = $context['effective_date'] ?? $context['date'] ?? date('Y-m-d');

        $empRow = [];
        if (is_array($employee)) {
            $empRow = $employee;
            if (empty($companyId) && !empty($empRow['company_id'])) {
                $companyId = $empRow['company_id'];
            }
            if (empty($employeeId) && !empty($empRow['id'])) {
                $employeeId = $empRow['id'];
            }
        } elseif (!empty($employeeId)) {
            try {
                $empModel = new EmployeeModel();
                $found = $empModel->find($employeeId);
                if ($found) {
                    $empRow = (array)$found;
                    if (empty($companyId) && !empty($empRow['company_id'])) {
                        $companyId = $empRow['company_id'];
                    }
                }
            } catch (\Throwable $e) {
                // Ignore lookup failure
            }
        }

        if (empty($companyId) && function_exists('session') && session()->has('company_id')) {
            $companyId = session('company_id');
        }

        if (empty($companyId)) {
            throw new RuleNotConfiguredException("Unable to determine company_id for TAX rule resolution.");
        }

        // Resolve authoritative TAX rule from RuleResolver
        /** @var ResolvedRule $resolved */
        $resolved = $this->resolver->resolve($companyId, 'TAX', $empRow, $effectiveDate);
        $params = $resolved->params();
        $rulesSnapshot = ['TAX' => $resolved->snapshot()];

        // Check if override rule or direct context mode
        $calcMode = !empty($context['calculation_mode'])
            ? (string)$context['calculation_mode']
            : (string)$resolved->get('calculation_mode');

        if (isset($context['basic']) && $context['basic'] !== '' && is_numeric($context['basic'])) {
            $basic = (float)$context['basic'];
        } else {
            $basicRatio = $params['basic_ratio_pct'] ?? $params['basic_salary_ratio_pct'] ?? null;
            if ($basicRatio === null) {
                throw new RuleNotConfiguredException(
                    "Rule parameter 'basic_ratio_pct' not configured in TAX domain for company '{$companyId}'.",
                    $companyId,
                    'TAX',
                    $effectiveDate
                );
            }
            $basic = round($monthlyGross * ((float)$basicRatio / 100.0), 2);
        }

        if (isset($context['house_rent']) && $context['house_rent'] !== '' && is_numeric($context['house_rent'])) {
            $houseRent = (float)$context['house_rent'];
        } else {
            $houseRentRatio = $params['house_rent_ratio_pct'] ?? null;
            if ($houseRentRatio === null) {
                throw new RuleNotConfiguredException(
                    "Rule parameter 'house_rent_ratio_pct' not configured in TAX domain for company '{$companyId}'.",
                    $companyId,
                    'TAX',
                    $effectiveDate
                );
            }
            $houseRent = round($basic * ((float)$houseRentRatio / 100.0), 2);
        }

        if (isset($context['medical']) && $context['medical'] !== '' && is_numeric($context['medical'])) {
            $medical = (float)$context['medical'];
        } else {
            $medicalRatio = $params['medical_ratio_pct'] ?? null;
            if ($medicalRatio === null) {
                throw new RuleNotConfiguredException(
                    "Rule parameter 'medical_ratio_pct' not configured in TAX domain for company '{$companyId}'.",
                    $companyId,
                    'TAX',
                    $effectiveDate
                );
            }
            $medical = round($basic * ((float)$medicalRatio / 100.0), 2);
        }

        if (isset($context['conveyance']) && $context['conveyance'] !== '' && is_numeric($context['conveyance'])) {
            $conveyance = (float)$context['conveyance'];
        } else {
            $conveyanceMonthly = $params['conveyance_monthly'] ?? $params['conveyance_allowance_monthly'] ?? null;
            if ($conveyanceMonthly === null) {
                throw new RuleNotConfiguredException(
                    "Rule parameter 'conveyance_monthly' not configured in TAX domain for company '{$companyId}'.",
                    $companyId,
                    'TAX',
                    $effectiveDate
                );
            }
            $conveyance = (float)$conveyanceMonthly;
        }
        $otherAllowances = (float)($context['other_allowances'] ?? max(0, $monthlyGross - ($basic + $houseRent + $medical + $conveyance)));
        $annualBonus = (float)($context['annual_bonus'] ?? 0.00);
        $annualInvestment = (float)($context['annual_investment'] ?? 0.00);
        $gender = ucfirst(strtolower($context['gender'] ?? $empRow['gender'] ?? 'All'));
        $category = ucfirst(strtolower($context['category'] ?? $context['tax_category'] ?? $empRow['tax_category'] ?? 'General'));

        $annualBasic = $basic * 12;
        $annualGross = ($monthlyGross * 12) + $annualBonus;
        $taxYear = self::getFiscalYear($effectiveDate);

        if ($calcMode === 'Exempt') {
            return [
                'rule_name'             => 'Statutory Progressive Tax Rule',
                'tax_rule_name'         => 'Statutory Progressive Tax Rule',
                'tax_year'              => $taxYear,
                'monthly_gross'         => $monthlyGross,
                'annual_gross'          => $annualGross,
                'exemptions'            => [
                    'medical_exemption'    => 0.0,
                    'conveyance_exemption' => 0.0,
                    'house_rent_exemption' => 0.0,
                    'total_exemptions'     => 0.0,
                ],
                'annual_taxable_income' => 0.0,
                'annual_tax_liability'  => 0.0,
                'min_taxable_threshold' => 0.0,
                'is_taxable'            => false,
                'gross_annual_tax'      => 0.0,
                'rebate_applied'        => 0.0,
                'min_tax_enforced'      => false,
                'min_tax_amount'        => 0.0,
                'net_annual_tax'        => 0.0,
                'monthly_tax_deduction' => 0.0,
                'monthly_tax'           => 0.0,
                'monthly_tds'           => 0.0,
                'effective_tax_rate'    => 0.0,
                'slab_breakdown'        => [],
                'rules_snapshot'        => $rulesSnapshot,
            ];
        }

        if ($calcMode === 'Fixed') {
            if (isset($context['annual_tax_amount']) && is_numeric($context['annual_tax_amount'])) {
                $fixedMonthly = round((float)$context['annual_tax_amount'] / 12, 2);
            } elseif (isset($context['custom_tax_amount']) && is_numeric($context['custom_tax_amount'])) {
                $fixedMonthly = (float)$context['custom_tax_amount'];
            } elseif (isset($context['fixed_tax_amount']) && is_numeric($context['fixed_tax_amount'])) {
                $fixedMonthly = (float)$context['fixed_tax_amount'];
            } elseif (isset($params['fixed_tax_amount']) && is_numeric($params['fixed_tax_amount'])) {
                $fixedMonthly = (float)$params['fixed_tax_amount'];
            } else {
                throw new RuleNotConfiguredException("Fixed tax amount is not configured for company '{$companyId}'.");
            }
            $annualFixed = round($fixedMonthly * 12, 2);
            $effRate = $annualGross > 0 ? round(($annualFixed / $annualGross) * 100, 2) : 0.0;
            return [
                'rule_name'             => 'Fixed Income Tax Override',
                'tax_rule_name'         => 'Fixed Income Tax Override',
                'tax_year'              => $taxYear,
                'monthly_gross'         => $monthlyGross,
                'annual_gross'          => $annualGross,
                'exemptions'            => [
                    'medical_exemption'    => 0.0,
                    'conveyance_exemption' => 0.0,
                    'house_rent_exemption' => 0.0,
                    'total_exemptions'     => 0.0,
                ],
                'annual_taxable_income' => $annualGross,
                'annual_tax_liability'  => $annualFixed,
                'min_taxable_threshold' => 0.0,
                'is_taxable'            => ($fixedMonthly > 0),
                'gross_annual_tax'      => $annualFixed,
                'rebate_applied'        => 0.0,
                'min_tax_enforced'      => false,
                'min_tax_amount'        => 0.0,
                'net_annual_tax'        => $annualFixed,
                'monthly_tax_deduction' => round($fixedMonthly, 2),
                'monthly_tax'           => round($fixedMonthly, 2),
                'monthly_tds'           => round($fixedMonthly, 2),
                'effective_tax_rate'    => $effRate,
                'slab_breakdown'        => [],
                'rules_snapshot'        => $rulesSnapshot,
            ];
        }

        // Auto progressive calculation
        $genderApplicability = (string)($params['gender_applicability'] ?? 'All');
        $minTaxable = (float)$params['tax_free_limit_yearly'];
        $medicalExemptionPct = (float)$params['medical_exemption_pct'];
        $medicalExemptionMax = (float)$params['medical_exemption_max'];
        $conveyanceExemptionMax = (float)$params['conveyance_exemption_max'];
        $houseRentExemptionPct = (float)$params['house_rent_exemption_pct'];
        $houseRentExemptionMax = (float)$params['house_rent_exemption_max'];
        $minTaxAmount = (float)$params['min_tax_amount'];
        $rebatePct = (float)$params['rebate_pct'];
        $rebateMaxTaxablePct = (float)$params['rebate_max_taxable_pct'];
        $fixedDeduction = (float)($context['fixed_deduction'] ?? $params['fixed_deduction'] ?? 0.0);
        $rawSlabs = $params['slabs'] ?? [];

        // Demographics thresholds strictly according to Bangladesh Income Tax policy
        $demoMap = $params['category_thresholds'] ?? [];
        $normCat = strtolower(trim((string)$category));
        $normGender = strtolower(trim((string)$gender));
        $catThreshold = null;

        if (!empty($demoMap)) {
            $catKey = str_replace(' ', '', (string)$category);
            if (str_contains($normCat, 'freedom') || str_contains($normCat, 'fighter') || str_contains($normCat, 'muktijoddha')) {
                $catThreshold = (float)($demoMap['FreedomFighter'] ?? $demoMap['Freedom Fighter'] ?? 500000);
            } elseif (str_contains($normCat, 'disab') || str_contains($normCat, 'physic') || str_contains($normCat, 'challenged') || str_contains($normCat, 'third') || str_contains($normCat, 'hijra')) {
                $catThreshold = (float)($demoMap['Disabled'] ?? $demoMap['Physically Challenged'] ?? 475000);
            } elseif (str_contains($normCat, 'senior') || str_contains($normCat, '65') || str_contains($normCat, 'elderly')) {
                $catThreshold = (float)($demoMap['Senior'] ?? $demoMap['Senior Citizen'] ?? 400000);
            } elseif (str_contains($normCat, 'female') || str_contains($normCat, 'woman') || $normGender === 'female') {
                $catThreshold = (float)($demoMap['Female'] ?? $demoMap['Women'] ?? 400000);
            } elseif (isset($demoMap[$category])) {
                $catThreshold = (float)$demoMap[$category];
            } elseif (isset($demoMap[$catKey])) {
                $catThreshold = (float)$demoMap[$catKey];
            } elseif (isset($demoMap['General'])) {
                $catThreshold = (float)$demoMap['General'];
            } elseif (isset($demoMap['Male'])) {
                $catThreshold = (float)$demoMap['Male'];
            }
        }
        if ($catThreshold !== null && $catThreshold > 0) {
            $minTaxable = $catThreshold;
        }

        // Construct progressive slabs with exact spans relative to demographic tax-free limit
        $slabs = [];
        $slabs[] = [
            'min'   => 0.0,
            'max'   => $minTaxable,
            'rate'  => 0.0,
            'label' => 'Tax-Free Threshold (First ' . number_format($minTaxable) . ')',
        ];
        $currLimit = $minTaxable;

        $nonZeroSlabs = array_values(array_filter($rawSlabs, fn($s) => (float)($s['rate'] ?? 0) > 0));
        if (empty($nonZeroSlabs)) {
            // Standard progressive slabs under Bangladesh Finance Act
            $standardSpans = [
                ['span' => 100000.0, 'rate' => 5.0,  'label' => 'Next 100,000 @ 5%'],
                ['span' => 300000.0, 'rate' => 10.0, 'label' => 'Next 300,000 @ 10%'],
                ['span' => 400000.0, 'rate' => 15.0, 'label' => 'Next 400,000 @ 15%'],
                ['span' => 500000.0, 'rate' => 20.0, 'label' => 'Next 500,000 @ 20%'],
                ['span' => null,     'rate' => 25.0, 'label' => 'Remaining Balance @ 25%'],
            ];
            foreach ($standardSpans as $sp) {
                $sMax = ($sp['span'] !== null) ? round($currLimit + $sp['span'], 2) : null;
                $slabs[] = [
                    'min'   => $currLimit,
                    'max'   => $sMax,
                    'rate'  => $sp['rate'],
                    'label' => $sp['label'],
                ];
                if ($sMax !== null) {
                    $currLimit = $sMax;
                }
            }
        } else {
            foreach ($nonZeroSlabs as $nz) {
                $origMin = (float)($nz['min'] ?? 0);
                $origMax = (isset($nz['max']) && $nz['max'] !== null && $nz['max'] !== '') ? (float)$nz['max'] : null;
                $rate = (float)($nz['rate'] ?? 0);
                $span = ($origMax !== null && $origMax > $origMin) ? round($origMax - $origMin, 2) : null;
                $sMax = ($span !== null) ? round($currLimit + $span, 2) : null;
                $slabs[] = [
                    'min'   => $currLimit,
                    'max'   => $sMax,
                    'rate'  => $rate,
                    'label' => $nz['label'] ?? (($sMax !== null) ? 'Next ' . number_format($span) . " @ {$rate}%" : "Remaining Balance @ {$rate}%"),
                ];
                if ($sMax !== null) {
                    $currLimit = $sMax;
                }
            }
        }

        // 1. Statutory Exemptions under Bangladesh Income Tax rules
        $medicalAnnual = $medical * 12;
        $medicalExempt = min($medicalAnnual, min($annualBasic * ($medicalExemptionPct / 100.0), $medicalExemptionMax));

        $conveyanceAnnual = $conveyance * 12;
        $conveyanceExempt = min($conveyanceAnnual, $conveyanceExemptionMax);

        $houseRentAnnual = $houseRent * 12;
        $houseRentExempt = min($houseRentAnnual, min($annualBasic * ($houseRentExemptionPct / 100.0), $houseRentExemptionMax));

        $totalExemptions = round($medicalExempt + $conveyanceExempt + $houseRentExempt, 2);

        // 2. Net Taxable Income
        $annualTaxableIncome = max(0.00, round($annualGross - $totalExemptions, 2));

        // 3. Progressive Slabs Breakdown
        $slabBreakdown = [];
        $totalGrossAnnualTax = 0.00;

        if ($annualTaxableIncome > $minTaxable) {
            foreach ($slabs as $slab) {
                $min = (float)($slab['min'] ?? 0);
                $max = isset($slab['max']) && $slab['max'] !== null && $slab['max'] !== '' ? (float)$slab['max'] : null;
                $rate = (float)($slab['rate'] ?? 0);
                $label = $slab['label'] ?? (($max !== null) ? "{$min} - {$max}" : "{$min}+");

                if ($rate <= 0 || $annualTaxableIncome <= $min) {
                    continue;
                }

                $taxableInSlab = 0.0;
                if ($max !== null) {
                    $upperLimit = min($annualTaxableIncome, $max);
                    $taxableInSlab = max(0.0, $upperLimit - $min);
                } else {
                    $taxableInSlab = max(0.0, $annualTaxableIncome - $min);
                }

                $taxForSlab = round($taxableInSlab * ($rate / 100.0), 2);
                $totalGrossAnnualTax += $taxForSlab;

                $slabBreakdown[] = [
                    'label'           => $label,
                    'slab_range'      => ($max !== null) ? number_format($min) . ' - ' . number_format($max) : number_format($min) . '+',
                    'taxable_amount'  => $taxableInSlab,
                    'rate_percentage' => $rate,
                    'tax_amount'      => $taxForSlab,
                ];
            }
        }

        // 4. Tax Rebate & Relief Calculation
        $investmentRebate = round($annualInvestment * ($rebatePct / 100.0), 2);
        $maxAllowableRebate = round($annualTaxableIncome * ($rebateMaxTaxablePct / 100.0), 2);
        $totalRebate = round(min($fixedDeduction + $investmentRebate, $maxAllowableRebate > 0 ? $maxAllowableRebate : ($fixedDeduction + $investmentRebate)), 2);

        // 5. Net Tax & Minimum Tax Rule under Bangladesh Income Tax Policy
        $taxAfterRebate = max(0.00, round($totalGrossAnnualTax - $totalRebate, 2));
        $netAnnualTax = 0.00;
        if ($annualTaxableIncome > $minTaxable) {
            $netAnnualTax = max($minTaxAmount, $taxAfterRebate);
        }

        $monthlyTax = round($netAnnualTax / 12, 2);
        $effectiveRate = $annualGross > 0 ? round(($netAnnualTax / $annualGross) * 100, 2) : 0.00;

        return [
            'rule_name'             => 'Statutory Progressive Tax Rule',
            'tax_rule_name'         => 'Statutory Progressive Tax Rule',
            'tax_year'              => $taxYear,
            'monthly_gross'         => $monthlyGross,
            'annual_gross'          => $annualGross,
            'exemptions'            => [
                'medical_exemption'    => $medicalExempt,
                'conveyance_exemption' => $conveyanceExempt,
                'house_rent_exemption' => $houseRentExempt,
                'total_exemptions'     => $totalExemptions,
            ],
            'annual_taxable_income' => $annualTaxableIncome,
            'annual_tax_liability'  => $netAnnualTax,
            'min_taxable_threshold' => $minTaxable,
            'is_taxable'            => ($annualTaxableIncome > $minTaxable),
            'gross_annual_tax'      => $totalGrossAnnualTax,
            'rebate_applied'        => $totalRebate,
            'min_tax_enforced'      => ($totalGrossAnnualTax > 0 && $taxAfterRebate < $minTaxAmount),
            'min_tax_amount'        => $minTaxAmount,
            'net_annual_tax'        => $netAnnualTax,
            'monthly_tax_deduction' => $monthlyTax,
            'monthly_tax'           => $monthlyTax,
            'monthly_tds'           => $monthlyTax,
            'effective_tax_rate'    => $effectiveRate,
            'slab_breakdown'        => $slabBreakdown,
            'rules_snapshot'        => $rulesSnapshot,
        ];
    }
}
