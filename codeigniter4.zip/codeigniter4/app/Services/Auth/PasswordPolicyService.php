<?php

namespace App\Services\Auth;

/**
 * Reusable Central Password Policy Service
 *
 * Enforces enterprise password security standards across the application:
 * - Minimum length (default 12 for password change / self-service, configurable for admin provision)
 * - Upper-case letter (A-Z)
 * - Lower-case letter (a-z)
 * - Digit (0-9)
 * - Special character
 * - Matching password confirmation
 * - Difference from current password
 */
class PasswordPolicyService
{
    public const DEFAULT_MIN_LENGTH = 8;
    public const MIN_LENGTH_STANDARD = 12;
    public const MIN_LENGTH_PROVISION = 10;

    /**
     * Resolve company-scoped or global password policy from system settings.
     *
     * @param string|null $companyId
     * @return array{min_length: int, require_digits: bool, require_symbols: bool, require_mixed_case: bool}
     */
    public static function forCompany(?string $companyId): array
    {
        $settingModel = new \App\Models\SystemSettingModel();

        // min_password_length -> fallback password_min_length (default 8, clamp 6..32)
        $rawMin = $settingModel->getSetting('min_password_length', $companyId, null);
        if ($rawMin === null || $rawMin === '') {
            $rawMin = $settingModel->getSetting('password_min_length', $companyId, self::DEFAULT_MIN_LENGTH);
        }
        $minLength = (int)$rawMin;
        if ($minLength < 6) {
            $minLength = 6;
        } elseif ($minLength > 32) {
            $minLength = 32;
        }

        // require_numbers -> fallback password_require_numbers (default 1)
        $rawDigits = $settingModel->getSetting('require_numbers', $companyId, null);
        if ($rawDigits === null || $rawDigits === '') {
            $rawDigits = $settingModel->getSetting('password_require_numbers', $companyId, 1);
        }
        $requireDigits = (bool)filter_var($rawDigits, FILTER_VALIDATE_BOOLEAN);

        // require_special_chars -> fallback password_require_symbols (default 1)
        $rawSymbols = $settingModel->getSetting('require_special_chars', $companyId, null);
        if ($rawSymbols === null || $rawSymbols === '') {
            $rawSymbols = $settingModel->getSetting('password_require_symbols', $companyId, 1);
        }
        $requireSymbols = (bool)filter_var($rawSymbols, FILTER_VALIDATE_BOOLEAN);

        // require_mixed_case -> fallback password_require_uppercase (default 1)
        $rawMixed = $settingModel->getSetting('require_mixed_case', $companyId, null);
        if ($rawMixed === null || $rawMixed === '') {
            $rawMixed = $settingModel->getSetting('password_require_uppercase', $companyId, 1);
        }
        $requireMixedCase = (bool)filter_var($rawMixed, FILTER_VALIDATE_BOOLEAN);

        return [
            'min_length'         => $minLength,
            'require_digits'     => $requireDigits,
            'require_symbols'    => $requireSymbols,
            'require_mixed_case' => $requireMixedCase,
        ];
    }

    /**
     * Describe human-readable password policy summary.
     */
    public static function describe(array $policy): string
    {
        $min = isset($policy['min_length']) ? (int)$policy['min_length'] : self::DEFAULT_MIN_LENGTH;
        if ($min <= 0) {
            $min = self::DEFAULT_MIN_LENGTH;
        }

        return "Min {$min} chars";
    }

    /**
     * Validate password complexity / strength.
     */
    public static function validateStrength(
        string $password,
        int $minLength = self::MIN_LENGTH_STANDARD,
        ?array $policy = null
    ): ?string {
        $effectiveMinLength = $policy !== null ? (int)($policy['min_length'] ?? $minLength) : $minLength;
        if (strlen($password) < $effectiveMinLength) {
            return "Password must be at least {$effectiveMinLength} characters long.";
        }

        $requireMixedCase = $policy !== null ? !empty($policy['require_mixed_case']) : true;
        if ($requireMixedCase) {
            if (!preg_match('/[A-Z]/', $password)) {
                return 'Password must contain at least one uppercase letter (A-Z).';
            }
            if (!preg_match('/[a-z]/', $password)) {
                return 'Password must contain at least one lowercase letter (a-z).';
            }
        }

        $requireDigits = $policy !== null ? !empty($policy['require_digits']) : true;
        if ($requireDigits) {
            if (!preg_match('/[0-9]/', $password)) {
                return 'Password must contain at least one digit (0-9).';
            }
        }

        $requireSymbols = $policy !== null ? !empty($policy['require_symbols']) : true;
        if ($requireSymbols) {
            if (!preg_match('/[^A-Za-z0-9]/', $password)) {
                return 'Password must contain at least one special character.';
            }
        }

        return null;
    }

    /**
     * Validate full change-password input payload.
     */
    public static function validateChangePassword(
        string $currentPassword,
        string $newPassword,
        string $confirmPassword,
        int $minLength = self::MIN_LENGTH_STANDARD,
        ?array $policy = null
    ): ?string {
        if ($currentPassword === '') {
            return 'Current password is required.';
        }
        if ($newPassword === '') {
            return 'New password is required.';
        }
        if ($confirmPassword === '') {
            return 'Password confirmation is required.';
        }
        if ($newPassword !== $confirmPassword) {
            return 'New password and confirmation do not match.';
        }
        if ($currentPassword === $newPassword) {
            return 'New password cannot be the same as your current password.';
        }

        return self::validateStrength($newPassword, $minLength, $policy);
    }
}
