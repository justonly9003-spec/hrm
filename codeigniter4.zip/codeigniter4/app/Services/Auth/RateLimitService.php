<?php

namespace App\Services\Auth;

use Config\Services;

/**
 * Reusable Rate Limiting Service for Authentication Endpoints
 *
 * Implements token bucket and sliding window rate limiting for:
 * - Login endpoints: Per-IP and Per-Account boundaries
 * - Refresh endpoints: Per-IP and Per-Token boundaries
 *
 * Prevents credential brute-forcing, password spraying, and refresh token flooding.
 */
class RateLimitService
{
    // Production Thresholds
    public const LOGIN_IP_LIMIT = 20;            // 20 requests per 60 seconds per IP
    public const LOGIN_ACCOUNT_LIMIT = 10;       // 10 requests per 60 seconds per account (company:identifier)
    public const REFRESH_IP_LIMIT = 30;          // 30 requests per 60 seconds per IP
    public const REFRESH_TOKEN_LIMIT = 10;       // 10 requests per 60 seconds per token
    public const WINDOW_SECONDS = 60;

    /** In-memory sliding window fallback store for testing or when cache is transient */
    protected static array $memoryBuckets = [];

    /** Allow overriding limits for testing */
    protected static ?int $testLoginIpLimit = null;
    protected static ?int $testRefreshLimit = null;

    public static function setTestLoginIpLimit(?int $limit): void
    {
        self::$testLoginIpLimit = $limit;
    }

    public static function setTestRefreshLimit(?int $limit): void
    {
        self::$testRefreshLimit = $limit;
    }

    public static function reset(): void
    {
        self::$memoryBuckets = [];
        self::$testLoginIpLimit = null;
        self::$testRefreshLimit = null;
    }

    /**
     * Check rate limiting for login attempts.
     */
    public static function checkLogin(string $ip, string $companyCode, string $identifier): array
    {
        $ip = trim($ip) ?: '127.0.0.1';
        $ipLimit = self::$testLoginIpLimit ?? self::LOGIN_IP_LIMIT;

        // 1. IP-level throttle
        $ipKey = 'rate_login_ip_' . md5($ip);
        if (!self::consume($ipKey, $ipLimit, self::WINDOW_SECONDS)) {
            $retryAfter = self::getRemainingSeconds($ipKey, self::WINDOW_SECONDS);
            return [
                'allowed'     => false,
                'retry_after' => $retryAfter,
                'message'     => 'Too many login attempts from this network. Please try again later.',
            ];
        }

        // 2. Account-level throttle (prevents password spraying across rotated device IDs)
        if ($companyCode !== '' && $identifier !== '') {
            $accKey = 'rate_login_acc_' . md5(strtolower(trim($companyCode) . ':' . trim($identifier)));
            if (!self::consume($accKey, self::LOGIN_ACCOUNT_LIMIT, self::WINDOW_SECONDS)) {
                $retryAfter = self::getRemainingSeconds($accKey, self::WINDOW_SECONDS);
                return [
                    'allowed'     => false,
                    'retry_after' => $retryAfter,
                    'message'     => 'Too many login attempts for this account. Please try again later.',
                ];
            }
        }

        return ['allowed' => true];
    }

    /**
     * Check rate limiting for token refresh attempts.
     */
    public static function checkRefresh(string $ip, string $refreshToken): array
    {
        $ip = trim($ip) ?: '127.0.0.1';
        $limit = self::$testRefreshLimit ?? self::REFRESH_IP_LIMIT;

        // 1. IP-level throttle
        $ipKey = 'rate_refresh_ip_' . md5($ip);
        if (!self::consume($ipKey, $limit, self::WINDOW_SECONDS)) {
            $retryAfter = self::getRemainingSeconds($ipKey, self::WINDOW_SECONDS);
            return [
                'allowed'     => false,
                'retry_after' => $retryAfter,
                'message'     => 'Too many refresh requests. Please try again later.',
            ];
        }

        // 2. Token hash throttle
        if ($refreshToken !== '') {
            $tokenKey = 'rate_refresh_tok_' . md5($refreshToken);
            if (!self::consume($tokenKey, self::REFRESH_TOKEN_LIMIT, self::WINDOW_SECONDS)) {
                $retryAfter = self::getRemainingSeconds($tokenKey, self::WINDOW_SECONDS);
                return [
                    'allowed'     => false,
                    'retry_after' => $retryAfter,
                    'message'     => 'Too many refresh requests for this token. Please try again later.',
                ];
            }
        }

        return ['allowed' => true];
    }

    /**
     * Token bucket consumption using CI4 Throttler with memory fallback.
     */
    protected static function consume(string $key, int $capacity, int $seconds): bool
    {
        // When running under test override or in-memory mode, use memory window directly
        if (self::$testLoginIpLimit !== null || self::$testRefreshLimit !== null) {
            return self::consumeMemory($key, $capacity, $seconds);
        }

        // Try framework throttler
        try {
            $throttler = Services::throttler(false);
            if ($throttler !== null) {
                $passed = $throttler->check($key, $capacity, $seconds);
                if (!$passed) {
                    return false;
                }
            }
        } catch (\Throwable $e) {
            // cache backend not available during early bootstrap/tests
        }

        return self::consumeMemory($key, $capacity, $seconds);
    }

    protected static function consumeMemory(string $key, int $capacity, int $seconds): bool
    {
        $now = time();
        if (!isset(self::$memoryBuckets[$key])) {
            self::$memoryBuckets[$key] = [];
        }

        self::$memoryBuckets[$key] = array_values(array_filter(
            self::$memoryBuckets[$key],
            fn($ts) => ($now - $ts) < $seconds
        ));

        if (count(self::$memoryBuckets[$key]) >= $capacity) {
            return false;
        }

        self::$memoryBuckets[$key][] = $now;
        return true;
    }

    protected static function getRemainingSeconds(string $key, int $seconds): int
    {
        try {
            $throttler = Services::throttler(false);
            if ($throttler !== null) {
                $time = $throttler->getTokenTime();
                if ($time > 0) {
                    return $time;
                }
            }
        } catch (\Throwable $e) {
            // fallback
        }

        if (!empty(self::$memoryBuckets[$key])) {
            $oldest = min(self::$memoryBuckets[$key]);
            $remaining = $seconds - (time() - $oldest);
            return max(1, $remaining);
        }

        return $seconds;
    }
}
