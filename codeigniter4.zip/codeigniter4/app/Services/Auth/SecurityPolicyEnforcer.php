<?php

namespace App\Services\Auth;

use App\Models\SystemSettingModel;

class SecurityPolicyEnforcer
{
    /**
     * Check if a given client IP address is permitted according to configured whitelist.
     * Empty whitelist allows all IPs.
     *
     * @param string|null $clientIp
     * @param string|null $whitelistStr Comma-separated or newline-separated IPs/CIDRs
     * @return bool
     */
    public static function isIpAllowed(?string $clientIp, ?string $whitelistStr): bool
    {
        if (empty($clientIp)) {
            return false;
        }

        // Always allow localhost/loopback in dev environments
        if (in_array($clientIp, ['127.0.0.1', '::1', 'localhost'], true)) {
            return true;
        }

        if (empty($whitelistStr) || trim($whitelistStr) === '') {
            return true;
        }

        $entries = array_filter(array_map('trim', preg_split('/[\r\n,]+/', $whitelistStr)));
        if (empty($entries)) {
            return true;
        }

        foreach ($entries as $entry) {
            if ($clientIp === $entry) {
                return true;
            }

            // Check CIDR block
            if (strpos($entry, '/') !== false) {
                if (self::ipMatchesCidr($clientIp, $entry)) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Test whether an IPv4 or IPv6 address falls within a given CIDR block.
     *
     * @param string $ip
     * @param string $cidr
     * @return bool
     */
    public static function ipMatchesCidr(string $ip, string $cidr): bool
    {
        $parts = explode('/', trim($cidr), 2);
        if (count($parts) !== 2) {
            return false;
        }

        $subnet = $parts[0];
        $prefix = (int)$parts[1];

        // IPv4 CIDR matching
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) && filter_var($subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            if ($prefix < 0 || $prefix > 32) {
                return false;
            }
            if ($prefix === 0) {
                return true;
            }

            $ipLong = ip2long($ip);
            $subnetLong = ip2long($subnet);
            $mask = -1 << (32 - $prefix);

            return (($ipLong & $mask) === ($subnetLong & $mask));
        }

        // IPv6 CIDR matching
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) && filter_var($subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            if ($prefix < 0 || $prefix > 128) {
                return false;
            }
            if ($prefix === 0) {
                return true;
            }

            $ipBin = inet_pton($ip);
            $subnetBin = inet_pton($subnet);
            if ($ipBin === false || $subnetBin === false) {
                return false;
            }

            $bytes = (int)floor($prefix / 8);
            $bits = $prefix % 8;

            if ($bytes > 0 && substr($ipBin, 0, $bytes) !== substr($subnetBin, 0, $bytes)) {
                return false;
            }

            if ($bits > 0) {
                $mask = chr(0xFF << (8 - $bits));
                if (($ipBin[$bytes] & $mask) !== ($subnetBin[$bytes] & $mask)) {
                    return false;
                }
            }

            return true;
        }

        return false;
    }

    /**
     * Validate an IP string or CIDR representation.
     *
     * @param string $entry
     * @return bool
     */
    public static function validateCidrOrIp(string $entry): bool
    {
        $entry = trim($entry);
        if ($entry === '') {
            return true;
        }

        if (filter_var($entry, FILTER_VALIDATE_IP)) {
            return true;
        }

        if (strpos($entry, '/') !== false) {
            $parts = explode('/', $entry, 2);
            if (count($parts) === 2) {
                $ip = $parts[0];
                $prefix = $parts[1];
                if (!ctype_digit($prefix)) {
                    return false;
                }
                $prefixInt = (int)$prefix;

                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                    return ($prefixInt >= 0 && $prefixInt <= 32);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
                    return ($prefixInt >= 0 && $prefixInt <= 128);
                }
            }
        }

        return false;
    }

    /**
     * Validate a comma/newline separated whitelist string.
     * Returns an array of invalid entries (empty if all valid).
     *
     * @param string $whitelistStr
     * @return array
     */
    public static function validateWhitelistFormat(string $whitelistStr): array
    {
        $invalid = [];
        $entries = array_filter(array_map('trim', preg_split('/[\r\n,]+/', $whitelistStr)));

        foreach ($entries as $entry) {
            if (!self::validateCidrOrIp($entry)) {
                $invalid[] = $entry;
            }
        }

        return $invalid;
    }

    /**
     * Resolve unified security settings for a company (with global fallback).
     *
     * @param string|null $companyId
     * @return array
     */
    public static function resolveSettings(?string $companyId = null): array
    {
        $settingModel = new SystemSettingModel();
        $map = $settingModel->getAllSettings($companyId);

        $minLen = $map['min_password_length'] ?? $map['password_min_length'] ?? '8';
        $expiry = $map['password_expiry_days'] ?? '90';
        $reqNum = $map['require_numbers'] ?? $map['password_require_numbers'] ?? '1';
        $reqSym = $map['require_special_chars'] ?? $map['password_require_symbols'] ?? '1';
        $reqCase = $map['require_mixed_case'] ?? $map['password_require_uppercase'] ?? '1';
        $maxAttempts = $map['max_login_attempts'] ?? '5';
        $lockoutMins = $map['lockout_minutes'] ?? $map['lockout_duration_minutes'] ?? '15';
        $timeoutMins = $map['session_timeout_minutes'] ?? '120';
        $ipWhitelist = $map['ip_whitelist'] ?? $map['allowed_ip_whitelist'] ?? '';
        $enforce2fa = $map['enforce_2fa_admins'] ?? $map['enforce_mfa'] ?? $map['require_two_factor'] ?? '0';

        $disallowConc = $map['disallow_concurrent_logins'] ?? (isset($map['allow_simultaneous_logins']) ? ($map['allow_simultaneous_logins'] == '0' ? '1' : '0') : '0');

        return [
            'min_password_length'        => (string)$minLen,
            'password_expiry_days'       => (string)$expiry,
            'require_numbers'            => (string)$reqNum,
            'require_special_chars'      => (string)$reqSym,
            'require_mixed_case'         => (string)$reqCase,
            'max_login_attempts'         => (string)$maxAttempts,
            'lockout_minutes'            => (string)$lockoutMins,
            'session_timeout_minutes'    => (string)$timeoutMins,
            'ip_whitelist'               => (string)$ipWhitelist,
            'enforce_2fa_admins'         => (string)$enforce2fa,
            'disallow_concurrent_logins' => (string)$disallowConc,
        ];
    }
}
