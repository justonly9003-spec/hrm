<?php

namespace App\Services\Auth;

/**
 * Reusable Central Account Lockout Policy Service
 *
 * Single Source of Truth for account lockout rules across Web and Mobile:
 * - Max consecutive failed attempts: 5
 * - Lockout duration: 15 minutes (900 seconds)
 * - Automatic unlock after duration elapses upon legitimate credential verification
 * - Concurrency-safe atomic updates
 */
class AccountLockoutService
{
    public const MAX_FAILED_ATTEMPTS = 5;
    public const LOCKOUT_DURATION_SECONDS = 900; // 15 minutes

    /**
     * Resolve the max failed attempts threshold dynamically from settings (default 5, clamped 1..50).
     */
    public static function getMaxAttempts(?string $companyId = null): int
    {
        try {
            $settingModel = new \App\Models\SystemSettingModel();
            $val = $settingModel->getSetting('max_login_attempts', $companyId, null);
            if ($val !== null && $val !== '') {
                $attempts = (int)$val;
                if ($attempts >= 1 && $attempts <= 50) {
                    return $attempts;
                }
            }
        } catch (\Throwable $e) {}

        return self::MAX_FAILED_ATTEMPTS;
    }

    /**
     * Resolve the lockout duration in seconds dynamically from settings (default 15 mins, clamped 1..1440 mins).
     */
    public static function getLockoutDurationSeconds(?string $companyId = null): int
    {
        try {
            $settingModel = new \App\Models\SystemSettingModel();
            $val = $settingModel->getSetting('lockout_minutes', $companyId, null);
            if ($val === null || $val === '') {
                $val = $settingModel->getSetting('lockout_duration_minutes', $companyId, null);
            }
            if ($val !== null && $val !== '') {
                $minutes = (int)$val;
                if ($minutes >= 1 && $minutes <= 1440) {
                    return $minutes * 60;
                }
            }
        } catch (\Throwable $e) {}

        return self::LOCKOUT_DURATION_SECONDS;
    }

    /**
     * Check if a user account is currently locked due to exceeded failed attempts.
     */
    public static function isLocked(?array $user): bool
    {
        if (!$user) {
            return false;
        }

        if (!empty($user['locked_until'])) {
            $lockedTime = strtotime((string)$user['locked_until']);
            if ($lockedTime > time()) {
                return true;
            }
        }

        return false;
    }

    /**
     * Determine if a user's previous lockout duration has expired.
     */
    public static function isLockExpired(?array $user): bool
    {
        if (!$user || empty($user['locked_until'])) {
            return false;
        }

        return strtotime((string)$user['locked_until']) <= time();
    }

    /**
     * Get remaining lockout duration in seconds. Returns 0 if not locked.
     */
    public static function getRemainingLockoutSeconds(?array $user): int
    {
        if (empty($user['locked_until'])) {
            return 0;
        }

        $remaining = strtotime((string)$user['locked_until']) - time();
        return max(0, $remaining);
    }

    /**
     * Format standard user-facing lockout message with remaining minutes.
     */
    public static function getLockoutMessage(?array $user = null): string
    {
        $remainingSecs = self::getRemainingLockoutSeconds($user);
        $remainingMins = max(1, (int)ceil($remainingSecs / 60));
        return "Account is temporarily locked due to consecutive failed attempts. Please retry in {$remainingMins} minute(s) or contact administrator.";
    }

    /**
     * Initial lockout threshold hit message.
     */
    public static function getInitialLockoutMessage(?string $companyId = null): string
    {
        $durationMins = (int)ceil(self::getLockoutDurationSeconds($companyId) / 60);
        return "Too many failed login attempts. Your account has been temporarily locked for {$durationMins} minutes.";
    }
}
