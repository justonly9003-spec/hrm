<?php

namespace App\Services;

use Config\Database;
use App\Models\NotificationModel;
use App\Models\LeaveModel;
use App\Models\LeaveTypeModel;
use App\Models\LeaveBalanceModel;
use App\Models\LeaveTransactionModel;
use App\Models\HolidayModel;
use App\Models\EmployeeModel;
use App\Services\Rules\RuleResolver;
use App\Services\Rules\RuleNotConfiguredException;

class LeaveService
{
    public const MAX_LEAVE_SPAN_DAYS = 366;

    /**
     * Strict Y-m-d date format validator using DateTime::createFromFormat and getLastErrors().
     */
    public static function validateDateInput(?string $dateStr, string $fieldName = 'Date'): ?string
    {
        if (empty($dateStr) || !is_string($dateStr)) {
            return "{$fieldName} is required.";
        }
        $dt = \DateTime::createFromFormat('Y-m-d', $dateStr);
        $errors = \DateTime::getLastErrors();
        if (!$dt || !empty($errors['warning_count']) || !empty($errors['error_count']) || $dt->format('Y-m-d') !== $dateStr) {
            return "Invalid {$fieldName} '{$dateStr}'. Must be a valid date in Y-m-d format.";
        }
        return null;
    }

    /**
     * Validates date range: strict Y-m-d, from <= to, and max span cap (default 366 days).
     */
    public static function validateLeaveDateRange(?string $fromDate, ?string $toDate = null, int $maxSpanDays = self::MAX_LEAVE_SPAN_DAYS): ?string
    {
        $fromErr = self::validateDateInput($fromDate, 'Start date');
        if ($fromErr !== null) {
            return $fromErr;
        }

        if ($toDate !== null && $toDate !== '') {
            $toErr = self::validateDateInput($toDate, 'End date');
            if ($toErr !== null) {
                return $toErr;
            }

            $fromDt = \DateTime::createFromFormat('Y-m-d', $fromDate);
            $toDt = \DateTime::createFromFormat('Y-m-d', $toDate);

            if ($fromDt > $toDt) {
                return "Start date '{$fromDate}' cannot be after end date '{$toDate}'.";
            }

            $spanDays = (int)$fromDt->diff($toDt)->days + 1;
            if ($spanDays > $maxSpanDays) {
                return "Date range exceeds maximum permitted span of {$maxSpanDays} days (requested {$spanDays} days).";
            }
        }

        return null;
    }

    protected $db;
    protected LeaveModel $leaveModel;
    protected LeaveTypeModel $leaveTypeModel;
    protected LeaveBalanceModel $balanceModel;
    protected LeaveTransactionModel $transactionModel;
    protected HolidayModel $holidayModel;
    protected EmployeeModel $employeeModel;

    public function __construct()
    {
        $this->db = Database::connect();
        $this->leaveModel = new LeaveModel();
        $this->leaveTypeModel = new LeaveTypeModel();
        $this->balanceModel = new LeaveBalanceModel();
        $this->transactionModel = new LeaveTransactionModel();
        $this->holidayModel = new HolidayModel();
        $this->employeeModel = new EmployeeModel();
    }

    /**
     * Match master leave type code/name with rule definition entitlement code/name using standard business aliases.
     */
    /**
     * Resolve a raw leave name or code to its canonical code (e.g. 'Special Leave' => 'SPL').
     */
    public static function canonicalLeaveTypeCode(string $nameOrCode): string
    {
        return \App\Services\Leave\LeaveTypeMatcher::canonicalLeaveTypeCode($nameOrCode);
    }

    public static function matchLeaveTypeCode(string $codeA, ?string $codeB = null, ?string $typeName = null): mixed
    {
        return \App\Services\Leave\LeaveTypeMatcher::matchLeaveTypeCode($codeA, $codeB, $typeName);
    }

    /**
     * Resolve leave entitlement rule from Single Rule Store (RuleResolver domain LEAVE).
     *
     * @param string $companyId
     * @param array $employee Employee row with organizational context
     * @param array $leaveType Leave type master row (code, name, id)
     * @param string $asOfDate Effective date for rule resolution (YYYY-MM-DD)
     * @return array Resolved entitlement parameters array
     * @throws RuleNotConfiguredException
     */
    public function resolveLeaveEntitlement(string $companyId, array $employee, array $leaveType, string $asOfDate): array
    {
        $companyId = trim($companyId);
        if ($companyId === '') {
            throw new RuleNotConfiguredException("Company ID is required to resolve leave rules.", null, 'LEAVE', $asOfDate);
        }

        $leaveRule = (new RuleResolver())->resolve($companyId, 'LEAVE', $asOfDate, $employee);
        $entitlements = $leaveRule->get('entitlements') ?: [];
        $ltCode = strtoupper(trim((string)($leaveType['code'] ?? '')));
        $ltName = trim((string)($leaveType['name'] ?? ''));
        $leaveTypeId = (string)($leaveType['id'] ?? '');

        $ruleEnt = null;
        foreach ($entitlements as $ent) {
            $entCode = strtoupper(trim((string)($ent['leave_type_code'] ?? '')));
            $entName = trim((string)($ent['leave_type_name'] ?? ''));
            if ($entCode === $ltCode
                || ($ent['leave_type_id'] ?? '') === $leaveTypeId
                || (!empty($entName) && !empty($ltName) && strcasecmp($entName, $ltName) === 0)
                || self::matchLeaveTypeCode($ltCode, $entCode, $ltName ?: null)) {
                $ruleEnt = $ent;
                break;
            }
        }

        if (!$ruleEnt) {
            // Check mandatory Company layer if child layer partially defined entitlements
            try {
                $compRule = RuleResolver::resolveForCompany($companyId, 'LEAVE', $asOfDate);
                $compEnts = $compRule->get('entitlements') ?: [];
                foreach ($compEnts as $ent) {
                    $entCode = strtoupper(trim((string)($ent['leave_type_code'] ?? '')));
                    $entName = trim((string)($ent['leave_type_name'] ?? ''));
                    if ($entCode === $ltCode
                        || ($ent['leave_type_id'] ?? '') === $leaveTypeId
                        || (!empty($entName) && !empty($ltName) && strcasecmp($entName, $ltName) === 0)
                        || self::matchLeaveTypeCode($ltCode, $entCode, $ltName ?: null)) {
                        $ruleEnt = $ent;
                        break;
                    }
                }
            } catch (\Throwable $ce) {
                log_message('error', 'resolveLeaveEntitlement company fallback error: ' . $ce->getMessage());
            }
        }

        if (!$ruleEnt) {
            throw new RuleNotConfiguredException(
                "Leave entitlement rule not configured for leave type code '{$ltCode}' in domain LEAVE",
                $companyId,
                'LEAVE',
                $asOfDate
            );
        }

        return $ruleEnt;
    }




    /**
     * Lock and retrieve a single row using SELECT ... FOR UPDATE (safe across MySQL/Postgres/SQLite).
     *
     * @param string $table
     * @param array<string, mixed> $criteria
     * @return array|null
     */
    protected function lockRow(string $table, array $criteria): ?array
    {
        $isSqlite = stripos($this->db->DBDriver ?? '', 'sqlite') !== false;
        $builder = $this->db->table($table);
        foreach ($criteria as $col => $val) {
            $builder->where($col, $val);
        }
        $sql = $builder->getCompiledSelect() . ($isSqlite ? '' : ' FOR UPDATE');
        $result = $this->db->query($sql);
        return $result ? ($result->getRowArray() ?: null) : null;
    }

    /**
     * Resolve whether sandwich rule is enabled for the company/entitlement from Single Rule Store.
     * Enforces:
     * 1. Per-type sandwich_rule must be true (if false, it switches sandwich OFF).
     * 2. Company-level sandwich.enabled must be true.
     * 3. If applies_to_paid_only is true, the leave must be paid (is_paid === true).
     */
    public function isSandwichEnabled(string $companyId, array $employee, array $ruleEnt, string $date, ?bool $isPaid = null): bool
    {
        // 1. Per-type setting MUST be enabled. The per-type sandwich_rule: false switches it off.
        if (isset($ruleEnt['sandwich_rule']) && empty($ruleEnt['sandwich_rule'])) {
            return false;
        }
        if (empty($ruleEnt['sandwich_rule'])) {
            return false;
        }

        // 2. Company / Scope level rule from Single Rule Store (LEAVE domain)
        try {
            $leaveRule = (new \App\Services\Rules\RuleResolver())->resolve($companyId, 'LEAVE', $date, $employee);
            $swConfig = $leaveRule->get('sandwich');

            // If company-level sandwich rule is not enabled, sandwich is disabled
            if (empty($swConfig['enabled'])) {
                return false;
            }

            // 3. Check applies_to_paid_only
            $appliesToPaidOnly = isset($swConfig['applies_to_paid_only']) ? (bool)$swConfig['applies_to_paid_only'] : true;
            if ($appliesToPaidOnly) {
                $paid = $isPaid !== null ? $isPaid : (!empty($ruleEnt['is_paid']));
                if (!$paid) {
                    return false;
                }
            }

            return true;
        } catch (\Throwable $e) {
            log_message('warning', "isSandwichEnabled rule resolution fallback: " . $e->getMessage());
            $paid = $isPaid !== null ? $isPaid : (!empty($ruleEnt['is_paid']));
            return !empty($ruleEnt['sandwich_rule']) && $paid;
        }
    }

    /**
     * Check if a date range triggers the Sandwich Rule:
     * e.g. starts on a working day and ends on a working day across intervening weekends or holidays.
     * Fully honors weekend_treatment, holiday_treatment, bridge_leave_action, and applies_to_paid_only.
     */
    public function checkSandwichRule(
        string $fromDate,
        string $toDate,
        ?string $companyId = null,
        ?string $employeeId = null,
        ?array $policy = null,
        ?array $holidays = null,
        ?bool $isPaid = null
    ): array {
        $start = new \DateTime($fromDate);
        $end = new \DateTime($toDate);
        if ($start > $end) {
            $temp = $start;
            $start = $end;
            $end = $temp;
        }

        // Dynamically resolve configured weekly off days from CompanyWeekendService
        $compToResolve = $companyId;
        $emp = null;
        if (!empty($employeeId)) {
            try {
                $emp = $this->employeeModel->find($employeeId);
                $compToResolve = $compToResolve ?: ($emp['company_id'] ?? null);
            } catch (\Throwable $e) {
                log_message('error', 'checkSandwichRule employee resolution error: ' . $e->getMessage());
            }
        }
        if (empty($compToResolve) && function_exists('session') && session()->has('company_id')) {
            $compToResolve = session()->get('company_id');
        }

        // Resolve policy as of fromDate (not today)
        if ($policy === null && !empty($compToResolve)) {
            try {
                $policy = $this->resolvePolicyForEmployee($emp ?: ['id' => $employeeId, 'company_id' => $compToResolve], null, $fromDate);
            } catch (\Throwable $e) {
                log_message('warning', 'checkSandwichRule policy resolution error: ' . $e->getMessage());
            }
        }

        $calTreatment = [];
        if (!empty($policy['calendarTreatment']) && is_array($policy['calendarTreatment'])) {
            $calTreatment = $policy['calendarTreatment'];
        } elseif (!empty($policy['sandwich_rules_json'])) {
            $calTreatment = is_array($policy['sandwich_rules_json']) ? $policy['sandwich_rules_json'] : (json_decode($policy['sandwich_rules_json'], true) ?: []);
        }

        $sandwichEnabled = isset($calTreatment['enabled']) ? (bool)$calTreatment['enabled'] : true;
        $bridgeLeaveEnabled = isset($calTreatment['bridge_leave_enabled']) ? (bool)$calTreatment['bridge_leave_enabled'] : (isset($calTreatment['bridgeLeaveEnabled']) ? (bool)$calTreatment['bridgeLeaveEnabled'] : $sandwichEnabled);
        $bridgeLeaveAction = $calTreatment['bridge_leave_action'] ?? ($calTreatment['bridgeLeaveAction'] ?? 'Count intervening days');
        $appliesToPaidOnly = isset($calTreatment['applies_to_paid_only']) ? (bool)$calTreatment['applies_to_paid_only'] : (isset($calTreatment['appliesToPaidOnly']) ? (bool)$calTreatment['appliesToPaidOnly'] : true);

        if (!$sandwichEnabled || !$bridgeLeaveEnabled) {
            return [
                'applies'       => false,
                'sandwich_days' => 0,
                'message'       => 'Sandwich rule is disabled in company policy.'
            ];
        }

        if ($appliesToPaidOnly && $isPaid !== null && !$isPaid) {
            return [
                'applies'       => false,
                'sandwich_days' => 0,
                'message'       => 'Sandwich rule applies to paid leave types only.'
            ];
        }

        $countsIntervening = (strcasecmp(trim((string)$bridgeLeaveAction), 'count intervening days') === 0);
        if (!$countsIntervening) {
            return [
                'applies'       => false,
                'sandwich_days' => 0,
                'message'       => 'Bridge leave action is configured to exclude intervening days.'
            ];
        }

        $weekendTreatment = $calTreatment['weekend_treatment'] ?? ($calTreatment['weekendTreatment'] ?? 'Include if sandwiched');
        $holidayTreatment = $calTreatment['holiday_treatment'] ?? ($calTreatment['holidayTreatment'] ?? 'Include if sandwiched');
        $treatWeekendAsLeave = !empty($calTreatment['treat_weekend_as_leave']) || !empty($calTreatment['treatWeekendAsLeave']);
        $treatHolidayAsLeave = !empty($calTreatment['treat_holiday_as_leave']) || !empty($calTreatment['treatHolidayAsLeave']);

        $configuredWeeklyOff = \App\Services\CompanyWeekendService::getCompanyWeeklyOff($compToResolve, $employeeId);

        // Fetch holidays if not provided
        if ($holidays === null) {
            $holidays = [];
            try {
                $db = Database::connect();
                $fields = $db->tableExists('holidays') ? $db->getFieldNames('holidays') : [];
                $sDateStr = $start->format('Y-m-d');
                $eDateStr = $end->format('Y-m-d');

                $holidayBuilder = $this->holidayModel->builder();
                if (in_array('company_id', $fields, true) && !empty($compToResolve)) {
                    $holidayBuilder->groupStart()
                        ->where('company_id', $compToResolve)
                        ->orWhere('company_id IS NULL')
                        ->orWhere('company_id', '')
                    ->groupEnd();
                }
                if (in_array('status', $fields, true)) {
                    $holidayBuilder->groupStart()
                        ->where('status', 'Active')
                        ->orWhere('status', 'Published')
                        ->orWhere('status IS NULL')
                    ->groupEnd();
                }
                if (in_array('from_date', $fields, true) && in_array('to_date', $fields, true)) {
                    $holidayRows = $holidayBuilder
                        ->where('from_date <=', $eDateStr)
                        ->where('to_date >=', $sDateStr)
                        ->get()->getResultArray();
                    foreach ($holidayRows as $h) {
                        if (!$this->isHolidayApplicableToEmployee($h, $emp, $employeeId, $compToResolve)) {
                            continue;
                        }
                        $hStart = new \DateTime($h['from_date']);
                        $hEnd = new \DateTime($h['to_date']);
                        $hCurr = clone $hStart;
                        while ($hCurr <= $hEnd) {
                            $holidays[$hCurr->format('Y-m-d')] = $h['name'] ?? 'Public Holiday';
                            $hCurr->modify('+1 day');
                        }
                    }
                }
            } catch (\Throwable $e) {
                log_message('error', 'checkSandwichRule holiday lookup error: ' . $e->getMessage());
            }
        }

        $startDateStr = $start->format('Y-m-d');
        $endDateStr = $end->format('Y-m-d');
        $startDayName = $start->format('l');
        $endDayName = $end->format('l');

        // Working day check: neither weekly off nor public holiday
        $startIsWorking = !in_array($startDayName, $configuredWeeklyOff, true) && !isset($holidays[$startDateStr]);
        $endIsWorking = !in_array($endDayName, $configuredWeeklyOff, true) && !isset($holidays[$endDateStr]);

        $interveningWeekendCount = 0;
        $interveningHolidayCount = 0;
        $curr = clone $start;
        $curr->modify('+1 day');
        while ($curr < $end) {
            $dStr = $curr->format('Y-m-d');
            $dName = $curr->format('l');
            if (isset($holidays[$dStr])) {
                $interveningHolidayCount++;
            } elseif (in_array($dName, $configuredWeeklyOff, true)) {
                $interveningWeekendCount++;
            }
            $curr->modify('+1 day');
        }

        $isWeekendSandwiched = (strcasecmp(trim((string)$weekendTreatment), 'include if sandwiched') === 0);
        $isHolidaySandwiched = (strcasecmp(trim((string)$holidayTreatment), 'include if sandwiched') === 0);
        $shouldIncludeSandwichedWeekends = ($isWeekendSandwiched || $treatWeekendAsLeave);
        $shouldIncludeSandwichedHolidays = ($isHolidaySandwiched || $treatHolidayAsLeave);

        $isSandwich = ($startIsWorking && $endIsWorking && ($interveningWeekendCount > 0 || $interveningHolidayCount > 0));
        
        $sandwichDays = 0;
        if ($isSandwich) {
            if ($shouldIncludeSandwichedWeekends) {
                $sandwichDays += $interveningWeekendCount;
            }
            if ($shouldIncludeSandwichedHolidays) {
                $sandwichDays += $interveningHolidayCount;
            }
        }

        $applies = ($isSandwich && $sandwichDays > 0);

        return [
            'applies'                 => $applies,
            'sandwich_days'           => $sandwichDays,
            'sandwich_weekend_days'   => $shouldIncludeSandwichedWeekends ? $interveningWeekendCount : 0,
            'sandwich_holiday_days'   => $shouldIncludeSandwichedHolidays ? $interveningHolidayCount : 0,
            'message'                 => $applies
                ? "Sandwich Rule applies: Intervening non-working days are included in leave deduction (+{$sandwichDays} days)."
                : 'Standard work days calculation.'
        ];
    }

    /**
     * Determine whether a holiday is applicable to a specific employee based on company, branch, department, and employee scope.
     */
    public function isHolidayApplicableToEmployee(array $h, ?array $emp = null, ?string $employeeId = null, ?string $companyId = null): bool
    {
        $hCompId = $h['company_id'] ?? null;
        if (!empty($companyId)) {
            if (!empty($hCompId) && (string)$hCompId !== (string)$companyId) {
                return false;
            }
        } else {
            if (!empty($hCompId)) {
                return false;
            }
        }

        $hScope    = !empty($h['scope']) ? strtolower(trim((string)$h['scope'])) : 'global';
        $hEmpId    = $h['employee_id'] ?? null;
        $hBranchId = $h['branch_id'] ?? null;
        $hDeptId   = $h['department_id'] ?? null;

        $targetEmpId = $employeeId ?: ($emp['id'] ?? null);
        $empBranchId = $emp['branch_id'] ?? null;
        $empDeptId   = $emp['department_id'] ?? null;

        // Employee-specific scope check
        if (!empty($hEmpId)) {
            return !empty($targetEmpId) && (string)$hEmpId === (string)$targetEmpId;
        }
        if ($hScope === 'employee') {
            return !empty($targetEmpId) && !empty($hEmpId) && (string)$hEmpId === (string)$targetEmpId;
        }

        // Branch-specific scope check
        if (!empty($hBranchId)) {
            return !empty($empBranchId) && (string)$hBranchId === (string)$empBranchId;
        }
        if ($hScope === 'branch') {
            return !empty($empBranchId) && !empty($hBranchId) && (string)$hBranchId === (string)$empBranchId;
        }

        // Department-specific scope check
        if (!empty($hDeptId)) {
            return !empty($empDeptId) && (string)$hDeptId === (string)$empDeptId;
        }
        if ($hScope === 'department') {
            return !empty($empDeptId) && !empty($hDeptId) && (string)$hDeptId === (string)$empDeptId;
        }

        return true;
    }

    /**
     * Calculate net working days between two dates, taking into account
     * weekends, public holidays, half-day flags, and sandwich rules.
     */
    public function calculateLeaveDays(string $employeeId, string $fromDate, string $toDate, bool $isHalfDay = false, bool $sandwichRule = false, ?array $policy = null, ?bool $isPaid = null): array
    {
        $isHalfDay = $isHalfDay && $fromDate === $toDate;
        $startDate = new \DateTime($fromDate);
        $endDate = $isHalfDay ? clone $startDate : new \DateTime($toDate);
        if ($startDate > $endDate) {
            $temp = $startDate;
            $startDate = $endDate;
            $endDate = $temp;
        }

        $compToResolve = null;
        $emp = null;
        if (!empty($employeeId)) {
            try {
                $emp = $this->employeeModel->find($employeeId);
                $compToResolve = $emp['company_id'] ?? null;
                if ($policy === null && $emp) {
                    $policy = $this->resolvePolicyForEmployee($emp, null, $fromDate);
                }
            } catch (\Throwable $e) {
                log_message('error', 'calculateLeaveDays employee/policy resolution error: ' . $e->getMessage());
            }
        }
        if (empty($compToResolve) && function_exists('session') && session()->has('company_id')) {
            $compToResolve = session()->get('company_id');
        }
        if ($policy === null && !empty($compToResolve)) {
            try {
                $policy = $this->resolvePolicyForEmployee($emp ?: ['id' => $employeeId, 'company_id' => $compToResolve], null, $fromDate);
            } catch (\Throwable $e) {
                log_message('error', 'calculateLeaveDays company policy resolution error: ' . $e->getMessage());
            }
        }

        // Calendar Treatment resolution from policy
        $calTreatment = [];
        if (!empty($policy['calendarTreatment']) && is_array($policy['calendarTreatment'])) {
            $calTreatment = $policy['calendarTreatment'];
        } elseif (!empty($policy['sandwich_rules_json'])) {
            $calTreatment = is_array($policy['sandwich_rules_json']) ? $policy['sandwich_rules_json'] : (json_decode($policy['sandwich_rules_json'], true) ?: []);
        }

        $weekendTreatment = $calTreatment['weekend_treatment'] ?? ($calTreatment['weekendTreatment'] ?? 'Include if sandwiched');
        $holidayTreatment = $calTreatment['holiday_treatment'] ?? ($calTreatment['holidayTreatment'] ?? 'Include if sandwiched');

        $treatWeekendAsLeave = !empty($calTreatment['treat_weekend_as_leave']) || !empty($calTreatment['treatWeekendAsLeave']);
        $treatHolidayAsLeave = !empty($calTreatment['treat_holiday_as_leave']) || !empty($calTreatment['treatHolidayAsLeave']);

        $isWeekendSandwiched = (strcasecmp(trim((string)$weekendTreatment), 'include if sandwiched') === 0);
        $isWeekendExcluded   = (strcasecmp(trim((string)$weekendTreatment), 'exclude weekly off') === 0);
        $isWeekendAllLeave   = (strcasecmp(trim((string)$weekendTreatment), 'count weekly off as leave') === 0);

        $isHolidaySandwiched = (strcasecmp(trim((string)$holidayTreatment), 'include if sandwiched') === 0);
        $isHolidayExcluded   = (strcasecmp(trim((string)$holidayTreatment), 'exclude holidays') === 0);
        $isHolidayAllLeave   = in_array(strtolower(trim((string)$holidayTreatment)), ['count holidays as leave', 'count all calendar days'], true);

        // Unconditional counting across entire date range
        $countWeekendAsLeave = $isWeekendAllLeave || ($treatWeekendAsLeave && !$isWeekendSandwiched && !$isWeekendExcluded);
        $countHolidaysAsLeave = $isHolidayAllLeave || ($treatHolidayAsLeave && !$isHolidaySandwiched && !$isHolidayExcluded);

        $sandwichEnabled = isset($calTreatment['enabled']) ? (bool)$calTreatment['enabled'] : true;
        $bridgeLeaveEnabled = isset($calTreatment['bridge_leave_enabled']) ? (bool)$calTreatment['bridge_leave_enabled'] : (isset($calTreatment['bridgeLeaveEnabled']) ? (bool)$calTreatment['bridgeLeaveEnabled'] : $sandwichEnabled);
        $bridgeLeaveAction = $calTreatment['bridge_leave_action'] ?? ($calTreatment['bridgeLeaveAction'] ?? 'Count intervening days');
        $appliesToPaidOnly = isset($calTreatment['applies_to_paid_only']) ? (bool)$calTreatment['applies_to_paid_only'] : (isset($calTreatment['appliesToPaidOnly']) ? (bool)$calTreatment['appliesToPaidOnly'] : true);

        // If policy specifies applies_to_paid_only and this leave is known to be unpaid, sandwich cannot apply
        if ($appliesToPaidOnly && $isPaid !== null && !$isPaid) {
            $sandwichRule = false;
        }
        if (!$sandwichEnabled || !$bridgeLeaveEnabled) {
            $sandwichRule = false;
        }

        // Get declared holidays in range with strict company and organizational scoping
        $holidays = [];
        try {
            $db = Database::connect();
            $fields = $db->tableExists('holidays') ? $db->getFieldNames('holidays') : [];
            $sDateStr = $startDate->format('Y-m-d');
            $eDateStr = $endDate->format('Y-m-d');

            $holidayBuilder = $this->holidayModel->builder();
            if (in_array('company_id', $fields, true)) {
                if (!empty($compToResolve)) {
                    $holidayBuilder->groupStart()
                        ->where('company_id', $compToResolve)
                        ->orWhere('company_id IS NULL')
                        ->orWhere('company_id', '')
                    ->groupEnd();
                } else {
                    $holidayBuilder->groupStart()
                        ->where('company_id IS NULL')
                        ->orWhere('company_id', '')
                    ->groupEnd();
                }
            }
            if (in_array('status', $fields, true)) {
                $holidayBuilder->groupStart()
                    ->where('status', 'Active')
                    ->orWhere('status', 'Published')
                    ->orWhere('status IS NULL')
                ->groupEnd();
            }

            // Organizational scope filter at query level
            $empBranchId = $emp['branch_id'] ?? null;
            if (in_array('branch_id', $fields, true)) {
                if (!empty($empBranchId)) {
                    $holidayBuilder->groupStart()
                        ->where('branch_id', $empBranchId)
                        ->orWhere('branch_id IS NULL')
                        ->orWhere('branch_id', '')
                    ->groupEnd();
                } else {
                    $holidayBuilder->groupStart()
                        ->where('branch_id IS NULL')
                        ->orWhere('branch_id', '')
                    ->groupEnd();
                }
            }

            $empDeptId = $emp['department_id'] ?? null;
            if (in_array('department_id', $fields, true)) {
                if (!empty($empDeptId)) {
                    $holidayBuilder->groupStart()
                        ->where('department_id', $empDeptId)
                        ->orWhere('department_id IS NULL')
                        ->orWhere('department_id', '')
                    ->groupEnd();
                } else {
                    $holidayBuilder->groupStart()
                        ->where('department_id IS NULL')
                        ->orWhere('department_id', '')
                    ->groupEnd();
                }
            }

            $targetEmpId = $employeeId ?: ($emp['id'] ?? null);
            if (in_array('employee_id', $fields, true)) {
                if (!empty($targetEmpId)) {
                    $holidayBuilder->groupStart()
                        ->where('employee_id', $targetEmpId)
                        ->orWhere('employee_id IS NULL')
                        ->orWhere('employee_id', '')
                    ->groupEnd();
                } else {
                    $holidayBuilder->groupStart()
                        ->where('employee_id IS NULL')
                        ->orWhere('employee_id', '')
                    ->groupEnd();
                }
            }

            if (in_array('from_date', $fields, true) && in_array('to_date', $fields, true)) {
                $holidayRows = $holidayBuilder
                    ->where('from_date <=', $eDateStr)
                    ->where('to_date >=', $sDateStr)
                    ->get()->getResultArray();
                foreach ($holidayRows as $h) {
                    if (!$this->isHolidayApplicableToEmployee($h, $emp, $employeeId, $compToResolve)) {
                        continue;
                    }
                    $hStart = new \DateTime($h['from_date']);
                    $hEnd = new \DateTime($h['to_date']);
                    $hCurr = clone $hStart;
                    while ($hCurr <= $hEnd) {
                        $holidays[$hCurr->format('Y-m-d')] = $h['name'] ?? 'Public Holiday';
                        $hCurr->modify('+1 day');
                    }
                }
            } elseif (in_array('date', $fields, true)) {
                $holidayRows = $holidayBuilder
                    ->where('date >=', $sDateStr)
                    ->where('date <=', $eDateStr)
                    ->get()->getResultArray();
                foreach ($holidayRows as $h) {
                    if (!$this->isHolidayApplicableToEmployee($h, $emp, $employeeId, $compToResolve)) {
                        continue;
                    }
                    $holidays[$h['date']] = $h['name'] ?? 'Public Holiday';
                }
            }
        } catch (\Throwable $e) {
            log_message('error', 'calculateLeaveDays holiday lookup error: ' . $e->getMessage() . "\n" . $e->getTraceAsString());
        }

        $calendarDays = 0;
        $weekendDays = 0;
        $holidayDays = 0;
        $workingDays = 0;
        $breakdown = [];

        // Dynamically resolve configured weekly off days from CompanyWeekendService
        $configuredWeeklyOff = \App\Services\CompanyWeekendService::getCompanyWeeklyOff($compToResolve, $employeeId);

        $curr = clone $startDate;
        while ($curr <= $endDate) {
            $calendarDays++;
            $dateStr = $curr->format('Y-m-d');
            $dayName = $curr->format('l');

            // Dynamic weekly off based on configured company profile (e.g. ['Friday'], ['Friday', 'Saturday'], or ['Sunday'])
            $isWeekend = in_array($dayName, $configuredWeeklyOff, true);
            $isHoliday = isset($holidays[$dateStr]);
            $holidayName = $holidays[$dateStr] ?? null;

            if ($isHoliday) {
                $holidayDays++;
                $isChargeable = $countHolidaysAsLeave ? ($isHalfDay ? 0.5 : 1.0) : 0.0;
            } elseif ($isWeekend) {
                $weekendDays++;
                $isChargeable = $countWeekendAsLeave ? ($isHalfDay ? 0.5 : 1.0) : 0.0;
            } else {
                $workingDays += ($isHalfDay ? 0.5 : 1.0);
                $isChargeable = $isHalfDay ? 0.5 : 1.0;
            }

            $breakdown[] = [
                'date'         => $dateStr,
                'day_name'     => $dayName,
                'is_weekend'   => $isWeekend,
                'is_holiday'   => $isHoliday,
                'holiday_name' => $holidayName,
                'chargeable'   => $isChargeable
            ];

            $curr->modify('+1 day');
        }

        $startIsWorking = !empty($breakdown) && !$breakdown[0]['is_weekend'] && !$breakdown[0]['is_holiday'];
        $lastIdx = count($breakdown) - 1;
        $endIsWorking = !empty($breakdown) && !$breakdown[$lastIdx]['is_weekend'] && !$breakdown[$lastIdx]['is_holiday'];
        $isSandwichSpan = ($startIsWorking && $endIsWorking && count($breakdown) > 2);

        $countsIntervening = (strcasecmp(trim((string)$bridgeLeaveAction), 'count intervening days') === 0);
        $shouldIncludeSandwichedWeekends = ($isWeekendSandwiched || $treatWeekendAsLeave);
        $shouldIncludeSandwichedHolidays = ($isHolidaySandwiched || $treatHolidayAsLeave);

        $interveningWeekendCount = 0;
        $interveningHolidayCount = 0;
        $bridgeDaysAdded = 0;
        $sandwichApplies = false;

        if (!$isHalfDay && count($breakdown) > 2) {
            for ($i = 1; $i < $lastIdx; $i++) {
                if ($breakdown[$i]['is_holiday']) {
                    $interveningHolidayCount++;
                } elseif ($breakdown[$i]['is_weekend']) {
                    $interveningWeekendCount++;
                }
            }
        }

        $sandwichConditionMet = ($isSandwichSpan && ($interveningWeekendCount > 0 || $interveningHolidayCount > 0));

        if ($sandwichRule && !$isHalfDay && $bridgeLeaveEnabled && $countsIntervening && $isSandwichSpan) {
            for ($i = 1; $i < $lastIdx; $i++) {
                if ($breakdown[$i]['is_holiday']) {
                    if (!$countHolidaysAsLeave && $shouldIncludeSandwichedHolidays) {
                        $breakdown[$i]['chargeable'] = 1.0;
                        $bridgeDaysAdded++;
                        $sandwichApplies = true;
                    }
                } elseif ($breakdown[$i]['is_weekend']) {
                    if (!$countWeekendAsLeave && $shouldIncludeSandwichedWeekends) {
                        $breakdown[$i]['chargeable'] = 1.0;
                        $bridgeDaysAdded++;
                        $sandwichApplies = true;
                    }
                }
            }
        }

        $calculatedTotal = $isHalfDay ? $breakdown[0]['chargeable'] : $workingDays;

        if (!$isHalfDay) {
            if ($countWeekendAsLeave) {
                $calculatedTotal += $weekendDays;
            }
            if ($countHolidaysAsLeave) {
                $calculatedTotal += $holidayDays;
            }
            $calculatedTotal += $bridgeDaysAdded;
        }

        $breakdownText = "{$workingDays} working days" .
            ($weekendDays > 0 ? " + {$weekendDays} weekend days (" . ($countWeekendAsLeave ? 'counted' : ($shouldIncludeSandwichedWeekends && $sandwichApplies ? 'sandwiched' : 'excluded')) . ")" : '') .
            ($holidayDays > 0 ? " + {$holidayDays} holidays (" . ($countHolidaysAsLeave ? 'counted' : ($shouldIncludeSandwichedHolidays && $sandwichApplies ? 'sandwiched' : 'excluded')) . ")" : '') .
            ($bridgeDaysAdded > 0 ? " + {$bridgeDaysAdded} bridge/sandwiched days" : '') .
            " = {$calculatedTotal} total leave days.";

        return [
            'total_calendar_days' => $calendarDays,
            'working_days'        => $workingDays,
            'weekend_days'        => $weekendDays,
            'holiday_days'        => $holidayDays,
            'sandwich_days'       => $bridgeDaysAdded,
            'bridge_days_added'   => $bridgeDaysAdded,
            'sandwich_applies'    => $sandwichApplies,
            'chargeable_days'     => (float)$calculatedTotal,
            'breakdown_text'      => $breakdownText,
            'breakdown'           => $breakdown
        ];
    }

    /**
     * Splits chargeable leave days by entitlement period year (calendar year, fiscal year, or joining anniversary).
     * Consistently used across apply, approve, reject, and cancel.
     */
    public function splitLeaveDaysByYear(string $employeeId, string $fromDate, string $toDate, float $totalDays, bool $isHalfDay = false, bool $sandwichRule = false, ?bool $isPaid = null, ?array $ruleEnt = null): array
    {
        $fromYear = (int)date('Y', strtotime($fromDate));
        $toYear = (int)date('Y', strtotime($toDate));

        $emp = null;
        if (!empty($employeeId) && $this->db->tableExists('employees')) {
            try {
                $emp = $this->db->table('employees')->where('id', $employeeId)->get()->getRowArray();
            } catch (\Throwable $te) {
                $emp = null;
            }
        }

        $fromPeriod = $fromYear;
        $toPeriod = $toYear;
        if ($emp && $ruleEnt) {
            $fromBounds = \App\Services\Leave\LeaveAccrualCalculator::getLeavePeriodBounds($emp, $ruleEnt, $fromDate);
            $toBounds = \App\Services\Leave\LeaveAccrualCalculator::getLeavePeriodBounds($emp, $ruleEnt, $toDate);
            $fromPeriod = (int)$fromBounds['period_year'];
            $toPeriod = (int)$toBounds['period_year'];
        }

        if ($fromPeriod === $toPeriod || empty($employeeId) || $totalDays <= 0) {
            return [$fromPeriod => $totalDays];
        }

        try {
            $calc = $this->calculateLeaveDays($employeeId, $fromDate, $toDate, $isHalfDay, $sandwichRule, null, $isPaid);
            $breakdown = $calc['breakdown'] ?? [];
            if (empty($breakdown)) {
                return [$fromPeriod => $totalDays];
            }

            $split = [];
            $totalBreakdownChargeable = 0.0;
            foreach ($breakdown as $b) {
                $bDate = $b['date'] ?? null;
                if (!$bDate) continue;
                $pYear = ($emp && $ruleEnt)
                    ? (int)\App\Services\Leave\LeaveAccrualCalculator::getLeavePeriodBounds($emp, $ruleEnt, $bDate)['period_year']
                    : (int)date('Y', strtotime($bDate));
                $chargeable = (float)($b['chargeable'] ?? 0.0);
                if ($chargeable > 0) {
                    $split[$pYear] = ($split[$pYear] ?? 0.0) + $chargeable;
                    $totalBreakdownChargeable += $chargeable;
                }
            }

            if (empty($split)) {
                return [$fromPeriod => $totalDays];
            }

            // If calculated breakdown total matches totalDays, return directly
            if (abs($totalBreakdownChargeable - $totalDays) < 0.01) {
                return $split;
            }

            // Pro-rate if totalDays differs (e.g. customized or rounded total_days)
            $normalized = [];
            $accumulated = 0.0;
            $keys = array_keys($split);
            $lastIndex = count($keys) - 1;
            foreach ($keys as $idx => $yr) {
                if ($idx === $lastIndex) {
                    $normalized[$yr] = round($totalDays - $accumulated, 2);
                } else {
                    $portion = round(($split[$yr] / $totalBreakdownChargeable) * $totalDays, 2);
                    $normalized[$yr] = $portion;
                    $accumulated += $portion;
                }
            }
            return $normalized;
        } catch (\Throwable $e) {
            log_message('error', 'splitLeaveDaysByYear calculation error: ' . $e->getMessage());
            return [$fromPeriod => $totalDays];
        }
    }

    /**
     * Shared rule resolution for leave applications.
     * Used across applyLeave, simulateLeaveApplication, and updateLeave.
     *
     * Semantics: non-null value in $ruleEnt wins; else non-null/non-empty leave_types column;
     * else throw RuleNotConfiguredException. An explicit null means "not set", never false.
     *
     * @param array $ruleEnt Entitlement rules resolved from Rule Store
     * @param array $leaveType Master leave_types record
     * @return array Resolved application parameters
     * @throws \App\Services\Rules\RuleNotConfiguredException
     */
    /**
     * Authoritative single resolver for leave type parameter.
     * Semantics: non-null value in $ruleEnt wins; else non-null/non-empty leave_types column;
     * else throw RuleNotConfiguredException. An explicit null means "not set", never false.
     *
     * @param string $key
     * @param array|null $ruleEnt
     * @param array|null $leaveType
     * @return mixed
     * @throws \App\Services\Rules\RuleNotConfiguredException
     */
    public static function resolveLeaveTypeParam(string $key, ?array $ruleEnt, ?array $leaveType)
    {
        $keysToCheck = [$key];
        if ($key === 'requires_attachment') {
            $keysToCheck = ['requires_attachment', 'attachment_required', 'is_attachment_required'];
        } elseif ($key === 'attachment_required') {
            $keysToCheck = ['attachment_required', 'requires_attachment'];
        } elseif ($key === 'requires_reason') {
            $keysToCheck = ['requires_reason', 'reason_required', 'is_reason_required'];
        } elseif ($key === 'allow_unpaid_split') {
            $keysToCheck = ['allow_unpaid_split', 'unpaid_split_allowed'];
        } elseif ($key === 'requires_medical_certificate') {
            $keysToCheck = ['requires_medical_certificate', 'medical_certificate_required'];
        } elseif ($key === 'medical_certificate_threshold_days') {
            $keysToCheck = ['medical_certificate_threshold_days', 'medical_cert_threshold_days'];
        } elseif ($key === 'allow_hourly_leave') {
            $keysToCheck = ['allow_hourly_leave', 'hourly_leave_allowed'];
        } elseif ($key === 'approval_required') {
            $keysToCheck = ['approval_required', 'requires_approval'];
        } elseif ($key === 'is_auto_approved') {
            $keysToCheck = ['is_auto_approved', 'auto_approved'];
        } elseif ($key === 'auto_approve_under_days') {
            $keysToCheck = ['auto_approve_under_days', 'auto_approve_days_threshold'];
        } elseif ($key === 'allow_emergency_absence') {
            $keysToCheck = ['allow_emergency_absence', 'allow_emergency_application', 'allow_emergency'];
        } elseif ($key === 'allow_backdated_application') {
            $keysToCheck = ['allow_backdated_application', 'allow_backdate', 'allow_backdated'];
        } elseif ($key === 'backdated_role_requirement') {
            $keysToCheck = ['backdated_role_requirement', 'backdated_approval_role', 'backdated_role'];
        } elseif ($key === 'applicable_gender') {
            $keysToCheck = ['applicable_gender', 'gender', 'target_gender'];
        }

        foreach ($keysToCheck as $k) {
            if ($ruleEnt !== null && array_key_exists($k, $ruleEnt) && $ruleEnt[$k] !== null) {
                return $ruleEnt[$k];
            }
        }

        foreach ($keysToCheck as $k) {
            if ($leaveType !== null && array_key_exists($k, $leaveType) && $leaveType[$k] !== null && $leaveType[$k] !== '') {
                return $leaveType[$k];
            }
        }

        $ltName = $leaveType['name'] ?? ($leaveType['code'] ?? ($ruleEnt['leave_type_code'] ?? 'Unknown Leave Type'));
        throw new \App\Services\Rules\RuleNotConfiguredException("Rule parameter '{$key}' is not configured for '{$ltName}'");
    }

    public function resolveApplicationRules(?array $ruleEnt, ?array $leaveType): array
    {
        $ruleEnt = $ruleEnt ?? [];
        $leaveType = $leaveType ?? [];
        $ltName = $leaveType['name'] ?? ($leaveType['code'] ?? 'Unknown Leave Type');

        $resolveParam = function (string $key, bool $required = true, $default = null, string $cast = 'string') use ($ruleEnt, $leaveType, $ltName) {
            $val = null;
            try {
                $val = self::resolveLeaveTypeParam($key, $ruleEnt, $leaveType);
            } catch (\App\Services\Rules\RuleNotConfiguredException $e) {
                if ($required) {
                    throw $e;
                }
                $val = $default;
            }

            if ($val === null) {
                return null;
            }

            switch ($cast) {
                case 'bool':
                    return (bool)$val;
                case 'int':
                    return (int)$val;
                case 'float':
                    return (float)$val;
                default:
                    return (string)$val;
            }
        };

        $hourlyAllowed = (bool)self::resolveLeaveTypeParam('allow_hourly_leave', $ruleEnt, $leaveType);

        return [
            'applicable_gender'                  => $resolveParam('applicable_gender', false, 'All', 'string'),
            'approval_required'                  => $resolveParam('approval_required', false, true, 'bool'),
            'is_auto_approved'                   => $resolveParam('is_auto_approved', false, false, 'bool'),
            'auto_approve_under_days'            => $resolveParam('auto_approve_under_days', false, 0.0, 'float'),
            'allow_backdated_application'        => $resolveParam('allow_backdated_application', false, true, 'bool'),
            'max_backdate_days'                  => $resolveParam('max_backdate_days', false, 0, 'int'),
            'allow_future_application'           => $resolveParam('allow_future_application', true, null, 'bool'),
            'max_future_days'                    => $resolveParam('max_future_days', true, null, 'int'),
            'min_notice_days'                    => $resolveParam('min_notice_days', true, null, 'int'),
            'backdated_role_requirement'         => $resolveParam('backdated_role_requirement', false, '', 'string'),
            'allow_emergency_absence'            => $resolveParam('allow_emergency_absence', false, false, 'bool'),
            'allow_half_day'                     => $resolveParam('allow_half_day', true, null, 'bool'),
            'max_consecutive_days'               => $resolveParam('max_consecutive_days', true, null, 'int'),
            'allow_hourly_leave'                 => $hourlyAllowed,
            'min_hourly_hours'                   => $hourlyAllowed ? $resolveParam('min_hourly_hours', false, 2.0, 'float') : null,
            'max_hourly_hours'                   => $hourlyAllowed ? $resolveParam('max_hourly_hours', false, 4.0, 'float') : null,
            'is_paid'                            => $resolveParam('is_paid', true, null, 'bool'),
            'paid_percentage'                    => $resolveParam('paid_percentage', false, 100.0, 'float'),
            'affects_payroll'                    => $resolveParam('affects_payroll', false, true, 'bool'),
            'sandwich_rule'                      => $resolveParam('sandwich_rule', true, null, 'bool'),
            'allow_unpaid_split'                 => $resolveParam('allow_unpaid_split', true, null, 'bool'),
            'allow_negative_balance'             => $resolveParam('allow_negative_balance', true, null, 'bool'),
            'max_negative_days'                  => $resolveParam('max_negative_days', true, null, 'float'),
            'requires_attachment'                => $resolveParam('requires_attachment', true, null, 'bool'),
            'requires_medical_certificate'       => $resolveParam('requires_medical_certificate', true, null, 'bool'),
            'medical_certificate_threshold_days' => $resolveParam('medical_certificate_threshold_days', true, null, 'int'),
            'requires_reason'                    => $resolveParam('requires_reason', true, null, 'bool'),
            'carry_forward_percentage'           => $resolveParam('carry_forward_percentage', false, 100.0, 'float'),
            'carry_forward_expiry_months'        => $resolveParam('carry_forward_expiry_months', false, null, 'int'),
            'carry_forward_period'               => $resolveParam('carry_forward_period', false, 'calendar_year', 'string'),
        ];
    }

    /**
     * Check if an employee's gender makes them eligible for a given leave type.
     *
     * @param array $employee Employee row array with 'gender'
     * @param array|string $leaveType Leave type master row or leave type code
     * @param array|null $ruleEnt Resolved entitlement array from Single Rule Store (domain: LEAVE)
     * @return array ['eligible' => bool, 'reason' => string|null, 'applicable_gender' => string, 'employee_gender' => string]
     */
    public static function checkGenderEligibility(array $employee, $leaveType, ?array $ruleEnt = null): array
    {
        $rawEmpGender = trim((string)($employee['gender'] ?? ''));
        $empGenderLower = strtolower($rawEmpGender);

        $ltCode = strtoupper(trim(is_array($leaveType) ? (string)($leaveType['code'] ?? '') : (string)$leaveType));
        $ltName = is_array($leaveType) ? trim((string)($leaveType['name'] ?? '')) : '';

        // Determine applicable gender: rule entitlement takes precedence, then leave type table column, then inferred by code
        $reqGender = 'All';
        if ($ruleEnt !== null && !empty($ruleEnt['applicable_gender'])) {
            $reqGender = ucfirst(strtolower(trim((string)$ruleEnt['applicable_gender'])));
        } elseif (is_array($leaveType) && !empty($leaveType['applicable_gender'])) {
            $reqGender = ucfirst(strtolower(trim((string)$leaveType['applicable_gender'])));
        } else {
            if (in_array($ltCode, ['ML', 'MATERNITY'], true) || stripos($ltName, 'maternity') !== false) {
                $reqGender = 'Female';
            } elseif (in_array($ltCode, ['PL', 'PATERNITY'], true) || stripos($ltName, 'paternity') !== false) {
                $reqGender = 'Male';
            } else {
                $reqGender = 'All';
            }
        }

        if ($reqGender === 'All') {
            return [
                'eligible'          => true,
                'reason'            => null,
                'applicable_gender' => 'All',
                'employee_gender'   => $rawEmpGender,
            ];
        }

        if ($reqGender === 'Female') {
            $isFemale = in_array($empGenderLower, ['female', 'f', 'woman'], true);
            if (!$isFemale) {
                $displayName = !empty($ltName) ? $ltName : ($ltCode === 'ML' ? 'Maternity Leave' : 'Female-only leave');
                return [
                    'eligible'          => false,
                    'reason'            => "{$displayName} is only applicable to female employees.",
                    'applicable_gender' => 'Female',
                    'employee_gender'   => $rawEmpGender,
                ];
            }
            return [
                'eligible'          => true,
                'reason'            => null,
                'applicable_gender' => 'Female',
                'employee_gender'   => $rawEmpGender,
            ];
        }

        if ($reqGender === 'Male') {
            $isMale = in_array($empGenderLower, ['male', 'm', 'man'], true);
            if (!$isMale) {
                $displayName = !empty($ltName) ? $ltName : ($ltCode === 'PL' ? 'Paternity Leave' : 'Male-only leave');
                return [
                    'eligible'          => false,
                    'reason'            => "{$displayName} is only applicable to male employees.",
                    'applicable_gender' => 'Male',
                    'employee_gender'   => $rawEmpGender,
                ];
            }
            return [
                'eligible'          => true,
                'reason'            => null,
                'applicable_gender' => 'Male',
                'employee_gender'   => $rawEmpGender,
            ];
        }

        return [
            'eligible'          => true,
            'reason'            => null,
            'applicable_gender' => $reqGender,
            'employee_gender'   => $rawEmpGender,
        ];
    }

    /**
     * Get list of leave types that the specified employee is currently eligible for,
     * filtered by gender eligibility and company leave policy rules.
     *
     * @param string $companyId
     * @param string $employeeId
     * @param string|null $asOfDate
     * @param bool $filterProbation
     * @return array
     */
    public function getEligibleLeaveTypesForEmployee(string $companyId, string $employeeId, ?string $asOfDate = null, bool $filterProbation = false): array
    {
        $asOfDate = $asOfDate ?: date('Y-m-d');
        $employee = $this->employeeModel->find($employeeId);
        if (!$employee) {
            return [];
        }

        $allTypes = $this->leaveTypeModel->getActiveTypes($companyId);
        if (empty($allTypes)) {
            return [];
        }

        // Resolve LEAVE domain rule for this employee from Single Rule Store
        $entMap = [];
        try {
            $leaveRule = (new RuleResolver())->resolve($companyId, 'LEAVE', $asOfDate, $employee);
            $entitlements = $leaveRule->get('entitlements') ?: [];
            foreach ($entitlements as $ent) {
                $code = strtoupper(trim((string)($ent['leave_type_code'] ?? '')));
                if ($code !== '') {
                    $entMap[$code] = $ent;
                }
            }
        } catch (\Throwable $e) {
            log_message('warning', 'getEligibleLeaveTypesForEmployee resolve error: ' . $e->getMessage());
        }

        $probService = new \App\Services\ProbationLeaveEligibilityService();

        $eligibleTypes = [];
        foreach ($allTypes as $lt) {
            $c = strtoupper(trim((string)($lt['code'] ?? '')));
            $matchedEnt = $entMap[$c] ?? null;
            if (!$matchedEnt) {
                foreach ($entMap as $ec => $ev) {
                    if (self::matchLeaveTypeCode($c, $ec, $lt['name'] ?? null)) {
                        $matchedEnt = $ev;
                        break;
                    }
                }
            }

            // 1. Gender Eligibility Check
            $genderCheck = self::checkGenderEligibility($employee, $lt, $matchedEnt);
            if (!$genderCheck['eligible']) {
                continue; // Ineligible based on employee gender
            }

            // Enrich leave type array with rule properties
            $appGender = $matchedEnt['applicable_gender'] ?? $lt['applicable_gender'] ?? 'All';
            $isPaid = isset($matchedEnt['is_paid']) ? !empty($matchedEnt['is_paid']) : (!empty($lt['is_paid']));
            $daysVal = $matchedEnt['days_per_year'] ?? $lt['days_per_year'] ?? null;
            if ($daysVal === null) {
                throw \App\Services\Rules\Exceptions\RuleNotConfiguredException::forDomain($companyId, 'LEAVE', $asOfDate, "days_per_year not configured for leave type '{$lt['code']}'");
            }
            $daysPerYear = (float)$daysVal;
            $allowEmergency = !empty($matchedEnt['allow_emergency_absence']);

            // 2. Probation eligibility check
            $probationCheck = null;
            try {
                $probationCheck = $probService->checkLeaveEligibility($employeeId, $lt['id'], $asOfDate, null, $companyId);
            } catch (\Throwable $pe) {
                // If probation check throws, default to eligible
            }

            // If caller explicitly requested to filter out probation-ineligible types
            if ($filterProbation && $probationCheck && empty($probationCheck['is_eligible'])) {
                continue;
            }

            $lt['applicable_gender'] = $appGender;
            $lt['is_paid'] = $isPaid;
            $lt['paid_percentage'] = isset($matchedEnt['paid_percentage']) ? (float)$matchedEnt['paid_percentage'] : ($isPaid ? 100.0 : 0.0);
            $lt['days_per_year'] = $daysPerYear;
            $lt['allow_emergency_absence'] = $allowEmergency;
            $lt['is_probation_eligible'] = $probationCheck ? !empty($probationCheck['is_eligible']) : true;
            $lt['probation_blocked_reason'] = $probationCheck ? ($probationCheck['blocked_reason'] ?? null) : null;
            $lt['accrual_mode'] = $matchedEnt['accrual_mode'] ?? 'Fixed yearly days';
            $lt['carry_forward_allowed'] = !empty($matchedEnt['carry_forward_allowed']);
            $lt['carry_forward_max_days'] = $matchedEnt['carry_forward_max_days'] ?? 0;
            $lt['carry_forward_percentage'] = $matchedEnt['carry_forward_percentage'] ?? 100;
            $lt['carry_forward_expiry_months'] = $matchedEnt['carry_forward_expiry_months'] ?? 12;
            $lt['approval_required'] = isset($matchedEnt['approval_required']) ? !empty($matchedEnt['approval_required']) : true;
            $lt['is_auto_approved'] = !empty($matchedEnt['is_auto_approved']);

            $eligibleTypes[] = $lt;
        }

        return $eligibleTypes;
    }

    /**
     * Resolves the per-year paid and unpaid split for a leave application.
     * Uses persisted year_split JSON if present; otherwise falls back to splitLeaveDaysByYear.
     */
    public function resolveApplicationYearSplit(array $app, float $paidDays, float $unpaidDays, string $fromDate, string $toDate, bool $isHalfDay = false, bool $sandwichRule = false): array
    {
        $paidByYear = [];
        $unpaidByYear = [];

        if (!empty($app['year_split'])) {
            $decoded = is_array($app['year_split']) ? $app['year_split'] : json_decode((string)$app['year_split'], true);
            if (is_array($decoded)) {
                if (isset($decoded['paid']) || isset($decoded['unpaid'])) {
                    $paidByYear = is_array($decoded['paid'] ?? null) ? $decoded['paid'] : [];
                    $unpaidByYear = is_array($decoded['unpaid'] ?? null) ? $decoded['unpaid'] : [];
                } else {
                    foreach ($decoded as $yr => $data) {
                        if (is_array($data)) {
                            if (isset($data['paid'])) $paidByYear[$yr] = (float)$data['paid'];
                            if (isset($data['unpaid'])) $unpaidByYear[$yr] = (float)$data['unpaid'];
                        }
                    }
                }
            }
        }

        if (empty($paidByYear) && $paidDays > 0) {
            $paidByYear = $this->splitLeaveDaysByYear($app['employee_id'] ?? '', $fromDate, $toDate, $paidDays, $isHalfDay, $sandwichRule, true);
        }
        if (empty($unpaidByYear) && $unpaidDays > 0) {
            $unpaidByYear = $this->splitLeaveDaysByYear($app['employee_id'] ?? '', $fromDate, $toDate, $unpaidDays, $isHalfDay, $sandwichRule, false);
        }

        return [
            'paid'   => $paidByYear,
            'unpaid' => $unpaidByYear,
        ];
    }

    /**
     * Get or calculate balance with the mandatory Enterprise formula:
     * Available Balance = Opening + Allocation + Accrual + Carry Forward - Approved - Pending - Unpaid - Encashed
     *
     * @param bool $readOnly If true, guarantees zero DB mutations (no INSERT or UPDATE). Safe for simulation.
     */
    public function getEmployeeBalance(string $employeeId, string $leaveTypeId, int $year, ?array $leaveTypeData = null, bool $readOnly = false, ?string $asOfDate = null): array
    {
        $calcDate = $asOfDate ?: (($year === (int)date('Y')) ? date('Y-m-d') : "{$year}-12-31");

        $leaveType = $leaveTypeData ?: $this->db->table('leave_types')->where('id', $leaveTypeId)->get()->getRowArray();
        if (!$leaveType) {
            throw new \RuntimeException("Leave type '{$leaveTypeId}' not found.");
        }

        $emp = $this->db->table('employees')->where('id', $employeeId)->get()->getRowArray();
        if (!$emp) {
            throw new \RuntimeException("Employee '{$employeeId}' not found.");
        }

        $companyId = $emp['company_id'] ?? (function_exists('session') && session()->has('company_id') ? session()->get('company_id') : null);
        if (empty($companyId)) {
            throw new \App\Services\Rules\RuleNotConfiguredException(
                "Company ID context is missing for employee {$employeeId}",
                null,
                'LEAVE',
                $calcDate
            );
        }

        // 1. Resolve leave rule from single source: RuleResolver (LEAVE domain)
        $ruleEnt = $this->resolveLeaveEntitlement($companyId, $emp, $leaveType, $calcDate);

        // 2. Fetch recorded ledger row for this employee and year
        $balance = $this->db->table('leave_balances')
            ->where('employee_id', $employeeId)
            ->where('leave_type_id', $leaveTypeId)
            ->where('year', $year)
            ->get()
            ->getRowArray();

        $allocated    = (float)($balance['allocated_days'] ?? 0.0);
        $opening      = (float)($balance['opening_balance'] ?? 0.0);
        $carryForward = (float)($balance['carry_forward_days'] ?? $balance['carried_forward_days'] ?? 0.0);
        $approved     = (float)($balance['approved_leave_days'] ?? 0.0);
        $pending      = (float)($balance['pending_leave_days'] ?? 0.0);
        $unpaid       = (float)($balance['unpaid_adjustment_days'] ?? 0.0);
        $encashed     = (float)($balance['encashed_days'] ?? 0.0);
        $expired      = 0.0;
        $manualAdj    = (float)($balance['manual_adjustment_days'] ?? 0.0);
        $accrued      = (float)($balance['accrued_days'] ?? 0.0);

        // Also sync accrued days from transaction ledger if accrued transactions exist
        try {
            $txAccrued = (float)$this->db->table('leave_transactions')
                ->where('employee_id', $employeeId)
                ->where('leave_type_id', $leaveTypeId)
                ->where('transaction_type', 'Accrual')
                ->where("YEAR(created_at) = {$year}")
                ->selectSum('days')
                ->get()->getRowArray()['days'] ?? 0.0;
            $accrued = max($accrued, $txAccrued);
        } catch (\Throwable $e) {
            // Ignore transaction lookup errors
        }

        // Sync actual live approved and pending applications count if available
        try {
            $periodBounds = \App\Services\Leave\LeaveAccrualCalculator::getLeavePeriodBounds($emp, $ruleEnt, $calcDate);
            if ((int)$periodBounds['period_year'] === $year) {
                $startOfPeriod = $periodBounds['start_date'];
                $endOfPeriod   = $periodBounds['end_date'];
            } else {
                $midPeriodDate = sprintf('%04d-06-15', $year);
                $otherBounds = \App\Services\Leave\LeaveAccrualCalculator::getLeavePeriodBounds($emp, $ruleEnt, $midPeriodDate);
                $startOfPeriod = $otherBounds['start_date'];
                $endOfPeriod   = $otherBounds['end_date'];
            }

            $apps = $this->db->table('leave_applications')
                ->where('employee_id', $employeeId)
                ->groupStart()
                    ->where('leave_type_id', $leaveTypeId)
                    ->orWhere('unpaid_leave_type_id', $leaveTypeId)
                ->groupEnd()
                ->where(new \CodeIgniter\Database\RawSql(
                    'COALESCE(`from_date`, `start_date`) <= ' . $this->db->escape($endOfPeriod)
                ))
                ->where(new \CodeIgniter\Database\RawSql(
                    'COALESCE(`to_date`, `end_date`, `from_date`, `start_date`) >= ' . $this->db->escape($startOfPeriod)
                ))
                ->get()
                ->getResultArray();

            if (!empty($apps)) {
                $approvedSum = 0.0;
                $pendingSum = 0.0;
                foreach ($apps as $a) {
                    $st = strtolower((string)($a['status'] ?? ''));
                    if (!in_array($st, ['approved', 'pending'], true)) {
                        continue;
                    }

                    $days = null;
                    if (!empty($a['year_split'])) {
                        $split = is_array($a['year_split']) ? $a['year_split'] : json_decode((string)$a['year_split'], true);
                        if (is_array($split)) {
                            if (isset($split['paid']) || isset($split['unpaid'])) {
                                $p = (float)($split['paid'][$year] ?? $split['paid'][(string)$year] ?? 0);
                                $u = (float)($split['unpaid'][$year] ?? $split['unpaid'][(string)$year] ?? 0);
                                $days = ((string)($a['leave_type_id'] ?? '') === (string)$leaveTypeId) ? $p : $u;
                            } elseif (isset($split[$year]) || isset($split[(string)$year])) {
                                $yrData = $split[$year] ?? $split[(string)$year];
                                if (is_array($yrData)) {
                                    $p = (float)($yrData['paid'] ?? 0);
                                    $u = (float)($yrData['unpaid'] ?? 0);
                                    $days = ((string)($a['leave_type_id'] ?? '') === (string)$leaveTypeId) ? $p : $u;
                                } else {
                                    $days = (float)$yrData;
                                }
                            } else {
                                $days = 0.0;
                            }
                        }
                    }
                    if ($days === null) {
                        if ((string)($a['leave_type_id'] ?? '') === (string)$leaveTypeId) {
                            $days = isset($a['paid_days']) ? (float)$a['paid_days'] : (float)($a['total_days'] ?? 0);
                        } else {
                            $days = (float)($a['unpaid_days'] ?? 0);
                        }
                    }

                    if ($st === 'approved') {
                        $approvedSum += $days;
                    } elseif ($st === 'pending') {
                        $pendingSum += $days;
                    }
                }
                $approved = max($approved, $approvedSum);
                $pending  = max($pending, $pendingSum);
            }
        } catch (\Throwable $e) {
            log_message('error', 'getEmployeeBalance application aggregation error: ' . $e->getMessage());
        }

        // 3. Authoritative On-The-Fly Derivation via LeaveAccrualCalculator
        $ledgerTotals = [
            'opening_balance'        => $opening,
            'allocated_days'         => $allocated,
            'accrued_days'           => $accrued,
            'carry_forward_days'     => $carryForward,
            'approved_leave_days'    => $approved,
            'pending_leave_days'     => $pending,
            'unpaid_adjustment_days' => $unpaid,
            'encashed_days'          => $encashed,
            'expired_days'           => $expired,
            'manual_adjustment_days' => $manualAdj,
        ];

        $derived = \App\Services\Leave\LeaveAccrualCalculator::calculateLiveBalance(
            $emp,
            $ruleEnt,
            $ledgerTotals,
            $calcDate
        );

        $result = array_merge($balance ?: [], [
            'id'                     => $balance['id'] ?? ('bal-' . bin2hex(random_bytes(6))),
            'employee_id'            => $employeeId,
            'leave_type_id'          => $leaveTypeId,
            'year'                   => $year,
            'opening_balance'        => $derived['opening_balance'],
            'allocated_days'         => $derived['allocated_days'],
            'manual_adjustment_days' => $derived['manual_adjustment_days'],
            'accrued_days'           => $derived['earned_days'],
            'earned_days'            => $derived['earned_days'],
            'carry_forward_days'     => $derived['carry_forward_days'],
            'total_entitlement'      => $derived['total_entitlement'],
            'approved_leave_days'    => $derived['approved_leave_days'],
            'pending_leave_days'     => $derived['pending_leave_days'],
            'unpaid_adjustment_days' => $derived['unpaid_adjustment_days'],
            'encashed_days'          => $derived['encashed_days'],
            'expired_days'           => $derived['expired_days'],
            'total_deductions'       => $derived['total_deductions'],
            'total_used'             => $derived['total_used'],
            'available_balance'      => $derived['available_balance'],
            'remaining_after_pending'=> $derived['available_balance'],
            'as_of_date'             => $calcDate,
            'accrual_mode'           => $ruleEnt['accrual_mode'] ?? 'Fixed yearly days',
        ]);

        if (!$balance && !$readOnly) {
            try {
                $this->balanceModel->insert([
                    'id'                     => $result['id'],
                    'employee_id'            => $employeeId,
                    'leave_type_id'          => $leaveTypeId,
                    'year'                   => $year,
                    'opening_balance'        => $result['opening_balance'],
                    'allocated_days'         => $result['allocated_days'],
                    'accrued_days'           => (float)($ledgerTotals['Accrual'] ?? 0.0),
                    'carry_forward_days'     => $result['carry_forward_days'],
                    'approved_leave_days'    => $result['approved_leave_days'],
                    'pending_leave_days'     => $result['pending_leave_days'],
                    'unpaid_adjustment_days' => $result['unpaid_adjustment_days'],
                    'encashed_days'          => $result['encashed_days'],
                    'manual_adjustment_days' => $result['manual_adjustment_days'],
                ]);
            } catch (\Throwable $e) {
                log_message('error', 'getEmployeeBalance initial balance insert error: ' . $e->getMessage());
            }
        }

        // Check probation & waiting period eligibility
        try {
            $probService = new \App\Services\ProbationLeaveEligibilityService();
            $eligibility = $probService->checkLeaveEligibility($employeeId, $leaveTypeId, $calcDate, null, $companyId);
            $result['is_eligible'] = $eligibility['is_eligible'];
            $result['blocked_reason'] = $eligibility['blocked_reason'];
            $result['eligibility_mode'] = $eligibility['eligibility_mode'] ?? 'immediately';
            $result['eligibility_date'] = $eligibility['eligibility_date'] ?? null;
            $result['is_probation_restricted'] = !$eligibility['is_eligible'];
        } catch (\Throwable $e) {
            log_message('warning', 'getEmployeeBalance probation check error: ' . $e->getMessage());
            $result['is_eligible'] = false;
            $result['blocked_reason'] = 'Unable to verify probation eligibility: ' . $e->getMessage();
            $result['is_probation_restricted'] = true;
        }

        return $result;
    }

    /**
     * Read-only variant of getEmployeeBalance guaranteeing ZERO database mutation.
     * Guaranteed safe for simulation, dry-runs, and preview queries.
     */
    public function getEmployeeBalanceReadOnly(string $employeeId, string $leaveTypeId, int $year, ?array $leaveTypeData = null, ?string $asOfDate = null): array
    {
        return $this->getEmployeeBalance($employeeId, $leaveTypeId, $year, $leaveTypeData, true, $asOfDate);
    }

    /**
     * Get summary of all leave balances for an employee across all company active types
     */
    public function getEmployeeAllBalances(string $employeeId, ?int $year = null, ?string $companyId = null, ?string $asOfDate = null, bool $readOnly = false): array
    {
        $year = $year ?: (int)date('Y');

        // Look up employee's company if companyId is not provided
        if (empty($companyId)) {
            try {
                $emp = $this->db->table('employees')->where('id', $employeeId)->get()->getRowArray();
                if (!empty($emp['company_id'])) {
                    $companyId = $emp['company_id'];
                }
            } catch (\Throwable $e) {
                log_message('error', 'getEmployeeAllBalances company lookup error: ' . $e->getMessage());
            }
        }

        $types = $this->leaveTypeModel->getActiveTypes($companyId);
        $summary = [];

        foreach ($types as $t) {
            try {
                $bal = $this->getEmployeeBalance($employeeId, $t['id'], $year, $t, $readOnly, $asOfDate);
            } catch (\App\Services\Rules\RuleNotConfiguredException $e) {
                $bal = [
                    'opening_balance'         => 0.0,
                    'allocated_days'          => 0.0,
                    'accrued_days'            => 0.0,
                    'carry_forward_days'      => 0.0,
                    'approved_leave_days'     => 0.0,
                    'pending_leave_days'      => 0.0,
                    'unpaid_adjustment_days'  => 0.0,
                    'encashed_days'           => 0.0,
                    'total_entitlement'       => 0.0,
                    'available_balance'       => 0.0,
                    'remaining_after_pending' => 0.0,
                    'is_eligible'             => false,
                    'blocked_reason'          => $e->getMessage(),
                    'eligibility_date'        => null,
                    'is_probation_restricted' => false,
                ];
            }
            $summary[] = [
                'type_id'                 => $t['id'],
                'type_name'               => $t['name'],
                'type_code'               => $t['code'] ?? strtoupper(substr($t['name'], 0, 2)),
                'is_paid'                 => (bool)($t['is_paid'] ?? 1),
                'allow_carry_forward'     => (bool)($t['allow_carry_forward'] ?? 0),
                'opening_balance'         => (float)($bal['opening_balance'] ?? 0),
                'allocated_days'          => (float)($bal['allocated_days'] ?? 0),
                'accrued_days'            => (float)($bal['accrued_days'] ?? 0),
                'carry_forward_days'      => (float)($bal['carry_forward_days'] ?? 0),
                'approved_leave_days'     => (float)($bal['approved_leave_days'] ?? 0),
                'pending_leave_days'      => (float)($bal['pending_leave_days'] ?? 0),
                'unpaid_adjustment_days'  => (float)($bal['unpaid_adjustment_days'] ?? 0),
                'encashed_days'           => (float)($bal['encashed_days'] ?? 0),
                'total_entitlement'       => (float)($bal['total_entitlement'] ?? 0),
                'available_balance'       => (float)($bal['available_balance'] ?? 0),
                'remaining_after_pending' => (float)($bal['remaining_after_pending'] ?? 0),
                'is_eligible'             => (bool)($bal['is_eligible'] ?? true),
                'blocked_reason'          => $bal['blocked_reason'] ?? null,
                'eligibility_date'        => $bal['eligibility_date'] ?? null,
                'is_probation_restricted' => (bool)($bal['is_probation_restricted'] ?? false),
            ];
        }

        return $summary;
    }

    /**
     * Authoritatively resolve the Unpaid Leave / Loss of Pay type for a company
     * without fragile string matching. If not existing in master table, ensures standard type.
     */
    public function resolveAuthoritativeUnpaidLeaveType(string $companyId): array
    {
        $companyId = trim($companyId);
        if (empty($companyId)) {
            throw new RuleNotConfiguredException("Company ID is required to resolve unpaid leave category.");
        }

        // 1. Try to find active unpaid leave type belonging to this company by code 'UL' or 'LWP'
        $type = $this->db->table('leave_types')
            ->where('company_id', $companyId)
            ->where('is_paid', 0)
            ->whereIn('code', ['UL', 'LWP', 'UNPAID', 'LOP'])
            ->where('status', 'active')
            ->get()->getRowArray();

        if ($type) {
            return $type;
        }

        // 2. Try any active leave type with is_paid = 0 in the company
        $type = $this->db->table('leave_types')
            ->where('company_id', $companyId)
            ->where('is_paid', 0)
            ->where('status', 'active')
            ->orderBy('id', 'ASC')
            ->get()->getRowArray();

        if ($type) {
            return $type;
        }

        // 3. Fallback to global/unscoped unpaid leave type with code 'UL' or 'LWP'
        $type = $this->db->table('leave_types')
            ->groupStart()
                ->where('company_id IS NULL')
                ->orWhere('company_id', '')
            ->groupEnd()
            ->where('is_paid', 0)
            ->whereIn('code', ['UL', 'LWP', 'UNPAID', 'LOP'])
            ->where('status', 'active')
            ->get()->getRowArray();

        if ($type) {
            return $type;
        }

        // 4. Do not mutate master data tables at runtime during approval/transaction execution
        throw new \App\Services\Rules\RuleNotConfiguredException(
            "Unpaid leave category (code UL or LWP) is not configured in master data for company {$companyId}.",
            $companyId,
            'LEAVE',
            date('Y-m-d')
        );
    }

    /**
     * Dispatch notification to HR and Tenant Administrators.
     */
    public function notifyAdmins(
        string $title,
        string $message,
        string $module = 'leave',
        ?string $linkOrId = null,
        ?string $companyId = null,
        ?string $employeeId = null
    ): array {
        $notifModel = new NotificationModel();
        return $notifModel->notifyAdmins($title, $message, $module, $linkOrId, $companyId, $employeeId);
    }

    /**
     * Submit a new Leave Application with complete validation
     * Authoritatively delegated to LeaveApplicationService
     */
    public function applyLeave(array $data): array
    {
        return (new \App\Services\Leave\LeaveApplicationService($this))->applyLeave($data);
    }
    /**
     * Update/Edit existing leave application (e.g. by HR or Employee during pending state).
     * Enforces strict probation & waiting period eligibility on the updated leave dates,
     * evaluates sandwich rules, validates leave overlap, and checks quota balances (SEC-LV-09).
     */
    public function updateLeave(string $applicationId, array $data, string $editorId): array
    {
        // 0. Pre-transaction fetch and rule resolution to prevent open transactions on RuleNotConfiguredException
        $preApp = $this->db->table('leave_applications')->where('id', $applicationId)->get()->getRowArray();
        if (!$preApp) {
            return ['success' => false, 'message' => 'Leave application not found.'];
        }

        $oldStatus = $preApp['status'] ?? 'Pending';
        if (in_array(strtolower($oldStatus), ['cancelled', 'rejected'], true)) {
            return ['success' => false, 'message' => "Cannot modify a {$oldStatus} leave application."];
        }

        $rawOldFrom   = $preApp['from_date'] ?? $preApp['start_date'] ?? null;
        $rawOldTo     = $preApp['to_date'] ?? $preApp['end_date'] ?? $rawOldFrom;
        $oldFromDate  = !empty($rawOldFrom) ? date('Y-m-d', strtotime($rawOldFrom)) : null;
        $oldToDate    = !empty($rawOldTo) ? date('Y-m-d', strtotime($rawOldTo)) : $oldFromDate;
        $oldLtId      = (string)($preApp['leave_type_id'] ?? '');
        $oldIsHalfDay = !empty($preApp['is_half_day']) || (!empty($preApp['half_day']) && strcasecmp((string)$preApp['half_day'], 'None') !== 0);

        $employeeId   = $data['employee_id'] ?? $preApp['employee_id'];
        $leaveTypeId  = (string)($data['leave_type_id'] ?? $preApp['leave_type_id']);
        $rawFrom      = $data['from_date'] ?? $data['start_date'] ?? $oldFromDate;
        $rawTo        = $data['to_date'] ?? $data['end_date'] ?? $oldToDate;
        $fromDate     = !empty($rawFrom) ? date('Y-m-d', strtotime($rawFrom)) : $oldFromDate;
        $toDate       = !empty($rawTo) ? date('Y-m-d', strtotime($rawTo)) : $oldToDate;

        $isHalfDay = isset($data['is_half_day'])
            ? (bool)$data['is_half_day']
            : (isset($data['half_day']) ? strcasecmp((string)$data['half_day'], 'None') !== 0 : $oldIsHalfDay);

        $datesChanged    = ($fromDate !== $oldFromDate || $toDate !== $oldToDate);
        $typeChanged     = ($leaveTypeId !== $oldLtId);
        $halfDayChanged  = ($isHalfDay !== $oldIsHalfDay);
        $scheduleChanged = ($datesChanged || $typeChanged || $halfDayChanged);

        $leaveType = $this->db->table('leave_types')->where('id', $leaveTypeId)->get()->getRowArray();
        if (!$leaveType) {
            return ['success' => false, 'message' => 'Leave category not found.'];
        }

        $emp = $this->db->table('employees')->where('id', $employeeId)->get()->getRowArray();
        if ($emp && !empty($leaveType['company_id']) && (string)$leaveType['company_id'] !== (string)($emp['company_id'] ?? '')) {
            return ['success' => false, 'message' => '403 Forbidden: Selected leave category belongs to another organization.'];
        }
        if (!empty($data['covering_employee_id'])) {
            $coveringEmp = $this->db->table('employees')->where('id', $data['covering_employee_id'])->get()->getRowArray();
            if (!$coveringEmp || ($emp && (string)($coveringEmp['company_id'] ?? '') !== (string)($emp['company_id'] ?? ''))) {
                return ['success' => false, 'message' => '403 Forbidden: Covering employee must belong to the same organization.'];
            }
        }

        // Resolve Leave Entitlement from Single Rule Store BEFORE opening transaction
        $companyId = $emp['company_id'] ?? (function_exists('session') && session()->has('company_id') ? session()->get('company_id') : null);
        $ruleEnt = $this->resolveLeaveEntitlement((string)$companyId, $emp ?: ['id' => $employeeId, 'company_id' => $companyId], $leaveType, $fromDate);
        $appRules = $this->resolveApplicationRules($ruleEnt, $leaveType);

        $this->db->transStart();

        try {
            $app = $this->lockRow('leave_applications', [
                'id' => $applicationId,
            ]);

            if (!$app) {
                $this->db->transRollback();
                return ['success' => false, 'message' => 'Leave application not found.'];
            }

            // Check Attendance / Payroll Settlement if previously Approved and dates changed
            if (strtolower($oldStatus) === 'approved' && $datesChanged) {
                $attService = new \App\Services\AttendanceService();
                $oldStart = new \DateTime($oldFromDate);
                $oldEnd = new \DateTime($oldToDate);
                $curr = clone $oldStart;
                while ($curr <= $oldEnd) {
                    $d = $curr->format('Y-m-d');
                    if ($attService->isAttendanceSettled($employeeId, $d)) {
                        $this->db->transRollback();
                        return [
                            'success' => false,
                            'message' => "422 Unprocessable Entity: Cannot modify approved leave application. Attendance on {$d} is locked and settled in payroll."
                        ];
                    }
                    $curr->modify('+1 day');
                }
            }

            // 1. Check Overlapping Leaves (excluding current application, only if dates changed)
            if ($datesChanged) {
                $existingOverlap = $this->db->table('leave_applications')
                    ->where('employee_id', $employeeId)
                    ->where('id !=', $applicationId)
                    ->whereIn('status', ['Approved', 'Pending', 'Endorsed'])
                    ->groupStart()
                        ->where("from_date <=", $toDate)
                        ->where("to_date >=", $fromDate)
                    ->groupEnd()
                    ->countAllResults();

                if ($existingOverlap > 0) {
                    $this->db->transRollback();
                    return ['success' => false, 'message' => 'An active or pending leave application already exists within the requested dates.'];
                }
            }

            // 2. Check probation eligibility (only when dates or leave type changed)
            if ($datesChanged || $typeChanged) {
                try {
                    $probationService = new \App\Services\ProbationLeaveEligibilityService();
                    $eligibilityCheck = $probationService->checkLeaveEligibility($employeeId, $leaveTypeId, $fromDate);
                    if (!$eligibilityCheck['is_eligible']) {
                        $this->db->transRollback();
                        $blockedMsg = !empty($eligibilityCheck['blocked_reason'])
                            ? $eligibilityCheck['blocked_reason']
                            : "Annual Leave is not available until your probation period is completed.";
                        return [
                            'success'                 => false,
                            'message'                 => $blockedMsg,
                            'is_probation_restricted' => true,
                            'eligibility'             => $eligibilityCheck
                        ];
                    }
                } catch (\Throwable $e) {
                    log_message('error', 'Probation eligibility check in updateLeave error: ' . $e->getMessage());
                    $this->db->transRollback();
                    return [
                        'success' => false,
                        'message' => 'Unable to verify probation eligibility. Please try again or contact HR.'
                    ];
                }
            }

            $isPaid = $appRules['is_paid'];
            $sandwich = $this->isSandwichEnabled((string)$companyId, $emp ?: ['id' => $employeeId, 'company_id' => $companyId], $ruleEnt, $fromDate, $isPaid);

        // Determine user identity & bypass authority
        $isOwnApplication = !empty($data['is_own_application']);
        $canManage = !empty($data['can_manage_leave']);
        $isHR = $canManage || !empty($data['is_hr']);
        $isManager = $canManage || !empty($data['is_manager']);

        if (!empty($editorId)) {
            if ((string)$editorId === (string)$employeeId) {
                $isOwnApplication = true;
            } else {
                $actingEmpCheck = $this->db->table('employees')
                    ->where('user_id', $editorId)
                    ->orWhere('id', $editorId)
                    ->get()
                    ->getRowArray();
                if ($actingEmpCheck && (string)$actingEmpCheck['id'] === (string)$employeeId) {
                    $isOwnApplication = true;
                }
            }

            try {
                $permService = new \App\Services\PermissionService();
                if ($permService->isSoftwareAppAdmin()) {
                    $isHR = true;
                    $isManager = true;
                } else {
                    $isHR = $isHR
                         || $permService->can($editorId, 'leave.manage', ['company_id' => $companyId])->isAllowed()
                         || $permService->can($editorId, 'leave.approve', ['company_id' => $companyId])->isAllowed()
                         || $permService->can($editorId, 'leaves.manage', ['company_id' => $companyId])->isAllowed()
                         || $permService->can($editorId, 'leaves.approve', ['company_id' => $companyId])->isAllowed();
                    $isManager = $isHR 
                         || $permService->can($editorId, 'leave.endorse', ['company_id' => $companyId])->isAllowed()
                         || $permService->can($editorId, 'leaves.endorse', ['company_id' => $companyId])->isAllowed();
                }
            } catch (\Throwable $e) {
                log_message('error', 'updateLeave permService error: ' . $e->getMessage());
            }
        }
        $canBypassLimits = (!$isOwnApplication && ($isHR || $isManager));

        // 3b. Validate limits from Rule Store
        // Half-day check: run only when half-day or leave type changed (kept for both HR and employee)
        if ($halfDayChanged || $typeChanged) {
            $allowHalfDay = $appRules['allow_half_day'];
            if ($isHalfDay && !$allowHalfDay) {
                $this->db->transRollback();
                return ['success' => false, 'message' => "Half-day applications are not permitted for '{$leaveType['name']}'."];
            }
        }

        // Backdate and Notice checks: run only when dates or leave type changed
        if ($datesChanged || $typeChanged) {
            $today = date('Y-m-d');
            $isBackdated = ($fromDate < $today);
            $rawEmergency = !empty($app['is_emergency']) || !empty($data['is_emergency']) || !empty($data['is_urgent']);
            $allowEmergencyAbsence = (bool)($appRules['allow_emergency_absence'] ?? false);
            $isEmergency = false;

            if ($rawEmergency) {
                if (!$canBypassLimits && !$allowEmergencyAbsence) {
                    $this->db->transRollback();
                    return [
                        'success' => false,
                        'message' => "Emergency absence is not permitted for '{$leaveType['name']}'. Only HR and managers can submit emergency requests for this leave category."
                    ];
                }
                $checkReason = trim((string)($data['reason'] ?? $app['reason'] ?? ''));
                if (strlen($checkReason) < 5) {
                    $this->db->transRollback();
                    return [
                        'success' => false,
                        'message' => "A valid, detailed reason explaining the emergency absence is mandatory."
                    ];
                }
                $isEmergency = true;
            }

            $ltCode = strtoupper(trim((string)($leaveType['code'] ?? '')));
            $ltName = strtolower(trim((string)($leaveType['name'] ?? '')));
            $isSickLeave = ($ltCode === 'SL' || strpos($ltName, 'sick') !== false || strpos($ltCode, 'SICK') !== false);

            if ($isBackdated) {
                $allowBackdated = isset($appRules['allow_backdated_application']) ? (bool)$appRules['allow_backdated_application'] : true;
                $maxBackdateDays = (int)($appRules['max_backdate_days'] ?? 0);
                $diffDays = (int)ceil((strtotime($today) - strtotime($fromDate)) / 86400);

                if (!$canBypassLimits) {
                    if (!$allowBackdated) {
                        $this->db->transRollback();
                        return ['success' => false, 'message' => "Backdated leave applications are strictly disabled for '{$leaveType['name']}'."];
                    }
                    if ($maxBackdateDays > 0 && $diffDays > $maxBackdateDays) {
                        $this->db->transRollback();
                        if ($isEmergency) {
                            return ['success' => false, 'message' => "Backdated limit exceeded for '{$leaveType['name']}': Maximum allowed is {$maxBackdateDays} days in the past (requested {$diffDays} days ago). Emergency applications exceeding this limit must be submitted by HR or a Manager."];
                        }
                        return ['success' => false, 'message' => "Backdated limit exceeded for '{$leaveType['name']}': Maximum allowed is {$maxBackdateDays} days in the past (requested {$diffDays} days ago)."];
                    }
                }
            }

            // Minimum Notice Period: exempt for HR, permitted emergency, and same-day sick leave
            $minNoticeDays = (int)($appRules['min_notice_days'] ?? 0);
            if (!$isBackdated && $minNoticeDays > 0) {
                $isSameDaySick = ($isSickLeave && $fromDate === $today);
                $isExemptFromNotice = ($canBypassLimits || ($isEmergency && ($canBypassLimits || $allowEmergencyAbsence)) || $isSameDaySick);
                if (!$isExemptFromNotice) {
                    $noticeDays = (int)floor((strtotime($fromDate) - strtotime($today)) / 86400);
                    if ($noticeDays < $minNoticeDays) {
                        $this->db->transRollback();
                        return ['success' => false, 'message' => "Notice period requirement not met: '{$leaveType['name']}' requires at least {$minNoticeDays} days advance notice (provided {$noticeDays} days)."];
                    }
                }
            }
        }

        // 4. Calculate Net Working Days and Max Consecutive Days Limit
        if ($scheduleChanged) {
            $calc = $this->calculateLeaveDays($employeeId, $fromDate, $toDate, $isHalfDay, $sandwich, null, $isPaid);
            $newChargeableDays = $calc['chargeable_days'];

            // 4a. Maximum Consecutive Days Limit (kept for both HR and employee)
            $maxConsecutive = $appRules['max_consecutive_days'];
            if ($maxConsecutive > 0 && $newChargeableDays > $maxConsecutive) {
                $this->db->transRollback();
                return ['success' => false, 'message' => "Consecutive days limit exceeded: '{$leaveType['name']}' allows a maximum of {$maxConsecutive} consecutive days per application (requested {$newChargeableDays} days)."];
            }
        } else {
            $newChargeableDays = (float)($app['total_days'] ?? 1.0);
            $calc = [
                'chargeable_days'  => $newChargeableDays,
                'sandwich_applies' => !empty($app['sandwich_rule_applies']),
                'sandwich_days'    => (int)($app['sandwich_days_count'] ?? 0)
            ];
        }

        $oldPaidDays   = isset($app['paid_days']) ? (float)$app['paid_days'] : (float)($app['total_days'] ?? 1.0);
        $oldUnpaidDays = (float)($app['unpaid_days'] ?? 0.0);
        $oldSandwich   = !empty($app['sandwich_rule_applies']);

        $newPaidByYear = [];
        $newUnpaidByYear = [];
        $newPaidDays = (float)$newChargeableDays;
        $newUnpaidDays = 0.0;

        // 5. Balance Quota Check across years (only needed if schedule changed)
        if ($scheduleChanged) {
            // Revert old balance allocation across its split years
            $oldSplitData = $this->resolveApplicationYearSplit($app, $oldPaidDays, $oldUnpaidDays, $oldFromDate, $oldToDate, $oldIsHalfDay, $oldSandwich);
            $oldPaidByYear = $oldSplitData['paid'];
            $oldUnpaidByYear = $oldSplitData['unpaid'];
            $oldUnpaidLtId = $app['unpaid_leave_type_id'] ?? null;

            if (in_array(strtolower($oldStatus), ['pending', 'endorsed'], true)) {
                foreach ($oldPaidByYear as $yr => $yrDays) {
                    if ($yrDays <= 0) continue;
                    $this->db->query(
                        "UPDATE leave_balances SET pending_leave_days = CASE WHEN pending_leave_days - ? < 0 THEN 0 ELSE pending_leave_days - ? END 
                         WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                        [$yrDays, $yrDays, $employeeId, $oldLtId, $yr]
                    );
                }
                if ($oldUnpaidDays > 0 && !empty($oldUnpaidLtId)) {
                    foreach ($oldUnpaidByYear as $yr => $yrDays) {
                        if ($yrDays <= 0) continue;
                        $this->db->query(
                            "UPDATE leave_balances SET pending_leave_days = CASE WHEN pending_leave_days - ? < 0 THEN 0 ELSE pending_leave_days - ? END 
                             WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                            [$yrDays, $yrDays, $employeeId, $oldUnpaidLtId, $yr]
                        );
                    }
                }
            } elseif (strtolower($oldStatus) === 'approved') {
                foreach ($oldPaidByYear as $yr => $yrDays) {
                    if ($yrDays <= 0) continue;
                    $this->db->query(
                        "UPDATE leave_balances SET approved_leave_days = CASE WHEN approved_leave_days - ? < 0 THEN 0 ELSE approved_leave_days - ? END 
                         WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                        [$yrDays, $yrDays, $employeeId, $oldLtId, $yr]
                    );
                }
                if ($oldUnpaidDays > 0 && !empty($oldUnpaidLtId)) {
                    foreach ($oldUnpaidByYear as $yr => $yrDays) {
                        if ($yrDays <= 0) continue;
                        $this->db->query(
                            "UPDATE leave_balances SET approved_leave_days = CASE WHEN approved_leave_days - ? < 0 THEN 0 ELSE approved_leave_days - ? END,
                                                       unpaid_adjustment_days = CASE WHEN unpaid_adjustment_days - ? < 0 THEN 0 ELSE unpaid_adjustment_days - ? END
                             WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                            [$yrDays, $yrDays, $yrDays, $yrDays, $employeeId, $oldUnpaidLtId, $yr]
                        );
                    }
                }
            }

            // Calculate new per-year coverage
            $yearSplitCharge = $this->splitLeaveDaysByYear($employeeId, $fromDate, $toDate, (float)$newChargeableDays, $isHalfDay, !empty($calc['sandwich_applies']), $isPaid);
            $totalCoveredPaid = 0.0;
            $totalNeededUnpaid = 0.0;
            $shortageFound = false;
            $allowNegative = (bool)($appRules['allow_negative_balance'] ?? false);
            $maxNegative = (float)($appRules['max_negative_days'] ?? 0.0);

            foreach ($yearSplitCharge as $yr => $yrDays) {
                $this->lockRow('leave_balances', [
                    'employee_id'   => $employeeId,
                    'leave_type_id' => $leaveTypeId,
                    'year'          => $yr,
                ]);

                $asOfCheckDate = ($yr === (int)date('Y', strtotime($fromDate))) ? $fromDate : "{$yr}-01-01";
                try {
                    $liveBal = $this->getEmployeeBalanceReadOnly($employeeId, $leaveTypeId, $yr, $leaveType, $asOfCheckDate);
                } catch (RuleNotConfiguredException $e) {
                    $this->db->transRollback();
                    throw $e;
                }
                $avail = (float)($liveBal['available_balance'] ?? 0.0);

                if ($isPaid && ($avail < $yrDays)) {
                    $yrShortage = $yrDays - $avail;
                    if ($allowNegative && $maxNegative > 0 && $yrShortage <= $maxNegative) {
                        $totalCoveredPaid += $yrDays;
                        $newPaidByYear[$yr] = (float)$yrDays;
                        $newUnpaidByYear[$yr] = 0.0;
                    } else {
                        $shortageFound = true;
                        $covered = max(0.0, min($avail, $yrDays));
                        $unpaidPart = $yrDays - $covered;
                        $totalCoveredPaid += $covered;
                        $totalNeededUnpaid += $unpaidPart;
                        $newPaidByYear[$yr] = round($covered, 2);
                        $newUnpaidByYear[$yr] = round($unpaidPart, 2);
                    }
                } else {
                    $totalCoveredPaid += $yrDays;
                    $newPaidByYear[$yr] = $isPaid ? (float)$yrDays : 0.0;
                    $newUnpaidByYear[$yr] = $isPaid ? 0.0 : (float)$yrDays;
                }
            }

            if ($isPaid && $shortageFound && !$allowNegative) {
                if (empty($appRules['allow_unpaid_split'])) {
                    $this->db->transRollback();
                    return [
                        'success' => false,
                        'message' => "Insufficient leave balance for {$leaveType['name']} ({$totalCoveredPaid} days available, {$newChargeableDays} days requested)."
                    ];
                }
            }

            $paidPercentage = isset($appRules['paid_percentage']) && is_numeric($appRules['paid_percentage'])
                ? (float)$appRules['paid_percentage']
                : (isset($ruleEnt['paid_percentage']) && is_numeric($ruleEnt['paid_percentage']) ? (float)$ruleEnt['paid_percentage'] : 100.0);
            if ($paidPercentage < 0.0) $paidPercentage = 0.0;
            if ($paidPercentage > 100.0) $paidPercentage = 100.0;

            if ($isPaid && $shortageFound) {
                $coveredPaid = round($totalCoveredPaid, 2);
                $newPaidDays = round($coveredPaid * ($paidPercentage / 100.0), 2);
                $newUnpaidDays = round($newChargeableDays - $newPaidDays, 2);
                foreach ($yearSplitCharge as $yr => $yrDays) {
                    $cov = (float)($newPaidByYear[$yr] ?? 0.0);
                    $p = round($cov * ($paidPercentage / 100.0), 2);
                    $newPaidByYear[$yr] = $p;
                    $newUnpaidByYear[$yr] = round($yrDays - $p, 2);
                }
                $sumPaid = round(array_sum($newPaidByYear), 2);
                if ($sumPaid !== $newPaidDays && !empty($newPaidByYear)) {
                    $diff = round($newPaidDays - $sumPaid, 2);
                    $lastYr = array_key_last($newPaidByYear);
                    $newPaidByYear[$lastYr] = round($newPaidByYear[$lastYr] + $diff, 2);
                    $newUnpaidByYear[$lastYr] = round($yearSplitCharge[$lastYr] - $newPaidByYear[$lastYr], 2);
                }
            } elseif (!$isPaid || $paidPercentage <= 0.0) {
                $newPaidDays = 0.0;
                $newUnpaidDays = (float)$newChargeableDays;
                foreach ($yearSplitCharge as $yr => $yrDays) {
                    $newPaidByYear[$yr] = 0.0;
                    $newUnpaidByYear[$yr] = (float)$yrDays;
                }
            } else {
                if ($paidPercentage < 100.0) {
                    $newPaidDays = round($newChargeableDays * ($paidPercentage / 100.0), 2);
                    $newUnpaidDays = round($newChargeableDays - $newPaidDays, 2);
                    foreach ($yearSplitCharge as $yr => $yrDays) {
                        $p = round($yrDays * ($paidPercentage / 100.0), 2);
                        $newPaidByYear[$yr] = $p;
                        $newUnpaidByYear[$yr] = round($yrDays - $p, 2);
                    }
                    $sumPaid = round(array_sum($newPaidByYear), 2);
                    if ($sumPaid !== $newPaidDays && !empty($newPaidByYear)) {
                        $diff = round($newPaidDays - $sumPaid, 2);
                        $lastYr = array_key_last($newPaidByYear);
                        $newPaidByYear[$lastYr] = round($newPaidByYear[$lastYr] + $diff, 2);
                        $newUnpaidByYear[$lastYr] = round($yearSplitCharge[$lastYr] - $newPaidByYear[$lastYr], 2);
                    }
                } else {
                    $newPaidDays = (float)$newChargeableDays;
                    $newUnpaidDays = 0.0;
                    foreach ($yearSplitCharge as $yr => $yrDays) {
                        $newPaidByYear[$yr] = (float)$yrDays;
                        $newUnpaidByYear[$yr] = 0.0;
                    }
                }
            }

            // Resolve target unpaid leave type id if new unpaid days exist
            $targetUnpaidTypeId = null;
            if ($newUnpaidDays > 0) {
                $unpaidType = $this->resolveAuthoritativeUnpaidLeaveType((string)$companyId);
                $targetUnpaidTypeId = !empty($app['unpaid_leave_type_id']) ? $app['unpaid_leave_type_id'] : ($unpaidType['id'] ?? null);
            }

            // Apply new allocation across split years
            if (in_array(strtolower($oldStatus), ['pending', 'endorsed'], true)) {
                foreach ($newPaidByYear as $yr => $yrDays) {
                    if ($yrDays <= 0) continue;
                    $yrBalanceRow = $this->lockRow('leave_balances', [
                        'employee_id'   => $employeeId,
                        'leave_type_id' => $leaveTypeId,
                        'year'          => $yr,
                    ]);
                    if ($yrBalanceRow) {
                        $this->db->query(
                            "UPDATE leave_balances SET pending_leave_days = pending_leave_days + ? 
                             WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                            [$yrDays, $employeeId, $leaveTypeId, $yr]
                        );
                    } else {
                        $this->db->table('leave_balances')->insert([
                            'id'                  => 'bal-' . bin2hex(random_bytes(6)),
                            'employee_id'         => $employeeId,
                            'leave_type_id'       => $leaveTypeId,
                            'year'                => $yr,
                            'pending_leave_days'  => $yrDays,
                            'created_at'          => date('Y-m-d H:i:s'),
                            'updated_at'          => date('Y-m-d H:i:s')
                        ]);
                    }
                }
                if ($newUnpaidDays > 0 && !empty($targetUnpaidTypeId)) {
                    foreach ($newUnpaidByYear as $yr => $yrDays) {
                        if ($yrDays <= 0) continue;
                        $yrBalanceRow = $this->lockRow('leave_balances', [
                            'employee_id'   => $employeeId,
                            'leave_type_id' => $targetUnpaidTypeId,
                            'year'          => $yr,
                        ]);
                        if ($yrBalanceRow) {
                            $this->db->query(
                                "UPDATE leave_balances SET pending_leave_days = pending_leave_days + ? 
                                 WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                                [$yrDays, $employeeId, $targetUnpaidTypeId, $yr]
                            );
                        } else {
                            $this->db->table('leave_balances')->insert([
                                'id'                  => 'bal-' . bin2hex(random_bytes(6)),
                                'employee_id'         => $employeeId,
                                'leave_type_id'       => $targetUnpaidTypeId,
                                'year'                => $yr,
                                'pending_leave_days'  => $yrDays,
                                'created_at'          => date('Y-m-d H:i:s'),
                                'updated_at'          => date('Y-m-d H:i:s')
                            ]);
                        }
                    }
                }
            } elseif (strtolower($oldStatus) === 'approved') {
                foreach ($newPaidByYear as $yr => $yrDays) {
                    if ($yrDays <= 0) continue;
                    $yrBalanceRow = $this->lockRow('leave_balances', [
                        'employee_id'   => $employeeId,
                        'leave_type_id' => $leaveTypeId,
                        'year'          => $yr,
                    ]);
                    if ($yrBalanceRow) {
                        $this->db->query(
                            "UPDATE leave_balances SET approved_leave_days = approved_leave_days + ? 
                             WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                            [$yrDays, $employeeId, $leaveTypeId, $yr]
                        );
                    } else {
                        $this->db->table('leave_balances')->insert([
                            'id'                  => 'bal-' . bin2hex(random_bytes(6)),
                            'employee_id'         => $employeeId,
                            'leave_type_id'       => $leaveTypeId,
                            'year'                => $yr,
                            'approved_leave_days' => $yrDays,
                            'created_at'          => date('Y-m-d H:i:s'),
                            'updated_at'          => date('Y-m-d H:i:s')
                        ]);
                    }
                }
                if ($newUnpaidDays > 0 && !empty($targetUnpaidTypeId)) {
                    foreach ($newUnpaidByYear as $yr => $yrDays) {
                        if ($yrDays <= 0) continue;
                        $yrBalanceRow = $this->lockRow('leave_balances', [
                            'employee_id'   => $employeeId,
                            'leave_type_id' => $targetUnpaidTypeId,
                            'year'          => $yr,
                        ]);
                        if ($yrBalanceRow) {
                            $this->db->query(
                                "UPDATE leave_balances SET approved_leave_days = approved_leave_days + ?,
                                                           unpaid_adjustment_days = unpaid_adjustment_days + ?
                                 WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                                [$yrDays, $yrDays, $employeeId, $targetUnpaidTypeId, $yr]
                            );
                        } else {
                            $this->db->table('leave_balances')->insert([
                                'id'                     => 'bal-' . bin2hex(random_bytes(6)),
                                'employee_id'            => $employeeId,
                                'leave_type_id'          => $targetUnpaidTypeId,
                                'year'                   => $yr,
                                'approved_leave_days'    => $yrDays,
                                'unpaid_adjustment_days' => $yrDays,
                                'created_at'             => date('Y-m-d H:i:s'),
                                'updated_at'             => date('Y-m-d H:i:s')
                            ]);
                        }
                    }
                }
            }
        } else {
            $currSplit = $this->resolveApplicationYearSplit($app, $oldPaidDays, $oldUnpaidDays, $oldFromDate, $oldToDate, $oldIsHalfDay, $oldSandwich);
            $newPaidByYear = $currSplit['paid'];
            $newUnpaidByYear = $currSplit['unpaid'];
            $newPaidDays = $oldPaidDays;
            $newUnpaidDays = $oldUnpaidDays;
        }

        if (strtolower($oldStatus) === 'approved' && $datesChanged) {

            // Sync attendance logs for newly adjusted approved dates
            $oldStart = new \DateTime($oldFromDate);
            $oldEnd = new \DateTime($oldToDate);
            $newStart = new \DateTime($fromDate);
            $newEnd = new \DateTime($toDate);

            // Clear old attendance that is no longer in the new range
            $curr = clone $oldStart;
            while ($curr <= $oldEnd) {
                $d = $curr->format('Y-m-d');
                if ($d < $fromDate || $d > $toDate) {
                    $attLog = $this->db->table('attendance_logs')
                        ->where('employee_id', $employeeId)
                        ->where('date', $d)
                        ->get()
                        ->getRowArray();
                    if ($attLog && ($attLog['status'] ?? '') === 'On Leave' && ($attLog['verification_method'] ?? '') === 'SYSTEM_LEAVE_SYNC') {
                        $this->db->table('attendance_logs')->where('id', $attLog['id'])->delete();
                    }
                }
                $curr->modify('+1 day');
            }

            // Set new attendance logs
            $empRecord = $this->db->table('employees')->where('id', $employeeId)->get()->getRowArray();
            $empCompanyId = $empRecord['company_id'] ?? null;

            $curr = clone $newStart;
            while ($curr <= $newEnd) {
                $d = $curr->format('Y-m-d');
                $attExists = $this->db->table('attendance_logs')
                    ->where('employee_id', $employeeId)
                    ->where('date', $d)
                    ->get()
                    ->getRowArray();
                if ($attExists) {
                    $this->db->table('attendance_logs')
                        ->where('id', $attExists['id'])
                        ->update(['status' => 'On Leave', 'is_approved' => 1, 'updated_at' => date('Y-m-d H:i:s')]);
                } else {
                    $this->db->table('attendance_logs')->insert([
                        'id'                  => 'att-' . bin2hex(random_bytes(6)),
                        'company_id'          => $empCompanyId,
                        'employee_id'         => $employeeId,
                        'date'                => $d,
                        'status'              => 'On Leave',
                        'working_hours'       => 0.0,
                        'late_minutes'        => 0,
                        'is_approved'         => 1,
                        'verification_method' => 'SYSTEM_LEAVE_SYNC',
                        'created_at'          => date('Y-m-d H:i:s'),
                        'updated_at'          => date('Y-m-d H:i:s')
                    ]);
                }
                $curr->modify('+1 day');
            }
        }

        $updatePayload = [
            'leave_type_id'         => $leaveTypeId,
            'from_date'             => $fromDate,
            'to_date'               => $toDate,
            'start_date'            => $fromDate,
            'end_date'              => $toDate,
            'total_days'            => $newChargeableDays,
            'paid_days'             => $newPaidDays,
            'unpaid_days'           => $newUnpaidDays,
            'year_split'            => json_encode(['paid' => $newPaidByYear, 'unpaid' => $newUnpaidByYear]),
            'is_half_day'           => $isHalfDay ? 1 : 0,
            'half_day'              => $isHalfDay ? (!empty($data['half_day']) && in_array($data['half_day'], ['First Half', 'Second Half'], true) ? $data['half_day'] : 'First Half') : 'None',
            'sandwich_rule_applies' => !empty($calc['sandwich_applies']) ? 1 : 0,
            'sandwich_days_count'   => (int)($calc['sandwich_days'] ?? 0),
            'reason'                => $data['reason'] ?? $app['reason'],
            'updated_at'            => date('Y-m-d H:i:s')
        ];

        if (isset($data['is_emergency']) || isset($data['is_urgent'])) {
            $updatePayload['is_emergency'] = $isEmergency ? 1 : 0;
        }

        if (!empty($data['emergency_contact'])) {
            $updatePayload['emergency_contact'] = $data['emergency_contact'];
        }
        if (!empty($data['covering_employee_id'])) {
            $updatePayload['covering_employee_id'] = $data['covering_employee_id'];
        }
        if (!empty($data['attachment_path'])) {
            $updatePayload['attachment_path'] = $data['attachment_path'];
        }
        if ($newUnpaidDays > 0) {
            if (empty($targetUnpaidTypeId)) {
                $unpaidType = $this->resolveAuthoritativeUnpaidLeaveType((string)$companyId);
                $targetUnpaidTypeId = !empty($app['unpaid_leave_type_id']) ? $app['unpaid_leave_type_id'] : ($unpaidType['id'] ?? null);
            }
            $updatePayload['unpaid_leave_type_id'] = $targetUnpaidTypeId;
        } else {
            $updatePayload['unpaid_leave_type_id'] = null;
        }

        $today = date('Y-m-d');
        $isBackdated = ($fromDate < $today);
        $backdatedRole = null;
        if ($isBackdated) {
            $backdatedRole = !empty($data['backdated_role'])
                ? trim((string)$data['backdated_role'])
                : trim((string)($appRules['backdated_role_requirement'] ?? ''));
        }

        $updatePayload['is_backdated'] = $isBackdated ? 1 : 0;
        $updatePayload['backdated_role'] = ($isBackdated && !empty($backdatedRole)) ? $backdatedRole : null;

        // Recompute required approvers based on updated dates, duration, and backdated policy
        $approvalWorkflow = [];
        try {
            $leaveRule = \App\Services\Rules\RuleResolver::resolve((string)$companyId, 'LEAVE', $fromDate, $emp ?: ['id' => $employeeId, 'company_id' => $companyId]);
            $approvalWorkflow = $leaveRule->get('approval_workflow') ?: [];
        } catch (\Throwable $wfEx) {
            log_message('warning', "updateLeave: failed to resolve LEAVE rule workflow: {$wfEx->getMessage()}");
        }

        $newRequiredApprovers = \App\Services\Leave\LeaveApplicationService::resolveRequiredApproversForApplication(
            $approvalWorkflow,
            (float)$newChargeableDays,
            $isBackdated,
            $backdatedRole ?: ''
        );

        $requiresManagerTier = \App\Services\Leave\LeaveApplicationService::isManagerTierRequired($newRequiredApprovers);
        $requiresDeptHead = in_array('Department Head', $newRequiredApprovers, true);
        $requiresHrAdmin = in_array('HR Admin', $newRequiredApprovers, true) || in_array('HR', $newRequiredApprovers, true) || in_array('HR Administration', $newRequiredApprovers, true);

        // A material edit (dates, leave type, half-day or day count) invalidates earlier endorsements:
        // the approvers endorsed a different request, so the approval chain starts again.
        $totalDaysChanged = abs((float)$newChargeableDays - (float)($app['total_days'] ?? 0)) > 0.001;
        $resetEndorsements = (strtolower((string)$oldStatus) !== 'approved')
            && ($scheduleChanged || $totalDaysChanged);

        if (strtolower((string)($oldStatus)) !== 'approved') {
            if ($resetEndorsements) {
                $updatePayload['manager_id']            = null;
                $updatePayload['manager_name']          = null;
                $updatePayload['manager_endorsed_at']   = null;
                $updatePayload['manager_remarks']       = null;
                $updatePayload['dept_head_id']          = null;
                $updatePayload['dept_head_name']        = null;
                $updatePayload['dept_head_endorsed_at'] = null;
                $updatePayload['dept_head_remarks']     = null;
                $updatePayload['hr_id']                 = null;
                $updatePayload['hr_name']               = null;
                $updatePayload['hr_approved_at']        = null;
                $updatePayload['hr_remarks']            = null;
                if (strtolower((string)$oldStatus) !== 'pending') {
                    $updatePayload['status'] = 'Pending';
                }
            }

            if ($requiresManagerTier || in_array('Manager', $newRequiredApprovers, true)) {
                if ($resetEndorsements || empty($app['manager_status'])) {
                    $updatePayload['manager_status'] = 'Pending';
                }
            } else {
                $updatePayload['manager_status'] = null;
            }

            if ($requiresHrAdmin) {
                if ($resetEndorsements || empty($app['hr_status'])) {
                    $updatePayload['hr_status'] = 'Pending';
                }
            } else {
                $updatePayload['hr_status'] = null;
            }

            if ($requiresDeptHead) {
                if ($resetEndorsements || empty($app['dept_head_status'])) {
                    $updatePayload['dept_head_status'] = 'Pending';
                }
            } else {
                $updatePayload['dept_head_status'] = null;
            }
        }

        $this->leaveModel->update($applicationId, $updatePayload);

        // Synchronize leave_approval_steps to match newly computed required approvers
        if ($this->db->tableExists('leave_approval_steps')) {
            try {
                $leaveAppService = new \App\Services\Leave\LeaveApplicationService($this);
                $newSteps = $leaveAppService->buildApprovalSteps($applicationId, $newRequiredApprovers, $emp ?: ['id' => $employeeId, 'company_id' => $companyId], false);

                $existingSteps = $this->db->table('leave_approval_steps')
                    ->where('application_id', $applicationId)
                    ->get()
                    ->getResultArray();
                $existingByRole = [];
                foreach ($existingSteps as $es) {
                    $r = strtolower(trim((string)($es['approver_role'] ?? '')));
                    $existingByRole[$r] = $es;
                }

                foreach ($newSteps as &$ns) {
                    $r = strtolower(trim((string)($ns['approver_role'] ?? '')));
                    if (!$resetEndorsements && isset($existingByRole[$r]) && in_array(strtolower((string)$existingByRole[$r]['status']), ['approved', 'endorsed'], true)) {
                        $ns['status']      = $existingByRole[$r]['status'];
                        $ns['approver_id'] = $existingByRole[$r]['approver_id'] ?: $ns['approver_id'];
                        $ns['comments']    = $existingByRole[$r]['comments'];
                        $ns['acted_at']    = $existingByRole[$r]['acted_at'];
                    }
                }
                unset($ns);

                $this->db->table('leave_approval_steps')->where('application_id', $applicationId)->delete();
                if (!empty($newSteps)) {
                    $this->db->table('leave_approval_steps')->insertBatch($newSteps);
                }
            } catch (\Throwable $stepEx) {
                log_message('notice', 'updateLeave approval steps sync error: ' . $stepEx->getMessage());
            }
        }

        $this->db->transComplete();

        return [
            'success'            => $this->db->transStatus(),
            'message'            => 'Leave application updated successfully.',
            'days'               => $newChargeableDays,
            'sandwich_applies'   => !empty($calc['sandwich_applies']),
            'is_backdated'       => $isBackdated,
            'backdated_role'     => $backdatedRole,
            'required_approvers' => $newRequiredApprovers,
        ];
        } catch (\Throwable $e) {
            $this->db->transRollback();
            throw $e;
        }
    }

    /**
     * Endorse Leave Application
     * Authoritatively delegated to LeaveApplicationService
     */
    public function endorseLeave(string $applicationId, string $managerId, ?string $managerName = null, ?string $remarks = null): array
    {
        return (new \App\Services\Leave\LeaveApplicationService($this))->endorseLeave($applicationId, $managerId, $managerName, $remarks);
    }

    /**
     * Department Head Endorsement
     * Authoritatively delegated to LeaveApplicationService
     */
    public function endorseDeptHead(string $applicationId, string $deptHeadId, ?string $deptHeadName = null, ?string $remarks = null): array
    {
        return (new \App\Services\Leave\LeaveApplicationService($this))->endorseDeptHead($applicationId, $deptHeadId, $deptHeadName, $remarks);
    }

    /**
     * Batch Approve multiple leave applications
     * Authoritatively delegated to LeaveApplicationService
     */
    public function batchApprove(array $applicationIds, string $approverId, ?string $remarks = null): array
    {
        return (new \App\Services\Leave\LeaveApplicationService($this))->batchApprove($applicationIds, $approverId, $remarks);
    }

    /**
     * Batch Reject multiple leave applications
     * Authoritatively delegated to LeaveApplicationService
     */
    public function batchReject(array $applicationIds, string $approverId, string $reason): array
    {
        return (new \App\Services\Leave\LeaveApplicationService($this))->batchReject($applicationIds, $approverId, $reason);
    }

    /**
     * Check Approval Authorization and Scope for a Leave Application
     * Authoritatively delegated to LeaveApplicationService
     */
    public function canApproveApplication(
        array $app,
        array $targetEmp,
        ?array $approverUser = null,
        ?array $approverEmp = null,
        ?string $approverId = null,
        ?array $approvalWorkflow = null
    ): array {
        return (new \App\Services\Leave\LeaveApplicationService($this))->canApproveApplication($app, $targetEmp, $approverUser, $approverEmp, $approverId, $approvalWorkflow);
    }

    /**
     * Approve Leave Application
     * Authoritatively delegated to LeaveApplicationService
     */
    public function approveLeave(string $applicationId, string $approverId, ?string $remarks = null): array
    {
        return (new \App\Services\Leave\LeaveApplicationService($this))->approveLeave($applicationId, $approverId, $remarks);
    }
    /**
     * Reject Leave Application
     * Authoritatively delegated to LeaveApplicationService
     */
    public function rejectLeave(string $applicationId, string $approverId, string $rejectionReason): array
    {
        return (new \App\Services\Leave\LeaveApplicationService($this))->rejectLeave($applicationId, $approverId, $rejectionReason);
    }

    /**
     * Cancel Leave Application (Reverts approved balance if needed)
     * Authoritatively delegated to LeaveApplicationService
     */
    public function cancelLeave(string $applicationId, string $userId, ?string $employeeId = null, bool $isAdmin = false, string $reason = ''): array
    {
        return (new \App\Services\Leave\LeaveApplicationService($this))->cancelLeave($applicationId, $userId, $employeeId, $isAdmin, $reason);
    }
    /**
     * Manual Leave Balance Adjustment by HR / Admin
     */
    public function adjustBalance(
        string $employeeId,
        string $leaveTypeId,
        int $year,
        float $days,
        string $type,
        string $remarks,
        string $adjustedBy,
        ?string $idempotencyKey = null
    ): array {
        try {
            return (new \App\Services\Leave\LeaveAccrualService())->adjustBalance(
                $employeeId,
                $leaveTypeId,
                $year,
                $days,
                $type,
                $remarks,
                $adjustedBy,
                $idempotencyKey
            );
        } catch (\Throwable $e) {
            log_message('error', 'adjustBalance transaction error: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Leave balance adjustment failed due to an unexpected system error. Please contact HR administration.'
            ];
        }
    }

    /**
     * Calculate authoritative encashable days for an employee as of date.
     * Evaluates SETTLEMENT leave_encashment_separation_types and LEAVE entitlements[].encashment_* rules.
     * Uses real columns: allocated_days, carried_forward_days, approved_leave_days, pending_leave_days, encashed_days.
     *
     * @param string $employeeId
     * @param string $asOfDate (YYYY-MM-DD)
     * @param string|null $separationType
     * @param bool $returnDetails
     * @return float|array
     */
    public function getSettlementEncashableDays(string $employeeId, string $asOfDate, ?string $separationType = null, bool $returnDetails = false): float|array
    {
        $emp = $this->db->table('employees')->where('id', $employeeId)->get()->getRowArray();
        if (!$emp) {
            return $returnDetails ? ['total_days' => 0.0, 'by_type' => [], 'rules_snapshot' => []] : 0.0;
        }

        $companyId = $emp['company_id'] ?? null;
        if (!$companyId) {
            return $returnDetails ? ['total_days' => 0.0, 'by_type' => [], 'rules_snapshot' => []] : 0.0;
        }

        $resolver = new RuleResolver();

        // 1. Check separation type applicability via SETTLEMENT rule
        $settlementRule = $resolver->resolve($companyId, 'SETTLEMENT', $asOfDate, $emp);
        $allowedSeparationTypes = (array)$settlementRule->get('leave_encashment_separation_types');

        if ($separationType !== null && $separationType !== '') {
            $isAllowedSeparation = false;
            foreach ($allowedSeparationTypes as $st) {
                if (strcasecmp((string)$st, (string)$separationType) === 0) {
                    $isAllowedSeparation = true;
                    break;
                }
            }
            if (!$isAllowedSeparation) {
                return $returnDetails ? [
                    'total_days'     => 0.0,
                    'by_type'        => [],
                    'rules_snapshot' => [
                        'SETTLEMENT' => [
                            'layers' => $settlementRule->layers(),
                            'hash'   => $settlementRule->sha1(),
                        ],
                    ],
                    'disallowed_reason' => "Separation type '{$separationType}' is not eligible for leave encashment under policy"
                ] : 0.0;
            }
        }

        // 2. Resolve effective LEAVE rule
        $leaveRule = $resolver->resolve($companyId, 'LEAVE', $asOfDate, $emp);
        $entitlements = (array)$leaveRule->get('entitlements');

        $encashableRulesByCode = [];
        foreach ($entitlements as $ent) {
            $code = strtoupper(trim((string)($ent['leave_type_code'] ?? '')));
            if ($code !== '' && !empty($ent['encashment_allowed'])) {
                $encashableRulesByCode[$code] = $ent;
            }
        }

        $rulesSnapshot = [
            'SETTLEMENT' => [
                'layers' => $settlementRule->layers(),
                'hash'   => $settlementRule->sha1(),
            ],
            'LEAVE' => [
                'layers' => $leaveRule->layers(),
                'hash'   => $leaveRule->sha1(),
            ],
        ];

        if (empty($encashableRulesByCode)) {
            return $returnDetails ? ['total_days' => 0.0, 'by_type' => [], 'rules_snapshot' => $rulesSnapshot] : 0.0;
        }

        // 3. Query current-year leave balance rows using real authoritative columns
        $year = (int)date('Y', strtotime($asOfDate));
        if ($year <= 0) {
            $year = (int)date('Y');
        }

        if (!$this->db->tableExists('leave_balances')) {
            return $returnDetails ? ['total_days' => 0.0, 'by_type' => [], 'rules_snapshot' => $rulesSnapshot] : 0.0;
        }

        $builder = $this->db->table('leave_balances')
            ->where('leave_balances.employee_id', $employeeId)
            ->where('leave_balances.year', $year);

        if ($this->db->tableExists('leave_types')) {
            $builder->select('leave_balances.*, leave_types.code, leave_types.name as leave_type_name')
                    ->join('leave_types', 'leave_types.id = leave_balances.leave_type_id', 'left');
        }

        $balances = $builder->get()->getResultArray();

        $totalEncashableDays = 0.0;
        $byType = [];

        foreach ($balances as $lb) {
            $code = strtoupper(trim((string)($lb['code'] ?? '')));
            if (!isset($encashableRulesByCode[$code])) {
                continue;
            }

            $entRule = $encashableRulesByCode[$code];

            // Authoritative live balance derived via LeaveAccrualCalculator as of date
            $liveBal = $this->getEmployeeBalanceReadOnly($employeeId, $lb['leave_type_id'], $year, null, $asOfDate);
            $availableBalance = (float)($liveBal['available_balance'] ?? 0.0);

            // Apply encashment rules
            $minBalanceToKeep = (float)($entRule['encashment_min_balance_days'] ?? 0);
            $maxEncashDays    = (float)($entRule['encashment_max_days'] ?? 0);

            $encashableForType = 0.0;
            if ($availableBalance > $minBalanceToKeep) {
                $encashableForType = $availableBalance - $minBalanceToKeep;
                if ($maxEncashDays > 0) {
                    $encashableForType = min($encashableForType, $maxEncashDays);
                }
            }

            $encashableForType = round(max(0.0, $encashableForType), 2);
            $totalEncashableDays += $encashableForType;

            $byType[$code] = [
                'leave_type_id'        => $lb['leave_type_id'] ?? null,
                'leave_type_code'      => $code,
                'leave_type_name'      => $lb['leave_type_name'] ?? $code,
                'available_balance'    => $availableBalance,
                'min_balance_to_keep'  => $minBalanceToKeep,
                'max_encash_limit'     => $maxEncashDays,
                'encashable_days'      => $encashableForType,
                'salary_basis'         => $entRule['encashment_salary_basis'] ?? 'Basic Salary',
                'divisor'              => $entRule['encashment_divisor'] ?? null,
            ];
        }

        $totalEncashableDays = round($totalEncashableDays, 2);

        if ($returnDetails) {
            return [
                'total_days'     => $totalEncashableDays,
                'by_type'        => $byType,
                'rules_snapshot' => $rulesSnapshot,
            ];
        }

        return $totalEncashableDays;
    }

    /**
     * Get encashable days.
     * Supports both settlement calculation: ($employeeId, $asOfDate, $separationType, $returnDetails)
     * and single-leave-type encashment: ($employeeId, $leaveTypeId, $year)
     */
    public function getEncashableDays(mixed $employee, ?string $dateOrLeaveTypeId = null, mixed $separationTypeOrYear = null, bool $returnDetails = false): float|array
    {
        $employeeId = is_array($employee) ? ($employee['id'] ?? $employee['employee_id'] ?? '') : (string)$employee;
        $arg2 = trim((string)$dateOrLeaveTypeId);

        $isDate = ($arg2 === '' || preg_match('/^\d{4}-\d{2}-\d{2}/', $arg2));
        $isSeparationString = (is_string($separationTypeOrYear) && !is_numeric($separationTypeOrYear) && $separationTypeOrYear !== '');

        if ($isDate || $isSeparationString || $returnDetails) {
            $asOfDate = ($isDate && $arg2 !== '') ? $arg2 : date('Y-m-d');
            $separationType = is_string($separationTypeOrYear) ? $separationTypeOrYear : null;
            return $this->getSettlementEncashableDays($employeeId, $asOfDate, $separationType, $returnDetails);
        }

        $year = is_numeric($separationTypeOrYear) ? (int)$separationTypeOrYear : null;
        return (new \App\Services\Leave\LeaveEncashmentService())->getEncashableDays($employeeId, $arg2, $year);
    }

    /**
     * Get encashable days for a specific leave type:
     * Authoritatively delegated to LeaveEncashmentService
     */
    public function getEncashableDaysForType(string $employeeId, string $leaveTypeId, ?int $year = null): array
    {
        return (new \App\Services\Leave\LeaveEncashmentService())->getEncashableDays($employeeId, $leaveTypeId, $year);
    }

    /**
     * Leave Encashment Processing with row-level locking & policy limits
     * Authoritatively delegated to LeaveEncashmentService
     */
    public function processEncashment(string $employeeId, string $leaveTypeId, float $days, string $processedBy, ?string $reason = null, string $status = 'Approved', bool $isDryRun = false): array
    {
        return (new \App\Services\Leave\LeaveEncashmentService())->processEncashment(
            $employeeId,
            $leaveTypeId,
            $days,
            $processedBy,
            $reason,
            $status,
            $isDryRun
        );
    }

    /**
     * Generate Monthly Leave Calendar Matrix
     */
    public function getCalendarMatrix(int $year, int $month, ?string $employeeId = null, ?string $companyId = null, ?string $branchId = null, ?string $departmentId = null): array
    {
        $numDays = (int)date('t', mktime(0, 0, 0, $month, 1, $year));
        $startDayOfWeek = (int)date('w', mktime(0, 0, 0, $month, 1, $year)); // 0 = Sun
        $startDateStr = sprintf('%04d-%02d-01', $year, $month);
        $endDateStr = sprintf('%04d-%02d-%02d', $year, $month, $numDays);

        // Fetch strictly Approved and Pending leaves in this month scoped by company / branch / department / employee.
        // Rejected, Cancelled, and Withdrawn leaves are excluded at SQL level and verified here.
        $leaves = $this->leaveModel->getCalendarLeaves(
            $companyId,
            $departmentId,
            $employeeId,
            $startDateStr,
            $endDateStr,
            null,
            null,
            $branchId
        );

        $holidayMap = [];
        try {
            $db = Database::connect();
            $fields = $db->tableExists('holidays') ? $db->getFieldNames('holidays') : [];
            $hasCompanyCol = in_array('company_id', $fields, true);

            $holidayQuery = $this->holidayModel->builder();
            if ($companyId && $hasCompanyCol) {
                $holidayQuery->groupStart()
                    ->where('company_id', $companyId)
                    ->orWhere('company_id IS NULL')
                    ->orWhere('company_id', '')
                    ->groupEnd();
            }

            if (in_array('from_date', $fields, true) && in_array('to_date', $fields, true)) {
                $holidayRows = $holidayQuery
                    ->where('from_date <=', $endDateStr)
                    ->where('to_date >=', $startDateStr)
                    ->get()->getResultArray();
                foreach ($holidayRows as $h) {
                    $hStart = new \DateTime($h['from_date']);
                    $hEnd = new \DateTime($h['to_date'] ?? $h['from_date']);
                    $hCurr = clone $hStart;
                    while ($hCurr <= $hEnd) {
                        $holidayMap[$hCurr->format('Y-m-d')] = $h['name'] ?? $h['description'] ?? 'Public Holiday';
                        $hCurr->modify('+1 day');
                    }
                }
            } elseif (in_array('date', $fields, true)) {
                $holidayRows = $holidayQuery
                    ->where('date >=', $startDateStr)
                    ->where('date <=', $endDateStr)
                    ->get()->getResultArray();
                foreach ($holidayRows as $h) {
                    $holidayMap[$h['date']] = $h['name'] ?? $h['description'] ?? 'Public Holiday';
                }
            } else {
                $holidayRows = $this->holidayModel->getOrderedHolidays($companyId);
                foreach ($holidayRows as $h) {
                    $hDate = $h['from_date'] ?? $h['date'] ?? null;
                    if ($hDate && $hDate >= $startDateStr && $hDate <= $endDateStr) {
                        $holidayMap[$hDate] = $h['name'] ?? 'Public Holiday';
                    }
                }
            }
        } catch (\Throwable $e) {
            log_message('error', 'LeaveService::getCalendarMatrix holidays: ' . $e->getMessage());
        }

        // Multi-tenant company context resolution:
        // App Admin without selected company has null companyId (platform-level).
        // Tenant roles resolve strictly to their authenticated companyId.
        $compToResolve = $companyId;
        if ($compToResolve === null && function_exists('session')) {
            $session = session();
            $permService = new \App\Services\PermissionService();
            $isAppAdmin = !empty($session->get('is_software_app_admin')) || $permService->isSoftwareAppAdmin($session->get('role') ?? $session->get('role_code') ?? null);
            if ($isAppAdmin) {
                $compToResolve = $session->get('selected_company_id') ?: null;
            } else {
                $compToResolve = $session->get('company_id') ?: null;
            }
        }
        $configuredWeeklyOff = \App\Services\CompanyWeekendService::getCompanyWeeklyOff($compToResolve);

        $normalizedMonthLeaves = [];
        foreach ($leaves as $l) {
            $rawStatus = strtolower(trim((string)($l['status'] ?? '')));
            if (in_array($rawStatus, ['rejected', 'cancelled', 'withdrawn'], true)) {
                continue;
            }
            $normalizedStatus = ($rawStatus === 'approved') ? 'Approved' : 'Pending';
            $from = (string)($l['start_date'] ?? $l['from_date'] ?? '');
            $to = (string)($l['end_date'] ?? $l['to_date'] ?? $from);
            if ($to === '') {
                $to = $from;
            }
            if ($from === '') {
                continue;
            }

            $empPhoto = $l['photo'] ?? $l['avatar'] ?? $l['employee_avatar'] ?? null;
            if (!empty($empPhoto) && is_string($empPhoto) && trim($empPhoto) !== '') {
                $avatarUrl = (str_starts_with($empPhoto, 'http') || str_starts_with($empPhoto, 'data:'))
                    ? $empPhoto
                    : base_url(ltrim($empPhoto, '/'));
            } else {
                $avatarUrl = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150';
            }

            $empFullName = trim(($l['first_name'] ?? '') . ' ' . ($l['last_name'] ?? ''));
            if ($empFullName === '') {
                $empFullName = trim((string)($l['employee_name'] ?? ''));
            }
            if ($empFullName === '') {
                $empFullName = $l['employee_code'] ?? $l['employee_id'] ?? 'Employee';
            }

            $leaveTypeName = $l['leave_type_name'] ?? $l['leave_type'] ?? $l['leave_type_code'] ?? 'Leave';

            $normalizedMonthLeaves[] = [
                'id'               => $l['id'],
                'employee_id'      => $l['employee_id'],
                'employee_code'    => $l['employee_code'] ?? '',
                'employee_name'    => $empFullName,
                'department_id'    => $l['department_id'] ?? $l['employee_department_id'] ?? null,
                'department_name'  => $l['department_name'] ?? 'General',
                'designation_name' => $l['designation_name'] ?? $l['employee_designation'] ?? 'Staff',
                'branch_id'        => $l['branch_id'] ?? $l['employee_branch_id'] ?? null,
                'branch_name'      => $l['branch_name'] ?? '',
                'avatar'           => $avatarUrl,
                'photo'            => $avatarUrl,
                'employee_avatar'  => $avatarUrl,
                'leave_type_id'    => $l['leave_type_id'] ?? '',
                'leave_type'       => $leaveTypeName,
                'leave_type_name'  => $leaveTypeName,
                'type_code'        => strtolower((string)($l['leave_type_code'] ?? $leaveTypeName)),
                'total_days'       => (float)($l['total_days'] ?? 1),
                'is_half_day'      => !empty($l['is_half_day']),
                'half_day_period'  => $l['half_day_period'] ?? $l['half_day_type'] ?? null,
                'status'           => $normalizedStatus,
                'approval_status'  => $normalizedStatus,
                'reason'           => $l['reason'] ?? '',
                'start_date'       => $from,
                'end_date'         => $to,
                'from_date'        => $from,
                'to_date'          => $to,
            ];
        }

        $days = [];
        for ($d = 1; $d <= $numDays; $d++) {
            $dateStr = sprintf('%04d-%02d-%02d', $year, $month, $d);
            $dayOfWeek = (int)date('w', strtotime($dateStr));
            $dayName = date('l', strtotime($dateStr));
            $isWeekend = in_array($dayName, $configuredWeeklyOff, true);

            $activeLeaves = [];
            foreach ($normalizedMonthLeaves as $nl) {
                if ($dateStr >= $nl['from_date'] && $dateStr <= $nl['to_date']) {
                    $activeLeaves[] = $nl;
                }
            }

            $days[] = [
                'day'          => $d,
                'date'         => $dateStr,
                'day_of_week'  => $dayOfWeek,
                'day_name'     => date('D', strtotime($dateStr)),
                'is_weekend'   => $isWeekend,
                'is_holiday'   => isset($holidayMap[$dateStr]),
                'holiday_name' => $holidayMap[$dateStr] ?? null,
                'leaves'       => $activeLeaves,
                'leave_count'  => count($activeLeaves)
            ];
        }

        return [
            'year'              => $year,
            'month'             => $month,
            'month_name'        => date('F', mktime(0, 0, 0, $month, 1, $year)),
            'days_in_month'     => $numDays,
            'start_day_of_week' => $startDayOfWeek,
            'company_id'        => $compToResolve,
            'weekly_off_days'   => $configuredWeeklyOff,
            'leaves'            => $normalizedMonthLeaves,
            'days'              => $days
        ];
    }

    /**
     * Get list of policies
     */
    /**
     * Get list of policies from Single Rule Store (domain: LEAVE)
     */
    public function getPolicies(?string $companyId = null): array
    {
        if (empty($companyId) && function_exists('session') && session()->has('company_id')) {
            $companyId = session()->get('company_id');
        }
        if (empty($companyId)) {
            return [];
        }

        try {
            $rule = RuleResolver::resolveForCompany($companyId, 'LEAVE', date('Y-m-d'));
            $params = $rule->params();
            $entitlements = $params['entitlements'] ?? $params['leave_types'] ?? [];
            $probation = $params['probation'] ?? $params['probation_rules'] ?? [];
            $sandwich = $params['sandwich'] ?? $params['sandwich_rules'] ?? [];
            $workflow = $params['approval_workflow'] ?? [];
            $unpaid = $params['unpaid_deduction'] ?? $params['unpaid_leave_deductions'] ?? [];

            $policyId = $rule->effectiveRuleId() ?: 'rule-leave-' . $companyId;
            $weekendTreatment = $sandwich['weekend_treatment'] ?? ($sandwich['weekendTreatment'] ?? null);
            $holidayTreatment = $sandwich['holiday_treatment'] ?? ($sandwich['holidayTreatment'] ?? null);
            $bridgeAction = $sandwich['bridge_leave_action'] ?? ($sandwich['bridgeLeaveAction'] ?? null);
            if ($weekendTreatment === null || $holidayTreatment === null || $bridgeAction === null) {
                throw \App\Services\Rules\Exceptions\RuleNotConfiguredException::forDomain($companyId, 'LEAVE', date('Y-m-d'), "Sandwich rules (weekend_treatment, holiday_treatment, bridge_leave_action) must be configured");
            }

            return [[
                    'id'                     => $policyId,
                    'company_id'             => $companyId,
                    'name'                   => 'Company Leave Rules',
                    'code'                   => 'POL-LEAVE',
                    'scope_level'            => 'Company',
                    'scope_id'               => $companyId,
                    'scope_name'             => 'Company',
                    'effective_from'         => date('Y-01-01'),
                    'effective_to'           => null,
                    'entitlements_json'      => json_encode($entitlements),
                    'probation_json'         => json_encode($probation),
                    'sandwich_rules_json'    => json_encode($sandwich),
                    'approval_workflow_json' => json_encode($workflow),
                    'unpaid_deductions_json' => json_encode($unpaid),
                    'encashment_rules_json'  => json_encode($entitlements),
                    'calendarTreatment'      => [
                        'enabled'                => !empty($sandwich['enabled']),
                        'weekend_treatment'      => $weekendTreatment,
                        'holiday_treatment'      => $holidayTreatment,
                        'treat_weekend_as_leave' => !empty($sandwich['treat_weekend_as_leave']),
                        'treat_holiday_as_leave' => !empty($sandwich['treat_holiday_as_leave']),
                        'bridge_leave_enabled'   => isset($sandwich['bridge_leave_enabled']) ? (bool)$sandwich['bridge_leave_enabled'] : (!empty($sandwich['enabled'])),
                        'bridge_leave_action'    => $bridgeAction,
                        'applies_to_paid_only'   => isset($sandwich['applies_to_paid_only']) ? (bool)$sandwich['applies_to_paid_only'] : true,
                        'weekendTreatment'       => $weekendTreatment,
                        'holidayTreatment'       => $holidayTreatment,
                        'treatWeekendAsLeave'    => !empty($sandwich['treat_weekend_as_leave']),
                        'treatHolidayAsLeave'    => !empty($sandwich['treat_holiday_as_leave']),
                        'bridgeLeaveEnabled'     => isset($sandwich['bridge_leave_enabled']) ? (bool)$sandwich['bridge_leave_enabled'] : (!empty($sandwich['enabled'])),
                        'bridgeLeaveAction'      => $bridgeAction,
                        'appliesToPaidOnly'      => isset($sandwich['applies_to_paid_only']) ? (bool)$sandwich['applies_to_paid_only'] : true,
                    ]
                ]];
            } catch (\Throwable $e) {
                log_message('error', 'getCalendarMatrix sandwich rule error: ' . $e->getMessage());
                return [];
            }
        }

        /**
         * Resolve hierarchical policy for employee using Single Rule Store:
         * Hierarchy: Employee > Shift > Designation > Department > Branch > Company
         */
        public function resolvePolicyForEmployee(array $employee, ?array $allPolicies = null, ?string $asOfDate = null): array
        {
            $companyId = $employee['company_id'] ?? null;
            if (empty($companyId) && function_exists('session') && session()->has('company_id')) {
                $companyId = session()->get('company_id');
            }
            if (empty($companyId)) {
                throw new RuleNotConfiguredException("Company ID is required to resolve LEAVE rule.");
            }

            $resolver = new RuleResolver();
            $date = !empty($asOfDate) ? $asOfDate : date('Y-m-d');
            $rule = $resolver->resolve($companyId, 'LEAVE', $date, $employee);
            $params = $rule->params();

            $entitlements = $params['entitlements'] ?? $params['leave_types'] ?? [];
            $probation = $params['probation'] ?? $params['probation_rules'] ?? [];
            $sandwich = $params['sandwich'] ?? $params['sandwich_rules'] ?? [];
            $workflow = $params['approval_workflow'] ?? [];
            $unpaid = $params['unpaid_deduction'] ?? $params['unpaid_leave_deductions'] ?? [];

            $weekendTreatment = $sandwich['weekend_treatment'] ?? ($sandwich['weekendTreatment'] ?? null);
            if ($weekendTreatment === null) {
                throw \App\Services\Rules\Exceptions\RuleNotConfiguredException::forDomain($companyId, 'LEAVE', $date, "sandwich.weekend_treatment is not configured");
            }
            $holidayTreatment = $sandwich['holiday_treatment'] ?? ($sandwich['holidayTreatment'] ?? null);
            if ($holidayTreatment === null) {
                throw \App\Services\Rules\Exceptions\RuleNotConfiguredException::forDomain($companyId, 'LEAVE', $date, "sandwich.holiday_treatment is not configured");
            }
            $bridgeAction = $sandwich['bridge_leave_action'] ?? ($sandwich['bridgeLeaveAction'] ?? null);
            if ($bridgeAction === null) {
                throw \App\Services\Rules\Exceptions\RuleNotConfiguredException::forDomain($companyId, 'LEAVE', $date, "sandwich.bridge_leave_action is not configured");
            }
            $appliesPaidOnly = isset($sandwich['applies_to_paid_only']) ? (bool)$sandwich['applies_to_paid_only'] : (isset($sandwich['appliesToPaidOnly']) ? (bool)$sandwich['appliesToPaidOnly'] : true);

        $isWeekendAllLeave = (strcasecmp(trim((string)$weekendTreatment), 'count weekly off as leave') === 0);
        $isHolidayAllLeave = in_array(strtolower(trim((string)$holidayTreatment)), ['count holidays as leave', 'count all calendar days'], true);

        return [
            'id'                     => $rule->effectiveRuleId() ?: 'rule-leave-' . $companyId,
            'company_id'             => $companyId,
            'name'                   => 'Company Leave Rules',
            'code'                   => 'POL-LEAVE',
            'scope_level'            => $rule->scopeLevel() ?? 'Company',
            'scope_id'               => $rule->scopeId() ?? null,
            'entitlements_json'      => json_encode($entitlements),
            'probation_json'         => json_encode($probation),
            'sandwich_rules_json'    => json_encode($sandwich),
            'approval_workflow_json' => json_encode($workflow),
            'unpaid_deductions_json' => json_encode($unpaid),
            'encashment_rules_json'  => json_encode($entitlements),
            'calendarTreatment'      => [
                'enabled'                => !empty($sandwich['enabled']),
                'weekend_treatment'      => $weekendTreatment,
                'holiday_treatment'      => $holidayTreatment,
                'treat_weekend_as_leave' => !empty($sandwich['treat_weekend_as_leave']) || $isWeekendAllLeave,
                'treat_holiday_as_leave' => !empty($sandwich['treat_holiday_as_leave']) || $isHolidayAllLeave,
                'bridge_leave_enabled'   => isset($sandwich['bridge_leave_enabled']) ? (bool)$sandwich['bridge_leave_enabled'] : (!empty($sandwich['enabled'])),
                'bridge_leave_action'    => $bridgeAction,
                'applies_to_paid_only'   => $appliesPaidOnly,
                'weekendTreatment'       => $weekendTreatment,
                'holidayTreatment'       => $holidayTreatment,
                'treatWeekendAsLeave'    => !empty($sandwich['treat_weekend_as_leave']) || $isWeekendAllLeave,
                'treatHolidayAsLeave'    => !empty($sandwich['treat_holiday_as_leave']) || $isHolidayAllLeave,
                'bridgeLeaveEnabled'     => isset($sandwich['bridge_leave_enabled']) ? (bool)$sandwich['bridge_leave_enabled'] : (!empty($sandwich['enabled'])),
                'bridgeLeaveAction'      => $bridgeAction,
                'appliesToPaidOnly'      => $appliesPaidOnly,
            ],
            '_resolved_rule'         => $rule
        ];
    }

    /**
     * Run Monthly Accrual Batch Engine:
     * Authoritatively delegated to LeaveAccrualService
     */
    public function runAccrualBatch(string $asOfDate, ?string $companyId = null, string $performedBy = 'Accrual Engine', bool $isDryRun = false): array
    {
        return (new \App\Services\Leave\LeaveAccrualService())->runAccrualBatch(
            $asOfDate,
            $companyId,
            $performedBy,
            $isDryRun
        );
    }

    /**
     * Year-End Carry Forward & Expiry Rollover Engine:
     * Authoritatively delegated to LeaveRolloverService
     */
    public function runYearEndRollover(int $fromYear, int $toYear, ?string $companyId = null, string $performedBy = 'Year-End Rollover Wizard', bool $isDryRun = false): array
    {
        return (new \App\Services\Leave\LeaveRolloverService())->runYearEndRollover(
            $fromYear,
            $toYear,
            $companyId,
            $performedBy,
            $isDryRun
        );
    }

    /**
     * Alias for runYearEndRollover
     */
    public function rolloverBalances(int $fromYear, int $toYear, ?string $companyId = null, string $performedBy = 'Year-End Rollover Wizard', bool $isDryRun = false): array
    {
        return $this->runYearEndRollover($fromYear, $toYear, $companyId, $performedBy, $isDryRun);
    }

    /**
     * Reopen a closed leave year:
     * Authoritatively delegated to LeaveRolloverService
     */
    public function reopenYear(int $year, string $companyId, string $reopenedBy, string $reason): array
    {
        return (new \App\Services\Leave\LeaveRolloverService())->reopenYear($year, $companyId, $reopenedBy, $reason);
    }

    /**
     * Leave Encashment Calculation:
     * Authoritatively delegated to LeaveEncashmentService
     */
    public function calculateEncashmentAmount(string $employeeId, string $leaveTypeId, float $days, ?array $leaveTypeData = null, ?array $employeeData = null): array
    {
        return (new \App\Services\Leave\LeaveEncashmentService())->calculateEncashmentAmount(
            $employeeId,
            $leaveTypeId,
            $days,
            $leaveTypeData,
            $employeeData
        );
    }

    /**
     * Payroll Unpaid Leave Deduction Calculation:
     * Resolves formula and parameters from LEAVE and PAYROLL_BASICS Single Rule Store definitions.
     */
    public function calculateUnpaidLeaveDeduction(string $employeeId, string $leaveTypeId, float $unpaidDays, ?array $leaveTypeData = null, ?array $employeeData = null): array
    {
        $asOfDate = date('Y-m-d');
        $activeSal = null;
        try {
            $salService = class_exists('\Config\Services') && method_exists('\Config\Services', 'salary')
                ? \Config\Services::salary()
                : new \App\Services\EmployeeSalaryService();
            $activeSal = $salService->getActiveSalary($employeeId, $asOfDate);
        } catch (\Throwable $e) {
            log_message('warning', 'calculateUnpaidLeaveDeduction getActiveSalary error: ' . $e->getMessage());
            $activeSal = null;
        }

        $emp = $employeeData ?: $this->db->table('employees')->where('id', $employeeId)->get()->getRowArray();
        $companyId = $emp['company_id'] ?? '';
        if (empty($companyId) && function_exists('session') && session()->has('company_id')) {
            $companyId = session()->get('company_id');
        }
        if (empty($companyId)) {
            throw new RuleNotConfiguredException("Company ID is required to calculate unpaid leave deduction.");
        }

        $basic = (float)($activeSal['basic_salary'] ?? $emp['basic_salary'] ?? 0.0);
        $gross = (float)($activeSal['gross_salary'] ?? $emp['gross_salary'] ?? $basic);

        $pbRule = (new RuleResolver())->resolve($companyId, 'PAYROLL_BASICS', $asOfDate, $emp);
        $leaveRule = (new RuleResolver())->resolve($companyId, 'LEAVE', $asOfDate, $emp);
        $unpaidRule = $leaveRule->get('unpaid_deduction') ?: [];

        $lt = $leaveTypeData ?: $this->db->table('leave_types')->where('id', $leaveTypeId)->get()->getRowArray();

        // Enforce affects_payroll rule setting (from domain unpaid_deduction rule or leave entitlement)
        $affectsPayroll = true;
        if (isset($unpaidRule['affects_payroll']) && $unpaidRule['affects_payroll'] === false) {
            $affectsPayroll = false;
        }
        if ($affectsPayroll && $lt) {
            try {
                $ruleEnt = $this->resolveLeaveEntitlement($companyId, $emp, $lt, $asOfDate);
                if (isset($ruleEnt['affects_payroll']) && $ruleEnt['affects_payroll'] === false) {
                    $affectsPayroll = false;
                }
            } catch (\Throwable $te) {
                // Ignore if entitlement resolution fails
            }
        }

        if (!$affectsPayroll) {
            return [
                'employee_id'    => $employeeId,
                'leave_type_id'  => $leaveTypeId,
                'unpaid_days'    => $unpaidDays,
                'formula'        => 'Exempt from payroll deduction (affects_payroll=false)',
                'daily_rate'     => 0.0,
                'deduction'      => 0.0
            ];
        }

        $configuredFormula = $unpaidRule['formula'] ?? ($lt['unpaid_deduction_formula'] ?? $lt['unpaidDeductionFormula'] ?? null);
        $salaryBasis = $unpaidRule['salary_basis']
            ?? (($configuredFormula !== null && stripos((string)$configuredFormula, 'Basic') !== false)
                ? 'Basic Salary'
                : (($configuredFormula !== null && stripos((string)$configuredFormula, 'Gross') !== false)
                    ? 'Gross Salary'
                    : 'Basic Salary'));

        $baseSalary = ($salaryBasis === 'Basic Salary') ? $basic : $gross;
        $overrideDivisorMode = null;
        if (!empty($unpaidRule['divisor']) && (int)$unpaidRule['divisor'] > 0) {
            $overrideDivisorMode = (string)(int)$unpaidRule['divisor'];
        } elseif ($configuredFormula !== null && str_contains((string)$configuredFormula, '26')) {
            $overrideDivisorMode = '26';
        } elseif ($configuredFormula !== null && str_contains((string)$configuredFormula, '30')) {
            $overrideDivisorMode = '30';
        }

        $rateInfo = \App\Services\Rules\DailyRateResolver::resolve(
            $companyId,
            $emp,
            $asOfDate,
            null,
            $baseSalary,
            $overrideDivisorMode
        );
        $divisorUsed = (float)$rateInfo['divisor_days'];
        $rawDailyRate = $divisorUsed > 0 ? ($baseSalary / $divisorUsed) : 0.0;
        $dailyRate = \App\Services\Rules\Money::round($rawDailyRate, $pbRule);
        $deduction = \App\Services\Rules\Money::round($rawDailyRate * $unpaidDays, $pbRule);
        $formula = $configuredFormula ?? "{$salaryBasis} / {$divisorUsed}";

        return [
            'employee_id'    => $employeeId,
            'leave_type_id'  => $leaveTypeId,
            'unpaid_days'    => $unpaidDays,
            'formula'        => $formula,
            'daily_rate'     => $dailyRate,
            'deduction'      => (float)$deduction
        ];
    }

    /**
     * Get Complete Transaction Ledger for an Employee or Company
     */
    public function getEmployeeLedger(?string $employeeId = null, ?string $leaveTypeId = null, ?int $year = null, ?string $companyId = null): array
    {
        try {
            if (!$this->db->tableExists('leave_transactions')) {
                return [];
            }

            $cols = $this->transactionModel->getTableColumns();
            $hasTxDate = in_array('transaction_date', $cols);

            $builder = $this->db->table('leave_transactions')
                ->select('leave_transactions.*, employees.first_name, employees.last_name, employees.employee_code, 
                          departments.name as department_name, leave_types.name as leave_type_name, leave_types.code as leave_type_code')
                ->join('employees', 'employees.id = leave_transactions.employee_id', 'left')
                ->join('departments', 'departments.id = employees.department_id', 'left')
                ->join('leave_types', 'leave_types.id = leave_transactions.leave_type_id', 'left');

            if ($employeeId) {
                $builder->where('leave_transactions.employee_id', $employeeId);
            }
            if ($leaveTypeId) {
                $builder->where('leave_transactions.leave_type_id', $leaveTypeId);
            }
            if ($year) {
                if ($hasTxDate) {
                    $builder->where("(YEAR(leave_transactions.transaction_date) = {$year} OR (leave_transactions.transaction_date IS NULL AND YEAR(leave_transactions.created_at) = {$year}))");
                } else {
                    $builder->where("YEAR(leave_transactions.created_at) = {$year}");
                }
            }
            if ($companyId) {
                $builder->where('employees.company_id', $companyId);
            }

            $orderField = $hasTxDate ? 'leave_transactions.transaction_date' : 'leave_transactions.created_at';
            $rows = $builder->orderBy($orderField, 'DESC')->orderBy('leave_transactions.created_at', 'DESC')->get()->getResultArray();

            $ledger = [];
            foreach ($rows as $r) {
                $fName = trim(($r['first_name'] ?? '') . ' ' . ($r['last_name'] ?? ''));
                $r['employee_name'] = !empty($fName) ? $fName : ($r['employee_code'] ?? $r['employee_id']);
                if (empty($r['transaction_date']) && !empty($r['created_at'])) {
                    $r['transaction_date'] = substr($r['created_at'], 0, 10);
                }
                $ledger[] = $r;
            }

            return $ledger;
        } catch (\Throwable $e) {
            log_message('error', 'getEmployeeLedger error: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Run a 100% read-only, non-mutating leave simulation.
     * Calculates span, sandwich rule, dynamic probation/eligibility, validation rules (errors/warnings),
     * balance projection, and financial/payroll impact.
     * Guaranteed ZERO database mutation.
     */
    public function simulateLeaveApplication(...$args): array
    {
        $mockEmp = null;
        $mockLeaveType = null;
        if (count($args) >= 3 && is_array($args[0]) && is_array($args[1]) && is_array($args[2])) {
            $mockEmp = $args[0];
            $mockLeaveType = $args[1];
            $params = $args[2];
            $employeeId = $params['employee_id'] ?? ($mockEmp['id'] ?? null);
            $leaveTypeId = $params['leave_type_id'] ?? ($mockLeaveType['id'] ?? null);
        } else {
            $params = $args[0] ?? [];
            $employeeId = $params['employee_id'] ?? null;
            $leaveTypeId = $params['leave_type_id'] ?? null;
        }

        $fromDate = $params['from_date'] ?? $params['start_date'] ?? date('Y-m-d');
        $toDate = $params['to_date'] ?? $params['end_date'] ?? $fromDate;
        $isHalfDay = !empty($params['is_half_day']);
        $isHourly = !empty($params['is_hourly']);
        $hourlyHours = (float)($params['hourly_hours'] ?? 4);
        $hasMedicalCert = !empty($params['has_medical_cert']);
        $hasAttachment = !empty($params['has_attachment']);
        $reason = trim($params['reason'] ?? 'Personal rest and family commitments.');

        if (!$employeeId || !$leaveTypeId) {
            return [
                'success' => false,
                'message' => 'Employee and Leave Type selections are required for simulation.'
            ];
        }

        // 1. Fetch Employee Profile
        $emp = $mockEmp;
        if (!$emp && $employeeId) {
            $emp = $this->db->table('employees')->where('id', $employeeId)->get()->getRowArray();
        }
        if (!$emp) {
            return ['success' => false, 'message' => 'Target employee not found.'];
        }

        // 2. Fetch Leave Type Details
        $leaveType = $mockLeaveType;
        if (!$leaveType && $leaveTypeId) {
            $leaveType = $this->db->table('leave_types')->where('id', $leaveTypeId)->get()->getRowArray();
        }
        if (!$leaveType) {
            return ['success' => false, 'message' => 'Selected leave type not found.'];
        }

        // 3. Resolve Hierarchical Policy & Leave Entitlement
        $companyId = $emp['company_id'] ?? (function_exists('session') && session()->has('company_id') ? session()->get('company_id') : null);
        $policy = $this->resolvePolicyForEmployee($emp, null, $fromDate);
        try {
            $ruleEnt = $this->resolveLeaveEntitlement((string)$companyId, $emp, $leaveType, $fromDate);
        } catch (\Throwable $re) {
            log_message('warning', 'simulateApplication resolveLeaveEntitlement error: ' . $re->getMessage());
            $ruleEnt = [];
        }

        $isPaid = !empty($ruleEnt['is_paid']) || (isset($leaveType['is_paid']) && !empty($leaveType['is_paid']));
        $sandwichRuleActive = $this->isSandwichEnabled((string)$companyId, $emp, $ruleEnt, $fromDate, $isPaid);

        // 4. Calculate Leave Duration Span & Bridge / Sandwich Rule
        $errors = [];
        $warnings = [];

        $totalDays = 0.0;
        $workingDays = 0.0;
        $weekendDays = 0;
        $holidayDays = 0;
        $bridgeDays = 0;
        $sandwichApplies = false;
        $breakdownText = '';

        if ($isHourly && $hourlyHours > 0) {
            $dayFraction = round(($hourlyHours / 8.0), 2);
            $totalDays = $dayFraction;
            $workingDays = $dayFraction;
            $breakdownText = "{$hourlyHours} hours requested ({$dayFraction} day fraction).";
        } elseif ($isHalfDay) {
            $totalDays = 0.5;
            $workingDays = 0.5;
            $breakdownText = "Half-day session (0.5 day).";
        } else {
            if (strtotime($fromDate) > strtotime($toDate)) {
                $breakdownText = 'Invalid date range: From date is after To date.';
                $errors[] = 'Invalid date range: Start date cannot be after end date.';
            } else {
                $calc = $this->calculateLeaveDays($employeeId, $fromDate, $toDate, false, $sandwichRuleActive, $policy, $isPaid);
                $totalDays = (float)($calc['chargeable_days'] ?? 0);
                $weekendDays = (int)($calc['weekend_days'] ?? 0);
                $holidayDays = (int)($calc['holiday_days'] ?? 0);
                $bridgeDays = (int)($calc['bridge_days_added'] ?? $calc['sandwich_days'] ?? 0);
                $sandwichApplies = !empty($calc['sandwich_applies']);
                $totalCalDays = (int)($calc['total_calendar_days'] ?? 1);
                $workingDays = (float)($calc['working_days'] ?? 0);
                $breakdownText = $calc['breakdown_text'] ?? "{$workingDays} working days = {$totalDays} total leave days.";
            }
        }

        // 5. Fetch Available Quota Balance
        $year = (int)date('Y', strtotime($fromDate));
        $balance = $this->getEmployeeBalanceReadOnly($employeeId, $leaveTypeId, $year, $leaveType, $fromDate);
        $currentAvailableBalance = (float)($balance['available_balance'] ?? 0.0);
        $projectedBalance = round($currentAvailableBalance - $totalDays, 1);

        // 6. Deep Multi-Tier Application Validation
        // Rule 1: Employee Active Check
        $empStatus = \App\Models\EmployeeModel::normalizeStatus($emp['status'] ?? \App\Models\EmployeeModel::STATUS_ACTIVE, true);
        if (in_array($empStatus, [
            \App\Models\EmployeeModel::STATUS_SUSPENDED,
            \App\Models\EmployeeModel::STATUS_RESIGNED,
            \App\Models\EmployeeModel::STATUS_TERMINATED,
            \App\Models\EmployeeModel::STATUS_INACTIVE,
        ], true)) {
            $statusLabel = \App\Models\EmployeeModel::STATUS_LABELS[$empStatus] ?? ucfirst($empStatus);
            $errors[] = "Application Denied: Employee status is {$statusLabel}. Only active personnel can apply for leave.";
        }

        // Rule 2: Leave Type Active Check
        if (strcasecmp((string)($leaveType['status'] ?? 'Active'), 'Inactive') === 0) {
            $errors[] = "Leave Type '{$leaveType['name']}' is currently disabled in system settings.";
        }

        // Gender Eligibility Evaluation
        $genderCheck = self::checkGenderEligibility($emp, $leaveType, $ruleEnt);
        if (!$genderCheck['eligible']) {
            $errors[] = $genderCheck['reason'];
        }

        // Rule 3: Dynamic Probation & Leave Eligibility Evaluation
        try {
            $probationService = new \App\Services\ProbationLeaveEligibilityService();
            $eligibilityCheck = $probationService->checkLeaveEligibility($employeeId, $leaveTypeId, $fromDate);
            if (!$eligibilityCheck['is_eligible']) {
                $errors[] = !empty($eligibilityCheck['blocked_reason'])
                    ? $eligibilityCheck['blocked_reason']
                    : "Leave is blocked during probation period.";
            }
        } catch (\Throwable $e) {
            log_message('error', 'Simulation probation check: ' . $e->getMessage());
            $errors[] = 'Unable to verify probation eligibility. Please try again or contact HR.';
        }

        // Rule 4: Policy-Level Probation Checks (via PROBATION rule in LEAVE domain & ProbationLeaveEligibilityService)
        $confirmDateVal = $emp['confirm_date'] ?? $emp['confirmDate'] ?? $emp['confirmation_date'] ?? $emp['probation_confirmed_date'] ?? null;
        $joinDateVal = employee_joining_date($emp) ?? $emp['employment_start_date'] ?? null;
        $probationStartVal = $emp['probation_start_date'] ?? $joinDateVal;
        $probationEndVal = $emp['probation_extended_date'] ?? $emp['probation_end_date'] ?? null;

        $probationRule = [];
        if (!empty($companyId)) {
            try {
                $resolvedLeaveRule = (new RuleResolver())->resolve((string)$companyId, 'LEAVE', $fromDate, $emp);
                if ($resolvedLeaveRule->has('probation')) {
                    $probationRule = (array)($resolvedLeaveRule->get('probation') ?: []);
                }
            } catch (\Throwable $e) {
                $probationRule = [];
            }
        }
        $pJson = !empty($policy['probation_json'])
            ? (is_array($policy['probation_json']) ? $policy['probation_json'] : (json_decode($policy['probation_json'], true) ?: []))
            : [];
        $probConfig = array_merge($probationRule, $pJson);

        $probCalcService = new \App\Services\ProbationLeaveEligibilityService();
        $isProbationByPeriod = false;
        if (!empty($probationEndVal)) {
            $isProbationByPeriod = (substr((string)$fromDate, 0, 10) <= substr((string)$probationEndVal, 0, 10));
        } elseif (!empty($emp['probation_duration_value']) && !empty($probationStartVal)) {
            $durVal = (int)$emp['probation_duration_value'];
            $durUnit = (string)($emp['probation_duration_unit'] ?? 'Months');
            $calcEnd = $probCalcService->calculateProbationEndDate((string)$probationStartVal, $durVal, $durUnit);
            $isProbationByPeriod = (substr((string)$fromDate, 0, 10) <= $calcEnd);
        } elseif (!empty($joinDateVal)) {
            $calcEnd = null;
            if (!empty($probConfig['probation_duration_days'])) {
                $calcEnd = $probCalcService->calculateProbationEndDate((string)$joinDateVal, (int)$probConfig['probation_duration_days'], 'Days');
            } elseif (!empty($probConfig['probation_period_days'])) {
                $calcEnd = $probCalcService->calculateProbationEndDate((string)$joinDateVal, (int)$probConfig['probation_period_days'], 'Days');
            } elseif (!empty($probConfig['probation_duration_months'])) {
                $calcEnd = $probCalcService->calculateProbationEndDate((string)$joinDateVal, (int)$probConfig['probation_duration_months'], 'Months');
            }
            if ($calcEnd !== null) {
                $isProbationByPeriod = (substr((string)$fromDate, 0, 10) <= $calcEnd);
            }
        }

        $isProbation = ($empStatus === \App\Models\EmployeeModel::STATUS_PROBATION) || (empty($confirmDateVal) && $isProbationByPeriod);
        if ($isProbation) {
            $blockedTypes = $probConfig['blockedLeaveTypeIds'] ?? $probConfig['blocked_leave_type_ids'] ?? [];
            $blockedCodes = array_map('strtoupper', (array)($probConfig['blocked_leave_type_codes'] ?? []));
            $ltCodeUpper = strtoupper(trim((string)($leaveType['code'] ?? '')));
            $policyLabel = $policy['name'] ?? 'Company Leave Policy';
            if (in_array($leaveTypeId, $blockedTypes, true) || ($ltCodeUpper !== '' && in_array($ltCodeUpper, $blockedCodes, true))) {
                $errors[] = "Probation Restriction: '{$leaveType['name']}' is blocked during the evaluation period according to policy '{$policyLabel}'.";
            }
            $canUseInProbation = $probConfig['canUseDuringProbation'] ?? ($probConfig['can_apply_during_probation'] ?? true);
            if ($canUseInProbation === false) {
                $errors[] = "Probation Restriction: Leave usage is disabled during probation under policy '{$policyLabel}'.";
            }
            $isPaidType = (bool)($leaveType['is_paid'] ?? 1);
            $allowUnpaidInProb = $probConfig['allowUnpaidLeave'] ?? ($probConfig['allow_unpaid_leave'] ?? true);
            $allowPaidInProb = $probConfig['allowPaidLeave'] ?? ($probConfig['allow_paid_leave'] ?? true);
            if (!$isPaidType && $allowUnpaidInProb === false) {
                $errors[] = "Unpaid leave is not permitted during probation.";
            }
            if ($isPaidType && isset($probConfig['allowPaidLeave']) && !$probConfig['allowPaidLeave']) {
                $errors[] = "Paid leave is not permitted during probation.";
            }
        }

        // Rule 5: Date Validation (Backdated & Future)
        $today = date('Y-m-d');
        $isBackdated = ($fromDate < $today);
        $isFuture = ($fromDate > $today);

        $rules = $this->resolveApplicationRules($ruleEnt, $leaveType);

        $allowBackdated = $rules['allow_backdated_application'];
        $maxBackdateDays = $rules['max_backdate_days'];
        $backdatedRole = $rules['backdated_role_requirement'];

        $rawEmergency = !empty($params['is_emergency']) || !empty($params['is_urgent']);
        $allowEmergencyAbsence = (bool)($rules['allow_emergency_absence'] ?? false);
        $canManage = !empty($params['can_manage_leave']);
        $isHR = $canManage || !empty($params['is_hr']);
        $isManager = $canManage || !empty($params['is_manager']);
        $isEmergency = false;

        $actingUserId = $params['applied_by'] ?? $params['user_id'] ?? null;
        $isOwnApplication = !empty($params['is_own_application']);
        if (!$isOwnApplication && !empty($actingUserId)) {
            if ((string)$actingUserId === (string)$employeeId) {
                $isOwnApplication = true;
            } elseif ($this->db) {
                $actingEmpCheck = $this->db->table('employees')
                    ->where('user_id', $actingUserId)
                    ->orWhere('id', $actingUserId)
                    ->get()
                    ->getRowArray();
                if ($actingEmpCheck && (string)$actingEmpCheck['id'] === (string)$employeeId) {
                    $isOwnApplication = true;
                }
            }
        }

        // When applying for their own leave, managers and HR staff act as regular applicants:
        // they cannot bypass notice periods, backdate limits, or emergency absence restrictions for their own leave.
        $canBypassLimits = (!$isOwnApplication && ($isHR || $isManager));

        if ($rawEmergency) {
            if (!$canBypassLimits && !$allowEmergencyAbsence) {
                $errors[] = "Emergency absence is not permitted for '{$leaveType['name']}'. Only HR and managers can submit emergency requests for this leave category.";
            }

            if (empty($reason) || strlen($reason) < 5) {
                $warnings[] = "A valid, detailed reason explaining the emergency absence is required.";
            }

            if ($canBypassLimits || $allowEmergencyAbsence) {
                $isEmergency = true;
            }
        }

        $ltCode = strtoupper(trim((string)($leaveType['code'] ?? '')));
        $ltName = strtolower(trim((string)($leaveType['name'] ?? '')));
        $isSickLeave = ($ltCode === 'SL' || strpos($ltName, 'sick') !== false || strpos($ltCode, 'SICK') !== false);

        if ($isBackdated) {
            $diffDays = (int)ceil((strtotime($today) - strtotime($fromDate)) / 86400);

            if (!$canBypassLimits) {
                if (!$allowBackdated) {
                    $errors[] = "Backdated leave applications are strictly disabled for '{$leaveType['name']}'.";
                } elseif ($maxBackdateDays > 0 && $diffDays > $maxBackdateDays) {
                    if ($isEmergency) {
                        $errors[] = "Backdated limit exceeded for '{$leaveType['name']}': Maximum allowed is {$maxBackdateDays} days in the past (requested {$diffDays} days ago). Emergency applications exceeding this limit must be submitted by HR or a Manager.";
                    } else {
                        $errors[] = "Backdated limit exceeded for '{$leaveType['name']}': Maximum allowed is {$maxBackdateDays} days in the past (requested {$diffDays} days ago).";
                    }
                }
            }

            // Note on required approvers for backdated leaves per company policy
            if (in_array($backdatedRole, ['Manager and HR', 'Manager & HR'], true)) {
                $warnings[] = "Backdated Leave: This application requires both Manager endorsement and HR Admin approval.";
            } elseif ($backdatedRole === 'HR Only') {
                $warnings[] = "Backdated Leave: This application requires HR Admin approval.";
            }
        }

        $allowFuture = $rules['allow_future_application'];
        $maxFutureDays = $rules['max_future_days'];
        if ($isFuture && $allowFuture && $maxFutureDays > 0) {
            $futureDays = (int)ceil((strtotime($fromDate) - strtotime($today)) / 86400);
            if ($futureDays > $maxFutureDays) {
                $errors[] = "Future leave limit exceeded: Applications cannot be submitted more than {$maxFutureDays} days in advance (requested {$futureDays} days in advance).";
            }
        }

        // Rule 6: Minimum Notice Period Check (Exempt for HR recording leave for others, permitted emergency applications, and same-day sick leave)
        $minNoticeDays = $rules['min_notice_days'];
        if (!$isBackdated && $minNoticeDays > 0) {
            $isSameDaySick = ($isSickLeave && $fromDate === $today);
            $isExemptFromNotice = ($canBypassLimits || ($isEmergency && $allowEmergencyAbsence) || $isSameDaySick);
            if (!$isExemptFromNotice) {
                $noticeDays = (int)floor((strtotime($fromDate) - strtotime($today)) / 86400);
                if ($noticeDays < $minNoticeDays) {
                    $warnings[] = "Notice Period Warning: '{$leaveType['name']}' policy expects minimum {$minNoticeDays} days advance notice (provided {$noticeDays} days).";
                }
            }
        }

        // Rule 7: Calculated Leave Days Span <= 0
        if ($totalDays <= 0) {
            $errors[] = "Calculated leave days is 0. Please select a valid working date range.";
        }

        // Rule 8: Max Consecutive Days
        $maxConsecutive = $rules['max_consecutive_days'];
        if ($maxConsecutive > 0 && $totalDays > $maxConsecutive) {
            $errors[] = "Consecutive Days Limit: '{$leaveType['name']}' allows a maximum of {$maxConsecutive} consecutive days per request (requested {$totalDays} days).";
        }

        // Rule 9: Half-Day & Hourly Rules
        $allowHalfDay = $rules['allow_half_day'];
        if ($isHalfDay && !$allowHalfDay) {
            $errors[] = "Half-day leave is not permitted for '{$leaveType['name']}'.";
        }
        $allowHourly = $rules['allow_hourly_leave'];
        if ($isHourly) {
            if (!$allowHourly) {
                $errors[] = "Hourly leave is not allowed for '{$leaveType['name']}'.";
            }
            $minHourly = (float)($rules['min_hourly_hours'] ?? 0);
            $maxHourly = (float)($rules['max_hourly_hours'] ?? 0);
            if ($minHourly > 0 && $hourlyHours < $minHourly) {
                $errors[] = "Minimum hourly leave duration is {$minHourly} hours.";
            }
            if ($maxHourly > 0 && $hourlyHours > $maxHourly) {
                $errors[] = "Maximum hourly leave duration is {$maxHourly} hours.";
            }
        }

        // Rule 10: Medical Certificate & Attachment Requirements
        $reqMed = (bool)$rules['requires_medical_certificate'];
        $medThreshold = (int)$rules['medical_certificate_threshold_days'];
        if ($reqMed && $totalDays > $medThreshold && !$hasMedicalCert) {
            $errors[] = "Medical Certificate Required: '{$leaveType['name']}' requests exceeding {$medThreshold} days require an attached medical prescription/certificate.";
        }
        $reqAttach = (bool)$rules['requires_attachment'];
        if ($reqAttach && !$hasAttachment && !$hasMedicalCert) {
            $errors[] = "Document Attachment Required: Supporting documents must be uploaded for '{$leaveType['name']}'.";
        }
        $reqReason = (bool)$rules['requires_reason'];
        if ($reqReason && (empty($reason) || strlen(trim($reason)) < 5)) {
            $errors[] = "A detailed reason (minimum 5 characters) is required.";
        }

        // Rule 11: Overlap Check with Active/Pending Leaves
        $existingOverlap = $this->db->table('leave_applications')
            ->where('employee_id', $employeeId)
            ->whereIn('status', ['Approved', 'Pending'])
            ->groupStart()
                ->where('from_date <=', $toDate)
                ->where('to_date >=', $fromDate)
            ->groupEnd()
            ->get()->getRowArray();
        if ($existingOverlap) {
            $errors[] = "Overlapping Leave Conflict: Already applied for leave ({$existingOverlap['id']}, {$existingOverlap['from_date']} to {$existingOverlap['to_date']}, status: {$existingOverlap['status']}).";
        }

        // Rule 12: Balance Engine & Negative Balance Rules
        $isPaid = (bool)$rules['is_paid'];
        $paidPercentage = isset($rules['paid_percentage']) && is_numeric($rules['paid_percentage']) ? (float)$rules['paid_percentage'] : 100.0;
        if ($paidPercentage < 0.0) $paidPercentage = 0.0;
        if ($paidPercentage > 100.0) $paidPercentage = 100.0;

        $shortageSplitActive = false;
        $splitPaidDays = null;
        $splitUnpaidDays = null;

        if ($projectedBalance < 0 && $isPaid) {
            $allowNegative = (bool)$rules['allow_negative_balance'];
            $maxNeg = (float)$rules['max_negative_days'];
            $allowSplit = !empty($rules['allow_unpaid_split']);
            if (!$allowNegative || $maxNeg <= 0) {
                if ($allowSplit) {
                    $shortageSplitActive = true;
                    $coveredPaid = max(0.0, $currentAvailableBalance);
                    $splitPaidDays = round($coveredPaid * ($paidPercentage / 100.0), 2);
                    $splitUnpaidDays = round($totalDays - $splitPaidDays, 2);
                    $warnings[] = "Insufficient Balance: Splitting into {$splitPaidDays} paid days and {$splitUnpaidDays} unpaid loss-of-pay days.";
                } else {
                    $errors[] = "Insufficient Leave Balance: Current balance is {$currentAvailableBalance} days. Cannot request {$totalDays} days.";
                }
            } else {
                $negAmount = abs($projectedBalance);
                if ($maxNeg > 0 && $negAmount > $maxNeg) {
                    if ($allowSplit) {
                        $shortageSplitActive = true;
                        $coveredPaid = max(0.0, $currentAvailableBalance + $maxNeg);
                        $splitPaidDays = round($coveredPaid * ($paidPercentage / 100.0), 2);
                        $splitUnpaidDays = round($totalDays - $splitPaidDays, 2);
                        $warnings[] = "Negative Balance Exceeded (-{$maxNeg}d cap): Splitting into {$splitPaidDays} paid/overdraft days and {$splitUnpaidDays} unpaid loss-of-pay days.";
                    } else {
                        $errors[] = "Negative Balance Exceeded: Maximum allowed negative balance is -{$maxNeg} days (projected: -{$negAmount} days).";
                    }
                } else {
                    $warnings[] = "Negative Balance Allowed: This request will overdraft your balance to -{$negAmount} days.";
                }
            }
        }

        // Rule 13: Determine Required Approvers by Permission + Scope (never hardcoded role names)
        $approverResolution = $this->resolveApproversForEmployee($emp);
        $requiredApprovers = !empty($approverResolution['tiers'])
            ? $approverResolution['tiers']
            : ['Tier 1: Endorsement (leave.endorse)', 'Tier 2: Final Sanction (leave.approve)'];

        // Auto-approval evaluation (must match LeaveApplicationService::applyLeave)
        $approvalWorkflow = $policy['approval_workflow'] ?? [];
        if (empty($approvalWorkflow) && !empty($policy['approval_workflow_json'])) {
            $approvalWorkflow = is_array($policy['approval_workflow_json'])
                ? $policy['approval_workflow_json']
                : (json_decode($policy['approval_workflow_json'], true) ?: []);
        }
        $autoApproveUnderDays = (float)($params['auto_approve_under_days'] ?? ($approvalWorkflow['auto_approve_under_days'] ?? ($rules['auto_approve_under_days'] ?? 0)));
        $approvalRequired = isset($params['approval_required']) ? (bool)$params['approval_required'] : (bool)($rules['approval_required'] ?? true);
        $isAutoApprovedRule = !empty($params['is_auto_approved']) || !empty($rules['is_auto_approved']);

        $isAutoApproved = \App\Services\Leave\LeaveApplicationService::determineAutoApproval([
            'is_backdated'            => $isBackdated,
            'backdated_role'          => $backdatedRole,
            'is_own_application'      => $isOwnApplication,
            'is_hr'                   => $isHR,
            'is_manager'              => $isManager,
            'approval_required'       => $approvalRequired,
            'is_auto_approved'        => $isAutoApprovedRule,
            'auto_approve_under_days' => $autoApproveUnderDays,
            'chargeable_days'         => $totalDays,
            'is_emergency'            => $isEmergency,
        ]);

        // 7. Financial & Payroll Impact Calculations
        $unpaidDaysEstimate = 0.0;
        if ($shortageSplitActive && $splitUnpaidDays !== null) {
            $unpaidDaysEstimate = (float)$splitUnpaidDays;
        } elseif (!$isPaid || $paidPercentage <= 0.0) {
            $unpaidDaysEstimate = (float)$totalDays;
        } elseif ($paidPercentage < 100.0) {
            $unpaidDaysEstimate = round($totalDays * ((100.0 - $paidPercentage) / 100.0), 2);
        }

        $unpaidTypeId = null;
        if ($unpaidDaysEstimate > 0.0) {
            try {
                $uType = $this->resolveAuthoritativeUnpaidLeaveType((string)$companyId);
                $unpaidTypeId = $uType['id'] ?? null;
            } catch (\Throwable $uex) {
                $unpaidTypeId = null;
            }
        }

        $unpaidLOP = 0.0;
        $unpaidFormula = '';
        if ($unpaidDaysEstimate > 0.0) {
            $lopRes = $this->calculateUnpaidLeaveDeduction($employeeId, $leaveTypeId, $unpaidDaysEstimate, $leaveType, $emp);
            $unpaidLOP = (float)($lopRes['deduction'] ?? 0);
            $unpaidFormula = $lopRes['formula'] ?? '';
        }

        $encashmentSample = 0.0;
        $encashSalaryBasis = '';
        $isEncashable = (($leaveType['encashment'] ?? '') === 'Yes' || !empty($leaveType['allow_encashment']));
        if ($isEncashable) {
            $encashRes = $this->calculateEncashmentAmount($employeeId, $leaveTypeId, $totalDays, $leaveType, $emp);
            $encashmentSample = (float)($encashRes['total_amount'] ?? 0);
            $encashSalaryBasis = $encashRes['salary_basis'] ?? '';
        }

        $isValid = empty($errors);
        $canApplyWithWarning = $isValid && !empty($warnings);

        // Calendar Treatment resolution
        $calTreatment = [];
        if (!empty($policy['calendarTreatment']) && is_array($policy['calendarTreatment'])) {
            $calTreatment = $policy['calendarTreatment'];
        } elseif (!empty($policy['sandwich_rules_json'])) {
            $calTreatment = is_array($policy['sandwich_rules_json']) ? $policy['sandwich_rules_json'] : (json_decode($policy['sandwich_rules_json'], true) ?: []);
        }

        if (isset($calTreatment['weekendTreatment'])) {
            $weekendTreatment = $calTreatment['weekendTreatment'];
        } elseif (isset($calTreatment['weekend_treatment'])) {
            $weekendTreatment = $calTreatment['weekend_treatment'];
        } elseif (isset($calTreatment['treatWeekendAsLeave'])) {
            $weekendTreatment = $calTreatment['treatWeekendAsLeave'] ? 'Count weekly off as leave' : 'Include if sandwiched';
        } else {
            $weekendTreatment = 'Include if sandwiched';
        }

        if (isset($calTreatment['holidayTreatment'])) {
            $holidayTreatment = $calTreatment['holidayTreatment'];
        } elseif (isset($calTreatment['holiday_treatment'])) {
            $holidayTreatment = $calTreatment['holiday_treatment'];
        } elseif (isset($calTreatment['treatHolidayAsLeave'])) {
            $holidayTreatment = $calTreatment['treatHolidayAsLeave'] ? 'Count holidays as leave' : 'Include if sandwiched';
        } else {
            $holidayTreatment = 'Include if sandwiched';
        }

        $bridgeLeaveEnabled = isset($calTreatment['bridgeLeaveEnabled']) ? (bool)$calTreatment['bridgeLeaveEnabled'] : ($calTreatment['enabled'] ?? true);
        $bridgeLeaveAction = $calTreatment['bridgeLeaveAction'] ?? 'Count intervening days';

        $activeSal = null;
        try {
            $salService = class_exists('\Config\Services') && method_exists('\Config\Services', 'salary')
                ? \Config\Services::salary()
                : new \App\Services\EmployeeSalaryService();
            $activeSal = $salService->getActiveSalary($employeeId, date('Y-m-d'));
        } catch (\Throwable $e) {
            $activeSal = null;
        }

        return [
            'success'          => true,
            'eligible'         => $isValid,
            'is_auto_approved' => $isAutoApproved,
            'errors'           => $errors,
            'warnings'         => $warnings,
            'resolvedPolicy' => [
                'id'                 => (string)($policy['id'] ?? ('rd-' . substr(md5(($emp['company_id'] ?? '') . 'LEAVE'), 0, 16))),
                'name'               => (string)($policy['name'] ?? 'Company Leave Rules'),
                'code'               => (string)($policy['code'] ?? 'RULE-LEAVE'),
                'scopeLevel'         => (string)($policy['scope_level'] ?? 'Company'),
                'weekendTreatment'   => $weekendTreatment,
                'holidayTreatment'   => $holidayTreatment,
                'bridgeLeaveEnabled' => $bridgeLeaveEnabled,
                'bridgeLeaveAction'  => $bridgeLeaveAction,
            ],
            'span' => [
                'totalDays'           => $totalDays,
                'workingDays'         => $workingDays,
                'weekendDaysCount'    => $weekendDays,
                'holidayDaysCount'    => $holidayDays,
                'bridgeDaysCount'     => $bridgeDays,
                'sandwichRuleApplies' => $sandwichApplies,
                'breakdownText'       => $breakdownText
            ],
            'validation' => [
                'isValid'             => $isValid,
                'is_auto_approved'    => $isAutoApproved,
                'canApplyWithWarning' => $canApplyWithWarning,
                'errors'              => $errors,
                'warnings'            => $warnings,
                'requiredApprovers'   => $requiredApprovers,
                'eligibleEndorsers'   => $approverResolution['endorsers'] ?? [],
                'eligibleApprovers'   => $approverResolution['approvers'] ?? [],
                'calculatedDays'      => $totalDays
            ],
            'currentBalance'    => $currentAvailableBalance,
            'projectedBalance'  => $projectedBalance,
            'unpaidLOP'         => $unpaidLOP,
            'unpaidFormula'     => $unpaidFormula,
            'unpaidDays'        => $unpaidDaysEstimate,
            'unpaidLeaveTypeId' => $unpaidTypeId,
            'unpaid_leave_type_id' => $unpaidTypeId,
            'encashmentSample'  => $encashmentSample,
            'encashSalaryBasis' => $encashSalaryBasis,
            'employee'          => [
                'id'             => $emp['id'],
                'name'           => trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')) ?: ($emp['employee_code'] ?? $emp['id']),
                'status'         => $emp['status'] ?? 'Active',
                'department_id'  => $emp['department_id'] ?? null,
                'designation_id' => $emp['designation_id'] ?? null,
                'joining_date'   => employee_joining_date($emp) ?? 'N/A',
                'join_date'      => employee_joining_date($emp) ?? 'N/A',
                'confirm_date'   => $emp['confirm_date'] ?? $emp['confirmation_date'] ?? null,
                'basic_salary'   => (float)($activeSal['basic_salary'] ?? $emp['basic_salary'] ?? 0),
                'gross_salary'   => (float)($activeSal['gross_salary'] ?? $emp['gross_salary'] ?? 0)
            ],
            'leaveType'        => [
                'id'                      => $leaveType['id'],
                'name'                    => $leaveType['name'],
                'code'                    => $leaveType['code'] ?? '',
                'is_paid'                 => $isPaid ? 'Yes' : 'No',
                'days_per_year'           => (float)($leaveType['days_per_year'] ?? $leaveType['annual_allocation'] ?? 10),
                'encashment'              => $isEncashable ? 'Yes' : 'No',
                'encashment_salary_basis' => $leaveType['encashment_salary_basis'] ?? 'Basic Salary'
            ]
        ];
    }

    /**
     * Resolve eligible approvers for an employee based strictly on permissions and scope.
     * Never resolves by hardcoded role names.
     *
     * @param array $emp Employee record
     * @return array ['endorsers' => string[], 'approvers' => string[], 'tiers' => string[]]
     */
    public function resolveApproversForEmployee(array $emp): array
    {
        $permService = new \App\Services\PermissionService();
        $companyId = $emp['company_id'] ?? null;
        $employeeId = $emp['id'] ?? null;

        // Query active users belonging to the company or platform admins
        $userBuilder = $this->db->table('users')->where('status', 'active');
        if ($companyId) {
            $userBuilder->groupStart()
                ->where('company_id', $companyId)
                ->orWhere('role_code', 'software_app_admin')
                ->orWhere("role_id IN (SELECT id FROM roles WHERE code = 'software_app_admin' OR name = 'Software App Admin')", null, false)
                ->groupEnd();
        }
        $users = $userBuilder->get()->getResultArray();

        $endorsers = [];
        $approvers = [];

        foreach ($users as $u) {
            $uEmpId = $u['employee_id'] ?? null;
            // Prevent self-endorsement / self-approval
            if (!empty($employeeId) && ($u['id'] === $employeeId || (string)$uEmpId === (string)$employeeId)) {
                continue;
            }

            // Check endorse permission
            $endorseDecision = $permService->can($u['id'], 'leave.endorse', $companyId);
            if ($endorseDecision->isAllowed()) {
                if ($permService->assertInScope($u, $endorseDecision, $emp)) {
                    $name = trim(($u['first_name'] ?? '') . ' ' . ($u['last_name'] ?? '')) ?: ($u['username'] ?? 'Endorser');
                    $endorsers[] = $name . ' (' . ucfirst($endorseDecision->scope()) . ' Endorser)';
                }
            }

            // Check approve permission
            $approveDecision = $permService->can($u['id'], 'leave.approve', $companyId);
            if ($approveDecision->isAllowed()) {
                if ($permService->assertInScope($u, $approveDecision, $emp)) {
                    $name = trim(($u['first_name'] ?? '') . ' ' . ($u['last_name'] ?? '')) ?: ($u['username'] ?? 'Approver');
                    $approvers[] = $name . ' (' . ucfirst($approveDecision->scope()) . ' Approver)';
                }
            }

            // Check HR approve permission (for multi-tier final step)
            $hrApproveDecision = $permService->can($u['id'], 'leave.hr_approve', $companyId);
            if (!$hrApproveDecision->isAllowed()) {
                $hrApproveDecision = $permService->can($u['id'], 'leaves.hr_approve', $companyId);
            }
            if ($hrApproveDecision->isAllowed()) {
                if ($permService->assertInScope($u, $hrApproveDecision, $emp)) {
                    $name = trim(($u['first_name'] ?? '') . ' ' . ($u['last_name'] ?? '')) ?: ($u['username'] ?? 'HR Approver');
                    $approvers[] = $name . ' (' . ucfirst($hrApproveDecision->scope()) . ' HR Approver)';
                }
            }
        }

        $tierSummary = [];
        if (!empty($endorsers)) {
            $tierSummary[] = 'Tier 1: Endorsement (leave.endorse)';
        }
        $tierSummary[] = 'Tier 2: Final Sanction (leave.hr_approve / leave.approve)';

        return [
            'endorsers' => array_values(array_unique($endorsers)),
            'approvers' => array_values(array_unique($approvers)),
            'tiers'     => $tierSummary,
        ];
    }

    /**
     * GAP-02: Leave Ledger Audit & Reconciliation Matrix
     * Live mathematical verification comparing immutable transaction logs against quota allocations.
     * Compares like-with-like (ledger used vs live approved, encashed vs encashed, adjustments vs manual).
     * Bulk loads all sources to avoid N*M database round-trips.
     *
     * @param string|null $companyId Authoritative company tenant context
     * @param int|null $year Target year (defaults to current year)
     * @param string|null $departmentId Optional department filter
     * @param string|null $branchId Optional branch filter
     * @param int $page 1-indexed page number (default 1)
     * @param int $perPage Rows per page (default 100, 0 for all)
     * @return array Matrix rows, metrics, and pagination metadata
     */
    public function getReconciliationMatrix(
        ?string $companyId = null,
        ?int $year = null,
        ?string $departmentId = null,
        ?string $branchId = null,
        int $page = 1,
        int $perPage = 100
    ): array {
        $year = $year ?: (int)date('Y');

        if (empty($companyId)) {
            return [
                'rows'    => [],
                'metrics' => [
                    'total_quotas'          => 0,
                    'optimal_count'         => 0,
                    'flagged_count'         => 0,
                    'overdrawn_count'       => 0,
                    'missing_opening_count' => 0,
                ],
                'pagination' => [
                    'page'        => $page,
                    'per_page'    => $perPage,
                    'total_rows'  => 0,
                    'total_pages' => 1,
                ],
            ];
        }

        // 1. Fetch active employees strictly scoped to company (exclude Resigned, Terminated, Inactive)
        $empBuilder = $this->db->table('employees')
            ->select('employees.id, employees.employee_code, employees.first_name, employees.last_name, 
                      employees.department_id, departments.name as department_name, 
                      employees.branch_id, branches.name as branch_name,
                      employees.status, employees.company_id')
            ->join('departments', 'departments.id = employees.department_id', 'left')
            ->join('branches', 'branches.id = employees.branch_id', 'left')
            ->where('employees.company_id', $companyId)
            ->whereNotIn('employees.status', [
                \App\Models\EmployeeModel::STATUS_RESIGNED,
                \App\Models\EmployeeModel::STATUS_TERMINATED,
                \App\Models\EmployeeModel::STATUS_INACTIVE,
            ]);

        if (!empty($departmentId) && $departmentId !== 'all') {
            $empBuilder->where('employees.department_id', $departmentId);
        }
        if (!empty($branchId) && $branchId !== 'all') {
            $empBuilder->where('employees.branch_id', $branchId);
        }

        $employees = $empBuilder->orderBy('employees.first_name', 'ASC')->get()->getResultArray();

        // 2. Fetch active leave types for company
        $leaveTypes = $this->leaveTypeModel->getActiveTypes($companyId);
        if (empty($leaveTypes) || empty($employees)) {
            return [
                'rows'    => [],
                'metrics' => [
                    'total_quotas'          => 0,
                    'optimal_count'         => 0,
                    'flagged_count'         => 0,
                    'overdrawn_count'       => 0,
                    'missing_opening_count' => 0,
                ],
                'pagination' => [
                    'page'        => $page,
                    'per_page'    => $perPage,
                    'total_rows'  => 0,
                    'total_pages' => 1,
                ],
            ];
        }

        // 3. Resolve LEAVE domain entitlements once in-memory from Single Rule Store
        $ruleEntitlements = [];
        try {
            $leaveRule = \App\Services\Rules\RuleResolver::resolveForCompany($companyId, 'LEAVE', "{$year}-01-01");
            $ents = $leaveRule->get('entitlements') ?: [];
            foreach ($ents as $e) {
                $code = strtoupper(trim((string)($e['leave_type_code'] ?? '')));
                if ($code) {
                    $ruleEntitlements[$code] = $e;
                }
                $ltId = (string)($e['leave_type_id'] ?? '');
                if ($ltId) {
                    $ruleEntitlements[$ltId] = $e;
                }
            }
        } catch (\Throwable $e) {
            log_message('warning', 'getReconciliationMatrix RuleResolver warning: ' . $e->getMessage());
        }

        // 4. Source 1: Bulk load all leave_transactions for company in target year (one query)
        $txSummary = [];
        if ($this->db->tableExists('leave_transactions')) {
            $txBuilder = $this->db->table('leave_transactions')
                ->select('leave_transactions.employee_id, leave_transactions.leave_type_id, leave_transactions.transaction_type, 
                          COALESCE(leave_transactions.days, 0) AS amt')
                ->join('employees', 'employees.id = leave_transactions.employee_id', 'inner')
                ->where('employees.company_id', $companyId);

            if (!empty($departmentId) && $departmentId !== 'all') {
                $txBuilder->where('employees.department_id', $departmentId);
            }
            if (!empty($branchId) && $branchId !== 'all') {
                $txBuilder->where('employees.branch_id', $branchId);
            }

            $cols = $this->transactionModel->getTableColumns();
            $hasTxDate = in_array('transaction_date', $cols, true);
            if ($hasTxDate) {
                $txBuilder->where("(YEAR(leave_transactions.transaction_date) = {$year} OR (leave_transactions.transaction_date IS NULL AND YEAR(leave_transactions.created_at) = {$year}))");
            } else {
                $txBuilder->where("YEAR(leave_transactions.created_at) = {$year}");
            }

            $rawTxs = $txBuilder->get()->getResultArray();
            foreach ($rawTxs as $tx) {
                $eId = (string)$tx['employee_id'];
                $ltId = (string)$tx['leave_type_id'];
                $type = trim((string)($tx['transaction_type'] ?? ''));
                $amt = (float)($tx['amt'] ?? 0);
                $typeLower = strtolower($type);

                if (!isset($txSummary[$eId][$ltId])) {
                    $txSummary[$eId][$ltId] = [
                        'opening'       => 0.0,
                        'accrued'       => 0.0,
                        'adjustments'   => 0.0,
                        'carry_forward' => 0.0,
                        'deductions'    => 0.0,
                        'reversals'     => 0.0,
                        'encashed'      => 0.0,
                        'expired'       => 0.0,
                        'has_opening'   => false,
                        'tx_count'      => 0,
                    ];
                }

                $txSummary[$eId][$ltId]['tx_count']++;

                if ($typeLower === 'opening') {
                    $txSummary[$eId][$ltId]['opening'] += $amt;
                    $txSummary[$eId][$ltId]['has_opening'] = true;
                } elseif ($typeLower === 'accrual') {
                    $txSummary[$eId][$ltId]['accrued'] += $amt;
                } elseif ($typeLower === 'adjustment credit') {
                    $txSummary[$eId][$ltId]['adjustments'] += abs($amt);
                } elseif ($typeLower === 'adjustment debit') {
                    $txSummary[$eId][$ltId]['adjustments'] -= abs($amt);
                } elseif ($typeLower === 'adjustment') {
                    $txSummary[$eId][$ltId]['adjustments'] += $amt;
                } elseif (in_array($typeLower, ['carry forward', 'carry_forward', 'carryforward'], true)) {
                    $txSummary[$eId][$ltId]['carry_forward'] += $amt;
                } elseif (in_array($typeLower, ['deduction', 'leave used', 'used', 'debit'], true)) {
                    $txSummary[$eId][$ltId]['deductions'] += abs($amt);
                } elseif ($typeLower === 'reversal') {
                    $txSummary[$eId][$ltId]['reversals'] += abs($amt);
                } elseif (in_array($typeLower, ['encashment', 'encashed'], true)) {
                    $txSummary[$eId][$ltId]['encashed'] += abs($amt);
                } elseif (in_array($typeLower, ['expiry', 'expired'], true)) {
                    $txSummary[$eId][$ltId]['expired'] += abs($amt);
                }
            }
        }

        // 5. Source 2: Bulk load stored leave_balances for company in target year (one query)
        $balSummary = [];
        if ($this->db->tableExists('leave_balances')) {
            $balBuilder = $this->db->table('leave_balances')
                ->select('leave_balances.employee_id, leave_balances.leave_type_id, 
                          leave_balances.opening_balance, leave_balances.allocated_days,
                          leave_balances.accrued_days, leave_balances.carry_forward_days,
                          leave_balances.approved_leave_days, leave_balances.pending_leave_days,
                          leave_balances.unpaid_adjustment_days, leave_balances.encashed_days,
                          leave_balances.manual_adjustment_days')
                ->join('employees', 'employees.id = leave_balances.employee_id', 'inner')
                ->where('employees.company_id', $companyId)
                ->where('leave_balances.year', $year);

            if (!empty($departmentId) && $departmentId !== 'all') {
                $balBuilder->where('employees.department_id', $departmentId);
            }
            if (!empty($branchId) && $branchId !== 'all') {
                $balBuilder->where('employees.branch_id', $branchId);
            }

            $rawBals = $balBuilder->get()->getResultArray();
            foreach ($rawBals as $b) {
                $eId = (string)$b['employee_id'];
                $ltId = (string)$b['leave_type_id'];
                $balSummary[$eId][$ltId] = $b;
            }
        }

        // 6. Source 3: Bulk load live leave_applications totals for company in target year (one query)
        $appSummary = [];
        if ($this->db->tableExists('leave_applications')) {
            $startOfYear = "{$year}-01-01";
            $endOfYear   = "{$year}-12-31";

            $hasFrom = $this->db->fieldExists('from_date', 'leave_applications');
            $hasTo   = $this->db->fieldExists('to_date', 'leave_applications');
            $hasStart = $this->db->fieldExists('start_date', 'leave_applications');
            $hasEnd   = $this->db->fieldExists('end_date', 'leave_applications');
            $hasCreated = $this->db->fieldExists('created_at', 'leave_applications');

            $startCols = [];
            if ($hasFrom) $startCols[] = 'leave_applications.from_date';
            if ($hasStart) $startCols[] = 'leave_applications.start_date';
            if ($hasCreated) $startCols[] = 'leave_applications.created_at';
            $sExpr = !empty($startCols) ? (count($startCols) > 1 ? 'COALESCE(' . implode(', ', $startCols) . ')' : $startCols[0]) : null;

            $endCols = [];
            if ($hasTo) $endCols[] = 'leave_applications.to_date';
            if ($hasEnd) $endCols[] = 'leave_applications.end_date';
            if ($hasFrom) $endCols[] = 'leave_applications.from_date';
            if ($hasStart) $endCols[] = 'leave_applications.start_date';
            if ($hasCreated) $endCols[] = 'leave_applications.created_at';
            $eExpr = !empty($endCols) ? (count($endCols) > 1 ? 'COALESCE(' . implode(', ', $endCols) . ')' : $endCols[0]) : null;

            $appBuilder = $this->db->table('leave_applications')
                ->select('leave_applications.employee_id, leave_applications.leave_type_id, 
                          LOWER(leave_applications.status) AS status_lower,
                          leave_applications.total_days,
                          leave_applications.year_split')
                ->join('employees', 'employees.id = leave_applications.employee_id', 'inner')
                ->where('employees.company_id', $companyId);

            if ($sExpr) {
                $appBuilder->where("{$sExpr} <=", $endOfYear);
            }
            if ($eExpr) {
                $appBuilder->where("{$eExpr} >=", $startOfYear);
            }
            $appBuilder->whereIn('LOWER(leave_applications.status)', ['approved', 'pending']);

            if (!empty($departmentId) && $departmentId !== 'all') {
                $appBuilder->where('employees.department_id', $departmentId);
            }
            if (!empty($branchId) && $branchId !== 'all') {
                $appBuilder->where('employees.branch_id', $branchId);
            }

            $rawRes = $appBuilder->get();
            $rawApps = ($rawRes && is_object($rawRes)) ? $rawRes->getResultArray() : [];
            foreach ($rawApps as $a) {
                $eId = (string)$a['employee_id'];
                $ltId = (string)$a['leave_type_id'];
                $st = (string)$a['status_lower'];

                $d = null;
                if (!empty($a['year_split'])) {
                    $split = is_array($a['year_split']) ? $a['year_split'] : json_decode((string)$a['year_split'], true);
                    if (is_array($split)) {
                        if (isset($split['paid']) || isset($split['unpaid'])) {
                            $p = (float)($split['paid'][$year] ?? $split['paid'][(string)$year] ?? 0);
                            $u = (float)($split['unpaid'][$year] ?? $split['unpaid'][(string)$year] ?? 0);
                            $d = $p + $u;
                        } elseif (isset($split[$year]) || isset($split[(string)$year])) {
                            $yrData = $split[$year] ?? $split[(string)$year];
                            if (is_array($yrData)) {
                                $d = (float)($yrData['paid'] ?? 0) + (float)($yrData['unpaid'] ?? 0);
                            } else {
                                $d = (float)$yrData;
                            }
                        } else {
                            $d = 0.0;
                        }
                    }
                }
                if ($d === null) {
                    $d = (float)($a['total_days'] ?? 0);
                }

                if (!isset($appSummary[$eId][$ltId])) {
                    $appSummary[$eId][$ltId] = ['approved' => 0.0, 'pending' => 0.0];
                }
                if ($st === 'approved') {
                    $appSummary[$eId][$ltId]['approved'] += $d;
                } elseif ($st === 'pending') {
                    $appSummary[$eId][$ltId]['pending'] += $d;
                }
            }
        }

        $items = [];
        $optimalCount = 0;
        $overdrawnCount = 0;
        $missingOpeningCount = 0;

        // 7. Iterate Cartesian Product: activeEmployees × activeLeaveTypes in memory
        foreach ($employees as $emp) {
            $fName = trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? ''));
            $empName = !empty($fName) ? $fName : ($emp['employee_code'] ?? $emp['id']);
            $deptName = $emp['department_name'] ?? ($emp['department_id'] ?? '');

            foreach ($leaveTypes as $lt) {
                $ltCode = strtoupper(trim((string)($lt['code'] ?? '')));
                $matchedRule = $ruleEntitlements[$ltCode] ?? $ruleEntitlements[$lt['id']] ?? null;
                if (!$matchedRule) {
                    foreach ($ruleEntitlements as $rc => $re) {
                        if (self::matchLeaveTypeCode($ltCode, $rc, $lt['name'] ?? null)) {
                            $matchedRule = $re;
                            break;
                        }
                    }
                }

                $accrualMode = $matchedRule['accrual_mode'] ?? null;
                $ruleDaysPerYear = (float)($matchedRule['days_per_year'] ?? $lt['days_per_year'] ?? 0.0);
                $isRuleDerived = !empty($accrualMode) || ($ruleDaysPerYear > 0.0);

                // Ledger transactions aggregation (Source 1)
                $txData = $txSummary[$emp['id']][$lt['id']] ?? [
                    'opening'       => 0.0,
                    'accrued'       => 0.0,
                    'adjustments'   => 0.0,
                    'carry_forward' => 0.0,
                    'deductions'    => 0.0,
                    'reversals'     => 0.0,
                    'encashed'      => 0.0,
                    'expired'       => 0.0,
                    'has_opening'   => false,
                    'tx_count'      => 0,
                ];

                $opening         = round((float)$txData['opening'], 2);
                $accrued         = round((float)$txData['accrued'], 2);
                $adjustments     = round((float)$txData['adjustments'], 2);
                $carryForward    = round((float)$txData['carry_forward'], 2);
                $used            = round(max(0.0, (float)$txData['deductions'] - (float)$txData['reversals']), 2);
                $encashed        = round((float)$txData['encashed'], 2);
                $expired         = round((float)$txData['expired'], 2);
                $hasOpeningTx    = (bool)$txData['has_opening'];

                $ledgerBal = round(($opening + $accrued + $adjustments + $carryForward - $used - $encashed - $expired), 2);

                // Stored balance and live applications (Sources 2 & 3)
                $bal = $balSummary[$emp['id']][$lt['id']] ?? [];
                $app = $appSummary[$emp['id']][$lt['id']] ?? ['approved' => 0.0, 'pending' => 0.0];

                $liveApproved  = round(max((float)($bal['approved_leave_days'] ?? 0.0), (float)($app['approved'] ?? 0.0)), 2);
                $liveEncashed  = round((float)($bal['encashed_days'] ?? 0.0), 2);
                $liveManualAdj = round((float)($bal['manual_adjustment_days'] ?? 0.0), 2);
                $storedOpening = round((float)($bal['opening_balance'] ?? 0.0), 2);

                // Compare like with like (identically rounded to 2 decimal places)
                $usedDiff     = round($used - $liveApproved, 2);
                $encashedDiff = round($encashed - $liveEncashed, 2);
                $adjDiff      = round($adjustments - $liveManualAdj, 2);

                $hasUsedDiscrepancy     = abs($usedDiff) >= 0.01;
                $hasEncashedDiscrepancy = abs($encashedDiff) >= 0.01;
                $hasAdjDiscrepancy      = abs($adjDiff) >= 0.01;
                $hasDiscrepancy         = ($hasUsedDiscrepancy || $hasEncashedDiscrepancy || $hasAdjDiscrepancy);

                // Ordered check hierarchy:
                // 1. OVERDRAWN: never flag OVERDRAWN for a type whose entitlement is rule-derived
                $isOverdrawn = false;
                if (!$isRuleDerived && $ledgerBal < -0.009) {
                    $isOverdrawn = true;
                }

                // 2. MISSING_OPENING: reachable for non-rule types lacking initial opening credit
                $isMissingOpening = false;
                if (!$isRuleDerived && !$hasOpeningTx && $storedOpening <= 0.009) {
                    $isMissingOpening = true;
                }

                if ($isOverdrawn) {
                    $discrepancyType = 'OVERDRAWN';
                    $absOver = number_format(abs($ledgerBal), 2);
                    $statusNote = "Negative balance overdraft (-{$absOver} days).";
                    $overdrawnCount++;
                } elseif ($isMissingOpening) {
                    $discrepancyType = 'MISSING_OPENING';
                    $statusNote = 'No initial opening transaction found.';
                    $missingOpeningCount++;
                } elseif ($hasDiscrepancy) {
                    $discrepancyType = 'DISCREPANCY';
                    $notes = [];
                    if ($hasUsedDiscrepancy) {
                        $notes[] = "Used ({$used}d) vs Approved ({$liveApproved}d)";
                    }
                    if ($hasEncashedDiscrepancy) {
                        $notes[] = "Encashed ({$encashed}d) vs Live ({$liveEncashed}d)";
                    }
                    if ($hasAdjDiscrepancy) {
                        $notes[] = "Adjustments ({$adjustments}d) vs Manual ({$liveManualAdj}d)";
                    }
                    $statusNote = "Discrepancy: " . implode('; ', $notes) . '.';
                } else {
                    $discrepancyType = 'OPTIMAL';
                    $statusNote = 'Quota verified: Balanced ledger.';
                    $optimalCount++;
                }

                $items[] = [
                    'employeeId'      => (string)$emp['id'],
                    'employeeCode'    => (string)($emp['employee_code'] ?? ''),
                    'employeeName'    => $empName,
                    'departmentName'  => $deptName,
                    'leaveTypeId'     => (string)$lt['id'],
                    'leaveTypeName'   => (string)$lt['name'],
                    'leaveTypeCode'   => (string)($lt['code'] ?? ''),
                    'ledgerBalance'   => $ledgerBal,
                    'liveBalance'     => $liveApproved,
                    'opening'         => $opening,
                    'accrued'         => $accrued,
                    'adjustments'     => $adjustments,
                    'carryForward'    => $carryForward,
                    'used'            => $used,
                    'encashed'        => $encashed,
                    'expired'         => $expired,
                    'isBalanced'      => $discrepancyType === 'OPTIMAL',
                    'isOverdrawn'     => $isOverdrawn,
                    'discrepancyType' => $discrepancyType,
                    'statusNote'      => $statusNote,
                ];
            }
        }

        $totalQuotas = count($items);
        $flaggedCount = $totalQuotas - $optimalCount;

        // Paginate result (e.g. 100 rows per page)
        $paginatedRows = $items;
        if ($perPage > 0) {
            $offset = max(0, ($page - 1) * $perPage);
            $paginatedRows = array_slice($items, $offset, $perPage);
        }

        return [
            'rows'    => $paginatedRows,
            'metrics' => [
                'total_quotas'          => $totalQuotas,
                'optimal_count'         => $optimalCount,
                'flagged_count'         => $flaggedCount,
                'overdrawn_count'       => $overdrawnCount,
                'missing_opening_count' => $missingOpeningCount,
            ],
            'pagination' => [
                'page'        => $page,
                'per_page'    => $perPage,
                'total_rows'  => $totalQuotas,
                'total_pages' => $perPage > 0 ? (int)ceil($totalQuotas / $perPage) : 1,
            ],
        ];
    }

    /**
     * GAP-02: Auto-reconciliation repair of MISSING_OPENING ledger quotas.
     * Controlled mutation that inserts initial Opening transactions with atomic transaction protection,
     * authoritative tenant isolation, duplicate prevention, balance caching synchronization, and audit logging.
     *
     * @param array $items Array of items submitted for repair (employeeId, leaveTypeId)
     * @param string $userId Performed by user ID
     * @param string|null $companyId Authoritative company tenant scope
     * @return array Execution report [success, repaired_count, skipped_count, errors, metrics]
     */
    public function autoReconcileMissingOpenings(array $items, string $userId, ?string $companyId = null): array
    {
        // DISABLED PENDING REVIEW: Prevent double-counting of leave entitlements until architectural review is approved.
        return [
            'success'        => false,
            'message'        => 'Auto-reconciliation of missing openings is disabled pending review to prevent duplicate entitlement allocation.',
            'repaired_count' => 0,
            'skipped_count'  => count($items),
            'errors'         => ['Auto-reconciliation is disabled pending review.'],
            'metrics'        => [
                'total_quotas'          => count($items),
                'optimal_count'         => 0,
                'flagged_count'         => count($items),
                'overdrawn_count'       => 0,
                'missing_opening_count' => count($items)
            ]
        ];

        if (empty($companyId)) {
            return [
                'success'        => false,
                'message'        => 'Authoritative company context required for auto-reconciliation.',
                'repaired_count' => 0,
                'skipped_count'  => 0,
                'errors'         => ['Missing tenant company context.']
            ];
        }

        $currentYear = (int)date('Y');
        $effectiveDate = "{$currentYear}-01-01";
        $performedBy = 'Reconciliation Audit Engine';
        $reason = 'System automated ledger reconciliation: Initial annual allocation';

        $repairedCount = 0;
        $skippedCount = 0;
        $errors = [];

        $this->db->transStart();

        try {
            foreach ($items as $idx => $item) {
                $empId = (string)($item['employeeId'] ?? $item['employee_id'] ?? '');
                $ltId = (string)($item['leaveTypeId'] ?? $item['leave_type_id'] ?? '');

                if (empty($empId) || empty($ltId)) {
                    $skippedCount++;
                    continue;
                }

                // 1. Authoritative verification of Employee and Tenant
                $emp = $this->db->table('employees')
                    ->where('id', $empId)
                    ->where('company_id', $companyId)
                    ->get()
                    ->getRowArray();

                $empNormStatus = \App\Models\EmployeeModel::normalizeStatus($emp['status'] ?? '', true);
                if (!$emp || in_array($empNormStatus, [\App\Models\EmployeeModel::STATUS_RESIGNED, \App\Models\EmployeeModel::STATUS_TERMINATED, \App\Models\EmployeeModel::STATUS_INACTIVE], true)) {
                    $skippedCount++;
                    $errors[] = "Employee {$empId} invalid or not eligible for company {$companyId}.";
                    continue;
                }

                // 2. Authoritative verification of Leave Type and Tenant
                $lt = $this->db->table('leave_types')
                    ->where('id', $ltId)
                    ->where('company_id', $companyId)
                    ->groupStart()
                        ->where('status', 'active')
                        ->orWhere('status', 'Active')
                        ->orWhere('status', null)
                    ->groupEnd()
                    ->get()
                    ->getRowArray();

                if (!$lt) {
                    $skippedCount++;
                    $errors[] = "Leave type {$ltId} invalid or inactive for company {$companyId}.";
                    continue;
                }

                // 3. Authoritative check for duplicate Opening transaction (idempotent / race-proof)
                $existingTx = $this->db->table('leave_transactions')
                    ->where('employee_id', $empId)
                    ->where('leave_type_id', $ltId)
                    ->groupStart()
                        ->where('transaction_type', 'Opening')
                        ->orWhere('transaction_type', 'opening')
                    ->groupEnd()
                    ->countAllResults();

                if ($existingTx > 0) {
                    $skippedCount++;
                    continue;
                }

                // 4. Resolve authoritative allocation from Single Rule Store (domain: LEAVE)
                $ruleAlloc = null;
                if (!empty($companyId)) {
                    try {
                        $leaveRule = (new RuleResolver())->resolve($companyId, 'LEAVE', $effectiveDate, $emp);
                        $entitlements = $leaveRule->get('entitlements') ?: [];
                        $ltCode = strtoupper($lt['code'] ?? '');
                        foreach ($entitlements as $ent) {
                            $entCode = strtoupper(trim((string)($ent['leave_type_code'] ?? '')));
                            if ($entCode === $ltCode 
                                || ($ent['leave_type_id'] ?? '') === $ltId
                                || self::matchLeaveTypeCode($ltCode, $entCode, $lt['name'] ?? null)) {
                                $ruleAlloc = (float)($ent['days_per_year'] ?? 0.0);
                                break;
                            }
                        }
                    } catch (\Throwable $e) {
                        log_message('error', 'reconcileBalances rule resolution error: ' . $e->getMessage());
                    }
                }
                $alloc = $ruleAlloc !== null ? $ruleAlloc : (float)($lt['days_per_year'] ?? $lt['annual_allocation'] ?? 0.0);

                // 5. Insert Opening Transaction into leave_transactions
                $txId = 'LTX-RECON-' . date('YmdHis') . '-' . bin2hex(random_bytes(4));
                $insertData = [
                    'id'               => $txId,
                    'employee_id'      => $empId,
                    'leave_type_id'    => $ltId,
                    'transaction_type' => 'Opening',
                    'days'             => $alloc,
                    'balance_before'   => 0.00,
                    'balance_after'    => $alloc,
                    'reference_id'     => 'RECON-' . $currentYear,
                    'remarks'          => $reason,
                    'transaction_date' => $effectiveDate,
                    'performed_by'     => $performedBy,
                    'created_at'       => date('Y-m-d H:i:s')
                ];

                // Check table columns to avoid column mismatch errors
                $cols = $this->transactionModel->getTableColumns();
                $finalTxData = [];
                foreach ($insertData as $k => $v) {
                    if (in_array($k, $cols, true)) {
                        $finalTxData[$k] = $v;
                    }
                }
                if (in_array('amount', $cols, true) && !isset($finalTxData['amount'])) {
                    $finalTxData['amount'] = $alloc;
                }

                $this->transactionModel->insert($finalTxData);

                // 6. Synchronize leave_balances summary record consistently
                $existingBal = $this->db->table('leave_balances')
                    ->where('employee_id', $empId)
                    ->where('leave_type_id', $ltId)
                    ->where('year', $currentYear)
                    ->get()
                    ->getRowArray();

                if ($existingBal) {
                    $this->db->table('leave_balances')
                        ->where('id', $existingBal['id'])
                        ->update([
                            'opening_balance' => $alloc,
                            'allocated_days'  => $alloc,
                            'updated_at'      => date('Y-m-d H:i:s')
                        ]);
                } else {
                    $balId = 'bal-' . bin2hex(random_bytes(6));
                    $this->balanceModel->insert([
                        'id'                     => $balId,
                        'employee_id'            => $empId,
                        'leave_type_id'          => $ltId,
                        'year'                   => $currentYear,
                        'opening_balance'        => $alloc,
                        'allocated_days'         => $alloc,
                        'accrued_days'           => 0.00,
                        'carry_forward_days'     => 0.00,
                        'approved_leave_days'    => 0.00,
                        'pending_leave_days'     => 0.00,
                        'unpaid_adjustment_days' => 0.00,
                        'encashed_days'          => 0.00,
                        'created_at'             => date('Y-m-d H:i:s')
                    ]);
                }

                // 7. Write Forensic Audit Log
                $auditService = new \App\Services\AuditService();
                $empName = trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')) ?: $emp['employee_code'];
                $auditService->log(
                    $userId,
                    $companyId,
                    'leave',
                    'leave.reconciliation_repaired',
                    $txId,
                    null,
                    [
                        'employee_id'      => $empId,
                        'employee_name'    => $empName,
                        'leave_type_id'    => $ltId,
                        'leave_type_name'  => $lt['name'],
                        'transaction_type' => 'Opening',
                        'amount'           => $alloc,
                        'year'             => $currentYear,
                        'reason'           => $reason,
                        'performed_by'     => $performedBy
                    ],
                    "Repaired missing opening quota: credited {$alloc} days to {$empName} ({$lt['name']})"
                );

                $repairedCount++;
            }

            $this->db->transComplete();

            if ($this->db->transStatus() === false) {
                return [
                    'success'        => false,
                    'message'        => 'Transaction aborted due to database error during reconciliation.',
                    'repaired_count' => 0,
                    'skipped_count'  => $skippedCount,
                    'errors'         => ['Database transaction failed.']
                ];
            }

            // Fresh metrics computation after repair
            $updatedMatrix = $this->getReconciliationMatrix($companyId, $currentYear);

            return [
                'success'        => true,
                'message'        => $repairedCount > 0 
                    ? "Audit completed: Repaired {$repairedCount} missing quota allocations." 
                    : "Audit complete: All ledger balances are mathematically verified and balanced.",
                'repaired_count' => $repairedCount,
                'skipped_count'  => $skippedCount,
                'errors'         => $errors,
                'metrics'        => $updatedMatrix['metrics']
            ];
        } catch (\Throwable $e) {
            $this->db->transRollback();
            log_message('error', 'autoReconcileMissingOpenings exception: ' . $e->getMessage());
            return [
                'success'        => false,
                'message'        => 'Auto-reconciliation encountered an unexpected error: ' . $e->getMessage(),
                'repaired_count' => 0,
                'skipped_count'  => $skippedCount,
                'errors'         => [$e->getMessage()]
            ];
        }
    }
}
