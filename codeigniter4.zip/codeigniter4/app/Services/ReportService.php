<?php

namespace App\Services;

use Config\Database;

class ReportService
{
    protected $db;

    public function __construct()
    {
        $this->db = Database::connect();
    }

    /**
     * Sanitize cell value against CSV Formula Injection / DDE Exploitation
     */
    public static function sanitizeCell($value): string
    {
        if ($value === null) {
            return '';
        }
        $str = (string)$value;
        if ($str === '') {
            return '';
        }

        // Check if value starts with formula triggers: =, +, -, @, tab, or carriage return
        $firstChar = $str[0];
        if (in_array($firstChar, ['=', '+', '-', '@', "\t", "\r", '%'], true)) {
            return "'" . $str;
        }

        return $str;
    }

    /**
     * Stream secure sanitized CSV download
     */
    public function generateCsv(array $headers, array $data, string $filename = 'export.csv'): void
    {
        // Prevent Header Injection / CRLF attacks in filename
        $cleanFilename = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', $filename);
        if (empty($cleanFilename)) {
            $cleanFilename = 'export_' . date('Y-m-d_H-i-s') . '.csv';
        }

        // Clean any output buffer
        if (ob_get_level() > 0) {
            ob_clean();
        }

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $cleanFilename . '"');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: max-age=0, no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');

        $output = fopen('php://output', 'w');

        // UTF-8 BOM for Microsoft Excel compatibility
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

        // Sanitize headers
        $sanitizedHeaders = array_map([self::class, 'sanitizeCell'], $headers);
        fputcsv($output, $sanitizedHeaders);

        // Sanitize and write rows
        foreach ($data as $row) {
            $sanitizedRow = array_map([self::class, 'sanitizeCell'], array_values((array)$row));
            fputcsv($output, $sanitizedRow);
        }

        fclose($output);
        exit;
    }

    /**
     * Shared staff scoping helper reusing EmployeeModel::applyScopedStaffFilter.
     * Ensures tenant isolation, branch/department filtering, manager/team leader hierarchy,
     * and e.deleted_at IS NULL.
     */
    public static function applyStaffScope($builder, string $companyId, array $filters = [], string $empAlias = 'e')
    {
        if (trim($companyId) === '') {
            throw new \InvalidArgumentException('ReportService::applyStaffScope: $companyId is required and cannot be empty.');
        }

        $branch = (!empty($filters['branch_id']) && $filters['branch_id'] !== 'all') ? $filters['branch_id'] : null;
        $dept = (!empty($filters['department_id']) && $filters['department_id'] !== 'all') ? $filters['department_id'] : null;

        $session = function_exists('session') ? session() : null;
        $currentUser = $session ? $session->get('user') : null;
        $role = $currentUser['role_code'] ?? $currentUser['role_name'] ?? ($session ? ($session->get('role_code') ?? $session->get('role')) : null);
        $permService = new \App\Services\PermissionService();
        $isSoftwareAdmin = $permService->isSoftwareAppAdmin((string)$role);

        $empModel = new \App\Models\EmployeeModel();
        $empModel->applyScopedStaffFilter(
            $builder,
            $companyId,
            $isSoftwareAdmin,
            $currentUser,
            $empAlias,
            $branch,
            $dept
        );

        $builder->where("{$empAlias}.deleted_at IS NULL");

        if (!empty($filters['employee_id']) && $filters['employee_id'] !== 'all') {
            $builder->where("{$empAlias}.id", $filters['employee_id']);
        }

        if (!empty($filters['designation_id']) && $filters['designation_id'] !== 'all') {
            $builder->where("{$empAlias}.designation_id", $filters['designation_id']);
        }

        if (!empty($filters['shift_id']) && $filters['shift_id'] !== 'all') {
            $builder->where("{$empAlias}.shift_id", $filters['shift_id']);
        }

        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $builder->where("{$empAlias}.status", $filters['status']);
        }

        if (!empty($filters['search'])) {
            $term = trim((string)$filters['search']);
            $builder->groupStart()
                ->like("{$empAlias}.first_name", $term)
                ->orLike("{$empAlias}.last_name", $term)
                ->orLike("{$empAlias}.employee_code", $term)
                ->groupEnd();
        }

        return $builder;
    }

    /**
     * Query data for standard enterprise report categories with strict tenant isolation
     */
    public function getReportData(string $type, string $companyId, array $filters = []): array
    {
        if (trim($companyId) === '') {
            throw new \InvalidArgumentException('ReportService: $companyId is required and cannot be empty.');
        }
        $from = $filters['from'] ?? date('Y-m-01');
        $to = $filters['to'] ?? date('Y-m-d');
        $deptId = $filters['department_id'] ?? null;

        $attFields = $this->db->tableExists('attendances') ? $this->db->getFieldNames('attendances') : [];

        // Dynamic detection for worked hours column
        if (in_array('worked_hours', $attFields, true)) {
            $workedHoursCol = 'a.worked_hours';
        } elseif (in_array('working_hours', $attFields, true)) {
            $workedHoursCol = 'a.working_hours as worked_hours';
        } elseif (in_array('work_hours', $attFields, true)) {
            $workedHoursCol = 'a.work_hours as worked_hours';
        } elseif (in_array('total_hours', $attFields, true)) {
            $workedHoursCol = 'a.total_hours as worked_hours';
        } elseif (in_array('actual_worked_hours', $attFields, true)) {
            $workedHoursCol = 'a.actual_worked_hours as worked_hours';
        } else {
            $workedHoursCol = '0.00 as worked_hours';
        }

        // Overtime hours column
        if (in_array('overtime_hours', $attFields, true)) {
            $otHoursCol = 'a.overtime_hours';
            $otWhereCol = 'a.overtime_hours';
        } else {
            $otHoursCol = '0.00 as overtime_hours';
            $otWhereCol = null;
        }

        // Late minutes / is_late
        if (in_array('late_minutes', $attFields, true)) {
            $lateMinCol = 'a.late_minutes';
        } else {
            $lateMinCol = '0 as late_minutes';
        }

        if (in_array('is_late', $attFields, true)) {
            $isLateCol = 'a.is_late';
            $isLateWhere = 'a.is_late';
        } elseif (in_array('late_minutes', $attFields, true)) {
            $isLateCol = '(CASE WHEN a.late_minutes > 0 THEN 1 ELSE 0 END) as is_late';
            $isLateWhere = 'a.late_minutes > 0';
        } else {
            $isLateCol = '0 as is_late';
            $isLateWhere = null;
        }

        // Check in / Check out
        $checkInCol = in_array('check_in', $attFields, true) ? 'a.check_in' : (in_array('in_time', $attFields, true) ? 'a.in_time as check_in' : (in_array('clock_in', $attFields, true) ? 'DATE_FORMAT(a.clock_in, "%H:%i:%s") as check_in' : 'NULL as check_in'));
        $checkOutCol = in_array('check_out', $attFields, true) ? 'a.check_out' : (in_array('out_time', $attFields, true) ? 'a.out_time as check_out' : (in_array('clock_out', $attFields, true) ? 'DATE_FORMAT(a.clock_out, "%H:%i:%s") as check_out' : 'NULL as check_out'));
        $statusCol = in_array('status', $attFields, true) ? 'a.status' : '"Present" as status';
        $hasShiftId = in_array('shift_id', $attFields, true);

        $catalog = AttendanceReportService::getReportCatalog();
        $cleanType = str_starts_with($type, 'att_') ? substr($type, 4) : $type;
        if (isset($catalog[$cleanType]) || isset($catalog[$type])) {
            $attService = new AttendanceReportService();
            $rep = $attService->generateReport($cleanType, $companyId, $filters);
            $cleanRows = [];
            foreach ($rep['rows'] as $row) {
                if (count($rep['headers']) === count($row)) {
                    $cleanRows[] = array_combine($rep['headers'], $row);
                } else {
                    $cleanRows[] = $row;
                }
            }
            return $cleanRows;
        }

        $leaveCatalog = LeaveReportService::getReportCatalog();
        $cleanLeaveType = str_starts_with($type, 'leave_') ? substr($type, 6) : $type;
        if (isset($leaveCatalog[$type]) || isset($leaveCatalog['leave_' . $type]) || isset($leaveCatalog[$cleanLeaveType])) {
            $leaveService = new LeaveReportService();
            $targetType = isset($leaveCatalog[$type]) ? $type : (isset($leaveCatalog['leave_' . $type]) ? 'leave_' . $type : $cleanLeaveType);
            $rep = $leaveService->generateReport($targetType, $companyId, $filters);
            $cleanRows = [];
            foreach ($rep['rows'] as $row) {
                if (count($rep['headers']) === count($row)) {
                    $cleanRows[] = array_combine($rep['headers'], $row);
                } else {
                    $cleanRows[] = $row;
                }
            }
            return $cleanRows;
        }

        $taxCatalog = TaxReportService::getReportCatalog();
        $cleanTaxType = str_starts_with($type, 'tax_') ? substr($type, 4) : $type;
        if (isset($taxCatalog[$type]) || isset($taxCatalog[$cleanTaxType]) || isset($taxCatalog['tax_' . $type])) {
            $taxService = new TaxReportService();
            $targetType = isset($taxCatalog[$type]) ? $type : (isset($taxCatalog[$cleanTaxType]) ? $cleanTaxType : 'tax_' . $type);
            $rep = $taxService->generateReport($targetType, $companyId, $filters);
            $cleanRows = [];
            foreach ($rep['rows'] as $row) {
                if (count($rep['headers']) === count($row)) {
                    $cleanRows[] = array_combine($rep['headers'], $row);
                } else {
                    $cleanRows[] = $row;
                }
            }
            return $cleanRows;
        }

        $loanCatalog = LoanAdvanceReportService::getReportCatalog();
        if (isset($loanCatalog[$type])) {
            $loanService = new LoanAdvanceReportService();
            $rep = $loanService->generateReport($type, $companyId, $filters);
            $cleanRows = [];
            foreach ($rep['rows'] as $row) {
                if (count($rep['headers']) === count($row)) {
                    $cleanRows[] = array_combine($rep['headers'], $row);
                } else {
                    $cleanRows[] = $row;
                }
            }
            return $cleanRows;
        }

        $otBonusCatalog = OvertimeBonusReportService::getReportCatalog();
        if (isset($otBonusCatalog[$type])) {
            $otService = new OvertimeBonusReportService();
            $rep = $otService->generateReport($type, $companyId, $filters);
            $cleanRows = [];
            foreach ($rep['rows'] as $row) {
                if (count($rep['headers']) === count($row)) {
                    $cleanRows[] = array_combine($rep['headers'], $row);
                } else {
                    $cleanRows[] = $row;
                }
            }
            return $cleanRows;
        }

        $payrollCatalog = PayrollReportService::getReportCatalog();
        if (isset($payrollCatalog[$type])) {
            $payService = new PayrollReportService();
            $rep = $payService->generateReport($type, $companyId, $filters);
            $cleanRows = [];
            foreach ($rep['rows'] as $row) {
                if (count($rep['headers']) === count($row)) {
                    $cleanRows[] = array_combine($rep['headers'], $row);
                } else {
                    $cleanRows[] = $row;
                }
            }
            return $cleanRows;
        }

        switch ($type) {
            case 'attendance':
                $baseTable = 'attendances';
                if (!$this->db->tableExists('attendances') && $this->db->tableExists('attendance_logs')) {
                    $baseTable = 'attendance_logs';
                }

                $builder = $this->db->table($baseTable . ' a')
                    ->select('a.date, e.employee_code, e.first_name, e.last_name, d.name as department, ' . ($hasShiftId ? 's.name' : 'NULL') . ' as shift, ' . $checkInCol . ', ' . $checkOutCol . ', ' . $workedHoursCol . ', ' . $otHoursCol . ', ' . $statusCol . ', ' . $isLateCol)
                    ->join('employees e', 'e.id = a.employee_id', 'left')
                    ->join('departments d', 'd.id = e.department_id', 'left');

                if ($hasShiftId) {
                    $builder->join('shifts s', 's.id = a.shift_id', 'left');
                }

                // Join approved early closure credits if table exists
                if ($this->db->tableExists('attendance_closure_credits')) {
                    $builder->select('
                        acc.actual_check_in as credit_in,
                        acc.actual_check_out as credit_out,
                        acc.actual_worked_hours as credit_worked,
                        acc.credited_hours as credit_hours,
                        acc.final_duty_hours as credit_final_duty,
                        acc.status as credit_status
                    ');
                    $builder->join('attendance_closure_credits acc', 'acc.employee_id = a.employee_id AND acc.attendance_date = a.date AND acc.status = "Approved"', 'left');
                }

                // Cross-reference attendance_logs if querying attendances
                if ($baseTable === 'attendances' && $this->db->tableExists('attendance_logs')) {
                    $logCols = $this->db->getFieldNames('attendance_logs');
                    $selLogs = ['al.check_in as log_in', 'al.check_out as log_out'];
                    if (in_array('actual_worked_hours', $logCols, true)) $selLogs[] = 'al.actual_worked_hours as log_actual_worked';
                    if (in_array('worked_hours', $logCols, true)) $selLogs[] = 'al.worked_hours as log_worked_hours';
                    if (in_array('working_hours', $logCols, true)) $selLogs[] = 'al.working_hours as log_working_hours';
                    if (in_array('regular_hours', $logCols, true)) $selLogs[] = 'al.regular_hours as log_regular_hours';
                    if (in_array('closure_credit_hours', $logCols, true)) $selLogs[] = 'al.closure_credit_hours as log_closure_credit';
                    $builder->select(implode(', ', $selLogs));
                    $builder->join('attendance_logs al', '(al.employee_id = a.employee_id OR al.employee_id = e.id) AND al.date = a.date', 'left');
                }

                $builder->where('a.date >=', $from)
                    ->where('a.date <=', $to);
                self::applyStaffScope($builder, $companyId, $filters, 'e');
                
                $rawRows = $builder->orderBy('a.date', 'DESC')->orderBy('e.first_name', 'ASC')->get()->getResultArray();

                $cleanRows = [];
                foreach ($rawRows as $row) {
                    $in = !empty($row['credit_in']) ? $row['credit_in'] :
                          (!empty($row['check_in']) ? $row['check_in'] :
                          (!empty($row['log_in']) ? $row['log_in'] : ''));
                    if ($in && strlen($in) === 5) {
                        $in .= ':00';
                    }

                    $out = !empty($row['credit_out']) ? $row['credit_out'] :
                           (!empty($row['check_out']) ? $row['check_out'] :
                           (!empty($row['log_out']) ? $row['log_out'] : ''));
                    if ($out && strlen($out) === 5) {
                        $out .= ':00';
                    }

                    // Early closure credit
                    $credHours = 0.00;
                    if (isset($row['credit_hours']) && (float)$row['credit_hours'] > 0) {
                        $credHours = (float)$row['credit_hours'];
                    } elseif (isset($row['log_closure_credit']) && (float)$row['log_closure_credit'] > 0) {
                        $credHours = (float)$row['log_closure_credit'];
                    } elseif (isset($row['closure_credit_hours']) && (float)$row['closure_credit_hours'] > 0) {
                        $credHours = (float)$row['closure_credit_hours'];
                    }

                    // Actual worked hours
                    $worked = 0.00;
                    if (isset($row['credit_worked']) && (float)$row['credit_worked'] > 0) {
                        $worked = (float)$row['credit_worked'];
                    } elseif (isset($row['log_actual_worked']) && (float)$row['log_actual_worked'] > 0) {
                        $worked = (float)$row['log_actual_worked'];
                    } elseif (isset($row['actual_worked_hours']) && (float)$row['actual_worked_hours'] > 0) {
                        $worked = (float)$row['actual_worked_hours'];
                    } elseif (isset($row['worked_hours']) && (float)$row['worked_hours'] > 0) {
                        $worked = (float)$row['worked_hours'];
                    } elseif (isset($row['log_worked_hours']) && (float)$row['log_worked_hours'] > 0) {
                        $worked = (float)$row['log_worked_hours'];
                    } elseif (isset($row['working_hours']) && (float)$row['working_hours'] > 0 && $credHours == 0) {
                        $worked = (float)$row['working_hours'];
                    } elseif (isset($row['log_working_hours']) && (float)$row['log_working_hours'] > 0 && $credHours == 0) {
                        $worked = (float)$row['log_working_hours'];
                    } elseif (!empty($in) && !empty($out)) {
                        $tIn = strtotime($in);
                        $tOut = strtotime($out);
                        if ($tIn && $tOut && $tOut > $tIn) {
                            $worked = round(($tOut - $tIn) / 3600, 2);
                        }
                    }

                    // Final duty hours
                    $duty = 0.00;
                    if (isset($row['credit_final_duty']) && (float)$row['credit_final_duty'] > 0) {
                        $duty = (float)$row['credit_final_duty'];
                    } elseif ($credHours > 0) {
                        $duty = round($worked + $credHours, 2);
                    } elseif (isset($row['log_regular_hours']) && (float)$row['log_regular_hours'] > 0) {
                        $duty = (float)$row['log_regular_hours'];
                    } elseif ($worked > 0) {
                        $duty = $worked;
                    }

                    $cleanRows[] = [
                        'date'                 => $row['date'],
                        'employee_code'        => $row['employee_code'],
                        'first_name'           => $row['first_name'],
                        'last_name'            => $row['last_name'],
                        'department'           => $row['department'],
                        'shift'                => $row['shift'],
                        'check_in'             => $in,
                        'check_out'            => $out,
                        'worked_hours'         => number_format($worked, 2, '.', ''),
                        'early_closure_credit' => number_format($credHours, 2, '.', ''),
                        'final_duty_hours'     => number_format($duty, 2, '.', ''),
                        'overtime_hours'       => number_format((float)($row['overtime_hours'] ?? 0), 2, '.', ''),
                        'status'               => $row['status'] ?: 'Present',
                        'is_late'              => (int)($row['is_late'] ?? 0),
                    ];
                }
                return $cleanRows;

            case 'late':
                $builder = $this->db->table($baseTable . ' a')
                    ->select('a.date, e.employee_code, CONCAT(e.first_name, " ", e.last_name) as employee_name, d.name as department, ' . ($hasShiftId ? 's.name' : 'NULL') . ' as shift, ' . $checkInCol . ', ' . $lateMinCol . ', ' . $isLateCol)
                    ->join('employees e', 'e.id = a.employee_id', 'left')
                    ->join('departments d', 'd.id = e.department_id', 'left');
                if ($hasShiftId) {
                    $builder->join('shifts s', 's.id = a.shift_id', 'left');
                }
                $builder->where('a.date >=', $from)
                    ->where('a.date <=', $to);
                if ($isLateWhere) {
                    if (strpos($isLateWhere, '>') !== false) {
                        $builder->where('a.late_minutes >', 0);
                    } else {
                        $builder->where('a.is_late', 1);
                    }
                }
                self::applyStaffScope($builder, $companyId, $filters, 'e');
                return $builder->orderBy('a.date', 'DESC')->get()->getResultArray();

            case 'overtime':
                $builder = $this->db->table($baseTable . ' a')
                    ->select('a.date, e.employee_code, CONCAT(e.first_name, " ", e.last_name) as employee_name, d.name as department, ' . $workedHoursCol . ', ' . $otHoursCol)
                    ->join('employees e', 'e.id = a.employee_id', 'left')
                    ->join('departments d', 'd.id = e.department_id', 'left')
                    ->where('a.date >=', $from)
                    ->where('a.date <=', $to);
                if ($otWhereCol) {
                    $builder->where($otWhereCol . ' >', 0);
                }
                self::applyStaffScope($builder, $companyId, $filters, 'e');
                return $builder->orderBy('a.date', 'DESC')->get()->getResultArray();

            case 'leave':
                $builder = $this->db->table('leaves l')
                    ->select('l.id, e.employee_code, CONCAT(e.first_name, " ", e.last_name) as employee_name, lt.name as leave_type, l.start_date, l.end_date, l.total_days, l.status, l.reason')
                    ->join('employees e', 'e.id = l.employee_id', 'left')
                    ->join('leave_types lt', 'lt.id = l.leave_type_id', 'left')
                    ->where('l.start_date <=', $to)
                    ->where('l.end_date >=', $from);
                self::applyStaffScope($builder, $companyId, $filters, 'e');
                return $builder->orderBy('l.start_date', 'DESC')->get()->getResultArray();

            case 'payroll':
            case 'salary_register':
                $hasItems = $this->db->tableExists('payroll_items');
                $hasPayrolls = $this->db->tableExists('payrolls');
                $piCols = $hasItems ? $this->db->getFieldNames('payroll_items') : [];
                $pCols = $hasPayrolls ? $this->db->getFieldNames('payrolls') : [];

                if ($hasItems) {
                    $hasAllowances = in_array('allowances', $piCols, true);
                    $hasHouseRent = in_array('house_rent', $piCols, true);
                    $hasMedical = in_array('medical', $piCols, true);
                    $hasConveyance = in_array('conveyance', $piCols, true);
                    $hasOt = in_array('overtime_amount', $piCols, true);
                    $hasBonus = in_array('bonus_amount', $piCols, true);
                    $hasTotalDed = in_array('total_deductions', $piCols, true);
                    $hasDed = in_array('deductions', $piCols, true);
                    $hasTax = in_array('tax_deduction', $piCols, true);
                    $hasPf = in_array('pf_deduction', $piCols, true);
                    $hasNet = in_array('net_salary', $piCols, true);
                    $hasBasic = in_array('basic_salary', $piCols, true);
                    $hasPaymentStatus = in_array('payment_status', $piCols, true);

                    $hasPayrollMonth = in_array('payroll_month', $pCols, true);
                    $hasMonth = in_array('month', $pCols, true);
                    $hasYear = in_array('year', $pCols, true);
                    $hasStatus = in_array('status', $pCols, true);

                    $hasOtherAllowances = in_array('other_allowances', $piCols, true);
                    if ($hasAllowances && $hasOtherAllowances) {
                        $allowanceSelect = '(COALESCE(pi.allowances, 0) + COALESCE(pi.other_allowances, 0)) as allowances';
                    } elseif ($hasAllowances) {
                        $allowanceSelect = 'pi.allowances as allowances';
                    } elseif ($hasOtherAllowances) {
                        $allowanceSelect = 'pi.other_allowances as allowances';
                    } elseif ($hasHouseRent || $hasMedical || $hasConveyance) {
                        $allowanceParts = [];
                        if ($hasHouseRent) $allowanceParts[] = 'COALESCE(pi.house_rent, 0)';
                        if ($hasMedical) $allowanceParts[] = 'COALESCE(pi.medical, 0)';
                        if ($hasConveyance) $allowanceParts[] = 'COALESCE(pi.conveyance, 0)';
                        $allowanceSelect = '(' . implode(' + ', $allowanceParts) . ') as allowances';
                    } else {
                        $allowanceSelect = '0.00 as allowances';
                    }

                    $basicSelect = $hasBasic ? 'pi.basic_salary as basic_salary' : '0.00 as basic_salary';
                    $otSelect = $hasOt ? 'pi.overtime_amount as overtime_amount' : '0.00 as overtime_amount';
                    $bonusSelect = $hasBonus ? 'pi.bonus_amount as bonus_amount' : (in_array('bonus', $piCols, true) ? 'pi.bonus as bonus_amount' : '0.00 as bonus_amount');
                    $dedSelect = $hasTotalDed ? 'pi.total_deductions as deductions' : ($hasDed ? 'pi.deductions as deductions' : '0.00 as deductions');
                    $taxSelect = $hasTax ? 'pi.tax_deduction as tax_deduction' : '0.00 as tax_deduction';
                    $pfSelect = $hasPf ? 'pi.pf_deduction as pf_deduction' : (in_array('provident_fund', $piCols, true) ? 'pi.provident_fund as pf_deduction' : '0.00 as pf_deduction');
                    $netSelect = $hasNet ? 'pi.net_salary as net_salary' : '0.00 as net_salary';

                    if ($hasStatus && $hasPaymentStatus) {
                        $statusSelect = 'COALESCE(p.status, pi.payment_status) as status';
                    } elseif ($hasStatus) {
                        $statusSelect = 'p.status as status';
                    } elseif ($hasPaymentStatus) {
                        $statusSelect = 'pi.payment_status as status';
                    } else {
                        $statusSelect = '"processed" as status';
                    }

                    if ($hasPayrollMonth && $hasMonth && $hasYear) {
                        $monthSelect = 'COALESCE(p.month, CAST(SUBSTRING(p.payroll_month, 6, 2) AS UNSIGNED)) as month';
                        $yearSelect = 'COALESCE(p.year, CAST(SUBSTRING(p.payroll_month, 1, 4) AS UNSIGNED)) as year';
                        $pmSelect = 'COALESCE(p.payroll_month, CONCAT(p.year, "-", LPAD(p.month, 2, "0"))) as payroll_month';
                    } elseif ($hasPayrollMonth) {
                        $monthSelect = 'CAST(SUBSTRING(p.payroll_month, 6, 2) AS UNSIGNED) as month';
                        $yearSelect = 'CAST(SUBSTRING(p.payroll_month, 1, 4) AS UNSIGNED) as year';
                        $pmSelect = 'p.payroll_month';
                    } elseif ($hasMonth && $hasYear) {
                        $monthSelect = 'p.month';
                        $yearSelect = 'p.year';
                        $pmSelect = 'CONCAT(p.year, "-", LPAD(p.month, 2, "0")) as payroll_month';
                    } else {
                        $monthSelect = '1 as month';
                        $yearSelect = 'YEAR(CURRENT_DATE) as year';
                        $pmSelect = '"" as payroll_month';
                    }

                    $builder = $this->db->table('payroll_items pi')
                        ->select("pi.id, e.employee_code, CONCAT(e.first_name, ' ', e.last_name) as employee_name, d.name as department, {$pmSelect}, {$monthSelect}, {$yearSelect}, {$basicSelect}, {$allowanceSelect}, {$otSelect}, {$bonusSelect}, {$dedSelect}, {$taxSelect}, {$pfSelect}, {$netSelect}, {$statusSelect}")
                        ->join('payrolls p', 'p.id = pi.payroll_id', 'inner')
                        ->join('employees e', 'e.id = pi.employee_id', 'left')
                        ->join('departments d', 'd.id = e.department_id', 'left');

                    if ($companyId) {
                        $builder->where('p.company_id', $companyId);
                    }
                    self::applyStaffScope($builder, $companyId, $filters, 'e');

                    if ($hasPayrollMonth) {
                        $builder->orderBy('p.payroll_month', 'DESC');
                    } elseif ($hasYear && $hasMonth) {
                        $builder->orderBy('p.year', 'DESC')->orderBy('p.month', 'DESC');
                    }
                    $builder->orderBy('e.employee_code', 'ASC');

                    $itemsData = $builder->get()->getResultArray();
                    if (!empty($itemsData)) {
                        return $itemsData;
                    }
                }

                // Fallback to legacy payrolls table if no records returned from payroll_items
                if ($hasPayrolls && in_array('employee_id', $pCols, true)) {
                    $hasAllowances = in_array('allowances', $pCols, true);
                    $hasHouseRent = in_array('house_rent', $pCols, true);
                    $hasMedical = in_array('medical_allowance', $pCols, true);
                    $hasConveyance = in_array('conveyance_allowance', $pCols, true);
                    $hasOtherAllowance = in_array('other_allowance', $pCols, true);
                    $hasOtherAllowances = in_array('other_allowances', $pCols, true);
                    $hasOt = in_array('overtime_amount', $pCols, true);
                    $hasBonusAmount = in_array('bonus_amount', $pCols, true);
                    $hasBonus = in_array('bonus', $pCols, true);
                    $hasTotalDed = in_array('total_deductions', $pCols, true);
                    $hasDed = in_array('deductions', $pCols, true);
                    $hasTax = in_array('tax_deduction', $pCols, true);
                    $hasPfDed = in_array('pf_deduction', $pCols, true);
                    $hasProvidentFund = in_array('provident_fund', $pCols, true);
                    $hasNet = in_array('net_salary', $pCols, true);
                    $hasBasic = in_array('basic_salary', $pCols, true);
                    $hasStatus = in_array('status', $pCols, true);
                    $hasPayrollMonth = in_array('payroll_month', $pCols, true);
                    $hasMonth = in_array('month', $pCols, true);
                    $hasYear = in_array('year', $pCols, true);

                    if ($hasAllowances) {
                        $allowanceSelect = 'p.allowances as allowances';
                    } elseif ($hasHouseRent || $hasMedical || $hasConveyance || $hasOtherAllowance || $hasOtherAllowances) {
                        $allowanceParts = [];
                        if ($hasHouseRent) $allowanceParts[] = 'COALESCE(p.house_rent, 0)';
                        if ($hasMedical) $allowanceParts[] = 'COALESCE(p.medical_allowance, 0)';
                        if ($hasConveyance) $allowanceParts[] = 'COALESCE(p.conveyance_allowance, 0)';
                        if ($hasOtherAllowance) $allowanceParts[] = 'COALESCE(p.other_allowance, 0)';
                        if ($hasOtherAllowances) $allowanceParts[] = 'COALESCE(p.other_allowances, 0)';
                        $allowanceSelect = '(' . implode(' + ', $allowanceParts) . ') as allowances';
                    } else {
                        $allowanceSelect = '0.00 as allowances';
                    }

                    $basicSelect = $hasBasic ? 'p.basic_salary as basic_salary' : '0.00 as basic_salary';
                    $otSelect = $hasOt ? 'p.overtime_amount' : '0.00 as overtime_amount';
                    $bonusSelect = $hasBonusAmount ? 'p.bonus_amount as bonus_amount' : ($hasBonus ? 'p.bonus as bonus_amount' : '0.00 as bonus_amount');
                    $dedSelect = $hasTotalDed ? 'p.total_deductions as deductions' : ($hasDed ? 'p.deductions as deductions' : '0.00 as deductions');
                    $taxSelect = $hasTax ? 'p.tax_deduction as tax_deduction' : '0.00 as tax_deduction';
                    $pfSelect = $hasPfDed ? 'p.pf_deduction as pf_deduction' : ($hasProvidentFund ? 'p.provident_fund as pf_deduction' : '0.00 as pf_deduction');
                    $netSelect = $hasNet ? 'p.net_salary as net_salary' : '0.00 as net_salary';
                    $statusSelect = $hasStatus ? 'p.status as status' : '"processed" as status';

                    if ($hasPayrollMonth && $hasMonth && $hasYear) {
                        $monthSelect = 'COALESCE(p.month, CAST(SUBSTRING(p.payroll_month, 6, 2) AS UNSIGNED)) as month';
                        $yearSelect = 'COALESCE(p.year, CAST(SUBSTRING(p.payroll_month, 1, 4) AS UNSIGNED)) as year';
                        $pmSelect = 'COALESCE(p.payroll_month, CONCAT(p.year, "-", LPAD(p.month, 2, "0"))) as payroll_month';
                    } elseif ($hasPayrollMonth) {
                        $monthSelect = 'CAST(SUBSTRING(p.payroll_month, 6, 2) AS UNSIGNED) as month';
                        $yearSelect = 'CAST(SUBSTRING(p.payroll_month, 1, 4) AS UNSIGNED) as year';
                        $pmSelect = 'p.payroll_month';
                    } elseif ($hasMonth && $hasYear) {
                        $monthSelect = 'p.month';
                        $yearSelect = 'p.year';
                        $pmSelect = 'CONCAT(p.year, "-", LPAD(p.month, 2, "0")) as payroll_month';
                    } else {
                        $monthSelect = '1 as month';
                        $yearSelect = 'YEAR(CURRENT_DATE) as year';
                        $pmSelect = '"" as payroll_month';
                    }

                    $builder = $this->db->table('payrolls p')
                        ->select("p.id, e.employee_code, CONCAT(e.first_name, ' ', e.last_name) as employee_name, d.name as department, {$pmSelect}, {$monthSelect}, {$yearSelect}, {$basicSelect}, {$allowanceSelect}, {$otSelect}, {$bonusSelect}, {$dedSelect}, {$taxSelect}, {$pfSelect}, {$netSelect}, {$statusSelect}")
                        ->join('employees e', 'e.id = p.employee_id', 'left')
                        ->join('departments d', 'd.id = e.department_id', 'left')
                        ->where('p.employee_id IS NOT NULL');

                    if ($companyId) {
                        $builder->where('p.company_id', $companyId);
                    }
                    self::applyStaffScope($builder, $companyId, $filters, 'e');

                    if ($hasPayrollMonth) {
                        $builder->orderBy('p.payroll_month', 'DESC');
                    } elseif ($hasYear && $hasMonth) {
                        $builder->orderBy('p.year', 'DESC')->orderBy('p.month', 'DESC');
                    }
                    $builder->orderBy('e.employee_code', 'ASC');

                    return $builder->get()->getResultArray();
                }

                return [];

            case 'bank_sheet':
                $hasItems = $this->db->tableExists('payroll_items');
                $hasPayrolls = $this->db->tableExists('payrolls');
                $hasBank = $this->db->tableExists('employee_bank_accounts');
                $ebaFields = $hasBank ? $this->db->getFieldNames('employee_bank_accounts') : [];
                $eCols = $this->db->tableExists('employees') ? $this->db->getFieldNames('employees') : [];
                $pCols = $hasPayrolls ? $this->db->getFieldNames('payrolls') : [];

                $bankNameCol = in_array('bank_name', $ebaFields, true) ? 'eba.bank_name' : (in_array('bank', $ebaFields, true) ? 'eba.bank as bank_name' : (in_array('bank_name', $eCols, true) ? 'e.bank_name' : 'NULL as bank_name'));
                $accNumCol = in_array('account_number', $ebaFields, true) ? 'eba.account_number' : (in_array('account_number', $eCols, true) ? 'e.account_number' : 'NULL as account_number');
                $routingCol = in_array('routing_number', $ebaFields, true) ? 'eba.routing_number' : (in_array('routing_number', $eCols, true) ? 'e.routing_number' : 'NULL as routing_number');
                $isPrimaryClause = in_array('is_primary', $ebaFields, true) ? ' AND eba.is_primary = 1' : '';

                if ($hasItems) {
                    $builder = $this->db->table('payroll_items pi')
                        ->select("pi.id, e.employee_code, CONCAT(e.first_name, ' ', e.last_name) as employee_name, {$bankNameCol}, {$accNumCol}, {$routingCol}, pi.net_salary, COALESCE(p.status, pi.payment_status) as status")
                        ->join('payrolls p', 'p.id = pi.payroll_id', 'inner')
                        ->join('employees e', 'e.id = pi.employee_id', 'left');

                    if ($hasBank) {
                        $builder->join('employee_bank_accounts eba', 'eba.employee_id = e.id' . $isPrimaryClause, 'left');
                    }

                    if (in_array('status', $pCols, true)) {
                        $builder->where('p.status !=', 'cancelled');
                    }
                    if ($companyId) {
                        $builder->where('p.company_id', $companyId);
                    }
                    self::applyStaffScope($builder, $companyId, $filters, 'e');

                    if (in_array('payroll_month', $pCols, true)) {
                        $builder->orderBy('p.payroll_month', 'DESC');
                    }
                    $builder->orderBy('e.employee_code', 'ASC');

                    $bankRows = $builder->get()->getResultArray();
                    if (!empty($bankRows)) {
                        return $bankRows;
                    }
                }

                // Fallback to legacy payrolls table
                if ($hasPayrolls && in_array('employee_id', $pCols, true)) {
                    $netCol = in_array('net_salary', $pCols, true) ? 'p.net_salary' : '0.00 as net_salary';
                    $statusCol = in_array('status', $pCols, true) ? 'p.status' : '"processed" as status';

                    $builder = $this->db->table('payrolls p')
                        ->select("p.id, e.employee_code, CONCAT(e.first_name, ' ', e.last_name) as employee_name, {$bankNameCol}, {$accNumCol}, {$routingCol}, {$netCol}, {$statusCol}")
                        ->join('employees e', 'e.id = p.employee_id', 'left');

                    if ($hasBank) {
                        $builder->join('employee_bank_accounts eba', 'eba.employee_id = e.id' . $isPrimaryClause, 'left');
                    }

                    $builder->where('p.employee_id IS NOT NULL');
                    if (in_array('status', $pCols, true)) {
                        $builder->where('p.status !=', 'cancelled');
                    }
                    if ($companyId) {
                        $builder->where('p.company_id', $companyId);
                    }
                    self::applyStaffScope($builder, $companyId, $filters, 'e');

                    return $builder->get()->getResultArray();
                }

                return [];

            case 'employee':
                $builder = $this->db->table('employees e')
                    ->select('e.employee_code, e.first_name, e.last_name, e.email, e.phone, d.name as department, des.name as designation, et.name as employment_type, e.joining_date, e.status')
                    ->join('departments d', 'd.id = e.department_id', 'left')
                    ->join('designations des', 'des.id = e.designation_id', 'left')
                    ->join('employment_types et', 'et.id = e.employment_type_id', 'left');
                self::applyStaffScope($builder, $companyId, $filters, 'e');
                return $builder->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

            case 'loan':
                $loanTable = $this->db->tableExists('employee_loans') ? 'employee_loans' : ($this->db->tableExists('loans') ? 'loans' : null);
                if (!$loanTable) {
                    return [];
                }
                $builder = $this->db->table($loanTable . ' l')
                    ->select('l.id, e.employee_code, CONCAT(e.first_name, " ", COALESCE(e.last_name, "")) as employee_name, d.name as department, l.loan_type, COALESCE(l.principal_amount, l.amount) as amount, COALESCE(l.monthly_installment, l.monthly_emi) as monthly_emi, COALESCE(l.total_installments, l.repayment_months) as total_installments, l.total_paid, l.total_due, l.status, l.created_at')
                    ->join('employees e', 'e.id = l.employee_id', 'left')
                    ->join('departments d', 'd.id = e.department_id', 'left');
                self::applyStaffScope($builder, $companyId, $filters, 'e');
                return $builder->orderBy('l.created_at', 'DESC')->get()->getResultArray();

            case 'tax':
                if (!$this->db->tableExists('payroll_items')) {
                    return [];
                }
                $builder = $this->db->table('payroll_items pi')
                    ->select('pi.id, e.employee_code, CONCAT(e.first_name, " ", COALESCE(e.last_name, "")) as employee_name, d.name as department, p.payroll_month, p.year, p.month, pi.basic_salary, pi.gross_salary, pi.tax_deduction, pi.net_salary, p.status')
                    ->join('payrolls p', 'p.id = pi.payroll_id', 'inner')
                    ->join('employees e', 'e.id = pi.employee_id', 'left')
                    ->join('departments d', 'd.id = e.department_id', 'left')
                    ->where('p.company_id', $companyId)
                    ->where('pi.tax_deduction >', 0);
                self::applyStaffScope($builder, $companyId, $filters, 'e');
                return $builder->orderBy('p.payroll_month', 'DESC')->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

            case 'pf':
                if ($this->db->tableExists('provident_fund_ledgers')) {
                    $builder = $this->db->table('provident_fund_ledgers pfl')
                        ->select('pfl.id, pfl.transaction_date, pfl.payroll_month, pfl.payroll_year, e.employee_code, CONCAT(e.first_name, " ", COALESCE(e.last_name, "")) as employee_name, d.name as department, pfl.transaction_type, pfl.pf_base_salary, pfl.employee_contribution, pfl.employer_contribution, pfl.total_contribution, pfl.running_balance, pfl.status')
                        ->join('employees e', 'e.id = pfl.employee_id', 'left')
                        ->join('departments d', 'd.id = e.department_id', 'left')
                        ->where('pfl.company_id', $companyId);
                    self::applyStaffScope($builder, $companyId, $filters, 'e');
                    return $builder->orderBy('pfl.transaction_date', 'DESC')->get()->getResultArray();
                } elseif ($this->db->tableExists('payroll_items')) {
                    $builder = $this->db->table('payroll_items pi')
                        ->select('pi.id, e.employee_code, CONCAT(e.first_name, " ", COALESCE(e.last_name, "")) as employee_name, d.name as department, p.payroll_month, pi.basic_salary, pi.pf_deduction, pi.employer_pf_contribution, pi.net_salary')
                        ->join('payrolls p', 'p.id = pi.payroll_id', 'inner')
                        ->join('employees e', 'e.id = pi.employee_id', 'left')
                        ->join('departments d', 'd.id = e.department_id', 'left')
                        ->where('p.company_id', $companyId)
                        ->where('pi.pf_deduction >', 0);
                    self::applyStaffScope($builder, $companyId, $filters, 'e');
                    return $builder->orderBy('p.payroll_month', 'DESC')->get()->getResultArray();
                }
                return [];

            case 'export_audit':
                if (!$this->db->tableExists('report_export_logs')) {
                    return [];
                }
                $builder = $this->db->table('report_export_logs rel')
                    ->select('rel.id, rel.created_at, rel.report_type, rel.format, rel.row_count, rel.role, rel.ip, rel.user_agent, rel.filters_json, u.username')
                    ->join('users u', 'u.id = rel.user_id', 'left')
                    ->where('rel.company_id', $companyId)
                    ->where('rel.created_at >=', $from . ' 00:00:00')
                    ->where('rel.created_at <=', $to . ' 23:59:59');
                return $builder->orderBy('rel.created_at', 'DESC')->get()->getResultArray();

            case 'audit':
                $builder = $this->db->table('audit_logs al')
                    ->select('al.id, al.created_at, al.username, al.module, al.action, al.record_id, al.ip_address, al.details')
                    ->where('al.created_at >=', $from . ' 00:00:00')
                    ->where('al.created_at <=', $to . ' 23:59:59');
                if ($companyId) $builder->where('al.company_id', $companyId);
                return $builder->orderBy('al.created_at', 'DESC')->get()->getResultArray();

            default:
                return [];
        }
    }

    /**
     * Unified Catalog of all Enterprise Reports across all functional domains
     */
    public static function getAllReportCatalogs(): array
    {
        return array_merge(
            AttendanceReportService::getReportCatalog(),
            LeaveReportService::getReportCatalog(),
            TaxReportService::getReportCatalog(),
            LoanAdvanceReportService::getReportCatalog(),
            OvertimeBonusReportService::getReportCatalog(),
            PayrollReportService::getReportCatalog()
        );
    }
}
