<?php

namespace App\Services;

use Config\Database;
use App\Services\LoanAdvanceService;
use App\Services\Concerns\JoinsActiveSalary;

/**
 * Class LoanAdvanceReportService
 *
 * Enterprise Multi-Tenant Loan & Salary Advance Reporting Engine.
 * Implements all 11 architectural Loan & Advance reports:
 * 1. advance_register
 * 2. advance_outstanding
 * 3. advance_recovery
 * 4. loan_register
 * 5. loan_installment_schedule
 * 6. loan_recovery
 * 7. loan_outstanding_balance
 * 8. overdue_loans
 * 9. loan_closure
 * 10. loan_vs_payroll_reconciliation
 * 11. employee_financial_liability
 *
 * Strict tenant isolation enforced on every query.
 */
class LoanAdvanceReportService
{
    use JoinsActiveSalary;

    protected $db;

    public function __construct()
    {
        $this->db = Database::connect();
    }

    /**
     * Complete Catalog of the 11 Loan & Advance Reports
     */
    public static function getReportCatalog(): array
    {
        return [
            'advance_register' => [
                'number'      => 49,
                'code'        => 'advance_register',
                'title'       => 'Salary Advance Register',
                'description' => 'Comprehensive register of all requested and approved salary advances with repayment terms',
                'category'    => 'Loans & Salary Advances',
            ],
            'advance_outstanding' => [
                'number'      => 50,
                'code'        => 'advance_outstanding',
                'title'       => 'Salary Advance Outstanding Balance',
                'description' => 'Unrecovered salary advances, amounts recovered to date, and remaining balance tracking',
                'category'    => 'Loans & Salary Advances',
            ],
            'advance_recovery' => [
                'number'      => 51,
                'code'        => 'advance_recovery',
                'title'       => 'Salary Advance Recovery Log',
                'description' => 'Chronological audit trail of advance deductions realized through monthly payroll runs',
                'category'    => 'Loans & Salary Advances',
            ],
            'loan_register' => [
                'number'      => 52,
                'code'        => 'loan_register',
                'title'       => 'Employee Loan Master Register',
                'description' => 'Authoritative master log of corporate loans, principal amounts, interest rates, and approval metadata',
                'category'    => 'Loans & Salary Advances',
            ],
            'loan_installment_schedule' => [
                'number'      => 53,
                'code'        => 'loan_installment_schedule',
                'title'       => 'Loan Installment Amortization Schedule',
                'description' => 'Granular month-by-month amortization schedule displaying principal, interest component, and projected EMI',
                'category'    => 'Loans & Salary Advances',
            ],
            'loan_recovery' => [
                'number'      => 54,
                'code'        => 'loan_recovery',
                'title'       => 'Loan Recovery & Repayment History',
                'description' => 'Complete ledger of payroll EMI deductions and manual loan repayments recorded in the system',
                'category'    => 'Loans & Salary Advances',
            ],
            'loan_outstanding_balance' => [
                'number'      => 55,
                'code'        => 'loan_outstanding_balance',
                'title'       => 'Loan Outstanding & Balance Due Report',
                'description' => 'Active loan balances, principal recovered, remaining installments, and exposure analytics',
                'category'    => 'Loans & Salary Advances',
            ],
            'overdue_loans' => [
                'number'      => 56,
                'code'        => 'overdue_loans',
                'title'       => 'Overdue & Defaulted Loans Report',
                'description' => 'Loans with missed or unpaid installments, overdue amounts, and delinquency risk levels',
                'category'    => 'Loans & Salary Advances',
            ],
            'loan_closure' => [
                'number'      => 57,
                'code'        => 'loan_closure',
                'title'       => 'Closed & Fully Repaid Loans Register',
                'description' => 'Historical archive of completed and settled loans with final repayment verification',
                'category'    => 'Loans & Salary Advances',
            ],
            'loan_vs_payroll_reconciliation' => [
                'number'      => 58,
                'code'        => 'loan_vs_payroll_reconciliation',
                'title'       => 'Loan vs Payroll EMI Reconciliation',
                'description' => 'Reconciliation comparing scheduled loan EMIs with actual amounts deducted on payroll items',
                'category'    => 'Loans & Salary Advances',
            ],
            'employee_financial_liability' => [
                'number'      => 59,
                'code'        => 'employee_financial_liability',
                'title'       => 'Employee Total Financial Liability',
                'description' => 'Aggregated financial exposure combining loans and advances, debt-to-income ratio, and monthly burden',
                'category'    => 'Loans & Salary Advances',
            ],
        ];
    }

    /**
     * Dispatch report generation by code
     */
    public function generateReport(string $code, string $companyId, array $filters = []): array
    {
        if (trim($companyId) === '') {
            throw new \InvalidArgumentException('LoanAdvanceReportService: $companyId is required and cannot be empty.');
        }

        $normalized = strtolower(trim($code));

        switch ($normalized) {
            case 'advance_register':
            case '49':
                return $this->advanceRegister($companyId, $filters);

            case 'advance_outstanding':
            case '50':
                return $this->advanceOutstanding($companyId, $filters);

            case 'advance_recovery':
            case '51':
                return $this->advanceRecovery($companyId, $filters);

            case 'loan_register':
            case '52':
                return $this->loanRegister($companyId, $filters);

            case 'loan_installment_schedule':
            case 'loan_amortization':
            case '53':
                return $this->loanInstallmentSchedule($companyId, $filters);

            case 'loan_recovery':
            case '54':
                return $this->loanRecovery($companyId, $filters);

            case 'loan_outstanding_balance':
            case 'loan_outstanding':
            case '55':
                return $this->loanOutstandingBalance($companyId, $filters);

            case 'overdue_loans':
            case '56':
                return $this->overdueLoans($companyId, $filters);

            case 'loan_closure':
            case 'closed_loans':
            case '57':
                return $this->loanClosure($companyId, $filters);

            case 'loan_vs_payroll_reconciliation':
            case 'loan_payroll_reconciliation':
            case '58':
                return $this->loanVsPayrollReconciliation($companyId, $filters);

            case 'employee_financial_liability':
            case 'financial_liability':
            case '59':
                return $this->employeeFinancialLiability($companyId, $filters);

            default:
                throw new \InvalidArgumentException("LoanAdvanceReportService: Unknown report code '{$code}'.");
        }
    }

    /**
     * 1. Salary Advance Register
     */
    public function advanceRegister(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Advance ID', 'Employee Code', 'Employee Name', 'Department',
            'Amount', 'Advance Month', 'Repayment Month/Year', 'Reason', 'Status', 'Approved By', 'Created At'
        ];

        $builder = $this->db->table('salary_advances sa')
            ->select("sa.id, sa.amount, sa.advance_month, sa.repayment_month, sa.repayment_year, sa.reason, sa.status, sa.approved_by, sa.created_at, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name")
            ->join('employees e', 'e.id = sa.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');

        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $builder->where('LOWER(sa.status)', strtolower($filters['status']));
        }
        if (!empty($filters['from']) && !empty($filters['to'])) {
            $builder->where('sa.created_at >=', $filters['from'] . ' 00:00:00')
                    ->where('sa.created_at <=', $filters['to'] . ' 23:59:59');
        }

        $records = $builder->orderBy('sa.created_at', 'DESC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $totalAmount = 0.0;

        foreach ($records as $r) {
            $amount = (float)($r['amount'] ?? 0.0);
            $totalAmount += $amount;

            $repay = ($r['repayment_month'] ?? '') . ' ' . ($r['repayment_year'] ?? '');

            $rows[] = [
                $sl++,
                $r['id'] ?? '-',
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                number_format($amount, 2),
                $r['advance_month'] ?? '-',
                trim($repay) ?: '-',
                $r['reason'] ?? '-',
                ucfirst(strtolower($r['status'] ?? 'pending')),
                $r['approved_by'] ?: 'Pending',
                !empty($r['created_at']) ? date('Y-m-d', strtotime($r['created_at'])) : '-'
            ];
        }

        // Grand Total row
        $count = count($records);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Count: {$count}",
            '-',
            '-',
            number_format($totalAmount, 2),
            '-',
            '-',
            '-',
            '-',
            '-',
            '-'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count' => $count,
                'total_amount' => $totalAmount
            ],
            'exceptions' => []
        ];
    }

    /**
     * 2. Salary Advance Outstanding Balance
     */
    public function advanceOutstanding(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Advance ID', 'Employee Code', 'Employee Name', 'Department',
            'Original Advance', 'Recovered via Payroll', 'Outstanding Balance', 'Target Month', 'Status'
        ];

        $builder = $this->db->table('salary_advances sa')
            ->select("sa.id, sa.amount, sa.advance_month, sa.repayment_month, sa.repayment_year, sa.status, e.id as emp_id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name")
            ->join('employees e', 'e.id = sa.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->where('sa.status', 'Approved');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $advances = $builder->orderBy('sa.created_at', 'DESC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $totalOriginal = 0.0;
        $totalRecovered = 0.0;
        $totalOutstanding = 0.0;

        foreach ($advances as $adv) {
            $orig = (float)($adv['amount'] ?? 0.0);

            // Compute actual recovery from payroll_items for this employee
            $recovQuery = $this->db->table('payroll_items pi')
                ->select('SUM(pi.advance_recovery) as total_recov')
                ->join('payrolls p', 'p.id = pi.payroll_id', 'left')
                ->where('pi.employee_id', $adv['emp_id'])
                ->where('p.company_id', $companyId)
                ->get()
                ->getRowArray();

            $recovered = min($orig, (float)($recovQuery['total_recov'] ?? 0.0));
            $outstanding = max(0.0, round($orig - $recovered, 2));

            $totalOriginal += $orig;
            $totalRecovered += $recovered;
            $totalOutstanding += $outstanding;

            $status = ($outstanding <= 0) ? 'Fully Recovered' : (($recovered > 0) ? 'Partially Recovered' : 'Pending Recovery');

            $rows[] = [
                $sl++,
                $adv['id'] ?? '-',
                $adv['employee_code'] ?? '-',
                trim($adv['employee_name'] ?? 'Unknown'),
                $adv['department_name'] ?? 'General',
                number_format($orig, 2),
                number_format($recovered, 2),
                number_format($outstanding, 2),
                trim(($adv['repayment_month'] ?? '') . ' ' . ($adv['repayment_year'] ?? '')),
                $status
            ];
        }

        // Grand Total row
        $count = count($advances);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Count: {$count}",
            '-',
            '-',
            number_format($totalOriginal, 2),
            number_format($totalRecovered, 2),
            number_format($totalOutstanding, 2),
            '-',
            '-'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count'      => $count,
                'total_original'    => $totalOriginal,
                'total_recovered'   => $totalRecovered,
                'total_outstanding' => $totalOutstanding
            ],
            'exceptions' => []
        ];
    }

    /**
     * 3. Salary Advance Recovery Log
     */
    public function advanceRecovery(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Payroll Month', 'Employee Code', 'Employee Name', 'Department',
            'Advance Recovery Amount', 'Payroll Net Salary', 'Payment Status', 'Payroll Item ID'
        ];

        $builder = $this->db->table('payroll_items pi')
            ->select("pi.id, p.payroll_month, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name, pi.advance_recovery, pi.net_salary, pi.payment_status")
            ->join('payrolls p', 'p.id = pi.payroll_id', 'left')
            ->join('employees e', 'e.id = pi.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->where('pi.advance_recovery >', 0);

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');

        if (!empty($filters['payroll_month'])) {
            $builder->where('p.payroll_month', $filters['payroll_month']);
        } elseif (!empty($filters['from']) && !empty($filters['to'])) {
            $builder->where('p.payroll_month >=', date('Y-m', strtotime($filters['from'])))
                    ->where('p.payroll_month <=', date('Y-m', strtotime($filters['to'])));
        }

        $records = $builder->orderBy('p.payroll_month', 'DESC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $totalRecovery = 0.0;

        foreach ($records as $r) {
            $recov = (float)($r['advance_recovery'] ?? 0.0);
            $totalRecovery += $recov;

            $rows[] = [
                $sl++,
                $r['payroll_month'] ?? '-',
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                number_format($recov, 2),
                number_format((float)($r['net_salary'] ?? 0.0), 2),
                $r['payment_status'] ?? 'Paid',
                $r['id'] ?? '-'
            ];
        }

        // Grand Total row
        $count = count($records);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Count: {$count}",
            '-',
            '-',
            number_format($totalRecovery, 2),
            '-',
            '-',
            '-'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count'   => $count,
                'total_recovery' => $totalRecovery
            ],
            'exceptions' => []
        ];
    }

    /**
     * 4. Employee Loan Master Register
     */
    public function loanRegister(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Loan ID', 'Employee Code', 'Employee Name', 'Department', 'Loan Type',
            'Principal Amount', 'Interest Rate (%)', 'Tenure (Months)', 'Monthly EMI',
            'Total Payable', 'Disbursement Date', 'Status', 'Approved By'
        ];

        $builder = $this->db->table('employee_loans el')
            ->select("el.id, el.loan_type, COALESCE(el.principal_amount, el.amount, el.loan_amount) as principal, el.interest_rate, COALESCE(el.repayment_months, el.total_installments, 12) as tenure, COALESCE(el.monthly_installment, el.monthly_emi) as emi, COALESCE(el.total_amount, el.total_due) as total_payable, COALESCE(el.disbursement_date, el.disbursed_date) as disb_date, el.status, el.approved_by, COALESCE(u.name, u.username) as approver_name, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name")
            ->join('employees e', 'e.id = el.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('users u', 'u.id = el.approved_by', 'left');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');

        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $builder->where('LOWER(el.status)', strtolower($filters['status']));
        }

        $records = $builder->orderBy('el.created_at', 'DESC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $totalPrincipal = 0.0;
        $totalPayable = 0.0;
        $totalEmi = 0.0;

        foreach ($records as $r) {
            $principal = (float)($r['principal'] ?? 0.0);
            $rate = (float)($r['interest_rate'] ?? 0.0);
            $tenure = (int)($r['tenure'] ?? 12);
            $emi = (float)($r['emi'] ?? 0.0);
            $total = (float)($r['total_payable'] ?? ($principal + ($principal * ($rate / 100) * ($tenure / 12))));

            $totalPrincipal += $principal;
            $totalPayable += $total;
            $totalEmi += $emi;

            $approvedBy = !empty($r['approver_name']) ? $r['approver_name'] : '-';

            $rows[] = [
                $sl++,
                $r['id'] ?? '-',
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                $r['loan_type'] ?? 'Corporate Loan',
                number_format($principal, 2),
                number_format($rate, 2) . '%',
                $tenure,
                number_format($emi, 2),
                number_format($total, 2),
                $r['disb_date'] ?: '-',
                ucfirst(strtolower($r['status'] ?? 'pending')),
                $approvedBy
            ];
        }

        // Grand Total row
        $count = count($records);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Count: {$count}",
            '-',
            '-',
            '-',
            number_format($totalPrincipal, 2),
            '-',
            '-',
            number_format($totalEmi, 2),
            number_format($totalPayable, 2),
            '-',
            '-',
            '-'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count'    => $count,
                'total_principal' => $totalPrincipal,
                'total_payable'   => $totalPayable,
                'total_emi'       => $totalEmi
            ],
            'exceptions' => []
        ];
    }

    /**
     * 5. Loan Installment Amortization Schedule
     */
    public function loanInstallmentSchedule(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Loan ID', 'Employee Code', 'Employee Name', 'Installment #',
            'Due Month', 'Principal Component', 'Interest Component', 'EMI Amount',
            'Running Balance', 'Payment Status'
        ];

        $builder = $this->db->table('employee_loans el')
            ->select("el.id, el.loan_type, COALESCE(el.principal_amount, el.amount, el.loan_amount) as principal, el.interest_rate, COALESCE(el.repayment_months, el.total_installments, 12) as tenure, COALESCE(el.monthly_installment, el.monthly_emi) as emi, COALESCE(el.disbursement_date, el.disbursed_date) as disb_date, el.status, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name")
            ->join('employees e', 'e.id = el.employee_id', 'left')
            ->where('el.status !=', 'Rejected');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $loans = $builder->orderBy('el.created_at', 'DESC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $totalEmiSum = 0.0;

        foreach ($loans as $loan) {
            $schedule = LoanAdvanceService::generateAmortizationSchedule($loan);
            $startDate = !empty($loan['disb_date']) ? strtotime($loan['disb_date']) : time();

            foreach ($schedule as $inst) {
                $instNo = (int)($inst['installment'] ?? 1);
                $dueMonth = date('F Y', strtotime("+{$instNo} month", $startDate));
                $emi = (float)($inst['emi'] ?? $loan['emi']);
                $princ = (float)($inst['principal'] ?? ($emi * 0.9));
                $interest = (float)($inst['interest'] ?? ($emi - $princ));
                $bal = (float)($inst['remainingBalance'] ?? 0.0);
                $status = !empty($inst['status']) ? ucfirst($inst['status']) : ($instNo <= 2 ? 'Paid' : 'Scheduled');

                $totalEmiSum += $emi;

                $rows[] = [
                    $sl++,
                    $loan['id'] ?? '-',
                    $loan['employee_code'] ?? '-',
                    trim($loan['employee_name'] ?? 'Unknown'),
                    "#{$instNo}",
                    $dueMonth,
                    number_format($princ, 2),
                    number_format($interest, 2),
                    number_format($emi, 2),
                    number_format($bal, 2),
                    $status
                ];
            }
        }

        // Grand Total row
        $count = count($rows);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Installments: {$count}",
            '-',
            '-',
            '-',
            '-',
            '-',
            number_format($totalEmiSum, 2),
            '-',
            '-'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'total_installments' => $count,
                'total_scheduled_emi' => $totalEmiSum
            ],
            'exceptions' => []
        ];
    }

    /**
     * 6. Loan Recovery & Repayment History
     */
    public function loanRecovery(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Payroll Month', 'Loan ID', 'Employee Code', 'Employee Name', 'Department',
            'Repayment Amount', 'Deduction Status', 'Settlement / Reference ID', 'Recorded At'
        ];

        $builder = $this->db->table('loan_repayments lr')
            ->select("lr.id, lr.loan_id, lr.payroll_month, lr.amount, lr.status, lr.settlement_id, lr.created_at, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name")
            ->join('employees e', 'e.id = lr.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');

        if (!empty($filters['payroll_month'])) {
            $builder->where('lr.payroll_month', $filters['payroll_month']);
        } elseif (!empty($filters['from']) && !empty($filters['to'])) {
            $builder->where('lr.payroll_month >=', date('Y-m', strtotime($filters['from'])))
                    ->where('lr.payroll_month <=', date('Y-m', strtotime($filters['to'])));
        }

        $records = $builder->orderBy('lr.created_at', 'DESC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $totalRecovered = 0.0;

        foreach ($records as $r) {
            $amt = (float)($r['amount'] ?? 0.0);
            $totalRecovered += $amt;

            $rows[] = [
                $sl++,
                $r['payroll_month'] ?? '-',
                $r['loan_id'] ?? '-',
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                number_format($amt, 2),
                ucfirst(strtolower($r['status'] ?? 'pending')),
                $r['settlement_id'] ?: 'Payroll Run',
                !empty($r['created_at']) ? date('Y-m-d H:i', strtotime($r['created_at'])) : '-'
            ];
        }

        // Grand Total row
        $count = count($records);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Count: {$count}",
            '-',
            '-',
            '-',
            number_format($totalRecovered, 2),
            '-',
            '-',
            '-'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count'    => $count,
                'total_recovered' => $totalRecovered
            ],
            'exceptions' => []
        ];
    }

    /**
     * 7. Loan Outstanding & Balance Due Report
     */
    public function loanOutstandingBalance(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Loan ID', 'Employee Code', 'Employee Name', 'Department',
            'Principal Amount', 'Total Repaid', 'Outstanding Due', 'Remaining Installments', 'Loan Status'
        ];

        $builder = $this->db->table('employee_loans el')
            ->select("el.id, COALESCE(el.principal_amount, el.amount, el.loan_amount) as principal, el.total_paid, el.total_due, el.remaining_installments, el.total_installments, el.status, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name")
            ->join('employees e', 'e.id = el.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->whereIn('el.status', ['Approved', 'Disbursed', 'Active']);

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $records = $builder->orderBy('el.created_at', 'DESC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $totalPrinc = 0.0;
        $totalPaid = 0.0;
        $totalDue = 0.0;

        foreach ($records as $r) {
            $princ = (float)($r['principal'] ?? 0.0);
            $paid = (float)($r['total_paid'] ?? 0.0);
            $due = (float)($r['total_due'] ?? max(0, $princ - $paid));
            $remInst = (int)($r['remaining_installments'] ?? $r['total_installments'] ?? 0);

            $totalPrinc += $princ;
            $totalPaid += $paid;
            $totalDue += $due;

            $rows[] = [
                $sl++,
                $r['id'] ?? '-',
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                number_format($princ, 2),
                number_format($paid, 2),
                number_format($due, 2),
                $remInst,
                ucfirst(strtolower($r['status'] ?? 'active'))
            ];
        }

        // Grand Total row
        $count = count($records);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Count: {$count}",
            '-',
            '-',
            number_format($totalPrinc, 2),
            number_format($totalPaid, 2),
            number_format($totalDue, 2),
            '-',
            '-'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count'    => $count,
                'total_principal' => $totalPrinc,
                'total_paid'      => $totalPaid,
                'total_due'       => $totalDue
            ],
            'exceptions' => []
        ];
    }

    /**
     * 8. Overdue & Defaulted Loans Report
     */
    public function overdueLoans(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Loan ID', 'Employee Code', 'Employee Name', 'Department',
            'Monthly EMI', 'Missed Months', 'Overdue Amount', 'Total Loan Due', 'Risk Level', 'Action Required'
        ];

        $builder = $this->db->table('employee_loans el')
            ->select("el.id, el.start_month, el.total_installments, COALESCE(el.principal_amount, el.amount, el.loan_amount) as principal, COALESCE(el.monthly_installment, el.monthly_emi) as emi, el.total_due, el.total_paid, el.status, e.id as emp_id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name")
            ->join('employees e', 'e.id = el.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->whereIn('el.status', ['Approved', 'Disbursed', 'Active']);

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $loans = $builder->orderBy('el.created_at', 'DESC')->get()->getResultArray();

        $rows = [];
        $exceptions = [];
        $sl = 1;
        $totalOverdueSum = 0.0;

        foreach ($loans as $l) {
            $emi = (float)($l['emi'] ?? 0.0);
            $totalDue = (float)($l['total_due'] ?? ($l['principal'] ?? 0.0));

            $start = $l['start_month'] ?? date('Y-m');
            $expected = 0;
            for ($m = strtotime("{$start}-01"); date('Y-m', $m) < date('Y-m'); $m = strtotime('+1 month', $m)) {
                $expected++; // sudhu agey jaowa mash gulo
            }
            $posted = $this->db->table('loan_repayments')
                ->where('loan_id', $l['id'])->where('status', 'posted')->where('settlement_id IS NULL', null, false)
                ->countAllResults();
            $overdueMonths = max(0, min($expected, (int)($l['total_installments'] ?? $expected)) - $posted);
            $missed = $overdueMonths;

            if ($missed > 0 && $emi > 0) {
                $overdueAmt = round($missed * $emi, 2);
                $risk = ($missed >= 3) ? 'Critical / Default' : (($missed === 2) ? 'High' : 'Moderate');
                $action = ($missed >= 3) ? 'Salary hold / Legal notice' : 'HR reminder notification';

                $totalOverdueSum += $overdueAmt;

                $exceptions[] = [
                    'employee_code' => $l['employee_code'],
                    'name'          => $l['employee_name'],
                    'issue'         => "{$missed} consecutive installments overdue"
                ];

                $rows[] = [
                    $sl++,
                    $l['id'] ?? '-',
                    $l['employee_code'] ?? '-',
                    trim($l['employee_name'] ?? 'Unknown'),
                    $l['department_name'] ?? 'General',
                    number_format($emi, 2),
                    $missed,
                    number_format($overdueAmt, 2),
                    number_format($totalDue, 2),
                    $risk,
                    $action
                ];
            }
        }

        // Grand Total row
        $count = count($rows);
        $rows[] = [
            'TOTAL',
            'Grand Total Overdue',
            "Count: {$count}",
            '-',
            '-',
            '-',
            '-',
            number_format($totalOverdueSum, 2),
            '-',
            $count > 0 ? 'Review Delinquency' : 'No Overdue',
            '-'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'overdue_count'  => $count,
                'total_overdue'  => $totalOverdueSum
            ],
            'exceptions' => $exceptions
        ];
    }

    /**
     * 9. Closed & Fully Repaid Loans Register
     */
    public function loanClosure(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Loan ID', 'Employee Code', 'Employee Name', 'Department',
            'Principal Loan', 'Total Amount Repaid', 'Settlement Date', 'Closure Status', 'Verified By'
        ];

        $builder = $this->db->table('employee_loans el')
            ->select("el.id, COALESCE(el.principal_amount, el.amount, el.loan_amount) as principal, el.total_paid, el.updated_at, el.status, el.approved_by, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name")
            ->join('employees e', 'e.id = el.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->whereIn('el.status', ['Closed', 'Completed', 'Settled']);

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $records = $builder->orderBy('el.updated_at', 'DESC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $totalPrinc = 0.0;
        $totalRepaid = 0.0;

        foreach ($records as $r) {
            $princ = (float)($r['principal'] ?? 0.0);
            $repaid = (float)($r['total_paid'] ?? $princ);

            $totalPrinc += $princ;
            $totalRepaid += $repaid;

            $rows[] = [
                $sl++,
                $r['id'] ?? '-',
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                number_format($princ, 2),
                number_format($repaid, 2),
                !empty($r['updated_at']) ? date('Y-m-d', strtotime($r['updated_at'])) : '-',
                'Closed / Settled',
                $r['approved_by'] ?: 'System Audit'
            ];
        }

        // Grand Total row
        $count = count($records);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Count: {$count}",
            '-',
            '-',
            number_format($totalPrinc, 2),
            number_format($totalRepaid, 2),
            '-',
            'Audited',
            '-'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'closed_loans_count' => $count,
                'total_principal'    => $totalPrinc,
                'total_repaid'       => $totalRepaid
            ],
            'exceptions' => []
        ];
    }

    /**
     * 10. Loan vs Payroll EMI Reconciliation
     */
    public function loanVsPayrollReconciliation(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Payroll Month', 'Employee Code', 'Employee Name', 'Loan ID',
            'Scheduled EMI', 'Actual Deducted EMI', 'Variance', 'Reconciliation Status', 'Remarks'
        ];

        $month = (string)($filters['payroll_month'] ?? date('Y-m'));
        if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $month)) {
            $month = date('Y-m');
        }
        $monthEnd = date('Y-m-t', strtotime("{$month}-01"));

        $builder = $this->db->table('employee_loans el')
            ->select("el.id as loan_id, COALESCE(el.monthly_installment, el.monthly_emi) as scheduled_emi,
                lr.amount as deducted_emi, lr.status as rep_status,
                e.employee_code, CONCAT(e.first_name,' ',COALESCE(e.last_name,'')) as employee_name")
            ->join('employees e', 'e.id = el.employee_id', 'left')
            ->join('loan_repayments lr',
                'lr.loan_id = el.id AND lr.payroll_month = ' . $this->db->escape($month) . " AND lr.status IN ('pending','posted')",
                'left')
            ->whereIn('el.status', ['Approved', 'Active'])
            ->where('COALESCE(el.disbursed_date, el.disbursement_date) <=', $monthEnd);

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $records = $builder->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

        $rows = [];
        $exceptions = [];
        $sl = 1;
        $totalSched = 0.0;
        $totalDeducted = 0.0;
        $totalVar = 0.0;

        foreach ($records as $r) {
            $sched = (float)($r['scheduled_emi'] ?? 0.0);
            $deducted = (float)($r['deducted_emi'] ?? 0.0);
            $var = round($sched - $deducted, 2);

            $status = ($var == 0) ? 'Matched' : (($deducted == 0) ? 'Skipped / Unapplied' : 'Partial Deduction');
            $remarks = ($var == 0) ? 'Exact deduction' : "Discrepancy of {$var}";

            if ($var != 0) {
                $exceptions[] = [
                    'employee_code' => $r['employee_code'],
                    'name'          => $r['employee_name'],
                    'issue'         => "EMI deduction discrepancy: {$var}"
                ];
            }

            $totalSched += $sched;
            $totalDeducted += $deducted;
            $totalVar += $var;

            $rows[] = [
                $sl++,
                $month,
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['loan_id'] ?? '-',
                number_format($sched, 2),
                number_format($deducted, 2),
                number_format($var, 2),
                $status,
                $remarks
            ];
        }

        // Grand Total row
        $count = count($records);
        $rows[] = [
            'TOTAL',
            $month,
            'Grand Total',
            "Count: {$count}",
            '-',
            number_format($totalSched, 2),
            number_format($totalDeducted, 2),
            number_format($totalVar, 2),
            count($exceptions) > 0 ? (count($exceptions) . ' Variances') : 'Reconciled',
            '-'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count'    => $count,
                'scheduled_emi'   => $totalSched,
                'deducted_emi'    => $totalDeducted,
                'variance'        => $totalVar,
                'exceptions'      => count($exceptions)
            ],
            'exceptions' => $exceptions
        ];
    }

    /**
     * 11. Employee Total Financial Liability
     */
    public function employeeFinancialLiability(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Employee Code', 'Employee Name', 'Department', 'Monthly Gross',
            'Active Loans Balance', 'Outstanding Advances', 'Total Liability',
            'Monthly Deduction Burden', 'Burden Ratio (%)', 'Risk Assessment'
        ];

        $salJoin = $this->getActiveSalaryJoin('e', 'es');
        $builder = $this->db->table('employees e')
            ->select("e.id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name, COALESCE(es.gross_salary, e.gross_salary, 0) as gross_salary")
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('employee_salaries es', $salJoin, 'left');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $employees = $builder->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

        $rows = [];
        $exceptions = [];
        $sl = 1;
        $totalGrossSum = 0.0;
        $totalLoanDueSum = 0.0;
        $totalAdvDueSum = 0.0;
        $grandLiabilitySum = 0.0;
        $totalMonthlyBurdenSum = 0.0;

        foreach ($employees as $emp) {
            $gross = (float)($emp['gross_salary'] ?? 0.0);

            // Never silently assume zero: mark missing salary as exception
            if ($gross <= 0) {
                $exceptions[] = [
                    'employee_code' => $emp['employee_code'],
                    'name'          => $emp['employee_name'],
                    'issue'         => 'Missing salary structure'
                ];
            }

            // Loans liability
            $loanQ = $this->db->table('employee_loans')
                ->select('SUM(COALESCE(total_due, principal_amount, amount)) as total_due, SUM(COALESCE(monthly_installment, monthly_emi)) as monthly_emi')
                ->where('employee_id', $emp['id'])
                ->whereIn('status', ['Approved', 'Disbursed', 'Active'])
                ->get()
                ->getRowArray();

            $loanDue = (float)($loanQ['total_due'] ?? 0.0);
            $loanEmi = (float)($loanQ['monthly_emi'] ?? 0.0);

            // Advances liability
            $advQ = $this->db->table('salary_advances')
                ->select('SUM(amount) as adv_total')
                ->where('employee_id', $emp['id'])
                ->where('status', 'Approved')
                ->get()
                ->getRowArray();

            $advDue = (float)($advQ['adv_total'] ?? 0.0);
            $totLiability = round($loanDue + $advDue, 2);
            $monthlyBurden = round($loanEmi + ($advDue > 0 ? ($advDue / 2) : 0), 2);
            $ratio = ($gross > 0) ? round(($monthlyBurden / $gross) * 100, 1) : 0.0;

            if ($totLiability <= 0 && $gross > 0) {
                // If filters want only with liabilities, or keep all
                continue;
            }

            $risk = ($ratio > 50) ? 'High / Debt Burden Breach' : (($ratio > 30) ? 'Moderate' : 'Low');

            $totalGrossSum += $gross;
            $totalLoanDueSum += $loanDue;
            $totalAdvDueSum += $advDue;
            $grandLiabilitySum += $totLiability;
            $totalMonthlyBurdenSum += $monthlyBurden;

            $rows[] = [
                $sl++,
                $emp['employee_code'] ?? '-',
                trim($emp['employee_name'] ?? 'Unknown'),
                $emp['department_name'] ?? 'General',
                number_format($gross, 2),
                number_format($loanDue, 2),
                number_format($advDue, 2),
                number_format($totLiability, 2),
                number_format($monthlyBurden, 2),
                $ratio . '%',
                $risk
            ];
        }

        // Grand Total row
        $count = count($rows);
        $avgRatio = ($totalGrossSum > 0) ? round(($totalMonthlyBurdenSum / $totalGrossSum) * 100, 1) : 0.0;
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Count: {$count}",
            '-',
            number_format($totalGrossSum, 2),
            number_format($totalLoanDueSum, 2),
            number_format($totalAdvDueSum, 2),
            number_format($grandLiabilitySum, 2),
            number_format($totalMonthlyBurdenSum, 2),
            $avgRatio . '%',
            count($exceptions) > 0 ? (count($exceptions) . ' Missing Salaries') : 'Audited'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count'    => $count,
                'total_liability' => $grandLiabilitySum,
                'monthly_burden'  => $totalMonthlyBurdenSum,
                'exceptions'      => count($exceptions)
            ],
            'exceptions' => $exceptions
        ];
    }
}
