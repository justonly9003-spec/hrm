<?php

namespace App\Services;

use App\Services\RuleEngineService;
use Config\Database;

class AttendanceService
{
    protected $db;
    protected $ruleEngine;
    protected static array $empProfileCache = [];

    public function __construct()
    {
        $this->db = Database::connect();
        $this->ruleEngine = new RuleEngineService();
    }

    /**
     * Synchronize with 'attendances' table if it exists in DB schema
     */
    protected function syncAttendancesTable(array $payload): void
    {
        if (!$this->db->tableExists('attendances')) {
            return;
        }

        try {
            $tableFields = $this->db->getFieldNames('attendances');
            $safePayload = [];
            foreach ($payload as $col => $val) {
                if (in_array($col, $tableFields, true)) {
                    $safePayload[$col] = $val;
                }
            }

            if (empty($safePayload['id'])) {
                return;
            }

            $existing = $this->db->table('attendances')->where('id', $safePayload['id'])->get()->getRowArray();
            if ($existing) {
                $this->db->table('attendances')->where('id', $safePayload['id'])->update($safePayload);
            } else {
                $this->db->table('attendances')->insert($safePayload);
            }
        } catch (\Throwable $e) {
            // Silently ignore schema disparity
        }
    }

    /**
     * Haversine Distance calculation (meters)
     */
    public function calculateDistance(float $lat1, float $lon1, float $lat2, float $lon2): float
    {
        $earthRadius = 6371000; // in meters
        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);
        $a = sin($dLat / 2) * sin($dLat / 2) +
             cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
             sin($dLon / 2) * sin($dLon / 2);
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        return $earthRadius * $c;
    }

    /**
     * Resolve shift grace column safely based on actual database schema
     */
    protected function getShiftGraceField(): string
    {
        static $field = null;
        if ($field === null) {
            $field = '15 as grace_time';
            try {
                if ($this->db->tableExists('shifts')) {
                    $cols = $this->db->getFieldNames('shifts');
                    if (in_array('grace_time', $cols, true)) {
                        $field = 'shifts.grace_time as grace_time';
                    } elseif (in_array('late_grace_period_mins', $cols, true)) {
                        $field = 'shifts.late_grace_period_mins as grace_time';
                    } elseif (in_array('late_grace_period_minutes', $cols, true)) {
                        $field = 'shifts.late_grace_period_minutes as grace_time';
                    }
                }
            } catch (\Throwable $e) {
                $field = '15 as grace_time';
            }
        }
        return $field;
    }

    /**
     * Check if an attendance record is settled in payroll (SEC-MOD02-002)
     */
    public function isAttendanceSettled(string $employeeId, string $date, ?string $logId = null, ?string $companyId = null): bool
    {
        try {
            $canonicalEmpId = $employeeId;
            $resolvedCompanyId = $companyId;
            if ($this->db->tableExists('employees')) {
                $builder = $this->db->table('employees');
                if (!empty($companyId)) {
                    $builder->where('company_id', $companyId);
                }
                $emp = $builder->where('id', $employeeId)->get()->getRowArray();
                if (!$emp && !empty($companyId)) {
                    $emp = $this->db->table('employees')
                        ->where('company_id', $companyId)
                        ->where('employee_code', $employeeId)
                        ->get()
                        ->getRowArray();
                }
                if ($emp) {
                    $canonicalEmpId = $emp['id'];
                    $resolvedCompanyId = $emp['company_id'] ?? $companyId;
                }
            }

            if ($logId && $this->db->tableExists('attendance_logs')) {
                $logBuilder = $this->db->table('attendance_logs')->where('id', $logId);
                if (!empty($resolvedCompanyId) && $this->db->fieldExists('company_id', 'attendance_logs')) {
                    $logBuilder->where('company_id', $resolvedCompanyId);
                }
                $log = $logBuilder->get()->getRowArray();
                if ($log && !empty($log['is_settled'])) {
                    return true;
                }
            }

            if ($this->db->tableExists('attendance_logs')) {
                $logBuilder = $this->db->table('attendance_logs')
                    ->groupStart()
                        ->where('employee_id', $canonicalEmpId)
                        ->orWhere('employee_id', $employeeId)
                    ->groupEnd()
                    ->where('date', $date);
                if (!empty($resolvedCompanyId) && $this->db->fieldExists('company_id', 'attendance_logs')) {
                    $logBuilder->where('company_id', $resolvedCompanyId);
                }
                $log = $logBuilder->get()->getRowArray();

                if ($log && !empty($log['is_settled'])) {
                    return true;
                }
            }

            // Check final_settlements (Decision 3)
            if ($this->db->tableExists('final_settlements')) {
                $fsBuilder = $this->db->table('final_settlements')
                    ->groupStart()
                        ->where('employee_id', $canonicalEmpId)
                        ->orWhere('employee_id', $employeeId)
                    ->groupEnd();
                if (!empty($resolvedCompanyId) && $this->db->fieldExists('company_id', 'final_settlements')) {
                    $fsBuilder->where('company_id', $resolvedCompanyId);
                }
                if ($this->db->fieldExists('status', 'final_settlements')) {
                    $fsBuilder->whereIn('status', ['Approved', 'Settled', 'Paid']);
                }
                if ($fsBuilder->countAllResults() > 0) {
                    return true;
                }
            }

            // Check payroll_run_locks (Decision 3)
            if ($this->db->tableExists('payroll_run_locks') && !empty($resolvedCompanyId)) {
                $month = substr($date, 0, 7);
                $prlBuilder = $this->db->table('payroll_run_locks')->where('company_id', $resolvedCompanyId);
                if ($this->db->fieldExists('payroll_month', 'payroll_run_locks')) {
                    $prlBuilder->where('payroll_month', $month);
                } elseif ($this->db->fieldExists('period_month', 'payroll_run_locks')) {
                    $prlBuilder->where('period_month', $month);
                }
                if ($this->db->fieldExists('status', 'payroll_run_locks')) {
                    $prlBuilder->whereIn('status', ['LOCKED', 'SETTLED', 'FINALIZED']);
                }
                if ($prlBuilder->countAllResults() > 0) {
                    return true;
                }
            }

            // Check if overtime records for this employee on this date are already settled
            if ($this->db->tableExists('overtime_records')) {
                if ($this->db->fieldExists('employee_id', 'overtime_records') &&
                    $this->db->fieldExists('date', 'overtime_records') &&
                    $this->db->fieldExists('is_settled', 'overtime_records')) {
                    $otBuilder = $this->db->table('overtime_records')
                        ->groupStart()
                            ->where('employee_id', $canonicalEmpId)
                            ->orWhere('employee_id', $employeeId)
                        ->groupEnd()
                        ->where('date', $date)
                        ->where('is_settled', 1);
                    if (!empty($resolvedCompanyId) && $this->db->fieldExists('company_id', 'overtime_records')) {
                        $otBuilder->where('company_id', $resolvedCompanyId);
                    }
                    if ($otBuilder->countAllResults() > 0) {
                        return true;
                    }
                }
            }

            // Check overtime settlement locks (company-level or employee-level if column exists)
            if ($this->db->tableExists('overtime_settlement_locks')) {
                $periodMonth = substr($date, 0, 7);
                if ($this->db->fieldExists('employee_id', 'overtime_settlement_locks')) {
                    $otBuilder = $this->db->table('overtime_settlement_locks')
                        ->groupStart()
                            ->where('employee_id', $canonicalEmpId)
                            ->orWhere('employee_id', $employeeId)
                        ->groupEnd();
                    if ($this->db->fieldExists('period_month', 'overtime_settlement_locks')) {
                        $otBuilder->where('period_month', $periodMonth);
                    } elseif ($this->db->fieldExists('payroll_month', 'overtime_settlement_locks')) {
                        $otBuilder->where('payroll_month', $periodMonth);
                    }
                    if ($this->db->fieldExists('status', 'overtime_settlement_locks')) {
                        $otBuilder->where('status', 'SETTLED');
                    }
                    if ($otBuilder->countAllResults() > 0) {
                        return true;
                    }
                } elseif ($this->db->fieldExists('payroll_month', 'overtime_settlement_locks') && $this->db->fieldExists('company_id', 'overtime_settlement_locks')) {
                    $compId = $resolvedCompanyId;
                    if (!$compId && function_exists('session') && session()->has('company_id')) {
                        $compId = session()->get('company_id');
                    }
                    if (!empty($compId)) {
                        $compLock = $this->db->table('overtime_settlement_locks')
                            ->where('company_id', $compId)
                            ->where('payroll_month', $periodMonth)
                            ->countAllResults();
                        if ($compLock > 0) {
                            return true;
                        }
                    }
                }
            }

            // Check payrolls table for locked or finalized payroll in that month
            if ($this->db->tableExists('payrolls')) {
                if ($this->db->fieldExists('employee_id', 'payrolls')) {
                    $month = (int)date('m', strtotime($date));
                    $year = (int)date('Y', strtotime($date));
                    $payrollQuery = $this->db->table('payrolls')
                        ->groupStart()
                            ->where('employee_id', $canonicalEmpId)
                            ->orWhere('employee_id', $employeeId)
                        ->groupEnd();

                    if (!empty($resolvedCompanyId) && $this->db->fieldExists('company_id', 'payrolls')) {
                        $payrollQuery->where('company_id', $resolvedCompanyId);
                    }

                    if ($this->db->fieldExists('year', 'payrolls')) {
                        $payrollQuery->where('year', $year);
                    }
                    if ($this->db->fieldExists('month', 'payrolls')) {
                        $payrollQuery->groupStart()
                            ->where('month', $month)
                            ->orWhere('month', sprintf('%02d', $month))
                        ->groupEnd();
                    }

                    $hasIsLocked = $this->db->fieldExists('is_locked', 'payrolls');
                    $hasStatus = $this->db->fieldExists('status', 'payrolls');

                    if ($hasIsLocked || $hasStatus) {
                        $payrollQuery->groupStart();
                        if ($hasIsLocked) {
                            $payrollQuery->where('is_locked', 1);
                        }
                        if ($hasStatus) {
                            if ($hasIsLocked) {
                                $payrollQuery->orWhereIn('status', ['processed', 'approved', 'paid']);
                            } else {
                                $payrollQuery->whereIn('status', ['processed', 'approved', 'paid']);
                            }
                        }
                        $payrollQuery->groupEnd();
                    }

                    if ($payrollQuery->countAllResults() > 0) {
                        return true;
                    }
                }
            }
        } catch (\Throwable $e) {
            log_message('error', 'isAttendanceSettled exception caught: ' . $e->getMessage());
            return false;
        }

        return false;
    }

    /**
     * Record Check-In with Geofence & Shift Verification
     */
    public function checkIn(string $employeeId, ?float $lat = null, ?float $lon = null, string $method = 'Web', string $remarks = ''): array
    {
        $today = date('Y-m-d');
        $now = date('H:i:s');

        // SEC-MOD02-002: Settled Payroll Protection
        if ($this->isAttendanceSettled($employeeId, $today)) {
            return [
                'success'     => false,
                'status_code' => 422,
                'message'     => "422 Unprocessable Entity: Attendance for {$employeeId} on {$today} is locked and settled in payroll."
            ];
        }

        // Fetch employee & branch details
        $emp = $this->db->table('employees')
            ->select('employees.*, departments.name as department_name, branches.latitude as branch_lat, branches.longitude as branch_lon, 
                      branches.allowed_gps_radius, shifts.start_time, shifts.end_time, ' . $this->getShiftGraceField())
            ->join('departments', 'departments.id = employees.department_id', 'left')
            ->join('branches', 'branches.id = employees.branch_id', 'left')
            ->join('shifts', 'shifts.id = employees.shift_id', 'left')
            ->where('employees.id', $employeeId)
            ->get()
            ->getRowArray();

        if (!$emp) {
            return ['success' => false, 'message' => 'Employee profile not found.'];
        }

        // SEC-ATT-10: Validate GPS Geofence and enforce coordinates when required
        $policy = (new \App\Models\AttendanceModel())->getPolicySettings($emp['company_id'] ?? null);
        $strictGeofence = !empty($policy['strictGeofence']);
        $branchHasCoords = !empty($emp['branch_lat']) && !empty($emp['branch_lon']);

        // Hardware / biometric methods are exempt from GPS check
        $isBiometricHardware = in_array(strtolower($method), [
            'biometric', 'fingerprint', 'face recognition', 'rfid card', 'zk-palm', 'hardware', 'zkteco'
        ], true);
        $hasCoords = ($lat !== null && $lon !== null && ($lat != 0.0 || $lon != 0.0));

        if (!$isBiometricHardware && $strictGeofence && !$hasCoords) {
            return [
                'success'     => false,
                'status_code' => 422,
                'message'     => 'GPS coordinates required for this location. Geofencing is strictly enforced.'
            ];
        }

        $withinGeofence = true;
        $geofenceStatus = 'verified';

        if ($hasCoords && $branchHasCoords) {
            $dist = $this->calculateDistance($lat, $lon, (float)$emp['branch_lat'], (float)$emp['branch_lon']);
            $allowed = (float)($emp['allowed_gps_radius'] ?: ($policy['geofenceRadius'] ?? 200));
            if ($dist > $allowed) {
                $withinGeofence = false;
                $geofenceStatus = 'violation';
                return [
                    'success'     => false,
                    'status_code' => 422,
                    'message'     => "GPS Geofence violation. You are " . round($dist) . "m away from branch (limit: {$allowed}m)."
                ];
            }
        } elseif (!$hasCoords) {
            $withinGeofence = false;
            $geofenceStatus = $isBiometricHardware ? 'exempt_biometric' : 'bypassed_missing_coords';
            if (!$isBiometricHardware) {
                $remarks = !empty($remarks) ? ($remarks . ' [Punch without GPS location: unverified]') : 'Punch without GPS location: unverified';
            }
        }

        // Check if today is a company weekend or holiday
        $isHoliday = false;
        if ($this->db->tableExists('holidays') && !empty($emp['company_id'])) {
            $hQuery = $this->db->table('holidays')->where('company_id', $emp['company_id']);
            if ($this->db->fieldExists('from_date', 'holidays') && $this->db->fieldExists('to_date', 'holidays')) {
                $hQuery->where('from_date <=', $today)->where('to_date >=', $today);
            } elseif ($this->db->fieldExists('holiday_date', 'holidays')) {
                $hQuery->where('holiday_date', $today);
            } elseif ($this->db->fieldExists('date', 'holidays')) {
                $hQuery->where('date', $today);
            }
            $isHoliday = $hQuery->countAllResults() > 0;
        }
        $isWeeklyOff = \App\Services\CompanyWeekendService::isWeeklyOff($today, $emp['company_id'] ?? null, $employeeId);

        // Resolve effective shift via Centralized Shift Resolution (Phase 3)
        $shiftModel = new \App\Models\ShiftModel();
        $effectiveShift = $shiftModel->resolveEffectiveShift($employeeId, $today, $emp);
        $isScheduled = !empty($effectiveShift['is_scheduled']) && empty($effectiveShift['is_day_off']) && ($effectiveShift['outcome'] ?? '') !== 'NO_ASSIGNED_SHIFT';
        $shiftStart = $isScheduled ? ($effectiveShift['start_time'] ?? ($emp['start_time'] ?? null)) : null;
        $shiftGrace = (int)($effectiveShift['late_grace_period_mins'] ?? ($emp['grace_time'] ?? 15));

        // Authoritative RuleEngine evaluation using full hierarchy:
        // Employee -> Shift -> Designation -> Department -> Global
        $profile = $this->ruleEngine->resolveEffectiveRuleProfile($today, $emp);

        // Calculate late status using RuleEngine's authoritative late rule hierarchy
        $lateRule = $profile['lateRule'] ?? ['enabled' => true, 'gracePeriodMinutes' => $shiftGrace, 'penaltyMethod' => 'Warning'];
        $lateMinutes = 0;
        if ($isWeeklyOff || ($effectiveShift['outcome'] ?? '') === 'WEEKLY_OFF' || ($effectiveShift['outcome'] ?? '') === 'ROSTER_DAY_OFF' || !empty($effectiveShift['is_day_off'])) {
            $status = 'Off-Day Work';
        } elseif (!$isScheduled) {
            $status = 'Present (Unscheduled)';
        } else {
            $status = 'Present';
        }

        if ($isScheduled && !empty($lateRule['enabled']) && !$isWeeklyOff && !$isHoliday && !empty($shiftStart)) {
            $shiftStartMins = RuleEngineService::timeStringToMinutes($shiftStart);
            $inMins = RuleEngineService::timeStringToMinutes($now);
            $gracePeriod = (int)($lateRule['gracePeriodMinutes'] ?? $shiftGrace);
            if ($inMins > ($shiftStartMins + $gracePeriod)) {
                $lateMinutes = max(0, $inMins - $shiftStartMins);
                $status = 'Late';
            }
        }

        // Check if log exists
        $existing = $this->db->table('attendance_logs')
            ->where('employee_id', $employeeId)
            ->where('date', $today)
            ->get()
            ->getRowArray();

        if ($existing && !empty($existing['check_in'])) {
            $existingIn = $existing['check_in'] ?? $existing['in_time'] ?? '';
            $inTs = strtotime($today . ' ' . $existingIn);
            $nowTs = strtotime($today . ' ' . $now);
            if ($inTs !== false && $nowTs !== false && abs($nowTs - $inTs) < 60) {
                return [
                    'success'     => true,
                    'type'        => 'Idempotent-Ignored',
                    'status_code' => 200,
                    'message'     => 'Check-in already registered (idempotent retry).'
                ];
            }
            return [
                'success'     => false,
                'status_code' => 409,
                'message'     => 'Check-in already registered for today.'
            ];
        }

        $logId = !empty($existing['id']) ? $existing['id'] : ('att-' . bin2hex(random_bytes(8)));
        $rosterRef = $effectiveShift['assignment_id'] ?? $effectiveShift['source'] ?? 'EMPLOYEE_DEFAULT';
        $insertData = [
            'id'                     => $logId,
            'employee_id'            => $employeeId,
            'company_id'             => $emp['company_id'] ?? null,
            'branch_id'              => $emp['branch_id'] ?? null,
            'shift_id'               => $effectiveShift['shift_id'] ?? null,
            'date'                   => $today,
            'attendance_date'        => $today,
            'shift_date'             => $today,
            'checkout_date'          => null,
            'roster_reference'       => $rosterRef,
            'schedule_snapshot_json' => json_encode($effectiveShift),
            'check_in'               => $now,
            'in_time'                => $now,
            'clock_in'               => "{$today} {$now}",
            'late_minutes'           => $lateMinutes,
            'status'                 => $status,
            'day_type'               => $isHoliday ? 'HOLIDAY_DUTY' : ($isWeeklyOff ? 'WEEKEND_DUTY' : 'NORMAL_WORKDAY'),
            'verification_method'    => $method,
            'is_approved'            => 1,
            'updated_at'             => date('Y-m-d H:i:s')
        ];
        if (!empty($remarks)) {
            $insertData['notes'] = $remarks;
        }

        $tableFields = $this->db->getFieldNames('attendance_logs');
        $safeInsert = [];
        foreach ($insertData as $col => $val) {
            if (in_array($col, $tableFields, true)) {
                $safeInsert[$col] = $val;
            }
        }

        if ($existing) {
            unset($safeInsert['id']);
            $this->db->table('attendance_logs')->where('id', $existing['id'])->update($safeInsert);
            $this->syncAttendancesTable(array_merge($safeInsert, ['id' => $existing['id']]));
        } else {
            $safeInsert['created_at'] = date('Y-m-d H:i:s');
            $this->db->table('attendance_logs')->insert($safeInsert);
            $this->syncAttendancesTable($safeInsert);
        }

        if ($lat !== null && $lon !== null && $this->db->tableExists('attendance_gps_logs')) {
            $gpsCols = $this->db->getFieldNames('attendance_gps_logs');
            $gpsData = [
                'id' => 'gps-' . bin2hex(random_bytes(8)),
                'employee_id' => $employeeId,
                'type' => 'Check-In',
                'latitude' => $lat,
                'longitude' => $lon,
                'is_within_geofence' => $withinGeofence ? 1 : 0
            ];
            if (in_array('attendance_log_id', $gpsCols, true)) {
                $gpsData['attendance_log_id'] = $logId;
            }
            if (in_array('attendance_id', $gpsCols, true)) {
                $gpsData['attendance_id'] = $logId;
            }
            $this->db->table('attendance_gps_logs')->insert($gpsData);
        }

        return ['success' => true, 'message' => 'Check-in registered successfully at ' . $now];
    }

    /**
     * Record Check-Out with GPS Geofence & RuleEngine Evaluation
     */
    public function checkOut(string $employeeId, ?float $lat = null, ?float $lon = null, string $method = 'Web'): array
    {
        $today = date('Y-m-d');
        $now = date('H:i:s');

        $emp = $this->db->table('employees')
            ->select('employees.*, departments.name as department_name, branches.latitude as branch_lat, 
                      branches.longitude as branch_lon, branches.allowed_gps_radius, 
                      shifts.start_time, shifts.end_time, ' . $this->getShiftGraceField())
            ->join('departments', 'departments.id = employees.department_id', 'left')
            ->join('branches', 'branches.id = employees.branch_id', 'left')
            ->join('shifts', 'shifts.id = employees.shift_id', 'left')
            ->where('employees.id', $employeeId)
            ->get()
            ->getRowArray();

        if (!$emp) {
            return ['success' => false, 'message' => 'Employee profile not found.'];
        }

        // SEC-ATT-10: Validate GPS Geofence and enforce coordinates when required
        $policy = (new \App\Models\AttendanceModel())->getPolicySettings($emp['company_id'] ?? null);
        $strictGeofence = !empty($policy['strictGeofence']);
        $branchHasCoords = !empty($emp['branch_lat']) && !empty($emp['branch_lon']);

        // Hardware / biometric methods are exempt from GPS check
        $isBiometricHardware = in_array(strtolower($method), [
            'biometric', 'fingerprint', 'face recognition', 'rfid card', 'zk-palm', 'hardware', 'zkteco'
        ], true);
        $hasCoords = ($lat !== null && $lon !== null && ($lat != 0.0 || $lon != 0.0));

        if (!$isBiometricHardware && $strictGeofence && !$hasCoords) {
            return [
                'success'     => false,
                'status_code' => 422,
                'message'     => 'GPS coordinates required for this location. Geofencing is strictly enforced.'
            ];
        }

        $withinGeofence = true;
        $geofenceStatus = 'verified';

        if ($hasCoords && $branchHasCoords) {
            $dist = $this->calculateDistance($lat, $lon, (float)$emp['branch_lat'], (float)$emp['branch_lon']);
            $allowed = (float)($emp['allowed_gps_radius'] ?: ($policy['geofenceRadius'] ?? 200));
            if ($dist > $allowed) {
                $withinGeofence = false;
                $geofenceStatus = 'violation';
                return [
                    'success'     => false,
                    'status_code' => 422,
                    'message'     => "GPS Geofence violation. You are " . round($dist) . "m away from branch (limit: {$allowed}m)."
                ];
            }
        } elseif (!$hasCoords) {
            $withinGeofence = false;
            $geofenceStatus = $isBiometricHardware ? 'exempt_biometric' : 'bypassed_missing_coords';
        }

        // Resolve target attendance log for check-out (supports P0-003 overnight / cross-midnight shifts)
        $targetLog = null;
        $targetDate = $today;
        $effectiveShift = null;

        // 1. Check if today has an open check-in
        $todayLog = $this->db->table('attendance_logs')
            ->where('employee_id', $employeeId)
            ->where('date', $today)
            ->get()
            ->getRowArray();

        if ($todayLog && !empty($todayLog['check_in']) && (empty($todayLog['check_out']) || $todayLog['check_out'] === '00:00:00')) {
            $targetLog = $todayLog;
            $targetDate = $today;
        } else {
            // 2. Check if yesterday has an unclosed check-in AND yesterday's shift was overnight
            $yesterday = date('Y-m-d', strtotime('-1 day'));
            $yesterdayLog = $this->db->table('attendance_logs')
                ->where('employee_id', $employeeId)
                ->where('date', $yesterday)
                ->get()
                ->getRowArray();

            $yesterdayIsOvernight = false;
            $yesterdayShift = null;
            if ($yesterdayLog && !empty($yesterdayLog['check_in']) && (empty($yesterdayLog['check_out']) || $yesterdayLog['check_out'] === '00:00:00') && !\App\Models\AttendanceModel::isClosureLog($yesterdayLog)) {
                $shiftModel = new \App\Models\ShiftModel();
                if (!empty($yesterdayLog['schedule_snapshot_json'])) {
                    $yesterdayShift = json_decode($yesterdayLog['schedule_snapshot_json'], true);
                }
                if (!$yesterdayShift) {
                    $yesterdayShift = $shiftModel->resolveEffectiveShift($employeeId, $yesterday, $emp);
                }
                if ($yesterdayShift) {
                    $yStartMins = RuleEngineService::timeStringToMinutes($yesterdayShift['start_time'] ?? '09:00');
                    $yEndMins = RuleEngineService::timeStringToMinutes($yesterdayShift['end_time'] ?? '18:00');
                    $yesterdayIsOvernight = ($yEndMins <= $yStartMins) || !empty($yesterdayShift['is_night_shift']) || !empty($yesterdayShift['is_cross_midnight']);
                }
            }

            if ($yesterdayIsOvernight) {
                $targetLog = $yesterdayLog;
                $targetDate = $yesterday;
                $effectiveShift = $yesterdayShift;
            } elseif ($todayLog && !empty($todayLog['check_in'])) {
                $targetLog = $todayLog;
                $targetDate = $today;
            }
        }

        if (!$targetLog || empty($targetLog['check_in'])) {
            return ['success' => false, 'message' => 'No active check-in record found for today or preceding overnight shift.'];
        }

        // Replay / Idempotency protection for check-out
        if (!empty($targetLog['check_out']) && $targetLog['check_out'] !== '00:00:00') {
            $outTs = strtotime(($targetLog['checkout_date'] ?? $targetDate) . ' ' . $targetLog['check_out']);
            $nowTs = strtotime($today . ' ' . $now);
            if ($outTs !== false && $nowTs !== false && abs($nowTs - $outTs) < 60) {
                return [
                    'success'     => true,
                    'type'        => 'Idempotent-Ignored',
                    'status_code' => 200,
                    'message'     => 'Check-out already registered (idempotent retry).'
                ];
            }
        }

        // SEC-MOD02-002: Settled Payroll Protection
        if ($this->isAttendanceSettled($employeeId, $targetDate, $targetLog['id'] ?? null)) {
            return [
                'success'     => false,
                'status_code' => 422,
                'message'     => "422 Unprocessable Entity: Attendance record on {$targetDate} is locked and settled in payroll."
            ];
        }

        // Centralized Shift Resolution (Phase 3)
        if (!$effectiveShift) {
            $shiftModel = new \App\Models\ShiftModel();
            $effectiveShift = $shiftModel->resolveEffectiveShift($employeeId, $targetDate, $emp);
        }

        // Evaluate via RuleEngineService
        $profile = $this->ruleEngine->resolveEffectiveRuleProfile($targetDate, $emp);
        $dailyRes = $this->ruleEngine->calculateDailyAttendance(
            $targetDate,
            $emp,
            array_merge($targetLog, ['check_in' => $targetLog['check_in'], 'check_out' => $now]),
            $profile,
            $effectiveShift
        );

        $workingHours = $dailyRes['net_hours'];
        $overtimeHours = $dailyRes['daily_overtime_hours'] + $dailyRes['off_day_overtime_hours'] + $dailyRes['holiday_overtime_hours'];
        $earlyOutMinutes = $dailyRes['early_out_minutes'] ?? 0;

        $rosterRef = $effectiveShift['assignment_id'] ?? $effectiveShift['source'] ?? ($targetLog['roster_reference'] ?? 'EMPLOYEE_DEFAULT');
        $updatePayload = [
            'shift_id'              => $effectiveShift['shift_id'] ?? ($targetLog['shift_id'] ?? null),
            'attendance_date'       => $targetDate,
            'shift_date'            => $targetDate,
            'checkout_date'         => $today,
            'roster_reference'      => $rosterRef,
            'schedule_snapshot_json'=> json_encode($effectiveShift),
            'check_out'             => $now,
            'out_time'              => $now,
            'clock_out'             => "{$today} {$now}",
            'gross_hours'           => $dailyRes['gross_hours'] ?? 0.0,
            'break_hours'           => $dailyRes['break_hours'] ?? 0.0,
            'net_hours'             => $workingHours,
            'working_hours'         => $workingHours,
            'regular_hours'         => $dailyRes['regular_hours'] ?? 0.0,
            'overtime_hours'        => $overtimeHours,
            'day_type'              => $dailyRes['day_type'] ?? 'NORMAL_WORKDAY',
            'ot_approval_status'    => $dailyRes['ot_approval_status'] ?? 'Not Required',
            'is_ot_payable'         => !empty($dailyRes['is_ot_payable']) ? 1 : 0,
            'ot_amount'             => $dailyRes['ot_amount'] ?? 0.00,
            'early_out_minutes'     => $earlyOutMinutes,
            'early_leaving_minutes' => $earlyOutMinutes,
            'status'                => $dailyRes['status'],
            'verification_method'   => $method,
            'updated_at'            => date('Y-m-d H:i:s')
        ];

        $tableFields = $this->db->getFieldNames('attendance_logs');
        $safePayload = [];
        foreach ($updatePayload as $col => $val) {
            if (in_array($col, $tableFields, true)) {
                $safePayload[$col] = $val;
            }
        }

        $this->db->table('attendance_logs')
            ->where('id', $targetLog['id'])
            ->update($safePayload);
        $this->syncAttendancesTable(array_merge($safePayload, ['id' => $targetLog['id']]));

        if ($lat !== null && $lon !== null && $this->db->tableExists('attendance_gps_logs')) {
            $gpsCols = $this->db->getFieldNames('attendance_gps_logs');
            $gpsData = [
                'id' => 'gps-' . bin2hex(random_bytes(8)),
                'employee_id' => $employeeId,
                'type' => 'Check-Out',
                'latitude' => $lat,
                'longitude' => $lon,
                'is_within_geofence' => $withinGeofence ? 1 : 0
            ];
            if (in_array('attendance_log_id', $gpsCols, true)) {
                $gpsData['attendance_log_id'] = $targetLog['id'];
            }
            if (in_array('attendance_id', $gpsCols, true)) {
                $gpsData['attendance_id'] = $targetLog['id'];
            }
            $this->db->table('attendance_gps_logs')->insert($gpsData);
        }

        $overnightNote = ($targetDate !== $today) ? " (Overnight Shift from {$targetDate})" : "";
        return [
            'success' => true,
            'message' => "Check-out registered successfully{$overnightNote} at {$now}. Total: {$workingHours} hrs (OT: {$overtimeHours} hrs)."
        ];
    }

    /**
     * Record Hardware / Biometric / RFID / QR punch
     */
    public function recordHardwarePunch(string $employeeId, string $method = 'Biometric', ?string $punchDate = null, ?string $punchTime = null, bool $skipDebounce = false, ?string $companyId = null): array
    {
        $today = $punchDate ?: date('Y-m-d');
        $now = $punchTime ? (strlen($punchTime) === 5 ? $punchTime . ':00' : $punchTime) : date('H:i:s');

        $cacheKey = ($companyId ?? 'global') . ':' . $employeeId;
        if (isset(self::$empProfileCache[$cacheKey])) {
            $emp = self::$empProfileCache[$cacheKey];
        } else {
            $builder = $this->db->table('employees')
                ->select('employees.*, departments.name as department_name, shifts.start_time, ' . $this->getShiftGraceField())
                ->join('departments', 'departments.id = employees.department_id', 'left')
                ->join('shifts', 'shifts.id = employees.shift_id', 'left')
                ->where('employees.id', $employeeId);
            if (!empty($companyId)) {
                $builder->where('employees.company_id', $companyId);
            }
            $emp = $builder->get()->getRowArray();

            if (!$emp) {
                if (!empty($companyId)) {
                    $emp = $this->db->table('employees')
                        ->select('employees.*, departments.name as department_name, shifts.start_time, ' . $this->getShiftGraceField())
                        ->join('departments', 'departments.id = employees.department_id', 'left')
                        ->join('shifts', 'shifts.id = employees.shift_id', 'left')
                        ->where('employees.company_id', $companyId)
                        ->where('employees.employee_code', $employeeId)
                        ->get()
                        ->getRowArray();
                } else {
                    log_message('error', "Ambiguous employee lookup for code '{$employeeId}': no company context provided and ID lookup failed.");
                    return ['success' => false, 'message' => "Ambiguous employee code '{$employeeId}': company context is required."];
                }
            }

            if ($emp) {
                $comp = $companyId ?? ($emp['company_id'] ?? 'global');
                self::$empProfileCache[$cacheKey] = $emp;
                self::$empProfileCache[$comp . ':' . $emp['id']] = $emp;
                if (!empty($emp['employee_code'])) {
                    self::$empProfileCache[$comp . ':' . $emp['employee_code']] = $emp;
                }
            }
        }

        if (!$emp) {
            return ['success' => false, 'message' => 'Employee profile not found.'];
        }

        $companyId = $companyId ?? ($emp['company_id'] ?? null);

        // Canonicalize employee ID to primary key
        $employeeId = $emp['id'];

        $empStatus = \App\Models\EmployeeModel::normalizeStatus($emp['status'] ?? \App\Models\EmployeeModel::STATUS_ACTIVE, true);
        if (in_array($empStatus, [
            \App\Models\EmployeeModel::STATUS_RESIGNED,
            \App\Models\EmployeeModel::STATUS_TERMINATED,
            \App\Models\EmployeeModel::STATUS_SUSPENDED,
            \App\Models\EmployeeModel::STATUS_INACTIVE,
        ], true)) {
            $statusLabel = \App\Models\EmployeeModel::getStatusLabel($empStatus);
            return ['success' => false, 'message' => "Access Denied: Employee status is {$statusLabel}."];
        }

        $empName = $emp['first_name'] . ' ' . $emp['last_name'];

        // P1-001: Biometric Idempotency & Replay Protection (60-second debounce window for real-time punches)
        if (!$skipDebounce && $punchDate === null) {
            $recentPunch = $this->db->table('attendance_logs')
                ->where('employee_id', $employeeId)
                ->groupStart()
                    ->where('date', $today)
                    ->orWhere('date', date('Y-m-d', strtotime('-1 day')))
                ->groupEnd()
                ->orderBy('updated_at', 'DESC')
                ->get()
                ->getRowArray();

            if ($recentPunch && !empty($recentPunch['updated_at'])) {
                $diffSecs = abs(time() - strtotime($recentPunch['updated_at']));
                if ($diffSecs < 60) {
                    return [
                        'success'       => true,
                        'type'          => 'Idempotent-Ignored',
                        'employee_name' => $empName,
                        'employee_code' => $emp['employee_code'],
                        'department'    => $emp['department_name'] ?? 'General',
                        'time'          => $now,
                        'status'        => $recentPunch['status'],
                        'message'       => "[{$method} Idempotency] Duplicate punch ignored within 60-second debounce window."
                    ];
                }
            }
        }

        // P0-003: Check if yesterday has an unclosed overnight shift
        $yesterday = date('Y-m-d', strtotime($today . ' -1 day'));
        $yesterdayLog = $this->db->table('attendance_logs')
            ->where('employee_id', $employeeId)
            ->where('date', $yesterday)
            ->get()
            ->getRowArray();

        $openYesterday = ($yesterdayLog && !empty($yesterdayLog['check_in']) && (empty($yesterdayLog['check_out']) || $yesterdayLog['check_out'] === '00:00:00') && !\App\Models\AttendanceModel::isClosureLog($yesterdayLog));

        // Check if existing log for today
        $existingToday = $this->db->table('attendance_logs')
            ->where('employee_id', $employeeId)
            ->where('date', $today)
            ->get()
            ->getRowArray();

        // Determine if this punch closes yesterday's overnight shift or interacts with today
        if ($openYesterday && (!$existingToday || empty($existingToday['check_in']))) {
            // Check out for yesterday's overnight shift
            if ($this->isAttendanceSettled($employeeId, $yesterday, $yesterdayLog['id'], $companyId)) {
                return ['success' => false, 'message' => 'Attendance for previous overnight shift is settled and locked.'];
            }

            $shiftModel = new \App\Models\ShiftModel();
            $effectiveShift = $shiftModel->resolveEffectiveShift($employeeId, $yesterday, $emp);
            $profile = $this->ruleEngine->resolveEffectiveRuleProfile($yesterday, $emp);
            $dailyRes = $this->ruleEngine->calculateDailyAttendance(
                $yesterday,
                $emp,
                array_merge($yesterdayLog, ['check_in' => $yesterdayLog['check_in'], 'check_out' => $now]),
                $profile,
                $effectiveShift
            );

            $workingHours = $dailyRes['net_hours'];
            $overtimeHours = $dailyRes['daily_overtime_hours'] + $dailyRes['off_day_overtime_hours'] + $dailyRes['holiday_overtime_hours'];
            $earlyOutMinutes = $dailyRes['early_out_minutes'] ?? 0;

            $rosterRef = $effectiveShift['assignment_id'] ?? $effectiveShift['source'] ?? ($yesterdayLog['roster_reference'] ?? 'EMPLOYEE_DEFAULT');
            $updatePayload = [
                'shift_id'              => $effectiveShift['shift_id'] ?? ($yesterdayLog['shift_id'] ?? null),
                'attendance_date'       => $yesterday,
                'shift_date'            => $yesterday,
                'checkout_date'         => $today,
                'roster_reference'      => $rosterRef,
                'schedule_snapshot_json'=> json_encode($effectiveShift),
                'check_out'             => $now,
                'out_time'              => $now,
                'clock_out'             => "{$today} {$now}",
                'gross_hours'           => $dailyRes['gross_hours'] ?? 0.0,
                'break_hours'           => $dailyRes['break_hours'] ?? 0.0,
                'net_hours'             => $workingHours,
                'working_hours'         => $workingHours,
                'regular_hours'         => $dailyRes['regular_hours'] ?? 0.0,
                'overtime_hours'        => $overtimeHours,
                'early_out_minutes'     => $earlyOutMinutes,
                'early_leaving_minutes' => $earlyOutMinutes,
                'day_type'              => $dailyRes['day_type'] ?? 'NORMAL_WORKDAY',
                'ot_approval_status'    => $dailyRes['ot_approval_status'] ?? 'Not Required',
                'is_ot_payable'         => !empty($dailyRes['is_ot_payable']) ? 1 : 0,
                'ot_amount'             => $dailyRes['ot_amount'] ?? 0.00,
                'status'                => $dailyRes['status'],
                'verification_method'   => $method,
                'updated_at'            => date('Y-m-d H:i:s')
            ];

            $tableFields = $this->db->getFieldNames('attendance_logs');
            $safePayload = [];
            foreach ($updatePayload as $col => $val) {
                if (in_array($col, $tableFields, true)) {
                    $safePayload[$col] = $val;
                }
            }

            $this->db->table('attendance_logs')->where('id', $yesterdayLog['id'])->update($safePayload);
            $this->syncAttendancesTable(array_merge($safePayload, ['id' => $yesterdayLog['id']]));

            return [
                'success'       => true,
                'type'          => 'Check-Out (Overnight)',
                'employee_name' => $empName,
                'employee_code' => $emp['employee_code'],
                'department'    => $emp['department_name'] ?? 'General',
                'time'          => $now,
                'status'        => $dailyRes['status'],
                'working_hours' => $workingHours,
                'overtime_hours'=> $overtimeHours,
                'message'       => "[{$method} Success] Overnight Check-Out recorded for {$empName} at {$now}. Total: {$workingHours} hrs (OT: {$overtimeHours} hrs)"
            ];
        }

        if (!$existingToday || empty($existingToday['check_in'])) {
            // First punch of the day -> Check In
            if ($this->isAttendanceSettled($employeeId, $today, null, $companyId)) {
                return ['success' => false, 'message' => 'Attendance for today is settled and locked in payroll.'];
            }

            $shiftModel = new \App\Models\ShiftModel();
            $effectiveShift = $shiftModel->resolveEffectiveShift($employeeId, $today, $emp);
            $isScheduled = !empty($effectiveShift['is_scheduled']) && empty($effectiveShift['is_day_off']) && ($effectiveShift['outcome'] ?? '') !== 'NO_ASSIGNED_SHIFT';
            $shiftStart = ($isScheduled && !empty($effectiveShift['start_time'])) ? strtotime($effectiveShift['start_time']) : null;
            $grace = (int)($effectiveShift['late_grace_period_mins'] ?? ($emp['grace_time'] ?? 0)) * 60;
            $punchTime = strtotime($now);
            $lateMinutes = 0;
            if (!empty($effectiveShift['is_day_off']) || ($effectiveShift['outcome'] ?? '') === 'WEEKLY_OFF' || ($effectiveShift['outcome'] ?? '') === 'ROSTER_DAY_OFF') {
                $status = 'Off-Day Work';
            } elseif (!$isScheduled) {
                $status = 'Present (Unscheduled)';
            } else {
                $status = 'Present';
            }

            if ($isScheduled && $shiftStart !== null && $punchTime > ($shiftStart + $grace)) {
                $lateMinutes = (int)(($punchTime - $shiftStart) / 60);
                $status = 'Late';
            } elseif ($existingToday && \App\Models\AttendanceModel::isClosureLog($existingToday)) {
                $status = 'Present (Early Closure)';
            }

            $rosterRef = $effectiveShift['assignment_id'] ?? $effectiveShift['source'] ?? 'EMPLOYEE_DEFAULT';
            $attendancePayload = [
                'employee_id'            => $employeeId,
                'company_id'             => $emp['company_id'] ?? null,
                'branch_id'              => $emp['branch_id'] ?? null,
                'shift_id'               => $effectiveShift['shift_id'] ?? null,
                'date'                   => $today,
                'attendance_date'        => $today,
                'shift_date'             => $today,
                'checkout_date'          => null,
                'roster_reference'       => $rosterRef,
                'schedule_snapshot_json' => json_encode($effectiveShift),
                'check_in'               => $now,
                'in_time'                => $now,
                'clock_in'               => "{$today} {$now}",
                'late_minutes'           => $lateMinutes,
                'status'                 => $status,
                'day_type'               => !empty($effectiveShift['is_day_off']) ? 'WEEKEND_DUTY' : 'NORMAL_WORKDAY',
                'verification_method'    => $method,
                'is_approved'            => 1,
                'updated_at'             => date('Y-m-d H:i:s')
            ];
            if ($existingToday) {
                $this->db->table('attendance_logs')
                    ->where('id', $existingToday['id'])
                    ->update($attendancePayload);
                $logId = $existingToday['id'];
                $this->syncAttendancesTable(array_merge($attendancePayload, ['id' => $logId]));
            } else {
                $attendancePayload['id'] = 'att-' . bin2hex(random_bytes(8));
                $attendancePayload['created_at'] = date('Y-m-d H:i:s');
                $this->db->table('attendance_logs')->insert($attendancePayload);
                $logId = $attendancePayload['id'];
                $this->syncAttendancesTable($attendancePayload);
            }

            return [
                'success'       => true,
                'type'          => 'Check-In',
                'employee_name' => $empName,
                'employee_code' => $emp['employee_code'],
                'department'    => $emp['department_name'] ?? 'General',
                'time'          => $now,
                'status'        => $status,
                'log_id'        => $logId,
                'message'       => "[{$method} Success] Check-In recorded for {$empName} at {$now}. Status: {$status}"
            ];
        } else {
            // Subsequent punch -> Check Out evaluated via RuleEngineService
            if ($this->isAttendanceSettled($employeeId, $today, $existingToday['id'], $companyId)) {
                return ['success' => false, 'message' => 'Attendance for today is settled and locked in payroll.'];
            }

            // Guard against replaying the exact same check-in timestamp during historical reprocess
            $inTs = strtotime($today . ' ' . $existingToday['check_in']);
            $outTs = strtotime($today . ' ' . $now);
            if ($inTs !== false && $outTs !== false && abs($outTs - $inTs) < 60) {
                return [
                    'success'       => true,
                    'type'          => 'Idempotent-Ignored',
                    'employee_name' => $empName,
                    'employee_code' => $emp['employee_code'],
                    'department'    => $emp['department_name'] ?? 'General',
                    'time'          => $now,
                    'status'        => $existingToday['status'],
                    'log_id'        => $existingToday['id'],
                    'working_hours' => (float)($existingToday['working_hours'] ?? 0.0),
                    'message'       => "[{$method} Idempotency] Duplicate check-in timestamp ignored."
                ];
            }

            $shiftModel = new \App\Models\ShiftModel();
            $effectiveShift = $shiftModel->resolveEffectiveShift($employeeId, $today, $emp);
            $profile = $this->ruleEngine->resolveEffectiveRuleProfile($today, $emp);
            $dailyRes = $this->ruleEngine->calculateDailyAttendance(
                $today,
                $emp,
                array_merge($existingToday, ['check_in' => $existingToday['check_in'], 'check_out' => $now]),
                $profile,
                $effectiveShift
            );

            $workingHours = $dailyRes['net_hours'];
            $overtimeHours = $dailyRes['daily_overtime_hours'] + $dailyRes['off_day_overtime_hours'] + $dailyRes['holiday_overtime_hours'];
            $earlyOutMinutes = $dailyRes['early_out_minutes'] ?? 0;

            $rosterRef = $effectiveShift['assignment_id'] ?? $effectiveShift['source'] ?? ($existingToday['roster_reference'] ?? 'EMPLOYEE_DEFAULT');
            $updatePayload = [
                'shift_id'              => $effectiveShift['shift_id'] ?? ($existingToday['shift_id'] ?? null),
                'attendance_date'       => $existingToday['attendance_date'] ?? $today,
                'shift_date'            => $existingToday['shift_date'] ?? $today,
                'checkout_date'         => $today,
                'roster_reference'      => $rosterRef,
                'schedule_snapshot_json'=> json_encode($effectiveShift),
                'check_out'             => $now,
                'out_time'              => $now,
                'clock_out'             => "{$today} {$now}",
                'gross_hours'           => $dailyRes['gross_hours'] ?? 0.0,
                'break_hours'           => $dailyRes['break_hours'] ?? 0.0,
                'net_hours'             => $workingHours,
                'working_hours'         => $workingHours,
                'regular_hours'         => $dailyRes['regular_hours'] ?? 0.0,
                'overtime_hours'        => $overtimeHours,
                'early_out_minutes'     => $earlyOutMinutes,
                'early_leaving_minutes' => $earlyOutMinutes,
                'day_type'              => $dailyRes['day_type'] ?? 'NORMAL_WORKDAY',
                'ot_approval_status'    => $dailyRes['ot_approval_status'] ?? 'Not Required',
                'is_ot_payable'         => !empty($dailyRes['is_ot_payable']) ? 1 : 0,
                'ot_amount'             => $dailyRes['ot_amount'] ?? 0.00,
                'status'                => $dailyRes['status'],
                'verification_method'   => $method,
                'updated_at'            => date('Y-m-d H:i:s')
            ];

            $tableFields = $this->db->getFieldNames('attendance_logs');
            $safePayload = [];
            foreach ($updatePayload as $col => $val) {
                if (in_array($col, $tableFields, true)) {
                    $safePayload[$col] = $val;
                }
            }

            $this->db->table('attendance_logs')
                ->where('id', $existingToday['id'])
                ->update($safePayload);
            $this->syncAttendancesTable(array_merge($safePayload, ['id' => $existingToday['id']]));

            return [
                'success'       => true,
                'type'          => 'Check-Out',
                'employee_name' => $empName,
                'employee_code' => $emp['employee_code'],
                'department'    => $emp['department_name'] ?? 'General',
                'time'          => $now,
                'status'        => $dailyRes['status'],
                'log_id'        => $existingToday['id'],
                'working_hours' => $workingHours,
                'overtime_hours'=> $overtimeHours,
                'message'       => "[{$method} Success] Check-Out recorded for {$empName} at {$now}. Total: {$workingHours} hrs (OT: {$overtimeHours} hrs)"
            ];
        }
    }

    /**
     * Start a break for an employee
     */
    public function startBreak(string $employeeId): array
    {
        $today = date('Y-m-d');
        $now = date('H:i:s');

        $log = $this->db->table('attendance_logs')
            ->where('employee_id', $employeeId)
            ->where('date', $today)
            ->get()
            ->getRowArray();

        if (!$log || empty($log['check_in'])) {
            return ['success' => false, 'message' => 'Cannot start break without active check-in.'];
        }

        if (function_exists('session')) {
            session()->set("break_start_{$employeeId}_{$today}", time());
        }

        return ['success' => true, 'time' => $now, 'message' => "Break started at {$now}."];
    }

    /**
     * End a break for an employee
     */
    public function endBreak(string $employeeId, ?int $durationMinutes = null): array
    {
        $now = date('H:i:s');
        $today = date('Y-m-d');

        $log = $this->db->table('attendance_logs')
            ->where('employee_id', $employeeId)
            ->where('date', $today)
            ->get()
            ->getRowArray();

        if (!$log) {
            return ['success' => false, 'message' => 'No active attendance record found for today.'];
        }

        if ($durationMinutes === null && function_exists('session') && session()->has("break_start_{$employeeId}_{$today}")) {
            $startTime = session()->get("break_start_{$employeeId}_{$today}");
            session()->remove("break_start_{$employeeId}_{$today}");
            $durationMinutes = max(1, (int)round((time() - $startTime) / 60));
        }

        if ($durationMinutes && $durationMinutes > 0) {
            $currentBreaks = (float)($log['break_hours'] ?? 0);
            $newBreaks = round($currentBreaks + ($durationMinutes / 60), 2);
            $this->db->table('attendance_logs')->where('id', $log['id'])->update([
                'break_hours' => $newBreaks,
                'updated_at'  => date('Y-m-d H:i:s'),
            ]);
        }

        return ['success' => true, 'time' => $now, 'message' => "Break ended at {$now}."];
    }

    /**
     * Save manual attendance record (HR entry) using authoritative RuleEngineService
     */
    public function saveManualLog(array $data): array
    {
        $empId = $data['employee_id'];
        $date = $data['date'] ?? date('Y-m-d');
        $checkIn = !empty($data['check_in']) ? (strlen($data['check_in']) === 5 ? $data['check_in'] . ':00' : $data['check_in']) : null;
        $checkOut = !empty($data['check_out']) ? (strlen($data['check_out']) === 5 ? $data['check_out'] . ':00' : $data['check_out']) : null;
        $statusOverride = $data['status'] ?? null;
        $manualOtGiven = isset($data['overtime_hours']) && $data['overtime_hours'] !== '' && is_numeric($data['overtime_hours']);
        $submittedOtHours = $manualOtGiven ? (float)$data['overtime_hours'] : null;

        // SEC-MOD02-002: Settled Payroll Protection
        if ($this->isAttendanceSettled($empId, $date)) {
            return [
                'success'     => false,
                'status_code' => 422,
                'message'     => "422 Unprocessable Entity: Attendance for employee {$empId} on {$date} is locked and settled in payroll."
            ];
        }

        // 1. Fetch complete employee context
        $emp = null;
        if ($this->db->tableExists('employees')) {
            $builder = $this->db->table('employees')
                ->select('employees.*, departments.name as department_name, designations.name as designation_name, shifts.name as shift_name, shifts.start_time as shift_start_time, shifts.end_time as shift_end_time')
                ->join('departments', 'departments.id = employees.department_id', 'left')
                ->join('designations', 'designations.id = employees.designation_id', 'left')
                ->join('shifts', 'shifts.id = employees.shift_id', 'left');

            $dataCompId = $data['company_id'] ?? null;
            if (!empty($dataCompId)) {
                $builder->where('employees.company_id', $dataCompId)
                    ->groupStart()
                        ->where('employees.id', $empId)
                        ->orWhere('employees.employee_code', $empId)
                    ->groupEnd();
                $emp = $builder->get()->getRowArray();
            } else {
                $emp = $builder->where('employees.id', $empId)->get()->getRowArray();
            }
        }

        if (!$emp) {
            $emp = [
                'id' => $empId,
                'company_id' => $data['company_id'] ?? null,
                'basic_salary' => 25000.0,
                'gross_salary' => 30000.0
            ];
        }

        // 2. Fetch centralized effective shift (P0-004)
        $shiftModel = new \App\Models\ShiftModel();
        $shift = $shiftModel->resolveEffectiveShift($emp['id'], $date, $emp);

        // 3. Fetch leaves & holidays
        $leaves = [];
        if ($this->db->tableExists('leave_applications')) {
            $leaves = $this->db->table('leave_applications')
                ->where('employee_id', $emp['id'])
                ->where('start_date <=', $date)
                ->where('end_date >=', $date)
                ->whereIn('status', ['Approved', 'Confirmed'])
                ->get()
                ->getResultArray();
        }

        $holidays = [];
        if ($this->db->tableExists('holidays')) {
            $hBuilder = $this->db->table('holidays')
                ->where('from_date <=', $date)
                ->where('to_date >=', $date);
            if (!empty($emp['company_id'])) {
                $hBuilder->groupStart()
                    ->where('company_id', $emp['company_id'])
                    ->orWhere('company_id IS NULL')
                ->groupEnd();
            }
            $holidays = $hBuilder->get()->getResultArray();
        }

        $existing = $this->db->table('attendance_logs')
            ->where('employee_id', $emp['id'])
            ->where('date', $date)
            ->get()
            ->getRowArray();

        // 4. Authoritative RuleEngine evaluation
        $profile = $this->ruleEngine->resolveEffectiveRuleProfile($date, $emp);
        $calc = $this->ruleEngine->calculateDailyAttendance(
            $date,
            $emp,
            array_merge($existing ?: [], [
                'check_in' => $checkIn ?: ($existing['check_in'] ?? null),
                'check_out' => $checkOut ?: ($existing['check_out'] ?? null),
                'ot_approval_status' => 'Approved'
            ]),
            $profile,
            $shift,
            $leaves,
            $holidays
        );

        $workingHours = (float)($calc['net_hours'] ?? 0.0);
        $calculatedOt = (float)($calc['daily_overtime_hours'] + $calc['off_day_overtime_hours'] + $calc['holiday_overtime_hours']);
        
        $isManualOverride = 0;
        $manualOtHours = 0.0;
        if ($manualOtGiven && abs($submittedOtHours - $calculatedOt) > 0.001) {
            $isManualOverride = 1;
            $manualOtHours = $submittedOtHours;
            $effectiveOtHours = $submittedOtHours;
            $effectiveOtAmount = round($effectiveOtHours * ($calc['ot_rate'] ?: 125.0), 2);
        } else {
            $effectiveOtHours = $manualOtGiven ? $submittedOtHours : $calculatedOt;
            $effectiveOtAmount = (float)($calc['ot_amount'] ?? 0.0);
        }

        $finalStatus = (!empty($statusOverride) && $statusOverride !== 'Present') ? $statusOverride : ($calc['status'] ?? 'Present');
        $dayType = $calc['day_type'] ?? 'NORMAL_WORKDAY';

        $isOvernight = false;
        if (!empty($checkIn) && !empty($checkOut)) {
            $inM = RuleEngineService::timeStringToMinutes($checkIn);
            $outM = RuleEngineService::timeStringToMinutes($checkOut);
            $isOvernight = ($outM < $inM) || !empty($shift['is_night_shift']) || !empty($shift['is_cross_midnight']);
        }
        $checkoutDate = $checkOut ? ($isOvernight ? date('Y-m-d', strtotime($date . ' +1 day')) : $date) : null;
        $clockOut = $checkOut ? "{$checkoutDate} {$checkOut}" : ($existing['clock_out'] ?? null);

        $rosterRef = $shift['assignment_id'] ?? $shift['source'] ?? 'EMPLOYEE_DEFAULT';

        $logData = [
            'shift_id'              => $shift['shift_id'] ?? null,
            'attendance_date'       => $date,
            'shift_date'            => $date,
            'checkout_date'         => $checkoutDate,
            'roster_reference'      => $rosterRef,
            'schedule_snapshot_json'=> json_encode($shift),
            'check_in'              => $checkIn ?: ($existing['check_in'] ?? null),
            'check_out'             => $checkOut ?: ($existing['check_out'] ?? null),
            'in_time'               => $checkIn ?: ($existing['in_time'] ?? null),
            'out_time'              => $checkOut ?: ($existing['out_time'] ?? null),
            'clock_in'              => $checkIn ? "{$date} {$checkIn}" : ($existing['clock_in'] ?? null),
            'clock_out'             => $clockOut,
            'gross_hours'           => (float)($calc['gross_hours'] ?? 0.0),
            'break_hours'           => (float)($calc['break_hours'] ?? 0.0),
            'net_hours'             => $workingHours,
            'working_hours'         => $workingHours,
            'regular_hours'         => (float)($calc['regular_hours'] ?? 0.0),
            'overtime_hours'        => $effectiveOtHours,
            'manual_overtime_hours' => $manualOtHours,
            'is_manual_override'    => $isManualOverride,
            'late_minutes'          => (int)($calc['late_minutes'] ?? 0),
            'early_out_minutes'     => (int)($calc['early_out_minutes'] ?? 0),
            'early_leaving_minutes' => (int)($calc['early_out_minutes'] ?? 0),
            'status'                => $finalStatus,
            'day_type'              => $dayType,
            'ot_approval_status'    => ($effectiveOtHours > 0) ? 'Approved' : 'Not Required',
            'is_ot_payable'         => ($effectiveOtHours > 0) ? 1 : 0,
            'ot_amount'             => $effectiveOtAmount,
            'verification_method'   => 'Manual',
            'is_approved'           => 1,
            'remarks'               => $isManualOverride ? "Manual OT override ({$manualOtHours}h vs auto {$calculatedOt}h)" : 'Manual HR Entry processed via Rule Engine',
            'updated_at'            => date('Y-m-d H:i:s')
        ];

        // Safe insertion/update matching existing table fields
        $tableFields = $this->db->getFieldNames('attendance_logs');
        $safeData = [];
        foreach ($logData as $col => $val) {
            if (in_array($col, $tableFields, true)) {
                $safeData[$col] = $val;
            }
        }

        if ($existing) {
            $this->db->table('attendance_logs')->where('id', $existing['id'])->update($safeData);
            $this->syncAttendancesTable(array_merge($safeData, ['id' => $existing['id']]));
            return [
                'success' => true,
                'message' => "Attendance record updated successfully via Rule Engine. (Working: {$workingHours}h, OT: {$effectiveOtHours}h)."
            ];
        } else {
            $safeData['id'] = 'att-' . bin2hex(random_bytes(8));
            $safeData['employee_id'] = $emp['id'];
            $safeData['company_id'] = $emp['company_id'] ?? null;
            $safeData['branch_id'] = $emp['branch_id'] ?? null;
            $safeData['shift_id'] = $shift['shift_id'] ?? ($emp['shift_id'] ?? null);
            $safeData['date'] = $date;
            $safeData['created_at'] = date('Y-m-d H:i:s');
            $this->db->table('attendance_logs')->insert($safeData);
            $this->syncAttendancesTable($safeData);
            return [
                'success' => true,
                'message' => "Attendance record created successfully via Rule Engine. (Working: {$workingHours}h, OT: {$effectiveOtHours}h)."
            ];
        }
    }

    /**
     * Recalculate daily attendance for an employee on a specific date using authoritative RuleEngineService
     */
    public function recalculateDailyAttendance(string $employeeId, string $date, ?string $companyId = null): array
    {
        // 1. Check settled payroll protection
        if ($this->isAttendanceSettled($employeeId, $date, null, $companyId)) {
            return [
                'success'     => false,
                'status_code' => 422,
                'message'     => "Attendance for employee {$employeeId} on {$date} is settled and locked in payroll."
            ];
        }

        // 2. Fetch employee profile
        $emp = $this->db->table('employees')
            ->select('employees.*, departments.name as department_name, designations.name as designation_name, shifts.start_time, shifts.end_time, ' . $this->getShiftGraceField())
            ->join('departments', 'departments.id = employees.department_id', 'left')
            ->join('designations', 'designations.id = employees.designation_id', 'left')
            ->join('shifts', 'shifts.id = employees.shift_id', 'left')
            ->where('employees.id', $employeeId);
        if (!empty($companyId)) {
            $emp->where('employees.company_id', $companyId);
        }
        $empData = $emp->get()->getRowArray();
        if (!$empData) {
            return ['success' => false, 'message' => 'Employee profile not found.'];
        }
        $companyId = $companyId ?? ($empData['company_id'] ?? null);

        // 3. Fetch existing attendance log
        $existing = $this->db->table('attendance_logs')
            ->where('employee_id', $employeeId)
            ->where('date', $date)
            ->get()
            ->getRowArray();

        // 4. Resolve effective shift via centralized shift resolution (Phase 3)
        $shiftModel = new \App\Models\ShiftModel();
        $effectiveShift = $shiftModel->resolveEffectiveShift($employeeId, $date, $empData);

        // 5. Fetch leaves & holidays
        $leaves = [];
        if ($this->db->tableExists('leave_applications')) {
            $leaves = $this->db->table('leave_applications')
                ->where('employee_id', $employeeId)
                ->where('start_date <=', $date)
                ->where('end_date >=', $date)
                ->whereIn('status', ['Approved', 'Confirmed'])
                ->get()
                ->getResultArray();
        }

        $holidays = [];
        if ($this->db->tableExists('holidays')) {
            $hBuilder = $this->db->table('holidays')
                ->where('from_date <=', $date)
                ->where('to_date >=', $date);
            if (!empty($companyId)) {
                $hBuilder->groupStart()
                    ->where('company_id', $companyId)
                    ->orWhere('company_id IS NULL')
                ->groupEnd();
            }
            $holidays = $hBuilder->get()->getResultArray();
        }

        // 6. Calculate via RuleEngineService
        $profile = $this->ruleEngine->resolveEffectiveRuleProfile($date, $empData);
        $calc = $this->ruleEngine->calculateDailyAttendance(
            $date,
            $empData,
            $existing ?: [],
            $profile,
            $effectiveShift,
            $leaves,
            $holidays
        );

        $checkIn = $existing['check_in'] ?? null;
        $checkOut = $existing['check_out'] ?? null;
        $isOvernight = false;
        if (!empty($checkIn) && !empty($checkOut)) {
            $inM = RuleEngineService::timeStringToMinutes($checkIn);
            $outM = RuleEngineService::timeStringToMinutes($checkOut);
            $isOvernight = ($outM < $inM) || !empty($effectiveShift['is_night_shift']) || !empty($effectiveShift['is_cross_midnight']);
        }
        $checkoutDate = $checkOut ? ($isOvernight ? date('Y-m-d', strtotime($date . ' +1 day')) : $date) : null;

        $workingHours = (float)($calc['net_hours'] ?? 0.0);
        $overtimeHours = (float)($calc['daily_overtime_hours'] + $calc['off_day_overtime_hours'] + $calc['holiday_overtime_hours']);
        $rosterRef = $effectiveShift['assignment_id'] ?? $effectiveShift['source'] ?? ($existing['roster_reference'] ?? 'EMPLOYEE_DEFAULT');

        $payload = [
            'shift_id'               => $effectiveShift['shift_id'] ?? ($existing['shift_id'] ?? null),
            'attendance_date'        => $date,
            'shift_date'             => $date,
            'checkout_date'          => $checkoutDate,
            'roster_reference'       => $rosterRef,
            'schedule_snapshot_json' => json_encode($effectiveShift),
            'gross_hours'            => (float)($calc['gross_hours'] ?? 0.0),
            'break_hours'            => (float)($calc['break_hours'] ?? 0.0),
            'net_hours'              => $workingHours,
            'working_hours'          => $workingHours,
            'regular_hours'          => (float)($calc['regular_hours'] ?? 0.0),
            'overtime_hours'         => $overtimeHours,
            'late_minutes'           => (int)($calc['late_minutes'] ?? 0),
            'early_out_minutes'      => (int)($calc['early_out_minutes'] ?? 0),
            'early_leaving_minutes'  => (int)($calc['early_out_minutes'] ?? 0),
            'status'                 => $calc['status'],
            'day_type'               => $calc['day_type'] ?? 'NORMAL_WORKDAY',
            'ot_approval_status'     => $calc['ot_approval_status'] ?? 'Not Required',
            'is_ot_payable'          => !empty($calc['is_ot_payable']) ? 1 : 0,
            'ot_amount'              => (float)($calc['ot_amount'] ?? 0.00),
            'updated_at'             => date('Y-m-d H:i:s')
        ];

        $tableFields = $this->db->getFieldNames('attendance_logs');
        $safePayload = [];
        foreach ($payload as $col => $val) {
            if (in_array($col, $tableFields, true)) {
                $safePayload[$col] = $val;
            }
        }

        if ($existing) {
            $this->db->table('attendance_logs')->where('id', $existing['id'])->update($safePayload);
            $logId = $existing['id'];
        } else {
            $logId = 'att-' . bin2hex(random_bytes(8));
            $safePayload['id'] = $logId;
            $safePayload['employee_id'] = $employeeId;
            $safePayload['company_id'] = $companyId;
            $safePayload['branch_id'] = $empData['branch_id'] ?? null;
            $safePayload['date'] = $date;
            $safePayload['verification_method'] = 'Recalculation';
            $safePayload['is_approved'] = 1;
            $safePayload['created_at'] = date('Y-m-d H:i:s');
            $this->db->table('attendance_logs')->insert($safePayload);
        }

        $this->syncAttendancesTable(array_merge($safePayload, ['id' => $logId]));

        return [
            'success' => true,
            'message' => "Attendance for {$empData['first_name']} on {$date} recalculated successfully. Working hours: {$workingHours}h, OT: {$overtimeHours}h.",
            'data'    => array_merge(['id' => $logId], $safePayload)
        ];
    }
}

