<?php

namespace App\Services;

use App\Models\EmployeeModel;
use App\Models\EmploymentTypeModel;
use App\Models\LeaveTypeModel;
use App\Models\ProbationAuditLogModel;
use App\Services\NotificationService;

class ProbationLeaveEligibilityService
{
    protected EmployeeModel $employeeModel;
    protected EmploymentTypeModel $employmentTypeModel;
    protected LeaveTypeModel $leaveTypeModel;
    protected ProbationAuditLogModel $auditLogModel;
    protected NotificationService $notificationService;

    public function __construct()
    {
        $this->employeeModel       = new EmployeeModel();
        $this->employmentTypeModel = new EmploymentTypeModel();
        $this->leaveTypeModel      = new LeaveTypeModel();
        $this->auditLogModel       = new ProbationAuditLogModel();
        $this->notificationService = new NotificationService();
    }

    /**
     * Calculate probation end date from start date and duration.
     * Example:
     * Joining Date: 2026-01-01, Duration: 3 Months
     * Probation End Date: 2026-03-31
     * First Eligible Date (completion + 1 day): 2026-04-01
     */
    public function calculateProbationEndDate(string $startDate, int $durationValue, string $durationUnit = 'Months'): string
    {
        if (empty($startDate) || $durationValue <= 0) {
            return $startDate;
        }

        try {
            $dt = new \DateTime($startDate);
            $unit = ucfirst(strtolower(trim($durationUnit)));

            if ($unit === 'Days' || $unit === 'Day') {
                $days = max(0, $durationValue - 1);
                $dt->modify("+{$days} days");
            } elseif ($unit === 'Months' || $unit === 'Month') {
                $dt->modify("+{$durationValue} months");
                $dt->modify("-1 day");
            } elseif ($unit === 'Years' || $unit === 'Year') {
                $dt->modify("+{$durationValue} years");
                $dt->modify("-1 day");
            } else {
                $dt->modify("+{$durationValue} months");
                $dt->modify("-1 day");
            }

            return $dt->format('Y-m-d');
        } catch (\Throwable $e) {
            return $startDate;
        }
    }

    /**
     * Calculate eligibility date based on rule and employee start date.
     */
    public function calculateWaitingPeriodDate(string $startDate, int $waitingValue, string $waitingUnit = 'Months'): string
    {
        if (empty($startDate) || $waitingValue <= 0) {
            return $startDate;
        }

        try {
            $dt = new \DateTime($startDate);
            $unit = ucfirst(strtolower(trim($waitingUnit)));

            if ($unit === 'Days' || $unit === 'Day') {
                $dt->modify("+{$waitingValue} days");
            } elseif ($unit === 'Months' || $unit === 'Month') {
                $dt->modify("+{$waitingValue} months");
            } elseif ($unit === 'Years' || $unit === 'Year') {
                $dt->modify("+{$waitingValue} years");
            } else {
                $dt->modify("+{$waitingValue} months");
            }

            return $dt->format('Y-m-d');
        } catch (\Throwable $e) {
            return $startDate;
        }
    }

    /**
     * Resolve effective employee probation details.
     */
    public function resolveEmployeeProbationState(array $employee): array
    {
        $joinDate = employee_joining_date($employee) ?? $employee['employment_start_date'] ?? date('Y-m-d');
        $probationStart = $employee['probation_start_date'] ?? $joinDate;
        
        // Duration: from employee, or from employment type
        $durationValue = !empty($employee['probation_duration_value']) ? (int)$employee['probation_duration_value'] : null;
        $durationUnit  = !empty($employee['probation_duration_unit']) ? $employee['probation_duration_unit'] : 'Months';

        // Check if employment type provides default duration
        $empType = null;
        $empTypeId = $employee['employment_type_id'] ?? null;
        if (!empty($empTypeId)) {
            try {
                $empType = $this->employmentTypeModel->find($empTypeId);
            } catch (\Throwable $e) {}
        }

        if ($durationValue === null && $empType && !empty($empType['duration_value'])) {
            $durationValue = (int)$empType['duration_value'];
            $durationUnit  = $empType['duration_unit'] ?? 'Months';
        }

        // Calculate standard probation end date only if duration is available
        $calculatedEndDate = $durationValue !== null ? $this->calculateProbationEndDate($probationStart, $durationValue, $durationUnit) : null;
        $probationEnd = !empty($employee['probation_end_date'])
            ? $employee['probation_end_date']
            : (!empty($employee['employment_end_date']) ? $employee['employment_end_date'] : $calculatedEndDate);

        // Check for extension
        $isExtended = false;
        if (!empty($employee['probation_extended_date'])) {
            $probationEnd = $employee['probation_extended_date'];
            $isExtended = true;
        }

        // Check for early confirmation (check both probation_confirmed_date and confirmation_date)
        $isEarlyConfirmed = false;
        $confirmedDate = $employee['probation_confirmed_date'] ?? $employee['confirmation_date'] ?? null;
        if (!empty($confirmedDate)) {
            $isEarlyConfirmed = true;
        }

        // Determine if employee is under probation
        $statusStr = strtolower(trim($employee['status'] ?? ''));
        $empPeriodStatus = strtolower(trim($employee['employment_period_status'] ?? ''));
        $probStatus = strtolower(trim($employee['probation_status'] ?? ''));

        $isUnderProbation = false;
        if ($isEarlyConfirmed) {
            $isUnderProbation = false;
        } elseif (in_array($probStatus, ['completed', 'confirmed', 'not applicable', 'cancelled'], true)) {
            $isUnderProbation = false;
        } elseif (in_array($statusStr, ['probation', 'on probation'], true) || $empPeriodStatus === 'probation' || in_array($probStatus, ['active', 'pending', 'extended', 'on probation'], true)) {
            $isUnderProbation = true;
        } elseif ($empType && (stripos($empType['name'] ?? '', 'probation') !== false || stripos($empType['code'] ?? '', 'prob') !== false)) {
            $isUnderProbation = true;
        }

        // Probation is only completed when formally confirmed or marked Completed/Confirmed
        $isCompleted = ($isEarlyConfirmed || in_array($probStatus, ['completed', 'confirmed'], true) || !empty($confirmedDate));

        // Date from which employee becomes eligible for post-probation leave
        $postProbationEligibilityDate = date('Y-m-d', strtotime($probationEnd . ' +1 day'));
        if ($isEarlyConfirmed && !empty($confirmedDate)) {
            $postProbationEligibilityDate = $confirmedDate;
        }

        return [
            'employee_id'                    => $employee['id'] ?? '',
            'employee_name'                  => trim(($employee['first_name'] ?? '') . ' ' . ($employee['last_name'] ?? '')),
            'join_date'                      => $joinDate,
            'probation_start_date'           => $probationStart,
            'probation_end_date'             => $probationEnd,
            'probation_duration_value'       => $durationValue,
            'probation_duration_unit'        => $durationUnit,
            'post_probation_eligibility_date'=> $postProbationEligibilityDate,
            'is_under_probation'             => $isUnderProbation,
            'is_extended'                    => $isExtended,
            'extended_date'                  => $employee['probation_extended_date'] ?? null,
            'is_early_confirmed'             => $isEarlyConfirmed,
            'confirmed_date'                 => $confirmedDate,
            'is_completed'                   => $isCompleted,
            'probation_status'               => $isCompleted ? 'Confirmed' : ($isExtended ? 'Extended' : ($isUnderProbation ? 'On Probation' : 'Regular')),
            'overrides'                      => !empty($employee['leave_eligibility_overrides']) ? json_decode($employee['leave_eligibility_overrides'], true) : []
        ];
    }

    /**
     * Resolve the active eligibility rule for a given leave type and employee.
     * Reads strictly from the Single Rule Store (domain: LEAVE -> probation.eligibility_rules).
     */
    public function resolveEligibilityRule(string $leaveTypeId, ?string $employmentTypeId = null, ?string $companyId = null, ?string $policyId = null): array
    {
        if (empty($companyId) && function_exists('session') && session()->has('company_id')) {
            $companyId = session()->get('company_id');
        }
        if (empty($companyId)) {
            $ltRow = $this->leaveTypeModel->find($leaveTypeId);
            $companyId = $ltRow['company_id'] ?? null;
        }
        if (empty($companyId)) {
            throw new \App\Services\Rules\RuleNotConfiguredException(
                "Company ID context is required to resolve LEAVE eligibility rules for leave type '{$leaveTypeId}'.",
                null,
                'LEAVE',
                date('Y-m-d')
            );
        }

        $leaveRule = \App\Services\Rules\RuleResolver::resolveForCompany($companyId, 'LEAVE', date('Y-m-d'));
        $probation = $leaveRule->get('probation') ?: [];
        $eligibilityRules = $probation['eligibility_rules'] ?? [];

        $lt = $this->leaveTypeModel->find($leaveTypeId);
        $ltCode = strtoupper(trim((string)($lt['code'] ?? '')));
        $ltName = $lt['name'] ?? ($ltCode ?: 'Leave');

        if (!empty($eligibilityRules) && is_array($eligibilityRules)) {
            foreach ($eligibilityRules as $er) {
                $matchesType = (($er['leave_type_id'] ?? '') === $leaveTypeId) ||
                               (strtoupper(trim((string)($er['leave_type_code'] ?? ''))) === $ltCode);
                if (!$matchesType) {
                    continue;
                }
                if ($employmentTypeId && !empty($er['employment_type_id']) && $er['employment_type_id'] !== $employmentTypeId) {
                    continue;
                }
                return [
                    'id'                   => $er['id'] ?? ('rule-pler-' . ($er['leave_type_code'] ?? $leaveTypeId)),
                    'leave_type_id'        => $leaveTypeId,
                    'leave_type_name'      => $ltName,
                    'leave_type_code'      => $er['leave_type_code'] ?? $ltCode,
                    'employment_type_id'   => $er['employment_type_id'] ?? $employmentTypeId,
                    'eligibility_mode'     => $er['eligibility_mode'] ?? 'after_probation',
                    'waiting_period_value' => (int)($er['waiting_period_value'] ?? 0),
                    'waiting_period_unit'  => $er['waiting_period_unit'] ?? 'Months',
                    'accrual_start_mode'   => $er['accrual_start_mode'] ?? 'from_joining',
                    'allow_advance_leave'  => !empty($er['allow_advance_leave']) ? 1 : 0,
                    'blocked_message'      => $er['blocked_message'] ?? null,
                    'status'               => 'active'
                ];
            }
        }

        // Derive eligibility from unified LEAVE probation rule parameters
        $blockedCodes = array_map('strtoupper', (array)($probation['blocked_leave_type_codes'] ?? []));
        $allowedCodes = array_map('strtoupper', (array)($probation['allowed_leave_type_codes'] ?? []));
        $canApplyInProbation = !empty($probation['can_apply_during_probation']);

        if (in_array($ltCode, $blockedCodes, true)) {
            $mode = 'after_probation';
            $blockedMsg = "{$ltName} is restricted during the evaluation period according to company leave rules.";
        } elseif (in_array($ltCode, $allowedCodes, true)) {
            $mode = 'immediately';
            $blockedMsg = null;
        } elseif (!$canApplyInProbation) {
            $mode = 'after_probation';
            $blockedMsg = "Leave applications are restricted during the probation period according to company leave rules.";
        } else {
            $mode = 'immediately';
            $blockedMsg = null;
        }

        return [
            'id'                   => 'rule-pler-' . ($ltCode ?: $leaveTypeId),
            'leave_type_id'        => $leaveTypeId,
            'leave_type_name'      => $ltName,
            'leave_type_code'      => $ltCode,
            'employment_type_id'   => $employmentTypeId,
            'eligibility_mode'     => $mode,
            'waiting_period_value' => 0,
            'waiting_period_unit'  => 'Months',
            'accrual_start_mode'   => !empty($probation['accrue_during_probation']) ? 'from_joining' : 'after_probation',
            'allow_advance_leave'  => 0,
            'blocked_message'      => $blockedMsg,
            'status'               => 'active'
        ];
    }

    /**
     * Deep check leave eligibility for an employee applying on a specific date.
     * Evaluates:
     * - Probation state (joining date, probation duration, completion date)
     * - Extension or early confirmation
     * - Employee-level override
     * - Leave type rule (immediately, after_probation, waiting_period, blocked)
     * - Waiting period elapsed state
     * - Returns exact blocked reason if ineligible
     */
    public function checkLeaveEligibility(
        string $employeeId,
        string $leaveTypeId,
        string $leaveStartDate,
        ?string $policyId = null,
        ?string $companyId = null
    ): array {
        $employee = $this->employeeModel->find($employeeId);
        if (!$employee) {
            return [
                'is_eligible'    => false,
                'blocked_reason' => 'Employee record not found.',
                'rule'           => null
            ];
        }

        $leaveType = $this->leaveTypeModel->find($leaveTypeId);
        $leaveTypeName = $leaveType['name'] ?? 'Requested Leave';

        // Gender eligibility check
        $genderCheck = \App\Services\LeaveService::checkGenderEligibility($employee, $leaveType ?: $leaveTypeId);
        if (!$genderCheck['eligible']) {
            return [
                'is_eligible'          => false,
                'blocked_reason'       => $genderCheck['reason'],
                'is_gender_restricted' => true,
                'rule'                 => null,
                'probation_state'      => null,
            ];
        }

        $companyId = $companyId ?: ($employee['company_id'] ?? null);
        $probState = $this->resolveEmployeeProbationState($employee);

        // 1. Check Employee-level override
        if (!empty($probState['overrides']) && is_array($probState['overrides'])) {
            foreach ($probState['overrides'] as $ov) {
                if (($ov['leave_type_id'] ?? '') === $leaveTypeId || ($ov['leave_type_name'] ?? '') === $leaveTypeName) {
                    $ovStatus = strtolower($ov['override_status'] ?? 'eligible');
                    $ovDate = $ov['effective_date'] ?? null;

                    if ($ovStatus === 'eligible') {
                        if (empty($ovDate) || $leaveStartDate >= $ovDate) {
                            return [
                                'is_eligible'          => true,
                                'blocked_reason'       => null,
                                'override_applied'     => true,
                                'override_reason'      => $ov['reason'] ?? 'HR Approved Override',
                                'probation_state'      => $probState,
                                'calculated_end_date'  => $probState['probation_end_date'],
                                'eligibility_date'     => $leaveStartDate
                            ];
                        }
                    } elseif ($ovStatus === 'blocked') {
                        return [
                            'is_eligible'          => false,
                            'blocked_reason'       => $ov['reason'] ?: "{$leaveTypeName} is restricted by HR employee-level override.",
                            'override_applied'     => true,
                            'probation_state'      => $probState
                        ];
                    }
                }
            }
        }

        // 2. If employee is NOT on probation (e.g. Regular, Completed, or Early Confirmed), they are eligible
        // UNLESS the leave date is in the past during their probation period
        $rule = $this->resolveEligibilityRule($leaveTypeId, $employee['employment_type_id'] ?? null, $companyId, $policyId);
        $mode = $rule['eligibility_mode'] ?? 'after_probation';

        // 3. Evaluate based on rule mode
        if ($mode === 'immediately') {
            return [
                'is_eligible'         => true,
                'blocked_reason'      => null,
                'eligibility_mode'    => 'immediately',
                'rule'                => $rule,
                'probation_state'     => $probState,
                'eligibility_date'    => $probState['join_date']
            ];
        }

        if ($mode === 'blocked') {
            return [
                'is_eligible'         => false,
                'blocked_reason'      => $rule['blocked_message'] ?: "{$leaveTypeName} is blocked during evaluation.",
                'eligibility_mode'    => 'blocked',
                'rule'                => $rule,
                'probation_state'     => $probState
            ];
        }

        if ($mode === 'waiting_period') {
            $waitingValue = (int)($rule['waiting_period_value'] ?? 1);
            $waitingUnit  = $rule['waiting_period_unit'] ?? 'Months';
            $eligibleDate = $this->calculateWaitingPeriodDate($probState['join_date'], $waitingValue, $waitingUnit);

            if ($leaveStartDate < $eligibleDate) {
                $customMsg = !empty($rule['blocked_message']) 
                    ? str_replace(['{leave_type}', '{date}'], [$leaveTypeName, $eligibleDate], $rule['blocked_message'])
                    : "{$leaveTypeName} is not available until {$eligibleDate} (waiting period: {$waitingValue} {$waitingUnit} from joining date).";
                return [
                    'is_eligible'         => false,
                    'blocked_reason'      => $customMsg,
                    'eligibility_mode'    => 'waiting_period',
                    'rule'                => $rule,
                    'eligibility_date'    => $eligibleDate,
                    'probation_state'     => $probState
                ];
            }

            return [
                'is_eligible'         => true,
                'blocked_reason'      => null,
                'eligibility_mode'    => 'waiting_period',
                'rule'                => $rule,
                'eligibility_date'    => $eligibleDate,
                'probation_state'     => $probState
            ];
        }

        if ($mode === 'after_probation' || $mode === 'after_confirmation') {
            // Check if employee has completed probation by the requested leave start date
            $probationEnd = $probState['probation_end_date'];
            $firstEligibleDate = $probState['post_probation_eligibility_date'];

            // If confirmed early, check confirmation date
            if ($probState['is_early_confirmed'] && !empty($probState['confirmed_date'])) {
                if ($leaveStartDate >= $probState['confirmed_date']) {
                    return [
                        'is_eligible'         => true,
                        'blocked_reason'      => null,
                        'eligibility_mode'    => $mode,
                        'rule'                => $rule,
                        'eligibility_date'    => $probState['confirmed_date'],
                        'probation_state'     => $probState,
                        'notes'               => 'Early confirmation applied'
                    ];
                }
            }

            // If leave start date falls within probation period (<= probation_end_date)
            if ($leaveStartDate <= $probationEnd) {
                $customMsg = !empty($rule['blocked_message'])
                    ? str_replace(['{leave_type}', '{date}'], [$leaveTypeName, $firstEligibleDate], $rule['blocked_message'])
                    : "{$leaveTypeName} is not available until your probation period is completed.";

                return [
                    'is_eligible'         => false,
                    'blocked_reason'      => $customMsg,
                    'eligibility_mode'    => $mode,
                    'rule'                => $rule,
                    'eligibility_date'    => $firstEligibleDate,
                    'probation_end_date'  => $probationEnd,
                    'probation_state'     => $probState
                ];
            }

            // Otherwise, leaveStartDate is after probation completion date! Automatically eligible!
            return [
                'is_eligible'         => true,
                'blocked_reason'      => null,
                'eligibility_mode'    => $mode,
                'rule'                => $rule,
                'eligibility_date'    => $firstEligibleDate,
                'probation_end_date'  => $probationEnd,
                'probation_state'     => $probState
            ];
        }

        return [
            'is_eligible'     => true,
            'blocked_reason'  => null,
            'rule'            => $rule,
            'probation_state' => $probState
        ];
    }

    /**
     * Extend probation for an employee.
     * Automatically recalculates probation end date and eligibility date, logs audit trail, and dispatches notifications.
     */
    public function extendProbation(
        string $employeeId,
        string $newEndDate,
        ?string $reason = null,
        ?string $actorId = null,
        ?string $actorName = null
    ): array {
        $employee = $this->employeeModel->find($employeeId);
        if (!$employee) {
            return ['success' => false, 'message' => 'Employee not found.'];
        }

        $rawStatus  = strtolower(trim((string)($employee['status'] ?? '')));
        $probStatus = trim((string)($employee['probation_status'] ?? ''));

        // Refuse inactive, terminated, or resigned employees
        if (in_array($rawStatus, ['terminated', 'resigned', 'inactive'], true)) {
            return ['success' => false, 'message' => "Cannot extend probation: Employee is currently {$rawStatus}."];
        }

        if (in_array($probStatus, ['Completed', 'Confirmed', 'Cancelled'], true)) {
            return ['success' => false, 'message' => "Cannot extend probation: Probation is already {$probStatus}."];
        }

        // Validate new_end_date is a valid date
        if (empty($newEndDate) || !strtotime($newEndDate)) {
            return ['success' => false, 'message' => 'A valid new probation end date format is required (YYYY-MM-DD).'];
        }

        $newEndStr    = date('Y-m-d', strtotime($newEndDate));
        $oldProbState = $this->resolveEmployeeProbationState($employee);
        $prevEndDate  = $oldProbState['probation_end_date'] ?? $employee['probation_end_date'] ?? null;

        // Validate new_end_date is strictly later than the current probation end date
        if (!empty($prevEndDate)) {
            $prevEndStr = date('Y-m-d', strtotime($prevEndDate));
            if ($newEndStr <= $prevEndStr) {
                return [
                    'success' => false,
                    'message' => "New probation end date ({$newEndStr}) must be strictly later than current probation end date ({$prevEndStr})."
                ];
            }
        }

        $db = \Config\Database::connect();
        $db->transBegin();

        try {
            $updateData = [
                'probation_extended_date' => $newEndStr,
                'probation_end_date'      => $newEndStr,
                'probation_status'        => 'Extended',
                'probation_notes'         => ($employee['probation_notes'] ?? '') . "\n[" . date('Y-m-d') . "] Probation extended to {$newEndStr} by {$actorName}. Reason: {$reason}"
            ];

            $this->employeeModel->update($employeeId, $updateData);

            // Audit log
            $this->auditLogModel->insert([
                'id'                => 'pal-' . bin2hex(random_bytes(6)),
                'employee_id'       => $employeeId,
                'company_id'        => $employee['company_id'] ?? null,
                'action_type'       => 'Probation Extended',
                'previous_end_date' => $prevEndDate,
                'new_end_date'      => $newEndStr,
                'previous_status'   => $oldProbState['probation_status'] ?? $probStatus,
                'new_status'        => 'Extended',
                'reason'            => $reason,
                'details'           => "Probation extended from " . ($prevEndDate ?: 'N/A') . " to {$newEndStr}. Next eligible leave date automatically updated.",
                'performed_by'      => $actorId,
                'performed_by_name' => $actorName ?: 'HR Admin',
                'created_at'        => date('Y-m-d H:i:s')
            ]);

            $db->transCommit();
        } catch (\Throwable $e) {
            $db->transRollback();
            return ['success' => false, 'message' => 'Failed to extend probation: ' . $e->getMessage()];
        }

        // Send notification
        try {
            $this->notificationService->createNotification([
                'user_id'     => $employee['user_id'] ?? null,
                'company_id'  => $employee['company_id'] ?? null,
                'type'        => 'probation_extended',
                'title'       => 'Probation Period Extended',
                'message'     => "Your probation evaluation period has been extended until {$newEndStr}.",
                'data'        => json_encode(['new_end_date' => $newEndStr, 'reason' => $reason])
            ]);
        } catch (\Throwable $e) {}

        return [
            'success'          => true,
            'message'          => "Probation extended successfully to {$newEndStr}. Leave eligibility dates automatically recalculated.",
            'new_end_date'     => $newEndStr,
            'eligibility_date' => date('Y-m-d', strtotime($newEndStr . ' +1 day'))
        ];
    }

    /**
     * Early confirm employee from probation.
     * Automatically unlocks leave types that require post-probation confirmation.
     */
    public function earlyConfirm(
        string $employeeId,
        string $confirmationDate,
        ?string $reason = null,
        ?string $actorId = null,
        ?string $actorName = null
    ): array {
        $employee = $this->employeeModel->find($employeeId);
        if (!$employee) {
            return ['success' => false, 'message' => 'Employee not found.'];
        }

        $rawStatus  = strtolower(trim((string)($employee['status'] ?? '')));
        $probStatus = trim((string)($employee['probation_status'] ?? ''));

        // Refuse terminated, resigned, or inactive employees
        if (in_array($rawStatus, ['terminated', 'resigned', 'inactive'], true)) {
            return ['success' => false, 'message' => "Cannot confirm probation: Employee is currently {$rawStatus}."];
        }

        // Only allow when employee status is 'probation' (or 'on_leave' during probation)
        $allowedStatuses = [\App\Models\EmployeeModel::STATUS_PROBATION, \App\Models\EmployeeModel::STATUS_ON_LEAVE];
        $isOnProbation   = in_array($rawStatus, $allowedStatuses, true)
            || in_array($probStatus, ['Active', 'Pending', 'Extended', 'On Probation'], true);

        if (!$isOnProbation && $rawStatus !== \App\Models\EmployeeModel::STATUS_PROBATION) {
            return ['success' => false, 'message' => "Cannot confirm probation: Employee status is '{$employee['status']}' (not on probation)."];
        }

        // Validate confirmation_date
        if (empty($confirmationDate) || !strtotime($confirmationDate)) {
            return ['success' => false, 'message' => 'A valid confirmation date format is required (YYYY-MM-DD).'];
        }

        $confDateStr = date('Y-m-d', strtotime($confirmationDate));
        $todayStr    = date('Y-m-d');

        if ($confDateStr > $todayStr) {
            return ['success' => false, 'message' => 'Confirmation date cannot be in the future.'];
        }

        $joinDate = employee_joining_date($employee) ?? $employee['joining_date'] ?? $employee['employment_start_date'] ?? null;
        if (!empty($joinDate)) {
            $joinDateStr = date('Y-m-d', strtotime($joinDate));
            if ($confDateStr < $joinDateStr) {
                return ['success' => false, 'message' => "Confirmation date ({$confDateStr}) cannot be earlier than employee joining date ({$joinDateStr})."];
            }
        }

        $oldProbState = $this->resolveEmployeeProbationState($employee);

        $db = \Config\Database::connect();
        $db->transBegin();

        try {
            $updateData = [
                'probation_confirmed_date' => $confDateStr,
                'confirmation_date'        => $confDateStr,
                'probation_status'         => 'Confirmed',
                'status'                   => \App\Models\EmployeeModel::STATUS_ACTIVE,
                'probation_notes'          => ($employee['probation_notes'] ?? '') . "\n[" . date('Y-m-d') . "] Early confirmed on {$confDateStr} by {$actorName}. Reason: {$reason}"
            ];

            $this->employeeModel->update($employeeId, $updateData);

            // Audit log
            $this->auditLogModel->insert([
                'id'                => 'pal-' . bin2hex(random_bytes(6)),
                'employee_id'       => $employeeId,
                'company_id'        => $employee['company_id'] ?? null,
                'action_type'       => 'Early Confirmation',
                'previous_end_date' => $oldProbState['probation_end_date'] ?? null,
                'new_end_date'      => $confDateStr,
                'previous_status'   => $oldProbState['probation_status'] ?? $probStatus,
                'new_status'        => 'Confirmed',
                'reason'            => $reason,
                'details'           => "Employee early-confirmed effective {$confDateStr}. Annual Leave and all post-probation leave types immediately unlocked.",
                'performed_by'      => $actorId,
                'performed_by_name' => $actorName ?: 'HR Admin',
                'created_at'        => date('Y-m-d H:i:s')
            ]);

            $db->transCommit();
        } catch (\Throwable $e) {
            $db->transRollback();
            return ['success' => false, 'message' => 'Failed to early confirm probation: ' . $e->getMessage()];
        }

        // Send notification
        try {
            $this->notificationService->createNotification([
                'user_id'     => $employee['user_id'] ?? null,
                'company_id'  => $employee['company_id'] ?? null,
                'type'        => 'probation_confirmed',
                'title'       => 'Employment Confirmed',
                'message'     => "Congratulations! Your employment has been confirmed effective {$confDateStr}. All leave privileges are now unlocked.",
                'data'        => json_encode(['confirmation_date' => $confDateStr])
            ]);
        } catch (\Throwable $e) {}

        return [
            'success'           => true,
            'message'           => "Employee successfully confirmed on {$confDateStr}. All leave types are now immediately eligible.",
            'confirmation_date' => $confDateStr
        ];
    }

    /**
     * Set Employee-level Leave Eligibility Override.
     */
    public function setEligibilityOverride(
        string $employeeId,
        string $leaveTypeId,
        string $overrideStatus, // 'Eligible', 'Blocked'
        ?string $effectiveDate = null,
        ?string $reason = null,
        ?string $actorId = null,
        ?string $actorName = null
    ): array {
        $employee = $this->employeeModel->find($employeeId);
        if (!$employee) {
            return ['success' => false, 'message' => 'Employee not found.'];
        }

        $reason = trim((string)$reason);
        if (empty($reason)) {
            return ['success' => false, 'message' => 'Reason is mandatory for probation eligibility override.'];
        }

        $existingOverrides = !empty($employee['leave_eligibility_overrides']) 
            ? json_decode($employee['leave_eligibility_overrides'], true) ?: []
            : [];

        // Remove existing for same leave type
        $newOverrides = array_values(array_filter($existingOverrides, fn($o) => ($o['leave_type_id'] ?? '') !== $leaveTypeId));

        $lt = $this->leaveTypeModel->find($leaveTypeId);
        $ltName = $lt['name'] ?? 'Custom Leave';

        $newOverrides[] = [
            'leave_type_id'   => $leaveTypeId,
            'leave_type_name' => $ltName,
            'override_status' => $overrideStatus,
            'effective_date'  => $effectiveDate ?: date('Y-m-d'),
            'reason'          => $reason,
            'granted_by'      => $actorName ?: 'HR Admin',
            'granted_at'      => date('Y-m-d H:i:s')
        ];

        $this->employeeModel->update($employeeId, [
            'leave_eligibility_overrides' => json_encode($newOverrides)
        ]);

        // Audit log
        $this->auditLogModel->insert([
            'id'                => 'pal-' . bin2hex(random_bytes(6)),
            'employee_id'       => $employeeId,
            'company_id'        => $employee['company_id'] ?? null,
            'action_type'       => 'Eligibility Override',
            'previous_end_date' => null,
            'new_end_date'      => null,
            'previous_status'   => null,
            'new_status'        => $overrideStatus,
            'reason'            => $reason,
            'details'           => "Override applied for {$ltName}: Status set to '{$overrideStatus}' effective {$effectiveDate}.",
            'performed_by'      => $actorId,
            'performed_by_name' => $actorName ?: 'HR Admin',
            'created_at'        => date('Y-m-d H:i:s')
        ]);

        return [
            'success'   => true,
            'message'   => "Eligibility override saved successfully for {$ltName}.",
            'overrides' => $newOverrides
        ];
    }

    /**
     * Remove Employee-level Leave Eligibility Override.
     */
    public function removeEligibilityOverride(
        string $employeeId,
        string $leaveTypeId,
        ?string $actorId = null,
        ?string $actorName = null
    ): array {
        $employee = $this->employeeModel->find($employeeId);
        if (!$employee) {
            return ['success' => false, 'message' => 'Employee not found.'];
        }

        $existingOverrides = !empty($employee['leave_eligibility_overrides']) 
            ? json_decode($employee['leave_eligibility_overrides'], true) ?: []
            : [];

        $newOverrides = array_values(array_filter($existingOverrides, fn($o) => ($o['leave_type_id'] ?? '') !== $leaveTypeId));

        $this->employeeModel->update($employeeId, [
            'leave_eligibility_overrides' => json_encode($newOverrides)
        ]);

        $this->auditLogModel->insert([
            'id'                => 'pal-' . bin2hex(random_bytes(6)),
            'employee_id'       => $employeeId,
            'company_id'        => $employee['company_id'] ?? null,
            'action_type'       => 'Override Removed',
            'previous_end_date' => null,
            'new_end_date'      => null,
            'previous_status'   => null,
            'new_status'        => 'Default Rule Active',
            'reason'            => 'Manual override removed by HR',
            'details'           => "Employee override removed for leave type ID {$leaveTypeId}. Standard probation rules restored.",
            'performed_by'      => $actorId,
            'performed_by_name' => $actorName ?: 'HR Admin',
            'created_at'        => date('Y-m-d H:i:s')
        ]);

        return [
            'success'   => true,
            'message'   => "Eligibility override removed successfully.",
            'overrides' => $newOverrides
        ];
    }

    /**
     * Mark probation as completed (natural or explicit confirmation).
     */
    public function completeProbation(
        string $employeeId,
        ?string $completionDate = null,
        ?string $reason = null,
        ?string $actorId = null,
        ?string $actorName = null
    ): array {
        $employee = $this->employeeModel->find($employeeId);
        if (!$employee) {
            return ['success' => false, 'message' => 'Employee not found.'];
        }

        $rawStatus  = strtolower(trim((string)($employee['status'] ?? '')));
        $probStatus = trim((string)($employee['probation_status'] ?? ''));

        // Refuse terminated, resigned, or inactive employees
        if (in_array($rawStatus, ['terminated', 'resigned', 'inactive'], true)) {
            return ['success' => false, 'message' => "Cannot complete probation: Employee is currently {$rawStatus}."];
        }

        // Only allow when employee status is 'probation' (or 'on_leave' during probation)
        $allowedStatuses = [\App\Models\EmployeeModel::STATUS_PROBATION, \App\Models\EmployeeModel::STATUS_ON_LEAVE];
        $isOnProbation   = in_array($rawStatus, $allowedStatuses, true)
            || in_array($probStatus, ['Active', 'Pending', 'Extended', 'On Probation'], true);

        if (!$isOnProbation && $rawStatus !== \App\Models\EmployeeModel::STATUS_PROBATION) {
            return ['success' => false, 'message' => "Cannot complete probation: Employee status is '{$employee['status']}' (not on probation)."];
        }

        $date = $completionDate ?: date('Y-m-d');
        if (!strtotime($date)) {
            return ['success' => false, 'message' => 'A valid completion date format is required (YYYY-MM-DD).'];
        }

        $confDateStr = date('Y-m-d', strtotime($date));
        $todayStr    = date('Y-m-d');

        if ($confDateStr > $todayStr) {
            return ['success' => false, 'message' => 'Confirmation date cannot be in the future.'];
        }

        $joinDate = employee_joining_date($employee) ?? $employee['joining_date'] ?? $employee['employment_start_date'] ?? null;
        if (!empty($joinDate)) {
            $joinDateStr = date('Y-m-d', strtotime($joinDate));
            if ($confDateStr < $joinDateStr) {
                return ['success' => false, 'message' => "Confirmation date ({$confDateStr}) cannot be earlier than employee joining date ({$joinDateStr})."];
            }
        }

        $oldProbState = $this->resolveEmployeeProbationState($employee);

        $db = \Config\Database::connect();
        $db->transBegin();

        try {
            $updateData = [
                'probation_status'         => 'Completed',
                'probation_confirmed_date' => $confDateStr,
                'status'                   => \App\Models\EmployeeModel::STATUS_ACTIVE,
                'confirmation_date'        => $confDateStr,
                'probation_notes'          => ($employee['probation_notes'] ?? '') . "\n[" . date('Y-m-d') . "] Probation completed on {$confDateStr} by {$actorName}. Reason: {$reason}"
            ];

            $this->employeeModel->update($employeeId, $updateData);

            $this->auditLogModel->insert([
                'id'                => 'pal-' . bin2hex(random_bytes(6)),
                'employee_id'       => $employeeId,
                'company_id'        => $employee['company_id'] ?? null,
                'action_type'       => 'Probation Completed',
                'previous_end_date' => $oldProbState['probation_end_date'] ?? null,
                'new_end_date'      => $confDateStr,
                'previous_status'   => $oldProbState['probation_status'] ?? $probStatus,
                'new_status'        => 'Completed',
                'reason'            => $reason,
                'details'           => "Probation completed effective {$confDateStr}. All post-probation leave privileges unlocked.",
                'performed_by'      => $actorId,
                'performed_by_name' => $actorName ?: 'HR Admin',
                'created_at'        => date('Y-m-d H:i:s')
            ]);

            $db->transCommit();
        } catch (\Throwable $e) {
            $db->transRollback();
            return ['success' => false, 'message' => 'Failed to complete probation: ' . $e->getMessage()];
        }

        return [
            'success'         => true,
            'message'         => "Probation marked as completed effective {$confDateStr}.",
            'completion_date' => $confDateStr
        ];
    }

    /**
     * Cancel probation evaluation (e.g. employee transitioned, waived, or cancelled).
     */
    public function cancelProbation(
        string $employeeId,
        ?string $reason = null,
        ?string $actorId = null,
        ?string $actorName = null
    ): array {
        $employee = $this->employeeModel->find($employeeId);
        if (!$employee) {
            return ['success' => false, 'message' => 'Employee not found.'];
        }

        $oldProbState = $this->resolveEmployeeProbationState($employee);

        $db = \Config\Database::connect();
        $db->transBegin();

        try {
            $updateData = [
                'probation_status' => 'Cancelled',
                'status'           => \App\Models\EmployeeModel::STATUS_ACTIVE,
                'probation_notes'  => ($employee['probation_notes'] ?? '') . "\n[" . date('Y-m-d') . "] Probation cancelled by {$actorName}. Reason: {$reason}"
            ];

            $this->employeeModel->update($employeeId, $updateData);

            $this->auditLogModel->insert([
                'id'                => 'pal-' . bin2hex(random_bytes(6)),
                'employee_id'       => $employeeId,
                'company_id'        => $employee['company_id'] ?? null,
                'action_type'       => 'Probation Cancelled',
                'previous_end_date' => $oldProbState['probation_end_date'] ?? null,
                'new_end_date'      => null,
                'previous_status'   => $oldProbState['probation_status'] ?? ($employee['probation_status'] ?? null),
                'new_status'        => 'Cancelled',
                'reason'            => $reason,
                'details'           => "Probation evaluation cancelled. Employee converted to regular status.",
                'performed_by'      => $actorId,
                'performed_by_name' => $actorName ?: 'HR Admin',
                'created_at'        => date('Y-m-d H:i:s')
            ]);

            $db->transCommit();
        } catch (\Throwable $e) {
            $db->transRollback();
            return ['success' => false, 'message' => 'Failed to cancel probation: ' . $e->getMessage()];
        }

        return [
            'success' => true,
            'message' => "Probation evaluation cancelled successfully."
        ];
    }

    /**
     * Change employee employment type (e.g. Probation -> Permanent/Confirmed).
     * Automatically updates probation state and recalculates leave eligibility.
     */
    public function changeEmploymentType(
        string $employeeId,
        string $newEmploymentTypeId,
        ?string $newStatus = 'active',
        ?string $reason = null,
        ?string $actorId = null,
        ?string $actorName = null
    ): array {
        $employee = $this->employeeModel->find($employeeId);
        if (!$employee) {
            return ['success' => false, 'message' => 'Employee not found.'];
        }

        $newEmpType = $this->employmentTypeModel->find($newEmploymentTypeId);
        $newTypeName = $newEmpType['name'] ?? 'Updated Type';
        $isNewTypeProbation = stripos($newTypeName, 'probation') !== false;

        $updateData = [
            'employment_type_id' => $newEmploymentTypeId,
            'status'             => $newStatus ?: 'active',
            'updated_at'         => date('Y-m-d H:i:s')
        ];

        if (!$isNewTypeProbation) {
            $updateData['probation_status'] = 'Completed';
            if (empty($employee['probation_confirmed_date'])) {
                $updateData['probation_confirmed_date'] = date('Y-m-d');
            }
        } else {
            $updateData['probation_status'] = 'On Probation';
        }

        $this->employeeModel->update($employeeId, $updateData);

        // Audit log
        $this->auditLogModel->insert([
            'id'                => 'pal-' . bin2hex(random_bytes(6)),
            'employee_id'       => $employeeId,
            'company_id'        => $employee['company_id'] ?? null,
            'action_type'       => 'Employment Type Changed',
            'previous_end_date' => $employee['probation_end_date'] ?? null,
            'new_end_date'      => $updateData['probation_confirmed_date'] ?? null,
            'previous_status'   => $employee['employment_type_id'] ?? null,
            'new_status'        => $newTypeName,
            'reason'            => $reason,
            'details'           => "Employment type changed to '{$newTypeName}'. Probation status: " . ($updateData['probation_status'] ?? 'Active'),
            'performed_by'      => $actorId,
            'performed_by_name' => $actorName ?: 'HR Admin',
            'created_at'        => date('Y-m-d H:i:s')
        ]);

        return [
            'success'              => true,
            'message'              => "Employment type updated to {$newTypeName}. Leave eligibility automatically recalculated.",
            'new_employment_type'  => $newTypeName,
            'is_under_probation'   => $isNewTypeProbation
        ];
    }

    /**
     * Get probation audit trail logs
     */
    public function getAuditLogs(?string $employeeId = null, ?string $companyId = null, int $limit = 100): array
    {
        $builder = $this->auditLogModel->builder();
        if ($employeeId) {
            $builder->where('employee_id', $employeeId);
        }
        if ($companyId) {
            $builder->where('company_id', $companyId);
        }
        return $builder->orderBy('created_at', 'DESC')->limit($limit)->get()->getResultArray();
    }

    /**
     * Save dynamic eligibility rule to Rule Engine (domain: LEAVE -> probation.eligibility_rules).
     */
    public function saveRule(array $data, ?string $actorId = null, ?string $actorName = null): array
    {
        $id = $data['id'] ?? null;
        $leaveTypeId = $data['leave_type_id'] ?? null;

        if (!$leaveTypeId) {
            return ['success' => false, 'message' => 'Leave Type is required.'];
        }

        $lt = $this->leaveTypeModel->find($leaveTypeId);
        $ltCode = strtoupper(trim((string)($lt['code'] ?? ($data['leave_type_code'] ?? 'LV'))));
        $ltName = $lt['name'] ?? ($data['leave_type_name'] ?? 'Custom Leave');

        $companyId = !empty($data['company_id']) ? $data['company_id'] : (function_exists('session') && session()->has('company_id') ? session()->get('company_id') : null);
        if (empty($companyId) && !empty($lt['company_id'])) {
            $companyId = $lt['company_id'];
        }
        if (empty($companyId)) {
            return ['success' => false, 'message' => 'Company ID is required to configure rules.'];
        }

        $ruleId = $id ?: ('rule-pler-' . strtolower($ltCode));
        $ruleItem = [
            'id'                   => $ruleId,
            'leave_type_id'        => $leaveTypeId,
            'leave_type_code'      => $ltCode,
            'leave_type_name'      => $ltName,
            'employment_type_id'   => !empty($data['employment_type_id']) ? $data['employment_type_id'] : null,
            'eligibility_mode'     => $data['eligibility_mode'] ?? 'after_probation',
            'waiting_period_value' => (int)($data['waiting_period_value'] ?? 0),
            'waiting_period_unit'  => $data['waiting_period_unit'] ?? 'Months',
            'accrual_start_mode'   => $data['accrual_start_mode'] ?? 'from_joining',
            'allow_advance_leave'  => !empty($data['allow_advance_leave']) ? true : false,
            'blocked_message'      => $data['blocked_message'] ?? null,
            'status'               => $data['status'] ?? 'active'
        ];

        $currentRule = \App\Services\Rules\RuleResolver::resolveForCompany($companyId, 'LEAVE', date('Y-m-d'));
        $params = $currentRule->params();
        $probation = $params['probation'] ?? [];
        $rules = $probation['eligibility_rules'] ?? [];

        $found = false;
        foreach ($rules as $idx => $r) {
            if ((!empty($id) && ($r['id'] ?? '') === $id) ||
                (($r['leave_type_code'] ?? '') === $ltCode && ($r['employment_type_id'] ?? null) === ($ruleItem['employment_type_id'] ?? null))) {
                $rules[$idx] = array_merge($r, $ruleItem);
                $found = true;
                break;
            }
        }
        if (!$found) {
            $rules[] = $ruleItem;
        }

        $probation['eligibility_rules'] = $rules;
        $params['probation'] = $probation;

        $actor = $actorId ?: (function_exists('session') && session()->has('user_id') ? (string)session()->get('user_id') : 'system');
        $permService = new \App\Services\PermissionService();
        if ($actor !== 'system' && !$permService->isSoftwareAppAdmin($actor)) {
            $hasPerm = $permService->hasPermission($actor, 'rules.manage') || $permService->hasPermission($actor, 'leave.manage');
            if (!$hasPerm) {
                return ['success' => false, 'message' => '403 Forbidden: rules.manage permission is required.'];
            }
        }

        $changeReason = trim((string)($data['change_reason'] ?? $data['reason'] ?? ''));
        if ($changeReason === '' || strcasecmp($changeReason, \App\Services\Rules\RuleWriteService::SEED_REASON) === 0) {
            $changeReason = "Update probation eligibility rule for {$ltName}";
        }

        $writeService = new \App\Services\Rules\RuleWriteService();
        $writeService->publishCompanyRule($companyId, 'LEAVE', $params, $actor, $changeReason);

        return [
            'success' => true,
            'message' => "Eligibility rule saved for {$ltName} in Rule Engine.",
            'rule_id' => $ruleId
        ];
    }

    /**
     * Delete dynamic eligibility rule from Rule Engine.
     */
    public function deleteRule(string $id, ?string $companyId = null, ?string $actorId = null, ?string $reason = null): array
    {
        if (empty($companyId) && function_exists('session') && session()->has('company_id')) {
            $companyId = session()->get('company_id');
        }
        if (empty($companyId)) {
            return ['success' => false, 'message' => 'Company ID is required to remove eligibility rule.'];
        }

        $actor = $actorId ?: (function_exists('session') && session()->has('user_id') ? (string)session()->get('user_id') : 'system');
        $permService = new \App\Services\PermissionService();
        if ($actor !== 'system' && !$permService->isSoftwareAppAdmin($actor)) {
            $hasPerm = $permService->hasPermission($actor, 'rules.manage') || $permService->hasPermission($actor, 'leave.manage');
            if (!$hasPerm) {
                return ['success' => false, 'message' => '403 Forbidden: rules.manage permission is required.'];
            }
        }

        $currentRule = \App\Services\Rules\RuleResolver::resolveForCompany($companyId, 'LEAVE', date('Y-m-d'));
        $params = $currentRule->params();
        $probation = $params['probation'] ?? [];
        $rules = $probation['eligibility_rules'] ?? [];

        $newRules = [];
        $removed = false;
        foreach ($rules as $r) {
            if (($r['id'] ?? '') === $id || ($r['leave_type_id'] ?? '') === $id || (strtoupper($r['leave_type_code'] ?? '') === strtoupper($id))) {
                $removed = true;
                continue;
            }
            $newRules[] = $r;
        }

        if (!$removed) {
            return ['success' => false, 'message' => 'Rule not found in Rule Engine.'];
        }

        $probation['eligibility_rules'] = $newRules;
        $params['probation'] = $probation;

        $changeReason = trim((string)$reason);
        if ($changeReason === '' || strcasecmp($changeReason, \App\Services\Rules\RuleWriteService::SEED_REASON) === 0) {
            $changeReason = "Deleted probation eligibility rule {$id}";
        }

        $writeService = new \App\Services\Rules\RuleWriteService();
        $writeService->publishCompanyRule($companyId, 'LEAVE', $params, $actor, $changeReason);

        return ['success' => true, 'message' => 'Eligibility rule removed successfully from Rule Engine.'];
    }

    /**
     * Get all eligibility rules scoped by company from Rule Engine.
     */
    public function getRules(?string $companyId = null): array
    {
        if (empty($companyId) && function_exists('session') && session()->has('company_id')) {
            $companyId = session()->get('company_id');
        }
        if (empty($companyId)) {
            return [];
        }

        try {
            $leaveRule = \App\Services\Rules\RuleResolver::resolveForCompany($companyId, 'LEAVE', date('Y-m-d'));
            $probation = $leaveRule->get('probation');
            return $probation['eligibility_rules'] ?? [];
        } catch (\Throwable $e) {
            return [];
        }
    }
}
