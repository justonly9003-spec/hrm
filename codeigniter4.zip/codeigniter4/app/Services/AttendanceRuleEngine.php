<?php

namespace App\Services;

use App\Models\AttendanceModel;
use App\Models\HolidayModel;
use App\Services\CompanyWeekendService;
use App\Services\RuleEngineService;
use Config\Database;

/**
 * Class AttendanceRuleEngine
 *
 * Authoritative single point of calculation for all attendance records.
 * Unifies calculations across Overview, Group Matrix, Dashboard Widgets, and Reports.
 */
class AttendanceRuleEngine
{
    protected $db;
    protected $ruleEngine;

    protected static array $holidayCache = [];
    protected static array $holidaysForDateCache = [];
    protected static array $leavesCache = [];
    protected static array $calculationCache = [];

    /**
     * Clear per-request engine caches
     */
    public static function clearEngineCaches(): void
    {
        self::$holidayCache = [];
        self::$holidaysForDateCache = [];
        self::$leavesCache = [];
        self::$calculationCache = [];
        HolidayModel::clearHolidayCache();
    }

    public function __construct()
    {
        $this->db = Database::connect();
        $this->ruleEngine = new RuleEngineService();
    }

    /**
     * Authoritative calculation engine for a specific date across active staff.
     */
    public function calculateAttendanceForDate(
        string $date,
        ?string $branchId = null,
        ?string $deptId = null,
        ?string $companyId = null,
        ?string $statusFilter = null,
        ?string $search = null,
        ?array $preloadedEmployees = null,
        bool $autoHealDb = false,
        bool $exceptHolidaysWeekends = false
    ): array {
        if ($branchId === 'all') $branchId = null;
        if ($deptId === 'all') $deptId = null;
        $today = date('Y-m-d');
        $isFuture = ($date > $today);

        // Multi-Tenant Scoping Guard:
        // Refuse to calculate attendance across multiple companies in a single un-scoped pass.
        // If companyId is not provided, group employees by company_id and run the engine per company.
        if (empty($companyId)) {
            return $this->calculateAttendanceForDateMultiCompany(
                $date,
                $branchId,
                $deptId,
                $statusFilter,
                $search,
                $preloadedEmployees,
                $autoHealDb,
                $exceptHolidaysWeekends
            );
        }

        // Per-request Cache Lookup: Keyed by company, branch, department, date and exceptHolidaysWeekends
        $normBranch = empty($branchId) ? '' : (string)$branchId;
        $normDept   = empty($deptId) ? '' : (string)$deptId;
        $hwKey      = $exceptHolidaysWeekends ? '1' : '0';
        $cacheKey   = "{$companyId}|{$normBranch}|{$normDept}|{$date}|{$hwKey}";

        if (isset(self::$calculationCache[$cacheKey])) {
            $cached = self::$calculationCache[$cacheKey];
            if (empty($statusFilter) && empty($search)) {
                return $cached;
            }
            $filteredLogs = $cached['allDetailedLogs'] ?? ($cached['detailedLogs'] ?? []);
            if (!empty($statusFilter) && $statusFilter !== 'all') {
                $filteredLogs = array_values(array_filter($filteredLogs, function ($item) use ($statusFilter) {
                    if ($statusFilter === 'Present') {
                        return AttendanceModel::isPresentLike($item['status'] ?? '', $item);
                    }
                    if ($statusFilter === 'Late') {
                        return !empty($item['is_late']) || in_array($item['status'] ?? '', ['Late', 'Late & Early Out'], true);
                    }
                    if ($statusFilter === 'Early Out') {
                        return !empty($item['is_early_out']) || in_array($item['status'] ?? '', ['Early Out', 'Late & Early Out'], true);
                    }
                    if ($statusFilter === 'Absent') {
                        return ($item['primary_bucket'] ?? '') === 'absent'
                            || ($item['status'] ?? '') === 'Absent'
                            || (!empty($item['is_absent']) && empty($item['is_present']));
                    }
                    if ($statusFilter === 'On Leave' || $statusFilter === 'Leave') {
                        return ($item['primary_bucket'] ?? '') === 'on_leave'
                            || (!empty($item['is_on_leave']) && empty($item['is_present']));
                    }
                    if ($statusFilter === 'Missing Punch') {
                        return ($item['primary_bucket'] ?? '') === 'missing_punch' || ($item['status'] ?? '') === 'Missing Punch';
                    }
                    return ($item['status'] ?? '') === $statusFilter;
                }));
            }
            if (!empty($search)) {
                $needle = strtolower(trim($search));
                $filteredLogs = array_values(array_filter($filteredLogs, function ($item) use ($needle) {
                    $name = strtolower($item['employee_name'] ?? '');
                    $code = strtolower($item['employee_code'] ?? '');
                    return str_contains($name, $needle) || str_contains($code, $needle);
                }));
            }
            $res = $cached;
            $res['detailedLogs'] = $filteredLogs;
            return $res;
        }

        // 1. Fetch eligible active employees who officially joined on or prior to target date
        if ($preloadedEmployees !== null) {
            $today = date('Y-m-d');
            $employees = [];
            $empIds = [];
            foreach ($preloadedEmployees as $re) {
                // Filter out employees who officially joined after target date
                $joinDate = employee_joining_date($re) ?? $re['employment_start_date'] ?? (!empty($re['created_at']) ? date('Y-m-d', strtotime($re['created_at'])) : null);
                if (!empty($joinDate) && $joinDate > $date) {
                    continue;
                }

                $sepDate = \App\Models\EmployeeModel::resolveSeparationDate($re, $this->db);
                if ($date < $today) {
                    // Past dates: include employee if employed on that date regardless of current status
                    if (!empty($sepDate) && $sepDate < $date) {
                        continue;
                    }
                } else {
                    // Today and future dates: keep Active/Probation requirement
                    $empStatus = strtolower(trim((string)($re['status'] ?? 'active')));
                    if ($empStatus !== '' && !in_array($empStatus, ['active', 'probation', 'null'], true)) {
                        continue;
                    }
                    if (!empty($sepDate) && $sepDate < $date) {
                        continue;
                    }
                }

                if (!empty($companyId) && (string)($re['company_id'] ?? '') !== (string)$companyId) {
                    continue;
                }
                if (!empty($branchId) && !empty($re['branch_id']) && (string)$re['branch_id'] !== (string)$branchId) {
                    continue;
                }
                if (!empty($deptId) && !empty($re['department_id']) && (string)$re['department_id'] !== (string)$deptId) {
                    continue;
                }

                $fName = trim($re['first_name'] ?? '');
                $lName = trim($re['last_name'] ?? '');
                $fullName = trim($fName . ' ' . $lName) ?: ($re['name'] ?? ($re['employee_code'] ?? 'Staff'));

                $re['name'] = $fullName;
                $re['department'] = $re['department_name'] ?? ($re['department'] ?? 'General');
                $re['branch'] = $re['branch_name'] ?? ($re['branch'] ?? 'Main Office');
                $re['designation'] = $re['designation_name'] ?? ($re['designation'] ?? 'Staff');
                $re['shift_name'] = $re['shift_name'] ?? 'General Shift (8 AM - 4 PM)';
                $re['start_time'] = $re['start_time'] ?? '08:00';
                $re['end_time'] = $re['end_time'] ?? '16:00';
                $re['grace_time'] = isset($re['grace_time']) && $re['grace_time'] !== '' && $re['grace_time'] !== null ? (int)$re['grace_time'] : null;
                $re['photo'] = !empty($re['photo']) ? $re['photo'] : 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150';
                $re['avatar'] = $re['photo'];
                $re['status'] = !empty($re['status']) ? ucfirst(strtolower(trim((string)$re['status']))) : 'Active';

                $employees[] = $re;
                if (!empty($re['id'])) {
                    $empIds[] = (string)$re['id'];
                }
            }
        } else {
            $hasShiftGrace = false;
            if ($this->db->tableExists('shifts')) {
                $shiftCols = $this->db->getFieldNames('shifts');
                $hasShiftGrace = in_array('grace_time', $shiftCols, true);
            }
            $graceSelect = $hasShiftGrace ? 'shifts.grace_time as grace_time' : '15 as grace_time';

            $empModel = new \App\Models\EmployeeModel();
            $sepSql = $empModel->getSeparationDateSql('employees.');

            $empBuilder = $this->db->table('employees')
                ->select("employees.*, departments.name as department_name, branches.name as branch_name, designations.name as designation_name, shifts.name as shift_name, shifts.start_time, shifts.end_time, shifts.weekly_off, shifts.work_days, {$graceSelect}, {$sepSql} as separation_date")
                ->join('departments', 'departments.id = employees.department_id', 'left')
                ->join('branches', 'branches.id = employees.branch_id', 'left')
                ->join('designations', 'designations.id = employees.designation_id', 'left')
                ->join('shifts', 'shifts.id = employees.shift_id', 'left');

            $empModel->applyEmploymentTenureFilter($empBuilder, $date, 'employees');

            if ($this->db->fieldExists('deleted_at', 'employees')) {
                $empBuilder->where('employees.deleted_at IS NULL');
            }

            if (!empty($companyId)) {
                $empBuilder->where('employees.company_id', $companyId);
            }
            if (!empty($branchId)) {
                $empBuilder->where('employees.branch_id', $branchId);
            }
            if (!empty($deptId)) {
                $empBuilder->where('employees.department_id', $deptId);
            }

            $rawEmployees = $empBuilder->orderBy('employees.first_name', 'ASC')->get()->getResultArray();

            $employees = [];
            $empIds = [];
            foreach ($rawEmployees as $re) {
                $fName = trim($re['first_name'] ?? '');
                $lName = trim($re['last_name'] ?? '');
                $fullName = trim($fName . ' ' . $lName) ?: ($re['name'] ?? ($re['employee_code'] ?? 'Staff'));

                $re['name'] = $fullName;
                $re['department'] = $re['department_name'] ?? 'General';
                $re['branch'] = $re['branch_name'] ?? 'Main Office';
                $re['designation'] = $re['designation_name'] ?? 'Staff';
                $re['shift_name'] = $re['shift_name'] ?? 'General Shift (8 AM - 4 PM)';
                $re['start_time'] = $re['start_time'] ?? '08:00';
                $re['end_time'] = $re['end_time'] ?? '16:00';
                $re['photo'] = !empty($re['photo']) ? $re['photo'] : 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150';
                $re['avatar'] = $re['photo'];
                $re['status'] = !empty($re['status']) ? ucfirst(strtolower(trim((string)$re['status']))) : 'Active';

                $employees[] = $re;
                if (!empty($re['id'])) {
                    $empIds[] = (string)$re['id'];
                }
            }
        }

        // 2. Approved Leaves for this date (cached per company per date to prevent N+1 queries across widgets)
        $leaves = [];
        $compLeaveKey = ($companyId ?: '__all__') . '|' . $date;
        if (isset(self::$leavesCache[$compLeaveKey])) {
            $allCompLeaves = self::$leavesCache[$compLeaveKey];
            if (!empty($empIds)) {
                $empIdFlip = array_flip($empIds);
                $leaves = array_values(array_filter($allCompLeaves, function ($lv) use ($empIdFlip) {
                    $lEid = (string)($lv['employee_id'] ?? '');
                    return isset($empIdFlip[$lEid]);
                }));
            } else {
                $leaves = $allCompLeaves;
            }
        } elseif ($this->db->tableExists('leave_applications') && (!empty($companyId) || !empty($empIds))) {
            try {
                $hasLeaveTypes = $this->db->tableExists('leave_types');
                $lb = $this->db->table('leave_applications');
                $hasStartDate = $this->db->fieldExists('start_date', 'leave_applications');
                $hasFromDate  = $this->db->fieldExists('from_date', 'leave_applications');
                $hasEndDate   = $this->db->fieldExists('end_date', 'leave_applications');
                $hasToDate    = $this->db->fieldExists('to_date', 'leave_applications');

                $lb->where('leave_applications.status', 'Approved');
                $lb->groupStart();
                if ($hasStartDate && $hasEndDate) {
                    $lb->groupStart()
                        ->where('leave_applications.start_date <=', $date)
                        ->where('leave_applications.end_date >=', $date)
                    ->groupEnd();
                    if ($hasFromDate && $hasToDate) {
                        $lb->orGroupStart()
                            ->where('leave_applications.from_date <=', $date)
                            ->where('leave_applications.to_date >=', $date)
                        ->groupEnd();
                    }
                } elseif ($hasFromDate && $hasToDate) {
                    $lb->groupStart()
                        ->where('leave_applications.from_date <=', $date)
                        ->where('leave_applications.to_date >=', $date)
                    ->groupEnd();
                } else {
                    $lb->where('1=1');
                }
                $lb->groupEnd();

                // Multi-tenant isolation: always enforce company filter on leave query
                if (!empty($companyId)) {
                    if ($this->db->fieldExists('company_id', 'leave_applications')) {
                        $lb->where('leave_applications.company_id', $companyId);
                    } else {
                        $lb->join('employees as leave_emp', 'leave_emp.id = leave_applications.employee_id')
                           ->where('leave_emp.company_id', $companyId);
                    }
                } elseif (!empty($empIds)) {
                    $lb->whereIn('leave_applications.employee_id', $empIds);
                }

                if ($hasLeaveTypes) {
                    $lb->select('leave_applications.*, leave_types.name as leave_type_name, leave_types.is_paid as leave_is_paid')
                       ->join('leave_types', 'leave_types.id = leave_applications.leave_type_id', 'left');
                } else {
                    $lb->select('leave_applications.*');
                }

                $res = $lb->get();
                $fetchedLeaves = ($res && is_object($res)) ? $res->getResultArray() : [];
                if (!empty($companyId)) {
                    self::$leavesCache[$compLeaveKey] = $fetchedLeaves;
                }
                if (!empty($empIds)) {
                    $empIdFlip = array_flip($empIds);
                    $leaves = array_values(array_filter($fetchedLeaves, function ($lv) use ($empIdFlip) {
                        $lEid = (string)($lv['employee_id'] ?? '');
                        return isset($empIdFlip[$lEid]);
                    }));
                } else {
                    $leaves = $fetchedLeaves;
                }
            } catch (\Throwable $e) {
                log_message('error', 'AttendanceRuleEngine leave check error: ' . $e->getMessage());
            }
        }

        // 3. Holidays covering this date (cached once per company per request)
        $holidays = [];
        $holidaysByCompany = [];
        $holDateKey = ($companyId ?: '__all__') . '|' . $date;
        if (isset(self::$holidaysForDateCache[$holDateKey])) {
            $holidays = self::$holidaysForDateCache[$holDateKey]['holidays'];
            $holidaysByCompany = self::$holidaysForDateCache[$holDateKey]['holidaysByCompany'];
        } elseif ($this->db->tableExists('holidays')) {
            try {
                $compKey = $companyId ?: '__all__';
                if (!isset(self::$holidayCache[$compKey])) {
                    self::$holidayCache[$compKey] = (new HolidayModel())->getOrderedHolidays($companyId);
                }
                $rawHolidays = self::$holidayCache[$compKey];
                foreach ($rawHolidays as $rh) {
                    $matches = false;
                    if (!empty($rh['from_date']) && !empty($rh['to_date'])) {
                        if ($date >= $rh['from_date'] && $date <= $rh['to_date']) {
                            $matches = true;
                        }
                    } elseif (!empty($rh['date']) && $rh['date'] === $date) {
                        $matches = true;
                    }

                    if ($matches) {
                        $hItem = [
                            'id'         => $rh['id'] ?? '',
                            'name'       => $rh['name'] ?? 'Holiday',
                            'date'       => $date,
                            'from_date'  => $rh['from_date'] ?? $date,
                            'to_date'    => $rh['to_date'] ?? $date,
                            'type'       => $rh['type'] ?? ($rh['holiday_type'] ?? 'public'),
                            'company_id' => $rh['company_id'] ?? $companyId,
                            'branch_id'  => $rh['branch_id'] ?? null
                        ];
                        $holidays[] = $hItem;
                        $hComp = (string)($hItem['company_id'] ?? '');
                        if ($hComp !== '') {
                            $holidaysByCompany[$hComp][] = $hItem;
                        } else {
                            $holidaysByCompany['__global__'][] = $hItem;
                        }
                    }
                }
                self::$holidaysForDateCache[$holDateKey] = [
                    'holidays' => $holidays,
                    'holidaysByCompany' => $holidaysByCompany,
                ];
            } catch (\Throwable $e) {
                log_message('error', 'AttendanceRuleEngine holiday check error: ' . $e->getMessage());
            }
        }

        // 4. Raw Attendance Logs for this date
        $logs = [];
        $logsByEmp = [];
        if ($this->db->tableExists('attendance_logs')) {
            $logBuilder = $this->db->table('attendance_logs')
                ->where('attendance_logs.date', $date);

            if (!empty($companyId)) {
                if ($this->db->fieldExists('company_id', 'attendance_logs')) {
                    $logBuilder->where('attendance_logs.company_id', $companyId);
                } else {
                    $logBuilder->join('employees', '(employees.id = attendance_logs.employee_id OR employees.employee_code = attendance_logs.employee_id) AND employees.company_id = ' . $this->db->escape($companyId))
                               ->where('employees.company_id', $companyId);
                }
                if (!empty($empIds)) {
                    $logBuilder->whereIn('attendance_logs.employee_id', $empIds);
                }
            } elseif (!empty($empIds)) {
                $logBuilder->whereIn('attendance_logs.employee_id', $empIds);
            }
            $logs = $logBuilder->select('attendance_logs.*')->get()->getResultArray();

            foreach ($logs as $l) {
                if (!array_key_exists('is_company_closure', $l)) {
                    $l['is_company_closure'] = 0;
                }
                if (!array_key_exists('closure_credit_hours', $l)) {
                    $l['closure_credit_hours'] = 0.0;
                }
                $l['skip_closure_lookup'] = true;

                $eid = strtolower(trim((string)($l['employee_id'] ?? '')));
                $ecode = strtolower(trim((string)($l['employee_code'] ?? '')));
                $logCompId = (string)($l['company_id'] ?? $companyId);

                if ($eid !== '') {
                    if ($logCompId !== '') {
                        $logsByEmp[$logCompId . '_' . $eid] = $l;
                    }
                    if (!empty($companyId) || !isset($logsByEmp[$eid])) {
                        $logsByEmp[$eid] = $l;
                    }
                }
                if ($ecode !== '') {
                    if ($logCompId !== '') {
                        $logsByEmp[$logCompId . '_' . $ecode] = $l;
                    }
                    if (!empty($companyId) && !isset($logsByEmp[$ecode])) {
                        $logsByEmp[$ecode] = $l;
                    }
                }
            }
        }

        // 4b. Preload Approved Early Closure Credits for this date
        $closureCreditsByEmp = [];
        if ($this->db->tableExists('attendance_closure_credits')) {
            try {
                $creditBuilder = $this->db->table('attendance_closure_credits')
                    ->where('attendance_date', $date)
                    ->where('status', 'Approved');
                if (!empty($companyId)) {
                    $creditBuilder->where('company_id', $companyId);
                } elseif (!empty($empIds)) {
                    $creditBuilder->whereIn('employee_id', $empIds);
                }
                $approvedCredits = $creditBuilder->get()->getResultArray();
                foreach ($approvedCredits as $ac) {
                    $cEmpId = strtolower(trim((string)($ac['employee_id'] ?? '')));
                    $cCompId = (string)($ac['company_id'] ?? $companyId);
                    if ($cEmpId !== '') {
                        $closureCreditsByEmp[$cEmpId] = $ac;
                        if ($cCompId !== '') {
                            $closureCreditsByEmp[$cCompId . '_' . $cEmpId] = $ac;
                        }
                    }
                }
            } catch (\Throwable $e) {
                log_message('error', 'AttendanceRuleEngine closure credit check error: ' . $e->getMessage());
            }
        }

        // 5. Unmapped Biometric events
        $unmappedBiometricCount = 0;
        try {
            if ($this->db->tableExists('raw_biometric_events')) {
                $rawBuilder = $this->db->table('raw_biometric_events')
                    ->where('DATE(punch_time)', $date)
                    ->where('matching_status', 'UNMATCHED');
                if (!empty($companyId)) {
                    $rawBuilder->where('company_id', $companyId);
                }
                $row = $rawBuilder->select('COUNT(DISTINCT biometric_user_id) as cnt')->get()->getRow();
                $unmappedBiometricCount = (int)($row->cnt ?? 0);
            }
        } catch (\Throwable $e) {
            log_message('error', 'AttendanceRuleEngine unmapped biometric check error: ' . $e->getMessage());
        }

        // 6. Enterprise Rule Profile Resolution via RuleResolver
        // Batch-load duty assignments, weekly-off data, and employee salaries before loop to eliminate N+1 queries
        $dutyLookup = CompanyWeekendService::preloadDutyAssignments($empIds, $date, $companyId);
        $weeklyOffLookup = CompanyWeekendService::preloadCompanyWeeklyOff($employees, $companyId);
        (new \App\Services\EmployeeSalaryService())->preloadActiveSalaries($employees, $date);

        // 7. Calculate status and metrics for each employee
        $calculatedResults = [];
        $serverCalculations = [];
        $detailedLogs = [];
        $pendingHealUpdates = [];

        // 7. Preload company weekend and holiday metadata
        $dayOfWeekName = date('l', strtotime($date));
        $companyWeeklyOffDays = CompanyWeekendService::getCompanyWeeklyOff($companyId, null, false, $date);
        $isCompanyWeekend = in_array($dayOfWeekName, $companyWeeklyOffDays, true);
        $isCompanyHolidayDate = !empty($holidays);
        $primaryHolidayName = !empty($holidays[0]['name']) ? $holidays[0]['name'] : '';

        // 8. Calculate status and metrics for each employee with mutually exclusive primary buckets
        $calculatedResults = [];
        $serverCalculations = [];
        $detailedLogs = [];
        $pendingHealUpdates = [];

        $totalActive = count($employees);
        $present = 0;
        $late = 0;
        $earlyOut = 0;
        $halfDay = 0;
        $onLeave = 0;
        $holidayCount = 0;
        $weeklyOffCount = 0;
        $missingPunch = 0;
        $absent = 0;
        $earlyClosureCount = 0;
        $wfh = 0;
        $totalWorkingHours = 0.0;
        $totalOvertime = 0.0;
        $primaryGraceMinutes = null;

        $prevSkipClosure = \App\Services\RuleEngineService::$skipClosureLookup;
        \App\Services\RuleEngineService::$skipClosureLookup = true;
        try {
            foreach ($employees as $emp) {
            $eId = strtolower(trim((string)($emp['id'] ?? '')));
            $eCode = strtolower(trim((string)($emp['employee_code'] ?? '')));
            $empComp = (string)($emp['company_id'] ?? $companyId);

            $empLog = null;
            if ($empComp !== '') {
                if ($eId !== '' && isset($logsByEmp[$empComp . '_' . $eId])) {
                    $empLog = $logsByEmp[$empComp . '_' . $eId];
                } elseif ($eCode !== '' && isset($logsByEmp[$empComp . '_' . $eCode])) {
                    $empLog = $logsByEmp[$empComp . '_' . $eCode];
                }
            }
            if ($empLog === null && !empty($companyId)) {
                if ($eId !== '' && isset($logsByEmp[$eId])) {
                    $empLog = $logsByEmp[$eId];
                } elseif ($eCode !== '' && isset($logsByEmp[$eCode])) {
                    $empLog = $logsByEmp[$eCode];
                }
            }

            // Merge approved closure credit if available
            $approvedCredit = null;
            if ($empComp !== '') {
                if ($eId !== '' && isset($closureCreditsByEmp[$empComp . '_' . $eId])) {
                    $approvedCredit = $closureCreditsByEmp[$empComp . '_' . $eId];
                } elseif ($eCode !== '' && isset($closureCreditsByEmp[$empComp . '_' . $eCode])) {
                    $approvedCredit = $closureCreditsByEmp[$empComp . '_' . $eCode];
                }
            }
            if ($approvedCredit === null && !empty($companyId)) {
                if ($eId !== '' && isset($closureCreditsByEmp[$eId])) {
                    $approvedCredit = $closureCreditsByEmp[$eId];
                } elseif ($eCode !== '' && isset($closureCreditsByEmp[$eCode])) {
                    $approvedCredit = $closureCreditsByEmp[$eCode];
                }
            }
            if ($approvedCredit) {
                if (!$empLog) {
                    $empLog = [
                        'id'                   => 'closure-credit-' . $emp['id'] . '-' . $date,
                        'employee_id'          => $emp['id'],
                        'employee_code'        => $emp['employee_code'] ?? $emp['id'],
                        'date'                 => $date,
                        'company_id'           => $emp['company_id'] ?? $companyId,
                        'is_company_closure'   => 1,
                        'closure_credit_hours' => (float)($approvedCredit['credited_hours'] ?? 0),
                        'working_hours'        => (float)($approvedCredit['final_duty_hours'] ?? ($approvedCredit['credited_hours'] ?? 8.0)),
                        'actual_worked_hours'  => (float)($approvedCredit['actual_worked_hours'] ?? 0),
                        'check_in'             => $approvedCredit['actual_check_in'] ?? null,
                        'check_out'            => $approvedCredit['actual_check_out'] ?? null,
                        'status'               => 'Present',
                        'verification_method'  => 'Company Early Closure Approved',
                        'skip_closure_lookup'  => true,
                    ];
                } else {
                    $empLog['is_company_closure'] = 1;
                    $empLog['closure_credit_hours'] = (float)($approvedCredit['credited_hours'] ?? ($empLog['closure_credit_hours'] ?? 0));
                    if (empty($empLog['check_in']) && !empty($approvedCredit['actual_check_in'])) {
                        $empLog['check_in'] = $approvedCredit['actual_check_in'];
                    }
                    if (empty($empLog['check_out']) && !empty($approvedCredit['actual_check_out'])) {
                        $empLog['check_out'] = $approvedCredit['actual_check_out'];
                    }
                    if (empty($empLog['working_hours']) || (float)$empLog['working_hours'] <= 0) {
                        $empLog['working_hours'] = (float)($approvedCredit['final_duty_hours'] ?? ($approvedCredit['credited_hours'] ?? 8.0));
                    }
                    if (!empty($approvedCredit['actual_worked_hours'])) {
                        $empLog['actual_worked_hours'] = (float)$approvedCredit['actual_worked_hours'];
                    }
                    $empLog['skip_closure_lookup'] = true;
                }
            } elseif ($empLog) {
                if (!array_key_exists('is_company_closure', $empLog)) {
                    $empLog['is_company_closure'] = 0;
                }
                if (!array_key_exists('closure_credit_hours', $empLog)) {
                    $empLog['closure_credit_hours'] = 0.0;
                }
                $empLog['skip_closure_lookup'] = true;
            }
            $emp['skip_closure_lookup'] = true;

            $shiftGraceTime = null;
            if (isset($emp['grace_time']) && $emp['grace_time'] !== '' && $emp['grace_time'] !== null) {
                $shiftGraceTime = (int)$emp['grace_time'];
            }
            $shift = [
                'id'         => $emp['shift_id'] ?? '',
                'name'       => $emp['shift_name'] ?? 'General Shift',
                'start_time' => $emp['start_time'] ?? '08:00',
                'end_time'   => $emp['end_time'] ?? '16:00',
                'grace_time' => $shiftGraceTime,
                'weekly_off' => $emp['weekly_off'] ?? []
            ];

            // Filter holidays for this employee's company and branch
            $empBranchId = (string)($emp['branch_id'] ?? '');
            $empHoliday = null;
            if (!empty($companyId)) {
                $candidateHolidays = $holidays;
            } else {
                $candidateHolidays = array_merge(
                    $holidaysByCompany[$empComp] ?? [],
                    $holidaysByCompany['__global__'] ?? []
                );
            }

            foreach ($candidateHolidays as $h) {
                if (!empty($h['company_id']) && $empComp !== '' && (string)$h['company_id'] !== $empComp) {
                    continue;
                }
                if (!empty($h['branch_id']) && $empBranchId !== '' && (string)$h['branch_id'] !== $empBranchId) {
                    continue;
                }
                $hStart = $h['from_date'] ?? ($h['date'] ?? '');
                $hEnd = $h['to_date'] ?? ($h['date'] ?? $hStart);
                if ($date >= $hStart && $date <= $hEnd) {
                    $empHoliday = $h;
                    break;
                }
            }
            $isEmpHoliday = ($empHoliday !== null);

            $profile = $this->ruleEngine->resolveEffectiveRuleProfile($date, $emp);
            $calc = $this->ruleEngine->calculateDailyAttendance($date, $emp, $empLog, $profile, $shift, $leaves, $candidateHolidays, $dutyLookup, $weeklyOffLookup);

            if ($primaryGraceMinutes === null && isset($calc['grace_minutes'])) {
                $primaryGraceMinutes = (int)$calc['grace_minutes'];
            }

            // Metrics from Rule Engine
            $status = $calc['status'] ?? 'Absent';
            $workHours = (float)($calc['net_hours'] ?? 0);
            $otHours = (float)($calc['total_overtime_hours'] ?? ($calc['daily_overtime_hours'] ?? 0));
            $lateMins = (int)($calc['late_minutes'] ?? 0);
            $earlyMins = (int)($calc['early_out_minutes'] ?? 0);
            $inTime = $calc['check_in'] ?? ($empLog['check_in'] ?? null);
            $outTime = $calc['check_out'] ?? ($empLog['check_out'] ?? null);

            $isEarlyClosure = AttendanceModel::isClosureLog($empLog)
                || in_array($status, ['Present (Early Closure)', 'Approved Early Closure', 'Early Closure Covered'], true);
            if ($isEarlyClosure) {
                $dbOrigNorm = AttendanceModel::normalizeAttendanceStatus($empLog['status'] ?? '');
                $isClosureLate = (!empty($calc['is_late']) || $lateMins > 0 || (int)($empLog['late_minutes'] ?? 0) > 0 || in_array($status, ['Late', 'Late & Early Out'], true) || in_array($dbOrigNorm, ['Late', 'Late & Early Out'], true));
                $lateMins = max($lateMins, (int)($empLog['late_minutes'] ?? 0));
                $status = $isClosureLate ? 'Late' : 'Present (Early Closure)';
                $earlyMins = 0;
                $calc['is_late'] = $isClosureLate;
                $calc['late_minutes'] = $lateMins;
                $calc['is_early_out'] = false;
                $calc['early_out_minutes'] = 0;
                $preservedHours = max($workHours, (float)($empLog['working_hours'] ?? 0.0), (float)($empLog['closure_credit_hours'] ?? 0.0));
                if ($preservedHours <= 0) {
                    $preservedHours = 8.0;
                }
                $workHours = $preservedHours;
                $calc['status'] = $status;
                $calc['net_hours'] = $workHours;
            }

            // Self-healing synchronization: collect diverged rows for batch update rather than inline DB writes
            if ($empLog && !empty($empLog['id']) && !$isFuture) {
                $dbStatus = $empLog['status'] ?? '';
                $dbHours = (float)($empLog['working_hours'] ?? 0);
                $calcHours = (float)($calc['net_hours'] ?? 0);
                $dbBreak = (float)($empLog['break_hours'] ?? 0);
                $calcBreak = (float)($calc['break_hours'] ?? 0);
                if ($dbStatus !== $calc['status'] || abs($dbHours - $calcHours) > 0.01 || abs($dbBreak - $calcBreak) > 0.01) {
                    if ($isEarlyClosure && (in_array($calc['status'], ['Absent', 'Missing Punch', 'Half Day', 'Early Out', 'Late & Early Out'], true) || $calcHours < $dbHours)) {
                        // Preserve approved early closure status and working_hours in DB: never downgrade or reduce hours
                    } else {
                        $pendingHealUpdates[] = [
                            'id'                => $empLog['id'],
                            'status'            => $calc['status'],
                            'working_hours'     => $isEarlyClosure ? max($dbHours, $calcHours) : $calc['net_hours'],
                            'break_hours'       => $calc['break_hours'] ?? 0.0,
                            'overtime_hours'    => $calc['total_overtime_hours'] ?? 0,
                            'late_minutes'      => $calc['late_minutes'] ?? 0,
                            'early_out_minutes' => $isEarlyClosure ? 0 : ($calc['early_out_minutes'] ?? 0),
                            'updated_at'        => date('Y-m-d H:i:s')
                        ];
                    }
                }
            }

            $calculatedResults[] = [
                'employee'     => $emp,
                'log'          => $empLog,
                'calculation'  => $calc,
                'rule_profile' => $profile
            ];

            if ($eId !== '') {
                if ($empComp !== '') {
                    $serverCalculations[$empComp . '_' . $eId] = $calc;
                }
                if (!empty($companyId) || !isset($serverCalculations[$eId])) {
                    $serverCalculations[$eId] = $calc;
                }
            }
            if ($eCode !== '') {
                if ($empComp !== '') {
                    $serverCalculations[$empComp . '_' . $eCode] = $calc;
                }
                if (!empty($companyId) && !isset($serverCalculations[$eCode])) {
                    $serverCalculations[$eCode] = $calc;
                }
            }

            $isPres = AttendanceModel::isPresentLike($status, $empLog)
                || in_array($status, ['WFH', 'Remote'], true)
                || $isEarlyClosure;
            $hasLate = (!empty($calc['is_late']) || $lateMins > 0 || in_array($status, ['Late', 'Late & Early Out']));
            $hasEarly = !$isEarlyClosure && (!empty($calc['is_early_out']) || $earlyMins > 0 || in_array($status, ['Early Out', 'Late & Early Out']));

            // Validate punch presence
            $hasInTime = !empty($inTime) && $inTime !== '--:--' && $inTime !== '--:--:--' && $inTime !== '00:00:00';
            $hasOutTime = !empty($outTime) && $outTime !== '--:--' && $outTime !== '--:--:--' && $outTime !== '00:00:00';
            $isTodayOrFuture = ($date >= $today);

            // ----------------------------------------------------
            // Missing Punch Irregularity vs Live Today In-Progress:
            // - If date is TODAY ($date >= $today) and employee has check-in with pending check-out:
            //   They are actively working today -> Present (or Late), NOT Missing Punch.
            // - If date is in the past ($date < $today) with single punch, or single out-punch with no in-punch,
            //   or status is explicitly 'Missing Punch': Classified as Missing Punch irregularity.
            // ----------------------------------------------------
            $normStatus = AttendanceModel::normalizeAttendanceStatus($status);
            $isMissingPunch = ($status === 'Missing Punch' || $normStatus === 'Missing Punch' || ($empLog && ($empLog['status'] ?? '') === 'Missing Punch'));
            if ($isMissingPunch && $isTodayOrFuture && $hasInTime && !$hasOutTime) {
                // Today's live check-in with pending evening check-out counts as Present
                $isMissingPunch = false;
                $isPres = true;
                $status = $hasLate ? 'Late' : ($isEarlyClosure ? 'Present (Early Closure)' : 'Present');
            } elseif (!$isMissingPunch && !$isTodayOrFuture && (($hasInTime && !$hasOutTime) || (!$hasInTime && $hasOutTime))) {
                // Past date with single IN or single OUT punch is an unresolved Missing Punch
                $isMissingPunch = true;
                $status = 'Missing Punch';
                $isPres = false;
            }

            // ----------------------------------------------------
            // 6 Mutually Exclusive Primary Buckets (Every active employee belongs to EXACTLY ONE):
            // 1. missing_punch: Unresolved incomplete punch record (shown in Missing Punch card, NOT in Absent)
            // 2. present: Physical attendance at work (includes late, early-out, half-day, leave-with-punch)
            // 3. on_leave: Approved leave with no physical attendance
            // 4. holiday: Unworked calendar / public holiday
            // 5. weekly_off: Unworked rest day / weekend
            // 6. absent: Unexcused absence on scheduled working day (directly counted, not by subtraction)
            // ----------------------------------------------------
            $empWeeklyOffDays = $weeklyOffLookup[$emp['id'] ?? ''] ?? $companyWeeklyOffDays;
            $isEmpWeekend = in_array($dayOfWeekName, $empWeeklyOffDays, true);
            $isOnLeaveRecord = !empty($calc['is_on_leave']) || str_contains(strtolower($status), 'leave') || !empty($empLog['is_on_leave']);

            $primaryBucket = 'absent';

            if ($isMissingPunch) {
                $primaryBucket = 'missing_punch';
                $missingPunch++;
            } elseif ($isPres || ($hasInTime && !in_array($status, ['Holiday', 'Weekly Off'], true))) {
                $primaryBucket = 'present';
                $present++;

                if ($hasLate) {
                    $late++;
                }
                if ($hasEarly) {
                    $earlyOut++;
                }
                if ($status === 'Half Day' || (!$isEarlyClosure && $workHours > 0 && $workHours < 4.0)) {
                    $halfDay++;
                }

                // If employee had an approved leave but physically came to work and punched (leave plus punch),
                // physical presence trumps leave. Set display status to reflect presence while not double-counting leave.
                if (str_contains(strtolower($status), 'leave')) {
                    $status = ($workHours > 0 && $workHours < 4.0) ? 'Half Day' : ($hasLate ? 'Late' : 'Present');
                    $calc['status'] = $status;
                }
            } elseif ($isOnLeaveRecord) {
                $primaryBucket = 'on_leave';
                $onLeave++;
            } elseif (!empty($calc['is_holiday']) || $status === 'Holiday' || ($isEmpHoliday && !$hasInTime)) {
                $primaryBucket = 'holiday';
                $holidayCount++;
            } elseif (!empty($calc['is_weekly_off']) || $status === 'Weekly Off' || ($isEmpWeekend && !$hasInTime)) {
                $primaryBucket = 'weekly_off';
                $weeklyOffCount++;
            } else {
                if ($exceptHolidaysWeekends && ($isEmpWeekend || $isEmpHoliday)) {
                    if ($isEmpHoliday) {
                        $primaryBucket = 'holiday';
                        $holidayCount++;
                    } else {
                        $primaryBucket = 'weekly_off';
                        $weeklyOffCount++;
                    }
                } else {
                    $primaryBucket = 'absent';
                    $absent++;
                }
            }

            // Construct detailed log item for Overview and Matrix views
            $detailedLogs[] = [
                'id'                  => $empLog['id'] ?? ('syn-' . $emp['id'] . '-' . $date),
                'attendance_id'       => $empLog['id'] ?? ('syn-' . $emp['id'] . '-' . $date),
                'employee_id'         => $emp['id'],
                'employee_code'       => $emp['employee_code'] ?? $emp['id'],
                'employee_name'       => $emp['name'],
                'company_id'          => $emp['company_id'] ?? $companyId,
                'department_id'       => $emp['department_id'] ?? '',
                'department_name'     => $emp['department_name'] ?? 'General',
                'branch_id'           => $emp['branch_id'] ?? '',
                'branch_name'         => $emp['branch_name'] ?? 'Main Office',
                'designation_id'      => $emp['designation_id'] ?? '',
                'designation_name'    => $emp['designation_name'] ?? 'Staff',
                'shift_name'          => $emp['shift_name'] ?? 'General Shift',
                'shift_start'         => $shift['start_time'],
                'shift_end'           => $shift['end_time'],
                'date'                => $date,
                'attendance_date'     => $date,
                'check_in'            => $inTime ?: '--:--:--',
                'check_out'           => $outTime ?: '--:--:--',
                'working_hours'       => $workHours,
                'overtime_hours'      => $otHours,
                'late_minutes'        => $lateMins,
                'early_out_minutes'   => $earlyMins,
                'status'              => $status,
                'primary_bucket'      => $primaryBucket,
                'verification_method' => $empLog['verification_method'] ?? 'Web',
                'is_company_closure'  => $isEarlyClosure ? 1 : 0,
                'closure_credit_hours'=> (float)($empLog['closure_credit_hours'] ?? 0),
                'actual_worked_hours' => (float)($empLog['actual_worked_hours'] ?? 0),
                'photo'               => $emp['photo'] ?? null,
                'avatar'              => $emp['photo'] ?? null,
                'is_late'             => $hasLate,
                'is_early_out'        => $hasEarly,
                'notes'               => $empLog['notes'] ?? ''
            ];

            // Accumulate metrics
            $totalWorkingHours += $workHours;
            $totalOvertime += $otHours;

            if ($isEarlyClosure) {
                $earlyClosureCount++;
            }

            if (($empLog['verification_method'] ?? '') === 'WFH' || ($empLog['verification_method'] ?? '') === 'Remote') {
                $wfh++;
            }
        }
        } finally {
            \App\Services\RuleEngineService::$skipClosureLookup = $prevSkipClosure;
        }

        // Mathematical invariant: primary buckets must sum exactly to totalActive
        $primaryBucketSum = $present + $onLeave + $holidayCount + $weeklyOffCount + $missingPunch + $absent;
        if (!$isFuture && $primaryBucketSum !== $totalActive) {
            log_message('error', "AttendanceRuleEngine bucket invariant failure on {$date}: sum={$primaryBucketSum}, totalActive={$totalActive}");
        }

        // Authoritative absence calculation for future dates
        if ($isFuture) {
            $absent = 0;
            $present = 0;
            $late = 0;
            $earlyOut = 0;
            $halfDay = 0;
            $missingPunch = 0;
            $totalWorkingHours = 0.0;
            $totalOvertime = 0.0;
        }

        $presenceRate = $totalActive > 0 ? round(($present / $totalActive) * 100, 1) : 0;
        $punctualityRate = $present > 0 ? round((max(0, $present - $late) / $present) * 100, 1) : 100;

        $stats = [
            'date'                   => $date,
            'day_of_week'            => $dayOfWeekName,
            'is_weekend'             => $isCompanyWeekend,
            'is_friday_weekend'      => in_array('Friday', $companyWeeklyOffDays, true) && ($dayOfWeekName === 'Friday'),
            'is_holiday'             => $isCompanyHolidayDate,
            'holiday_name'           => $primaryHolidayName,
            'company_weekly_off'     => $companyWeeklyOffDays,
            'except_holidays_weekends' => $exceptHolidaysWeekends,
            'totalActive'            => $totalActive,
            'totalEmployees'         => $totalActive,
            'total_active'           => $totalActive,
            'present'                => $present,
            'late'                   => $late,
            'halfDay'                => $halfDay,
            'half_day'               => $halfDay,
            'absent'                 => $absent,
            'onLeave'                => $onLeave,
            'on_leave'               => $onLeave,
            'earlyOut'               => $earlyOut,
            'early_out'              => $earlyOut,
            'missingPunch'           => $missingPunch,
            'missing_punch'          => $missingPunch,
            'earlyClosureCount'      => $earlyClosureCount,
            'early_closure_count'    => $earlyClosureCount,
            'wfh'                    => $wfh,
            'unmappedBiometric'      => $unmappedBiometricCount,
            'unmappedBiometricCount' => $unmappedBiometricCount,
            'holiday'                => $holidayCount,
            'holiday_count'          => $holidayCount,
            'weeklyOff'              => $weeklyOffCount,
            'weekly_off_count'       => $weeklyOffCount,
            'totalOvertime'          => round($totalOvertime, 1),
            'totalOvertimeHours'     => round($totalOvertime, 1),
            'total_overtime'         => round($totalOvertime, 1),
            'totalWorkingHours'      => round($totalWorkingHours, 1),
            'totalWorkedHours'       => round($totalWorkingHours, 1),
            'total_working_hours'    => round($totalWorkingHours, 1),
            'attendanceRate'         => $presenceRate,
            'presenceRate'           => $presenceRate,
            'punctualityRate'        => $punctualityRate,
            'grace_minutes'          => $primaryGraceMinutes ?? (int)($settings['graceTime'] ?? 15),
            'graceMinutes'           => $primaryGraceMinutes ?? (int)($settings['graceTime'] ?? 15),
            'primary_bucket_sum'     => $primaryBucketSum,
            'is_future'              => $isFuture
        ];

        // Apply search and status filters to detailed logs if requested
        $filteredLogs = $detailedLogs;
        if (!empty($statusFilter) && $statusFilter !== 'all') {
            $filteredLogs = array_values(array_filter($filteredLogs, function ($item) use ($statusFilter) {
                if ($statusFilter === 'Present') {
                    return AttendanceModel::isPresentLike($item['status'] ?? '', $item);
                }
                if ($statusFilter === 'Late') {
                    return !empty($item['is_late']) || in_array($item['status'] ?? '', ['Late', 'Late & Early Out'], true);
                }
                if ($statusFilter === 'Early Out') {
                    return !empty($item['is_early_out']) || in_array($item['status'] ?? '', ['Early Out', 'Late & Early Out'], true);
                }
                if ($statusFilter === 'Absent') {
                    return ($item['primary_bucket'] ?? '') === 'absent'
                        || strcasecmp($item['status'] ?? '', 'Absent') === 0
                        || stripos($item['status'] ?? '', 'absent') !== false;
                }
                if ($statusFilter === 'Missing Punch' || $statusFilter === 'missing_punch') {
                    return ($item['primary_bucket'] ?? '') === 'missing_punch'
                        || strcasecmp($item['status'] ?? '', 'Missing Punch') === 0
                        || strcasecmp($item['status'] ?? '', 'missing_punch') === 0;
                }
                return strcasecmp($item['status'] ?? '', $statusFilter) === 0;
            }));
        }

        if (!empty($search)) {
            $s = strtolower(trim($search));
            $filteredLogs = array_values(array_filter($filteredLogs, function ($item) use ($s) {
                return str_contains(strtolower($item['employee_name'] ?? ''), $s)
                    || str_contains(strtolower($item['employee_code'] ?? ''), $s)
                    || str_contains(strtolower($item['department_name'] ?? ''), $s);
            }));
        }

        // Execute single batched update only if autoHealDb is explicitly enabled (e.g. background task or admin action)
        if ($autoHealDb && !empty($pendingHealUpdates)) {
            try {
                $this->db->table('attendance_logs')->updateBatch($pendingHealUpdates, 'id');
            } catch (\Throwable $e) {
                log_message('error', 'AttendanceRuleEngine batch heal error: ' . $e->getMessage());
            }
        }

        $returnPayload = [
            'date'               => $date,
            'stats'              => $stats,
            'employees'          => $employees,
            'logs'               => $logs,
            'detailedLogs'       => $filteredLogs,
            'allDetailedLogs'    => $detailedLogs,
            'leaves'             => $leaves,
            'holidays'           => $holidays,
            'calculated_results' => $calculatedResults,
            'serverCalculations' => $serverCalculations,
            'pendingHealUpdates' => $pendingHealUpdates
        ];

        // Store into per-request calculation cache
        if (empty($statusFilter) && empty($search)) {
            self::$calculationCache[$cacheKey] = $returnPayload;
        } else {
            if (!isset(self::$calculationCache[$cacheKey])) {
                $baseCopy = $returnPayload;
                $baseCopy['detailedLogs'] = $detailedLogs;
                self::$calculationCache[$cacheKey] = $baseCopy;
            }
        }

        return $returnPayload;
    }

    /**
     * Authoritative calculation engine for a date range with company holiday and weekend handling.
     * When $exceptHolidaysWeekends is true, weekends (e.g. Friday) and official holidays are excluded
     * from the required muster and absent calculations.
     */
    public function calculateAttendanceForDateRange(
        string $fromDate,
        string $toDate,
        ?string $branchId = null,
        ?string $deptId = null,
        ?string $companyId = null,
        ?string $statusFilter = null,
        ?string $search = null,
        ?array $preloadedEmployees = null,
        bool $exceptHolidaysWeekends = false
    ): array {
        if ($branchId === 'all') $branchId = null;
        if ($deptId === 'all') $deptId = null;
        $today = date('Y-m-d');
        if ($fromDate > $toDate) {
            $tmp = $fromDate;
            $fromDate = $toDate;
            $toDate = $tmp;
        }

        // Multi-Tenant Scoping Guard:
        // Refuse to calculate attendance across multiple companies in an un-scoped pass.
        if (empty($companyId)) {
            return $this->calculateAttendanceForDateRangeMultiCompany(
                $fromDate,
                $toDate,
                $branchId,
                $deptId,
                $statusFilter,
                $search,
                $preloadedEmployees,
                $exceptHolidaysWeekends
            );
        }

        // Limit range span to max 62 days for safety and high performance
        $startTs = strtotime($fromDate);
        $endTs = strtotime($toDate);
        $diffDays = (int)(($endTs - $startTs) / 86400);
        if ($diffDays > 62) {
            $endTs = strtotime($fromDate . ' +62 days');
            $toDate = date('Y-m-d', $endTs);
        }

        // Preload company weekly off
        $defaultCompanyWeeklyOff = CompanyWeekendService::getCompanyWeeklyOff($companyId, null, false, $fromDate);

        // Preload holidays covering the range
        $rangeHolidays = [];
        $rangeHolidaysByCompany = [];
        if ($this->db->tableExists('holidays')) {
            try {
                $compKey = $companyId ?: '__all__';
                if (!isset(self::$holidayCache[$compKey])) {
                    self::$holidayCache[$compKey] = (new HolidayModel())->getOrderedHolidays($companyId);
                }
                $rawHolidays = self::$holidayCache[$compKey];
                foreach ($rawHolidays as $rh) {
                    $hStart = $rh['from_date'] ?? ($rh['date'] ?? '');
                    $hEnd = $rh['to_date'] ?? ($rh['date'] ?? $hStart);
                    if ($hStart <= $toDate && $hEnd >= $fromDate) {
                        $hItem = [
                            'id'         => $rh['id'] ?? '',
                            'name'       => $rh['name'] ?? 'Holiday',
                            'from_date'  => $hStart,
                            'to_date'    => $hEnd,
                            'type'       => $rh['type'] ?? ($rh['holiday_type'] ?? 'public'),
                            'company_id' => $rh['company_id'] ?? $companyId,
                            'branch_id'  => $rh['branch_id'] ?? null
                        ];
                        $rangeHolidays[] = $hItem;
                        $hComp = (string)($hItem['company_id'] ?? '');
                        if ($hComp !== '') {
                            $rangeHolidaysByCompany[$hComp][] = $hItem;
                        } else {
                            $rangeHolidaysByCompany['__global__'][] = $hItem;
                        }
                    }
                }
            } catch (\Throwable $e) {}
        }

        // Determine day metadata for each date in range
        $calendarDays = [];
        $workingDates = [];
        $weekendDates = [];
        $holidayDates = [];

        $currTs = $startTs;
        while ($currTs <= $endTs) {
            $cDate = date('Y-m-d', $currTs);
            $dayName = date('l', $currTs);
            $isWeekend = in_array($dayName, $defaultCompanyWeeklyOff, true);
            $isFridayWeekend = ($dayName === 'Friday' && in_array('Friday', $defaultCompanyWeeklyOff, true));

            $matchedHoliday = null;
            foreach ($rangeHolidays as $rh) {
                if ($cDate >= $rh['from_date'] && $cDate <= $rh['to_date']) {
                    $matchedHoliday = $rh;
                    break;
                }
            }
            $isHoliday = ($matchedHoliday !== null);

            $dayMeta = [
                'date'              => $cDate,
                'day_of_week'       => $dayName,
                'is_weekend'        => $isWeekend,
                'is_friday_weekend' => $isFridayWeekend,
                'is_holiday'        => $isHoliday,
                'holiday_name'      => $matchedHoliday['name'] ?? '',
                'is_excepted'       => ($exceptHolidaysWeekends && ($isWeekend || $isHoliday))
            ];
            $calendarDays[$cDate] = $dayMeta;

            if ($isHoliday) {
                $holidayDates[] = $cDate;
            } elseif ($isWeekend) {
                $weekendDates[] = $cDate;
            } else {
                $workingDates[] = $cDate;
            }

            $currTs = strtotime('+1 day', $currTs);
        }

        // Fetch all detailed logs across the range using AttendanceModel
        $attModel = new \App\Models\AttendanceModel();
        $rawLogs = $attModel->getDetailedLogs(null, $branchId, $deptId, $statusFilter, $search, $fromDate, $toDate, null, $companyId);

        // Preload active salaries and weekly-off for employees
        $empModel = new \App\Models\EmployeeModel();
        if ($preloadedEmployees !== null) {
            $allEmpList = $preloadedEmployees;
        } else {
            $empQuery = (new \App\Models\EmployeeModel());
            if (!empty($companyId)) {
                $empQuery->where('company_id', $companyId);
            }
            $empModel->applyEmploymentTenureRangeFilter($empQuery, $fromDate, $toDate, 'employees');
            if ($this->db->fieldExists('deleted_at', 'employees')) {
                $empQuery->where('employees.deleted_at IS NULL');
            }
            $allEmpList = $empQuery->findAll();
        }
        $empMap = [];
        $empIds = [];
        foreach ($allEmpList as $ae) {
            $eid = (string)($ae['id'] ?? '');
            if ($eid) {
                $empMap[$eid] = $ae;
                $empIds[] = $eid;
            }
        }
        (new \App\Services\EmployeeSalaryService())->preloadActiveSalaries($empIds, $toDate);

        // Process and enrich each log record with weekend and holiday flags
        $rangeLogs = [];
        $totPresent = 0;
        $totLate = 0;
        $totEarlyOut = 0;
        $totHalfDay = 0;
        $totOnLeave = 0;
        $totWeeklyOff = 0;
        $totHoliday = 0;
        $totMissingPunch = 0;
        $totAbsent = 0;
        $totWorkedHours = 0.0;
        $totOvertimeHours = 0.0;

        foreach ($rawLogs as $l) {
            $lDate = $l['date'] ?? $l['attendance_date'] ?? '';
            $logEmpId = (string)($l['employee_id'] ?? '');
            $empRow = $empMap[$logEmpId] ?? null;
            $logComp = (string)($l['company_id'] ?? ($empRow['company_id'] ?? $companyId));

            $isLogHoliday = false;
            $logHolidayName = '';
            $checkRangeHolidays = !empty($companyId)
                ? $rangeHolidays
                : array_merge($rangeHolidaysByCompany[$logComp] ?? [], $rangeHolidaysByCompany['__global__'] ?? []);

            foreach ($checkRangeHolidays as $rh) {
                if ($lDate >= $rh['from_date'] && $lDate <= $rh['to_date']) {
                    if (empty($rh['branch_id']) || (string)$rh['branch_id'] === (string)($l['branch_id'] ?? '')) {
                        $isLogHoliday = true;
                        $logHolidayName = $rh['name'];
                        break;
                    }
                }
            }

            $dayMeta = $calendarDays[$lDate] ?? [
                'date'              => $lDate,
                'day_of_week'       => date('l', strtotime($lDate ?: $today)),
                'is_weekend'        => false,
                'is_friday_weekend' => (date('l', strtotime($lDate ?: $today)) === 'Friday' && in_array('Friday', $defaultCompanyWeeklyOff, true)),
                'is_holiday'        => false,
                'holiday_name'      => '',
                'is_excepted'       => false
            ];

            // If exceptHolidaysWeekends is active, skip non-working dates unless they have actual punches
            $hasCheckIn = !empty($l['check_in']) && $l['check_in'] !== '--:--:--' && $l['check_in'] !== '---';
            if ($exceptHolidaysWeekends && ($dayMeta['is_weekend'] || $isLogHoliday) && !$hasCheckIn) {
                continue;
            }

            $stat = $l['status'] ?? 'Absent';
            if (!$hasCheckIn) {
                if ($isLogHoliday) {
                    $stat = 'Holiday';
                    $l['status'] = 'Holiday';
                } elseif ($dayMeta['is_weekend']) {
                    $stat = 'Weekly Off';
                    $l['status'] = 'Weekly Off';
                }
            } else {
                if ($isLogHoliday) {
                    $stat = 'Holiday Duty Present';
                    $l['status'] = 'Holiday Duty Present';
                } elseif ($dayMeta['is_weekend']) {
                    $stat = 'Weekend Duty Present';
                    $l['status'] = 'Weekend Duty Present';
                }
            }

            $wHrs = (float)($l['working_hours'] ?? 0);
            $otHrs = (float)($l['overtime_hours'] ?? 0);
            $lateMins = (int)($l['late_minutes'] ?? 0);
            $earlyMins = (int)($l['early_out_minutes'] ?? 0);

            $l['day_of_week'] = $dayMeta['day_of_week'];
            $l['is_weekend'] = $dayMeta['is_weekend'];
            $l['is_friday_weekend'] = $dayMeta['is_friday_weekend'];
            $l['is_holiday'] = $isLogHoliday;
            $l['holiday_name'] = $logHolidayName;
            $l['is_excepted'] = $dayMeta['is_excepted'];

            $isRangeEarlyClosure = AttendanceModel::isClosureLog($l)
                || in_array($stat, ['Present (Early Closure)', 'Approved Early Closure', 'Early Closure Covered'], true);
            if ($isRangeEarlyClosure) {
                $isRangeLate = ($lateMins > 0 || in_array($stat, ['Late', 'Late & Early Out'], true));
                $stat = $isRangeLate ? 'Late' : 'Present (Early Closure)';
                $l['status'] = $stat;
                $earlyMins = 0;
                $l['early_out_minutes'] = 0;
                if ($wHrs <= 0) {
                    $wHrs = (float)($l['working_hours'] ?? ($l['closure_credit_hours'] ?? 8.0));
                    $l['working_hours'] = $wHrs;
                }
            }
            $isRangeMissing = ($stat === 'Missing Punch');
            $hasRangeIn = !empty($l['check_in']) && $l['check_in'] !== '--:--' && $l['check_in'] !== '--:--:--';
            $hasRangeOut = !empty($l['check_out']) && $l['check_out'] !== '--:--' && $l['check_out'] !== '--:--:--';
            $isRangePastDate = ($lDate < $today);

            if (!$isRangeMissing && $isRangePastDate && (($hasRangeIn && !$hasRangeOut) || (!$hasRangeIn && $hasRangeOut))) {
                $isRangeMissing = true;
                $stat = 'Missing Punch';
                $l['status'] = 'Missing Punch';
            }

            if ($isRangeMissing) {
                $totMissingPunch++;
            } elseif (AttendanceModel::isPresentLike($stat, $l) || in_array($stat, ['WFH', 'Remote'], true) || $isRangeEarlyClosure || ($hasRangeIn && !in_array($stat, ['Holiday', 'Weekly Off'], true))) {
                $totPresent++;
                if ($stat === 'Late' || $lateMins > 0) $totLate++;
                if (!$isRangeEarlyClosure && ($stat === 'Early Out' || $earlyMins > 0)) $totEarlyOut++;
                if (!$isRangeEarlyClosure && $stat === 'Half Day') $totHalfDay++;
            } elseif (str_contains(strtolower($stat), 'leave')) {
                $totOnLeave++;
            } elseif ($stat === 'Holiday' || ($dayMeta['is_holiday'] && !$hasRangeIn)) {
                $totHoliday++;
            } elseif ($stat === 'Weekly Off' || ($dayMeta['is_weekend'] && !$hasRangeIn)) {
                $totWeeklyOff++;
            } else {
                $totAbsent++;
            }

            $totWorkedHours += $wHrs;
            $totOvertimeHours += $otHrs;

            $rangeLogs[] = $l;
        }

        $activeStaffCount = count($allEmpList);
        $totalWorkingDaysCount = count($workingDates);
        $totalWeekendDaysCount = count($weekendDates);
        $totalHolidayDaysCount = count($holidayDates);

        $totLogsCount = count($rangeLogs);
        $rangePresenceRate = $totLogsCount > 0 ? round(($totPresent / $totLogsCount) * 100, 1) : 0;
        $rangePunctualityRate = $totPresent > 0 ? round((max(0, $totPresent - $totLate) / $totPresent) * 100, 1) : 100;

        $stats = [
            'date'                      => $fromDate,
            'from_date'                 => $fromDate,
            'to_date'                   => $toDate,
            'is_date_range'             => true,
            'total_calendar_days'       => count($calendarDays),
            'working_days_count'        => $totalWorkingDaysCount,
            'weekend_days_count'        => $totalWeekendDaysCount,
            'holiday_days_count'        => $totalHolidayDaysCount,
            'except_holidays_weekends'  => $exceptHolidaysWeekends,
            'totalActive'               => $activeStaffCount,
            'totalEmployees'            => $activeStaffCount,
            'total_active'              => $activeStaffCount,
            'present'                   => $totPresent,
            'late'                      => $totLate,
            'earlyOut'                  => $totEarlyOut,
            'halfDay'                   => $totHalfDay,
            'absent'                    => $totAbsent,
            'onLeave'                   => $totOnLeave,
            'holiday'                   => $totHoliday,
            'holiday_count'             => $totHoliday,
            'weeklyOff'                 => $totWeeklyOff,
            'weekly_off_count'          => $totWeeklyOff,
            'missingPunch'              => $totMissingPunch,
            'missing_punch'             => $totMissingPunch,
            'totalWorkingHours'         => round($totWorkedHours, 1),
            'totalWorkedHours'          => round($totWorkedHours, 1),
            'totalOvertime'             => round($totOvertimeHours, 1),
            'totalOvertimeHours'        => round($totOvertimeHours, 1),
            'presenceRate'              => $rangePresenceRate,
            'punctualityRate'           => $rangePunctualityRate,
            'company_weekly_off'        => $defaultCompanyWeeklyOff,
            'is_friday_weekend'         => in_array('Friday', $defaultCompanyWeeklyOff, true),
            'is_weekend'                => in_array(date('l', strtotime($fromDate)), $defaultCompanyWeeklyOff, true),
            'is_holiday'                => !empty($rangeHolidays),
            'is_future'                 => ($fromDate > $today)
        ];

        return [
            'from_date'            => $fromDate,
            'to_date'              => $toDate,
            'is_date_range'        => true,
            'stats'                => $stats,
            'calendarDays'         => $calendarDays,
            'detailedLogs'         => $rangeLogs,
            'allDetailedLogs'      => $rangeLogs,
            'logs'                 => $rangeLogs,
            'employees'            => $allEmpList,
            'serverCalculations'   => []
        ];
    }

    /**
     * Executes authoritative attendance calculation per tenant company and merges results.
     * Prevents cross-company collisions of employee codes, logs, holidays, and leaves.
     */
    protected function calculateAttendanceForDateMultiCompany(
        string $date,
        ?string $branchId,
        ?string $deptId,
        ?string $statusFilter,
        ?string $search,
        ?array $preloadedEmployees,
        bool $autoHealDb,
        bool $exceptHolidaysWeekends
    ): array {
        // Resolve employee pool across all companies if not preloaded
        $employees = $preloadedEmployees;
        if ($employees === null) {
            $hasShiftGrace = false;
            if ($this->db->tableExists('shifts')) {
                $shiftCols = $this->db->getFieldNames('shifts');
                $hasShiftGrace = in_array('grace_time', $shiftCols, true);
            }
            $graceSelect = $hasShiftGrace ? 'shifts.grace_time as grace_time' : '15 as grace_time';

            $empModel = new \App\Models\EmployeeModel();
            $sepSql = $empModel->getSeparationDateSql('employees.');

            $empBuilder = $this->db->table('employees')
                ->select("employees.*, departments.name as department_name, branches.name as branch_name, designations.name as designation_name, shifts.name as shift_name, shifts.start_time, shifts.end_time, shifts.weekly_off, shifts.work_days, {$graceSelect}, {$sepSql} as separation_date")
                ->join('departments', 'departments.id = employees.department_id', 'left')
                ->join('branches', 'branches.id = employees.branch_id', 'left')
                ->join('designations', 'designations.id = employees.designation_id', 'left')
                ->join('shifts', 'shifts.id = employees.shift_id', 'left');

            $empModel->applyEmploymentTenureFilter($empBuilder, $date, 'employees');

            if ($this->db->fieldExists('deleted_at', 'employees')) {
                $empBuilder->where('employees.deleted_at IS NULL');
            }

            if (!empty($branchId)) {
                $empBuilder->where('employees.branch_id', $branchId);
            }
            if (!empty($deptId)) {
                $empBuilder->where('employees.department_id', $deptId);
            }

            $employees = $empBuilder->orderBy('employees.first_name', 'ASC')->get()->getResultArray();
        }

        if (empty($employees)) {
            return $this->buildEmptyAttendanceResult($date);
        }

        // Group employees by company_id
        $byCompany = [];
        foreach ($employees as $re) {
            $cId = (string)($re['company_id'] ?? '');
            if ($cId !== '') {
                $byCompany[$cId][] = $re;
            }
        }

        if (empty($byCompany)) {
            return $this->buildEmptyAttendanceResult($date);
        }

        $mergedStats = [
            'total_active'        => 0,
            'present'             => 0,
            'late'                => 0,
            'early_out'           => 0,
            'half_day'            => 0,
            'on_leave'            => 0,
            'holiday'             => 0,
            'holiday_count'       => 0,
            'weekly_off'          => 0,
            'weekly_off_count'    => 0,
            'missing_punch'       => 0,
            'absent'              => 0,
            'early_closure'       => 0,
            'wfh'                 => 0,
            'total_working_hours' => 0.0,
            'total_overtime'      => 0.0,
            'total_overtime_minutes' => 0,
            'presence_rate'       => 0,
            'punctuality_rate'    => 100,
            'unmapped_biometric_count' => 0,
            'is_company_closure'  => false,
            'closure_credit_hours'=> 0.0,
            'closure_remarks'     => ''
        ];

        $mergedEmployees = [];
        $mergedLogs = [];
        $mergedDetailedLogs = [];
        $mergedAllDetailedLogs = [];
        $mergedLeaves = [];
        $mergedHolidays = [];
        $mergedCalculatedResults = [];
        $mergedServerCalculations = [];
        $mergedPendingHeal = [];

        foreach ($byCompany as $cId => $compEmployees) {
            try {
                $sub = $this->calculateAttendanceForDate(
                    $date,
                    $branchId,
                    $deptId,
                    $cId,
                    $statusFilter,
                    $search,
                    $compEmployees,
                    $autoHealDb,
                    $exceptHolidaysWeekends
                );
            } catch (\App\Services\Rules\RuleNotConfiguredException $eRule) {
                log_message('error', "Multi-company attendance skipped tenant '{$cId}' due to unconfigured rule: " . $eRule->getMessage());
                continue;
            } catch (\Throwable $eGen) {
                log_message('error', "Multi-company attendance calculation failed for tenant '{$cId}': " . $eGen->getMessage());
                continue;
            }

            // Accumulate counts
            $s = $sub['stats'] ?? [];
            $mergedStats['total_active'] += (int)($s['total_active'] ?? 0);
            $mergedStats['present'] += (int)($s['present'] ?? 0);
            $mergedStats['late'] += (int)($s['late'] ?? 0);
            $mergedStats['early_out'] += (int)($s['early_out'] ?? 0);
            $mergedStats['half_day'] += (int)($s['half_day'] ?? 0);
            $mergedStats['on_leave'] += (int)($s['on_leave'] ?? 0);
            $mergedStats['holiday'] += (int)($s['holiday'] ?? 0);
            $mergedStats['holiday_count'] += (int)($s['holiday_count'] ?? ($s['holiday'] ?? 0));
            $mergedStats['weekly_off'] += (int)($s['weekly_off'] ?? 0);
            $mergedStats['weekly_off_count'] += (int)($s['weekly_off_count'] ?? ($s['weekly_off'] ?? 0));
            $mergedStats['missing_punch'] += (int)($s['missing_punch'] ?? 0);
            $mergedStats['absent'] += (int)($s['absent'] ?? 0);
            $mergedStats['early_closure'] += (int)($s['early_closure'] ?? 0);
            $mergedStats['wfh'] += (int)($s['wfh'] ?? 0);
            $mergedStats['total_working_hours'] += (float)($s['total_working_hours'] ?? 0);
            $mergedStats['total_overtime'] += (float)($s['total_overtime'] ?? 0);
            $mergedStats['total_overtime_minutes'] += (int)($s['total_overtime_minutes'] ?? 0);
            $mergedStats['unmapped_biometric_count'] += (int)($s['unmapped_biometric_count'] ?? 0);

            $mergedEmployees = array_merge($mergedEmployees, $sub['employees'] ?? []);
            $mergedLogs = array_merge($mergedLogs, $sub['logs'] ?? []);
            $mergedDetailedLogs = array_merge($mergedDetailedLogs, $sub['detailedLogs'] ?? []);
            $mergedAllDetailedLogs = array_merge($mergedAllDetailedLogs, $sub['allDetailedLogs'] ?? []);
            $mergedLeaves = array_merge($mergedLeaves, $sub['leaves'] ?? []);
            $mergedHolidays = array_merge($mergedHolidays, $sub['holidays'] ?? []);
            $mergedCalculatedResults = array_merge($mergedCalculatedResults, $sub['calculated_results'] ?? []);
            $mergedPendingHeal = array_merge($mergedPendingHeal, $sub['pendingHealUpdates'] ?? []);

            // For serverCalculations: key by scoped composite key and non-colliding employee ID
            foreach ($sub['serverCalculations'] ?? [] as $k => $sc) {
                $mergedServerCalculations[$cId . '_' . $k] = $sc;
                if (!isset($mergedServerCalculations[$k])) {
                    $mergedServerCalculations[$k] = $sc;
                }
            }
        }

        if ($mergedStats['total_active'] > 0) {
            $mergedStats['presence_rate'] = (int)round(($mergedStats['present'] / $mergedStats['total_active']) * 100);
            $mergedStats['punctuality_rate'] = ($mergedStats['present'] > 0)
                ? (int)round((($mergedStats['present'] - $mergedStats['late']) / $mergedStats['present']) * 100)
                : 100;
        }

        return [
            'date'               => $date,
            'stats'              => $mergedStats,
            'employees'          => $mergedEmployees,
            'logs'               => $mergedLogs,
            'detailedLogs'       => $mergedDetailedLogs,
            'allDetailedLogs'    => $mergedAllDetailedLogs,
            'leaves'             => $mergedLeaves,
            'holidays'           => $mergedHolidays,
            'calculated_results' => $mergedCalculatedResults,
            'serverCalculations' => $mergedServerCalculations,
            'pendingHealUpdates' => $mergedPendingHeal
        ];
    }

    /**
     * Executes authoritative range calculation per tenant company and merges results.
     */
    protected function calculateAttendanceForDateRangeMultiCompany(
        string $fromDate,
        string $toDate,
        ?string $branchId,
        ?string $deptId,
        ?string $statusFilter,
        ?string $search,
        ?array $preloadedEmployees,
        bool $exceptHolidaysWeekends
    ): array {
        if ($preloadedEmployees !== null) {
            $employees = $preloadedEmployees;
        } else {
            $empModel = new \App\Models\EmployeeModel();
            $empQuery = (new \App\Models\EmployeeModel());
            $empModel->applyEmploymentTenureRangeFilter($empQuery, $fromDate, $toDate, 'employees');
            if ($this->db->fieldExists('deleted_at', 'employees')) {
                $empQuery->where('employees.deleted_at IS NULL');
            }
            $employees = $empQuery->findAll();
        }

        if (empty($employees)) {
            return [
                'from_date'          => $fromDate,
                'to_date'            => $toDate,
                'is_date_range'      => true,
                'stats'              => [],
                'calendarDays'       => [],
                'detailedLogs'       => [],
                'allDetailedLogs'    => [],
                'logs'               => [],
                'employees'          => [],
                'serverCalculations' => []
            ];
        }

        $byCompany = [];
        foreach ($employees as $emp) {
            $cId = (string)($emp['company_id'] ?? '');
            if ($cId !== '') {
                $byCompany[$cId][] = $emp;
            }
        }

        if (empty($byCompany)) {
            return [
                'from_date'          => $fromDate,
                'to_date'            => $toDate,
                'is_date_range'      => true,
                'stats'              => [],
                'calendarDays'       => [],
                'detailedLogs'       => [],
                'allDetailedLogs'    => [],
                'logs'               => [],
                'employees'          => [],
                'serverCalculations' => []
            ];
        }

        $mergedLogs = [];
        $mergedCalendarDays = [];
        $mergedStats = [
            'total_active'        => 0,
            'present'             => 0,
            'late'                => 0,
            'early_out'           => 0,
            'half_day'            => 0,
            'on_leave'            => 0,
            'holiday'             => 0,
            'weekly_off'          => 0,
            'missing_punch'       => 0,
            'absent'              => 0,
            'totalWorkingHours'   => 0.0,
            'totalOvertime'       => 0.0,
            'presenceRate'        => 0,
            'punctualityRate'     => 100,
            'is_date_range'       => true
        ];

        foreach ($byCompany as $cId => $compEmployees) {
            $sub = $this->calculateAttendanceForDateRange(
                $fromDate,
                $toDate,
                $branchId,
                $deptId,
                $cId,
                $statusFilter,
                $search,
                $compEmployees,
                $exceptHolidaysWeekends
            );

            $s = $sub['stats'] ?? [];
            $mergedStats['total_active'] += (int)($s['total_active'] ?? 0);
            $mergedStats['present'] += (int)($s['present'] ?? 0);
            $mergedStats['late'] += (int)($s['late'] ?? 0);
            $mergedStats['early_out'] += (int)($s['early_out'] ?? 0);
            $mergedStats['half_day'] += (int)($s['half_day'] ?? 0);
            $mergedStats['on_leave'] += (int)($s['on_leave'] ?? 0);
            $mergedStats['holiday'] += (int)($s['holiday'] ?? 0);
            $mergedStats['weekly_off'] += (int)($s['weekly_off'] ?? 0);
            $mergedStats['missing_punch'] += (int)($s['missing_punch'] ?? 0);
            $mergedStats['absent'] += (int)($s['absent'] ?? 0);
            $mergedStats['totalWorkingHours'] += (float)($s['totalWorkingHours'] ?? 0);
            $mergedStats['totalOvertime'] += (float)($s['totalOvertime'] ?? 0);
            if (!isset($mergedStats['grace_minutes']) && isset($s['grace_minutes'])) {
                $mergedStats['grace_minutes'] = (int)$s['grace_minutes'];
                $mergedStats['graceMinutes']  = (int)$s['grace_minutes'];
            }

            $mergedLogs = array_merge($mergedLogs, $sub['detailedLogs'] ?? []);
            if (empty($mergedCalendarDays) && !empty($sub['calendarDays'])) {
                $mergedCalendarDays = $sub['calendarDays'];
            }
        }

        if ($mergedStats['total_active'] > 0) {
            $mergedStats['presenceRate'] = (int)round(($mergedStats['present'] / $mergedStats['total_active']) * 100);
            $mergedStats['punctualityRate'] = ($mergedStats['present'] > 0)
                ? (int)round((($mergedStats['present'] - $mergedStats['late']) / $mergedStats['present']) * 100)
                : 100;
        }

        return [
            'from_date'          => $fromDate,
            'to_date'            => $toDate,
            'is_date_range'      => true,
            'stats'              => $mergedStats,
            'calendarDays'       => $mergedCalendarDays,
            'detailedLogs'       => $mergedLogs,
            'allDetailedLogs'    => $mergedLogs,
            'logs'               => $mergedLogs,
            'employees'          => $employees,
            'serverCalculations' => []
        ];
    }

    /**
     * Builds empty attendance calculation result structure.
     */
    protected function buildEmptyAttendanceResult(string $date): array
    {
        return [
            'date'               => $date,
            'stats'              => [
                'total_active'             => 0,
                'present'                  => 0,
                'late'                     => 0,
                'early_out'                => 0,
                'half_day'                 => 0,
                'on_leave'                 => 0,
                'holiday'                  => 0,
                'holiday_count'            => 0,
                'weekly_off'               => 0,
                'weekly_off_count'         => 0,
                'missing_punch'            => 0,
                'absent'                   => 0,
                'early_closure'            => 0,
                'wfh'                      => 0,
                'total_working_hours'      => 0.0,
                'total_overtime'           => 0.0,
                'total_overtime_minutes'   => 0,
                'presence_rate'            => 0,
                'punctuality_rate'         => 100,
                'grace_minutes'            => 15,
                'graceMinutes'             => 15,
                'unmapped_biometric_count' => 0,
                'is_company_closure'       => false,
                'closure_credit_hours'     => 0.0,
                'closure_remarks'          => ''
            ],
            'employees'          => [],
            'logs'               => [],
            'detailedLogs'       => [],
            'allDetailedLogs'    => [],
            'leaves'             => [],
            'holidays'           => [],
            'calculated_results' => [],
            'serverCalculations' => [],
            'pendingHealUpdates' => []
        ];
    }
}
