<?php

namespace App\Services;

use App\Libraries\AssetDepreciation;
use App\Libraries\AssetWriteOffReasons;
use App\Models\EmployeeModel;
use App\Models\FinalSettlementModel;
use App\Models\LoanModel;
use App\Services\Rules\RuleResolver;
use App\Services\Gratuity\GratuityCalculator;
use App\Services\LeaveService;
use App\Services\EmployeeSalaryService;
use Config\Database;

class FinalSettlementService
{
    protected EmployeeModel $employeeModel;
    protected FinalSettlementModel $settlementModel;
    protected LoanModel $loanModel;

    public function __construct()
    {
        $this->employeeModel   = new EmployeeModel();
        $this->settlementModel = new FinalSettlementModel();
        $this->loanModel       = new LoanModel();
    }

    /**
     * Calculate comprehensive final settlement breakdown using RuleResolver and authoritative database records.
     * Enforces the single-source rule framework for SETTLEMENT, GRATUITY, LEAVE, and PAYROLL_BASICS domains.
     */
    public function calculateSettlement(string $employeeId, string $lastWorkingDay, array $options = []): array
    {
        $employee = $this->employeeModel->find($employeeId);
        if (!$employee) {
            return ['success' => false, 'message' => 'Employee record not found'];
        }

        $companyId = $employee['company_id'] ?? null;
        if (!$companyId) {
            return ['success' => false, 'message' => 'Employee has no associated company_id'];
        }

        $separationType = $options['separation_type'] ?? 'Resignation';
        $separationDate = $options['separation_date'] ?? $lastWorkingDay;
        $joiningDate    = function_exists('employee_joining_date')
            ? employee_joining_date($employee)
            : ($employee['joining_date'] ?? $employee['hire_date'] ?? $employee['date_of_joining'] ?? null);

        if (!$joiningDate) {
            $joiningDate = date('Y-m-d');
        }

        $activeSalary = null;
        try {
            $salService = class_exists('\Config\Services') && method_exists('\Config\Services', 'salary')
                ? \Config\Services::salary()
                : new EmployeeSalaryService();
            $activeSalary = $salService->getActiveSalary($employeeId, $lastWorkingDay);
        } catch (\Throwable $e) {
            $activeSalary = null;
        }

        $lastBasic = (float)($activeSalary['basic_salary'] ?? $employee['basic_salary'] ?? 0);
        $lastGross = (float)($activeSalary['gross_salary'] ?? $employee['gross_salary'] ?? 0);

        // Resolve rule domains via single source RuleResolver
        $resolver = new RuleResolver();
        $payrollBasicsRule = $resolver->resolve($companyId, 'PAYROLL_BASICS', $lastWorkingDay, $employee);
        $settlementRule    = $resolver->resolve($companyId, 'SETTLEMENT', $lastWorkingDay, $employee);
        $leaveRule         = $resolver->resolve($companyId, 'LEAVE', $lastWorkingDay, $employee);

        $rulesSnapshot = [
            'PAYROLL_BASICS' => [
                'layers' => $payrollBasicsRule->layers(),
                'hash'   => $payrollBasicsRule->sha1(),
            ],
            'SETTLEMENT' => [
                'layers' => $settlementRule->layers(),
                'hash'   => $settlementRule->sha1(),
            ],
            'LEAVE' => [
                'layers' => $leaveRule->layers(),
                'hash'   => $leaveRule->sha1(),
            ],
        ];

        $taxRule = null;
        try {
            $taxRule = $resolver->resolve($companyId, 'TAX', $lastWorkingDay, $employee);
            $rulesSnapshot['TAX'] = [
                'layers' => $taxRule->layers(),
                'hash'   => $taxRule->sha1(),
            ];
        } catch (\Throwable $e) {
            $taxRule = null;
        }

        // 1. Gratuity Calculation (Powered by single source GratuityCalculator)
        $calculator = new GratuityCalculator($resolver);
        $gratuityResult = $calculator->calculateFinalSettlement(
            $companyId,
            $employee,
            $lastWorkingDay,
            $lastBasic,
            $separationType,
            $lastGross,
            $options
        );

        if (!empty($gratuityResult['rules_snapshot']['GRATUITY'])) {
            $rulesSnapshot['GRATUITY'] = $gratuityResult['rules_snapshot']['GRATUITY'];
        }

        $isGratuityEligible  = (bool)($gratuityResult['is_eligible'] ?? false);
        $gratuityYears       = (int)($gratuityResult['rounded_gratuity_years'] ?? 0);
        $gratuityDivisorDays = (int)($gratuityResult['month_divisor_days'] ?? $payrollBasicsRule->get('daily_rate_divisor'));
        $gratuityDaysRate    = (float)($gratuityResult['multiplier_days_per_year'] ?? 0);
        $gratuityMinYears    = (float)($gratuityResult['eligibility_min_years'] ?? 0);
        $gratuityAmount      = (float)($gratuityResult['gratuity_amount'] ?? 0.00);

        // 2. Service Duration (Authoritative joining date and interval from GratuityCalculator)
        $serviceYears  = (int)($gratuityResult['years'] ?? 0);
        $serviceMonths = (int)($gratuityResult['months'] ?? 0);
        $serviceDays   = (int)($gratuityResult['days'] ?? 0);
        $decimalYears  = (float)($gratuityResult['service_years'] ?? 0.0);

        // 3. Leave Encashment Calculation
        // Read authoritative encashable balance and check separation eligibility via LeaveService
        $leaveService = new LeaveService();
        $encashableDetails = $leaveService->getEncashableDays($employeeId, $lastWorkingDay, $separationType, true);
        $dbEncashableDays = (float)($encashableDetails['total_days'] ?? 0.0);

        // Client cannot arbitrate days above authoritative DB balance
        if (isset($options['encashable_leave_days'])) {
            $requestedDays = max(0.0, (float)$options['encashable_leave_days']);
            $encashableDays = min($requestedDays, $dbEncashableDays);
        } else {
            $encashableDays = $dbEncashableDays;
        }

        // Determine leave divisor and salary basis from leave policy or payroll basics
        $leaveDivisorDays = null;
        $leaveSalaryBasis = 'Basic Salary';
        if (!empty($encashableDetails['by_type'])) {
            $firstType = reset($encashableDetails['by_type']);
            $leaveDivisorDays = $firstType['divisor'] ?? null;
            $leaveSalaryBasis = $firstType['salary_basis'] ?? 'Basic Salary';
        }
        if ($leaveDivisorDays === null || (int)$leaveDivisorDays <= 0) {
            $leaveDivisorDays = (int)$payrollBasicsRule->get('daily_rate_divisor');
        }
        if ($leaveDivisorDays <= 0) {
            throw new \RuntimeException('Leave encashment divisor must be greater than zero.');
        }

        $encashBasisAmount = (strcasecmp($leaveSalaryBasis, 'Gross Salary') === 0) ? $lastGross : $lastBasic;
        $dailyEncashRate = ($encashBasisAmount > 0) ? round($encashBasisAmount / $leaveDivisorDays, 2) : 0.00;
        $leaveEncashmentAmount = round($encashableDays * $dailyEncashRate, 2);

        // 4. Prorated Exit Month Salary
        $exitSalaryBasis = (string)$settlementRule->get('exit_month_salary_basis');
        $exitSalaryBasisAmount = (strcasecmp($exitSalaryBasis, 'Basic') === 0) ? $lastBasic : $lastGross;

        $exitTime = strtotime($lastWorkingDay);
        $daysInExitMonth = (int)date('t', $exitTime);
        $workedDaysInExitMonth = isset($options['worked_days_in_exit_month']) 
            ? max(0, min($daysInExitMonth, (int)$options['worked_days_in_exit_month']))
            : (int)date('d', $exitTime);

        $exitMonthSalary = 0.00;
        if ($daysInExitMonth > 0 && $exitSalaryBasisAmount > 0) {
            $exitMonthSalary = round(($exitSalaryBasisAmount / $daysInExitMonth) * $workedDaysInExitMonth, 2);
        }

        // Check if non-Draft payroll item exists for the exit month to prevent double payment
        $db = Database::connect();
        $exitYearMonth = date('Y-m', $exitTime);
        $exitYear = (int)date('Y', $exitTime);
        $exitMonthNum = (int)date('n', $exitTime);
        $existingPayrollItem = null;

        if ($db->tableExists('payroll_items') && $db->tableExists('payrolls')) {
            $existingPayrollItem = $db->table('payroll_items')
                ->select('payroll_items.id, payroll_items.gross_salary, payroll_items.net_salary, payroll_items.basic_salary, payroll_items.payment_status, payrolls.id as payroll_id, payrolls.status as batch_status, payrolls.payroll_month, payrolls.is_locked')
                ->join('payrolls', 'payrolls.id = payroll_items.payroll_id', 'inner')
                ->where('payroll_items.employee_id', $employeeId)
                ->groupStart()
                    ->where('payrolls.payroll_month', $exitYearMonth)
                    ->orGroupStart()
                        ->where('payrolls.year', $exitYear)
                        ->where('payrolls.month', $exitMonthNum)
                    ->groupEnd()
                ->groupEnd()
                ->where('payrolls.status !=', 'Draft')
                ->get()
                ->getRowArray();
        }

        $alreadyPaidExitSalary = 0.00;
        if ($existingPayrollItem) {
            $alreadyPaidExitSalary = round((float)($existingPayrollItem['net_salary'] > 0 ? $existingPayrollItem['net_salary'] : ($existingPayrollItem['gross_salary'] ?? 0)), 2);
            if (!empty($options['block_if_payroll_exists']) && $alreadyPaidExitSalary > 0) {
                return [
                    'success' => false,
                    'message' => "Payroll for exit month {$exitYearMonth} has already been processed with status '{$existingPayrollItem['batch_status']}' (Amount paid: {$alreadyPaidExitSalary}). Settlement exit-month salary cannot be processed."
                ];
            }
            // Subtract what was paid from exit month salary
            $exitMonthSalary = max(0.00, round($exitMonthSalary - $alreadyPaidExitSalary, 2));
        }

        // 5. Notice Period Shortfall Deduction
        // Evaluates SETTLEMENT rule parameters: notice_period_days, notice_max_days, notice_shortfall_applies_to, notice_divisor
        $ruleNoticeDays      = (int)$settlementRule->get('notice_period_days');
        $ruleNoticeMaxDays   = (int)$settlementRule->get('notice_max_days');
        $shortfallAppliesTo  = (array)$settlementRule->get('notice_shortfall_applies_to');
        $ruleNoticeDivisor   = $settlementRule->get('notice_divisor');

        $requiredNoticeDays = isset($options['notice_period_required_days'])
            ? max(0, min($ruleNoticeMaxDays, (int)$options['notice_period_required_days']))
            : $ruleNoticeDays;

        $servedNoticeDays   = isset($options['notice_period_served_days'])
            ? max(0, min($requiredNoticeDays, (int)$options['notice_period_served_days']))
            : $requiredNoticeDays;

        $shortfallDays = max(0, $requiredNoticeDays - $servedNoticeDays);

        $shortfallApplies = false;
        foreach ($shortfallAppliesTo as $applicableType) {
            if (strcasecmp((string)$applicableType, (string)$separationType) === 0) {
                $shortfallApplies = true;
                break;
            }
        }

        $noticeShortfallDeduction = 0.00;
        if ($shortfallApplies && $shortfallDays > 0) {
            $noticeDivisorDays = ($ruleNoticeDivisor !== null && (int)$ruleNoticeDivisor > 0)
                ? (int)$ruleNoticeDivisor
                : (int)$payrollBasicsRule->get('daily_rate_divisor');

            if ($noticeDivisorDays <= 0) {
                throw new \RuntimeException('Notice divisor must be greater than zero.');
            }

            $dailyNoticeRate = ($lastBasic > 0) ? round($lastBasic / $noticeDivisorDays, 2) : 0.00;
            $noticeShortfallDeduction = round($shortfallDays * $dailyNoticeRate, 2);
        }

        // 6. Outstanding Loan Settlement (Enforce authoritative DB loan balances and track per-loan lines)
        $authoritativeLoanDue = 0.00;
        $loanLines = [];
        $loanTable = $db->tableExists('employee_loans') ? 'employee_loans' : ($db->tableExists('loans') ? 'loans' : null);
        if ($loanTable !== null) {
            $loans = $db->table($loanTable)
                ->where('employee_id', $employeeId)
                ->whereIn('status', ['Active', 'active', 'Approved', 'approved'])
                ->get()
                ->getResultArray();
            foreach ($loans as $ln) {
                $due = isset($ln['total_due']) ? (float)$ln['total_due'] : 0.0;
                if ($due <= 0 && isset($ln['remaining_amount'])) {
                    $due = (float)$ln['remaining_amount'];
                }
                if ($due <= 0 && isset($ln['principal_amount']) && (!isset($ln['total_paid']) || (float)$ln['total_paid'] <= 0)) {
                    $due = (float)$ln['principal_amount'];
                }
                $due = round($due, 2);
                if ($due > 0) {
                    $authoritativeLoanDue += $due;
                    $loanLines[] = [
                        'loan_id'   => $ln['id'],
                        'amount'    => $due,
                        'loan_type' => $ln['loan_type'] ?? 'Loan',
                    ];
                }
            }
        }
        $authoritativeLoanDue = round($authoritativeLoanDue, 2);
        // Authoritative: loan deduction is strictly derived from system loan records (no client override)
        $outstandingLoanAmount = $authoritativeLoanDue;

        // 7. Outstanding Advance Salary (Authoritative DB check)
        $authoritativeAdvanceDue = 0.00;
        $advanceLines = [];
        $advanceTable = $db->tableExists('salary_advances') ? 'salary_advances' : ($db->tableExists('advance_salaries') ? 'advance_salaries' : null);
        if ($advanceTable !== null) {
            $advances = $db->table($advanceTable)->where('employee_id', $employeeId)
                ->whereIn('status', ['Approved', 'Partially Recovered'])->get()->getResultArray();   // Pending/Active BAD
            foreach ($advances as $adv) {
                $orig = (float)($adv['original_amount'] ?? 0);
                if ($orig <= 0) {
                    $orig = (float)($adv['amount'] ?? 0);
                }
                $out  = round($orig - (float)($adv['recovered_amount'] ?? 0), 2);
                if ($out > 0) {
                    $authoritativeAdvanceDue += $out;
                    $advanceLines[] = ['advance_id' => $adv['id'], 'amount' => $out];
                }
            }
        }
        $authoritativeAdvanceDue = round($authoritativeAdvanceDue, 2);
        // Authoritative: advance deduction is strictly derived from system advance records (no client override)
        $advanceDeduction = $authoritativeAdvanceDue;

        // 8. Tax Deduction (Explicit manual note required when non-zero, or auto-calculated via RuleResolver TAX domain)
        $taxDeduction = 0.00;
        $taxNote = '';
        if (isset($options['tax_deduction']) && $options['tax_deduction'] !== null && $options['tax_deduction'] !== '') {
            $taxDeduction = max(0.0, (float)$options['tax_deduction']);
            $taxNote = trim((string)($options['tax_note'] ?? ''));
            if ($taxDeduction > 0 && $taxNote === '') {
                return [
                    'success' => false,
                    'message' => 'tax_note is required when tax_deduction is applied.'
                ];
            }
        } elseif (!empty($options['calculate_tax'])) {
            $salaryTax = 0.00;
            if ($taxRule !== null) {
                try {
                    $taxCalc = new \App\Services\Tax\TaxCalculator($resolver);
                    $taxRes = $taxCalc->calculateTax($lastGross, [
                        'company_id'     => $companyId,
                        'employee'       => $employee,
                        'basic'          => $lastBasic,
                        'gross'          => $lastGross,
                        'effective_date' => $lastWorkingDay,
                    ]);
                    $salaryTax = (float)($taxRes['monthly_tax_deduction'] ?? 0.0);
                } catch (\Throwable $e) {
                    $salaryTax = 0.00;
                }
            }

            $gratuityTaxDeduction   = (float)($gratuityResult['gratuity_tax_deduction'] ?? 0.0);
            $gratuityExemptionLimit = (float)($gratuityResult['tax_exemption_limit'] ?? 0.0);
            $gratuityTaxRate        = (float)($gratuityResult['tax_rate_on_excess'] ?? 0.0);

            if ($salaryTax > 0.0 && $gratuityTaxDeduction > 0.0) {
                $taxDeduction = round($salaryTax + $gratuityTaxDeduction, 2);
                $taxNote = sprintf(
                    'Auto-calculated: Salary Tax (%s) + Gratuity Tax (%s @ %g%% on excess over %s exemption)',
                    number_format($salaryTax, 2),
                    number_format($gratuityTaxDeduction, 2),
                    $gratuityTaxRate,
                    number_format($gratuityExemptionLimit, 2)
                );
            } elseif ($gratuityTaxDeduction > 0.0) {
                $taxDeduction = round($gratuityTaxDeduction, 2);
                $taxNote = sprintf(
                    'Auto-calculated Gratuity Tax: %s (%g%% on excess over %s exemption)',
                    number_format($gratuityTaxDeduction, 2),
                    $gratuityTaxRate,
                    number_format($gratuityExemptionLimit, 2)
                );
            } elseif ($salaryTax > 0.0) {
                $taxDeduction = round($salaryTax, 2);
                $taxNote = 'Auto-calculated via RuleResolver (TAX)';
            } else {
                $taxDeduction = 0.00;
                $taxNote = $gratuityAmount > 0.0
                    ? sprintf('Gratuity (%s) within tax-free exemption limit (%s); 0 tax', number_format($gratuityAmount, 2), number_format($gratuityExemptionLimit, 2))
                    : 'Auto-calculated terminal tax: 0.00';
            }
        }

        // 9. Other Earnings & Deductions
        $bonusPending           = max(0.0, (float)($options['bonus_pending'] ?? 0));
        $otherAllowances        = max(0.0, (float)($options['other_allowances'] ?? 0));

        $unreturnedAssets = [];
        if (array_key_exists('asset_recovery_deduction', $options) && $options['asset_recovery_deduction'] !== null && $options['asset_recovery_deduction'] !== '') {
            $assetRecoveryDeduction = max(0.0, (float)$options['asset_recovery_deduction']);
        } else {
            $assetRecoveryDeduction = 0.00;
            $db = Database::connect();
            if ($db->tableExists('company_assets')) {
                // Charge only unsettled liability write-offs for this employee.
                // Note: EmployeeSeparationService blocks separation if the employee holds an 'Assigned' asset,
                // so an employee undergoing separation has returned all assets or had them written off.
                // 'Assigned' assets are excluded from final settlement recovery.
                $currentSettlementId = $options['settlement_id'] ?? ($options['id'] ?? null);

                $builder = $db->table('company_assets')
                    ->select('company_assets.*, asset_categories.useful_life_years, asset_categories.depreciation_method', false)
                    ->join('asset_categories', 'asset_categories.id = company_assets.category_id', 'left')
                    ->where('company_assets.written_off_by_employee_id', $employee['id'])
                    ->whereIn('company_assets.written_off_reason', AssetWriteOffReasons::LIABILITY)
                    ->where('company_assets.status', 'Written-Off');

                if (!empty($employee['company_id']) && $db->fieldExists('company_id', 'company_assets')) {
                    $builder->where('company_assets.company_id', $employee['company_id']);
                }

                if ($db->fieldExists('recovery_settlement_id', 'company_assets')) {
                    if (!empty($currentSettlementId)) {
                        $builder->groupStart()
                            ->where('company_assets.recovery_settlement_id IS NULL', null, false)
                            ->orWhere('company_assets.recovery_settlement_id', $currentSettlementId)
                        ->groupEnd();
                    } else {
                        $builder->where('company_assets.recovery_settlement_id IS NULL', null, false);
                    }
                }

                if ($db->fieldExists('deleted_at', 'company_assets')) {
                    $builder->where('company_assets.deleted_at IS NULL', null, false);
                }
                $rawAssets = $builder->get()->getResultArray();

                foreach ($rawAssets as $ua) {
                    $purchaseVal  = max(0.0, (float)($ua['purchase_value'] ?? 0.0));
                    $usefulYears  = (int)($ua['useful_life_years'] ?? 0);
                    $purchaseDate = $ua['purchase_date'] ?? null;
                    $alreadyCollected = max(0.0, (float)($ua['recovery_recovered_amount'] ?? 0.0));

                    // If recovery_amount is explicitly set on a written-off asset, honor it; otherwise compute via AssetDepreciation
                    $hasExplicitRecovery = (isset($ua['recovery_amount']) && $ua['recovery_amount'] !== null && (float)$ua['recovery_amount'] >= 0.0);
                    if ($hasExplicitRecovery) {
                        $targetRecovery = (float)$ua['recovery_amount'];
                    } else {
                        $targetRecovery = AssetDepreciation::bookValue(
                            $purchaseVal,
                            $purchaseDate,
                            $usefulYears > 0 ? $usefulYears : null,
                            $ua['depreciation_method'] ?? 'none',
                            $lastWorkingDay
                        );
                    }

                    // Charge only the remaining unrecovered amount after deducting any monthly payroll recoveries
                    $remainingCharge = max(0.0, round($targetRecovery - $alreadyCollected, 2));

                    // Exclude assets already fully recovered through monthly payroll
                    // (prevents double-charging when recovery_recovered_amount covers the recovery liability)
                    if ($targetRecovery > 0.0 && $remainingCharge <= 0.0) {
                        continue;
                    }

                    // Decision: If recovery_amount is 0 (or depreciated book value is 0), do not charge the employee.
                    // Furthermore, do not mark this asset as "settled" with a zero charge in company_assets,
                    // as doing so would falsely record a financial recovery or lock an uncharged record.
                    if ($targetRecovery <= 0.0 || $remainingCharge <= 0.0) {
                        continue;
                    }

                    $ua['calculated_recovery_amount'] = $remainingCharge;
                    $assetRecoveryDeduction += $remainingCharge;
                    $unreturnedAssets[] = $ua;
                }
                $assetRecoveryDeduction = round($assetRecoveryDeduction, 2);
            }
        }
        $otherDeductions        = max(0.0, (float)($options['other_deductions'] ?? 0));

        // Totals
        $totalPayable = round($exitMonthSalary + $gratuityAmount + $leaveEncashmentAmount + $bonusPending + $otherAllowances, 2);
        $totalDeductions = round($noticeShortfallDeduction + $outstandingLoanAmount + $advanceDeduction + $assetRecoveryDeduction + $taxDeduction + $otherDeductions, 2);
        $netSettlement = round($totalPayable - $totalDeductions, 2);

        return [
            'success' => true,
            'employee' => [
                'id'            => $employee['id'],
                'company_id'    => $employee['company_id'] ?? null,
                'first_name'    => $employee['first_name'] ?? '',
                'last_name'     => $employee['last_name'] ?? '',
                'employee_id'   => $employee['employee_id'] ?? $employee['id'],
                'department_id' => $employee['department_id'] ?? null,
                'designation'   => $employee['designation'] ?? '',
                'joining_date'  => $joiningDate,
                'basic_salary'  => $lastBasic,
                'gross_salary'  => $lastGross,
            ],
            'separation_type'  => $separationType,
            'separation_date'  => $separationDate,
            'last_working_day' => $lastWorkingDay,
            'service' => [
                'joining_date'     => $joiningDate,
                'last_working_day' => $lastWorkingDay,
                'years'            => $serviceYears,
                'months'           => $serviceMonths,
                'days'             => $serviceDays,
                'decimal_years'    => $decimalYears,
            ],
            'earnings' => [
                'last_drawn_basic'          => $lastBasic,
                'last_drawn_gross'          => $lastGross,
                'worked_days_in_exit_month' => $workedDaysInExitMonth,
                'days_in_exit_month'        => $daysInExitMonth,
                'exit_month_salary'         => $exitMonthSalary,
                'gratuity_eligible'         => $isGratuityEligible ? 1 : 0,
                'gratuity_years'            => $gratuityYears,
                'gratuity_rate_days'        => $gratuityDaysRate,
                'gratuity_divisor_days'     => $gratuityDivisorDays,
                'gratuity_min_years'        => $gratuityMinYears,
                'gratuity_amount'           => $gratuityAmount,
                'gratuity_details'          => $gratuityResult,
                'encashable_leave_days'     => $encashableDays,
                'daily_basic_rate'          => $dailyEncashRate,
                'leave_encashment_amount'   => $leaveEncashmentAmount,
                'leave_lines'               => $encashableDetails['by_type'] ?? [],
                'exit_month_already_paid'   => $alreadyPaidExitSalary,
                'bonus_pending'             => $bonusPending,
                'other_allowances'          => $otherAllowances,
                'total_payable'             => $totalPayable,
            ],
            'deductions' => [
                'notice_period_required_days'   => $requiredNoticeDays,
                'notice_period_served_days'     => $servedNoticeDays,
                'notice_shortfall_days'         => $shortfallDays,
                'notice_shortfall_deduction'    => $noticeShortfallDeduction,
                'outstanding_loan_deduction'    => $outstandingLoanAmount,
                'loan_lines'                    => $loanLines,
                'outstanding_advance_deduction' => $advanceDeduction,
                'advance_lines'                 => $advanceLines,
                'asset_recovery_deduction'      => $assetRecoveryDeduction,
                'tax_deduction'                 => $taxDeduction,
                'tax_note'                      => $taxNote,
                'gratuity_tax_deduction'        => (float)($gratuityResult['gratuity_tax_deduction'] ?? 0.0),
                'provident_fund_employee'       => 0.00,
                'provident_fund_employer'       => 0.00,
                'other_deductions'              => $otherDeductions,
                'total_deductions'              => $totalDeductions,
            ],
            'unreturned_assets'       => $unreturnedAssets,
            'unreturned_assets_count' => count($unreturnedAssets),
            'net_settlement_amount'   => $netSettlement,
            'is_payable_to_employee'  => ($netSettlement >= 0),
            'rules_snapshot'          => $rulesSnapshot,
        ];
    }

    /**
     * Save or update a final settlement record
     */
    public function saveSettlement(array $data, ?string $settlementId = null, ?string $actorUserId = null): array
    {
        $employeeId = $data['employee_id'] ?? '';
        if (!$employeeId) {
            return ['success' => false, 'message' => 'Employee ID is required'];
        }

        $employee = $this->employeeModel->find($employeeId);
        if (!$employee) {
            return ['success' => false, 'message' => 'Employee record not found'];
        }

        $authoritativeCompanyId = $employee['company_id'] ?? null;
        if (!$authoritativeCompanyId) {
            return ['success' => false, 'message' => 'Target employee has no associated company_id'];
        }

        $id = $settlementId ?: ($data['id'] ?? ('SETTLE-' . bin2hex(random_bytes(6))));
        $data['settlement_id'] = $id;

        $lastWorkingDay = $data['last_working_day'] ?? date('Y-m-d');
        $calc = $this->calculateSettlement($employeeId, $lastWorkingDay, $data);
        if (!$calc['success']) {
            return $calc;
        }

        $existing = $settlementId ? $this->settlementModel->find($settlementId) : null;

        // Verify status: once approved or disbursed, it cannot be modified via save
        if ($existing && in_array($existing['payment_status'], ['Approved', 'Disbursed', 'Settled'])) {
            return [
                'success' => false,
                'message' => "Cannot edit settlement with status {$existing['payment_status']}."
            ];
        }

        $targetStatus = $data['payment_status'] ?? ($existing['payment_status'] ?? 'Draft');

        // Enforce one active settlement per employee (active_key column with UNIQUE index)
        if (in_array($targetStatus, ['Draft', 'Approved', 'Disbursed'], true)) {
            $activeCheckQuery = $this->settlementModel
                ->where('employee_id', $employeeId)
                ->whereIn('payment_status', ['Draft', 'Approved', 'Disbursed']);
            if ($existing) {
                $activeCheckQuery->where('id !=', $existing['id']);
            }
            $existingActive = $activeCheckQuery->first();
            if ($existingActive) {
                return [
                    'success' => false,
                    'message' => "An active final settlement already exists for this employee (Settlement ID: {$existingActive['id']}, Status: {$existingActive['payment_status']}). Only one active settlement is allowed per employee.",
                    'code'    => 409
                ];
            }
        }

        // Authoritative preparer attribution
        $preparedBy = $existing ? ($existing['prepared_by'] ?? ($actorUserId ?: 'HR & Payroll Dept')) : ($actorUserId ?: 'HR & Payroll Dept');

        $record = [
            'id'                            => $id,
            'company_id'                    => $authoritativeCompanyId,
            'employee_id'                   => $employeeId,
            'active_key'                    => in_array($targetStatus, ['Draft', 'Approved', 'Disbursed'], true) ? $employeeId : null,
            'separation_type'               => $calc['separation_type'],
            'resignation_or_termination_id' => $data['resignation_or_termination_id'] ?? null,
            'joining_date'                  => $calc['service']['joining_date'],
            'separation_date'               => $calc['separation_date'],
            'last_working_day'              => $calc['last_working_day'],
            'total_service_years'           => $calc['service']['decimal_years'],
            'total_service_months'          => $calc['service']['months'],
            'total_service_days'            => $calc['service']['days'],
            'last_drawn_basic'              => $calc['earnings']['last_drawn_basic'],
            'last_drawn_gross'              => $calc['earnings']['last_drawn_gross'],
            'worked_days_in_exit_month'     => $calc['earnings']['worked_days_in_exit_month'],
            'exit_month_salary'             => $calc['earnings']['exit_month_salary'],
            'gratuity_eligible'             => $calc['earnings']['gratuity_eligible'],
            'gratuity_years'                => $calc['earnings']['gratuity_years'],
            'gratuity_rate_days'            => $calc['earnings']['gratuity_rate_days'],
            'gratuity_amount'               => $calc['earnings']['gratuity_amount'],
            'encashable_leave_days'         => $calc['earnings']['encashable_leave_days'],
            'leave_encashment_amount'       => $calc['earnings']['leave_encashment_amount'],
            'settlement_leave_lines_json'   => !empty($calc['earnings']['leave_lines']) ? json_encode($calc['earnings']['leave_lines']) : null,
            'bonus_pending'                 => $calc['earnings']['bonus_pending'],
            'other_allowances'              => $calc['earnings']['other_allowances'],
            'total_payable'                 => $calc['earnings']['total_payable'],
            'notice_period_required_days'   => $calc['deductions']['notice_period_required_days'],
            'notice_period_served_days'     => $calc['deductions']['notice_period_served_days'],
            'notice_shortfall_days'         => $calc['deductions']['notice_shortfall_days'],
            'notice_shortfall_deduction'    => $calc['deductions']['notice_shortfall_deduction'],
            'outstanding_loan_deduction'    => $calc['deductions']['outstanding_loan_deduction'],
            'settlement_loan_lines_json'    => !empty($calc['deductions']['loan_lines']) ? json_encode($calc['deductions']['loan_lines']) : null,
            'outstanding_advance_deduction' => $calc['deductions']['outstanding_advance_deduction'],
            'settlement_advance_lines_json' => !empty($calc['deductions']['advance_lines']) ? json_encode($calc['deductions']['advance_lines']) : null,
            'tax_deduction'                 => $calc['deductions']['tax_deduction'],
            'tax_note'                      => $calc['deductions']['tax_note'] ?? null,
            'provident_fund_employee'       => 0.00,
            'provident_fund_employer'       => 0.00,
            'asset_recovery_deduction'      => $calc['deductions']['asset_recovery_deduction'],
            'other_deductions'              => $calc['deductions']['other_deductions'],
            'total_deductions'              => $calc['deductions']['total_deductions'],
            'net_settlement_amount'         => $calc['net_settlement_amount'],
            'payment_status'                => $targetStatus,
            'disbursement_date'             => null,
            'payment_method'                => $data['payment_method'] ?? 'Bank Transfer',
            'transaction_reference'         => $data['transaction_reference'] ?? null,
            'remarks'                       => $data['remarks'] ?? '',
            'prepared_by'                   => $preparedBy,
            'approved_by'                   => $existing ? ($existing['approved_by'] ?? null) : null,
            'rules_snapshot_json'           => !empty($calc['rules_snapshot']) ? json_encode($calc['rules_snapshot']) : null,
            'updated_at'                    => date('Y-m-d H:i:s'),
        ];

        $db = Database::connect();
        $db->transStart();

        try {
            if ($existing) {
                $this->settlementModel->update($id, $record);
            } else {
                $record['created_at'] = date('Y-m-d H:i:s');
                $this->settlementModel->insert($record);
            }

            if ($db->tableExists('company_assets')) {
                if ($targetStatus !== 'Cancelled') {
                    $chargedWrittenOffIds = [];
                    foreach ($calc['unreturned_assets'] ?? [] as $ua) {
                        // Decision: Only link and mark assets as settled if an actual positive liability amount was charged (> 0).
                        // If recovery_amount is 0 or was already fully recovered through monthly payroll,
                        // do not mark the asset as "settled" with a zero charge in company_assets.
                        if (($ua['status'] ?? '') === 'Written-Off'
                            && !empty($ua['written_off_reason'])
                            && AssetWriteOffReasons::isLiability($ua['written_off_reason'])
                            && (float)($ua['calculated_recovery_amount'] ?? 0.0) > 0.0
                        ) {
                            $chargedWrittenOffIds[] = $ua['id'];
                        }
                    }

                    if (!empty($chargedWrittenOffIds)) {
                        $db->table('company_assets')
                            ->whereIn('id', $chargedWrittenOffIds)
                            ->update([
                                'recovery_settlement_id' => $id,
                                'recovery_settled_at'    => date('Y-m-d H:i:s'),
                            ]);
                    }

                    if ($existing) {
                        $releaseBuilder = $db->table('company_assets')
                            ->where('recovery_settlement_id', $id);
                        if (!empty($chargedWrittenOffIds)) {
                            $releaseBuilder->whereNotIn('id', $chargedWrittenOffIds);
                        }
                        $releaseBuilder->update([
                            'recovery_settlement_id' => null,
                            'recovery_settled_at'    => null,
                        ]);
                    }
                } else {
                    $db->table('company_assets')
                        ->where('recovery_settlement_id', $id)
                        ->update([
                            'recovery_settlement_id' => null,
                            'recovery_settled_at'    => null,
                        ]);
                }
            }

            $db->transComplete();

            if ($db->transStatus() === false) {
                return [
                    'success' => false,
                    'message' => 'Database transaction failed while saving final settlement.'
                ];
            }
        } catch (\Throwable $e) {
            $db->transRollback();
            log_message('error', 'saveSettlement transaction failure: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Error saving final settlement: ' . $e->getMessage()
            ];
        }

        return [
            'success' => true,
            'settlement_id' => $id,
            'calculation' => $calc
        ];
    }

    /**
     * Approve final settlement (Transitions Draft -> Approved) with Segregation of Duties and Recomputation Verification
     */
    public function approveSettlement(string $settlementId, ?string $actorUserId = null): array
    {
        $settlement = $this->settlementModel->find($settlementId);
        if (!$settlement) {
            return ['success' => false, 'message' => 'Settlement record not found', 'code' => 404];
        }

        if ($settlement['payment_status'] !== 'Draft') {
            return [
                'success' => false,
                'message' => "Only settlements in Draft status can be approved. Current status: {$settlement['payment_status']}.",
                'code' => 400
            ];
        }

        // Segregation of Duties: Preparer cannot approve their own calculation
        if ($actorUserId && !empty($settlement['prepared_by']) && $settlement['prepared_by'] === $actorUserId) {
            return [
                'success' => false,
                'message' => 'Segregation of Duties violation: The preparer cannot approve the final settlement.',
                'code' => 403
            ];
        }

        // Recompute settlement using authoritative rules and DB state to detect drift
        $recomputeOptions = [
            'separation_type'               => $settlement['separation_type'],
            'separation_date'               => $settlement['separation_date'],
            'last_working_day'              => $settlement['last_working_day'],
            'resignation_or_termination_id' => $settlement['resignation_or_termination_id'],
            'worked_days_in_exit_month'     => $settlement['worked_days_in_exit_month'],
            'notice_period_required_days'   => $settlement['notice_period_required_days'],
            'notice_period_served_days'     => $settlement['notice_period_served_days'],
            'encashable_leave_days'         => $settlement['encashable_leave_days'],
            'bonus_pending'                 => $settlement['bonus_pending'],
            'other_allowances'              => $settlement['other_allowances'],
            'tax_deduction'                 => $settlement['tax_deduction'],
            'tax_note'                      => $settlement['tax_note'] ?? null,
            'asset_recovery_deduction'      => $settlement['asset_recovery_deduction'],
            'other_deductions'              => $settlement['other_deductions'],
        ];

        $recomputed = $this->calculateSettlement($settlement['employee_id'], $settlement['last_working_day'], $recomputeOptions);
        if (!$recomputed['success']) {
            return [
                'success' => false,
                'message' => 'Failed to recompute settlement for approval: ' . ($recomputed['message'] ?? 'Unknown error'),
                'code'    => 400
            ];
        }

        // Compare recomputed totals to saved draft
        $savedNet             = (float)$settlement['net_settlement_amount'];
        $recomputedNet        = (float)$recomputed['net_settlement_amount'];
        $savedPayable         = (float)$settlement['total_payable'];
        $recomputedPayable    = (float)$recomputed['earnings']['total_payable'];
        $savedDeductions      = (float)$settlement['total_deductions'];
        $recomputedDeductions = (float)$recomputed['deductions']['total_deductions'];

        if (abs($savedNet - $recomputedNet) > 0.01 || abs($savedPayable - $recomputedPayable) > 0.01 || abs($savedDeductions - $recomputedDeductions) > 0.01) {
            $diff = [
                'saved' => [
                    'total_payable'                 => $savedPayable,
                    'total_deductions'              => $savedDeductions,
                    'net_settlement_amount'         => $savedNet,
                    'exit_month_salary'             => (float)$settlement['exit_month_salary'],
                    'gratuity_amount'               => (float)$settlement['gratuity_amount'],
                    'leave_encashment_amount'       => (float)$settlement['leave_encashment_amount'],
                    'outstanding_loan_deduction'    => (float)$settlement['outstanding_loan_deduction'],
                    'outstanding_advance_deduction' => (float)$settlement['outstanding_advance_deduction'],
                ],
                'recomputed' => [
                    'total_payable'                 => $recomputedPayable,
                    'total_deductions'              => $recomputedDeductions,
                    'net_settlement_amount'         => $recomputedNet,
                    'exit_month_salary'             => (float)$recomputed['earnings']['exit_month_salary'],
                    'gratuity_amount'               => (float)$recomputed['earnings']['gratuity_amount'],
                    'leave_encashment_amount'       => (float)$recomputed['earnings']['leave_encashment_amount'],
                    'outstanding_loan_deduction'    => (float)$recomputed['deductions']['outstanding_loan_deduction'],
                    'outstanding_advance_deduction' => (float)$recomputed['deductions']['outstanding_advance_deduction'],
                ],
                'variance' => round($recomputedNet - $savedNet, 2)
            ];

            return [
                'success' => false,
                'message' => 'Settlement approval rejected: Recomputed calculation differs from the saved draft.',
                'code'    => 409,
                'data'    => [
                    'diff' => $diff
                ]
            ];
        }

        $approver = $actorUserId ?: 'HR Director';
        $updateData = [
            'payment_status' => 'Approved',
            'approved_by'    => $approver,
            'updated_at'     => date('Y-m-d H:i:s')
        ];
        if (!empty($recomputed['deductions']['loan_lines'])) {
            $updateData['settlement_loan_lines_json'] = json_encode($recomputed['deductions']['loan_lines']);
        }
        if (!empty($recomputed['deductions']['advance_lines'])) {
            $updateData['settlement_advance_lines_json'] = json_encode($recomputed['deductions']['advance_lines']);
        }
        if (!empty($recomputed['earnings']['leave_lines'])) {
            $updateData['settlement_leave_lines_json'] = json_encode($recomputed['earnings']['leave_lines']);
        }
        if (!empty($recomputed['rules_snapshot'])) {
            $updateData['rules_snapshot_json'] = json_encode($recomputed['rules_snapshot']);
        }
        $this->settlementModel->update($settlementId, $updateData);

        return [
            'success' => true,
            'message' => 'Final settlement approved successfully'
        ];
    }

    /**
     * Disburse settlement, close recorded loans, deduct encashed leave, recover salary advances, and transition employee status
     */
    public function approveAndDisburse(string $settlementId, array $paymentDetails = [], ?string $actorUserId = null): array
    {
        $settlement = $this->settlementModel->find($settlementId);
        if (!$settlement) {
            return ['success' => false, 'message' => 'Settlement record not found', 'code' => 404];
        }

        $currentStatus = $settlement['payment_status'] ?? 'Draft';
        if ($currentStatus !== 'Approved') {
            return [
                'success' => false,
                'message' => "Settlement must be Approved prior to disbursement. Current status: {$currentStatus}.",
                'code' => 400
            ];
        }

        $employeeId = $settlement['employee_id'];
        $employee = $this->employeeModel->find($employeeId);
        if (!$employee) {
            return ['success' => false, 'message' => 'Associated employee record not found', 'code' => 404];
        }

        // Segregation of Duties validation
        if ($actorUserId) {
            if (!empty($settlement['prepared_by']) && $settlement['prepared_by'] === $actorUserId) {
                return [
                    'success' => false,
                    'message' => 'Segregation of Duties violation: The preparer cannot disburse the final settlement.',
                    'code' => 403
                ];
            }
            if (!empty($settlement['approved_by']) && $settlement['approved_by'] === $actorUserId) {
                return [
                    'success' => false,
                    'message' => 'Segregation of Duties violation: The approver cannot disburse the final settlement.',
                    'code' => 403
                ];
            }
        }

        $db = Database::connect();
        $db->transStart();

        try {
            $loanTable = $db->tableExists('employee_loans') ? 'employee_loans' : ($db->tableExists('loans') ? 'loans' : null);
            $advanceTable = $db->tableExists('salary_advances') ? 'salary_advances' : ($db->tableExists('advance_salaries') ? 'advance_salaries' : null);

            // Revalidate: calculate current loan due and advance due and ensure they match approved settlement
            $currentLoanDue = 0.00;
            if ($loanTable !== null) {
                $loans = $db->table($loanTable)
                    ->where('employee_id', $employeeId)
                    ->whereIn('status', ['Active', 'active', 'Approved', 'approved'])
                    ->get()
                    ->getResultArray();
                foreach ($loans as $ln) {
                    $due = isset($ln['total_due']) ? (float)$ln['total_due'] : 0.0;
                    if ($due <= 0 && isset($ln['remaining_amount'])) {
                        $due = (float)$ln['remaining_amount'];
                    }
                    if ($due <= 0 && isset($ln['principal_amount']) && (!isset($ln['total_paid']) || (float)$ln['total_paid'] <= 0)) {
                        $due = (float)$ln['principal_amount'];
                    }
                    $due = round($due, 2);
                    if ($due > 0) {
                        $currentLoanDue += $due;
                    }
                }
            }
            $currentLoanDue = round($currentLoanDue, 2);

            $currentAdvanceDue = 0.00;
            if ($advanceTable !== null) {
                $advances = $db->table($advanceTable)
                    ->where('employee_id', $employeeId)
                    ->whereIn('status', ['Approved', 'Partially Recovered'])
                    ->get()
                    ->getResultArray();
                foreach ($advances as $adv) {
                    $orig = (float)($adv['original_amount'] ?? 0);
                    if ($orig <= 0) {
                        $orig = (float)($adv['amount'] ?? 0);
                    }
                    $out  = round($orig - (float)($adv['recovered_amount'] ?? 0), 2);
                    if ($out > 0) {
                        $currentAdvanceDue += $out;
                    }
                }
            }
            $currentAdvanceDue = round($currentAdvanceDue, 2);

            $approvedLoanDue = round((float)($settlement['outstanding_loan_deduction'] ?? 0), 2);
            $approvedAdvanceDue = round((float)($settlement['outstanding_advance_deduction'] ?? 0), 2);

            if (abs($currentLoanDue - $approvedLoanDue) > 0.01 || abs($currentAdvanceDue - $approvedAdvanceDue) > 0.01) {
                $db->transRollback();
                return [
                    'success' => false,
                    'message' => 'Dues changed since approval. Recalculate the settlement.',
                    'code'    => 409
                ];
            }

            // 1. Close exactly the loans recorded in the approved settlement
            $loanLinesJson = $settlement['settlement_loan_lines_json'] ?? null;
            $loanLines = !empty($loanLinesJson) ? json_decode($loanLinesJson, true) : null;
            $payrollMonth = date('Y-m', strtotime($settlement['last_working_day'] ?? date('Y-m-d')));

            if ($loanTable !== null && is_array($loanLines) && !empty($loanLines)) {
                foreach ($loanLines as $line) {
                    $loanId = $line['loan_id'] ?? null;
                    $amountToClose = round((float)($line['amount'] ?? 0), 2);
                    if (!$loanId || $amountToClose <= 0) {
                        continue;
                    }

                    $loanRow = $db->table($loanTable)->where('id', $loanId)->get()->getRowArray();
                    if ($loanRow) {
                        $companyId = $employee['company_id'] ?? $settlement['company_id'] ?? null;

                        // 1. Write immutable row in loan_ledger_entries (entry_type = 'settlement')
                        if ($db->tableExists('loan_ledger_entries')) {
                            $db->table('loan_ledger_entries')->insert([
                                'id'              => 'lle-' . bin2hex(random_bytes(14)),
                                'company_id'      => $companyId,
                                'loan_id'         => $loanId,
                                'entry_type'      => 'settlement',
                                'amount'          => $amountToClose,
                                'payroll_item_id' => null,
                                'payroll_id'      => null,
                                'settlement_id'   => $settlementId,
                                'created_by'      => $actorUserId ?? ($settlement['approved_by'] ?? null),
                                'created_at'      => date('Y-m-d H:i:s')
                            ]);
                        }

                        // 2. Recompute balances authoritatively from ledger
                        $this->loanModel->recomputeBalances($loanId);

                        // Add repayment entry using existing table columns + settlement_id
                        if ($db->tableExists('loan_repayments')) {
                            $db->table('loan_repayments')->insert([
                                'id'              => 'REP-FS-' . bin2hex(random_bytes(5)),
                                'loan_id'         => $loanId,
                                'employee_id'     => $employeeId,
                                'settlement_id'   => $settlementId,
                                'payroll_item_id' => null,
                                'payroll_month'   => 'FS-' . substr($settlementId, 0, 16),
                                'company_id'      => $companyId,
                                'amount'          => $amountToClose,
                                'status'          => 'posted',
                                'created_at'      => date('Y-m-d H:i:s')
                            ]);
                        }
                    }
                }
            }

            // 2. Mark salary advances as Recovered
            if ($advanceTable !== null) {
                $advLines = json_decode($settlement['settlement_advance_lines_json'] ?? '[]', true) ?: [];
                foreach ($advLines as $ln) {
                    $adv = $db->table($advanceTable)->where('id', $ln['advance_id'])->get()->getRowArray();
                    $orig = (float)($adv['original_amount'] ?? 0);
                    if ($orig <= 0) {
                        $orig = (float)($adv['amount'] ?? 0);
                    }
                    $db->table($advanceTable)->where('id', $adv['id'])->update([
                        'recovered_amount' => $orig,
                        'status'           => 'Recovered',
                        'updated_at'       => date('Y-m-d H:i:s'),
                    ]);
                }
            }

            // 3. Add encashed_days to leave_balances in the same transaction
            $encashedDays = (float)($settlement['encashable_leave_days'] ?? 0.0);
            if ($encashedDays > 0 && $db->tableExists('leave_balances')) {
                $exitYear = (int)date('Y', strtotime($settlement['last_working_day'] ?? date('Y-m-d')));
                $leaveLinesJson = $settlement['settlement_leave_lines_json'] ?? null;
                $leaveLines = !empty($leaveLinesJson) ? json_decode($leaveLinesJson, true) : null;

                if (is_array($leaveLines) && !empty($leaveLines)) {
                    foreach ($leaveLines as $line) {
                        $ltId = $line['leave_type_id'] ?? null;
                        $days = (float)($line['encashable_days'] ?? 0);
                        if ($ltId && $days > 0) {
                            $db->query(
                                "UPDATE leave_balances SET encashed_days = encashed_days + ? WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                                [$days, $employeeId, $ltId, $exitYear]
                            );
                        }
                    }
                } else {
                    $balances = $db->table('leave_balances')
                        ->where('employee_id', $employeeId)
                        ->where('year', $exitYear)
                        ->get()
                        ->getResultArray();

                    $leaveService = new LeaveService();
                    $lastWorkingDay = $settlement['last_working_day'] ?? date('Y-m-d');
                    $remainingToDeduct = $encashedDays;
                    foreach ($balances as $lb) {
                        if ($remainingToDeduct <= 0) {
                            break;
                        }
                        $bal = $leaveService->getEmployeeBalanceReadOnly($employeeId, $lb['leave_type_id'], $exitYear, null, $lastWorkingDay);
                        $avail = max(0.0, (float)($bal['available_balance'] ?? 0.0));

                        if ($avail > 0) {
                            $toEncash = min($avail, $remainingToDeduct);
                            $db->query(
                                "UPDATE leave_balances SET encashed_days = encashed_days + ? WHERE id = ?",
                                [$toEncash, $lb['id']]
                            );
                            $remainingToDeduct -= $toEncash;
                        }
                    }
                }
            }

            // 4. Update employee status from SETTLEMENT employee_status_map (verified against allowed list)
            $companyId = $employee['company_id'] ?? '';
            $sepType = (string)($settlement['separation_type'] ?? 'Resignation');
            $targetStatus = null;

            if ($companyId !== '') {
                try {
                    $resolver = new RuleResolver();
                    $settlementRule = $resolver->resolve($companyId, 'SETTLEMENT', $settlement['last_working_day'] ?? date('Y-m-d'), $employee);
                    $rawStatusMap = $settlementRule->get('employee_status_map');

                    if (is_array($rawStatusMap)) {
                        foreach ($rawStatusMap as $entry) {
                            if (is_array($entry) && isset($entry['separation_type'], $entry['employee_status']) && strcasecmp((string)$entry['separation_type'], $sepType) === 0) {
                                $targetStatus = (string)$entry['employee_status'];
                                break;
                            } elseif (is_string($entry) && strcasecmp((string)$entry, $sepType) === 0) {
                                $targetStatus = (string)$entry;
                                break;
                            }
                        }
                        if ($targetStatus === null && isset($rawStatusMap[$sepType])) {
                            $targetStatus = (string)$rawStatusMap[$sepType];
                        }
                    }
                } catch (\Throwable $e) {
                    log_message('error', 'Error resolving employee_status_map: ' . $e->getMessage());
                }
            }

            // Allowed canonical values from EmployeeModel: ['active', 'probation', 'on_leave', 'suspended', 'resigned', 'terminated', 'inactive']
            $allowedStatuses = \App\Models\EmployeeModel::STATUSES;
            $normalizedStatus = $targetStatus ? \App\Models\EmployeeModel::normalizeStatus($targetStatus) : null;
            if ($normalizedStatus && in_array($normalizedStatus, $allowedStatuses, true)) {
                $finalEmployeeStatus = $normalizedStatus;
            } else {
                $finalEmployeeStatus = (in_array($sepType, ['Termination', 'Dismissal'], true))
                    ? \App\Models\EmployeeModel::STATUS_TERMINATED
                    : \App\Models\EmployeeModel::STATUS_RESIGNED;
            }

            $this->employeeModel->update($employeeId, [
                'status' => $finalEmployeeStatus
            ]);

            // 5. Update resignation or termination record by resignation_or_termination_id
            $resigOrTermId = $settlement['resignation_or_termination_id'] ?? null;
            if ($resigOrTermId) {
                if (in_array($sepType, ['Termination', 'Dismissal'], true) && $db->tableExists('employee_terminations')) {
                    $db->table('employee_terminations')
                       ->where('id', $resigOrTermId)
                       ->update(['final_settlement_status' => 'Completed', 'clearance_status' => 'Completed', 'updated_at' => date('Y-m-d H:i:s')]);
                } elseif ($db->tableExists('employee_resignations')) {
                    $db->table('employee_resignations')
                       ->where('id', $resigOrTermId)
                       ->update(['final_settlement_status' => 'Completed', 'clearance_status' => 'Completed', 'updated_at' => date('Y-m-d H:i:s')]);
                }
            } else {
                // Fallback: update only the single most recent record for that employee (never update all history by employee_id)
                if (in_array($sepType, ['Termination', 'Dismissal'], true) && $db->tableExists('employee_terminations')) {
                    $latestTerm = $db->table('employee_terminations')
                        ->where('employee_id', $employeeId)
                        ->orderBy('created_at', 'DESC')
                        ->limit(1)
                        ->get()
                        ->getRowArray();
                    if ($latestTerm) {
                        $db->table('employee_terminations')
                           ->where('id', $latestTerm['id'])
                           ->update(['final_settlement_status' => 'Completed', 'clearance_status' => 'Completed', 'updated_at' => date('Y-m-d H:i:s')]);
                    }
                } elseif ($db->tableExists('employee_resignations')) {
                    $latestResig = $db->table('employee_resignations')
                        ->where('employee_id', $employeeId)
                        ->orderBy('created_at', 'DESC')
                        ->limit(1)
                        ->get()
                        ->getRowArray();
                    if ($latestResig) {
                        $db->table('employee_resignations')
                           ->where('id', $latestResig['id'])
                           ->update(['final_settlement_status' => 'Completed', 'clearance_status' => 'Completed', 'updated_at' => date('Y-m-d H:i:s')]);
                    }
                }
            }

            // 6. Update settlement status to Disbursed
            $disbursedBy = $actorUserId ?: ($paymentDetails['disbursed_by'] ?? 'Finance Director');
            $this->settlementModel->update($settlementId, [
                'payment_status'        => 'Disbursed',
                'disbursement_date'     => $paymentDetails['disbursement_date'] ?? date('Y-m-d'),
                'payment_method'        => $paymentDetails['payment_method'] ?? ($settlement['payment_method'] ?: 'Bank Transfer'),
                'transaction_reference' => $paymentDetails['transaction_reference'] ?? ($settlement['transaction_reference'] ?: 'TXN-FS-' . strtoupper(bin2hex(random_bytes(4)))),
                'disbursed_by'          => $disbursedBy,
                'updated_at'            => date('Y-m-d H:i:s')
            ]);

            $db->transComplete();

            if ($db->transStatus() === false) {
                return [
                    'success' => false,
                    'message' => 'Transaction failed while disbursing final settlement.',
                    'code' => 500
                ];
            }

            return [
                'success' => true,
                'message' => 'Final settlement successfully disbursed and all employee accounts settled'
            ];
        } catch (\Throwable $e) {
            $db->transRollback();
            return [
                'success' => false,
                'message' => 'Disbursement error: ' . $e->getMessage(),
                'code' => 500
            ];
        }
    }
}
