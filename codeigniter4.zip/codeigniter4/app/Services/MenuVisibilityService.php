<?php

namespace App\Services;

use Config\Database;
use App\Models\MenuVisibilityModel;
use App\Models\UserModel;
use App\Models\RoleModel;

class MenuVisibilityService
{
    protected $db;
    protected $permissionService;
    protected $menuModel;

    // Request-level memory cache
    protected static array $visibilityCache = [];
    protected static array $roleVisibilityMapCache = [];
    protected static array $userRecordCache = [];
    protected static array $roleRecordCache = [];

    public function __construct(?PermissionService $permissionService = null)
    {
        $this->db = Database::connect();
        $this->permissionService = $permissionService ?? new PermissionService();
        $this->menuModel = new MenuVisibilityModel();
    }

    public static function clearCache(): void
    {
        self::$visibilityCache = [];
        self::$roleVisibilityMapCache = [];
        self::$userRecordCache = [];
        self::$roleRecordCache = [];
    }

    /**
     * Canonical Registry of all Sidebar Pages and their Tabs
     */
    public function getRegistry(): array
    {
        return [
            'dashboard' => [
                'key'                 => 'dashboard',
                'title'               => 'Dashboard',
                'icon'                => 'layout-grid',
                'required_permission' => 'dashboard.view',
                'tabs'                => [],
            ],
            'ess' => [
                'key'                 => 'ess',
                'title'               => 'Self-Service (ESS)',
                'icon'                => 'user-check',
                'required_permission' => 'dashboard.view',
                'tabs'                => [],
            ],
            'dashboard_widgets' => [
                'key'                 => 'dashboard_widgets',
                'title'               => 'Dashboard Widgets',
                'icon'                => 'sliders',
                'required_permission' => 'dashboard.manage',
                'tabs'                => [],
            ],
            'attendance' => [
                'key'                 => 'attendance',
                'title'               => 'Attendance Tracker',
                'icon'                => 'clock',
                'required_permission' => 'attendance.view',
                'tabs'                => [
                    [
                        'key'                 => 'attendance.overview',
                        'id'                  => 'overview',
                        'title'               => 'Overview',
                        'icon'                => 'layout-dashboard',
                        'required_permission' => 'attendance.view',
                    ],
                    [
                        'key'                 => 'attendance.today',
                        'id'                  => 'today',
                        'title'               => "Today's Muster",
                        'icon'                => 'calendar-check',
                        'required_permission' => 'attendance.view',
                    ],
                    [
                        'key'                 => 'attendance.live_control',
                        'id'                  => 'live-control',
                        'title'               => 'Live Control',
                        'icon'                => 'activity',
                        'required_permission' => 'attendance.manage',
                    ],
                    [
                        'key'                 => 'attendance.employee',
                        'id'                  => 'employee',
                        'title'               => 'Individual Ledger',
                        'icon'                => 'user',
                        'required_permission' => 'attendance.view',
                    ],
                    [
                        'key'                 => 'attendance.group',
                        'id'                  => 'group',
                        'title'               => 'Group Matrix',
                        'icon'                => 'users',
                        'required_permission' => 'attendance.view',
                    ],
                    [
                        'key'                 => 'attendance.calendar',
                        'id'                  => 'calendar',
                        'title'               => 'Calendar',
                        'icon'                => 'calendar',
                        'required_permission' => 'attendance.view',
                    ],
                    [
                        'key'                 => 'attendance.monthly',
                        'id'                  => 'monthly',
                        'title'               => 'Monthly Timesheet',
                        'icon'                => 'layers',
                        'required_permission' => 'attendance.view',
                    ],
                    [
                        'key'                 => 'attendance.corrections',
                        'id'                  => 'corrections',
                        'title'               => 'Corrections',
                        'icon'                => 'edit-3',
                        'required_permission' => 'attendance.view',
                    ],
                    [
                        'key'                 => 'attendance.early_closures',
                        'id'                  => 'early-closures',
                        'title'               => 'Company Early Closures',
                        'icon'                => 'building-2',
                        'required_permission' => 'attendance.early_closures',
                    ],
                    [
                        'key'                 => 'attendance.sync',
                        'id'                  => 'sync',
                        'title'               => 'ZKTeco Hardware',
                        'icon'                => 'server',
                        'required_permission' => 'attendance.sync',
                    ],
                    [
                        'key'                 => 'attendance.unmatched',
                        'id'                  => 'unmatched',
                        'title'               => 'Unmatched Biometric Staff',
                        'icon'                => 'fingerprint',
                        'required_permission' => 'attendance.view',
                    ],
                    [
                        'key'                 => 'attendance.clock',
                        'id'                  => 'clock',
                        'title'               => 'Self Clock & Kiosk',
                        'icon'                => 'scan-face',
                        'required_permission' => null,
                    ],
                    [
                        'key'                 => 'attendance.reports',
                        'id'                  => 'reports',
                        'title'               => 'Export & Reports',
                        'icon'                => 'download',
                        'required_permission' => 'reports.view',
                    ],
                ],
            ],
            'attendance_early_closures' => [
                'key'                 => 'attendance_early_closures',
                'title'               => 'Company Early Closures',
                'icon'                => 'building-2',
                'required_permission' => 'attendance.early_closures',
                'tabs'                => [],
            ],
            'roster' => [
                'key'                 => 'roster',
                'title'               => 'Shift & Roster',
                'icon'                => 'calendar-range',
                'required_permission' => 'rostering.view',
                'tabs'                => [],
            ],
            'biometric_sync' => [
                'key'                 => 'biometric_sync',
                'title'               => 'Biometric Device',
                'icon'                => 'refresh-cw',
                'required_permission' => 'attendance.sync',
                'tabs'                => [],
            ],
            'leave' => [
                'key'                 => 'leave',
                'title'               => 'Leave Management',
                'icon'                => 'calendar-off',
                'required_permission' => 'leaves.view',
                'tabs'                => [],
            ],
            'notices' => [
                'key'                 => 'notices',
                'title'               => 'Notice Board',
                'icon'                => 'megaphone',
                'required_permission' => 'notices.view',
                'tabs'                => [],
            ],
            'payroll' => [
                'key'                 => 'payroll',
                'title'               => 'Payroll & Salary',
                'icon'                => 'banknote',
                'required_permission' => 'payroll.view',
                'tabs'                => [
                    [
                        'key'                 => 'payroll.dashboard',
                        'id'                  => 'dashboard',
                        'title'               => 'Payroll Dashboard',
                        'icon'                => 'layout-dashboard',
                        'required_permission' => 'payroll.view',
                    ],
                    [
                        'key'                 => 'payroll.processing',
                        'id'                  => 'processing',
                        'title'               => 'Payroll Processing',
                        'icon'                => 'sliders',
                        'required_permission' => 'payroll.view',
                    ],
                    [
                        'key'                 => 'payroll.structures',
                        'id'                  => 'structures',
                        'title'               => 'Salary Structures',
                        'icon'                => 'layers',
                        'required_permission' => 'payroll.view',
                    ],
                    [
                        'key'                 => 'payroll.loans',
                        'id'                  => 'loans',
                        'title'               => 'Loans & Advances',
                        'icon'                => 'landmark',
                        'required_permission' => 'payroll.view',
                    ],
                    [
                        'key'                 => 'payroll.bank_export',
                        'id'                  => 'bank_export',
                        'title'               => 'Bank Payment & EFT',
                        'icon'                => 'building-2',
                        'required_permission' => 'payroll.export',
                    ],
                    [
                        'key'                 => 'payroll.payslips',
                        'id'                  => 'payslips',
                        'title'               => 'Payslip Generator',
                        'icon'                => 'file-text',
                        'required_permission' => 'payroll.view',
                    ],
                    [
                        'key'                 => 'payroll.settlement',
                        'id'                  => 'settlement',
                        'title'               => 'Final Settlement & Gratuity',
                        'icon'                => 'award',
                        'required_permission' => 'payroll.view',
                    ],
                    [
                        'key'                 => 'payroll.audit',
                        'id'                  => 'audit',
                        'title'               => 'Audit Log',
                        'icon'                => 'shield-check',
                        'required_permission' => 'payroll.view',
                    ],
                    [
                        'key'                 => 'payroll.pf_summary',
                        'id'                  => 'pf_summary',
                        'title'               => 'Provident Fund Summary',
                        'icon'                => 'piggy-bank',
                        'required_permission' => 'pf.view',
                    ],
                ],
            ],
            'pf_summary' => [
                'key'                 => 'pf_summary',
                'title'               => 'Provident Fund Summary',
                'icon'                => 'piggy-bank',
                'required_permission' => 'pf.view',
                'tabs'                => [
                    [
                        'key'                 => 'pf_summary.summary',
                        'id'                  => 'summary',
                        'title'               => 'PF Summary',
                        'icon'                => 'pie-chart',
                        'required_permission' => 'pf.view',
                    ],
                    [
                        'key'                 => 'pf_summary.details',
                        'id'                  => 'details',
                        'title'               => 'PF Monthly Ledgers',
                        'icon'                => 'file-text',
                        'required_permission' => 'pf.view',
                    ],
                    [
                        'key'                 => 'pf_summary.eligibility',
                        'id'                  => 'eligibility',
                        'title'               => 'PF Eligibility',
                        'icon'                => 'check-circle',
                        'required_permission' => 'pf.view',
                    ],
                    [
                        'key'                 => 'pf_summary.reconciliation',
                        'id'                  => 'reconciliation',
                        'title'               => 'PF Reconciliation',
                        'icon'                => 'scale',
                        'required_permission' => 'pf.view',
                    ],
                ],
            ],
            'bonuses' => [
                'key'                 => 'bonuses',
                'title'               => 'Bonuses & Incentives',
                'icon'                => 'gift',
                'required_permission' => 'bonus.view',
                'tabs'                => [],
            ],
            'loans' => [
                'key'                 => 'loans',
                'title'               => 'Employee Loans',
                'icon'                => 'wallet',
                'required_permission' => 'loans.view',
                'tabs'                => [],
            ],
            'insurance' => [
                'key'                 => 'insurance',
                'title'               => 'Medical Insurance',
                'icon'                => 'shield-plus',
                'required_permission' => 'medical_insurance.view',
                'tabs'                => [
                    [
                        'key'                 => 'insurance.dashboard',
                        'id'                  => 'dashboard',
                        'title'               => 'Dashboard',
                        'icon'                => 'layout-dashboard',
                        'required_permission' => 'medical_insurance.view',
                    ],
                    [
                        'key'                 => 'insurance.providers',
                        'id'                  => 'providers',
                        'title'               => 'Providers',
                        'icon'                => 'building-2',
                        'required_permission' => 'medical_insurance.view',
                    ],
                    [
                        'key'                 => 'insurance.plans',
                        'id'                  => 'plans',
                        'title'               => 'Plans',
                        'icon'                => 'layers',
                        'required_permission' => 'medical_insurance.view',
                    ],
                    [
                        'key'                 => 'insurance.enrollments',
                        'id'                  => 'enrollments',
                        'title'               => 'Enrollments',
                        'icon'                => 'users',
                        'required_permission' => 'medical_insurance.view',
                    ],
                    [
                        'key'                 => 'insurance.dependents',
                        'id'                  => 'dependents',
                        'title'               => 'Dependents',
                        'icon'                => 'heart-handshake',
                        'required_permission' => 'medical_insurance.view',
                    ],
                    [
                        'key'                 => 'insurance.claims',
                        'id'                  => 'claims',
                        'title'               => 'Claims',
                        'icon'                => 'receipt',
                        'required_permission' => 'medical_insurance.view',
                    ],
                    [
                        'key'                 => 'insurance.reports',
                        'id'                  => 'reports',
                        'title'               => 'Reports',
                        'icon'                => 'bar-chart-3',
                        'required_permission' => 'medical_insurance.view',
                    ],
                ],
            ],
            'rules' => [
                'key'                 => 'rules',
                'title'               => 'Rule Engine',
                'icon'                => 'scale',
                'required_permission' => 'rules.view',
                'tabs'                => [
                    [
                        'key'                 => 'rules.overview',
                        'id'                  => 'overview',
                        'title'               => 'Overview',
                        'icon'                => 'layers',
                        'required_permission' => 'rules.view',
                    ],
                    [
                        'key'                 => 'rules.attendance',
                        'id'                  => 'attendance',
                        'title'               => 'Attendance',
                        'icon'                => 'clock',
                        'required_permission' => 'attendance.view',
                    ],
                    [
                        'key'                 => 'rules.overtime',
                        'id'                  => 'overtime',
                        'title'               => 'Overtime',
                        'icon'                => 'timer',
                        'required_permission' => 'overtime.view',
                    ],
                    [
                        'key'                 => 'rules.leave',
                        'id'                  => 'leave',
                        'title'               => 'Leave Policy',
                        'icon'                => 'calendar-days',
                        'required_permission' => 'leave.view',
                    ],
                    [
                        'key'                 => 'rules.bonus',
                        'id'                  => 'bonus',
                        'title'               => 'Bonus',
                        'icon'                => 'gift',
                        'required_permission' => 'bonus.view',
                    ],
                    [
                        'key'                 => 'rules.pf',
                        'id'                  => 'pf',
                        'title'               => 'Provident Fund',
                        'icon'                => 'shield-check',
                        'required_permission' => 'pf.view',
                    ],
                    [
                        'key'                 => 'rules.gratuity',
                        'id'                  => 'gratuity',
                        'title'               => 'Gratuity',
                        'icon'                => 'award',
                        'required_permission' => 'payroll.view',
                    ],
                    [
                        'key'                 => 'rules.settlement',
                        'id'                  => 'settlement',
                        'title'               => 'Settlement',
                        'icon'                => 'receipt',
                        'required_permission' => 'settlement.view',
                    ],
                    [
                        'key'                 => 'rules.tax',
                        'id'                  => 'tax',
                        'title'               => 'Tax',
                        'icon'                => 'file-text',
                        'required_permission' => 'tax.view',
                    ],
                    [
                        'key'                 => 'rules.payroll_basics',
                        'id'                  => 'payroll_basics',
                        'title'               => 'Payroll Basics',
                        'icon'                => 'banknote',
                        'required_permission' => 'payroll.view',
                    ],
                ],
            ],
            'training' => [
                'key'                 => 'training',
                'title'               => 'Training Sessions',
                'icon'                => 'graduation-cap',
                'required_permission' => 'training.view',
                'tabs'                => [],
            ],
            'recruitment' => [
                'key'                 => 'recruitment',
                'title'               => 'Recruitment Portal',
                'icon'                => 'user-plus',
                'required_permission' => 'recruitment.view',
                'tabs'                => [],
            ],
            'performance' => [
                'key'                 => 'performance',
                'title'               => 'Performance Management',
                'icon'                => 'target',
                'required_permission' => 'performance.view',
                'tabs'                => [],
            ],
            'assets' => [
                'key'                 => 'assets',
                'title'               => 'Assets & Inventory',
                'icon'                => 'laptop',
                'required_permission' => 'assets.view',
                'tabs'                => [],
            ],
            'reports' => [
                'key'                 => 'reports',
                'title'               => 'Analytics & Export Hub',
                'icon'                => 'bar-chart-3',
                'required_permission' => 'reports.view',
                'tabs'                => [],
            ],
            'reports_upload' => [
                'key'                 => 'reports_upload',
                'title'               => 'Report Upload Hub',
                'icon'                => 'upload-cloud',
                'required_permission' => 'reports.view',
                'tabs'                => [],
            ],
            'branding' => [
                'key'                 => 'branding',
                'title'               => 'Company Logo & Branding',
                'icon'                => 'image',
                'required_permission' => 'master.view',
                'tabs'                => [],
            ],
            'company_profile' => [
                'key'                 => 'company_profile',
                'title'               => 'Company Profile',
                'icon'                => 'building-2',
                'required_permission' => 'master.view',
                'tabs'                => [],
            ],
            'employees' => [
                'key'                 => 'employees',
                'title'               => 'Employees Directory',
                'icon'                => 'users',
                'required_permission' => 'directory.view',
                'tabs'                => [
                    [
                        'key'                 => 'employees.overview',
                        'id'                  => 'overview',
                        'title'               => 'Overview',
                        'icon'                => 'layout-dashboard',
                        'required_permission' => 'directory.view',
                    ],
                    [
                        'key'                 => 'employees.personal',
                        'id'                  => 'personal',
                        'title'               => 'Personal Info',
                        'icon'                => 'user',
                        'required_permission' => 'directory.view',
                    ],
                    [
                        'key'                 => 'employees.contact',
                        'id'                  => 'contact',
                        'title'               => 'Contact',
                        'icon'                => 'phone',
                        'required_permission' => 'directory.view',
                    ],
                    [
                        'key'                 => 'employees.address',
                        'id'                  => 'address',
                        'title'               => 'Address',
                        'icon'                => 'map-pin',
                        'required_permission' => 'directory.view',
                    ],
                    [
                        'key'                 => 'employees.employment',
                        'id'                  => 'employment',
                        'title'               => 'Employment',
                        'icon'                => 'briefcase',
                        'required_permission' => 'directory.view',
                    ],
                    [
                        'key'                 => 'employees.bank',
                        'id'                  => 'bank',
                        'title'               => 'Bank & Salary',
                        'icon'                => 'landmark',
                        'required_permission' => 'directory.view',
                    ],
                    [
                        'key'                 => 'employees.education',
                        'id'                  => 'education',
                        'title'               => 'Education',
                        'icon'                => 'graduation-cap',
                        'required_permission' => 'directory.view',
                    ],
                    [
                        'key'                 => 'employees.experience',
                        'id'                  => 'experience',
                        'title'               => 'Experience',
                        'icon'                => 'award',
                        'required_permission' => 'directory.view',
                    ],
                    [
                        'key'                 => 'employees.family',
                        'id'                  => 'family',
                        'title'               => 'Family',
                        'icon'                => 'users',
                        'required_permission' => 'directory.view',
                    ],
                    [
                        'key'                 => 'employees.emergency',
                        'id'                  => 'emergency',
                        'title'               => 'Emergency',
                        'icon'                => 'phone-call',
                        'required_permission' => 'directory.view',
                    ],
                    [
                        'key'                 => 'employees.documents',
                        'id'                  => 'documents',
                        'title'               => 'Documents',
                        'icon'                => 'file-text',
                        'required_permission' => 'directory.view',
                    ],
                    [
                        'key'                 => 'employees.promotion',
                        'id'                  => 'promotion',
                        'title'               => 'Promotions',
                        'icon'                => 'trending-up',
                        'required_permission' => 'directory.view',
                    ],
                    [
                        'key'                 => 'employees.transfer',
                        'id'                  => 'transfer',
                        'title'               => 'Transfers',
                        'icon'                => 'arrow-left-right',
                        'required_permission' => 'directory.view',
                    ],
                    [
                        'key'                 => 'employees.resignation',
                        'id'                  => 'resignation',
                        'title'               => 'Resignation',
                        'icon'                => 'log-out',
                        'required_permission' => 'directory.view',
                    ],
                    [
                        'key'                 => 'employees.termination',
                        'id'                  => 'termination',
                        'title'               => 'Termination',
                        'icon'                => 'shield-alert',
                        'required_permission' => 'directory.view',
                    ],
                    [
                        'key'                 => 'employees.attendance',
                        'id'                  => 'attendance',
                        'title'               => 'Attendance',
                        'icon'                => 'clock',
                        'required_permission' => 'attendance.view',
                    ],
                    [
                        'key'                 => 'employees.leave',
                        'id'                  => 'leave',
                        'title'               => 'Leave History',
                        'icon'                => 'plane-takeoff',
                        'required_permission' => 'leaves.view',
                    ],
                    [
                        'key'                 => 'employees.payroll',
                        'id'                  => 'payroll',
                        'title'               => 'Payroll & Payslips',
                        'icon'                => 'receipt',
                        'required_permission' => 'payroll.view',
                    ],
                    [
                        'key'                 => 'employees.provident_fund',
                        'id'                  => 'provident_fund',
                        'title'               => 'Provident Fund',
                        'icon'                => 'piggy-bank',
                        'required_permission' => null,
                    ],
                    [
                        'key'                 => 'employees.skills',
                        'id'                  => 'skills',
                        'title'               => 'Skills',
                        'icon'                => 'zap',
                        'required_permission' => 'directory.view',
                    ],
                    [
                        'key'                 => 'employees.performance',
                        'id'                  => 'performance',
                        'title'               => 'Performance',
                        'icon'                => 'star',
                        'required_permission' => 'performance.view',
                    ],
                    [
                        'key'                 => 'employees.training',
                        'id'                  => 'training',
                        'title'               => 'Training',
                        'icon'                => 'book-open',
                        'required_permission' => 'training.view',
                    ],
                    [
                        'key'                 => 'employees.assets',
                        'id'                  => 'assets',
                        'title'               => 'Assets',
                        'icon'                => 'laptop',
                        'required_permission' => 'assets.view',
                    ],
                    [
                        'key'                 => 'employees.login',
                        'id'                  => 'login',
                        'title'               => 'Login & Security',
                        'icon'                => 'shield-check',
                        'required_permission' => 'security.view',
                    ],
                    [
                        'key'                 => 'employees.audit',
                        'id'                  => 'audit',
                        'title'               => 'Audit Trail',
                        'icon'                => 'history',
                        'required_permission' => 'audit.view',
                    ],
                ],
            ],
            'organogram' => [
                'key'                 => 'organogram',
                'title'               => 'Employee Organogram',
                'icon'                => 'git-branch',
                'required_permission' => 'directory.view',
                'tabs'                => [],
            ],
            'master' => [
                'key'                 => 'master',
                'title'               => 'Master Console',
                'icon'                => 'layers',
                'required_permission' => 'master.view',
                'tabs'                => [],
            ],
            'security' => [
                'key'                 => 'security',
                'title'               => 'Security & RBAC',
                'icon'                => 'shield-check',
                'required_permission' => 'security.view',
                'tabs'                => [
                    [
                        'key'                 => 'security.users',
                        'id'                  => 'users',
                        'title'               => 'User Accounts',
                        'icon'                => 'users',
                        'required_permission' => 'security.view',
                    ],
                    [
                        'key'                 => 'security.roles',
                        'id'                  => 'roles',
                        'title'               => 'Security & RBAC Suite',
                        'icon'                => 'shield-check',
                        'required_permission' => 'role.manage',
                    ],
                    [
                        'key'                 => 'security.login_audit',
                        'id'                  => 'login-audit',
                        'title'               => 'Login Audit Logs',
                        'icon'                => 'history',
                        'required_permission' => 'audit.view',
                    ],
                    [
                        'key'                 => 'security.menu_access',
                        'id'                  => 'menu-access',
                        'title'               => 'Menu & Tab Access',
                        'icon'                => 'sliders',
                        'required_permission' => 'role.manage',
                    ],
                ],
            ],
            'system' => [
                'key'                 => 'system',
                'title'               => 'System Administration',
                'icon'                => 'sliders',
                'required_permission' => 'system.view',
                'tabs'                => [
                    [
                        'key'                 => 'system.backups',
                        'id'                  => 'backups',
                        'title'               => 'Backup Manager',
                        'icon'                => 'hard-drive',
                        'required_permission' => 'backups.view',
                    ],
                    [
                        'key'                 => 'system.restore',
                        'id'                  => 'restore',
                        'title'               => 'Restore Core',
                        'icon'                => 'archive-restore',
                        'required_permission' => 'backups.restore',
                    ],
                    [
                        'key'                 => 'system.smtp',
                        'id'                  => 'smtp',
                        'title'               => 'SMTP Gateway',
                        'icon'                => 'mail',
                        'required_permission' => 'email.smtp.view',
                    ],
                    [
                        'key'                 => 'system.templates',
                        'id'                  => 'templates',
                        'title'               => 'Email Templates',
                        'icon'                => 'layout-template',
                        'required_permission' => 'email.template.view',
                    ],
                    [
                        'key'                 => 'system.logs',
                        'id'                  => 'logs',
                        'title'               => 'Security Audit Logs',
                        'icon'                => 'scroll',
                        'required_permission' => 'audit.view',
                    ],
                    [
                        'key'                 => 'system.settings',
                        'id'                  => 'settings',
                        'title'               => 'General Settings',
                        'icon'                => 'settings',
                        'required_permission' => 'settings.view',
                    ],
                    [
                        'key'                 => 'system.security',
                        'id'                  => 'security',
                        'title'               => 'Security Policies',
                        'icon'                => 'shield-check',
                        'required_permission' => 'settings.view',
                    ],
                    [
                        'key'                 => 'system.theme',
                        'id'                  => 'theme',
                        'title'               => 'Theme & Styling',
                        'icon'                => 'palette',
                        'required_permission' => 'theme.view',
                    ],
                ],
            ],
        ];
    }

    /**
     * Get all known valid menu and tab item keys from the canonical registry
     */
    public function getKnownMenuKeys(): array
    {
        $keys = [];
        foreach ($this->getRegistry() as $pageKey => $page) {
            $keys[] = (string)$pageKey;
            if (!empty($page['tabs']) && is_array($page['tabs'])) {
                foreach ($page['tabs'] as $tab) {
                    if (!empty($tab['key'])) {
                        $keys[] = (string)$tab['key'];
                    }
                }
            }
        }
        return array_values(array_unique($keys));
    }

    /**
     * Get parent key if key represents a tab
     */
    public function getParentKey(string $key): ?string
    {
        if (str_contains($key, '.')) {
            $parts = explode('.', $key, 2);
            return $parts[0];
        }
        return null;
    }

    /**
     * Get required permission for an item key
     */
    public function getRequiredPermission(string $key): ?string
    {
        $registry = $this->getRegistry();
        $parent = $this->getParentKey($key);

        if ($parent !== null) {
            if (isset($registry[$parent]['tabs'])) {
                foreach ($registry[$parent]['tabs'] as $tab) {
                    if ($tab['key'] === $key) {
                        return $tab['required_permission'];
                    }
                }
            }
            return null;
        }

        return $registry[$key]['required_permission'] ?? null;
    }

    /**
     * Check if an item is strictly protected from being hidden for Company Admin
     */
    public function isProtectedItem(string $key, ?string $canonicalRole = null): bool
    {
        if ($key === 'security' || $key === 'security.menu_access') {
            if ($canonicalRole === null || in_array($canonicalRole, ['company_admin', 'super_admin'], true)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Check if a role has permission for a specific item
     */
    public function roleHasPermission(array $role, string $key): bool
    {
        $canonical = $this->permissionService->canonicalizeRole($role['code'] ?? $role['name'] ?? '');
        if ($canonical === 'software_app_admin') {
            return true;
        }

        $requiredPerm = $this->getRequiredPermission($key);
        if ($requiredPerm === null) {
            return true;
        }

        if ($canonical === 'company_admin') {
            // Company Admin has access to company modules, except platform-only system actions
            if (str_starts_with($requiredPerm, 'system.')) {
                return false;
            }
            return true;
        }

        // Check assigned permissions for role
        $roleId = $role['id'] ?? '';
        if (empty($roleId)) {
            return false;
        }

        $assigned = $this->permissionService->getRolePermissions($roleId);
        $assignedCodes = array_column($assigned, 'code');
        if (in_array($requiredPerm, $assignedCodes, true)) {
            return true;
        }
        foreach ($assignedCodes as $c) {
            if ($this->permissionService->areEquivalent($c, $requiredPerm)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Fetch user record with static caching
     */
    protected function getUser(string $userId): ?array
    {
        if (isset(self::$userRecordCache[$userId])) {
            return self::$userRecordCache[$userId];
        }

        try {
            $user = $this->db->table('users')->where('id', $userId)->get()->getRowArray();
            self::$userRecordCache[$userId] = $user;
            return $user;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Fetch role record with static caching
     */
    protected function getRole(string $roleId): ?array
    {
        if (isset(self::$roleRecordCache[$roleId])) {
            return self::$roleRecordCache[$roleId];
        }

        try {
            $role = $this->db->table('roles')->where('id', $roleId)->get()->getRowArray();
            self::$roleRecordCache[$roleId] = $role;
            return $role;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Core Visibility Check for a user
     * Priority:
     * 1) Permission check (no permission = never visible)
     * 2) Employee override (if present)
     * 3) Role setting
     * 4) Default = visible
     * A tab is visible only if its parent page is visible.
     */
    public function isVisible(?string $userId, string $key): bool
    {
        if (empty($userId)) {
            $userId = (string)(session()->get('user_id') ?? '');
        }

        if (empty($userId)) {
            return false;
        }

        // Cache key per request
        $cacheKey = $userId . '|' . $key;
        if (isset(self::$visibilityCache[$cacheKey])) {
            return self::$visibilityCache[$cacheKey];
        }

        $user = $this->getUser($userId);
        if (!$user) {
            self::$visibilityCache[$cacheKey] = false;
            return false;
        }

        $roleId = $user['role_id'] ?? '';
        $role = !empty($roleId) ? $this->getRole($roleId) : null;
        $canonicalRole = $this->permissionService->canonicalizeRole($role['code'] ?? $role['name'] ?? session()->get('role') ?? 'employee');

        // Software App Admin is NEVER affected: everything is visible
        if ($canonicalRole === 'software_app_admin' || $this->permissionService->isSoftwareAppAdmin($canonicalRole)) {
            self::$visibilityCache[$cacheKey] = true;
            return true;
        }

        $companyId = $user['company_id'] ?? (session()->get('company_id') ?: null);

        // Protected items cannot be hidden for Company Admin
        if ($canonicalRole === 'company_admin' && $this->isProtectedItem($key, $canonicalRole)) {
            self::$visibilityCache[$cacheKey] = true;
            return true;
        }

        // Tab hierarchy rule: A tab is visible only if its parent page is visible
        $parentKey = $this->getParentKey($key);
        if ($parentKey !== null) {
            if (!$this->isVisible($userId, $parentKey)) {
                self::$visibilityCache[$cacheKey] = false;
                return false;
            }
        }

        // Priority 1: Permission check (no permission = never visible)
        $requiredPerm = $this->getRequiredPermission($key);
        if ($requiredPerm !== null) {
            if (!$this->permissionService->hasPermission($requiredPerm, $userId)) {
                self::$visibilityCache[$cacheKey] = false;
                return false;
            }
        }

        if (empty($companyId) || !$this->db->tableExists('menu_visibility')) {
            self::$visibilityCache[$cacheKey] = true;
            return true;
        }

        // Priority 2: Employee override (if present)
        $userRow = $this->db->table('menu_visibility')
            ->where('company_id', $companyId)
            ->where('scope_type', 'user')
            ->where('scope_id', $userId)
            ->where('item_key', $key)
            ->get()
            ->getRowArray();

        if ($userRow !== null) {
            $result = ((int)$userRow['is_visible'] === 1);
            self::$visibilityCache[$cacheKey] = $result;
            return $result;
        }

        // Priority 3: Role setting
        if (!empty($roleId)) {
            $roleRow = $this->db->table('menu_visibility')
                ->where('company_id', $companyId)
                ->where('scope_type', 'role')
                ->where('scope_id', $roleId)
                ->where('item_key', $key)
                ->get()
                ->getRowArray();

            if ($roleRow !== null) {
                $result = ((int)$roleRow['is_visible'] === 1);
                self::$visibilityCache[$cacheKey] = $result;
                return $result;
            }
        }

        // Priority 4: Default = visible
        self::$visibilityCache[$cacheKey] = true;
        return true;
    }

    /**
     * Compute effective visibility for a role (used in Admin UI)
     */
    public function isVisibleForRole(string $companyId, array $role, string $key): bool
    {
        $canonical = $this->permissionService->canonicalizeRole($role['code'] ?? $role['name'] ?? '');
        if ($canonical === 'software_app_admin') {
            return true;
        }

        // Protected items
        if ($canonical === 'company_admin' && $this->isProtectedItem($key, $canonical)) {
            return true;
        }

        // Hierarchy rule
        $parentKey = $this->getParentKey($key);
        if ($parentKey !== null) {
            if (!$this->isVisibleForRole($companyId, $role, $parentKey)) {
                return false;
            }
        }

        // Permission check
        if (!$this->roleHasPermission($role, $key)) {
            return false;
        }

        if (!$this->db->tableExists('menu_visibility')) {
            return true;
        }

        $row = $this->db->table('menu_visibility')
            ->where('company_id', $companyId)
            ->where('scope_type', 'role')
            ->where('scope_id', $role['id'])
            ->where('item_key', $key)
            ->get()
            ->getRowArray();

        if ($row !== null) {
            return ((int)$row['is_visible'] === 1);
        }

        return true;
    }

    /**
     * Returns raw role visibility map (ignoring parent cascade, for editor state)
     */
    public function getRoleRawVisibilityMap(string $companyId, string $roleId): array
    {
        $map = [];
        if (!$this->db->tableExists('menu_visibility')) {
            return $map;
        }

        $rows = $this->db->table('menu_visibility')
            ->where('company_id', $companyId)
            ->where('scope_type', 'role')
            ->where('scope_id', $roleId)
            ->get()
            ->getResultArray();

        foreach ($rows as $r) {
            $map[$r['item_key']] = ((int)$r['is_visible'] === 1);
        }

        return $map;
    }

    /**
     * Returns raw user exception overrides map
     */
    public function getUserRawOverridesMap(string $companyId, string $userId): array
    {
        $map = [];
        if (!$this->db->tableExists('menu_visibility')) {
            return $map;
        }

        $rows = $this->db->table('menu_visibility')
            ->where('company_id', $companyId)
            ->where('scope_type', 'user')
            ->where('scope_id', $userId)
            ->get()
            ->getResultArray();

        foreach ($rows as $r) {
            $map[$r['item_key']] = ((int)$r['is_visible'] === 1);
        }

        return $map;
    }

    /**
     * Helper to find the first visible tab on a page (for redirects)
     */
    public function getFirstVisibleTab(string $pageKey, ?string $userId = null): ?string
    {
        $registry = $this->getRegistry();
        if (empty($registry[$pageKey]['tabs'])) {
            return null;
        }

        foreach ($registry[$pageKey]['tabs'] as $tab) {
            if ($this->isVisible($userId, $tab['key'])) {
                return $tab['id'];
            }
        }

        return null;
    }
}
