<?php

namespace App\Services;

use App\Models\AuditLogModel;
use Ramsey\Uuid\Uuid;

class AuditService
{
    private function normalizeJsonValue($value): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }

        if (is_string($value)) {
            $trimmed = trim($value);

            if ($trimmed === '') {
                return null;
            }

            json_decode($trimmed);
            if (json_last_error() === JSON_ERROR_NONE) {
                return $trimmed;
            }

            return json_encode(['value' => $value], JSON_THROW_ON_ERROR);
        }

        return json_encode($value, JSON_THROW_ON_ERROR);
    }

    public function log(
        ?string $userId,
        string $module,
        string $action,
        ?string $recordId = null,
        $oldValues = null,
        $newValues = null,
        $ipAddress = null,
        $userAgent = null,
        ?string $details = null
    ): void {
        try {
            // Defensive argument alignment for shifted or legacy signatures
            if (is_array($ipAddress) || is_array($userAgent)) {
                $funcArgs = func_get_args();
                if (count($funcArgs) >= 8 && (is_array($funcArgs[6] ?? null) || is_array($funcArgs[7] ?? null))) {
                    // Shifted: ($userId, $companyId, $module, $submodule, $action, $recordId, $oldValues, $newValues, $details)
                    $module = trim(($funcArgs[2] ?? $module) . '.' . ($funcArgs[3] ?? ''), '.');
                    $action = (string)($funcArgs[4] ?? $action);
                    $recordId = (string)($funcArgs[5] ?? $recordId);
                    $oldValues = $funcArgs[6] ?? null;
                    $newValues = $funcArgs[7] ?? null;
                    $details = is_string($funcArgs[8] ?? null) ? $funcArgs[8] : null;
                }
                $ipAddress = null;
                $userAgent = null;
            }

            $ipAddress = is_string($ipAddress) ? $ipAddress : null;
            $userAgent = is_string($userAgent) ? $userAgent : null;

            $request = service('request');
            $ip = $ipAddress ?? ($request ? $request->getIPAddress() : '127.0.0.1');
            $agent = $userAgent ?? ($request && $request->getUserAgent() ? $request->getUserAgent()->getAgentString() : 'System');

            $db = \Config\Database::connect();
            $fields = $db->getFieldNames('audit_logs');
            $hasField = fn(string $f): bool => in_array($f, $fields, true);

            $uuidStr = null;
            if (class_exists(Uuid::class)) {
                try {
                    $uuidStr = Uuid::uuid4()->toString();
                } catch (\Throwable $e) {}
            }
            if (!$uuidStr) {
                $bytes = random_bytes(16);
                $bytes[6] = chr(ord($bytes[6]) & 0x0f | 0x40);
                $bytes[8] = chr(ord($bytes[8]) & 0x3f | 0x80);
                $uuidStr = vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($bytes), 4));
            }

            $data = [
                'id' => $uuidStr,
                'created_at' => date('Y-m-d H:i:s'),
            ];

            if ($hasField('user_id')) {
                $data['user_id'] = $userId;
            }
            if ($hasField('module')) {
                $data['module'] = $module;
            }
            if ($hasField('action')) {
                $data['action'] = $action;
            }
            if ($hasField('record_id')) {
                $data['record_id'] = $recordId;
            }
            if ($hasField('entity_id') && !isset($data['entity_id'])) {
                $data['entity_id'] = $recordId;
            }
            if ($hasField('entity_type') && !isset($data['entity_type'])) {
                $data['entity_type'] = $module;
            }
            if ($hasField('details')) {
                $data['details'] = $details;
            }
            if ($hasField('old_values')) {
                $data['old_values'] = $this->normalizeJsonValue($oldValues);
            }
            if ($hasField('new_values')) {
                $data['new_values'] = $this->normalizeJsonValue($newValues);
            }
            if ($hasField('ip_address')) {
                $data['ip_address'] = $ip ?? '127.0.0.1';
            }
            if ($hasField('user_agent')) {
                $data['user_agent'] = $agent;
            }
            if ($hasField('timestamp') && !isset($data['timestamp'])) {
                $data['timestamp'] = date('Y-m-d H:i:s');
            }

            $db->table('audit_logs')->insert($data);
        } catch (\Throwable $e) {
            log_message('error', 'AuditService::log error: ' . $e->getMessage());
        }
    }
}
