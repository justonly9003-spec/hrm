<?php

namespace App\Services\Mobile;

use App\Services\Auth\AccountLockoutService;
use App\Services\Auth\RateLimitService;
use CodeIgniter\Database\BaseConnection;
use Config\Database;
use Ramsey\Uuid\Uuid;

class MobileAuthService
{
    private BaseConnection $db;

    public function __construct(?BaseConnection $db = null)
    {
        $this->db = $db ?? Database::connect();
    }

    public function login(
        string $companyCode,
        string $identifier,
        string $password,
        array $device = [],
        ?string $ip = null,
        ?string $userAgent = null
    ): array {
        $companyCode = trim($companyCode);
        $identifier  = trim($identifier);

        if ($companyCode === '' || $identifier === '' || $password === '') {
            $errors = [];
            if ($companyCode === '') {
                $errors['company_code'] = 'Company code is required.';
            }
            if ($identifier === '') {
                $errors['identifier'] = 'Identifier is required.';
            }
            if ($password === '') {
                $errors['password'] = 'Password is required.';
            }
            return [
                'ok'      => false,
                'status'  => 401,
                'message' => 'Company code, identifier, and password are required.',
                'errors'  => $errors,
            ];
        }

        // Rate limiting check (per-IP and per-Account)
        $rateCheck = RateLimitService::checkLogin((string)$ip, $companyCode, $identifier);
        if (!($rateCheck['allowed'] ?? false)) {
            $retryAfter = (int)($rateCheck['retry_after'] ?? 60);
            return [
                'ok'          => false,
                'status'      => 429,
                'message'     => $rateCheck['message'] ?? 'Too many login attempts. Please try again later.',
                'retry_after' => $retryAfter,
            ];
        }

        $company = $this->db->table('companies')
            ->where('code', $companyCode)
            ->where('status', 'active')
            ->get()->getRowArray();

        if (!$company) {
            $this->logLogin(null, $ip, $userAgent, 'failed');
            // Prevent tenant enumeration by returning consistent credentials error
            return ['ok' => false, 'status' => 401, 'message' => 'Invalid credentials.'];
        }

        // Safe concurrency using transaction
        $this->db->transStart();

        $user = $this->db->table('users')
            ->select('users.*, roles.code as role_code')
            ->join('roles', 'roles.id = users.role_id', 'left')
            ->where('users.company_id', $company['id'])
            ->groupStart()
                ->where('users.username', $identifier)
                ->orWhere('users.email', $identifier)
            ->groupEnd()
            ->get()->getRowArray();

        if (!$user) {
            $this->db->transComplete();
            $this->logLogin(null, $ip, $userAgent, 'failed');
            return ['ok' => false, 'status' => 401, 'message' => 'Invalid credentials.'];
        }

        if (strtolower((string)($user['status'] ?? '')) !== 'active') {
            $this->db->transComplete();
            $this->logLogin($user['id'], $ip, $userAgent, 'blocked');
            return ['ok' => false, 'status' => 401, 'message' => 'Account is not active.'];
        }

        // Central Account Lockout Check (5 failed attempts = 15 minutes lockout)
        if (AccountLockoutService::isLocked($user)) {
            $remainingSecs = AccountLockoutService::getRemainingLockoutSeconds($user);
            $remainingMins = max(1, (int)ceil($remainingSecs / 60));
            $this->db->transComplete();
            $this->logLogin($user['id'], $ip, $userAgent, 'locked');

            return [
                'ok'          => false,
                'status'      => 429,
                'message'     => "Account is temporarily locked due to consecutive failed attempts. Please retry in {$remainingMins} minute(s) or contact administrator.",
                'retry_after' => $remainingSecs,
            ];
        }

        if (!password_verify($password, (string)($user['password_hash'] ?? ''))) {
            // Failed password attempt
            // If lock has expired previously, start fresh from 1
            if (!empty($user['locked_until']) && strtotime((string)$user['locked_until']) <= time()) {
                $newFailed = 1;
            } else {
                $newFailed = (int)($user['failed_logins'] ?? 0) + 1;
            }

            $updateData = ['failed_logins' => $newFailed];
            $isNowLocked = false;
            $lockSecs = 0;

            $maxAttempts = AccountLockoutService::getMaxAttempts($company['id'] ?? null);
            if ($newFailed >= $maxAttempts) {
                $lockSecs = AccountLockoutService::getLockoutDurationSeconds($company['id'] ?? null);
                $updateData['locked_until'] = date('Y-m-d H:i:s', time() + $lockSecs);
                $isNowLocked = true;
            }

            $this->db->table('users')
                ->where('id', $user['id'])
                ->where('company_id', $company['id'])
                ->update($updateData);

            $this->db->transComplete();

            if ($isNowLocked) {
                $this->logLogin($user['id'], $ip, $userAgent, 'locked');
                $this->auditLockout($user['id'], (string)($user['username'] ?? $identifier), $newFailed, $ip, $userAgent);

                return [
                    'ok'          => false,
                    'status'      => 429,
                    'message'     => 'Too many failed login attempts. Your account has been temporarily locked for 15 minutes.',
                    'retry_after' => $lockSecs,
                ];
            }

            $this->logLogin($user['id'], $ip, $userAgent, 'failed');
            return ['ok' => false, 'status' => 401, 'message' => 'Invalid credentials.'];
        }

        if (!empty($user['employee_id']) && $this->db->tableExists('employees')) {
            $emp = $this->db->table('employees')
                ->where('id', $user['employee_id'])
                ->where('company_id', $company['id'])
                ->get()->getRowArray();
            if (!$emp) {
                $this->db->transComplete();
                $this->logLogin($user['id'], $ip, $userAgent, 'blocked');
                return ['ok' => false, 'status' => 403, 'message' => 'Employee record does not match company context.'];
            }
        }

        // Live account, company, and employee status validation
        $contextCheck = $this->validateLiveAccountContext($user['id'], $company['id'], $user['employee_id'] ?? null);
        if (!$contextCheck['ok']) {
            $this->db->transComplete();
            $this->logLogin($user['id'], $ip, $userAgent, 'blocked');
            return [
                'ok'      => false,
                'status'  => $contextCheck['status'] ?? 403,
                'message' => $contextCheck['message'] ?? 'Account or employee profile is not authorized.',
            ];
        }

        // Legitimate login: reset failed_logins and clear locked_until
        $this->db->table('users')
            ->where('id', $user['id'])
            ->where('company_id', $company['id'])
            ->update([
                'failed_logins' => 0,
                'locked_until'  => null,
                'last_login_at' => date('Y-m-d H:i:s'),
            ]);
        $this->db->transComplete();
        $this->logLogin($user['id'], $ip, $userAgent, 'success');

        $deviceUid = trim((string)($device['device_uid'] ?? 'dev-' . bin2hex(random_bytes(8))));
        $platform  = substr((string)($device['platform'] ?? 'unknown'), 0, 20);
        $devName   = substr((string)($device['device_name'] ?? 'Mobile Device'), 0, 150);
        $appVer    = substr((string)($device['app_version'] ?? '1.0'), 0, 30);
        $pushToken = isset($device['push_token']) ? substr((string)$device['push_token'], 0, 512) : null;

        $existingDevice = $this->db->table('mobile_devices')
            ->where('user_id', $user['id'])
            ->where('company_id', $company['id'])
            ->where('device_uid', $deviceUid)
            ->get()->getRowArray();

        $deviceId = $existingDevice['id'] ?? Uuid::uuid4()->toString();
        $now = date('Y-m-d H:i:s');

        if ($existingDevice) {
            $this->db->table('mobile_devices')
                ->where('id', $deviceId)
                ->where('user_id', $user['id'])
                ->where('company_id', $company['id'])
                ->update([
                    'platform'     => $platform,
                    'device_name'  => $devName,
                    'app_version'  => $appVer,
                    'push_token'   => $pushToken ?? $existingDevice['push_token'],
                    'last_seen_at' => $now,
                    'updated_at'   => $now,
                ]);
        } else {
            $this->db->table('mobile_devices')->insert([
                'id'           => $deviceId,
                'user_id'      => $user['id'],
                'company_id'   => $company['id'],
                'device_uid'   => $deviceUid,
                'platform'     => $platform,
                'device_name'  => $devName,
                'app_version'  => $appVer,
                'push_token'   => $pushToken,
                'last_seen_at' => $now,
                'created_at'   => $now,
                'updated_at'   => $now,
            ]);
        }

        $tokens = $this->issueTokenPair($user['id'], $company['id'], $deviceId, null, $ip);

        return [
            'ok'      => true,
            'status'  => 200,
            'message' => 'Login successful.',
            'data'    => [
                'tokens' => $tokens,
                'user'   => [
                    'id'                   => $user['id'],
                    'user_id'              => $user['id'],
                    'name'                 => $user['name'] ?? $user['username'],
                    'username'             => $user['username'],
                    'email'                => $user['email'],
                    'company_id'           => $user['company_id'],
                    'company_code'         => $company['code'] ?? '',
                    'company_name'         => $company['name'] ?? '',
                    'employee_id'          => $user['employee_id'],
                    'branch_id'            => $user['branch_id'],
                    'role'                 => strtoupper((string)($user['role_code'] ?? 'EMPLOYEE')),
                    'role_code'            => $user['role_code'] ?? 'employee',
                    'must_change_password' => (bool)($user['must_change_password'] ?? false),
                ],
            ],
        ];
    }

    public function refresh(string $refreshToken, ?string $ip = null): array
    {
        $refreshToken = trim($refreshToken);
        if ($refreshToken === '') {
            return [
                'ok'      => false,
                'status'  => 401,
                'message' => 'Refresh token is required.',
                'errors'  => ['refresh_token' => 'Refresh token is required.'],
            ];
        }

        // Rate limiting check
        $rateCheck = RateLimitService::checkRefresh((string)$ip, $refreshToken);
        if (!($rateCheck['allowed'] ?? false)) {
            $retryAfter = (int)($rateCheck['retry_after'] ?? 60);
            return [
                'ok'          => false,
                'status'      => 429,
                'message'     => $rateCheck['message'] ?? 'Too many refresh requests. Please try again later.',
                'retry_after' => $retryAfter,
            ];
        }

        $hash = hash('sha256', $refreshToken);
        $record = $this->db->table('mobile_refresh_tokens')->where('token_hash', $hash)->get()->getRowArray();

        if (!$record) {
            return ['ok' => false, 'status' => 401, 'message' => 'Invalid refresh token.'];
        }

        $now = date('Y-m-d H:i:s');

        // Check if token was explicitly revoked
        if (!empty($record['revoked_at'])) {
            // Already revoked token: trigger family-wide revocation to protect against token compromise
            $this->revokeTokenFamily($record['family_id'], $record['user_id'], $record['company_id']);
            return ['ok' => false, 'status' => 401, 'message' => 'Invalid or revoked refresh token. Token family revoked.'];
        }

        // Check if token was previously used (single-use rotation check)
        if (!empty($record['used_at'])) {
            // REFRESH TOKEN REUSE ATTACK DETECTED!
            // Revoke the entire token family immediately to protect user account.
            $this->revokeTokenFamily($record['family_id'], $record['user_id'], $record['company_id']);
            $this->db->table('mobile_access_tokens')
                ->where('user_id', $record['user_id'])
                ->where('device_id', $record['device_id'])
                ->update(['revoked_at' => $now]);

            return ['ok' => false, 'status' => 401, 'message' => 'Invalid or reused refresh token. Token family revoked.'];
        }

        if (strtotime($record['expires_at']) < time()) {
            return ['ok' => false, 'status' => 401, 'message' => 'Refresh token has expired.'];
        }

        // Comprehensive live account, tenant, and employee status validation
        $contextCheck = $this->validateLiveAccountContext($record['user_id'], $record['company_id']);
        if (!$contextCheck['ok']) {
            // Disabled or unauthorized account: revoke entire token family so no further tokens can be issued
            $this->revokeTokenFamily($record['family_id'], $record['user_id'], $record['company_id']);
            $this->db->table('mobile_access_tokens')
                ->where('user_id', $record['user_id'])
                ->where('device_id', $record['device_id'])
                ->update(['revoked_at' => $now]);

            return [
                'ok'      => false,
                'status'  => $contextCheck['status'] ?? 401,
                'message' => $contextCheck['message'] ?? 'Account is not authorized.',
            ];
        }

        $serverVerifiedUser = $contextCheck['user'];

        // Atomic rotation: mark token as used
        $this->db->transStart();
        $this->db->table('mobile_refresh_tokens')
            ->where('id', $record['id'])
            ->where('used_at IS NULL')
            ->where('revoked_at IS NULL')
            ->update(['used_at' => $now]);

        if ($this->db->affectedRows() === 0) {
            $this->db->transComplete();
            return ['ok' => false, 'status' => 401, 'message' => 'Concurrent refresh in progress. Please retry.'];
        }

        // Issue new token pair preserving token family
        $newTokens = $this->issueTokenPair(
            $serverVerifiedUser['id'],
            $serverVerifiedUser['company_id'],
            $record['device_id'],
            $record['family_id'],
            $ip
        );

        $this->db->table('mobile_refresh_tokens')
            ->where('id', $record['id'])
            ->update([
                'replaced_by_id' => $newTokens['refresh_token_id'],
            ]);

        // Revoke older access token associated with the previous refresh token
        $this->db->table('mobile_access_tokens')
            ->where('refresh_token_id', $record['id'])
            ->where('revoked_at IS NULL')
            ->update(['revoked_at' => $now]);

        unset($newTokens['refresh_token_id']);

        $this->db->transComplete();

        return [
            'ok'      => true,
            'status'  => 200,
            'message' => 'Tokens refreshed successfully.',
            'data'    => [
                'tokens' => $newTokens,
            ],
        ];
    }

    public function logout(string $accessToken, ?string $userId = null, ?string $companyId = null): array
    {
        $accessToken = trim($accessToken);
        if ($accessToken === '') {
            return ['ok' => true, 'status' => 200, 'message' => 'Logged out.'];
        }

        $hash = hash('sha256', $accessToken);
        $now = date('Y-m-d H:i:s');

        $tb = $this->db->table('mobile_access_tokens')->where('token_hash', $hash);
        if (!empty($userId)) {
            $tb->where('user_id', $userId);
        }
        $token = $tb->get()->getRowArray();
        if ($token) {
            $this->db->table('mobile_access_tokens')
                ->where('id', $token['id'])
                ->where('user_id', $token['user_id'])
                ->update(['revoked_at' => $now]);

            if (!empty($token['refresh_token_id'])) {
                $rb = $this->db->table('mobile_refresh_tokens')
                    ->where('id', $token['refresh_token_id'])
                    ->where('user_id', $token['user_id']);
                if (!empty($companyId)) {
                    $rb->where('company_id', $companyId);
                }
                $rb->update(['revoked_at' => $now]);
            }
        }

        return ['ok' => true, 'status' => 200, 'message' => 'Logged out successfully.'];
    }

    public function logoutAll(
        string $userId,
        ?string $companyId = null,
        ?string $ip = null,
        ?string $userAgent = null
    ): array {
        $now = date('Y-m-d H:i:s');

        // Explicit transaction for atomic revocation across all token tables and sessions
        $this->db->transStart();

        // 1. Revoke all active access tokens for this user
        if ($this->db->tableExists('mobile_access_tokens')) {
            $this->db->table('mobile_access_tokens')
                ->where('user_id', $userId)
                ->where('revoked_at IS NULL')
                ->update(['revoked_at' => $now]);
        }

        // 2. Revoke all active refresh tokens for this user
        if ($this->db->tableExists('mobile_refresh_tokens')) {
            $rtBuilder = $this->db->table('mobile_refresh_tokens')
                ->where('user_id', $userId)
                ->where('revoked_at IS NULL');
            if (!empty($companyId)) {
                $rtBuilder->where('company_id', $companyId);
            }
            $rtBuilder->update(['revoked_at' => $now]);
        }

        // 3. Purge web sessions
        $this->destroyUserWebSessions($userId);

        $this->db->transComplete();

        // 4. Audit log without exposing tokens
        $this->auditLogoutAll($userId, $ip, $userAgent);

        return [
            'ok'      => true,
            'success' => true,
            'status'  => 200,
            'message' => 'Logged out from all devices successfully.',
            'data'    => (object)[],
        ];
    }

    public function authenticate(string $accessToken): array
    {
        $accessToken = trim($accessToken);
        if ($accessToken === '') {
            return ['ok' => false, 'status' => 401, 'message' => 'Missing access token.'];
        }

        $hash = hash('sha256', $accessToken);
        $record = $this->db->table('mobile_access_tokens')
            ->where('token_hash', $hash)
            ->where('revoked_at IS NULL')
            ->get()->getRowArray();

        if (!$record) {
            return ['ok' => false, 'status' => 401, 'message' => 'Invalid or revoked token.'];
        }

        if (strtotime($record['expires_at']) < time()) {
            return ['ok' => false, 'status' => 401, 'message' => 'Access token expired.'];
        }

        // Validate live user, company, and employee status
        $contextCheck = $this->validateLiveAccountContext($record['user_id'], null, null);
        if (!$contextCheck['ok']) {
            $now = date('Y-m-d H:i:s');

            // Immediately revoke this access token
            $this->db->table('mobile_access_tokens')
                ->where('id', $record['id'])
                ->update(['revoked_at' => $now]);

            // If tied to a refresh token family, revoke the entire token family
            if (!empty($record['refresh_token_id'])) {
                $rt = $this->db->table('mobile_refresh_tokens')
                    ->where('id', $record['refresh_token_id'])
                    ->get()->getRowArray();
                if ($rt) {
                    $this->revokeTokenFamily($rt['family_id'], $record['user_id'], $rt['company_id']);
                }
            }

            // Revoke any other access tokens on this device
            $this->db->table('mobile_access_tokens')
                ->where('device_id', $record['device_id'])
                ->where('user_id', $record['user_id'])
                ->where('revoked_at IS NULL')
                ->update(['revoked_at' => $now]);

            return [
                'ok'      => false,
                'status'  => $contextCheck['status'] ?? 401,
                'message' => $contextCheck['message'] ?? 'Account is not authorized.',
            ];
        }

        $user = $contextCheck['user'];

        if (!empty($record['refresh_token_id'])) {
            $rt = $this->db->table('mobile_refresh_tokens')
                ->select('company_id')
                ->where('id', $record['refresh_token_id'])
                ->where('user_id', $record['user_id'])
                ->get()->getRowArray();
            if ($rt && !empty($rt['company_id']) && (string)$rt['company_id'] !== (string)($user['company_id'] ?? '')) {
                return ['ok' => false, 'status' => 401, 'message' => 'Token tenant mismatch.'];
            }
        }

        return [
            'ok'     => true,
            'status' => 200,
            'data'   => [
                'user'         => $user,
                'token_record' => $record,
            ],
        ];
    }

    /**
     * Unified live account, tenant, and employee status verification.
     * Enforces identical policy across login, refresh, and token authentication.
     */
    public function validateLiveAccountContext(string $userId, ?string $companyId = null, ?string $employeeId = null): array
    {
        if (!$this->db->tableExists('users')) {
            return ['ok' => false, 'status' => 401, 'message' => 'User table not available.'];
        }

        $user = $this->db->table('users')
            ->select('users.*, roles.code as role_code, roles.status as role_status')
            ->join('roles', 'roles.id = users.role_id', 'left')
            ->where('users.id', $userId)
            ->get()->getRowArray();

        if (!$user) {
            return ['ok' => false, 'status' => 401, 'message' => 'User not active or does not exist.', 'reason' => 'user_not_found'];
        }

        // 1. User status check
        $normUserStatus = \App\Models\UserModel::normalizeStatus($user['status'] ?? null);
        if ($normUserStatus !== \App\Models\UserModel::STATUS_ACTIVE) {
            $rawStatus = $user['status'] ?? 'inactive';
            return [
                'ok'      => false,
                'status'  => 401,
                'message' => "Access Denied: Account is {$rawStatus} or suspended.",
                'reason'  => 'user_inactive',
                'user'    => $user,
            ];
        }

        // 2. User lockout check
        if (AccountLockoutService::isLocked($user)) {
            $rem = AccountLockoutService::getRemainingLockoutSeconds($user);
            return [
                'ok'          => false,
                'status'      => 429,
                'message'     => 'Account is temporarily locked due to consecutive failed attempts.',
                'reason'      => 'user_locked',
                'retry_after' => $rem,
                'user'        => $user,
            ];
        }

        // 3. Organization / Company status check
        $effectiveCompanyId = $user['company_id'] ?? $companyId;
        if (!empty($companyId) && !empty($user['company_id']) && (string)$companyId !== (string)$user['company_id']) {
            return [
                'ok'      => false,
                'status'  => 401,
                'message' => 'Token tenant mismatch.',
                'reason'  => 'company_mismatch',
                'user'    => $user,
            ];
        }

        if (empty($effectiveCompanyId)) {
            return [
                'ok'      => false,
                'status'  => 401,
                'message' => 'User is not assigned to an organization.',
                'reason'  => 'company_missing',
                'user'    => $user,
            ];
        }

        if ($this->db->tableExists('companies')) {
            $compBuilder = $this->db->table('companies')->where('id', $effectiveCompanyId);
            $comp = $compBuilder->get()->getRowArray();

            if (!$comp) {
                return [
                    'ok'      => false,
                    'status'  => 403,
                    'message' => 'Organization not found.',
                    'reason'  => 'company_inactive',
                    'user'    => $user,
                ];
            }

            if (!empty($comp['deleted_at'])) {
                return [
                    'ok'      => false,
                    'status'  => 403,
                    'message' => 'Access Denied: Your organization has been deleted.',
                    'reason'  => 'company_inactive',
                    'user'    => $user,
                    'company' => $comp,
                ];
            }

            $compStatus = strtolower(trim((string)($comp['status'] ?? 'active')));
            if ($compStatus !== 'active') {
                $compName = $comp['name'] ?? 'Organization';
                return [
                    'ok'      => false,
                    'status'  => 403,
                    'message' => "Access Denied: Your organization ('{$compName}') is currently {$compStatus}.",
                    'reason'  => 'company_inactive',
                    'user'    => $user,
                    'company' => $comp,
                ];
            }
        }

        // 4. Employee status check
        $effectiveEmpId = $user['employee_id'] ?? $employeeId;
        if (!empty($effectiveEmpId) && $this->db->tableExists('employees')) {
            $emp = $this->db->table('employees')->where('id', $effectiveEmpId)->get()->getRowArray();
            if (!$emp) {
                return [
                    'ok'      => false,
                    'status'  => 403,
                    'message' => 'Access Denied: Linked employee profile does not exist.',
                    'reason'  => 'employee_inactive',
                    'user'    => $user,
                ];
            }

            if (!empty($emp['company_id']) && (string)$emp['company_id'] !== (string)$effectiveCompanyId) {
                return [
                    'ok'      => false,
                    'status'  => 403,
                    'message' => 'Access Denied: Employee does not belong to the user organization.',
                    'reason'  => 'employee_tenant_mismatch',
                    'user'    => $user,
                ];
            }

            if (!empty($emp['deleted_at'])) {
                return [
                    'ok'      => false,
                    'status'  => 403,
                    'message' => 'Access Denied: Your employee profile has been deleted.',
                    'reason'  => 'employee_inactive',
                    'user'    => $user,
                    'employee' => $emp,
                ];
            }

            $empNormStatus = \App\Models\EmployeeModel::normalizeStatus($emp['status'] ?? \App\Models\EmployeeModel::STATUS_ACTIVE, true);
            if (in_array($empNormStatus, [
                \App\Models\EmployeeModel::STATUS_TERMINATED,
                \App\Models\EmployeeModel::STATUS_RESIGNED,
                \App\Models\EmployeeModel::STATUS_SUSPENDED,
                \App\Models\EmployeeModel::STATUS_INACTIVE,
            ], true)) {
                $statusLabel = \App\Models\EmployeeModel::STATUS_LABELS[$empNormStatus] ?? ucfirst((string)$empNormStatus);
                return [
                    'ok'       => false,
                    'status'   => 403,
                    'message'  => "Access Denied: Your employee profile is marked as '{$statusLabel}'. Access has been revoked.",
                    'reason'   => 'employee_inactive',
                    'user'     => $user,
                    'employee' => $emp,
                ];
            }
        }

        // 5. Assigned role status check
        if (!empty($user['role_status']) && strtolower(trim((string)$user['role_status'])) !== 'active') {
            return [
                'ok'      => false,
                'status'  => 403,
                'message' => 'Access Denied: Assigned role is currently inactive.',
                'reason'  => 'role_inactive',
                'user'    => $user,
            ];
        }

        return [
            'ok'       => true,
            'status'   => 200,
            'user'     => $user,
            'company'  => $comp ?? null,
            'employee' => $emp ?? null,
        ];
    }

    /**
     * Revokes an entire token family (refresh tokens and linked access tokens)
     */
    public function revokeTokenFamily(string $familyId, ?string $userId = null, ?string $companyId = null): int
    {
        $now = date('Y-m-d H:i:s');
        $affected = 0;

        if ($this->db->tableExists('mobile_refresh_tokens')) {
            // Find IDs before update for portable access token revocation
            $rfb = $this->db->table('mobile_refresh_tokens')
                ->select('id')
                ->where('family_id', $familyId)
                ->where('revoked_at IS NULL');
            if (!empty($userId)) {
                $rfb->where('user_id', $userId);
            }
            if (!empty($companyId)) {
                $rfb->where('company_id', $companyId);
            }
            $rfRows = $rfb->get()->getResultArray();
            $rfIds = !empty($rfRows) ? array_column($rfRows, 'id') : [];

            $tb = $this->db->table('mobile_refresh_tokens')
                ->where('family_id', $familyId)
                ->where('revoked_at IS NULL');
            if (!empty($userId)) {
                $tb->where('user_id', $userId);
            }
            if (!empty($companyId)) {
                $tb->where('company_id', $companyId);
            }
            $tb->update(['revoked_at' => $now]);
            $affected += $this->db->affectedRows();

            // Revoke linked access tokens
            if (!empty($rfIds) && $this->db->tableExists('mobile_access_tokens')) {
                $this->db->table('mobile_access_tokens')
                    ->whereIn('refresh_token_id', $rfIds)
                    ->where('revoked_at IS NULL')
                    ->update(['revoked_at' => $now]);
            }
        }

        return $affected;
    }

    /**
     * Revokes all active access and refresh tokens for a user
     */
    public function revokeTokensForUser(string $userId, ?string $reason = null): int
    {
        $now = date('Y-m-d H:i:s');
        $count = 0;

        if ($this->db->tableExists('mobile_access_tokens')) {
            $this->db->table('mobile_access_tokens')
                ->where('user_id', $userId)
                ->where('revoked_at IS NULL')
                ->update(['revoked_at' => $now]);
            $count += $this->db->affectedRows();
        }

        if ($this->db->tableExists('mobile_refresh_tokens')) {
            $this->db->table('mobile_refresh_tokens')
                ->where('user_id', $userId)
                ->where('revoked_at IS NULL')
                ->update(['revoked_at' => $now]);
            $count += $this->db->affectedRows();
        }

        return $count;
    }

    /**
     * Revokes all active tokens for all user accounts linked to an employee
     */
    public function revokeTokensForEmployee(string $employeeId, ?string $companyId = null, ?string $reason = null): int
    {
        if (!$this->db->tableExists('users')) {
            return 0;
        }

        $qb = $this->db->table('users')->select('id')->where('employee_id', $employeeId);
        if (!empty($companyId)) {
            $qb->where('company_id', $companyId);
        }
        $users = $qb->get()->getResultArray();
        $count = 0;
        foreach ($users as $u) {
            $count += $this->revokeTokensForUser((string)$u['id'], $reason);
        }
        return $count;
    }

    /**
     * Revokes all active tokens for all users within a company
     */
    public function revokeTokensForCompany(string $companyId, ?string $reason = null): int
    {
        $now = date('Y-m-d H:i:s');
        $count = 0;

        if ($this->db->tableExists('mobile_refresh_tokens')) {
            $this->db->table('mobile_refresh_tokens')
                ->where('company_id', $companyId)
                ->where('revoked_at IS NULL')
                ->update(['revoked_at' => $now]);
            $count += $this->db->affectedRows();
        }

        if ($this->db->tableExists('mobile_access_tokens') && $this->db->tableExists('users')) {
            $userIds = $this->db->table('users')->select('id')->where('company_id', $companyId)->get()->getResultArray();
            if (!empty($userIds)) {
                $ids = array_column($userIds, 'id');
                $this->db->table('mobile_access_tokens')
                    ->whereIn('user_id', $ids)
                    ->where('revoked_at IS NULL')
                    ->update(['revoked_at' => $now]);
                $count += $this->db->affectedRows();
            }
        }

        return $count;
    }

    private function issueTokenPair(string $userId, ?string $companyId, string $deviceId, ?string $familyId = null, ?string $ip = null): array
    {
        $rawAccessToken  = 'mat_' . bin2hex(random_bytes(32));
        $rawRefreshToken = 'mrt_' . bin2hex(random_bytes(32));

        $accessHash  = hash('sha256', $rawAccessToken);
        $refreshHash = hash('sha256', $rawRefreshToken);

        $now = date('Y-m-d H:i:s');
        $accessExpiry  = date('Y-m-d H:i:s', time() + 3600); // 1 hour
        $refreshExpiry = date('Y-m-d H:i:s', time() + (86400 * 30)); // 30 days

        $refreshTokenId = Uuid::uuid4()->toString();
        $familyId       = $familyId ?: Uuid::uuid4()->toString();

        $this->db->table('mobile_refresh_tokens')->insert([
            'id'          => $refreshTokenId,
            'user_id'     => $userId,
            'company_id'  => $companyId,
            'device_id'   => $deviceId,
            'family_id'   => $familyId,
            'token_hash'  => $refreshHash,
            'expires_at'  => $refreshExpiry,
            'created_ip'  => $ip,
            'created_at'  => $now,
        ]);

        $accessTokenId = Uuid::uuid4()->toString();
        $this->db->table('mobile_access_tokens')->insert([
            'id'               => $accessTokenId,
            'user_id'          => $userId,
            'device_id'        => $deviceId,
            'refresh_token_id' => $refreshTokenId,
            'token_hash'       => $accessHash,
            'expires_at'       => $accessExpiry,
            'created_at'       => $now,
        ]);

        return [
            'access_token'     => $rawAccessToken,
            'refresh_token'    => $rawRefreshToken,
            'expires_in'       => 3600,
            'refresh_token_id' => $refreshTokenId,
        ];
    }

    private function logLogin(?string $userId, ?string $ip, ?string $userAgent, string $status): void
    {
        try {
            $now = date('Y-m-d H:i:s');
            $this->db->table('login_history')->insert([
                'id'           => Uuid::uuid4()->toString(),
                'user_id'      => $userId,
                'ip_address'   => $ip ? substr($ip, 0, 45) : null,
                'user_agent'   => $userAgent ? substr($userAgent, 0, 500) : null,
                'status'       => $status,
                'attempted_at' => $now,
                'login_time'   => $status === 'success' ? $now : null,
                'created_at'   => $now,
            ]);
        } catch (\Throwable $e) {
            // Non-blocking log failure
        }
    }

    public function changePassword(
        string $userId,
        ?string $companyId,
        string $currentPassword,
        string $newPassword,
        string $confirmPassword,
        ?string $currentToken = null,
        ?string $ip = null,
        ?string $userAgent = null
    ): array {
        // Enforce centralized password policy
        $policy = \App\Services\Auth\PasswordPolicyService::forCompany($companyId);
        $policyError = \App\Services\Auth\PasswordPolicyService::validateChangePassword(
            $currentPassword,
            $newPassword,
            $confirmPassword,
            \App\Services\Auth\PasswordPolicyService::DEFAULT_MIN_LENGTH,
            $policy
        );
        if ($policyError !== null) {
            $field = 'new_password';
            if (stripos($policyError, 'current password') !== false) {
                $field = 'current_password';
            } elseif (stripos($policyError, 'confirmation') !== false) {
                $field = 'confirm_password';
            }
            return [
                'ok'      => false,
                'success' => false,
                'status'  => 422,
                'message' => $policyError,
                'errors'  => [$field => $policyError],
                'data'    => (object)[],
            ];
        }

        $qb = $this->db->table('users')->where('id', $userId);
        if (!empty($companyId)) {
            $qb->where('company_id', $companyId);
        }
        $user = $qb->get()->getRowArray();

        if (!$user) {
            return [
                'ok'      => false,
                'success' => false,
                'status'  => 401,
                'message' => 'Unauthorized user context.',
                'errors'  => ['user' => 'Unauthorized user context.'],
                'data'    => (object)[],
            ];
        }

        if (strtolower((string)($user['status'] ?? '')) !== 'active') {
            return [
                'ok'      => false,
                'success' => false,
                'status'  => 401,
                'message' => 'Account is not active.',
                'errors'  => ['user' => 'Account is not active.'],
                'data'    => (object)[],
            ];
        }

        if (!password_verify($currentPassword, (string)($user['password_hash'] ?? ''))) {
            return [
                'ok'      => false,
                'success' => false,
                'status'  => 422,
                'message' => 'Current password does not match.',
                'errors'  => ['current_password' => 'Current password does not match.'],
                'data'    => (object)[],
            ];
        }

        $now = date('Y-m-d H:i:s');
        $this->db->table('users')
            ->where('id', $user['id'])
            ->where('company_id', $user['company_id'])
            ->update([
                'password_hash'        => password_hash($newPassword, PASSWORD_BCRYPT),
                'failed_logins'        => 0,
                'locked_until'         => null,
                'must_change_password' => 0,
                'updated_at'           => $now,
            ]);

        try {
            if (\App\Services\Mobile\MobileAuthContext::get('id') === $user['id'] || \App\Services\Mobile\MobileAuthContext::get('user_id') === $user['id']) {
                \App\Services\Mobile\MobileAuthContext::set('must_change_password', 0);
            }
        } catch (\Throwable $e) {
            // non-blocking
        }

        // Invalidate OTHER active tokens and sessions per security policy
        $this->invalidateOtherUserSessionsAndTokens($user['id'], $currentToken, $now);

        // Audit log without sensitive passwords or tokens
        $this->auditPasswordChange($user['id'], $ip, $userAgent);

        return [
            'ok'      => true,
            'success' => true,
            'status'  => 200,
            'message' => 'Password updated successfully.',
            'data'    => (object)[],
        ];
    }

    private function invalidateOtherUserSessionsAndTokens(string $userId, ?string $currentToken, string $now): void
    {
        $currentTokenHash = !empty($currentToken) ? hash('sha256', trim($currentToken)) : null;
        $currentRefreshId = null;

        if ($currentTokenHash && $this->db->tableExists('mobile_access_tokens')) {
            $currTokenRow = $this->db->table('mobile_access_tokens')
                ->where('token_hash', $currentTokenHash)
                ->get()->getRowArray();
            $currentRefreshId = $currTokenRow['refresh_token_id'] ?? null;
        }

        // Revoke other mobile access tokens
        if ($this->db->tableExists('mobile_access_tokens')) {
            $at = $this->db->table('mobile_access_tokens')
                ->where('user_id', $userId)
                ->where('revoked_at IS NULL');
            if ($currentTokenHash) {
                $at->where('token_hash !=', $currentTokenHash);
            }
            $at->update(['revoked_at' => $now]);
        }

        // Revoke other mobile refresh tokens
        if ($this->db->tableExists('mobile_refresh_tokens')) {
            $rt = $this->db->table('mobile_refresh_tokens')
                ->where('user_id', $userId)
                ->where('revoked_at IS NULL');
            if ($currentRefreshId) {
                $rt->where('id !=', $currentRefreshId);
            }
            $rt->update(['revoked_at' => $now]);
        }

        // Purge web sessions
        $this->destroyUserWebSessions($userId);
    }

    private function destroyUserWebSessions(string $userId): void
    {
        // Purge database web sessions
        try {
            if ($this->db->tableExists('ci_sessions')) {
                $this->db->table('ci_sessions')->like('data', $userId)->delete();
            }
        } catch (\Throwable $e) {
            // non-blocking
        }

        // Purge file-based web sessions
        try {
            $sessionConfig = config('Session');
            $savePath = $sessionConfig->savePath ?? (WRITEPATH . 'session');
            if (is_dir($savePath)) {
                $files = glob(rtrim($savePath, '/\\') . '/*');
                if ($files) {
                    foreach ($files as $file) {
                        if (!is_file($file)) {
                            continue;
                        }
                        $content = @file_get_contents($file);
                        if ($content !== false && strpos($content, $userId) !== false) {
                            @unlink($file);
                        }
                    }
                }
            }
        } catch (\Throwable $e) {
            // non-blocking
        }
    }

    private function auditLogoutAll(string $userId, ?string $ip, ?string $userAgent): void
    {
        try {
            if (class_exists(\App\Services\AuditService::class)) {
                (new \App\Services\AuditService())->log(
                    $userId,
                    'auth',
                    'logout.all',
                    $userId,
                    null,
                    ['action' => 'User logged out from all devices and tokens revoked'],
                    $ip,
                    $userAgent,
                    'via Mobile App'
                );
            }
        } catch (\Throwable $e) {
            // Non-blocking log failure
        }
    }

    private function auditPasswordChange(string $userId, ?string $ip, ?string $userAgent): void
    {
        try {
            if (class_exists(\App\Services\AuditService::class)) {
                (new \App\Services\AuditService())->log(
                    $userId,
                    'auth',
                    'password.changed',
                    $userId,
                    null,
                    ['action' => 'Password changed via mobile API and must_change_password cleared'],
                    $ip,
                    $userAgent,
                    'via Mobile App'
                );
            }
        } catch (\Throwable $e) {
            // Non-blocking log failure
        }
    }

    private function auditLockout(string $userId, string $identifier, int $failedCount, ?string $ip, ?string $userAgent): void
    {
        try {
            if (class_exists(\App\Services\AuditService::class)) {
                (new \App\Services\AuditService())->log(
                    $userId,
                    'security',
                    'Account Locked',
                    $userId,
                    null,
                    [
                        'username'     => $identifier,
                        'failed_count' => $failedCount,
                        'message'      => 'Account automatically locked for 15 minutes due to 5 consecutive failed login attempts',
                    ],
                    $ip,
                    $userAgent,
                    'via Mobile App'
                );
            }
        } catch (\Throwable $e) {
            // Non-blocking log failure
        }
    }
}

