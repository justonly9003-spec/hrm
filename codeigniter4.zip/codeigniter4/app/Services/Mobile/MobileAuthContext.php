<?php

namespace App\Services\Mobile;

/**
 * MobileAuthContext
 *
 * Lightweight, in-memory request-scoped context for authenticated mobile requests.
 * Eliminates the need to start or write PHP disk/redis sessions for stateless Bearer API calls,
 * preventing orphaned session files.
 */
class MobileAuthContext
{
    private static ?array $user = null;

    public static function setUser(?array $user): void
    {
        self::$user = $user;
    }

    public static function getUser(): ?array
    {
        return self::$user;
    }

    public static function get(string $key, $default = null)
    {
        if (self::$user === null) {
            return $default;
        }

        // Support direct key or alias
        if (array_key_exists($key, self::$user)) {
            return self::$user[$key];
        }

        if ($key === 'user_id' && isset(self::$user['id'])) {
            return self::$user['id'];
        }

        return $default;
    }

    public static function reset(): void
    {
        self::$user = null;
    }
}
