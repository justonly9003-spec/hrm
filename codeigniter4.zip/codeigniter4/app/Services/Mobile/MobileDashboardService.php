<?php

namespace App\Services\Mobile;

use App\Models\EmployeeModel;
use App\Models\LeaveModel;
use App\Models\NoticeModel;
use App\Services\LeaveService;
use App\Services\PermissionService;
use App\Services\Rules\RuleNotConfiguredException;
use CodeIgniter\Database\BaseConnection;
use Config\Database;

/**
 * MobileDashboardService
 *
 * Provides real-time aggregated dashboard data for the authenticated employee only.
 * Reuses existing services (LeaveService, Attendance, etc.) and strictly scopes
 * every query by tenant company_id and authenticated employee_id / user_id.
 * Zero demo, hardcoded or cross-tenant data.
 */
class MobileDashboardService
{
    protected BaseConnection $db;
    protected PermissionService $permissionService;

    public function __construct(?BaseConnection $db = null)
    {
        $this->db = $db ?? Database::connect();
        $this->permissionService = new PermissionService();
    }

    /**
     * Retrieve complete dashboard payload for the authenticated employee context.
     */
    public function getDashboard(string $userId, string $companyId, string $employeeId): array
    {
        if ($userId === '' || $companyId === '' || $employeeId === '') {
            return [
                'ok'      => false,
                'status'  => 404,
                'message' => 'Employee profile not found.',
                'data'    => (object)[],
            ];
        }

        // 1. Fetch employee profile and organizational metadata
        $employee = $this->getEmployeeProfile($employeeId, $companyId);
        if (!$employee) {
            return [
                'ok'      => false,
                'status'  => 404,
                'message' => 'Employee profile not found.',
                'data'    => (object)[],
            ];
        }

        // 2. Company master data
        $company = $this->getCompanyInfo($companyId);

        // 3. Today's attendance data
        $today = date('Y-m-d');
        $attendance = $this->getTodayAttendance($employeeId, $companyId, $userId, $today);

        // 4. Leave balances and recent applications
        $leaveData = $this->getLeaveOverview($employeeId, $companyId, $userId, (int)date('Y', strtotime($today)));

        // 5. Latest finalized payslip (read-only summary, no bank account details)
        $latestPayslip = $this->getLatestFinalizedPayslip($employeeId, $companyId);

        // 6. Notifications (unread count and recent list)
        $notifications = $this->getNotificationsSummary($userId, $companyId);

        // 7. Active company announcements / notices
        $announcements = $this->getActiveAnnouncements($companyId);

        // 8. High-level KPI summary cards for mobile dashboard header
        $summary = [
            'attendance_status'          => $attendance['status'] ?? 'Not Marked',
            'is_checked_in'              => (bool)($attendance['checked_in'] ?? false),
            'total_available_leaves'     => (float)($leaveData['total_available_balance'] ?? 0.0),
            'pending_leave_requests'     => (int)($leaveData['pending_applications_count'] ?? 0),
            'unread_notifications_count' => (int)($notifications['unread_count'] ?? 0),
        ];

        return [
            'ok'      => true,
            'status'  => 200,
            'message' => 'Dashboard data retrieved successfully.',
            'data'    => [
                'employee'         => $employee,
                'company'          => $company,
                'summary'          => $summary,
                'attendance_today' => $attendance,
                'leave_summary'    => $leaveData,
                'latest_payslip'   => $latestPayslip,
                'notifications'    => $notifications,
                'announcements'    => $announcements,
            ],
        ];
    }

    /**
     * Retrieve employee demographic and organizational metadata.
     * Excludes sensitive salary and banking information.
     */
    private function getEmployeeProfile(string $employeeId, string $companyId): ?array
    {
        if (!$this->db->tableExists('employees')) {
            return null;
        }

        $fields = $this->db->getFieldNames('employees');
        $allowedFields = ['employee_code', 'first_name', 'last_name', 'email', 'phone', 'joining_date', 'status', 'photo'];
        $cols = array_values(array_intersect($allowedFields, $fields));
        $select = array_map(static fn($c) => "employees.{$c}", $cols);

        $builder = $this->db->table('employees')
            ->select(array_merge(['employees.id'], $select, [
                'departments.name AS department',
                'designations.name AS designation',
                'branches.name AS branch',
            ]))
            ->join('departments', 'departments.id = employees.department_id', 'left')
            ->join('designations', 'designations.id = employees.designation_id', 'left')
            ->join('branches', 'branches.id = employees.branch_id', 'left')
            ->where('employees.id', $employeeId)
            ->where('employees.company_id', $companyId);

        $row = $builder->get()->getRowArray();
        if (!$row) {
            return null;
        }

        $firstName = trim((string)($row['first_name'] ?? ''));
        $lastName  = trim((string)($row['last_name'] ?? ''));
        $row['full_name'] = trim("{$firstName} {$lastName}");

        return $row;
    }

    /**
     * Retrieve basic company metadata.
     */
    private function getCompanyInfo(string $companyId): array
    {
        if (!$this->db->tableExists('companies')) {
            return ['id' => $companyId, 'name' => '', 'code' => ''];
        }

        $row = $this->db->table('companies')
            ->select('id, name, code')
            ->where('id', $companyId)
            ->get()->getRowArray();

        return $row ?: ['id' => $companyId, 'name' => '', 'code' => ''];
    }

    /**
     * Retrieve today's attendance status and logs for the authenticated employee.
     */
    private function getTodayAttendance(string $employeeId, string $companyId, string $userId, string $today): array
    {
        $canAttendance = $this->canAccess($userId, ['attendance.view', 'attendance.clock']);
        if (!$canAttendance) {
            return [
                'date'          => $today,
                'is_authorized' => false,
                'checked_in'    => false,
                'checked_out'   => false,
                'status'        => 'Unauthorized',
            ];
        }

        if (!$this->db->tableExists('attendance_logs')) {
            return [
                'date'          => $today,
                'is_authorized' => true,
                'checked_in'    => false,
                'checked_out'   => false,
                'check_in_time' => null,
                'check_out_time'=> null,
                'status'        => 'Not Marked',
                'late_minutes'  => 0,
                'working_hours' => 0.0,
            ];
        }

        $fields = $this->db->getFieldNames('attendance_logs');
        $wanted = ['date', 'clock_in', 'clock_out', 'in_time', 'out_time', 'check_in', 'check_out', 'status', 'late_minutes', 'working_hours', 'total_working_hours', 'remarks', 'notes'];
        $cols = array_values(array_intersect($wanted, $fields));

        $builder = $this->db->table('attendance_logs')
            ->where('employee_id', $employeeId)
            ->where('company_id', $companyId)
            ->where('date', $today);

        if (!empty($cols)) {
            $builder->select(implode(',', $cols));
        }

        $row = $builder->get()->getRowArray();

        $inTime  = $row['in_time'] ?? ($row['check_in'] ?? null);
        $outTime = $row['out_time'] ?? ($row['check_out'] ?? null);

        if (!$inTime && !empty($row['clock_in'])) {
            $inTime = date('H:i:s', strtotime($row['clock_in']));
        }
        if (!$outTime && !empty($row['clock_out'])) {
            $outTime = date('H:i:s', strtotime($row['clock_out']));
        }

        $checkedIn  = !empty($inTime) || !empty($row['clock_in'] ?? null);
        $checkedOut = !empty($outTime) || !empty($row['clock_out'] ?? null);

        $status = $row['status'] ?? ($checkedIn ? 'Present' : 'Not Marked');
        $lateMinutes = (int)($row['late_minutes'] ?? 0);
        $workingHours = (float)($row['working_hours'] ?? ($row['total_working_hours'] ?? 0.0));

        return [
            'date'          => $today,
            'is_authorized' => true,
            'checked_in'    => $checkedIn,
            'checked_out'   => $checkedOut,
            'check_in_time' => $inTime,
            'check_out_time'=> $outTime,
            'status'        => $status,
            'late_minutes'  => $lateMinutes,
            'working_hours' => $workingHours,
        ];
    }

    /**
     * Retrieve leave balances and recent leave applications.
     */
    private function getLeaveOverview(string $employeeId, string $companyId, string $userId, int $year): array
    {
        $canLeave = $this->canAccess($userId, ['leave.view', 'leave.create', 'leaves.view']);
        if (!$canLeave) {
            return [
                'is_authorized'              => false,
                'year'                       => $year,
                'total_available_balance'    => 0.0,
                'pending_applications_count' => 0,
                'balances'                   => [],
                'recent_applications'        => [],
            ];
        }

        $balances = [];
        $totalAvailable = 0.0;

        // 1. Fetch live balances via LeaveService or fallback to leave_balances table
        try {
            $leaveService = new LeaveService();
            $rawBalances = $leaveService->getEmployeeAllBalances($employeeId, $year, $companyId, null, true);

            foreach ($rawBalances as $bal) {
                $avail = (float)($bal['balance'] ?? ($bal['available_balance'] ?? 0.0));
                $totalAvailable += $avail;
                $balances[] = [
                    'leave_type_id'   => $bal['leave_type_id'] ?? null,
                    'leave_type_name' => $bal['leave_type_name'] ?? ($bal['name'] ?? 'Leave'),
                    'leave_type_code' => $bal['leave_type_code'] ?? ($bal['code'] ?? 'LV'),
                    'leave_is_paid'   => !empty($bal['leave_is_paid'] ?? $bal['is_paid']),
                    'entitled_days'   => (float)($bal['entitled_days'] ?? ($bal['total_entitlement'] ?? 0.0)),
                    'used_days'       => (float)($bal['used_days'] ?? ($bal['approved_leave_days'] ?? 0.0)),
                    'pending_days'    => (float)($bal['pending_days'] ?? ($bal['pending_leave_days'] ?? 0.0)),
                    'balance'         => $avail,
                ];
            }
        } catch (\Throwable $e) {
            // Fallback directly to leave_balances table if rules are not initialized or table format is standard
            if ($this->db->tableExists('leave_balances')) {
                try {
                    $dbBalances = $this->db->table('leave_balances')
                        ->select('leave_balances.*, leave_types.name as leave_type_name, leave_types.code as leave_type_code, leave_types.is_paid as leave_is_paid')
                        ->join('leave_types', 'leave_types.id = leave_balances.leave_type_id', 'left')
                        ->where('leave_balances.employee_id', $employeeId)
                        ->where('leave_balances.year', $year)
                        ->get()->getResultArray();

                    foreach ($dbBalances as $row) {
                        $avail = (float)($row['balance'] ?? 0.0);
                        $totalAvailable += $avail;
                        $balances[] = [
                            'leave_type_id'   => $row['leave_type_id'] ?? null,
                            'leave_type_name' => $row['leave_type_name'] ?? 'Leave',
                            'leave_type_code' => $row['leave_type_code'] ?? 'LV',
                            'leave_is_paid'   => !empty($row['leave_is_paid']),
                            'entitled_days'   => (float)($row['allocated_days'] ?? ($row['entitled_days'] ?? 0.0)),
                            'used_days'       => (float)($row['used_days'] ?? 0.0),
                            'pending_days'    => (float)($row['pending_days'] ?? 0.0),
                            'balance'         => $avail,
                        ];
                    }
                } catch (\Throwable $ex) {
                    $balances = [];
                }
            }
        }

        // 2. Fetch pending leave applications count
        $pendingCount = 0;
        $recentApplications = [];

        if ($this->db->tableExists('leave_applications')) {
            try {
                $appBuilder = $this->db->table('leave_applications')
                    ->where('employee_id', $employeeId)
                    ->groupStart()
                        ->where('status', 'pending')
                        ->orWhere('status', 'Pending')
                    ->groupEnd();

                if ($this->db->fieldExists('company_id', 'leave_applications')) {
                    $appBuilder->where('company_id', $companyId);
                }
                $pendingCount = $appBuilder->countAllResults();

                // 3. Fetch recent applications (limit 5)
                $appCols = $this->db->getFieldNames('leave_applications');
                $wantedCols = ['id', 'leave_type_id', 'from_date', 'to_date', 'start_date', 'end_date', 'total_days', 'reason', 'status', 'created_at', 'applied_at'];
                $selectCols = array_values(array_intersect($wantedCols, $appCols));

                $recentBuilder = $this->db->table('leave_applications')
                    ->where('employee_id', $employeeId);

                if ($this->db->fieldExists('company_id', 'leave_applications')) {
                    $recentBuilder->where('company_id', $companyId);
                }

                if (!empty($selectCols)) {
                    $recentBuilder->select(implode(',', $selectCols));
                }

                if (in_array('created_at', $appCols, true)) {
                    $recentBuilder->orderBy('created_at', 'DESC');
                } elseif (in_array('id', $appCols, true)) {
                    $recentBuilder->orderBy('id', 'DESC');
                }

                $recentApplications = $recentBuilder->limit(5)->get()->getResultArray();
            } catch (\Throwable $e) {
                $pendingCount = 0;
                $recentApplications = [];
            }
        }

        return [
            'is_authorized'              => true,
            'year'                       => $year,
            'total_available_balance'    => $totalAvailable,
            'pending_applications_count' => $pendingCount,
            'balances'                   => $balances,
            'recent_applications'        => $recentApplications,
        ];
    }

    /**
     * Retrieve latest finalized/published payslip for the authenticated employee.
     * Only finalized/locked/approved payslips are visible to the employee.
     */
    private function getLatestFinalizedPayslip(string $employeeId, string $companyId): ?array
    {
        if (!$this->db->tableExists('payrolls') || !$this->db->tableExists('payroll_items')) {
            return null;
        }

        try {
            $itemCols = $this->db->getFieldNames('payroll_items');
            $wantedCols = ['basic_salary', 'gross_salary', 'total_deductions', 'net_salary', 'payment_status'];
            $existingCols = array_values(array_intersect($wantedCols, $itemCols));
            $selectCols = array_map(static fn($c) => "payroll_items.{$c}", $existingCols);

            $builder = $this->db->table('payroll_items')
                ->select(array_merge(['payroll_items.id', 'payrolls.payroll_month'], $selectCols))
                ->join('payrolls', 'payrolls.id = payroll_items.payroll_id')
                ->where('payroll_items.employee_id', $employeeId)
                ->where('payrolls.company_id', $companyId);

            if ($this->db->fieldExists('company_id', 'payroll_items')) {
                $builder->where('payroll_items.company_id', $companyId);
            }

            // Publication status check: must be locked or approved/finalized/paid
            $builder->groupStart()
                ->where('payrolls.is_locked', 1)
                ->orWhere("LOWER(TRIM(payrolls.status)) IN ('approved','finalized','locked','paid')", null, false);

            if ($this->db->fieldExists('payment_status', 'payroll_items')) {
                $builder->orWhere("LOWER(TRIM(payroll_items.payment_status)) IN ('approved','paid')", null, false);
            }
            $builder->groupEnd();

            $builder->orderBy('payrolls.payroll_month', 'DESC');
            $row = $builder->get()->getRowArray();

            if (!$row) {
                return null;
            }

            return [
                'id'               => $row['id'],
                'payroll_month'    => $row['payroll_month'],
                'gross_salary'     => (float)($row['gross_salary'] ?? 0.0),
                'total_deductions' => (float)($row['total_deductions'] ?? 0.0),
                'net_salary'       => (float)($row['net_salary'] ?? 0.0),
                'payment_status'   => $row['payment_status'] ?? 'Finalized',
                'pdf_url'          => base_url('payroll/payslip/' . rawurlencode((string)$row['id'])),
            ];
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Retrieve notifications unread count and recent notifications list.
     */
    private function getNotificationsSummary(string $userId, string $companyId): array
    {
        if (!$this->db->tableExists('notifications')) {
            return ['unread_count' => 0, 'recent' => []];
        }

        try {
            $fields = $this->db->getFieldNames('notifications');

            // Unread count
            $countBuilder = $this->db->table('notifications')
                ->where('user_id', $userId)
                ->where('is_read', 0);

            if (in_array('company_id', $fields, true)) {
                $countBuilder->where('company_id', $companyId);
            }
            $unreadCount = $countBuilder->countAllResults();

            // Recent 5 notifications
            $wanted = ['id', 'title', 'message', 'type', 'priority', 'related_module', 'icon', 'link', 'is_read', 'created_at'];
            $cols = array_values(array_intersect($wanted, $fields));

            $recentBuilder = $this->db->table('notifications')
                ->where('user_id', $userId);

            if (in_array('company_id', $fields, true)) {
                $recentBuilder->where('company_id', $companyId);
            }

            if (!empty($cols)) {
                $recentBuilder->select(implode(',', $cols));
            }

            if (in_array('created_at', $fields, true)) {
                $recentBuilder->orderBy('created_at', 'DESC');
            } elseif (in_array('id', $fields, true)) {
                $recentBuilder->orderBy('id', 'DESC');
            }

            $recent = $recentBuilder->limit(5)->get()->getResultArray();

            return [
                'unread_count' => $unreadCount,
                'recent'       => $recent,
            ];
        } catch (\Throwable $e) {
            return ['unread_count' => 0, 'recent' => []];
        }
    }

    /**
     * Retrieve active announcements / notices for the company.
     */
    private function getActiveAnnouncements(string $companyId): array
    {
        if (!$this->db->tableExists('notices')) {
            return [];
        }

        try {
            $fields = $this->db->getFieldNames('notices');
            $builder = $this->db->table('notices');

            if (in_array('company_id', $fields, true)) {
                $builder->where('company_id', $companyId);
            }

            if (in_array('status', $fields, true)) {
                $builder->groupStart()
                    ->where('status', 'active')
                    ->orWhere('status', 'published')
                    ->orWhere('status', 'Active')
                    ->orWhere('status', 'Published')
                ->groupEnd();
            }

            $today = date('Y-m-d');
            if (in_array('expiry_date', $fields, true)) {
                $builder->groupStart()
                    ->where('expiry_date >=', $today)
                    ->orWhere('expiry_date IS NULL')
                ->groupEnd();
            } elseif (in_array('expires_at', $fields, true)) {
                $builder->groupStart()
                    ->where('expires_at >=', date('Y-m-d H:i:s'))
                    ->orWhere('expires_at IS NULL')
                ->groupEnd();
            }

            $wanted = ['id', 'title', 'content', 'description', 'type', 'category', 'published_date', 'created_at'];
            $cols = array_values(array_intersect($wanted, $fields));
            if (!empty($cols)) {
                $builder->select(implode(',', $cols));
            }

            if (in_array('published_date', $fields, true)) {
                $builder->orderBy('published_date', 'DESC');
            } elseif (in_array('created_at', $fields, true)) {
                $builder->orderBy('created_at', 'DESC');
            }

            return $builder->limit(3)->get()->getResultArray();
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * Check if user holds at least one of the specified permissions.
     */
    private function canAccess(string $userId, array $permissions): bool
    {
        foreach ($permissions as $p) {
            try {
                $res = $this->permissionService->can($p, null, $userId);
                $allowed = ($res instanceof \App\Services\PermissionDecision) ? $res->isAllowed() : (bool)$res;
                if ($allowed) {
                    return true;
                }
            } catch (\Throwable $e) {
                // Ignore and check next
            }
        }
        return false;
    }
}
