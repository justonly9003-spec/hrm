<?php

namespace App\Services;

use App\Services\Overtime\OvertimeCalculationService;

/**
 * OvertimeService
 *
 * Primary service facade for overtime policy calculation, validation, approval,
 * and settlement integration with single rule store (RuleResolver).
 */
class OvertimeService extends OvertimeCalculationService
{
    // Inherits all authoritative calculation, policy resolution, approval, and payroll methods
}
