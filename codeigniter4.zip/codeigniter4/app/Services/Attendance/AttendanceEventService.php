<?php

namespace App\Services\Attendance;

use App\Services\AttendanceEventService as BaseAttendanceEventService;

/**
 * Sub-namespace alias for App\Services\AttendanceEventService
 */
class AttendanceEventService extends BaseAttendanceEventService
{
}
