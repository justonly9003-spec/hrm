<?php

namespace App\Services\Pf;

use App\Models\EmployeeModel;
use App\Models\EmployeePfEligibilityPeriodModel;
use App\Models\ProvidentFundLedgerModel;
use App\Services\AuditService;
use Config\Database;
use InvalidArgumentException;
use RuntimeException;

class PfEligibilityService
{
    protected $db;
    protected EmployeePfEligibilityPeriodModel $periodModel;
    protected EmployeeModel $employeeModel;
    protected ProvidentFundLedgerModel $ledgerModel;
    protected AuditService $auditService;

    public function __construct(
        ?EmployeePfEligibilityPeriodModel $periodModel = null,
        ?EmployeeModel $employeeModel = null,
        ?ProvidentFundLedgerModel $ledgerModel = null,
        ?AuditService $auditService = null
    ) {
        $this->db = Database::connect();
        $this->periodModel = $periodModel ?? new EmployeePfEligibilityPeriodModel();
        $this->employeeModel = $employeeModel ?? new EmployeeModel();
        $this->ledgerModel = $ledgerModel ?? new ProvidentFundLedgerModel();
        $this->auditService = $auditService ?? new AuditService();
    }

    /**
     * Atomically changes and records an employee's Provident Fund eligibility period.
     * Enforces single source of truth, timeline non-overlap, payroll lock protection, and tenant validation.
     *
     * @param string $companyId Organization ID
     * @param string $employeeId Target Employee ID
     * @param string $status 'Eligible', 'Not Eligible', or 'Exempt'
     * @param string $effectiveFrom Y-m-d start date
     * @param string|null $effectiveTo Y-m-d end date or null if ongoing
     * @param string|null $reason Mandatory if status != 'Eligible'
     * @param string|null $memberId UAN or PF Member identifier
     * @param string|null $actorId User performing the modification
     * @param string|null $notes Additional administrative or audit notes
     * @return array The newly created period record
     *
     * @throws InvalidArgumentException On validation or parameter failure
     * @throws RuntimeException On authorization, tenant scope, or payroll lock violation
     */
    public function changeEligibility(
        string $companyId,
        string $employeeId,
        string $status,
        string $effectiveFrom,
        ?string $effectiveTo = null,
        ?string $reason = null,
        ?string $memberId = null,
        ?string $actorId = null,
        ?string $notes = null
    ): array {
        // 1. Status normalization and validation
        $status = trim($status);
        if ($status === 'Enrolled') {
            $status = 'Eligible';
        } elseif ($status === 'Ineligible') {
            $status = 'Not Eligible';
        }

        if (!in_array($status, ['Eligible', 'Not Eligible', 'Exempt'], true)) {
            throw new InvalidArgumentException("Invalid PF eligibility status '{$status}'. Allowed values: Eligible, Not Eligible, Exempt.");
        }

        // 2. Date format and range validation
        $effectiveFrom = trim($effectiveFrom);
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $effectiveFrom)) {
            throw new InvalidArgumentException("Effective from date must be in YYYY-MM-DD format.");
        }

        if ($effectiveTo !== null && trim($effectiveTo) !== '') {
            $effectiveTo = trim($effectiveTo);
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $effectiveTo)) {
                throw new InvalidArgumentException("Effective to date must be in YYYY-MM-DD format.");
            }
            if ($effectiveTo < $effectiveFrom) {
                throw new InvalidArgumentException("Effective to date ({$effectiveTo}) cannot be earlier than effective from date ({$effectiveFrom}).");
            }
        } else {
            $effectiveTo = null;
        }

        // 3. Reason requirement for non-eligible statuses
        $reason = $reason !== null ? trim($reason) : null;
        if ($reason === '') {
            $reason = null;
        }
        if ($status !== 'Eligible' && empty($reason)) {
            throw new InvalidArgumentException("A valid justification reason is mandatory when setting PF eligibility to '{$status}'.");
        }

        // 4. Employee & tenant validation
        $emp = $this->employeeModel->find($employeeId);
        if (!$emp) {
            throw new InvalidArgumentException("Employee with ID '{$employeeId}' not found.");
        }

        $empCompanyId = (string)($emp['company_id'] ?? '');
        if ($empCompanyId !== '' && $empCompanyId !== $companyId) {
            throw new RuntimeException("403 Forbidden: Target employee belongs to another organization.");
        }

        // 5. Software App Admin / Super Admin exclusion
        $role = $emp['role'] ?? '';
        $code = $emp['employee_code'] ?? '';
        if ($role === 'Software App Admin' || $code === 'SUPER_ADMIN') {
            throw new InvalidArgumentException("Software App Admin / Super Admin cannot participate in Provident Fund.");
        }

        // 6. Locked payroll month protection
        $targetMonth = substr($effectiveFrom, 0, 7);
        $lockedPayroll = $this->db->table('payrolls')
            ->where('company_id', $companyId)
            ->where('payroll_month', $targetMonth)
            ->groupStart()
                ->where('is_locked', 1)
                ->orWhereIn('status', ['Locked', 'Approved', 'Paid'])
            ->groupEnd()
            ->get()
            ->getRowArray();

        if ($lockedPayroll) {
            throw new RuntimeException("Cannot modify PF eligibility in {$targetMonth}: payroll for this month is already generated and locked.");
        }

        // Determine member ID
        $memberId = $memberId !== null ? trim($memberId) : null;
        if ($memberId === '') {
            $memberId = null;
        }
        if (empty($memberId)) {
            $memberId = $emp['pf_member_id'] ?? null;
        }
        if ($status === 'Eligible' && empty($memberId)) {
            $memberId = 'PF-' . ($emp['employee_code'] ?? $emp['id']);
        }

        // 7. Atomic DB Transaction with Row Locking
        $this->db->transBegin();

        try {
            // Lock existing rows for this employee (pessimistic concurrency control)
            if ($this->db->tableExists('employee_pf_eligibility_periods')) {
                $this->db->query("SELECT id FROM employee_pf_eligibility_periods WHERE employee_id = ? FOR UPDATE", [$employeeId]);
            }

            // Find previous active/covering period before changes for audit logging
            $previousPeriod = $this->getEligibilityOn($employeeId, $effectiveFrom);

            // Fetch all existing periods for timeline trimming / splitting
            $existingPeriods = $this->periodModel->where('employee_id', $employeeId)
                ->orderBy('effective_from', 'ASC')
                ->findAll();

            $newFrom = $effectiveFrom;
            $newTo = $effectiveTo;

            foreach ($existingPeriods as $e) {
                $eId = $e['id'];
                $eFrom = $e['effective_from'];
                $eTo = $e['effective_to'];

                if ($newTo === null) {
                    // Open-ended new period
                    if ($eFrom >= $newFrom) {
                        // Completely superseded by new period
                        $this->periodModel->delete($eId);
                    } elseif ($eTo === null || $eTo >= $newFrom) {
                        // Starts before new period and extends into/past it: close at newFrom - 1 day
                        $adjustedTo = date('Y-m-d', strtotime($newFrom . ' -1 day'));
                        $this->periodModel->update($eId, [
                            'effective_to' => $adjustedTo,
                            'updated_at'   => date('Y-m-d H:i:s'),
                        ]);
                    }
                } else {
                    // Finite new period [newFrom, newTo]
                    if ($eFrom >= $newFrom && ($eTo !== null && $eTo <= $newTo)) {
                        // Case A: Existing is completely covered inside the new finite period
                        $this->periodModel->delete($eId);
                    } elseif ($eFrom < $newFrom && ($eTo === null || $eTo > $newTo)) {
                        // Case B: New period is strictly inside existing period -> split into two
                        $firstPartTo = date('Y-m-d', strtotime($newFrom . ' -1 day'));
                        $this->periodModel->update($eId, [
                            'effective_to' => $firstPartTo,
                            'updated_at'   => date('Y-m-d H:i:s'),
                        ]);

                        $secondPartFrom = date('Y-m-d', strtotime($newTo . ' +1 day'));
                        $splitId = 'pfe-' . bin2hex(random_bytes(8));
                        $this->periodModel->insert([
                            'id'             => $splitId,
                            'company_id'     => $e['company_id'],
                            'employee_id'    => $employeeId,
                            'status'         => $e['status'],
                            'effective_from' => $secondPartFrom,
                            'effective_to'   => $eTo,
                            'reason'         => $e['reason'],
                            'member_id'      => $e['member_id'],
                            'created_by'     => $actorId,
                            'created_at'     => date('Y-m-d H:i:s'),
                            'updated_at'     => date('Y-m-d H:i:s'),
                        ]);
                    } elseif ($eFrom < $newFrom && ($eTo !== null && $eTo >= $newFrom && $eTo <= $newTo)) {
                        // Case C: Existing starts before and ends inside new period
                        $adjustedTo = date('Y-m-d', strtotime($newFrom . ' -1 day'));
                        $this->periodModel->update($eId, [
                            'effective_to' => $adjustedTo,
                            'updated_at'   => date('Y-m-d H:i:s'),
                        ]);
                    } elseif ($eFrom >= $newFrom && $eFrom <= $newTo && ($eTo === null || $eTo > $newTo)) {
                        // Case D: Existing starts inside new period and extends past it
                        $adjustedFrom = date('Y-m-d', strtotime($newTo . ' +1 day'));
                        $this->periodModel->update($eId, [
                            'effective_from' => $adjustedFrom,
                            'updated_at'     => date('Y-m-d H:i:s'),
                        ]);
                    }
                    // Case E: No overlap -> leave untouched
                }
            }

            // Insert the new period
            $newPeriodId = 'pfe-' . bin2hex(random_bytes(8));
            $now = date('Y-m-d H:i:s');
            $newPeriodData = [
                'id'             => $newPeriodId,
                'company_id'     => $companyId,
                'employee_id'    => $employeeId,
                'status'         => $status,
                'effective_from' => $effectiveFrom,
                'effective_to'   => $effectiveTo,
                'reason'         => $reason,
                'member_id'      => $memberId,
                'created_by'     => $actorId,
                'created_at'     => $now,
                'updated_at'     => $now,
            ];

            $this->periodModel->insert($newPeriodData);

            // 8. Synchronize employee snapshot columns for current date (today)
            $today = date('Y-m-d');
            $currentPeriod = $this->getEligibilityOn($employeeId, $today);

            $snapshotUpdate = [];
            if ($currentPeriod) {
                $isApplicable = ($currentPeriod['status'] === 'Eligible') ? 1 : 0;
                $pfStatus = ($currentPeriod['status'] === 'Eligible')
                    ? 'Enrolled'
                    : ($currentPeriod['status'] === 'Exempt' ? 'Exempt' : 'Not Enrolled');

                $snapshotUpdate = [
                    'is_pf_applicable'    => $isApplicable,
                    'pf_status'           => $pfStatus,
                    'pf_member_id'        => $memberId,
                    'pf_effective_date'   => $currentPeriod['effective_from'],
                    'pf_close_date'       => ($currentPeriod['status'] !== 'Eligible' || !empty($currentPeriod['effective_to']))
                        ? ($currentPeriod['effective_to'] ?: $currentPeriod['effective_from'])
                        : null,
                    'pf_close_reason'     => ($currentPeriod['status'] !== 'Eligible') ? $currentPeriod['reason'] : null,
                    'pf_exemption_reason' => ($currentPeriod['status'] === 'Exempt') ? $currentPeriod['reason'] : null,
                ];
            } else {
                $snapshotUpdate = [
                    'is_pf_applicable'  => 0,
                    'pf_status'         => 'Not Enrolled',
                    'pf_member_id'      => $memberId,
                ];
            }

            if ($notes !== null) {
                $snapshotUpdate['pf_notes'] = $notes;
            }

            $this->employeeModel->update($employeeId, $snapshotUpdate);

            // 9. Write authoritative audit log
            $this->auditService->log(
                $actorId,
                'employee_pf_eligibility',
                'eligibility.changed',
                $newPeriodId,
                $previousPeriod,
                $newPeriodData,
                null,
                null,
                "Updated PF eligibility for employee {$employeeId} to {$status} from {$effectiveFrom}" . ($effectiveTo ? " to {$effectiveTo}" : "")
            );

            if ($this->db->transStatus() === false) {
                $this->db->transRollback();
                throw new RuntimeException("Transaction failed during PF eligibility period update.");
            }

            $this->db->transCommit();
            return $newPeriodData;
        } catch (\Throwable $e) {
            $this->db->transRollback();
            throw $e;
        }
    }

    /**
     * Retrieve the period that covers an employee on a given date.
     * Guaranteed at most one period covers any date.
     */
    public function getEligibilityOn(string $employeeId, string $date): ?array
    {
        if (!$this->db->tableExists('employee_pf_eligibility_periods')) {
            // Fallback to employee master facts if table not yet migrated
            $emp = $this->employeeModel->find($employeeId);
            if (!$emp) {
                return null;
            }
            $isApp = !empty($emp['is_pf_applicable']) && (int)$emp['is_pf_applicable'] === 1;
            $rawStatus = trim((string)($emp['pf_status'] ?? ''));
            $effDate = $emp['pf_effective_date'] ?? $emp['joining_date'] ?? null;
            $closeDate = $emp['pf_close_date'] ?? null;

            if ($isApp && ($rawStatus === 'Enrolled' || $rawStatus === '')) {
                if ($effDate && $date < $effDate) {
                    return null;
                }
                if ($closeDate && $date >= $closeDate) {
                    return null;
                }
                return [
                    'id'             => 'legacy-virtual',
                    'company_id'     => $emp['company_id'],
                    'employee_id'    => $employeeId,
                    'status'         => 'Eligible',
                    'effective_from' => $effDate ?: '2020-01-01',
                    'effective_to'   => $closeDate,
                    'reason'         => null,
                    'member_id'      => $emp['pf_member_id'] ?? null,
                ];
            }
            return null;
        }

        return $this->periodModel->getPeriodOn($employeeId, $date);
    }

    /**
     * Retrieve full timeline history for an employee in reverse chronological order
     */
    public function getHistory(string $employeeId): array
    {
        if (!$this->db->tableExists('employee_pf_eligibility_periods')) {
            return [];
        }

        return $this->periodModel->getEmployeeHistory($employeeId);
    }

    /**
     * Retrieve accumulated PF contribution summary from committed ledger entries
     */
    public function getEmployeeSummary(string $employeeId): array
    {
        $currentBalance = $this->ledgerModel->getLatestBalance($employeeId);

        $committedRows = $this->db->table('provident_fund_ledgers')
            ->where('employee_id', $employeeId)
            ->where('status', 'posted')
            ->get()
            ->getResultArray();

        $totalEmployee = 0.00;
        $totalEmployer = 0.00;
        $totalAdj = 0.00;
        $lastMonth = null;
        $lastYear = null;

        foreach ($committedRows as $row) {
            $type = $row['transaction_type'] ?? 'CONTRIBUTION';
            if ($type === 'OPENING_BALANCE' || $type === 'INTEREST') {
                $totalAdj += (float)($row['total_contribution'] ?? 0.00);
            } else {
                $totalEmployee += (float)($row['employee_contribution'] ?? 0.00);
                $totalEmployer += (float)($row['employer_contribution'] ?? 0.00);
            }

            if (!empty($row['payroll_month']) && !empty($row['payroll_year'])) {
                if ($lastYear === null || $row['payroll_year'] > $lastYear || ($row['payroll_year'] === $lastYear && $row['payroll_month'] > $lastMonth)) {
                    $lastYear = (int)$row['payroll_year'];
                    $lastMonth = (int)$row['payroll_month'];
                }
            }
        }

        $totalContribution = round($totalEmployee + $totalEmployer + $totalAdj, 2);
        $lastPeriodStr = ($lastMonth && $lastYear) ? sprintf('%04d-%02d', $lastYear, $lastMonth) : 'N/A';

        return [
            'employee_id'               => $employeeId,
            'total_employee_savings'    => round($totalEmployee, 2),
            'total_employer_match'      => round($totalEmployer, 2),
            'total_adjustments'         => round($totalAdj, 2),
            'total_accumulated_corpus'  => $totalContribution,
            'current_balance'           => round($currentBalance, 2),
            'last_contribution_period'  => $lastPeriodStr,
            'total_transactions_count'  => count($committedRows),
        ];
    }

    /**
     * Integrity assertion to ensure no overlapping periods exist for an employee
     */
    public function validateNoOverlaps(string $employeeId): bool
    {
        $periods = $this->periodModel->where('employee_id', $employeeId)
            ->orderBy('effective_from', 'ASC')
            ->findAll();

        $count = count($periods);
        for ($i = 0; $i < $count - 1; $i++) {
            $current = $periods[$i];
            $next = $periods[$i + 1];

            $currTo = $current['effective_to'];
            $nextFrom = $next['effective_from'];

            // If current is open-ended or ends on/after next starts, that's an invalid overlap
            if ($currTo === null || $currTo >= $nextFrom) {
                return false;
            }
        }

        return true;
    }
}
