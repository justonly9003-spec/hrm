<?php

namespace App\Services\Pf;

use App\Services\Rules\RuleResolver;
use App\Services\Rules\ResolvedRule;
use App\Services\Rules\FormulaEvaluator;
use App\Models\EmployeeModel;
use App\Services\Pf\PfEligibilityService;

class PfCalculator
{
    protected RuleResolver $resolver;
    protected PfEligibilityService $eligibilityService;

    public function __construct(?RuleResolver $resolver = null, ?PfEligibilityService $eligibilityService = null)
    {
        $this->resolver = $resolver ?? new RuleResolver();
        $this->eligibilityService = $eligibilityService ?? new PfEligibilityService();
    }

    /**
     * Calculate Provident Fund deductions and contributions for an employee.
     *
     * @param array{
     *     company_id: string,
     *     employee: array|string,
     *     effective_date?: string,
     *     earnings?: array<string, float|int|numeric>,
     *     basic?: float|int|numeric,
     *     gross?: float|int|numeric
     * } $context
     * @return array
     */
    public function calculate(array $context): array
    {
        $companyId = (string)($context['company_id'] ?? '');
        $rawEmployee = $context['employee'] ?? null;
        $effectiveDate = (string)($context['effective_date'] ?? date('Y-m-d'));

        // 1. Resolve full employee facts array
        $employee = [];
        if (is_array($rawEmployee)) {
            $employee = $rawEmployee;
        } elseif (is_string($rawEmployee) && $rawEmployee !== '') {
            $empModel = new EmployeeModel();
            $employee = $empModel->find($rawEmployee) ?: ['id' => $rawEmployee];
        }

        if ($companyId === '' && !empty($employee['company_id'])) {
            $companyId = (string)$employee['company_id'];
        }

        // 2. Normalize earnings map
        $earnings = $context['earnings'] ?? [];
        if (!is_array($earnings)) {
            $earnings = [];
        }
        if (isset($context['basic']) && !isset($earnings['Basic']) && !isset($earnings['basic'])) {
            $earnings['Basic'] = (float)$context['basic'];
        }
        if (isset($context['gross']) && !isset($earnings['Gross']) && !isset($earnings['gross'])) {
            $earnings['Gross'] = (float)$context['gross'];
        }

        $midMonthRule = (string)($context['mid_month_rule'] ?? ($context['company_settings']['pf_mid_month_rule'] ?? 'next_payroll_month'));

        // 3. Evaluate Employee Facts & Eligibility
        $eligibility = $this->evaluateEmployeeEligibility($employee, $effectiveDate, $midMonthRule);
        if (!$eligibility['is_eligible']) {
            return [
                'is_eligible'           => false,
                'is_applicable'         => $eligibility['is_applicable'],
                'status'                => $eligibility['status'],
                'period_id'             => $eligibility['period_id'] ?? null,
                'employee_deduction'    => 0.00,
                'employer_contribution' => 0.00,
                'total_pf'              => 0.00,
                'resolved_basis_amount' => 0.00,
                'effective_basis_amount'=> 0.00,
                'calculation_basis'     => 'N/A',
                'employee_rate_applied' => 0.00,
                'employer_rate_applied' => 0.00,
                'rule_name'             => $eligibility['status'],
                'reason'                => $eligibility['reason'],
                'rules_snapshot'        => [],
                'snapshot'              => null,
            ];
        }

        // 4. Resolve PF rule strictly through RuleResolver (Single Source of Truth)
        $rule = $this->resolver->resolve($companyId, 'PF', $effectiveDate, $employee);

        // 5. Read parameters strictly from ResolvedRule (NO literal fallbacks)
        $contribType     = (string)$rule->get('contribution_type');
        $empRate         = (float)$rule->get('employee_rate');
        $compRate        = (float)$rule->get('employer_rate');
        $empFixed        = (float)$rule->get('employee_fixed_amount');
        $compFixed       = (float)$rule->get('employer_fixed_amount');
        $basis           = (string)$rule->get('calculation_basis');
        $basisComponents = (array)$rule->get('basis_components');
        $customFormula   = $rule->has('custom_formula') ? $rule->get('custom_formula') : null;
        $compFormula     = $rule->has('employer_formula') ? $rule->get('employer_formula') : null;
        $minSalary       = (float)$rule->get('min_salary_limit');
        $maxSalary       = (float)$rule->get('max_salary_limit');
        $minDeduction    = (float)$rule->get('min_deduction_limit');
        $maxDeduction    = (float)$rule->get('max_deduction_limit');

        // Allow temporary simulation / test overrides if explicitly supplied
        $ruleName = 'Provident Fund';
        $layers = $rule->layers();
        $versionNumber = (int)($layers[0]['version_number'] ?? 1);
        if (!empty($context['rule_override']) && is_array($context['rule_override'])) {
            $ov = $context['rule_override'];
            if (isset($ov['employee_rate'])) $empRate = (float)$ov['employee_rate'];
            if (isset($ov['employer_rate'])) $compRate = (float)$ov['employer_rate'];
            if (isset($ov['contribution_type'])) $contribType = (string)$ov['contribution_type'];
            if (isset($ov['calculation_basis'])) $basis = (string)$ov['calculation_basis'];
            if (isset($ov['employee_fixed_amount'])) $empFixed = (float)$ov['employee_fixed_amount'];
            if (isset($ov['employer_fixed_amount'])) $compFixed = (float)$ov['employer_fixed_amount'];
            if (isset($ov['custom_formula'])) $customFormula = (string)$ov['custom_formula'];
            if (isset($ov['employer_formula'])) $compFormula = (string)$ov['employer_formula'];
            if (isset($ov['version_number'])) $versionNumber = (int)$ov['version_number'];
            if (isset($ov['rule_name'])) $ruleName = (string)$ov['rule_name'];
        }

        if (!empty($context['has_pf_override']) && isset($context['custom_employee_rate'])) {
            $empRate = (float)$context['custom_employee_rate'];
        }

        $basicAmt      = (float)($earnings['Basic'] ?? $earnings['basic'] ?? $earnings['BASIC'] ?? 0.0);
        $grossAmt      = (float)($earnings['Gross'] ?? $earnings['gross'] ?? $earnings['GROSS'] ?? $basicAmt);
        $houseRentAmt  = (float)($earnings['HouseRent'] ?? $earnings['House_Rent'] ?? $earnings['HRA'] ?? $earnings['houseRent'] ?? $earnings['HOUSE_RENT'] ?? 0.0);
        $medicalAmt    = (float)($earnings['Medical'] ?? $earnings['medical'] ?? $earnings['MED'] ?? $earnings['MEDICAL'] ?? 0.0);
        $conveyanceAmt = (float)($earnings['Conveyance'] ?? $earnings['conveyance'] ?? $earnings['Transport'] ?? $earnings['CONVEYANCE'] ?? 0.0);

        $formulaContextVars = array_merge([
            'BASIC'         => $basicAmt,
            'GROSS'         => $grossAmt,
            'HOUSE_RENT'    => $houseRentAmt,
            'MEDICAL'       => $medicalAmt,
            'CONVEYANCE'    => $conveyanceAmt,
            'RATE'          => $empRate,
            'EMPLOYEE_RATE' => $empRate,
            'EMPLOYER_RATE' => $compRate,
        ], $earnings);

        // 6. Resolve Calculation Basis
        $resolvedBasis = $this->resolveCalculationBasis($basis, $basisComponents, $formulaContextVars, $customFormula, $companyId);

        // 7. Minimum Salary Threshold Check
        if ($minSalary > 0 && $resolvedBasis < $minSalary) {
            $rulesSnapshot = [
                'PF' => [
                    'layers' => $rule->layers(),
                    'hash'   => $rule->sha1(),
                ],
            ];

            return [
                'is_eligible'           => true,
                'is_applicable'         => true,
                'status'                => 'Below Threshold',
                'employee_deduction'    => 0.00,
                'employer_contribution' => 0.00,
                'total_pf'              => 0.00,
                'resolved_basis_amount' => round($resolvedBasis, 2),
                'effective_basis_amount'=> round($resolvedBasis, 2),
                'calculation_basis'     => $basis,
                'employee_rate_applied' => $empRate,
                'employer_rate_applied' => $compRate,
                'rule_name'             => 'PF Rule',
                'reason'                => "Basis amount ({$resolvedBasis}) is below minimum eligible limit ({$minSalary})",
                'rules_snapshot'        => $rulesSnapshot,
                'snapshot'              => null,
            ];
        }

        // 8. Maximum Salary Limit Clamping
        $effectiveBasis = ($maxSalary > 0 && $resolvedBasis > $maxSalary) ? $maxSalary : $resolvedBasis;

        // 9. Calculate Employee Deduction & Employer Contribution
        $employeeDeduction    = 0.00;
        $employerContribution = 0.00;

        if ($contribType === 'fixed') {
            $employeeDeduction    = $empFixed;
            $employerContribution = $compFixed;
        } elseif ($contribType === 'formula' || $basis === 'Custom_Formula') {
            $empForm  = trim((string)($customFormula ?? ''));
            $compForm = trim((string)($compFormula ?? '')) !== '' ? trim((string)$compFormula) : $empForm;

            if ($empForm === '') {
                throw new \InvalidArgumentException('PF formula calculation requires a non-empty custom_formula.');
            }

            $vars = array_merge($formulaContextVars, [
                'BASIC'         => $earnings['Basic'] ?? $earnings['basic'] ?? $resolvedBasis,
                'GROSS'         => $earnings['Gross'] ?? $earnings['gross'] ?? $resolvedBasis,
                'RATE'          => $empRate,
                'EMPLOYEE_RATE' => $empRate,
                'EMPLOYER_RATE' => $compRate,
                'BASIS'         => $effectiveBasis,
            ]);

            try {
                $employeeDeduction    = FormulaEvaluator::evaluate($empForm, $vars);
                $employerContribution = FormulaEvaluator::evaluate($compForm, $vars);
            } catch (\InvalidArgumentException $e) {
                throw new \InvalidArgumentException('PF formula evaluation failed: ' . $e->getMessage(), 0, $e);
            }
        } else {
            // Default: Percentage
            $employeeDeduction    = round($effectiveBasis * ($empRate / 100.0), 2);
            $employerContribution = round($effectiveBasis * ($compRate / 100.0), 2);
        }

        // 10. Clamping to Min/Max Deduction limits
        if ($minDeduction > 0 && $employeeDeduction > 0 && $employeeDeduction < $minDeduction) {
            $employeeDeduction = $minDeduction;
        }
        if ($maxDeduction > 0 && $employeeDeduction > $maxDeduction) {
            $employeeDeduction = $maxDeduction;
        }

        if ($minDeduction > 0 && $employerContribution > 0 && $employerContribution < $minDeduction) {
            $employerContribution = $minDeduction;
        }
        if ($maxDeduction > 0 && $employerContribution > $maxDeduction) {
            $employerContribution = $maxDeduction;
        }

        // Apply mid-month pro-rata ratio if applicable
        $proRataRatio = (float)($eligibility['pro_rata_ratio'] ?? 1.0);
        if ($proRataRatio < 1.0 && $proRataRatio > 0.0) {
            $employeeDeduction    = round($employeeDeduction * $proRataRatio, 2);
            $employerContribution = round($employerContribution * $proRataRatio, 2);
        }

        $employeeDeduction    = round($employeeDeduction, 2);
        $employerContribution = round($employerContribution, 2);
        $totalPf              = round($employeeDeduction + $employerContribution, 2);

        // 11. Build Rules Snapshot
        $rulesSnapshot = [
            'PF' => [
                'layers'        => $rule->layers(),
                'hash'          => $rule->sha1(),
                'period_id'     => $eligibility['period_id'] ?? null,
                'period_status' => $eligibility['status'] ?? null,
            ],
        ];

        // Detailed snapshot for backward compatibility and audits
        $detailedSnapshot = [
            'domain'                 => 'PF',
            'period_id'              => $eligibility['period_id'] ?? null,
            'period_status'          => $eligibility['status'] ?? null,
            'pro_rata_ratio'         => $proRataRatio,
            'calculation_basis'      => $basis,
            'basis_components'       => $basisComponents,
            'resolved_basis_amount'  => round($resolvedBasis, 2),
            'effective_basis_amount' => round($effectiveBasis, 2),
            'employee_rate_applied'  => $empRate,
            'employer_rate_applied'  => $compRate,
            'contribution_type'      => $contribType,
            'employee_deduction'     => $employeeDeduction,
            'employer_contribution'  => $employerContribution,
            'effective_date'         => $effectiveDate,
            'layers'                 => $rule->layers(),
            'rule_hash'              => $rule->sha1(),
            'snapshot_timestamp'     => date('Y-m-d H:i:s'),
        ];

        return [
            'is_eligible'           => true,
            'is_applicable'         => true,
            'status'                => 'Enrolled',
            'period_id'             => $eligibility['period_id'] ?? null,
            'period_status'         => $eligibility['status'] ?? null,
            'pro_rata_ratio'        => $proRataRatio,
            'version_number'        => $versionNumber,
            'contribution_type'     => $contribType,
            'employee_rate'         => $empRate,
            'employer_rate'         => $compRate,
            'employee_deduction'    => $employeeDeduction,
            'employer_contribution' => $employerContribution,
            'total_pf'              => $totalPf,
            'resolved_basis_amount' => round($resolvedBasis, 2),
            'effective_basis_amount'=> round($effectiveBasis, 2),
            'calculation_basis'     => $basis,
            'employee_rate_applied' => $empRate,
            'employer_rate_applied' => $compRate,
            'rule_name'             => $ruleName,
            'reason'                => 'Calculated via single rule store PF definition',
            'rules_snapshot'        => $rulesSnapshot,
            'snapshot'              => $detailedSnapshot,
        ];
    }

    /**
     * Validate a single PF formula string at save time using FormulaEvaluator::testFormulaSyntax.
     *
     * @param string $formula
     * @param array<int|string, mixed> $extraVars
     * @return array{valid: bool, sample_result?: float, error?: string}
     */
    public function validateFormula(string $formula, array $extraVars = []): array
    {
        return FormulaEvaluator::testFormulaSyntax($formula, $extraVars);
    }

    /**
     * Validate PF rule formula fields (custom_formula, employer_formula) at save time.
     *
     * @param array<string, mixed> $params
     * @param array<int|string, mixed> $extraVars
     * @return array{valid: bool, errors: array<string, string>}
     */
    public static function validateFormulaFields(array $params, array $extraVars = []): array
    {
        $errors = [];
        $contribType = (string)($params['contribution_type'] ?? '');
        $calcBasis   = (string)($params['calculation_basis'] ?? '');
        $requiresFormula = ($contribType === 'formula' || $calcBasis === 'Custom_Formula');

        $customFormula   = $params['custom_formula'] ?? null;
        $employerFormula = $params['employer_formula'] ?? null;

        if ($requiresFormula && (!is_string($customFormula) || trim($customFormula) === '')) {
            $errors['custom_formula'] = "Parameter 'custom_formula' cannot be empty when contribution_type is 'formula' or calculation_basis is 'Custom_Formula'";
        }

        if (is_string($customFormula) && trim($customFormula) !== '') {
            $syntaxCheck = FormulaEvaluator::testFormulaSyntax($customFormula, $extraVars);
            if (!$syntaxCheck['valid']) {
                $errors['custom_formula'] = "Invalid formula in 'custom_formula': " . ($syntaxCheck['error'] ?? 'Invalid syntax');
            }
        }

        if (is_string($employerFormula) && trim($employerFormula) !== '') {
            $syntaxCheck = FormulaEvaluator::testFormulaSyntax($employerFormula, $extraVars);
            if (!$syntaxCheck['valid']) {
                $errors['employer_formula'] = "Invalid formula in 'employer_formula': " . ($syntaxCheck['error'] ?? 'Invalid syntax');
            }
        }

        return [
            'valid'  => empty($errors),
            'errors' => $errors,
        ];
    }

    /**
     * Evaluate custom formula with variable bindings
     *
     * @throws \InvalidArgumentException
     */
    public function evaluateFormula(string $formula, array $variables): float
    {
        try {
            return FormulaEvaluator::evaluate($formula, $variables);
        } catch (\InvalidArgumentException $e) {
            throw new \InvalidArgumentException('PF formula evaluation failed: ' . $e->getMessage(), 0, $e);
        }
    }

    /**
     * Evaluate employee eligibility using authoritative PF eligibility periods and mid-month policy.
     *
     * @param array $employee
     * @param string $effectiveDate
     * @param string $midMonthRule 'next_payroll_month' (default) or 'pro_rata_days'
     * @return array{is_eligible: bool, is_applicable: bool, status: string, period_id: ?string, reason: string, pro_rata_ratio: float}
     */
    public function evaluateEmployeeEligibility(array $employee, string $effectiveDate, string $midMonthRule = 'next_payroll_month'): array
    {
        // 1. Software App Admin & Super Admin exclusion
        $role = $employee['role'] ?? '';
        $code = $employee['employee_code'] ?? '';
        if ($role === 'Software App Admin' || $code === 'SUPER_ADMIN') {
            return [
                'is_eligible'    => false,
                'is_applicable'  => false,
                'status'         => 'Excluded',
                'period_id'      => null,
                'reason'         => 'Software App Admin / Super Admin cannot participate in statutory deductions.',
                'pro_rata_ratio' => 0.0,
            ];
        }

        // 2. Contextual setting from salary assignment: pf_settings override
        if (isset($employee['pf_settings']) && is_array($employee['pf_settings'])) {
            $pfSettings = $employee['pf_settings'];
            $assignEligible = null;
            if (isset($pfSettings['eligible'])) {
                $assignEligible = (bool)$pfSettings['eligible'];
            } elseif (isset($pfSettings['is_eligible'])) {
                $assignEligible = (bool)$pfSettings['is_eligible'];
            } elseif (isset($pfSettings['is_pf_applicable'])) {
                $assignEligible = (bool)$pfSettings['is_pf_applicable'];
            }
            if ($assignEligible === false) {
                return [
                    'is_eligible'    => false,
                    'is_applicable'  => false,
                    'status'         => 'Ineligible',
                    'period_id'      => null,
                    'reason'         => !empty($pfSettings['override_reason'])
                        ? (string)$pfSettings['override_reason']
                        : 'Employee is marked ineligible in salary assignment pf_settings.',
                    'pro_rata_ratio' => 0.0,
                ];
            }
            if ($assignEligible === true) {
                return [
                    'is_eligible'    => true,
                    'is_applicable'  => true,
                    'status'         => 'Eligible',
                    'period_id'      => null,
                    'reason'         => 'Employee is marked eligible in salary assignment pf_settings.',
                    'pro_rata_ratio' => 1.0,
                ];
            }
        }

        $employeeId = $employee['id'] ?? null;
        if (!$employeeId) {
            return [
                'is_eligible'    => false,
                'is_applicable'  => false,
                'status'         => 'Not Eligible',
                'period_id'      => null,
                'reason'         => 'Employee identifier missing.',
                'pro_rata_ratio' => 0.0,
            ];
        }

        // 3. Query authoritative covering eligibility period
        $period = $this->eligibilityService->getEligibilityOn((string)$employeeId, $effectiveDate);

        if (!$period) {
            // Check fallback facts on employee row
            if (!empty($employee['is_pf_applicable']) || ($employee['pf_status'] ?? '') === 'Enrolled') {
                return [
                    'is_eligible'    => true,
                    'is_applicable'  => true,
                    'status'         => 'Eligible',
                    'period_id'      => null,
                    'reason'         => 'Employee is enrolled in Provident Fund via master records.',
                    'pro_rata_ratio' => 1.0,
                ];
            }

            // Safe default: no covering period => NOT eligible (removes default true behavior)
            return [
                'is_eligible'    => false,
                'is_applicable'  => false,
                'status'         => 'Not Eligible',
                'period_id'      => null,
                'reason'         => 'No active PF eligibility period covers the payroll date.',
                'pro_rata_ratio' => 0.0,
            ];
        }

        $periodStatus = $period['status'] ?? 'Not Eligible';
        $periodId = $period['id'] ?? null;

        if ($periodStatus === 'Exempt') {
            return [
                'is_eligible'    => false,
                'is_applicable'  => false,
                'status'         => 'Exempt',
                'period_id'      => $periodId,
                'reason'         => !empty($period['reason']) ? $period['reason'] : 'Employee is exempt from Provident Fund.',
                'pro_rata_ratio' => 0.0,
            ];
        }

        if ($periodStatus === 'Not Eligible') {
            return [
                'is_eligible'    => false,
                'is_applicable'  => false,
                'status'         => 'Not Eligible',
                'period_id'      => $periodId,
                'reason'         => !empty($period['reason']) ? $period['reason'] : 'Employee is not eligible for Provident Fund.',
                'pro_rata_ratio' => 0.0,
            ];
        }

        // Period status is 'Eligible'. Apply Mid-Month rule:
        // Policy options: 'next_payroll_month' (default) vs 'pro_rata_days'.
        $monthStart = date('Y-m-01', strtotime($effectiveDate));
        $monthEnd   = date('Y-m-t', strtotime($effectiveDate));
        $daysInMonth = (int)date('t', strtotime($effectiveDate));
        if ($daysInMonth <= 0) {
            $daysInMonth = 30;
        }

        $effFrom = $period['effective_from'];
        $effTo   = $period['effective_to'];

        // Case 1: Mid-month enrollment start
        if ($effFrom > $monthStart && $effFrom <= $monthEnd) {
            if ($midMonthRule === 'next_payroll_month') {
                return [
                    'is_eligible'    => false,
                    'is_applicable'  => true,
                    'status'         => 'Pending Effective Date',
                    'period_id'      => $periodId,
                    'reason'         => "Mid-month enrollment starting on {$effFrom} takes effect next payroll month under next_payroll_month policy.",
                    'pro_rata_ratio' => 0.0,
                ];
            } else {
                // pro_rata_days
                $effEnd = ($effTo !== null && $effTo < $monthEnd) ? $effTo : $monthEnd;
                $activeDays = max(1, (int)((strtotime($effEnd) - strtotime($effFrom)) / 86400) + 1);
                $ratio = min(1.0, max(0.0, $activeDays / $daysInMonth));

                return [
                    'is_eligible'    => true,
                    'is_applicable'  => true,
                    'status'         => 'Eligible',
                    'period_id'      => $periodId,
                    'reason'         => "Pro-rata mid-month enrollment: {$activeDays}/{$daysInMonth} days active.",
                    'pro_rata_ratio' => $ratio,
                ];
            }
        }

        // Case 2: Mid-month termination end
        if ($effTo !== null && $effTo >= $monthStart && $effTo < $monthEnd) {
            if ($midMonthRule === 'pro_rata_days') {
                $effStart = ($effFrom > $monthStart) ? $effFrom : $monthStart;
                $activeDays = max(1, (int)((strtotime($effTo) - strtotime($effStart)) / 86400) + 1);
                $ratio = min(1.0, max(0.0, $activeDays / $daysInMonth));

                return [
                    'is_eligible'    => true,
                    'is_applicable'  => true,
                    'status'         => 'Eligible',
                    'period_id'      => $periodId,
                    'reason'         => "Pro-rata mid-month termination: {$activeDays}/{$daysInMonth} days active.",
                    'pro_rata_ratio' => $ratio,
                ];
            }
        }

        // Standard full month active period
        return [
            'is_eligible'    => true,
            'is_applicable'  => true,
            'status'         => 'Eligible',
            'period_id'      => $periodId,
            'reason'         => 'Employee meets all Provident Fund eligibility criteria for this period.',
            'pro_rata_ratio' => 1.0,
        ];
    }

    /**
     * Resolve the numerical basis amount from salary components according to basis configuration.
     *
     * @param string $basis
     * @param array<string> $basisComponents
     * @param array<string, float|int|numeric> $earningsMap
     * @param string|null $customFormula
     * @param string|null $companyId
     * @return float
     */
    public function resolveCalculationBasis(string $basis, array $basisComponents, array $earningsMap, ?string $customFormula = null, ?string $companyId = null): float
    {
        // Normalize earnings map keys
        $normMap = [];
        foreach ($earningsMap as $k => $v) {
            $amt = (float)$v;
            $normMap[strtoupper(trim((string)$k))] = $amt;
            $clean = strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', (string)$k));
            $normMap[$clean] = $amt;
        }

        $basic     = $normMap['BASIC'] ?? $normMap['BASICSALARY'] ?? 0.0;
        $houseRent = $normMap['HOUSERENT'] ?? $normMap['HOUSE_RENT'] ?? $normMap['HRA'] ?? 0.0;

        switch ($basis) {
            case 'Gross':
            case 'Gross Salary':
                return (float)($normMap['GROSS'] ?? $normMap['GROSS_SALARY'] ?? $normMap['GROSSSALARY'] ?? $basic);

            case 'Basic_HouseRent':
            case 'Basic + House Rent':
            case 'Basic + HRA':
                return $basic + $houseRent;

            case 'Custom_Components':
            case 'Selected Salary Components':
                // Query salary_components for component-level eligibility flag (PF-1 Option A)
                $applicableCodes = null;
                if (!empty($companyId)) {
                    try {
                        $db = \Config\Database::connect();
                        if ($db->tableExists('salary_components')) {
                            $builder = $db->table('salary_components')->where('company_id', $companyId);
                            $pfCol = $db->fieldExists('include_in_pf_basis', 'salary_components') ? 'include_in_pf_basis' : 'is_pf_applicable';
                            $rows = $builder->where($pfCol, 1)->get()->getResultArray();
                            $applicableCodes = [];
                            foreach ($rows as $r) {
                                $codeU = strtoupper(trim((string)$r['code']));
                                $applicableCodes[$codeU] = true;
                                $clean = strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', (string)$r['code']));
                                $applicableCodes[$clean] = true;
                                if (!empty($r['name'])) {
                                    $applicableCodes[strtoupper(trim((string)$r['name']))] = true;
                                    $applicableCodes[strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', (string)$r['name']))] = true;
                                }
                            }
                        }
                    } catch (\Throwable $e) {
                        $applicableCodes = null;
                    }
                }

                if (!empty($basisComponents)) {
                    $sum = 0.0;
                    foreach ($basisComponents as $comp) {
                        $cUpper = strtoupper(trim((string)$comp));
                        $cClean = strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', (string)$comp));

                        // If component table flags are queried, verify this component has PF applicability enabled
                        if ($applicableCodes !== null && !isset($applicableCodes[$cUpper]) && !isset($applicableCodes[$cClean])) {
                            continue;
                        }

                        if (isset($normMap[$cUpper])) {
                            $sum += $normMap[$cUpper];
                        } elseif (isset($normMap[$cClean])) {
                            $sum += $normMap[$cClean];
                        } else {
                            // Partial substring match
                            foreach ($normMap as $mk => $mv) {
                                if (strpos($mk, $cClean) !== false || strpos($cClean, $mk) !== false) {
                                    $sum += $mv;
                                    break;
                                }
                            }
                        }
                    }
                    return $sum > 0.0 ? $sum : $basic;
                }

                // If no static list was configured on rule, sum all earnings matching applicable components
                if ($applicableCodes !== null && !empty($applicableCodes)) {
                    $sum = 0.0;
                    foreach ($normMap as $k => $amt) {
                        if (isset($applicableCodes[$k])) {
                            $sum += $amt;
                        }
                    }
                    return $sum > 0.0 ? $sum : $basic;
                }

                return $basic;

            case 'Custom_Formula':
                $formulaStr = trim((string)($customFormula ?? ''));
                if ($formulaStr === '') {
                    throw new \InvalidArgumentException('PF calculation_basis is Custom_Formula, but custom_formula is empty.');
                }
                $formulaVars = array_merge([
                    'BASIC'      => $basic,
                    'GROSS'      => (float)($normMap['GROSS'] ?? $normMap['GROSS_SALARY'] ?? $normMap['GROSSSALARY'] ?? $basic),
                    'HOUSE_RENT' => $houseRent,
                    'MEDICAL'    => (float)($normMap['MEDICAL'] ?? $normMap['MED'] ?? $normMap['MEDICAL_ALLOWANCE'] ?? 0.0),
                    'CONVEYANCE' => (float)($normMap['CONVEYANCE'] ?? $normMap['TRANSPORT'] ?? 0.0),
                ], $earningsMap);
                try {
                    return FormulaEvaluator::evaluate($formulaStr, $formulaVars);
                } catch (\InvalidArgumentException $e) {
                    throw new \InvalidArgumentException('PF basis formula evaluation failed: ' . $e->getMessage(), 0, $e);
                }

            case 'Basic':
            default:
                return $basic;
        }
    }
}
