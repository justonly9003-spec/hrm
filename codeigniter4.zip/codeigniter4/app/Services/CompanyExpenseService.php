<?php

namespace App\Services;

use App\Models\CompanyExpense\CompanyExpenseModel;
use App\Models\CompanyExpense\ExpenseCategoryModel;
use App\Models\CompanyExpense\CompanyExpenseApprovalModel;
use App\Models\CompanyExpense\CompanyExpensePaymentModel;
use App\Models\CompanyExpense\CompanyExpenseDocumentModel;
use CodeIgniter\Database\Exceptions\DatabaseException;

/**
 * Service: CompanyExpenseService
 * Authoritative business logic, financial transitions, numbering sequences,
 * and reporting analytics for Daily Company Operational Expenses.
 */
class CompanyExpenseService
{
    protected $db;
    protected $expenseModel;
    protected $categoryModel;
    protected $approvalModel;
    protected $paymentModel;
    protected $documentModel;

    public function __construct()
    {
        $this->db            = \Config\Database::connect();
        $this->expenseModel  = new CompanyExpenseModel();
        $this->categoryModel = new ExpenseCategoryModel();
        $this->approvalModel = new CompanyExpenseApprovalModel();
        $this->paymentModel  = new CompanyExpensePaymentModel();
        $this->documentModel = new CompanyExpenseDocumentModel();
    }

    /**
     * Atomically generate unique company expense number (e.g. EXP-2026-000001)
     */
    public function generateExpenseNumber(string $companyId, ?int $year = null): string
    {
        $year = $year ?: (int)date('Y');
        $prefix = sprintf('EXP-%04d-', $year);

        $row = $this->db->table('company_expenses')
            ->select('expense_number')
            ->where('company_id', $companyId)
            ->like('expense_number', $prefix, 'after')
            ->orderBy('id', 'DESC')
            ->limit(1)
            ->get()
            ->getFirstRow('array');

        $nextSeq = 1;
        if (!empty($row['expense_number'])) {
            $parts = explode('-', $row['expense_number']);
            $lastNum = (int)end($parts);
            if ($lastNum > 0) {
                $nextSeq = $lastNum + 1;
            }
        }

        // Check for safety loop in case of race condition
        do {
            $candidate = sprintf('%s%06d', $prefix, $nextSeq);
            $exists = $this->db->table('company_expenses')
                ->where('company_id', $companyId)
                ->where('expense_number', $candidate)
                ->countAllResults();
            if ($exists === 0) {
                return $candidate;
            }
            $nextSeq++;
        } while ($nextSeq < 999999);

        return sprintf('%s%06d', $prefix, $nextSeq);
    }

    /**
     * Transition 1: Submit draft or returned expense for review
     */
    public function submitExpense(string $companyId, string $expenseId, string $actorId, ?string $comments = null): array
    {
        $expense = $this->expenseModel->where('company_id', $companyId)->find($expenseId);
        if (!$expense) {
            throw new \RuntimeException('Company expense not found or access denied.');
        }

        if (!in_array($expense['status'], ['Draft', 'Rejected'], true)) {
            throw new \RuntimeException("Cannot submit expense with status '{$expense['status']}'. Only Draft or Rejected expenses can be submitted.");
        }

        $now = date('Y-m-d H:i:s');
        $this->db->transStart();

        $updateData = [
            'status'       => 'Submitted',
            'submitted_by' => $actorId,
            'submitted_at' => $now,
            'updated_by'   => $actorId,
            'updated_at'   => $now,
        ];

        $this->expenseModel->update($expenseId, $updateData);

        $this->approvalModel->insert([
            'id'              => 'cpxap-' . bin2hex(random_bytes(14)),
            'company_id'      => $companyId,
            'expense_id'      => $expenseId,
            'action'          => 'Submit',
            'actor_id'        => $actorId,
            'previous_status' => $expense['status'],
            'new_status'      => 'Submitted',
            'comments'        => $comments ?: 'Expense submitted for management/finance review',
            'created_at'      => $now,
        ]);

        $this->db->transComplete();
        if ($this->db->transStatus() === false) {
            throw new DatabaseException('Failed to submit company expense.');
        }

        return $this->expenseModel->getExpenseWithDetails($companyId, $expenseId);
    }

    /**
     * Transition 2: Approve submitted expense
     */
    public function approveExpense(string $companyId, string $expenseId, string $actorId, ?string $comments = null): array
    {
        $expense = $this->expenseModel->where('company_id', $companyId)->find($expenseId);
        if (!$expense) {
            throw new \RuntimeException('Company expense not found or access denied.');
        }

        if ($expense['status'] !== 'Submitted') {
            throw new \RuntimeException("Cannot approve expense with status '{$expense['status']}'. Only Submitted expenses can be approved.");
        }

        $now = date('Y-m-d H:i:s');
        $this->db->transStart();

        $updateData = [
            'status'      => 'Approved',
            'approved_by' => $actorId,
            'approved_at' => $now,
            'updated_by'  => $actorId,
            'updated_at'  => $now,
        ];

        $this->expenseModel->update($expenseId, $updateData);

        $this->approvalModel->insert([
            'id'              => 'cpxap-' . bin2hex(random_bytes(14)),
            'company_id'      => $companyId,
            'expense_id'      => $expenseId,
            'action'          => 'Approve',
            'actor_id'        => $actorId,
            'previous_status' => 'Submitted',
            'new_status'      => 'Approved',
            'comments'        => $comments ?: 'Expense approved for payment',
            'created_at'      => $now,
        ]);

        $this->db->transComplete();
        if ($this->db->transStatus() === false) {
            throw new DatabaseException('Failed to approve company expense.');
        }

        return $this->expenseModel->getExpenseWithDetails($companyId, $expenseId);
    }

    /**
     * Transition 3: Reject submitted expense
     */
    public function rejectExpense(string $companyId, string $expenseId, string $actorId, string $rejectionReason): array
    {
        $reason = trim($rejectionReason);
        if (empty($reason)) {
            throw new \InvalidArgumentException('Rejection reason is mandatory.');
        }

        $expense = $this->expenseModel->where('company_id', $companyId)->find($expenseId);
        if (!$expense) {
            throw new \RuntimeException('Company expense not found or access denied.');
        }

        if ($expense['status'] !== 'Submitted') {
            throw new \RuntimeException("Cannot reject expense with status '{$expense['status']}'. Only Submitted expenses can be rejected.");
        }

        $now = date('Y-m-d H:i:s');
        $this->db->transStart();

        $updateData = [
            'status'           => 'Rejected',
            'rejection_reason' => $reason,
            'updated_by'       => $actorId,
            'updated_at'       => $now,
        ];

        $this->expenseModel->update($expenseId, $updateData);

        $this->approvalModel->insert([
            'id'              => 'cpxap-' . bin2hex(random_bytes(14)),
            'company_id'      => $companyId,
            'expense_id'      => $expenseId,
            'action'          => 'Reject',
            'actor_id'        => $actorId,
            'previous_status' => 'Submitted',
            'new_status'      => 'Rejected',
            'comments'        => $reason,
            'created_at'      => $now,
        ]);

        $this->db->transComplete();
        if ($this->db->transStatus() === false) {
            throw new DatabaseException('Failed to reject company expense.');
        }

        return $this->expenseModel->getExpenseWithDetails($companyId, $expenseId);
    }

    /**
     * Transition 4: Cancel expense
     */
    public function cancelExpense(string $companyId, string $expenseId, string $actorId, string $cancellationReason): array
    {
        $reason = trim($cancellationReason);
        if (empty($reason)) {
            throw new \InvalidArgumentException('Cancellation reason is mandatory.');
        }

        $expense = $this->expenseModel->where('company_id', $companyId)->find($expenseId);
        if (!$expense) {
            throw new \RuntimeException('Company expense not found or access denied.');
        }

        if (in_array($expense['status'], ['Paid', 'Cancelled'], true)) {
            throw new \RuntimeException("Cannot cancel expense with status '{$expense['status']}'.");
        }

        $now = date('Y-m-d H:i:s');
        $this->db->transStart();

        $updateData = [
            'status'              => 'Cancelled',
            'cancellation_reason' => $reason,
            'updated_by'          => $actorId,
            'updated_at'          => $now,
        ];

        $this->expenseModel->update($expenseId, $updateData);

        $this->approvalModel->insert([
            'id'              => 'cpxap-' . bin2hex(random_bytes(14)),
            'company_id'      => $companyId,
            'expense_id'      => $expenseId,
            'action'          => 'Cancel',
            'actor_id'        => $actorId,
            'previous_status' => $expense['status'],
            'new_status'      => 'Cancelled',
            'comments'        => $reason,
            'created_at'      => $now,
        ]);

        $this->db->transComplete();
        if ($this->db->transStatus() === false) {
            throw new DatabaseException('Failed to cancel company expense.');
        }

        return $this->expenseModel->getExpenseWithDetails($companyId, $expenseId);
    }

    /**
     * Transition 5: Process and record payment for an approved expense
     */
    public function processPayment(string $companyId, string $expenseId, string $actorId, array $paymentData): array
    {
        $expense = $this->expenseModel->where('company_id', $companyId)->find($expenseId);
        if (!$expense) {
            throw new \RuntimeException('Company expense not found or access denied.');
        }

        if ($expense['status'] !== 'Approved') {
            throw new \RuntimeException("Cannot pay expense with status '{$expense['status']}'. Only Approved expenses can be marked as Paid.");
        }

        $payAmount = isset($paymentData['amount']) ? (float)$paymentData['amount'] : (float)$expense['amount'];
        if ($payAmount <= 0) {
            throw new \InvalidArgumentException('Payment amount must be greater than zero.');
        }

        if ($payAmount > (float)$expense['amount']) {
            throw new \InvalidArgumentException('Payment amount cannot exceed the total expense amount.');
        }

        $payDate   = !empty($paymentData['payment_date']) ? $paymentData['payment_date'] : date('Y-m-d');
        $payMethod = !empty($paymentData['payment_method']) ? trim($paymentData['payment_method']) : 'Bank Transfer';
        $payAcc    = !empty($paymentData['payment_account']) ? trim($paymentData['payment_account']) : 'Company Bank Account';
        $trxRef    = !empty($paymentData['transaction_reference']) ? trim($paymentData['transaction_reference']) : null;
        $notes     = !empty($paymentData['notes']) ? trim($paymentData['notes']) : null;
        $now       = date('Y-m-d H:i:s');

        $this->db->transStart();

        // 1. Record payment row
        $paymentRecordId = 'cpxpay-' . bin2hex(random_bytes(14));
        $this->paymentModel->insert([
            'id'                    => $paymentRecordId,
            'company_id'            => $companyId,
            'expense_id'            => $expenseId,
            'payment_date'          => $payDate,
            'payment_method'        => $payMethod,
            'payment_account'       => $payAcc,
            'amount'                => $payAmount,
            'transaction_reference' => $trxRef,
            'paid_by'               => $actorId,
            'notes'                 => $notes,
            'created_at'            => $now,
        ]);

        // 2. Update company expense to Paid
        $this->expenseModel->update($expenseId, [
            'status'                => 'Paid',
            'paid_amount'           => $payAmount,
            'payment_date'          => $payDate,
            'payment_method'        => $payMethod,
            'payment_account'       => $payAcc,
            'transaction_reference' => $trxRef,
            'paid_by'               => $actorId,
            'paid_at'               => $now,
            'updated_by'            => $actorId,
            'updated_at'            => $now,
        ]);

        // 3. Record workflow audit row
        $this->approvalModel->insert([
            'id'              => 'cpxap-' . bin2hex(random_bytes(14)),
            'company_id'      => $companyId,
            'expense_id'      => $expenseId,
            'action'          => 'Pay',
            'actor_id'        => $actorId,
            'previous_status' => 'Approved',
            'new_status'      => 'Paid',
            'comments'        => sprintf('Payment of %0.2f disbursed via %s (Ref: %s)', $payAmount, $payMethod, $trxRef ?: 'N/A'),
            'created_at'      => $now,
        ]);

        $this->db->transComplete();
        if ($this->db->transStatus() === false) {
            throw new DatabaseException('Failed to record payment for company expense.');
        }

        return $this->expenseModel->getExpenseWithDetails($companyId, $expenseId);
    }

    /**
     * Dashboard Analytics: Today, This Week, This Month, This Year,
     * Status breakdown, Category breakdown, and Monthly trend.
     */
    public function getDashboardMetrics(string $companyId, ?string $branchId = null): array
    {
        $today     = date('Y-m-d');
        $weekStart = date('Y-m-d', strtotime('monday this week'));
        $weekEnd   = date('Y-m-d', strtotime('sunday this week'));
        $monthStart= date('Y-m-01');
        $monthEnd  = date('Y-m-t');
        $yearStart = date('Y-01-01');
        $yearEnd   = date('Y-12-31');

        $base = $this->db->table('company_expenses')
            ->where('company_id', $companyId)
            ->where('deleted_at IS NULL');

        if (!empty($branchId)) {
            $base->where('branch_id', $branchId);
        }

        // Helper for sums
        $getPeriodTotal = function(string $start, string $end, ?string $status = null) use ($companyId, $branchId) {
            $b = $this->db->table('company_expenses')
                ->selectSum('amount', 'total_amount')
                ->selectCount('id', 'total_count')
                ->where('company_id', $companyId)
                ->where('deleted_at IS NULL')
                ->where('expense_date >=', $start)
                ->where('expense_date <=', $end);

            if (!empty($branchId)) {
                $b->where('branch_id', $branchId);
            }
            if (!empty($status)) {
                $b->where('status', $status);
            }
            $r = $b->get()->getFirstRow('array');
            return [
                'amount' => (float)($r['total_amount'] ?? 0),
                'count'  => (int)($r['total_count'] ?? 0),
            ];
        };

        $todayStats = $getPeriodTotal($today, $today);
        $weekStats  = $getPeriodTotal($weekStart, $weekEnd);
        $monthStats = $getPeriodTotal($monthStart, $monthEnd);
        $yearStats  = $getPeriodTotal($yearStart, $yearEnd);

        // Status Breakdown
        $statusCounts = [
            'Draft'     => ['count' => 0, 'amount' => 0.0],
            'Submitted' => ['count' => 0, 'amount' => 0.0],
            'Approved'  => ['count' => 0, 'amount' => 0.0],
            'Rejected'  => ['count' => 0, 'amount' => 0.0],
            'Paid'      => ['count' => 0, 'amount' => 0.0],
            'Cancelled' => ['count' => 0, 'amount' => 0.0],
        ];

        $bStatus = $this->db->table('company_expenses')
            ->select('status, COUNT(id) as count, SUM(amount) as total_amount')
            ->where('company_id', $companyId)
            ->where('deleted_at IS NULL');

        if (!empty($branchId)) {
            $bStatus->where('branch_id', $branchId);
        }

        $statusRows = $bStatus->groupBy('status')->get()->getResultArray();
        foreach ($statusRows as $sr) {
            if (isset($statusCounts[$sr['status']])) {
                $statusCounts[$sr['status']] = [
                    'count'  => (int)$sr['count'],
                    'amount' => (float)$sr['total_amount'],
                ];
            }
        }

        // Category Summary (This Year)
        $bCat = $this->db->table('company_expenses')
            ->select('expense_categories.id as category_id,
                      expense_categories.name as category_name,
                      expense_categories.code as category_code,
                      COUNT(company_expenses.id) as expense_count,
                      SUM(company_expenses.amount) as total_amount')
            ->join('expense_categories', 'expense_categories.id = company_expenses.category_id', 'left')
            ->where('company_expenses.company_id', $companyId)
            ->where('company_expenses.deleted_at IS NULL')
            ->where('company_expenses.status !=', 'Cancelled')
            ->where('company_expenses.expense_date >=', $yearStart)
            ->where('company_expenses.expense_date <=', $yearEnd);

        if (!empty($branchId)) {
            $bCat->where('company_expenses.branch_id', $branchId);
        }

        $catRows = $bCat->groupBy('expense_categories.id')
            ->orderBy('total_amount', 'DESC')
            ->get()
            ->getResultArray();

        $totalYearNonCancelled = array_sum(array_column($catRows, 'total_amount')) ?: 1.0;
        $categoryBreakdown = [];
        foreach ($catRows as $c) {
            $amt = (float)$c['total_amount'];
            $categoryBreakdown[] = [
                'category_id'   => $c['category_id'],
                'category_name' => $c['category_name'] ?: 'Uncategorized',
                'category_code' => $c['category_code'] ?: 'OTHER',
                'expense_count' => (int)$c['expense_count'],
                'total_amount'  => $amt,
                'percentage'    => round(($amt / $totalYearNonCancelled) * 100, 1),
            ];
        }

        // Monthly Trend (Current Year 12 Months)
        $monthlyTrend = [];
        $currentYear = (int)date('Y');
        $months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

        for ($m = 1; $m <= 12; $m++) {
            $mStart = sprintf('%04d-%02d-01', $currentYear, $m);
            $mEnd   = date('Y-m-t', strtotime($mStart));

            $bTrend = $this->db->table('company_expenses')
                ->selectSum('amount', 'total_amount')
                ->select("SUM(CASE WHEN status = 'Paid' THEN amount ELSE 0 END) as paid_amount")
                ->selectCount('id', 'total_count')
                ->where('company_id', $companyId)
                ->where('deleted_at IS NULL')
                ->where('status !=', 'Cancelled')
                ->where('expense_date >=', $mStart)
                ->where('expense_date <=', $mEnd);

            if (!empty($branchId)) {
                $bTrend->where('branch_id', $branchId);
            }

            $tRow = $bTrend->get()->getFirstRow('array');
            $monthlyTrend[] = [
                'month_number' => $m,
                'month_name'   => $months[$m - 1],
                'month_label'  => $months[$m - 1] . ' ' . $currentYear,
                'total_amount' => (float)($tRow['total_amount'] ?? 0),
                'paid_amount'  => (float)($tRow['paid_amount'] ?? 0),
                'count'        => (int)($tRow['total_count'] ?? 0),
            ];
        }

        return [
            'today' => [
                'amount' => $todayStats['amount'],
                'count'  => $todayStats['count'],
            ],
            'this_week' => [
                'amount'     => $weekStats['amount'],
                'count'      => $weekStats['count'],
                'start_date' => $weekStart,
                'end_date'   => $weekEnd,
            ],
            'this_month' => [
                'amount'     => $monthStats['amount'],
                'count'      => $monthStats['count'],
                'start_date' => $monthStart,
                'end_date'   => $monthEnd,
            ],
            'this_year' => [
                'amount'     => $yearStats['amount'],
                'count'      => $yearStats['count'],
                'year'       => $currentYear,
            ],
            'status_summary' => [
                'pending_approval' => $statusCounts['Submitted'],
                'approved'         => $statusCounts['Approved'],
                'paid'             => $statusCounts['Paid'],
                'rejected'         => $statusCounts['Rejected'],
                'draft'            => $statusCounts['Draft'],
                'cancelled'        => $statusCounts['Cancelled'],
                'unpaid'           => [
                    'count'  => $statusCounts['Submitted']['count'] + $statusCounts['Approved']['count'],
                    'amount' => $statusCounts['Submitted']['amount'] + $statusCounts['Approved']['amount'],
                ],
                'total_incurred'   => [
                    'count'  => $statusCounts['Draft']['count'] + $statusCounts['Submitted']['count'] + $statusCounts['Approved']['count'] + $statusCounts['Paid']['count'],
                    'amount' => $statusCounts['Draft']['amount'] + $statusCounts['Submitted']['amount'] + $statusCounts['Approved']['amount'] + $statusCounts['Paid']['amount'],
                ],
            ],
            'category_breakdown' => $categoryBreakdown,
            'monthly_trend'      => $monthlyTrend,
        ];
    }

    /**
     * Report 1: Daily Expense Log Report
     */
    public function getDailyReport(string $companyId, array $filters = []): array
    {
        $filters['date_from'] = $filters['date_from'] ?? date('Y-m-01');
        $filters['date_to']   = $filters['date_to'] ?? date('Y-m-d');

        $rows = $this->expenseModel->getExpensesDetailed(
            $companyId,
            $filters,
            500,
            0,
            'expense_date',
            'DESC'
        );

        $totalAmount = array_sum(array_column($rows, 'amount'));
        $paidAmount  = array_sum(array_column($rows, 'paid_amount'));

        return [
            'filters'      => $filters,
            'total_count'  => count($rows),
            'total_amount' => (float)$totalAmount,
            'paid_amount'  => (float)$paidAmount,
            'records'      => $rows,
        ];
    }

    /**
     * Report 2: Category Summary Report
     */
    public function getCategoryReport(string $companyId, array $filters = []): array
    {
        $dateFrom = $filters['date_from'] ?? date('Y-01-01');
        $dateTo   = $filters['date_to'] ?? date('Y-m-d');

        $builder = $this->db->table('company_expenses')
            ->select('expense_categories.id as category_id,
                      expense_categories.name as category_name,
                      expense_categories.code as category_code,
                      COUNT(company_expenses.id) as expense_count,
                      SUM(company_expenses.amount) as total_amount,
                      SUM(CASE WHEN company_expenses.status = "Paid" THEN company_expenses.paid_amount ELSE 0 END) as paid_amount,
                      SUM(CASE WHEN company_expenses.status = "Approved" THEN company_expenses.amount ELSE 0 END) as approved_unpaid,
                      SUM(CASE WHEN company_expenses.status = "Submitted" THEN company_expenses.amount ELSE 0 END) as pending_amount')
            ->join('expense_categories', 'expense_categories.id = company_expenses.category_id', 'left')
            ->where('company_expenses.company_id', $companyId)
            ->where('company_expenses.deleted_at IS NULL')
            ->where('company_expenses.status !=', 'Cancelled')
            ->where('company_expenses.expense_date >=', $dateFrom)
            ->where('company_expenses.expense_date <=', $dateTo);

        if (!empty($filters['branch_id'])) {
            $builder->where('company_expenses.branch_id', $filters['branch_id']);
        }

        $rows = $builder->groupBy('expense_categories.id')
            ->orderBy('total_amount', 'DESC')
            ->get()
            ->getResultArray();

        $overallTotal = array_sum(array_column($rows, 'total_amount'));

        $data = array_map(function($r) use ($overallTotal) {
            $tot = (float)$r['total_amount'];
            return [
                'category_id'     => $r['category_id'],
                'category_name'   => $r['category_name'] ?: 'Uncategorized',
                'category_code'   => $r['category_code'] ?: 'OTHER',
                'expense_count'   => (int)$r['expense_count'],
                'total_amount'    => $tot,
                'paid_amount'     => (float)$r['paid_amount'],
                'approved_unpaid' => (float)$r['approved_unpaid'],
                'pending_amount'  => (float)$r['pending_amount'],
                'percentage'      => $overallTotal > 0 ? round(($tot / $overallTotal) * 100, 2) : 0,
            ];
        }, $rows);

        return [
            'date_from'      => $dateFrom,
            'date_to'        => $dateTo,
            'total_expense'  => (float)$overallTotal,
            'category_count' => count($data),
            'categories'     => $data,
        ];
    }

    /**
     * Report 3: Monthly Breakdown Report
     */
    public function getMonthlyReport(string $companyId, ?int $year = null, ?string $branchId = null): array
    {
        $year = $year ?: (int)date('Y');
        $months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        $result = [];
        $grandTotal = 0.0;
        $grandPaid  = 0.0;

        for ($m = 1; $m <= 12; $m++) {
            $mStart = sprintf('%04d-%02d-01', $year, $m);
            $mEnd   = date('Y-m-t', strtotime($mStart));

            $b = $this->db->table('company_expenses')
                ->select("COUNT(id) as total_count,
                          SUM(amount) as total_amount,
                          SUM(CASE WHEN status = 'Approved' THEN amount ELSE 0 END) as approved_amount,
                          SUM(CASE WHEN status = 'Submitted' THEN amount ELSE 0 END) as submitted_amount,
                          SUM(CASE WHEN status = 'Paid' THEN paid_amount ELSE 0 END) as paid_amount,
                          SUM(CASE WHEN status = 'Rejected' THEN amount ELSE 0 END) as rejected_amount,
                          SUM(CASE WHEN status = 'Cancelled' THEN amount ELSE 0 END) as cancelled_amount")
                ->where('company_id', $companyId)
                ->where('deleted_at IS NULL')
                ->where('expense_date >=', $mStart)
                ->where('expense_date <=', $mEnd);

            if (!empty($branchId)) {
                $b->where('branch_id', $branchId);
            }

            $row = $b->get()->getFirstRow('array');
            $tot = (float)($row['total_amount'] ?? 0);
            $paid = (float)($row['paid_amount'] ?? 0);

            $grandTotal += $tot;
            $grandPaid  += $paid;

            $result[] = [
                'month_number'     => $m,
                'month_name'       => $months[$m - 1],
                'month_key'        => sprintf('%04d-%02d', $year, $m),
                'total_count'      => (int)($row['total_count'] ?? 0),
                'total_amount'     => $tot,
                'approved_amount'  => (float)($row['approved_amount'] ?? 0),
                'pending_amount'   => (float)($row['submitted_amount'] ?? 0),
                'paid_amount'      => $paid,
                'rejected_amount'  => (float)($row['rejected_amount'] ?? 0),
                'cancelled_amount' => (float)($row['cancelled_amount'] ?? 0),
            ];
        }

        return [
            'year'         => $year,
            'grand_total'  => $grandTotal,
            'grand_paid'   => $grandPaid,
            'monthly_data' => $result,
        ];
    }

    /**
     * Report 4: Expense Payments Disbursed Report
     */
    public function getPaymentReport(string $companyId, array $filters = []): array
    {
        $builder = $this->db->table('company_expense_payments')
            ->select('company_expense_payments.*,
                      company_expenses.expense_number,
                      company_expenses.title as expense_title,
                      company_expenses.description as expense_description,
                      company_expenses.vendor_name,
                      company_expenses.amount as expense_total_amount,
                      company_expenses.currency,
                      expense_categories.name as category_name,
                      users.username as paid_by_username')
            ->join('company_expenses', 'company_expenses.id = company_expense_payments.expense_id', 'left')
            ->join('expense_categories', 'expense_categories.id = company_expenses.category_id', 'left')
            ->join('users', 'users.id = company_expense_payments.paid_by', 'left')
            ->where('company_expense_payments.company_id', $companyId);

        if (!empty($filters['date_from'])) {
            $builder->where('company_expense_payments.payment_date >=', $filters['date_from']);
        }
        if (!empty($filters['date_to'])) {
            $builder->where('company_expense_payments.payment_date <=', $filters['date_to']);
        }
        if (!empty($filters['payment_method'])) {
            $builder->where('company_expense_payments.payment_method', $filters['payment_method']);
        }
        if (!empty($filters['search'])) {
            $s = trim($filters['search']);
            $builder->groupStart()
                ->like('company_expenses.expense_number', $s)
                ->orLike('company_expenses.vendor_name', $s)
                ->orLike('company_expense_payments.transaction_reference', $s)
                ->orLike('company_expense_payments.payment_account', $s)
            ->groupEnd();
        }

        $builder->orderBy('company_expense_payments.payment_date', 'DESC');
        $builder->orderBy('company_expense_payments.id', 'DESC');

        $rows = $builder->get()->getResultArray();
        $totalDisbursed = array_sum(array_column($rows, 'amount'));

        return [
            'filters'         => $filters,
            'payment_count'   => count($rows),
            'total_disbursed' => (float)$totalDisbursed,
            'payments'        => $rows,
        ];
    }
}
