<?php

namespace App\Services\Overtime;

use App\Models\AttendanceModel;
use App\Models\EmployeeModel;
use App\Models\HolidayModel;
use App\Models\OvertimeClaimModel;
use App\Models\OvertimeRecordModel;
use App\Models\OvertimeSettlementLockModel;
use App\Models\ShiftModel;
use App\Services\CompanyWeekendService;
use App\Services\EmployeeSalaryService;
use App\Services\Rules\RuleResolver;
use App\Services\Rules\RuleNotConfiguredException;
use App\Services\Rules\DailyRateResolver;
use App\Services\Rules\Money;
use Config\Database;

/**
 * Authoritative Overtime Calculation Engine
 *
 * Provides single server-side calculation of employee overtime across:
 * - Normal Workday (Early Arrival OT, Post-Shift OT)
 * - Weekly Off / Weekend Overtime (with multiplier)
 * - Holiday Overtime (with multiplier)
 * - Grace periods, minimum counting units (15/30 min rounding), caps
 * - Authoritative salary/hourly rate calculation using EmployeeSalaryService
 * - Multi-tenant isolation (company_id)
 * - Approval and claim lifecycle
 * - Payroll hard-lock and immutability guarantees
 */
class OvertimeCalculationService
{
    protected $db;
    protected $recordModel;
    protected $claimModel;
    protected $lockModel;
    protected $empModel;
    protected $attendanceModel;
    protected $shiftModel;
    protected $holidayModel;
    protected $dutyModel;
    protected $salaryService;

    public function __construct()
    {
        $this->db              = Database::connect();
        $this->recordModel     = new OvertimeRecordModel();
        $this->claimModel      = new OvertimeClaimModel();
        $this->lockModel       = new OvertimeSettlementLockModel();
        $this->empModel        = new EmployeeModel();
        $this->attendanceModel = new AttendanceModel();
        $this->shiftModel      = new ShiftModel();
        $this->holidayModel    = new HolidayModel();
        $this->dutyModel       = new \App\Models\DutyAssignmentModel();
        $this->salaryService   = new EmployeeSalaryService();
    }

    /**
     * Resolve the effective Overtime Policy for a company/employee using RuleResolver
     */
    public function resolvePolicy(string $companyId, mixed $employeeOrScopes = null, ?string $date = null): array
    {
        $date = $date ?: date('Y-m-d');
        $scopes = [];
        if (is_array($employeeOrScopes)) {
            $scopes = $employeeOrScopes;
            if (empty($companyId) && !empty($employeeOrScopes['company_id'])) {
                $companyId = (string)$employeeOrScopes['company_id'];
            }
        } elseif (is_string($employeeOrScopes)) {
            $scopes = ['branch_id' => $employeeOrScopes];
            if (is_string($date) && !preg_match('/^\d{4}-\d{2}-\d{2}/', $date)) {
                // If 3rd parameter was legacy departmentId string rather than a date
                $scopes['department_id'] = $date;
                $date = date('Y-m-d');
            }
        }

        if (empty($companyId) && function_exists('session')) {
            try {
                $companyId = (string)(session('selected_company_id') ?: session('company_id') ?: '');
            } catch (\Throwable $e) {}
        }

        $otRule = RuleResolver::resolve($companyId, 'OVERTIME', $date, $scopes);
        $basicsRule = RuleResolver::resolveForCompany($companyId, 'PAYROLL_BASICS', $date);

        $divMode = (string)$otRule->get('divisor_mode');
        $rateInfo = DailyRateResolver::resolve($companyId, $scopes, $date, null, 0.0, $divMode);
        $divisorDays = (float)$rateInfo['divisor_days'];

        if ($divisorDays <= 0) {
            throw new RuleNotConfiguredException("Invalid or zero divisor days in overtime rule calculation.");
        }

        $divisorHours = (float)($otRule->params()['divisor_hours'] ?? $basicsRule->get('standard_daily_hours'));
        if ($divisorHours <= 0) {
            throw new RuleNotConfiguredException("Invalid or zero standard daily hours in overtime rule calculation.");
        }

        $normalMultiplier = (float)$otRule->get('normal_multiplier');
        $weeklyOffMultiplier = (float)$otRule->get('weekly_off_multiplier');
        $holidayMultiplier = (float)$otRule->get('holiday_multiplier');
        $specialMultiplier = (float)($otRule->has('special_multiplier') ? $otRule->get('special_multiplier') : $holidayMultiplier);
        $nightMultiplier = (float)$otRule->get('night_multiplier');

        if ($normalMultiplier <= 0 || $weeklyOffMultiplier <= 0 || $holidayMultiplier <= 0) {
            throw new RuleNotConfiguredException("Missing or zero overtime multiplier configuration for company {$companyId}.");
        }

        $enableEarlyArrival      = !empty($otRule->get('enable_early_arrival_ot'));
        $earlyArrivalMinThreshold = (int)$otRule->get('early_arrival_min_threshold_minutes');
        $earlyGraceMinutes       = (int)$otRule->get('early_arrival_grace_minutes');

        $enablePostShift         = !empty($otRule->has('enable_post_shift_ot') ? $otRule->get('enable_post_shift_ot') : true);
        $postShiftMinThreshold   = (int)$otRule->get('post_shift_min_threshold_minutes');
        $postGraceMinutes        = (int)$otRule->get('post_shift_grace_minutes');

        $weeklyOtEnabled = $otRule->has('weekly_ot_enabled') && !empty($otRule->get('weekly_ot_enabled'));

        return [
            'id'                                  => $otRule->snapshot()['layers'][0]['rule_id'] ?? null,
            'policy_id'                           => $otRule->snapshot()['layers'][0]['rule_id'] ?? null,
            'company_id'                          => $companyId,
            'policy_name'                         => 'Company Overtime Policy',
            'policy_code'                         => 'OVERTIME',
            'salary_basis'                        => (string)$otRule->get('salary_basis'),
            'divisor_mode'                        => $divMode,
            'divisor_days'                        => $divisorDays,
            'standard_daily_hours'                => $divisorHours,
            'divisor_hours'                       => $divisorHours,
            'normal_ot_multiplier'                => $normalMultiplier,
            'normal_multiplier'                   => $normalMultiplier,
            'weekly_off_ot_multiplier'            => $weeklyOffMultiplier,
            'weekly_off_multiplier'               => $weeklyOffMultiplier,
            'holiday_ot_multiplier'               => $holidayMultiplier,
            'holiday_multiplier'                  => $holidayMultiplier,
            'special_ot_multiplier'               => $specialMultiplier,
            'special_multiplier'                  => $specialMultiplier,
            'night_multiplier'                    => $nightMultiplier,
            'min_ot_unit_minutes'                 => (int)$otRule->get('min_ot_unit_minutes'),
            'rounding_mode'                       => (string)$otRule->get('rounding_mode'),
            'daily_threshold_hours'               => (float)$otRule->get('daily_threshold_hours'),
            'max_daily_ot_hours'                  => (float)$otRule->get('max_daily_ot_hours'),
            'max_monthly_ot_hours'                => (float)$otRule->get('max_monthly_ot_hours'),
            'enable_early_arrival_ot'             => $enableEarlyArrival,
            'early_arrival_grace_minutes'         => $earlyGraceMinutes,
            'early_arrival_min_threshold_minutes' => $earlyArrivalMinThreshold,
            'enable_post_shift_ot'                => $enablePostShift,
            'post_shift_grace_minutes'            => $postGraceMinutes,
            'post_shift_min_threshold_minutes'    => $postShiftMinThreshold,
            'enable_daily_ot'                     => !empty($otRule->has('enable_daily_ot') ? $otRule->get('enable_daily_ot') : true) && !$weeklyOtEnabled,
            'weekly_ot_enabled'                   => $weeklyOtEnabled,
            'weekly_required_hours'               => $weeklyOtEnabled ? (float)$otRule->get('weekly_required_hours') : 0.0,
            'weekly_present_days'                 => $weeklyOtEnabled ? (array)$otRule->get('weekly_present_days') : [],
            'weekly_ot_multiplier'                => $weeklyOtEnabled ? (float)$otRule->get('weekly_ot_multiplier') : 0.0,
            'requires_pre_approval'               => !empty($otRule->get('requires_pre_approval')),
            'requires_post_approval'              => !empty($otRule->get('requires_post_approval')),
            'calculation_method'                  => (string)$otRule->get('calculation_method'),
            'conflict_policy'                     => (string)$otRule->get('conflict_policy'),
            'money_decimals'                      => (int)$basicsRule->get('money_decimals'),
            'rules_snapshot_json'                 => json_encode([
                'OVERTIME'       => $otRule->snapshot(),
                'PAYROLL_BASICS' => $basicsRule->snapshot()
            ]),
        ];
    }

    /**
     * Convert HH:MM or HH:MM:SS to total minutes from midnight
     */
    public static function timeToMinutes(?string $timeStr): int
    {
        if (empty($timeStr)) {
            return 0;
        }
        $parts = explode(':', trim($timeStr));
        $h = isset($parts[0]) ? (int)$parts[0] : 0;
        $m = isset($parts[1]) ? (int)$parts[1] : 0;
        return ($h * 60) + $m;
    }

    /**
     * Apply Minimum Counting Unit & Rounding Policy
     */
    public static function applyUnitRounding(int $totalMinutes, int $minUnitMinutes = 15, string $roundingMode = 'Exact'): int
    {
        if ($totalMinutes <= 0) {
            return 0;
        }

        if ($minUnitMinutes <= 1 || $roundingMode === 'exact' || $roundingMode === 'Exact') {
            return $totalMinutes;
        }

        $units = $totalMinutes / $minUnitMinutes;
        $mode = strtolower(str_replace([' ', '-'], '_', $roundingMode));

        switch ($mode) {
            case 'exact':
                return $totalMinutes;
            case 'nearest_15_minutes':
            case 'nearest_15':
                return (int)(round($totalMinutes / 15) * 15);
            case 'nearest_30_minutes':
            case 'nearest_30':
                return (int)(round($totalMinutes / 30) * 30);
            case 'nearest_1_hour':
            case 'nearest_hour':
                return (int)(round($totalMinutes / 60) * 60);
            case 'floor':
            case 'round_down':
                $roundedUnits = floor($units);
                break;
            case 'ceil':
            case 'round_up':
                $roundedUnits = ceil($units);
                break;
            case 'round':
            default:
                $roundedUnits = round($units);
                break;
        }

        return (int)($roundedUnits * $minUnitMinutes);
    }

    /**
     * Authoritatively calculate employee hourly rate based on salary structure
     */
    public function calculateHourlyRate(array $employee, array $policy, ?string $date = null): array
    {
        $employeeId = $employee['id'] ?? '';
        $date = $date ?: date('Y-m-d');

        $baseSalary = 0.00;
        $salaryBasis = $policy['salary_basis'] ?? 'Basic Salary';

        // 1. Try fetching authoritative active salary snapshot
        try {
            $activeSalary = $this->salaryService->getActiveSalary($employeeId, $date);
            if ($activeSalary) {
                if (stripos($salaryBasis, 'gross') !== false) {
                    $baseSalary = (float)($activeSalary['gross_salary'] ?? 0);
                } else {
                    $baseSalary = (float)($activeSalary['basic_salary'] ?? 0);
                }
            }
        } catch (\Throwable $e) {
            // Fallback to employee table
        }

        // 2. Fallback to employee master table if not configured in salary structures
        if ($baseSalary <= 0) {
            if (stripos($salaryBasis, 'gross') !== false) {
                $baseSalary = (float)($employee['gross_salary'] ?? $employee['basic_salary'] ?? 0.00);
            } else {
                $baseSalary = (float)($employee['basic_salary'] ?? 0.00);
            }
        }

        // 3. Divisor Days and Working Hours from policy via DailyRateResolver
        $divisorMode = $policy['divisor_mode'] ?? null;
        $compContext = (string)($employee['company_id'] ?? '');
        if (empty($compContext) && function_exists('session')) {
            try {
                $compContext = (string)(session('selected_company_id') ?: session('company_id') ?: '');
            } catch (\Throwable $e) {}
        }
        $rateInfo = DailyRateResolver::resolve($compContext, $employee, $date, null, $baseSalary, $divisorMode);
        $divisorDays = (float)$rateInfo['divisor_days'];

        if ($divisorDays <= 0) {
            throw new RuleNotConfiguredException("Invalid or zero divisor days in overtime rule calculation.");
        }

        $standardDailyHours = (float)($policy['standard_daily_hours'] ?? ($policy['divisor_hours'] ?? 0.00));
        if ($standardDailyHours <= 0) {
            throw new RuleNotConfiguredException("Invalid or zero standard daily hours in overtime rule calculation.");
        }

        $totalMonthlyHours = $divisorDays * $standardDailyHours;
        $moneyDecimals = isset($policy['money_decimals'])
            ? (int)$policy['money_decimals']
            : Money::decimals($compContext, $employee, $date);
        $hourlyRate = $totalMonthlyHours > 0 ? Money::round($baseSalary / $totalMonthlyHours, $moneyDecimals) : 0.00;

        return [
            'base_salary'          => $baseSalary,
            'salary_basis'         => $salaryBasis,
            'divisor_days'         => $divisorDays,
            'standard_daily_hours' => $standardDailyHours,
            'total_monthly_hours'  => $totalMonthlyHours,
            'hourly_rate'          => $hourlyRate
        ];
    }

    /**
     * Calculate Daily Overtime for a single attendance log or punch set
     *
     * @param array $employee Employee record
     * @param array $attendanceLog Attendance punch details
     * @param array|null $shift Assigned shift details
     * @param array|null $policy Overtime policy
     * @param array $holidays List of holidays for company
     * @return array Calculation breakdown and record payload
     */
    public function calculateDailyOvertime(
        array $employee,
        array $attendanceLog,
        ?array $shift = null,
        ?array $policy = null,
        array $holidays = []
    ): array {
        $companyId  = $employee['company_id'] ?? '';
        if (empty($companyId) && function_exists('session')) {
            try {
                $companyId = (string)(session('selected_company_id') ?: session('company_id') ?: '');
            } catch (\Throwable $e) {}
        }
        $employeeId = $employee['id'] ?? '';
        $date       = $attendanceLog['date'] ?? $attendanceLog['attendance_date'] ?? date('Y-m-d');

        if (empty($policy)) {
            $policy = $this->resolvePolicy(
                $companyId,
                $employee,
                $date
            );
        }

        // 1. Resolve Shift if not passed via Centralized Shift Resolution (P0-004)
        if (empty($shift)) {
            $shiftContext = $employee;
            if (!empty($attendanceLog['shift_id']) && empty($shiftContext['shift_id'])) {
                $shiftContext['shift_id'] = $attendanceLog['shift_id'];
            }
            $shift = $this->shiftModel->resolveEffectiveShift($employeeId, $date, $shiftContext);
        }

        // 2. Resolve Holidays if not passed
        if (empty($holidays) && !empty($companyId)) {
            $holidays = $this->holidayModel
                ->where('company_id', $companyId)
                ->where('status', 'Published')
                ->findAll();
        }

        // 3. Determine Day Type (Special Duty vs Holiday vs Weekly Off vs Normal Workday)
        $dayEval = CompanyWeekendService::evaluateDayType($date, $employee, $shift, $holidays);
        $isHoliday   = !empty($dayEval['is_holiday']);
        $isWeeklyOff = !empty($dayEval['is_weekly_off']);
        $holidayName = $dayEval['holiday_name'] ?? null;

        // Check for Special Duty assignment (single source: DutyAssignmentModel)
        $specialDuty = null;
        if (!empty($employeeId) && !empty($this->dutyModel)) {
            try {
                $duty = $this->dutyModel->getDutyForEmployeeDate($employeeId, $date, $companyId);
                if ($duty && in_array(strtoupper($duty['duty_type'] ?? ''), ['SPECIAL_DUTY', 'EMERGENCY_DUTY'], true)) {
                    $specialDuty = $duty;
                }
            } catch (\Throwable $e) {}
        }
        $isSpecialDuty = ($specialDuty !== null);

        // Shift or employee explicit weekly off check fallback
        if (!$isWeeklyOff && !$isSpecialDuty && !empty($shift)) {
            $dayName = date('l', strtotime($date));
            $shiftWeekends = $shift['weekend_days'] ?? $shift['weekly_off'] ?? null;
            if (!empty($shiftWeekends)) {
                $weekends = is_array($shiftWeekends) ? $shiftWeekends : explode(',', (string)$shiftWeekends);
                $weekends = array_map('trim', $weekends);
                if (in_array($dayName, $weekends, true)) {
                    $isWeeklyOff = true;
                }
            }
        }
        if (!$isWeeklyOff && !$isSpecialDuty && !empty($employee['weekly_off'])) {
            $dayName = date('l', strtotime($date));
            $empWeekends = is_array($employee['weekly_off']) ? $employee['weekly_off'] : explode(',', (string)$employee['weekly_off']);
            $empWeekends = array_map('trim', $empWeekends);
            if (in_array($dayName, $empWeekends, true)) {
                $isWeeklyOff = true;
            }
        }

        // Punches
        $checkInRaw  = $attendanceLog['check_in'] ?? $attendanceLog['in_time'] ?? $attendanceLog['clock_in'] ?? null;
        $checkOutRaw = $attendanceLog['check_out'] ?? $attendanceLog['out_time'] ?? $attendanceLog['clock_out'] ?? null;

        // Clean to HH:MM format
        $actualIn  = !empty($checkInRaw) ? date('H:i', strtotime($checkInRaw)) : null;
        $actualOut = !empty($checkOutRaw) ? date('H:i', strtotime($checkOutRaw)) : null;

        // Shift times
        $shiftStart = $shift['start_time'] ?? null;
        $shiftEnd   = $shift['end_time'] ?? null;
        $shiftStart = !empty($shiftStart) ? date('H:i', strtotime($shiftStart)) : null;
        $shiftEnd   = !empty($shiftEnd) ? date('H:i', strtotime($shiftEnd)) : null;

        // Hourly rate components
        $rateInfo = $this->calculateHourlyRate($employee, $policy, $date);
        $hourlyRate = $rateInfo['hourly_rate'];
        $baseSalary = $rateInfo['base_salary'];

        // Determine multiplier and ot_type from resolved policy (no literal fallbacks)
        if ($isSpecialDuty) {
            $otType     = 'Special Duty';
            $multiplier = (float)($policy['special_multiplier'] ?? ($policy['special_ot_multiplier'] ?? 0.0));
            if ($multiplier <= 0) {
                $multiplier = (float)($policy['holiday_multiplier'] ?? ($policy['holiday_ot_multiplier'] ?? 0.0));
            }
        } elseif ($isHoliday) {
            $otType     = 'Holiday';
            $multiplier = (float)($policy['holiday_multiplier'] ?? ($policy['holiday_ot_multiplier'] ?? 0.0));
        } elseif ($isWeeklyOff || ($shift['outcome'] ?? '') === 'ROSTER_DAY_OFF' || !empty($shift['is_day_off'])) {
            $otType     = 'Weekly Off';
            $multiplier = (float)($policy['weekly_off_multiplier'] ?? ($policy['weekly_off_ot_multiplier'] ?? 0.0));
        } else {
            $otType     = 'Normal';
            $multiplier = (float)($policy['normal_multiplier'] ?? ($policy['normal_ot_multiplier'] ?? 0.0));
        }

        if ($multiplier <= 0) {
            throw new RuleNotConfiguredException("Missing or zero overtime multiplier for {$otType} in company {$companyId}.");
        }

        if (!isset($policy['min_ot_unit_minutes'])) {
            throw new RuleNotConfiguredException("Missing min_ot_unit_minutes in overtime rule for company {$companyId}.");
        }
        $minUnitMinutes  = (int)$policy['min_ot_unit_minutes'];
        $roundingMode    = $policy['rounding_mode'] ?? 'Exact';
        $maxDailyOtHours = (float)($policy['max_daily_ot_hours'] ?? 0.00);

        $moneyDecimals = isset($policy['money_decimals'])
            ? (int)$policy['money_decimals']
            : Money::decimals($companyId, $employee, $date);

        // Employee OT eligibility: DutyAssignment.is_overtime_eligible is the only authoritative source.
        // Unscheduled employees (NO_ASSIGNED_SHIFT) do not automatically create approved OT.
        $isUnscheduled = (($shift['outcome'] ?? '') === 'NO_ASSIGNED_SHIFT' || (isset($shift['is_scheduled']) && !$shift['is_scheduled']));
        $isEligible = !$isUnscheduled && $this->dutyModel->isEmployeeOvertimeEligible($employeeId, $date, $companyId);
        if (!$isEligible) {
            return [
                'company_id'                => $companyId,
                'employee_id'               => $employeeId,
                'attendance_log_id'         => $attendanceLog['id'] ?? null,
                'policy_id'                 => $policy['id'] ?? null,
                'date'                      => $date,
                'ot_type'                   => $otType,
                'shift_id'                  => $shift['id'] ?? null,
                'shift_start'               => $shiftStart,
                'shift_end'                 => $shiftEnd,
                'actual_in'                 => $actualIn,
                'actual_out'                => $actualOut,
                'raw_early_minutes'         => 0,
                'raw_post_minutes'          => 0,
                'raw_total_minutes'         => 0,
                'payable_early_minutes'     => 0,
                'payable_post_minutes'      => 0,
                'payable_total_minutes'     => 0,
                'overtime_hours'            => 0.00,
                'base_salary'               => $baseSalary,
                'hourly_rate'               => $hourlyRate,
                'multiplier'                => $multiplier,
                'ot_rate'                   => Money::round($hourlyRate * $multiplier, $moneyDecimals),
                'ot_amount'                 => 0.00,
                'approval_status'           => 'Not Required',
                'is_settled'                => 0,
                'calculation_metadata_json' => json_encode(['reason' => 'Employee is not eligible for overtime per DutyAssignment.is_overtime_eligible']),
            ];
        }

        $rawEarlyMinutes     = 0;
        $rawPostMinutes      = 0;
        $payableEarlyMinutes = 0;
        $payablePostMinutes  = 0;
        $payableTotalMinutes = 0;
        $overtimeHours       = 0.00;

        // If no check-in or no check-out, no OT can be generated
        if (empty($actualIn) || empty($actualOut)) {
            return [
                'company_id'                => $companyId,
                'employee_id'               => $employeeId,
                'attendance_log_id'         => $attendanceLog['id'] ?? null,
                'policy_id'                 => $policy['id'] ?? null,
                'date'                      => $date,
                'ot_type'                   => $otType,
                'shift_id'                  => $shift['id'] ?? null,
                'shift_start'               => $shiftStart,
                'shift_end'                 => $shiftEnd,
                'actual_in'                 => $actualIn,
                'actual_out'                => $actualOut,
                'raw_early_minutes'         => 0,
                'raw_post_minutes'          => 0,
                'raw_total_minutes'         => 0,
                'payable_early_minutes'     => 0,
                'payable_post_minutes'      => 0,
                'payable_total_minutes'     => 0,
                'overtime_hours'            => 0.00,
                'base_salary'               => $baseSalary,
                'hourly_rate'               => $hourlyRate,
                'multiplier'                => $multiplier,
                'ot_rate'                   => Money::round($hourlyRate * $multiplier, $moneyDecimals),
                'ot_amount'                 => 0.00,
                'approval_status'           => 'Not Required',
                'is_settled'                => 0,
                'calculation_metadata_json' => json_encode(['reason' => 'Missing punch in or out']),
            ];
        }

        $inMins  = self::timeToMinutes($actualIn);
        $outMins = self::timeToMinutes($actualOut);

        // Handle overnight punches
        $effOutMins = $outMins < $inMins ? ($outMins + 1440) : $outMins;
        $totalWorkedMins = $effOutMins - $inMins;

        // Deduct unpaid break if applicable (Single Source of Truth: RuleResolver domain ATTENDANCE)
        $breakMins = 0;
        try {
            if (!empty($companyId)) {
                $attResolved = \App\Services\Rules\RuleResolver::resolveStatic((string)$companyId, 'ATTENDANCE', $date, $employee);
                $attParams = $attResolved->params();
                $breakEnabled = !empty($attParams['break_enabled']) && $attParams['break_enabled'] !== 'false' && $attParams['break_enabled'] !== false && $attParams['break_enabled'] !== 0 && $attParams['break_enabled'] !== '0';
                $breakPaid = !empty($attParams['break_is_paid']);
                $breakAutoDeduct = !isset($attParams['break_auto_deduct']) ? true : (!empty($attParams['break_auto_deduct']));
                if ($breakEnabled && !$breakPaid) {
                    $ruleBreakMins = (int)$attResolved->get('break_duration_minutes');
                    $explicitBreakHours = isset($attendanceLog['break_hours']) && $attendanceLog['break_hours'] !== null && $attendanceLog['break_hours'] !== '' ? (float)$attendanceLog['break_hours'] : null;
                    if ($explicitBreakHours !== null) {
                        $breakMins = (int)round($explicitBreakHours * 60);
                    } elseif ($breakAutoDeduct) {
                        $breakMins = $ruleBreakMins;
                    }
                }
            }
        } catch (\Throwable $e) {
            // Fall back to shift attributes only if rule definition cannot be resolved
            $shiftBreakMins = (int)($shift['break_duration_minutes'] ?? $shift['break_time'] ?? 0);
            $isPaidBreak = !empty($shift['is_paid_break']);
            if (!$isPaidBreak) {
                $breakMins = $shiftBreakMins;
            }
        }

        if ($breakMins > 0 && $totalWorkedMins > $breakMins) {
            $netWorkedMins = $totalWorkedMins - $breakMins;
        } else {
            $netWorkedMins = $totalWorkedMins;
        }

        // Anti-double-counting metrics
        $prevOvernightCheckout = null;
        $overnightOverlapDetected = false;
        $overlapDeductedMins = 0;

        if ($isHoliday || $isWeeklyOff || ($isSpecialDuty && ($specialDuty['ot_treatment'] ?? '') !== 'Hours Beyond Shift as OT')) {
            // Off-Day, Holiday, or Special Duty (all-hours treatment): All worked time counts toward OT
            $rawTotalMinutes = $netWorkedMins;
            $roundedMinutes  = self::applyUnitRounding($rawTotalMinutes, $minUnitMinutes, $roundingMode);
            $payableTotalMinutes = $roundedMinutes;
            $rawPostMinutes  = $rawTotalMinutes;
            $payablePostMinutes = $payableTotalMinutes;
            $overtimeHours   = round($payableTotalMinutes / 60, 2);
        } else {
            // Normal Workday (or Special Duty beyond shift): Evaluate Early Arrival & Post-Shift
            $shiftStartMins = self::timeToMinutes($shiftStart);
            $shiftEndMins   = self::timeToMinutes($shiftEnd);
            $effShiftEndMins = $shiftEndMins <= $shiftStartMins ? ($shiftEndMins + 1440) : $shiftEndMins;

            // Anti-double-counting: Check if previous day's shift was overnight and extended into today
            $prevLog = $attendanceLog['prev_attendance_log'] ?? $attendanceLog['previous_log'] ?? null;
            if (!$prevLog && !empty($employeeId) && !empty($this->attendanceModel)) {
                try {
                    $prevDate = date('Y-m-d', strtotime($date . ' -1 day'));
                    $prevBuilder = $this->attendanceModel
                        ->where('employee_id', $employeeId)
                        ->where('date', $prevDate);
                    if (!empty($companyId)) {
                        $prevBuilder->where('company_id', $companyId);
                    }
                    $prevLog = $prevBuilder->first();
                } catch (\Throwable $e) {}
            }

            if ($prevLog) {
                $prevIn  = $prevLog['check_in'] ?? $prevLog['in_time'] ?? null;
                $prevOut = $prevLog['check_out'] ?? $prevLog['out_time'] ?? null;
                $isPrevOvernight = false;
                if (!empty($prevLog['checkout_date']) && $prevLog['checkout_date'] === $date) {
                    $isPrevOvernight = true;
                } elseif (!empty($prevIn) && !empty($prevOut)) {
                    $pInMins  = self::timeToMinutes($prevIn);
                    $pOutMins = self::timeToMinutes($prevOut);
                    if ($pOutMins < $pInMins) {
                        $isPrevOvernight = true;
                    }
                }

                if ($isPrevOvernight && !empty($prevOut)) {
                    $prevOvernightCheckout = date('H:i', strtotime($prevOut));
                    $prevOutMins = self::timeToMinutes($prevOvernightCheckout);
                    // If today's check-in is earlier than yesterday's overnight checkout:
                    // The time before yesterday's checkout was already worked and accounted for under yesterday's shift/OT!
                    if ($inMins < $prevOutMins) {
                        $overnightOverlapDetected = true;
                        $overlapDeductedMins = $prevOutMins - $inMins;
                    }
                }
            }

            // 1. Early Arrival / Check-in OT Evaluation
            $allowEarlyArrival = !empty($policy['enable_early_arrival_ot']);
            $earlyGrace        = isset($policy['early_arrival_grace_minutes']) ? (int)$policy['early_arrival_grace_minutes'] : 0;
            if (!isset($policy['early_arrival_min_threshold_minutes'])) {
                throw new RuleNotConfiguredException("Missing early_arrival_min_threshold_minutes in overtime policy definition");
            }
            $earlyThreshold    = (int)$policy['early_arrival_min_threshold_minutes'];

            // Effective early check-in cannot start before previous day's overnight checkout
            $effectiveInMins = $inMins;
            if ($overnightOverlapDetected && $prevOvernightCheckout !== null) {
                $prevOutMins = self::timeToMinutes($prevOvernightCheckout);
                $effectiveInMins = max($inMins, $prevOutMins);
            }

            if ($effectiveInMins < $shiftStartMins) {
                $rawEarlyMinutes = $shiftStartMins - $effectiveInMins;
                // Threshold is an ELIGIBILITY condition, not a deduction!
                // Example: early threshold = 30 min. If rawEarlyMinutes >= 30, eligible OT = rawEarlyMinutes (not rawEarlyMinutes - 30).
                if ($allowEarlyArrival && $rawEarlyMinutes >= $earlyThreshold) {
                    $payableEarlyMinutes = max(0, $rawEarlyMinutes - $earlyGrace);
                } else {
                    $payableEarlyMinutes = 0;
                }
            } else {
                $rawEarlyMinutes     = 0;
                $payableEarlyMinutes = 0;
            }

            // 2. Post-Shift / Check-out OT Evaluation
            $allowPostShift = isset($policy['enable_post_shift_ot'])
                ? !empty($policy['enable_post_shift_ot'])
                : true;
            $postGrace     = isset($policy['post_shift_grace_minutes']) ? (int)$policy['post_shift_grace_minutes'] : 0;
            if (!isset($policy['post_shift_min_threshold_minutes']) && !isset($policy['min_ot_minutes_to_qualify'])) {
                throw new RuleNotConfiguredException("Missing post_shift_min_threshold_minutes in overtime policy definition");
            }
            $postThreshold = (int)($policy['post_shift_min_threshold_minutes'] ?? $policy['min_ot_minutes_to_qualify']);

            if ($effOutMins > $effShiftEndMins) {
                $rawPostMinutes = $effOutMins - $effShiftEndMins;
                // Threshold is an ELIGIBILITY condition, not a deduction!
                // Example: shift end 16:00, checkout 17:00, min 30 => eligible OT = 60 minutes (not 30).
                if ($allowPostShift && $rawPostMinutes >= $postThreshold) {
                    $payablePostMinutes = max(0, $rawPostMinutes - $postGrace);
                } else {
                    $payablePostMinutes = 0;
                }
            } else {
                $rawPostMinutes     = 0;
                $payablePostMinutes = 0;
            }

            // Check overall daily OT toggle
            $enableDailyOt = !empty($policy['enable_daily_ot'] ?? true);
            if (!$enableDailyOt) {
                $payableEarlyMinutes = 0;
                $payablePostMinutes  = 0;
            }

            // Raw total and payable total (prevent double-counting between early and post)
            $rawTotalMinutes = $rawEarlyMinutes + $rawPostMinutes;
            $unroundedPayable = $payableEarlyMinutes + $payablePostMinutes;

            // Apply Minimum Unit Counting & Rounding
            $payableTotalMinutes = self::applyUnitRounding($unroundedPayable, $minUnitMinutes, $roundingMode);
            $overtimeHours       = round($payableTotalMinutes / 60, 2);
        }

        // Cap at max daily OT hours if configured
        if ($maxDailyOtHours > 0 && $overtimeHours > $maxDailyOtHours) {
            $overtimeHours = $maxDailyOtHours;
            $payableTotalMinutes = (int)round($overtimeHours * 60);
        }

        $otRate   = Money::round($hourlyRate * $multiplier, $moneyDecimals);
        $otAmount = Money::round($overtimeHours * $otRate, $moneyDecimals);

        // Approval status: Overtime is NEVER auto-approved.
        // It must default to 'Pending' whenever overtime hours are earned (> 0), requiring supervisor sign-off.
        // If 0 overtime hours, status is 'Not Required'.
        // (If requires_post_approval is explicitly set to false/0 in legacy test configurations, allow Approved).
        $requiresPostApproval = !isset($policy['requires_post_approval']) ? true : !empty($policy['requires_post_approval']);
        if ($overtimeHours <= 0) {
            $approvalStatus = 'Not Required';
        } else {
            $approvalStatus = $requiresPostApproval ? 'Pending' : 'Approved';
        }

        $metadata = [
            'day_type'                            => $otType,
            'is_weekly_off'                       => $isWeeklyOff,
            'is_holiday'                          => $isHoliday,
            'holiday_name'                        => $holidayName,
            'is_special_duty'                     => $isSpecialDuty,
            'special_duty_id'                     => $specialDuty['id'] ?? null,
            'special_duty_type'                   => $specialDuty['duty_type'] ?? null,
            'special_duty_treatment'              => $specialDuty['ot_treatment'] ?? null,
            'total_worked_mins'                   => $totalWorkedMins,
            'net_worked_mins'                     => $netWorkedMins,
            'early_ot_allowed'                    => $allowEarlyArrival ?? false,
            'early_threshold_mins'                => $earlyThreshold ?? 0,
            'early_threshold_met'                 => ($rawEarlyMinutes >= ($earlyThreshold ?? 0)),
            'early_grace_mins'                    => $earlyGrace ?? 0,
            'raw_early_minutes'                   => $rawEarlyMinutes,
            'payable_early_minutes'               => $payableEarlyMinutes,
            'post_ot_allowed'                     => $allowPostShift ?? false,
            'post_threshold_mins'                 => $postThreshold ?? 0,
            'post_threshold_met'                  => ($rawPostMinutes >= ($postThreshold ?? 0)),
            'post_grace_mins'                     => $postGrace ?? 0,
            'raw_post_minutes'                    => $rawPostMinutes,
            'payable_post_minutes'                => $payablePostMinutes,
            'raw_total_minutes'                   => $rawTotalMinutes,
            'payable_total_minutes'               => $payableTotalMinutes,
            'overtime_hours'                      => $overtimeHours,
            'threshold_is_eligibility_condition'  => true,
            'anti_double_counting'                => [
                'overnight_overlap_detected' => $overnightOverlapDetected,
                'prev_day_checkout'          => $prevOvernightCheckout,
                'overlap_deducted_minutes'   => $overlapDeductedMins,
                'special_duty_applied'       => $isSpecialDuty,
            ],
            'min_unit_mins'                       => $minUnitMinutes,
            'rounding_mode'                       => $roundingMode,
            'rate_breakdown'                      => $rateInfo,
            'rules_snapshot_json'                 => $policy['rules_snapshot_json'] ?? null,
        ];

        return [
            'company_id'                => $companyId,
            'employee_id'               => $employeeId,
            'attendance_log_id'         => $attendanceLog['id'] ?? null,
            'policy_id'                 => $policy['id'] ?? null,
            'date'                      => $date,
            'ot_type'                   => $otType,
            'shift_id'                  => $shift['id'] ?? null,
            'shift_start'               => $shiftStart,
            'shift_end'                 => $shiftEnd,
            'actual_in'                 => $actualIn,
            'actual_out'                => $actualOut,
            'raw_early_minutes'         => $rawEarlyMinutes,
            'raw_post_minutes'          => $rawPostMinutes,
            'raw_total_minutes'         => $rawTotalMinutes,
            'payable_early_minutes'     => $payableEarlyMinutes,
            'payable_post_minutes'      => $payablePostMinutes,
            'payable_total_minutes'     => $payableTotalMinutes,
            'overtime_minutes'          => $payableTotalMinutes,
            'overtime_hours'            => $overtimeHours,
            'base_salary'               => $baseSalary,
            'hourly_rate'               => $hourlyRate,
            'multiplier'                => $multiplier,
            'ot_rate'                   => $otRate,
            'ot_amount'                 => $otAmount,
            'approval_status'           => $approvalStatus,
            'is_settled'                => 0,
            'rules_snapshot_json'       => $policy['rules_snapshot_json'] ?? null,
            'calculation_metadata_json' => json_encode($metadata),
        ];
    }

    /**
     * Authoritatively calculate and persist overtime records for an employee across a date range
     *
     * Idempotent:
     * - Preserves approved/rejected status unless explicitly forced.
     * - STRICTLY REFUSES to modify any record where is_settled = 1.
     */
    public function calculateForEmployeeRange(
        string $employeeId,
        string $startDate,
        string $endDate,
        ?string $companyId = null,
        bool $persist = true
    ): array {
        $employee = $this->empModel->find($employeeId);
        if (!$employee) {
            throw new \InvalidArgumentException("Employee not found: {$employeeId}");
        }

        $effectiveCompanyId = $companyId ?: ($employee['company_id'] ?? '');
        if (empty($effectiveCompanyId)) {
            throw new \InvalidArgumentException("Company ID is required for employee calculation.");
        }

        $policy = $this->resolvePolicy(
            $effectiveCompanyId,
            $employee,
            $startDate
        );

        // Fetch shifts and holidays for company
        $holidays = $this->holidayModel
            ->where('company_id', $effectiveCompanyId)
            ->where('status', 'Published')
            ->findAll();

        // Fetch attendance logs in date range
        $logs = $this->attendanceModel
            ->where('employee_id', $employeeId)
            ->where('company_id', $effectiveCompanyId)
            ->where('date >=', $startDate)
            ->where('date <=', $endDate)
            ->findAll();

        $logsByDate = [];
        foreach ($logs as $l) {
            $logsByDate[$l['date']] = $l;
        }

        $results = [];
        $current = strtotime($startDate);
        $last    = strtotime($endDate);

        while ($current <= $last) {
            $d = date('Y-m-d', $current);
            $log = $logsByDate[$d] ?? ['date' => $d];

            $calc = $this->calculateDailyOvertime($employee, $log, null, $policy, $holidays);

            if ($persist && $calc['overtime_hours'] > 0) {
                $savedRecord = $this->persistRecord($calc);
                $results[] = $savedRecord;
            } else {
                $results[] = $calc;
            }

            $current = strtotime('+1 day', $current);
        }

        if (!empty($policy['weekly_ot_enabled'])) {
            try {
                $wsIdx = $this->weekStartIndex($effectiveCompanyId, $startDate, $employee);
                if ($wsIdx === null) {
                    throw new RuleNotConfiguredException('ATTENDANCE week_start_day is required for weekly overtime.');
                }
                $cursor = strtotime($startDate);
                while ((int)date('w', $cursor) !== $wsIdx) {
                    $cursor = strtotime('-1 day', $cursor);
                }
                for (; $cursor <= $last; $cursor = strtotime('+7 days', $cursor)) {
                    $wk = $this->calculateWeeklyOvertime($employee, $policy, date('Y-m-d', $cursor), $persist);
                    if ($wk) {
                        $results[] = $wk;
                    }
                }
            } catch (\Throwable $e) {
                log_message('error', "Weekly OT failed for {$employee['id']}: " . $e->getMessage());
            }
        }

        return $results;
    }

    private function weekStartIndex(string $companyId, string $date, array $scopes): ?int
    {
        $rule = RuleResolver::resolve($companyId, 'ATTENDANCE', $date, $scopes);
        $name = $rule->has('week_start_day') ? (string)$rule->get('week_start_day') : '';
        $i = array_search($name, ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'], true);
        return $i === false ? null : $i;
    }

    /**
     * Weekly OT = net hours worked on present days in the week - required weekly hours.
     * Auto-approved. One record per employee per week (ot_type = 'Weekly').
     */
    public function calculateWeeklyOvertime(array $employee, array $policy, string $weekStart, bool $persist = true): ?array
    {
        $companyId  = (string)($employee['company_id'] ?? '');
        $employeeId = (string)($employee['id'] ?? '');
        $weekEnd    = date('Y-m-d', strtotime($weekStart . ' +6 days'));
        $required   = (float)($policy['weekly_required_hours'] ?? 0);
        $present    = (array)($policy['weekly_present_days'] ?? []);
        if (empty($policy['weekly_ot_enabled']) || $required <= 0 || empty($present)) {
            return null;
        }

        $weekly = $this->recordModel->where('employee_id', $employeeId)->where('ot_type', 'Weekly')
            ->where('date >=', $weekStart)->where('date <=', $weekEnd)->findAll();
        foreach ($weekly as $w) {
            if (!empty($w['is_settled'])) {
                return $w; // settled records are immutable
            }
        }

        // Dates already carrying another OT record (holiday / off-day / special) are paid there
        $others = $this->recordModel->where('employee_id', $employeeId)->where('ot_type !=', 'Weekly')
            ->where('date >=', $weekStart)->where('date <=', $weekEnd)->findAll();
        $busy = array_flip(array_column($others, 'date'));

        $presentDates = [];
        for ($d = strtotime($weekStart); $d <= strtotime($weekEnd); $d = strtotime('+1 day', $d)) {
            if (in_array(date('l', $d), $present, true)) {
                $presentDates[] = date('Y-m-d', $d);
            }
        }

        $logs = $this->attendanceModel->where('employee_id', $employeeId)->where('company_id', $companyId)
            ->where('date >=', $weekStart)->where('date <=', $weekEnd)->findAll();
        $worked = 0.0;
        foreach ($logs as $l) {
            if (!in_array($l['date'], $presentDates, true) || isset($busy[$l['date']])) {
                continue;
            }
            if (empty($l['check_out']) || $l['check_out'] === '00:00:00') {
                continue;
            }
            $worked += (float)(!empty($l['net_hours']) ? $l['net_hours'] : ($l['working_hours'] ?? 0));
        }

        $rawMinutes = (int)round(max(0.0, $worked - $required) * 60);
        $unit       = max(1, (int)($policy['min_ot_unit_minutes'] ?? 1));
        $payable    = self::applyUnitRounding($rawMinutes, $unit, (string)($policy['rounding_mode'] ?? 'Exact'));
        $hours      = round($payable / 60, 2);

        if ($persist) {
            foreach ($weekly as $w) {
                $this->recordModel->delete($w['id']); // idempotent recompute
            }
        }
        if ($hours <= 0) {
            return null;
        }

        $recordDate = null;
        foreach (array_reverse($presentDates) as $d) {
            if (!isset($busy[$d])) {
                $recordDate = $d;
                break;
            }
        }
        if ($recordDate === null) {
            log_message('warning', "Weekly OT: no free date for {$employeeId} week {$weekStart}");
            return null;
        }

        $mult = (float)($policy['weekly_ot_multiplier'] ?? 0);
        if ($mult <= 0) {
            throw new RuleNotConfiguredException('Weekly OT multiplier is missing or zero.');
        }
        $rate     = $this->calculateHourlyRate($employee, $policy, $recordDate);
        $decimals = (int)($policy['money_decimals'] ?? 2);
        $otRate   = Money::round($rate['hourly_rate'] * $mult, $decimals);
        $now      = date('Y-m-d H:i:s');

        $calc = [
            'company_id'                => $companyId,
            'employee_id'               => $employeeId,
            'attendance_log_id'         => null,
            'policy_id'                 => $policy['id'] ?? null,
            'date'                      => $recordDate,
            'ot_type'                   => 'Weekly',
            'raw_total_minutes'         => $rawMinutes,
            'payable_total_minutes'     => $payable,
            'overtime_minutes'          => $payable,
            'overtime_hours'            => $hours,
            'base_salary'               => $rate['base_salary'],
            'hourly_rate'               => $rate['hourly_rate'],
            'multiplier'                => $mult,
            'ot_rate'                   => $otRate,
            'ot_amount'                 => Money::round($hours * $otRate, $decimals),
            'approval_status'           => 'Approved',
            'approved_by'               => 'SYSTEM_WEEKLY_OT',
            'approved_at'               => $now,
            'is_settled'                => 0,
            'rules_snapshot_json'       => $policy['rules_snapshot_json'] ?? null,
            'calculation_metadata_json' => json_encode([
                'week_start' => $weekStart, 'week_end' => $weekEnd,
                'worked_hours' => round($worked, 2), 'required_hours' => $required,
            ]),
        ];

        return $persist ? $this->persistRecord($calc) : $calc;
    }

    /**
     * Persist an Overtime Record safely with idempotency and lock protection
     */
    public function persistRecord(array $calc): array
    {
        $employeeId = $calc['employee_id'];
        $date       = $calc['date'];
        $otType     = $calc['ot_type'];

        // Check if an existing record already exists for this employee on this date
        // Strictly prevent duplicate overtime counting: query by employee_id + date
        $existing = $this->recordModel
            ->where('employee_id', $employeeId)
            ->where('date', $date)
            ->first();

        if ($existing) {
            if (!empty($existing['is_settled'])) {
                // IMMUTABLE: Never touch settled records
                return $existing;
            }

            // Preserve existing approval status if it was already explicitly approved or rejected
            if (in_array($existing['approval_status'], ['Approved', 'Rejected'])) {
                $calc['approval_status'] = $existing['approval_status'];
                $calc['approved_by']     = $existing['approved_by'];
                $calc['approved_at']     = $existing['approved_at'];
                $calc['rejection_reason'] = $existing['rejection_reason'];
            }

            $calc['id'] = $existing['id'];
            $calc['updated_at'] = date('Y-m-d H:i:s');
            $this->recordModel->update($existing['id'], $calc);
            $saved = array_merge($existing, $calc);

            // Clean up any stray duplicate non-settled records for the same employee and date
            try {
                $this->recordModel
                    ->where('employee_id', $employeeId)
                    ->where('date', $date)
                    ->where('id !=', $existing['id'])
                    ->where('is_settled', 0)
                    ->delete();
            } catch (\Throwable $e) {
                // Ignore cleanup errors
            }
        } else {
            $calc['id'] = 'otrec-' . bin2hex(random_bytes(8));
            $calc['created_at'] = date('Y-m-d H:i:s');
            $calc['updated_at'] = date('Y-m-d H:i:s');
            $this->recordModel->insert($calc);
            $saved = $calc;
        }

        // Sync with attendance_logs if attendance_log_id exists
        if (!empty($calc['attendance_log_id'])) {
            try {
                $this->attendanceModel->update($calc['attendance_log_id'], [
                    'overtime_hours'     => $calc['overtime_hours'],
                    'ot_amount'          => $calc['ot_amount'],
                    'ot_approval_status' => $calc['approval_status'],
                    'is_ot_payable'      => $calc['approval_status'] === 'Approved' ? 1 : 0
                ]);
            } catch (\Throwable $e) {
                // Ignore sync errors
            }
        }

        return $saved;
    }

    /**
     * Batch calculate overtime for all employees in a company/branch/department
     */
    public function calculateForCompanyRange(
        string $companyId,
        string $startDate,
        string $endDate,
        ?string $branchId = null,
        ?string $departmentId = null
    ): array {
        $builder = $this->empModel
            ->where('company_id', $companyId)
            ->where('status', \App\Models\EmployeeModel::STATUS_ACTIVE);

        if (!empty($branchId)) {
            $builder->where('branch_id', $branchId);
        }
        if (!empty($departmentId)) {
            $builder->where('department_id', $departmentId);
        }

        $employees = $builder->findAll();
        $totalCalculated = 0;
        $totalHours      = 0.00;
        $totalAmount     = 0.00;
        $allRecords      = [];

        foreach ($employees as $emp) {
            $records = $this->calculateForEmployeeRange($emp['id'], $startDate, $endDate, $companyId, true);
            foreach ($records as $r) {
                if (($r['overtime_hours'] ?? 0) > 0) {
                    $totalCalculated++;
                    $totalHours  += (float)$r['overtime_hours'];
                    $totalAmount += (float)$r['ot_amount'];
                    $allRecords[] = $r;
                }
            }
        }

        $moneyDecimals = Money::decimals($companyId, null, $startDate);

        return [
            'success'          => true,
            'total_employees'  => count($employees),
            'total_records'    => $totalCalculated,
            'total_hours'      => round($totalHours, 2),
            'total_amount'     => Money::round($totalAmount, $moneyDecimals),
            'records'          => $allRecords,
        ];
    }

    /**
     * Approve an Overtime Record
     */
    public function approveRecord(string $recordId, string $approverId, ?string $companyId = null): bool
    {
        $builder = $this->recordModel->where('id', $recordId);
        if (!empty($companyId)) {
            $builder->where('company_id', $companyId);
        }
        $record = $builder->first();
        if (!$record) {
            return false;
        }

        if (!empty($record['is_settled'])) {
            throw new \RuntimeException("Cannot approve a settled overtime record.");
        }

        $updated = $this->recordModel->update($recordId, [
            'approval_status'  => 'Approved',
            'approved_by'      => $approverId,
            'approved_at'      => date('Y-m-d H:i:s'),
            'rejection_reason' => null,
            'updated_at'       => date('Y-m-d H:i:s')
        ]);

        if ($updated) {
            try {
                (new \App\Services\AuditService())->log(
                    $approverId,
                    'overtime',
                    'approve',
                    $recordId,
                    ['approval_status' => $record['approval_status'] ?? 'Pending'],
                    ['approval_status' => 'Approved', 'approved_by' => $approverId],
                    null,
                    null,
                    "Approved overtime record {$recordId} for employee {$record['employee_id']} on date {$record['date']} ({$record['overtime_hours']} hours)"
                );
            } catch (\Throwable $e) {}
        }

        if ($updated && !empty($record['attendance_log_id'])) {
            try {
                $this->attendanceModel->update($record['attendance_log_id'], [
                    'ot_approval_status' => 'Approved',
                    'is_ot_payable'      => 1
                ]);
            } catch (\Throwable $e) {}
        }

        return (bool)$updated;
    }

    /**
     * Reject an Overtime Record
     */
    public function rejectRecord(string $recordId, string $approverId, string $reason, ?string $companyId = null): bool
    {
        $builder = $this->recordModel->where('id', $recordId);
        if (!empty($companyId)) {
            $builder->where('company_id', $companyId);
        }
        $record = $builder->first();
        if (!$record) {
            return false;
        }

        if (!empty($record['is_settled'])) {
            throw new \RuntimeException("Cannot reject a settled overtime record.");
        }

        $updated = $this->recordModel->update($recordId, [
            'approval_status'  => 'Rejected',
            'approved_by'      => $approverId,
            'approved_at'      => date('Y-m-d H:i:s'),
            'rejection_reason' => $reason,
            'updated_at'       => date('Y-m-d H:i:s')
        ]);

        if ($updated) {
            try {
                (new \App\Services\AuditService())->log(
                    $approverId,
                    'overtime',
                    'reject',
                    $recordId,
                    ['approval_status' => $record['approval_status'] ?? 'Pending'],
                    ['approval_status' => 'Rejected', 'rejected_by' => $approverId, 'rejection_reason' => $reason],
                    null,
                    null,
                    "Rejected overtime record {$recordId} for employee {$record['employee_id']} on date {$record['date']} (Reason: {$reason})"
                );
            } catch (\Throwable $e) {}
        }

        if ($updated && !empty($record['attendance_log_id'])) {
            try {
                $this->attendanceModel->update($record['attendance_log_id'], [
                    'ot_approval_status' => 'Rejected',
                    'is_ot_payable'      => 0
                ]);
            } catch (\Throwable $e) {}
        }

        return (bool)$updated;
    }

    /**
     * Get Authoritative Overtime Summary for an employee in a payroll month
     * Used by PayrollService to inject into gross pay
     */
    /**
     * Get Authoritative Overtime Summary for an employee in a payroll month
     * Used by PayrollService to inject into gross pay
     * Strictly includes Approved records only, excludes records settled in other batches, and deduplicates by date.
     */
    public function getSummaryForPayroll(string $employeeId, string $month, string $companyId, ?string $payrollId = null): array
    {
        $startDate = "{$month}-01";
        $endDate   = date('Y-m-t', strtotime($startDate));

        $records = $this->recordModel
            ->where('employee_id', $employeeId)
            ->where('company_id', $companyId)
            ->where('date >=', $startDate)
            ->where('date <=', $endDate)
            ->where('approval_status', 'Approved')
            ->orderBy('date', 'ASC')
            ->orderBy('id', 'DESC')
            ->findAll();

        $totalHours   = 0.00;
        $totalMinutes = 0;
        $totalAmount  = 0.00;
        $recordIds    = [];
        $seenDates    = [];

        foreach ($records as $r) {
            // Defense-in-depth: Never count non-approved records
            if (($r['approval_status'] ?? '') !== 'Approved') {
                continue;
            }

            // Exclude records already settled in a different payroll batch
            if (!empty($r['is_settled']) && !empty($r['payroll_id']) && !empty($payrollId) && $r['payroll_id'] !== $payrollId) {
                continue;
            }

            // Deduplicate duplicate records on the same date for this employee
            $rDate = $r['date'] ?? '';
            if ($rDate !== '' && isset($seenDates[$rDate])) {
                continue;
            }
            if ($rDate !== '') {
                $seenDates[$rDate] = true;
            }

            $hrs = (float)($r['overtime_hours'] ?? 0);
            $mins = (int)($r['payable_total_minutes'] ?? round($hrs * 60));
            $totalHours   += $hrs;
            $totalMinutes += $mins;
            $totalAmount  += (float)($r['ot_amount'] ?? 0);
            $recordIds[]  = $r['id'];
        }

        $moneyDecimals = Money::decimals($companyId, null, $startDate);

        return [
            'employee_id'      => $employeeId,
            'month'            => $month,
            'approved_minutes' => $totalMinutes,
            'approved_hours'   => round($totalHours, 2),
            'ot_amount'        => Money::round($totalAmount, $moneyDecimals),
            'record_ids'       => $recordIds,
            'record_count'     => count($recordIds),
        ];
    }

    /**
     * Get Authoritative Bulk Overtime Summaries for multiple employees in a payroll month
     * Executes one query grouped by employee for high-performance batch processing
     * Strictly includes Approved records only, excludes records settled in other batches, and deduplicates by (employee_id, date).
     */
    public function getBulkSummaryForPayroll(array $employeeIds, string $month, ?string $companyId = null, ?string $payrollId = null): array
    {
        $result = [];
        if (empty($employeeIds)) {
            return $result;
        }

        // Initialize zero default summary for every employee in the batch
        foreach ($employeeIds as $eId) {
            $result[$eId] = [
                'employee_id'      => $eId,
                'month'            => $month,
                'approved_minutes' => 0,
                'approved_hours'   => 0.00,
                'ot_amount'        => 0.00,
                'record_ids'       => [],
                'record_count'     => 0,
            ];
        }

        $startDate = "{$month}-01";
        $endDate   = date('Y-m-t', strtotime($startDate));

        $builder = $this->recordModel
            ->whereIn('employee_id', $employeeIds)
            ->where('date >=', $startDate)
            ->where('date <=', $endDate)
            ->where('approval_status', 'Approved')
            ->orderBy('date', 'ASC')
            ->orderBy('id', 'DESC');

        if (!empty($companyId)) {
            $builder->where('company_id', $companyId);
        }

        $records = $builder->findAll();
        $moneyDecimals = !empty($companyId) ? Money::decimals($companyId, null, $startDate) : null;
        $seenByEmpDate = [];

        foreach ($records as $r) {
            $eId = $r['employee_id'] ?? null;
            if (!$eId || !isset($result[$eId])) {
                continue;
            }

            // Defense-in-depth: Never count non-approved records
            if (($r['approval_status'] ?? '') !== 'Approved') {
                continue;
            }

            // Exclude records already settled in another payroll batch
            if (!empty($r['is_settled']) && !empty($r['payroll_id']) && !empty($payrollId) && $r['payroll_id'] !== $payrollId) {
                continue;
            }

            // Deduplicate duplicate records on the same date for the same employee
            $rDate = $r['date'] ?? '';
            $empDateKey = $eId . '|' . $rDate;
            if ($rDate !== '' && isset($seenByEmpDate[$empDateKey])) {
                continue;
            }
            if ($rDate !== '') {
                $seenByEmpDate[$empDateKey] = true;
            }

            $recDecimals = $moneyDecimals ?? Money::decimals((string)($r['company_id'] ?? ''), null, $startDate);
            $hrs = (float)($r['overtime_hours'] ?? 0);
            $mins = (int)($r['payable_total_minutes'] ?? round($hrs * 60));
            $result[$eId]['approved_hours']   = round($result[$eId]['approved_hours'] + $hrs, 2);
            $result[$eId]['approved_minutes'] = (int)($result[$eId]['approved_minutes'] + $mins);
            $result[$eId]['ot_amount']        = Money::round($result[$eId]['ot_amount'] + (float)($r['ot_amount'] ?? 0), $recDecimals);
            $result[$eId]['record_ids'][]     = $r['id'];
            $result[$eId]['record_count']++;
        }

        return $result;
    }

    /**
     * Revert Overtime Settlement Lock when a payroll batch is unlocked or draft regenerated
     */
    public function revertOvertimeSettlement(string $payrollId, ?string $companyId = null): void
    {
        $this->db->transStart();

        $builder = $this->recordModel->where('payroll_id', $payrollId);
        if (!empty($companyId)) {
            $builder->where('company_id', $companyId);
        }
        $records = $builder->findAll();

        foreach ($records as $r) {
            $this->recordModel->update($r['id'], [
                'is_settled' => 0,
                'payroll_id' => null,
                'settled_at' => null,
                'updated_at' => date('Y-m-d H:i:s')
            ]);

            if (!empty($r['attendance_log_id'])) {
                try {
                    $this->attendanceModel->update($r['attendance_log_id'], [
                        'is_settled' => 0
                    ]);
                } catch (\Throwable $e) {}
            }
        }

        if ($this->db->tableExists('attendance_logs')) {
            try {
                $this->db->query("
                    UPDATE attendance_logs
                    SET is_settled = 0, payroll_item_id = NULL
                    WHERE payroll_item_id IN (
                        SELECT id FROM payroll_items WHERE payroll_id = ?
                    )
                ", [$payrollId]);
            } catch (\Throwable $e) {}
        }

        if ($this->lockModel) {
            try {
                $lockBuilder = $this->lockModel->where('payroll_id', $payrollId);
                if (!empty($companyId)) {
                    $lockBuilder->where('company_id', $companyId);
                }
                $lockBuilder->delete();
            } catch (\Throwable $e) {}
        }

        $this->db->transComplete();
    }

    /**
     * Hard-Lock and Settle Overtime records when payroll is generated
     * Guarantees that historical OT cannot be altered after payroll processing
     */
    public function settleOvertimeForPayroll(
        string $payrollId,
        string $month,
        string $companyId,
        string $userId
    ): array {
        $startDate = "{$month}-01";
        $endDate   = date('Y-m-t', strtotime($startDate));

        // 1. Get all approved records for the month
        $records = $this->recordModel
            ->where('company_id', $companyId)
            ->where('date >=', $startDate)
            ->where('date <=', $endDate)
            ->where('approval_status', 'Approved')
            ->where('is_settled', 0)
            ->findAll();

        $totalRecords = count($records);
        $totalHours   = 0.00;
        $totalAmount  = 0.00;

        $now = date('Y-m-d H:i:s');

        $this->db->transStart();

        foreach ($records as $r) {
            $totalHours  += (float)$r['overtime_hours'];
            $totalAmount += (float)$r['ot_amount'];

            $this->recordModel->update($r['id'], [
                'is_settled' => 1,
                'payroll_id' => $payrollId,
                'settled_at' => $now,
                'updated_at' => $now
            ]);

            if (!empty($r['attendance_log_id'])) {
                try {
                    $this->attendanceModel->update($r['attendance_log_id'], [
                        'is_settled' => 1
                    ]);
                } catch (\Throwable $e) {}
            }
        }

        // 2. Create Cryptographic Settlement Lock
        $moneyDecimals = Money::decimals($companyId, null, $startDate);
        $lockPayload = "{$companyId}|{$payrollId}|{$month}|{$totalRecords}|{$totalHours}|{$totalAmount}|{$now}";
        $lockHash    = hash('sha256', $lockPayload);

        $lockId = 'otlock-' . bin2hex(random_bytes(8));
        $lockData = [
            'id'            => $lockId,
            'company_id'    => $companyId,
            'payroll_id'    => $payrollId,
            'payroll_month' => $month,
            'total_records' => $totalRecords,
            'total_hours'   => round($totalHours, 2),
            'total_amount'  => Money::round($totalAmount, $moneyDecimals),
            'locked_by'     => $userId,
            'locked_at'     => $now,
            'lock_hash'     => $lockHash,
            'created_at'    => $now,
            'updated_at'    => $now
        ];

        // Use insert or update if already locked
        $existingLock = $this->lockModel
            ->where('company_id', $companyId)
            ->where('payroll_month', $month)
            ->first();

        if ($existingLock) {
            $this->lockModel->update($existingLock['id'], $lockData);
        } else {
            $this->lockModel->insert($lockData);
        }

        $this->db->transComplete();

        return [
            'success'       => $this->db->transStatus(),
            'total_records' => $totalRecords,
            'total_hours'   => round($totalHours, 2),
            'total_amount'  => Money::round($totalAmount, $moneyDecimals),
            'lock_hash'     => $lockHash,
        ];
    }

    /**
     * Check if a payroll month is hard-locked for a company
     */
    public function isMonthLocked(string $companyId, string $month): bool
    {
        return $this->lockModel->isMonthLocked($companyId, $month);
    }

    /**
     * Submit an Overtime Claim (Employee self-service or supervisor)
     */
    public function submitClaim(array $data): array
    {
        // Enforce DutyAssignment.is_overtime_eligible as single authoritative source
        $isEligible = $this->dutyModel->isEmployeeOvertimeEligible($data['employee_id'], $data['date'] ?? null, $data['company_id'] ?? null);
        if (!$isEligible) {
            throw new \InvalidArgumentException("Employee is not eligible for overtime per DutyAssignment.is_overtime_eligible.");
        }

        $id = 'otclm-' . bin2hex(random_bytes(8));
        $now = date('Y-m-d H:i:s');

        $claim = [
            'id'                 => $id,
            'company_id'         => $data['company_id'],
            'employee_id'        => $data['employee_id'],
            'overtime_record_id' => $data['overtime_record_id'] ?? null,
            'date'               => $data['date'],
            'ot_type'            => $data['ot_type'] ?? 'Post-Shift',
            'requested_hours'    => (float)($data['requested_hours'] ?? 0),
            'approved_hours'     => null,
            'reason'             => $data['reason'] ?? '',
            'status'             => 'Pending',
            'reviewed_by'        => null,
            'reviewed_at'        => null,
            'rejection_reason'   => null,
            'created_at'         => $now,
            'updated_at'         => $now
        ];

        $this->claimModel->insert($claim);
        return $claim;
    }

    /**
     * Review an Overtime Claim (Approve / Reject)
     */
    public function reviewClaim(
        string $claimId,
        string $reviewerId,
        string $action,
        ?float $approvedHours = null,
        ?string $reason = null,
        ?string $companyId = null
    ): bool {
        $builder = $this->claimModel->where('id', $claimId);
        if ($companyId) {
            $builder->where('company_id', $companyId);
        }
        $claim = $builder->first();
        if (!$claim) {
            return false;
        }
        // A decided claim cannot be flipped later (payroll integrity)
        if (strcasecmp((string)($claim['status'] ?? 'Pending'), 'Pending') !== 0) {
            return false;
        }

        $now = date('Y-m-d H:i:s');
        $status = strtolower($action) === 'approve' ? 'Approved' : 'Rejected';

        $update = [
            'status'           => $status,
            'reviewed_by'      => $reviewerId,
            'reviewed_at'      => $now,
            'rejection_reason' => $status === 'Rejected' ? $reason : null,
            'approved_hours'   => $status === 'Approved' ? ($approvedHours ?? $claim['requested_hours']) : 0.00,
            'updated_at'       => $now
        ];

        $res = $this->claimModel->update($claimId, $update);

        // If linked to an overtime_record, update record approval as well
        if ($res && !empty($claim['overtime_record_id'])) {
            if ($status === 'Approved') {
                $this->approveRecord($claim['overtime_record_id'], $reviewerId, $companyId);
            } else {
                $this->rejectRecord($claim['overtime_record_id'], $reviewerId, $reason ?: 'Claim rejected', $companyId);
            }
        }

        return (bool)$res;
    }
}
