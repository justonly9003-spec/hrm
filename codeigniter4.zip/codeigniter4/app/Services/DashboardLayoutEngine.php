<?php

namespace App\Services;

/**
 * DashboardLayoutEngine
 * 
 * Central layout calculation service for the unified dashboard.
 * Dynamically resolves:
 * - Order & Position
 * - Width (full, two_thirds, half, third, quarter)
 * - Height & Size (auto, sm, md, lg)
 * - Visibility
 * - Responsive Tailwind breakpoints (mobile -> tablet -> desktop)
 */
class DashboardLayoutEngine
{
    /**
     * Build layout specifications for active authorized widgets
     * 
     * @param array $widgets List of authorized active widget definitions
     * @param array $configurations Resolved configuration map (keyed by widget ID or code)
     * @return array Layout structure with ordered widgets, responsive classes, and container specs
     */
    public function buildLayout(array $widgets, array $configurations = []): array
    {
        $orderedWidgets = [];
        $widgetClasses  = [];

        foreach ($widgets as $widget) {
            $widgetId = $widget['id'] ?? '';
            $code = $widget['code'] ?? '';

            // Retrieve configuration with fallback to widget defaults
            $cfg = $configurations[$widgetId] ?? $configurations[$code] ?? $widget;

            // Check visibility
            $status = (int)($cfg['status'] ?? $widget['status'] ?? 1);
            $isVisible = isset($cfg['is_visible']) ? (int)$cfg['is_visible'] : $status;
            if ($status === 0 || $isVisible === 0) {
                continue; // Widget is OFF or Hidden - do not include in layout
            }

            $sortOrder = (int)($cfg['sort_order'] ?? $widget['sort_order'] ?? 0);
            $position  = (int)($cfg['position'] ?? $sortOrder);
            $gridWidth = (string)($cfg['grid_width'] ?? $widget['grid_width'] ?? 'half');
            $gridHeight= (string)($cfg['grid_height'] ?? $widget['grid_height'] ?? 'auto');

            // Responsive grid column spans (12-column grid)
            // Mobile (< 768px): always col-span-12 (stacked, easy touch targets)
            // Tablet (md: 768px - 1024px): 2 columns (col-span-6 or 12)
            // Desktop (lg: 1024px+): full fractional flexibility
            $colSpanClass = $this->resolveColSpanClass($gridWidth);
            $heightClass  = $this->resolveHeightClass($gridHeight);

            $combinedClass = trim("{$colSpanClass} {$heightClass} transition-all duration-200");

            $widgetClasses[$widgetId] = $combinedClass;
            $widgetClasses[$code]     = $combinedClass;

            $widget['resolved_position']  = $position;
            $widget['resolved_sort_order']= $sortOrder;
            $widget['resolved_grid_width']= $gridWidth;
            $widget['resolved_grid_height']= $gridHeight;
            $widget['layout_class']       = $combinedClass;

            $orderedWidgets[] = $widget;
        }

        // Sort widgets dynamically by position, then sort_order, then title
        usort($orderedWidgets, function ($a, $b) {
            if ($a['resolved_position'] !== $b['resolved_position']) {
                return $a['resolved_position'] <=> $b['resolved_position'];
            }
            if ($a['resolved_sort_order'] !== $b['resolved_sort_order']) {
                return $a['resolved_sort_order'] <=> $b['resolved_sort_order'];
            }
            return strcmp($a['title'] ?? '', $b['title'] ?? '');
        });

        return [
            'container_class' => 'grid grid-cols-12 gap-6 w-full',
            'ordered_widgets' => $orderedWidgets,
            'widget_classes'  => $widgetClasses,
            'total_visible'   => count($orderedWidgets),
        ];
    }

    /**
     * Map width string to 12-column responsive CSS classes
     */
    public function resolveColSpanClass(string $gridWidth): string
    {
        switch (strtolower(trim($gridWidth))) {
            case 'full':
            case '12':
            case 'col-12':
                return 'col-span-12';

            case 'two_thirds':
            case '2/3':
            case '8':
            case 'col-8':
                return 'col-span-12 lg:col-span-8';

            case 'third':
            case '1/3':
            case '4':
            case 'col-4':
                return 'col-span-12 md:col-span-6 lg:col-span-4';

            case 'quarter':
            case '1/4':
            case '3':
            case 'col-3':
                return 'col-span-12 sm:col-span-6 lg:col-span-3';

            case 'half':
            case '1/2':
            case '6':
            case 'col-6':
            default:
                return 'col-span-12 md:col-span-6 lg:col-span-6';
        }
    }

    /**
     * Map height / size string to responsive height CSS classes
     */
    public function resolveHeightClass(string $gridHeight): string
    {
        switch (strtolower(trim($gridHeight))) {
            case 'sm':
            case 'small':
                return 'min-h-[160px]';

            case 'md':
            case 'medium':
                return 'min-h-[300px]';

            case 'lg':
            case 'large':
                return 'min-h-[460px]';

            case 'auto':
            default:
                return '';
        }
    }
}
