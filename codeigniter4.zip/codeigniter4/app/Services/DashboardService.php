<?php

namespace App\Services;

use Config\Database;
use App\Models\DashboardWidgetModel;
use App\Models\DashboardRoleWidgetModel;
use App\Models\DashboardCompanyWidgetModel;
use App\Models\EmployeeModel;
use App\Models\AttendanceModel;
use App\Models\LeaveModel;
use App\Models\NoticeModel;
use App\Models\DepartmentModel;
use App\Models\BranchModel;
use App\Models\CompanyModel;
use App\Models\HolidayModel;
use App\Models\PayrollModel;
use App\Models\AuditLogModel;
use App\Models\UserModel;
use App\Models\RoleModel;
use App\Services\PermissionService;
use App\Services\LeaveService;
use App\Services\AuditService;

class DashboardService
{
    protected $db;
    protected $permissionService;
    protected $auditService;
    protected $widgetModel;
    protected $roleWidgetModel;
    protected $companyWidgetModel;
    protected $widgetAssignmentModel;

    public function __construct()
    {
        $this->db = Database::connect();
        $this->permissionService = new PermissionService();
        $this->auditService = new AuditService();

        $this->widgetModel = new DashboardWidgetModel();
        $this->roleWidgetModel = new DashboardRoleWidgetModel();
        $this->companyWidgetModel = new DashboardCompanyWidgetModel();
        $this->widgetAssignmentModel = new \App\Models\DashboardWidgetAssignmentModel();
    }

    /**
     * Normalize widget view path with backward compatibility mapping
     * Resolves central app/Views/dashboard/widgets/* and transparently handles legacy employee paths.
     */
    public static function normalizeWidgetViewPath(?string $viewPath): string
    {
        if (empty($viewPath)) {
            return 'dashboard/widgets/clock_card';
        }

        // Migrate legacy employee view path to canonical central widgets directory
        if (str_starts_with($viewPath, 'dashboard/employee/widgets/')) {
            $viewPath = str_replace('dashboard/employee/widgets/', 'dashboard/widgets/', $viewPath);
        }

        // Strip .php extension if mistakenly supplied
        if (str_ends_with($viewPath, '.php')) {
            $viewPath = substr($viewPath, 0, -4);
        }

        return $viewPath;
    }

    /**
     * Get Complete Resolved Dashboard Configuration and Widget Data for Current User
     * Implements dynamic pipeline: User -> Role -> Permission -> Scope -> Category -> Widgets
     * Each user receives only authorized widgets.
     *
     * PHASES 2 & 3: CATEGORY PARTITIONING & ASYNCHRONOUS LAZY LOADING
     * Evaluates data ONLY for the active category (default: 'overview').
     * Other categories are loaded asynchronously on-demand via AJAX.
     */
    public function getDashboardForUser(?string $userId = null, ?string $companyId = null, ?string $roleCode = null, ?array $scopeOverride = null, string $requestedCategory = 'overview'): array
    {
        $session = \Config\Services::session();
        $effectiveUserId = $userId ?: $session->get('user_id');
        $effectiveCompanyId = $companyId ?: $session->get('company_id');
        $effectiveRoleCode = $roleCode ?: ($session->get('role_code') ?? $session->get('role') ?? 'employee');
        $canonicalRole = $this->permissionService->canonicalizeRole($effectiveRoleCode);

        // Fetch company details including subscription plan
        $company = null;
        $subscriptionPlan = 'enterprise'; // default for platform admin or standalone
        if ($effectiveCompanyId) {
            $compModel = new CompanyModel();
            $company = $compModel->find($effectiveCompanyId);
            if ($company && !empty($company['subscription_plan'])) {
                $subscriptionPlan = strtolower($company['subscription_plan']);
            }
        }

        // ----------------------------------------------------
        // Resolve User & Scope Context
        // ----------------------------------------------------
        $userModel = new UserModel();
        $empModel = new EmployeeModel();
        $branchModel = new BranchModel();
        $deptModel = new DepartmentModel();

        $userRow = $effectiveUserId ? $userModel->find($effectiveUserId) : null;
        $currentEmp = null;
        if ($userRow && !empty($userRow['employee_id'])) {
            $currentEmp = $empModel->find($userRow['employee_id']);
        }
        if (!$currentEmp && $session->get('employee_id')) {
            $currentEmp = $empModel->find($session->get('employee_id'));
        }

        // Derive Scope based on User, Role, and Scope Override (Company-wide default for Company Admin and HR)
        $scope = $this->resolveUserScope($effectiveUserId, $effectiveCompanyId, $canonicalRole, $scopeOverride, $currentEmp);

        // ----------------------------------------------------
        // Multi-Scope Assignment & Widget Authorization Resolution
        // ----------------------------------------------------
        $resolved = $this->resolveAuthorizedWidgets($canonicalRole, $effectiveCompanyId, $effectiveUserId, $scope, $subscriptionPlan);
        $authorizedWidgets = $resolved['authorized_widgets'];
        $widgetConfigurations = $resolved['widget_configurations'];
        $orderedWidgets = $resolved['ordered_widgets'];
        $layout = $resolved['layout'];

        // ----------------------------------------------------
        // CATEGORY PARTITIONING (PHASE 2 & PHASE 3)
        // Group authorized widgets into the 4 approved categories:
        // 1. Overview (Default)
        // 2. Attendance & Shifts
        // 3. Leaves & Roster
        // 4. Payroll & Compliance
        // ----------------------------------------------------
        $categoryWidgets = [
            DashboardWidgetRegistry::CATEGORY_GROUP_OVERVIEW   => [],
            DashboardWidgetRegistry::CATEGORY_GROUP_ATTENDANCE => [],
            DashboardWidgetRegistry::CATEGORY_GROUP_LEAVES     => [],
            DashboardWidgetRegistry::CATEGORY_GROUP_PAYROLL    => [],
        ];
        $categoryCounts = [
            DashboardWidgetRegistry::CATEGORY_GROUP_OVERVIEW   => 0,
            DashboardWidgetRegistry::CATEGORY_GROUP_ATTENDANCE => 0,
            DashboardWidgetRegistry::CATEGORY_GROUP_LEAVES     => 0,
            DashboardWidgetRegistry::CATEGORY_GROUP_PAYROLL    => 0,
        ];

        foreach ($orderedWidgets as $widget) {
            $code = $widget['code'] ?? ($widget['id'] ?? '');
            $cat = DashboardWidgetRegistry::resolveCategoryGroup($code);
            if (!isset($categoryWidgets[$cat])) {
                $cat = DashboardWidgetRegistry::CATEGORY_GROUP_OVERVIEW;
            }
            $categoryWidgets[$cat][] = $widget;
            $categoryCounts[$cat]++;
        }

        // ----------------------------------------------------
        // PHASE 15 & PHASE 3: ASYNCHRONOUS CATEGORY-SCOPED DATA PROVIDER INVOCATION
        // Only queries and evaluates data strictly needed for widgets in the requested category!
        // If requestedCategory is 'overview', attendance exception rosters, leave calendar matrices,
        // and payroll summaries are NOT queried or calculated during initial page render!
        // ----------------------------------------------------
        $validCategories = [
            DashboardWidgetRegistry::CATEGORY_GROUP_OVERVIEW,
            DashboardWidgetRegistry::CATEGORY_GROUP_ATTENDANCE,
            DashboardWidgetRegistry::CATEGORY_GROUP_LEAVES,
            DashboardWidgetRegistry::CATEGORY_GROUP_PAYROLL,
        ];

        if ($requestedCategory === 'all') {
            $widgetsToProvide = $orderedWidgets;
        } elseif (in_array($requestedCategory, $validCategories, true)) {
            $widgetsToProvide = $categoryWidgets[$requestedCategory] ?? [];
        } else {
            $requestedCategory = DashboardWidgetRegistry::CATEGORY_GROUP_OVERVIEW;
            $widgetsToProvide = $categoryWidgets[DashboardWidgetRegistry::CATEGORY_GROUP_OVERVIEW] ?? [];
        }

        $dataProvider = new \App\Services\DashboardWidgetDataProvider();
        $dataPayload = $dataProvider->provideDataForActiveWidgets($widgetsToProvide, $canonicalRole, $effectiveCompanyId, $effectiveUserId, $scope);

        // Backward compatibility metrics wrapper
        $metricsWrapper = [
            'today'              => $dataPayload['today'],
            'current_month'      => $dataPayload['current_month'],
            'current_month_name' => $dataPayload['current_month_name'],
            'platform'           => $dataPayload['platform'] ?? [],
            'workforce'          => array_merge($dataPayload, [
                'present_today'       => $dataPayload['attendance_stats']['present'] ?? 0,
                'late_today'          => $dataPayload['attendance_stats']['late'] ?? 0,
                'on_leave_today'      => $dataPayload['attendance_stats']['on_leave'] ?? 0,
                'absent_today'        => $dataPayload['attendance_stats']['absent'] ?? 0,
                'attendance_rate'     => $dataPayload['attendance_stats']['attendance_rate'] ?? 0.0,
            ]),
            'data'               => $dataPayload,
        ];

        $branchesList    = $effectiveCompanyId ? $branchModel->where('company_id', $effectiveCompanyId)->where('status', 'Active')->orderBy('name', 'ASC')->findAll() : [];
        if (in_array($canonicalRole, ['manager', 'team_leader'], true)) {
            // Department Manager: Only authorized department is available
            $mgrDeptId = $scope['department_id'] ?? ($currentEmp['department_id'] ?? null);
            $departmentsList = ($effectiveCompanyId && $mgrDeptId)
                ? $deptModel->where('company_id', $effectiveCompanyId)->where('id', $mgrDeptId)->where('status', 'Active')->findAll()
                : [];
        } else {
            // Company Admin & HR: All active departments belonging to their company
            $departmentsList = $effectiveCompanyId ? $deptModel->where('company_id', $effectiveCompanyId)->where('status', 'Active')->orderBy('name', 'ASC')->findAll() : [];
        }

        // ----------------------------------------------------
        // PHASE 16: DELIVER TO THE ONE SINGLE DASHBOARD VIEW
        // The view contains ZERO business calculations!
        // ----------------------------------------------------
        return [
            'user_id'                 => $effectiveUserId,
            'user'                    => [
                'id'            => $effectiveUserId,
                'name'          => $session->get('user_name') ?: ($currentEmp ? trim($currentEmp['first_name'] . ' ' . $currentEmp['last_name']) : 'User'),
                'username'      => $session->get('username') ?: 'user',
                'role'          => $this->getRoleDisplayName($canonicalRole),
                'avatar'        => $currentEmp['photo'] ?? null,
                'employee_code' => $currentEmp['employee_code'] ?? null,
            ],
            'company_id'              => $effectiveCompanyId,
            'company'                 => $company,
            'role_code'               => $canonicalRole,
            'role_title'              => $this->getRoleDisplayName($canonicalRole),
            'currentRole'             => $canonicalRole,
            'scope'                   => $scope,
            'subscription_plan'       => $subscriptionPlan,
            'authorized_widgets'      => $orderedWidgets,
            'widget_configurations'   => $widgetConfigurations,
            'widget_data'             => $dataPayload,
            'layout'                  => $layout,
            'widgets'                 => $orderedWidgets,
            'active_widgets'          => $orderedWidgets,
            'category_widgets'        => $categoryWidgets,
            'category_counts'         => $categoryCounts,
            'category_groups'         => DashboardWidgetRegistry::getCategoryGroups(),
            'active_category'         => $requestedCategory,
            'metrics'                 => $metricsWrapper,
            'enabled_modules'         => $dataPayload['enabled_modules'] ?? [],
            'branches'                => $branchesList,
            'departments'             => $departmentsList,
        ];
    }

    /**
     * Get list of all customizable widgets with per-user authorization status
     * for the dashboard customization modal (lazy-loaded via AJAX).
     *
     * @param string|null $userId User ID
     * @param string|null $companyId Company ID
     * @param string|null $roleCode Role code
     * @param array|null $scopeOverride Scope overrides (e.g. branch_id, department_id)
     * @return array List of customizable widgets with authorization and configuration state
     */
    public function getCustomizableWidgetsForUser(?string $userId = null, ?string $companyId = null, ?string $roleCode = null, ?array $scopeOverride = null): array
    {
        $session = \Config\Services::session();
        $effectiveUserId = $userId ?: ($session ? $session->get('user_id') : null);
        $userModel = new UserModel();
        $empModel = new EmployeeModel();
        $userRow = $effectiveUserId ? $userModel->find($effectiveUserId) : null;

        $effectiveCompanyId = $companyId ?: ($userRow['company_id'] ?? ($session ? $session->get('company_id') : null));
        $effectiveRoleCode = $roleCode;
        if (empty($effectiveRoleCode) && $userRow && !empty($userRow['role_id'])) {
            $roleModel = new \App\Models\RoleModel();
            $rRow = $roleModel->find($userRow['role_id']);
            if ($rRow) {
                $effectiveRoleCode = $rRow['code'] ?? $rRow['name'] ?? null;
            }
        }
        if (empty($effectiveRoleCode)) {
            $effectiveRoleCode = $session ? ($session->get('role_code') ?? $session->get('role') ?? 'employee') : 'employee';
        }
        $canonicalRole = $this->permissionService->canonicalizeRole($effectiveRoleCode);

        // Fetch company subscription plan
        $subscriptionPlan = 'enterprise';
        if ($effectiveCompanyId) {
            $compModel = new CompanyModel();
            $company = $compModel->find($effectiveCompanyId);
            if ($company && !empty($company['subscription_plan'])) {
                $subscriptionPlan = strtolower($company['subscription_plan']);
            }
        }

        $currentEmp = null;
        if ($userRow && !empty($userRow['employee_id'])) {
            $currentEmp = $empModel->find($userRow['employee_id']);
        }
        if (!$currentEmp && $session && $session->get('employee_id')) {
            $currentEmp = $empModel->find($session->get('employee_id'));
        }

        $scope = $this->resolveUserScope($effectiveUserId, $effectiveCompanyId, $canonicalRole, $scopeOverride, $currentEmp);

        $resolved = $this->resolveAuthorizedWidgets($canonicalRole, $effectiveCompanyId, $effectiveUserId, $scope, $subscriptionPlan);
        $authorizedWidgets = $resolved['authorized_widgets'];
        $widgetConfigurations = $resolved['widget_configurations'];

        $allCustomizableWidgets = [];
        foreach ($authorizedWidgets as $catItem) {
            $wId = $catItem['id'] ?? '';
            $wCode = $catItem['code'] ?? '';
            $cfg = $widgetConfigurations[$wId] ?? $widgetConfigurations[$wCode] ?? $catItem;

            $allCustomizableWidgets[] = [
                'id'                  => $wId,
                'code'                => $wCode,
                'title'               => $catItem['title'],
                'description'         => $catItem['description'] ?? '',
                'category'            => $catItem['category'] ?? 'general',
                'category_group'      => DashboardWidgetRegistry::resolveCategoryGroup($wCode ?: $wId),
                'icon'                => $catItem['icon'] ?? 'layout-grid',
                'module_code'         => $catItem['module_code'] ?? null,
                'permission_code'     => $catItem['permission_code'] ?? null,
                'is_authorized'       => true,
                'unauthorized_reason' => '',
                'status'              => (int)($cfg['status'] ?? 1),
                'grid_width'          => $cfg['grid_width'] ?? 'half',
                'sort_order'          => (int)($cfg['sort_order'] ?? 99),
                'effective_level'     => $cfg['effective_level'] ?? 'global',
            ];
        }

        return $allCustomizableWidgets;
    }

    /**
     * Dashboard Precedence and Security Architecture:
     * - Admin layers (global default, role, branch, department, company): any layer with status=0 disables the widget; a lower layer cannot re-enable it.
     * - The USER layer may only hide/reorder/resize widgets the admin layers left enabled. It must never enable an admin-disabled widget.
     * - Order/width/height: most specific wins (user > department > branch > company > role > default).
     * - toggleUserWidget, reorderUserWidgets and saveUserPreferences return 403 when asked to enable an admin-disabled widget.
     *
     * Evaluates whether a widget is disabled by ANY administrative layer:
     * 1. Global default layer (dashboard_widgets default_status)
     * 2. Role layer (dashboard_widget_assignments scope_type='role')
     * 3. Company layer (dashboard_widget_assignments scope_type='company')
     * 4. Branch layer (dashboard_widget_assignments scope_type='branch')
     * 5. Department layer (dashboard_widget_assignments scope_type='department')
     *
     * @param array|string $widget Widget array or widget ID/code
     * @param string $canonicalRole Canonical role of user
     * @param string|null $companyId Company identifier
     * @param string|null $userId User identifier
     * @param array|null $scope Resolved user scope
     * @param array|null $preloaded Optional preloaded layers for performance
     * @return array ['disabled' => bool, 'layer' => string|null, 'reason' => string]
     */
    public function isWidgetAdminDisabled(
        $widget,
        string $canonicalRole,
        ?string $companyId = null,
        ?string $userId = null,
        ?array $scope = null,
        ?array $preloaded = null
    ): array {
        if (is_string($widget)) {
            $widgetRow = $this->widgetModel->where('id', $widget)->orWhere('code', $widget)->first();
            if (!$widgetRow) {
                $reg = DashboardWidgetRegistry::getByCode($widget);
                if ($reg) {
                    $widgetRow = $this->widgetModel->where('code', $reg['code'])->first() ?: $reg;
                }
            }
            $widget = $widgetRow ?: ['id' => $widget, 'code' => $widget];
        }

        $wId    = (string)($widget['id'] ?? '');
        $wCode  = (string)($widget['code'] ?? '');
        $wTitle = (string)($widget['title'] ?? ($widget['code'] ?? 'Widget'));

        $branchId = $scope['branch_id'] ?? null;
        $deptId   = $scope['department_id'] ?? null;
        if (($branchId === null || $deptId === null) && $userId) {
            if ($scope === null) {
                $scope = $this->resolveUserScope($userId, $companyId, $canonicalRole);
            }
            $branchId = $scope['branch_id'] ?? null;
            $deptId   = $scope['department_id'] ?? null;
        }

        // Executive Operations & Workforce Summary widget (company_executive_kpis / executive_kpis / wdg-kpi-01)
        // is the authoritative executive summary card deck for company_admin and hr_admin.
        // Meanwhile, attendance_overview_kpis (wdg-att-10, "Attendance Master KPI Deck") is disabled
        // for company_admin and hr_admin by administrative role policy and can be freely disabled.
        $isExecutiveKpi = in_array($wCode, ['company_executive_kpis', 'executive_kpis'], true) || ($wId === 'wdg-kpi-01');
        $isExecutiveAdminRole = in_array($canonicalRole, ['company_admin', 'hr_admin'], true);

        if ($isExecutiveAdminRole && $isExecutiveKpi) {
            // Check only if explicitly disabled at company scope by tenant administrator
            if ($companyId) {
                if ($preloaded !== null && isset($preloaded['company'])) {
                    $c = $preloaded['company'][$wId] ?? ($wCode !== '' ? ($preloaded['company'][$wCode] ?? null) : null);
                    if ($c !== null && ((isset($c['status']) && (int)$c['status'] === 0) || (isset($c['is_visible']) && (int)$c['is_visible'] === 0))) {
                        return [
                            'disabled' => true,
                            'layer'    => 'company',
                            'reason'   => "Widget '{$wTitle}' is disabled at company scope.",
                        ];
                    }
                }
            }

            return [
                'disabled' => false,
                'layer'    => null,
                'reason'   => '',
            ];
        }

        // Layer 1: Global default layer
        if (isset($widget['default_status']) && (int)$widget['default_status'] === 0) {
            return [
                'disabled' => true,
                'layer'    => 'default',
                'reason'   => "Widget '{$wTitle}' is globally disabled by default.",
            ];
        }

        // Layer 2: Role layer (dashboard_widget_assignments scope_type='role')
        if ($preloaded !== null && isset($preloaded['role'])) {
            $r = $preloaded['role'][$wId] ?? ($wCode !== '' ? ($preloaded['role'][$wCode] ?? null) : null);
            if ($r !== null && ((isset($r['status']) && (int)$r['status'] === 0) || (isset($r['is_visible']) && (int)$r['is_visible'] === 0))) {
                return [
                    'disabled' => true,
                    'layer'    => 'role',
                    'reason'   => "Widget '{$wTitle}' is disabled for role '{$canonicalRole}'.",
                ];
            }
        } else {
            if ($this->db->tableExists('dashboard_widget_assignments')) {
                $rAssigns = $this->widgetAssignmentModel
                    ->where('scope_type', 'role')
                    ->where('scope_id', $canonicalRole)
                    ->groupStart()
                        ->where('widget_id', $wId)
                        ->orWhere('widget_id', $wCode)
                    ->groupEnd()
                    ->findAll();
                foreach ($rAssigns as $ra) {
                    if ((isset($ra['status']) && (int)$ra['status'] === 0) || (isset($ra['is_visible']) && (int)$ra['is_visible'] === 0)) {
                        return [
                            'disabled' => true,
                            'layer'    => 'role',
                            'reason'   => "Widget '{$wTitle}' is disabled for role '{$canonicalRole}'.",
                        ];
                    }
                }
            }
        }

        // Layer 3: Company layer (dashboard_widget_assignments scope_type='company')
        if ($companyId) {
            if ($preloaded !== null && isset($preloaded['company'])) {
                $c = $preloaded['company'][$wId] ?? ($wCode !== '' ? ($preloaded['company'][$wCode] ?? null) : null);
                if ($c !== null && ((isset($c['status']) && (int)$c['status'] === 0) || (isset($c['is_visible']) && (int)$c['is_visible'] === 0))) {
                    return [
                        'disabled' => true,
                        'layer'    => 'company',
                        'reason'   => "Widget '{$wTitle}' is disabled at company scope.",
                    ];
                }
            } else {
                if ($this->db->tableExists('dashboard_widget_assignments')) {
                    $cAssigns = $this->widgetAssignmentModel
                        ->where('scope_type', 'company')
                        ->where('scope_id', $companyId)
                        ->groupStart()
                            ->where('widget_id', $wId)
                            ->orWhere('widget_id', $wCode)
                        ->groupEnd()
                        ->findAll();
                    foreach ($cAssigns as $ca) {
                        if ((isset($ca['status']) && (int)$ca['status'] === 0) || (isset($ca['is_visible']) && (int)$ca['is_visible'] === 0)) {
                            return [
                                'disabled' => true,
                                'layer'    => 'company',
                                'reason'   => "Widget '{$wTitle}' is disabled at company scope.",
                            ];
                        }
                    }
                }
            }
        }

        // Layer 4: Branch layer (dashboard_widget_assignments scope_type='branch')
        if ($branchId) {
            if ($preloaded !== null && isset($preloaded['branch'])) {
                $b = $preloaded['branch'][$wId] ?? ($wCode !== '' ? ($preloaded['branch'][$wCode] ?? null) : null);
                if ($b !== null && ((isset($b['status']) && (int)$b['status'] === 0) || (isset($b['is_visible']) && (int)$b['is_visible'] === 0))) {
                    return [
                        'disabled' => true,
                        'layer'    => 'branch',
                        'reason'   => "Widget '{$wTitle}' is disabled at branch scope.",
                    ];
                }
            } else {
                if ($this->db->tableExists('dashboard_widget_assignments')) {
                    $bAssigns = (new \App\Models\DashboardWidgetAssignmentModel())
                        ->where('scope_type', 'branch')
                        ->where('scope_id', $branchId)
                        ->groupStart()
                            ->where('widget_id', $wId)
                            ->orWhere('widget_id', $wCode)
                        ->groupEnd()
                        ->findAll();
                    foreach ($bAssigns as $ba) {
                        if ((isset($ba['status']) && (int)$ba['status'] === 0) || (isset($ba['is_visible']) && (int)$ba['is_visible'] === 0)) {
                            return [
                                'disabled' => true,
                                'layer'    => 'branch',
                                'reason'   => "Widget '{$wTitle}' is disabled at branch scope.",
                            ];
                        }
                    }
                }
            }
        }

        // Layer 5: Department layer (dashboard_widget_assignments scope_type='department')
        if ($deptId) {
            if ($preloaded !== null && isset($preloaded['department'])) {
                $d = $preloaded['department'][$wId] ?? ($wCode !== '' ? ($preloaded['department'][$wCode] ?? null) : null);
                if ($d !== null && ((isset($d['status']) && (int)$d['status'] === 0) || (isset($d['is_visible']) && (int)$d['is_visible'] === 0))) {
                    return [
                        'disabled' => true,
                        'layer'    => 'department',
                        'reason'   => "Widget '{$wTitle}' is disabled at department scope.",
                    ];
                }
            } else {
                if ($this->db->tableExists('dashboard_widget_assignments')) {
                    $dAssigns = (new \App\Models\DashboardWidgetAssignmentModel())
                        ->where('scope_type', 'department')
                        ->where('scope_id', $deptId)
                        ->groupStart()
                            ->where('widget_id', $wId)
                            ->orWhere('widget_id', $wCode)
                        ->groupEnd()
                        ->findAll();
                    foreach ($dAssigns as $da) {
                        if ((isset($da['status']) && (int)$da['status'] === 0) || (isset($da['is_visible']) && (int)$da['is_visible'] === 0)) {
                            return [
                                'disabled' => true,
                                'layer'    => 'department',
                                'reason'   => "Widget '{$wTitle}' is disabled at department scope.",
                            ];
                        }
                    }
                }
            }
        }

        return [
            'disabled' => false,
            'layer'    => null,
            'reason'   => '',
        ];
    }

    /**
     * Resolve authorized active widgets and layout configurations for a user/role context.
     * Single source of widget authorization used by BOTH getDashboardForUser and buildDashboardMetrics.
     * Evaluates:
     * 1. Module status for organization
     * 2. RBAC permission requirements
     * 3. Subscription plan eligibility
     * 4. Target roles matching
     * 5. Self-scope / Employee scope allow-list
     * 6. Admin layer disable checks (Global, Role, Company, Branch, Department)
     * 7. Precedence for sort_order, grid_width, grid_height: user > department > branch > company > role > default
     */
    private function resolveAuthorizedWidgets(
        string $canonicalRole,
        ?string $companyId = null,
        ?string $userId = null,
        ?array $scope = null,
        ?string $subscriptionPlan = null
    ): array {
        if ($scope === null) {
            $scope = $this->resolveUserScope($userId, $companyId, $canonicalRole);
        }

        if ($subscriptionPlan === null) {
            $subscriptionPlan = 'enterprise';
            if ($companyId) {
                $compModel = new CompanyModel();
                $company = $compModel->find($companyId);
                if ($company && !empty($company['subscription_plan'])) {
                    $subscriptionPlan = strtolower($company['subscription_plan']);
                }
            }
        }

        $isCompanyAdmin = in_array($canonicalRole, ['company_admin', 'hr_admin', 'hr_officer', 'finance', 'auditor'], true);
        $scopeType = $scope['type'] ?? ($isCompanyAdmin ? 'company' : 'self');
        $branchId  = $scope['branch_id'] ?? null;
        $deptId    = $scope['department_id'] ?? null;

        // Retrieve catalog
        $allCatalog = $this->widgetModel->orderBy('default_sort_order', 'ASC')->findAll();
        if (empty($allCatalog)) {
            $allCatalog = DashboardWidgetRegistry::getSeedingList();
        } else {
            // Guarantee that all target registered widgets exist in the catalog even if DB table is missing rows
            $existingKeys = [];
            foreach ($allCatalog as $ci) {
                if (!empty($ci['id'])) {
                    $existingKeys[(string)$ci['id']] = true;
                }
                if (!empty($ci['code'])) {
                    $existingKeys[(string)$ci['code']] = true;
                }
            }
            foreach (DashboardWidgetRegistry::getMasterCatalog() as $regKey => $regItem) {
                $regId = (string)($regItem['id'] ?? '');
                $regCode = (string)($regItem['code'] ?? '');
                if (!isset($existingKeys[$regId]) && !isset($existingKeys[$regCode])) {
                    $allCatalog[] = [
                        'id'                    => $regId,
                        'code'                  => $regCode,
                        'title'                 => $regItem['title'],
                        'description'           => $regItem['description'] ?? '',
                        'category'              => $regItem['category'] ?? 'general',
                        'view_path'             => $regItem['view_path'] ?? '',
                        'icon'                  => $regItem['icon'] ?? 'layout-grid',
                        'module_code'           => $regItem['module_code'] ?? null,
                        'permission_code'       => $regItem['permission_code'] ?? null,
                        'target_roles'          => json_encode($regItem['target_roles'] ?? []),
                        'min_subscription_plan' => $regItem['min_subscription_plan'] ?? 'starter',
                        'default_status'        => $regItem['default_status'] ?? 1,
                        'default_sort_order'    => $regItem['default_sort_order'] ?? 99,
                        'grid_width'            => $regItem['grid_width'] ?? 'half',
                    ];
                    $existingKeys[$regId] = true;
                    $existingKeys[$regCode] = true;
                }
            }
        }

        // 1. Role layer configs (reads strictly from dashboard_widget_assignments)
        $roleConfigs = [];
        if ($this->db->tableExists('dashboard_widget_assignments')) {
            $rAssigns = $this->widgetAssignmentModel->getAssignmentsForScope('role', $canonicalRole);
            foreach ($rAssigns as $ra) {
                $roleConfigs[$ra['widget_id']] = $ra;
            }
        }

        // 2. Company layer configs (reads strictly from dashboard_widget_assignments)
        $companyConfigs = [];
        if ($companyId && $this->db->tableExists('dashboard_widget_assignments')) {
            $cAssigns = $this->widgetAssignmentModel->getAssignmentsForScope('company', $companyId);
            foreach ($cAssigns as $ca) {
                $companyConfigs[$ca['widget_id']] = $ca;
            }
        }

        // 3. Branch layer configs
        $branchConfigs = [];
        if ($branchId && $this->db->tableExists('dashboard_widget_assignments')) {
            $bAssigns = $this->widgetAssignmentModel->getAssignmentsForScope('branch', $branchId);
            foreach ($bAssigns as $ba) {
                $branchConfigs[$ba['widget_id']] = $ba;
            }
        }

        // 4. Department layer configs
        $deptConfigs = [];
        if ($deptId && $this->db->tableExists('dashboard_widget_assignments')) {
            $dAssigns = $this->widgetAssignmentModel->getAssignmentsForScope('department', $deptId);
            foreach ($dAssigns as $da) {
                $deptConfigs[$da['widget_id']] = $da;
            }
        }

        // 5. User layer configs (reads strictly from dashboard_widget_assignments)
        $userConfigs = [];
        if ($userId && $this->db->tableExists('dashboard_widget_assignments')) {
            $uAssigns = $this->widgetAssignmentModel->getAssignmentsForScope('user', $userId);
            foreach ($uAssigns as $ua) {
                $userConfigs[$ua['widget_id']] = $ua;
            }
        }

        $preloaded = [
            'role'       => $roleConfigs,
            'company'    => $companyConfigs,
            'branch'     => $branchConfigs,
            'department' => $deptConfigs,
        ];

        $authorizedWidgets = [];
        $widgetConfigurations = [];

        foreach ($allCatalog as $catItem) {
            $wId   = (string)($catItem['id'] ?? '');
            $wCode = (string)($catItem['code'] ?? '');

            $authCheck = $this->isWidgetAuthorizedForUser(
                $catItem,
                $canonicalRole,
                $companyId,
                $userId,
                $scopeType,
                $subscriptionPlan
            );

            if (!$authCheck['authorized']) {
                continue;
            }

            // Admin layers (global default, role, branch, department, company): any layer with status=0 disables the widget; a lower layer cannot re-enable it.
            $adminCheck = $this->isWidgetAdminDisabled($catItem, $canonicalRole, $companyId, $userId, $scope, $preloaded);
            if ($adminCheck['disabled']) {
                continue;
            }

            // Order/width/height: most specific wins (user > department > branch > company > role > default).
            $status         = 1;
            $isVisible      = 1;
            $sortOrder      = (int)($catItem['default_sort_order'] ?? 0);
            $gridWidth      = (string)($catItem['grid_width'] ?? 'half');
            $gridHeight     = 'auto';
            $effectiveLevel = 'global';

            // Role
            $r = $roleConfigs[$wId] ?? ($wCode !== '' ? ($roleConfigs[$wCode] ?? null) : null);
            if ($r !== null) {
                if (isset($r['sort_order'])) {
                    $sortOrder = (int)$r['sort_order'];
                    $effectiveLevel = 'role';
                }
                if (!empty($r['grid_width'])) {
                    $gridWidth = $r['grid_width'];
                    $effectiveLevel = 'role';
                }
                if (!empty($r['grid_height'])) {
                    $gridHeight = $r['grid_height'];
                    $effectiveLevel = 'role';
                }
            }

            // Company
            $c = $companyConfigs[$wId] ?? ($wCode !== '' ? ($companyConfigs[$wCode] ?? null) : null);
            if ($c !== null) {
                if (isset($c['sort_order'])) {
                    $sortOrder = (int)$c['sort_order'];
                    $effectiveLevel = 'company';
                }
                if (!empty($c['grid_width'])) {
                    $gridWidth = $c['grid_width'];
                    $effectiveLevel = 'company';
                }
                if (!empty($c['grid_height'])) {
                    $gridHeight = $c['grid_height'];
                    $effectiveLevel = 'company';
                }
            }

            // Branch
            $b = $branchConfigs[$wId] ?? ($wCode !== '' ? ($branchConfigs[$wCode] ?? null) : null);
            if ($b !== null) {
                if (isset($b['sort_order'])) {
                    $sortOrder = (int)$b['sort_order'];
                    $effectiveLevel = 'branch';
                }
                if (!empty($b['grid_width'])) {
                    $gridWidth = $b['grid_width'];
                    $effectiveLevel = 'branch';
                }
                if (!empty($b['grid_height'])) {
                    $gridHeight = $b['grid_height'];
                    $effectiveLevel = 'branch';
                }
            }

            // Department
            $d = $deptConfigs[$wId] ?? ($wCode !== '' ? ($deptConfigs[$wCode] ?? null) : null);
            if ($d !== null) {
                if (isset($d['sort_order'])) {
                    $sortOrder = (int)$d['sort_order'];
                    $effectiveLevel = 'department';
                }
                if (!empty($d['grid_width'])) {
                    $gridWidth = $d['grid_width'];
                    $effectiveLevel = 'department';
                }
                if (!empty($d['grid_height'])) {
                    $gridHeight = $d['grid_height'];
                    $effectiveLevel = 'department';
                }
            }

            // User layer (most specific)
            // The USER layer may only hide/reorder/resize widgets the admin layers left enabled. It must never enable an admin-disabled widget.
            $u = $userConfigs[$wId] ?? ($wCode !== '' ? ($userConfigs[$wCode] ?? null) : null);
            if ($u !== null) {
                if ((isset($u['status']) && (int)$u['status'] === 0) || (isset($u['is_visible']) && (int)$u['is_visible'] === 0)) {
                    $status = 0;
                    $isVisible = 0;
                    $effectiveLevel = 'user';
                }
                if (isset($u['sort_order'])) {
                    $sortOrder = (int)$u['sort_order'];
                    $effectiveLevel = 'user';
                }
                if (!empty($u['grid_width'])) {
                    $gridWidth = $u['grid_width'];
                    $effectiveLevel = 'user';
                }
                if (!empty($u['grid_height'])) {
                    $gridHeight = $u['grid_height'];
                    $effectiveLevel = 'user';
                }
            }

            // INVARIANT: Executive Workforce & Attendance Summary (company_executive_kpis / executive_kpis / wdg-kpi-01)
            // is kept active for company_admin & hr_admin by default (unless customized).
            $isExecutiveKpi = in_array($wCode, ['company_executive_kpis', 'executive_kpis'], true) || ($wId === 'wdg-kpi-01');

            if (in_array($canonicalRole, ['company_admin', 'hr_admin'], true) && $isExecutiveKpi) {
                // If not explicitly disabled by user, keep active
                if ($u === null || ((int)($u['status'] ?? 1) === 1 && (int)($u['is_visible'] ?? 1) === 1)) {
                    $status = 1;
                    $isVisible = 1;
                }
            }

            // Attendance Master KPI Deck (attendance_overview_kpis / wdg-att-10) is disabled for executive roles
            // (company_admin, hr_admin) because company_executive_kpis is their authoritative deck.
            $isAttendanceMasterDeck = ($wCode === 'attendance_overview_kpis') || ($wId === 'wdg-att-10');
            if (in_array($canonicalRole, ['company_admin', 'hr_admin'], true) && $isAttendanceMasterDeck) {
                $r = $roleConfigs[$wId] ?? ($wCode !== '' ? ($roleConfigs[$wCode] ?? null) : null);
                if ($r !== null && ((isset($r['status']) && (int)$r['status'] === 0) || (isset($r['is_visible']) && (int)$r['is_visible'] === 0))) {
                    $status = 0;
                    $isVisible = 0;
                }
                if ($u !== null && ((isset($u['status']) && (int)$u['status'] === 0) || (isset($u['is_visible']) && (int)$u['is_visible'] === 0))) {
                    $status = 0;
                    $isVisible = 0;
                }
            }

            $config = [
                'widget_id'       => $wId,
                'code'            => $wCode,
                'status'          => $status,
                'is_visible'      => $isVisible,
                'sort_order'      => $sortOrder,
                'position'        => $sortOrder,
                'grid_width'      => $gridWidth,
                'grid_height'     => $gridHeight,
                'effective_level' => $effectiveLevel,
            ];

            $catItem['status'] = $status;
            $catItem['is_visible'] = $isVisible;
            $catItem['sort_order'] = $sortOrder;
            $catItem['grid_width'] = $gridWidth;
            $catItem['effective_level'] = $effectiveLevel;

            $authorizedWidgets[$wId] = $catItem;
            if ($wCode !== '') {
                $authorizedWidgets[$wCode] = $catItem;
            }
            $widgetConfigurations[$wId] = $config;
            if ($wCode !== '') {
                $widgetConfigurations[$wCode] = $config;
            }
        }

        // Execute Layout Engine (automatically strips widgets with status === 0 || is_visible === 0)
        $layoutEngine = new \App\Services\DashboardLayoutEngine();
        $uniqueAuthorized = [];
        foreach ($authorizedWidgets as $w) {
            $uniqueAuthorized[$w['id'] ?? $w['code']] = $w;
        }
        $layout = $layoutEngine->buildLayout(array_values($uniqueAuthorized), $widgetConfigurations);
        $orderedWidgets = $layout['ordered_widgets'];

        return [
            'authorized_widgets'    => array_values($uniqueAuthorized),
            'widget_configurations' => $widgetConfigurations,
            'active_widgets'        => $orderedWidgets,
            'ordered_widgets'       => $orderedWidgets,
            'layout'                => $layout,
        ];
    }

    /**
     * Compute comprehensive metrics payload per role (delegated to DashboardWidgetDataProvider)
     * SEC-WIDGET-05: Resolves authorized active widgets first. Never passes un-gated master catalog!
     */
    public function buildDashboardMetrics(string $canonicalRole, ?string $companyId = null, ?string $userId = null, ?array $scope = null): array
    {
        if ($scope === null) {
            $scope = $this->resolveUserScope($userId, $companyId, $canonicalRole);
        }

        $resolved = $this->resolveAuthorizedWidgets($canonicalRole, $companyId, $userId, $scope);
        $activeWidgets = $resolved['active_widgets'];

        $dataProvider = new DashboardWidgetDataProvider();
        $dataPayload = $dataProvider->provideDataForActiveWidgets($activeWidgets, $canonicalRole, $companyId, $userId, $scope);

        return [
            'today'              => $dataPayload['today'],
            'current_month'      => $dataPayload['current_month'],
            'current_month_name' => $dataPayload['current_month_name'],
            'platform'           => $dataPayload['platform'] ?? [],
            'workforce'          => array_merge($dataPayload, [
                'present_today'   => $dataPayload['attendance_stats']['present'] ?? 0,
                'late_today'      => $dataPayload['attendance_stats']['late'] ?? 0,
                'on_leave_today'  => $dataPayload['attendance_stats']['on_leave'] ?? 0,
                'absent_today'    => $dataPayload['attendance_stats']['absent'] ?? 0,
                'attendance_rate' => $dataPayload['attendance_stats']['attendance_rate'] ?? 0.0,
            ]),
            'data'               => $dataPayload,
        ];
    }

    /**
     * Resolve organizational scope based on User, Role, Tenant, and requested Scope Overrides.
     * 
     * Rule:
     * - Company Admin & HR (company_admin, hr_admin, hr_officer, finance, auditor):
     *   Scope defaults to ALL departments across the authenticated company (company-wide scope).
     *   Specific department or branch is only set if explicitly passed in $scopeOverride.
     * - Department Manager (manager, team_leader):
     *   Strictly restricted to their authorized department (never company-wide).
     * - Employee:
     *   Restricted to personal self-service scope.
     * - Software App Admin:
     *   Global platform fleet scope by default; filterable by company, branch, or department.
     */
    public function resolveUserScope(?string $userId, ?string $companyId, string $canonicalRole, ?array $scopeOverride = null, ?array $currentEmp = null): array
    {
        $session = function_exists('session') ? session() : null;
        $userModel = new UserModel();
        $empModel = new EmployeeModel();
        $branchModel = new BranchModel();
        $deptModel = new DepartmentModel();

        if ($currentEmp === null) {
            $userRow = $userId ? $userModel->find($userId) : null;
            if ($userRow && !empty($userRow['employee_id'])) {
                $currentEmp = $empModel->find($userRow['employee_id']);
            }
            if (!$currentEmp && $session && $session->get('employee_id')) {
                $currentEmp = $empModel->find($session->get('employee_id'));
            }
        }

        $scopeOverride = $scopeOverride ?? [];

        // Tenant boundary validation on scope overrides (Defense-in-Depth)
        if ($companyId && $canonicalRole !== 'software_app_admin') {
            if (!empty($scopeOverride['branch_id']) && $scopeOverride['branch_id'] !== 'all') {
                $bCheck = $branchModel->where('company_id', $companyId)->find($scopeOverride['branch_id']);
                if (!$bCheck) {
                    unset($scopeOverride['branch_id']);
                }
            }
            if (!empty($scopeOverride['department_id']) && $scopeOverride['department_id'] !== 'all') {
                $dCheck = $deptModel->where('company_id', $companyId)->find($scopeOverride['department_id']);
                if (!$dCheck) {
                    unset($scopeOverride['department_id']);
                }
            }
        }

        $scopeBranchId = null;
        $scopeDeptId   = null;
        $scopeEmpId    = $currentEmp['id'] ?? null;
        $scopeType     = 'self';

        if ($canonicalRole === 'software_app_admin') {
            $scopeType = 'global';
            if (!empty($scopeOverride['branch_id']) && $scopeOverride['branch_id'] !== 'all') {
                $scopeBranchId = (string)$scopeOverride['branch_id'];
                $scopeType = 'branch';
            }
            if (!empty($scopeOverride['department_id']) && $scopeOverride['department_id'] !== 'all') {
                $scopeDeptId = (string)$scopeOverride['department_id'];
                $scopeType = 'department';
            }
        } elseif ($canonicalRole === 'employee') {
            $scopeType     = 'self';
            $scopeDeptId   = $currentEmp['department_id'] ?? null;
            $scopeBranchId = $currentEmp['branch_id'] ?? null;
        } elseif (in_array($canonicalRole, ['manager', 'team_leader'], true)) {
            // Department Manager: restricted to their assigned/managed department
            $mgrDeptId = $currentEmp['department_id'] ?? null;
            // Also check if employee is head of a department
            if (empty($mgrDeptId) && $companyId && !empty($currentEmp['id'])) {
                $headDept = $deptModel->where('company_id', $companyId)->where('head_id', $currentEmp['id'])->first();
                if ($headDept) {
                    $mgrDeptId = $headDept['id'];
                }
            }

            $scopeDeptId   = $mgrDeptId;
            $scopeBranchId = $currentEmp['branch_id'] ?? null;
            $scopeType     = !empty($scopeDeptId) ? 'department' : (!empty($scopeBranchId) ? 'branch' : 'self');

            // If manager explicitly requested an authorized department, verify match
            if (!empty($scopeOverride['department_id']) && $scopeOverride['department_id'] !== 'all') {
                if ((string)$scopeOverride['department_id'] === (string)$scopeDeptId) {
                    $scopeDeptId = (string)$scopeOverride['department_id'];
                }
            }
            if (!empty($scopeOverride['branch_id']) && $scopeOverride['branch_id'] !== 'all') {
                if ((string)$scopeOverride['branch_id'] === (string)$scopeBranchId) {
                    $scopeBranchId = (string)$scopeOverride['branch_id'];
                }
            }
        } elseif ($canonicalRole === 'branch_manager') {
            $mgrBranchId = $currentEmp['branch_id'] ?? null;
            if (empty($mgrBranchId) && $companyId && !empty($currentEmp['id'])) {
                $headBranch = $branchModel->where('company_id', $companyId)->where('manager_id', $currentEmp['id'])->first();
                if ($headBranch) {
                    $mgrBranchId = $headBranch['id'];
                }
            }
            $scopeBranchId = $mgrBranchId;
            $scopeDeptId   = $currentEmp['department_id'] ?? null;
            $scopeType     = !empty($scopeBranchId) ? 'branch' : 'self';

            if (!empty($scopeOverride['branch_id']) && $scopeOverride['branch_id'] !== 'all') {
                if ((string)$scopeOverride['branch_id'] === (string)$scopeBranchId) {
                    $scopeBranchId = (string)$scopeOverride['branch_id'];
                }
            }
        } elseif (in_array($canonicalRole, ['company_admin', 'hr_admin', 'hr_officer', 'finance', 'auditor'], true)) {
            // Company Admin, HR Admin, HR Officer, Finance, Auditor:
            // COMPANY-WIDE by default across ALL departments in the company
            $scopeType = 'company';
            $scopeDeptId = null;
            $scopeBranchId = null;

            if (!empty($scopeOverride['branch_id']) && $scopeOverride['branch_id'] !== 'all') {
                $scopeBranchId = (string)$scopeOverride['branch_id'];
                $scopeType = 'branch';
            }
            if (!empty($scopeOverride['department_id']) && $scopeOverride['department_id'] !== 'all') {
                $scopeDeptId = (string)$scopeOverride['department_id'];
                $scopeType = 'department';
            }
        } else {
            // Any role not explicitly handled must resolve to 'self', never the company-wide else-branch.
            $scopeType     = 'self';
            $scopeDeptId   = $currentEmp['department_id'] ?? null;
            $scopeBranchId = $currentEmp['branch_id'] ?? null;
        }

        $branchName = null;
        if ($scopeBranchId) {
            $bRow = $branchModel->find($scopeBranchId);
            $branchName = $bRow['name'] ?? null;
        }
        $deptName = null;
        if ($scopeDeptId) {
            $dRow = $deptModel->find($scopeDeptId);
            $deptName = $dRow['name'] ?? null;
        }

        return [
            'type'            => $scopeType,
            'branch_id'       => $scopeBranchId,
            'branch_name'     => $branchName,
            'department_id'   => $scopeDeptId,
            'department_name' => $deptName,
            'employee_id'     => $scopeEmpId,
            'employee_name'   => $currentEmp ? trim(($currentEmp['first_name'] ?? '') . ' ' . ($currentEmp['last_name'] ?? '')) : null,
        ];
    }

    /**
     * Check if a subscription plan meets minimum required tier
     * starter < professional < enterprise
     */
    public function isPlanEligible(string $currentPlan, string $minPlan): bool
    {
        $tiers = [
            'starter'      => 1,
            'basic'        => 1,
            'standard'     => 2,
            'professional' => 2,
            'pro'          => 2,
            'enterprise'   => 3,
            'unlimited'    => 3,
        ];

        $currentTier = $tiers[strtolower($currentPlan)] ?? 3;
        $requiredTier = $tiers[strtolower($minPlan)] ?? 1;

        return $currentTier >= $requiredTier;
    }

    /**
     * Map canonical role code to human-readable label
     */
    public function getRoleDisplayName(string $canonicalRole): string
    {
        $map = [
            'software_app_admin' => 'Software App Administrator',
            'company_admin'      => 'Company Administrator',
            'hr_admin'           => 'HR Administrator',
            'hr_officer'         => 'HR Officer',
            'finance'            => 'Finance Controller',
            'branch_manager'     => 'Branch Manager',
            'manager'            => 'Department Manager',
            'team_leader'        => 'Team Leader',
            'employee'           => 'Employee Portal',
            'auditor'            => 'Compliance Auditor',
        ];
        return $map[$canonicalRole] ?? ucfirst(str_replace('_', ' ', $canonicalRole));
    }

    /**
     * Seed baseline widget definitions and default role mappings
     */
    public function ensureDefaultWidgetsSeeded(bool $force = false): array
    {
        $stats = ['inserted' => 0, 'updated' => 0, 'role_configs' => 0];
        try {
            if (!$this->db->tableExists('dashboard_widgets')) {
                return $stats;
            }

            // Always migrate any legacy widget view paths in the database to canonical central locations
            $this->db->query("UPDATE dashboard_widgets SET view_path = REPLACE(view_path, 'dashboard/employee/widgets/', 'dashboard/widgets/') WHERE view_path LIKE 'dashboard/employee/widgets/%'");

            $count = $this->db->table('dashboard_widgets')->countAllResults();
            $roleAssignmentsCount = $this->db->tableExists('dashboard_widget_assignments')
                ? $this->db->table('dashboard_widget_assignments')->where('scope_type', 'role')->countAllResults()
                : 0;
            $legacyCount = $this->db->table('dashboard_widgets')->like('view_path', 'dashboard/employee/widgets/')->countAllResults();
            $masterCatalogCount = count(DashboardWidgetRegistry::getMasterCatalog());
            if ($count >= $masterCatalogCount && $roleAssignmentsCount > 0 && !$force && $legacyCount === 0) {
                return $stats;
            }

            $this->db->transBegin();

            $widgets = DashboardWidgetRegistry::getSeedingList();

            foreach ($widgets as $w) {
                $exists = $this->db->table('dashboard_widgets')->where('code', $w['code'])->get()->getRowArray();
                if (!$exists) {
                    $w['created_at'] = date('Y-m-d H:i:s');
                    $w['updated_at'] = date('Y-m-d H:i:s');
                    $this->db->table('dashboard_widgets')->insert($w);
                    $stats['inserted']++;
                } else {
                    $this->db->table('dashboard_widgets')->where('code', $w['code'])->update([
                        'title'                 => $w['title'],
                        'description'           => $w['description'],
                        'category'              => $w['category'],
                        'view_path'             => $w['view_path'],
                        'icon'                  => $w['icon'],
                        'module_code'           => $w['module_code'],
                        'permission_code'       => $w['permission_code'],
                        'target_roles'          => $w['target_roles'],
                        'min_subscription_plan' => $w['min_subscription_plan'],
                        'grid_width'            => $w['grid_width'],
                        'updated_at'            => date('Y-m-d H:i:s'),
                    ]);
                    $stats['updated']++;
                }
            }

            // Seed / Sync role configurations directly into dashboard_widget_assignments
            $allInserted = $this->db->table('dashboard_widgets')->get()->getResultArray();
            $roles = ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'branch_manager', 'manager', 'team_leader', 'employee', 'auditor', 'finance'];

            if ($this->db->tableExists('dashboard_widget_assignments')) {
                foreach ($roles as $rCode) {
                    $existingRoleRows = $this->widgetAssignmentModel
                        ->where('scope_type', 'role')
                        ->where('scope_id', $rCode)
                        ->findAll();
                    $validWidgetIdsForRole = [];

                    foreach ($allInserted as $widget) {
                        $targetRoles = json_decode($widget['target_roles'] ?? '[]', true) ?: [];
                        $isAllowedForRole = ($rCode === 'software_app_admin') || in_array($rCode, $targetRoles, true) || in_array('*', $targetRoles, true);

                        if ($isAllowedForRole) {
                            $validWidgetIdsForRole[] = $widget['id'];
                            $roleConfigExists = $this->widgetAssignmentModel
                                ->where('scope_type', 'role')
                                ->where('scope_id', $rCode)
                                ->where('widget_id', $widget['id'])
                                ->countAllResults();

                            $isExecutiveKpi = in_array($widget['code'] ?? '', ['company_executive_kpis', 'executive_kpis'], true) || (($widget['id'] ?? '') === 'wdg-kpi-01');
                            $isAttendanceDeck = in_array($widget['code'] ?? '', ['attendance_overview_kpis'], true) || (($widget['id'] ?? '') === 'wdg-att-10');
                            $isExecutiveRole = in_array($rCode, ['company_admin', 'hr_admin', 'finance', 'auditor', 'software_app_admin'], true);

                            // Attendance Master KPI Deck is disabled for executive roles (company_admin, hr_admin)
                            if ($isExecutiveRole && $isAttendanceDeck) {
                                $targetRoleStatus = 0;
                            } elseif (in_array($rCode, ['company_admin', 'hr_admin'], true) && $isExecutiveKpi) {
                                $targetRoleStatus = 1;
                            } else {
                                $targetRoleStatus = (int)$widget['default_status'];
                            }

                            if ($roleConfigExists === 0) {
                                $this->widgetAssignmentModel->saveAssignment('role', $rCode, $widget['id'], [
                                    'status'     => $targetRoleStatus,
                                    'is_visible' => $targetRoleStatus,
                                    'sort_order' => (int)$widget['default_sort_order'],
                                    'position'   => (int)$widget['default_sort_order'],
                                    'grid_width' => $widget['grid_width'],
                                ]);
                                $stats['role_configs']++;
                            } elseif ($isExecutiveRole && $isAttendanceDeck) {
                                // Keep Attendance Master KPI Deck disabled for executive roles
                                $this->widgetAssignmentModel
                                    ->where('scope_type', 'role')
                                    ->where('scope_id', $rCode)
                                    ->where('widget_id', $widget['id'])
                                    ->set(['status' => 0, 'is_visible' => 0])
                                    ->update();
                            } elseif (in_array($rCode, ['company_admin', 'hr_admin'], true) && $isExecutiveKpi) {
                                $this->widgetAssignmentModel
                                    ->where('scope_type', 'role')
                                    ->where('scope_id', $rCode)
                                    ->where('widget_id', $widget['id'])
                                    ->set(['status' => 1, 'is_visible' => 1])
                                    ->update();
                            }
                        }
                    }

                    // Remove role assignments for widgets not belonging to this role to eliminate duplicates
                    foreach ($existingRoleRows as $row) {
                        if (!in_array($row['widget_id'], $validWidgetIdsForRole, true)) {
                            $this->widgetAssignmentModel->delete($row['id']);
                        }
                    }
                }
            }

            if ($this->db->transStatus() === false) {
                $this->db->transRollback();
            } else {
                $this->db->transCommit();
            }

            return $stats;
        } catch (\Throwable $e) {
            if ($this->db->transStatus() !== null) {
                $this->db->transRollback();
            }
            log_message('error', 'Error in ensureDefaultWidgetsSeeded: ' . $e->getMessage());
            return $stats;
        }
    }

    /**
     * Alias for ensureDefaultWidgetsSeeded for spark seeding command
     */
    public function seedDefaultWidgets(bool $force = false): array
    {
        return $this->ensureDefaultWidgetsSeeded($force);
    }

    /**
     * Toggle Widget Status for any scope (user, role, branch, department, company, global)
     */
    public function toggleWidgetStatus(string $widgetId, string $targetType, string $targetId, int $newStatus, ?string $actorUserId = null): array
    {
        $widget = $this->widgetModel->where('id', $widgetId)->orWhere('code', $widgetId)->first();
        if (!$widget) {
            return ['success' => false, 'message' => 'Widget not found'];
        }

        if (!in_array($targetType, ['role', 'company', 'branch', 'department', 'user'], true)) {
            return ['success' => false, 'message' => 'Invalid target type'];
        }

        $realWidgetId = $widget['id'];
        $canonicalTargetId = ($targetType === 'role') ? $this->permissionService->canonicalizeRole($targetId) : $targetId;

        $this->db->transBegin();
        try {
            if ($this->db->tableExists('dashboard_widget_assignments')) {
                $this->widgetAssignmentModel->saveAssignment($targetType, $canonicalTargetId, $realWidgetId, [
                    'status'     => $newStatus,
                    'is_visible' => $newStatus,
                ], [
                    'sort_order' => $widget['default_sort_order'],
                    'grid_width' => $widget['grid_width'] ?? 'half',
                ]);
            }

            if ($this->db->transStatus() === false) {
                $this->db->transRollback();
                return ['success' => false, 'message' => 'Failed to update widget status.'];
            }

            $this->db->transCommit();
        } catch (\Throwable $e) {
            $this->db->transRollback();
            log_message('error', 'toggleWidgetStatus error: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Database error while toggling widget status.'];
        }

        $this->auditService->log(
            $actorUserId,
            'dashboard_management',
            "Toggle {$targetType} Widget Status",
            $realWidgetId,
            ['scope' => $targetType, 'target_id' => $canonicalTargetId, 'status' => $newStatus ? 'Active' : 'Inactive', 'widget' => $widget['title']],
            ['message' => "Toggled widget '{$widget['title']}' for scope {$targetType} ({$canonicalTargetId}) to " . ($newStatus ? 'Active (ON)' : 'Inactive (OFF)')]
        );

        return [
            'success' => true,
            'message' => "Widget '{$widget['title']}' set to " . ($newStatus ? 'Active (ON)' : 'Inactive (OFF)') . " for {$targetType} scope."
        ];
    }

    /**
     * Update Widget Sort Order
     */
    public function updateWidgetOrder(array $orderedWidgetIds, string $targetType, string $targetId, ?string $actorUserId = null): array
    {
        if (!in_array($targetType, ['role', 'company', 'branch', 'department', 'user'], true)) {
            return ['success' => false, 'message' => 'Invalid target type'];
        }

        $canonicalTargetId = ($targetType === 'role') ? $this->permissionService->canonicalizeRole($targetId) : $targetId;

        $this->db->transBegin();
        try {
            foreach ($orderedWidgetIds as $order => $wId) {
                $w = $this->widgetModel->where('id', $wId)->orWhere('code', $wId)->first();
                $realWidgetId = $w ? $w['id'] : $wId;
                $defaultStatus = $w ? (int)$w['default_status'] : 1;
                $defaultGridWidth = $w ? ($w['grid_width'] ?? 'half') : 'half';

                $this->widgetAssignmentModel->saveAssignment($targetType, $canonicalTargetId, $realWidgetId, [
                    'sort_order' => $order + 1,
                    'position'   => $order + 1,
                ], [
                    'status'     => $defaultStatus,
                    'grid_width' => $defaultGridWidth,
                ]);
            }

            if ($this->db->transStatus() === false) {
                $this->db->transRollback();
                return ['success' => false, 'message' => 'Failed to save widget order.'];
            }

            $this->db->transCommit();
        } catch (\Throwable $e) {
            $this->db->transRollback();
            log_message('error', 'updateWidgetOrder error: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Database error while reordering widgets.'];
        }

        $this->auditService->log(
            $actorUserId,
            'dashboard_management',
            'Reorder ' . ucfirst($targetType) . ' Widgets',
            null,
            ['scope' => $targetType, 'target_id' => $canonicalTargetId, 'order_count' => count($orderedWidgetIds)],
            ['message' => "Updated widget sort order for {$targetType} '{$canonicalTargetId}'"]
        );

        return ['success' => true, 'message' => ucfirst($targetType) . ' widget display order re-saved successfully.'];
    }

    /**
     * Reset Company Widget Override back to Role/System Default
     */
    public function resetCompanyOverride(string $widgetId, string $companyId, ?string $actorUserId = null): array
    {
        $widget = $this->widgetModel->where('id', $widgetId)->orWhere('code', $widgetId)->first();
        $realWidgetId = $widget ? $widget['id'] : $widgetId;
        $title = $widget['title'] ?? 'Widget';

        $existing = $this->widgetAssignmentModel
            ->where('scope_type', 'company')
            ->where('scope_id', $companyId)
            ->where('widget_id', $realWidgetId)
            ->first();

        if (!$existing) {
            return ['success' => true, 'message' => 'No override found; widget is already using system default.'];
        }

        $this->db->transBegin();
        try {
            $this->widgetAssignmentModel->deleteAssignment('company', $companyId, $realWidgetId);

            if ($this->db->transStatus() === false) {
                $this->db->transRollback();
                return ['success' => false, 'message' => 'Failed to reset company override.'];
            }

            $this->db->transCommit();
        } catch (\Throwable $e) {
            $this->db->transRollback();
            log_message('error', 'resetCompanyOverride error: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Database error while resetting override.'];
        }

        $this->auditService->log(
            $actorUserId,
            'dashboard_management',
            'Reset Company Widget Override',
            $realWidgetId,
            ['company_id' => $companyId, 'widget' => $title],
            ['message' => "Reset company override for widget '{$title}' back to role default"]
        );

        return ['success' => true, 'message' => "Override for '{$title}' cleared. Restored to role default."];
    }

    /**
     * Assign a widget from catalog to a role
     */
    public function assignWidgetToRole(string $widgetId, string $roleCode, ?string $actorUserId = null): array
    {
        $widget = $this->widgetModel->where('id', $widgetId)->orWhere('code', $widgetId)->first();
        if (!$widget) {
            return ['success' => false, 'message' => 'Widget not found in catalog.'];
        }

        $canonicalRole = $this->permissionService->canonicalizeRole($roleCode);
        $realWidgetId = $widget['id'];

        $existing = $this->widgetAssignmentModel
            ->where('scope_type', 'role')
            ->where('scope_id', $canonicalRole)
            ->where('widget_id', $realWidgetId)
            ->first();

        if ($existing) {
            $this->db->transBegin();
            try {
                $this->widgetAssignmentModel->saveAssignment('role', $canonicalRole, $realWidgetId, [
                    'status'     => 1,
                    'is_visible' => 1,
                ]);
                $this->db->transCommit();
            } catch (\Throwable $e) {
                $this->db->transRollback();
            }
            return ['success' => true, 'message' => "Widget '{$widget['title']}' is already assigned to '{$canonicalRole}' and has been activated."];
        }

        $maxOrder = $this->widgetAssignmentModel
            ->where('scope_type', 'role')
            ->where('scope_id', $canonicalRole)
            ->selectMax('sort_order')
            ->first();
        $nextOrder = ($maxOrder['sort_order'] ?? 0) + 1;

        $this->db->transBegin();
        try {
            $this->widgetAssignmentModel->saveAssignment('role', $canonicalRole, $realWidgetId, [
                'status'     => 1,
                'is_visible' => 1,
                'sort_order' => $nextOrder,
                'position'   => $nextOrder,
                'grid_width' => $widget['grid_width'] ?? 'half',
            ]);

            if ($this->db->transStatus() === false) {
                $this->db->transRollback();
                return ['success' => false, 'message' => 'Failed to assign widget to role.'];
            }

            $this->db->transCommit();
        } catch (\Throwable $e) {
            $this->db->transRollback();
            log_message('error', 'assignWidgetToRole error: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Database error while assigning widget to role.'];
        }

        $this->auditService->log(
            $actorUserId,
            'dashboard_management',
            'Assign Widget to Role',
            $realWidgetId,
            ['role' => $canonicalRole, 'widget' => $widget['title']],
            ['message' => "Assigned widget '{$widget['title']}' to role '{$canonicalRole}'"]
        );

        return ['success' => true, 'message' => "Widget '{$widget['title']}' successfully added to '{$canonicalRole}' dashboard."];
    }

    /**
     * Remove widget assignment from a role
     */
    public function removeWidgetFromRole(string $widgetId, string $roleCode, ?string $actorUserId = null): array
    {
        $canonicalRole = $this->permissionService->canonicalizeRole($roleCode);
        $widget = $this->widgetModel->where('id', $widgetId)->orWhere('code', $widgetId)->first();
        $realWidgetId = $widget ? $widget['id'] : $widgetId;

        $existing = $this->widgetAssignmentModel
            ->where('scope_type', 'role')
            ->where('scope_id', $canonicalRole)
            ->where('widget_id', $realWidgetId)
            ->first();

        if (!$existing) {
            return ['success' => true, 'message' => 'Widget is not assigned to this role.'];
        }

        $this->db->transBegin();
        try {
            $this->widgetAssignmentModel->deleteAssignment('role', $canonicalRole, $realWidgetId);

            if ($this->db->transStatus() === false) {
                $this->db->transRollback();
                return ['success' => false, 'message' => 'Failed to remove widget from role.'];
            }

            $this->db->transCommit();
        } catch (\Throwable $e) {
            $this->db->transRollback();
            log_message('error', 'removeWidgetFromRole error: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Database error while removing widget from role.'];
        }

        $title = $widget['title'] ?? 'Widget';
        $this->auditService->log(
            $actorUserId,
            'dashboard_management',
            'Remove Widget from Role',
            $realWidgetId,
            ['role' => $canonicalRole, 'widget' => $title],
            ['message' => "Removed widget '{$title}' from role '{$canonicalRole}'"]
        );

        return ['success' => true, 'message' => "Widget '{$title}' removed from '{$canonicalRole}'."];
    }

    /**
     * Update Widget Grid Width (half / full)
     */
    public function updateWidgetGridWidth(string $widgetId, string $targetType, string $targetId, string $gridWidth, ?string $actorUserId = null): array
    {
        $gridWidth = in_array($gridWidth, ['half', 'full'], true) ? $gridWidth : 'half';
        $canonicalTargetId = ($targetType === 'role') ? $this->permissionService->canonicalizeRole($targetId) : $targetId;
        $widget = $this->widgetModel->where('id', $widgetId)->orWhere('code', $widgetId)->first();
        $realWidgetId = $widget ? $widget['id'] : $widgetId;

        $existing = $this->widgetAssignmentModel
            ->where('scope_type', $targetType)
            ->where('scope_id', $canonicalTargetId)
            ->where('widget_id', $realWidgetId)
            ->first();

        if (!$existing) {
            return ['success' => false, 'message' => 'Widget mapping not found for width update.'];
        }

        $this->db->transBegin();
        try {
            $this->widgetAssignmentModel->saveAssignment($targetType, $canonicalTargetId, $realWidgetId, [
                'grid_width' => $gridWidth,
            ]);

            if ($this->db->transStatus() === false) {
                $this->db->transRollback();
                return ['success' => false, 'message' => 'Failed to update widget layout width.'];
            }

            $this->db->transCommit();
        } catch (\Throwable $e) {
            $this->db->transRollback();
            log_message('error', 'updateWidgetGridWidth error: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Database error while updating widget layout width.'];
        }

        return ['success' => true, 'message' => "Layout column width updated to '{$gridWidth}' for {$targetType}."];
    }

    /**
     * Check if a widget is authorized for a specific user.
     * INVARIANT: "Users cannot enable unauthorized widgets."
     * A widget is authorized ONLY IF:
     * 1. Its module is enabled for the company.
     * 2. The user has the required RBAC permission.
     * 3. The user's role matches target_roles.
     */
    public function isWidgetAuthorizedForUser(
        array $widget,
        string $canonicalRole,
        ?string $companyId = null,
        ?string $userId = null,
        ?string $scopeType = null,
        ?string $subscriptionPlan = null
    ): array {
        // Resolve companyId if not provided but userId is present
        if (empty($companyId) && $userId) {
            $userRow = (new UserModel())->find($userId);
            if ($userRow && !empty($userRow['company_id'])) {
                $companyId = $userRow['company_id'];
            }
        }

        // Resolve company's subscription plan when not explicitly passed
        if ($subscriptionPlan === null || $subscriptionPlan === '') {
            $subscriptionPlan = 'starter';
            if ($companyId) {
                $compModel = new CompanyModel();
                $company = $compModel->find($companyId);
                if ($company && !empty($company['subscription_plan'])) {
                    $subscriptionPlan = strtolower($company['subscription_plan']);
                }
            } elseif ($canonicalRole === 'software_app_admin') {
                $subscriptionPlan = 'enterprise';
            }
        }

        // Resolve user's scope type when not explicitly passed
        if ($scopeType === null || $scopeType === '') {
            $scope = $this->resolveUserScope($userId, $companyId, $canonicalRole);
            $scopeType = $scope['type'] ?? (in_array($canonicalRole, ['company_admin', 'hr_admin', 'hr_officer', 'finance', 'auditor'], true) ? 'company' : 'self');
        }

        $widgetCode = $widget['code'] ?? '';

        // 0. Platform Admin widgets guard: Exclusively reserved for Software App Admin
        // Authoritative registry constants DashboardWidgetRegistry::PLATFORM_WIDGET_CODES:
        // 'appadmin_platform_overview', 'appadmin_company_fleet', 'appadmin_system_health', 'appadmin_kpis', 'system_health_telemetry'
        $isPlatformWidget = DashboardWidgetRegistry::isPlatformWidget($widgetCode);
        if ($isPlatformWidget && $canonicalRole !== 'software_app_admin') {
            return [
                'authorized' => false,
                'reason'     => 'Widget is reserved for Platform Administrators.'
            ];
        }

        $isAuditStream = in_array($widgetCode, ['appadmin_audit_stream', 'platform_audit_stream'], true);
        if ($isAuditStream && !in_array($canonicalRole, ['software_app_admin', 'auditor', 'company_admin', 'finance'], true)) {
            return [
                'authorized' => false,
                'reason'     => 'Widget requires audit privileges.'
            ];
        }

        // 1. Check module status
        if (!empty($widget['module_code'])) {
            if (!$this->permissionService->isModuleEnabledForCompany($companyId, $widget['module_code'])) {
                return [
                    'authorized' => false,
                    'reason'     => "Module '{$widget['module_code']}' is currently disabled for this organization."
                ];
            }
        }

        // 2. Check RBAC permissions (Software App Admin bypasses)
        if (!empty($widget['permission_code']) && $canonicalRole !== 'software_app_admin') {
            $parts = explode('.', $widget['permission_code']);
            $mod = $parts[0] ?? $widget['permission_code'];
            $act = $parts[1] ?? 'view';
            if (!$this->permissionService->hasAccess($userId, $mod, $act, $canonicalRole)) {
                return [
                    'authorized' => false,
                    'reason'     => "Requires permission '{$widget['permission_code']}'."
                ];
            }
        }

        // 3. Check Target Roles
        if (!empty($widget['target_roles']) && $canonicalRole !== 'software_app_admin') {
            $targetRoles = is_array($widget['target_roles']) ? $widget['target_roles'] : json_decode($widget['target_roles'], true);
            if (is_array($targetRoles)) {
                if (!in_array($canonicalRole, $targetRoles, true) && !in_array('*', $targetRoles, true)) {
                    return [
                        'authorized' => false,
                        'reason'     => "Widget is not permitted for role '{$canonicalRole}'."
                    ];
                }
            } elseif ($targetRoles !== '*' && $targetRoles !== $canonicalRole) {
                return [
                    'authorized' => false,
                    'reason'     => "Widget is not permitted for role '{$canonicalRole}'."
                ];
            }
        }

        // 4. Check Subscription Tier
        if (!empty($widget['min_subscription_plan']) && !$this->isPlanEligible($subscriptionPlan, $widget['min_subscription_plan'])) {
            return [
                'authorized' => false,
                'reason'     => "Requires subscription plan tier '{$widget['min_subscription_plan']}'."
            ];
        }

        // 5. Self-scope / Employee scope restrictions (hide company-wide management widgets)
        // Uses authoritative DashboardWidgetRegistry::SELF_SERVICE_ALLOWED_CODES:
        // 'employee_clock_card', 'employee_leave_balances', 'employee_quick_actions', 'employee_recent_activity',
        // 'staff_leave_calendar', 'employee_my_calendar', 'company_holiday_calendar', 'company_notice_board',
        // 'employee_recent_notices', 'employee_tasks'
        if ($canonicalRole === 'employee' || $scopeType === 'self') {
            if (!DashboardWidgetRegistry::isSelfServiceAllowed($widgetCode)) {
                return [
                    'authorized' => false,
                    'reason'     => 'Widget is not permitted in self-service employee scope.'
                ];
            }
        }

        return ['authorized' => true, 'reason' => ''];
    }

    /**
     * User Customization: Toggle Show/Hide for a single widget.
     * CRITICAL INVARIANT: "Users cannot enable unauthorized widgets."
     */
    public function toggleUserWidget(string $userId, string $widgetIdOrCode, int $status, ?string $canonicalRole = null, ?string $companyId = null): array
    {
        $widget = $this->widgetModel->where('id', $widgetIdOrCode)->orWhere('code', $widgetIdOrCode)->first();
        if (!$widget) {
            $catalogItem = DashboardWidgetRegistry::getByCode($widgetIdOrCode);
            if ($catalogItem) {
                $widget = $this->widgetModel->where('code', $catalogItem['code'])->first();
            }
        }

        if (!$widget) {
            return ['success' => false, 'code' => 404, 'message' => 'Widget not found in registry.'];
        }

        if ((empty($companyId) || empty($canonicalRole)) && $userId) {
            $userRow = (new \App\Models\UserModel())->find($userId);
            if ($userRow) {
                if (empty($companyId) && !empty($userRow['company_id'])) {
                    $companyId = $userRow['company_id'];
                }
                if (empty($canonicalRole) && !empty($userRow['role_id'])) {
                    $rRow = (new \App\Models\RoleModel())->find($userRow['role_id']);
                    if ($rRow) {
                        $canonicalRole = $this->permissionService->canonicalizeRole($rRow['code'] ?? $rRow['name'] ?? 'employee');
                    }
                }
            }
        }
        if (empty($canonicalRole)) {
            $session = \Config\Services::session();
            $canonicalRole = $this->permissionService->canonicalizeRole($session ? ($session->get('role_code') ?? $session->get('role') ?? 'employee') : 'employee');
        }

        $subscriptionPlan = 'starter';
        if ($companyId) {
            $compModel = new \App\Models\CompanyModel();
            $comp = $compModel->find($companyId);
            if ($comp && !empty($comp['subscription_plan'])) {
                $subscriptionPlan = strtolower($comp['subscription_plan']);
            }
        } elseif ($canonicalRole === 'software_app_admin') {
            $subscriptionPlan = 'enterprise';
        }

        $scope = $this->resolveUserScope($userId, $companyId, $canonicalRole);
        $scopeType = $scope['type'] ?? (in_array($canonicalRole, ['company_admin', 'hr_admin', 'hr_officer', 'finance', 'auditor'], true) ? 'company' : 'self');

        // CRITICAL INVARIANT: "Users cannot enable unauthorized or admin-disabled widgets."
        if ($status === 1) {
            $auth = $this->isWidgetAuthorizedForUser($widget, $canonicalRole, $companyId, $userId, $scopeType, $subscriptionPlan);
            if (!$auth['authorized']) {
                return [
                    'success' => false,
                    'code'    => 403,
                    'message' => "Unauthorized: You do not have permission to enable widget '{$widget['title']}' ({$auth['reason']})."
                ];
            }

            $adminCheck = $this->isWidgetAdminDisabled($widget, $canonicalRole, $companyId, $userId, $scope);
            if ($adminCheck['disabled']) {
                return [
                    'success' => false,
                    'code'    => 403,
                    'message' => "Unauthorized: Widget '{$widget['title']}' cannot be enabled because it has been disabled by an administrative policy ({$adminCheck['reason']})."
                ];
            }
        }

        $this->db->transBegin();
        try {
            $this->widgetAssignmentModel->saveAssignment('user', $userId, $widget['id'], [
                'status'     => $status,
                'is_visible' => $status,
            ]);

            if ($this->db->transStatus() === false) {
                $this->db->transRollback();
                return ['success' => false, 'code' => 500, 'message' => 'Failed to save widget setting.'];
            }

            $this->db->transCommit();
        } catch (\Throwable $e) {
            $this->db->transRollback();
            log_message('error', 'toggleUserWidget error: ' . $e->getMessage());
            return ['success' => false, 'code' => 500, 'message' => 'Database error while updating widget setting.'];
        }

        $actionWord = ($status === 1) ? 'shown' : 'hidden';
        return [
            'success' => true,
            'message' => "Widget '{$widget['title']}' is now {$actionWord} on your personal dashboard."
        ];
    }

    /**
     * User Customization: Reorder widgets for the user.
     * SEC-WIDGET-01: Validates authorization of every widget before persisting.
     * Prevents Unauthorized Widget Assignment Injection via Reorder.
     */
    public function reorderUserWidgets(string $userId, array $orderedWidgetIds, ?string $canonicalRole = null, ?string $companyId = null): array
    {
        if (empty($orderedWidgetIds) || !is_array($orderedWidgetIds)) {
            return [
                'success' => false,
                'code'    => 400,
                'message' => 'Invalid or empty widget order sequence provided.'
            ];
        }

        // Validate duplicates
        if (count($orderedWidgetIds) !== count(array_unique($orderedWidgetIds))) {
            return [
                'success' => false,
                'code'    => 400,
                'message' => 'Duplicate widget identifiers in reorder payload are not permitted.'
            ];
        }

        // Resolve canonical role and company context if not passed
        if (empty($canonicalRole)) {
            $session = \Config\Services::session();
            $roleCode = (string)($session->get('role') ?? $session->get('role_code') ?? '');
            if (empty($roleCode) && $userId) {
                $userRow = (new \App\Models\UserModel())->find($userId);
                if ($userRow && !empty($userRow['role_id'])) {
                    $roleRow = (new \App\Models\RoleModel())->find($userRow['role_id']);
                    $roleCode = $roleRow['slug'] ?? $roleRow['name'] ?? '';
                }
            }
            $canonicalRole = $this->permissionService->canonicalizeRole($roleCode ?: 'employee');
        }

        if (empty($companyId)) {
            $session = \Config\Services::session();
            $companyId = $session->get('company_id');
            if (empty($companyId) && $userId) {
                $userRow = (new \App\Models\UserModel())->find($userId);
                $companyId = $userRow['company_id'] ?? null;
            }
        }

        $subscriptionPlan = 'starter';
        if ($companyId) {
            $compModel = new \App\Models\CompanyModel();
            $comp = $compModel->find($companyId);
            if ($comp && !empty($comp['subscription_plan'])) {
                $subscriptionPlan = strtolower($comp['subscription_plan']);
            }
        } elseif ($canonicalRole === 'software_app_admin') {
            $subscriptionPlan = 'enterprise';
        }

        $scope = $this->resolveUserScope($userId, $companyId, $canonicalRole);
        $scopeType = $scope['type'] ?? (in_array($canonicalRole, ['company_admin', 'hr_admin', 'hr_officer', 'finance', 'auditor'], true) ? 'company' : 'self');

        // Validate all widgets in the reorder payload upfront
        $validatedWidgets = [];
        foreach ($orderedWidgetIds as $wId) {
            if (!is_string($wId) || trim($wId) === '') {
                return [
                    'success' => false,
                    'code'    => 400,
                    'message' => 'Malformed widget identifier in ordering sequence.'
                ];
            }

            $widget = $this->widgetModel->where('id', $wId)->orWhere('code', $wId)->first();
            if (!$widget) {
                $catalogItem = DashboardWidgetRegistry::getByCode($wId);
                if ($catalogItem) {
                    $widget = $this->widgetModel->where('code', $catalogItem['code'])->first();
                }
            }

            if (!$widget) {
                return [
                    'success' => false,
                    'code'    => 404,
                    'message' => "Unknown widget identifier '{$wId}' in ordering payload."
                ];
            }

            // CRITICAL INVARIANT: "Users cannot enable or order unauthorized or admin-disabled widgets."
            $auth = $this->isWidgetAuthorizedForUser($widget, $canonicalRole, $companyId, $userId, $scopeType, $subscriptionPlan);
            if (!$auth['authorized']) {
                return [
                    'success' => false,
                    'code'    => 403,
                    'message' => "Unauthorized widget '{$widget['title']}' (code: {$widget['code']}) cannot be ordered: {$auth['reason']}"
                ];
            }

            $adminCheck = $this->isWidgetAdminDisabled($widget, $canonicalRole, $companyId, $userId, $scope);
            if ($adminCheck['disabled']) {
                return [
                    'success' => false,
                    'code'    => 403,
                    'message' => "Unauthorized: Widget '{$widget['title']}' cannot be ordered because it has been disabled by an administrative policy ({$adminCheck['reason']})."
                ];
            }

            $validatedWidgets[] = $widget;
        }

        // All submitted widgets are verified authorized; persist updated ordering sequence
        $this->db->transBegin();
        try {
            foreach ($validatedWidgets as $index => $widget) {
                $sortOrder = $index + 1;
                $realId = $widget['id'];

                $this->widgetAssignmentModel->saveAssignment('user', $userId, $realId, [
                    'sort_order' => $sortOrder,
                    'position'   => $sortOrder,
                ]);
            }

            if ($this->db->transStatus() === false) {
                $this->db->transRollback();
                return ['success' => false, 'code' => 500, 'message' => 'Failed to persist reordered widget sequence.'];
            }

            $this->db->transCommit();
        } catch (\Throwable $e) {
            $this->db->transRollback();
            log_message('error', 'reorderUserWidgets error: ' . $e->getMessage());
            return ['success' => false, 'code' => 500, 'message' => 'Database error while reordering widgets.'];
        }

        return ['success' => true, 'message' => 'Dashboard widget order updated successfully.'];
    }

    /**
     * User Customization: Resize widget width for the user.
     */
    public function resizeUserWidget(string $userId, string $widgetIdOrCode, string $gridWidth): array
    {
        $allowedWidths = ['half', 'full', 'two_thirds', 'third', 'quarter'];
        if (!in_array($gridWidth, $allowedWidths, true)) {
            $gridWidth = 'half';
        }

        $widget = $this->widgetModel->where('id', $widgetIdOrCode)->orWhere('code', $widgetIdOrCode)->first();
        if (!$widget) {
            return ['success' => false, 'code' => 404, 'message' => 'Widget not found.'];
        }

        $this->db->transBegin();
        try {
            $this->widgetAssignmentModel->saveAssignment('user', $userId, $widget['id'], [
                'grid_width' => $gridWidth,
            ]);

            if ($this->db->transStatus() === false) {
                $this->db->transRollback();
                return ['success' => false, 'code' => 500, 'message' => 'Failed to resize widget.'];
            }

            $this->db->transCommit();
        } catch (\Throwable $e) {
            $this->db->transRollback();
            log_message('error', 'resizeUserWidget error: ' . $e->getMessage());
            return ['success' => false, 'code' => 500, 'message' => 'Database error while resizing widget.'];
        }

        return ['success' => true, 'message' => "Widget '{$widget['title']}' width resized to '{$gridWidth}'."];
    }

    /**
     * User Customization: Reset all user widget preferences back to default.
     */
    public function resetUserPreferences(string $userId): array
    {
        $this->db->transBegin();
        try {
            $this->widgetAssignmentModel->where('scope_type', 'user')->where('scope_id', $userId)->delete();

            if ($this->db->transStatus() === false) {
                $this->db->transRollback();
                return ['success' => false, 'message' => 'Failed to reset preferences.'];
            }

            $this->db->transCommit();
        } catch (\Throwable $e) {
            $this->db->transRollback();
            log_message('error', 'resetUserPreferences error: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Database error while resetting user preferences.'];
        }

        $this->auditService->log(
            $userId,
            'dashboard_preferences',
            'Reset User Dashboard Preferences',
            $userId,
            [],
            ['message' => "User {$userId} reset personalized dashboard widgets back to system role defaults."]
        );

        return ['success' => true, 'message' => 'Your dashboard layout and widgets have been reset to role defaults.'];
    }

    /**
     * User Customization: Batch Save all user preferences.
     * CRITICAL INVARIANT: "Users cannot enable unauthorized widgets."
     */
    public function saveUserPreferences(string $userId, array $preferences, ?string $canonicalRole = null, ?string $companyId = null): array
    {
        if ((empty($companyId) || empty($canonicalRole)) && $userId) {
            $userRow = (new \App\Models\UserModel())->find($userId);
            if ($userRow) {
                if (empty($companyId) && !empty($userRow['company_id'])) {
                    $companyId = $userRow['company_id'];
                }
                if (empty($canonicalRole) && !empty($userRow['role_id'])) {
                    $rRow = (new \App\Models\RoleModel())->find($userRow['role_id']);
                    if ($rRow) {
                        $canonicalRole = $this->permissionService->canonicalizeRole($rRow['code'] ?? $rRow['name'] ?? 'employee');
                    }
                }
            }
        }
        if (empty($canonicalRole)) {
            $session = \Config\Services::session();
            $canonicalRole = $this->permissionService->canonicalizeRole($session ? ($session->get('role_code') ?? $session->get('role') ?? 'employee') : 'employee');
        }

        $subscriptionPlan = 'starter';
        if ($companyId) {
            $compModel = new \App\Models\CompanyModel();
            $comp = $compModel->find($companyId);
            if ($comp && !empty($comp['subscription_plan'])) {
                $subscriptionPlan = strtolower($comp['subscription_plan']);
            }
        } elseif ($canonicalRole === 'software_app_admin') {
            $subscriptionPlan = 'enterprise';
        }

        $scope = $this->resolveUserScope($userId, $companyId, $canonicalRole);
        $scopeType = $scope['type'] ?? (in_array($canonicalRole, ['company_admin', 'hr_admin', 'hr_officer', 'finance', 'auditor'], true) ? 'company' : 'self');

        $this->db->transBegin();
        try {
            foreach ($preferences as $index => $pref) {
                $wId = $pref['widget_id'] ?? $pref['id'] ?? $pref['code'] ?? '';
                $status = isset($pref['status']) ? (int)$pref['status'] : 1;
                $gridWidth = $pref['grid_width'] ?? 'half';
                $sortOrder = isset($pref['sort_order']) ? (int)$pref['sort_order'] : ($index + 1);

                $widget = $this->widgetModel->where('id', $wId)->orWhere('code', $wId)->first();
                if (!$widget) {
                    continue;
                }

                // CRITICAL INVARIANT: "Users cannot enable unauthorized or admin-disabled widgets."
                if ($status === 1) {
                    $auth = $this->isWidgetAuthorizedForUser($widget, $canonicalRole, $companyId, $userId, $scopeType, $subscriptionPlan);
                    if (!$auth['authorized']) {
                        $this->db->transRollback();
                        return [
                            'success' => false,
                            'code'    => 403,
                            'message' => "Cannot enable unauthorized widget '{$widget['title']}': {$auth['reason']}"
                        ];
                    }

                    $adminCheck = $this->isWidgetAdminDisabled($widget, $canonicalRole, $companyId, $userId, $scope);
                    if ($adminCheck['disabled']) {
                        $this->db->transRollback();
                        return [
                            'success' => false,
                            'code'    => 403,
                            'message' => "Unauthorized: Cannot enable widget '{$widget['title']}' because it has been disabled by an administrative policy ({$adminCheck['reason']})."
                        ];
                    }
                }

                $this->widgetAssignmentModel->saveAssignment('user', $userId, $widget['id'], [
                    'status'     => $status,
                    'is_visible' => $status,
                    'sort_order' => $sortOrder,
                    'position'   => $sortOrder,
                    'grid_width' => $gridWidth,
                ]);
            }

            if ($this->db->transStatus() === false) {
                $this->db->transRollback();
                return ['success' => false, 'message' => 'Failed to save dashboard preferences.'];
            }

            $this->db->transCommit();
        } catch (\Throwable $e) {
            $this->db->transRollback();
            log_message('error', 'saveUserPreferences error: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Database error while saving dashboard preferences.'];
        }

        return ['success' => true, 'message' => 'Dashboard preferences saved successfully.'];
    }
}
