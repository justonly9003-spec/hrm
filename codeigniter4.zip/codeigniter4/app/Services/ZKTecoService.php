<?php

namespace App\Services;

use App\Models\AttendanceModel;
use App\Models\BiometricDeviceModel;
use App\Models\EmployeeModel;
use App\Services\BiometricMappingService;
use Config\Database;
use Ramsey\Uuid\Uuid;

/**
 * ZKTeco Direct Network Protocol & SDK Connector Service
 * Supports TCP/UDP Port 4370 socket communication with ZKTeco, ZKFinger,
 * IFace, MB20, K40, F18, and compatible standalone biometric terminals.
 */
class ZKTecoService
{
    const CMD_CONNECT = 1000;
    const CMD_EXIT = 1001;
    const CMD_ENABLEDEVICE = 1002;
    const CMD_DISABLEDEVICE = 1003;
    const CMD_RESTART = 1004;
    const CMD_POWEROFF = 1005;
    const CMD_SLEEP = 1006;
    const CMD_RESUME = 1007;
    const CMD_GET_VERSION = 1100;
    const CMD_GET_TIME = 201;
    const CMD_SET_TIME = 202;
    const CMD_ATTLOG_RRQ = 13;
    const CMD_PREPARE_DATA = 1500;
    const CMD_DATA = 1501;
    const CMD_FREE_DATA = 1502;
    const CMD_READ_BUFFER = 1503;
    const CMD_DATA_RDY = 1504;
    const CMD_CLEAR_DATA = 14;
    const CMD_CLEAR_ATTLOG = 15;
    const CMD_USERTEMP_RRQ = 9;
    const CMD_AUTH = 1102;

    const CMD_ACK_OK = 2000;
    const CMD_ACK_ERROR = 2001;
    const CMD_ACK_DATA = 2002;
    const CMD_ACK_UNAUTH = 2005;
    const CMD_ACK_ERROR_DATA = 65531;

    const SYNC_LOOKBACK_SECONDS = 86400;

    protected $db;
    protected $deviceModel;
    protected $attendanceModel;
    protected $employeeModel;
    protected $mappingService;
    protected $lastResponseCommand;
    protected ?AttendanceService $attendanceService = null;

    protected function getAttendanceService(): AttendanceService
    {
        if ($this->attendanceService === null) {
            $this->attendanceService = new AttendanceService();
        }
        return $this->attendanceService;
    }

    public function __construct()
    {
        $this->db = Database::connect();
        $this->deviceModel = new BiometricDeviceModel();
        $this->attendanceModel = new AttendanceModel();
        $this->employeeModel = new EmployeeModel();
        $this->mappingService = new BiometricMappingService();
    }

    /**
     * Test TCP/UDP socket ping to the ZKTeco IP
     */
    public function testConnection(string $ip, int $port = 4370, int $timeout = 3): array
    {
        return $this->deviceModel->testSocketConnection($ip, $port, $timeout);
    }

    /**
     * Synchronize attendance logs from a specific device
     */
    public function syncDevice(string $deviceId, string $triggerType = 'Direct IP Sync', ?string $companyId = null, bool $forceAll = false): array
    {
        $device = $this->deviceModel->find($deviceId);
        if (!$device) {
            return [
                'success' => false,
                'synced_records' => 0,
                'message' => 'Device not found in system register.'
            ];
        }

        // SEC-ATT-07: Scope device lookup to company_id if tenant context provided
        if (!empty($companyId) && !empty($device['company_id']) && (string)$device['company_id'] !== (string)$companyId) {
            log_message('warning', "SEC-ATT-07: Cross-tenant device sync attempt: device {$deviceId} belongs to {$device['company_id']}, requested by {$companyId}");
            return [
                'success' => false,
                'synced_records' => 0,
                'message' => 'Cross-tenant device sync violation.'
            ];
        }
        $companyId = $device['company_id'] ?: $companyId;

        $ip = $device['ip_address'];
        $port = (int) ($device['port'] ?: 4370);

        if (isset($device['is_active']) && (int)$device['is_active'] !== 1) {
            return [
                'success' => false,
                'synced_records' => 0,
                'message' => 'Device is disabled.'
            ];
        }

        if (function_exists('set_time_limit')) {
            @set_time_limit(300);
        }
        @ini_set('max_execution_time', '300');

        // 1. Probe connectivity
        $probe = $this->testConnection($ip, $port, 2);

        $syncedPunches = 0;
        $recordsFetched = 0;
        $duplicatesSkipped = 0;
        $recordsFailed = 0;
        $startedAt = date('Y-m-d H:i:s');
        $completedAt = null;
        $status = 'Success';
        $errorMessage = null;

        $isFresh = $forceAll || empty($device['last_sync_at']);

        if ($probe['online']) {
            try {
                // Read attendance records from device over socket (outside database transaction)
                $records = $this->readAttendanceRecords($device);
                $records = $this->normalizeRecordTimes($records, $device);
                $recordsFetched = count($records);

                // Incremental pull filter: if already synced before and not a forced fresh pull,
                // only process records after the last sync timestamp (with SYNC_LOOKBACK_SECONDS safety window for clock drift)
                $recordsToProcess = $records;
                $cutoffDate = null;
                if (!$isFresh && !empty($device['last_sync_at'])) {
                    $cutoffTimestamp = strtotime($device['last_sync_at']) - self::SYNC_LOOKBACK_SECONDS;
                    $cutoffDate = date('Y-m-d H:i:s', $cutoffTimestamp);
                    $recordsToProcess = [];
                    foreach ($records as $r) {
                        $eventTs = !empty($r['event_time']) ? strtotime($r['event_time']) : 0;
                        if ($eventTs >= $cutoffTimestamp) {
                            $recordsToProcess[] = $r;
                        }
                    }
                }

                if (count($recordsToProcess) === 0 && $recordsFetched > 0) {
                    // Fast path: No new punches on device since last sync
                    $now = date('Y-m-d H:i:s');
                    $this->deviceModel->update($deviceId, [
                        'status'            => 'Online',
                        'last_connected_at' => $now,
                        'last_sync_at'      => $now
                    ]);

                    $this->db->table('attendance_sync_logs')->insert([
                        'id'                 => Uuid::uuid4()->toString(),
                        'company_id'         => $companyId,
                        'device_id'          => $device['id'],
                        'sync_type'          => $triggerType . ' (Incremental)',
                        'records_synced'     => 0,
                        'started_at'         => $startedAt,
                        'completed_at'       => $now,
                        'records_fetched'    => $recordsFetched,
                        'records_inserted'   => 0,
                        'duplicates_skipped' => 0,
                        'records_failed'     => 0,
                        'status'             => 'Success',
                        'error_message'      => null,
                        'sync_time'          => $now
                    ]);

                    return [
                        'success'        => true,
                        'synced_records' => 0,
                        'mode'           => 'incremental',
                        'device'         => $device,
                        'probe'          => $probe,
                        'message'        => "Device '{$device['device_name']}' is up to date: 0 new punches since last sync ({$device['last_sync_at']}). Fast incremental scan checked {$recordsFetched} logs."
                    ];
                }

                if (count($recordsToProcess) > 0) {
                    // Preload existing event hashes in a single query for O(1) duplicate checks
                    $hashQuery = $this->db->table('biometric_attendance_events')
                        ->select('event_hash')
                        ->where('company_id', $companyId)
                        ->where('device_id', $device['id']);
                    if (!empty($cutoffDate)) {
                        $hashQuery->where('event_time >=', $cutoffDate);
                    }
                    $existingRows = $hashQuery->get()->getResultArray();

                    $existingHashSet = [];
                    foreach ($existingRows as $row) {
                        if (!empty($row['event_hash'])) {
                            $existingHashSet[$row['event_hash']] = true;
                        }
                    }

                    $employeeCache = [];
                    $pendingNewEvents = [];

                    foreach ($recordsToProcess as $record) {
                        $hash = hash('sha256', implode('|', [
                            $companyId,
                            $device['id'],
                            $record['device_event_id'] ?? '',
                            $record['device_user_id'],
                            $record['device_event_time'] ?? $record['event_time'],
                            $record['raw_payload'] ?? ''
                        ]));

                        if (isset($existingHashSet[$hash])) {
                            $duplicatesSkipped++;
                            continue;
                        }

                        // Mark seen immediately to prevent intra-batch duplicate insertion
                        $existingHashSet[$hash] = true;

                        // Cache employee mapping lookups
                        $devUserId = (string)$record['device_user_id'];
                        if (!array_key_exists($devUserId, $employeeCache)) {
                            $employeeCache[$devUserId] = $this->mappingService->resolveEmployeeForBiometricPunch(
                                $devUserId,
                                $companyId,
                                $device['id']
                            );
                        }
                        $mapping = $employeeCache[$devUserId];

                        $pendingNewEvents[] = [
                            'record'  => $record,
                            'hash'    => $hash,
                            'mapping' => $mapping,
                        ];
                    }

                    // Process and commit new punches in small batches to release DB locks quickly
                    usort($pendingNewEvents, static function ($a, $b) {
                        return [$a['record']['event_time'], (string) ($a['record']['device_event_id'] ?? '')]
                           <=> [$b['record']['event_time'], (string) ($b['record']['device_event_id'] ?? '')];
                    });
                    $chunks = array_chunk($pendingNewEvents, 50);
                    foreach ($chunks as $chunk) {
                        $this->db->transStart();
                        foreach ($chunk as $item) {
                            try {
                                $rec = $item['record'];
                                $map = $item['mapping'];
                                $this->db->table('biometric_attendance_events')->insert([
                                    'id'              => Uuid::uuid4()->toString(),
                                    'company_id'      => $companyId,
                                    'device_id'       => $device['id'],
                                    'device_user_id'  => $rec['device_user_id'],
                                    'event_time'      => $rec['event_time'],
                                    'device_event_id' => $rec['device_event_id'],
                                    'event_hash'      => $item['hash'],
                                    'raw_payload'     => $rec['raw_payload'],
                                    'employee_id'     => $map['id'] ?? null,
                                    'created_at'      => date('Y-m-d H:i:s'),
                                ]);

                                if ($map) {
                                    $timestamp = strtotime($rec['event_time']);
                                    $this->ingestPunchRecord(
                                        $map['id'],
                                        date('Y-m-d', $timestamp),
                                        date('H:i:s', $timestamp),
                                        "ZK Device: {$device['device_name']}"
                                    );
                                } else {
                                    $this->mappingService->recordUnmatchedPunch($rec, $companyId, $device);
                                }
                                $syncedPunches++;
                            } catch (\Throwable $recordError) {
                                $recordsFailed++;
                                log_message('error', 'ZKTeco event import failed: ' . $recordError->getMessage());
                            }
                        }
                        $this->db->transComplete();
                    }
                }

                if ($recordsFailed > 0) {
                    $status = $syncedPunches > 0 || $duplicatesSkipped > 0 ? 'Partial' : 'Failed';
                }
                $now = date('Y-m-d H:i:s');
                $deviceUpdates = [
                    'status'            => 'Online',
                    'last_connected_at' => $now,
                ];
                if ($recordsFailed === 0) {
                    $deviceUpdates['last_sync_at'] = $now;
                }
                $this->deviceModel->update($deviceId, $deviceUpdates);
                $completedAt = date('Y-m-d H:i:s');
            } catch (\Throwable $e) {
                $status = 'Failed';
                $errorMessage = 'Protocol exchange failed: ' . $e->getMessage();
                log_message('error', 'ZKTeco sync failed: ' . $e->getMessage());
                $this->deviceModel->update($deviceId, ['status' => 'Offline']);
            }
        } else {
            $status = 'Failed';
            $errorMessage = $probe['message'];

            $this->deviceModel->update($deviceId, [
                'status' => 'Offline',
            ]);
        }

        // Insert sync log
        $this->db->table('attendance_sync_logs')->insert([
            'id'             => Uuid::uuid4()->toString(),
            'company_id'     => $companyId,
            'device_id'      => $device['id'],
            'sync_type'      => $triggerType . ($isFresh ? ' (Full/Fresh)' : ' (Incremental)'),
            'records_synced' => $syncedPunches,
            'started_at'     => $startedAt,
            'completed_at'   => $completedAt ?: date('Y-m-d H:i:s'),
            'records_fetched' => $recordsFetched,
            'records_inserted' => $syncedPunches,
            'duplicates_skipped' => $duplicatesSkipped,
            'records_failed' => $recordsFailed,
            'status'         => $status,
            'error_message'  => $errorMessage,
            'sync_time'      => date('Y-m-d H:i:s')
        ]);

        $summaryMsg = $isFresh
            ? "Fresh full sync completed: {$syncedPunches} new punches ingested ({$recordsFetched} total records on device, {$duplicatesSkipped} duplicates skipped)."
            : "Incremental sync completed: {$syncedPunches} new punches ingested ({$duplicatesSkipped} duplicate logs skipped, scanned {$recordsFetched} terminal logs).";

        return [
            'success'        => $status === 'Success',
            'synced_records' => $syncedPunches,
            'mode'           => $isFresh ? 'fresh' : 'incremental',
            'device'         => $device,
            'probe'          => $probe,
            'message'        => $status === 'Success' 
                ? $summaryMsg
                : (($probe['online'] ? "Device at {$ip}:{$port} is reachable. " : "Could not reach device at {$ip}:{$port}. ") . $errorMessage)
        ];
    }

    protected function normalizeRecordTimes(array $records, array $device): array
    {
        $tz = trim((string) ($device['timezone'] ?? ''));
        $appTz = config('App')->appTimezone ?? date_default_timezone_get();
        foreach ($records as &$r) {
            $r['device_event_time'] = $r['event_time'] ?? null;
        }
        unset($r);
        if ($tz === '' || $tz === $appTz) {
            return $records;
        }
        try {
            $from = new \DateTimeZone($tz);
            $to   = new \DateTimeZone($appTz);
        } catch (\Throwable $e) {
            return $records;
        }
        foreach ($records as &$r) {
            if (empty($r['event_time'])) { continue; }
            try {
                $dt = new \DateTime($r['event_time'], $from);
                $dt->setTimezone($to);
                $r['event_time'] = $dt->format('Y-m-d H:i:s');
            } catch (\Throwable $e) {}
        }
        unset($r);
        return $records;
    }

    protected function readAttendanceRecords(array $device): array
    {
        $protocol = strtoupper(trim($device['protocol'] ?? 'AUTO'));
        $ip = $device['ip_address'];
        $port = (int)($device['port'] ?: 4370);
        $errors = [];

        // Auto-negotiation / Protocol selection:
        // Standalone ZKTeco terminals (F22/ID, F18, K40, uFace) listen on UDP 4370 as their primary transport.
        // Even when TCP 4370 port is open, the ZK binary exchange commonly requires UDP datagrams.
        if ($protocol === 'UDP') {
            try {
                return $this->readAttendanceRecordsViaUdp($device);
            } catch (\Throwable $e) {
                $errors[] = "UDP: " . $e->getMessage();
                try {
                    return $this->readAttendanceRecordsViaTcp($device);
                } catch (\Throwable $te) {
                    $errors[] = "TCP Fallback: " . $te->getMessage();
                }
            }
        } elseif ($protocol === 'TCP') {
            try {
                return $this->readAttendanceRecordsViaTcp($device);
            } catch (\Throwable $e) {
                $errors[] = "TCP: " . $e->getMessage();
                try {
                    return $this->readAttendanceRecordsViaUdp($device);
                } catch (\Throwable $ue) {
                    $errors[] = "UDP Fallback: " . $ue->getMessage();
                }
            }
        } else {
            // AUTO, STANDALONE, or unspecified: Try UDP first (standard for F22, F18, K40), then TCP
            try {
                return $this->readAttendanceRecordsViaUdp($device);
            } catch (\Throwable $e) {
                $errors[] = "UDP: " . $e->getMessage();
                try {
                    return $this->readAttendanceRecordsViaTcp($device);
                } catch (\Throwable $te) {
                    $errors[] = "TCP: " . $te->getMessage();
                }
            }
        }

        $hint = " Diagnostic checklist: 1) Protocol: F22/ID, F18, and K40 standalone devices require UDP protocol on port 4370. 2) Comm Key: In the terminal hardware menu (Comm -> PC Connection -> Comm Key / Password), verify the value matches (default is 0). 3) Network: Device at {$ip}:{$port} must be directly reachable via bidirectional UDP/TCP without NAT/firewall drop.";
        throw new \RuntimeException(implode(" | ", $errors) . $hint);
    }

    /**
     * Read attendance punches using ZKTeco UDP Protocol (Standard for F22/ID, F18, K40, MB20)
     */
    protected function readAttendanceRecordsViaUdp(array $device): array
    {
        $ip = $device['ip_address'];
        $port = (int)($device['port'] ?: 4370);
        $socket = @fsockopen("udp://{$ip}", $port, $errno, $errstr, 3);
        if (!$socket) {
            throw new \RuntimeException("Could not open UDP socket to {$ip}:{$port}: {$errstr} ({$errno})");
        }
        stream_set_timeout($socket, 3);

        $sessionId = 0;
        $replyId = 65534; // ZKTeco sequence begins at 65534 (USHRT_MAX - 1)

        try {
            // 1. Initial Handshake (CMD_CONNECT = 1000)
            $this->sendUdpCommand($socket, self::CMD_CONNECT, '', $sessionId, $replyId);

            // 2. Authentication if unauthorized or communication key specified
            $commKey = (int)($device['comm_key'] ?? 0);
            if ($this->lastResponseCommand === self::CMD_ACK_UNAUTH) {
                try {
                    $authKey = $this->makeCommunicationKey($commKey, $sessionId);
                    $this->sendUdpCommand($socket, self::CMD_AUTH, $authKey, $sessionId, $replyId);
                } catch (\Throwable $authErr) {
                    throw new \RuntimeException("Authentication rejected by device (Comm Key mismatch). Current key: '{$commKey}'. Check device Menu > Comm. > PC Connection > Comm Key.");
                }
            } elseif ($commKey > 0 && $this->lastResponseCommand !== self::CMD_ACK_OK) {
                try {
                    $authKey = $this->makeCommunicationKey($commKey, $sessionId);
                    $this->sendUdpCommand($socket, self::CMD_AUTH, $authKey, $sessionId, $replyId);
                } catch (\Throwable $authErr) {
                    // Ignore if device was already authorized without auth exchange
                }
            }

            // 3. Disable device during read to freeze punch buffer
            try {
                $this->sendUdpCommand($socket, self::CMD_DISABLEDEVICE, '', $sessionId, $replyId);
            } catch (\Throwable $t) {}

            // 4. Download attendance payload
            $payload = $this->readPreparedDataUdp($socket, $sessionId, $replyId, self::CMD_ATTLOG_RRQ);

            // 5. Re-enable terminal
            try {
                $this->sendUdpCommand($socket, self::CMD_ENABLEDEVICE, '', $sessionId, $replyId);
            } catch (\Throwable $t) {}

            // 6. Graceful session exit
            try {
                $this->sendUdpCommand($socket, self::CMD_EXIT, '', $sessionId, $replyId);
            } catch (\Throwable $t) {}

            fclose($socket);

            return $this->parseAttendanceRecords($payload);
        } catch (\Throwable $e) {
            @fclose($socket);
            throw $e;
        }
    }

    /**
     * Transmit single UDP command datagram and parse 8-byte ZK response envelope
     */
    protected function sendUdpCommand($socket, int $command, string $payload, int &$sessionId, ?int &$replyId = null): string
    {
        if ($replyId === null) {
            $replyId = 65534;
        }
        $packet = $this->buildPacket($command, $payload, $sessionId, $replyId);
        $written = @fwrite($socket, $packet);
        if ($written === false || $written === 0) {
            throw new \RuntimeException("Failed to transmit UDP packet for command {$command}.");
        }

        $response = @fread($socket, 65535);
        if ($response === false || strlen($response) < 8) {
            $meta = stream_get_meta_data($socket);
            if (!empty($meta['timed_out'])) {
                throw new \RuntimeException("UDP response timed out for command {$command}.");
            }
            throw new \RuntimeException("Empty or truncated UDP response for command {$command}.");
        }

        $parts = unpack('vcommand/vchecksum/vsession/vreply', substr($response, 0, 8));
        $this->lastResponseCommand = (int)$parts['command'];
        if ($parts['session'] > 0 || $command === self::CMD_CONNECT) {
            $sessionId = (int)$parts['session'];
        }
        // Sequence replyId is incremented monotonically by buildPacket(), do not overwrite with server response

        if (in_array($parts['command'], [self::CMD_ACK_ERROR, self::CMD_ACK_ERROR_DATA, 65532, 65533], true)) {
            throw new \RuntimeException("Device rejected command {$command} with ACK code {$parts['command']}.");
        }

        return substr($response, 8);
    }

    /**
     * Stream prepared buffer chunks or direct log response over UDP
     */
    protected function readPreparedDataUdp($socket, int &$sessionId, int &$replyId, int $command): string
    {
        // Try Method A: CMD_READ_BUFFER with command parameter (ZK6001 / Linux firmware)
        try {
            $response = $this->sendUdpCommand($socket, self::CMD_READ_BUFFER, pack('cvVV', 1, $command, 0, 0), $sessionId, $replyId);
            if (strlen($response) >= 4) {
                $size = unpack('Vsize', substr($response, 0, 4))['size'];
                if ($size > 0 && $size < 50000000) {
                    $data = '';
                    $chunkSize = 1024;
                    for ($offset = 0; $offset < $size; $offset += $chunkSize) {
                        $length = min($chunkSize, $size - $offset);
                        $chunk = $this->sendUdpCommand($socket, self::CMD_DATA_RDY, pack('VV', $offset, $length), $sessionId, $replyId);
                        $data .= $chunk;
                    }
                    try {
                        $this->sendUdpCommand($socket, self::CMD_FREE_DATA, '', $sessionId, $replyId);
                    } catch (\Throwable $t) {}
                    return substr($data, 0, $size);
                }
            }
        } catch (\Throwable $e) {
            // Fall back to Method B
        }

        // Method B: Direct CMD_ATTLOG_RRQ
        $response = $this->sendUdpCommand($socket, $command, '', $sessionId, $replyId);
        if ($this->lastResponseCommand === self::CMD_PREPARE_DATA) {
            $size = strlen($response) >= 4 ? unpack('Vsize', substr($response, 0, 4))['size'] : 0;
            $data = '';
            $maxAttempts = 1000;
            while ($maxAttempts-- > 0) {
                $chunk = @fread($socket, 65535);
                if ($chunk === false || strlen($chunk) < 8) {
                    break;
                }
                $parts = unpack('vcommand/vchecksum/vsession/vreply', substr($chunk, 0, 8));
                if ($parts['command'] === self::CMD_DATA) {
                    $data .= substr($chunk, 8);
                } elseif ($parts['command'] === self::CMD_ACK_OK) {
                    break;
                }
                if ($size > 0 && strlen($data) >= $size) {
                    break;
                }
            }
            return $size > 0 ? substr($data, 0, $size) : $data;
        }

        return $response;
    }

    /**
     * Read attendance punches using ZKTeco TCP Protocol (Enveloped & Raw)
     */
    protected function readAttendanceRecordsViaTcp(array $device): array
    {
        $ip = $device['ip_address'];
        $port = (int)($device['port'] ?: 4370);
        $socket = @fsockopen($ip, $port, $errno, $errstr, 3);
        if (!$socket) {
            throw new \RuntimeException("TCP socket unavailable to {$ip}:{$port}: {$errstr} ({$errno})");
        }
        stream_set_timeout($socket, 3);
        $sessionId = 0;
        $replyId = 65534;

        try {
            $this->sendCommand($socket, self::CMD_CONNECT, '', $sessionId, $replyId);
            $commKey = (int)($device['comm_key'] ?? 0);
            if ($this->lastResponseCommand === self::CMD_ACK_UNAUTH) {
                try {
                    $authKey = $this->makeCommunicationKey($commKey, $sessionId);
                    $this->sendCommand($socket, self::CMD_AUTH, $authKey, $sessionId, $replyId);
                } catch (\Throwable $authErr) {
                    throw new \RuntimeException("Authentication rejected by device (Comm Key mismatch). Current key: '{$commKey}'. Check device Menu > Comm. > PC Connection > Comm Key.");
                }
            } elseif ($commKey > 0 && $this->lastResponseCommand !== self::CMD_ACK_OK) {
                try {
                    $authKey = $this->makeCommunicationKey($commKey, $sessionId);
                    $this->sendCommand($socket, self::CMD_AUTH, $authKey, $sessionId, $replyId);
                } catch (\Throwable $authErr) {
                    // Ignore if device was already authorized
                }
            }

            try {
                $this->sendCommand($socket, self::CMD_DISABLEDEVICE, '', $sessionId, $replyId);
            } catch (\Throwable $t) {}

            $payload = $this->readPreparedData($socket, $sessionId, $replyId, self::CMD_ATTLOG_RRQ);

            try {
                $this->sendCommand($socket, self::CMD_ENABLEDEVICE, '', $sessionId, $replyId);
            } catch (\Throwable $t) {}

            try {
                $this->sendCommand($socket, self::CMD_EXIT, '', $sessionId, $replyId);
            } catch (\Throwable $t) {}

            fclose($socket);

            return $this->parseAttendanceRecords($payload);
        } catch (\Throwable $e) {
            @fclose($socket);
            throw $e;
        }
    }

    /**
     * Parse a single raw biometric attendance record (binary chunk of 40, 16, or 14 bytes, or its hex representation).
     *
     * Standard 40-byte ZKTeco TFT structure (unpack format: 'vuid/a24userid/Cstate/Vtime/Cpunch/a8space'):
     * - Bytes 0..1  (2 bytes, 'v'): Device internal numeric enrollment ID (uid)
     * - Bytes 2..25 (24 bytes, 'a24'): Alphanumeric User ID / Employee PIN (null-padded string)
     * - Byte 26     (1 byte,  'C'): State / Verification mode
     * - Bytes 27..30(4 bytes, 'V'): Encoded 32-bit timestamp
     * - Byte 31     (1 byte,  'C'): Punch type (0 = In, 1 = Out, etc.)
     * - Bytes 32..39(8 bytes, 'a8'): Reserved / Workcode padding
     */
    public function parseSingleAttendanceRecord(string $chunk): ?array
    {
        // If passed as hex-encoded string (e.g. from raw_payload column in DB)
        if (ctype_xdigit($chunk) && (strlen($chunk) === 80 || strlen($chunk) === 32 || strlen($chunk) === 28)) {
            $chunk = (string)hex2bin($chunk);
        }

        $length = strlen($chunk);

        // Modern 40-byte record format (F22/ID, F18, K40, uFace, MB20, etc.)
        if ($length === 40) {
            $u = unpack('vuid/a24userid/Cstate/Vtime/Cpunch/a8space', $chunk);
            if (!$u) {
                return null;
            }

            $uid = (int)($u['uid'] ?? 0);
            $rawUserId = (string)($u['userid'] ?? '');

            // Extract string up to first null byte (\0 termination)
            $userId = trim(explode("\0", $rawUserId, 2)[0]);
            // Strip non-printable control characters while preserving standard printable characters
            $userId = preg_replace('/[^\x20-\x7E]/', '', $userId);
            $userId = trim($userId);

            // If extended string user ID is empty, fallback to numeric device UID (if > 0)
            if ($userId === '' && $uid > 0) {
                $userId = (string)$uid;
            }

            // Reject if no valid identity can be recovered
            if ($userId === '') {
                return null;
            }

            // Primary: Standard ZKTeco packed 32-bit timestamp at byte offset 27 ('Vtime')
            $eventTime = $this->decodeTime((int)($u['time'] ?? 0));

            // Fallback: Explicit calendar components if firmware used alternative 8-byte date/time struct (starting after state at offset 27)
            if (!$eventTime) {
                $exp = unpack('vyear/Cmonth/Cday/Chour/Cminute/Csecond', substr($chunk, 27, 8));
                if ($exp && $exp['year'] >= 2000 && $exp['year'] <= 2050 && $exp['month'] >= 1 && $exp['month'] <= 12 && $exp['day'] >= 1 && $exp['day'] <= 31 && checkdate($exp['month'], $exp['day'], $exp['year'])) {
                    $eventTime = sprintf('%04d-%02d-%02d %02d:%02d:%02d', $exp['year'], $exp['month'], $exp['day'], $exp['hour'], $exp['minute'], $exp['second']);
                }
            }

            if (!$eventTime) {
                return null;
            }

            return [
                'device_user_id'  => $userId,
                'event_time'      => $eventTime,
                'device_event_id' => null,
                'raw_payload'     => bin2hex($chunk),
                'verify_mode'     => (int)($u['state'] ?? 0),
                'punch_status'    => (int)($u['punch'] ?? 0),
                'device_uid'      => $uid,
            ];
        }

        // Legacy 14 or 16-byte record format (B&W terminals, ZK 6.0 firmware)
        if ($length === 14 || $length === 16) {
            $fields = unpack('vpin/Cverify/Cstatus/Vtimestamp', substr($chunk, 0, 8));
            if (!$fields || (int)($fields['pin'] ?? 0) <= 0) {
                return null;
            }

            $eventTime = $this->decodeTime((int)($fields['timestamp'] ?? 0));
            if (!$eventTime) {
                return null;
            }

            return [
                'device_user_id'  => (string)$fields['pin'],
                'event_time'      => $eventTime,
                'device_event_id' => null,
                'raw_payload'     => bin2hex($chunk),
                'verify_mode'     => (int)($fields['verify'] ?? 0),
                'punch_status'    => (int)($fields['status'] ?? 0),
                'device_uid'      => (int)$fields['pin'],
            ];
        }

        return null;
    }

    /**
     * Parse binary attendance logs supporting both 40-byte TFT (F22/ID, F18, K40) and legacy 14/16-byte records
     */
    public function parseAttendanceRecords(string $payload): array
    {
        $payloadLength = strlen($payload);
        if ($payloadLength < 14) {
            return [];
        }

        // Candidate stream alignment strategies: [offset, chunkSize]
        // 1. 40-byte TFT record starting at offset 4 (when 4-byte record count header is prepended)
        // 2. 40-byte TFT record starting at offset 0 (no header)
        // 3. 16-byte legacy record starting at offset 4
        // 4. 16-byte legacy record starting at offset 0
        // 5. 14-byte legacy record starting at offset 0
        $strategies = [
            ['offset' => 4, 'size' => 40],
            ['offset' => 0, 'size' => 40],
            ['offset' => 4, 'size' => 16],
            ['offset' => 0, 'size' => 16],
            ['offset' => 0, 'size' => 14],
        ];

        $bestRecords = [];
        foreach ($strategies as $strat) {
            $offset = $strat['offset'];
            $chunkSize = $strat['size'];
            if ($payloadLength < $offset + $chunkSize) {
                continue;
            }

            $currentRecords = [];
            $limit = $payloadLength - $chunkSize;
            for ($i = $offset; $i <= $limit; $i += $chunkSize) {
                $chunk = substr($payload, $i, $chunkSize);
                $rec = $this->parseSingleAttendanceRecord($chunk);
                if ($rec !== null) {
                    $currentRecords[] = $rec;
                }
            }

            if (count($currentRecords) > count($bestRecords)) {
                $bestRecords = $currentRecords;
                // If 40-byte TFT parser yielded records, it's overwhelmingly the correct format
                if ($chunkSize === 40 && count($bestRecords) >= 1) {
                    break;
                }
            }
        }

        return $bestRecords;
    }

    /**
     * Decode standard 4-byte packed ZKTeco integer timestamp into YYYY-MM-DD HH:MM:SS string.
     * Returns null if timestamp is invalid or results in an out-of-bounds or non-existent calendar date.
     */
    public function decodeTime(int|float $t): ?string
    {
        if ($t <= 0) {
            return null;
        }

        $second = (int)$t % 60;
        $t = (int)floor($t / 60);
        $minute = (int)$t % 60;
        $t = (int)floor($t / 60);
        $hour = (int)$t % 24;
        $t = (int)floor($t / 24);
        $day = (int)($t % 31) + 1;
        $t = (int)floor($t / 31);
        $month = (int)($t % 12) + 1;
        $t = (int)floor($t / 12);
        $year = (int)$t + 2000;

        if ($year < 2000 || $year > 2050 || $month < 1 || $month > 12 || $day < 1 || $day > 31 || $hour < 0 || $hour > 23 || $minute < 0 || $minute > 59 || $second < 0 || $second > 59) {
            return null;
        }

        if (!checkdate($month, $day, $year)) {
            return null;
        }

        return sprintf('%04d-%02d-%02d %02d:%02d:%02d', $year, $month, $day, $hour, $minute, $second);
    }

    /**
     * Reprocess raw biometric attendance events stored in biometric_attendance_events table
     * using the corrected binary parser without altering raw_payload.
     */
    public function reprocessBiometricEvents(?string $deviceId = null, ?string $companyId = null, int $limit = 0): array
    {
        if (function_exists('set_time_limit')) {
            @set_time_limit(600);
        }
        @ini_set('max_execution_time', '600');

        $table = $this->db->table('biometric_attendance_events');
        $query = $table->select('id, company_id, device_id, device_user_id, event_time, device_event_id, event_hash, raw_payload, employee_id');
        if ($deviceId) {
            $query->where('device_id', $deviceId);
        }
        if ($companyId) {
            $query->where('company_id', $companyId);
        }
        if ($limit > 0) {
            $query->limit($limit);
        }

        $totalProcessed = 0;
        $totalUpdated = 0;
        $totalMapped = 0;
        $totalUnmatched = 0;
        $totalErrors = 0;
        $errors = [];

        $events = $query->get()->getResultArray();
        $totalRecords = count($events);

        $deviceCache = [];
        $employeeCache = [];

        foreach ($events as $event) {
            $totalProcessed++;
            $rawPayload = $event['raw_payload'] ?? '';
            if (empty($rawPayload)) {
                $totalErrors++;
                continue;
            }

            $parsed = $this->parseSingleAttendanceRecord($rawPayload);
            if (!$parsed) {
                $totalErrors++;
                $errors[] = "Row {$event['id']}: Unparseable raw payload";
                continue;
            }

            $correctedUserId = $parsed['device_user_id'];
            $correctedEventTime = $parsed['event_time'];
            $evtCompanyId = $event['company_id'];
            $evtDeviceId = $event['device_id'];

            // Compute correct event_hash
            $newHash = hash('sha256', implode('|', [
                $evtCompanyId,
                $evtDeviceId,
                $event['device_event_id'] ?? '',
                $correctedUserId,
                $correctedEventTime,
                $rawPayload
            ]));

            // Check if user ID or timestamp or hash changed
            $hasChanged = ($correctedUserId !== $event['device_user_id'])
                || ($correctedEventTime !== $event['event_time'])
                || ($newHash !== $event['event_hash']);

            // Resolve employee mapping for the corrected device_user_id
            $cacheKey = "{$evtCompanyId}:{$evtDeviceId}:{$correctedUserId}";
            if (!array_key_exists($cacheKey, $employeeCache)) {
                $employeeCache[$cacheKey] = $this->mappingService->resolveEmployeeForBiometricPunch($correctedUserId, $evtCompanyId, $evtDeviceId);
            }
            $resolvedEmp = $employeeCache[$cacheKey];
            $resolvedEmpId = $resolvedEmp['id'] ?? null;

            if ($resolvedEmpId) {
                $totalMapped++;
            } else {
                $totalUnmatched++;
            }

            // Only update if there are changes or employee mapping changed
            if ($hasChanged || $resolvedEmpId !== $event['employee_id']) {
                try {
                    $this->db->table('biometric_attendance_events')
                        ->where('id', $event['id'])
                        ->update([
                            'device_user_id' => $correctedUserId,
                            'event_time'     => $correctedEventTime,
                            'event_hash'     => $newHash,
                            'employee_id'    => $resolvedEmpId,
                        ]);
                    $totalUpdated++;
                } catch (\Throwable $e) {
                    if (str_contains($e->getMessage(), 'Duplicate') || str_contains($e->getMessage(), 'UNIQUE')) {
                        $this->db->table('biometric_attendance_events')->where('id', $event['id'])->delete();
                    } else {
                        $totalErrors++;
                        $errors[] = "Row {$event['id']} update failed: " . $e->getMessage();
                    }
                }
            }

            // If employee mapped, sync punch into attendance
            if ($resolvedEmpId) {
                if (!array_key_exists($evtDeviceId, $deviceCache)) {
                    $deviceCache[$evtDeviceId] = $this->db->table('biometric_devices')->where('id', $evtDeviceId)->get()->getRowArray();
                }
                $dev = $deviceCache[$evtDeviceId];
                $source = $dev ? "ZK Device: {$dev['device_name']}" : 'Biometric Terminal Reprocess';
                $ts = strtotime($correctedEventTime);
                if ($ts) {
                    $this->ingestPunchRecord($resolvedEmpId, date('Y-m-d', $ts), date('H:i:s', $ts), $source);
                }
            } else {
                // Ensure unmapped punches are preserved in unmatched staff table, NEVER marked absent
                if (!array_key_exists($evtDeviceId, $deviceCache)) {
                    $deviceCache[$evtDeviceId] = $this->db->table('biometric_devices')->where('id', $evtDeviceId)->get()->getRowArray();
                }
                $dev = $deviceCache[$evtDeviceId];
                $this->mappingService->recordUnmatchedPunch([
                    'device_user_id' => $correctedUserId,
                    'event_time'     => $correctedEventTime,
                    'raw_payload'    => $rawPayload,
                ], $evtCompanyId, $dev);
            }
        }

        return [
            'total_records'   => $totalRecords,
            'total_processed' => $totalProcessed,
            'total_updated'   => $totalUpdated,
            'total_mapped'    => $totalMapped,
            'total_unmatched' => $totalUnmatched,
            'total_errors'    => $totalErrors,
            'sample_errors'   => array_slice($errors, 0, 10),
        ];
    }

    protected function sendCommand($socket, int $command, string $payload, int &$sessionId, ?int &$replyId = null): string
    {
        if ($replyId === null) {
            $replyId = 65534;
        }
        $packet = $this->buildPacket($command, $payload, $sessionId, $replyId);
        fwrite($socket, pack('vvV', 20560, 32130, strlen($packet)) . $packet);
        $tcpHeader = $this->readExact($socket, 8, $command);
        $tcp = unpack('vmagic1/vmagic2/Vlength', $tcpHeader);
        if ($tcp['magic1'] !== 20560 || $tcp['magic2'] !== 32130 || $tcp['length'] < 8) {
            throw new \RuntimeException('Device returned an invalid TCP protocol envelope.');
        }
        $body = $this->readExact($socket, (int)$tcp['length'], $command);
        if (strlen($body) < 8) {
            throw new \RuntimeException('Device protocol response timed out.');
        }
        $parts = unpack('vcommand/vchecksum/vsession/vreply', substr($body, 0, 8));
        $this->lastResponseCommand = (int)$parts['command'];
        if ($parts['session'] > 0 || $command === self::CMD_CONNECT) {
            $sessionId = (int)$parts['session'];
        }
        // Sequence replyId is incremented monotonically by buildPacket(), do not overwrite with server response

        if (in_array($parts['command'], [self::CMD_ACK_ERROR, self::CMD_ACK_ERROR_DATA, 65532, 65533], true)) {
            throw new \RuntimeException('Device rejected the ZKTeco command.');
        }
        return substr($body, 8);
    }

    protected function makeCommunicationKey(int $key, int $sessionId): string
    {
        $scrambled = 0;
        for ($bit = 0; $bit < 32; $bit++) {
            $scrambled = ($scrambled << 1) | (($key & (1 << $bit)) ? 1 : 0);
        }
        $scrambled = ($scrambled + $sessionId) & 0xffffffff;
        $bytes = array_values(unpack('C*', pack('V', $scrambled)));
        $bytes[0] ^= ord('Z');
        $bytes[1] ^= ord('K');
        $bytes[2] ^= ord('S');
        $bytes[3] ^= ord('O');
        $first = $bytes[0];
        $second = $bytes[1];
        $bytes[0] = $bytes[2];
        $bytes[1] = $bytes[3];
        $bytes[2] = $first;
        $bytes[3] = $second;
        $tick = 50;
        $bytes[0] ^= $tick;
        $bytes[1] ^= $tick;
        $bytes[2] = $tick;
        $bytes[3] ^= $tick;
        return call_user_func_array('pack', array_merge(['C*'], $bytes));
    }

    protected function buildPacket(int $command, string $payload, int $sessionId, int &$replyId): string
    {
        $header = pack('vvvv', $command, 0, $sessionId, $replyId);
        $bytes = unpack('C*', $header . $payload);
        $checksum = 0;
        for ($index = 1; $index <= count($bytes); $index += 2) {
            $word = $bytes[$index] | (($bytes[$index + 1] ?? 0) << 8);
            $checksum += $word;
            if ($checksum > 65535) {
                $checksum -= 65535;
            }
        }
        $checksum = (~$checksum) & 0xffff;
        $packet = pack('vvvv', $command, $checksum, $sessionId, $replyId) . $payload;
        $replyId = ($replyId + 1) >= 65535 ? 0 : $replyId + 1;
        return $packet;
    }

    protected function readPreparedData($socket, int &$sessionId, int &$replyId, int $command): string
    {
        // Method A: Buffered read (modern TFT / Linux ZEM600 / ZEM800)
        try {
            $response = $this->sendCommand($socket, self::CMD_READ_BUFFER, pack('cvVV', 1, $command, 0, 0), $sessionId, $replyId);
            if (strlen($response) >= 4) {
                $size = unpack('Vsize', substr($response, 0, 4))['size'];
                if ($size > 0 && $size < 50000000) {
                    $data = '';
                    $chunkSize = 1024;
                    for ($offset = 0; $offset < $size; $offset += $chunkSize) {
                        $length = min($chunkSize, $size - $offset);
                        $chunk = $this->sendCommand($socket, self::CMD_DATA_RDY, pack('VV', $offset, $length), $sessionId, $replyId);
                        $data .= $chunk;
                    }
                    try {
                        $this->sendCommand($socket, self::CMD_FREE_DATA, '', $sessionId, $replyId);
                    } catch (\Throwable $t) {}
                    return substr($data, 0, $size);
                }
            }
        } catch (\Throwable $e) {
            // Fall back to Method B if CMD_READ_BUFFER is rejected
        }

        // Method B: Direct command request (legacy TFT / standalone)
        $response = $this->sendCommand($socket, $command, '', $sessionId, $replyId);
        if ($this->lastResponseCommand === self::CMD_PREPARE_DATA) {
            $size = strlen($response) >= 4 ? unpack('Vsize', substr($response, 0, 4))['size'] : 0;
            $data = '';
            $maxAttempts = 1000;
            while ($maxAttempts-- > 0) {
                try {
                    $tcpHeader = $this->readExact($socket, 8, $command);
                    $tcp = unpack('vmagic1/vmagic2/Vlength', $tcpHeader);
                    if ($tcp['magic1'] === 20560 && $tcp['magic2'] === 32130 && $tcp['length'] >= 8) {
                        $chunk = $this->readExact($socket, (int)$tcp['length'], $command);
                        $parts = unpack('vcommand/vchecksum/vsession/vreply', substr($chunk, 0, 8));
                        if ($parts['command'] === self::CMD_DATA) {
                            $data .= substr($chunk, 8);
                        } elseif ($parts['command'] === self::CMD_ACK_OK) {
                            break;
                        }
                    }
                } catch (\Throwable $t) {
                    break;
                }
                if ($size > 0 && strlen($data) >= $size) {
                    break;
                }
            }
            return $size > 0 ? substr($data, 0, $size) : $data;
        }

        return $response;
    }

    protected function readExact($socket, int $length, int $command = 0): string
    {
        $data = '';
        while (strlen($data) < $length) {
            $chunk = fread($socket, $length - strlen($data));
            if ($chunk === false || $chunk === '') {
                $meta = stream_get_meta_data($socket);
                $stage = $command > 0 ? " for command {$command}" : '';
                log_message('error', 'ZKTeco protocol read timeout' . $stage . ': ' . json_encode([
                    'bytes_received' => strlen($data),
                    'expected_bytes' => $length,
                    'timed_out' => $meta['timed_out'] ?? null,
                    'eof' => $meta['eof'] ?? null,
                ]));
                throw new \RuntimeException('Device protocol response timed out' . $stage . '.');
            }
            $data .= $chunk;
        }
        return $data;
    }

    protected function storeRawEvent(array $device, string $companyId, array $record): bool
    {
        $hash = hash('sha256', implode('|', [$companyId, $device['id'], $record['device_event_id'] ?? '', $record['device_user_id'], $record['device_event_time'] ?? $record['event_time'], $record['raw_payload'] ?? '']));
        $table = $this->db->table('biometric_attendance_events');
        if ($table->where(['company_id' => $companyId, 'device_id' => $device['id'], 'event_hash' => $hash])->countAllResults() > 0) {
            return false;
        }
        $mapping = $this->mappingService->resolveEmployeeForBiometricPunch($record['device_user_id'], $companyId, $device['id']);
        $table->insert([
            'id' => Uuid::uuid4()->toString(),
            'company_id' => $companyId,
            'device_id' => $device['id'],
            'device_user_id' => $record['device_user_id'],
            'event_time' => $record['event_time'],
            'device_event_id' => $record['device_event_id'],
            'event_hash' => $hash,
            'raw_payload' => $record['raw_payload'],
            'employee_id' => $mapping['id'] ?? null,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
        if ($mapping) {
            $timestamp = strtotime($record['event_time']);
            $this->ingestPunchRecord($mapping['id'], date('Y-m-d', $timestamp), date('H:i:s', $timestamp), "ZK Device: {$device['device_name']}");
        } else {
            $this->mappingService->recordUnmatchedPunch($record, $companyId, $device);
        }
        return true;
    }

    /**
     * Ingest batch raw punches pushed by Windows ZKFinger SDK Agent or Direct Device Sync
     */
    public function ingestBatchPunches(array $punches, string $source = 'Windows ZKFinger SDK Agent', ?string $companyId = null, ?array $deviceInfo = null): array
    {
        if (function_exists('set_time_limit')) {
            @set_time_limit(300);
        }
        @ini_set('max_execution_time', '300');

        $ingestedCount = 0;
        $unmatchedCount = 0;
        $skippedCount = 0;
        $unmatchedIdentities = [];
        $matchedIdentities = [];
        $errors = [];
        $empCache = [];

        // SEC-ATT-07: Prohibit punch ingestion without company context to prevent cross-tenant punch collisions
        if (empty($companyId)) {
            return [
                'success'   => false,
                'ingested'  => 0,
                'unmatched' => 0,
                'skipped'   => count($punches),
                'errors'    => ['Security Policy: company_id is strictly required for biometric punch ingestion.']
            ];
        }

        usort($punches, static function ($a, $b) {
            $dtA = trim((string) ($a['datetime'] ?? $a['timestamp'] ?? ''));
            $dtB = trim((string) ($b['datetime'] ?? $b['timestamp'] ?? ''));
            $tsA = is_numeric($dtA) ? (int) $dtA : (strtotime($dtA) ?: 0);
            $tsB = is_numeric($dtB) ? (int) $dtB : (strtotime($dtB) ?: 0);
            return $tsA !== $tsB ? ($tsA <=> $tsB) : ($dtA <=> $dtB);
        });

        $this->db->transStart();

        foreach ($punches as $punch) {
            $empCode = trim($punch['employee_code'] ?? $punch['pin'] ?? $punch['emp_id'] ?? $punch['user_id'] ?? '');
            $punchDateTime = trim($punch['datetime'] ?? $punch['timestamp'] ?? '');

            if (empty($empCode) || empty($punchDateTime)) {
                $skippedCount++;
                continue;
            }

            // Parse Date and Time
            $timestamp = strtotime($punchDateTime);
            if (!$timestamp) {
                $skippedCount++;
                continue;
            }

            $date = date('Y-m-d', $timestamp);
            $time = date('H:i:s', $timestamp);

            // 1. Resolve Employee Master record (via biometric_mappings or direct employee_code fallback)
            if (!array_key_exists($empCode, $empCache)) {
                $empCache[$empCode] = $this->mappingService->resolveEmployeeForBiometricPunch($empCode, $companyId, $deviceInfo['id'] ?? null);
            }
            $emp = $empCache[$empCode];

            if ($emp) {
                if (!empty($emp['company_id']) && (string)$emp['company_id'] !== (string)$companyId) {
                    log_message('warning', "SEC-ATT-07: Employee tenant mismatch for employee {$empCode}.");
                    $skippedCount++;
                    $errors[] = "Employee Code '{$empCode}' belongs to another tenant.";
                    continue;
                }
                $attendanceResult = $this->ingestPunchRecord($emp['id'], $date, $time, $source, $companyId);
                if (!empty($attendanceResult['success'])) {
                    $ingestedCount++;
                    if (!in_array($empCode, $matchedIdentities, true)) {
                        $matchedIdentities[] = $empCode;
                    }
                } else {
                    $skippedCount++;
                    $errors[] = "Biometric User ID '{$empCode}' was mapped, but attendance processing failed: " . ($attendanceResult['message'] ?? 'Unknown attendance error');
                }
            } else {
                // 2. Unmatched Biometric Identity: NEVER silently discard attendance!
                // Preserve raw punch event and register / update identity in Unmatched Biometric Staff
                $unmatchedRes = $this->mappingService->recordUnmatchedPunch($punch, $companyId, $deviceInfo);
                $unmatchedCount++;
                if (!in_array($empCode, $unmatchedIdentities)) {
                    $unmatchedIdentities[] = $empCode;
                }
                $errors[] = "Biometric User ID '{$empCode}' preserved as UNMATCHED staff awaiting onboarding/linking.";
            }
        }

        $syncStatus = 'Success';
        if ($ingestedCount === 0 && $unmatchedCount > 0) {
            $syncStatus = 'Unmatched';
        } elseif ($ingestedCount === 0 && $skippedCount > 0) {
            $syncStatus = 'Failed';
        } elseif ($unmatchedCount > 0) {
            $syncStatus = 'Partial';
        }

        $this->db->table('attendance_sync_logs')->insert([
            'id'             => Uuid::uuid4()->toString(),
            'device_id'      => $source,
            'sync_type'      => 'SDK Push API',
            'records_synced' => $ingestedCount,
            'status'         => $syncStatus,
            'error_message'  => !empty($errors) ? implode('; ', array_slice($errors, 0, 5)) : null,
            'sync_time'      => date('Y-m-d H:i:s')
        ]);

        $this->db->transComplete();

        return [
            'success'              => true,
            'ingested'             => $ingestedCount,
            'unmatched'            => $unmatchedCount,
            'skipped'              => $skippedCount,
            'unmatched_identities' => $unmatchedIdentities,
            'matched_identities'   => $matchedIdentities,
            'errors'               => $errors
        ];
    }

    /**
     * Ingest or update single punch record through enterprise Attendance Engine
     */
    protected function ingestPunchRecord(string $empId, string $date, string $time, string $method, ?string $companyId = null): array
    {
        return $this->getAttendanceService()->recordHardwarePunch($empId, $method, $date, $time, false, $companyId);
    }
}
