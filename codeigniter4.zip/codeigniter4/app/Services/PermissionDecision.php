<?php

namespace App\Services;

/**
 * Immutable/Serializable Permission Resolution Decision
 * 
 * Contains:
 * - allowed: bool
 * - tier: string ('root_software_app_admin', 'root_company_admin', 'user_override_deny', 'user_override_grant', 'self_service_implicit', 'role_default', 'default_deny', 'platform_deny', 'inactive_deny', etc.)
 * - scope: string ('all', 'company', 'branch', 'department', 'team', 'self', 'none')
 * - reason: string (human-readable explanation for security telemetry & audit)
 * - code: string (normalized module.action)
 * - expiresAt: ?string (ISO date if temporary/delegated override)
 */
class PermissionDecision implements \ArrayAccess, \JsonSerializable
{
    public bool $allowed;
    public string $tier;
    public string $scope;
    public string $reason;
    public ?string $code;
    public ?string $expiresAt;
    public ?string $scopeId;

    public function __construct(
        bool $allowed,
        string $tier,
        string $scope = 'company',
        string $reason = '',
        ?string $code = null,
        ?string $expiresAt = null,
        ?string $scopeId = null
    ) {
        $this->allowed   = $allowed;
        $this->tier      = $tier;
        $this->scope     = $scope ?: ($allowed ? 'company' : 'none');
        $this->reason    = $reason;
        $this->code      = $code;
        $this->expiresAt = $expiresAt;
        $this->scopeId   = $scopeId;
    }

    public static function allow(string $scope = 'company', string $reason = 'Active grant', string $tier = 'allow', ?string $code = null, ?string $expiresAt = null, ?string $scopeId = null): self
    {
        return new self(true, $tier, $scope, $reason, $code, $expiresAt, $scopeId);
    }

    public static function deny(string $reason = 'Access denied', string $tier = 'deny', string $scope = 'none', ?string $code = null, ?string $expiresAt = null, ?string $scopeId = null): self
    {
        return new self(false, $tier, $scope, $reason, $code, $expiresAt, $scopeId);
    }

    public function isAllowed(): bool
    {
        return $this->allowed;
    }

    public function allowed(): bool
    {
        return $this->allowed;
    }

    public function scope(): string
    {
        return $this->scope;
    }

    public function scopeId(): ?string
    {
        return $this->scopeId;
    }

    public function tier(): string
    {
        return $this->tier;
    }

    public function reason(): string
    {
        return $this->reason;
    }

    public function code(): ?string
    {
        return $this->code;
    }

    public function expiresAt(): ?string
    {
        return $this->expiresAt;
    }

    public function toArray(): array
    {
        return [
            'allowed'    => $this->allowed,
            'tier'       => $this->tier,
            'scope'      => $this->scope,
            'scope_id'   => $this->scopeId,
            'reason'     => $this->reason,
            'code'       => $this->code,
            'expires_at' => $this->expiresAt,
        ];
    }

    public function jsonSerialize(): mixed
    {
        return $this->toArray();
    }

    public function __toString(): string
    {
        return $this->allowed ? '1' : '0';
    }

    // ArrayAccess implementation for backwards compatibility with array destructuring
    public function offsetExists(mixed $offset): bool
    {
        return in_array($offset, ['allowed', 'tier', 'scope', 'scope_id', 'scopeId', 'reason', 'code', 'expires_at', 'expiresAt'], true);
    }

    public function offsetGet(mixed $offset): mixed
    {
        return match ($offset) {
            'allowed'                 => $this->allowed,
            'tier'                    => $this->tier,
            'scope'                   => $this->scope,
            'scope_id', 'scopeId'     => $this->scopeId,
            'reason'                  => $this->reason,
            'code'                    => $this->code,
            'expires_at', 'expiresAt' => $this->expiresAt,
            default                   => null,
        };
    }

    public function offsetSet(mixed $offset, mixed $value): void
    {
        // Immutable
    }

    public function offsetUnset(mixed $offset): void
    {
        // Immutable
    }
}
