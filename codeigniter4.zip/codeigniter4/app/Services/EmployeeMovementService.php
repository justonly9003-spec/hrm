<?php

namespace App\Services;

use App\Models\EmployeeModel;
use App\Models\EmployeePromotionModel;
use App\Models\EmployeeTransferModel;
use App\Models\DesignationModel;
use App\Models\BranchModel;
use App\Models\DepartmentModel;
use App\Services\EmployeeSalaryService;
use App\Services\AuditService;
use Config\Database;

/**
 * Service consolidating employee movement operations:
 * Promotions and Transfers with unified validation, scope checking, transactions, and audit logging.
 */
class EmployeeMovementService
{
    protected EmployeeModel $employeeModel;
    protected EmployeePromotionModel $promotionModel;
    protected EmployeeTransferModel $transferModel;
    protected DesignationModel $designationModel;
    protected BranchModel $branchModel;
    protected DepartmentModel $departmentModel;
    protected EmployeeSalaryService $salaryService;
    protected AuditService $auditService;

    public function __construct(
        ?EmployeeModel $employeeModel = null,
        ?EmployeePromotionModel $promotionModel = null,
        ?EmployeeTransferModel $transferModel = null,
        ?DesignationModel $designationModel = null,
        ?BranchModel $branchModel = null,
        ?DepartmentModel $departmentModel = null,
        ?EmployeeSalaryService $salaryService = null,
        ?AuditService $auditService = null
    ) {
        $this->employeeModel    = $employeeModel ?? new EmployeeModel();
        $this->promotionModel   = $promotionModel ?? new EmployeePromotionModel();
        $this->transferModel    = $transferModel ?? new EmployeeTransferModel();
        $this->designationModel = $designationModel ?? new DesignationModel();
        $this->branchModel      = $branchModel ?? new BranchModel();
        $this->departmentModel  = $departmentModel ?? new DepartmentModel();
        $this->salaryService    = $salaryService ?? new EmployeeSalaryService();
        $this->auditService     = $auditService ?? new AuditService();
    }

    /**
     * Process an employee promotion.
     *
     * @param string $employeeId
     * @param array $data Expected: [new_designation_id, new_salary, promotion_date?, reason?, approved_by?, new_branch_id?]
     * @param string|null $actorId
     * @param array|null $actorUser
     * @param string|null $scopedCompanyId Null if software app admin
     * @return array ['success' => bool, 'message' => string, 'data' => array]
     * @throws \SecurityException|\InvalidArgumentException|\RuntimeException
     */
    public function promote(
        string $employeeId,
        array $data,
        ?string $actorId = null,
        ?array $actorUser = null,
        ?string $scopedCompanyId = null
    ): array {
        $emp = $this->employeeModel->find($employeeId);
        if (!$emp) {
            throw new \InvalidArgumentException('Employee not found.');
        }

        // Multi-tenant isolation: verify target employee belongs to scoped company
        if (!empty($scopedCompanyId) && !empty($emp['company_id']) && (string)$emp['company_id'] !== (string)$scopedCompanyId) {
            throw new \SecurityException('403 Forbidden: Cross-tenant operation unauthorized.');
        }

        $newDesigId = trim((string)($data['new_designation_id'] ?? ''));
        if (empty($newDesigId)) {
            throw new \InvalidArgumentException('A valid new designation is required for promotion.');
        }

        $newDesg = $this->designationModel->find($newDesigId);
        if (!$newDesg) {
            throw new \InvalidArgumentException('The selected designation was not found.');
        }

        // Validate designation tenant scope
        $empCompanyId = $emp['company_id'] ?? $scopedCompanyId;
        if (!empty($empCompanyId) && !empty($newDesg['company_id']) && (string)$newDesg['company_id'] !== (string)$empCompanyId) {
            throw new \SecurityException('403 Forbidden: Selected designation belongs to another company.');
        }

        $newSalary = isset($data['new_salary']) ? (float)$data['new_salary'] : (float)($emp['basic_salary'] ?? 0);
        if ($newSalary < 0) {
            throw new \InvalidArgumentException('New salary cannot be negative.');
        }

        $promoDate = !empty($data['promotion_date']) ? (string)$data['promotion_date'] : date('Y-m-d');
        $reason = trim((string)($data['reason'] ?? 'Promoted'));
        // Never take approved_by from POST; use logged-in user context with no dummy fallbacks
        $approver = !empty($actorUser['name']) ? (string)$actorUser['name'] : (!empty($actorUser['username']) ? (string)$actorUser['username'] : (string)$actorId);

        // Optional branch transfer in conjunction with promotion
        $newBranchId = !empty($data['new_branch_id']) ? (string)$data['new_branch_id'] : (!empty($data['branch_id']) ? (string)$data['branch_id'] : null);
        if (!empty($newBranchId) && !empty($empCompanyId)) {
            $branch = $this->branchModel->find($newBranchId);
            if ($branch && !empty($branch['company_id']) && (string)$branch['company_id'] !== (string)$empCompanyId) {
                throw new \SecurityException('403 Forbidden: Target branch not within company boundaries.');
            }
        }

        $db = Database::connect();
        $db->transBegin();

        try {
            $promotionId = 'prom-' . bin2hex(random_bytes(8));
            $promoFields = $db->tableExists('employee_promotions') ? $db->getFieldNames('employee_promotions') : [];
            $promoPayload = [
                'id'                      => $promotionId,
                'employee_id'             => $employeeId,
                'promotion_date'          => $promoDate,
                'effective_date'          => $promoDate,
                'previous_designation_id' => $emp['designation_id'] ?? null,
                'new_designation_id'      => $newDesigId,
                'previous_salary'         => $emp['basic_salary'] ?? 0,
                'new_salary'              => $newSalary,
                'reason'                  => $reason,
                'remarks'                 => $data['remarks'] ?? $reason,
                'approved_by'             => $approver,
                'status'                  => 'Approved',
            ];
            if (!empty($promoFields)) {
                $promoPayload = array_intersect_key($promoPayload, array_flip($promoFields));
            }
            $this->promotionModel->insert($promoPayload);

            // Never write null into designation_id
            $updateFields = ['designation_id' => $newDesigId];
            if (!empty($newBranchId) && (string)$newBranchId !== (string)($emp['branch_id'] ?? '')) {
                $updateFields['branch_id'] = $newBranchId;

                // Also record the branch transfer record
                $transferFields = $db->tableExists('employee_transfers') ? $db->getFieldNames('employee_transfers') : [];
                $transferPayload = [
                    'id'                  => 'trf-' . bin2hex(random_bytes(8)),
                    'employee_id'         => $employeeId,
                    'transfer_date'       => $promoDate,
                    'effective_date'      => $promoDate,
                    'from_branch_id'      => $emp['branch_id'] ?? null,
                    'to_branch_id'        => $newBranchId,
                    'from_department_id'  => $emp['department_id'] ?? null,
                    'to_department_id'    => $emp['department_id'] ?? null,
                    'from_designation_id' => $emp['designation_id'] ?? null,
                    'to_designation_id'   => $newDesigId,
                    'reason'              => 'Branch transfer on promotion: ' . $reason,
                    'approved_by'         => $approver,
                ];
                if (!empty($transferFields)) {
                    $transferPayload = array_intersect_key($transferPayload, array_flip($transferFields));
                }
                $this->transferModel->insert($transferPayload);
            }

            $this->employeeModel->update($employeeId, $updateFields);

            // Assign revised salary via EmployeeSalaryService if salary > 0
            if ($newSalary > 0) {
                $salaryResult = $this->salaryService->assignSalary($employeeId, [
                    'basic_salary'   => $newSalary,
                    'effective_from' => $promoDate,
                    'notes'          => 'Promotion: ' . ($reason ?: 'Designation change')
                ], $emp['company_id'] ?? null, $actorUser);

                if (empty($salaryResult['success'])) {
                    $db->transRollback();
                    throw new \RuntimeException('Promotion failed: Salary assignment failed - ' . ($salaryResult['message'] ?? 'Unknown error'));
                }
            }

            $db->transCommit();
        } catch (\Throwable $e) {
            $db->transRollback();
            throw $e;
        }

        // Unified audit log
        $this->auditService->log(
            $actorId,
            'employee',
            'employee.promoted',
            $employeeId,
            ['designation_id' => $emp['designation_id'] ?? null, 'basic_salary' => $emp['basic_salary'] ?? 0],
            ['designation_id' => $newDesigId, 'basic_salary' => $newSalary, 'branch_id' => $newBranchId ?? ($emp['branch_id'] ?? null)],
            null,
            null,
            "Promoted employee {$employeeId} to designation {$newDesigId} with salary {$newSalary}"
        );

        return [
            'success' => true,
            'message' => 'Employee promotion processed and profile updated.',
            'data'    => [
                'promotion_id'       => $promotionId,
                'employee_id'        => $employeeId,
                'new_designation_id' => $newDesigId,
                'new_salary'         => $newSalary,
                'promotion_date'     => $promoDate
            ]
        ];
    }

    /**
     * Process an employee transfer.
     *
     * @param string $employeeId
     * @param array $data Expected: [to_branch_id?, to_department_id?, to_designation_id?, transfer_date?, reason?, approved_by?]
     * @param string|null $actorId
     * @param array|null $actorUser
     * @param string|null $scopedCompanyId Null if software app admin
     * @return array ['success' => bool, 'message' => string, 'data' => array]
     * @throws \SecurityException|\InvalidArgumentException|\RuntimeException
     */
    public function transfer(
        string $employeeId,
        array $data,
        ?string $actorId = null,
        ?array $actorUser = null,
        ?string $scopedCompanyId = null
    ): array {
        $emp = $this->employeeModel->find($employeeId);
        if (!$emp) {
            throw new \InvalidArgumentException('Employee not found.');
        }

        // Multi-tenant isolation: verify target employee belongs to scoped company
        if (!empty($scopedCompanyId) && !empty($emp['company_id']) && (string)$emp['company_id'] !== (string)$scopedCompanyId) {
            throw new \SecurityException('403 Forbidden: Cross-tenant operation unauthorized.');
        }

        $toBranch = !empty($data['to_branch_id']) ? (string)$data['to_branch_id'] : (!empty($data['to_branch']) ? (string)$data['to_branch'] : ($emp['branch_id'] ?? null));
        $toDept   = !empty($data['to_department_id']) ? (string)$data['to_department_id'] : (!empty($data['to_department']) ? (string)$data['to_department'] : ($emp['department_id'] ?? null));
        $toDesg   = !empty($data['to_designation_id']) ? (string)$data['to_designation_id'] : (!empty($data['to_designation']) ? (string)$data['to_designation'] : ($emp['designation_id'] ?? null));

        $empCompanyId = $emp['company_id'] ?? $scopedCompanyId;

        // Scope validation on target entities (same checks as EmployeeController::store)
        if (!empty($toBranch)) {
            $branch = $this->branchModel->find($toBranch);
            if (!$branch || (!empty($branch['company_id']) && !empty($empCompanyId) && (string)$branch['company_id'] !== (string)$empCompanyId)) {
                throw new \SecurityException('403 Forbidden: Selected branch was not found or does not belong to this employee\'s assigned company.');
            }
        }

        if (!empty($toDept)) {
            $dept = $this->departmentModel->find($toDept);
            if (!$dept || (!empty($dept['company_id']) && !empty($empCompanyId) && (string)$dept['company_id'] !== (string)$empCompanyId)) {
                throw new \SecurityException('403 Forbidden: Selected department was not found or does not belong to this employee\'s assigned company.');
            }
        }

        if (!empty($toDesg)) {
            $desg = $this->designationModel->find($toDesg);
            if (!$desg || (!empty($desg['company_id']) && !empty($empCompanyId) && (string)$desg['company_id'] !== (string)$empCompanyId)) {
                throw new \SecurityException('403 Forbidden: Selected designation was not found or belongs to another company.');
            }
        }

        $transferDate = !empty($data['transfer_date']) ? (string)$data['transfer_date'] : date('Y-m-d');
        $reason       = trim((string)($data['reason'] ?? ''));
        // Never take approved_by from POST; use logged-in user context
        $approver     = !empty($actorUser['name']) ? (string)$actorUser['name'] : (!empty($actorUser['username']) ? (string)$actorUser['username'] : (string)$actorId);

        $db = Database::connect();
        $db->transBegin();

        try {
            $transferId = 'trf-' . bin2hex(random_bytes(8));
            $transferFields = $db->tableExists('employee_transfers') ? $db->getFieldNames('employee_transfers') : [];
            $transferPayload = [
                'id'                  => $transferId,
                'employee_id'         => $employeeId,
                'transfer_date'       => $transferDate,
                'effective_date'      => $transferDate,
                'from_branch_id'      => $emp['branch_id'] ?? null,
                'to_branch_id'        => $toBranch,
                'from_department_id'  => $emp['department_id'] ?? null,
                'to_department_id'    => $toDept,
                'from_designation_id' => $emp['designation_id'] ?? null,
                'to_designation_id'   => $toDesg,
                'reason'              => $reason,
                'approved_by'         => $approver,
            ];
            if (!empty($transferFields)) {
                $transferPayload = array_intersect_key($transferPayload, array_flip($transferFields));
            }
            $this->transferModel->insert($transferPayload);

            $this->employeeModel->update($employeeId, [
                'branch_id'      => $toBranch,
                'department_id'  => $toDept,
                'designation_id' => $toDesg
            ]);

            $db->transCommit();
        } catch (\Throwable $e) {
            $db->transRollback();
            throw $e;
        }

        // Unified audit log
        $this->auditService->log(
            $actorId,
            'employee',
            'employee.transferred',
            $employeeId,
            [
                'branch_id'      => $emp['branch_id'] ?? null,
                'department_id'  => $emp['department_id'] ?? null,
                'designation_id' => $emp['designation_id'] ?? null
            ],
            [
                'branch_id'      => $toBranch,
                'department_id'  => $toDept,
                'designation_id' => $toDesg
            ],
            null,
            null,
            "Transferred employee {$employeeId} to Branch: {$toBranch}, Dept: {$toDept}, Designation: {$toDesg}"
        );

        return [
            'success' => true,
            'message' => 'Employee transfer successfully recorded.',
            'data'    => [
                'transfer_id'        => $transferId,
                'employee_id'        => $employeeId,
                'to_branch_id'       => $toBranch,
                'to_department_id'   => $toDept,
                'to_designation_id'  => $toDesg,
                'transfer_date'      => $transferDate
            ]
        ];
    }
}
