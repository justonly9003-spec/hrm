<?php

namespace App\Services;

use Config\Database;

class PermissionService
{
    /**
     * Single shared canonical list of state-changing permission actions blocked for the read-only Auditor role.
     */
    public const AUDITOR_MUTATION_ACTIONS = [
        'create',
        'edit',
        'update',
        'save',
        'store',
        'delete',
        'remove',
        'approve',
        'hr_approve',
        'reject',
        'endorse',
        'cancel',
        'run',
        'generate',
        'disburse',
        'sync',
        'adjust',
        'balance_adjust',
        'assign',
        'publish',
        'manage',
        'recommend',
        'lock',
        'unlock',
        'closing_reopen',
        'encash',
        'probation',
        'movement',
        'promote',
        'transfer',
        'separate',
        'terminate',
        'approve_resignation',
        'bulk',
        'clock',
        'regularize',
        'regularize_approve',
        'early_closure_manage',
        'device_manage',
        'loans',
        'enroll',
        'convert',
        'upload',
        'purge',
        'restore',
        'backup',
        'toggle',
        'reset',
    ];

    /**
     * Known state-changing URI path segments or route suffixes that must also be blocked on GET for Auditor.
     */
    public const AUDITOR_STATE_CHANGING_URI_SEGMENTS = [
        'create',
        'store',
        'save',
        'edit',
        'update',
        'delete',
        'remove',
        'approve',
        'reject',
        'endorse',
        'cancel',
        'toggle',
        'toggle-status',
        'toggle-lock',
        'toggle-2fa',
        'lock',
        'unlock',
        'reset',
        'reset-password',
        'reset-2fa',
        'sync',
        'reprocess',
        'repair',
        'assign',
        'bulk-assign',
        'auto-assign',
        'publish',
        'archive',
        'disburse',
        'generate',
        'adjust',
        'balance-adjust',
        'encash',
        'accrue-monthly',
        'rollover-year-end',
        'reopen-year',
        'auto-reconcile',
        'run-diagnostic-tests',
        'test-summary-rules',
        'seed-attendance',
        'initialize',
        'initialize-all',
        'initialize-defaults',
        'flush-queue',
        'trigger-workflow',
        'send-wish',
        'clear-all',
        'mark-read',
        'mark-all-read',
        'switch-persona',
        'stop-impersonation',
        'purge',
        'clear',
        'restore',
        'upload-restore',
    ];

    public static function isAuditorMutationAction(string $action): bool
    {
        return in_array(strtolower(trim($action)), self::AUDITOR_MUTATION_ACTIONS, true);
    }

    public static function isAuditorBlockedRequest(string $method, string $uriPath): bool
    {
        $method = strtoupper(trim($method));
        if (in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
            return true;
        }

        $cleanUri = strtolower(trim($uriPath, '/'));
        if ($cleanUri === '') {
            return false;
        }

        $segments = explode('/', $cleanUri);
        foreach ($segments as $seg) {
            if (in_array($seg, self::AUDITOR_STATE_CHANGING_URI_SEGMENTS, true)) {
                return true;
            }
            foreach (['run-', 'delete-', 'save-', 'update-', 'toggle-', 'reset-', 'seed-', 'approve-', 'reject-'] as $prefix) {
                if (str_starts_with($seg, $prefix)) {
                    return true;
                }
            }
        }

        return false;
    }

    protected $db;
    protected static $moduleStatusesCache = [];
    protected static $hasAccessCache = [];
    protected static ?bool $hasActionColumn = null;
    protected static ?bool $hasRoleCompanyColumn = null;

    public function __construct($db = null)
    {
        if ($db !== null) {
            $this->db = $db;
        } else {
            try {
                $this->db = Database::connect();
            } catch (\Throwable $e) {
                // In CLI unit test environments where sqlite3 driver is not loaded
                $this->db = null;
            }
        }
    }

    /**
     * Clear request-level static caches
     */
    public static function clearCache(): void
    {
        self::$moduleStatusesCache = [];
        self::$hasAccessCache = [];
        self::$hasActionColumn = null;
        self::$hasRoleCompanyColumn = null;
    }

    /**
     * Check if roles table has company_id column (schema resilience)
     */
    public function hasRoleCompanyColumn(): bool
    {
        if (self::$hasRoleCompanyColumn !== null) {
            return self::$hasRoleCompanyColumn;
        }

        try {
            if (!$this->db->tableExists('roles')) {
                self::$hasRoleCompanyColumn = false;
                return false;
            }
            self::$hasRoleCompanyColumn = $this->db->fieldExists('company_id', 'roles');
            return self::$hasRoleCompanyColumn;
        } catch (\Throwable $e) {
            self::$hasRoleCompanyColumn = false;
            return false;
        }
    }

    /**
     * Check if permissions table has the action column (read-only check; schema changes belong in migrations)
     */
    public function ensureActionColumn(): bool
    {
        if (self::$hasActionColumn !== null) {
            return self::$hasActionColumn;
        }

        try {
            if (!$this->db || !$this->db->tableExists('permissions')) {
                self::$hasActionColumn = false;
                return false;
            }

            self::$hasActionColumn = $this->db->fieldExists('action', 'permissions');
            return self::$hasActionColumn;
        } catch (\Throwable $e) {
            self::$hasActionColumn = false;
            return false;
        }
    }

/**
     * Check if a role or user has access to a specific module and action.
     * Uses the unified Permission-First resolution pipeline.
     */
    public function hasAccess(?string $userId = null, ?string $module = null, ?string $action = 'view', ?string $role = null): bool
    {
        $session = \Config\Services::session();
        $sessionRole = strtolower((string)($session->get('role') ?? $session->get('role_code') ?? ''));

        if ($this->isSoftwareAppAdmin()) {
            return true;
        }

        if (empty($module)) {
            return false;
        }

        $act = strtolower($action ?: 'view');
        $mod = strtolower($module);

        // Normalize module and action
        $norm = $this->normalizePermission($mod, $act);
        $normMod = $norm['module'];
        $normAct = $norm['action'];
        $permCode = $normMod . '.' . $normAct;

        // Disallow platform-level operations for non-Software App Admin
        if ($this->isPlatformPermission($normMod, $normAct) && !$this->isSoftwareAppAdmin()) {
            return false;
        }

        // Multi-tenant company module enablement check
        $companyId = $session->get('company_id');
        if ($companyId && !$this->isModuleEnabledForCompany($companyId, $normMod)) {
            return false;
        }

        $targetUserId = null;
        $targetRole = null;

        if (!empty($userId)) {
            // Check if $userId corresponds to an actual record in the users table
            $userRow = null;
            try {
                if ($this->db->tableExists('users')) {
                    $userRow = $this->db->table('users')->select('id, role_id')->where('id', $userId)->get()->getRowArray();
                }
            } catch (\Throwable $e) {
                $userRow = null;
            }

            if ($userRow) {
                // Definitively a real user in the system — NEVER treat as a role!
                $targetUserId = $userRow['id'];
                $targetRole = $role ?: ($userRow['role_id'] ?? null);
            } elseif (str_contains($userId, '-') || str_starts_with($userId, 'usr') || strlen($userId) >= 20) {
                // Explicit user ID format
                $targetUserId = $userId;
                $targetRole = $role;
            } else {
                // Non-UUID string not found in users table.
                // Allow ONLY specific system role codes (NEVER generic admin/user/staff/manager).
                $strictSystemRoles = [
                    'software_app_admin', 'company_admin', 'hr_admin', 'hr_officer',
                    'branch_manager', 'auditor', 'finance'
                ];
                $cleaned = strtolower(trim($userId));
                if (in_array($cleaned, $strictSystemRoles, true)) {
                    $targetRole = $cleaned;
                    $targetUserId = null;
                } else {
                    // Fail closed for unrecognized identifier; treat as userId so check() executes rather than role bypass
                    $targetUserId = $userId;
                    $targetRole = $role;
                }
            }
        } else {
            $targetUserId = null;
            $targetRole = $role;
        }

        // If role was passed as a UUID, transfer to targetUserId if empty
        if (empty($targetUserId) && !empty($targetRole) && strlen($targetRole) === 36 && str_contains($targetRole, '-')) {
            try {
                if ($this->db->tableExists('users')) {
                    $uRow = $this->db->table('users')->select('id')->where('id', $targetRole)->get()->getRowArray();
                    if ($uRow) {
                        $targetUserId = $uRow['id'];
                        $targetRole = null;
                    }
                }
            } catch (\Throwable $e) {
                // Ignore DB error during bootstrap
            }
        }

        if (empty($targetUserId) && empty($targetRole)) {
            $targetUserId = $session->get('user_id');
            $targetRole = $sessionRole;
        }

        // 1. Evaluate target user if present
        if (!empty($targetUserId)) {
            $decision = $this->check($targetUserId, $permCode);
            if ($decision->isAllowed()) {
                return true;
            }
            // check() is the single source of truth. Explicit user DENY, scope/tenant/platform/module
            // denials and role-matrix removals are FINAL. The legacy role fallback below is used only
            // as a one-time bootstrap when the user's system role (is_system = 1) has zero role_permissions rows.
            if ($decision->tier !== 'default_deny' || !$this->isRoleUnseeded($targetUserId)) {
                return false;
            }
        }

        // 2. Fallback to role-level access check (system roles only; custom roles with is_system = 0 fail closed)
        $targetRole = strtolower((string)($targetRole ?: ($role ?: ($sessionRole ?? ''))));
        if ($targetRole) {
            $roleRow = $this->resolveRoleRecord($targetRole, $companyId, $targetUserId);
            if ($roleRow) {
                if (isset($roleRow['is_system']) && (int)$roleRow['is_system'] === 0) {
                    return false;
                }
                $targetRole = strtolower((string)($roleRow['code'] ?? $roleRow['name'] ?? ''));
            }
            return $this->checkDefaultRoleAccess($targetRole, $normMod, $normAct, $companyId, $targetUserId);
        }

        return false;
    }

    /**
     * Unified Permission-First Evaluator
     * 
     * Pipeline:
     * 1. Normalize code and fail-closed if unknown.
     * 2. Verify user and role active status.
     * 3. Root Rule 1: Software App Admin universal allow (scope: 'all').
     * 4. Platform permission guard (exclusively Software App Admin).
     * 5. User-level Overrides (user_permissions):
     *    - Expired overrides ignored.
     *    - Explicit DENY (is_granted = 0) ALWAYS wins over grants.
     *    - Explicit GRANT (is_granted = 1) grants elevated access with scope.
     * 6. Self-Service Implicit Rule for Linked Employees:
     *    - Linked employees get implicit self-service on own data (scope: 'self').
     * 7. Root Rule 2: Company Admin full company business authority (scope: 'company').
     * 8. Base Role Default Permissions (role_permissions table from DB):
     *    - Single source of truth in DB.
     *    - Auditor restricted from any mutation actions.
     * 9. Default: FAIL-CLOSED DENY.
     */
    public function check(string $userId, string $permissionCode, $targetRecord = null): PermissionDecision
    {
        if (is_string($targetRecord) && !empty($targetRecord)) {
            $targetRecord = ['company_id' => $targetRecord];
        } elseif ($targetRecord !== null && !is_array($targetRecord)) {
            $targetRecord = (array)$targetRecord;
        }

        $cacheKey = $userId . '|' . $permissionCode;
        if ($targetRecord !== null) {
            $cacheKey .= '|' . md5(json_encode($targetRecord));
        }

        if (isset(self::$hasAccessCache[$cacheKey])) {
            $cached = self::$hasAccessCache[$cacheKey];
            if ($cached instanceof PermissionDecision) {
                return $cached;
            }
            return new PermissionDecision((bool)$cached, 'cached');
        }

        // 1. Normalize permission
        $norm = $this->normalizePermission($permissionCode);
        $normCode = $norm['code'];
        $normMod  = $norm['module'];
        $normAct  = $norm['action'];

        $config = new \Config\Permissions();
        $isKnown = isset($config->catalogue[$normCode])
            || isset($config->catalogue[$permissionCode])
            || isset($config->catalogue[$normMod . '.' . $normAct]);

        if (!$isKnown) {
            $isKnown = $this->db->table('permissions')
                ->where('code', $normCode)
                ->orWhere('code', $permissionCode)
                ->countAllResults() > 0;
        }

        $isCanonicalAction = in_array($normAct, $config->canonicalActions ?? [], true);
        $isKnownModule     = isset($config->modules[$normMod]) || isset($config->modules[$permissionCode]);

        if (!$isKnown) {
            log_message('warning', "RBAC: Unknown permission code '{$permissionCode}' (normalized: '{$normCode}') evaluated for user '{$userId}'.");
        }

        // 1a. If action is not even in canonical vocabulary (e.g. leave.view_all_typo), fail-closed immediately
        if (!$isKnown && (!$isCanonicalAction || $isKnownModule)) {
            $decision = new PermissionDecision(false, 'unknown_permission_deny', 'none', "Unknown permission code '{$permissionCode}'", $normCode);
            self::$hasAccessCache[$cacheKey] = $decision;
            return $decision;
        }

        // 2. Fetch User and Role Record
        $roleCompanyCol = $this->hasRoleCompanyColumn() ? ', roles.company_id as role_company_id' : '';
        $hasRoleIsSystem = $this->db->tableExists('roles') && $this->db->fieldExists('is_system', 'roles');
        $roleSystemCol = $hasRoleIsSystem ? ', roles.is_system as role_is_system' : '';

        $user = $this->db->table('users')
            ->select('users.*, roles.name as role_name, roles.code as role_code, roles.status as role_status' . $roleCompanyCol . $roleSystemCol)
            ->join('roles', 'roles.id = users.role_id', 'left')
            ->where('users.id', $userId)
            ->orWhere('users.username', $userId)
            ->get()
            ->getRowArray();

        if (!$user) {
            $decision = new PermissionDecision(false, 'inactive_deny', 'none', 'User account does not exist', $normCode);
            self::$hasAccessCache[$cacheKey] = $decision;
            return $decision;
        }

        // Inactive user guard
        if (strtolower($user['status'] ?? 'active') !== 'active') {
            $decision = new PermissionDecision(false, 'inactive_deny', 'none', 'User account is deactivated or suspended', $normCode);
            self::$hasAccessCache[$cacheKey] = $decision;
            return $decision;
        }

        // RC-8: Platform Admin is decided by is_system=1 AND company_id IS NULL on both role and user, not purely by name
        $isSystemRole = (int)($user['role_is_system'] ?? 0) === 1;
        $isGlobalRole = empty($user['role_company_id']);
        $isGlobalUser = empty($user['company_id']);
        $isPlatformAdmin = $isSystemRole && $isGlobalRole && $isGlobalUser;

        // Custom role guard: if roles.is_system == 0, never grant root/system powers by role name
        $isCustomRole = $hasRoleIsSystem && isset($user['role_is_system']) && (int)$user['role_is_system'] === 0;
        $canonicalRole = $isCustomRole
            ? strtolower(trim((string)($user['role_code'] ?? 'custom')))
            : $this->canonicalizeRole($user['role_code'] ?? $user['role_name'] ?? '');

        // 3. Root Rule 1: Software App Admin has unrestricted platform access (including newly added modules)
        if ($isPlatformAdmin && $canonicalRole === 'software_app_admin') {
            $decision = new PermissionDecision(true, 'root_software_app_admin', 'all', 'Software App Admin has unrestricted platform access', $normCode);
            self::$hasAccessCache[$cacheKey] = $decision;
            return $decision;
        }

        // Inactive role guard
        if (isset($user['role_status']) && strtolower($user['role_status']) !== 'active') {
            $decision = new PermissionDecision(false, 'inactive_deny', 'none', 'Assigned user role is currently inactive', $normCode);
            self::$hasAccessCache[$cacheKey] = $decision;
            return $decision;
        }

        // 4. Platform Permission Boundary: Exclusively reserved for Software App Admin
        $isPlatform = $this->isPlatformPermission($normMod, $normAct) || $this->isPlatformPermission($normCode);
        if ($isPlatform) {
            $decision = new PermissionDecision(false, 'platform_deny', 'none', 'Platform permissions are strictly reserved for Software App Admin', $normCode);
            self::$hasAccessCache[$cacheKey] = $decision;
            return $decision;
        }

        // Multi-tenant Module Enabled Check
        $companyId = $user['company_id'] ?? null;
        if ($companyId && !$this->isModuleEnabledForCompany($companyId, $normMod)) {
            $decision = new PermissionDecision(false, 'module_disabled', 'none', "Module '{$normMod}' is disabled for tenant", $normCode);
            self::$hasAccessCache[$cacheKey] = $decision;
            return $decision;
        }

        // Build exact permission code match list (including paired module aliases for the SAME action only — no .manage wildcard)
        $permCodes = [$normCode, $permissionCode, $normMod . '.' . $normAct];
        if ($normMod === 'leave' || $normMod === 'leaves') {
            $permCodes[] = 'leaves.' . $normAct;
            $permCodes[] = 'leave.' . $normAct;
        } elseif ($normMod === 'company_expense' || $normMod === 'expenses') {
            $permCodes[] = 'expenses.' . $normAct;
            $permCodes[] = 'company_expense.' . $normAct;
        } elseif ($normMod === 'medical_insurance' || $normMod === 'insurance') {
            $permCodes[] = 'insurance.' . $normAct;
            $permCodes[] = 'medical_insurance.' . $normAct;
        } elseif ($normMod === 'roster' || $normMod === 'rostering') {
            $permCodes[] = 'rostering.' . $normAct;
            $permCodes[] = 'roster.' . $normAct;
        } elseif ($normMod === 'directory' || $normMod === 'employees') {
            $permCodes[] = 'employees.' . $normAct;
            $permCodes[] = 'directory.' . $normAct;
        } elseif ($normMod === 'user' || $normMod === 'users') {
            $permCodes[] = 'users.' . $normAct;
            $permCodes[] = 'user.' . $normAct;
        } elseif ($normMod === 'role' || $normMod === 'roles') {
            $permCodes[] = 'roles.' . $normAct;
            $permCodes[] = 'role.' . $normAct;
        }
        $permCodes = array_values(array_unique($permCodes));
        $hasActionCol = $this->ensureActionColumn();

        // 5. User-level Overrides (user_permissions table)
        $builder = $this->db->table('user_permissions')
            ->select('user_permissions.*, permissions.code as perm_code, permissions.module as perm_mod')
            ->join('permissions', 'permissions.id = user_permissions.permission_id')
            ->where('user_permissions.user_id', $user['id'])
            ->groupStart()
                ->whereIn('permissions.code', $permCodes);

        if ($hasActionCol) {
            $builder->orGroupStart()
                ->where('permissions.module', $normMod)
                ->where('permissions.action', $normAct)
            ->groupEnd();
        }
        $overrides = $builder->groupEnd()->get()->getResultArray();

        if (!empty($overrides)) {
            $nowTs = time();

            // First: Explicit DENY always takes precedence over explicit GRANT, role default, and self-service
            foreach ($overrides as $ov) {
                if (!empty($ov['expires_at']) && strtotime($ov['expires_at']) < $nowTs) {
                    continue; // Ignore expired override
                }
                if ((int)$ov['is_granted'] === 0) {
                    $decision = new PermissionDecision(false, 'user_override_deny', 'none', 'Explicit user-level DENY override active', $normCode, $ov['expires_at'] ?? null);
                    self::$hasAccessCache[$cacheKey] = $decision;
                    return $decision;
                }
            }

            // Second: Explicit GRANT
            foreach ($overrides as $ov) {
                if (!empty($ov['expires_at']) && strtotime($ov['expires_at']) < $nowTs) {
                    continue; // Ignore expired override
                }
                if ((int)$ov['is_granted'] === 1) {
                    $scopeLevel = $ov['scope_level'] ?? 'company';
                    $scopeId = !empty($ov['scope_id']) ? (string)$ov['scope_id'] : null;
                    if ($targetRecord !== null && !$this->assertInScope($user, $scopeLevel, $targetRecord, $scopeId)) {
                        $decision = new PermissionDecision(false, 'out_of_scope_deny', $scopeLevel, 'Target record out of granted scope', $normCode, $ov['expires_at'] ?? null, $scopeId);
                        self::$hasAccessCache[$cacheKey] = $decision;
                        return $decision;
                    }
                    $decision = new PermissionDecision(true, 'user_override_grant', $scopeLevel, 'Explicit user-level GRANT override active', $normCode, $ov['expires_at'] ?? null, $scopeId);
                    self::$hasAccessCache[$cacheKey] = $decision;
                    return $decision;
                }
            }
        }

        // 6. Root Rule 2: Company Admin full authority over company business modules (including brand-new modules)
        if (!$isCustomRole && $canonicalRole === 'company_admin') {
            if ($targetRecord !== null && !$this->assertInScope($user, 'company', $targetRecord)) {
                $decision = new PermissionDecision(false, 'tenant_isolation_deny', 'company', 'Company Admin strictly constrained by tenant boundary', $normCode);
                self::$hasAccessCache[$cacheKey] = $decision;
                return $decision;
            }
            $decision = new PermissionDecision(true, 'root_company_admin', 'company', 'Company Admin has administrative authority over tenant business modules', $normCode);
            self::$hasAccessCache[$cacheKey] = $decision;
            return $decision;
        }

        // Unknown permission guard for non-root roles
        if (!$isKnown) {
            $decision = new PermissionDecision(false, 'unknown_permission_deny', 'none', "Unknown permission code '{$permissionCode}'", $normCode);
            self::$hasAccessCache[$cacheKey] = $decision;
            return $decision;
        }

        // 7. Base Role Permissions (role_permissions table as authoritative DB source)
        $roleId = $user['role_id'] ?? null;
        if ($roleId) {
            $rBuilder = $this->db->table('role_permissions')
                ->select('role_permissions.*, permissions.code as perm_code')
                ->join('permissions', 'permissions.id = role_permissions.permission_id')
                ->where('role_permissions.role_id', $roleId)
                ->groupStart()
                    ->whereIn('permissions.code', $permCodes);

            if ($hasActionCol) {
                $rBuilder->orGroupStart()
                    ->where('permissions.module', $normMod)
                    ->where('permissions.action', $normAct)
                ->groupEnd();
            }

            $rBuilder->groupEnd();

            // RC-6: Deterministic ORDER BY so $rolePerms[0] does not pick an arbitrary row when aliases differ
            $escapedNorm = $this->db->escape($normCode);
            $escapedPerm = $this->db->escape($permissionCode);
            $rBuilder->orderBy("CASE WHEN permissions.code = {$escapedNorm} THEN 0 WHEN permissions.code = {$escapedPerm} THEN 1 ELSE 2 END", 'ASC', false);
            if ($this->db->fieldExists('scope_level', 'role_permissions')) {
                // Scope specificity hierarchy order: self > team > department > branch > company
                $rBuilder->orderBy("CASE role_permissions.scope_level WHEN 'self' THEN 1 WHEN 'team' THEN 2 WHEN 'department' THEN 3 WHEN 'branch' THEN 4 WHEN 'company' THEN 5 ELSE 6 END", 'ASC', false);
            }
            if ($this->db->fieldExists('id', 'role_permissions')) {
                $rBuilder->orderBy('role_permissions.id', 'ASC');
            } else {
                $rBuilder->orderBy('permissions.id', 'ASC');
            }

            $rolePerms = $rBuilder->get()->getResultArray();

            if (!empty($rolePerms)) {
                // Hard Rule: Auditor is strictly read-only view and export. Any state mutation is blocked.
                if ($canonicalRole === 'auditor') {
                    if (self::isAuditorMutationAction($normAct)) {
                        $decision = new PermissionDecision(false, 'auditor_mutation_deny', 'none', 'Auditor role is strictly read-only and prohibited from performing state mutations', $normCode);
                        self::$hasAccessCache[$cacheKey] = $decision;
                        return $decision;
                    }
                }

                // Manager and Team Leader directory module restrictions: view-only on own team
                if (in_array($canonicalRole, ['manager', 'team_leader'], true) && $normMod === 'directory') {
                    if ($normAct !== 'view') {
                        $decision = new PermissionDecision(false, 'role_boundary_deny', 'none', "Role '{$canonicalRole}' is restricted to view-only on staff directory", $normCode);
                        self::$hasAccessCache[$cacheKey] = $decision;
                        return $decision;
                    }
                }

                // Branch Manager directory module restrictions: view/edit within branch, deny delete/terminate
                if ($canonicalRole === 'branch_manager' && $normMod === 'directory') {
                    if (in_array($normAct, ['delete', 'terminate'], true)) {
                        $decision = new PermissionDecision(false, 'role_boundary_deny', 'none', "Role 'branch_manager' is prohibited from deleting or terminating personnel", $normCode);
                        self::$hasAccessCache[$cacheKey] = $decision;
                        return $decision;
                    }
                }

                // HR Officer directory module restrictions: view/create/edit allowed; delete/promote/terminate denied unless explicitly in role_permissions
                if ($canonicalRole === 'hr_officer' && $normMod === 'directory') {
                    if (in_array($normAct, ['delete', 'promote', 'terminate'], true)) {
                        $hasExplicit = false;
                        $exactCodes = ['directory.' . $normAct, 'employees.' . $normAct];
                        foreach ($rolePerms as $rpCheck) {
                            $codeCheck = strtolower(trim((string)($rpCheck['perm_code'] ?? '')));
                            if (in_array($codeCheck, $exactCodes, true)) {
                                $hasExplicit = true;
                                break;
                            }
                        }
                        if (!$hasExplicit) {
                            $decision = new PermissionDecision(false, 'role_boundary_deny', 'none', "Action '{$normAct}' on staff directory is denied for hr_officer unless explicitly granted in role permissions", $normCode);
                            self::$hasAccessCache[$cacheKey] = $decision;
                            return $decision;
                        }
                    }
                }

                $rp = $rolePerms[0];
                $scopeLevel = $rp['scope_level'] ?? 'company';
                $scopeId = !empty($rp['scope_id']) ? (string)$rp['scope_id'] : null;
                if ($normMod === 'directory') {
                    if ($canonicalRole === 'branch_manager') {
                        $scopeLevel = 'branch';
                    } elseif (in_array($canonicalRole, ['manager', 'team_leader'], true)) {
                        $scopeLevel = 'team';
                    }
                }
                if ($targetRecord !== null && !$this->assertInScope($user, $scopeLevel, $targetRecord, $scopeId)) {
                    $decision = new PermissionDecision(false, 'out_of_scope_deny', $scopeLevel, 'Target record out of role granted scope', $normCode, null, $scopeId);
                    self::$hasAccessCache[$cacheKey] = $decision;
                    return $decision;
                }
                $decision = new PermissionDecision(true, 'role_default', $scopeLevel, "Granted by assigned role '{$canonicalRole}'", $normCode, null, $scopeId);
                self::$hasAccessCache[$cacheKey] = $decision;
                return $decision;
            }

            // RC-1 FIX: Check if the assigned role has ANY permission rows configured for this module.
            // If the role has rows configured for this module, but this specific permission is missing,
            // the role configuration for this module is authoritative and must not be overridden
            // by implicit self-service fallthrough.
            $modAliases = [$normMod];
            $moduleAliasesMap = [
                'directory'         => ['employees', 'employee'],
                'employees'         => ['directory', 'employee'],
                'attendance'        => ['biometric'],
                'rostering'         => ['roster', 'shifts', 'shift'],
                'leaves'            => ['leave'],
                'payroll'           => ['salary'],
                'pf'                => ['provident_fund', 'provident-fund'],
                'bonus'             => ['bonuses'],
                'loans'             => ['loan'],
                'assets'            => ['asset'],
                'training'          => ['trainings'],
                'performance'       => ['appraisal', 'appraisals', 'kpi'],
                'notices'           => ['notice', 'bulletin'],
                'notifications'     => ['notification'],
                'company_expense'   => ['expense', 'expenses'],
                'medical_insurance' => ['insurance'],
            ];
            if (isset($moduleAliasesMap[$normMod])) {
                $modAliases = array_values(array_unique(array_merge($modAliases, $moduleAliasesMap[$normMod])));
            }

            try {
                $roleHasModuleRows = $this->db->table('role_permissions')
                    ->join('permissions', 'permissions.id = role_permissions.permission_id')
                    ->where('role_permissions.role_id', $roleId)
                    ->groupStart()
                        ->whereIn('permissions.module', $modAliases)
                    ->groupEnd()
                    ->countAllResults() > 0;
            } catch (\Throwable $e) {
                $roleHasModuleRows = false;
            }
        } else {
            $roleHasModuleRows = false;
        }

        // 8. Implicit Self-Service for Linked Employees (Always scope = 'self')
        // RC-1 FIX:
        // - Evaluated ONLY when the role has NO rows configured for this module ($roleHasModuleRows === false).
        // - Strictly limited to genuinely self-scoped actions (*.self, payslip.own, clock, regularize, profile).
        // - NEVER granted for module-wide 'view' or administrative actions.
        if (!$roleHasModuleRows && $this->isImplicitSelfService($normMod, $normAct)) {
            $isLinkedEmployee = !empty($user['employee_id']);
            if (!$isLinkedEmployee && !empty($user['id'])) {
                try {
                    if ($this->db->tableExists('employees') && $this->db->fieldExists('user_id', 'employees')) {
                        $empRow = $this->db->table('employees')->select('id')->where('user_id', $user['id'])->get()->getRowArray();
                        $isLinkedEmployee = !empty($empRow['id']);
                    }
                } catch (\Throwable $e) {}
            }
            if (!$isLinkedEmployee && !empty($user['email'])) {
                $empRow = $this->db->table('employees')->select('id')->where('email', $user['email'])->get()->getRowArray();
                $isLinkedEmployee = !empty($empRow['id']);
            }
            if (!$isLinkedEmployee && !empty($user['username']) && !empty($user['company_id'])) {
                $empRow = $this->db->table('employees')
                    ->select('id')
                    ->where('company_id', $user['company_id'])
                    ->where('employee_code', $user['username'])
                    ->get()
                    ->getRowArray();
                $isLinkedEmployee = !empty($empRow['id']);
            }

            if ($isLinkedEmployee) {
                if ($targetRecord !== null && !$this->assertInScope($user, 'self', $targetRecord)) {
                    $decision = new PermissionDecision(false, 'self_service_scope_mismatch', 'self', 'Self-service action only permitted on user own records', $normCode);
                    self::$hasAccessCache[$cacheKey] = $decision;
                    return $decision;
                }
                $decision = new PermissionDecision(true, 'self_service_implicit', 'self', 'Implicit self-service permission for employee profile', $normCode);
                self::$hasAccessCache[$cacheKey] = $decision;
                return $decision;
            }
        }

        // 9. Fail-closed Default Deny
        $decision = new PermissionDecision(false, 'default_deny', 'none', 'Permission not granted by user override, role, or root rules', $normCode);
        self::$hasAccessCache[$cacheKey] = $decision;
        return $decision;
    }

    /**
     * Flush memory permission decisions cache
     */
    public static function flushCache(?string $userId = null): void
    {
        if ($userId === null) {
            self::$hasAccessCache = [];
        } else {
            foreach (array_keys(self::$hasAccessCache) as $k) {
                if (str_starts_with($k, $userId . '|')) {
                    unset(self::$hasAccessCache[$k]);
                }
            }
        }
    }

    /**
     * Polymorphic permission evaluator matching BaseController::hasPermission
     * Supports both:
     * hasPermission(string $permissionCode, ?string $userId = null)
     * hasPermission(string $userId, string $permissionCode)
     */
    public function hasPermission($arg1, $arg2 = null): bool
    {
        if ($this->isSoftwareAppAdmin()) {
            return true;
        }

        $userId = null;
        $permissionCode = null;

        if ($arg2 !== null) {
            if (str_starts_with((string)$arg1, 'usr-') || str_starts_with((string)$arg1, 'user-') || is_numeric($arg1)) {
                $userId = (string)$arg1;
                $permissionCode = (string)$arg2;
            } elseif (str_contains((string)$arg1, '.') || !str_contains((string)$arg2, '.')) {
                $permissionCode = (string)$arg1;
                $userId = (string)$arg2;
            } else {
                $userId = (string)$arg1;
                $permissionCode = (string)$arg2;
            }
        } else {
            $permissionCode = (string)$arg1;
            $session = \Config\Services::session();
            $userId = $session ? $session->get('user_id') : null;
        }

        if (!empty($userId) && !empty($permissionCode)) {
            return $this->check($userId, $permissionCode)->isAllowed();
        }

        return false;
    }

    /**
     * Single resolver entry point (Section 1 of MASTER_INSTRUCTION_RBAC_and_Attendance.md).
     * Supports both:
     * - PermissionService::can(string $userId, string $code, $context = null): PermissionDecision
     * - PermissionService::can(string $code, $context = null, ?string $userId = null): PermissionDecision
     */
    public function can(string $firstArg, $secondArg = null, $thirdArg = null): PermissionDecision
    {
        // Form A: can(string $userId, string $code, $context = null)
        if (is_string($secondArg) && (str_contains($secondArg, '.') || !str_contains($firstArg, '.'))) {
            $userId = $firstArg;
            $code = $secondArg;
            $targetRecord = is_array($thirdArg) ? $thirdArg : (is_string($thirdArg) && !empty($thirdArg) ? ['company_id' => $thirdArg] : null);
            return $this->check($userId, $code, $targetRecord);
        }

        // Form B: can(string $code, $context = null, ?string $userId = null)
        $code = $firstArg;
        $targetRecord = is_array($secondArg) ? $secondArg : (is_array($thirdArg) ? $thirdArg : null);
        if ($targetRecord === null && is_string($secondArg) && !str_contains($secondArg, '.') && is_string($thirdArg)) {
            $targetRecord = ['company_id' => $secondArg];
        }
        $userId = is_string($thirdArg) ? $thirdArg : (is_string($secondArg) && !is_array($secondArg) && str_contains($firstArg, '.') ? $secondArg : null);

        if (empty($userId)) {
            $session = \Config\Services::session();
            $userId = $session ? (string)$session->get('user_id') : '';
        }

        return $this->check((string)$userId, $code, $targetRecord);
    }

    /**
     * Normalize module and action or permission code into canonical form
     */
    public function normalizePermission(string $permissionOrModule, ?string $action = null): array
    {
        if ($action === null && str_contains($permissionOrModule, '.')) {
            $parts = explode('.', $permissionOrModule, 2);
            $mod = strtolower(trim($parts[0]));
            $act = strtolower(trim($parts[1] ?? 'view'));
        } else {
            $mod = strtolower(trim($permissionOrModule));
            $act = strtolower(trim($action ?: 'view'));
        }

        // Module aliases
        $moduleAliases = [
            'leave'       => 'leaves',
            'expense'     => 'company_expense',
            'expenses'    => 'company_expense',
            'insurance'   => 'medical_insurance',
            'users'       => 'user',
            'roles'       => 'role',
            'employee'    => 'directory',
            'employees'   => 'directory',
            'biometric'   => 'attendance',
            'roster'      => 'rostering',
            'shifts'      => 'rostering',
            'shift'       => 'rostering',
            'bonuses'     => 'bonus',
            'loan'        => 'loans',
            'asset'       => 'assets',
            'trainings'   => 'training',
            'appraisal'   => 'performance',
            'appraisals'  => 'performance',
            'kpi'         => 'performance',
            'notice'      => 'notices',
            'bulletin'    => 'notices',
            'notification'=> 'notifications',
            'provident_fund' => 'pf',
            'provident-fund' => 'pf',
        ];

        if (isset($moduleAliases[$mod])) {
            $mod = $moduleAliases[$mod];
        }

        // Action aliases
        $actionAliases = [
            'upload'               => 'create',
            'update'               => 'edit',
            'export_excel'         => 'export',
            'export_pdf'           => 'export',
            'print'                => 'export',
            'restore'              => 'edit',
            'lock_unlock'          => 'manage',
            'recalculate'          => 'run',
            'settle'               => 'approve',
            'read'                 => 'view',
            'history'              => 'view',
            'early_closure'        => 'early_closures',
            'early-closure'        => 'early_closures',
            'early-closures'       => 'early_closures',
            'early_closure_manage' => 'early_closure_manage',
            'regularize_approve'   => 'regularize_approve',
            'balance_adjust'       => 'balance_adjust',
        ];

        if (isset($actionAliases[$act])) {
            $act = $actionAliases[$act];
        }

        return [
            'module' => $mod,
            'action' => $act,
            'code'   => $mod . '.' . $act,
        ];
    }

    /**
     * True ONLY when the user's role is a system role (roles.is_system = 1) AND has no role_permissions rows at all.
     * Custom roles (is_system = 0) are never treated as unseeded system roles.
     */
    protected function isRoleUnseeded(string $userId): bool
    {
        try {
            if (!$this->db || !$this->db->tableExists('users') || !$this->db->tableExists('roles')) {
                return false;
            }
            $hasIsSystem = $this->db->fieldExists('is_system', 'roles');
            $selectCols = 'users.role_id' . ($hasIsSystem ? ', roles.is_system' : '');
            $u = $this->db->table('users')
                ->select($selectCols)
                ->join('roles', 'roles.id = users.role_id', 'left')
                ->where('users.id', $userId)
                ->get()
                ->getRowArray();
            if (empty($u['role_id'])) {
                return false;
            }
            if ($hasIsSystem && (int)($u['is_system'] ?? 0) !== 1) {
                return false;
            }
            return $this->db->table('role_permissions')->where('role_id', $u['role_id'])->countAllResults() === 0;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Check if module and action are implicit self-service for linked employees.
     * RC-1 FIX:
     * Strictly limited to genuinely self-scoped actions (*.self, payslip.own, clock, regularize, profile).
     * Module-wide 'view' and administrative actions are NEVER granted implicitly!
     */
    protected function isImplicitSelfService(string $module, string $action): bool
    {
        // NEVER allow module-wide view (except personal operational dashboard)
        if ($action === 'view') {
            return $module === 'dashboard';
        }

        // Genuinely self-scoped action patterns (*.self, *.own, profile, clock, regularize, payslip)
        if (in_array($action, ['self', 'own', 'profile', 'clock', 'regularize', 'payslip', 'payslip_own'], true)) {
            return true;
        }

        if (str_ends_with($action, '.self') || str_ends_with($action, '_self') || str_ends_with($action, '.own') || str_ends_with($action, '_own')) {
            return true;
        }

        $selfServiceActions = [
            'dashboard'     => ['view'],
            'profile'       => ['view', 'edit', 'self'],
            'directory'     => ['profile', 'self'],
            'employees'     => ['profile', 'self'],
            'attendance'    => ['clock', 'regularize'],
            'payroll'       => ['payslip', 'payslip_own', 'self'],
            'payslip'       => ['view', 'own', 'self'],
        ];

        return isset($selfServiceActions[$module]) && in_array($action, $selfServiceActions[$module], true);
    }

    /**
     * Resolve a role record safely within tenant boundaries:
     * 1. If user ID is available, resolve by current user's role_id (users.role_id).
     * 2. Otherwise resolve by code AND company_id of the acting user (session company_id).
     *    Never use orWhere('name'...) without the same company filter.
     *    Group the conditions: company_id = X AND (code = Y OR name = Y).
     * 3. Only fall back to a role row with company_id IS NULL (global/system role) if no company-specific one exists.
     *    Never fall back to another company's role.
     */
    public function resolveRoleRecord(string $roleOrCode, ?string $companyId = null, ?string $userId = null): ?array
    {
        if (!$this->db) {
            return null;
        }

        $session = function_exists('session') ? session() : (class_exists('\Config\Services') ? \Config\Services::session() : null);
        $actingUserId = $userId ?: ($session ? $session->get('user_id') : null);
        $actingCompanyId = $companyId ?: ($session ? $session->get('company_id') : null);

        $hasCompanyCol = $this->hasRoleCompanyColumn();

        // 1. Resolve by CURRENT USER's role_id whenever a user id is available
        if (!empty($actingUserId)) {
            $userRow = $this->db->table('users')
                ->select('id, role_id, company_id')
                ->where('id', $actingUserId)
                ->get()
                ->getRowArray();

            if ($userRow) {
                if (empty($actingCompanyId) && !empty($userRow['company_id'])) {
                    $actingCompanyId = $userRow['company_id'];
                }

                if (!empty($userRow['role_id'])) {
                    $roleRow = $this->db->table('roles')
                        ->where('id', $userRow['role_id'])
                        ->get()
                        ->getRowArray();

                    if ($roleRow) {
                        $roleCompany = $hasCompanyCol ? ($roleRow['company_id'] ?? null) : null;
                        // Tenant guard: Must belong to acting company or be a global role (company_id IS NULL)
                        // Never fall back to another company's role
                        if ($roleCompany === null || empty($roleCompany) || $roleCompany === $actingCompanyId) {
                            return $roleRow;
                        }
                    }
                }
            }
        }

        // 2. Resolve by code/name AND company_id of the acting user
        $canonicalRole = $this->canonicalizeRole($roleOrCode);
        $displayName = ucwords(str_replace('_', ' ', $canonicalRole));
        $roleIdentifiers = array_unique(array_filter([$roleOrCode, $canonicalRole, $displayName]));

        if (!empty($actingCompanyId) && $hasCompanyCol) {
            $builder = $this->db->table('roles')
                ->where('company_id', $actingCompanyId)
                ->groupStart();

            $first = true;
            foreach ($roleIdentifiers as $ident) {
                if ($first) {
                    $builder->where('id', $ident)
                            ->orWhere('code', $ident)
                            ->orWhere('name', $ident);
                    $first = false;
                } else {
                    $builder->orWhere('id', $ident)
                            ->orWhere('code', $ident)
                            ->orWhere('name', $ident);
                }
            }
            $companyRole = $builder->groupEnd()->get()->getRowArray();
            if ($companyRole) {
                return $companyRole;
            }
        }

        // 3. Fallback to global/system role (company_id IS NULL) ONLY if no company-specific one exists
        // Never fall back to another company's role
        $globalBuilder = $this->db->table('roles');
        if ($hasCompanyCol) {
            $globalBuilder->where('company_id', null);
        }

        $globalBuilder->groupStart();
        $first = true;
        foreach ($roleIdentifiers as $ident) {
            if ($first) {
                $globalBuilder->where('id', $ident)
                              ->orWhere('code', $ident)
                              ->orWhere('name', $ident);
                $first = false;
            } else {
                $globalBuilder->orWhere('id', $ident)
                              ->orWhere('code', $ident)
                              ->orWhere('name', $ident);
            }
        }
        $globalRole = $globalBuilder->groupEnd()->get()->getRowArray();
        return $globalRole ?: null;
    }

    /**
     * Check default role access without user context (used by CLI, seeds, and fallbacks)
     * Strictly fail-closed!
     */
    public function checkDefaultRoleAccess(string $role, string $module, string $action = 'view', ?string $companyId = null, ?string $userId = null): bool
    {
        $canonicalRole = $this->canonicalizeRole($role);
        $norm = $this->normalizePermission($module, $action);
        $mod  = $norm['module'];
        $act  = $norm['action'];
        $code = $norm['code'];

        // Root Rule 1: Software App Admin universal allow
        if ($canonicalRole === 'software_app_admin' || $this->isSoftwareAppAdmin()) {
            return true;
        }

        // Platform permissions are strictly reserved for Software App Admin
        if ($this->isPlatformPermission($code) || $this->isPlatformPermission($mod, $act)) {
            return false;
        }

        // Root Rule 2: Company Admin full business authority
        if ($canonicalRole === 'company_admin') {
            $config = new \Config\Permissions();
            $knownActions = array_merge(
                $config->canonicalActions ?? [],
                array_keys($config->actionAliases ?? []),
                ['view', 'create', 'edit', 'delete', 'approve', 'endorse', 'reject', 'cancel', 'manage', 'export', 'run', 'adjust', 'assign', 'clock', 'regularize', 'early_closures', 'disburse', 'generate', 'settle', 'view_all', 'select', 'loans']
            );

            // Fail-closed against unknown/made-up actions
            if (!in_array($act, $knownActions, true)) {
                return false;
            }

            return true;
        }

        // If employee action is implicit self-service, allow immediately
        if ($canonicalRole === 'employee' && $this->isImplicitSelfService($mod, $act)) {
            return true;
        }

        // Auditor boundary: strictly read-only view and export (mutations strictly prohibited)
        if ($canonicalRole === 'auditor') {
            if (self::isAuditorMutationAction($act)) {
                return false;
            }
        }

        // Manager and Team Leader directory module restrictions: view only!
        if (in_array($canonicalRole, ['manager', 'team_leader'], true) && $mod === 'directory') {
            if ($act !== 'view') {
                return false;
            }
        }

        // Branch Manager directory module restrictions: keep view/edit within own branch; deny delete/terminate!
        if ($canonicalRole === 'branch_manager' && $mod === 'directory') {
            if (in_array($act, ['delete', 'terminate'], true)) {
                return false;
            }
        }

        // Resolve acting user and company context
        $session = function_exists('session') ? session() : (class_exists('\Config\Services') ? \Config\Services::session() : null);
        $actingUserId = $userId ?: ($session ? $session->get('user_id') : null);
        $actingCompanyId = $companyId ?: ($session ? $session->get('company_id') : null);

        if (!empty($actingUserId) && $this->db) {
            $userRow = $this->db->table('users')
                ->select('id, role_id, company_id')
                ->where('id', $actingUserId)
                ->get()
                ->getRowArray();
            if ($userRow && empty($actingCompanyId) && !empty($userRow['company_id'])) {
                $actingCompanyId = $userRow['company_id'];
            }
        }

        $isSoftwareAdmin = ($canonicalRole === 'software_app_admin') || $this->isSoftwareAppAdmin();

        // If the user has no company id and is not a software admin, return false
        if (!empty($actingUserId) && empty($actingCompanyId) && !$isSoftwareAdmin) {
            return false;
        }
        if ($session && $session->has('user_id') && empty($actingCompanyId) && !$isSoftwareAdmin) {
            return false;
        }

        $config = new \Config\Permissions();
        $isSystemRole = in_array($canonicalRole, array_keys($config->systemRoles), true);

        // Build exact permission code match list (including paired module aliases for the SAME action only — NO wildcards!)
        $permCodes = [$code, $mod . '.' . $act];
        if ($mod === 'leaves' || $mod === 'leave') {
            $permCodes[] = 'leaves.' . $act;
            $permCodes[] = 'leave.' . $act;
        } elseif ($mod === 'directory' || $mod === 'employees') {
            $permCodes[] = 'employees.' . $act;
            $permCodes[] = 'directory.' . $act;
        } elseif ($mod === 'company_expense' || $mod === 'expenses') {
            $permCodes[] = 'expenses.' . $act;
            $permCodes[] = 'company_expense.' . $act;
        } elseif ($mod === 'medical_insurance' || $mod === 'insurance') {
            $permCodes[] = 'insurance.' . $act;
            $permCodes[] = 'medical_insurance.' . $act;
        } elseif ($mod === 'rostering' || $mod === 'roster') {
            $permCodes[] = 'roster.' . $act;
            $permCodes[] = 'rostering.' . $act;
        } elseif ($mod === 'user' || $mod === 'users') {
            $permCodes[] = 'users.' . $act;
            $permCodes[] = 'user.' . $act;
        } elseif ($mod === 'role' || $mod === 'roles') {
            $permCodes[] = 'roles.' . $act;
            $permCodes[] = 'role.' . $act;
        }
        $permCodes = array_values(array_unique($permCodes));

        // Try DB role_permissions first (authoritative single source of truth)
        $roleRow = $this->resolveRoleRecord($canonicalRole, $actingCompanyId, $actingUserId);
        if ($roleRow) {
            $isCustomRole = !$isSystemRole || (isset($roleRow['is_system']) && (int)$roleRow['is_system'] === 0);
            $hasActionCol = $this->ensureActionColumn();

            $builder = $this->db->table('role_permissions')
                ->join('permissions', 'permissions.id = role_permissions.permission_id')
                ->where('role_permissions.role_id', $roleRow['id'])
                ->groupStart()
                    ->whereIn('permissions.code', $permCodes);

            if ($hasActionCol) {
                $builder->orGroupStart()
                    ->where('permissions.module', $mod)
                    ->where('permissions.action', $act)
                ->groupEnd();
            }

            $count = $builder->groupEnd()->countAllResults();
            if ($count > 0) {
                return true;
            }

            // Custom roles fail-closed: they NEVER inherit fallback matrices!
            if ($isCustomRole) {
                return false;
            }

            // A role row existing in the database is governed by DB role_permissions.
            // If the role has 0 rows or this permission was revoked/omitted, fail-closed!
            return false;
        }

        // Custom roles not found in DB fail-closed immediately
        if (!$isSystemRole) {
            return false;
        }

        // Seeded role definitions fallback (ONLY for unseeded environments/CLI tests where DB has no role records)
        return $this->checkFallbackRoleMatrix($canonicalRole, $mod, $act);
    }

    /**
     * Fallback matrix for system roles when DB has not been seeded yet
     */
    protected function checkFallbackRoleMatrix(string $canonicalRole, string $mod, string $act): bool
    {
        // Leave actions strictly require database role_permissions or explicit user grants (zero role-based fallback)
        if ($mod === 'leaves' || $mod === 'leave') {
            return false;
        }

        if ($canonicalRole === 'hr_admin') {
            // Financial operations: strictly view and export only
            if (in_array($mod, ['payroll', 'bonus', 'loans'], true)) {
                return in_array($act, ['view', 'export'], true);
            }

            // Security, RBAC, settings, system boundaries denied
            if (in_array($mod, ['user', 'role', 'settings', 'security', 'system', 'company_provision', 'module_toggle', 'global_rbac', 'global_security', 'system_audit', 'security_policy'], true)) {
                return false;
            }

            // Company lifecycle denied
            if ($mod === 'company' || $mod === 'companies') {
                return false;
            }

            if ($mod === 'dashboard' && $act === 'view') return true;
            if ($mod === 'directory' && in_array($act, ['view', 'create', 'edit', 'delete', 'export', 'manage'], true)) return true;
            if ($mod === 'attendance' && in_array($act, ['view', 'clock', 'regularize', 'approve', 'create', 'edit', 'export', 'manage', 'early_closures'], true)) return true;
            if ($mod === 'rostering' && in_array($act, ['view', 'create', 'edit', 'delete', 'assign', 'export', 'manage'], true)) return true;
            if ($mod === 'assets' && in_array($act, ['view', 'create', 'edit', 'delete', 'assign', 'export', 'manage'], true)) return true;
            if ($mod === 'training' && in_array($act, ['view', 'create', 'edit', 'delete', 'assign', 'export', 'manage'], true)) return true;
            if ($mod === 'performance' && in_array($act, ['view', 'create', 'edit', 'approve', 'delete', 'export', 'manage'], true)) return true;
            if ($mod === 'recruitment' && in_array($act, ['view', 'create', 'edit', 'delete', 'approve', 'export', 'manage'], true)) return true;
            if ($mod === 'reports' && in_array($act, ['view', 'export', 'create', 'delete', 'manage'], true)) return true;
            if ($mod === 'rules' && in_array($act, ['view', 'manage'], true)) return true;
            if ($mod === 'notices' && in_array($act, ['view', 'create', 'edit', 'delete', 'manage'], true)) return true;
            if ($mod === 'notifications' && in_array($act, ['view', 'manage'], true)) return true;
            if ($mod === 'medical_insurance' && in_array($act, ['view', 'create', 'edit', 'approve', 'delete', 'export', 'manage'], true)) return true;
            if ($mod === 'company_expense' && in_array($act, ['view', 'create', 'edit', 'approve', 'delete', 'export', 'manage'], true)) return true;
            if ($mod === 'master' && in_array($act, ['view', 'create', 'edit'], true)) return true;

            return false;
        }

        if ($canonicalRole === 'hr_officer') {
            if (in_array($mod, ['payroll', 'bonus', 'loans', 'user', 'role', 'settings', 'security', 'system', 'rules'], true)) {
                return false;
            }
            if ($mod === 'dashboard' && $act === 'view') return true;
            if ($mod === 'directory' && in_array($act, ['view', 'create', 'edit', 'export'], true)) return true;
            if ($mod === 'attendance' && in_array($act, ['view', 'clock', 'regularize', 'create', 'edit', 'export'], true)) return true;
            if ($mod === 'rostering' && in_array($act, ['view', 'create', 'edit', 'assign', 'export'], true)) return true;
            if (in_array($mod, ['assets', 'training'], true) && in_array($act, ['view', 'create', 'edit', 'assign', 'export'], true)) return true;
            if (in_array($mod, ['medical_insurance', 'company_expense'], true) && in_array($act, ['view', 'create', 'edit', 'export'], true)) return true;
            if ($mod === 'reports' && in_array($act, ['view', 'export'], true)) return true;
            if ($mod === 'notices' && in_array($act, ['view', 'create', 'edit'], true)) return true;
            if ($mod === 'notifications' && $act === 'view') return true;
            return false;
        }

        if ($canonicalRole === 'finance') {
            if (in_array($mod, ['user', 'role', 'settings', 'security', 'system', 'recruitment'], true)) {
                return false;
            }
            if ($mod === 'dashboard' && $act === 'view') return true;
            if ($mod === 'payroll' && in_array($act, ['view', 'run', 'generate', 'edit', 'approve', 'delete', 'export', 'manage', 'disburse', 'adjust', 'loans'], true)) return true;
            if ($mod === 'bonus' && in_array($act, ['view', 'create', 'approve', 'delete', 'export', 'manage'], true)) return true;
            if ($mod === 'loans' && in_array($act, ['view', 'create', 'approve', 'edit', 'delete', 'export', 'manage'], true)) return true;
            if ($mod === 'pf' && in_array($act, ['view', 'export', 'manage'], true)) return true;
            if ($mod === 'rules' && in_array($act, ['view', 'manage'], true)) return true;
            if ($mod === 'company_expense' && in_array($act, ['view', 'approve', 'export', 'manage'], true)) return true;
            if ($mod === 'medical_insurance' && in_array($act, ['view', 'approve', 'export'], true)) return true;
            if (in_array($mod, ['attendance', 'assets', 'reports'], true) && in_array($act, ['view', 'export'], true)) return true;
            if (in_array($mod, ['notices', 'notifications'], true) && $act === 'view') return true;
            return false;
        }

        if ($canonicalRole === 'branch_manager') {
            if (in_array($mod, ['payroll', 'bonus', 'loans', 'user', 'role', 'settings', 'security', 'system', 'rules'], true)) {
                return false;
            }
            if ($mod === 'dashboard' && $act === 'view') return true;
            if ($mod === 'directory' && in_array($act, ['view', 'edit', 'export'], true)) return true;
            if ($mod === 'attendance' && in_array($act, ['view', 'clock', 'regularize', 'approve', 'export'], true)) return true;
            if ($mod === 'rostering' && in_array($act, ['view', 'create', 'edit', 'assign', 'export'], true)) return true;
            if (in_array($mod, ['assets', 'training'], true) && in_array($act, ['view', 'assign', 'export'], true)) return true;
            if ($mod === 'performance' && in_array($act, ['view', 'create', 'edit', 'approve', 'export'], true)) return true;
            if (in_array($mod, ['medical_insurance', 'company_expense'], true) && in_array($act, ['view', 'create', 'approve', 'export'], true)) return true;
            if ($mod === 'reports' && in_array($act, ['view', 'export'], true)) return true;
            if ($mod === 'notices' && in_array($act, ['view', 'create'], true)) return true;
            if ($mod === 'notifications' && $act === 'view') return true;
            return false;
        }

        if ($canonicalRole === 'manager') {
            if (in_array($mod, ['payroll', 'bonus', 'loans', 'user', 'role', 'settings', 'security', 'system', 'rules'], true)) {
                return false;
            }
            if ($mod === 'dashboard' && $act === 'view') return true;
            if ($mod === 'directory' && $act === 'view') return true;
            if ($mod === 'attendance' && in_array($act, ['view', 'clock', 'regularize', 'approve', 'export'], true)) return true;
            if ($mod === 'rostering' && in_array($act, ['view', 'create', 'edit', 'assign'], true)) return true;
            if ($mod === 'performance' && in_array($act, ['view', 'create', 'edit', 'export'], true)) return true;
            if ($mod === 'recruitment' && in_array($act, ['view', 'create', 'edit'], true)) return true;
            if ($mod === 'training' && in_array($act, ['view', 'assign'], true)) return true;
            if ($mod === 'company_expense' && in_array($act, ['view', 'create', 'approve'], true)) return true;
            if ($mod === 'reports' && in_array($act, ['view', 'export'], true)) return true;
            if (in_array($mod, ['notices', 'notifications'], true) && $act === 'view') return true;
            return false;
        }

        if ($canonicalRole === 'team_leader') {
            if (in_array($mod, ['payroll', 'bonus', 'loans', 'user', 'role', 'settings', 'security', 'system', 'rules', 'recruitment'], true)) {
                return false;
            }
            if ($mod === 'dashboard' && $act === 'view') return true;
            if ($mod === 'directory' && $act === 'view') return true;
            if ($mod === 'attendance' && in_array($act, ['view', 'clock', 'regularize'], true)) return true;
            if ($mod === 'rostering' && in_array($act, ['view', 'edit'], true)) return true;
            if ($mod === 'performance' && in_array($act, ['view', 'create', 'edit'], true)) return true;
            if ($mod === 'training' && $act === 'view') return true;
            if ($mod === 'company_expense' && in_array($act, ['view', 'create'], true)) return true;
            if (in_array($mod, ['notices', 'notifications'], true) && $act === 'view') return true;
            return false;
        }

        if ($canonicalRole === 'auditor') {
            if (self::isAuditorMutationAction($act)) {
                return false;
            }
            return in_array($act, ['view', 'export', 'history', 'read'], true);
        }

        if ($canonicalRole === 'employee') {
            $config = new \Config\Permissions();
            $allowedCodes = $config->roleDefaultMatrix['employee']['permissions'] ?? [];
            return in_array($mod . '.' . $act, $allowedCodes, true)
                || in_array($code ?? ($mod . '.' . $act), $allowedCodes, true)
                || $this->isImplicitSelfService($mod, $act);
        }

        return false;
    }

    /**
     * Validate whether a target record complies with the required operational scope
     *
     * @param array|null $user
     * @param string|\App\Services\PermissionDecision|array|object $requiredScope
     * @param array $targetRecord
     * @param string|null $scopeId Optional explicit scope ID (e.g. from user override or role permission)
     * @return bool
     */
    public function assertInScope(?array $user, $requiredScope, array $targetRecord, ?string $scopeId = null): bool
    {
        if ($requiredScope instanceof \App\Services\PermissionDecision) {
            if ($scopeId === null && method_exists($requiredScope, 'scopeId')) {
                $scopeId = $requiredScope->scopeId();
            }
            $requiredScope = $requiredScope->scope();
        } elseif (is_array($requiredScope)) {
            if ($scopeId === null && !empty($requiredScope['scope_id'])) {
                $scopeId = (string)$requiredScope['scope_id'];
            }
            $requiredScope = $requiredScope['scope'] ?? ($requiredScope['scope_level'] ?? 'company');
        } elseif (is_object($requiredScope)) {
            if ($scopeId === null && isset($requiredScope->scope_id)) {
                $scopeId = (string)$requiredScope->scope_id;
            } elseif ($scopeId === null && isset($requiredScope->scopeId)) {
                $scopeId = (string)$requiredScope->scopeId;
            }
            if (isset($requiredScope->scope)) {
                $requiredScope = (string)$requiredScope->scope;
            }
        }

        if (empty($user)) {
            return false;
        }

        $isSystemRole = (int)($user['role_is_system'] ?? 0) === 1;
        $isGlobalRole = empty($user['role_company_id']);
        $isGlobalUser = empty($user['company_id']);
        $canonicalRole = $this->canonicalizeRole($user['role_code'] ?? $user['role_name'] ?? '');
        if ($isSystemRole && $isGlobalRole && $isGlobalUser && $canonicalRole === 'software_app_admin') {
            return true;
        }

        if ($requiredScope === 'all') {
            return false;
        }

        // Hard Exception (c): Tenant isolation (company_id) can never be overridden by any permission
        $userCompanyId = $user['company_id'] ?? null;
        if (empty($userCompanyId)) {
            return false;
        }

        $scope = strtolower($requiredScope ?: 'company');

        // For 'company' scope, strictly require the target record's company_id
        $targetCompanyId = $targetRecord['company_id'] ?? null;
        if ($scope === 'company') {
            if (empty($targetCompanyId) || (string)$userCompanyId !== (string)$targetCompanyId) {
                return false;
            }
            if (!empty($scopeId) && (string)$targetCompanyId !== (string)$scopeId) {
                return false;
            }
            return true;
        }

        if (empty($targetCompanyId) && !empty($targetRecord['employee_id']) && $this->db) {
            try {
                if ($this->db->tableExists('employees')) {
                    $empRow = $this->db->table('employees')
                        ->select('company_id, branch_id, department_id')
                        ->where('id', $targetRecord['employee_id'])
                        ->get()->getRowArray();
                    if ($empRow) {
                        $targetCompanyId = $empRow['company_id'] ?? null;
                        if (empty($targetRecord['branch_id']) && !empty($empRow['branch_id'])) {
                            $targetRecord['branch_id'] = $empRow['branch_id'];
                        }
                        if (empty($targetRecord['department_id']) && !empty($empRow['department_id'])) {
                            $targetRecord['department_id'] = $empRow['department_id'];
                        }
                    }
                }
            } catch (\Throwable $e) {}
        }

        // RC-6: Strict tenant isolation. Target record MUST have a company_id matching user's company_id.
        // A missing or non-matching target company_id immediately denies access (no open fallback).
        if (empty($targetCompanyId) || (string)$userCompanyId !== (string)$targetCompanyId) {
            return false;
        }

        if ($scope === 'branch') {
            // RC-6: Use explicit scope_id if defined; otherwise compare user's home branch
            $allowedBranchId = !empty($scopeId) ? $scopeId : ($user['branch_id'] ?? null);
            $targetBranchId = $targetRecord['branch_id'] ?? null;
            if (empty($allowedBranchId) || empty($targetBranchId)) {
                return false;
            }
            return (string)$allowedBranchId === (string)$targetBranchId;
        }

        if ($scope === 'department') {
            // RC-6: Use explicit scope_id if defined; otherwise compare user's home department
            $allowedDeptId = !empty($scopeId) ? $scopeId : ($user['department_id'] ?? null);
            $targetDeptId = $targetRecord['department_id'] ?? null;
            if (empty($allowedDeptId) || empty($targetDeptId)) {
                return false;
            }
            return (string)$allowedDeptId === (string)$targetDeptId;
        }

        if ($scope === 'team') {
            $managerEmpId = !empty($scopeId) ? $scopeId : ($user['employee_id'] ?? null);
            if (empty($managerEmpId) && !empty($user['id']) && $this->db) {
                try {
                    $uRow = $this->db->table('users')->select('employee_id')->where('id', $user['id'])->get()->getRowArray();
                    $managerEmpId = $uRow['employee_id'] ?? null;
                } catch (\Throwable $e) {}
            }
            $targetEmpId = $targetRecord['employee_id'] ?? ($targetRecord['id'] ?? null);
            if ($managerEmpId && $targetEmpId) {
                if ((string)$managerEmpId === (string)$targetEmpId) {
                    return true;
                }
                // Check direct manager relationship
                if (!empty($targetRecord['manager_id']) && (string)$targetRecord['manager_id'] === (string)$managerEmpId) {
                    return true;
                }
                if (!empty($targetRecord['reporting_manager_id']) && (string)$targetRecord['reporting_manager_id'] === (string)$managerEmpId) {
                    return true;
                }
                if ($this->db) {
                    $teamIds = $this->getDescendantEmployeeIds((string)$managerEmpId, $userCompanyId);
                    if (in_array((string)$targetEmpId, $teamIds, true)) {
                        return true;
                    }
                }
            }
            return false;
        }

        if ($scope === 'self' || $scope === 'own' || $scope === 'employee') {
            $allowedEmpId = !empty($scopeId) ? $scopeId : ($user['employee_id'] ?? null);
            if (empty($allowedEmpId) && !empty($user['id']) && $this->db) {
                try {
                    $userRow = $this->db->table('users')->select('employee_id, company_id')->where('id', $user['id'])->get()->getRowArray();
                    $allowedEmpId = $userRow['employee_id'] ?? null;
                    if (empty($allowedEmpId) && $this->db->fieldExists('user_id', 'employees')) {
                        $empBuilder = $this->db->table('employees')->select('id')->where('user_id', $user['id']);
                        if (!empty($userCompanyId)) {
                            $empBuilder->where('company_id', $userCompanyId);
                        }
                        $matches = $empBuilder->get()->getResultArray();
                        if (count($matches) === 1) {
                            $allowedEmpId = $matches[0]['id'] ?? null;
                        }
                    }
                } catch (\Throwable $e) {
                    // DB lookup non-fatal in isolated unit tests
                }
            }
            $targetEmpId = $targetRecord['employee_id'] ?? ($targetRecord['id'] ?? null);
            return !empty($allowedEmpId) && !empty($targetEmpId) && ((string)$allowedEmpId === (string)$targetEmpId);
        }

        if ($scope === 'designation') {
            $allowedDesigId = !empty($scopeId) ? $scopeId : ($user['designation_id'] ?? null);
            $targetDesigId = $targetRecord['designation_id'] ?? null;
            return !empty($allowedDesigId) && !empty($targetDesigId) && ((string)$allowedDesigId === (string)$targetDesigId);
        }

        if ($scope === 'shift') {
            $allowedShiftId = !empty($scopeId) ? $scopeId : ($user['shift_id'] ?? null);
            $targetShiftId = $targetRecord['shift_id'] ?? null;
            return !empty($allowedShiftId) && !empty($targetShiftId) && ((string)$allowedShiftId === (string)$targetShiftId);
        }

        return false;
    }

    /**
     * Hard Exception (b): Standard users cannot approve or endorse their own request even if they hold the permission.
     * Privileged administrators (software_app_admin, company_admin, hr_admin) can process their own requests when holding the appropriate RBAC permission.
     *
     * @param string|null $actorEmployeeId
     * @param string|null $targetEmployeeId
     * @param array|null $actorUser
     * @param string|null $permission
     * @return bool
     */
    public function assertNotSelfApproval(?string $actorEmployeeId, ?string $targetEmployeeId, ?array $actorUser = null, ?string $permission = null): bool
    {
        if (!empty($actorEmployeeId) && !empty($targetEmployeeId)) {
            if ((string)$actorEmployeeId === (string)$targetEmployeeId) {
                if ($actorUser !== null) {
                    $rawRole = $actorUser['role_code'] ?? $actorUser['role_name'] ?? $actorUser['role'] ?? '';
                    $canonicalRole = $this->canonicalizeRole($rawRole);
                    if ($canonicalRole === 'software_app_admin' || $canonicalRole === 'company_admin' || $canonicalRole === 'hr_admin' || $this->isHRAdmin($rawRole)) {
                        if ($permission !== null && !empty($actorUser['id'])) {
                            return $this->can($actorUser['id'], $permission, ['company_id' => $actorUser['company_id'] ?? null])->isAllowed();
                        }
                        return true;
                    }
                }
                return false;
            }
            return true;
        }
        return true;
    }

    /**
     * Get all descendant employee IDs for a given manager ID (reporting chain).
     *
     * @param string $managerId
     * @param string|null $companyId
     * @return array<string>
     */
    public function getDescendantEmployeeIds(string $managerId, ?string $companyId = null): array
    {
        if (empty($managerId) || !$this->db) {
            return [];
        }

        try {
            if (!$this->db->tableExists('employees')) {
                return [];
            }
        } catch (\Throwable $e) {
            return [];
        }

        $descendantIds = [];
        $currentLevel = [$managerId];
        $visited = [$managerId => true];

        try {
            while (!empty($currentLevel)) {
                $builder = $this->db->table('employees')
                    ->select('id')
                    ->groupStart()
                        ->whereIn('reporting_manager_id', $currentLevel)
                        ->orWhereIn('manager_id', $currentLevel)
                    ->groupEnd();

                if (!empty($companyId)) {
                    $builder->where('company_id', $companyId);
                }

                $rows = $builder->get()->getResultArray();
                $nextLevel = [];
                foreach ($rows as $r) {
                    $id = (string)$r['id'];
                    if (!isset($visited[$id])) {
                        $visited[$id] = true;
                        $descendantIds[] = $id;
                        $nextLevel[] = $id;
                    }
                }
                $currentLevel = $nextLevel;
            }
        } catch (\Throwable $e) {
            return $descendantIds;
        }

        return $descendantIds;
    }

    /**
     * Shared Query Scoping: Apply data scope filter to a query builder
     *
     * @param mixed $builder Query Builder instance
     * @param string $alias Table alias or table name (e.g. 'leaves', 'attendances', 'employees')
     * @param string|\App\Services\PermissionDecision|array|object $decision Decision object or scope level ('all', 'company', 'branch', 'department', 'team', 'self')
     * @param array|null $user Current user context
     * @param string|null $scopeId Optional explicit scope ID
     * @return mixed
     */
    public function applyDataScope($builder, string $alias, $decision, ?array $user = null, ?string $scopeId = null)
    {
        if ($decision instanceof \App\Services\PermissionDecision) {
            if ($scopeId === null && method_exists($decision, 'scopeId')) {
                $scopeId = $decision->scopeId();
            }
            $scope = strtolower($decision->scope());
        } elseif (is_string($decision)) {
            $scope = strtolower($decision);
        } elseif (is_object($decision) && isset($decision->scope)) {
            if ($scopeId === null && isset($decision->scope_id)) {
                $scopeId = (string)$decision->scope_id;
            } elseif ($scopeId === null && isset($decision->scopeId)) {
                $scopeId = (string)$decision->scopeId;
            }
            $scope = strtolower((string)$decision->scope);
        } elseif (is_array($decision)) {
            if ($scopeId === null && !empty($decision['scope_id'])) {
                $scopeId = (string)$decision['scope_id'];
            }
            $scope = strtolower($decision['scope'] ?? ($decision['scope_level'] ?? 'company'));
        } else {
            $scope = 'company';
        }

        if ($user === null) {
            $session = \Config\Services::session();
            if ($session && $session->has('user_id')) {
                $userModel = new \App\Models\UserModel();
                $user = $userModel->getUserWithEmployeeContext((string)$session->get('user_id'));
            } else {
                $user = $session ? $session->get('user') : null;
            }
        }

        $isSystemRole = (int)($user['role_is_system'] ?? 0) === 1;
        $isGlobalRole = !empty($user) && empty($user['role_company_id']);
        $isGlobalUser = !empty($user) && empty($user['company_id']);
        $canonicalRole = !empty($user) ? $this->canonicalizeRole($user['role_code'] ?? $user['role_name'] ?? '') : '';
        $isPlatformAdmin = $isSystemRole && $isGlobalRole && $isGlobalUser && ($canonicalRole === 'software_app_admin');
        if ($isPlatformAdmin) {
            return $builder;
        }

        $cleanAlias = trim(str_replace('`', '', $alias));
        $isEmployeeTable = in_array(strtolower($cleanAlias), ['employees', 'e', 'emp'], true);
        $colPrefix = $cleanAlias !== '' ? "{$alias}." : '';

        // Fail closed (return no rows) when the user has no company_id and is not a platform admin
        $companyId = $user['company_id'] ?? null;
        if (empty($companyId)) {
            $builder->where('1 = 0', null, false);
            return $builder;
        }
        $builder->where("{$colPrefix}company_id", $companyId);

        if ($scope === 'none') {
            $builder->where('1 = 0', null, false);
            return $builder;
        }

        if ($scope === 'all') {
            // Cross-tenant 'all' scope is strictly reserved for software_app_admin.
            // For tenant users, 'all' collapses to tenant company scope.
            return $builder;
        }

        if ($scope === 'company') {
            return $builder;
        }

        if ($scope === 'branch') {
            // RC-6: Use explicit scope_id if defined; otherwise compare user's home branch
            $branchId = !empty($scopeId) ? $scopeId : ($user['branch_id'] ?? null);
            if (!empty($branchId)) {
                $builder->where("{$alias}.branch_id", $branchId);
            } else {
                $builder->where('1 = 0', null, false);
            }
            return $builder;
        }

        if ($scope === 'department') {
            // RC-6: Use explicit scope_id if defined; otherwise compare user's home department
            $deptId = !empty($scopeId) ? $scopeId : ($user['department_id'] ?? null);
            if (!empty($deptId)) {
                $builder->where("{$alias}.department_id", $deptId);
            } else {
                $builder->where('1 = 0', null, false);
            }
            return $builder;
        }

        if ($scope === 'team') {
            $empId = !empty($scopeId) ? $scopeId : ($user['employee_id'] ?? null);
            if (empty($empId) && !empty($user['id'])) {
                $userRow = $this->db->table('users')->select('employee_id')->where('id', $user['id'])->get()->getRowArray();
                $empId = $userRow['employee_id'] ?? null;
                if (empty($empId) && $this->db->fieldExists('user_id', 'employees')) {
                    $empRow = $this->db->table('employees')->select('id')->where('user_id', $user['id'])->get()->getRowArray();
                    $empId = $empRow['id'] ?? null;
                }
            }
            if (!empty($empId)) {
                $teamIds = $this->getDescendantEmployeeIds((string)$empId, $user['company_id'] ?? null);
                $allowedIds = array_merge([(string)$empId], $teamIds);
                $col = $isEmployeeTable ? (!empty($alias) ? "{$alias}.id" : "id") : (!empty($alias) ? "{$alias}.employee_id" : "employee_id");
                $builder->whereIn($col, $allowedIds);
            } else {
                $builder->where('1 = 0', null, false);
            }
            return $builder;
        }

        if ($scope === 'self' || $scope === 'own' || $scope === 'employee') {
            $empId = !empty($scopeId) ? $scopeId : ($user['employee_id'] ?? null);
            if (empty($empId) && !empty($user['id'])) {
                $userRow = $this->db->table('users')->select('employee_id')->where('id', $user['id'])->get()->getRowArray();
                $empId = $userRow['employee_id'] ?? null;
                if (empty($empId) && $this->db->fieldExists('user_id', 'employees')) {
                    $empRow = $this->db->table('employees')->select('id')->where('user_id', $user['id'])->get()->getRowArray();
                    $empId = $empRow['id'] ?? null;
                }
            }
            if (!empty($empId)) {
                $col = $isEmployeeTable ? (!empty($alias) ? "{$alias}.id" : "id") : (!empty($alias) ? "{$alias}.employee_id" : "employee_id");
                $builder->where($col, $empId);
            } else {
                $builder->where('1 = 0', null, false);
            }
            return $builder;
        }

        return $builder;
    }

    /**
     * Compute effective permissions dictionary [code => scope_level] for a user:
     * Effective permission = (role default permissions + user-granted permissions) - user-denied permissions
     */
    public function getUserPermissions(string $userId): array
    {
        $user = $this->db->table('users')
            ->select('users.*, roles.code as role_code, roles.name as role_name, roles.is_system as role_is_system, roles.company_id as role_company_id')
            ->join('roles', 'roles.id = users.role_id', 'left')
            ->where('users.id', $userId)
            ->orWhere('users.username', $userId)
            ->get()
            ->getRowArray();

        if (!$user) {
            return [];
        }

        $canonicalRole = $this->canonicalizeRole($user['role_code'] ?? $user['role_name'] ?? '');
        $config = new \Config\Permissions();
        $allCatalogueCodes = array_keys($config->catalogue);
        $platformList = $config->platformOnlyPermissions ?? ['system.view', 'system.manage', 'system.delete', 'company.create', 'platform.admin'];

        $isSystemRole = (int)($user['role_is_system'] ?? 0) === 1;
        $isGlobalRole = empty($user['role_company_id']);
        $isGlobalUser = empty($user['company_id']);
        $isPlatformAdmin = $isSystemRole && $isGlobalRole && $isGlobalUser && ($canonicalRole === 'software_app_admin');

        // Root Rule 1: Software App Admin has all catalogue permissions with scope 'all'
        if ($isPlatformAdmin) {
            return array_fill_keys($allCatalogueCodes, 'all');
        }

        // Root Rule 2: Company Admin has all non-platform permissions with scope 'company'
        if ($canonicalRole === 'company_admin') {
            $caPerms = array_filter($allCatalogueCodes, function($c) use ($platformList) {
                return !in_array($c, $platformList, true) && !str_starts_with($c, 'system.');
            });
            return array_fill_keys(array_values($caPerms), 'company');
        }

        // Compute effective permissions = (role default permissions + user-granted permissions) - user-denied permissions
        $effectivePerms = [];

        // 1. User Overrides
        $overrides = $this->getUserPermissionOverrides($user['id']);
        $deniedCodes = [];
        $nowTs = time();

        foreach ($overrides as $ov) {
            if (!empty($ov['expires_at']) && strtotime($ov['expires_at']) < $nowTs) {
                continue;
            }
            if ((int)$ov['is_granted'] === 0) {
                $deniedCodes[$ov['code']] = true;
            }
        }

        // 2. Base Role Permissions
        $rolePerms = !empty($user['role_id']) ? $this->getRolePermissions($user['role_id']) : [];
        foreach ($rolePerms as $rp) {
            $code = $rp['code'];
            if (isset($deniedCodes[$code])) {
                continue; // Denied by user override
            }
            if ($canonicalRole === 'auditor') {
                $parts = explode('.', $code, 2);
                $act = $parts[1] ?? '';
                if (self::isAuditorMutationAction($act)) {
                    continue;
                }
            }
            $effectivePerms[$code] = $rp['scope_level'] ?? 'company';
        }

        // 3. User-granted Overrides
        foreach ($overrides as $ov) {
            if (!empty($ov['expires_at']) && strtotime($ov['expires_at']) < $nowTs) {
                continue;
            }
            if ((int)$ov['is_granted'] === 1) {
                $effectivePerms[$ov['code']] = $ov['scope_level'] ?? 'company';
            }
        }

        return $effectivePerms;
    }

    /**
     * Retrieve all active explicit user overrides with metadata
     */
    public function getUserPermissionOverrides(string $userId): array
    {
        $permActionCol = $this->ensureActionColumn() ? 'permissions.action' : "SUBSTRING_INDEX(permissions.code, '.', -1) AS action";
        $hasScopeLevel = $this->db->fieldExists('scope_level', 'user_permissions');
        $hasScopeId    = $this->db->fieldExists('scope_id', 'user_permissions');
        $hasExpiresAt  = $this->db->fieldExists('expires_at', 'user_permissions');
        $hasReason     = $this->db->fieldExists('reason', 'user_permissions');
        $hasGrantedBy  = $this->db->fieldExists('granted_by', 'user_permissions');

        $extraCols = '';
        if ($hasScopeLevel) $extraCols .= ', user_permissions.scope_level';
        if ($hasScopeId)    $extraCols .= ', user_permissions.scope_id';
        if ($hasExpiresAt)  $extraCols .= ', user_permissions.expires_at';
        if ($hasReason)     $extraCols .= ', user_permissions.reason';
        if ($hasGrantedBy)  $extraCols .= ', user_permissions.granted_by';

        return $this->db->table('user_permissions')
            ->select("user_permissions.id, user_permissions.user_id, user_permissions.permission_id, user_permissions.is_granted, permissions.code, permissions.module, {$permActionCol}, permissions.name, permissions.description{$extraCols}")
            ->join('permissions', 'permissions.id = user_permissions.permission_id')
            ->where('user_permissions.user_id', $userId)
            ->get()
            ->getResultArray();
    }

    /**
     * Save an explicit user permission override (Grant = 1, Deny = 0) with scope and expiry support
     */
    public function saveUserPermissionOverride(
        string $userId,
        string $permissionId,
        int $isGranted,
        ?string $actorId = null,
        string $scopeLevel = 'company',
        ?string $scopeId = null,
        ?string $expiresAt = null,
        ?string $reason = null
    ): bool {
        // Resolve permission ID if passed as code (e.g. 'leaves.approve')
        if (str_contains($permissionId, '.')) {
            $permRow = $this->db->table('permissions')->where('code', $permissionId)->get()->getRowArray();
            if ($permRow) {
                $permissionId = $permRow['id'];
            }
        }

        $existing = $this->db->table('user_permissions')
            ->where('user_id', $userId)
            ->where('permission_id', $permissionId)
            ->get()
            ->getRowArray();

        $now = date('Y-m-d H:i:s');
        $cols = $this->db->getFieldNames('user_permissions');

        $data = [
            'is_granted' => $isGranted ? 1 : 0,
            'updated_at' => $now,
        ];
        if (in_array('scope_level', $cols, true)) {
            $data['scope_level'] = $scopeLevel ?: 'company';
        }
        if (in_array('scope_id', $cols, true)) {
            $data['scope_id'] = $scopeId;
        }
        if (in_array('expires_at', $cols, true)) {
            $data['expires_at'] = $expiresAt;
        }
        if (in_array('reason', $cols, true)) {
            $data['reason'] = $reason;
        }
        if (in_array('granted_by', $cols, true)) {
            $data['granted_by'] = $actorId;
        }

        if ($existing) {
            $this->db->table('user_permissions')
                ->where('id', $existing['id'])
                ->update($data);
        } else {
            $data['id'] = \Ramsey\Uuid\Uuid::uuid4()->toString();
            $data['user_id'] = $userId;
            $data['permission_id'] = $permissionId;
            $data['created_at'] = $now;
            $this->db->table('user_permissions')->insert($data);
        }

        self::$hasAccessCache = [];
        return true;
    }

    /**
     * Remove an explicit user permission override (reverts to role default)
     */
    public function removeUserPermissionOverride(string $userId, string $permissionId): bool
    {
        // Resolve permission ID if passed as code
        if (str_contains($permissionId, '.')) {
            $permRow = $this->db->table('permissions')->where('code', $permissionId)->get()->getRowArray();
            if ($permRow) {
                $permissionId = $permRow['id'];
            }
        }

        $this->db->table('user_permissions')
            ->where('user_id', $userId)
            ->where('permission_id', $permissionId)
            ->delete();

        self::$hasAccessCache = [];
        return true;
    }

    /**
     * Reset all user permission overrides for a user
     */
    public function resetUserPermissionOverrides(string $userId): bool
    {
        $this->db->table('user_permissions')
            ->where('user_id', $userId)
            ->delete();

        self::$hasAccessCache = [];
        return true;
    }

    /**
     * Get all permission rows for a role
     */
    public function getRolePermissions(string $roleId): array
    {
        $permActionCol = $this->ensureActionColumn() ? 'permissions.action' : "SUBSTRING_INDEX(permissions.code, '.', -1) AS action";
        $hasScopeLevel = $this->db->fieldExists('scope_level', 'role_permissions');
        $hasScopeId    = $this->db->fieldExists('scope_id', 'role_permissions');
        $extraCol = '';
        if ($hasScopeLevel) {
            $extraCol .= ', role_permissions.scope_level';
        }
        if ($hasScopeId) {
            $extraCol .= ', role_permissions.scope_id';
        }

        return $this->db->table('role_permissions')
            ->select("permissions.id, permissions.code, permissions.module, {$permActionCol}, permissions.description{$extraCol}")
            ->join('permissions', 'permissions.id = role_permissions.permission_id')
            ->where('role_permissions.role_id', $roleId)
            ->get()
            ->getResultArray();
    }

    /**
     * Map any legacy or formatted role string to the canonical 9 system roles:
     * - software_app_admin (Software App Admin - Top System Admin)
     * - company_admin (Company Admin)
     * - hr_admin (HR Admin)
     * - hr_officer (HR Officer)
     * - finance (Finance)
     * - manager (Manager)
     * - team_leader (Team Leader)
     * - employee (Employee)
     * - auditor (Auditor)
     */
    public function canonicalizeRole(?string $role): string
    {
        if (!$role) return 'employee';
        $r = strtolower(trim($role));
        $r = str_replace(['-', ' '], '_', $r);

        // Block custom role names like 'admin' / 'administrator' from mapping to company_admin automatically
        if ($r === 'admin' || $r === 'administrator') {
            return $r;
        }

        switch ($r) {
            case 'software_app_admin':
            case 'software_app_administrator':
            case 'softwareadmin':
            case 'software_admin':
            case 'softwareadministrator':
            case 'software_administrator':
            case 'super_admin':
            case 'superadmin':
            case 'super_administrator':
            case 'r_sa':
            case 'role_sa':
            case 'role_super_admin':
                return 'software_app_admin';

            case 'company_admin':
            case 'companyadmin':
            case 'company_administrator':
            case 'r_ca':
            case 'role_ca':
            case 'role_company_admin':
                return 'company_admin';

            case 'hr_admin':
            case 'hradmin':
            case 'hr_administrator':
            case 'r_hra':
            case 'role_hra':
            case 'role_hr_admin':
                return 'hr_admin';

            case 'hr_officer':
            case 'hrofficer':
            case 'r_hro':
            case 'role_hro':
            case 'role_hr_officer':
                return 'hr_officer';

            case 'branch_manager':
            case 'branchmanager':
            case 'r_bm':
            case 'role_bm':
            case 'role_branch_manager':
                return 'branch_manager';

            case 'finance':
            case 'r_fin':
            case 'role_fin':
                return 'finance';

            case 'manager':
            case 'r_mgr':
            case 'role_mgr':
                return 'manager';

            case 'team_leader':
            case 'teamleader':
            case 'r_tl':
            case 'role_tl':
                return 'team_leader';

            case 'auditor':
            case 'r_aud':
            case 'role_aud':
                return 'auditor';

            case 'employee':
            case 'r_emp':
            case 'role_emp':
                return 'employee';

            default:
                // Custom or unmapped tenant roles return their own slug/code
                // They must resolve capabilities via their own DB role_permissions only
                return $r;
        }
    }

    /**
     * Normalize role name/code string (alias of canonicalizeRole).
     */
    public function normalizeRole(?string $role): string
    {
        return $this->canonicalizeRole($role);
    }

    /**
     * Complete 6-Tier System Navigation Hierarchy
     * ROLE -> MODULE -> NAVBAR -> TAB -> SUB-TAB -> ACTION
     */
    public function getNavigationHierarchy(): array
    {
        return [
            [
                'id' => 'employees',
                'name' => 'Staff & Workforce Directory',
                'code' => 'employees',
                'icon' => 'users',
                'navbars' => [
                    [
                        'id' => 'directory',
                        'name' => 'Staff Directory',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'manager', 'team_leader', 'auditor'],
                        'tabs' => [
                            ['id' => 'all-staff', 'name' => 'All Staff Profiles', 'subTabs' => [['id' => 'active-roster', 'name' => 'Active Roster'], ['id' => 'probation', 'name' => 'Probation Review']]],
                            ['id' => 'departments', 'name' => 'Department Grouping', 'subTabs' => [['id' => 'headcount', 'name' => 'Headcount Summary']]]
                        ]
                    ],
                    [
                        'id' => 'organogram',
                        'name' => 'Employee Organogram',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'manager', 'team_leader', 'auditor'],
                        'tabs' => [
                            ['id' => 'org-tree', 'name' => 'Hierarchical Tree Chart']
                        ]
                    ],
                    [
                        'id' => 'onboarding',
                        'name' => 'Talent Onboarding',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer'],
                        'tabs' => [
                            ['id' => 'new-hires', 'name' => 'New Joiners', 'subTabs' => [['id' => 'docs-verification', 'name' => 'Document Verification'], ['id' => 'bank-details', 'name' => 'Bank Setup']]],
                            ['id' => 'checklists', 'name' => 'Asset & ID Issuance']
                        ]
                    ],
                    [
                        'id' => 'lifecycle',
                        'name' => 'Employee Lifecycle',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'manager'],
                        'tabs' => [
                            ['id' => 'promotions', 'name' => 'Promotions & Transfers'],
                            ['id' => 'resignations', 'name' => 'Exit & Offboarding', 'subTabs' => [['id' => 'clearance', 'name' => 'Department Clearance']]]
                        ]
                    ]
                ]
            ],
            [
                'id' => 'attendance',
                'name' => 'Attendance, Shifts & Roster',
                'code' => 'attendance',
                'icon' => 'clock',
                'navbars' => [
                    [
                        'id' => 'daily-attendance',
                        'name' => 'Daily Attendance Engine',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'manager', 'team_leader', 'employee', 'auditor'],
                        'tabs' => [
                            ['id' => 'live-punches', 'name' => 'Real-time Punches', 'subTabs' => [['id' => 'biometric-feed', 'name' => 'Biometric Hardware Feed'], ['id' => 'geo-tracking', 'name' => 'Mobile Geo-Fence']]],
                            ['id' => 'regularization', 'name' => 'Punch Regularizations', 'subTabs' => [['id' => 'pending-approvals', 'name' => 'Manager Approvals']]]
                        ]
                    ],
                    [
                        'id' => 'early-closures',
                        'name' => 'Company Early Closures',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin'],
                        'tabs' => [
                            ['id' => 'closure-schedule', 'name' => 'Closure Schedule', 'subTabs' => [['id' => 'active-closures', 'name' => 'Active Closures'], ['id' => 'past-closures', 'name' => 'Past Closures']]],
                            ['id' => 'credit-allocation', 'name' => 'Full-Day Credit Allocation']
                        ]
                    ],
                    [
                        'id' => 'rules-engine',
                        'name' => 'Attendance & Bonus Rules',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'finance'],
                        'tabs' => [
                            ['id' => 'general-rules', 'name' => 'General & Workweek Policy', 'subTabs' => [['id' => 'work-hours', 'name' => 'Standard Work Hours'], ['id' => 'grace-period', 'name' => 'Lateness Grace Period']]],
                            ['id' => 'overtime-rules', 'name' => 'OT Multipliers & Caps', 'subTabs' => [['id' => 'daily-cap', 'name' => 'Daily Max Cap'], ['id' => 'anti-double-count', 'name' => 'Anti-Double-Counting']]]
                        ]
                    ],
                    [
                        'id' => 'roster',
                        'name' => 'Shift Rostering & Swaps',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'manager', 'team_leader'],
                        'tabs' => [
                            ['id' => 'shift-planner', 'name' => 'Monthly Roster Grid', 'subTabs' => [['id' => 'shift-assignment', 'name' => 'Bulk Shift Assign']]],
                            ['id' => 'shift-swaps', 'name' => 'Peer Shift Swap Requests']
                        ]
                    ],
                    [
                        'id' => 'overtime',
                        'name' => 'Overtime Tracking & Claims',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'manager', 'team_leader', 'employee', 'finance'],
                        'tabs' => [
                            ['id' => 'ot-requests', 'name' => 'Overtime Work Requests', 'subTabs' => [['id' => 'daily-ot', 'name' => 'Daily OT Breakdown'], ['id' => 'weekly-ot', 'name' => 'Weekly Cap Audit']]],
                            ['id' => 'ot-calculator', 'name' => 'OT Rate Matrix & Policy']
                        ]
                    ],
                    [
                        'id' => 'biometric-sync',
                        'name' => 'Biometric Devices',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin'],
                        'tabs' => [
                            ['id' => 'device-fleet', 'name' => 'Device Fleet Monitor', 'subTabs' => [['id' => 'sync-logs', 'name' => 'Hardware Sync Logs']]]
                        ]
                    ]
                ]
            ],
            [
                'id' => 'leaves',
                'name' => 'Leave Management & Holidays',
                'code' => 'leaves',
                'icon' => 'calendar',
                'navbars' => [
                    [
                        'id' => 'leave-applications',
                        'name' => 'Leave Applications',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'manager', 'team_leader', 'employee', 'auditor'],
                        'tabs' => [
                            ['id' => 'my-leaves', 'name' => 'My Applications', 'subTabs' => [['id' => 'leave-history', 'name' => 'Historical Leaves']]],
                            ['id' => 'team-approvals', 'name' => 'Team Approvals', 'subTabs' => [['id' => 'manager-queue', 'name' => 'Approval Queue']]]
                        ]
                    ],
                    [
                        'id' => 'leave-balances',
                        'name' => 'Leave Ledger & Quotas',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'manager', 'finance', 'auditor'],
                        'tabs' => [
                            ['id' => 'quota-allocation', 'name' => 'Annual Quota Allocation'],
                            ['id' => 'encashment', 'name' => 'Leave Encashment Claims']
                        ]
                    ],
                    [
                        'id' => 'holiday-calendar',
                        'name' => 'Public Holidays & Observances',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'manager', 'team_leader', 'employee', 'finance', 'auditor'],
                        'tabs' => [
                            ['id' => 'calendar-view', 'name' => 'Company Holiday Calendar']
                        ]
                    ]
                ]
            ],
            [
                'id' => 'overtime',
                'name' => 'Overtime Calculation & Claims',
                'code' => 'overtime',
                'icon' => 'clock-8',
                'navbars' => [
                    [
                        'id' => 'ot-requests',
                        'name' => 'Overtime Work Requests',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'manager', 'team_leader', 'employee', 'finance'],
                        'tabs' => [
                            ['id' => 'pre-approval', 'name' => 'Pre-approved OT Sheets', 'subTabs' => [['id' => 'daily-ot', 'name' => 'Daily OT Breakdown'], ['id' => 'weekly-ot', 'name' => 'Weekly Cap Audit']]],
                            ['id' => 'claims-review', 'name' => 'Manager & Finance Verification']
                        ]
                    ],
                    [
                        'id' => 'ot-calculator',
                        'name' => 'OT Rate Matrix & Policy',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'finance'],
                        'tabs' => [
                            ['id' => 'multiplier-rates', 'name' => 'Multiplier Rates (1.5x / 2.0x / 2.5x)'],
                            ['id' => 'conflict-policy', 'name' => 'Anti-Double-Counting Rules']
                        ]
                    ]
                ]
            ],
            [
                'id' => 'payroll',
                'name' => 'Payroll, Salary & Advances',
                'code' => 'payroll',
                'icon' => 'dollar-sign',
                'navbars' => [
                    [
                        'id' => 'payroll-run',
                        'name' => 'Monthly Payroll Processing',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'finance', 'auditor'],
                        'tabs' => [
                            ['id' => 'salary-batch', 'name' => 'Process Monthly Salary', 'subTabs' => [['id' => 'gross-deductions', 'name' => 'Gross & Statutory Deductions'], ['id' => 'tax-withholdings', 'name' => 'TDS / Withholding Tax']]],
                            ['id' => 'bank-advice', 'name' => 'Bank Transfer Advice & Export']
                        ]
                    ],
                    [
                        'id' => 'salary-structures',
                        'name' => 'Salary Grade & Structures',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'finance'],
                        'tabs' => [
                            ['id' => 'pay-grades', 'name' => 'Pay Scales & Components'],
                            ['id' => 'allowances', 'name' => 'Fixed & Variable Allowances']
                        ]
                    ],
                    [
                        'id' => 'bonus-runs',
                        'name' => 'Performance & Festive Bonuses',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'finance'],
                        'tabs' => [
                            ['id' => 'festive-bonus', 'name' => 'Festive Bonus Engine'],
                            ['id' => 'performance-bonus', 'name' => 'Performance Tier Payouts']
                        ]
                    ],
                    [
                        'id' => 'loans-advances',
                        'name' => 'Staff Loans & Salary Advances',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'finance', 'hr_admin', 'employee'],
                        'tabs' => [
                            ['id' => 'active-loans', 'name' => 'Loan Repayment Schedules', 'subTabs' => [['id' => 'emi-deductions', 'name' => 'Payroll EMI Deductions']]],
                            ['id' => 'new-request', 'name' => 'Advance Salary Applications']
                        ]
                    ],
                    [
                        'id' => 'pf-summary',
                        'name' => 'Provident Fund (PF) Summary & Ledgers',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'finance', 'auditor'],
                        'tabs' => [
                            ['id' => 'pf-summary-tab', 'name' => 'PF Summary Statements', 'subTabs' => [['id' => 'pf-balances', 'name' => 'Corpus & Balances'], ['id' => 'pf-reconciliation', 'name' => 'Statutory Reconciliation']]],
                            ['id' => 'pf-details-tab', 'name' => 'PF Monthly Ledgers'],
                            ['id' => 'pf-eligibility-tab', 'name' => 'PF Eligibility & Exceptions']
                        ]
                    ]
                ]
            ],
            [
                'id' => 'talent-operations',
                'name' => 'Talent, Growth & Operations',
                'code' => 'talent_operations',
                'icon' => 'graduation-cap',
                'navbars' => [
                    [
                        'id' => 'training-programs',
                        'name' => 'Training Courses & Workshops',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'manager', 'employee'],
                        'tabs' => [
                            ['id' => 'course-catalog', 'name' => 'Course Catalog & Calendar'],
                            ['id' => 'certifications', 'name' => 'Issued Certifications']
                        ]
                    ],
                    [
                        'id' => 'job-openings',
                        'name' => 'Job Requisitions & ATS',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'manager'],
                        'tabs' => [
                            ['id' => 'openings-list', 'name' => 'Active Job Openings'],
                            ['id' => 'candidate-pipeline', 'name' => 'Applicant Kanban Board']
                        ]
                    ],
                    [
                        'id' => 'appraisal-cycles',
                        'name' => 'Appraisals & KPI Management',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'manager', 'employee'],
                        'tabs' => [
                            ['id' => 'self-eval', 'name' => 'Self Assessment Review'],
                            ['id' => 'manager-eval', 'name' => 'Manager Appraisal Scorecard']
                        ]
                    ],
                    [
                        'id' => 'asset-inventory',
                        'name' => 'Equipment & Inventory',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'finance', 'auditor'],
                        'tabs' => [
                            ['id' => 'it-assets', 'name' => 'Laptops & Devices', 'subTabs' => [['id' => 'serial-tags', 'name' => 'Barcode / Serial Tags']]],
                            ['id' => 'non-it-assets', 'name' => 'Furniture & Vehicles']
                        ]
                    ],
                    [
                        'id' => 'asset-allocations',
                        'name' => 'Employee Custody',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'employee'],
                        'tabs' => [
                            ['id' => 'custody-log', 'name' => 'Handover / Return Receipts']
                        ]
                    ]
                ]
            ],
            [
                'id' => 'notices',
                'name' => 'Notices & Announcements',
                'code' => 'notices',
                'icon' => 'bell',
                'navbars' => [
                    [
                        'id' => 'bulletin-board',
                        'name' => 'Company Broadcasts',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'manager', 'team_leader', 'employee', 'finance', 'auditor'],
                        'tabs' => [
                            ['id' => 'published-notices', 'name' => 'Active Circulars'],
                            ['id' => 'emergency-alerts', 'name' => 'Emergency Broadcasts']
                        ]
                    ]
                ]
            ],
            [
                'id' => 'reports',
                'name' => 'Analytics & Executive Reports',
                'code' => 'reports',
                'icon' => 'bar-chart-3',
                'navbars' => [
                    [
                        'id' => 'attendance-reports',
                        'name' => 'Workforce & Attendance Analytics',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'finance', 'manager', 'auditor'],
                        'tabs' => [
                            ['id' => 'monthly-muster', 'name' => 'Monthly Muster Roll'],
                            ['id' => 'absenteeism', 'name' => 'Absenteeism & Late Trends']
                        ]
                    ],
                    [
                        'id' => 'salary-reports',
                        'name' => 'Payroll & Cost Register',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'finance', 'auditor'],
                        'tabs' => [
                            ['id' => 'salary-sheet', 'name' => 'Consolidated Salary Sheet'],
                            ['id' => 'tax-deductions', 'name' => 'Statutory Tax Statements']
                        ]
                    ],
                    [
                        'id' => 'reports-upload',
                        'name' => 'Report Upload Hub',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'finance', 'auditor'],
                        'tabs' => [
                            ['id' => 'upload-docs', 'name' => 'Document & Report Vault']
                        ]
                    ]
                ]
            ],
            [
                'id' => 'medical_insurance',
                'name' => 'Medical Insurance Management',
                'code' => 'medical_insurance',
                'icon' => 'shield-plus',
                'navbars' => [
                    [
                        'id' => 'insurance-dashboard',
                        'name' => 'Executive Overview',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'finance', 'auditor', 'employee'],
                        'tabs' => [
                            ['id' => 'insurance-metrics', 'name' => 'Coverage & Financial Metrics']
                        ]
                    ],
                    [
                        'id' => 'insurance-providers',
                        'name' => 'Insurance Providers',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer'],
                        'tabs' => [
                            ['id' => 'providers-list', 'name' => 'Underwriter Registry']
                        ]
                    ],
                    [
                        'id' => 'insurance-plans',
                        'name' => 'Insurance Plans',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'finance'],
                        'tabs' => [
                            ['id' => 'plans-list', 'name' => 'Benefit Packages']
                        ]
                    ],
                    [
                        'id' => 'insurance-enrollments',
                        'name' => 'Employee Enrollments',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'finance'],
                        'tabs' => [
                            ['id' => 'enrollments-list', 'name' => 'Covered Employees']
                        ]
                    ],
                    [
                        'id' => 'insurance-dependents',
                        'name' => 'Covered Dependents',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'employee'],
                        'tabs' => [
                            ['id' => 'dependents-list', 'name' => 'Beneficiaries']
                        ]
                    ],
                    [
                        'id' => 'insurance-claims',
                        'name' => 'Medical Claims',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'finance', 'auditor', 'employee'],
                        'tabs' => [
                            ['id' => 'claims-list', 'name' => 'Claims Register']
                        ]
                    ],
                    [
                        'id' => 'insurance-reports',
                        'name' => 'Insurance Reports',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'finance', 'auditor'],
                        'tabs' => [
                            ['id' => 'reports-analytics', 'name' => 'Statutory & Premium Statements']
                        ]
                    ]
                ]
            ],
            [
                'id' => 'company_expense',
                'name' => 'Daily Company Expenses',
                'code' => 'company_expense',
                'icon' => 'receipt',
                'navbars' => [
                    [
                        'id' => 'expenses-dashboard',
                        'name' => 'Expense Dashboard',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'finance', 'auditor', 'branch_manager', 'hr_officer', 'employee'],
                        'tabs' => [
                            ['id' => 'overview-metrics', 'name' => 'Financial Metrics & Charts']
                        ]
                    ],
                    [
                        'id' => 'expenses-list',
                        'name' => 'Company Expenses',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'finance', 'branch_manager', 'hr_officer', 'employee'],
                        'tabs' => [
                            ['id' => 'all-expenses', 'name' => 'Expense Register']
                        ]
                    ],
                    [
                        'id' => 'expenses-categories',
                        'name' => 'Expense Categories',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'finance'],
                        'tabs' => [
                            ['id' => 'categories-list', 'name' => 'Category Registry']
                        ]
                    ],
                    [
                        'id' => 'expenses-approvals',
                        'name' => 'Expense Approvals',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'finance'],
                        'tabs' => [
                            ['id' => 'pending-approvals', 'name' => 'Pending Verification']
                        ]
                    ],
                    [
                        'id' => 'expenses-payments',
                        'name' => 'Payment Disbursements',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'finance', 'auditor'],
                        'tabs' => [
                            ['id' => 'disbursements-list', 'name' => 'Payment Journal']
                        ]
                    ],
                    [
                        'id' => 'expenses-reports',
                        'name' => 'Expense Reports',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'finance', 'auditor', 'branch_manager'],
                        'tabs' => [
                            ['id' => 'daily-report', 'name' => 'Daily Log'],
                            ['id' => 'category-report', 'name' => 'Category Breakdown'],
                            ['id' => 'monthly-report', 'name' => 'Monthly Trends'],
                            ['id' => 'payment-report', 'name' => 'Payment Audit']
                        ]
                    ]
                ]
            ],
            [
                'id' => 'master',
                'name' => 'Master Data & Governance',
                'code' => 'master',
                'icon' => 'database',
                'navbars' => [
                    [
                        'id' => 'company-branding',
                        'name' => 'Company Logo & Branding',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin'],
                        'tabs' => [
                            ['id' => 'brand-assets', 'name' => 'Logos & Color Palette']
                        ]
                    ],
                    [
                        'id' => 'company-profile',
                        'name' => 'Company Profile',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'auditor'],
                        'tabs' => [
                            ['id' => 'profile-summary', 'name' => 'Corporate Profile']
                        ]
                    ],
                    [
                        'id' => 'company-branches',
                        'name' => 'Branches & Company Info',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'auditor'],
                        'tabs' => [
                            ['id' => 'entity-details', 'name' => 'Legal Entity Profile'],
                            ['id' => 'branch-locations', 'name' => 'Branch Network & Geofencing']
                        ]
                    ],
                    [
                        'id' => 'departments-designations',
                        'name' => 'Org Hierarchy & Titles',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'hr_admin', 'auditor'],
                        'tabs' => [
                            ['id' => 'dept-list', 'name' => 'Departments'],
                            ['id' => 'designation-list', 'name' => 'Job Designations']
                        ]
                    ]
                ]
            ],
            [
                'id' => 'settings',
                'name' => 'Security & Governance Administration',
                'code' => 'settings',
                'icon' => 'shield',
                'navbars' => [
                    [
                        'id' => 'users-management',
                        'name' => 'User Accounts',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'auditor'],
                        'tabs' => [
                            ['id' => 'user-list', 'name' => 'Registered Accounts', 'subTabs' => [['id' => 'active-users', 'name' => 'Active Accounts'], ['id' => 'suspended-users', 'name' => 'Suspended Accounts']]],
                            ['id' => 'credentials', 'name' => 'Account Provisioning', 'subTabs' => [['id' => 'employee-link', 'name' => 'Employee Binding'], ['id' => 'password-reset', 'name' => 'Credential Resets']]]
                        ]
                    ],
                    [
                        'id' => 'roles-permissions',
                        'name' => 'Security & RBAC Suite',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'auditor'],
                        'tabs' => [
                            ['id' => 'rbac-tree', 'name' => '6-Tier Permission Tree', 'subTabs' => [['id' => 'action-matrix', 'name' => 'Capability Flags'], ['id' => 'role-lifecycle', 'name' => 'Role Status Toggle']]],
                            ['id' => 'permission-matrix', 'name' => 'Permission Matrix Grid', 'subTabs' => [['id' => 'bulk-grant', 'name' => 'Batch Capabilities']]],
                            ['id' => 'visibility-matrix', 'name' => 'Navigation Visibility Grid'],
                            ['id' => 'simulator', 'name' => 'Live RBAC Sandbox Simulator', 'subTabs' => [['id' => 'trace-diag', 'name' => 'Diagnostic Execution Trace']]]
                        ]
                    ],
                    [
                        'id' => 'login-audit',
                        'name' => 'Login Audit Logs',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'auditor'],
                        'tabs' => [
                            ['id' => 'auth-events', 'name' => 'Authentication Telemetry', 'subTabs' => [['id' => 'successful-logins', 'name' => 'Successful Logins'], ['id' => 'failed-logins', 'name' => 'Failed Attempts']]],
                            ['id' => 'device-forensics', 'name' => 'Device & IP Telemetry', 'subTabs' => [['id' => 'lockout-logs', 'name' => 'Account Lockout Events']]]
                        ]
                    ],
                    [
                        'id' => 'security-policy',
                        'name' => 'Security Policy & Keys',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin'],
                        'tabs' => [
                            ['id' => 'password-policy', 'name' => 'Password Policy & Complexity', 'subTabs' => [['id' => 'expiry-rules', 'name' => 'Periodic Expiration'], ['id' => 'complexity-chars', 'name' => 'Special Chars & Numbers']]],
                            ['id' => 'session-governance', 'name' => 'Brute Force & Session Lifetimes', 'subTabs' => [['id' => 'lockout-limits', 'name' => 'Max Failed Attempts'], ['id' => 'inactivity-timeout', 'name' => 'Session Timeout']]]
                        ]
                    ],
                    [
                        'id' => 'system-audit',
                        'name' => 'System Audit Trail',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin', 'auditor'],
                        'tabs' => [
                            ['id' => 'event-logs', 'name' => 'Entity & Database Mutation Logs', 'subTabs' => [['id' => 'module-filter', 'name' => 'Module Mutation Trail'], ['id' => 'actor-trace', 'name' => 'Actor & Payload Forensic']]],
                            ['id' => 'retention-purge', 'name' => 'Log Retention & Export', 'subTabs' => [['id' => 'csv-export', 'name' => 'CSV Dump Generator'], ['id' => 'purge-policy', 'name' => 'Purge Threshold']]]
                        ]
                    ],
                    [
                        'id' => 'system-settings',
                        'name' => 'System Settings',
                        'defaultVisibleRoles' => ['software_app_admin', 'company_admin'],
                        'tabs' => [
                            ['id' => 'entity-details', 'name' => 'Corporate Legal Entity Profile', 'subTabs' => [['id' => 'company-name', 'name' => 'Legal Identity'], ['id' => 'currency-tax', 'name' => 'Tax Number & Currency']]],
                            ['id' => 'system-guards', 'name' => 'System Safeguards & CSRF', 'subTabs' => [['id' => 'csrf-guard', 'name' => 'CSRF Token Enforcement'], ['id' => 'audit-switch', 'name' => 'Audit Engine Toggle']]]
                        ]
                    ]
                ]
            ]
        ];
    }

    /**
     * Check navigation visibility for a canonical role
     */
    public function isNavigationVisibleForRole(string $role, string $navbarId, ?string $userId = null): bool
    {
        $canonical = $this->canonicalizeRole($role);
        if ($canonical === 'software_app_admin') {
            return true;
        }

        // Check explicit user overrides if userId provided
        if (!empty($userId)) {
            $userRow = $this->db->table('users')->where('id', $userId)->orWhere('username', $userId)->get()->getRowArray();
            if ($userRow) {
                $uid = $userRow['id'];
                // Check if user has an explicit navigation or permission override
                $userOverride = $this->db->table('user_permissions')
                    ->select('user_permissions.is_granted')
                    ->join('permissions', 'permissions.id = user_permissions.permission_id')
                    ->where('user_permissions.user_id', $uid)
                    ->groupStart()
                        ->where('permissions.code', 'nav:' . $navbarId)
                        ->orWhere('permissions.code', $navbarId . '.view')
                        ->orWhere('permissions.module', $navbarId)
                    ->groupEnd()
                    ->get()
                    ->getRowArray();

                if ($userOverride !== null) {
                    return (bool)$userOverride['is_granted'];
                }

                // Check if user has any granted permission for the underlying module
                $navToModuleMap = [
                    'leave-applications' => 'leaves',
                    'leave-balances'     => 'leaves',
                    'daily-attendance'   => 'attendance',
                    'early-closures'     => 'attendance',
                    'rules-engine'       => 'rules',
                    'roster'             => 'rostering',
                    'payroll-run'        => 'payroll',
                    'salary-structures'  => 'payroll',
                    'bonus-runs'         => 'bonus',
                    'loans-advances'     => 'loans',
                    'asset-inventory'    => 'assets',
                    'asset-allocations'  => 'assets',
                    'training-programs'  => 'training',
                    'job-openings'       => 'recruitment',
                    'appraisal-cycles'   => 'performance',
                    'attendance-reports' => 'reports',
                    'salary-reports'     => 'reports',
                    'reports-upload'     => 'reports',
                    'bulletin-board'     => 'notices',
                    'directory'          => 'directory',
                    'organogram'         => 'directory',
                    'company-branches'   => 'master',
                    'roles-permissions'  => 'role',
                    'users-management'   => 'user',
                    'system-settings'    => 'settings',
                    'pf-summary'         => 'pf',
                    'provident-fund'     => 'pf',
                ];
                if (isset($navToModuleMap[$navbarId])) {
                    $targetMod = $navToModuleMap[$navbarId];
                    if ($this->hasAccess(null, $targetMod, 'view', $uid) || 
                        $this->hasAccess(null, $targetMod, 'manage', $uid) ||
                        $this->hasAccess(null, $targetMod, 'approve', $uid)) {
                        return true;
                    }
                }
            }
        }

        $aliasMap = [
            'pf' => 'pf-summary',
            'pf-summary' => 'pf-summary',
            'provident-fund' => 'pf-summary',
            'attendance' => 'daily-attendance',
            'daily-attendance' => 'daily-attendance',
            'early-closures' => 'early-closures',
            'early_closures' => 'early-closures',
            'earlyclosures' => 'early-closures',
            'rules' => 'rules-engine',
            'rules-engine' => 'rules-engine',
            'attendance-rules' => 'rules-engine',
            'roster' => 'roster',
            'rostering' => 'roster',
            'overtime' => 'overtime',
            'sync' => 'biometric-sync',
            'biometric' => 'biometric-sync',
            'biometric-sync' => 'biometric-sync',
            'unmatched' => 'biometric-sync',
            'unmatched-biometrics' => 'biometric-sync',
            'unmatched-staff' => 'biometric-sync',
            'leaves' => 'leave-applications',
            'leave' => 'leave-applications',
            'leave-applications' => 'leave-applications',
            'leave-balances' => 'leave-balances',
            'notices' => 'bulletin-board',
            'notice' => 'bulletin-board',
            'bulletin-board' => 'bulletin-board',
            'payroll' => 'payroll-run',
            'payroll-run' => 'payroll-run',
            'salary-structures' => 'salary-structures',
            'bonuses' => 'bonus-runs',
            'bonus' => 'bonus-runs',
            'bonus-runs' => 'bonus-runs',
            'loans' => 'loans-advances',
            'loan' => 'loans-advances',
            'loans-advances' => 'loans-advances',
            'assets' => 'asset-inventory',
            'asset-inventory' => 'asset-inventory',
            'asset-allocations' => 'asset-allocations',
            'training' => 'training-programs',
            'training-programs' => 'training-programs',
            'recruitment' => 'job-openings',
            'job-openings' => 'job-openings',
            'performance' => 'appraisal-cycles',
            'appraisal-cycles' => 'appraisal-cycles',
            'reports' => 'attendance-reports',
            'attendance-reports' => 'attendance-reports',
            'salary-reports' => 'salary-reports',
            'reports-upload' => 'reports-upload',
            'report-upload' => 'reports-upload',
            'directory' => 'directory',
            'employees' => 'directory',
            'organogram' => 'organogram',
            'branding' => 'company-branding',
            'company-branding' => 'company-branding',
            'profile' => 'company-profile',
            'company-profile' => 'company-profile',
            'master' => 'company-branches',
            'company-branches' => 'company-branches',
            'security' => 'roles-permissions',
            'roles-permissions' => 'roles-permissions',
            'users' => 'users-management',
            'users-management' => 'users-management',
            'system' => 'system-settings',
            'system-settings' => 'system-settings',
        ];

        $targetNavbarId = $aliasMap[$navbarId] ?? $navbarId;

        foreach ($this->getNavigationHierarchy() as $module) {
            foreach ($module['navbars'] as $nav) {
                if ($nav['id'] === $targetNavbarId) {
                    return in_array($canonical, $nav['defaultVisibleRoles'] ?? [], true);
                }
            }
        }
        return false;
    }

    /**
     * Simulate access check with detailed step-by-step diagnostic trace
     */
    public function simulateAccessTrace(
        string $roleOrUserId, 
        string $moduleCode, 
        string $action = 'view', 
        ?string $navbarId = null,
        ?string $tabId = null,
        ?string $subTabId = null,
        string $mode = 'role',
        ?string $targetEmployeeId = null
    ): array {
        $steps = [];
        $action = strtolower(trim($action));
        $moduleCode = strtolower(trim($moduleCode));
        if (str_contains($moduleCode, '.')) {
            $parts = explode('.', $moduleCode, 2);
            $moduleCode = $parts[0];
            $action = $parts[1] ?: $action;
        }

        $userRow = null;
        $roleRow = null;
        $roleName = 'Employee';
        $canonicalRole = 'employee';
        $isRoleActive = true;
        $isUserActive = true;

        if ($mode === 'user') {
            $userRow = $this->db->table('users')
                ->select('users.*, roles.name as role_name, roles.code as role_code, roles.status as role_status')
                ->join('roles', 'roles.id = users.role_id', 'left')
                ->where('users.id', $roleOrUserId)
                ->orWhere('users.username', $roleOrUserId)
                ->get()
                ->getRowArray();

            if (!$userRow) {
                return [
                    'granted'    => false,
                    'allowed'    => false,
                    'statusCode' => 404,
                    'tier'       => 'user_not_found',
                    'scope'      => 'none',
                    'reason'     => "Target user '{$roleOrUserId}' does not exist in database.",
                    'trace'      => ['User lookup failed in `users` table']
                ];
            }

            $isUserActive = (strtolower($userRow['status'] ?? 'active') === 'active');
            $steps[] = "Step 1: Evaluated User Account '{$userRow['username']}' status -> " . ($isUserActive ? '[ACTIVE]' : '[INACTIVE/LOCKED]');
            if (!$isUserActive) {
                return [
                    'granted'    => false,
                    'allowed'    => false,
                    'statusCode' => 403,
                    'tier'       => 'inactive_deny',
                    'scope'      => 'none',
                    'reason'     => "403 Forbidden: User account '{$userRow['username']}' status is '{$userRow['status']}'. Authentication and API executions are blocked.",
                    'trace'      => $steps
                ];
            }

            $roleName = $userRow['role_name'] ?? 'Employee';
            $canonicalRole = $this->canonicalizeRole($userRow['role_code'] ?? $roleName);
            $isRoleActive = (isset($userRow['role_status']) && strtolower($userRow['role_status']) === 'active');
        } else {
            $session = function_exists('session') ? session() : (class_exists('\Config\Services') ? \Config\Services::session() : null);
            $sessionCompanyId = $session ? $session->get('company_id') : null;
            $roleRow = $this->resolveRoleRecord($roleOrUserId, $sessionCompanyId);
            if ($roleRow) {
                $roleName = $roleRow['name'];
                $canonicalRole = $this->canonicalizeRole($roleRow['code'] ?? $roleRow['name']);
                $isRoleActive = (strtolower($roleRow['status'] ?? 'active') === 'active');
            } else {
                $canonicalRole = $this->canonicalizeRole($roleOrUserId);
                $roleName = ucwords(str_replace('_', ' ', $canonicalRole));
            }
        }

        $steps[] = "Step 2: Canonicalized Role '{$roleName}' to '{$canonicalRole}' -> Status: " . ($isRoleActive ? '[ACTIVE]' : '[INACTIVE]');

        // Software App Admin bypass
        if ($canonicalRole === 'software_app_admin') {
            $steps[] = "Step 3: Root System Safeguard matched -> Software App Admin granted universal bypass.";
            return [
                'granted'    => true,
                'allowed'    => true,
                'statusCode' => 200,
                'tier'       => 'root_software_app_admin',
                'scope'      => 'all',
                'reason'     => "Access Approved: Software App Admin possesses universal root privileges across all modules.",
                'trace'      => $steps
            ];
        }

        // Inactive role check
        if (!$isRoleActive) {
            $steps[] = "Step 3: Role '{$roleName}' is marked Inactive -> Revoking all privileges.";
            return [
                'granted'    => false,
                'allowed'    => false,
                'statusCode' => 403,
                'tier'       => 'inactive_deny',
                'scope'      => 'none',
                'reason'     => "403 Forbidden: Assigned role '{$roleName}' is currently inactive in RBAC database.",
                'trace'      => $steps
            ];
        }

        // Navigation visibility check if navbarId provided
        $isNavVisible = true;
        if ($navbarId) {
            $isNavVisible = $this->isNavigationVisibleForRole($canonicalRole, $navbarId);
            $steps[] = "Step 4: Evaluated Navbar '{$navbarId}' visibility for role '{$canonicalRole}' -> " . ($isNavVisible ? '[VISIBLE]' : '[HIDDEN]');
        }

        // Unified permission verification
        $permCode = "{$moduleCode}.{$action}";
        $inScope = null;

        if ($mode === 'user' && !empty($userRow)) {
            $decision = $this->check($userRow['id'], $permCode);
            $isGranted = $decision->isAllowed();
            $tier = $decision->tier();
            $scope = $decision->scope();
            $reason = $decision->reason();
            $steps[] = "Step 5: Evaluated Permission-First Pipeline for '{$permCode}' -> [" . ($isGranted ? 'ALLOW' : 'DENY') . "] (Tier: {$tier}, Scope: {$scope})";

            if ($targetEmployeeId) {
                $targetEmployee = $this->db->table('employees')->where('id', $targetEmployeeId)->get()->getRowArray();
                if ($targetEmployee) {
                    $inScope = $this->assertInScope($userRow, $scope, $targetEmployee);
                    $steps[] = "Step 6: Data Scope Evaluation on target employee '{$targetEmployee['first_name']} {$targetEmployee['last_name']}' against scope [{$scope}] -> " . ($inScope ? '[IN SCOPE]' : '[OUT OF SCOPE]');
                }
            }
        } else {
            $isGranted = $this->hasAccess($roleOrUserId, $moduleCode, $action);
            $tier = $isGranted ? 'role_default' : 'default_deny';
            $scope = $isGranted ? 'company' : 'none';
            $reason = $isGranted
                ? "Role '{$roleName}' default matrix authorizes capability '{$permCode}'."
                : "Role '{$roleName}' default matrix lacks capability '{$permCode}'.";
            $steps[] = "Step 5: Queried database for action permission code '{$permCode}' -> " . ($isGranted ? '[AUTHORIZED]' : '[DENIED]');
        }

        return [
            'granted'             => $isGranted,
            'allowed'             => $isGranted,
            'statusCode'          => $isGranted ? 200 : 403,
            'tier'                => $tier,
            'scope'               => $scope,
            'code'                => $permCode,
            'isNavigationVisible' => $isNavVisible,
            'target_in_scope'     => $inScope,
            'reason'              => $isGranted 
                ? "Access Approved (200 OK): {$reason}"
                : "403 Forbidden: {$reason}",
            'trace'               => $steps
        ];
    }

    /**
     * Check if a role is an elevated administrator role
     * Note: ONLY Software App Admin is globally elevated to bypass permission matrices.
     * Company Admin is tenant-scoped and must be evaluated against standard tenant matrices.
     */
    public function isElevatedRole(string $role): bool
    {
        $canonical = $this->canonicalizeRole($role);
        return $canonical === 'software_app_admin';
    }

    /**
     * Check if a role is the root Software App Admin
     */
    public function isSoftwareAppAdmin(?string $role = null): bool
    {
        $session = \Config\Services::session();
        $targetUserId = null;
        $roleCandidate = null;

        if ($role === null) {
            $targetUserId = (string)($session->get('user_id') ?? '');
            $roleCandidate = (string)($session->get('role') ?? $session->get('role_code') ?? '');
            if ($session->has('company_id') && !empty($session->get('company_id'))) {
                return false;
            }
        } elseif ((strlen($role) === 36 && str_contains($role, '-')) || str_starts_with($role, 'usr-') || str_starts_with($role, 'user-')) {
            $targetUserId = $role;
        } else {
            $roleCandidate = $role;
        }

        // If we have a user context, verify is_system = 1 AND company_id IS NULL from DB
        if (!empty($targetUserId)) {
            try {
                if ($this->db && $this->db->tableExists('users')) {
                    $uRow = $this->db->table('users')
                        ->select('users.company_id as user_company_id, roles.is_system as role_is_system, roles.company_id as role_company_id, roles.code as role_code, roles.name as role_name')
                        ->join('roles', 'roles.id = users.role_id', 'left')
                        ->where('users.id', $targetUserId)
                        ->get()
                        ->getRowArray();
                    if ($uRow) {
                        if (!empty($uRow['user_company_id']) || !empty($uRow['role_company_id'])) {
                            return false;
                        }
                        if ((int)($uRow['role_is_system'] ?? 0) !== 1) {
                            return false;
                        }
                        $cand = (string)($uRow['role_code'] ?? $uRow['role_name'] ?? $roleCandidate);
                        return $this->canonicalizeRole($cand) === 'software_app_admin';
                    }
                }
            } catch (\Throwable $e) {}
        }

        // If no user context, verify candidate canonicalizes to software_app_admin
        if ($this->canonicalizeRole($roleCandidate) !== 'software_app_admin') {
            return false;
        }

        // And verify from DB that a global system role exists with is_system=1 and company_id IS NULL
        try {
            if ($this->db && $this->db->tableExists('roles')) {
                $sysRole = $this->db->table('roles')
                    ->where('is_system', 1)
                    ->groupStart()
                        ->where('company_id IS NULL', null, false)
                        ->orWhere('company_id', '')
                    ->groupEnd()
                    ->groupStart()
                        ->where('code', 'software_app_admin')
                        ->orWhere('code', 'r_sa')
                        ->orWhere('name', 'Software App Admin')
                    ->groupEnd()
                    ->get()
                    ->getRowArray();
                return !empty($sysRole);
            }
        } catch (\Throwable $e) {}

        return true;
    }

    /**
     * Check if a role is a Company Admin
     */
    public function isCompanyAdmin(?string $role = null): bool
    {
        if ($role === null) {
            $session = \Config\Services::session();
            $role = (string)($session->get('role') ?? $session->get('role_code') ?? '');
        }
        return $this->canonicalizeRole($role) === 'company_admin';
    }

    /**
     * Check if a role is a Branch Manager
     */
    public function isBranchManager(?string $role = null): bool
    {
        if ($role === null) {
            $session = \Config\Services::session();
            $role = (string)($session->get('role') ?? $session->get('role_code') ?? '');
        }
        return $this->canonicalizeRole($role) === 'branch_manager';
    }

    /**
     * Check if a role is an HR Admin
     */
    public function isHRAdmin(?string $role = null): bool
    {
        if ($role === null) {
            $session = \Config\Services::session();
            $role = (string)($session->get('role') ?? $session->get('role_code') ?? '');
        }
        return $this->canonicalizeRole($role) === 'hr_admin';
    }

    /**
     * Check if a role is an HR Officer
     */
    public function isHROfficer(?string $role = null): bool
    {
        if ($role === null) {
            $session = \Config\Services::session();
            $role = (string)($session->get('role') ?? $session->get('role_code') ?? '');
        }
        return $this->canonicalizeRole($role) === 'hr_officer';
    }

    /**
     * Check if a role is HR or Admin (software_app_admin, company_admin, hr_admin, hr_officer)
     */
    public function isHRorAdmin(?string $role = null): bool
    {
        if ($role === null) {
            $session = \Config\Services::session();
            $role = (string)($session->get('role') ?? $session->get('role_code') ?? '');
        }
        $canonical = $this->canonicalizeRole($role);
        return in_array($canonical, ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer'], true);
    }

    /**
     * Check if a role is Finance
     */
    public function isFinance(?string $role = null): bool
    {
        if ($role === null) {
            $session = \Config\Services::session();
            $role = (string)($session->get('role') ?? $session->get('role_code') ?? '');
        }
        return $this->canonicalizeRole($role) === 'finance';
    }

    /**
     * Check if a role is a Manager
     */
    public function isManager(?string $role = null): bool
    {
        if ($role === null) {
            $session = \Config\Services::session();
            $role = (string)($session->get('role') ?? $session->get('role_code') ?? '');
        }
        return $this->canonicalizeRole($role) === 'manager';
    }

    /**
     * Check if a role is a Team Leader
     */
    public function isTeamLeader(?string $role = null): bool
    {
        if ($role === null) {
            $session = \Config\Services::session();
            $role = (string)($session->get('role') ?? $session->get('role_code') ?? '');
        }
        return $this->canonicalizeRole($role) === 'team_leader';
    }

    /**
     * Check if a role is an Employee
     */
    public function isEmployee(?string $role = null): bool
    {
        if ($role === null) {
            $session = \Config\Services::session();
            $role = (string)($session->get('role') ?? $session->get('role_code') ?? '');
        }
        return $this->canonicalizeRole($role) === 'employee';
    }

    /**
     * Check if a role is an Auditor
     */
    public function isAuditor(?string $role = null): bool
    {
        if ($role === null) {
            $session = \Config\Services::session();
            $role = (string)($session->get('role') ?? $session->get('role_code') ?? '');
        }
        return $this->canonicalizeRole($role) === 'auditor';
    }

    /**
     * Check if a permission or module belongs to the root PLATFORM namespace
     */
    public function isPlatformPermission(string $permissionOrModule, ?string $action = null): bool
    {
        $check = strtolower(trim($permissionOrModule));
        if ($action !== null && trim($action) !== '') {
            $actTrimmed = strtolower(trim($action));
            return $this->isPlatformPermission($check . '.' . $actTrimmed) || $this->isPlatformPermission($check);
        }
        if ($check === '') {
            return false;
        }

        $parts = explode('.', $check);
        $mod = $parts[0] ?? $check;
        $act = $parts[1] ?? '';

        if (in_array($mod, ['platform', 'system', 'company_provision', 'global_rbac', 'global_security', 'module_toggle'], true)) {
            return true;
        }
        if (in_array($act, ['system_backup', 'system_restore', 'platform_admin', 'global_rbac', 'global_security'], true)) {
            return true;
        }
        if (in_array($check, ['company.create', 'company.delete', 'companies.create', 'companies.delete', 'company.provision', 'companies.provision', 'company.view_all', 'platform.admin', 'system.view', 'system.manage', 'system.delete', 'system.backup', 'system.restore', 'module_toggle', 'modules.toggle'], true)) {
            return true;
        }

        return str_starts_with($check, 'platform') || 
               str_starts_with($check, 'system.') ||
               str_starts_with($check, 'system_') ||
               str_starts_with($check, 'security.global') ||
               str_starts_with($check, 'rbac.global') ||
               str_starts_with($check, 'companies.create') ||
               str_starts_with($check, 'companies.delete') ||
               str_starts_with($check, 'company_provision') ||
               str_starts_with($check, 'global_') ||
               str_contains($check, 'software_app_admin') ||
               in_array($check, [
                   'platform', 'system', 'system_backup', 'system_restore',
                   'companies', 'company_provision', 'global_rbac', 'global_security',
                   'module_toggle', 'modules.toggle',
                   'system.software_app_admin.view', 'system.software_app_admin.manage',
                   'system.rbac.global', 'system.security.global', 'system.platform.manage'
               ], true);
    }

    /**
     * Check if two permission codes are equivalent (exact or via normalizePermission aliases)
     */
    public function areEquivalent(string $code1, string $code2): bool
    {
        $c1 = strtolower(trim($code1));
        $c2 = strtolower(trim($code2));
        if ($c1 === $c2) {
            return true;
        }
        if (($c1 === 'pf.view' && $c2 === 'payroll.view') || ($c1 === 'payroll.view' && $c2 === 'pf.view')) {
            return true;
        }
        $n1 = $this->normalizePermission($c1);
        $n2 = $this->normalizePermission($c2);
        return ($n1['code'] === $n2['code']);
    }

    /**
     * Get the architectural hierarchy level for a role:
     * - ROOT (Software App Admin / Platform Owner)
     * - BUSINESS_ADMINISTRATION (Company Admin)
     * - OPERATIONAL (HR, Manager, Employee, etc.)
     */
    public function getRoleLevel(string $role): string
    {
        $canonical = $this->canonicalizeRole($role);
        if ($canonical === 'software_app_admin') {
            return 'ROOT';
        }
        if ($canonical === 'company_admin') {
            return 'BUSINESS_ADMINISTRATION';
        }
        return 'OPERATIONAL';
    }

    /**
     * Canonical Role Definition Metadata
     */
    public function getRoleDefinition(string $role): array
    {
        $canonical = $this->canonicalizeRole($role);
        $defs = [
            'software_app_admin' => [
                'name' => 'Software App Admin',
                'key' => 'software_app_admin',
                'short_name' => 'SA',
                'level' => 'ROOT',
                'description' => 'Root technical application administrator and platform owner with global system security and RBAC permissions.',
                'scope' => 'GLOBAL',
                'is_protected' => true,
            ],
            'company_admin' => [
                'name' => 'Company Admin',
                'key' => 'company_admin',
                'short_name' => 'CA',
                'level' => 'BUSINESS_ADMINISTRATION',
                'description' => 'Executive enterprise tenant administrator with broad organizational governance across the company.',
                'scope' => 'COMPANY',
                'is_protected' => false,
            ],
            'hr_admin' => [
                'name' => 'HR Admin',
                'key' => 'hr_admin',
                'short_name' => 'HRA',
                'level' => 'OPERATIONAL',
                'description' => 'Primary HR administrator for managing employees, leave workflows, attendance, and onboarding.',
                'scope' => 'COMPANY',
                'is_protected' => false,
            ],
            'hr_officer' => [
                'name' => 'HR Officer',
                'key' => 'hr_officer',
                'short_name' => 'HRO',
                'level' => 'OPERATIONAL',
                'description' => 'HR officer managing day-to-day HR operations, basic data entries, and staff records.',
                'scope' => 'COMPANY',
                'is_protected' => false,
            ],
            'branch_manager' => [
                'name' => 'Branch Manager',
                'key' => 'branch_manager',
                'short_name' => 'BM',
                'level' => 'OPERATIONAL',
                'description' => 'Branch executive overseeing branch operations, attendance, and branch personnel.',
                'scope' => 'BRANCH',
                'is_protected' => false,
            ],
            'finance' => [
                'name' => 'Finance',
                'key' => 'finance',
                'short_name' => 'FIN',
                'level' => 'OPERATIONAL',
                'description' => 'Financial operations manager handling payroll approvals, bonus disbursements, and tax ledgers.',
                'scope' => 'COMPANY',
                'is_protected' => false,
            ],
            'manager' => [
                'name' => 'Manager',
                'key' => 'manager',
                'short_name' => 'MGR',
                'level' => 'OPERATIONAL',
                'description' => 'Department head with authority to approve attendance, regularizations, and leave requests.',
                'scope' => 'TEAM',
                'is_protected' => false,
            ],
            'team_leader' => [
                'name' => 'Team Leader',
                'key' => 'team_leader',
                'short_name' => 'TL',
                'level' => 'OPERATIONAL',
                'description' => 'Team leader supervising project members, performance reviews, and initial shift plans.',
                'scope' => 'TEAM',
                'is_protected' => false,
            ],
            'employee' => [
                'name' => 'Employee',
                'key' => 'employee',
                'short_name' => 'EMP',
                'level' => 'OPERATIONAL',
                'description' => 'Standard employee with self-service access to personal profile, attendance, and leave.',
                'scope' => 'COMPANY',
                'is_protected' => false,
            ],
            'auditor' => [
                'name' => 'Auditor',
                'key' => 'auditor',
                'short_name' => 'AUD',
                'level' => 'OPERATIONAL',
                'description' => 'Compliance auditor with read-only access to all system activity, logs, and generated reports.',
                'scope' => 'COMPANY',
                'is_protected' => false,
            ],
        ];
        return $defs[$canonical] ?? $defs['employee'];
    }

    /**
     * Check if a specific module is enabled for a given company.
     * Software App Admin can enable/disable modules per company.
     * Module OFF is strictly enforced server-side.
     */
    public function isModuleEnabledForCompany(?string $companyId, string $moduleCode): bool
    {
        if (!$companyId) {
            return true;
        }

        $moduleCode = strtolower(trim($moduleCode));
        if ($moduleCode === '') {
            return true;
        }

        // Core baseline modules always enabled
        if (in_array($moduleCode, ['dashboard', 'notifications', 'notices', 'profile', 'my-profile', 'system', 'overview'], true)) {
            return true;
        }

        $synonyms = [
            'payroll'      => ['payroll', 'payrolls'],
            'payrolls'     => ['payroll', 'payrolls'],
            'leave'        => ['leave', 'leaves'],
            'leaves'       => ['leave', 'leaves'],
            'attendance'   => ['attendance', 'attendances'],
            'attendances'  => ['attendance', 'attendances'],
            'overtime'     => ['overtime', 'overtime_requests'],
            'rostering'    => ['rostering', 'shift_roster', 'roster', 'shifts'],
            'shift_roster' => ['rostering', 'shift_roster', 'roster', 'shifts'],
            'employee'     => ['employee', 'employees', 'directory'],
            'employees'    => ['employee', 'employees', 'directory'],
            'directory'    => ['employee', 'employees', 'directory'],
            'master'       => ['master', 'departments', 'branches', 'designations'],
            'training'     => ['training', 'trainings'],
            'performance'  => ['performance'],
            'recruitment'  => ['recruitment'],
            'assets'       => ['asset', 'assets'],
        ];
        $codesToTest = $synonyms[$moduleCode] ?? [$moduleCode];

        // Consult cached module statuses dictionary
        $statuses = $this->getAllModuleStatusesForCompany($companyId);
        foreach ($codesToTest as $code) {
            if (isset($statuses[$code]) && !$statuses[$code]) {
                return false;
            }
        }

        return true;
    }

    /**
     * Get associative map of all modules and their enabled state for a company.
     * Guaranteed server-side module status dictionary.
     */
    public function getAllModuleStatusesForCompany(?string $companyId): array
    {
        $cacheKey = $companyId ?: 'global';
        if (isset(self::$moduleStatusesCache[$cacheKey])) {
            return self::$moduleStatusesCache[$cacheKey];
        }

        $modules = [
            'dashboard'   => true,
            'attendance'  => true,
            'leaves'      => true,
            'leave'       => true,
            'payroll'     => true,
            'overtime'    => true,
            'rostering'   => true,
            'shift_roster'=> true,
            'directory'   => true,
            'employees'   => true,
            'master'      => true,
            'training'    => true,
            'performance' => true,
            'recruitment' => true,
            'assets'      => true,
            'notices'     => true,
            'system'      => true,
        ];

        if (!$companyId) {
            self::$moduleStatusesCache[$cacheKey] = $modules;
            return $modules;
        }

        try {
            if ($this->db->tableExists('company_modules')) {
                $rows = $this->db->table('company_modules')
                    ->where('company_id', $companyId)
                    ->get()
                    ->getResultArray();

                foreach ($rows as $row) {
                    $mCode = strtolower(trim($row['module_code']));
                    $isEnabled = (bool)($row['is_enabled'] ?? 1);
                    $modules[$mCode] = $isEnabled;

                    // Synchronize synonyms
                    if ($mCode === 'leave') $modules['leaves'] = $isEnabled;
                    if ($mCode === 'leaves') $modules['leave'] = $isEnabled;
                    if ($mCode === 'payroll') $modules['payrolls'] = $isEnabled;
                    if ($mCode === 'employee' || $mCode === 'employees' || $mCode === 'directory') {
                        $modules['directory'] = $isEnabled;
                        $modules['employees'] = $isEnabled;
                        $modules['employee'] = $isEnabled;
                    }
                    if ($mCode === 'rostering' || $mCode === 'shift_roster') {
                        $modules['rostering'] = $isEnabled;
                        $modules['shift_roster'] = $isEnabled;
                    }
                }
            }
        } catch (\Throwable $e) {
            // fallback to default
        }

        self::$moduleStatusesCache[$cacheKey] = $modules;
        return $modules;
    }

    /**
     * Validate tenant boundary. Company Admin and users can ONLY access records in their own company.
     * Software App Admin can access any company.
     */
    public function validateTenantScope(?array $actorUser, ?string $targetCompanyId): bool
    {
        if (!$actorUser) {
            return false;
        }

        $isSystemRole = (int)($actorUser['role_is_system'] ?? 0) === 1;
        $isGlobalRole = empty($actorUser['role_company_id']);
        $isGlobalUser = empty($actorUser['company_id']);
        $actorRole = $this->canonicalizeRole($actorUser['role_name'] ?? $actorUser['role_code'] ?? '');
        if ($isSystemRole && $isGlobalRole && $isGlobalUser && $actorRole === 'software_app_admin') {
            return true;
        }

        $userCompanyId = $actorUser['company_id'] ?? (function_exists('session') && session()->has('company_id') ? session()->get('company_id') : null);
        if (!$userCompanyId || !$targetCompanyId) {
            return false;
        }

        return (string)$userCompanyId === (string)$targetCompanyId;
    }

    /**
     * Validate branch boundary. Ensures the branch belongs to the actor's company.
     * Software App Admin can access any branch.
     */
    public function validateBranchScope(?array $actorUser, ?string $targetBranchId): bool
    {
        if (!$actorUser) {
            return false;
        }

        $isSystemRole = (int)($actorUser['role_is_system'] ?? 0) === 1;
        $isGlobalRole = empty($actorUser['role_company_id']);
        $isGlobalUser = empty($actorUser['company_id']);
        $actorRole = $this->canonicalizeRole($actorUser['role_name'] ?? $actorUser['role_code'] ?? '');
        if ($isSystemRole && $isGlobalRole && $isGlobalUser && $actorRole === 'software_app_admin') {
            return true;
        }

        if (!$targetBranchId) {
            return false;
        }

        $userCompanyId = $actorUser['company_id'] ?? null;
        if (!$userCompanyId) {
            return false;
        }

        try {
            $branchModel = new \App\Models\BranchModel();
            $branch = $branchModel->find($targetBranchId);
            if (!$branch) {
                return false;
            }
            return (string)($branch['company_id'] ?? '') === (string)$userCompanyId;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Validate whether an actor role is permitted to create, modify or assign a target role.
     * - Company Admin CANNOT create or assign Software App Admin.
     * - Only Software App Admin can manage Platform roles.
     */
    public function canManageRole(string $actorRole, string $targetRole): bool
    {
        $actorCanonical = $this->canonicalizeRole($actorRole);
        $targetCanonical = $this->canonicalizeRole($targetRole);

        if ($this->isSoftwareAppAdmin($actorCanonical)) {
            return true;
        }

        // Non-platform admins can never manage or assign Software App Admin
        if ($targetCanonical === 'software_app_admin') {
            return false;
        }

        // Company Admin can manage company-level roles
        if ($this->isCompanyAdmin($actorCanonical)) {
            return true;
        }

        // HR Admin and other business roles cannot manage or assign roles
        return false;
    }

    /**
     * Check if a role or current session can manage security (overrides, lock/unlock, 2FA)
     */
    public function canManageSecurity(?string $role = null): bool
    {
        if ($this->isSoftwareAppAdmin($role) || $this->isCompanyAdmin($role)) {
            return true;
        }
        $canonical = $this->canonicalizeRole($role);
        if ($canonical === 'hr_admin') {
            return true;
        }
        $session = \Config\Services::session();
        $userId = $session ? (string)$session->get('user_id') : '';
        if ($userId) {
            return $this->can($userId, 'role.manage')->isAllowed() 
                || $this->can($userId, 'user.manage')->isAllowed() 
                || $this->can($userId, 'rbac.assign')->isAllowed();
        }
        return false;
    }

    /**
     * Check if a role or current session can reset user passwords
     */
    public function canResetPassword(?string $role = null): bool
    {
        if ($this->isSoftwareAppAdmin($role) || $this->isCompanyAdmin($role) || $this->isHRAdmin($role)) {
            return true;
        }
        $session = \Config\Services::session();
        $userId = $session ? (string)$session->get('user_id') : '';
        if ($userId) {
            return $this->can($userId, 'user.edit')->isAllowed() 
                || $this->can($userId, 'user.manage')->isAllowed();
        }
        return false;
    }

    /**
     * Check if a role or current session can manage user accounts (suspend, delete, reactivate)
     */
    public function canManageUsers(?string $role = null): bool
    {
        if ($this->isSoftwareAppAdmin($role) || $this->isCompanyAdmin($role) || $this->isHRAdmin($role)) {
            return true;
        }
        $session = \Config\Services::session();
        $userId = $session ? (string)$session->get('user_id') : '';
        if ($userId) {
            return $this->can($userId, 'user.manage')->isAllowed()
                || $this->can($userId, 'user.delete')->isAllowed();
        }
        return false;
    }
}
