<?php

namespace App\Services;

use App\Models\EmailTemplateModel;
use App\Models\CompanyModel;

class EmailTemplateRenderer
{
    protected EmailTemplateModel $templateModel;

    public function __construct(?EmailTemplateModel $templateModel = null)
    {
        $this->templateModel = $templateModel ?? new EmailTemplateModel();
    }

    /**
     * Render an email template by template code and variables.
     * Respects company override: if company override exists, it shadows the global template.
     *
     * @param string $templateCode e.g. 'welcome_email', 'leave_applied', 'leave_approved', 'leave_rejected', 'payslip_ready', 'asset_assignment'
     * @param array<string, mixed> $variables Key-value map of placeholders (with or without curly braces)
     * @param string|null $companyId Tenant company ID for resolving overrides
     * @return array{subject: string, body: string, template: array|null}
     */
    public function render(string $templateCode, array $variables = [], ?string $companyId = null): array
    {
        $template = $this->templateModel->getTemplateByCode($templateCode, $companyId);

        // Auto-resolve company name if missing from variables
        if (!isset($variables['company_name']) && !isset($variables['{company_name}'])) {
            $companyName = $this->resolveCompanyName($companyId);
            if ($companyName) {
                $variables['company_name'] = $companyName;
            }
        }

        if (!$template) {
            $defaultSubject = (string)($variables['subject'] ?? ucfirst(str_replace('_', ' ', $templateCode)));
            $defaultBody    = (string)($variables['body'] ?? '');

            return [
                'subject'  => $this->replacePlaceholders($defaultSubject, $variables),
                'body'     => $this->replacePlaceholders($defaultBody, $variables),
                'template' => null,
            ];
        }

        $rawSubject = (string)($template['subject'] ?? '');
        $rawBody    = (string)($template['body'] ?? '');

        $renderedSubject = $this->replacePlaceholders($rawSubject, $variables);
        $renderedBody    = $this->replacePlaceholders($rawBody, $variables);

        return [
            'subject'  => $renderedSubject,
            'body'     => $renderedBody,
            'template' => $template,
        ];
    }

    /**
     * Static shortcut to render an email template.
     */
    public static function renderTemplate(string $templateCode, array $variables = [], ?string $companyId = null): array
    {
        $instance = new self();
        return $instance->render($templateCode, $variables, $companyId);
    }

    /**
     * Replace {placeholder} tokens in text with values from variables array.
     */
    public function replacePlaceholders(string $text, array $variables): string
    {
        if ($text === '' || empty($variables)) {
            return $text;
        }

        $pairs = [];
        foreach ($variables as $key => $value) {
            if (is_array($value) || (is_object($value) && !method_exists($value, '__toString'))) {
                continue;
            }
            $valStr = (string)$value;
            $rawKey = trim((string)$key, '{}');
            $pairs['{' . $rawKey . '}'] = $valStr;
        }

        return strtr($text, $pairs);
    }

    /**
     * Helper: Render Welcome Email for newly provisioned employee / user.
     */
    public function renderWelcome(array $employee, array $user = [], ?string $companyId = null): array
    {
        $empName = trim(($employee['first_name'] ?? '') . ' ' . ($employee['last_name'] ?? ''));
        $empCode = $employee['employee_code'] ?? ($employee['id'] ?? 'N/A');
        $username = $user['username'] ?? ($employee['email'] ?? $empCode);

        return $this->render('welcome_email', [
            'employee_name' => $empName,
            'employee_code' => $empCode,
            'username'      => $username,
        ], $companyId ?? ($employee['company_id'] ?? null));
    }

    /**
     * Helper: Render Leave Application Submission (leave_applied).
     */
    public function renderLeaveApplied(array $data, ?string $companyId = null): array
    {
        return $this->render('leave_applied', [
            'manager_name'  => $data['manager_name'] ?? 'Manager',
            'employee_name' => $data['employee_name'] ?? 'Employee',
            'employee_code' => $data['employee_code'] ?? '',
            'leave_type'    => $data['leave_type'] ?? 'Leave',
            'days'          => (string)($data['days'] ?? $data['total_days'] ?? 1),
            'from_date'     => $data['from_date'] ?? ($data['start_date'] ?? date('Y-m-d')),
            'to_date'       => $data['to_date'] ?? ($data['end_date'] ?? date('Y-m-d')),
            'reason'        => $data['reason'] ?? 'Not specified',
            'approval_link' => $data['approval_link'] ?? base_url('leave'),
        ], $companyId);
    }

    /**
     * Helper: Render Leave Request Approved (leave_approved).
     */
    public function renderLeaveApproved(array $data, ?string $companyId = null): array
    {
        return $this->render('leave_approved', [
            'employee_name'     => $data['employee_name'] ?? 'Employee',
            'leave_type'        => $data['leave_type'] ?? 'Leave',
            'from_date'         => $data['from_date'] ?? ($data['start_date'] ?? date('Y-m-d')),
            'to_date'           => $data['to_date'] ?? ($data['end_date'] ?? date('Y-m-d')),
            'approver_name'     => $data['approver_name'] ?? 'HR Admin',
            'remaining_balance' => (string)($data['remaining_balance'] ?? 'N/A'),
        ], $companyId);
    }

    /**
     * Helper: Render Leave Request Rejected (leave_rejected).
     */
    public function renderLeaveRejected(array $data, ?string $companyId = null): array
    {
        return $this->render('leave_rejected', [
            'employee_name' => $data['employee_name'] ?? 'Employee',
            'leave_type'    => $data['leave_type'] ?? 'Leave',
            'from_date'     => $data['from_date'] ?? ($data['start_date'] ?? date('Y-m-d')),
            'to_date'       => $data['to_date'] ?? ($data['end_date'] ?? date('Y-m-d')),
            'reason'        => $data['reason'] ?? 'No reason specified',
        ], $companyId);
    }

    /**
     * Helper: Render Payslip Notification (payslip_ready).
     */
    public function renderPayslipReady(array $data, ?string $companyId = null): array
    {
        $gross = isset($data['gross_salary']) ? (is_numeric($data['gross_salary']) ? ('$' . number_format((float)$data['gross_salary'], 2)) : (string)$data['gross_salary']) : '$0.00';
        $deductions = isset($data['total_deductions']) ? (is_numeric($data['total_deductions']) ? ('$' . number_format((float)$data['total_deductions'], 2)) : (string)$data['total_deductions']) : '$0.00';
        $net = isset($data['net_salary']) ? (is_numeric($data['net_salary']) ? ('$' . number_format((float)$data['net_salary'], 2)) : (string)$data['net_salary']) : '$0.00';

        return $this->render('payslip_ready', [
            'employee_name'    => $data['employee_name'] ?? 'Employee',
            'payroll_month'    => $data['payroll_month'] ?? date('F Y'),
            'cycle_name'       => $data['cycle_name'] ?? 'Monthly Regular',
            'gross_salary'     => $gross,
            'total_deductions' => $deductions,
            'net_salary'       => $net,
            'payslip_link'     => $data['payslip_link'] ?? base_url('payroll'),
        ], $companyId);
    }

    /**
     * Helper: Render Asset Custody Assignment (asset_assignment).
     */
    public function renderAssetAssignment(array $data, ?string $companyId = null): array
    {
        return $this->render('asset_assignment', [
            'employee_name' => $data['employee_name'] ?? 'Employee',
            'asset_name'    => $data['asset_name'] ?? 'Company Asset',
            'asset_code'    => $data['asset_code'] ?? 'AST-0000',
            'serial_number' => $data['serial_number'] ?? 'N/A',
        ], $companyId);
    }

    /**
     * Resolve company display name.
     */
    protected function resolveCompanyName(?string $companyId): ?string
    {
        if (empty($companyId)) {
            return null;
        }

        try {
            $company = (new CompanyModel())->find($companyId);
            return $company['name'] ?? null;
        } catch (\Throwable $e) {
            return null;
        }
    }
}
