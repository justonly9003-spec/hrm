<?php

namespace App\Services;

use App\Services\Rules\RuleResolver;
use App\Services\Rules\RuleNotConfiguredException;
use App\Services\Tax\TaxCalculator;
use App\Models\SalaryComponentModel;
use App\Models\SalaryStructureItemModel;
use App\Models\EmployeeModel;
use App\Libraries\PayrollCalculator;

/**
 * SalaryPolicyResolver
 *
 * The authoritative server-side resolver and single calculation authority for:
 * - Base and dynamic salary components (Earnings, Deductions)
 * - Statutory Policy compliance (Provident Fund, Income Tax/TDS, Gratuity)
 * - Versioned policy source tracing and compliance badges ("Source: <Policy name> v<version>, effective <date>")
 * - Enforcing read-only statutory rows with explicit override validation and audit reason tracking
 */
class SalaryPolicyResolver
{
    protected SalaryComponentModel $componentModel;
    protected SalaryStructureItemModel $structureItemModel;
    protected EmployeeModel $employeeModel;

    public function __construct()
    {
        $this->componentModel     = new SalaryComponentModel();
        $this->structureItemModel = new SalaryStructureItemModel();
        $this->employeeModel      = new EmployeeModel();
    }

    /**
     * Master Salary Policy Resolver Entrypoint
     *
     * @param array $params [
     *   'company_id'          => string,
     *   'employee_id'         => ?string,
     *   'basic_salary'        => float|int,
     *   'sample_basic_salary' => ?float,
     *   'structure_id'        => ?string,
     *   'components'          => ?array,
     *   'effective_date'      => ?string (YYYY-MM-DD),
     *   'pf_settings'         => ?array,
     *   'tax_settings'        => ?array,
     *   'gratuity_settings'   => ?array,
     * ]
     * @return array
     */
    public function resolve(array $params): array
    {
        $companyId = !empty($params['company_id']) ? (string)$params['company_id'] : null;
        if (empty($companyId)) {
            throw new RuleNotConfiguredException("Company ID is required to resolve salary policy.");
        }
        $effectiveDate = !empty($params['effective_date']) ? (string)$params['effective_date'] : date('Y-m-d');
        $employeeId = !empty($params['employee_id']) ? (string)$params['employee_id'] : null;

        $employee = null;
        if (!empty($employeeId)) {
            $employee = $this->employeeModel->find($employeeId);
        }

        $basic = (float)($params['basic_salary'] ?? $params['sample_basic_salary'] ?? ($employee['basic_salary'] ?? 0.0));
        if ($basic < 0) {
            $basic = 0.0;
        }

        $structureId = $params['structure_id'] ?? ($employee['salary_structure_id'] ?? null);
        $inputComponents = $params['components'] ?? $params['items'] ?? [];

        // 1. Resolve Raw Components list from input, template, or defaults
        $components = $this->normalizeInputComponents($inputComponents, $structureId, $companyId, $basic);

        // 2. Resolve Earnings (allowances, basic) and Compute Gross
        $earningsResult = $this->resolveEarnings($components, $basic);
        $grossSalary = $earningsResult['gross_salary'];
        $taxableGross = $earningsResult['taxable_gross'] ?? $grossSalary;
        $resolvedEarnings = $earningsResult['earnings'];

        // 3. Build comprehensive earnings map for PF Statutory Policy Engine
        $pfEarningsMap = [
            'Basic'        => $basic,
            'Basic_Salary' => $basic,
            'Gross'        => $grossSalary,
            'Gross_Salary' => $grossSalary,
        ];
        foreach ($resolvedEarnings as $e) {
            $isEnabled = $e['is_enabled'] ?? true;
            if ($isEnabled) {
                $cCode = trim((string)($e['component_code'] ?? $e['code'] ?? ''));
                $cName = trim((string)($e['name'] ?? $e['component_name'] ?? ''));
                $amt = (float)($e['amount'] ?? 0.0);
                if ($cCode !== '') {
                    $pfEarningsMap[$cCode] = $amt;
                }
                if ($cName !== '') {
                    $pfEarningsMap[$cName] = $amt;
                }
                // Common aliases for statutory policy basis matching
                if ($cCode === 'HRA' || stripos($cName, 'house rent') !== false) {
                    $pfEarningsMap['House_Rent'] = $amt;
                    $pfEarningsMap['HRA'] = $amt;
                    $pfEarningsMap['House Rent'] = $amt;
                }
                if ($cCode === 'MED' || stripos($cName, 'medical') !== false) {
                    $pfEarningsMap['Medical'] = $amt;
                    $pfEarningsMap['Medical_Allowance'] = $amt;
                    $pfEarningsMap['Medical Allowance'] = $amt;
                }
                if (in_array($cCode, ['CONV', 'TRANS', 'TA'], true) || stripos($cName, 'conveyance') !== false || stripos($cName, 'transport') !== false) {
                    $pfEarningsMap['Conveyance'] = $amt;
                    $pfEarningsMap['Transport'] = $amt;
                    $pfEarningsMap['Transport_Allowance'] = $amt;
                    $pfEarningsMap['Transport Allowance'] = $amt;
                }
                if (stripos($cName, 'food') !== false) {
                    $pfEarningsMap['Food'] = $amt;
                    $pfEarningsMap['Food_Allowance'] = $amt;
                    $pfEarningsMap['Food Allowance'] = $amt;
                }
                if (stripos($cName, 'special') !== false) {
                    $pfEarningsMap['Special'] = $amt;
                    $pfEarningsMap['Special_Allowance'] = $amt;
                    $pfEarningsMap['Special Allowance'] = $amt;
                }
            }
        }

        // 3. Resolve Statutory Provident Fund (PF) with full component breakdown
        $pfResult = $this->resolveProvidentFund($companyId, $effectiveDate, $basic, $grossSalary, $params['pf_settings'] ?? [], $employee, $pfEarningsMap);

        // 4. Resolve Statutory Income Tax (TDS) with Taxable Base
        $taxResult = $this->resolveIncomeTax($companyId, $effectiveDate, $basic, $taxableGross, $params['tax_settings'] ?? [], $employee, [
            'earnings' => $resolvedEarnings,
            'gross'    => $taxableGross,
        ]);

        // 5. Resolve Statutory Gratuity Provision
        $gratuityResult = $this->resolveGratuity($companyId, $effectiveDate, $basic, $grossSalary, $params['gratuity_settings'] ?? [], $employee);

        // 5.5 Resolve Overtime Policy (Read-Only) from RuleResolver / OvertimeCalculationService
        $otCalcService = new \App\Services\Overtime\OvertimeCalculationService();
        $otPolicy = $otCalcService->resolvePolicy($companyId, $employee, $effectiveDate);

        $dutyModel = new \App\Models\DutyAssignmentModel();
        $isOtEligible = $employeeId ? $dutyModel->isEmployeeOvertimeEligible($employeeId, $effectiveDate, $companyId) : true;

        $otPolicyResult = [
            'policy_id'                  => $otPolicy['id'] ?? null,
            'policy_name'                => $otPolicy['policy_name'],
            'policy_code'                => $otPolicy['policy_code'],
            'salary_basis'               => $otPolicy['salary_basis'],
            'divisor_mode'               => $otPolicy['divisor_mode'],
            'divisor_days'               => (float)$otPolicy['divisor_days'],
            'standard_daily_hours'       => (float)$otPolicy['standard_daily_hours'],
            'normal_ot_multiplier'       => (float)$otPolicy['normal_ot_multiplier'],
            'weekly_off_ot_multiplier'   => (float)$otPolicy['weekly_off_ot_multiplier'],
            'holiday_ot_multiplier'      => (float)$otPolicy['holiday_ot_multiplier'],
            'min_ot_unit_minutes'        => (int)$otPolicy['min_ot_unit_minutes'],
            'rounding_mode'              => $otPolicy['rounding_mode'],
            'max_daily_ot_hours'         => (float)$otPolicy['max_daily_ot_hours'],
            'requires_pre_approval'      => !empty($otPolicy['requires_pre_approval']),
            'is_eligible'                => $isOtEligible,
            'source_badge'               => 'Source: Rule Engine (RuleResolver OVERTIME)',
            'is_readonly'                => true,
            'note'                       => 'Policy-driven from Rule Store. OT hours are tracked via biometric attendance and paid exclusively from approved records via OvertimeCalculationService.'
        ];

        // 6. Resolve Non-Statutory Deductions
        $nonStatDeductionsResult = $this->resolveNonStatutoryDeductions($components, $basic, $grossSalary);
        $nonStatDeductions = $nonStatDeductionsResult['deductions'];

        // 7. Assemble Deductions List with Statutory Rows Marked and Formatted
        $allDeductions = [];

        // Add Statutory PF deduction if active/eligible
        if ($pfResult['is_active']) {
            $allDeductions[] = [
                'component_id'         => $pfResult['component_id'] ?? 'DED_PF',
                'component_code'       => 'EMP_PF',
                'name'                 => 'Provident Fund (PF)',
                'type'                 => 'deduction',
                'calculation_type'     => $pfResult['calculation_type'],
                'calculation_base'     => $pfResult['calculation_base'],
                'rate_or_amount'       => $pfResult['rate_or_amount'],
                'amount'               => $pfResult['employee_deduction'],
                'is_enabled'           => true,
                'is_taxable'           => 0,
                'is_statutory'         => true,
                'is_readonly'          => !$pfResult['is_override'],
                'policy_name'          => $pfResult['policy_name'],
                'policy_version'       => $pfResult['policy_version'],
                'policy_effective_date'=> $pfResult['policy_effective_date'],
                'source_badge'         => $pfResult['source_badge'],
                'is_override'          => $pfResult['is_override'],
                'override_reason'      => $pfResult['override_reason'],
            ];
        }

        // Add Statutory Income Tax (TDS) deduction
        if ($taxResult['is_active']) {
            $allDeductions[] = [
                'component_id'         => $taxResult['component_id'] ?? 'DED_TDS',
                'component_code'       => 'TDS',
                'name'                 => 'Income Tax (TDS)',
                'type'                 => 'deduction',
                'calculation_type'     => $taxResult['calculation_mode'] === 'Fixed' ? 'fixed' : 'slab',
                'calculation_base'     => 'Gross Salary',
                'rate_or_amount'       => $taxResult['amount'],
                'amount'               => $taxResult['amount'],
                'is_enabled'           => true,
                'is_taxable'           => 0,
                'is_statutory'         => true,
                'is_readonly'          => !$taxResult['is_override'],
                'policy_name'          => $taxResult['policy_name'],
                'policy_version'       => $taxResult['policy_version'],
                'policy_effective_date'=> $taxResult['policy_effective_date'],
                'source_badge'         => $taxResult['source_badge'],
                'is_override'          => $taxResult['is_override'],
                'override_reason'      => $taxResult['override_reason'],
            ];
        }

        // Add user-defined non-statutory deductions
        foreach ($nonStatDeductions as $nsd) {
            $allDeductions[] = $nsd;
        }

        // 8. Assemble Full Normalized Components list for the UI table
        $unifiedComponents = [];
        foreach ($resolvedEarnings as $earn) {
            $unifiedComponents[] = $earn;
        }
        foreach ($allDeductions as $ded) {
            $unifiedComponents[] = $ded;
        }

        // 9. Employer Contributions (CTC additions)
        $employerContributions = [];
        $totalEmployerCost = 0.0;

        if ($pfResult['is_active'] && $pfResult['employer_contribution'] > 0) {
            $totalEmployerCost += $pfResult['employer_contribution'];
            $employerContributions[] = [
                'component_id'   => 'ER_PF',
                'component_code' => 'ER_PF',
                'name'           => 'Employer PF Match (' . $pfResult['employer_rate'] . '%)',
                'type'           => 'employer_contribution',
                'amount'         => $pfResult['employer_contribution'],
                'annual_amount'  => round($pfResult['employer_contribution'] * 12, 2),
                'is_statutory'   => true,
                'is_readonly'    => !$pfResult['is_override'],
                'source_badge'   => $pfResult['source_badge'],
                'is_override'    => $pfResult['is_override'],
                'override_reason'=> $pfResult['override_reason'],
            ];
        }

        if ($gratuityResult['is_active'] && $gratuityResult['amount'] > 0) {
            $totalEmployerCost += $gratuityResult['amount'];
            $employerContributions[] = [
                'component_id'   => 'ER_GRATUITY',
                'component_code' => 'GRATUITY',
                'name'           => 'Statutory Gratuity Provision',
                'type'           => 'employer_contribution',
                'amount'         => $gratuityResult['amount'],
                'annual_amount'  => round($gratuityResult['amount'] * 12, 2),
                'is_statutory'   => true,
                'is_readonly'    => !$gratuityResult['is_override'],
                'source_badge'   => $gratuityResult['source_badge'],
                'is_override'    => $gratuityResult['is_override'],
                'override_reason'=> $gratuityResult['override_reason'],
            ];
        }

        // 10. Financial Totals
        $totalDeductions = 0.0;
        foreach ($allDeductions as $d) {
            if (!empty($d['is_enabled'])) {
                $totalDeductions += (float)($d['amount'] ?? 0);
            }
        }
        $totalDeductions = round($totalDeductions, 2);
        $netSalary = max(0.0, round($grossSalary - $totalDeductions, 2));
        $totalCtc = round($grossSalary + $totalEmployerCost, 2);
        $annualCtc = round($totalCtc * 12, 2);

        return [
            'success'               => true,
            'company_id'            => $companyId,
            'employee_id'           => $employeeId,
            'effective_date'        => $effectiveDate,
            'basic_salary'          => round($basic, 2),
            'gross_salary'          => round($grossSalary, 2),
            'total_deductions'      => round($totalDeductions, 2),
            'net_salary'            => round($netSalary, 2),
            'total_employer_cost'   => round($totalEmployerCost, 2),
            'total_ctc'             => round($totalCtc, 2),
            'annual_ctc'            => round($annualCtc, 2),
            'components'            => $unifiedComponents,
            'earnings'              => $resolvedEarnings,
            'deductions'            => $allDeductions,
            'employer_contributions'=> $employerContributions,
            'overtime_policy'       => $otPolicyResult,
            'statutory_policies'    => [
                'provident_fund' => $pfResult,
                'income_tax'     => $taxResult,
                'gratuity'       => $gratuityResult,
                'overtime'       => $otPolicyResult,
            ]
        ];
    }

    /**
     * Normalize incoming component items or retrieve defaults/template
     */
    protected function normalizeInputComponents(array $components, ?string $structureId, string $companyId, float $basic): array
    {
        if (empty($components) && !empty($structureId)) {
            $rawItems = $this->structureItemModel->where('structure_id', $structureId)->orderBy('sort_order', 'ASC')->findAll();
            $components = [];
            foreach ($rawItems as $it) {
                $compDef = $this->componentModel->find($it['component_id']);
                $compIsActive = $compDef ? ((($compDef['status'] ?? 'Active') === 'Active') && (isset($compDef['is_active']) ? (int)(bool)$compDef['is_active'] === 1 : true)) : false;
                if (!$compIsActive) {
                    continue;
                }
                $rawEnabled = $it['is_enabled'] ?? null;
                $isEnabled = ($rawEnabled === null) ? true : ($rawEnabled !== false && $rawEnabled !== 0 && $rawEnabled !== '0' && $rawEnabled !== 'false');
                $components[] = [
                    'component_id'     => $it['component_id'],
                    'component_code'   => $compDef['code'] ?? '',
                    'name'             => $compDef['name'] ?? '',
                    'type'             => $compDef['type'] ?? 'earning',
                    'calculation_type' => $it['calculation_type'] ?? 'fixed',
                    'calculation_base' => $it['calculation_base'] ?? 'Basic Salary',
                    'rate_or_amount'   => (float)($it['default_value'] ?? $it['rate_or_amount'] ?? 0),
                    'formula'          => $it['custom_formula'] ?? '',
                    'is_enabled'       => $isEnabled,
                    'is_taxable'       => (int)($it['is_taxable'] ?? 1),
                    'is_statutory'     => (int)($it['is_statutory'] ?? 0),
                    'sort_order'       => (int)($it['sort_order'] ?? 1),
                    'status'           => 'Active',
                    'is_active'        => 1,
                ];
            }
        }

        if (empty($components)) {
            $taxRuleCompany = RuleResolver::resolveForCompany($companyId, 'TAX', $effectiveDate);
            $hraRate = (float)$taxRuleCompany->get('house_rent_ratio_pct');
            $medRate = (float)$taxRuleCompany->get('medical_ratio_pct');
            $convAmt = (float)$taxRuleCompany->get('conveyance_monthly');

            // Standard baseline components from authoritative TAX rule definition
            $components = [
                [
                    'component_id'     => 'comp-basic',
                    'component_code'   => 'BASIC',
                    'name'             => 'Basic Salary',
                    'type'             => 'earning',
                    'calculation_type' => 'fixed',
                    'calculation_base' => 'Basic Salary',
                    'rate_or_amount'   => $basic,
                    'amount'           => $basic,
                    'formula'          => '',
                    'is_enabled'       => true,
                    'is_taxable'       => 1,
                    'is_statutory'     => 0,
                    'sort_order'       => 1
                ],
                [
                    'component_id'     => 'comp-hra',
                    'component_code'   => 'HRA',
                    'name'             => 'House Rent Allowance',
                    'type'             => 'earning',
                    'calculation_type' => 'percentage',
                    'calculation_base' => 'Basic Salary',
                    'rate_or_amount'   => $hraRate,
                    'formula'          => '',
                    'is_enabled'       => true,
                    'is_taxable'       => 1,
                    'is_statutory'     => 0,
                    'sort_order'       => 2
                ],
                [
                    'component_id'     => 'comp-med',
                    'component_code'   => 'MED',
                    'name'             => 'Medical Allowance',
                    'type'             => 'earning',
                    'calculation_type' => 'percentage',
                    'calculation_base' => 'Basic Salary',
                    'rate_or_amount'   => $medRate,
                    'formula'          => '',
                    'is_enabled'       => true,
                    'is_taxable'       => 1,
                    'is_statutory'     => 0,
                    'sort_order'       => 3
                ],
                [
                    'component_id'     => 'comp-conv',
                    'component_code'   => 'CONV',
                    'name'             => 'Conveyance Allowance',
                    'type'             => 'earning',
                    'calculation_type' => 'fixed',
                    'calculation_base' => 'Basic Salary',
                    'rate_or_amount'   => $convAmt,
                    'formula'          => '',
                    'is_enabled'       => true,
                    'is_taxable'       => 1,
                    'is_statutory'     => 0,
                    'sort_order'       => 4
                ],
            ];
        }

        // Ensure BASIC component is synchronized
        $hasBasic = false;
        foreach ($components as &$c) {
            $code = strtoupper(trim((string)($c['component_code'] ?? $c['code'] ?? '')));
            if ($code === 'BASIC') {
                $hasBasic = true;
                $c['type'] = 'earning';
                $c['rate_or_amount'] = $basic;
                $c['amount'] = $basic;
                $c['is_enabled'] = true;
                break;
            }
        }
        unset($c);

        if (!$hasBasic) {
            array_unshift($components, [
                'component_id'     => 'comp-basic',
                'component_code'   => 'BASIC',
                'name'             => 'Basic Salary',
                'type'             => 'earning',
                'calculation_type' => 'fixed',
                'calculation_base' => 'Basic Salary',
                'rate_or_amount'   => $basic,
                'amount'           => $basic,
                'formula'          => '',
                'is_enabled'       => true,
                'is_taxable'       => 1,
                'is_statutory'     => 0,
                'sort_order'       => 1
            ]);
        }

        // Filter out any overtime components and inactive components from base structure components.
        // OT is policy-driven (RuleResolver OVERTIME domain) and calculated via OvertimeCalculationService.
        // Inactive components must NOT calculate or be in working mode.
        $filtered = [];
        foreach ($components as $c) {
            $code = strtoupper(trim((string)($c['component_code'] ?? $c['code'] ?? '')));
            $name = trim((string)($c['name'] ?? $c['component_name'] ?? ''));
            $calcType = strtolower((string)($c['calculation_type'] ?? ''));
            if ($calcType === 'overtime based' || in_array($code, ['OT', 'OVERTIME'], true) || stripos($name, 'overtime') !== false) {
                continue;
            }

            // Check if explicitly marked inactive
            $isInactive = (isset($c['status']) && strtolower(trim((string)$c['status'])) === 'inactive')
                || (isset($c['is_active']) && ($c['is_active'] === false || $c['is_active'] === 0 || $c['is_active'] === '0' || $c['is_active'] === 'false'))
                || (isset($c['master_is_active']) && $c['master_is_active'] === false);

            // Check master component definition if component_id or code is known
            if (!$isInactive) {
                $targetCompId = $c['component_id'] ?? $c['id'] ?? null;
                $compDef = null;
                if (!empty($targetCompId)) {
                    $compDef = $this->componentModel->find($targetCompId);
                }
                if (!$compDef && !empty($code)) {
                    $compDef = $this->componentModel->where('company_id', $companyId)->where('code', $code)->first();
                }
                if ($compDef && ((($compDef['status'] ?? 'Active') === 'Inactive') || (isset($compDef['is_active']) && empty($compDef['is_active'])))) {
                    $isInactive = true;
                }
            }

            if ($isInactive) {
                continue;
            }

            $filtered[] = $c;
        }

        return $filtered;
    }

    /**
     * Resolve Earning Components & Gross Salary
     */
    protected function resolveEarnings(array $components, float $basic): array
    {
        $earnings = [];
        $gross = 0.0;
        $varPool = [
            'BASIC'        => $basic,
            'BASIC_SALARY' => $basic,
            'GROSS'        => $basic,
            'GROSS_SALARY' => $basic,
        ];

        // Pass 1: Resolve fixed and Basic-relative percentages
        foreach ($components as $c) {
            $type = strtolower((string)($c['type'] ?? 'earning'));
            if ($type !== 'earning') {
                continue;
            }

            $code = strtoupper(trim((string)($c['component_code'] ?? $c['code'] ?? '')));
            $name = trim((string)($c['name'] ?? $c['component_name'] ?? ''));
            $calcType = strtolower((string)($c['calculation_type'] ?? 'fixed'));

            // Exclude overtime from standard salary structure earnings
            if ($calcType === 'overtime based' || in_array($code, ['OT', 'OVERTIME'], true) || stripos($name, 'overtime') !== false) {
                continue;
            }

            $rateOrAmt = (float)($c['rate_or_amount'] ?? $c['default_value'] ?? 0);
            $rawEnabled = $c['is_enabled'] ?? null;
            $isEnabled = ($rawEnabled === null) ? true : ($rawEnabled !== false && $rawEnabled !== 0 && $rawEnabled !== '0' && $rawEnabled !== 'false');

            $amt = 0.0;
            if ($code === 'BASIC') {
                $amt = $basic;
            } elseif ($isEnabled) {
                if ($calcType === 'fixed') {
                    $amt = $rateOrAmt;
                } elseif ($calcType === 'percentage') {
                    $baseName = $c['calculation_base'] ?? 'Basic Salary';
                    if ($baseName !== 'Gross Salary') {
                        $amt = round($basic * ($rateOrAmt / 100.0), 2);
                    }
                } elseif ($calcType === 'formula' && !empty($c['formula'])) {
                    $amt = (float)PayrollCalculator::evaluateSalaryFormula($c['formula'], $varPool);
                } else {
                    $amt = $rateOrAmt;
                }
            }

            $entry = array_merge($c, [
                'component_code' => $code,
                'type'           => 'earning',
                'amount'         => round($amt, 2),
                'is_enabled'     => $isEnabled,
                'is_statutory'   => false,
                'is_readonly'    => false,
            ]);

            $earnings[] = $entry;
            $varPool[$code] = $amt;
            if ($isEnabled) {
                $gross += $amt;
            }
        }

        $varPool['GROSS'] = $gross;
        $varPool['GROSS_SALARY'] = $gross;

        // Pass 2: Re-evaluate any percentage based on Gross Salary
        foreach ($earnings as &$e) {
            $calcType = strtolower((string)($e['calculation_type'] ?? 'fixed'));
            $baseName = $e['calculation_base'] ?? 'Basic Salary';
            $rawEEnabled = $e['is_enabled'] ?? null;
            $isEEnabled = ($rawEEnabled === null) ? true : ($rawEEnabled !== false && $rawEEnabled !== 0 && $rawEEnabled !== '0' && $rawEEnabled !== 'false');
            if ($isEEnabled && $calcType === 'percentage' && $baseName === 'Gross Salary') {
                $rate = (float)($e['rate_or_amount'] ?? 0);
                $oldAmt = (float)($e['amount'] ?? 0);
                $newAmt = round($gross * ($rate / 100.0), 2);
                $gross = $gross - $oldAmt + $newAmt;
                $e['amount'] = $newAmt;
            }
        }
        unset($e);

        $taxableGross = 0.0;
        foreach ($earnings as $e) {
            $rawEEnabled = $e['is_enabled'] ?? null;
            $isEnabled = ($rawEEnabled === null) ? true : ($rawEEnabled !== false && $rawEEnabled !== 0 && $rawEEnabled !== '0' && $rawEEnabled !== 'false');
            $isTaxable = isset($e['is_taxable']) ? ((int)$e['is_taxable'] === 1 || $e['is_taxable'] === true) : true;
            if ($isEnabled && $isTaxable) {
                $taxableGross += (float)($e['amount'] ?? 0);
            }
        }

        return [
            'gross_salary'  => round($gross, 2),
            'taxable_gross' => round($taxableGross, 2),
            'earnings'      => $earnings,
        ];
    }

    /**
     * Resolve Provident Fund Statutory Policy
     */
    protected function resolveProvidentFund(
        ?string $companyId,
        string $effectiveDate,
        float $basic,
        float $gross,
        array $pfSettings,
        ?array $employee,
        array $earningsMap = []
    ): array
    {
        if (empty($companyId)) {
            throw new RuleNotConfiguredException("Company ID is required to resolve provident fund policy.");
        }

        $isExplicitEligible = isset($pfSettings['is_eligible'])
            ? (bool)$pfSettings['is_eligible']
            : (isset($pfSettings['eligible'])
                ? (bool)$pfSettings['eligible']
                : (!empty($employee['is_pf_applicable']) || ($employee['pf_status'] ?? '') === 'Enrolled'));

        $pfSettings['eligible'] = $isExplicitEligible;
        $pfSettings['is_eligible'] = $isExplicitEligible;

        $employeeData = array_merge($employee ?? [], [
            'company_id'       => $companyId,
            'pf_settings'      => $pfSettings,
            'is_pf_applicable' => $isExplicitEligible ? 1 : 0,
            'pf_status'        => $isExplicitEligible ? 'Enrolled' : ($employee['pf_status'] ?? 'Not Enrolled'),
        ]);

        if (empty($earningsMap)) {
            $earningsMap = [
                'Basic'        => $basic,
                'Basic_Salary' => $basic,
                'Gross'        => $gross,
                'Gross_Salary' => $gross,
            ];
        } else {
            if (!isset($earningsMap['Basic'])) {
                $earningsMap['Basic'] = $basic;
            }
            if (!isset($earningsMap['Basic_Salary'])) {
                $earningsMap['Basic_Salary'] = $basic;
            }
            if (!isset($earningsMap['Gross'])) {
                $earningsMap['Gross'] = $gross;
            }
            if (!isset($earningsMap['Gross_Salary'])) {
                $earningsMap['Gross_Salary'] = $gross;
            }
        }

        $pfCalc = new \App\Services\Pf\PfCalculator();
        $calcContext = [
            'company_id'     => $companyId,
            'employee'       => $employeeData,
            'effective_date' => $effectiveDate,
            'basic'          => $basic,
            'gross'          => $gross,
            'earnings'       => $earningsMap,
        ];
        if (!empty($pfSettings['is_override'])) {
            $ovRates = [];
            if (isset($pfSettings['employee_rate'])) {
                $ovRates['employee_rate'] = (float)$pfSettings['employee_rate'];
            }
            if (isset($pfSettings['employer_rate'])) {
                $ovRates['employer_rate'] = (float)$pfSettings['employer_rate'];
            }
            if (!empty($ovRates)) {
                $calcContext['rule_override'] = $ovRates;
            }
        }
        try {
            $statutoryPf = $pfCalc->calculate($calcContext);
        } catch (\InvalidArgumentException $e) {
            log_message('error', 'SalaryPolicyResolver PF formula calculation error: ' . $e->getMessage());
            throw $e;
        }

        $isEligible = (bool)($statutoryPf['is_eligible'] ?? false);
        if (!$isEligible && $isExplicitEligible) {
            $isEligible = true;
        }

        $isOverride = !empty($pfSettings['is_override']) || !empty($pfSettings['pf_is_override']);
        $overrideReason = trim((string)($pfSettings['override_reason'] ?? $pfSettings['reason'] ?? ''));

        $policyName = 'Company Standard Provident Fund Policy';
        $versionNum = 1;
        $effectiveFrom = $effectiveDate;
        $sourceBadge = "Source: Provident Fund (Single Rule Store)";

        $empRateApplied = (float)($statutoryPf['employee_rate_applied'] ?? 0.00);
        $empDedApplied = (float)($statutoryPf['employee_deduction'] ?? 0.00);
        $coRateApplied = (float)($statutoryPf['employer_rate_applied'] ?? 0.00);
        $coContribApplied = (float)($statutoryPf['employer_contribution'] ?? 0.00);

        return [
            'is_active'             => $isEligible,
            'is_eligible'           => $isEligible,
            'policy_name'           => $policyName,
            'policy_version'        => $versionNum,
            'policy_effective_date' => $effectiveFrom,
            'source_badge'          => $sourceBadge,
            'is_override'           => $isOverride,
            'override_reason'       => $isOverride ? $overrideReason : null,
            'calculation_type'      => (string)($statutoryPf['calculation_type'] ?? $statutoryPf['contribution_type']),
            'calculation_base'      => (string)$statutoryPf['calculation_basis'],
            'rate_or_amount'        => $empRateApplied,
            'employer_rate'         => $coRateApplied,
            'employee_deduction'    => $empDedApplied,
            'employer_contribution' => $coContribApplied,
            'snapshot'              => $statutoryPf['snapshot'] ?? null,
            'rules_snapshot'        => $statutoryPf['rules_snapshot'] ?? [],
        ];
    }

    /**
     * Resolve Income Tax (TDS) Statutory Policy
     * Single Source of Truth: RuleResolver (TAX domain) with Bangladesh fiscal year (Jul-Jun)
     */
    public function resolveIncomeTax(
        string $companyId,
        string $effectiveDate,
        float $basic,
        float $taxableGross,
        array $taxSettings,
        ?array $employee,
        array $context = []
    ): array
    {
        // 1. Bangladesh Fiscal Year (Jul 1 - Jun 30)
        $taxYear = RuleResolver::getFiscalYear($effectiveDate);

        // 2. Employee Tax Facts: Category and TIN
        $category = trim((string)($taxSettings['category'] ?? $taxSettings['tax_category'] ?? $employee['tax_category'] ?? $employee['category'] ?? 'General'));
        if ($category === '') {
            $category = (($employee['gender'] ?? '') === 'Female') ? 'Female' : 'General';
        }
        $gender = $employee['gender'] ?? 'All';
        $tin = trim((string)($taxSettings['tin'] ?? $taxSettings['tax_identification_number'] ?? $employee['tax_identification_number'] ?? $employee['tin'] ?? ''));

        // 3. Optional Override: Exempt / Fixed with reason
        $resolvedTaxRule = RuleResolver::resolveStatic($companyId, 'TAX', $effectiveDate, $employee ?? []);
        $taxRuleMode = (string)$resolvedTaxRule->get('calculation_mode');
        $calcMode = !empty($taxSettings['calculation_mode']) 
            ? (string)$taxSettings['calculation_mode'] 
            : (!empty($taxSettings['mode']) ? (string)$taxSettings['mode'] : $taxRuleMode);
        $isOverride = in_array($calcMode, ['Exempt', 'Fixed'], true) || (!empty($taxSettings['is_override']) && $calcMode !== 'Auto');
        $overrideReason = trim((string)($taxSettings['override_reason'] ?? $taxSettings['reason'] ?? ''));

        $monthlyTax = 0.00;
        $calcTax = null;
        $activeRule = null;
        $rulesSnapshot = [];
        $annualTaxAmount = null;
        $annualTaxYear = null;
        $warnings = [];
        $autoReference = null;

        $buildTaxContext = function() use ($context, $basic, $taxableGross, $companyId, $employee, $category, $gender, $taxYear, $tin, $effectiveDate) {
            $taxableBasic = 0.0;
            $taxableHouseRent = 0.0;
            $taxableMedical = 0.0;
            $taxableConveyance = 0.0;
            $taxableOther = 0.0;

            if (!empty($context['earnings']) && is_array($context['earnings'])) {
                foreach ($context['earnings'] as $ea) {
                    $isTaxable = isset($ea['is_taxable']) ? ((int)$ea['is_taxable'] === 1 || $ea['is_taxable'] === true) : true;
                    if (!$isTaxable || empty($ea['is_enabled'])) continue;
                    $code = strtoupper(trim((string)($ea['component_code'] ?? $ea['code'] ?? '')));
                    $name = strtolower(trim((string)($ea['name'] ?? '')));
                    $amt = (float)($ea['amount'] ?? 0.0);

                    if ($code === 'BASIC' || str_contains($name, 'basic')) {
                        $taxableBasic += $amt;
                    } elseif (in_array($code, ['HRA', 'HOUSE_RENT'], true) || str_contains($name, 'house rent')) {
                        $taxableHouseRent += $amt;
                    } elseif (in_array($code, ['MED', 'MEDICAL'], true) || str_contains($name, 'medical')) {
                        $taxableMedical += $amt;
                    } elseif (in_array($code, ['CONV', 'TRANSPORT', 'TRAVEL'], true) || str_contains($name, 'conveyance') || str_contains($name, 'transport')) {
                        $taxableConveyance += $amt;
                    } else {
                        $taxableOther += $amt;
                    }
                }
            } else {
                $taxableBasic = $basic;
                $taxableHouseRent = $context['house_rent'] ?? 0.0;
                $taxableMedical = $context['medical'] ?? 0.0;
                $taxableConveyance = $context['conveyance'] ?? 0.0;
                $taxableOther = $context['other_allowances'] ?? 0.0;
            }

            return array_merge([
                'company_id'      => $companyId,
                'employee'        => $employee ?? [],
                'employee_id'     => $employee['id'] ?? null,
                'basic'           => $taxableBasic > 0 ? $taxableBasic : $basic,
                'taxable_gross'   => $taxableGross,
                'gross'           => $taxableGross,
                'house_rent'      => $taxableHouseRent,
                'medical'         => $taxableMedical,
                'conveyance'      => $taxableConveyance,
                'other_allowances'=> $taxableOther,
                'category'        => $category,
                'gender'          => $gender,
                'tax_year'        => $taxYear,
                'tin'             => $tin,
                'effective_date'  => $effectiveDate,
            ], $context);
        };

        if ($calcMode === 'Exempt') {
            $monthlyTax = 0.00;
            $policyName = 'Statutory Income Tax (Exempt Override)';
            $sourceBadge = !empty($overrideReason)
                ? "Source: Tax Exempt Override ({$overrideReason})"
                : "Source: Tax Exempt Override";
            
            try {
                $resolvedRule = RuleResolver::resolveStatic($companyId, 'TAX', $effectiveDate, $employee ?? []);
                $rulesSnapshot = ['TAX' => $resolvedRule->snapshot()];
            } catch (\Throwable $e) {
                // Keep empty snapshot if unconfigured
            }
        } elseif ($calcMode === 'Fixed' || ($isOverride && $calcMode !== 'Auto')) {
            $annualTaxRaw = $taxSettings['annual_tax_amount'] ?? null;
            if ($annualTaxRaw !== null && $annualTaxRaw !== '' && is_numeric($annualTaxRaw)) {
                $monthlyTax = round(max(0.0, (float)$annualTaxRaw) / 12, 2);          // annual / 12
                $annualTaxAmount = round(max(0.0, (float)$annualTaxRaw), 2);
            } else {                                                                  // legacy rows: monthly amount only
                $monthlyTax = (float)($taxSettings['custom_tax_amount'] ?? $taxSettings['fixed_amount'] ?? $taxSettings['amount'] ?? $taxSettings['fixed_tax_amount'] ?? 0.0);
                $annualTaxAmount = round($monthlyTax * 12, 2);
            }
            $annualTaxYear = $taxSettings['annual_tax_year'] ?? null;
            if (!empty($annualTaxYear) && (string)$annualTaxYear !== (string)$taxYear) {
                $warnings[] = "Annual tax amount was set for FY {$annualTaxYear} but this payroll is FY {$taxYear}. Review the employee's annual tax amount.";
            }

            try {
                // Same context as the Auto branch, but force Auto mode so TaxCalculator runs the slabs.
                $taxContextForAuto = $buildTaxContext();
                $refCtx = array_merge($taxContextForAuto, ['calculation_mode' => 'Auto']);
                $ref = RuleResolver::calculateTax($taxableGross, $refCtx);
                $autoReference = [
                    'monthly_tax'   => (float)($ref['monthly_tax_deduction'] ?? 0.0),
                    'annual_tax'    => (float)($ref['annual_tax_liability'] ?? 0.0),
                    'taxable_gross' => round($taxableGross, 2),
                ];
            } catch (\Throwable $e) {
                $autoReference = null;
            }

            $policyName = 'Statutory Income Tax (Fixed TDS Override)';
            $sourceBadge = !empty($overrideReason)
                ? "Source: Fixed TDS Override ({$overrideReason})"
                : "Source: Fixed TDS Override";

            try {
                $resolvedRule = RuleResolver::resolveStatic($companyId, 'TAX', $effectiveDate, $employee ?? []);
                $rulesSnapshot = ['TAX' => $resolvedRule->snapshot()];
            } catch (\Throwable $e) {
                // Keep empty snapshot if unconfigured
            }
        } else {
            // Dynamic Progressive Tax Calculation via RuleResolver TAX (Single Source of Truth)
            $taxContext = $buildTaxContext();
            $calcTax = RuleResolver::calculateTax($taxableGross, $taxContext);
            $monthlyTax = (float)($calcTax['monthly_tax_deduction'] ?? 0.0);
            $rulesSnapshot = $calcTax['rules_snapshot'] ?? [];

            $ruleName = $calcTax['rule_name'] ?? 'Statutory Progressive Income Tax (National)';
            $policyName = $ruleName;
            $sourceBadge = "Source: {$ruleName} (FY {$taxYear})";
        }

        return [
            'is_active'             => true,
            'policy_name'           => $policyName,
            'policy_version'        => 1,
            'policy_effective_date' => $effectiveDate,
            'source_badge'          => $sourceBadge,
            'tax_year'              => $taxYear,
            'tax_category'          => $category,
            'tin'                   => $tin,
            'calculation_mode'      => $calcMode,
            'is_override'           => $isOverride,
            'override_reason'       => $isOverride ? $overrideReason : null,
            'amount'                => round($monthlyTax, 2),
            'taxable_gross'         => round($taxableGross, 2),
            'rule'                  => $activeRule,
            'breakdown'             => $calcTax,
            'rules_snapshot'        => $rulesSnapshot,
            'annual_tax_amount'     => $annualTaxAmount,
            'annual_tax_year'       => $annualTaxYear,
            'warnings'              => $warnings,
            'auto_reference'        => $autoReference,
        ];
    }

    /**
     * Resolve Statutory Gratuity Provision
     */
    protected function resolveGratuity(string $companyId, string $effectiveDate, float $basic, float $gross, array $gratuitySettings, ?array $employee): array
    {
        $calculator = new \App\Services\Gratuity\GratuityCalculator();
        $res = $calculator->calculateAccrual(
            $companyId,
            $employee ?? [],
            $effectiveDate,
            $basic,
            $gross,
            ['gratuity_settings' => $gratuitySettings]
        );

        return [
            'is_active'             => true,
            'is_eligible'           => $res['is_eligible'] ?? false,
            'policy_name'           => $res['policy_name'] ?? 'Statutory Gratuity Provision Policy',
            'policy_version'        => $res['policy_version'] ?? 1,
            'policy_effective_date' => $res['policy_effective_date'] ?? $effectiveDate,
            'source_badge'          => $res['source_badge'] ?? '',
            'is_override'           => $res['is_override'] ?? false,
            'override_reason'       => $res['override_reason'] ?? null,
            'amount'                => round((float)($res['monthly_provision_accrual'] ?? 0.0), 2),
            'rate_percentage'       => $res['rate_percentage'] ?? 0.0,
            'multiplier_days_per_year' => (float)$res['multiplier_days_per_year'],
            'month_divisor_days'       => (int)$res['month_divisor_days'],
            'rule'                     => [
                'multiplier_days_per_year' => (float)$res['multiplier_days_per_year'],
                'month_divisor_days'       => (int)$res['month_divisor_days'],
            ],
            'details'               => $res,
        ];
    }

    /**
     * Resolve Non-Statutory Deductions
     */
    protected function resolveNonStatutoryDeductions(array $components, float $basic, float $gross): array
    {
        $deductions = [];

        foreach ($components as $c) {
            $type = strtolower((string)($c['type'] ?? ''));
            if ($type !== 'deduction') {
                continue;
            }

            $code = strtoupper(trim((string)($c['component_code'] ?? $c['code'] ?? '')));
            // Skip statutory PF and Tax as they are resolved with authoritative badges
            if ($code === 'EMP_PF' || $code === 'PF' || $code === 'TDS' || $code === 'TAX') {
                continue;
            }

            $calcType = strtolower((string)($c['calculation_type'] ?? 'fixed'));
            $rateOrAmt = (float)($c['rate_or_amount'] ?? $c['default_value'] ?? 0);
            $rawEnabled = $c['is_enabled'] ?? null;
            $isEnabled = ($rawEnabled === null) ? true : ($rawEnabled !== false && $rawEnabled !== 0 && $rawEnabled !== '0' && $rawEnabled !== 'false');

            $amt = 0.0;
            if ($isEnabled) {
                if ($calcType === 'fixed') {
                    $amt = $rateOrAmt;
                } elseif ($calcType === 'percentage') {
                    $base = ($c['calculation_base'] ?? 'Basic Salary') === 'Gross Salary' ? $gross : $basic;
                    $pct = normalize_percentage($rateOrAmt);
                    $amt = round($base * ($pct / 100.0), 2);
                } elseif ($calcType === 'formula' && !empty($c['formula'])) {
                    $amt = (float)PayrollCalculator::evaluateSalaryFormula($c['formula'], ['BASIC' => $basic, 'GROSS' => $gross]);
                } else {
                    $amt = $rateOrAmt;
                }
            }

            $deductions[] = array_merge($c, [
                'component_code' => $code,
                'type'           => 'deduction',
                'amount'         => round($amt, 2),
                'is_enabled'     => $isEnabled,
                'is_statutory'   => false,
                'is_readonly'    => false,
            ]);
        }

        return ['deductions' => $deductions];
    }
}
