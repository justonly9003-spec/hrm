<?php

namespace App\Services\Gratuity;

use App\Services\Rules\ResolvedRule;
use App\Services\Rules\RuleResolver;
use DateTime;
use InvalidArgumentException;

class GratuityCalculator
{
    protected RuleResolver $resolver;

    public function __construct(?RuleResolver $resolver = null)
    {
        $this->resolver = $resolver ?? new RuleResolver();
    }

    /**
     * Universal entry point matching standard context array.
     *
     * @param array{
     *   company_id: string,
     *   employee: array|string,
     *   effective_date?: string,
     *   date?: string,
     *   basic: float|numeric,
     *   gross?: float|numeric,
     *   separation_type?: string,
     *   options?: array,
     *   house_rent?: float|numeric
     * } $context
     * @return array
     */
    public function calculate(array $context): array
    {
        $companyId = trim((string)($context['company_id'] ?? ''));
        if ($companyId === '') {
            throw new InvalidArgumentException("company_id is required for Gratuity calculation");
        }

        $employee = $context['employee'] ?? [];
        $date     = (string)($context['effective_date'] ?? $context['date'] ?? date('Y-m-d'));
        $basic    = (float)($context['basic'] ?? 0.0);
        $gross    = isset($context['gross']) ? (float)$context['gross'] : null;
        $sepType  = isset($context['separation_type']) ? (string)$context['separation_type'] : null;

        return $this->performCalculation($companyId, $employee, $date, $basic, $gross, $sepType, $context);
    }

    /**
     * Calculate monthly provision accrual for payroll run.
     */
    public function calculateAccrual(
        string $companyId,
        array|string $employee,
        string $date,
        float $basic,
        ?float $gross = null,
        array $context = []
    ): array {
        return $this->performCalculation($companyId, $employee, $date, $basic, $gross, null, $context);
    }

    /**
     * Calculate lump sum gratuity and exit entitlements for final settlement.
     */
    public function calculateFinalSettlement(
        string $companyId,
        array|string $employee,
        string $lastWorkingDay,
        float $lastBasic,
        ?string $separationType = null,
        ?float $lastGross = null,
        ?array $options = null
    ): array {
        $context = is_array($options) ? $options : [];
        return $this->performCalculation($companyId, $employee, $lastWorkingDay, $lastBasic, $lastGross, $separationType, $context);
    }

    /**
     * Internal calculation logic strictly driven by RuleResolver (domain: GRATUITY).
     */
    protected function performCalculation(
        string $companyId,
        array|string $employee,
        string $date,
        float $basic,
        ?float $gross,
        ?string $separationType,
        array $context
    ): array {
        $date = substr(trim($date), 0, 10);
        if ($date === '') {
            $date = date('Y-m-d');
        }

        // 1. Resolve effective GRATUITY rule for this employee & date
        $rule = $this->resolver->resolve($companyId, 'GRATUITY', $date, $employee);

        $rulesSnapshot = [
            'GRATUITY' => [
                'layers' => $rule->layers(),
                'hash'   => $rule->sha1(),
            ],
        ];

        // 2. Read parameters strictly from ResolvedRule (NO literal fallbacks!)
        $enabled              = (bool)$rule->get('enabled');
        $minYears             = (float)$rule->get('eligibility_min_years');
        $calcBasis            = (string)$rule->get('calculation_basis');
        $daysPerYear          = (float)$rule->get('days_per_year');
        $daysPerYearAfter10y  = $rule->has('days_per_year_after_10y')
            ? (float)$rule->get('days_per_year_after_10y')
            : (float)$rule->get('days_per_year');
        $divisorDaysRaw       = $rule->get('divisor_days');
        $roundingRule         = (string)$rule->get('rounding_rule');
        $maxCeiling           = (float)$rule->get('max_ceiling');
        $taxExemptionLimit    = (float)$rule->get('tax_exemption_limit');
        $taxRateOnExcess      = (float)$rule->get('tax_rate_on_excess');
        $serviceEndInclusive  = (bool)$rule->get('service_end_inclusive');
        $provisionMode        = (string)$rule->get('provision_mode');
        $provisionStart       = (string)$rule->get('provision_start');
        $eligibleEmpTypes     = (array)$rule->get('eligible_employment_types');
        $separationRules      = (array)$rule->get('separation_rules');
        $customMonthlyAmount  = $rule->has('custom_monthly_amount') ? $rule->get('custom_monthly_amount') : null;

        // If divisor_days is null, resolve from PAYROLL_BASICS domain
        if ($divisorDaysRaw === null) {
            $basicsRule = $this->resolver->resolve($companyId, 'PAYROLL_BASICS', $date, $employee);
            $divisorDays = (int)$basicsRule->get('daily_rate_divisor');
            $rulesSnapshot['PAYROLL_BASICS'] = [
                'layers' => $basicsRule->layers(),
                'hash'   => $basicsRule->sha1(),
            ];
        } else {
            $divisorDays = (int)$divisorDaysRaw;
        }

        // 3. Service duration from joining date
        $joiningDate = null;
        if (function_exists('employee_joining_date')) {
            $joiningDate = employee_joining_date(is_array($employee) ? $employee : ['id' => $employee]);
        }
        if (!$joiningDate && is_array($employee)) {
            $joiningDate = $employee['joining_date'] ?? $employee['hire_date'] ?? $employee['date_of_joining'] ?? null;
        }

        $y = 0;
        $m = 0;
        $d = 0;
        $serviceYears = 0.0;
        $hasJoiningDate = !empty($joiningDate);

        if ($hasJoiningDate) {
            $start = new DateTime((string)$joiningDate);
            $end   = new DateTime($date);

            if ($serviceEndInclusive) {
                $endInterval = clone $end;
                $endInterval->modify('+1 day');
                $interval = $start->diff($endInterval);
            } else {
                $interval = $start->diff($end);
            }

            $y = (int)$interval->y;
            $m = (int)$interval->m;
            $d = (int)$interval->d;
            $serviceYears = (float)($y + ($m / 12) + ($d / 365));
        }

        // 4. Gating and Eligibility Evaluation
        $isEligible = true;
        $reason = null;

        if (!$hasJoiningDate) {
            $isEligible = false;
            $reason = 'Joining date is missing for gratuity qualification';
        }

        // Employment type gating
        if ($isEligible && !empty($eligibleEmpTypes)) {
            $empType = is_array($employee)
                ? ($employee['employment_type'] ?? $employee['employment_type_name'] ?? $employee['employment_type_id'] ?? null)
                : null;
            if ($empType !== null && !in_array($empType, $eligibleEmpTypes, true)) {
                $isEligible = false;
                $reason = "Employment type '{$empType}' is not eligible for gratuity";
            }
        }

        // Separation rules (if separation type specified)
        if ($isEligible && !empty($separationType) && !empty($separationRules)) {
            foreach ($separationRules as $sRule) {
                if (isset($sRule['separation_type']) && strcasecmp((string)$sRule['separation_type'], $separationType) === 0) {
                    if (isset($sRule['eligible']) && !(bool)$sRule['eligible']) {
                        $isEligible = false;
                        $reason = "Separation type '{$separationType}' is not eligible for gratuity";
                    }
                    if (isset($sRule['min_years_override']) && $sRule['min_years_override'] !== null) {
                        $minYears = (float)$sRule['min_years_override'];
                    }
                    break;
                }
            }
        }

        // Minimum service years requirement
        if ($isEligible) {
            if (!$enabled) {
                $isEligible = false;
                $reason = 'Gratuity policy is disabled';
            } elseif ($serviceYears < $minYears) {
                $isEligible = false;
                $reason = "Service period (" . number_format($serviceYears, 2) . " years) is less than required minimum ({$minYears} years)";
            } else {
                $reason = 'Eligible for statutory gratuity';
            }
        }

        // 5. Service Rounding
        switch ($roundingRule) {
            case 'RoundUpSixMonths':
                $roundedYears = ($m >= 6) ? ($y + 1) : $y;
                break;
            case 'ExactFraction':
                $roundedYears = round($serviceYears, 2);
                break;
            case 'FullYearsOnly':
                $roundedYears = $y;
                break;
            case 'RoundHalfYear':
                if ($m >= 9) {
                    $roundedYears = $y + 1.0;
                } elseif ($m >= 3) {
                    $roundedYears = $y + 0.5;
                } else {
                    $roundedYears = (float)$y;
                }
                break;
            default:
                $roundedYears = $y;
                break;
        }

        // 6. Calculation Basis Amount
        switch ($calcBasis) {
            case 'Gross':
                $basisAmount = $gross !== null ? (float)$gross : (float)$basic;
                break;
            case 'Basic_HouseRent':
                $houseRent   = (float)($context['house_rent'] ?? 0.0);
                $basisAmount = (float)($basic + $houseRent);
                break;
            case 'Basic':
            default:
                $basisAmount = (float)$basic;
                break;
        }

        // 7. Daily rate and two-slab annual multipliers
        $dailyRate              = $divisorDays > 0 ? ($basisAmount / $divisorDays) : 0.0;
        $annualMultiplierTier1  = $dailyRate * $daysPerYear;
        $annualMultiplierTier2  = $dailyRate * $daysPerYearAfter10y;

        // 8. Service split across slabs (Tier 1: <= 10 yrs @ days_per_year, Tier 2: > 10 yrs @ days_per_year_after_10y)
        $totalGratuityYears = $isEligible ? (float)$roundedYears : 0.0;
        if ($totalGratuityYears > 10.0) {
            $tier1Years = 10.0;
            $tier2Years = $totalGratuityYears - 10.0;
        } else {
            $tier1Years = $totalGratuityYears;
            $tier2Years = 0.0;
        }

        $tier1Amount = $tier1Years * $annualMultiplierTier1;
        $tier2Amount = $tier2Years * $annualMultiplierTier2;

        $uncappedAmount      = round($tier1Amount + $tier2Amount, 2);
        $isCapped            = ($maxCeiling > 0 && $uncappedAmount > $maxCeiling);
        $finalGratuityAmount = $isEligible ? ($isCapped ? $maxCeiling : $uncappedAmount) : 0.00;

        // 9. Gratuity Tax Exemption & Deduction on Excess
        $taxableGratuityExcess = 0.00;
        $gratuityTaxDeduction  = 0.00;
        if ($isEligible && $finalGratuityAmount > $taxExemptionLimit && $taxRateOnExcess > 0.0) {
            $taxableGratuityExcess = round($finalGratuityAmount - $taxExemptionLimit, 2);
            $gratuityTaxDeduction  = round($taxableGratuityExcess * ($taxRateOnExcess / 100.0), 2);
        }
        $netGratuityAmount = round($finalGratuityAmount - $gratuityTaxDeduction, 2);

        // Rate percentage based on tenure slab
        $currentDaysPerYear = ($serviceYears > 10.0) ? $daysPerYearAfter10y : $daysPerYear;
        $ratePercentage     = $divisorDays > 0 ? round((($currentDaysPerYear / $divisorDays) / 12) * 100, 2) : 0.0;

        // 9. Check Employee Scope Layer (Override)
        $isOverride = false;
        $overrideReason = null;
        foreach ($rule->layers() as $layer) {
            if (($layer['scope_level'] ?? '') === 'Employee') {
                $isOverride = true;
                $overrideReason = $layer['change_reason'] ?? 'Employee specific override';
                break;
            }
        }

        // 10. Monthly Provision Accrual
        if ($customMonthlyAmount !== null && (float)$customMonthlyAmount >= 0) {
            $monthlyAccrual = round((float)$customMonthlyAmount, 2);
        } elseif (!$enabled || $provisionMode === 'FinalSettlementOnly') {
            $monthlyAccrual = 0.00;
        } else {
            if ($provisionStart === 'FromJoining' || $isEligible) {
                $currentAnnualMultiplier = ($serviceYears > 10.0) ? $annualMultiplierTier2 : $annualMultiplierTier1;
                $monthlyAccrual = round($currentAnnualMultiplier / 12, 2);
            } else {
                $monthlyAccrual = 0.00;
            }
        }

        // 11. Formula Description explicitly showing two-slab breakdown
        if ($tier2Years > 0) {
            $formulaDescription = sprintf(
                "Slab 1 (1st %g yrs @ %g d/yr): (%s / %d) * %g * %g = %s + Slab 2 (remaining %g yrs @ %g d/yr): (%s / %d) * %g * %g = %s | Total: %s",
                $tier1Years,
                $daysPerYear,
                number_format($basisAmount, 2),
                $divisorDays,
                $daysPerYear,
                $tier1Years,
                number_format($tier1Amount, 2),
                $tier2Years,
                $daysPerYearAfter10y,
                number_format($basisAmount, 2),
                $divisorDays,
                $daysPerYearAfter10y,
                $tier2Years,
                number_format($tier2Amount, 2),
                number_format($uncappedAmount, 2)
            );
        } else {
            $formulaDescription = sprintf(
                "%g yrs @ %g d/yr: (%s / %d) * %g * %g = %s",
                $tier1Years,
                $daysPerYear,
                number_format($basisAmount, 2),
                $divisorDays,
                $daysPerYear,
                $tier1Years,
                number_format($tier1Amount, 2)
            );
        }
        if ($isCapped) {
            $formulaDescription .= sprintf(" [Capped at Statutory Ceiling: %s]", number_format($maxCeiling, 2));
        }
        if ($gratuityTaxDeduction > 0) {
            $formulaDescription .= sprintf(
                " [Tax Exemption Limit: %s, Taxable Excess: %s @ %g%% = %s Tax Withheld | Net Gratuity: %s]",
                number_format($taxExemptionLimit, 2),
                number_format($taxableGratuityExcess, 2),
                $taxRateOnExcess,
                number_format($gratuityTaxDeduction, 2),
                number_format($netGratuityAmount, 2)
            );
        }

        // 12. Metadata & Source Badge
        $companyLayer = null;
        foreach ($rule->layers() as $layer) {
            if (($layer['scope_level'] ?? '') === 'Company') {
                $companyLayer = $layer;
                break;
            }
        }
        $policyVersion = $companyLayer['version_number'] ?? 1;

        if ($isOverride) {
            $overrideRuleId = $rule->layers()[count($rule->layers()) - 1]['rule_id'] ?? '';
            $sourceBadge = "Source: Employee Override ({$overrideRuleId})";
        } else {
            $sourceBadge = "Source: Company Policy v{$policyVersion} (rule_definitions)";
        }

        return [
            'is_eligible'               => $isEligible,
            'reason'                    => $reason,
            'service_years'             => round($serviceYears, 2),
            'years'                     => $y,
            'months'                    => $m,
            'days'                      => $d,
            'rounded_gratuity_years'    => $isEligible ? $roundedYears : 0,
            'daily_rate'                => round($dailyRate, 2),
            'basis_amount'              => round($basisAmount, 2),
            'month_divisor_days'        => $divisorDays,
            'divisor_days'              => $divisorDays,
            'multiplier_days_per_year'  => $daysPerYear,
            'days_per_year'             => $daysPerYear,
            'days_per_year_after_10y'   => $daysPerYearAfter10y,
            'tier1_years'               => $tier1Years,
            'tier2_years'               => $tier2Years,
            'tier1_amount'              => round($tier1Amount, 2),
            'tier2_amount'              => round($tier2Amount, 2),
            'annual_multiplier_tier1'   => round($annualMultiplierTier1, 2),
            'annual_multiplier_tier2'   => round($annualMultiplierTier2, 2),
            'annual_multiplier'         => round($annualMultiplierTier1, 2),
            'eligibility_min_years'     => $minYears,
            'rate_percentage'           => $ratePercentage,
            'uncapped_amount'           => $uncappedAmount,
            'max_ceiling_amount'        => $maxCeiling,
            'max_ceiling'               => $maxCeiling,
            'is_capped'                 => $isCapped,
            'tax_exemption_limit'       => $taxExemptionLimit,
            'tax_rate_on_excess'        => $taxRateOnExcess,
            'taxable_gratuity_excess'   => $taxableGratuityExcess,
            'gratuity_tax_deduction'    => $gratuityTaxDeduction,
            'net_gratuity_amount'       => $netGratuityAmount,
            'gratuity_amount'           => $finalGratuityAmount,
            'monthly_provision_accrual' => $monthlyAccrual,
            'monthly_accrual'           => $monthlyAccrual,
            'is_override'               => $isOverride,
            'override_reason'           => $overrideReason,
            'policy_name'               => 'Statutory Gratuity Provision Policy',
            'policy_version'            => $policyVersion,
            'policy_effective_date'     => $date,
            'source_badge'              => $sourceBadge,
            'formula_description'       => $formulaDescription,
            'source'                    => 'Rule Engine (rule_definitions)',
            'rules_snapshot'            => $rulesSnapshot,
            'resolved_rule'             => $rule,
        ];
    }
}
