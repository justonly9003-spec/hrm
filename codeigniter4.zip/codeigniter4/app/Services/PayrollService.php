<?php

namespace App\Services;

use App\Models\ProvidentFundLedgerModel;
use App\Models\LoanModel;
use App\Models\PayrollGenerationLockModel;
use App\Services\ArrearService;
use App\Services\AuditService;
use App\Services\LoanAdvanceService;
use App\Services\SalaryPolicyResolver;
use App\Services\Gratuity\GratuityCalculator;
use App\Services\Rules\Money;
use App\Libraries\AssetWriteOffReasons;
use Config\Database;

class PayrollService
{
    protected $db;
    protected SalaryPolicyResolver $policyResolver;
    protected GratuityCalculator $gratuityCalculator;
    protected ProvidentFundLedgerModel $pfLedgerModel;
    protected LoanModel $loanModel;
    protected PayrollGenerationLockModel $lockModel;
    protected ArrearService $arrearService;
    protected EmployeeSalaryService $salaryService;
    protected \App\Services\Overtime\OvertimeCalculationService $otService;
    protected AuditService $auditService;
    private ?array $cachedAttendanceLogFields = null;

    public function __construct()
    {
        $this->db = Database::connect();
        $this->policyResolver = new SalaryPolicyResolver();
        $this->gratuityCalculator = new GratuityCalculator();
        $this->pfLedgerModel = new ProvidentFundLedgerModel();
        $this->loanModel = new LoanModel();
        $this->lockModel = new PayrollGenerationLockModel();
        $this->arrearService = new ArrearService();
        $this->salaryService = new EmployeeSalaryService();
        $this->otService = new \App\Services\Overtime\OvertimeCalculationService();
        $this->auditService = new AuditService();
    }

    /**
     * Cache fields of attendance_logs to avoid repetitive schema lookups during payroll runs
     */
    private function getAttendanceLogFields(): array
    {
        if ($this->cachedAttendanceLogFields === null) {
            try {
                $this->cachedAttendanceLogFields = $this->db->tableExists('attendance_logs')
                    ? $this->db->getFieldNames('attendance_logs')
                    : [];
            } catch (\Throwable $e) {
                $this->cachedAttendanceLogFields = [];
            }
        }
        return $this->cachedAttendanceLogFields;
    }

    /**
     * Apply late attendance filtering conditions safely based on actual schema columns in attendance_logs
     *
     * @param \CodeIgniter\Database\BaseBuilder $builder
     */
    private function applyLateAttendanceFilter($builder): void
    {
        $fields = $this->getAttendanceLogFields();
        $builder->groupStart();
        $hasCond = false;

        if (in_array('is_late', $fields, true)) {
            $builder->where('is_late', 1);
            $hasCond = true;
        }

        if (in_array('late_minutes', $fields, true)) {
            if ($hasCond) {
                $builder->orWhere('late_minutes >', 0);
            } else {
                $builder->where('late_minutes >', 0);
                $hasCond = true;
            }
        }

        if (in_array('status', $fields, true)) {
            if ($hasCond) {
                $builder->orWhereIn('status', ['Late', 'Late & Early Out', 'late']);
            } else {
                $builder->whereIn('status', ['Late', 'Late & Early Out', 'late']);
                $hasCond = true;
            }
        }

        if (!$hasCond) {
            $builder->where('1 = 0', null, false);
        }

        $builder->groupEnd();
    }

    /**
     * Resolve authoritative daily salary rate and divisor for Loss of Pay (LOP) and unpaid leave deductions.
     * Evaluated strictly via DailyRateResolver against PAYROLL_BASICS.
     */
    public function resolveDailySalaryRate(float $salary, string $monthStr, array $ruleProfile, ?string $companyId = null): array
    {
        $cid = $companyId ?: ($ruleProfile['company_id'] ?? null);
        if (empty($cid) && function_exists('session')) {
            try {
                $cid = session('selected_company_id') ?: session('company_id');
            } catch (\Throwable $e) {}
        }
        if (empty($cid)) {
            throw new \App\Services\Rules\RuleNotConfiguredException(
                "Company ID context is required to resolve daily salary rate."
            );
        }

        $employee = $ruleProfile['employee'] ?? ($ruleProfile['emp'] ?? null);

        return \App\Services\Rules\DailyRateResolver::resolve($cid, $employee, null, $monthStr, $salary);
    }

    /**
     * Calculate the unpaid leave days of an application that fall within a specific payroll month.
     * Accurately supports single-month leaves as well as leaves spanning across month boundaries.
     */
    public function calculateUnpaidLeaveDaysInMonth(array $ul, string $monthStartDate, string $monthEndDate): float
    {
        // If leave type or application is flagged as not affecting payroll
        if (isset($ul['affects_payroll']) && ($ul['affects_payroll'] === false || $ul['affects_payroll'] === 0 || $ul['affects_payroll'] === '0')) {
            return 0.0;
        }
        if (isset($ul['type_affects_payroll']) && ($ul['type_affects_payroll'] === false || $ul['type_affects_payroll'] === 0 || $ul['type_affects_payroll'] === '0')) {
            return 0.0;
        }

        // Check LEAVE domain rule for unpaid_deduction.affects_payroll
        if (!isset($ul['affects_payroll']) && !empty($ul['employee_id'])) {
            try {
                $comp = $ul['company_id'] ?? null;
                if (!$comp && $this->db->tableExists('employees')) {
                    $eRow = $this->db->table('employees')->select('company_id')->where('id', $ul['employee_id'])->get()->getRowArray();
                    $comp = $eRow['company_id'] ?? null;
                }
                if ($comp) {
                    $lRule = \App\Services\Rules\RuleResolver::resolveForCompany($comp, 'LEAVE', $monthStartDate);
                    $unpaidRule = $lRule->get('unpaid_deduction') ?: [];
                    if (isset($unpaidRule['affects_payroll']) && $unpaidRule['affects_payroll'] === false) {
                        return 0.0;
                    }
                }
            } catch (\Throwable $e) {
                // Ignore fallback error
            }
        }

        $appStart = $ul['start_date'] ?? $ul['from_date'] ?? null;
        $appEnd = $ul['end_date'] ?? $ul['to_date'] ?? $appStart;
        if (!$appStart) {
            return (float)($ul['unpaid_days'] ?? ($ul['total_days'] ?? 0.0));
        }
        if (!$appEnd) {
            $appEnd = $appStart;
        }

        $paidPercentage = isset($ul['paid_percentage']) && is_numeric($ul['paid_percentage'])
            ? (float)$ul['paid_percentage']
            : (isset($ul['type_paid_percentage']) && is_numeric($ul['type_paid_percentage'])
                ? (float)$ul['type_paid_percentage']
                : null);

        if ($paidPercentage === null && !empty($ul['leave_type_id']) && $this->db->tableExists('leave_types')) {
            $ltRow = $this->db->table('leave_types')->select('paid_percentage')->where('id', $ul['leave_type_id'])->get()->getRowArray();
            if ($ltRow && isset($ltRow['paid_percentage']) && is_numeric($ltRow['paid_percentage'])) {
                $paidPercentage = (float)$ltRow['paid_percentage'];
            }
        }

        // Entirely within this month
        if ($appStart >= $monthStartDate && $appEnd <= $monthEndDate) {
            if ((float)($ul['unpaid_days'] ?? 0) > 0) {
                return (float)$ul['unpaid_days'];
            }
            if ($paidPercentage !== null && $paidPercentage < 100.0) {
                $tot = (float)($ul['total_days'] ?? 1.0);
                return round($tot * ((100.0 - $paidPercentage) / 100.0), 2);
            }
            if (isset($ul['type_is_paid']) && (int)$ul['type_is_paid'] === 0) {
                return (float)($ul['total_days'] ?? 1.0);
            }
            if (isset($ul['is_paid']) && (int)$ul['is_paid'] === 0) {
                return (float)($ul['total_days'] ?? 1.0);
            }
            return 0.0;
        }

        // Multi-month spanning leave: compute date overlap with payroll month
        $overlapStart = max($appStart, $monthStartDate);
        $overlapEnd = min($appEnd, $monthEndDate);

        if ($overlapStart > $overlapEnd) {
            return 0.0;
        }

        $totalCalDays = max(1, (int)round((strtotime($appEnd) - strtotime($appStart)) / 86400) + 1);
        $overlapCalDays = max(0, (int)round((strtotime($overlapEnd) - strtotime($overlapStart)) / 86400) + 1);

        $totalUnpaid = 0.0;
        if ((float)($ul['unpaid_days'] ?? 0) > 0) {
            $totalUnpaid = (float)$ul['unpaid_days'];
        } elseif ($paidPercentage !== null && $paidPercentage < 100.0) {
            $tot = (float)($ul['total_days'] ?? $totalCalDays);
            $totalUnpaid = round($tot * ((100.0 - $paidPercentage) / 100.0), 2);
        } elseif (isset($ul['type_is_paid']) && (int)$ul['type_is_paid'] === 0) {
            $totalUnpaid = (float)($ul['total_days'] ?? $totalCalDays);
        } elseif (isset($ul['is_paid']) && (int)$ul['is_paid'] === 0) {
            $totalUnpaid = (float)($ul['total_days'] ?? $totalCalDays);
        }

        if ($totalUnpaid <= 0.0) {
            return 0.0;
        }

        $prorated = round($totalUnpaid * ($overlapCalDays / $totalCalDays), 2);
        return min($prorated, $totalUnpaid);
    }

    /**
     * Calculate dynamic late penalty based on company rule profile, system settings, and attendance logs
     */
    public function calculateDynamicLatePenalty(array $emp, string $month, float $dailyRate, array $ruleProfile, ?string $companyId, ?array $preloadedLateLogs = null, ?array $preloadedTiers = null): float
    {
        $lateRule = $ruleProfile['lateRule'] ?? [];
        if (isset($lateRule['enabled']) && !$lateRule['enabled']) {
            return 0.00;
        }

        $penaltyMethod = $lateRule['penaltyMethod'] ?? 'Leave deduction';
        if (in_array($penaltyMethod, ['Warning', 'Ignore'], true)) {
            return 0.00;
        }

        if ($preloadedLateLogs !== null) {
            $lateLogs = $preloadedLateLogs;
        } else {
            if (!$this->db->tableExists('attendance_logs')) {
                return (float)($emp['late_penalty'] ?? 0.00);
            }

            $logQuery = $this->db->table('attendance_logs')
                ->where('employee_id', $emp['id'])
                ->like('date', $month, 'after');
            $this->applyLateAttendanceFilter($logQuery);
            $logRes = $logQuery->get();
            $lateLogs = ($logRes && is_object($logRes)) ? $logRes->getResultArray() : [];
        }

        $lateCount = count($lateLogs);
        if ($lateCount === 0) {
            return 0.00;
        }

        // 1. Check for custom company late tiers in ruleProfile or system_settings
        $tiers = $preloadedTiers ?? ($lateRule['tiers'] ?? null);
        if (empty($tiers) && $this->db->tableExists('system_settings')) {
            $settingQuery = $this->db->table('system_settings')
                ->where('setting_key', 'late_penalty_tiers');
            if ($companyId) {
                $settingQuery->groupStart()
                    ->where('company_id', $companyId)
                    ->orWhere('company_id IS NULL')
                ->groupEnd();
            }
            $tierRes = $settingQuery->get();
            $tierSetting = ($tierRes && is_object($tierRes)) ? $tierRes->getRowArray() : null;
            if ($tierSetting && !empty($tierSetting['setting_value'])) {
                $tiers = json_decode($tierSetting['setting_value'], true);
            }
        }

        $moneyDecimals = isset($ruleProfile['money_decimals']) && is_numeric($ruleProfile['money_decimals'])
            ? (int)$ruleProfile['money_decimals']
            : Money::decimals((string)($companyId ?: ($emp['company_id'] ?? '')), $emp, "{$month}-01");

        if (!empty($tiers) && is_array($tiers)) {
            foreach ($tiers as $tier) {
                $min = (int)($tier['min_lates'] ?? $tier['minLates'] ?? 0);
                $max = (int)($tier['max_lates'] ?? $tier['maxLates'] ?? 999);
                if ($lateCount >= $min && $lateCount <= $max) {
                    $action = $tier['action'] ?? 'deduction';
                    if (strtolower($action) === 'warning' || strtolower($action) === 'ignore') {
                        return 0.00;
                    }
                    if (isset($tier['fixed_amount'])) {
                        return Money::round((float)$tier['fixed_amount'], $moneyDecimals);
                    }
                    $penaltyDays = (float)($tier['penalty_days'] ?? $tier['penaltyDays'] ?? 0.0);
                    return Money::round($penaltyDays * $dailyRate, $moneyDecimals);
                }
            }
        }

        // 2. Check per-minute deduction method
        if ($penaltyMethod === 'Deduction') {
            $logDeductionSum = 0.0;
            $hasLogDeductions = false;
            foreach ($lateLogs as $ll) {
                if (isset($ll['late_penalty_deduction']) && (float)$ll['late_penalty_deduction'] > 0) {
                    $logDeductionSum += (float)$ll['late_penalty_deduction'];
                    $hasLogDeductions = true;
                }
            }
            if ($hasLogDeductions) {
                return Money::round($logDeductionSum, $moneyDecimals);
            }

            $ratePerMin = (float)($lateRule['penaltyDeductionAmountPerMinute'] ?? 0.0);
            if ($ratePerMin > 0) {
                $totalLateMins = 0;
                foreach ($lateLogs as $ll) {
                    $totalLateMins += (int)($ll['late_minutes'] ?? 0);
                }
                return Money::round($totalLateMins * $ratePerMin, $moneyDecimals);
            }
        }

        // 3. Consecutive / Count-based threshold deduction (e.g. every 3 lates = 0.5 or 1 day penalty)
        $threshold = (int)($lateRule['consecutiveLateDaysThreshold'] ?? 3);
        $penaltyDaysPerThreshold = (float)($lateRule['consecutiveLatePenaltyLeaveDays'] ?? $lateRule['penaltyDays'] ?? 0.5);

        if ($threshold > 0 && $lateCount >= $threshold) {
            $penaltyMultiples = intdiv($lateCount, $threshold);
            return Money::round($penaltyMultiples * $penaltyDaysPerThreshold * $dailyRate, $moneyDecimals);
        }

        return 0.00;
    }

    /**
     * Pure calculation of an individual employee's monthly payroll item.
     * Performs ZERO database mutations.
     *
     * @param array $emp Employee row
     * @param array $ctx Preloaded context maps (bonuses, leaves, arrears, loans, advances, overtime, settings, etc.)
     * @return array [
     *     'eligible' => bool,
     *     'item' => array, // row for payroll_items table
     *     'effects' => array, // items to write upon batch generation / approval
     *     'excluded_employee' => ?array
     * ]
     */
    public function calculateEmployeeItem(array $emp, array $ctx, bool $dryRun = false): array
    {
        $isDryRun = $dryRun || (!empty($ctx['dry_run']));
        $month = $ctx['month'];
        $daysInMonth = (int)($ctx['days_in_month'] ?? date('t', strtotime("{$month}-01")));
        if ($daysInMonth <= 0) $daysInMonth = 30;
        $monthStartDate = $ctx['month_start_date'] ?? "{$month}-01";
        $monthEndDate = $ctx['month_end_date'] ?? sprintf('%s-%02d', $month, $daysInMonth);
        $monthNum = (int)($ctx['month_num'] ?? date('n', strtotime("{$month}-01")));
        $yearNum = (int)($ctx['year_num'] ?? date('Y', strtotime("{$month}-01")));
        $taxYear = $ctx['tax_year'] ?? (($monthNum >= 7) ? "{$yearNum}-" . ($yearNum + 1) : ($yearNum - 1) . "-{$yearNum}");
        $companyId = $ctx['company_id'] ?? ($emp['company_id'] ?? null);
        $payrollId = $ctx['payroll_id'] ?? null;

        // Check joining date constraint
        $empJoinDate = employee_joining_date($emp) ?? $emp['employment_start_date'] ?? null;
        if (!empty($empJoinDate) && $empJoinDate > $monthEndDate) {
            return [
                'eligible'          => false,
                'item'              => [],
                'effects'           => [],
                'excluded_employee' => [
                    'id'            => $emp['id'],
                    'employee_code' => $emp['employee_code'] ?? '',
                    'name'          => trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')),
                    'reason'        => 'Joined after payroll month'
                ]
            ];
        }

        // BUSINESS RULE: Employee salary MUST be explicitly assigned by an authorized HR/Admin user.
        $salaryEligibility = $ctx['salaries'][$emp['id']] ?? $this->salaryService->isPayrollEligible($emp['id'], $month);
        if (!$salaryEligibility['eligible']) {
            return [
                'eligible'          => false,
                'item'              => [],
                'effects'           => [],
                'excluded_employee' => [
                    'id'            => $emp['id'],
                    'employee_code' => $emp['employee_code'] ?? '',
                    'name'          => trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')),
                    'reason'        => $salaryEligibility['reason'] ?? 'Salary Configuration Required'
                ]
            ];
        }

        $activeSal = $salaryEligibility['salary'];
        $basic = (float)$activeSal['basic_salary'];
        $comp = $activeSal['components'] ?? [];

        // Dynamic Allowances strictly from explicitly assigned salary components
        $earningsList = $activeSal['earnings'] ?? [];
        $houseRent = 0.00;
        $medical = 0.00;
        $transport = 0.00;
        $food = 0.00;
        $special = 0.00;
        $totalAssignedAllowances = 0.00;
        $taxableAllowances = 0.00;
        $basicIsTaxable = true;
        $basicIncludedInGross = true;

        if (!empty($earningsList) && is_array($earningsList)) {
            $hasExplicitBasic = false;
            foreach ($earningsList as $ea) {
                $code = strtoupper(trim((string)($ea['code'] ?? $ea['component_code'] ?? '')));
                $category = strtoupper(trim((string)($ea['category'] ?? $ea['component_category'] ?? '')));
                $amt = (float)($ea['amount'] ?? 0.00);
                $isEnabled = $ea['is_enabled'] ?? true;
                if (!$isEnabled) continue;

                $calcType = strtolower((string)($ea['calculation_type'] ?? ''));
                // Overtime is strictly policy-driven via OvertimeCalculationService from approved records; ignore any legacy structure item
                if ($calcType === 'overtime based' || in_array($code, ['OT', 'OVERTIME', 'OVER_TIME', 'OT_PAY'], true) || in_array($category, ['OT', 'OVERTIME'], true)) {
                    continue;
                }

                $isIncludedInGross = isset($ea['is_included_in_gross'])
                    ? ((int)$ea['is_included_in_gross'] === 1 || $ea['is_included_in_gross'] === true)
                    : true;

                $isTaxable = isset($ea['is_taxable'])
                    ? ((int)$ea['is_taxable'] === 1 || $ea['is_taxable'] === true)
                    : true;

                // Component classification strictly by code/category mapping (no stripos on names)
                $isBasicComponent = in_array($code, ['BASIC', 'BASIC_SALARY', 'BASE', 'BASE_SALARY', 'BASIC_PAY'], true)
                    || in_array($category, ['BASIC', 'BASIC_SALARY'], true);

                if ($isBasicComponent) {
                    $basic = $amt;
                    $hasExplicitBasic = true;
                    $basicIsTaxable = $isTaxable;
                    $basicIncludedInGross = $isIncludedInGross;
                } else {
                    if ($isIncludedInGross) {
                        $totalAssignedAllowances += $amt;
                    }
                    if ($isTaxable) {
                        $taxableAllowances += $amt;
                    }

                    $isHra = in_array($code, ['HRA', 'HOUSE_RENT', 'HOUSE_RENT_ALLOWANCE', 'HOUSING', 'RENT'], true)
                        || in_array($category, ['HRA', 'HOUSE_RENT', 'HOUSING'], true);

                    $isMed = in_array($code, ['MED', 'MEDICAL', 'MEDICAL_ALLOWANCE', 'MED_ALL', 'HEALTH'], true)
                        || in_array($category, ['MED', 'MEDICAL', 'HEALTH'], true);

                    $isConv = in_array($code, ['CONV', 'CONVEYANCE', 'TRANSPORT', 'TRAVEL', 'TRAVEL_ALLOWANCE', 'COMMUTE'], true)
                        || in_array($category, ['CONV', 'CONVEYANCE', 'TRANSPORT', 'TRAVEL'], true);

                    $isFood = in_array($code, ['FOOD', 'FOOD_ALLOWANCE', 'MEAL', 'MEAL_ALLOWANCE', 'LUNCH'], true)
                        || in_array($category, ['FOOD', 'MEAL'], true);

                    if ($isHra) {
                        $houseRent += $amt;
                    } elseif ($isMed) {
                        $medical += $amt;
                    } elseif ($isConv) {
                        $transport += $amt;
                    } elseif ($isFood) {
                        $food += $amt;
                    } else {
                        $special += $amt;
                    }
                }
            }
            if (!$hasExplicitBasic && (empty($activeSal['basic_salary']) || (float)$activeSal['basic_salary'] <= 0)) {
                $basic = 0.00;
            }
        } else {
            if (!empty($activeSal['id']) || !empty($activeSal['has_explicit_structure'])) {
                $basic = (float)($activeSal['basic_salary'] ?? 0.00);
                $basicIsTaxable = true;
                $basicIncludedInGross = true;
                $houseRent = 0.00;
                $medical = 0.00;
                $transport = 0.00;
                $food = 0.00;
                $special = 0.00;
                $totalAssignedAllowances = 0.00;
                $taxableAllowances = 0.00;
            } else {
                $houseRent = (float)($comp['house_rent'] ?? ($emp['house_rent_allowance'] ?? 0.0));
                $medical = (float)($comp['medical'] ?? ($emp['medical_allowance'] ?? 0.0));
                $transport = (float)($comp['conveyance'] ?? ($emp['conveyance_allowance'] ?? $emp['transport_allowance'] ?? 0.0));
                $food = (float)($comp['food'] ?? ($emp['food_allowance'] ?? 0.0));
                $special = (float)($comp['special'] ?? ($emp['special_allowance'] ?? 0.0));
                $totalAssignedAllowances = $houseRent + $medical + $transport + $food + $special + (float)($comp['other_allowances'] ?? 0.0);
                $taxableAllowances = $totalAssignedAllowances;
            }
        }

        $pbRule = \App\Services\Rules\RuleResolver::resolve(
            (string)($companyId ?: ($emp['company_id'] ?? '')),
            'PAYROLL_BASICS',
            $monthStartDate,
            $emp
        );
        $moneyDecimals = Money::decimals($pbRule);

        $conveyance = $transport;
        $allowances = Money::round($totalAssignedAllowances, $moneyDecimals);
        $taxableAllowances = Money::round($taxableAllowances, $moneyDecimals);
        $otherAllowances = Money::round(max(0, $allowances - ($houseRent + $medical + $transport)), $moneyDecimals);

        // Mid-Month Joining Salary Proration (Configured basis via PAYROLL_BASICS)
        $prorationBasis = (string)$pbRule->get('proration_basis');
        $prorationFactor = 1.0;
        if (!empty($empJoinDate) && $empJoinDate > $monthStartDate && $empJoinDate <= $monthEndDate) {
            $joinDay = (int)date('d', strtotime($empJoinDate));
            $activeDays = ($daysInMonth - $joinDay) + 1;
            if ($prorationBasis === 'WorkingDays') {
                $workingDivisor = (float)$pbRule->get('daily_rate_divisor');
                $prorationFactor = $workingDivisor > 0 ? min(1.0, $activeDays / $workingDivisor) : ($activeDays / $daysInMonth);
            } else {
                $prorationFactor = $activeDays / $daysInMonth;
            }
            $basic = Money::round($basic * $prorationFactor, $moneyDecimals);
            $houseRent = Money::round($houseRent * $prorationFactor, $moneyDecimals);
            $medical = Money::round($medical * $prorationFactor, $moneyDecimals);
            $transport = Money::round($transport * $prorationFactor, $moneyDecimals);
            $conveyance = $transport;
            $food = Money::round($food * $prorationFactor, $moneyDecimals);
            $special = Money::round($special * $prorationFactor, $moneyDecimals);
            $allowances = Money::round($allowances * $prorationFactor, $moneyDecimals);
            $taxableAllowances = Money::round($taxableAllowances * $prorationFactor, $moneyDecimals);
            $otherAllowances = Money::round(max(0, $allowances - ($houseRent + $medical + $transport)), $moneyDecimals);

            // Prorate stored breakdown earnings list
            if (!empty($earningsList) && is_array($earningsList)) {
                foreach ($earningsList as &$eaItem) {
                    $eaCode = strtoupper(trim((string)($eaItem['code'] ?? $eaItem['component_code'] ?? '')));
                    $eaCat = strtoupper(trim((string)($eaItem['category'] ?? $eaItem['component_category'] ?? '')));
                    $isBasic = in_array($eaCode, ['BASIC', 'BASIC_SALARY', 'BASE', 'BASE_SALARY', 'BASIC_PAY'], true)
                        || in_array($eaCat, ['BASIC', 'BASIC_SALARY'], true);
                    if ($isBasic) {
                        $eaItem['amount'] = $basic;
                    } else {
                        $origAmt = (float)($eaItem['amount'] ?? 0.00);
                        $eaItem['amount'] = Money::round($origAmt * $prorationFactor, $moneyDecimals);
                    }
                }
                unset($eaItem);
            }
        }

        // Rule profile resolution (Single Source of Truth via RuleResolver)
        $ruleProfile = $ctx['rule_profiles'][$emp['id']] ?? \App\Services\Rules\RuleResolver::attendanceProfile($emp, $month . '-01');
        $ruleProfile['money_decimals'] = $moneyDecimals;

        // Overtime Integration (strictly approved records only, deduplicated, batch-scoped)
        if (isset($ctx['overtime'][$emp['id']])) {
            $otSummary = $ctx['overtime'][$emp['id']];
        } else {
            $otSummary = $this->otService->getSummaryForPayroll($emp['id'], $month, $companyId ?: '', $payrollId);
        }
        $overtimeAmount = (float)($otSummary['ot_amount'] ?? 0.0);
        $settledLogIds = $otSummary['record_ids'] ?? [];
        $approvedOtMins = (int)($otSummary['approved_minutes'] ?? round((float)($otSummary['approved_hours'] ?? 0) * 60));
        $approvedOtHours = (float)($otSummary['approved_hours'] ?? round($approvedOtMins / 60, 2));

        // Bonus Integration (Monthly Schemes + Approved Weekly Attendance Bonuses)
        $bonus = 0.00;
        $bRecords = $ctx['bonuses'][$emp['id']] ?? [];
        $consumedBonusIds = [];
        foreach ($bRecords as $br) {
            $bonus += (float)($br['amount'] ?? 0.00);
            if (!empty($br['id'])) {
                $consumedBonusIds[] = (string)$br['id'];
            }
        }

        $wRecords = $ctx['weekly_bonuses'][$emp['id']] ?? [];
        $consumedWeeklyBonusIds = [];
        $weeklyBonusAmount = 0.00;
        foreach ($wRecords as $wr) {
            $wAmt = (float)($wr['bonus_amount'] ?? 0.00);
            $weeklyBonusAmount += $wAmt;
            if (!empty($wr['id'])) {
                $consumedWeeklyBonusIds[] = (string)$wr['id'];
            }
        }
        $bonus = Money::round($bonus + $weeklyBonusAmount, $moneyDecimals);

        // Actual Annual Bonus in Current Fiscal Year (Approved, Settled, or Paid from bonus table)
        $annualBonus = 0.00;
        if (isset($ctx['fiscal_bonus_totals'][$emp['id']])) {
            $annualBonus = (float)$ctx['fiscal_bonus_totals'][$emp['id']];
        } else {
            $annualBonus = $this->getFiscalYearBonusTotal($emp['id'], $month, $taxYear);
        }
        if ($bonus > $annualBonus) {
            $annualBonus = $bonus;
        }
        $annualBonus = Money::round($annualBonus, $moneyDecimals);

        // Pending Arrears Integration
        $arrearAmount = 0.00;
        $arrearPf = 0.00;
        $arrearPfEmployer = 0.00;
        $disbursedArrearIds = [];
        $pendingArrears = $ctx['arrears'][$emp['id']] ?? [];
        foreach ($pendingArrears as $pa) {
            $arrearAmount += (float)($pa['gross_arrear'] ?? $pa['net_arrear'] ?? 0.00);
            $arrearPf += (float)($pa['pf_arrear'] ?? 0.00);
            $arrearPfEmployer += (float)($pa['pf_arrear_employer'] ?? 0.00);
            $disbursedArrearIds[] = $pa['id'];
        }

        $incentive = 0.00;

        // Leave Encashment Integration (Approved encashments with payout_month <= current payroll month)
        $encashment = 0.00;
        $encashRecords = [];
        if (isset($ctx['leave_encashments'][$emp['id']])) {
            $encashRecords = $ctx['leave_encashments'][$emp['id']];
        } elseif (!isset($ctx['leave_encashments']) && $this->db->tableExists('leave_encashments')) {
            $encashRecords = $this->getApprovedEncashmentsForEmployee($emp['id'], $month, $companyId, $payrollId);
        }
        $consumedEncashmentIds = [];
        foreach ($encashRecords as $er) {
            $encAmt = (float)($er['total_amount'] ?? $er['amount'] ?? 0.00);
            $encashment += $encAmt;
            if (!empty($er['id'])) {
                $consumedEncashmentIds[] = (string)$er['id'];
            }
        }
        $encashment = Money::round($encashment, $moneyDecimals);

        $gross = Money::round(($basicIncludedInGross ? $basic : 0.00) + $allowances + $overtimeAmount + $bonus + $incentive + $encashment + $arrearAmount, $moneyDecimals);

        // Context for statutory calculations
        $empContext = [
            'employee_id' => $emp['id'],
            'grade_id' => $emp['salary_grade_id'] ?? null,
            'gender' => $emp['gender'] ?? 'All',
            'category' => $emp['tax_category'] ?? $emp['category'] ?? (($emp['gender'] ?? '') === 'Female' ? 'Female' : 'General'),
            'employment_type_id' => $emp['employment_type_id'] ?? null,
            'company_id' => $companyId,
            'tax_year' => $taxYear,
            'basic' => $basic,
            'house_rent' => $houseRent,
            'medical' => $medical,
            'conveyance' => $conveyance,
            'other_allowances' => Money::round($food + $special, $moneyDecimals),
            'annual_bonus' => $annualBonus,
        ];

        // -------------------------------------------------------------
        // PROVIDENT FUND: Single Source of Truth via PfCalculator & RuleResolver
        // -------------------------------------------------------------
        $daysInMonth = (int)date('t', strtotime($month . '-01'));
        if ($daysInMonth <= 0) $daysInMonth = 30;
        $effectiveDate = sprintf('%s-%02d', $month, $daysInMonth);

        $isAppAdmin = ($emp['role'] ?? '') === 'Software App Admin' || ($emp['employee_code'] ?? '') === 'SUPER_ADMIN';

        $allowanceComponents = [
            'HRA'              => $houseRent,
            'Medical'          => $medical,
            'Conveyance'       => $conveyance,
            'Transport'        => $transport,
            'Food'             => $food,
            'Special'          => $special,
            'Other_Allowances' => $otherAllowances,
            'Overtime'         => $overtimeAmount,
            'Bonus'            => $bonus,
        ];
        if (!empty($earningsList) && is_array($earningsList)) {
            foreach ($earningsList as $ea) {
                $cCode = trim((string)($ea['code'] ?? $ea['component_code'] ?? ''));
                if ($cCode !== '') {
                    $allowanceComponents[$cCode] = (float)($ea['amount'] ?? 0.0);
                }
                $cName = trim((string)($ea['name'] ?? $ea['component_name'] ?? ''));
                if ($cName !== '') {
                    $allowanceComponents[$cName] = (float)($ea['amount'] ?? 0.0);
                }
            }
        }

        $empPfInput = array_merge($emp, [
            'pf_settings' => $activeSal['pf_settings'] ?? ($emp['pf_settings'] ?? null),
        ]);

        $pfCalc = new \App\Services\Pf\PfCalculator();
        try {
            $statutoryPf = $pfCalc->calculate([
                'company_id'     => $companyId ?? ($emp['company_id'] ?? null),
                'employee'       => $empPfInput,
                'effective_date' => $effectiveDate,
                'earnings'       => array_merge($allowanceComponents, [
                    'Basic' => $basic,
                    'Gross' => $gross,
                ]),
            ]);
        } catch (\InvalidArgumentException $e) {
            log_message('error', 'PayrollService PF formula calculation error for employee ' . ($emp['id'] ?? 'unknown') . ': ' . $e->getMessage());
            throw $e;
        }

        $pfIsEligible = !$isAppAdmin && (bool)($statutoryPf['is_eligible'] ?? false);
        $appliedArrearPf = $pfIsEligible ? $arrearPf : 0.00;
        $appliedArrearPfEmployer = $pfIsEligible ? $arrearPfEmployer : 0.00;
        $pfDeduction = $pfIsEligible ? Money::round((float)($statutoryPf['employee_deduction'] ?? 0.00) + $appliedArrearPf, $moneyDecimals) : 0.00;
        $pfEmployerContribution = $pfIsEligible ? Money::round((float)($statutoryPf['employer_contribution'] ?? 0.00) + $appliedArrearPfEmployer, $moneyDecimals) : 0.00;

        $pfSnapshotRuleId = $statutoryPf['snapshot']['policy_version_id'] ?? ($statutoryPf['snapshot']['policy_rule_id'] ?? 'PF_RULE_STORE');
        $pfSnapshotRuleName = 'Provident Fund';
        $pfSnapshotContribType = ucfirst($statutoryPf['snapshot']['contribution_type'] ?? 'Percentage');
        $pfStatutorySnapshot = $statutoryPf['snapshot'] ?? null;
        $pfRulesSnapshot = $statutoryPf['rules_snapshot'] ?? [];

        $pfResult = [
            'employee_deduction'       => $pfDeduction,
            'employer_contribution'    => $pfEmployerContribution,
            'total_pf'                 => Money::round($pfDeduction + $pfEmployerContribution, $moneyDecimals),
            'effective_base'           => (float)($statutoryPf['effective_basis_amount'] ?? $basic),
            'rule_id'                  => $pfSnapshotRuleId,
            'rule_name'                => $pfSnapshotRuleName,
            'is_eligible'              => $pfIsEligible,
            'arrear_pf_deduction'      => $appliedArrearPf,
            'arrear_pf_employer'       => $appliedArrearPfEmployer,
            'has_pf_arrear_recovery'   => ($appliedArrearPf < 0 || $appliedArrearPfEmployer < 0),
            'snapshot'                 => $pfStatutorySnapshot,
            'rules_snapshot'           => $pfRulesSnapshot,
        ];

        // -------------------------------------------------------------
        // Prepare stored breakdown: earnings
        // -------------------------------------------------------------
        $finalEarningsBreakdown = [];
        if (!empty($earningsList) && is_array($earningsList)) {
            foreach ($earningsList as $e) {
                if (($e['is_enabled'] ?? true) && (float)($e['amount'] ?? 0) > 0) {
                    $finalEarningsBreakdown[] = $e;
                }
            }
        }
        if (empty($finalEarningsBreakdown)) {
            // Fetch actual component flags once, keyed by code
            $componentFlags = [];
            if (!empty($companyId) && $this->db->tableExists('salary_components')) {
                $compRes = $this->db->table('salary_components')
                    ->where('company_id', $companyId)
                    ->whereIn('code', ['BASIC', 'HRA', 'MED', 'CONV', 'FOOD', 'SPECIAL'])
                    ->get();
                $componentRows = ($compRes && is_object($compRes)) ? $compRes->getResultArray() : [];
                foreach ($componentRows as $c) {
                    $componentFlags[$c['code']] = [
                        'is_taxable'           => (bool)($c['is_taxable'] ?? false),
                        'is_included_in_gross' => (bool)($c['is_included_in_gross'] ?? true),
                    ];
                }
            }

            $getComponentFlag = function(string $code, string $flag, bool $defaultVal) use ($componentFlags, $companyId) {
                if (isset($componentFlags[$code][$flag])) {
                    return $componentFlags[$code][$flag];
                }
                log_message('warning', "Missing salary_components configuration for code '{$code}' in company '{$companyId}'. Falling back to default {$flag}=" . ($defaultVal ? 'true' : 'false') . '.');
                return $defaultVal;
            };

            if ($basic > 0) {
                $finalEarningsBreakdown[] = ['code' => 'BASIC', 'name' => 'Basic Salary', 'amount' => $basic, 'type' => 'earning', 'is_included_in_gross' => $basicIncludedInGross, 'is_taxable' => $basicIsTaxable];
            }
            if ($houseRent > 0) {
                $finalEarningsBreakdown[] = [
                    'code' => 'HRA',
                    'name' => 'House Rent Allowance (HRA)',
                    'amount' => $houseRent,
                    'type' => 'earning',
                    'is_included_in_gross' => $getComponentFlag('HRA', 'is_included_in_gross', true),
                    'is_taxable' => $getComponentFlag('HRA', 'is_taxable', true),
                ];
            }
            if ($medical > 0) {
                $finalEarningsBreakdown[] = [
                    'code' => 'MED',
                    'name' => 'Medical Allowance',
                    'amount' => $medical,
                    'type' => 'earning',
                    'is_included_in_gross' => $getComponentFlag('MED', 'is_included_in_gross', true),
                    'is_taxable' => $getComponentFlag('MED', 'is_taxable', true),
                ];
            }
            if ($conveyance > 0) {
                $finalEarningsBreakdown[] = [
                    'code' => 'CONV',
                    'name' => 'Conveyance Allowance',
                    'amount' => $conveyance,
                    'type' => 'earning',
                    'is_included_in_gross' => $getComponentFlag('CONV', 'is_included_in_gross', true),
                    'is_taxable' => $getComponentFlag('CONV', 'is_taxable', true),
                ];
            }
            if ($food > 0) {
                $finalEarningsBreakdown[] = [
                    'code' => 'FOOD',
                    'name' => 'Food Allowance',
                    'amount' => $food,
                    'type' => 'earning',
                    'is_included_in_gross' => $getComponentFlag('FOOD', 'is_included_in_gross', true),
                    'is_taxable' => $getComponentFlag('FOOD', 'is_taxable', true),
                ];
            }
            if ($special > 0) {
                $finalEarningsBreakdown[] = [
                    'code' => 'SPECIAL',
                    'name' => 'Special Allowance',
                    'amount' => $special,
                    'type' => 'earning',
                    'is_included_in_gross' => $getComponentFlag('SPECIAL', 'is_included_in_gross', true),
                    'is_taxable' => $getComponentFlag('SPECIAL', 'is_taxable', true),
                ];
            }
        }
        if ($overtimeAmount > 0 && !array_filter($finalEarningsBreakdown, fn($e) => in_array(strtoupper($e['code'] ?? ''), ['OT', 'OVERTIME', 'OVER_TIME', 'OT_PAY'], true))) {
            $finalEarningsBreakdown[] = ['code' => 'OT', 'name' => 'Overtime Pay', 'amount' => $overtimeAmount, 'type' => 'earning', 'is_included_in_gross' => true, 'is_taxable' => true];
        }
        if ($bonus > 0 && !array_filter($finalEarningsBreakdown, fn($e) => in_array(strtoupper($e['code'] ?? ''), ['BONUS', 'BONUS_PAY'], true))) {
            $finalEarningsBreakdown[] = ['code' => 'BONUS', 'name' => 'Bonus Compensation', 'amount' => $bonus, 'type' => 'earning', 'is_included_in_gross' => true, 'is_taxable' => true];
        }
        if ($incentive > 0 && !array_filter($finalEarningsBreakdown, fn($e) => in_array(strtoupper($e['code'] ?? ''), ['INCENTIVE', 'INCENTIVE_PAY', 'PERFORMANCE_INCENTIVE'], true))) {
            $finalEarningsBreakdown[] = ['code' => 'INCENTIVE', 'name' => 'Performance Incentive', 'amount' => $incentive, 'type' => 'earning', 'is_included_in_gross' => true, 'is_taxable' => true];
        }
        if ($encashment > 0 && !array_filter($finalEarningsBreakdown, fn($e) => in_array(strtoupper($e['code'] ?? ''), ['LEAVE_ENCASHMENT', 'ENCASHMENT', 'LEAVE_ENCASH'], true))) {
            $finalEarningsBreakdown[] = ['code' => 'LEAVE_ENCASHMENT', 'name' => 'Leave Encashment', 'amount' => $encashment, 'type' => 'earning', 'is_included_in_gross' => true, 'is_taxable' => true];
        }
        if ($arrearAmount > 0 && !array_filter($finalEarningsBreakdown, fn($e) => in_array(strtoupper($e['code'] ?? ''), ['ARREAR', 'ARREARS'], true))) {
            $finalEarningsBreakdown[] = ['code' => 'ARREAR', 'name' => 'Salary Arrears', 'amount' => $arrearAmount, 'type' => 'earning', 'is_included_in_gross' => true, 'is_taxable' => true];
        }

        // -------------------------------------------------------------
        // INCOME TAX (TDS): Single Source of Truth via SalaryPolicyResolver
        // -------------------------------------------------------------
        // Taxable base contains all earnings breakdown items flagged taxable (is_taxable === true)
        $taxableBase = 0.00;
        foreach ($finalEarningsBreakdown as $feb) {
            $isEarningTaxable = isset($feb['is_taxable'])
                ? ((int)$feb['is_taxable'] === 1 || $feb['is_taxable'] === true)
                : true;
            if ($isEarningTaxable) {
                $taxableBase += (float)($feb['amount'] ?? 0.00);
            }
        }
        $taxableBase = Money::round($taxableBase, $moneyDecimals);
        $taxSettings = $activeSal['tax_settings'] ?? ($emp['tax_settings'] ?? []);
        if (empty($taxSettings['category']) && !empty($emp['tax_category'])) {
            $taxSettings['category'] = $emp['tax_category'];
        }
        if (empty($taxSettings['tin']) && !empty($emp['tax_identification_number'])) {
            $taxSettings['tin'] = $emp['tax_identification_number'];
        }

        $taxResolution = $this->policyResolver->resolveIncomeTax(
            (string)($companyId ?? ($emp['company_id'] ?? '')),
            $effectiveDate,
            $basic,
            $taxableBase,
            $taxSettings,
            $emp,
            array_merge($empContext, [
                'earnings'         => $finalEarningsBreakdown,
                'taxable_gross'    => $taxableBase,
                'gross'            => $taxableBase,
                'house_rent'       => $houseRent,
                'medical'          => $medical,
                'conveyance'       => $conveyance,
                'other_allowances' => Money::round($food + $special, $moneyDecimals),
                'annual_bonus'     => $annualBonus,
            ])
        );
        $taxDeduction = (float)($taxResolution['amount'] ?? 0.00);
        $taxResult = $taxResolution['breakdown'] ?? [];

        // Dynamic Loan Recovery (pure computation, no DB mutation)
        // Rule: Only deduct loan when disbursed_date <= payroll month end
        $loanEmi = 0.00;
        $loansToAmortize = [];
        $activeLoans = $ctx['loans'][$emp['id']] ?? [];
        foreach ($activeLoans as $l) {
            $startMonth = $l['start_month'] ?? null;
            if (!empty($startMonth)) {
                if ($startMonth > $month) {
                    continue;
                }
            } else {
                $disbursedDate = $l['disbursed_date'] ?? $l['disbursement_date'] ?? null;
                if (empty($disbursedDate) || $disbursedDate > $monthEndDate) {
                    continue;
                }
            }
            $installment = (float)($l['monthly_installment'] ?: ($l['monthly_emi'] ?? 0));
            $totalDue = isset($l['total_due']) ? (float)$l['total_due'] : ((float)($l['principal_amount'] ?? $l['loan_amount'] ?? 0) - (float)($l['total_paid'] ?? 0));
            if ($totalDue <= 0.00) {
                continue;
            }
            $remInst = isset($l['remaining_installments']) && $l['remaining_installments'] !== null ? (int)$l['remaining_installments'] : null;
            // Last installment explicitly takes the remainder so total_due becomes strictly 0.00
            if ($remInst === 1 || $totalDue <= $installment) {
                $deduct = Money::round($totalDue, $moneyDecimals);
            } else {
                $deduct = Money::round(min($installment, $totalDue), $moneyDecimals);
            }
            if ($deduct > 0) {
                $loanEmi += $deduct;
                $loansToAmortize[] = [
                    'loan_id' => $l['id'],
                    'amount'  => $deduct
                ];
            }
        }

        // Dynamic Salary Advance Recovery (outstanding balance of advances due this month)
        $advanceRecovery = 0.00;
        $advRecords = [];
        $empAdvances = $ctx['advances'][$emp['id']] ?? [];
        foreach ($empAdvances as $adv) {
            if (!in_array($adv['status'] ?? '', ['Approved', 'Partially Recovered'], true)) {
                continue;
            }
            if (!LoanAdvanceService::matchesRepaymentMonth($adv, $month)) {
                continue;
            }
            $outstanding = self::advanceOutstanding($adv);
            if ($outstanding <= 0.009) {
                continue;
            }
            $advRecords[] = $adv;
            $advanceRecovery += $outstanding;
        }
        $advanceRecovery = Money::round($advanceRecovery, $moneyDecimals);
        $advRecord = !empty($advRecords) ? $advRecords[0] : null;

        // Dynamic Unpaid Leave & Loss of Pay (supports multi-month spanning leaves + unapproved absences)
        $unpaidDays = 0.0;
        $empLeaves = $ctx['unpaid_leaves'][$emp['id']] ?? [];
        foreach ($empLeaves as $ul) {
            $unpaidDays += $this->calculateUnpaidLeaveDaysInMonth($ul, $monthStartDate, $monthEndDate);
        }
        $absentDays = (float)($ctx['absent_days'][$emp['id']] ?? 0.0);
        $totalLopDays = round($unpaidDays + $absentDays, 2);

        $dailyRateInfo = $this->resolveDailySalaryRate($basic, $month, $ruleProfile, $companyId);
        $dailyRate = $dailyRateInfo['daily_rate'];
        $unpaidLeaveDeduction = Money::round($totalLopDays * $dailyRate, $moneyDecimals);

        // Dynamic Late Penalty
        $latePenalty = $this->calculateDynamicLatePenalty(
            $emp,
            $month,
            $dailyRate,
            $ruleProfile,
            $companyId,
            $ctx['late_logs'][$emp['id']] ?? null,
            $ctx['late_tiers'] ?? null
        );

        // Structure deductions (fixed/percentage/formula) applied as "other deductions" except those governed by statutory policy (PF, TDS, gratuity)
        $customRecurringDeductions = 0.00;
        $deductionsList = $activeSal['deductions'] ?? [];
        if (!empty($deductionsList) && is_array($deductionsList)) {
            foreach ($deductionsList as &$ded) {
                $code = strtoupper(trim((string)($ded['code'] ?? $ded['component_code'] ?? '')));
                $category = strtoupper(trim((string)($ded['category'] ?? $ded['component_category'] ?? '')));
                $isEnabled = $ded['is_enabled'] ?? true;
                if (!$isEnabled) continue;

                // Statutory policy mappings strictly by code/category (zero stripos on names)
                $isStatutoryPf = in_array($code, ['PF', 'EMP_PF', 'PROVIDENT_FUND', 'EMPLOYEE_PF', 'EPF'], true)
                    || in_array($category, ['PF', 'PROVIDENT_FUND', 'STATUTORY_PF', 'EPF'], true);

                $isStatutoryTax = in_array($code, ['TAX', 'TDS', 'TAX_TDS', 'ITAX', 'INC_TAX', 'PAYE', 'WITHHOLDING_TAX', 'WHT'], true)
                    || in_array($category, ['TAX', 'TDS', 'PAYE', 'STATUTORY_TAX', 'WITHHOLDING_TAX'], true);

                $isStatutoryGratuity = in_array($code, ['GRATUITY', 'GRATUITY_PROVISION', 'ER_GRATUITY', 'STATUTORY_GRATUITY'], true)
                    || in_array($category, ['GRATUITY', 'STATUTORY_GRATUITY'], true);

                if ($isStatutoryPf || $isStatutoryTax || $isStatutoryGratuity) {
                    continue;
                }

                // Apply structure deduction: fixed / percentage / formula
                $calcType = strtolower(trim((string)($ded['calculation_type'] ?? $ded['calculationType'] ?? 'fixed')));
                $calcBase = trim((string)($ded['calculation_base'] ?? $ded['calculationBase'] ?? 'Basic Salary'));
                $rateOrAmt = (float)($ded['rate_or_amount'] ?? $ded['rateOrAmount'] ?? $ded['amount'] ?? 0.00);
                $formula = $ded['custom_formula'] ?? $ded['customFormula'] ?? $ded['formula'] ?? null;

                $dedAmt = 0.00;
                if ($calcType === 'percentage' || $calcType === 'percent_basic' || $calcType === 'percent_gross') {
                    $pct = normalize_percentage($rateOrAmt);
                    $baseVal = ($calcType === 'percent_gross' || strcasecmp($calcBase, 'Gross Salary') === 0 || strcasecmp($calcBase, 'Gross') === 0)
                        ? $gross
                        : $basic;
                    $dedAmt = Money::round($baseVal * ($pct / 100.0), $moneyDecimals);
                } elseif ($calcType === 'formula' && !empty($formula)) {
                    $varPool = [
                        'BASIC'        => $basic,
                        'Basic'        => $basic,
                        'basic'        => $basic,
                        'GROSS'        => $gross,
                        'Gross'        => $gross,
                        'gross'        => $gross,
                        'GROSS_SALARY' => $gross,
                        'GrossSalary'  => $gross,
                    ];
                    $dedAmt = Money::round((float)\App\Libraries\PayrollCalculator::evaluateSalaryFormula($formula, $varPool), $moneyDecimals);
                } else {
                    $rawVal = (float)($ded['amount'] ?? $rateOrAmt);
                    $dedAmt = ($prorationFactor < 1.0) ? Money::round($rawVal * $prorationFactor, $moneyDecimals) : Money::round($rawVal, $moneyDecimals);
                }

                // Reflect evaluated amount on the deduction item so the stored breakdown matches
                $ded['amount'] = $dedAmt;
                $customRecurringDeductions += $dedAmt;
            }
            unset($ded);
        }
        $otherDeductions = Money::round((float)($emp['other_deductions'] ?? 0.00) + $customRecurringDeductions, $moneyDecimals);

        // Statutory 50% Deduction Ceiling
        $minNetSalaryFloor = 0.0;
        if (isset($ctx['minimum_net_salary_floor'])) {
            $minNetSalaryFloor = (float)$ctx['minimum_net_salary_floor'];
        } elseif ($pbRule->has('minimum_net_salary_floor')) {
            $minNetSalaryFloor = (float)$pbRule->get('minimum_net_salary_floor');
        }

        $ceilingResult = $this->applyStatutoryDeductionCeiling($gross, [
            'tax'     => $taxDeduction,
            'pf'      => $pfDeduction,
            'lop'     => $unpaidLeaveDeduction + $latePenalty,
            'advance' => $advanceRecovery,
            'loan'    => $loanEmi,
            'other'   => $otherDeductions
        ], 0.50, $minNetSalaryFloor, $emp, $moneyDecimals);

        $appliedTax = $ceilingResult['applied']['tax'];
        $appliedPf = $ceilingResult['applied']['pf'];
        $appliedAdvance = $ceilingResult['applied']['advance'];
        $appliedLoan = $ceilingResult['applied']['loan'];
        $appliedOther = $ceilingResult['applied']['other'];
        $totalEmpDeductions = $ceilingResult['total_deductions'];
        $net = $ceilingResult['net_salary'];

        // Dynamic Asset Recovery for written-off assets (Liability reasons only)
        // Respects minimum_net_salary_floor (keeps net >= floor, carrying remainder forward)
        $empAssets = $ctx['assets'][$emp['id']] ?? null;
        if ($empAssets === null && $this->db->tableExists('company_assets')) {
            $ab = $this->db->table('company_assets')
                ->where('written_off_by_employee_id', $emp['id'])
                ->where('status', 'Written-Off')
                ->whereIn('written_off_reason', AssetWriteOffReasons::LIABILITY);
            if (!empty($companyId) && $this->db->fieldExists('company_id', 'company_assets')) {
                $ab->where('company_id', $companyId);
            }
            if ($this->db->fieldExists('deleted_at', 'company_assets')) {
                $ab->where('company_assets.deleted_at IS NULL', null, false);
            }
            if ($this->db->fieldExists('recovery_settlement_id', 'company_assets')) {
                $ab->where('company_assets.recovery_settlement_id IS NULL', null, false);
            }
            $ab->orderBy('written_off_at', 'ASC')
               ->orderBy('created_at', 'ASC')
               ->orderBy('id', 'ASC');
            $empAssetsRes = $ab->get();
            $empAssets = ($empAssetsRes && is_object($empAssetsRes)) ? $empAssetsRes->getResultArray() : [];
        } elseif ($empAssets === null) {
            $empAssets = [];
        }

        // Preloaded or dynamic posted log idempotency check for this payroll batch
        $postedAssetLogMap = $ctx['posted_asset_ids'] ?? null;
        if ($postedAssetLogMap === null && !empty($payrollId) && $this->db->tableExists('asset_recovery_log')) {
            $plRes = $this->db->table('asset_recovery_log')
                ->select('asset_id')
                ->where('payroll_id', $payrollId)
                ->where('status', 'posted')
                ->get();
            $plRows = ($plRes && is_object($plRes)) ? $plRes->getResultArray() : [];
            $postedAssetLogMap = [];
            foreach ($plRows as $plr) {
                $postedAssetLogMap[$plr['asset_id']] = true;
            }
        } elseif ($postedAssetLogMap === null) {
            $postedAssetLogMap = [];
        }

        $effectiveFloor = max(0.0, (float)$minNetSalaryFloor);
        if ($effectiveFloor > 0.0) {
            $maxAssetRecoveryDeductible = max(0.0, Money::round($net - $effectiveFloor, $moneyDecimals));
        } else {
            $maxAssetRecoveryDeductible = max(0.0, $net);
        }

        $appliedAssetRecovery = 0.00;
        $assetRecoveriesToApply = [];
        $remainingHeadroom = $maxAssetRecoveryDeductible;

        foreach ($empAssets as $asset) {
            if ($remainingHeadroom <= 0.009) {
                break;
            }
            if (strcasecmp((string)($asset['status'] ?? ''), 'Written-Off') !== 0) {
                continue;
            }
            if (!AssetWriteOffReasons::isLiability($asset['written_off_reason'] ?? '')) {
                continue;
            }
            if (!empty($asset['deleted_at']) || !empty($asset['recovery_settlement_id'])) {
                continue;
            }
            if (!empty($postedAssetLogMap[$asset['id']])) {
                continue;
            }

            $recAmount = (float)($asset['recovery_amount'] ?? 0.0);
            $recRecovered = (float)($asset['recovery_recovered_amount'] ?? 0.0);
            $remLiability = Money::round(max(0.0, $recAmount - $recRecovered), $moneyDecimals);
            if ($remLiability <= 0.009) {
                continue;
            }

            $take = min($remLiability, $remainingHeadroom);
            $take = Money::round($take, $moneyDecimals);
            if ($take <= 0.009) {
                continue;
            }

            $assetRecoveriesToApply[] = [
                'asset'                 => $asset,
                'asset_id'              => $asset['id'],
                'amount'                => $take,
                'prev_recovered_amount' => $recRecovered,
                'new_recovered_amount'  => Money::round($recRecovered + $take, $moneyDecimals),
            ];

            $appliedAssetRecovery = Money::round($appliedAssetRecovery + $take, $moneyDecimals);
            $remainingHeadroom = Money::round($remainingHeadroom - $take, $moneyDecimals);
        }

        $totalEmpDeductions = Money::round($totalEmpDeductions + $appliedAssetRecovery, $moneyDecimals);
        $net = Money::round(max(0.0, $net - $appliedAssetRecovery), $moneyDecimals);

        // Standardized deterministic Item ID: ensures PF ledger contribution idempotency
        $itemId = 'PAY-' . md5($emp['id'] . $month);

        // Dynamic Statutory Gratuity Provision (Single Rule Store)
        $effectiveCompanyId = $companyId ?? ($emp['company_id'] ?? null);
        $gratuityResult = $this->gratuityCalculator->calculateAccrual(
            (string)$effectiveCompanyId,
            array_merge($emp, [
                'gratuity_settings' => $activeSal['gratuity_settings'] ?? ($emp['gratuity_settings'] ?? null),
            ]),
            $effectiveDate,
            $basic,
            $gross,
            [
                'gratuity_settings' => $activeSal['gratuity_settings'] ?? ($emp['gratuity_settings'] ?? null),
            ]
        );
        $gratuityProvision = (float)($gratuityResult['monthly_provision_accrual'] ?? 0.00);

        $totalEmployerCost = Money::round($pfEmployerContribution + $gratuityProvision, $moneyDecimals);
        $ctc = Money::round($gross + $totalEmployerCost, $moneyDecimals);
        $annualCtc = Money::round($ctc * 12, $moneyDecimals);



        // Prepare stored breakdown: deductions
        $finalDeductionsBreakdown = [];
        $hasPfInBreakdown = false;
        $hasTaxInBreakdown = false;
        if (!empty($deductionsList) && is_array($deductionsList)) {
            foreach ($deductionsList as $d) {
                if (!($d['is_enabled'] ?? true)) continue;
                $dCode = strtoupper(trim((string)($d['code'] ?? $d['component_code'] ?? '')));
                $dCat = strtoupper(trim((string)($d['category'] ?? $d['component_category'] ?? '')));

                $isPf = in_array($dCode, ['PF', 'EMP_PF', 'PROVIDENT_FUND', 'EMPLOYEE_PF', 'EPF'], true)
                    || in_array($dCat, ['PF', 'PROVIDENT_FUND', 'STATUTORY_PF', 'EPF'], true);
                $isTax = in_array($dCode, ['TAX', 'TDS', 'TAX_TDS', 'ITAX', 'INC_TAX', 'PAYE', 'WITHHOLDING_TAX', 'WHT'], true)
                    || in_array($dCat, ['TAX', 'TDS', 'PAYE', 'STATUTORY_TAX', 'WITHHOLDING_TAX'], true);

                if ($isPf) {
                    $d['amount'] = $appliedPf;
                    $d['is_statutory'] = true;
                    $hasPfInBreakdown = true;
                } elseif ($isTax) {
                    $d['amount'] = $appliedTax;
                    $d['is_statutory'] = true;
                    $hasTaxInBreakdown = true;
                }
                if ((float)($d['amount'] ?? 0) > 0) {
                    $finalDeductionsBreakdown[] = $d;
                }
            }
        }
        if (!$hasPfInBreakdown && $appliedPf > 0) {
            $finalDeductionsBreakdown[] = [
                'component_id' => 'comp-pf',
                'code'         => 'PF',
                'name'         => 'Provident Fund (PF)',
                'amount'       => $appliedPf,
                'type'         => 'deduction',
                'is_statutory' => true
            ];
        }
        if (!$hasTaxInBreakdown && $appliedTax > 0) {
            $finalDeductionsBreakdown[] = [
                'component_id' => 'comp-tax',
                'code'         => 'TAX',
                'name'         => 'Income Tax (TDS)',
                'amount'       => $appliedTax,
                'type'         => 'deduction',
                'is_statutory' => true
            ];
        }
        if ($appliedAssetRecovery > 0) {
            $finalDeductionsBreakdown[] = [
                'component_id' => 'comp-asset-recovery',
                'code'         => 'ASSET_RECOVERY',
                'name'         => 'Asset Recovery',
                'amount'       => $appliedAssetRecovery,
                'type'         => 'deduction',
                'is_statutory' => false
            ];
        }

        $componentsBreakdown = [
            'structure_id'              => $activeSal['structure_id'] ?? ($emp['salary_structure_id'] ?? null),
            'structure_name'            => $activeSal['structure_name'] ?? ($emp['structure_name'] ?? 'Standard Salary Structure'),
            'earnings'                  => $finalEarningsBreakdown,
            'deductions'                => $finalDeductionsBreakdown,
            'employer_contributions' => [
                [
                    'component_id'     => 'ER_PF',
                    'component_code'   => 'PF_EMPLOYER',
                    'name'             => 'Employer Provident Fund Matching',
                    'type'             => 'employer_contribution',
                    'amount'           => $pfEmployerContribution,
                    'is_statutory'     => true,
                    'is_eligible'      => $pfIsEligible,
                ],
                [
                    'component_id'     => 'ER_GRATUITY',
                    'component_code'   => 'GRATUITY_PROVISION',
                    'name'             => 'Statutory Gratuity Provision',
                    'type'             => 'employer_contribution',
                    'amount'           => $gratuityProvision,
                    'is_statutory'     => true,
                    'is_eligible'      => $gratuityResult['is_eligible'] ?? false,
                    'rate_percentage'  => $gratuityResult['rate_percentage'] ?? 0,
                    'eligibility_years'=> (int)($gratuityResult['eligibility_min_years'] ?? throw new \App\Services\Rules\RuleNotConfiguredException("Missing eligibility_min_years in Gratuity rule", (string)$effectiveCompanyId, 'GRATUITY', $effectiveDate)),
                    'multiplier_days'  => (int)($gratuityResult['multiplier_days_per_year'] ?? throw new \App\Services\Rules\RuleNotConfiguredException("Missing multiplier_days_per_year in Gratuity rule", (string)$effectiveCompanyId, 'GRATUITY', $effectiveDate)),
                    'divisor_days'     => (int)($gratuityResult['month_divisor_days'] ?? throw new \App\Services\Rules\RuleNotConfiguredException("Missing month_divisor_days in Gratuity rule", (string)$effectiveCompanyId, 'GRATUITY', $effectiveDate)),
                ],
            ],
            'gratuity_provision'        => $gratuityProvision,
            'gratuity_details'          => $gratuityResult,
            'tax_details'               => [
                'policy_name'                => $taxResolution['policy_name'] ?? 'Income Tax (TDS)',
                'source_badge'               => $taxResolution['source_badge'] ?? '',
                'tax_year'                   => $taxResolution['tax_year'] ?? $taxYear,
                'tax_category'               => $taxResolution['tax_category'] ?? ($emp['tax_category'] ?? 'General'),
                'tin'                        => $taxResolution['tin'] ?? '',
                'calculation_mode'           => (string)($taxResolution['calculation_mode'] ?? throw new \App\Services\Rules\RuleNotConfiguredException("Missing calculation_mode in Tax resolution", (string)$companyId, 'TAX', $effectiveDate)),
                'is_override'                => $taxResolution['is_override'] ?? false,
                'override_reason'            => $taxResolution['override_reason'] ?? null,
                'taxable_gross'              => $taxableBase,
                'monthly_tax'                => $taxDeduction,
                'breakdown'                  => $taxResult,
                'annual_tax_amount'          => $taxResolution['annual_tax_amount'] ?? null,
                'annual_tax_year'            => $taxResolution['annual_tax_year'] ?? null,
                'auto_reference_monthly_tax' => $taxResolution['auto_reference']['monthly_tax'] ?? null,
                'auto_reference_annual_tax'  => $taxResolution['auto_reference']['annual_tax'] ?? null,
                'warnings'                   => $taxResolution['warnings'] ?? [],
            ],
            'total_employer_cost'       => $totalEmployerCost,
            'ctc'                       => $ctc,
            'annual_ctc'                => $annualCtc,
            'statutory_ceiling_applied' => $ceilingResult['cap_applied'] ?? ($ceilingResult['ceiling_breached'] ?? false),
            'minimum_net_salary_floor'  => $minNetSalaryFloor,
            'floor_warning'             => $ceilingResult['floor_warning'] ?? null,
            'warnings'                  => array_merge($taxResolution['warnings'] ?? [], $ceilingResult['warnings'] ?? []),
            'is_below_floor'            => $ceilingResult['is_below_floor'] ?? false,
            'unapplied_deductions'      => [
                'tax' => (float)($ceilingResult['unapplied']['tax'] ?? 0.0),
                'pf'  => (float)($ceilingResult['unapplied']['pf'] ?? 0.0),
                'lop' => (float)($ceilingResult['unapplied']['lop'] ?? 0.0),
            ],
            'bonus_record_ids'          => $consumedBonusIds,
            'weekly_bonus_record_ids'   => $consumedWeeklyBonusIds,
            'leave_encashment_ids'      => $consumedEncashmentIds,
            'attendance_metrics'        => [
                'scheduled_duty_hours'  => (float)($ctx['scheduled_duty_hours'][$emp['id']] ?? 0.0),
                'actual_working_hours'  => (float)($ctx['actual_working_hours'][$emp['id']] ?? 0.0),
                'unpaid_leave_days'     => $unpaidDays,
                'absent_days'           => $absentDays,
                'total_lop_days'        => $totalLopDays,
                'lop_deduction'         => $unpaidLeaveDeduction,
                'approved_ot_minutes'   => $approvedOtMins,
                'approved_ot_hours'     => $approvedOtHours,
                'overtime_amount'       => $overtimeAmount,
            ],
        ];

        $itemInsertData = [
            'id'                       => $itemId,
            'payroll_id'               => $payrollId,
            'employee_id'              => $emp['id'],
            'basic_salary'             => $basic,
            'house_rent'               => $houseRent,
            'medical'                  => $medical,
            'conveyance'               => $transport,
            'allowances'               => $allowances,
            'other_allowances'         => $otherAllowances,
            'overtime_amount'          => $overtimeAmount,
            'bonus_amount'             => $bonus,
            'incentive_amount'         => $incentive,
            'arrear_amount'            => $arrearAmount,
            'leave_encashment'         => $encashment,
            'gross_salary'             => $gross,
            'tax_deduction'            => $appliedTax,
            'pf_deduction'             => $appliedPf,
            'arrear_pf_deduction'      => $appliedArrearPf,
            'arrear_pf_employer'       => $appliedArrearPfEmployer,
            'has_pf_arrear_recovery'   => ($appliedArrearPf < 0 || $appliedArrearPfEmployer < 0) ? 1 : 0,
            'loan_emi'                 => $appliedLoan,
            'advance_recovery'         => $appliedAdvance,
            'asset_recovery'           => $appliedAssetRecovery,
            'unpaid_leave_deduction'   => $unpaidLeaveDeduction,
            'lop_deduction'            => $unpaidLeaveDeduction,
            'late_penalty'             => $latePenalty,
            'other_deductions'         => $appliedOther,
            'total_deductions'         => $totalEmpDeductions,
            'net_salary'               => $net,
            'payment_status'           => 'Draft',
            'is_pf_applicable'         => $pfIsEligible ? 1 : 0,
            'pf_status'                => $statutoryPf['status'] ?? ($pfIsEligible ? 'Enrolled' : ($isAppAdmin ? 'Not Enrolled' : ($emp['pf_status'] ?? 'Not Enrolled'))),
            'pf_rule_id'               => $pfSnapshotRuleId,
            'pf_rule_name'             => $pfSnapshotRuleName,
            'pf_contribution_type'     => $pfSnapshotContribType,
            'employer_pf_contribution' => $pfEmployerContribution,
            'gratuity_provision'       => $gratuityProvision,
            'unapplied_tax'            => (float)($ceilingResult['unapplied']['tax'] ?? 0.0),
            'unapplied_pf'             => (float)($ceilingResult['unapplied']['pf'] ?? 0.0),
            'unapplied_lop'            => (float)($ceilingResult['unapplied']['lop'] ?? 0.0),
            'tax_year'                 => $taxResolution['tax_year'] ?? $taxYear,
            'rule_version'             => (function() use ($taxResolution) {
                if (!empty($taxResolution['rules_snapshot']['TAX']['layers'])) {
                    $layers = $taxResolution['rules_snapshot']['TAX']['layers'];
                    $last = end($layers);
                    return (int)($last['version_number'] ?? 1);
                }
                return 1;
            })(),
            'tax_rule_version'         => (function() use ($taxResolution) {
                if (!empty($taxResolution['rules_snapshot']['TAX']['layers'])) {
                    $layers = $taxResolution['rules_snapshot']['TAX']['layers'];
                    $last = end($layers);
                    return (int)($last['version_number'] ?? 1);
                }
                return 1;
            })(),
            'rules_snapshot_json'      => (function() use ($gratuityResult, $pfResult, $taxResolution, $bRecords, $wRecords) {
                $bonusSnapshots = [];
                if (!empty($bRecords)) {
                    foreach ($bRecords as $br) {
                        if (!empty($br['rules_snapshot_json'])) {
                            $decoded = json_decode($br['rules_snapshot_json'], true);
                            if (is_array($decoded)) {
                                $bonusSnapshots = array_merge($bonusSnapshots, $decoded);
                            }
                        }
                    }
                }
                if (!empty($wRecords)) {
                    foreach ($wRecords as $wr) {
                        if (!empty($wr['rules_snapshot_json'])) {
                            $wDecoded = json_decode($wr['rules_snapshot_json'], true);
                            if (is_array($wDecoded)) {
                                $bonusSnapshots = array_merge($bonusSnapshots, $wDecoded);
                            }
                        }
                    }
                }
                $combined = array_merge(
                    $gratuityResult['rules_snapshot'] ?? [],
                    $pfResult['rules_snapshot'] ?? [],
                    $taxResolution['rules_snapshot'] ?? [],
                    $bonusSnapshots
                );
                return !empty($combined) ? json_encode($combined, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : null;
            })(),
            'pf_member_id'             => $emp['pf_member_id'] ?? null,
            'statutory_snapshot_json'  => json_encode($pfStatutorySnapshot),
            'components_breakdown_json' => json_encode($componentsBreakdown)
        ];

        // Synchronize post-ceiling applied PF deduction into pfResult
        $pfResult['employee_deduction'] = $appliedPf;
        $pfResult['total_pf'] = Money::round($appliedPf + $pfEmployerContribution, $moneyDecimals);

        $effects = [
            'loans'                    => $loansToAmortize,
            'applied_loan'             => $appliedLoan,
            'advances'                 => $advRecords,
            'advance_records'          => $advRecords,
            'applied_advance'          => $appliedAdvance,
            'asset_recoveries'         => $assetRecoveriesToApply,
            'applied_asset_recovery'   => $appliedAssetRecovery,
            'arrear_ids'               => $disbursedArrearIds,
            'arrear_amount'            => $arrearAmount,
            'bonus_ids'                => $consumedBonusIds,
            'weekly_bonus_ids'         => $consumedWeeklyBonusIds,
            'encashment_ids'           => $consumedEncashmentIds,
            'leave_encashment'         => $encashment,
            'pf_result'                => $pfResult,
            'pf_deduction'             => $appliedPf,
            'pf_employer_contribution' => $pfEmployerContribution,
            'gratuity_result'          => $gratuityResult,
            'gratuity_provision'       => $gratuityProvision,
            'settled_log_ids'          => $settledLogIds,
            'attendance_metrics'       => $componentsBreakdown['attendance_metrics'] ?? [],
            'breakdown'                => $componentsBreakdown,
        ];

        return [
            'eligible'          => true,
            'item'              => $itemInsertData,
            'effects'           => $effects,
            'excluded_employee' => null,
            'floor_warning'     => $ceilingResult['floor_warning'] ?? null,
            'is_below_floor'    => $ceilingResult['is_below_floor'] ?? false,
            'warnings'          => $ceilingResult['warnings'] ?? [],
        ];
    }

    /**
     * Build Batch Context with preloaded maps for high-performance batch and preview calculation
     */
    public function buildBatchContext(string $month, ?string $companyId, array $employees, ?string $branchId = null, ?string $payrollId = null): array
    {
        $daysInMonth = (int)date('t', strtotime($month . '-01'));
        if ($daysInMonth <= 0) $daysInMonth = 30;
        $monthStartDate = "$month-01";
        $monthEndDate = sprintf('%s-%02d', $month, $daysInMonth);

        $monthNum = (int)date('n', strtotime("$month-01"));
        $yearNum = (int)date('Y', strtotime("$month-01"));
        $taxYear = ($monthNum >= 7) ? "$yearNum-" . ($yearNum + 1) : ($yearNum - 1) . "-$yearNum";

        $employeeIds = array_column($employees, 'id');

        $payrollPeriodDate = sprintf('%04d-%02d-01', $yearNum, $monthNum);
        $twelveMonthsAgoDate = date('Y-m-01', strtotime('-12 months', strtotime($payrollPeriodDate)));
        $twelveMonthsAgoPeriod = date('Y-m', strtotime($twelveMonthsAgoDate));
        $earliestYear = (int)date('Y', strtotime($twelveMonthsAgoDate));

        // 1. Bonus records map (with carry-forward support for prior approved unsettled records within 12 months)
        $allBonusRecords = [];
        $stuckBonusRecords = [];
        if (!empty($employeeIds) && $this->db->tableExists('bonus_records')) {
            $monthName = date('F', strtotime("{$month}-01"));
            $bBuilder = $this->db->table('bonus_records')
                ->whereIn('employee_id', $employeeIds)
                ->where('status', 'Approved');

            if (!empty($companyId) && $this->db->fieldExists('company_id', 'bonus_records')) {
                $bBuilder->where('bonus_records.company_id', $companyId);
            }
            if ($this->db->fieldExists('deleted_at', 'bonus_records')) {
                $bBuilder->where('bonus_records.deleted_at IS NULL');
            }
            if ($this->db->fieldExists('is_settled_in_payroll', 'bonus_records')) {
                $bBuilder->where('bonus_records.is_settled_in_payroll', 0);
            }

            // Linkage check: only allow records unlinked, linked to this batch, or whose referenced batch was purged
            if ($this->db->fieldExists('payroll_id', 'bonus_records')) {
                $bBuilder->groupStart()
                    ->where('bonus_records.payroll_id IS NULL')
                    ->orWhere('bonus_records.payroll_id', '')
                    ->orWhere('bonus_records.payroll_id', $payrollId)
                    ->orWhere("bonus_records.payroll_id NOT IN (SELECT id FROM payrolls)")
                ->groupEnd();
            }

            // Carry-forward: query approved unsettled bonus records within 12-month horizon
            $monthMap = [
                'january' => 1, 'jan' => 1, '1' => 1, '01' => 1,
                'february' => 2, 'feb' => 2, '2' => 2, '02' => 2,
                'march' => 3, 'mar' => 3, '3' => 3, '03' => 3,
                'april' => 4, 'apr' => 4, '4' => 4, '04' => 4,
                'may' => 5, '5' => 5, '05' => 5,
                'june' => 6, 'jun' => 6, '6' => 6, '06' => 6,
                'july' => 7, 'jul' => 7, '7' => 7, '07' => 7,
                'august' => 8, 'aug' => 8, '8' => 8, '08' => 8,
                'september' => 9, 'sep' => 9, 'sept' => 9, '9' => 9, '09' => 9,
                'october' => 10, 'oct' => 10, '10' => 10,
                'november' => 11, 'nov' => 11, '11' => 11,
                'december' => 12, 'dec' => 12, '12' => 12,
            ];

            $hasPayoutCol = $this->db->fieldExists('payout_month', 'bonus_records');
            if ($this->db->fieldExists('year', 'bonus_records')) {
                $bBuilder->groupStart()
                    ->groupStart()
                        ->where('bonus_records.year >=', $earliestYear)
                        ->where('bonus_records.year <=', $yearNum)
                    ->groupEnd();
                if ($hasPayoutCol) {
                    $bBuilder->orGroupStart()
                        ->where('bonus_records.payout_month IS NOT NULL')
                        ->where('bonus_records.payout_month !=', '')
                        ->where('bonus_records.payout_month <=', $month)
                    ->groupEnd();
                }
                $bBuilder->groupEnd();
            }
            $bRes = $bBuilder->get();
            $bRows = ($bRes && is_object($bRes)) ? $bRes->getResultArray() : [];
            foreach ($bRows as $br) {
                $rYear = !empty($br['year']) ? (int)$br['year'] : 0;
                $bm = trim((string)($br['bonus_month'] ?? ''));
                if (preg_match('/^(\d{4})-(\d{1,2})/', $bm, $mMatches)) {
                    $recPeriod = sprintf('%04d-%02d', (int)$mMatches[1], (int)$mMatches[2]);
                } else {
                    $bmLower = strtolower($bm);
                    $mNum = $monthMap[$bmLower] ?? 0;
                    $recPeriod = ($rYear > 0 && $mNum > 0) ? sprintf('%04d-%02d', $rYear, $mNum) : null;
                }

                // Stop payout_month from pulling a bonus in earlier than its month:
                // 1. If original bonus month is later than current payroll month, it cannot be pulled in!
                if ($recPeriod !== null && $recPeriod > $month) {
                    continue;
                }

                $pm = $hasPayoutCol ? trim((string)($br['payout_month'] ?? '')) : '';

                // Treat payout_month <= payroll month as eligible. Only skip when it is later.
                if (!empty($pm)) {
                    if ($pm > $month) {
                        continue;
                    }
                    $allBonusRecords[$br['employee_id']][] = $br;
                    continue;
                }

                // If month cannot be parsed, treat as unverified/stuck rather than paying silently
                if ($recPeriod === null) {
                    $stuckBonusRecords[] = $br;
                    continue;
                }
                if ($recPeriod < $twelveMonthsAgoPeriod) {
                    $stuckBonusRecords[] = $br;
                    continue;
                }
                $allBonusRecords[$br['employee_id']][] = $br;
            }
        }

        // 1a. Weekly Attendance & Punctuality Bonus records map (with carry-forward support for prior approved unsettled weeks within 12 months)
        $allWeeklyBonusRecords = [];
        $stuckWeeklyBonusRecords = [];
        if (!empty($employeeIds) && $this->db->tableExists('weekly_bonus_records')) {
            $hasWeeklyPayoutCol = $this->db->fieldExists('payout_month', 'weekly_bonus_records');
            $wBuilder = $this->db->table('weekly_bonus_records')
                ->whereIn('employee_id', $employeeIds)
                ->where('status', 'Approved')
                ->where('is_eligible', 1)
                ->where('status !=', 'Paid');

            $wBuilder->groupStart()
                ->groupStart()
                    ->where('week_start_date <=', $monthEndDate)
                    ->where('week_start_date >=', $twelveMonthsAgoDate)
                ->groupEnd();
            if ($hasWeeklyPayoutCol) {
                $wBuilder->orGroupStart()
                    ->where('weekly_bonus_records.payout_month IS NOT NULL')
                    ->where('weekly_bonus_records.payout_month !=', '')
                    ->where('weekly_bonus_records.payout_month <=', $month)
                ->groupEnd();
            }
            $wBuilder->groupEnd();

            if (!empty($companyId) && $this->db->fieldExists('company_id', 'weekly_bonus_records')) {
                $wBuilder->where('weekly_bonus_records.company_id', $companyId);
            }
            if ($this->db->fieldExists('deleted_at', 'weekly_bonus_records')) {
                $wBuilder->where('weekly_bonus_records.deleted_at IS NULL');
            }

            // Linkage check: only allow unlinked, linked to this batch, or where linked batch was deleted
            if ($this->db->fieldExists('payroll_id', 'weekly_bonus_records')) {
                $wBuilder->groupStart()
                    ->where('weekly_bonus_records.payroll_id IS NULL')
                    ->orWhere('weekly_bonus_records.payroll_id', '')
                    ->orWhere('weekly_bonus_records.payroll_id', $payrollId)
                    ->orWhere("weekly_bonus_records.payroll_id NOT IN (SELECT id FROM payrolls)")
                ->groupEnd();
            }

            $wRes = $wBuilder->get();
            $wRows = ($wRes && is_object($wRes)) ? $wRes->getResultArray() : [];
            foreach ($wRows as $wr) {
                $weekMonth = substr((string)($wr['week_start_date'] ?? ''), 0, 7);
                $wpm = $hasWeeklyPayoutCol ? trim((string)($wr['payout_month'] ?? '')) : '';

                // Stop payout_month from pulling a bonus in earlier than its month:
                // 1. Cannot pull bonus if week itself is in a future month relative to payroll month
                if ($weekMonth > $month) {
                    continue;
                }

                // Treat payout_month <= payroll month as eligible. Only skip when it is later.
                if (!empty($wpm)) {
                    if ($wpm > $month) {
                        continue;
                    }
                    $allWeeklyBonusRecords[$wr['employee_id']][] = $wr;
                    continue;
                }

                $allWeeklyBonusRecords[$wr['employee_id']][] = $wr;
            }

            // Collect stuck weekly records older than 12 months for reporting
            $wStuckBuilder = $this->db->table('weekly_bonus_records')
                ->whereIn('employee_id', $employeeIds)
                ->where('status', 'Approved')
                ->where('status !=', 'Paid')
                ->where('week_start_date <', $twelveMonthsAgoDate);
            if ($hasWeeklyPayoutCol) {
                $wStuckBuilder->where("(weekly_bonus_records.payout_month IS NULL OR weekly_bonus_records.payout_month = '')");
            }
            if (!empty($companyId) && $this->db->fieldExists('company_id', 'weekly_bonus_records')) {
                $wStuckBuilder->where('company_id', $companyId);
            }
            if ($this->db->fieldExists('deleted_at', 'weekly_bonus_records')) {
                $wStuckBuilder->where('deleted_at IS NULL');
            }
            $wStuckRes = $wStuckBuilder->get();
            $stuckWeeklyBonusRecords = ($wStuckRes && is_object($wStuckRes)) ? $wStuckRes->getResultArray() : [];
        }

        // 1b. Fiscal Year Bonus totals (actual paid + approved + settled bonuses in current fiscal year from bonus table)
        $allFiscalBonusTotals = [];
        $bonusTable = $this->db->tableExists('bonus_records') ? 'bonus_records' : ($this->db->tableExists('bonuses') ? 'bonuses' : null);
        if (!empty($employeeIds) && $bonusTable) {
            $fyStartYear = ($monthNum >= 7) ? $yearNum : ($yearNum - 1);
            $fyEndYear = $fyStartYear + 1;

            $fyBuilder = $this->db->table($bonusTable)
                ->whereIn('employee_id', $employeeIds);

            if (!empty($companyId) && $this->db->fieldExists('company_id', $bonusTable)) {
                $fyBuilder->where("{$bonusTable}.company_id", $companyId);
            }
            if ($this->db->fieldExists('deleted_at', $bonusTable)) {
                $fyBuilder->where("{$bonusTable}.deleted_at IS NULL");
            }

            // Count ONLY Approved, Settled, or Paid bonuses in tax projection (never count Pending)
            $fyBuilder->whereIn('status', ['Approved', 'approved', 'Settled', 'settled', 'Paid', 'paid']);

            $fyRes = $fyBuilder->get();
            $fyRows = ($fyRes && is_object($fyRes)) ? $fyRes->getResultArray() : [];
            foreach ($fyRows as $fyr) {
                if ($this->isBonusInFiscalYear($fyr, $fyStartYear, $fyEndYear)) {
                    $empId = (string)($fyr['employee_id'] ?? '');
                    if ($empId !== '') {
                        $allFiscalBonusTotals[$empId] = round(($allFiscalBonusTotals[$empId] ?? 0.0) + (float)($fyr['amount'] ?? 0.0), 2);
                    }
                }
            }
        }

        // 2. Unpaid leaves map (supports multi-month leaves overlapping with the payroll month)
        $allUnpaidLeaves = [];
        if (!empty($employeeIds) && $this->db->tableExists('leave_applications') && $this->db->tableExists('leave_types')) {
            $hasStartDate  = $this->db->fieldExists('start_date', 'leave_applications');
            $hasFromDate   = $this->db->fieldExists('from_date', 'leave_applications');
            $hasEndDate    = $this->db->fieldExists('end_date', 'leave_applications');
            $hasToDate     = $this->db->fieldExists('to_date', 'leave_applications');
            $hasUnpaidDays = $this->db->fieldExists('unpaid_days', 'leave_applications');
            $hasTypeIsPaid = $this->db->fieldExists('is_paid', 'leave_types');
            $hasTypePaidPct = $this->db->fieldExists('paid_percentage', 'leave_types');

            if ($hasStartDate && $hasFromDate) {
                $startExpr = "COALESCE(leave_applications.start_date, leave_applications.from_date)";
            } elseif ($hasStartDate) {
                $startExpr = "leave_applications.start_date";
            } elseif ($hasFromDate) {
                $startExpr = "leave_applications.from_date";
            } else {
                $startExpr = null;
            }

            if ($hasEndDate && $hasToDate) {
                $endExpr = "COALESCE(leave_applications.end_date, leave_applications.to_date" . ($startExpr ? ", {$startExpr}" : "") . ")";
            } elseif ($hasEndDate) {
                $endExpr = "leave_applications.end_date";
            } elseif ($hasToDate) {
                $endExpr = "leave_applications.to_date";
            } else {
                $endExpr = $startExpr;
            }

            $selectCols = ['leave_applications.*'];
            if ($hasTypeIsPaid) {
                $selectCols[] = 'leave_types.is_paid as type_is_paid';
            }
            if ($hasTypePaidPct) {
                $selectCols[] = 'leave_types.paid_percentage as type_paid_percentage';
            }

            $lBuilder = $this->db->table('leave_applications')
                ->select(implode(', ', $selectCols))
                ->join('leave_types', 'leave_types.id = leave_applications.leave_type_id', 'left')
                ->whereIn('leave_applications.employee_id', $employeeIds)
                ->where('leave_applications.status', 'Approved');

            $lBuilder->groupStart();
            $orCount = 0;
            if ($hasTypeIsPaid) {
                $lBuilder->where('leave_types.is_paid', 0);
                $orCount++;
            }
            if ($hasUnpaidDays) {
                if ($orCount > 0) {
                    $lBuilder->orWhere('leave_applications.unpaid_days >', 0);
                } else {
                    $lBuilder->where('leave_applications.unpaid_days >', 0);
                    $orCount++;
                }
            }
            if ($hasTypePaidPct) {
                if ($orCount > 0) {
                    $lBuilder->orWhere('leave_types.paid_percentage <', 100);
                } else {
                    $lBuilder->where('leave_types.paid_percentage <', 100);
                    $orCount++;
                }
            }
            if ($orCount === 0) {
                $lBuilder->where('1=1');
            }
            $lBuilder->groupEnd();

            if ($startExpr) {
                $lBuilder->where("{$startExpr} <=", $monthEndDate);
            }
            if ($endExpr) {
                $lBuilder->where("{$endExpr} >=", $monthStartDate);
            }

            $lRes = $lBuilder->get();
            $lRows = ($lRes && is_object($lRes)) ? $lRes->getResultArray() : [];
            foreach ($lRows as $lr) {
                $allUnpaidLeaves[$lr['employee_id']][] = $lr;
            }
        }

        // 2a. Leave encashments map (approved encashments with payout_month <= payroll month)
        $allEncashments = [];
        if (!empty($employeeIds) && $this->db->tableExists('leave_encashments')) {
            $eBuilder = $this->db->table('leave_encashments')
                ->whereIn('employee_id', $employeeIds)
                ->where('status', 'Approved');

            if (!empty($companyId) && $this->db->fieldExists('company_id', 'leave_encashments')) {
                $eBuilder->where('leave_encashments.company_id', $companyId);
            }

            if ($this->db->fieldExists('payroll_id', 'leave_encashments')) {
                $eBuilder->groupStart()
                    ->where('leave_encashments.payroll_id IS NULL')
                    ->orWhere('leave_encashments.payroll_id', '')
                    ->orWhere('leave_encashments.payroll_id', $payrollId)
                    ->orWhere("leave_encashments.payroll_id NOT IN (SELECT id FROM payrolls)")
                ->groupEnd();
            }

            $hasPayoutCol = $this->db->fieldExists('payout_month', 'leave_encashments');
            $eRes = $eBuilder->get();
            $eRows = ($eRes && is_object($eRes)) ? $eRes->getResultArray() : [];
            foreach ($eRows as $er) {
                $pm = $hasPayoutCol ? trim((string)($er['payout_month'] ?? '')) : '';
                if (!empty($pm)) {
                    if ($pm > $month) {
                        continue;
                    }
                    $allEncashments[$er['employee_id']][] = $er;
                    continue;
                }

                $dt = $er['approved_at'] ?? $er['applied_at'] ?? $er['created_at'] ?? null;
                if (!empty($dt)) {
                    $dtMonth = substr((string)$dt, 0, 7);
                    if ($dtMonth > $month) {
                        continue;
                    }
                }
                $allEncashments[$er['employee_id']][] = $er;
            }
        }

        // 3. Pending arrears map
        $allPendingArrears = !empty($employeeIds) ? $this->arrearService->getPendingArrearsForEmployees($employeeIds) : [];

        // 4. Loans map (only include loans disbursed on or before payroll month end)
        $allLoans = [];
        $loanTable = $this->db->tableExists('employee_loans') ? 'employee_loans' : ($this->db->tableExists('loans') ? 'loans' : null);
        if (!empty($employeeIds) && $loanTable) {
            $loanRes = $this->db->table($loanTable)
                ->whereIn('employee_id', $employeeIds)
                ->whereIn('status', ['Active', 'active', 'Approved', 'approved'])
                ->get();
            $loanRows = ($loanRes && is_object($loanRes)) ? $loanRes->getResultArray() : [];
            foreach ($loanRows as $lr) {
                $startMonth = $lr['start_month'] ?? null;
                if (!empty($startMonth)) {
                    if ($startMonth <= $month) {
                        $allLoans[$lr['employee_id']][] = $lr;
                    }
                } else {
                    $disbDate = $lr['disbursed_date'] ?? $lr['disbursement_date'] ?? null;
                    if (!empty($disbDate) && $disbDate <= $monthEndDate) {
                        $allLoans[$lr['employee_id']][] = $lr;
                    }
                }
            }
        }

        // 5. Advances map (strict year+month match; includes partially recovered advances)
        $allAdvances = [];
        $tableAdv = $this->db->tableExists('salary_advances') ? 'salary_advances' : ($this->db->tableExists('advance_salaries') ? 'advance_salaries' : null);
        if (!empty($employeeIds) && $tableAdv) {
            $advRes = $this->db->table($tableAdv)
                ->whereIn('employee_id', $employeeIds)
                ->whereIn('status', ['Approved', 'Partially Recovered'])
                ->orderBy('created_at', 'ASC')
                ->get();
            $advRows = ($advRes && is_object($advRes)) ? $advRes->getResultArray() : [];
            foreach ($advRows as $ar) {
                if (LoanAdvanceService::matchesRepaymentMonth($ar, $month)) {
                    $allAdvances[$ar['employee_id']][] = $ar;
                }
            }
        }

        // 6. Overtime summaries map (bulk query with strict approval, deduplication, and batch-scoping)
        $allOvertime = !empty($employeeIds) ? $this->otService->getBulkSummaryForPayroll($employeeIds, $month, $companyId ?: '', $payrollId) : [];

        // Preload shifts and define working hours resolution function
        $shiftsById = [];
        if ($this->db->tableExists('shifts')) {
            $sRes = $this->db->table('shifts')->get();
            $sRows = ($sRes && is_object($sRes)) ? $sRes->getResultArray() : [];
            foreach ($sRows as $sr) {
                $shiftsById[$sr['id']] = $sr;
            }
        }

        $getShiftHours = function(?array $shift): float {
            if (!$shift) return 8.0;
            if (isset($shift['minimum_working_hours']) && (float)$shift['minimum_working_hours'] > 0) {
                return (float)$shift['minimum_working_hours'];
            }
            if (isset($shift['working_hours']) && (float)$shift['working_hours'] > 0) {
                return (float)$shift['working_hours'];
            }
            if (!empty($shift['start_time']) && !empty($shift['end_time'])) {
                $start = strtotime($shift['start_time']);
                $end = strtotime($shift['end_time']);
                $diff = ($end - $start) / 3600;
                if ($diff < 0) $diff += 24;
                if ($diff > 0) return (float)round($diff, 2);
            }
            return 8.0;
        };

        // 6a. Roster Scheduled Duty Hours & Approved Attendance Working Hours
        $allScheduledHours = [];
        $allActualWorkingHours = [];
        $allAbsentDays = [];

        $rosterAssignmentsByEmp = [];
        if (!empty($employeeIds) && $this->db->tableExists('roster_assignments')) {
            $raBuilder = $this->db->table('roster_assignments')
                ->select('roster_assignments.employee_id, roster_assignments.date AS roster_date, roster_assignments.shift_id')
                ->whereIn('roster_assignments.employee_id', $employeeIds)
                ->where('roster_assignments.date >=', $monthStartDate)
                ->where('roster_assignments.date <=', $monthEndDate);
            if ($this->db->fieldExists('is_published', 'roster_assignments')) {
                $raBuilder->where('roster_assignments.is_published', 1);
            }
            $raRes = $raBuilder->get();
            $raRows = ($raRes && is_object($raRes)) ? $raRes->getResultArray() : [];
            foreach ($raRows as $rar) {
                $rosterAssignmentsByEmp[$rar['employee_id']][$rar['roster_date']] = $rar;
            }
        }

        $attLogsByEmp = [];
        if (!empty($employeeIds) && $this->db->tableExists('attendance_logs')) {
            $attBuilder = $this->db->table('attendance_logs')
                ->whereIn('employee_id', $employeeIds)
                ->where('date >=', $monthStartDate)
                ->where('date <=', $monthEndDate);
            if (!empty($companyId)) {
                $attBuilder->where('company_id', $companyId);
            }
            $attRes = $attBuilder->get();
            $attRows = ($attRes && is_object($attRes)) ? $attRes->getResultArray() : [];
            foreach ($attRows as $ar) {
                $attLogsByEmp[$ar['employee_id']][$ar['date']] = $ar;
            }
        }

        $monthHolidays = [];
        if ($this->db->tableExists('holidays')) {
            $hBuilder = $this->db->table('holidays');
            if (!empty($companyId)) {
                $hBuilder->where('company_id', $companyId);
            }
            if ($this->db->fieldExists('status', 'holidays')) {
                $hBuilder->where('status', 'Published');
            }
            $hRes = $hBuilder->get();
            $hRows = ($hRes && is_object($hRes)) ? $hRes->getResultArray() : [];
            foreach ($hRows as $hr) {
                $hStart = $hr['from_date'] ?? ($hr['date'] ?? null);
                $hEnd   = $hr['to_date'] ?? ($hr['date'] ?? $hStart);
                if ($hStart) {
                    $s = max($monthStartDate, substr((string)$hStart, 0, 10));
                    $e = min($monthEndDate, substr((string)$hEnd, 0, 10));
                    $cur = $s;
                    while ($cur <= $e) {
                        $monthHolidays[$cur] = true;
                        $cur = date('Y-m-d', strtotime($cur . ' +1 day'));
                    }
                }
            }
        }

        $companyWeeklyOff = \App\Services\CompanyWeekendService::getCompanyWeeklyOff($companyId);

        foreach ($employees as $empRow) {
            $eId = $empRow['id'];
            $empJoinDate = employee_joining_date($empRow) ?? $empRow['employment_start_date'] ?? null;
            $empMasterShiftId = $empRow['shift_id'] ?? null;
            $masterShift = $empMasterShiftId && isset($shiftsById[$empMasterShiftId]) ? $shiftsById[$empMasterShiftId] : null;
            $defaultShiftHours = $getShiftHours($masterShift);

            $empWeeklyOff = !empty($empRow['weekly_off'])
                ? (is_array($empRow['weekly_off']) ? $empRow['weekly_off'] : array_map('trim', explode(',', (string)$empRow['weekly_off'])))
                : $companyWeeklyOff;

            $scheduledHours = 0.0;
            $actualHours = 0.0;
            $absentCount = 0.0;

            for ($d = 1; $d <= $daysInMonth; $d++) {
                $curDate = sprintf('%s-%02d', $month, $d);
                if (!empty($empJoinDate) && $curDate < $empJoinDate) {
                    continue;
                }

                $dow = date('l', strtotime($curDate));
                $isHoliday = isset($monthHolidays[$curDate]);
                $isWeeklyOff = in_array($dow, $empWeeklyOff, true);

                if (isset($rosterAssignmentsByEmp[$eId][$curDate])) {
                    $ra = $rosterAssignmentsByEmp[$eId][$curDate];
                    $raShift = (!empty($ra['shift_id']) && isset($shiftsById[$ra['shift_id']])) ? $shiftsById[$ra['shift_id']] : null;
                    $isRosterOff = ($raShift && (($raShift['outcome'] ?? '') === 'ROSTER_DAY_OFF' || !empty($raShift['is_day_off'])));
                    if (!$isRosterOff && !$isHoliday && !$isWeeklyOff) {
                        $scheduledHours += $getShiftHours($raShift);
                    }
                } elseif (!$isHoliday && !$isWeeklyOff) {
                    $scheduledHours += $defaultShiftHours;
                }

                if (isset($attLogsByEmp[$eId][$curDate])) {
                    $log = $attLogsByEmp[$eId][$curDate];
                    $st = $log['status'] ?? '';
                    if ($st !== 'Rejected') {
                        $wh = (float)($log['working_hours'] ?? ($log['net_hours'] ?? 0.0));
                        $actualHours += $wh;
                    }
                    if ($st === 'Absent') {
                        $hasLeave = false;
                        if (!empty($allUnpaidLeaves[$eId])) {
                            foreach ($allUnpaidLeaves[$eId] as $ulRow) {
                                $uStart = $ulRow['start_date'] ?? $ulRow['from_date'] ?? '';
                                $uEnd   = $ulRow['end_date'] ?? $ulRow['to_date'] ?? $uStart;
                                if ($curDate >= $uStart && $curDate <= $uEnd) {
                                    $hasLeave = true;
                                    break;
                                }
                            }
                        }
                        if (!$hasLeave) {
                            $absentCount += 1.0;
                        }
                    }
                }
            }

            $allScheduledHours[$eId]     = round($scheduledHours, 2);
            $allActualWorkingHours[$eId] = round($actualHours, 2);
            $allAbsentDays[$eId]         = round($absentCount, 2);
        }

        // 7. Late logs map
        $allLateLogs = [];
        if (!empty($employeeIds) && $this->db->tableExists('attendance_logs')) {
            $lateQuery = $this->db->table('attendance_logs')
                ->whereIn('employee_id', $employeeIds)
                ->like('date', $month, 'after');
            $this->applyLateAttendanceFilter($lateQuery);
            $lateRes = $lateQuery->get();
            $lateRows = ($lateRes && is_object($lateRes)) ? $lateRes->getResultArray() : [];
            foreach ($lateRows as $llr) {
                $allLateLogs[$llr['employee_id']][] = $llr;
            }
        }

        // 8. Late penalty tiers setting
        $lateTiers = null;
        if ($this->db->tableExists('system_settings')) {
            $tierBuilder = $this->db->table('system_settings')
                ->where('setting_key', 'late_penalty_tiers');
            if (!empty($companyId)) {
                $tierBuilder->groupStart()
                    ->where('company_id', $companyId)
                    ->orWhere('company_id IS NULL')
                ->groupEnd();
            }
            $tierRes = $tierBuilder->get();
            $tierSetting = ($tierRes && is_object($tierRes)) ? $tierRes->getRowArray() : null;
            if ($tierSetting && !empty($tierSetting['setting_value'])) {
                $lateTiers = json_decode($tierSetting['setting_value'], true);
            }
        }

        $allStuck = array_merge($stuckBonusRecords, $stuckWeeklyBonusRecords);
        if (!empty($allStuck)) {
            log_message('warning', "Batch context for {$month} found " . count($allStuck) . " approved bonus records older than the 12-month horizon (stuck bonuses).");
        }

        // 9. Minimum net salary floor from PAYROLL_BASICS rule
        $minNetSalaryFloor = 0.0;
        if (!empty($companyId)) {
            try {
                $basics = \App\Services\Rules\RuleResolver::resolveForCompany($companyId, 'PAYROLL_BASICS', $monthStartDate);
                if ($basics->has('minimum_net_salary_floor')) {
                    $minNetSalaryFloor = (float)$basics->get('minimum_net_salary_floor');
                }
            } catch (\Throwable $e) {
                log_message('warning', "Batch context for {$month} could not resolve minimum_net_salary_floor: " . $e->getMessage());
            }
        }

        // 10. Preload written-off assets with liability reasons for asset recovery
        $allAssets = [];
        if (!empty($employeeIds) && $this->db->tableExists('company_assets')) {
            $ab = $this->db->table('company_assets')
                ->whereIn('written_off_by_employee_id', $employeeIds)
                ->where('status', 'Written-Off')
                ->whereIn('written_off_reason', AssetWriteOffReasons::LIABILITY);
            if (!empty($companyId) && $this->db->fieldExists('company_id', 'company_assets')) {
                $ab->where('company_id', $companyId);
            }
            if ($this->db->fieldExists('deleted_at', 'company_assets')) {
                $ab->where('company_assets.deleted_at IS NULL', null, false);
            }
            if ($this->db->fieldExists('recovery_settlement_id', 'company_assets')) {
                $ab->where('company_assets.recovery_settlement_id IS NULL', null, false);
            }
            $ab->orderBy('written_off_at', 'ASC')
               ->orderBy('created_at', 'ASC')
               ->orderBy('id', 'ASC');
            $astRes = $ab->get();
            $astRows = ($astRes && is_object($astRes)) ? $astRes->getResultArray() : [];
            foreach ($astRows as $ar) {
                $allAssets[$ar['written_off_by_employee_id']][] = $ar;
            }
        }

        // 11. Preload posted asset recovery log IDs for idempotency guard in this batch
        $postedAssetIds = [];
        if (!empty($payrollId) && $this->db->tableExists('asset_recovery_log')) {
            $plRes = $this->db->table('asset_recovery_log')
                ->select('asset_id')
                ->where('payroll_id', $payrollId)
                ->where('status', 'posted')
                ->get();
            $plRows = ($plRes && is_object($plRes)) ? $plRes->getResultArray() : [];
            foreach ($plRows as $plr) {
                $postedAssetIds[$plr['asset_id']] = true;
            }
        }

        return [
            'month'                     => $month,
            'company_id'                => $companyId,
            'branch_id'                 => $branchId,
            'payroll_id'                => $payrollId ?: ('pr-' . bin2hex(random_bytes(8))),
            'days_in_month'             => $daysInMonth,
            'month_start_date'          => $monthStartDate,
            'month_end_date'            => $monthEndDate,
            'tax_year'                  => $taxYear,
            'month_num'                 => $monthNum,
            'year_num'                  => $yearNum,
            'bonuses'                   => $allBonusRecords,
            'weekly_bonuses'            => $allWeeklyBonusRecords,
            'stuck_bonuses'             => $allStuck,
            'fiscal_bonus_totals'       => $allFiscalBonusTotals,
            'unpaid_leaves'             => $allUnpaidLeaves,
            'leave_encashments'         => $allEncashments,
            'arrears'                   => $allPendingArrears,
            'loans'                     => $allLoans,
            'advances'                  => $allAdvances,
            'overtime'                  => $allOvertime,
            'late_logs'                 => $allLateLogs,
            'late_tiers'                => $lateTiers,
            'minimum_net_salary_floor'  => $minNetSalaryFloor,
            'assets'                    => $allAssets,
            'posted_asset_ids'          => $postedAssetIds,
            'scheduled_duty_hours'      => $allScheduledHours,
            'actual_working_hours'      => $allActualWorkingHours,
            'absent_days'               => $allAbsentDays,
        ];
    }

    /**
     * Calculate actual paid + declared bonus total for an employee in the current fiscal year from bonus table.
     */
    public function getFiscalYearBonusTotal(string $employeeId, string $month, ?string $taxYear = null): float
    {
        $bonusTable = $this->db->tableExists('bonus_records') ? 'bonus_records' : ($this->db->tableExists('bonuses') ? 'bonuses' : null);
        if (!$bonusTable || empty($employeeId)) {
            return 0.00;
        }

        if (!empty($taxYear) && preg_match('/^(\d{4})-(\d{4})$/', $taxYear, $tyMatches)) {
            $fyStartYear = (int)$tyMatches[1];
            $fyEndYear = (int)$tyMatches[2];
        } else {
            $monthNum = (int)date('n', strtotime("$month-01"));
            $yearNum = (int)date('Y', strtotime("$month-01"));
            $fyStartYear = ($monthNum >= 7) ? $yearNum : ($yearNum - 1);
            $fyEndYear = $fyStartYear + 1;
        }

        $builder = $this->db->table($bonusTable)
            ->where('employee_id', $employeeId);

        if ($this->db->fieldExists('deleted_at', $bonusTable)) {
            $builder->where("{$bonusTable}.deleted_at IS NULL");
        }

        // Count ONLY Approved, Settled, or Paid bonuses in fiscal year tax projection (never count Pending)
        $builder->whereIn('status', ['Approved', 'approved', 'Settled', 'settled', 'Paid', 'paid']);

        $res = $builder->get();
        $rows = ($res && is_object($res)) ? $res->getResultArray() : [];
        $total = 0.00;
        foreach ($rows as $r) {
            if ($this->isBonusInFiscalYear($r, $fyStartYear, $fyEndYear)) {
                $total += (float)($r['amount'] ?? 0.00);
            }
        }

        return round($total, 2);
    }

    /**
     * Check if a bonus record belongs to the specified fiscal year (July fyStartYear - June fyEndYear).
     */
    private function isBonusInFiscalYear(array $row, int $fyStartYear, int $fyEndYear): bool
    {
        $fyStartDate = sprintf('%04d-07-01', $fyStartYear);
        $fyEndDate = sprintf('%04d-06-30', $fyEndYear);

        // 1. Direct date check (e.g. date or disbursement_date)
        $dateVal = $row['date'] ?? ($row['disbursement_date'] ?? null);
        if (!empty($dateVal) && $dateVal !== '0000-00-00') {
            $d = substr((string)$dateVal, 0, 10);
            if ($d >= $fyStartDate && $d <= $fyEndDate) {
                return true;
            }
        }

        // 2. Bonus month and year check
        $bm = trim((string)($row['bonus_month'] ?? ''));
        $rYear = !empty($row['year']) ? (int)$row['year'] : 0;

        // Check if bonus_month contains YYYY-MM
        if (preg_match('/^(\d{4})-(\d{1,2})/', $bm, $mMatches)) {
            $bYear = (int)$mMatches[1];
            $bMonth = (int)$mMatches[2];
            if ($bYear === $fyStartYear && $bMonth >= 7 && $bMonth <= 12) {
                return true;
            }
            if ($bYear === $fyEndYear && $bMonth >= 1 && $bMonth <= 6) {
                return true;
            }
        }

        // Check if bonus_month is a month name or number with associated year
        $monthMap = [
            'january' => 1, 'jan' => 1, '1' => 1, '01' => 1,
            'february' => 2, 'feb' => 2, '2' => 2, '02' => 2,
            'march' => 3, 'mar' => 3, '3' => 3, '03' => 3,
            'april' => 4, 'apr' => 4, '4' => 4, '04' => 4,
            'may' => 5, '5' => 5, '05' => 5,
            'june' => 6, 'jun' => 6, '6' => 6, '06' => 6,
            'july' => 7, 'jul' => 7, '7' => 7, '07' => 7,
            'august' => 8, 'aug' => 8, '8' => 8, '08' => 8,
            'september' => 9, 'sep' => 9, 'sept' => 9, '9' => 9, '09' => 9,
            'october' => 10, 'oct' => 10, '10' => 10,
            'november' => 11, 'nov' => 11, '11' => 11,
            'december' => 12, 'dec' => 12, '12' => 12,
        ];
        $bmLower = strtolower($bm);
        $mNum = $monthMap[$bmLower] ?? 0;
        if ($mNum === 0 && !empty($bm)) {
            $ts = strtotime("{$bm} 1 2000");
            if ($ts !== false) {
                $mNum = (int)date('n', $ts);
            }
        }

        if ($rYear > 0 && $mNum >= 1 && $mNum <= 12) {
            if ($rYear === $fyStartYear && $mNum >= 7 && $mNum <= 12) {
                return true;
            }
            if ($rYear === $fyEndYear && $mNum >= 1 && $mNum <= 6) {
                return true;
            }
        }

        // 3. Fallback to created_at
        if (!empty($row['created_at']) && $row['created_at'] !== '0000-00-00 00:00:00') {
            $cDate = substr((string)$row['created_at'], 0, 10);
            if ($cDate >= $fyStartDate && $cDate <= $fyEndDate) {
                return true;
            }
        }

        return false;
    }

    /**
     * Calculate and Generate Payroll batch for all active employees
     * Formula: Net = Basic + Allowances + Overtime + Bonus + Incentive + Encashment - Tax - PF - Loan EMI - Advance Recovery - Unpaid Leave - Other Deductions
     */
    public function generatePayrollBatch(string $month, string $companyId, ?string $branchId = null, ?string $userId = null, bool $dryRun = false): array
    {
        if (empty($companyId) || trim($companyId) === '') {
            throw new \InvalidArgumentException('Company ID is required for payroll generation.');
        }

        // 1. Concurrency control: acquire exclusive lock
        $lockToken = bin2hex(random_bytes(16));
        if (!$dryRun && !$this->lockModel->acquireLock($companyId, $month, $lockToken, 300, $userId)) {
            return [
                'success'            => false,
                'blocked'            => true,
                'message'            => "Payroll generation for {$month} is already in progress for company {$companyId}. Concurrent execution blocked.",
                'batch_id'           => '',
                'payroll_id'         => null,
                'generated_count'    => 0,
                'excluded_count'     => 0,
                'excluded_employees' => []
            ];
        }

        try {
            $empFields = $this->db->tableExists('employees') ? $this->db->getFieldNames('employees') : [];
            $hasSalaryGradeCol = in_array('salary_grade_id', $empFields, true);
            
            $desgFields = $this->db->tableExists('designations') ? $this->db->getFieldNames('designations') : [];
            $desgNameCol = in_array('name', $desgFields, true) ? 'designations.name' : (in_array('title', $desgFields, true) ? 'designations.title' : "''");

            $selectStr = "employees.*, branches.name as branch_name, departments.name as department_name, {$desgNameCol} as designation_name";
            if ($hasSalaryGradeCol && $this->db->tableExists('salary_grades')) {
                $sgFields = $this->db->getFieldNames('salary_grades');
                $sgNameCol = in_array('grade_name', $sgFields, true) ? 'salary_grades.grade_name' : (in_array('name', $sgFields, true) ? 'salary_grades.name' : "''");
                $selectStr .= ", {$sgNameCol} as grade_name";
            }

            $builder = $this->db->table('employees')
                ->select($selectStr)
                ->join('branches', 'branches.id = employees.branch_id', 'left')
                ->join('departments', 'departments.id = employees.department_id', 'left')
                ->join('designations', 'designations.id = employees.designation_id', 'left');

            if ($hasSalaryGradeCol && $this->db->tableExists('salary_grades')) {
                $builder->join('salary_grades', 'salary_grades.id = employees.salary_grade_id', 'left');
            }

            $builder->where('employees.company_id', $companyId)
                ->whereIn('employees.status', [\App\Models\EmployeeModel::STATUS_ACTIVE, 'Active', 'active']);

            if ($branchId) $builder->where('employees.branch_id', $branchId);

            $empRes = $builder->get();
            $employees = ($empRes && is_object($empRes)) ? $empRes->getResultArray() : [];
            if (empty($employees)) {
                return [
                    'success'            => false,
                    'message'            => 'No active employees found for payroll processing.',
                    'batch_id'           => '',
                    'payroll_id'         => null,
                    'generated_count'    => 0,
                    'excluded_count'     => 0,
                    'excluded_employees' => []
                ];
            }

            $daysInMonth = (int)date('t', strtotime($month . '-01'));
            if ($daysInMonth <= 0) $daysInMonth = 30;
            $monthStartDate = "$month-01";
            $monthEndDate = sprintf('%s-%02d', $month, $daysInMonth);

            // Dynamic Tax Fiscal Year (Bangladesh July 1 to June 30)
            $monthNum = (int)date('n', strtotime("$month-01"));
            $yearNum = (int)date('Y', strtotime("$month-01"));
            $taxYear = ($monthNum >= 7) ? "$yearNum-" . ($yearNum + 1) : ($yearNum - 1) . "-$yearNum";

            // Idempotency: find or create batch
            $batchQuery = $this->db->table('payrolls')->where('payroll_month', $month);
            if ($companyId) {
                $batchQuery->where('company_id', $companyId);
            }
            $bqRes = $batchQuery->get();
            $existingBatch = ($bqRes && is_object($bqRes)) ? $bqRes->getRowArray() : null;

            // Guard against overwriting finalized/progressed batches (VULN-PAY-07)
            if ($existingBatch && !$dryRun) {
                $status = strtolower($existingBatch['status'] ?? '');
                $isLocked = (int)($existingBatch['is_locked'] ?? 0);
                $finalizedStatuses = ['approved', 'financeapproved', 'locked', 'paid', 'disbursed', 'closed'];
                if ($isLocked === 1 || in_array($status, $finalizedStatuses, true)) {
                    return [
                        'success'            => false,
                        'blocked'            => true,
                        'batch_id'           => $existingBatch['id'],
                        'payroll_id'         => $existingBatch['id'],
                        'message'            => "Payroll batch for month {$month} is already {$existingBatch['status']} (locked: " . ($isLocked ? 'yes' : 'no') . ") and cannot be regenerated.",
                        'generated_count'    => 0,
                        'excluded_count'     => 0,
                        'excluded_employees' => []
                    ];
                }
            }

            $payrollId = $existingBatch ? $existingBatch['id'] : ('pr-' . bin2hex(random_bytes(8)));

            if (!$dryRun) {
                // Begin database transaction BEFORE any mutations (reversals, deletions, insertions) to ensure atomic rollback
                $this->db->transStart();

                // Revert previous draft entries for this month inside transaction to ensure idempotency (tenant-scoped)
                $this->loanModel->revertMonthDeductions($month, $companyId, $payrollId);
                $this->arrearService->revertPayrollArrears($payrollId);
                $this->pfLedgerModel->revertDraftBatch($companyId, $monthNum, $yearNum);
                $this->otService->revertOvertimeSettlement($payrollId, $companyId);
                $this->revertAssetRecoveryForPayroll($payrollId, $companyId);

                // Ensure created_by and prepared_by columns exist on payrolls table if not already present
                if ($this->db->tableExists('payrolls')) {
                    $pFields = $this->db->getFieldNames('payrolls');
                    $missingPCols = [];
                    if (!in_array('created_by', $pFields, true)) {
                        $missingPCols['created_by'] = ['type' => 'VARCHAR', 'constraint' => 64, 'null' => true];
                    }
                    if (!in_array('prepared_by', $pFields, true)) {
                        $missingPCols['prepared_by'] = ['type' => 'VARCHAR', 'constraint' => 64, 'null' => true];
                    }
                    if (!empty($missingPCols)) {
                        try {
                            $forge = \Config\Database::forge();
                            $forge->addColumn('payrolls', $missingPCols);
                            $this->db->resetDataCache();
                        } catch (\Throwable $e) {}
                    }
                }

                // Clean up previous items for this batch if re-running
                if ($existingBatch) {
                    $this->db->table('payroll_items')->where('payroll_id', $payrollId)->delete();
                    if ($this->db->tableExists('bonus_records')) {
                        $this->db->table('bonus_records')
                            ->where('payroll_id', $payrollId)
                            ->where('is_settled_in_payroll', 0)
                            ->update(['payroll_id' => null]);
                    }
                    if ($this->db->tableExists('weekly_bonus_records') && $this->db->fieldExists('payroll_id', 'weekly_bonus_records')) {
                        $this->db->table('weekly_bonus_records')
                            ->where('payroll_id', $payrollId)
                            ->where('status !=', 'Paid')
                            ->update(['payroll_id' => null]);
                    }

                    $updateData = [
                        'total_employees' => count($employees),
                        'status'          => 'Draft',
                        'is_locked'       => 0,
                        'updated_at'      => date('Y-m-d H:i:s'),
                        'prepared_by'     => $userId ?: ($existingBatch['prepared_by'] ?? $existingBatch['created_by'] ?? null)
                    ];
                    if (empty($existingBatch['created_by']) && $userId) {
                        $updateData['created_by'] = $userId;
                    }
                    $this->db->table('payrolls')->where('id', $payrollId)->update($updateData);
                } else {
                    $this->db->table('payrolls')->insert([
                        'id'              => $payrollId,
                        'company_id'      => $companyId,
                        'branch_id'       => $branchId,
                        'payroll_month'   => $month,
                        'total_employees' => count($employees),
                        'status'          => 'Draft',
                        'is_locked'       => 0,
                        'created_by'      => $userId,
                        'prepared_by'     => $userId,
                        'created_at'      => date('Y-m-d H:i:s')
                    ]);
                }

                // Release truly orphaned linkages where referenced payroll was deleted
                if ($this->db->tableExists('weekly_bonus_records') && $this->db->fieldExists('payroll_id', 'weekly_bonus_records')) {
                    $this->db->query("
                        UPDATE weekly_bonus_records 
                        SET payroll_id = NULL 
                        WHERE company_id = ? 
                          AND status != 'Paid' 
                          AND payroll_id IS NOT NULL 
                          AND payroll_id != '' 
                          AND payroll_id NOT IN (SELECT id FROM payrolls)
                    ", [$companyId]);
                }
                if ($this->db->tableExists('bonus_records') && $this->db->fieldExists('payroll_id', 'bonus_records')) {
                    $this->db->query("
                        UPDATE bonus_records 
                        SET payroll_id = NULL 
                        WHERE company_id = ? 
                          AND is_settled_in_payroll = 0 
                          AND payroll_id IS NOT NULL 
                          AND payroll_id != '' 
                          AND payroll_id NOT IN (SELECT id FROM payrolls)
                    ", [$companyId]);
                }

                // Note: Holds belonging to other active drafts are never stolen or cleared without synchronization.
            }

            // Build full batch context with preloaded maps (bonus, leaves, arrears, loans, advances, OT, late logs)
            $ctx = $this->buildBatchContext($month, $companyId, $employees, $branchId, $payrollId);
            if ($dryRun) {
                $ctx['dry_run'] = true;
            }

            $totalEarnings = 0.00;
            $totalDeductions = 0.00;
            $netDisbursed = 0.00;
            $totalScheduledHours = 0.00;
            $totalActualWorkingHours = 0.00;
            $totalApprovedOtHours = 0.00;
            $totalApprovedOtMinutes = 0;
            $totalOvertimePay = 0.00;
            $totalLopDeductions = 0.00;
            $totalUnpaidDays = 0.00;
            $totalAbsentDays = 0.00;
            $payrollItemsToInsert = [];
            $allEffects = [];
            $excludedEmployees = [];
            $floorWarnings = [];
            $lowestGrossSalary = null;
            $configuredFloor = (float)($ctx['minimum_net_salary_floor'] ?? 0.0);

            foreach ($employees as $emp) {
                $calc = $this->calculateEmployeeItem($emp, $ctx, $dryRun);
                if (!$calc['eligible']) {
                    if (!empty($calc['excluded_employee'])) {
                        $excludedEmployees[] = $calc['excluded_employee'];
                    }
                    continue;
                }

                $payrollItemsToInsert[] = $calc['item'];
                $allEffects[] = [
                    'emp'     => $emp,
                    'item_id' => $calc['item']['id'],
                    'effects' => $calc['effects']
                ];

                $grossVal = (float)$calc['item']['gross_salary'];
                if ($lowestGrossSalary === null || $grossVal < $lowestGrossSalary) {
                    $lowestGrossSalary = $grossVal;
                }

                if (!empty($calc['floor_warning'])) {
                    $floorWarnings[] = $calc['floor_warning'];
                }

                $totalEarnings += (float)$calc['item']['gross_salary'];
                $totalDeductions += (float)$calc['item']['total_deductions'];
                $netDisbursed += (float)$calc['item']['net_salary'];

                $attMet = $calc['effects']['attendance_metrics'] ?? ($calc['effects']['breakdown']['attendance_metrics'] ?? []);
                $totalScheduledHours     += (float)($attMet['scheduled_duty_hours'] ?? 0.0);
                $totalActualWorkingHours += (float)($attMet['actual_working_hours'] ?? 0.0);
                $totalApprovedOtHours    += (float)($attMet['approved_ot_hours'] ?? 0.0);
                $totalApprovedOtMinutes  += (int)($attMet['approved_ot_minutes'] ?? 0);
                $totalOvertimePay        += (float)($attMet['overtime_amount'] ?? 0.0);
                $totalLopDeductions      += (float)($attMet['lop_deduction'] ?? 0.0);
                $totalUnpaidDays         += (float)($attMet['unpaid_leave_days'] ?? 0.0);
                $totalAbsentDays         += (float)($attMet['absent_days'] ?? 0.0);
            }

            $draftSummary = [
                'batch_id'                   => $payrollId,
                'payroll_month'              => $month,
                'company_id'                 => $companyId,
                'total_employees'            => count($payrollItemsToInsert),
                'total_earnings'             => $totalEarnings,
                'total_deductions'           => $totalDeductions,
                'net_disbursed'              => $netDisbursed,
                'total_scheduled_duty_hours' => round($totalScheduledHours, 2),
                'total_actual_working_hours' => round($totalActualWorkingHours, 2),
                'total_approved_ot_hours'    => round($totalApprovedOtHours, 2),
                'total_approved_ot_minutes'  => $totalApprovedOtMinutes,
                'total_overtime_pay'         => $totalOvertimePay,
                'total_lop_deductions'       => $totalLopDeductions,
                'total_unpaid_leave_days'    => round($totalUnpaidDays, 2),
                'total_absent_days'          => round($totalAbsentDays, 2),
            ];

            $settingsWarning = null;
            if ($configuredFloor > 0.0 && $lowestGrossSalary !== null && $configuredFloor > $lowestGrossSalary) {
                $settingsWarning = sprintf(
                    'Configured minimum net salary floor (%s) is greater than the company\'s lowest gross salary in this run (%s).',
                    number_format($configuredFloor, 2),
                    number_format($lowestGrossSalary, 2)
                );
            }

            if ($dryRun) {
                return [
                    'success'            => true,
                    'message'            => "Dry-run calculation completed for {$month} (Company: {$companyId}).",
                    'batch_id'           => $payrollId,
                    'payroll_id'         => $payrollId,
                    'draft_summary'      => $draftSummary,
                    'generated_count'    => count($payrollItemsToInsert),
                    'excluded_count'     => count($excludedEmployees),
                    'excluded_employees' => $excludedEmployees,
                    'items'              => $payrollItemsToInsert,
                    'effects'            => $allEffects,
                    'total_earnings'     => $totalEarnings,
                    'total_deductions'   => $totalDeductions,
                    'net_disbursed'      => $netDisbursed,
                    'floor_warnings'     => $floorWarnings,
                    'below_floor_count'  => count($floorWarnings),
                    'settings_warning'   => $settingsWarning,
                    'lowest_gross_salary'=> $lowestGrossSalary,
                    'minimum_floor'      => $configuredFloor,
                ];
            }

            if (empty($payrollItemsToInsert) && !empty($employees)) {
                $this->db->transRollback();
                return [
                    'success'            => false,
                    'message'            => "No eligible employees could be processed for {$month}. All " . count($excludedEmployees) . " employee(s) require explicit salary assignment before payroll can be calculated.",
                    'batch_id'           => $payrollId,
                    'payroll_id'         => $payrollId,
                    'generated_count'    => 0,
                    'excluded_count'     => count($excludedEmployees),
                    'excluded_employees' => $excludedEmployees
                ];
            }

            // Chunked insertion into payroll_items (100 items per chunk)
            $hasBreakdownCol    = $this->db->fieldExists('components_breakdown_json', 'payroll_items');
            $hasGratuityCol     = $this->db->fieldExists('gratuity_provision', 'payroll_items');
            $hasUnappliedTaxCol = $this->db->fieldExists('unapplied_tax', 'payroll_items');
            $hasUnappliedPfCol  = $this->db->fieldExists('unapplied_pf', 'payroll_items');
            $hasUnappliedLopCol = $this->db->fieldExists('unapplied_lop', 'payroll_items');
            $hasPfContribTypeCol = $this->db->fieldExists('pf_contribution_type', 'payroll_items');
            $hasAssetRecoveryCol = $this->db->fieldExists('asset_recovery', 'payroll_items');
            $hasBonusRecordsTable = $this->db->tableExists('bonus_records');
            $hasWeeklyBonusPayrollCol = $this->db->tableExists('weekly_bonus_records') && $this->db->fieldExists('payroll_id', 'weekly_bonus_records');

            $chunks = array_chunk($payrollItemsToInsert, 100);
            foreach ($chunks as $chunk) {
                if (!$hasBreakdownCol || !$hasGratuityCol || !$hasUnappliedTaxCol || !$hasUnappliedPfCol || !$hasUnappliedLopCol || !$hasPfContribTypeCol || !$hasAssetRecoveryCol) {
                    foreach ($chunk as &$row) {
                        if (!$hasBreakdownCol) {
                            unset($row['components_breakdown_json']);
                        }
                        if (!$hasGratuityCol) {
                            unset($row['gratuity_provision']);
                        }
                        if (!$hasUnappliedTaxCol) {
                            unset($row['unapplied_tax']);
                        }
                        if (!$hasUnappliedPfCol) {
                            unset($row['unapplied_pf']);
                        }
                        if (!$hasUnappliedLopCol) {
                            unset($row['unapplied_lop']);
                        }
                        if (!$hasPfContribTypeCol) {
                            unset($row['pf_contribution_type']);
                        }
                        if (!$hasAssetRecoveryCol) {
                            unset($row['asset_recovery']);
                        }
                    }
                    unset($row);
                }
                $this->db->table('payroll_items')->insertBatch($chunk);
            }

            // Execute Effects with Draft Semantics (recordDraftRepayment, linkArrearsToDraft, PF draft)
            foreach ($allEffects as $effect) {
                $empId = $effect['emp']['id'];
                $itemId = $effect['item_id'];
                $eff = $effect['effects'];

                // 1. Stage loan draft repayments (without amortizing live principal balance)
                $remainingLoan = (float)($eff['applied_loan'] ?? 0.0);
                if (!empty($eff['loans']) && $remainingLoan > 0.0) {
                    foreach ($eff['loans'] as $lta) {
                        if ($remainingLoan <= 0.0) break;
                        $actualLoanDeduct = min((float)$lta['amount'], $remainingLoan);
                        if ($actualLoanDeduct > 0.0) {
                            $this->loanModel->recordDraftRepayment(
                                $lta['loan_id'],
                                $empId,
                                $actualLoanDeduct,
                                $month,
                                $itemId,
                                $companyId
                            );
                            $remainingLoan = round($remainingLoan - $actualLoanDeduct, 2);
                        }
                    }
                }

                // 2. Link arrears to draft batch
                if (!empty($eff['arrear_ids'])) {
                    $this->arrearService->linkArrearsToDraft($eff['arrear_ids'], $payrollId, $month);
                }

                // 3. Record draft PF contribution in ledger (status = 'draft', authoritative balance untouched)
                $pfResult = $eff['pf_result'] ?? [];
                $pfDed = (float)($eff['pf_deduction'] ?? 0.0);
                // Use $appliedPf ($pfDed, after ceiling) in $pfResult instead of pre-ceiling $pfDeduction
                $pfResult['employee_deduction'] = $pfDed;
                $pfResult['total_pf'] = round($pfDed + (float)($pfResult['employer_contribution'] ?? 0.00), 2);
                if ($pfDed > 0 || (isset($pfResult['employer_contribution']) && (float)$pfResult['employer_contribution'] > 0)) {
                    try {
                        $actorUserId = !empty($userId) ? $userId : ($this->db->table('payrolls')->select('created_by, prepared_by')->where('id', $payrollId)->get()->getRowArray()['prepared_by'] ?? ($this->db->table('payrolls')->select('created_by')->where('id', $payrollId)->get()->getRowArray()['created_by'] ?? ($this->db->table('users')->select('id')->where('company_id', $companyId)->orderBy('created_at', 'ASC')->get()->getRowArray()['id'] ?? null)));
                        $this->pfLedgerModel->recordPayrollContribution([
                            'id'              => $payrollId,
                            'payroll_id'      => $payrollId,
                            'payroll_item_id' => $itemId,
                            'company_id'      => $companyId,
                            'employee_id'     => $empId,
                            'month'           => $monthNum,
                            'year'            => $yearNum,
                        ], $pfResult, $actorUserId, 'draft');
                    } catch (\Throwable $e) {
                        log_message('error', 'PF Ledger draft contribution error: ' . $e->getMessage());
                    }
                }


                // 5. Attendance OT logs link (do NOT mark is_settled = 1 during draft generation; settling occurs on approve/finalize)
                if (!empty($eff['settled_log_ids'])) {
                    try {
                        $this->db->table('attendance_logs')
                            ->whereIn('id', $eff['settled_log_ids'])
                            ->update([
                                'payroll_item_id' => $itemId
                            ]);
                    } catch (\Throwable $e) {
                        // Safe handling if column does not exist yet
                    }
                }

                // 6. Link consumed bonus records and weekly bonus records to draft batch (using pre-cached table/field flags)
                if (!empty($eff['bonus_ids']) && $hasBonusRecordsTable) {
                    try {
                        $this->db->table('bonus_records')
                            ->whereIn('id', $eff['bonus_ids'])
                            ->where('status', 'Approved')
                            ->where('is_settled_in_payroll', 0)
                            ->update(['payroll_id' => $payrollId]);
                    } catch (\Throwable $e) {
                        log_message('notice', "Bonus records draft linkage notice: " . $e->getMessage());
                    }
                }
                if (!empty($eff['weekly_bonus_ids']) && $hasWeeklyBonusPayrollCol) {
                    try {
                        $this->db->table('weekly_bonus_records')
                            ->whereIn('id', $eff['weekly_bonus_ids'])
                            ->where('status', 'Approved')
                            ->where('status !=', 'Paid')
                            ->update(['payroll_id' => $payrollId]);
                    } catch (\Throwable $e) {
                        log_message('notice', "Weekly bonus records draft linkage notice: " . $e->getMessage());
                    }
                }

                // 7. Link consumed leave encashment records to draft batch
                if (!empty($eff['encashment_ids']) && $this->db->tableExists('leave_encashments')) {
                    try {
                        $encUpd = ['payroll_id' => $payrollId];
                        if ($this->db->fieldExists('payroll_item_id', 'leave_encashments')) {
                            $encUpd['payroll_item_id'] = $itemId;
                        }
                        $this->db->table('leave_encashments')
                            ->whereIn('id', $eff['encashment_ids'])
                            ->where('status', 'Approved')
                            ->update($encUpd);
                    } catch (\Throwable $e) {
                        log_message('notice', "Leave encashment draft linkage notice: " . $e->getMessage());
                    }
                }

                // 8. Record asset recovery in company_assets and asset_recovery_log
                if (!empty($eff['asset_recoveries']) && $this->db->tableExists('company_assets') && $this->db->tableExists('asset_recovery_log')) {
                    $hasPayrollItemCol = $this->db->fieldExists('recovery_payroll_item_id', 'company_assets');
                    $nowDate = date('Y-m-d H:i:s');
                    foreach ($eff['asset_recoveries'] as $arEff) {
                        $assetId = $arEff['asset_id'];
                        $recAmt = (float)$arEff['amount'];
                        $prevRecovered = (float)$arEff['prev_recovered_amount'];
                        $newRecovered = (float)$arEff['new_recovered_amount'];

                        // Idempotency guard: if a posted log row already exists for this payroll_id + asset_id, do not deduct again
                        $alreadyPosted = $this->db->table('asset_recovery_log')
                            ->where('payroll_id', $payrollId)
                            ->where('asset_id', $assetId)
                            ->where('status', 'posted')
                            ->countAllResults();
                        if ($alreadyPosted > 0) {
                            continue;
                        }

                        $assetUpdate = [
                            'recovery_recovered_amount' => $newRecovered,
                            'updated_at'                => $nowDate,
                        ];
                        if ($hasPayrollItemCol) {
                            $assetUpdate['recovery_payroll_item_id'] = $itemId;
                        }
                        $this->db->table('company_assets')
                            ->where('id', $assetId)
                            ->update($assetUpdate);

                        $this->db->table('asset_recovery_log')->insert([
                            'id'                    => \Ramsey\Uuid\Uuid::uuid4()->toString(),
                            'company_id'            => $arEff['asset']['company_id'] ?? $companyId,
                            'asset_id'              => $assetId,
                            'employee_id'           => $empId,
                            'payroll_id'            => $payrollId,
                            'payroll_item_id'       => $itemId,
                            'payroll_month'         => $month,
                            'amount'                => $recAmt,
                            'prev_recovered_amount' => $prevRecovered,
                            'status'                => 'posted',
                            'created_at'            => $nowDate,
                            'reversed_at'           => null,
                        ]);
                    }
                }
            }

            // Update payrolls batch record
            $this->db->table('payrolls')->where('id', $payrollId)->update([
                'total_employees'  => count($payrollItemsToInsert),
                'total_earnings'   => $totalEarnings,
                'total_deductions' => $totalDeductions,
                'net_disbursed'    => $netDisbursed,
                'status'           => 'Draft',
                'is_locked'        => 0,
                'updated_at'       => date('Y-m-d H:i:s'),
                'prepared_by'      => $userId ?: ($existingBatch['prepared_by'] ?? $existingBatch['created_by'] ?? null)
            ]);

            // Write payroll.generated audit log for SoD enforcement
            $this->auditService->log(
                $userId,
                'payroll',
                'payroll.generated',
                $payrollId,
                null,
                [
                    'month'              => $month,
                    'company_id'         => $companyId,
                    'employee_count'     => count($payrollItemsToInsert),
                    'net_disbursed'      => $netDisbursed,
                    'below_floor_count'  => count($floorWarnings),
                    'floor_warnings'     => $floorWarnings,
                    'settings_warning'   => $settingsWarning,
                ],
                null,
                null,
                "Generated draft payroll batch for month {$month}"
            );

            $this->db->transComplete();

            $transSuccess = (bool)$this->db->transStatus();
            $genCount = count($payrollItemsToInsert);
            $exCount = count($excludedEmployees);
            $asOfDate = sprintf('%s-01', $month);
            $currency = '';
            try {
                $basics = \App\Services\Rules\RuleResolver::resolveForCompany($companyId, 'PAYROLL_BASICS', $asOfDate);
                $currency = trim((string)$basics->get('currency_code'));
            } catch (\Throwable $e) {
                log_message('warning', "Payroll generation: unable to resolve currency for company {$companyId} in month {$month}: " . $e->getMessage());
                $currency = '';
            }

            $formattedNet = number_format($netDisbursed, 2);
            $disbursedText = $currency !== '' ? "Net Disbursed: {$currency} {$formattedNet}" : "Net Disbursed: {$formattedNet}";

            $msg = $transSuccess
                ? "Payroll draft for {$month} generated successfully for {$genCount} employee(s). {$disbursedText}"
                : "Payroll calculation transaction failed for {$month} and was rolled back.";
            if ($transSuccess && $exCount > 0) {
                $msg .= " ({$exCount} employee(s) excluded: Salary Configuration Required)";
            }
            if ($transSuccess && count($floorWarnings) > 0) {
                $msg .= " [" . count($floorWarnings) . " employee(s) below minimum net salary]";
            }

            return [
                'success'            => $transSuccess,
                'message'            => $msg,
                'batch_id'           => $payrollId,
                'payroll_id'         => $payrollId,
                'draft_summary'      => $draftSummary,
                'generated_count'    => $genCount,
                'excluded_count'     => $exCount,
                'excluded_employees' => $excludedEmployees,
                'floor_warnings'     => $floorWarnings,
                'below_floor_count'  => count($floorWarnings),
                'settings_warning'   => $settingsWarning,
                'lowest_gross_salary'=> $lowestGrossSalary,
                'minimum_floor'      => $configuredFloor,
            ];
        } catch (\Throwable $e) {
            if (!$dryRun) {
                $this->db->transRollback();
            }
            log_message('error', "Payroll generation exception for {$month} (Company: {$companyId}): " . $e->getMessage());
            return [
                'success'            => false,
                'message'            => "Payroll generation failed: " . $e->getMessage(),
                'batch_id'           => $payrollId ?? '',
                'payroll_id'         => $payrollId ?? null,
                'generated_count'    => 0,
                'excluded_count'     => 0,
                'excluded_employees' => []
            ];

        } finally {
            if (!$dryRun) {
                $this->lockModel->releaseLock($companyId, $month, $lockToken);
            }
        }
    }

    /**
     * Lock / Unlock with reason and audit log
     */
    public function toggleLock(string $payrollId, bool $lock, string $userId, ?string $reason = null): array
    {
        $this->db->table('payrolls')->where('id', $payrollId)->update([
            'is_locked' => $lock ? 1 : 0,
            'locked_by' => $lock ? $userId : null,
            'locked_at' => $lock ? date('Y-m-d H:i:s') : null,
            'lock_reason' => $reason
        ]);

        return ['success' => true, 'message' => $lock ? 'Payroll batch locked against modifications.' : 'Payroll batch unlocked.'];
    }

    /**
     * Original advance amount. original_amount can legitimately be 0.00 on old rows, so fall back to amount.
     */
    private static function advanceOriginal(array $adv): float
    {
        $orig = (float)($adv['original_amount'] ?? 0);
        if ($orig <= 0) {
            $orig = (float)($adv['amount'] ?? 0);
        }
        return round($orig, 2);
    }

    /**
     * Amount still to be recovered from payroll.
     */
    private static function advanceOutstanding(array $adv): float
    {
        return round(max(0.0, self::advanceOriginal($adv) - (float)($adv['recovered_amount'] ?? 0)), 2);
    }

    /**
     * Settle advance recovery for a locked payroll batch.
     *
     * Distributes the amount actually deducted per employee (payroll_items.advance_recovery,
     * i.e. after the pay ceiling) across that employee's matching advances, oldest first.
     * Fully recovered advances become 'Recovered'; the rest become 'Partially Recovered'
     * and move to the next month. Every change is logged for unlock/revert.
     * Idempotent: if this payroll was already settled, nothing is changed.
     *
     * @return array Advance IDs touched
     */
    public function settlePayrollDeductions(string $payrollId, string $month, ?string $companyId = null): array
    {
        $tableAdv = 'salary_advances';
        if (!$this->db->tableExists($tableAdv)) {
            return [];
        }
        if (!$this->db->tableExists('salary_advance_recovery_log')) {
            throw new \RuntimeException('salary_advance_recovery_log table is missing. Run migrations.');
        }

        // Idempotency guard
        $exRes = $this->db->table('salary_advance_recovery_log')
            ->select('advance_id')
            ->where('payroll_id', $payrollId)
            ->where('status', 'posted')
            ->get();
        $existing = ($exRes && is_object($exRes)) ? $exRes->getResultArray() : [];
        if (!empty($existing)) {
            return array_values(array_unique(array_column($existing, 'advance_id')));
        }

        $itemsRes = $this->db->table('payroll_items')
            ->where('payroll_id', $payrollId)
            ->where('advance_recovery >', 0)
            ->get();
        $items = ($itemsRes && is_object($itemsRes)) ? $itemsRes->getResultArray() : [];

        $now        = date('Y-m-d H:i:s');
        $nextMonth  = date('Y-m', strtotime("{$month}-01 +1 month"));
        $nextYear   = (int)date('Y', strtotime("{$month}-01 +1 month"));
        $hasCompany = $this->db->fieldExists('company_id', $tableAdv);
        $settledIds = [];

        $this->db->transStart();

        foreach ($items as $item) {
            $remaining = round((float)$item['advance_recovery'], 2);

            $builder = $this->db->table($tableAdv)
                ->where('employee_id', $item['employee_id'])
                ->whereIn('status', ['Approved', 'Partially Recovered'])
                ->orderBy('created_at', 'ASC')
                ->orderBy('id', 'ASC');
            if (!empty($companyId) && $hasCompany) {
                $builder->where('company_id', $companyId);
            }

            $advRes = $builder->get();
            $advList = ($advRes && is_object($advRes)) ? $advRes->getResultArray() : [];
            foreach ($advList as $adv) {
                if ($remaining <= 0.009) {
                    break;
                }
                if (!LoanAdvanceService::matchesRepaymentMonth($adv, $month)) {
                    continue;
                }

                $outstanding = self::advanceOutstanding($adv);
                if ($outstanding <= 0.009) {
                    continue;
                }

                $take         = round(min($remaining, $outstanding), 2);
                $original     = self::advanceOriginal($adv);
                $newRecovered = round((float)($adv['recovered_amount'] ?? 0) + $take, 2);
                $fullyDone    = ($original - $newRecovered) <= 0.009;

                $update = [
                    'recovered_amount' => $newRecovered,
                    'updated_at'       => $now,
                ];
                if ((float)($adv['original_amount'] ?? 0) <= 0) {
                    $update['original_amount'] = $original;
                }
                if ($fullyDone) {
                    $update['status'] = 'Recovered';
                } else {
                    $update['status']          = 'Partially Recovered';
                    $update['repayment_month'] = $nextMonth;
                    $update['repayment_year']  = $nextYear;
                }

                $this->db->table($tableAdv)->where('id', $adv['id'])->update($update);

                $this->db->table('salary_advance_recovery_log')->insert([
                    'id'                   => \Ramsey\Uuid\Uuid::uuid4()->toString(),
                    'company_id'           => $adv['company_id'] ?? $companyId,
                    'advance_id'           => $adv['id'],
                    'employee_id'          => $item['employee_id'],
                    'payroll_id'           => $payrollId,
                    'payroll_item_id'      => $item['id'] ?? null,
                    'payroll_month'        => $month,
                    'amount'               => $take,
                    'prev_status'          => $adv['status'],
                    'prev_repayment_month' => $adv['repayment_month'] ?? null,
                    'prev_repayment_year'  => !empty($adv['repayment_year']) ? (int)$adv['repayment_year'] : null,
                    'status'               => 'posted',
                    'created_at'           => $now,
                ]);

                $remaining   = round($remaining - $take, 2);
                $settledIds[] = $adv['id'];
            }

            if ($remaining > 0.009) {
                log_message('warning', "Advance settlement: payroll {$payrollId} employee {$item['employee_id']} had {$remaining} deducted but no matching advance to absorb it.");
            }
        }

        $this->db->transComplete();
        if ($this->db->transStatus() === false) {
            throw new \RuntimeException("Advance settlement failed for payroll {$payrollId}.");
        }

        return array_values(array_unique($settledIds));
    }

    /**
     * Undo advance settlement for a payroll batch (used when a locked payroll is unlocked).
     * Restores recovered_amount, status and repayment month/year exactly as before locking.
     * Refuses if a later payroll already recovered the same advance.
     *
     * @return int Number of log rows reversed
     */
    public function revertPayrollAdvanceSettlement(string $payrollId, ?string $companyId = null): int
    {
        if (!$this->db->tableExists('salary_advance_recovery_log') || !$this->db->tableExists('salary_advances')) {
            return 0;
        }

        $builder = $this->db->table('salary_advance_recovery_log')
            ->where('payroll_id', $payrollId)
            ->where('status', 'posted')
            ->orderBy('created_at', 'DESC')
            ->orderBy('id', 'DESC');
        if (!empty($companyId)) {
            $builder->where('company_id', $companyId);
        }
        $logRes = $builder->get();
        $logs = ($logRes && is_object($logRes)) ? $logRes->getResultArray() : [];
        if (empty($logs)) {
            return 0;
        }

        // Safety: a later payroll must not have recovered the same advance
        foreach ($logs as $log) {
            $later = $this->db->table('salary_advance_recovery_log')
                ->where('advance_id', $log['advance_id'])
                ->where('status', 'posted')
                ->where('payroll_id !=', $payrollId)
                ->where('created_at >', $log['created_at'])
                ->countAllResults();
            if ($later > 0) {
                throw new \RuntimeException('Cannot unlock: a later payroll has already recovered part of the same salary advance. Unlock the later payroll first.');
            }
        }

        $now = date('Y-m-d H:i:s');
        $count = 0;
        $this->db->transStart();
        foreach ($logs as $log) {
            $adv = $this->db->table('salary_advances')->where('id', $log['advance_id'])->get()->getRowArray();
            if ($adv) {
                $this->db->table('salary_advances')->where('id', $log['advance_id'])->update([
                    'recovered_amount' => round(max(0.0, (float)($adv['recovered_amount'] ?? 0) - (float)$log['amount']), 2),
                    'status'           => $log['prev_status'],
                    'repayment_month'  => $log['prev_repayment_month'],
                    'repayment_year'   => $log['prev_repayment_year'],
                    'updated_at'       => $now,
                ]);
            }
            $this->db->table('salary_advance_recovery_log')->where('id', $log['id'])->update([
                'status'      => 'reversed',
                'reversed_at' => $now,
            ]);
            $count++;
        }
        $this->db->transComplete();
        if ($this->db->transStatus() === false) {
            throw new \RuntimeException("Advance settlement revert failed for payroll {$payrollId}.");
        }

        return $count;
    }

    /**
     * Undo asset recovery deductions for a payroll batch (used when re-running, unlocking, or discarding).
     * Restores recovery_recovered_amount and clears recovery_payroll_item_id on company_assets,
     * and marks asset_recovery_log rows as 'reversed' with reversed_at.
     *
     * @param string $payrollId
     * @param string|null $companyId
     * @return int Number of log rows reversed
     */
    public function revertAssetRecoveryForPayroll(string $payrollId, ?string $companyId = null): int
    {
        if (!$this->db->tableExists('asset_recovery_log') || !$this->db->tableExists('company_assets')) {
            return 0;
        }

        $builder = $this->db->table('asset_recovery_log')
            ->where('payroll_id', $payrollId)
            ->where('status', 'posted')
            ->orderBy('created_at', 'DESC')
            ->orderBy('id', 'DESC');

        if (!empty($companyId)) {
            $builder->where('company_id', $companyId);
        }

        $logRes = $builder->get();
        $logs = ($logRes && is_object($logRes)) ? $logRes->getResultArray() : [];

        if (empty($logs)) {
            return 0;
        }

        // Safety: a later payroll must not have recovered the same asset
        foreach ($logs as $log) {
            $later = $this->db->table('asset_recovery_log')
                ->where('asset_id', $log['asset_id'])
                ->where('status', 'posted')
                ->where('payroll_id !=', $payrollId)
                ->where('created_at >', $log['created_at'])
                ->countAllResults();

            if ($later > 0) {
                throw new \RuntimeException('Cannot revert: a later payroll has already recovered part of the same asset liability. Revert the later payroll first.');
            }
        }

        $now = date('Y-m-d H:i:s');
        $count = 0;
        $hasItemCol = $this->db->fieldExists('recovery_payroll_item_id', 'company_assets');

        $this->db->transStart();

        foreach ($logs as $log) {
            $asset = $this->db->table('company_assets')->where('id', $log['asset_id'])->get()->getRowArray();
            if ($asset) {
                $restoredAmount = isset($log['prev_recovered_amount'])
                    ? (float)$log['prev_recovered_amount']
                    : max(0.0, (float)($asset['recovery_recovered_amount'] ?? 0) - (float)$log['amount']);

                $assetUpdate = [
                    'recovery_recovered_amount' => round(max(0.0, $restoredAmount), 2),
                    'updated_at'                => $now,
                ];

                if ($hasItemCol && ($asset['recovery_payroll_item_id'] ?? null) === ($log['payroll_item_id'] ?? null)) {
                    $assetUpdate['recovery_payroll_item_id'] = null;
                }

                $this->db->table('company_assets')->where('id', $log['asset_id'])->update($assetUpdate);
            }

            $this->db->table('asset_recovery_log')->where('id', $log['id'])->update([
                'status'      => 'reversed',
                'reversed_at' => $now,
            ]);

            $count++;
        }

        $this->db->transComplete();

        if ($this->db->transStatus() === false) {
            throw new \RuntimeException("Asset recovery revert failed for payroll {$payrollId}.");
        }

        return $count;
    }

    /**
     * Settle payroll bonuses: Marks all approved bonus records
     * disbursed for the batch as 'Settled' (with is_settled_in_payroll = 1 and payroll_id).
     *
     * @param string $payrollId
     * @param string $month YYYY-MM
     * @param string|null $companyId
     * @return array Settled bonus IDs
     */
    public function settlePayrollBonuses(string $payrollId, string $month, ?string $companyId = null): array
    {
        if (!$this->db->tableExists('bonus_records')) {
            return [];
        }

        $itemsRes = $this->db->table('payroll_items')
            ->select('employee_id, bonus_amount AS bonus, rules_snapshot_json, components_breakdown_json')
            ->where('payroll_id', $payrollId)
            ->get();
        $items = ($itemsRes && is_object($itemsRes)) ? $itemsRes->getResultArray() : [];

        if (empty($items)) {
            return [];
        }

        $targetBonusIds = [];
        $targetWeeklyBonusIds = [];
        foreach ($items as $item) {
            if (!empty($item['components_breakdown_json'])) {
                $bd = json_decode($item['components_breakdown_json'], true);
                if (is_array($bd)) {
                    if (!empty($bd['bonus_record_ids']) && is_array($bd['bonus_record_ids'])) {
                        foreach ($bd['bonus_record_ids'] as $bid) {
                            if (!empty($bid)) {
                                $targetBonusIds[] = (string)$bid;
                            }
                        }
                    }
                    if (!empty($bd['weekly_bonus_record_ids']) && is_array($bd['weekly_bonus_record_ids'])) {
                        foreach ($bd['weekly_bonus_record_ids'] as $wbid) {
                            if (!empty($wbid)) {
                                $targetWeeklyBonusIds[] = (string)$wbid;
                            }
                        }
                    }
                }
            }
        }

        $targetBonusIds = array_values(array_unique($targetBonusIds));
        $targetWeeklyBonusIds = array_values(array_unique($targetWeeklyBonusIds));

        // Fallback for legacy batches: find bonus records linked to this payroll_id
        if (empty($targetBonusIds)) {
            $linkedRes = $this->db->table('bonus_records')
                ->select('id')
                ->where('payroll_id', $payrollId)
                ->where('status', 'Approved')
                ->where('deleted_at IS NULL')
                ->get();
            $linked = ($linkedRes && is_object($linkedRes)) ? $linkedRes->getResultArray() : [];
            $targetBonusIds = array_column($linked, 'id');
        }

        // Fallback for weekly bonus records: find weekly records linked to this payroll_id
        if (empty($targetWeeklyBonusIds) && $this->db->tableExists('weekly_bonus_records') && $this->db->fieldExists('payroll_id', 'weekly_bonus_records')) {
            $wLinkedBuilder = $this->db->table('weekly_bonus_records')
                ->select('id')
                ->where('payroll_id', $payrollId)
                ->where('status', 'Approved');
            if (!empty($companyId) && $this->db->fieldExists('company_id', 'weekly_bonus_records')) {
                $wLinkedBuilder->where('company_id', $companyId);
            }
            if ($this->db->fieldExists('deleted_at', 'weekly_bonus_records')) {
                $wLinkedBuilder->where('deleted_at IS NULL');
            }
            $wLinkedRes = $wLinkedBuilder->get();
            $wLinked = ($wLinkedRes && is_object($wLinkedRes)) ? $wLinkedRes->getResultArray() : [];
            $targetWeeklyBonusIds = array_column($wLinked, 'id');
        }

        $now = date('Y-m-d H:i:s');
        $this->db->transStart();

        $settledIds = [];
        if (!empty($targetBonusIds)) {
            $matchingRowsQuery = $this->db->table('bonus_records')
                ->select('id')
                ->whereIn('id', $targetBonusIds)
                ->where('status', 'Approved')
                ->where('is_settled_in_payroll', 0);

            if (!empty($companyId) && $this->db->fieldExists('company_id', 'bonus_records')) {
                $matchingRowsQuery->where('company_id', $companyId);
            }
            if ($this->db->fieldExists('deleted_at', 'bonus_records')) {
                $matchingRowsQuery->where('deleted_at IS NULL');
            }

            $mrRes = $matchingRowsQuery->get();
            $matchedRows = ($mrRes && is_object($mrRes)) ? $mrRes->getResultArray() : [];
            $settledIds = array_column($matchedRows, 'id');

            if (!empty($settledIds)) {
                $this->db->table('bonus_records')
                    ->whereIn('id', $settledIds)
                    ->update([
                        'is_settled_in_payroll' => 1,
                        'payroll_id'            => $payrollId,
                        'status'                => 'Settled',
                        'updated_at'            => $now,
                    ]);
            }
        }

        // Settle weekly bonuses consumed by this payroll
        if (!empty($targetWeeklyBonusIds) && $this->db->tableExists('weekly_bonus_records')) {
            $wMatchQuery = $this->db->table('weekly_bonus_records')
                ->select('id')
                ->whereIn('id', $targetWeeklyBonusIds)
                ->where('status', 'Approved');

            if (!empty($companyId) && $this->db->fieldExists('company_id', 'weekly_bonus_records')) {
                $wMatchQuery->where('company_id', $companyId);
            }
            if ($this->db->fieldExists('deleted_at', 'weekly_bonus_records')) {
                $wMatchQuery->where('deleted_at IS NULL');
            }
            $wmRes = $wMatchQuery->get();
            $wMatchedRows = ($wmRes && is_object($wmRes)) ? $wmRes->getResultArray() : [];
            $settledWeeklyIds = array_column($wMatchedRows, 'id');

            if (!empty($settledWeeklyIds)) {
                $updateFields = [
                    'status'     => 'Paid',
                    'updated_at' => $now,
                ];
                if ($this->db->fieldExists('payroll_id', 'weekly_bonus_records')) {
                    $updateFields['payroll_id'] = $payrollId;
                }

                $this->db->table('weekly_bonus_records')
                    ->whereIn('id', $settledWeeklyIds)
                    ->update($updateFields);
            }
        }

        $this->db->transComplete();
        if ($this->db->transStatus() === false) {
            log_message('error', "Failed database transaction during settlePayrollBonuses for payroll {$payrollId}");
            throw new \RuntimeException("Failed database transaction during settlePayrollBonuses for payroll {$payrollId}");
        }

        return $settledIds;
    }

    /**
     * Unsettle / Revert payroll bonuses when unlocking a batch.
     * Preserves rejected/cancelled status; only records that were Settled/Paid revert to Approved.
     *
     * @param string $payrollId
     * @param string|null $companyId
     * @return int Number of reverted records
     */
    public function unsettlePayrollBonuses(string $payrollId, ?string $companyId = null): int
    {
        $now = date('Y-m-d H:i:s');
        $this->db->transStart();

        $revertedCount = 0;
        if ($this->db->tableExists('bonus_records')) {
            // Only revert records that were marked Settled
            $builder = $this->db->table('bonus_records')
                ->where('payroll_id', $payrollId)
                ->where('status', 'Settled');

            if (!empty($companyId) && $this->db->fieldExists('company_id', 'bonus_records')) {
                $builder->where('company_id', $companyId);
            }

            $recRes = $builder->get();
            $records = ($recRes && is_object($recRes)) ? $recRes->getResultArray() : [];
            if (!empty($records)) {
                $updBuilder = $this->db->table('bonus_records')
                    ->where('payroll_id', $payrollId)
                    ->where('status', 'Settled');

                if (!empty($companyId) && $this->db->fieldExists('company_id', 'bonus_records')) {
                    $updBuilder->where('company_id', $companyId);
                }

                $updBuilder->update([
                    'is_settled_in_payroll' => 0,
                    'payroll_id'            => null,
                    'status'                => 'Approved',
                    'updated_at'            => $now
                ]);
                $revertedCount += count($records);
            }

            // For other records linked to this payroll_id (draft-linked), clear payroll_id without changing status
            $otherBonusBuilder = $this->db->table('bonus_records')
                ->where('payroll_id', $payrollId)
                ->where('status !=', 'Settled');
            if (!empty($companyId) && $this->db->fieldExists('company_id', 'bonus_records')) {
                $otherBonusBuilder->where('company_id', $companyId);
            }
            $otherBonusBuilder->update([
                'payroll_id' => null,
                'updated_at' => $now
            ]);
        }

        // Revert weekly bonus records: ONLY records that were Paid revert to Approved!
        // Rejected or other records keep their status and only have payroll_id cleared.
        if ($this->db->tableExists('weekly_bonus_records') && $this->db->fieldExists('payroll_id', 'weekly_bonus_records')) {
            $wBuilder = $this->db->table('weekly_bonus_records')
                ->where('payroll_id', $payrollId)
                ->where('status', 'Paid');

            if (!empty($companyId) && $this->db->fieldExists('company_id', 'weekly_bonus_records')) {
                $wBuilder->where('company_id', $companyId);
            }

            $wRecRes = $wBuilder->get();
            $wRecords = ($wRecRes && is_object($wRecRes)) ? $wRecRes->getResultArray() : [];
            if (!empty($wRecords)) {
                $wUpd = $this->db->table('weekly_bonus_records')
                    ->where('payroll_id', $payrollId)
                    ->where('status', 'Paid');

                if (!empty($companyId) && $this->db->fieldExists('company_id', 'weekly_bonus_records')) {
                    $wUpd->where('company_id', $companyId);
                }

                $wUpd->update([
                    'payroll_id' => null,
                    'status'     => 'Approved',
                    'updated_at' => $now,
                ]);
                $revertedCount += count($wRecords);
            }

            // For any other weekly records linked to this payroll (e.g. Rejected or Draft-linked), only clear payroll_id
            $wOtherUpd = $this->db->table('weekly_bonus_records')
                ->where('payroll_id', $payrollId)
                ->where('status !=', 'Paid');

            if (!empty($companyId) && $this->db->fieldExists('company_id', 'weekly_bonus_records')) {
                $wOtherUpd->where('company_id', $companyId);
            }

            $wOtherUpd->update([
                'payroll_id' => null,
                'updated_at' => $now,
            ]);
        }

        $this->db->transComplete();
        if ($this->db->transStatus() === false) {
            log_message('error', "Failed database transaction during unsettlePayrollBonuses for payroll {$payrollId}");
            return 0;
        }

        return $revertedCount;
    }

    /**
     * Query approved leave encashments eligible for payout in the given month for an employee.
     */
    public function getApprovedEncashmentsForEmployee(string $employeeId, string $month, ?string $companyId = null, ?string $payrollId = null): array
    {
        if (!$this->db->tableExists('leave_encashments') || empty($employeeId)) {
            return [];
        }

        $builder = $this->db->table('leave_encashments')
            ->where('employee_id', $employeeId)
            ->where('status', 'Approved');

        if (!empty($companyId) && $this->db->fieldExists('company_id', 'leave_encashments')) {
            $builder->where('leave_encashments.company_id', $companyId);
        }

        if ($this->db->fieldExists('payroll_id', 'leave_encashments')) {
            $builder->groupStart()
                ->where('leave_encashments.payroll_id IS NULL')
                ->orWhere('leave_encashments.payroll_id', '')
                ->orWhere('leave_encashments.payroll_id', $payrollId)
                ->orWhere("leave_encashments.payroll_id NOT IN (SELECT id FROM payrolls)")
            ->groupEnd();
        }

        $hasPayoutCol = $this->db->fieldExists('payout_month', 'leave_encashments');
        $rowRes = $builder->get();
        $rows = ($rowRes && is_object($rowRes)) ? $rowRes->getResultArray() : [];
        $eligible = [];
        foreach ($rows as $er) {
            $pm = $hasPayoutCol ? trim((string)($er['payout_month'] ?? '')) : '';
            if (!empty($pm)) {
                if ($pm > $month) {
                    continue;
                }
                $eligible[] = $er;
                continue;
            }

            $dt = $er['approved_at'] ?? $er['applied_at'] ?? $er['created_at'] ?? null;
            if (!empty($dt)) {
                $dtMonth = substr((string)$dt, 0, 7);
                if ($dtMonth > $month) {
                    continue;
                }
            }
            $eligible[] = $er;
        }

        return $eligible;
    }

    /**
     * Settle leave encashments paid in a finalized payroll batch.
     * Transitions status from 'Approved' to 'Paid' and sets paid_at timestamp.
     *
     * @param string $payrollId
     * @param string $month YYYY-MM
     * @param string|null $companyId
     * @return array Settled encashment IDs
     */
    public function settlePayrollEncashments(string $payrollId, string $month, ?string $companyId = null): array
    {
        if (!$this->db->tableExists('leave_encashments')) {
            return [];
        }

        $itemsRes = $this->db->table('payroll_items')
            ->select('employee_id, leave_encashment, components_breakdown_json')
            ->where('payroll_id', $payrollId)
            ->get();
        $items = ($itemsRes && is_object($itemsRes)) ? $itemsRes->getResultArray() : [];

        if (empty($items)) {
            return [];
        }

        $targetEncashmentIds = [];
        foreach ($items as $item) {
            if (!empty($item['components_breakdown_json'])) {
                $bd = json_decode($item['components_breakdown_json'], true);
                if (is_array($bd) && !empty($bd['leave_encashment_ids']) && is_array($bd['leave_encashment_ids'])) {
                    foreach ($bd['leave_encashment_ids'] as $eid) {
                        if (!empty($eid)) {
                            $targetEncashmentIds[] = (string)$eid;
                        }
                    }
                }
            }
        }
        $targetEncashmentIds = array_values(array_unique($targetEncashmentIds));

        // Fallback for batches where breakdown does not store IDs
        if (empty($targetEncashmentIds)) {
            $linkedRes = $this->db->table('leave_encashments')
                ->select('id')
                ->where('payroll_id', $payrollId)
                ->where('status', 'Approved')
                ->get();
            $linked = ($linkedRes && is_object($linkedRes)) ? $linkedRes->getResultArray() : [];
            $targetEncashmentIds = array_column($linked, 'id');
        }

        if (empty($targetEncashmentIds)) {
            return [];
        }

        $now = date('Y-m-d H:i:s');
        $this->db->transStart();

        $matchingQuery = $this->db->table('leave_encashments')
            ->select('id')
            ->whereIn('id', $targetEncashmentIds)
            ->where('status', 'Approved');

        if (!empty($companyId) && $this->db->fieldExists('company_id', 'leave_encashments')) {
            $matchingQuery->where('company_id', $companyId);
        }

        $mqRes = $matchingQuery->get();
        $matchedRows = ($mqRes && is_object($mqRes)) ? $mqRes->getResultArray() : [];
        $settledIds = array_column($matchedRows, 'id');

        if (!empty($settledIds)) {
            $updateFields = [
                'status'     => 'Paid',
                'payroll_id' => $payrollId,
                'updated_at' => $now,
            ];
            if ($this->db->fieldExists('paid_at', 'leave_encashments')) {
                $updateFields['paid_at'] = $now;
            }
            $this->db->table('leave_encashments')
                ->whereIn('id', $settledIds)
                ->update($updateFields);
        }

        $this->db->transComplete();
        if ($this->db->transStatus() === false) {
            log_message('error', "Failed database transaction during settlePayrollEncashments for payroll {$payrollId}");
            throw new \RuntimeException("Failed database transaction during settlePayrollEncashments for payroll {$payrollId}");
        }

        return $settledIds;
    }

    /**
     * Unsettle / Revert leave encashments when unlocking or discarding a batch.
     * Records with status = 'Paid' revert back to 'Approved'.
     * Draft-linked records have their payroll_id and payroll_item_id cleared.
     *
     * @param string $payrollId
     * @param string|null $companyId
     * @return int Number of reverted records
     */
    public function unsettlePayrollEncashments(string $payrollId, ?string $companyId = null): int
    {
        $now = date('Y-m-d H:i:s');
        $this->db->transStart();

        $revertedCount = 0;
        if ($this->db->tableExists('leave_encashments')) {
            $builder = $this->db->table('leave_encashments')
                ->where('payroll_id', $payrollId)
                ->where('status', 'Paid');

            if (!empty($companyId) && $this->db->fieldExists('company_id', 'leave_encashments')) {
                $builder->where('company_id', $companyId);
            }

            $recRes = $builder->get();
            $records = ($recRes && is_object($recRes)) ? $recRes->getResultArray() : [];
            if (!empty($records)) {
                $updBuilder = $this->db->table('leave_encashments')
                    ->where('payroll_id', $payrollId)
                    ->where('status', 'Paid');

                if (!empty($companyId) && $this->db->fieldExists('company_id', 'leave_encashments')) {
                    $updBuilder->where('company_id', $companyId);
                }

                $updFields = [
                    'status'     => 'Approved',
                    'payroll_id' => null,
                    'updated_at' => $now,
                ];
                if ($this->db->fieldExists('payroll_item_id', 'leave_encashments')) {
                    $updFields['payroll_item_id'] = null;
                }
                if ($this->db->fieldExists('paid_at', 'leave_encashments')) {
                    $updFields['paid_at'] = null;
                }

                $updBuilder->update($updFields);
                $revertedCount += count($records);
            }

            // For draft-linked records (status != 'Paid'), clear payroll_id without changing status
            $otherBuilder = $this->db->table('leave_encashments')
                ->where('payroll_id', $payrollId)
                ->where('status !=', 'Paid');
            if (!empty($companyId) && $this->db->fieldExists('company_id', 'leave_encashments')) {
                $otherBuilder->where('company_id', $companyId);
            }
            $otherFields = [
                'payroll_id' => null,
                'updated_at' => $now,
            ];
            if ($this->db->fieldExists('payroll_item_id', 'leave_encashments')) {
                $otherFields['payroll_item_id'] = null;
            }
            $otherBuilder->update($otherFields);
        }

        $this->db->transComplete();
        if ($this->db->transStatus() === false) {
            log_message('error', "Failed database transaction during unsettlePayrollEncashments for payroll {$payrollId}");
            return 0;
        }

        return $revertedCount;
    }

    /**
     * Authoritative Statutory Deduction Ceiling Engine (50% Statutory Cap)
     * Priority: Tax -> PF -> Advance Recovery -> Loan EMI -> Other (LOP applied in full outside ceiling)
     *
     * Option C Decision: LOP is intentionally outside the 50% statutory deduction ceiling;
     * it is deducted in full and is not counted toward the 50% ceiling.
     * Other deductions (loan, advance, and so on) still respect the 50% ceiling as they do today.
     *
     * @param float $gross
     * @param array $requestedDeductions ['tax' => float, 'pf' => float, 'lop' => float, 'advance' => float, 'loan' => float, 'other' => float]
     * @param float $ceilingRatio (default 0.50)
     * @param float $minNetSalaryFloor (default 0.0, 0 means no floor)
     * @param array|null $employeeInfo Optional employee metadata for warnings
     * @return array
     */
    public function applyStatutoryDeductionCeiling(
        float $gross,
        array $requestedDeductions,
        float $ceilingRatio = 0.50,
        float $minNetSalaryFloor = 0.0,
        ?array $employeeInfo = null,
        ?int $moneyDecimals = null
    ): array {
        if ($moneyDecimals === null) {
            if (!empty($employeeInfo['company_id'])) {
                $asOf = null;
                $itemMonth = (string)($employeeInfo['month'] ?? $employeeInfo['payroll_month'] ?? '');
                if (preg_match('/^\d{4}-\d{2}$/', $itemMonth)) {
                    $asOf = $itemMonth . '-01';
                } elseif (!empty($employeeInfo['month_start_date'])) {
                    $asOf = date('Y-m-d', strtotime((string)$employeeInfo['month_start_date']));
                }
                $moneyDecimals = Money::decimals((string)$employeeInfo['company_id'], $employeeInfo, $asOf);
            } else {
                try {
                    $moneyDecimals = Money::decimals(null, $employeeInfo);
                } catch (\Throwable $e) {
                    $moneyDecimals = 2;
                }
            }
        }

        $gross = Money::round(max(0.0, $gross), $moneyDecimals);
        $statutoryCeilingAmount = Money::round($gross * $ceilingRatio, $moneyDecimals);
        $remainingCeiling = $statutoryCeilingAmount;

        // 1. Mandatory: Tax
        $taxRequested = Money::round(max(0.0, (float)($requestedDeductions['tax'] ?? 0.0)), $moneyDecimals);
        $taxApplied = min($taxRequested, $remainingCeiling);
        $remainingCeiling = max(0.0, Money::round($remainingCeiling - $taxApplied, $moneyDecimals));
        $unappliedTax = Money::round($taxRequested - $taxApplied, $moneyDecimals);

        // 2. Mandatory: PF
        $pfRequested = Money::round(max(0.0, (float)($requestedDeductions['pf'] ?? 0.0)), $moneyDecimals);
        $pfApplied = min($pfRequested, $remainingCeiling);
        $remainingCeiling = max(0.0, Money::round($remainingCeiling - $pfApplied, $moneyDecimals));
        $unappliedPf = Money::round($pfRequested - $pfApplied, $moneyDecimals);

        // 3. Advance Recovery
        $advanceRequested = Money::round(max(0.0, (float)($requestedDeductions['advance'] ?? 0.0)), $moneyDecimals);
        $advanceApplied = min($advanceRequested, $remainingCeiling);
        $remainingCeiling = max(0.0, Money::round($remainingCeiling - $advanceApplied, $moneyDecimals));
        $unrecoveredAdvance = Money::round($advanceRequested - $advanceApplied, $moneyDecimals);

        // 4. Loan EMI
        $loanRequested = Money::round(max(0.0, (float)($requestedDeductions['loan'] ?? 0.0)), $moneyDecimals);
        $loanApplied = min($loanRequested, $remainingCeiling);
        $remainingCeiling = max(0.0, Money::round($remainingCeiling - $loanApplied, $moneyDecimals));
        $unrecoveredLoan = Money::round($loanRequested - $loanApplied, $moneyDecimals);

        // 5. Other / Discretionary Deductions
        $otherRequested = Money::round(max(0.0, (float)($requestedDeductions['other'] ?? 0.0)), $moneyDecimals);
        $otherApplied = min($otherRequested, $remainingCeiling);
        $remainingCeiling = max(0.0, Money::round($remainingCeiling - $otherApplied, $moneyDecimals));
        $unappliedOther = Money::round($otherRequested - $otherApplied, $moneyDecimals);

        // 6. Statutory / Contractual LOP (applied in full outside the ceiling)
        // Option C Decision: LOP is intentionally outside the 50% statutory deduction ceiling;
        // it is deducted in full and is not counted toward the 50% ceiling.
        // Other deductions (loan, advance, etc.) still respect the 50% ceiling.
        $lopRequested = Money::round(max(0.0, (float)($requestedDeductions['lop'] ?? 0.0)), $moneyDecimals);
        $lopApplied = $lopRequested;
        $unappliedLop = 0.0;

        $totalApplied = Money::round($taxApplied + $pfApplied + $lopApplied + $advanceApplied + $loanApplied + $otherApplied, $moneyDecimals);
        // Net salary must never go below 0 (existing max(0, ...) behavior)
        $net = max(0.0, Money::round($gross - $totalApplied, $moneyDecimals));

        $totalRequested = Money::round($taxRequested + $pfRequested + $lopRequested + $advanceRequested + $loanRequested + $otherRequested, $moneyDecimals);
        $ceilingSubjectRequested = Money::round($taxRequested + $pfRequested + $advanceRequested + $loanRequested + $otherRequested, $moneyDecimals);

        // Non-LOP deductions applied
        $otherDeductionsApplied = Money::round($taxApplied + $pfApplied + $advanceApplied + $loanApplied + $otherApplied, $moneyDecimals);

        $warnings = [];
        $floorWarning = null;
        $minNetSalaryFloor = Money::round(max(0.0, (float)$minNetSalaryFloor), $moneyDecimals);

        // Minimum net salary floor evaluation: if net salary < minimum_net_salary_floor (and floor > 0)
        // Do NOT block payroll and do NOT change the amounts. Only add a warning.
        if ($minNetSalaryFloor > 0.0 && $net < $minNetSalaryFloor) {
            $shortfall = Money::round($minNetSalaryFloor - $net, $moneyDecimals);
            $empName = !empty($employeeInfo['first_name'])
                ? trim($employeeInfo['first_name'] . ' ' . ($employeeInfo['last_name'] ?? ''))
                : ($employeeInfo['employee_name'] ?? ($employeeInfo['name'] ?? ($employeeInfo['employee_id'] ?? ($employeeInfo['id'] ?? 'Employee'))));
            $empCode = $employeeInfo['employee_code'] ?? ($employeeInfo['employeeId'] ?? ($employeeInfo['id'] ?? ''));

            $floorWarning = [
                'employee'         => $empName,
                'employee_id'      => $employeeInfo['id'] ?? ($employeeInfo['employee_id'] ?? null),
                'employee_name'    => $empName,
                'employee_code'    => $empCode,
                'gross'            => $gross,
                'lop_amount'       => $lopApplied,
                'other_deductions' => $otherDeductionsApplied,
                'net'              => $net,
                'floor'            => $minNetSalaryFloor,
                'shortfall'        => $shortfall,
                'message'          => sprintf(
                    'Employee %s net salary (%s) is below minimum net salary floor (%s). Shortfall: %s.',
                    $empName,
                    number_format($net, $moneyDecimals),
                    number_format($minNetSalaryFloor, $moneyDecimals),
                    number_format($shortfall, $moneyDecimals)
                )
            ];
            $warnings[] = $floorWarning;
        }

        return [
            'gross'                      => $gross,
            'ceiling_ratio'              => $ceilingRatio,
            'ceiling_amount'             => $statutoryCeilingAmount,
            'applied'                    => [
                'tax'     => $taxApplied,
                'pf'      => $pfApplied,
                'lop'     => $lopApplied,
                'advance' => $advanceApplied,
                'loan'    => $loanApplied,
                'other'   => $otherApplied,
            ],
            'unapplied'                  => [
                'tax'     => $unappliedTax,
                'pf'      => $unappliedPf,
                'lop'     => $unappliedLop,
                'advance' => $unrecoveredAdvance,
                'loan'    => $unrecoveredLoan,
                'other'   => $unappliedOther,
            ],
            'total_deductions'           => $totalApplied,
            'total_requested_deductions' => $totalRequested,
            'net_salary'                 => $net,
            'ceiling_breached'           => $ceilingSubjectRequested > $statutoryCeilingAmount,
            'minimum_net_salary_floor'   => $minNetSalaryFloor,
            'warnings'                   => $warnings,
            'floor_warning'              => $floorWarning,
            'is_below_floor'             => ($floorWarning !== null),
        ];
    }

    /**
     * Authoritative helper for calculating an adjusted individual payroll item.
     * Centralizes gross, statutory deduction ceiling, and net calculations for manual adjustments.
     *
     * @param array $item Existing payroll item array
     * @param array $adjustments Array of user adjustment inputs (bonus, tax, pf, other_deductions, etc.)
     * @param float $minNetSalaryFloor
     * @return array
     */
    public function calculateAdjustedItem(array $item, array $adjustments = [], float $minNetSalaryFloor = 0.0): array
    {
        $moneyDecimals = null;
        $floorAsOf = date('Y-m-d');
        $itemMonth = (string)($item['month'] ?? $item['payroll_month'] ?? '');
        if (preg_match('/^\d{4}-\d{2}$/', $itemMonth)) {
            $floorAsOf = $itemMonth . '-01';
        } elseif (!empty($item['month_start_date'])) {
            $floorAsOf = date('Y-m-d', strtotime((string)$item['month_start_date']));
        }

        if (!empty($item['company_id'])) {
            try {
                $pbRule = \App\Services\Rules\RuleResolver::resolveForCompany($item['company_id'], 'PAYROLL_BASICS', $floorAsOf);
                $moneyDecimals = Money::decimals($pbRule);
                if ($minNetSalaryFloor <= 0.0 && $pbRule->has('minimum_net_salary_floor')) {
                    $minNetSalaryFloor = (float)$pbRule->get('minimum_net_salary_floor');
                }
            } catch (\Throwable $e) {
                log_message('warning', "Could not resolve PAYROLL_BASICS for company {$item['company_id']} in calculateAdjustedItem: " . $e->getMessage());
            }
        }
        if ($moneyDecimals === null) {
            try {
                $moneyDecimals = Money::decimals(null, $item, $floorAsOf);
            } catch (\Throwable $e) {
                $moneyDecimals = 2;
            }
        }

        $basic = (float)($item['basic_salary'] ?? 0.0);
        $allowances = (float)($item['allowances'] ?? 0.0);
        $adjBonus = max(0.0, (float)($adjustments['bonus'] ?? ($item['bonus_amount'] ?? 0.0)));
        $adjOt = max(0.0, (float)($adjustments['overtime'] ?? ($item['overtime_amount'] ?? 0.0)));
        $adjArrear = max(0.0, (float)($adjustments['arrear'] ?? ($item['arrear_amount'] ?? 0.0)));
        $adjIncentive = max(0.0, (float)($adjustments['incentive'] ?? ($item['incentive_amount'] ?? 0.0)));
        $adjEncashment = max(0.0, (float)($adjustments['encashment'] ?? ($adjustments['leave_encashment'] ?? ($item['leave_encashment'] ?? 0.0))));
        $gross = Money::round($basic + $allowances + $adjBonus + $adjOt + $adjArrear + $adjIncentive + $adjEncashment, $moneyDecimals);

        $lop = (float)($adjustments['lop'] ?? ($item['lop_deduction'] ?? ($item['unpaid_leave_deduction'] ?? 0.0)));
        $advance = (float)($adjustments['advance'] ?? ($item['advance_recovery'] ?? 0.0));
        $assetRecovery = max(0.0, (float)($adjustments['asset_recovery'] ?? ($item['asset_recovery'] ?? 0.0)));
        $scheduledLoanEmi = (float)($adjustments['loan'] ?? ($item['loan_emi'] ?? 0.0));

        $statutoryPf = (float)($item['pf_deduction'] ?? 0.0);
        $requestedPf = isset($adjustments['pf']) ? max(0.0, (float)$adjustments['pf']) : $statutoryPf;
        $adjTax = max(0.0, (float)($adjustments['tax'] ?? ($item['tax_deduction'] ?? 0.0)));
        $adjOtherDeductions = max(0.0, (float)($adjustments['other_deductions'] ?? ($item['other_deductions'] ?? 0.0)));

        // The ceiling engine receives LOP as unpaid leave + late penalty (same as calculateEmployeeItem),
        // otherwise any adjustment would silently drop the late penalty from total deductions.
        $latePenalty = max(0.0, (float)($item['late_penalty'] ?? 0.0));
        $ceilingResult = $this->applyStatutoryDeductionCeiling($gross, [
            'tax'     => $adjTax,
            'pf'      => $requestedPf,
            'lop'     => $lop + $latePenalty,
            'advance' => $advance,
            'loan'    => $scheduledLoanEmi,
            'other'   => $adjOtherDeductions
        ], 0.50, $minNetSalaryFloor, $item, $moneyDecimals);

        // Asset Recovery respects minimum_net_salary_floor
        $effectiveFloor = max(0.0, (float)$minNetSalaryFloor);
        $adjNet = $ceilingResult['net_salary'];
        if ($effectiveFloor > 0.0) {
            $maxAssetRecoveryDeductible = max(0.0, Money::round($adjNet - $effectiveFloor, $moneyDecimals));
        } else {
            $maxAssetRecoveryDeductible = max(0.0, $adjNet);
        }
        $adjAssetRecovery = min($assetRecovery, $maxAssetRecoveryDeductible);
        $adjAssetRecovery = Money::round($adjAssetRecovery, $moneyDecimals);
        $adjTotalDeductions = Money::round($ceilingResult['total_deductions'] + $adjAssetRecovery, $moneyDecimals);
        $adjFinalNet = Money::round(max(0.0, $adjNet - $adjAssetRecovery), $moneyDecimals);

        return [
            'gross_salary'      => $gross,
            'bonus_amount'      => $adjBonus,
            'overtime_amount'   => $adjOt,
            'leave_encashment'  => $adjEncashment,
            'tax_deduction'     => $ceilingResult['applied']['tax'],
            'pf_deduction'      => $ceilingResult['applied']['pf'],
            // lop_deduction stays "unpaid leave only"; the late penalty is stored in its own column.
            'lop_deduction'     => max(0.0, Money::round($ceilingResult['applied']['lop'] - $latePenalty, $moneyDecimals)),
            'advance_recovery'  => $ceilingResult['applied']['advance'],
            'asset_recovery'    => $adjAssetRecovery,
            'loan_emi'          => $ceilingResult['applied']['loan'],
            'other_deductions'  => $ceilingResult['applied']['other'],
            'total_deductions'  => $adjTotalDeductions,
            'net_salary'        => $adjFinalNet,
            'unapplied_tax'     => (float)($ceilingResult['unapplied']['tax'] ?? 0.0),
            'unapplied_pf'      => (float)($ceilingResult['unapplied']['pf'] ?? 0.0),
            'unapplied_lop'     => (float)($ceilingResult['unapplied']['lop'] ?? 0.0),
            'ceiling_result'    => $ceilingResult,
            'warnings'          => $ceilingResult['warnings'] ?? [],
            'floor_warning'     => $ceilingResult['floor_warning'] ?? null,
            'is_below_floor'    => $ceilingResult['is_below_floor'] ?? false,
        ];
    }

    /**
     * Synchronize a draft payroll item when a linked bonus (weekly or regular) is rejected or removed.
     *
     * @param string $payrollId
     * @param string $employeeId
     * @param float $deductedAmount
     * @param string|null $removedWeeklyBonusId
     * @param string|null $removedRegularBonusId
     * @return bool
     */
    public function syncDraftItemBonusChange(string $payrollId, string $employeeId, float $deductedAmount, ?string $removedWeeklyBonusId = null, ?string $removedRegularBonusId = null, ?float $deltaAmount = null): bool
    {
        if ($deltaAmount !== null) {
            if (abs($deltaAmount) <= 0.001 && empty($removedWeeklyBonusId) && empty($removedRegularBonusId)) {
                return true;
            }
        } elseif ($deductedAmount <= 0.001 && empty($removedWeeklyBonusId) && empty($removedRegularBonusId)) {
            return true;
        }

        // Verify batch exists and is unlocked
        $batch = $this->db->table('payrolls')->where('id', $payrollId)->get()->getRowArray();
        if (!$batch || !empty($batch['is_locked'])) {
            return false;
        }

        $item = $this->db->table('payroll_items')
            ->where('payroll_id', $payrollId)
            ->where('employee_id', $employeeId)
            ->get()->getRowArray();

        if (!$item) {
            // When the draft exists but the employee's item doesn't, allow release or cancel without a sync
            return true;
        }

        $currentBonus = (float)($item['bonus_amount'] ?? ($item['bonus'] ?? 0.0));
        if ($deltaAmount !== null) {
            $newBonus = max(0.0, round($currentBonus + $deltaAmount, 2));
        } else {
            $newBonus = max(0.0, round($currentBonus - $deductedAmount, 2));
        }

        // Update components_breakdown_json
        $rawBreakdown = $item['components_breakdown_json'] ?? null;
        $bd = !empty($rawBreakdown) ? (is_string($rawBreakdown) ? json_decode($rawBreakdown, true) : $rawBreakdown) : [];
        if (is_array($bd)) {
            if ($removedWeeklyBonusId && !empty($bd['weekly_bonus_record_ids']) && is_array($bd['weekly_bonus_record_ids'])) {
                $bd['weekly_bonus_record_ids'] = array_values(array_filter($bd['weekly_bonus_record_ids'], function($id) use ($removedWeeklyBonusId) {
                    return (string)$id !== (string)$removedWeeklyBonusId;
                }));
            }
            if ($removedRegularBonusId && !empty($bd['bonus_record_ids']) && is_array($bd['bonus_record_ids'])) {
                $bd['bonus_record_ids'] = array_values(array_filter($bd['bonus_record_ids'], function($id) use ($removedRegularBonusId) {
                    return (string)$id !== (string)$removedRegularBonusId;
                }));
            }
            $hasBonusEarning = false;
            if (!empty($bd['earnings']) && is_array($bd['earnings'])) {
                foreach ($bd['earnings'] as &$e) {
                    $eCode = strtoupper(trim((string)($e['code'] ?? $e['component_code'] ?? '')));
                    if (in_array($eCode, ['BONUS', 'BONUS_PAY'], true)) {
                        $e['amount'] = $newBonus;
                        $hasBonusEarning = true;
                    }
                }
                unset($e);
            }
            if (!$hasBonusEarning && $newBonus > 0) {
                if (!isset($bd['earnings']) || !is_array($bd['earnings'])) {
                    $bd['earnings'] = [];
                }
                $bd['earnings'][] = [
                    'code'       => 'BONUS',
                    'name'       => 'Bonus & Incentives',
                    'amount'     => $newBonus,
                    'is_taxable' => true,
                ];
            }
        }

        // Recalculate item with dynamic Income Tax (TDS) re-evaluation
        $lop = (float)($item['lop_deduction'] ?? ($item['unpaid_leave_deduction'] ?? 0));
        $advance = (float)($item['advance_recovery'] ?? 0);
        $loan = (float)($item['loan_emi'] ?? 0);
        $overtime = (float)($item['overtime_amount'] ?? 0);
        $pf = (float)($item['pf_deduction'] ?? 0);
        $other = (float)($item['other_deductions'] ?? 0);

        // Dynamically recompute income tax using policyResolver and RuleResolver TAX domain
        $tax = (float)($item['tax_deduction'] ?? 0);
        try {
            $emp = $this->db->table('employees')->where('id', $employeeId)->get()->getRowArray() ?: [];
            $payrollMonthStr = $batch['payroll_month'] ?? date('Y-m');
            $effectiveDate = date('Y-m-t', strtotime("{$payrollMonthStr}-01"));
            $taxYear = \App\Services\Tax\TaxCalculator::getFiscalYear("{$payrollMonthStr}-01");

            $basic = (float)($item['basic_salary'] ?? 0);
            $houseRent = (float)($item['house_rent'] ?? 0);
            $medical = (float)($item['medical'] ?? 0);
            $conveyance = (float)($item['conveyance'] ?? 0);

            $taxableBase = 0.0;
            if (!empty($bd['earnings']) && is_array($bd['earnings'])) {
                foreach ($bd['earnings'] as $feb) {
                    $isEarningTaxable = isset($feb['is_taxable'])
                        ? ((int)$feb['is_taxable'] === 1 || $feb['is_taxable'] === true)
                        : true;
                    if ($isEarningTaxable) {
                        $taxableBase += (float)($feb['amount'] ?? 0.00);
                    }
                }
            } else {
                $taxableBase = $basic + (float)($item['allowances'] ?? 0) + $overtime + $newBonus;
            }
            $taxableBase = round($taxableBase, 2);

            $annualBonus = $this->getFiscalYearBonusTotal($employeeId, $payrollMonthStr, $taxYear);
            if ($newBonus > $annualBonus) {
                $annualBonus = $newBonus;
            }

            $taxSettings = !empty($emp['tax_settings']) && is_string($emp['tax_settings'])
                ? json_decode($emp['tax_settings'], true)
                : ($emp['tax_settings'] ?? []);
            if (empty($taxSettings['category']) && !empty($emp['tax_category'])) {
                $taxSettings['category'] = $emp['tax_category'];
            }
            if (empty($taxSettings['tin']) && !empty($emp['tax_identification_number'])) {
                $taxSettings['tin'] = $emp['tax_identification_number'];
            }

            $taxResolution = $this->policyResolver->resolveIncomeTax(
                (string)($batch['company_id'] ?? ($emp['company_id'] ?? '')),
                $effectiveDate,
                $basic,
                $taxableBase,
                $taxSettings,
                $emp,
                [
                    'employee_id'      => $employeeId,
                    'company_id'       => $batch['company_id'] ?? ($emp['company_id'] ?? ''),
                    'tax_year'         => $taxYear,
                    'basic'            => $basic,
                    'house_rent'       => $houseRent,
                    'medical'          => $medical,
                    'conveyance'       => $conveyance,
                    'other_allowances' => (float)($item['other_allowances'] ?? 0),
                    'annual_bonus'     => $annualBonus,
                    'earnings'         => $bd['earnings'] ?? [],
                    'taxable_gross'    => $taxableBase,
                    'gross'            => $taxableBase,
                ]
            );
            $tax = (float)($taxResolution['amount'] ?? 0.00);

            if (isset($bd['tax']) && is_array($bd['tax'])) {
                $bd['tax']['monthly_tax'] = $tax;
                $bd['tax']['taxable_gross'] = $taxableBase;
                if (isset($taxResolution['breakdown'])) {
                    $bd['tax']['breakdown'] = $taxResolution['breakdown'];
                }
            }
            if (isset($bd['tax_details']) && is_array($bd['tax_details'])) {
                $bd['tax_details']['monthly_tax'] = $tax;
                $bd['tax_details']['taxable_gross'] = $taxableBase;
                $bd['tax_details']['annual_tax_amount'] = $taxResolution['annual_tax_amount'] ?? null;
                $bd['tax_details']['annual_tax_year'] = $taxResolution['annual_tax_year'] ?? null;
                $bd['tax_details']['auto_reference_monthly_tax'] = $taxResolution['auto_reference']['monthly_tax'] ?? null;
                $bd['tax_details']['auto_reference_annual_tax'] = $taxResolution['auto_reference']['annual_tax'] ?? null;
                $bd['tax_details']['warnings'] = $taxResolution['warnings'] ?? [];
                if (isset($taxResolution['breakdown'])) {
                    $bd['tax_details']['breakdown'] = $taxResolution['breakdown'];
                }
            }
        } catch (\Throwable $e) {
            log_message('error', 'Tax recalculation failed during draft bonus synchronization: ' . $e->getMessage());
            throw new \RuntimeException('Tax recalculation failed during draft bonus synchronization: ' . $e->getMessage(), 0, $e);
        }

        $calc = $this->calculateAdjustedItem($item, [
            'bonus'            => $newBonus,
            'overtime'         => $overtime,
            'tax'              => $tax,
            'pf'               => $pf,
            'other_deductions' => $other,
            'lop'              => $lop,
            'advance'          => $advance,
            'loan'             => $loan,
        ]);

        $updatePayload = [
            'bonus_amount'     => $newBonus,
            'gross_salary'     => $calc['gross_salary'],
            'total_deductions' => $calc['total_deductions'],
            'net_salary'       => $calc['net_salary'],
            'tax_deduction'    => $calc['tax_deduction'],
            'pf_deduction'     => $calc['pf_deduction'],
            'advance_recovery' => $calc['advance_recovery'],
            'loan_emi'         => $calc['loan_emi'],
            'unapplied_tax'    => (float)($calc['ceiling_result']['unapplied']['tax'] ?? 0.0),
            'unapplied_pf'     => (float)($calc['ceiling_result']['unapplied']['pf'] ?? 0.0),
            'unapplied_lop'    => (float)($calc['ceiling_result']['unapplied']['lop'] ?? 0.0),
        ];
        if ($this->db->fieldExists('bonus', 'payroll_items')) {
            $updatePayload['bonus'] = $newBonus;
        }
        if ($this->db->fieldExists('components_breakdown_json', 'payroll_items')) {
            $updatePayload['components_breakdown_json'] = json_encode($bd, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        }

        $this->db->table('payroll_items')->where('id', $item['id'])->update($updatePayload);

        // Resync parent payroll totals
        $totals = $this->db->table('payroll_items')
            ->selectSum('gross_salary')
            ->selectSum('total_deductions')
            ->selectSum('net_salary')
            ->where('payroll_id', $payrollId)
            ->get()->getRowArray();

        $this->db->table('payrolls')->where('id', $payrollId)->update([
            'total_earnings'   => (float)($totals['gross_salary'] ?? 0),
            'total_deductions' => (float)($totals['total_deductions'] ?? 0),
            'net_disbursed'    => (float)($totals['net_salary'] ?? 0),
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        return true;
    }

    /**
     * Query approved bonus records and weekly records older than the 12-month carry-forward horizon (stuck bonuses).
     *
     * @param string $companyId
     * @param string|null $asOfDate YYYY-MM-DD or YYYY-MM (default: current date)
     * @return array ['regular' => array, 'weekly' => array, 'total_count' => int, 'total_amount' => float]
     */
    public function getStuckBonuses(string $companyId, ?string $asOfDate = null): array
    {
        $baseDate = $asOfDate ? (preg_match('/^\d{4}-\d{2}$/', $asOfDate) ? "{$asOfDate}-01" : $asOfDate) : date('Y-m-01');
        $twelveMonthsAgoDate = date('Y-m-01', strtotime('-12 months', strtotime($baseDate)));
        $twelveMonthsAgoPeriod = date('Y-m', strtotime($twelveMonthsAgoDate));

        // Under the carry-forward rule (payout_month <= payroll month is eligible),
        // swept Approved records are paid automatically by the next payroll, so they need no action.
        // Therefore, swept records must NEVER be marked as stuck regardless of locked payroll months.
        // Only unswept records (payout_month IS NULL or empty) exceeding the 12-month window are stuck.

        $monthMap = [
            'january' => 1, 'jan' => 1, '1' => 1, '01' => 1,
            'february' => 2, 'feb' => 2, '2' => 2, '02' => 2,
            'march' => 3, 'mar' => 3, '3' => 3, '03' => 3,
            'april' => 4, 'apr' => 4, '4' => 4, '04' => 4,
            'may' => 5, '5' => 5, '05' => 5,
            'june' => 6, 'jun' => 6, '6' => 6, '06' => 6,
            'july' => 7, 'jul' => 7, '7' => 7, '07' => 7,
            'august' => 8, 'aug' => 8, '8' => 8, '08' => 8,
            'september' => 9, 'sep' => 9, 'sept' => 9, '9' => 9, '09' => 9,
            'october' => 10, 'oct' => 10, '10' => 10,
            'november' => 11, 'nov' => 11, '11' => 11,
            'december' => 12, 'dec' => 12, '12' => 12,
        ];

        $stuckRegular = [];
        $regularAmount = 0.0;
        if ($this->db->tableExists('bonus_records')) {
            $hasPayoutCol = $this->db->fieldExists('payout_month', 'bonus_records');
            $hasSweptCol = $this->db->fieldExists('swept_by', 'bonus_records');
            $hasSweptAtCol = $this->db->fieldExists('swept_at', 'bonus_records');

            $bBuilder = $this->db->table('bonus_records')
                ->select("bonus_records.*, CONCAT(COALESCE(employees.first_name,''), ' ', COALESCE(employees.last_name,'')) as employee_full_name, employees.employee_code, departments.name as dept_title")
                ->join('employees', 'employees.id = bonus_records.employee_id', 'left')
                ->join('departments', 'departments.id = employees.department_id', 'left')
                ->where('bonus_records.company_id', $companyId)
                ->where('bonus_records.status', 'Approved')
                ->where('bonus_records.is_settled_in_payroll', 0)
                ->where('bonus_records.deleted_at IS NULL');

            // Under the carry-forward rule (payout_month <= payroll_month is eligible),
            // swept records are automatically paid in the next payroll and require no manual action.
            // Only unswept records (payout_month IS NULL or empty) that exceed the 12-month window are stuck.
            if ($hasPayoutCol) {
                $bBuilder->groupStart()
                    ->where('bonus_records.payout_month IS NULL')
                    ->orWhere('bonus_records.payout_month', '')
                ->groupEnd();
            }

            $rows = $bBuilder->get()->getResultArray() ?: [];
            foreach ($rows as $r) {
                $pm = $hasPayoutCol ? trim((string)($r['payout_month'] ?? '')) : '';
                if (!empty($pm)) {
                    // Scheduled for upcoming payroll; not stuck
                    continue;
                }

                $rYear = !empty($r['year']) ? (int)$r['year'] : 0;
                $bm = trim((string)($r['bonus_month'] ?? ''));
                if (preg_match('/^(\d{4})-(\d{1,2})/', $bm, $mMatches)) {
                    $recPeriod = sprintf('%04d-%02d', (int)$mMatches[1], (int)$mMatches[2]);
                } else {
                    $bmLower = strtolower($bm);
                    $mNum = $monthMap[$bmLower] ?? 0;
                    $recPeriod = ($rYear > 0 && $mNum > 0) ? sprintf('%04d-%02d', $rYear, $mNum) : null;
                }

                // If period is unparseable or older than 12 months, report in stuck records
                if ($recPeriod === null || $recPeriod < $twelveMonthsAgoPeriod) {
                    $stuckRegular[] = $r;
                    $regularAmount = round($regularAmount + (float)($r['amount'] ?? 0.0), 2);
                }
            }
        }

        $stuckWeekly = [];
        $weeklyAmount = 0.0;
        if ($this->db->tableExists('weekly_bonus_records')) {
            $hasWeeklyPayoutCol = $this->db->fieldExists('payout_month', 'weekly_bonus_records');
            $hasWeeklySweptCol = $this->db->fieldExists('swept_by', 'weekly_bonus_records');
            $hasWeeklySweptAtCol = $this->db->fieldExists('swept_at', 'weekly_bonus_records');

            $wBuilder = $this->db->table('weekly_bonus_records')
                ->select("weekly_bonus_records.*, CONCAT(COALESCE(employees.first_name,''), ' ', COALESCE(employees.last_name,'')) as employee_full_name, employees.employee_code, departments.name as dept_title")
                ->join('employees', 'employees.id = weekly_bonus_records.employee_id', 'left')
                ->join('departments', 'departments.id = employees.department_id', 'left')
                ->where('weekly_bonus_records.company_id', $companyId)
                ->where('weekly_bonus_records.status', 'Approved')
                ->where('weekly_bonus_records.status !=', 'Paid')
                ->where('weekly_bonus_records.deleted_at IS NULL');

            // Only unswept weekly records older than 12 months need action; swept records are automatically paid
            if ($hasWeeklyPayoutCol) {
                $wBuilder->groupStart()
                    ->where('weekly_bonus_records.payout_month IS NULL')
                    ->orWhere('weekly_bonus_records.payout_month', '')
                ->groupEnd()
                ->where('weekly_bonus_records.week_start_date <', $twelveMonthsAgoDate);
            } else {
                $wBuilder->where('weekly_bonus_records.week_start_date <', $twelveMonthsAgoDate);
            }

            $wRows = $wBuilder->get()->getResultArray() ?: [];
            foreach ($wRows as $wr) {
                $wpm = $hasWeeklyPayoutCol ? trim((string)($wr['payout_month'] ?? '')) : '';
                if (!empty($wpm)) {
                    // Scheduled for upcoming payroll; not stuck
                    continue;
                }

                $wStartDate = (string)($wr['week_start_date'] ?? '');
                if ($wStartDate < $twelveMonthsAgoDate) {
                    $stuckWeekly[] = $wr;
                    $weeklyAmount = round($weeklyAmount + (float)($wr['bonus_amount'] ?? 0.0), 2);
                }
            }
        }

        // Query held regular bonus records (differentiating active draft holds vs deleted payroll holds)
        $heldRegular = [];
        $heldRegularAmount = 0.0;
        $heldDeletedRegular = [];
        $heldDeletedRegularAmount = 0.0;

        if ($this->db->tableExists('bonus_records')) {
            $hb = $this->db->table('bonus_records')
                ->select("bonus_records.*, CONCAT(COALESCE(employees.first_name,''), ' ', COALESCE(employees.last_name,'')) as employee_full_name, employees.employee_code, departments.name as dept_title, payrolls.status as payroll_status, payrolls.payroll_month as holding_batch_month, payrolls.is_locked as holding_batch_locked, payrolls.id as holding_batch_id")
                ->join('employees', 'employees.id = bonus_records.employee_id', 'left')
                ->join('departments', 'departments.id = employees.department_id', 'left')
                ->join('payrolls', 'payrolls.id = bonus_records.payroll_id', 'left')
                ->where('bonus_records.company_id', $companyId)
                ->where('bonus_records.status', 'Approved')
                ->where('bonus_records.is_settled_in_payroll', 0)
                ->where('bonus_records.payroll_id IS NOT NULL')
                ->where('bonus_records.deleted_at IS NULL');
            $hRows = $hb->get()->getResultArray() ?: [];
            foreach ($hRows as $hr) {
                if (empty($hr['holding_batch_id'])) {
                    // Linked payroll batch was deleted / no longer exists
                    $hr['linked_payroll_deleted'] = true;
                    $heldDeletedRegular[] = $hr;
                    $heldDeletedRegularAmount = round($heldDeletedRegularAmount + (float)($hr['amount'] ?? 0.0), 2);
                } elseif (empty($hr['holding_batch_locked'])) {
                    $hr['linked_payroll_deleted'] = false;
                    $heldRegular[] = $hr;
                    $heldRegularAmount = round($heldRegularAmount + (float)($hr['amount'] ?? 0.0), 2);
                }
            }
        }

        // Query held weekly bonus records (differentiating active draft holds vs deleted payroll holds)
        $heldWeekly = [];
        $heldWeeklyAmount = 0.0;
        $heldDeletedWeekly = [];
        $heldDeletedWeeklyAmount = 0.0;

        if ($this->db->tableExists('weekly_bonus_records')) {
            $hwb = $this->db->table('weekly_bonus_records')
                ->select("weekly_bonus_records.*, CONCAT(COALESCE(employees.first_name,''), ' ', COALESCE(employees.last_name,'')) as employee_full_name, employees.employee_code, departments.name as dept_title, payrolls.status as payroll_status, payrolls.payroll_month as holding_batch_month, payrolls.is_locked as holding_batch_locked, payrolls.id as holding_batch_id")
                ->join('employees', 'employees.id = weekly_bonus_records.employee_id', 'left')
                ->join('departments', 'departments.id = employees.department_id', 'left')
                ->join('payrolls', 'payrolls.id = weekly_bonus_records.payroll_id', 'left')
                ->where('weekly_bonus_records.company_id', $companyId)
                ->where('weekly_bonus_records.status', 'Approved')
                ->where('weekly_bonus_records.status !=', 'Paid')
                ->where('weekly_bonus_records.payroll_id IS NOT NULL')
                ->where('weekly_bonus_records.deleted_at IS NULL');
            $hwRows = $hwb->get()->getResultArray() ?: [];
            foreach ($hwRows as $hwr) {
                if (empty($hwr['holding_batch_id'])) {
                    // Linked payroll batch was deleted / no longer exists
                    $hwr['linked_payroll_deleted'] = true;
                    $heldDeletedWeekly[] = $hwr;
                    $heldDeletedWeeklyAmount = round($heldDeletedWeeklyAmount + (float)($hwr['bonus_amount'] ?? 0.0), 2);
                } elseif (empty($hwr['holding_batch_locked'])) {
                    $hwr['linked_payroll_deleted'] = false;
                    $heldWeekly[] = $hwr;
                    $heldWeeklyAmount = round($heldWeeklyAmount + (float)($hwr['bonus_amount'] ?? 0.0), 2);
                }
            }
        }

        // Query scheduled but unpaid swept records whose payout_month <= latest locked payroll month
        $latestLockedPayroll = null;
        if ($this->db->tableExists('payrolls')) {
            $latestLockedPayroll = $this->db->table('payrolls')
                ->select('payroll_month')
                ->where('company_id', $companyId)
                ->where('is_locked', 1)
                ->orderBy('payroll_month', 'DESC')
                ->get()
                ->getRowArray();
        }
        $latestLockedMonth = !empty($latestLockedPayroll['payroll_month']) ? (string)$latestLockedPayroll['payroll_month'] : null;

        $scheduledUnpaidRegular = [];
        $scheduledUnpaidRegularAmount = 0.0;
        if ($this->db->tableExists('bonus_records') && !empty($hasPayoutCol) && $latestLockedMonth !== null) {
            $surBuilder = $this->db->table('bonus_records')
                ->select("bonus_records.*, CONCAT(COALESCE(employees.first_name,''), ' ', COALESCE(employees.last_name,'')) as employee_full_name, employees.employee_code, departments.name as dept_title")
                ->join('employees', 'employees.id = bonus_records.employee_id', 'left')
                ->join('departments', 'departments.id = employees.department_id', 'left')
                ->where('bonus_records.company_id', $companyId)
                ->where('bonus_records.status', 'Approved')
                ->where('bonus_records.payout_month IS NOT NULL')
                ->where("bonus_records.payout_month != ''")
                ->where('bonus_records.payout_month <=', $latestLockedMonth)
                ->where('bonus_records.is_settled_in_payroll', 0)
                ->where('bonus_records.status !=', 'Paid')
                ->where('bonus_records.deleted_at IS NULL');
            $scheduledUnpaidRegular = $surBuilder->get()->getResultArray() ?: [];
            foreach ($scheduledUnpaidRegular as $sur) {
                $scheduledUnpaidRegularAmount = round($scheduledUnpaidRegularAmount + (float)($sur['amount'] ?? 0.0), 2);
            }
        }

        $scheduledUnpaidWeekly = [];
        $scheduledUnpaidWeeklyAmount = 0.0;
        if ($this->db->tableExists('weekly_bonus_records') && !empty($hasWeeklyPayoutCol) && $latestLockedMonth !== null) {
            $suwBuilder = $this->db->table('weekly_bonus_records')
                ->select("weekly_bonus_records.*, CONCAT(COALESCE(employees.first_name,''), ' ', COALESCE(employees.last_name,'')) as employee_full_name, employees.employee_code, departments.name as dept_title")
                ->join('employees', 'employees.id = weekly_bonus_records.employee_id', 'left')
                ->join('departments', 'departments.id = employees.department_id', 'left')
                ->where('weekly_bonus_records.company_id', $companyId)
                ->where('weekly_bonus_records.status', 'Approved')
                ->where('weekly_bonus_records.payout_month IS NOT NULL')
                ->where("weekly_bonus_records.payout_month != ''")
                ->where('weekly_bonus_records.payout_month <=', $latestLockedMonth)
                ->where('weekly_bonus_records.status !=', 'Paid')
                ->where('weekly_bonus_records.deleted_at IS NULL');
            $scheduledUnpaidWeekly = $suwBuilder->get()->getResultArray() ?: [];
            foreach ($scheduledUnpaidWeekly as $suw) {
                $scheduledUnpaidWeeklyAmount = round($scheduledUnpaidWeeklyAmount + (float)($suw['bonus_amount'] ?? 0.0), 2);
            }
        }

        $scheduledUnpaidCount = count($scheduledUnpaidRegular) + count($scheduledUnpaidWeekly);
        $scheduledUnpaidAmount = round($scheduledUnpaidRegularAmount + $scheduledUnpaidWeeklyAmount, 2);

        $heldDeletedCount = count($heldDeletedRegular) + count($heldDeletedWeekly);
        $heldDeletedAmount = round($heldDeletedRegularAmount + $heldDeletedWeeklyAmount, 2);
        $heldActiveCount = count($heldRegular) + count($heldWeekly);
        $heldActiveAmount = round($heldRegularAmount + $heldWeeklyAmount, 2);

        return [
            'latest_locked_month'      => $latestLockedMonth,
            'regular'                  => $stuckRegular,
            'weekly'                   => $stuckWeekly,
            'scheduled_unpaid_regular' => $scheduledUnpaidRegular,
            'scheduled_unpaid_weekly'  => $scheduledUnpaidWeekly,
            'scheduled_unpaid_count'   => $scheduledUnpaidCount,
            'scheduled_unpaid_amount'  => $scheduledUnpaidAmount,
            'held_regular'             => $heldRegular,
            'held_weekly'              => $heldWeekly,
            'held_deleted_regular'     => $heldDeletedRegular,
            'held_deleted_weekly'      => $heldDeletedWeekly,
            'held_deleted_count'       => $heldDeletedCount,
            'held_deleted_amount'      => $heldDeletedAmount,
            'held_count'               => $heldActiveCount + $heldDeletedCount,
            'held_amount'              => round($heldActiveAmount + $heldDeletedAmount, 2),
            'expired_count'            => count($stuckRegular) + count($stuckWeekly),
            'expired_amount'           => round($regularAmount + $weeklyAmount, 2),
            'total_count'              => count($stuckRegular) + count($stuckWeekly) + $heldActiveCount + $heldDeletedCount + $scheduledUnpaidCount,
            'total_amount'             => round($regularAmount + $weeklyAmount + $heldActiveAmount + $heldDeletedAmount + $scheduledUnpaidAmount, 2),
            'cutoff_date'              => $twelveMonthsAgoDate,
            'cutoff_period'            => $twelveMonthsAgoPeriod,
        ];
    }
}