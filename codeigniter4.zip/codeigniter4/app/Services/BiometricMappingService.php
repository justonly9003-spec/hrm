<?php

namespace App\Services;

use App\Models\BiometricMappingModel;
use App\Models\UnmatchedBiometricModel;
use App\Models\RawBiometricEventModel;
use App\Models\EmployeeModel;
use App\Models\BiometricDeviceModel;
use App\Services\AttendanceService;
use App\Services\AuditService;
use Config\Database;
use Ramsey\Uuid\Uuid;

class BiometricMappingService
{
    protected $db;
    protected $mappingModel;
    protected $unmatchedModel;
    protected $rawEventModel;
    protected $employeeModel;
    protected $deviceModel;
    protected $auditService;

    public function __construct()
    {
        $this->db = Database::connect();
        $this->mappingModel = new BiometricMappingModel();
        $this->unmatchedModel = new UnmatchedBiometricModel();
        $this->rawEventModel = new RawBiometricEventModel();
        $this->employeeModel = new EmployeeModel();
        $this->deviceModel = new BiometricDeviceModel();
        $this->auditService = new AuditService();

        $this->mappingModel->ensureTableExists();
        $this->unmatchedModel->ensureTableExists();
        $this->rawEventModel->ensureTableExists();
    }

    /**
     * Generate all normalized PIN candidate variations (leading zeros, prefixes, padding)
     */
    public function generateCandidateVariants(?string $pin): array
    {
        if ($pin === null || $pin === '') {
            return [];
        }
        $pin = trim((string)$pin);
        $candidates = [$pin, strtoupper($pin), strtolower($pin)];

        $strippedZeros = ltrim($pin, '0');
        if (!empty($strippedZeros)) {
            $candidates[] = $strippedZeros;
            $candidates[] = 'EMP-' . $strippedZeros;
            $candidates[] = 'emp-' . $strippedZeros;
            if (strlen($strippedZeros) < 8) {
                $candidates[] = str_pad($strippedZeros, 4, '0', STR_PAD_LEFT);
                $candidates[] = str_pad($strippedZeros, 5, '0', STR_PAD_LEFT);
                $candidates[] = str_pad($strippedZeros, 6, '0', STR_PAD_LEFT);
                $candidates[] = str_pad($strippedZeros, 8, '0', STR_PAD_LEFT);
            }
        }
        if (stripos($pin, 'EMP-') === 0) {
            $noPrefix = substr($pin, 4);
            $candidates[] = $noPrefix;
            $noPrefixZeros = ltrim($noPrefix, '0');
            if (!empty($noPrefixZeros)) {
                $candidates[] = $noPrefixZeros;
                $candidates[] = 'EMP-' . $noPrefixZeros;
            }
        } else {
            $candidates[] = 'EMP-' . $pin;
            $candidates[] = 'emp-' . strtolower($pin);
        }

        return array_values(array_unique(array_filter($candidates)));
    }

    /**
     * Resolve Employee Master record from a biometric punch identity
     * 1. Check explicit active mapping in biometric_mappings
     * 2. Direct fallback to employee_code or id in employees table
     */
    public function resolveEmployeeForBiometricPunch(string $biometricUserId, string $companyId, ?string $deviceId = null): ?array
    {
        $biometricUserId = trim($biometricUserId);
        if (empty($biometricUserId) || empty($companyId)) {
            return null;
        }

        // Generate PIN candidate variations (leading zeros, EMP- prefix, padded)
        $candidates = $this->generateCandidateVariants($biometricUserId);

        // 1. Explicit Active Biometric Mapping Lookup
        $mapping = $this->mappingModel->findActiveMapping($candidates, $companyId, $deviceId);
        if ($mapping && !empty($mapping['employee_id'])) {
            $targetEmpCandidates = $this->generateCandidateVariants($mapping['employee_id']);

            // Priority 1: Check in tenant company
            $emp = $this->employeeModel
                ->where('company_id', $companyId)
                ->groupStart()
                    ->whereIn('id', $targetEmpCandidates)
                    ->orWhereIn('employee_code', $targetEmpCandidates)
                ->groupEnd()
                ->first();

            if ($emp) {
                return $emp;
            }
        }

        // Mapping-only devices must not fall back to employee_code matching
        if (!empty($deviceId)) {
            $devCfg = \Config\Database::connect()->table('biometric_devices')
                ->select('auto_match_by_code')->where('id', $deviceId)->get()->getRowArray();
            if ($devCfg && isset($devCfg['auto_match_by_code']) && (int) $devCfg['auto_match_by_code'] === 0) {
                return null;
            }
        }

        // 2. Direct Fallback: Check if employee_code or id matches any candidate variation
        $emp = $this->employeeModel
            ->where('company_id', $companyId)
            ->groupStart()
                ->whereIn('employee_code', $candidates)
                ->orWhereIn('id', $candidates)
            ->groupEnd()
            ->first();

        if ($emp) {
            // Auto-persist active mapping so future lookups are immediate and auditable
            try {
                $now = date('Y-m-d H:i:s');
                $existingMapQ = $this->mappingModel
                    ->where('company_id', $companyId)
                    ->where('biometric_user_id', $biometricUserId);
                if (!empty($deviceId)) {
                    $existingMapQ->groupStart()
                        ->where('device_id', $deviceId)
                        ->orWhere('device_id IS NULL')
                        ->orWhere('device_id', '')
                        ->orWhere('device_id', 'ALL')
                    ->groupEnd();
                }
                $existingMap = $existingMapQ->first();

                if (!$existingMap) {
                    $this->mappingModel->insert([
                        'id'                => Uuid::uuid4()->toString(),
                        'company_id'        => $companyId,
                        'device_id'         => $deviceId,
                        'biometric_user_id' => $biometricUserId,
                        'device_user_name'  => trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')),
                        'employee_id'       => $emp['id'],
                        'status'            => 'Active',
                        'mapped_by'         => 'System Auto-Match',
                        'mapped_at'         => $now,
                        'notes'             => 'Auto-created from direct employee_code match.',
                        'created_at'        => $now,
                        'updated_at'        => $now
                    ]);
                }
            } catch (\Throwable $e) {
                log_message('error', 'Auto-mapping creation warning: ' . $e->getMessage());
            }

            return $emp;
        }

        return null;
    }

    /**
     * Record an unmatched punch:
     * 1. Preserves raw punch in raw_biometric_events (never discard)
     * 2. Upserts identity in unmatched_biometric_identities with updated event count and last seen
     */
    public function recordUnmatchedPunch(array $punchData, string $companyId, ?array $deviceInfo = null): array
    {
        // 1. Authoritative extraction of Biometric User ID / Terminal PIN
        $empCode = trim(
            (string)(
                $punchData['device_user_id']
                ?? $punchData['biometric_user_id']
                ?? $punchData['employee_code']
                ?? $punchData['pin']
                ?? $punchData['emp_id']
                ?? $punchData['user_id']
                ?? $punchData['badge_number']
                ?? $punchData['badgenumber']
                ?? $punchData['card_number']
                ?? $punchData['card_no']
                ?? $punchData['user_pin']
                ?? $punchData['device_pin']
                ?? $punchData['uid']
                ?? ''
            )
        );

        // 2. Authoritative extraction of Punch DateTime
        $punchDateTime = trim(
            (string)(
                $punchData['event_time']
                ?? $punchData['punch_time']
                ?? $punchData['datetime']
                ?? $punchData['timestamp']
                ?? $punchData['record_time']
                ?? $punchData['time']
                ?? ''
            )
        );

        // 3. Fallback extraction from raw_payload if missing
        if ((empty($empCode) || empty($punchDateTime)) && !empty($punchData['raw_payload'])) {
            $raw = $punchData['raw_payload'];
            if (is_string($raw)) {
                $decoded = json_decode($raw, true);
                if (is_array($decoded)) {
                    if (empty($empCode)) {
                        $empCode = trim(
                            (string)(
                                $decoded['device_user_id']
                                ?? $decoded['biometric_user_id']
                                ?? $decoded['employee_code']
                                ?? $decoded['pin']
                                ?? $decoded['emp_id']
                                ?? $decoded['user_id']
                                ?? $decoded['badge_number']
                                ?? $decoded['badgenumber']
                                ?? $decoded['card_number']
                                ?? ''
                            )
                        );
                    }
                    if (empty($punchDateTime)) {
                        $punchDateTime = trim(
                            (string)(
                                $decoded['event_time']
                                ?? $decoded['punch_time']
                                ?? $decoded['datetime']
                                ?? $decoded['timestamp']
                                ?? ''
                            )
                        );
                    }
                } elseif (ctype_xdigit($raw) && strlen($raw) >= 80) {
                    $zkService = new \App\Services\ZKTecoService();
                    $parsed = $zkService->parseSingleAttendanceRecord(hex2bin($raw));
                    if (!empty($parsed)) {
                        if (empty($empCode) && !empty($parsed['device_user_id'])) {
                            $empCode = trim((string)$parsed['device_user_id']);
                        }
                        if (empty($punchDateTime) && !empty($parsed['event_time'])) {
                            $punchDateTime = trim((string)$parsed['event_time']);
                        }
                    }
                }
            }
        }

        if (empty($punchDateTime) || !strtotime($punchDateTime)) {
            $punchDateTime = date('Y-m-d H:i:s');
        }

        // 4. Extraction of punch state / status
        $punchState = trim((string)($punchData['punch_state'] ?? $punchData['status'] ?? ''));
        if (empty($punchState)) {
            $statusVal = $punchData['punch_status'] ?? ($punchData['punch'] ?? null);
            if ($statusVal !== null) {
                $punchState = match ((int)$statusVal) {
                    0 => 'CheckIn',
                    1 => 'CheckOut',
                    2 => 'BreakOut',
                    3 => 'BreakIn',
                    4 => 'OvertimeIn',
                    5 => 'OvertimeOut',
                    default => 'CheckIn'
                };
            } else {
                $punchState = 'CheckIn';
            }
        }

        $punchName = trim((string)($punchData['name'] ?? $punchData['user_name'] ?? ''));

        $deviceId = $deviceInfo['id'] ?? $punchData['device_id'] ?? null;
        $deviceName = $deviceInfo['device_name'] ?? $punchData['device_name'] ?? 'Biometric Device';
        $deviceSerial = $deviceInfo['serial_number'] ?? $punchData['device_sn'] ?? null;

        $now = date('Y-m-d H:i:s');
        $rawEventId = Uuid::uuid4()->toString();

        // Guard against storing empty/null PIN to prevent collision of distinct users
        $storedBiometricUserId = !empty($empCode) ? $empCode : ('UNKNOWN_' . substr($rawEventId, 0, 8));

        // Prepare raw payload
        $rawPayloadToStore = is_string($punchData['raw_payload'] ?? null) && !empty($punchData['raw_payload'])
            ? $punchData['raw_payload']
            : json_encode(array_merge($punchData, [
                'device_user_id' => $storedBiometricUserId,
                'event_time'     => $punchDateTime,
                'punch_state'    => $punchState,
            ]));

        // 1. Insert into raw_biometric_events
        $this->rawEventModel->insert([
            'id'                   => $rawEventId,
            'company_id'           => $companyId,
            'device_id'            => $deviceId,
            'device_name'          => $deviceName,
            'device_serial'        => $deviceSerial,
            'biometric_user_id'    => $storedBiometricUserId,
            'name_from_device'     => !empty($punchName) ? $punchName : null,
            'punch_time'           => $punchDateTime,
            'punch_state'          => $punchState,
            'raw_payload'          => $rawPayloadToStore,
            'matching_status'      => 'UNMATCHED',
            'resolved_employee_id' => null,
            'attendance_log_id'    => null,
            'created_at'           => $now
        ]);

        // 2. Check if identity exists in unmatched_biometric_identities (only for valid PINs)
        $unmatchedId = null;

        if (!empty($empCode)) {
            $existingIdentity = $this->unmatchedModel
                ->where('company_id', $companyId)
                ->where('biometric_user_id', $empCode)
                ->first();

            if ($existingIdentity) {
                $unmatchedId = $existingIdentity['id'];
                $newCount = ((int)($existingIdentity['event_count'] ?? 0)) + 1;

                $updateData = [
                    'event_count'  => $newCount,
                    'last_seen_at' => $punchDateTime,
                    'updated_at'   => $now
                ];

                if (empty($existingIdentity['first_seen_at']) || strtotime($punchDateTime) < strtotime($existingIdentity['first_seen_at'])) {
                    $updateData['first_seen_at'] = $punchDateTime;
                }

                if (empty($existingIdentity['name_from_device']) && !empty($punchName)) {
                    $updateData['name_from_device'] = $punchName;
                }
                if (empty($existingIdentity['device_id']) && !empty($deviceId)) {
                    $updateData['device_id'] = $deviceId;
                }
                if (empty($existingIdentity['device_name']) && !empty($deviceName)) {
                    $updateData['device_name'] = $deviceName;
                }
                if (empty($existingIdentity['device_serial']) && !empty($deviceSerial)) {
                    $updateData['device_serial'] = $deviceSerial;
                }

                // If it was marked MAPPED, leave it; otherwise keep or ensure UNMATCHED
                if (($existingIdentity['status'] ?? '') !== 'MAPPED' && ($existingIdentity['status'] ?? '') !== 'IGNORED') {
                    $updateData['status'] = 'UNMATCHED';
                }

                $this->unmatchedModel->update($unmatchedId, $updateData);
            } else {
                $unmatchedId = Uuid::uuid4()->toString();
                $this->unmatchedModel->insert([
                    'id'                => $unmatchedId,
                    'company_id'        => $companyId,
                    'device_id'         => $deviceId,
                    'device_name'       => $deviceName,
                    'device_serial'     => $deviceSerial,
                    'biometric_user_id' => $empCode,
                    'name_from_device'  => !empty($punchName) ? $punchName : null,
                    'first_seen_at'     => $punchDateTime,
                    'last_seen_at'      => $punchDateTime,
                    'event_count'       => 1,
                    'status'            => 'UNMATCHED',
                    'created_at'        => $now,
                    'updated_at'        => $now
                ]);
            }
        }

        return [
            'unmatched_identity_id' => $unmatchedId,
            'raw_event_id'          => $rawEventId,
            'biometric_user_id'     => $storedBiometricUserId
        ];
    }

    /**
     * Link an unmatched biometric identity to an existing Employee Master record
     */
    public function linkBiometricIdentity(string $unmatchedIdOrUserId, string $employeeId, string $companyId, ?string $actorUserId = null, ?string $deviceId = null, bool $reprocessEvents = true): array
    {
        $this->db->transStart();

        // 1. Verify Target Employee across ID and employee_code candidate variants
        $empCandidates = $this->generateCandidateVariants($employeeId);
        $emp = $this->employeeModel
            ->where('company_id', $companyId)
            ->groupStart()
                ->whereIn('id', $empCandidates)
                ->orWhereIn('employee_code', $empCandidates)
            ->groupEnd()
            ->first();

        if (!$emp) {
            $this->db->transRollback();
            return [
                'success' => false,
                'message' => 'Target employee record was not found or does not belong to the authorized company.'
            ];
        }

        // 2. Find unmatched identity record
        $unmatched = $this->unmatchedModel
            ->where('company_id', $companyId)
            ->groupStart()
                ->where('id', $unmatchedIdOrUserId)
                ->orWhere('biometric_user_id', $unmatchedIdOrUserId)
            ->groupEnd()
            ->first();

        $biometricUserId = $unmatched ? $unmatched['biometric_user_id'] : $unmatchedIdOrUserId;
        $deviceUserName = $unmatched['name_from_device'] ?? trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? ''));
        $targetDeviceId = $deviceId ?: ($unmatched['device_id'] ?? null);

        $now = date('Y-m-d H:i:s');

        // 3. Create or update active mapping in biometric_mappings
        $existingMapping = $this->mappingModel
            ->where('company_id', $companyId)
            ->where('biometric_user_id', $biometricUserId)
            ->first();

        $mappingId = null;
        if ($existingMapping) {
            $mappingId = $existingMapping['id'];
            $this->mappingModel->update($mappingId, [
                'employee_id'      => $employeeId,
                'device_user_name' => $deviceUserName,
                'device_id'        => $targetDeviceId,
                'status'           => 'Active',
                'mapped_by'        => $actorUserId,
                'mapped_at'        => $now,
                'updated_at'       => $now
            ]);
        } else {
            $mappingId = Uuid::uuid4()->toString();
            $this->mappingModel->insert([
                'id'                => $mappingId,
                'company_id'        => $companyId,
                'device_id'         => $targetDeviceId,
                'biometric_user_id' => $biometricUserId,
                'device_user_name'  => $deviceUserName,
                'employee_id'       => $employeeId,
                'status'            => 'Active',
                'mapped_by'         => $actorUserId,
                'mapped_at'         => $now,
                'created_at'        => $now,
                'updated_at'        => $now
            ]);
        }

        // 4. Update unmatched record status to MAPPED
        if ($unmatched) {
            $this->unmatchedModel->update($unmatched['id'], [
                'status'             => 'MAPPED',
                'mapped_employee_id' => $employeeId,
                'mapped_at'          => $now,
                'mapped_by'          => $actorUserId,
                'updated_at'         => $now
            ]);
        }

        // 5. Reprocess raw events into attendance_logs if requested
        $reprocessedCount = 0;
        if ($reprocessEvents) {
            $reprocessedCount = $this->reprocessPendingEvents($biometricUserId, $employeeId, $companyId, $emp);
        }

        // 6. Audit Trail
        $empFullName = trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')) ?: $emp['employee_code'];
        $this->auditService->log(
            $actorUserId,
            'biometric',
            'biometric.linked',
            $mappingId,
            ['status' => 'UNMATCHED', 'biometric_user_id' => $biometricUserId],
            ['status' => 'MAPPED', 'employee_id' => $employeeId, 'employee_name' => $empFullName, 'reprocessed' => $reprocessedCount],
            null,
            null,
            "Linked biometric identity [User ID: {$biometricUserId}] to employee {$empFullName} ({$emp['employee_code']}). Reprocessed {$reprocessedCount} raw punches."
        );

        $this->db->transComplete();

        return [
            'success'            => true,
            'message'            => "Biometric identity [{$biometricUserId}] successfully linked to {$empFullName}. {$reprocessedCount} raw attendance punch(es) reprocessed.",
            'mapping_id'         => $mappingId,
            'employee'           => $emp,
            'reprocessed_count'  => $reprocessedCount
        ];
    }

    /**
     * Reprocess all UNMATCHED raw events and historical biometric_attendance_events for a biometric identity into official attendance logs.
     * Uses the ORIGINAL biometric_attendance_events.event_time values (never created_at, never mapping time).
     */
    public function reprocessPendingEvents(string $biometricUserId, string $employeeId, string $companyId, ?array $employeeData = null): int
    {
        if (empty($employeeData)) {
            $empCandidates = $this->generateCandidateVariants($employeeId);
            $employeeData = $this->employeeModel
                ->where('company_id', $companyId)
                ->groupStart()
                    ->whereIn('id', $empCandidates)
                    ->orWhereIn('employee_code', $empCandidates)
                ->groupEnd()
                ->first();
        }

        if (!$employeeData) {
            return 0;
        }

        $canonicalEmpId = $employeeData['id'];
        $pinCandidates = $this->generateCandidateVariants($biometricUserId);
        $now = date('Y-m-d H:i:s');

        // 1. Query historical events from biometric_attendance_events
        $bioEvents = [];
        if ($this->db->tableExists('biometric_attendance_events')) {
            $bioBuilder = $this->db->table('biometric_attendance_events');
            if (!empty($companyId)) {
                $bioBuilder->where('company_id', $companyId);
            }
            $bioBuilder->whereIn('device_user_id', $pinCandidates)
                       ->orderBy('event_time', 'ASC');
            $bioEvents = $bioBuilder->get()->getResultArray();

            // Immediately map employee_id on all biometric_attendance_events
            if (!empty($bioEvents)) {
                $bioUpdateBuilder = $this->db->table('biometric_attendance_events');
                if (!empty($companyId)) {
                    $bioUpdateBuilder->where('company_id', $companyId);
                }
                $bioUpdateBuilder->whereIn('device_user_id', $pinCandidates)
                                 ->update(['employee_id' => $canonicalEmpId]);
            }
        }

        // 2. Query events from raw_biometric_events
        $rawEvents = [];
        if ($this->db->tableExists('raw_biometric_events')) {
            $rawBuilder = $this->rawEventModel
                ->whereIn('biometric_user_id', $pinCandidates);
            if (!empty($companyId)) {
                $rawBuilder->where('company_id', $companyId);
            }
            $rawBuilder->orderBy('punch_time', 'ASC');
            $rawEvents = $rawBuilder->findAll();
        }

        if (empty($bioEvents) && empty($rawEvents)) {
            return 0;
        }

        // 3. Consolidate all historical punches preserving original event timestamps
        // Deduplicate using timestamp down to second
        $unifiedPunches = [];
        $seenTimestamps = [];

        foreach ($bioEvents as $bEvent) {
            // AUTHORITATIVE SOURCE: event_time (NOT created_at)
            $punchTime = trim($bEvent['event_time'] ?? '');
            if (empty($punchTime) || $punchTime === '0000-00-00 00:00:00') {
                continue;
            }
            $ts = strtotime($punchTime);
            if (!$ts) continue;

            $normTime = date('Y-m-d H:i:s', $ts);
            $key = $normTime;
            if (isset($seenTimestamps[$key])) {
                continue;
            }
            $seenTimestamps[$key] = true;

            $unifiedPunches[] = [
                'type'        => 'biometric_attendance_events',
                'id'          => $bEvent['id'] ?? null,
                'punch_time'  => $normTime,
                'device_id'   => $bEvent['device_id'] ?? null,
                'device_name' => 'Biometric Device',
            ];
        }

        foreach ($rawEvents as $rEvent) {
            $punchTime = trim($rEvent['punch_time'] ?? '');
            if (empty($punchTime) || $punchTime === '0000-00-00 00:00:00') {
                continue;
            }
            $ts = strtotime($punchTime);
            if (!$ts) continue;

            $normTime = date('Y-m-d H:i:s', $ts);
            $key = $normTime;
            if (isset($seenTimestamps[$key])) {
                // If already recorded from biometric_attendance_events, just mark raw event as reprocessed
                $this->rawEventModel->update($rEvent['id'], [
                    'matching_status'      => 'REPROCESSED',
                    'resolved_employee_id' => $canonicalEmpId,
                    'processed_at'         => $now,
                    'reprocess_notes'      => 'Matched via biometric_attendance_events.'
                ]);
                continue;
            }
            $seenTimestamps[$key] = true;

            $unifiedPunches[] = [
                'type'        => 'raw_biometric_events',
                'id'          => $rEvent['id'] ?? null,
                'punch_time'  => $normTime,
                'device_id'   => $rEvent['device_id'] ?? null,
                'device_name' => $rEvent['device_name'] ?? 'Biometric Device',
            ];
        }

        if (empty($unifiedPunches)) {
            return 0;
        }

        // 4. Sort chronologically by original punch_time
        usort($unifiedPunches, function ($a, $b) {
            return strcmp($a['punch_time'], $b['punch_time']);
        });

        // 5. Check if employee joining_date needs to be aligned with historical punches
        $earliestPunchDate = substr($unifiedPunches[0]['punch_time'], 0, 10);
        $empJoin = employee_joining_date($employeeData) ?? $employeeData['employment_start_date'] ?? null;
        if (!empty($empJoin) && $empJoin > $earliestPunchDate) {
            $empUpdate = [];
            $empFields = $this->db->getFieldNames('employees');
            if (in_array('joining_date', $empFields, true)) {
                $empUpdate['joining_date'] = $earliestPunchDate;
            }
            if (in_array('employment_start_date', $empFields, true)) {
                $empUpdate['employment_start_date'] = $earliestPunchDate;
            }
            if (!empty($empUpdate)) {
                $this->employeeModel->update($canonicalEmpId, $empUpdate);
            }
        }

        // 6. Ingest into attendance_logs using AttendanceService
        $attService = new AttendanceService();
        $reprocessedCount = 0;

        // Check if biometric_attendance_events has attendance_log_id column
        $hasBioAttLogCol = false;
        if ($this->db->tableExists('biometric_attendance_events')) {
            $bioFields = $this->db->getFieldNames('biometric_attendance_events');
            $hasBioAttLogCol = in_array('attendance_log_id', $bioFields, true);
        }

        foreach ($unifiedPunches as $punch) {
            $timestamp = strtotime($punch['punch_time']);
            if (!$timestamp) continue;

            $date = date('Y-m-d', $timestamp);
            $time = date('H:i:s', $timestamp);
            $method = !empty($punch['device_name']) ? "Biometric Device: {$punch['device_name']}" : 'Biometric Hardware Ingestion';

            // Synchronize punch via closure-safe syncAttendanceLog
            $result = $this->syncAttendanceLog($canonicalEmpId, $date, $time, $method, $attService);

            $logId = $result['log_id'] ?? null;
            if (!$logId) {
                // Look up log ID for this date and employee
                $existingLog = $this->db->table('attendance_logs')
                    ->select('id')
                    ->where('employee_id', $canonicalEmpId)
                    ->where('date', $date)
                    ->get()
                    ->getRowArray();
                $logId = $existingLog['id'] ?? null;
            }

            if (!empty($result['success'])) {
                if ($punch['type'] === 'raw_biometric_events' && !empty($punch['id'])) {
                    $this->rawEventModel->update($punch['id'], [
                        'matching_status'      => 'REPROCESSED',
                        'resolved_employee_id' => $canonicalEmpId,
                        'attendance_log_id'    => $logId,
                        'processed_at'         => $now,
                        'reprocess_notes'      => $result['message'] ?? 'Processed during biometric mapping.'
                    ]);
                } elseif ($punch['type'] === 'biometric_attendance_events' && !empty($punch['id']) && $hasBioAttLogCol && $logId) {
                    $this->db->table('biometric_attendance_events')
                        ->where('id', $punch['id'])
                        ->update(['attendance_log_id' => $logId]);
                }
                $reprocessedCount++;
            } else {
                if ($punch['type'] === 'raw_biometric_events' && !empty($punch['id'])) {
                    $this->rawEventModel->update($punch['id'], [
                        'resolved_employee_id' => $canonicalEmpId,
                        'attendance_log_id'    => $logId,
                        'reprocess_notes'      => $result['message'] ?? 'Attendance engine note.'
                    ]);
                }
            }
        }

        // 7. Update unmatched_biometric_identities record with accurate event count
        $unmatchedRec = $this->unmatchedModel
            ->where('company_id', $companyId)
            ->whereIn('biometric_user_id', $pinCandidates)
            ->first();

        if ($unmatchedRec) {
            $totalEventCount = max(count($unifiedPunches), (int)($unmatchedRec['event_count'] ?? 0));
            $this->unmatchedModel->update($unmatchedRec['id'], [
                'status'             => 'MAPPED',
                'mapped_employee_id' => $canonicalEmpId,
                'event_count'        => $totalEventCount,
                'last_seen_at'       => end($unifiedPunches)['punch_time'] ?? $now,
                'mapped_at'          => $now,
                'updated_at'         => $now
            ]);
        }

        return $reprocessedCount;
    }

    /**
     * Mark an unmatched identity as IGNORED (with reason)
     */
    public function ignoreBiometricIdentity(string $unmatchedId, string $companyId, string $reason, ?string $actorUserId = null): array
    {
        $unmatched = $this->unmatchedModel
            ->where('id', $unmatchedId)
            ->where('company_id', $companyId)
            ->first();

        if (!$unmatched) {
            return ['success' => false, 'message' => 'Unmatched identity record not found.'];
        }

        $now = date('Y-m-d H:i:s');
        $this->unmatchedModel->update($unmatchedId, [
            'status'        => 'IGNORED',
            'ignore_reason' => $reason,
            'mapped_by'     => $actorUserId,
            'updated_at'    => $now
        ]);

        // Also mark raw events as IGNORED
        $this->rawEventModel
            ->where('company_id', $companyId)
            ->where('biometric_user_id', $unmatched['biometric_user_id'])
            ->where('matching_status', 'UNMATCHED')
            ->set(['matching_status' => 'IGNORED', 'reprocess_notes' => "Ignored by admin: {$reason}"])
            ->update();

        $this->auditService->log(
            $actorUserId,
            'biometric',
            'biometric.ignored',
            $unmatchedId,
            ['status' => $unmatched['status']],
            ['status' => 'IGNORED', 'reason' => $reason],
            null,
            null,
            "Ignored unmatched biometric identity [User ID: {$unmatched['biometric_user_id']}]. Reason: {$reason}"
        );

        return ['success' => true, 'message' => 'Unmatched biometric identity marked as ignored.'];
    }

    /**
     * Unmap / deactivate an existing mapping
     */
    public function unmapBiometricIdentity(string $mappingId, string $companyId, ?string $actorUserId = null, ?string $reason = null): array
    {
        $mapping = $this->mappingModel
            ->where('id', $mappingId)
            ->where('company_id', $companyId)
            ->first();

        if (!$mapping) {
            return ['success' => false, 'message' => 'Mapping record not found.'];
        }

        $now = date('Y-m-d H:i:s');
        $this->mappingModel->update($mappingId, [
            'status'     => 'Disabled',
            'notes'      => $reason ?: 'Unmapped by administrator.',
            'updated_at' => $now
        ]);

        // Reset unmatched identity back to UNMATCHED if exists
        $this->unmatchedModel
            ->where('company_id', $companyId)
            ->where('biometric_user_id', $mapping['biometric_user_id'])
            ->set(['status' => 'UNMATCHED', 'mapped_employee_id' => null, 'updated_at' => $now])
            ->update();

        $this->auditService->log(
            $actorUserId,
            'biometric',
            'biometric.unmapped',
            $mappingId,
            ['status' => 'Active', 'employee_id' => $mapping['employee_id']],
            ['status' => 'Disabled', 'reason' => $reason],
            null,
            null,
            "Unmapped biometric identity [User ID: {$mapping['biometric_user_id']}]. Reason: " . ($reason ?: 'None specified')
        );

        return ['success' => true, 'message' => 'Biometric mapping disabled successfully.'];
    }

    /**
     * Closure-safe synchronization of a biometric punch or existing attendance log for an employee and date.
     * Ensures an approved Company Early Closure row is never downgraded to Absent, Missing Punch, Half Day, or Early Out,
     * and its working_hours / closure_credit_hours are never zeroed or reduced.
     */
    public function syncAttendanceLog(
        string $employeeId,
        string $date,
        ?string $punchTime = null,
        string $method = 'Biometric Hardware Ingestion',
        ?\App\Services\AttendanceService $attService = null,
        ?string $companyId = null
    ): array {
        if (empty($companyId) && $this->db->tableExists('employees')) {
            $empRow = $this->db->table('employees')->select('company_id')->where('id', $employeeId)->get()->getRowArray();
            $companyId = $empRow['company_id'] ?? null;
        }

        $existingLog = null;
        if ($this->db->tableExists('attendance_logs')) {
            $existingLog = $this->db->table('attendance_logs')
                ->where('employee_id', $employeeId)
                ->where('date', $date)
                ->get()
                ->getRowArray();
        }

        $wasClosure = \App\Models\AttendanceModel::isClosureLog($existingLog);
        $origWorkingHours = (float)($existingLog['working_hours'] ?? 0.0);
        $origClosureCredit = (float)($existingLog['closure_credit_hours'] ?? 0.0);
        $origLateMinutes = (int)($existingLog['late_minutes'] ?? 0);
        $origNormStatus = \App\Models\AttendanceModel::normalizeAttendanceStatus($existingLog['status'] ?? '');
        $wasLate = $origLateMinutes > 0 || in_array($origNormStatus, ['Late', 'Late & Early Out'], true);

        if ($punchTime !== null) {
            $normTime = strlen($punchTime) === 5 ? $punchTime . ':00' : $punchTime;
            // If replaying the exact same check_in punch on an existing log, do not treat it as a 0-minute check_out
            if ($existingLog && !empty($existingLog['check_in'])) {
                $inTs = strtotime($date . ' ' . $existingLog['check_in']);
                $pTs = strtotime($date . ' ' . $normTime);
                if ($inTs !== false && $pTs !== false && abs($pTs - $inTs) < 60) {
                    if ($wasClosure) {
                        $preservedStatus = $wasLate ? 'Late' : 'Present (Early Closure)';
                        $preservedHours = max($origWorkingHours, $origClosureCredit > 0 ? $origClosureCredit : 8.0);
                        $this->db->table('attendance_logs')
                            ->where('id', $existingLog['id'])
                            ->update([
                                'status'            => $preservedStatus,
                                'working_hours'     => $preservedHours,
                                'early_out_minutes' => 0,
                                'updated_at'        => date('Y-m-d H:i:s'),
                            ]);
                        return [
                            'success'       => true,
                            'type'          => 'Check-In (Idempotent)',
                            'log_id'        => $existingLog['id'],
                            'status'        => $preservedStatus,
                            'working_hours' => $preservedHours,
                            'message'       => 'Duplicate check-in punch ignored; closure log preserved.',
                        ];
                    }
                    return [
                        'success'       => true,
                        'type'          => 'Check-In (Idempotent)',
                        'log_id'        => $existingLog['id'],
                        'status'        => $existingLog['status'] ?? 'Present',
                        'working_hours' => $origWorkingHours,
                        'message'       => 'Duplicate check-in punch ignored.',
                    ];
                }
            }

            $attService = $attService ?? new \App\Services\AttendanceService();
            $result = $attService->recordHardwarePunch($employeeId, $method, $date, $normTime, true, $companyId);
        } else {
            if (!$existingLog) {
                return ['success' => false, 'message' => 'No attendance log found to synchronize.'];
            }
            $result = [
                'success'       => true,
                'log_id'        => $existingLog['id'],
                'status'        => $existingLog['status'] ?? 'Absent',
                'working_hours' => $origWorkingHours,
            ];
        }

        // Post-sync guard: if the row was a closure row, ensure it was not downgraded or zeroed
        if ($wasClosure && $this->db->tableExists('attendance_logs')) {
            $logId = $result['log_id'] ?? ($existingLog['id'] ?? null);
            if ($logId) {
                $afterLog = $this->db->table('attendance_logs')->where('id', $logId)->get()->getRowArray();
                if ($afterLog) {
                    $afterLateMins = max($origLateMinutes, (int)($afterLog['late_minutes'] ?? 0));
                    $afterNormStatus = \App\Models\AttendanceModel::normalizeAttendanceStatus($afterLog['status'] ?? '');
                    $isNowLate = $wasLate || $afterLateMins > 0 || in_array($afterNormStatus, ['Late', 'Late & Early Out'], true);
                    $expectedStatus = $isNowLate ? 'Late' : 'Present (Early Closure)';
                    $afterHours = (float)($afterLog['working_hours'] ?? 0.0);
                    $expectedHours = max($afterHours, $origWorkingHours, $origClosureCredit > 0 ? $origClosureCredit : 8.0);

                    $tableFields = $this->db->getFieldNames('attendance_logs');
                    $fixPayload = [
                        'status'            => $expectedStatus,
                        'working_hours'     => $expectedHours,
                        'late_minutes'      => $afterLateMins,
                        'early_out_minutes' => 0,
                        'updated_at'        => date('Y-m-d H:i:s'),
                    ];
                    if (in_array('is_company_closure', $tableFields, true)) {
                        $fixPayload['is_company_closure'] = 1;
                    }
                    if (in_array('closure_credit_hours', $tableFields, true) && $origClosureCredit > 0) {
                        $fixPayload['closure_credit_hours'] = $origClosureCredit;
                    }
                    if (in_array('net_hours', $tableFields, true)) {
                        $fixPayload['net_hours'] = $expectedHours;
                    }
                    if (in_array('early_leaving_minutes', $tableFields, true)) {
                        $fixPayload['early_leaving_minutes'] = 0;
                    }
                    $this->db->table('attendance_logs')->where('id', $logId)->update($fixPayload);

                    $result['status'] = $expectedStatus;
                    $result['working_hours'] = $expectedHours;
                }
            }
        }

        return $result;
    }
}
