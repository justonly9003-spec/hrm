<?php

namespace App\Services;

use App\Models\PerformanceModel;
use App\Models\GoalModel;
use App\Models\KPIModel;
use App\Models\EmployeePromotionModel;
use App\Models\EmployeeModel;
use App\Models\DesignationModel;
use Ramsey\Uuid\Uuid;

/**
 * PerformanceService
 * 
 * Enterprise 360 Appraisals, OKR & Goal Tracking, Designation KPI Distributions,
 * and Automated Promotion & Merit Increment Pipeline.
 */
class PerformanceService
{
    protected $db;
    protected $performanceModel;
    protected $goalModel;
    protected $kpiModel;
    protected $promotionModel;
    protected $employeeModel;
    protected $auditService;
    protected $notificationService;

    public function __construct()
    {
        $this->db = \Config\Database::connect();
        $this->ensureTablesExist();
        $this->performanceModel = new PerformanceModel();
        $this->goalModel = new GoalModel();
        $this->kpiModel = new KPIModel();
        $this->promotionModel = new EmployeePromotionModel();
        $this->employeeModel = new EmployeeModel();
        $this->auditService = new AuditService();
        $this->notificationService = new NotificationService();
    }

    /**
     * Ensure database tables for performance, goals, KPIs and promotions exist
     */
    public function ensureTablesExist(): void
    {
        try {
            // 1. Employee Goals Table
            if (!$this->db->tableExists('employee_goals')) {
                $this->db->query("
                    CREATE TABLE IF NOT EXISTS `employee_goals` (
                        `id` VARCHAR(36) NOT NULL PRIMARY KEY,
                        `employee_id` VARCHAR(36) NOT NULL,
                        `title` VARCHAR(255) NOT NULL,
                        `description` TEXT NULL,
                        `target_date` DATE NOT NULL,
                        `progress_pct` INT DEFAULT 0,
                        `status` ENUM('Pending', 'Ongoing', 'Achieved', 'Missed') DEFAULT 'Pending',
                        `created_by` VARCHAR(36) NULL,
                        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
                        `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                        INDEX `idx_goal_emp` (`employee_id`),
                        INDEX `idx_goal_status` (`status`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
                ");
            }

            // 2. Designation KPIs Table
            if (!$this->db->tableExists('designation_kpis')) {
                $this->db->query("
                    CREATE TABLE IF NOT EXISTS `designation_kpis` (
                        `id` VARCHAR(36) NOT NULL PRIMARY KEY,
                        `designation_id` VARCHAR(36) NOT NULL,
                        `kpi_name` VARCHAR(255) NOT NULL,
                        `target_metric` TEXT NOT NULL,
                        `weight` INT DEFAULT 25,
                        `status` ENUM('active', 'inactive') DEFAULT 'active',
                        `company_id` VARCHAR(36) NULL,
                        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
                        `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                        INDEX `idx_kpi_desg` (`designation_id`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
                ");
            }

            // 3. Ensure performance_evaluations columns
            if ($this->db->tableExists('performance_evaluations')) {
                $fields = $this->db->getFieldNames('performance_evaluations');
                
                $columnsToAdd = [
                    'cycle_name' => "VARCHAR(100) NULL DEFAULT 'Annual Appraisal " . date('Y') . "'",
                    'stage' => "ENUM('Draft', 'Self_Submitted', 'Manager_Reviewed', 'HR_Closed') DEFAULT 'Manager_Reviewed'",
                    'self_score' => "DECIMAL(5, 2) DEFAULT 85.00",
                    'peer_score' => "DECIMAL(5, 2) DEFAULT 85.00",
                    'manager_score' => "DECIMAL(5, 2) DEFAULT 90.00",
                    'kpi_score' => "DECIMAL(5, 2) DEFAULT 88.00",
                    'aggregate_score' => "DECIMAL(5, 2) DEFAULT 87.60",
                    'rating_class' => "VARCHAR(100) NULL",
                    'recommendation' => "TEXT NULL",
                    'comments' => "TEXT NULL",
                    'company_id' => "VARCHAR(36) NULL"
                ];

                foreach ($columnsToAdd as $col => $typeDef) {
                    if (!in_array($col, $fields, true)) {
                        $this->db->query("ALTER TABLE `performance_evaluations` ADD COLUMN `{$col}` {$typeDef}");
                    }
                }
            }

            // 4. Ensure employee_promotions columns
            if ($this->db->tableExists('employee_promotions')) {
                $fields = $this->db->getFieldNames('employee_promotions');
                if (!in_array('effective_date', $fields, true)) {
                    $this->db->query("ALTER TABLE `employee_promotions` ADD COLUMN `effective_date` DATE NULL");
                }
                if (!in_array('status', $fields, true)) {
                    $this->db->query("ALTER TABLE `employee_promotions` ADD COLUMN `status` ENUM('Pending_Approval', 'Approved', 'Rejected') DEFAULT 'Pending_Approval'");
                }
            }

            // Seed initial data if tables are empty
            $this->seedInitialDataIfEmpty();

        } catch (\Throwable $e) {
            log_message('error', 'PerformanceService ensureTablesExist error: ' . $e->getMessage());
        }
    }

    /**
     * Seed realistic sample data if empty
     */
    private function seedInitialDataIfEmpty(): void
    {
        try {
            // Seed KPIs if empty
            if ($this->db->tableExists('designation_kpis') && $this->db->table('designation_kpis')->countAllResults() === 0) {
                $desgs = $this->db->table('designations')->get()->getResultArray();
                $desgMap = [];
                foreach ($desgs as $d) {
                    $dName = $d['name'] ?? $d['title'] ?? '';
                    if (!empty($dName)) {
                        $desgMap[strtolower($dName)] = $d['id'];
                    }
                }

                $sampleKPIs = [
                    ['title' => 'Chief Technology Officer', 'kpi' => 'Platform Uptime & Architecture SLAs', 'metric' => 'Maintain 99.95% production uptime, zero fatal data loss events', 'weight' => 40],
                    ['title' => 'Senior Software Architect', 'kpi' => 'Delivery Velocity & Code Quality', 'metric' => 'Deploy < 2% hotfix rate, sprint velocity achievement > 92%', 'weight' => 40],
                    ['title' => 'Software Engineer', 'kpi' => 'Feature Delivery & Test Coverage', 'metric' => 'Resolve 20+ story points per cycle, unit test coverage > 85%', 'weight' => 50],
                    ['title' => 'HR Manager', 'kpi' => 'Talent Acquisition & Retention', 'metric' => 'Time to hire < 21 days, employee retention > 95%', 'weight' => 40],
                    ['title' => 'Finance Manager', 'kpi' => 'Financial Audit Compliance & Accuracy', 'metric' => 'Zero tax filing deviations, 100% on-time monthly payroll disbursements', 'weight' => 45],
                ];

                foreach ($sampleKPIs as $item) {
                    $desgId = $desgMap[strtolower($item['title'])] ?? ($desgs[0]['id'] ?? 'desg-001');
                    $this->db->table('designation_kpis')->insert([
                        'id' => 'KPI-' . Uuid::uuid4()->toString(),
                        'designation_id' => $desgId,
                        'kpi_name' => $item['kpi'],
                        'target_metric' => $item['metric'],
                        'weight' => $item['weight'],
                        'status' => 'active',
                        'created_at' => date('Y-m-d H:i:s'),
                        'updated_at' => date('Y-m-d H:i:s')
                    ]);
                }
            }

            // Seed Goals if empty
            if ($this->db->tableExists('employee_goals') && $this->db->table('employee_goals')->countAllResults() === 0) {
                $emps = $this->db->table('employees')->limit(4)->get()->getResultArray();
                if (!empty($emps)) {
                    $sampleGoals = [
                        ['title' => 'Architect Cloud SQL High Availability & Microservices Migration', 'progress' => 75, 'status' => 'Ongoing'],
                        ['title' => 'Complete Advanced TypeScript & React Architecture Certification', 'progress' => 90, 'status' => 'Ongoing'],
                        ['title' => 'Implement Automated Unit Testing for Payroll & Tax Ledger Engines', 'progress' => 100, 'status' => 'Achieved'],
                        ['title' => 'Optimize Biometric ZKTeco Sync Engine Response Time (< 250ms)', 'progress' => 40, 'status' => 'Ongoing'],
                    ];

                    foreach ($sampleGoals as $idx => $sg) {
                        $emp = $emps[$idx % count($emps)];
                        $this->db->table('employee_goals')->insert([
                            'id' => 'GOL-' . (701 + $idx),
                            'employee_id' => $emp['id'],
                            'title' => $sg['title'],
                            'description' => 'Target strategic initiative assigned for current performance period.',
                            'target_date' => date('Y-m-d', strtotime('+' . (($idx + 1) * 30) . ' days')),
                            'progress_pct' => $sg['progress'],
                            'status' => $sg['status'],
                            'created_at' => date('Y-m-d H:i:s'),
                            'updated_at' => date('Y-m-d H:i:s')
                        ]);
                    }
                }
            }

            // Seed 360 Evaluations if empty
            if ($this->db->tableExists('performance_evaluations') && $this->db->table('performance_evaluations')->countAllResults() === 0) {
                $emps = $this->db->table('employees')->limit(3)->get()->getResultArray();
                if (!empty($emps)) {
                    $revData = [
                        [
                            'self' => 92, 'peer' => 94, 'mgr' => 95, 'kpi' => 90,
                            'cycle' => 'Annual Appraisal ' . date('Y'),
                            'stage' => 'HR_Closed',
                            'comments' => 'Consistently leads core system refactors with exceptional precision, mentoring junior developers effectively.'
                        ],
                        [
                            'self' => 82, 'peer' => 80, 'mgr' => 85, 'kpi' => 84,
                            'cycle' => 'Mid-Year Probation Appraisal',
                            'stage' => 'Manager_Reviewed',
                            'comments' => 'Demonstrated solid delivery on schedule throughout probationary assignment.'
                        ]
                    ];

                    foreach ($revData as $i => $rv) {
                        $emp = $emps[$i % count($emps)];
                        $calc = $this->calculate360Score($rv['self'], $rv['peer'], $rv['mgr'], $rv['kpi']);

                        $this->db->table('performance_evaluations')->insert([
                            'id' => 'REV-' . (801 + $i),
                            'employee_id' => $emp['id'],
                            'reviewer_id' => $emps[0]['id'],
                            'evaluator_id' => $emps[0]['id'],
                            'cycle_name' => $rv['cycle'],
                            'review_period' => $rv['cycle'],
                            'stage' => $rv['stage'],
                            'self_score' => $rv['self'],
                            'peer_score' => $rv['peer'],
                            'manager_score' => $rv['mgr'],
                            'kpi_score' => $rv['kpi'],
                            'aggregate_score' => $calc['aggregate_score'],
                            'score' => $calc['aggregate_score'],
                            'overall_score' => $calc['aggregate_score'],
                            'rating_class' => $calc['rating_class'],
                            'recommendation' => $calc['recommendation'],
                            'comments' => $rv['comments'],
                            'feedback' => $rv['comments'],
                            'appraisal_comments' => $rv['comments'],
                            'recommended_increment' => ($calc['rating_class'] === 'Exceeds Expectations') ? 15.00 : 8.00,
                            'status' => ($rv['stage'] === 'HR_Closed') ? 'finalized' : 'submitted',
                            'created_at' => date('Y-m-d H:i:s', strtotime('-' . ($i * 10) . ' days')),
                            'updated_at' => date('Y-m-d H:i:s')
                        ]);
                    }
                }
            }

        } catch (\Throwable $e) {
            log_message('error', 'PerformanceService seedInitialData error: ' . $e->getMessage());
        }
    }

    /**
     * 360 Appraisal Scoring Algorithm
     * Weights: Self (20%) + Peer (20%) + Manager (40%) + KPI (20%)
     */
    public function calculate360Score(float $selfScore, float $peerScore, float $managerScore, float $kpiScore): array
    {
        $selfScore = max(0, min(100, $selfScore));
        $peerScore = max(0, min(100, $peerScore));
        $managerScore = max(0, min(100, $managerScore));
        $kpiScore = max(0, min(100, $kpiScore));

        // Standard 360 Multi-Tier Formula
        $aggregate = ($selfScore * 0.20) + ($peerScore * 0.20) + ($managerScore * 0.40) + ($kpiScore * 0.20);
        $aggregateRounded = round($aggregate, 1);

        // Grade classification & recommendation matrix
        if ($aggregateRounded >= 90) {
            $ratingClass = 'Exceeds Expectations';
            $recommendation = 'Recommended Fast-Track Grade Promotion & 15% Merit Increment';
            $recommendedIncrement = 15.00;
        } elseif ($aggregateRounded >= 75) {
            $ratingClass = 'Meets Expectations';
            $recommendation = 'Recommended 8% Annual Merit Increment';
            $recommendedIncrement = 8.00;
        } elseif ($aggregateRounded >= 60) {
            $ratingClass = 'Developing';
            $recommendation = 'Recommended 4% Standard Cost of Living Adjustment';
            $recommendedIncrement = 4.00;
        } else {
            $ratingClass = 'Needs Improvement (PIP)';
            $recommendation = 'Assigned to 90-Day Structured Performance Improvement Plan (PIP)';
            $recommendedIncrement = 0.00;
        }

        return [
            'self_score' => $selfScore,
            'peer_score' => $peerScore,
            'manager_score' => $managerScore,
            'kpi_score' => $kpiScore,
            'aggregate_score' => $aggregateRounded,
            'rating_class' => $ratingClass,
            'recommendation' => $recommendation,
            'recommended_increment' => $recommendedIncrement
        ];
    }

    /**
     * Submit Conducted 360 Performance Appraisal
     */
    public function submit360Appraisal(array $postData, ?string $actorUserId = null): array
    {
        $employeeId = $postData['employee_id'] ?? '';
        if (empty($employeeId)) {
            throw new \InvalidArgumentException('Employee ID is required for performance appraisal.');
        }

        $emp = $this->employeeModel->find($employeeId);
        if (!$emp) {
            throw new \InvalidArgumentException('Employee record not found.');
        }

        $selfScore = (float)($postData['self_score'] ?? 85);
        $peerScore = (float)($postData['peer_score'] ?? 85);
        $managerScore = (float)($postData['manager_score'] ?? 90);
        $kpiScore = (float)($postData['kpi_score'] ?? 88);

        $calc = $this->calculate360Score($selfScore, $peerScore, $managerScore, $kpiScore);

        $evalId = 'REV-' . Uuid::uuid4()->toString();
        $cycleName = !empty($postData['cycle_name']) ? trim($postData['cycle_name']) : ('Annual Appraisal ' . date('Y'));
        $comments = !empty($postData['comments']) ? trim($postData['comments']) : ($postData['appraisal_comments'] ?? 'Evaluation submitted.');

        $reviewerId = $postData['reviewer_id'] ?? $actorUserId ?? $emp['id'];

        $fields = $this->db->getFieldNames('performance_evaluations');

        $record = [
            'id' => $evalId,
            'employee_id' => $employeeId,
            'cycle_name' => $cycleName,
            'review_period' => $cycleName,
            'stage' => $postData['stage'] ?? 'Manager_Reviewed',
            'self_score' => $calc['self_score'],
            'peer_score' => $calc['peer_score'],
            'manager_score' => $calc['manager_score'],
            'kpi_score' => $calc['kpi_score'],
            'aggregate_score' => $calc['aggregate_score'],
            'score' => $calc['aggregate_score'],
            'overall_score' => $calc['aggregate_score'],
            'rating_class' => $calc['rating_class'],
            'recommendation' => $calc['recommendation'],
            'comments' => $comments,
            'feedback' => $comments,
            'appraisal_comments' => $comments,
            'recommended_increment' => $calc['recommended_increment'],
            'status' => 'Submitted',
            'company_id' => $emp['company_id'] ?? null,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        if (in_array('reviewer_id', $fields, true)) {
            $record['reviewer_id'] = $reviewerId;
        }
        if (in_array('evaluator_id', $fields, true)) {
            $record['evaluator_id'] = $reviewerId;
        }
        if (in_array('period_start', $fields, true)) {
            $record['period_start'] = date('Y-01-01');
        }
        if (in_array('period_end', $fields, true)) {
            $record['period_end'] = date('Y-12-31');
        }

        // Subscores 1-5 for backwards compatibility
        if (in_array('job_knowledge', $fields, true)) $record['job_knowledge'] = max(1, min(5, round($selfScore / 20)));
        if (in_array('work_quality', $fields, true)) $record['work_quality'] = max(1, min(5, round($managerScore / 20)));
        if (in_array('communication', $fields, true)) $record['communication'] = max(1, min(5, round($peerScore / 20)));
        if (in_array('punctuality', $fields, true)) $record['punctuality'] = max(1, min(5, round($kpiScore / 20)));

        $this->db->table('performance_evaluations')->insert($record);

        $empName = trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? ''));

        // Audit Log
        if ($actorUserId) {
            $this->auditService->log(
                $actorUserId,
                'performance',
                'Appraisal Completed',
                $evalId,
                null,
                $record,
                null,
                null,
                "360 appraisal submitted for {$empName}. Score: {$calc['aggregate_score']}/100 ({$calc['rating_class']})"
            );
        }

        // Send In-App Notification
        $this->notificationService->sendSystemNotification(
            $employeeId,
            'Performance Appraisal Completed',
            "Your 360 performance appraisal ({$cycleName}) has been finalized. Score: {$calc['aggregate_score']}/100 [{$calc['rating_class']}].",
            'performance',
            $evalId
        );

        return array_merge($record, ['employee_name' => $empName]);
    }

    /**
     * Advance Review Stage (Draft -> Self_Submitted -> Manager_Reviewed -> HR_Closed)
     */
    public function advanceReviewStage(string $evalId, string $nextStage, ?string $actorUserId = null): bool
    {
        $validStages = ['Draft', 'Self_Submitted', 'Manager_Reviewed', 'HR_Closed'];
        if (!in_array($nextStage, $validStages, true)) {
            throw new \InvalidArgumentException("Invalid review stage: {$nextStage}");
        }

        $review = $this->performanceModel->find($evalId);
        if (!$review) {
            throw new \InvalidArgumentException("Appraisal review {$evalId} not found.");
        }

        $update = [
            'stage' => $nextStage,
            'status' => ($nextStage === 'HR_Closed') ? 'finalized' : 'submitted',
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $this->db->table('performance_evaluations')->where('id', $evalId)->update($update);

        if ($actorUserId) {
            $this->auditService->log(
                $actorUserId,
                'performance',
                'Appraisal Stage Advanced',
                $evalId,
                ['stage' => $review['stage'] ?? ''],
                ['stage' => $nextStage],
                null,
                null,
                "Review {$evalId} moved to stage {$nextStage}"
            );
        }

        return true;
    }

    /**
     * Create Employee Goal / OKR
     */
    public function createGoal(array $postData, ?string $actorUserId = null): array
    {
        $employeeId = $postData['employee_id'] ?? '';
        $title = trim($postData['title'] ?? '');
        $targetDate = $postData['target_date'] ?? date('Y-m-d', strtotime('+30 days'));

        if (empty($employeeId) || empty($title)) {
            throw new \InvalidArgumentException('Employee and Goal Title are required.');
        }

        $emp = $this->employeeModel->find($employeeId);
        if (!$emp) {
            throw new \InvalidArgumentException('Employee not found.');
        }

        $goalId = 'GOL-' . Uuid::uuid4()->toString();
        $record = [
            'id' => $goalId,
            'employee_id' => $employeeId,
            'title' => $title,
            'description' => $postData['description'] ?? null,
            'target_date' => $targetDate,
            'progress_pct' => 0,
            'status' => 'Pending',
            'created_by' => $actorUserId,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $this->db->table('employee_goals')->insert($record);

        $empName = trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? ''));

        if ($actorUserId) {
            $this->auditService->log(
                $actorUserId,
                'performance',
                'Goal Created',
                $goalId,
                null,
                $record,
                null,
                null,
                "New goal created for {$empName}: {$title}"
            );
        }

        return array_merge($record, ['employee_name' => $empName]);
    }

    /**
     * Update Goal Progress
     */
    public function updateGoalProgress(string $goalId, int $progressPct, ?string $actorUserId = null): bool
    {
        $progressPct = max(0, min(100, $progressPct));
        $status = ($progressPct === 100) ? 'Achieved' : (($progressPct > 0) ? 'Ongoing' : 'Pending');

        $goal = $this->goalModel->find($goalId);
        if (!$goal) {
            throw new \InvalidArgumentException("Goal {$goalId} not found.");
        }

        $this->db->table('employee_goals')->where('id', $goalId)->update([
            'progress_pct' => $progressPct,
            'status' => $status,
            'updated_at' => date('Y-m-d H:i:s')
        ]);

        if ($actorUserId) {
            $this->auditService->log(
                $actorUserId,
                'performance',
                'Goal Updated',
                $goalId,
                ['progress_pct' => $goal['progress_pct']],
                ['progress_pct' => $progressPct, 'status' => $status],
                null,
                null,
                "Goal progress updated to {$progressPct}% [{$status}]"
            );
        }

        return true;
    }

    /**
     * Create / Update Designation KPI
     */
    public function saveKPI(array $postData, ?string $actorUserId = null): array
    {
        $desgId = $postData['designation_id'] ?? '';
        $kpiName = trim($postData['kpi_name'] ?? '');
        $metric = trim($postData['target_metric'] ?? '');
        $weight = max(1, min(100, (int)($postData['weight'] ?? 25)));

        if (empty($desgId) || empty($kpiName) || empty($metric)) {
            throw new \InvalidArgumentException('Designation, KPI Name, and Target Metric are required.');
        }

        $kpiId = $postData['id'] ?? ('KPI-' . Uuid::uuid4()->toString());
        $isUpdate = !empty($postData['id']) && $this->kpiModel->find($postData['id']);

        $record = [
            'id' => $kpiId,
            'designation_id' => $desgId,
            'kpi_name' => $kpiName,
            'target_metric' => $metric,
            'weight' => $weight,
            'status' => $postData['status'] ?? 'active',
            'company_id' => $postData['company_id'] ?? null,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        if ($isUpdate) {
            $this->db->table('designation_kpis')->where('id', $kpiId)->update($record);
        } else {
            $record['created_at'] = date('Y-m-d H:i:s');
            $this->db->table('designation_kpis')->insert($record);
        }

        if ($actorUserId) {
            $this->auditService->log(
                $actorUserId,
                'performance',
                $isUpdate ? 'KPI Updated' : 'KPI Created',
                $kpiId,
                null,
                $record,
                null,
                null,
                "Designation KPI saved: {$kpiName} ({$weight}%)"
            );
        }

        return $record;
    }

    /**
     * Initiate Promotion & Merit Increment
     */
    public function initiatePromotion(array $postData, ?string $actorUserId = null, bool $autoApprove = false): array
    {
        $employeeId = $postData['employee_id'] ?? '';
        $newDesgId = $postData['new_designation_id'] ?? '';
        $newSalary = (float)($postData['new_salary'] ?? 0);
        $effectiveDate = $postData['effective_date'] ?? date('Y-m-d');

        if (empty($employeeId) || empty($newDesgId) || $newSalary <= 0) {
            throw new \InvalidArgumentException('Employee, New Designation, and Valid New Salary are required.');
        }

        $emp = $this->employeeModel->find($employeeId);
        if (!$emp) {
            throw new \InvalidArgumentException('Employee record not found.');
        }

        $promoId = 'PRM-' . Uuid::uuid4()->toString();
        $status = $autoApprove ? 'Approved' : 'Pending_Approval';

        $record = [
            'id' => $promoId,
            'employee_id' => $employeeId,
            'previous_designation_id' => $emp['designation_id'] ?? null,
            'new_designation_id' => $newDesgId,
            'previous_salary' => (float)($emp['basic_salary'] ?? 0),
            'new_salary' => $newSalary,
            'promotion_date' => $effectiveDate,
            'effective_date' => $effectiveDate,
            'status' => $status,
            'remarks' => $postData['remarks'] ?? $postData['reason'] ?? 'Merit promotion based on performance appraisal score.',
            'approved_by' => $autoApprove ? $actorUserId : null,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $this->db->table('employee_promotions')->insert($record);

        // If auto-approved, update employee designation and sync salary via EmployeeSalaryService
        if ($autoApprove) {
            $this->db->table('employees')->where('id', $employeeId)->update([
                'designation_id' => $newDesgId,
                'updated_at' => date('Y-m-d H:i:s')
            ]);

            if ($newSalary > 0) {
                $salaryService = new \App\Services\EmployeeSalaryService();
                $salaryService->assignSalary($employeeId, [
                    'basic_salary'   => $newSalary,
                    'effective_from' => $effectiveDate,
                    'notes'          => 'Auto-approved merit promotion to designation ID ' . $newDesgId
                ], $emp['company_id'] ?? null);
            }
        }

        $empName = trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? ''));

        if ($actorUserId) {
            $this->auditService->log(
                $actorUserId,
                'performance',
                'Promotion Initiated',
                $promoId,
                null,
                $record,
                null,
                null,
                "Promotion initiated for {$empName}. New Salary: {$newSalary} [Status: {$status}]"
            );
        }

        return array_merge($record, ['employee_name' => $empName]);
    }

    /**
     * Approve Promotion & Update Employee Record
     */
    public function approvePromotion(string $promoId, ?string $actorUserId = null): bool
    {
        $promo = $this->promotionModel->find($promoId);
        if (!$promo) {
            throw new \InvalidArgumentException("Promotion record {$promoId} not found.");
        }

        if ($promo['status'] === 'Approved') {
            return true;
        }

        $this->db->transStart();

        // 1. Update Promotion Status
        $this->db->table('employee_promotions')->where('id', $promoId)->update([
            'status' => 'Approved',
            'approved_by' => $actorUserId,
            'updated_at' => date('Y-m-d H:i:s')
        ]);

        // 2. Update Employee Master Record
        if (!empty($promo['employee_id']) && !empty($promo['new_designation_id'])) {
            $this->db->table('employees')->where('id', $promo['employee_id'])->update([
                'designation_id' => $promo['new_designation_id'],
                'updated_at' => date('Y-m-d H:i:s')
            ]);

            $newSal = (float)($promo['new_salary'] ?? 0);
            if ($newSal > 0) {
                $salaryService = new \App\Services\EmployeeSalaryService();
                $promoEmp = (new \App\Models\EmployeeModel())->find($promo['employee_id']);
                $salaryService->assignSalary($promo['employee_id'], [
                    'basic_salary'   => $newSal,
                    'effective_from' => $promo['effective_date'] ?? date('Y-m-d'),
                    'notes'          => 'Approved merit promotion to designation ID ' . $promo['new_designation_id']
                ], $promoEmp['company_id'] ?? null);
            }
        }

        $this->db->transComplete();

        if ($this->db->transStatus() === false) {
            throw new \RuntimeException("Failed to atomically commit promotion approval.");
        }

        // 3. Notify Employee
        $this->notificationService->sendSystemNotification(
            $promo['employee_id'],
            'Promotion Officially Approved',
            "Congratulations! Your promotion to the new designation with adjusted basic salary of {$promo['new_salary']} has been approved.",
            'performance',
            $promoId
        );

        if ($actorUserId) {
            $this->auditService->log(
                $actorUserId,
                'performance',
                'Promotion Approved',
                $promoId,
                ['status' => 'Pending_Approval'],
                ['status' => 'Approved'],
                null,
                null,
                "Promotion approved for employee {$promo['employee_id']}"
            );
        }

        return true;
    }

    /**
     * Reject Promotion
     */
    public function rejectPromotion(string $promoId, ?string $reason = null, ?string $actorUserId = null): bool
    {
        $promo = $this->promotionModel->find($promoId);
        if (!$promo) {
            throw new \InvalidArgumentException("Promotion record {$promoId} not found.");
        }

        $this->db->table('employee_promotions')->where('id', $promoId)->update([
            'status' => 'Rejected',
            'remarks' => !empty($reason) ? ($promo['remarks'] . ' | Rejected: ' . $reason) : $promo['remarks'],
            'updated_at' => date('Y-m-d H:i:s')
        ]);

        if ($actorUserId) {
            $this->auditService->log(
                $actorUserId,
                'performance',
                'Promotion Rejected',
                $promoId,
                ['status' => $promo['status']],
                ['status' => 'Rejected', 'reason' => $reason],
                null,
                null,
                "Promotion rejected for employee {$promo['employee_id']}"
            );
        }

        return true;
    }

    /**
     * Get Comprehensive Performance Analytics & KPI Dashboard
     */
    public function getPerformanceStats(?string $companyId = null): array
    {
        $reviews = $this->performanceModel->getEvaluationsWithDetails(null, $companyId);
        $goals = $this->goalModel->getGoalsWithDetails(null, $companyId);
        $kpis = $this->kpiModel->getKPIsWithDetails(null, $companyId);
        $promotions = $this->promotionModel->getPromotionsWithDetails(null, $companyId);

        $totalReviews = count($reviews);
        $sumScore = 0;
        $exceedsCount = 0;
        $pipCount = 0;

        foreach ($reviews as $r) {
            $score = (float)($r['aggregate_score'] ?? 0);
            $sumScore += $score;
            if ($score >= 90) $exceedsCount++;
            if ($score < 60) $pipCount++;
        }

        $avgScore = $totalReviews > 0 ? round($sumScore / $totalReviews, 1) : 0;

        $totalGoals = count($goals);
        $achievedGoals = 0;
        $ongoingGoals = 0;

        foreach ($goals as $g) {
            if (($g['status'] ?? '') === 'Achieved' || (int)($g['progress_pct'] ?? 0) === 100) {
                $achievedGoals++;
            } else {
                $ongoingGoals++;
            }
        }

        $goalCompletionRate = $totalGoals > 0 ? round(($achievedGoals / $totalGoals) * 100, 1) : 0;

        $pendingPromos = count(array_filter($promotions, function($p) {
            return ($p['status'] ?? '') === 'Pending_Approval' || ($p['status'] ?? '') === 'pending';
        }));

        return [
            'total_reviews' => $totalReviews,
            'average_score' => $avgScore,
            'exceeds_expectations_count' => $exceedsCount,
            'pip_count' => $pipCount,
            'total_goals' => $totalGoals,
            'achieved_goals' => $achievedGoals,
            'ongoing_goals' => $ongoingGoals,
            'goal_completion_rate' => $goalCompletionRate,
            'total_kpis' => count($kpis),
            'pending_promotions' => $pendingPromos,
            'total_promotions' => count($promotions)
        ];
    }
}
