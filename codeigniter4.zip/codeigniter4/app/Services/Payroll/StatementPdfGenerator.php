<?php

namespace App\Services\Payroll;

/**
 * StatementPdfGenerator
 *
 * Builds multi-page, table based statements (salary, tax, provident fund) as a genuine
 * PDF 1.4 binary, in the same dependency free way as PayslipPdfGenerator
 * (A4, Helvetica / Helvetica-Bold, no HTML).
 *
 * $doc = [
 *   'company'   => string,                        // banner title
 *   'title'     => string,                        // e.g. "SALARY STATEMENT 2026"
 *   'info'      => [label => value, ...],         // employee block (2 columns)
 *   'summary'   => [label => value, ...],         // 1..5 highlighted boxes
 *   'columns'   => [['label'=>..,'w'=>..,'align'=>'L|R|C'], ...] // widths must add up to 515
 *   'rows'      => [[cell, cell, ...], ...],
 *   'totals'    => [cell, cell, ...] | null,      // bold closing row
 *   'note'      => string,                        // small print under the table
 *   'generated' => string,
 * ]
 */
class StatementPdfGenerator
{
    private const PAGE_W = 595.28;
    private const PAGE_H = 841.89;
    private const LEFT   = 40.0;
    private const WIDTH  = 515.0;
    private const BOTTOM = 790.0; // top-based y where table content must stop
    private const ROW_H  = 17.0;
    private const HEAD_H = 20.0;

    /** Helvetica advance widths (1/1000 em) for ASCII 32..126 */
    private const W = [
        278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278,
        556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556,
        1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778,
        667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556,
        333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556,
        556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584,
    ];

    /** @var string[] content stream per page (ops without footer) */
    private array $pages = [];
    private int $cur = -1;

    public function generate(array $doc): string
    {
        $this->pages = [];
        $this->cur   = -1;

        $columns = $doc['columns'];
        $rows    = $doc['rows'] ?? [];

        $top = $this->firstPage($doc);

        // Table header on page 1
        $top = $this->tableHeader($columns, $top);

        if (!$rows && empty($doc['totals'])) {
            $this->text(self::LEFT + 6, $top + 12, 'No records found for this period.', 9, false, [0.4, 0.4, 0.4]);
            $top += self::ROW_H;
        }

        $i = 0;
        foreach ($rows as $row) {
            if ($top + self::ROW_H > self::BOTTOM) {
                $this->newPage();
                $top = $this->tableHeader($columns, 50.0);
            }
            if ($i % 2 === 1) {
                $this->rect(self::LEFT, $top, self::WIDTH, self::ROW_H, [0.96, 0.97, 0.98]);
            }
            $this->tableRow($columns, $row, $top, false);
            $top += self::ROW_H;
            $i++;
        }

        if (!empty($doc['totals'])) {
            if ($top + self::ROW_H + 4 > self::BOTTOM) {
                $this->newPage();
                $top = $this->tableHeader($columns, 50.0);
            }
            $this->rect(self::LEFT, $top, self::WIDTH, self::ROW_H + 2, [0.89, 0.92, 0.97]);
            $this->tableRow($columns, $doc['totals'], $top + 1, true);
            $top += self::ROW_H + 2;
        }

        // closing rule
        $this->line(self::LEFT, $top, self::LEFT + self::WIDTH, $top, [0.8, 0.84, 0.9]);
        $top += 14;

        if (!empty($doc['note'])) {
            foreach ($this->wrap((string)$doc['note'], 8, self::WIDTH) as $ln) {
                if ($top + 11 > self::BOTTOM) {
                    $this->newPage();
                    $top = 50.0;
                }
                $this->text(self::LEFT, $top + 8, $ln, 8, false, [0.4, 0.45, 0.5]);
                $top += 11;
            }
        }

        return $this->assemble((string)($doc['generated'] ?? ''));
    }

    // ------------------------------------------------------------------ layout

    private function firstPage(array $doc): float
    {
        $this->newPage();

        // Banner
        $this->rect(self::LEFT, 40, self::WIDTH, 70, [0.06, 0.09, 0.16]);
        $this->text(self::LEFT + 16, 40 + 30, $this->fit((string)($doc['company'] ?? ''), 16, true, self::WIDTH - 32), 16, true, [1, 1, 1]);
        $this->text(self::LEFT + 16, 40 + 52, (string)($doc['title'] ?? ''), 11, false, [0.78, 0.84, 0.95]);

        // Employee info, two columns
        $top   = 126.0;
        $info  = $doc['info'] ?? [];
        $items = [];
        foreach ($info as $k => $v) {
            $items[] = [(string)$k, (string)$v];
        }
        $perCol = (int)ceil(max(1, count($items)) / 2);
        foreach ($items as $idx => [$label, $value]) {
            $col = intdiv($idx, $perCol);
            $row = $idx % $perCol;
            $x   = self::LEFT + $col * 260;
            $y   = $top + $row * 15;
            $this->text($x, $y + 9, $label, 8.5, false, [0.45, 0.5, 0.58]);
            $this->text($x + 78, $y + 9, $this->fit($value, 9, true, 170), 9, true, [0.1, 0.12, 0.18]);
        }
        $top += $perCol * 15 + 12;

        // Summary boxes
        $summary = $doc['summary'] ?? [];
        $n = count($summary);
        if ($n > 0) {
            $gap = 8.0;
            $bw  = (self::WIDTH - $gap * ($n - 1)) / $n;
            $x   = self::LEFT;
            foreach ($summary as $label => $value) {
                $this->rect($x, $top, $bw, 46, [0.93, 0.95, 0.99]);
                $this->rect($x, $top, 3, 46, [0.15, 0.39, 0.92]);
                $this->text($x + 10, $top + 16, $this->fit((string)$label, 7.5, false, $bw - 14), 7.5, false, [0.4, 0.45, 0.55]);

                // shrink the figure until it fits the box, so big amounts are never cut off
                $size = 11.0;
                while ($size > 7.0 && $this->width($this->clean((string)$value), $size, true) > $bw - 14) {
                    $size -= 0.5;
                }
                $this->text($x + 10, $top + 34, $this->fit((string)$value, $size, true, $bw - 14), $size, true, [0.06, 0.09, 0.16]);
                $x += $bw + $gap;
            }
            $top += 46 + 16;
        }

        return $top;
    }

    private function tableHeader(array $columns, float $top): float
    {
        $this->rect(self::LEFT, $top, self::WIDTH, self::HEAD_H, [0.06, 0.09, 0.16]);
        $x = self::LEFT;
        foreach ($columns as $c) {
            $this->cell($x, $top + 13.5, (string)$c['label'], (float)$c['w'], (string)($c['align'] ?? 'L'), 8, true, [1, 1, 1]);
            $x += (float)$c['w'];
        }
        return $top + self::HEAD_H;
    }

    private function tableRow(array $columns, array $cells, float $top, bool $bold): void
    {
        $x = self::LEFT;
        foreach ($columns as $i => $c) {
            $this->cell($x, $top + 12, (string)($cells[$i] ?? ''), (float)$c['w'], (string)($c['align'] ?? 'L'), 8.5, $bold, [0.1, 0.12, 0.18]);
            $x += (float)$c['w'];
        }
    }

    /** Text inside a column with 6pt padding; truncated if too long. */
    private function cell(float $x, float $baseTop, string $text, float $w, string $align, float $size, bool $bold, array $rgb): void
    {
        $text  = $this->fit($text, $size, $bold, $w - 12);
        $width = $this->width($text, $size, $bold);
        if ($align === 'R') {
            $tx = $x + $w - 6 - $width;
        } elseif ($align === 'C') {
            $tx = $x + ($w - $width) / 2;
        } else {
            $tx = $x + 6;
        }
        $this->text($tx, $baseTop, $text, $size, $bold, $rgb);
    }

    // ------------------------------------------------------------------ text helpers

    private function clean(string $s): string
    {
        $s = str_replace(["\xE0\xA7\xB3", "\xE2\x82\xB9"], ['BDT ', 'INR '], $s); // Taka / Rupee sign
        $t = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s);
        if ($t === false) {
            $t = $s;
        }
        return preg_replace('/[^\x20-\x7E]/', '', $t) ?? '';
    }

    private function width(string $s, float $size, bool $bold): float
    {
        $w = 0.0;
        $len = strlen($s);
        for ($i = 0; $i < $len; $i++) {
            $o = ord($s[$i]);
            $u = ($o >= 32 && $o <= 126) ? self::W[$o - 32] : 556;
            if ($bold && !($o >= 48 && $o <= 57)) {
                $u *= 1.07; // bold letters are a little wider; digits are identical
            }
            $w += $u;
        }
        return $w * $size / 1000.0;
    }

    private function fit(string $s, float $size, bool $bold, float $max): string
    {
        $s = $this->clean($s);
        if ($this->width($s, $size, $bold) <= $max) {
            return $s;
        }
        while ($s !== '' && $this->width($s . '..', $size, $bold) > $max) {
            $s = substr($s, 0, -1);
        }
        return $s . '..';
    }

    /** @return string[] */
    private function wrap(string $s, float $size, float $max): array
    {
        $words = preg_split('/\s+/', $this->clean($s)) ?: [];
        $lines = [];
        $line  = '';
        foreach ($words as $w) {
            $try = $line === '' ? $w : $line . ' ' . $w;
            if ($this->width($try, $size, false) > $max && $line !== '') {
                $lines[] = $line;
                $line    = $w;
            } else {
                $line = $try;
            }
        }
        if ($line !== '') {
            $lines[] = $line;
        }
        return $lines;
    }

    private function esc(string $s): string
    {
        return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $s);
    }

    // ------------------------------------------------------------------ drawing primitives (top-based y)

    private function newPage(): void
    {
        $this->cur++;
        $this->pages[$this->cur] = '';
    }

    private function emit(string $op): void
    {
        $this->pages[$this->cur] .= $op . "\n";
    }

    private function rgb(array $c, string $op): string
    {
        return sprintf('%.3F %.3F %.3F %s', $c[0], $c[1], $c[2], $op);
    }

    private function rect(float $x, float $top, float $w, float $h, array $fill): void
    {
        $y = self::PAGE_H - $top - $h;
        $this->emit($this->rgb($fill, 'rg'));
        $this->emit(sprintf('%.2F %.2F %.2F %.2F re f', $x, $y, $w, $h));
    }

    private function line(float $x1, float $top1, float $x2, float $top2, array $rgb): void
    {
        $this->emit($this->rgb($rgb, 'RG'));
        $this->emit('0.6 w');
        $this->emit(sprintf('%.2F %.2F m %.2F %.2F l S', $x1, self::PAGE_H - $top1, $x2, self::PAGE_H - $top2));
    }

    /** $baseTop = top-based y of the text baseline */
    private function text(float $x, float $baseTop, string $s, float $size, bool $bold, array $rgb): void
    {
        $s = $this->clean($s);
        if ($s === '') {
            return;
        }
        $this->emit($this->rgb($rgb, 'rg'));
        $this->emit(sprintf('BT /%s %.2F Tf %.2F %.2F Td (%s) Tj ET', $bold ? 'F2' : 'F1', $size, $x, self::PAGE_H - $baseTop, $this->esc($s)));
    }

    // ------------------------------------------------------------------ PDF assembly

    private function assemble(string $generated): string
    {
        $count = count($this->pages);
        // footer with page numbers
        foreach ($this->pages as $i => $_) {
            $this->cur = $i;
            $this->line(self::LEFT, 806, self::LEFT + self::WIDTH, 806, [0.85, 0.88, 0.92]);
            $left = 'System generated statement' . ($generated !== '' ? ' - ' . $generated : '');
            $this->text(self::LEFT, 820, $left, 7.5, false, [0.5, 0.55, 0.6]);
            $label = 'Page ' . ($i + 1) . ' of ' . $count;
            $this->text(self::LEFT + self::WIDTH - $this->width($label, 7.5, false), 820, $label, 7.5, false, [0.5, 0.55, 0.6]);
        }

        $objs = [];
        $objs[1] = '<< /Type /Catalog /Pages 2 0 R >>';
        $kids = [];
        for ($i = 0; $i < $count; $i++) {
            $kids[] = (5 + $i * 2) . ' 0 R';
        }
        $objs[2] = '<< /Type /Pages /Kids [' . implode(' ', $kids) . '] /Count ' . $count . ' >>';
        $objs[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
        $objs[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';

        for ($i = 0; $i < $count; $i++) {
            $pageNo = 5 + $i * 2;
            $contNo = $pageNo + 1;
            $objs[$pageNo] = sprintf(
                '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %.2F %.2F] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents %d 0 R >>',
                self::PAGE_W,
                self::PAGE_H,
                $contNo
            );
            $stream = $this->pages[$i];
            $objs[$contNo] = '<< /Length ' . strlen($stream) . " >>\nstream\n" . $stream . 'endstream';
        }

        $pdf = "%PDF-1.4\n";
        $offsets = [];
        ksort($objs);
        foreach ($objs as $n => $body) {
            $offsets[$n] = strlen($pdf);
            $pdf .= $n . " 0 obj\n" . $body . "\nendobj\n";
        }
        $xref = strlen($pdf);
        $max  = max(array_keys($objs));
        $pdf .= "xref\n0 " . ($max + 1) . "\n";
        $pdf .= "0000000000 65535 f \n";
        for ($n = 1; $n <= $max; $n++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$n] ?? 0);
        }
        $pdf .= "trailer\n<< /Size " . ($max + 1) . " /Root 1 0 R >>\nstartxref\n" . $xref . "\n%%EOF";

        return $pdf;
    }
}
