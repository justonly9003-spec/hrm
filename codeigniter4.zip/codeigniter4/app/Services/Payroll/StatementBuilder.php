<?php

namespace App\Services\Payroll;

/**
 * Turns database rows into the document description that StatementPdfGenerator prints.
 * Pure functions (no database, no request) so they can be tested on their own.
 */
class StatementBuilder
{
    /**
     * @param array<int,array<string,mixed>> $items payroll_items rows joined with payrolls.payroll_month
     */
    public static function salary(array $items, int $year, string $cur): array
    {
        $rows = [];
        $t = ['basic' => 0.0, 'allow' => 0.0, 'extra' => 0.0, 'gross' => 0.0, 'ded' => 0.0, 'net' => 0.0];
        foreach ($items as $it) {
            $basic = self::f($it, 'basic_salary');
            $sumAllow = self::f($it, 'house_rent') + self::f($it, 'medical') + self::f($it, 'conveyance') + self::f($it, 'other_allowances');
            $allow = max(self::f($it, 'allowances'), $sumAllow);
            $extra = self::f($it, 'overtime_amount') + self::f($it, 'bonus_amount') + self::f($it, 'arrear_amount');
            $gross = isset($it['gross_salary']) ? self::f($it, 'gross_salary') : $basic + $allow + $extra;
            $ded   = self::deductions($it);
            $net   = isset($it['net_salary']) ? self::f($it, 'net_salary') : max(0.0, $gross - $ded);

            $rows[] = [self::month($it), self::n($basic), self::n($allow), self::n($extra), self::n($gross), self::n($ded), self::n($net)];
            $t['basic'] += $basic;
            $t['allow'] += $allow;
            $t['extra'] += $extra;
            $t['gross'] += $gross;
            $t['ded']   += $ded;
            $t['net']   += $net;
        }

        return [
            'kind'    => 'salary',
            'title'   => 'SALARY STATEMENT - ' . $year,
            'period'  => self::period($items, $year),
            'summary' => [
                'Months paid'      => (string)count($items),
                'Total gross'      => $cur . ' ' . self::n($t['gross']),
                'Total deductions' => $cur . ' ' . self::n($t['ded']),
                'Total net pay'    => $cur . ' ' . self::n($t['net']),
            ],
            'columns' => [
                ['label' => 'Month',      'w' => 70, 'align' => 'L'],
                ['label' => 'Basic',      'w' => 65, 'align' => 'R'],
                ['label' => 'Allowances', 'w' => 70, 'align' => 'R'],
                ['label' => 'OT / Bonus', 'w' => 65, 'align' => 'R'],
                ['label' => 'Gross',      'w' => 80, 'align' => 'R'],
                ['label' => 'Deductions', 'w' => 80, 'align' => 'R'],
                ['label' => 'Net pay',    'w' => 85, 'align' => 'R'],
            ],
            'rows'   => $rows,
            'totals' => $rows ? ['Total', self::n($t['basic']), self::n($t['allow']), self::n($t['extra']), self::n($t['gross']), self::n($t['ded']), self::n($t['net'])] : null,
            'note'   => 'Amounts are taken from approved and finalized payroll only. OT / Bonus includes overtime, bonus and arrears.',
        ];
    }

    public static function tax(array $items, int $year, string $cur): array
    {
        $rows = [];
        $gTot = $dTot = $tTot = $nTot = 0.0;
        foreach ($items as $it) {
            $basic = self::f($it, 'basic_salary');
            $allow = max(self::f($it, 'allowances'), self::f($it, 'house_rent') + self::f($it, 'medical') + self::f($it, 'conveyance') + self::f($it, 'other_allowances'));
            $extra = self::f($it, 'overtime_amount') + self::f($it, 'bonus_amount') + self::f($it, 'arrear_amount');
            $gross = isset($it['gross_salary']) ? self::f($it, 'gross_salary') : $basic + $allow + $extra;
            $ded   = self::deductions($it);
            $tax   = self::f($it, 'tax_deduction');
            $net   = isset($it['net_salary']) ? self::f($it, 'net_salary') : max(0.0, $gross - $ded);

            $rows[] = [self::month($it), self::n($gross), self::n($ded), self::n($tax), self::n($net)];
            $gTot += $gross;
            $dTot += $ded;
            $tTot += $tax;
            $nTot += $net;
        }
        $rate = $gTot > 0 ? round($tTot / $gTot * 100, 2) : 0.0;

        return [
            'kind'    => 'tax',
            'title'   => 'TAX STATEMENT - ' . $year,
            'period'  => self::period($items, $year),
            'summary' => [
                'Total gross income'  => $cur . ' ' . self::n($gTot),
                'Tax deducted (TDS)'  => $cur . ' ' . self::n($tTot),
                'Effective tax rate'  => number_format($rate, 2) . ' %',
            ],
            'columns' => [
                ['label' => 'Month',                  'w' => 80,  'align' => 'L'],
                ['label' => 'Gross income',           'w' => 110, 'align' => 'R'],
                ['label' => 'Total deductions',       'w' => 110, 'align' => 'R'],
                ['label' => 'Tax deducted at source', 'w' => 115, 'align' => 'R'],
                ['label' => 'Net pay',                'w' => 100, 'align' => 'R'],
            ],
            'rows'   => $rows,
            'totals' => $rows ? ['Total', self::n($gTot), self::n($dTot), self::n($tTot), self::n($nTot)] : null,
            'note'   => 'Tax is the income tax withheld by payroll in the months shown. This is a payroll summary for your records; '
                      . 'it is not a tax return or an official tax certificate.',
        ];
    }

    /**
     * @param array<int,array<string,mixed>> $ledger posted provident_fund_ledgers rows, oldest first
     */
    public static function pf(array $ledger, int $year, string $cur): array
    {
        // A posted REVERSAL cancels the row it points to; both are left out of the statement.
        $reversed = [];
        foreach ($ledger as $r) {
            if (strtoupper((string)($r['transaction_type'] ?? '')) === 'REVERSAL' && !empty($r['reversal_of_id'])) {
                $reversed[(string)$r['reversal_of_id']] = true;
            }
        }
        $live = array_values(array_filter($ledger, static function ($r) use ($reversed) {
            return strtoupper((string)($r['transaction_type'] ?? '')) !== 'REVERSAL' && !isset($reversed[(string)($r['id'] ?? '')]);
        }));

        $opening = 0.0;
        $inYear  = [];
        foreach ($live as $r) {
            $y = self::rowYear($r);
            if ($y !== null && $y < $year) {
                $opening = self::f($r, 'running_balance');
            } elseif ($y === $year) {
                $inYear[] = $r;
            }
        }

        $emp = $er = $interest = 0.0;
        $rows = [];
        if ($inYear || $opening != 0.0) {
            $rows[] = ['', 'Opening balance', '', '', '', self::n($opening)];
        }
        $closing = $opening;
        foreach ($inYear as $r) {
            $type = strtoupper((string)($r['transaction_type'] ?? ''));
            $e    = self::f($r, 'employee_contribution');
            $c    = self::f($r, 'employer_contribution');
            $tot  = isset($r['total_contribution']) ? self::f($r, 'total_contribution') : $e + $c;
            if ($type === 'CONTRIBUTION') {
                $emp += $e;
                $er  += $c;
            } elseif ($type === 'INTEREST') {
                $interest += $tot;
            }

            $label = ucwords(strtolower(str_replace('_', ' ', $type)));
            if (!empty($r['payroll_month'])) {
                $label .= ' (' . $r['payroll_month'] . ')';
            }
            $date = substr((string)($r['transaction_date'] ?? $r['created_at'] ?? ''), 0, 10);
            $closing = isset($r['running_balance']) ? self::f($r, 'running_balance') : $closing + $tot;

            $rows[] = [
                $date,
                $label,
                $type === 'CONTRIBUTION' ? self::n($e) : '',
                $type === 'CONTRIBUTION' ? self::n($c) : '',
                self::n($tot),
                self::n($closing),
            ];
        }

        return [
            'kind'    => 'pf',
            'title'   => 'PROVIDENT FUND STATEMENT - ' . $year,
            'period'  => 'Year ' . $year,
            'summary' => [
                'Opening balance'    => $cur . ' ' . self::n($opening),
                'Employee share'     => $cur . ' ' . self::n($emp),
                'Employer share'     => $cur . ' ' . self::n($er),
                'Interest'           => $cur . ' ' . self::n($interest),
                'Closing balance'    => $cur . ' ' . self::n($closing),
            ],
            'columns' => [
                ['label' => 'Date',         'w' => 62,  'align' => 'L'],
                ['label' => 'Particulars',  'w' => 118, 'align' => 'L'],
                ['label' => 'Employee',     'w' => 80,  'align' => 'R'],
                ['label' => 'Employer',     'w' => 80,  'align' => 'R'],
                ['label' => 'Amount',       'w' => 80,  'align' => 'R'],
                ['label' => 'Balance',      'w' => 95,  'align' => 'R'],
            ],
            'rows'   => $rows,
            'totals' => $inYear ? ['', 'Closing balance', self::n($emp), self::n($er), '', self::n($closing)] : null,
            'note'   => 'Only posted ledger entries are listed. Reversed entries are excluded. Interest is shown as posted by the company.',
        ];
    }

    // ------------------------------------------------------------------ helpers

    private static function deductions(array $it): float
    {
        if (isset($it['total_deductions'])) {
            return self::f($it, 'total_deductions');
        }
        return self::f($it, 'tax_deduction') + self::f($it, 'pf_deduction') + self::f($it, 'arrear_pf_deduction')
            + self::f($it, 'loan_emi') + self::f($it, 'loan_deduction') + self::f($it, 'advance_recovery')
            + self::f($it, 'asset_recovery')
            + self::f($it, 'lop_deduction') + self::f($it, 'unpaid_leave_deduction') + self::f($it, 'late_penalty')
            + self::f($it, 'other_deductions') + self::f($it, 'deductions');
    }

    private static function f(array $row, string $key): float
    {
        return isset($row[$key]) && is_numeric($row[$key]) ? round((float)$row[$key], 2) : 0.0;
    }

    private static function n(float $v): string
    {
        return number_format(round($v, 2), 2);
    }

    private static function month(array $it): string
    {
        $m  = (string)($it['payroll_month'] ?? '');
        $ts = strtotime($m . '-01');
        return $ts ? date('M Y', $ts) : $m;
    }

    private static function period(array $items, int $year): string
    {
        if (!$items) {
            return 'Year ' . $year;
        }
        $first = self::month($items[0]);
        $last  = self::month($items[count($items) - 1]);
        return $first === $last ? $first : $first . ' - ' . $last;
    }

    private static function rowYear(array $r): ?int
    {
        foreach (['transaction_date', 'payroll_year', 'created_at'] as $k) {
            if (!empty($r[$k]) && preg_match('/^(\d{4})/', (string)$r[$k], $m)) {
                return (int)$m[1];
            }
        }
        return null;
    }
}
