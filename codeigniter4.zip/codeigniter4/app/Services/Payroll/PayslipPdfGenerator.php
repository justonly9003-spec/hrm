<?php

namespace App\Services\Payroll;

/**
 * PayslipPdfGenerator
 *
 * Generates an authentic, standards-compliant PDF 1.4 binary document for payslips
 * without requiring third-party composer dependencies (Dompdf/TCPDF).
 *
 * Document specifications:
 * - PDF 1.4 binary vector format
 * - MediaBox: Standard A4 (595.28 x 841.89 points)
 * - Standard Type 1 Typefaces: Helvetica, Helvetica-Bold
 * - Explicit allow-list for earnings and deduction components
 * - Zero HTML tags under application/pdf
 */
class PayslipPdfGenerator
{
    /**
     * Generate complete binary PDF string for a payslip record.
     *
     * @param array $item Payroll item record from database
     * @param array $employee Employee master record
     * @param array $company Company master record
     * @param array|null $componentsBreakdown Allow-listed components
     * @return string Valid %PDF-1.4 binary content
     */
    public function generate(array $item, array $employee, array $company, ?array $componentsBreakdown = null): string
    {
        $companyName = !empty($company['name']) ? (string)$company['name'] : '';
        $companyAddress = !empty($company['address']) ? (string)$company['address'] : '';
        $companyContact = trim(($company['email'] ?? '') . (!empty($company['email']) && !empty($company['phone']) ? ' | ' : '') . ($company['phone'] ?? ''));

        $firstName = trim((string)($employee['first_name'] ?? ''));
        $lastName  = trim((string)($employee['last_name'] ?? ''));
        $empName   = trim("{$firstName} {$lastName}") ?: 'Employee';
        $empCode   = (string)($employee['employee_code'] ?? 'N/A');
        $dept      = (string)($employee['department_name'] ?? ($employee['department'] ?? 'General'));
        $desig     = (string)($employee['designation_name'] ?? ($employee['designation'] ?? 'Staff'));
        $branch    = (string)($employee['branch_name'] ?? ($employee['branch'] ?? 'Main Office'));
        $joinDate  = !empty($employee['joining_date']) ? substr((string)$employee['joining_date'], 0, 10) : 'N/A';

        $monthStr = (string)($item['payroll_month'] ?? date('Y-m'));
        $currency = !empty($company['currency']) ? (string)$company['currency'] : app_currency_code($item['company_id'] ?? null);

        $basic    = round((float)($item['basic_salary'] ?? 0.0), 2);
        $hra      = round((float)($item['house_rent'] ?? 0.0), 2);
        $medical  = round((float)($item['medical'] ?? 0.0), 2);
        $conv     = round((float)($item['conveyance'] ?? 0.0), 2);
        $allow    = round((float)($item['allowances'] ?? 0.0) + (float)($item['other_allowances'] ?? 0.0), 2);
        $ot       = round((float)($item['overtime_amount'] ?? 0.0), 2);
        $bonus    = round((float)($item['bonus_amount'] ?? 0.0), 2);
        $arrears  = round((float)($item['arrear_amount'] ?? 0.0), 2);
        $gross    = round((float)($item['gross_salary'] ?? ($basic + $hra + $medical + $conv + $allow + $ot + $bonus + $arrears)), 2);

        $tax      = round((float)($item['tax_deduction'] ?? 0.0), 2);
        $pf       = round((float)($item['pf_deduction'] ?? 0.0) + (float)($item['arrear_pf_deduction'] ?? 0.0), 2);
        $loan     = round((float)($item['loan_emi'] ?? 0.0) + (float)($item['loan_deduction'] ?? 0.0), 2);
        $adv      = round((float)($item['advance_recovery'] ?? 0.0), 2);
        $assetRec = round((float)($item['asset_recovery'] ?? 0.0), 2);
        $lop      = round((float)($item['lop_deduction'] ?? 0.0) + (float)($item['unpaid_leave_deduction'] ?? 0.0) + (float)($item['late_penalty'] ?? 0.0), 2);
        $otherDed = round((float)($item['other_deductions'] ?? 0.0) + (float)($item['deductions'] ?? 0.0), 2);
        $totDed   = round((float)($item['total_deductions'] ?? ($tax + $pf + $loan + $adv + $assetRec + $lop + $otherDed)), 2);

        $net      = round((float)($item['net_salary'] ?? max(0, $gross - $totDed)), 2);

        $batchSt  = strtolower(trim((string)($item['batch_status'] ?? '')));
        $itemSt   = strtolower(trim((string)($item['payment_status'] ?? '')));
        $isPaid   = in_array($batchSt, ['paid', 'disbursed'], true) || in_array($itemSt, ['paid', 'disbursed'], true);
        $statusLabel = $isPaid ? 'PAID' : (!empty($item['batch_is_locked']) ? 'FINALIZED' : 'APPROVED');

        // Build PDF graphics and text stream
        $s = [];

        // 1. Header Banner Box
        // Dark slate background: #0f172a (0.06, 0.09, 0.16)
        $s[] = "0.06 0.09 0.16 rg";
        $s[] = "40 730 515 80 re f";

        // Company Name
        $s[] = "1 1 1 rg";
        $s[] = "BT /F2 16 Tf 55 780 Td (" . $this->pdfEscape($companyName) . ") Tj ET";

        // Subtitle & Address
        $s[] = "0.85 0.90 0.95 rg";
        $s[] = "BT /F1 9 Tf 55 765 Td (" . $this->pdfEscape($companyAddress) . ") Tj ET";
        if (!empty($companyContact)) {
            $s[] = "BT /F1 8 Tf 55 750 Td (" . $this->pdfEscape($companyContact) . ") Tj ET";
        }

        // Payslip Month Badge (Right side of banner)
        $s[] = "0.15 0.23 0.35 rg";
        $s[] = "395 745 145 50 re f";
        $s[] = "1 1 1 rg";
        $s[] = "BT /F2 10 Tf 405 775 Td (SALARY STATEMENT) Tj ET";
        $s[] = "0.38 0.75 0.95 rg";
        $s[] = "BT /F2 12 Tf 405 755 Td (" . $this->pdfEscape(strtoupper(date('F Y', strtotime("{$monthStr}-01")))) . ") Tj ET";

        // 2. Employee Details Card
        // Background: #f8fafc (0.97, 0.98, 0.99), Border: #e2e8f0 (0.88, 0.91, 0.94)
        $s[] = "0.97 0.98 0.99 rg";
        $s[] = "0.88 0.91 0.94 RG 1 w";
        $s[] = "40 635 515 80 re B";

        // Col 1: Employee Name, Code, Department
        $s[] = "0.40 0.45 0.50 rg";
        $s[] = "BT /F1 9 Tf 55 695 Td (Employee Name:) Tj ET";
        $s[] = "0.10 0.15 0.20 rg";
        $s[] = "BT /F2 10 Tf 140 695 Td (" . $this->pdfEscape($empName) . ") Tj ET";

        $s[] = "0.40 0.45 0.50 rg";
        $s[] = "BT /F1 9 Tf 55 675 Td (Employee Code:) Tj ET";
        $s[] = "0.10 0.15 0.20 rg";
        $s[] = "BT /F2 9 Tf 140 675 Td (" . $this->pdfEscape($empCode) . ") Tj ET";

        $s[] = "0.40 0.45 0.50 rg";
        $s[] = "BT /F1 9 Tf 55 655 Td (Department:) Tj ET";
        $s[] = "0.10 0.15 0.20 rg";
        $s[] = "BT /F1 9 Tf 140 655 Td (" . $this->pdfEscape($dept) . ") Tj ET";

        // Col 2: Designation, Branch, Joining Date
        $s[] = "0.40 0.45 0.50 rg";
        $s[] = "BT /F1 9 Tf 320 695 Td (Designation:) Tj ET";
        $s[] = "0.10 0.15 0.20 rg";
        $s[] = "BT /F1 9 Tf 395 695 Td (" . $this->pdfEscape($desig) . ") Tj ET";

        $s[] = "0.40 0.45 0.50 rg";
        $s[] = "BT /F1 9 Tf 320 675 Td (Branch:) Tj ET";
        $s[] = "0.10 0.15 0.20 rg";
        $s[] = "BT /F1 9 Tf 395 675 Td (" . $this->pdfEscape($branch) . ") Tj ET";

        $s[] = "0.40 0.45 0.50 rg";
        $s[] = "BT /F1 9 Tf 320 655 Td (Joining Date:) Tj ET";
        $s[] = "0.10 0.15 0.20 rg";
        $s[] = "BT /F1 9 Tf 395 655 Td (" . $this->pdfEscape($joinDate) . ") Tj ET";

        // 3. Compensation Breakdown Table (Earnings vs Deductions)
        // Table Headers
        // Earnings Header: #f1f5f9 (0.94, 0.96, 0.98)
        $s[] = "0.94 0.96 0.98 rg";
        $s[] = "40 600 250 22 re f";
        $s[] = "0.10 0.15 0.25 rg";
        $s[] = "BT /F2 10 Tf 50 607 Td (EARNINGS) Tj ET";
        $s[] = "BT /F2 10 Tf 225 607 Td (AMOUNT (" . $this->pdfEscape($currency) . ")) Tj ET";

        // Deductions Header: #f1f5f9
        $s[] = "0.94 0.96 0.98 rg";
        $s[] = "305 600 250 22 re f";
        $s[] = "0.10 0.15 0.25 rg";
        $s[] = "BT /F2 10 Tf 315 607 Td (DEDUCTIONS) Tj ET";
        $s[] = "BT /F2 10 Tf 490 607 Td (AMOUNT (" . $this->pdfEscape($currency) . ")) Tj ET";

        // Prepare line items
        $earningsRows = [
            ['Basic Salary', $basic],
            ['House Rent Allowance (HRA)', $hra],
            ['Medical Allowance', $medical],
            ['Conveyance Allowance', $conv],
            ['Other Allowances', $allow],
            ['Overtime Earnings', $ot],
            ['Bonus / Incentives', $bonus],
            ['Arrears', $arrears],
        ];

        $deductionsRows = [
            ['Income Tax (TDS)', $tax],
            ['Provident Fund (PF)', $pf],
            ['Loan / EMI Repayment', $loan],
            ['Advance Salary Recovery', $adv],
            ['LOP / Unpaid Leave Penalty', $lop],
            ['Other Deductions', $otherDed],
        ];

        // Draw items
        $rowY = 582;
        $maxRows = max(count($earningsRows), count($deductionsRows));

        for ($i = 0; $i < $maxRows; $i++) {
            // Light alternating zebra stripe
            if ($i % 2 === 1) {
                $s[] = "0.98 0.99 1.00 rg";
                $s[] = "40 " . ($rowY - 4) . " 250 16 re f";
                $s[] = "305 " . ($rowY - 4) . " 250 16 re f";
            }

            // Left (Earnings)
            if (isset($earningsRows[$i])) {
                $eName = $earningsRows[$i][0];
                $eAmt  = number_format($earningsRows[$i][1], 2);
                $s[] = "0.20 0.25 0.30 rg";
                $s[] = "BT /F1 9 Tf 50 {$rowY} Td (" . $this->pdfEscape($eName) . ") Tj ET";
                $s[] = "BT /F1 9 Tf 240 {$rowY} Td (" . $this->pdfEscape($eAmt) . ") Tj ET";
            }

            // Right (Deductions)
            if (isset($deductionsRows[$i])) {
                $dName = $deductionsRows[$i][0];
                $dAmt  = number_format($deductionsRows[$i][1], 2);
                $s[] = "0.20 0.25 0.30 rg";
                $s[] = "BT /F1 9 Tf 315 {$rowY} Td (" . $this->pdfEscape($dName) . ") Tj ET";
                $s[] = "BT /F1 9 Tf 505 {$rowY} Td (" . $this->pdfEscape($dAmt) . ") Tj ET";
            }

            $rowY -= 17;
        }

        // 4. Totals Bar
        $totY = $rowY - 8;
        $s[] = "0.90 0.93 0.96 rg";
        $s[] = "40 " . ($totY - 5) . " 250 24 re f";
        $s[] = "305 " . ($totY - 5) . " 250 24 re f";

        // Gross total
        $s[] = "0.08 0.12 0.20 rg";
        $s[] = "BT /F2 10 Tf 50 {$totY} Td (TOTAL GROSS SALARY) Tj ET";
        $s[] = "BT /F2 10 Tf 220 {$totY} Td (" . $this->pdfEscape(number_format($gross, 2)) . ") Tj ET";

        // Deductions total
        $s[] = "0.08 0.12 0.20 rg";
        $s[] = "BT /F2 10 Tf 315 {$totY} Td (TOTAL DEDUCTIONS) Tj ET";
        $s[] = "BT /F2 10 Tf 485 {$totY} Td (" . $this->pdfEscape(number_format($totDed, 2)) . ") Tj ET";

        // 5. Net Salary Highlight Card
        $netY = $totY - 65;
        // Background: #f0fdf4 (0.94, 0.99, 0.96), Border: #16a34a (0.09, 0.64, 0.29)
        $s[] = "0.94 0.99 0.96 rg";
        $s[] = "0.09 0.64 0.29 RG 1.5 w";
        $s[] = "40 {$netY} 515 50 re B";

        $s[] = "0.15 0.35 0.20 rg";
        $s[] = "BT /F2 10 Tf 55 " . ($netY + 28) . " Td (NET SALARY DISBURSEMENT) Tj ET";
        $s[] = "0.40 0.50 0.45 rg";
        $s[] = "BT /F1 8 Tf 55 " . ($netY + 12) . " Td (Total amount payable for the period {$monthStr}) Tj ET";

        // Amount Display
        $netStr = "{$currency} " . number_format($net, 2);
        $s[] = "0.06 0.45 0.20 rg";
        $s[] = "BT /F2 16 Tf 340 " . ($netY + 20) . " Td (" . $this->pdfEscape($netStr) . ") Tj ET";

        // Status Badge
        $badgeColor = $isPaid ? "0.08 0.55 0.25 rg" : "0.75 0.45 0.10 rg";
        $s[] = $badgeColor;
        $s[] = "BT /F2 9 Tf 465 " . ($netY + 22) . " Td ([" . $statusLabel . "]) Tj ET";

        // 6. Security & Verification Section
        $docHash = hash('sha256', ($item['id'] ?? '') . '|' . $empCode . '|' . $net . '|' . $monthStr);
        $shortHash = substr($docHash, 0, 16) . '...' . substr($docHash, -8);
        $genTime = date('Y-m-d H:i:s T');

        $s[] = "0.88 0.91 0.94 RG 0.5 w";
        $s[] = "40 " . ($netY - 20) . " 515 0.5 re S";

        $s[] = "0.45 0.50 0.55 rg";
        $s[] = "BT /F1 8 Tf 40 " . ($netY - 35) . " Td (System Verification Signature: SHA256: " . $this->pdfEscape($shortHash) . ") Tj ET";
        $s[] = "BT /F1 8 Tf 40 " . ($netY - 48) . " Td (Generated On: " . $this->pdfEscape($genTime) . " | Source: Mobile ESS Secure API) Tj ET";
        $s[] = "BT /F1 8 Tf 40 " . ($netY - 61) . " Td (This is an official computer-generated document. No signature is required. Confidential.) Tj ET";

        $contentStream = implode("\n", $s);

        // Build valid PDF 1.4 object catalog and cross-reference table
        $objects = [];
        $objects[1] = "<< /Type /Catalog /Pages 2 0 R >>";
        $objects[2] = "<< /Type /Pages /Kids [3 0 R] /Count 1 >>";
        $objects[3] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Contents 6 0 R /Resources << /Font << /F1 4 0 R /F2 5 0 R >> /ProcSet [/PDF /Text] >> >>";
        $objects[4] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>";
        $objects[5] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>";
        $objects[6] = "<< /Length " . strlen($contentStream) . " >>\nstream\n" . $contentStream . "\nendstream";
        $objects[7] = "<< /Title (" . $this->pdfEscape("Official Payslip - {$empName} - {$monthStr}") . ") /Author (" . $this->pdfEscape($companyName) . ") /Creator (Enterprise HRMS Mobile API) /CreationDate (D:" . date('YmdHis') . ") >>";

        $out = "%PDF-1.4\n%\xe2\xe3\xcf\xd3\n";
        $offsets = [];

        for ($i = 1; $i <= 7; $i++) {
            $offsets[$i] = strlen($out);
            $out .= "{$i} 0 obj\n" . $objects[$i] . "\nendobj\n";
        }

        $xrefOffset = strlen($out);
        $out .= "xref\n";
        $out .= "0 8\n";
        $out .= "0000000000 65535 f \n";
        for ($i = 1; $i <= 7; $i++) {
            $out .= sprintf("%010d 00000 n \n", $offsets[$i]);
        }

        $out .= "trailer\n";
        $out .= "<< /Size 8 /Root 1 0 R /Info 7 0 R >>\n";
        $out .= "startxref\n";
        $out .= "{$xrefOffset}\n";
        $out .= "%%EOF\n";

        return $out;
    }

    /**
     * Escape strings for PDF text literal syntax (parenthesized).
     */
    private function pdfEscape(string $str): string
    {
        $str = str_replace('\\', '\\\\', $str);
        $str = str_replace('(', '\\(', $str);
        $str = str_replace(')', '\\)', $str);
        return preg_replace('/[\r\n\t]+/', ' ', $str);
    }
}
