<?php

namespace App\Services;

use Config\Database;
use App\Services\Concerns\JoinsActiveSalary;

/**
 * Class OvertimeBonusReportService
 *
 * Enterprise Multi-Tenant Overtime & Bonus Operations Reporting Engine.
 * Implements all 9 architectural Overtime & Bonus reports:
 * 1. monthly_overtime_summary
 * 2. department_overtime
 * 3. ot_application_register
 * 4. pending_ot_approval
 * 5. ot_rate_amount
 * 6. ot_reconciliation
 * 7. double_counted_ot_exception
 * 8. bonus_register
 * 9. bonus_approval_payment
 *
 * Strict tenant isolation enforced on every query.
 */
class OvertimeBonusReportService
{
    use JoinsActiveSalary;

    protected $db;

    public function __construct()
    {
        $this->db = Database::connect();
    }

    /**
     * Complete Catalog of the 9 Overtime & Bonus Reports
     */
    public static function getReportCatalog(): array
    {
        return [
            'monthly_overtime_summary' => [
                'number'      => 60,
                'code'        => 'monthly_overtime_summary',
                'title'       => 'Monthly Overtime Summary',
                'description' => 'Employee-level aggregation of early arrival, post-shift, holiday OT hours, and total payable amounts',
                'category'    => 'Overtime & Bonus Operations',
            ],
            'department_overtime' => [
                'number'      => 61,
                'code'        => 'department_overtime',
                'title'       => 'Departmental Overtime Analytics',
                'description' => 'Departmental distribution of overtime utilization, workforce density, and overtime cost ratio',
                'category'    => 'Overtime & Bonus Operations',
            ],
            'ot_application_register' => [
                'number'      => 62,
                'code'        => 'ot_application_register',
                'title'       => 'Overtime Application & Claim Register',
                'description' => 'Detailed log of employee overtime pre-approvals and claims with justification and review history',
                'category'    => 'Overtime & Bonus Operations',
            ],
            'pending_ot_approval' => [
                'number'      => 63,
                'code'        => 'pending_ot_approval',
                'title'       => 'Pending Overtime Approvals',
                'description' => 'Overtime records and claims awaiting managerial review with aging analysis and estimated liability',
                'category'    => 'Overtime & Bonus Operations',
            ],
            'ot_rate_amount' => [
                'number'      => 64,
                'code'        => 'ot_rate_amount',
                'title'       => 'Overtime Rate & Calculation Audit',
                'description' => 'Audit of hourly wage formulas, statutory multipliers (1.5x/2.0x/2.5x), and computed overtime rates',
                'category'    => 'Overtime & Bonus Operations',
            ],
            'ot_reconciliation' => [
                'number'      => 65,
                'code'        => 'ot_reconciliation',
                'title'       => 'Three-Way Overtime Reconciliation',
                'description' => 'Attendance raw OT vs Manager approved OT vs Payroll paid OT comparison highlighting unapproved or unpaid gaps',
                'category'    => 'Overtime & Bonus Operations',
            ],
            'double_counted_ot_exception' => [
                'number'      => 66,
                'code'        => 'double_counted_ot_exception',
                'title'       => 'Double-Counted & Overlapping OT Exceptions',
                'description' => 'Integrity audit detecting duplicate records, overlapping claim hours, and early closure double counting',
                'category'    => 'Overtime & Bonus Operations',
            ],
            'bonus_register' => [
                'number'      => 67,
                'code'        => 'bonus_register',
                'title'       => 'Bonus Master Disbursement Register',
                'description' => 'Comprehensive register of festival, performance, and attendance bonuses with prorated formulas',
                'category'    => 'Overtime & Bonus Operations',
            ],
                        'daily_overtime' => [
                'number'      => 69,
                'code'        => 'daily_overtime',
                'title'       => 'Daily Overtime Operational Register',
                'description' => 'Detailed date-wise overtime records with early arrival, post-shift, holiday breakdowns, multipliers, and settlement status',
                'category'    => 'Overtime & Bonus Operations',
            ],
            'weekly_overtime' => [
                'number'      => 70,
                'code'        => 'weekly_overtime',
                'title'       => 'Weekly Overtime Distribution Report',
                'description' => 'Weekly employee overtime distribution separating regular shift OT from weekend and public holiday OT',
                'category'    => 'Overtime & Bonus Operations',
            ],
            'bonus_approval_payment' => [
                'number'      => 68,
                'code'        => 'bonus_approval_payment',
                'title'       => 'Bonus Approval & Payroll Settlement Tracker',
                'description' => 'Workflow tracking of bonus approvals, payroll settlement linkage, and payment disbursement states',
                'category'    => 'Overtime & Bonus Operations',
            ],
        ];
    }

    /**
     * Dispatch report generation by code
     */
    public function generateReport(string $code, string $companyId, array $filters = []): array
    {
        if (trim($companyId) === '') {
            throw new \InvalidArgumentException('OvertimeBonusReportService: $companyId is required and cannot be empty.');
        }

        $normalized = strtolower(trim($code));

        switch ($normalized) {
            case 'monthly_overtime_summary':
            case 'monthly_ot_summary':
            case '60':
                return $this->monthlyOvertimeSummary($companyId, $filters);

            case 'department_overtime':
            case 'dept_overtime':
            case '61':
                return $this->departmentOvertime($companyId, $filters);

            case 'ot_application_register':
            case 'ot_claims_register':
            case '62':
                return $this->otApplicationRegister($companyId, $filters);

            case 'pending_ot_approval':
            case 'pending_ot':
            case '63':
                return $this->pendingOtApproval($companyId, $filters);

            case 'ot_rate_amount':
            case 'ot_rates':
            case '64':
                return $this->otRateAmount($companyId, $filters);

            case 'ot_reconciliation':
            case 'overtime_reconciliation':
            case '65':
                return $this->otReconciliation($companyId, $filters);

            case 'double_counted_ot_exception':
            case 'ot_duplicate_exception':
            case '66':
                return $this->doubleCountedOtException($companyId, $filters);

            case 'bonus_register':
            case '67':
                return $this->bonusRegister($companyId, $filters);

            case 'daily_overtime':
            case 'daily_ot':
            case '69':
                return $this->dailyOvertime($companyId, $filters);
            case 'weekly_overtime':
            case 'weekly_ot':
            case '70':
                return $this->weeklyOvertime($companyId, $filters);
            case 'bonus_approval_payment':
            case 'bonus_payment_tracker':
            case '68':
                return $this->bonusApprovalPayment($companyId, $filters);

            default:
                throw new \InvalidArgumentException("OvertimeBonusReportService: Unknown report code '{$code}'.");
        }
    }

    /**
     * 1. Monthly Overtime Summary
     */
    public function monthlyOvertimeSummary(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Month', 'Employee Code', 'Employee Name', 'Department',
            'Early Arrival (Hrs)', 'Post-Shift (Hrs)', 'Holiday/Weekend (Hrs)', 'Total OT Hours', 'Total OT Minutes',
            'Avg Hourly Rate', 'Total Overtime Amount', 'Status'
        ];

        $from = $filters['from'] ?? date('Y-m-01');
        $to = $filters['to'] ?? date('Y-m-d');
        if (!empty($filters['payroll_month'])) {
            $from = $filters['payroll_month'] . '-01';
            $to = date('Y-m-t', strtotime($from));
        }

        $builder = $this->db->table('overtime_records otr')
            ->select("otr.employee_id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name,
                SUM(CASE WHEN otr.ot_type = 'Early Arrival' THEN otr.overtime_hours ELSE 0 END) as early_hours,
                SUM(CASE WHEN otr.ot_type = 'Post-Shift' OR otr.ot_type = 'Normal' THEN otr.overtime_hours ELSE 0 END) as post_hours,
                SUM(CASE WHEN otr.ot_type IN ('Holiday', 'Weekly Off', 'Special') THEN otr.overtime_hours ELSE 0 END) as holiday_hours,
                SUM(otr.overtime_hours) as total_ot_hours,
                SUM(COALESCE(otr.payable_total_minutes, ROUND(otr.overtime_hours * 60))) as total_ot_minutes,
                AVG(otr.ot_rate) as avg_rate,
                SUM(otr.ot_amount) as total_ot_amount,
                MAX(otr.approval_status) as last_status")
            ->join('employees e', 'e.id = otr.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->where('otr.date >=', $from)
            ->where('otr.date <=', $to)
            ->groupBy('otr.employee_id, e.employee_code, e.first_name, e.last_name, d.name');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $records = $builder->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $totalEarly = 0.0;
        $totalPost = 0.0;
        $totalHoli = 0.0;
        $totalHours = 0.0;
        $totalMinutes = 0;
        $totalAmount = 0.0;

        foreach ($records as $r) {
            $early = (float)($r['early_hours'] ?? 0.0);
            $post = (float)($r['post_hours'] ?? 0.0);
            $holi = (float)($r['holiday_hours'] ?? 0.0);
            $hours = (float)($r['total_ot_hours'] ?? 0.0);
            $minutes = (int)($r['total_ot_minutes'] ?? round($hours * 60));
            $rate = (float)($r['avg_rate'] ?? 0.0);
            $amt = (float)($r['total_ot_amount'] ?? 0.0);

            $totalEarly += $early;
            $totalPost += $post;
            $totalHoli += $holi;
            $totalHours += $hours;
            $totalMinutes += $minutes;
            $totalAmount += $amt;

            $rows[] = [
                $sl++,
                date('Y-m', strtotime($from)),
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                number_format($early, 1),
                number_format($post, 1),
                number_format($holi, 1),
                number_format($hours, 1),
                $minutes,
                number_format($rate, 2),
                number_format($amt, 2),
                ucfirst(strtolower($r['last_status'] ?? 'Approved'))
            ];
        }

        // Grand Total row
        $count = count($records);
        $rows[] = [
            'TOTAL',
            date('Y-m', strtotime($from)),
            'Grand Total',
            "Count: {$count}",
            '-',
            number_format($totalEarly, 1),
            number_format($totalPost, 1),
            number_format($totalHoli, 1),
            number_format($totalHours, 1),
            $totalMinutes,
            '-',
            number_format($totalAmount, 2),
            '-'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count'    => $count,
                'total_ot_hours'  => $totalHours,
                'total_ot_amount' => $totalAmount
            ],
            'exceptions' => []
        ];
    }

    /**
     * 2. Departmental Overtime Analytics
     */
    public function departmentOvertime(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Department Name', 'Employees with OT', 'Total OT Hours',
            'Average OT (Hrs/Emp)', 'Total OT Expenditure', 'Department Basic Payroll', 'OT % of Payroll'
        ];

        $from = $filters['from'] ?? date('Y-m-01');
        $to = $filters['to'] ?? date('Y-m-d');
        if (!empty($filters['payroll_month'])) {
            $from = $filters['payroll_month'] . '-01';
            $to = date('Y-m-t', strtotime($from));
        }

        $salJoin = $this->getActiveSalaryJoin('e', 'es');
        $builder = $this->db->table('departments d')
            ->select("d.id, d.name as department_name,
                COUNT(DISTINCT otr.employee_id) as emp_count,
                SUM(COALESCE(otr.overtime_hours, 0)) as total_hours,
                SUM(COALESCE(otr.ot_amount, 0)) as total_amount,
                SUM(COALESCE(es.basic_salary, e.basic_salary, 0)) as dept_basic")
            ->join('employees e', 'e.department_id = d.id AND e.deleted_at IS NULL', 'left')
            ->join('employee_salaries es', $salJoin, 'left')
            ->join('overtime_records otr', 'otr.employee_id = e.id AND otr.date >= ' . $this->db->escape($from) . ' AND otr.date <= ' . $this->db->escape($to), 'left')
            ->where('d.company_id', $companyId)
            ->groupBy('d.id, d.name');

        $records = $builder->orderBy('total_amount', 'DESC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $grandEmps = 0;
        $grandHours = 0.0;
        $grandAmount = 0.0;
        $grandPayroll = 0.0;

        foreach ($records as $r) {
            $emps = (int)($r['emp_count'] ?? 0);
            $hours = (float)($r['total_hours'] ?? 0.0);
            $amount = (float)($r['total_amount'] ?? 0.0);
            $basic = (float)($r['dept_basic'] ?? 0.0);
            $avg = ($emps > 0) ? round($hours / $emps, 1) : 0.0;
            $ratio = ($basic > 0) ? round(($amount / $basic) * 100, 1) : 0.0;

            $grandEmps += $emps;
            $grandHours += $hours;
            $grandAmount += $amount;
            $grandPayroll += $basic;

            $rows[] = [
                $sl++,
                $r['department_name'] ?? 'General',
                $emps,
                number_format($hours, 1),
                number_format($avg, 1),
                number_format($amount, 2),
                number_format($basic, 2),
                $ratio . '%'
            ];
        }

        // Grand Total row
        $count = count($records);
        $overallRatio = ($grandPayroll > 0) ? round(($grandAmount / $grandPayroll) * 100, 1) : 0.0;
        $rows[] = [
            'TOTAL',
            'Grand Total',
            $grandEmps,
            number_format($grandHours, 1),
            '-',
            number_format($grandAmount, 2),
            number_format($grandPayroll, 2),
            $overallRatio . '%'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'department_count' => $count,
                'total_ot_hours'   => $grandHours,
                'total_ot_cost'    => $grandAmount
            ],
            'exceptions' => []
        ];
    }

    /**
     * 3. Overtime Application & Claim Register
     */
    public function otApplicationRegister(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Claim ID', 'Claim Date', 'Employee Code', 'Employee Name', 'Department',
            'OT Type', 'Requested Hours', 'Approved Hours', 'Reason', 'Status', 'Reviewed By'
        ];

        $from = $filters['from'] ?? date('Y-m-01');
        $to = $filters['to'] ?? date('Y-m-d');

        $builder = $this->db->table('overtime_claims otc')
            ->select("otc.id, otc.date, otc.ot_type, otc.requested_hours, otc.approved_hours, otc.reason, otc.status, otc.reviewed_by, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name")
            ->join('employees e', 'e.id = otc.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->where('otc.date >=', $from)
            ->where('otc.date <=', $to);

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');

        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $builder->where('LOWER(otc.status)', strtolower($filters['status']));
        }

        $records = $builder->orderBy('otc.date', 'DESC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $totalReq = 0.0;
        $totalApp = 0.0;

        foreach ($records as $r) {
            $req = (float)($r['requested_hours'] ?? 0.0);
            $app = (float)($r['approved_hours'] ?? $req);

            $totalReq += $req;
            $totalApp += $app;

            $rows[] = [
                $sl++,
                $r['id'] ?? '-',
                $r['date'] ?? '-',
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                $r['ot_type'] ?? 'Post-Shift',
                number_format($req, 1),
                number_format($app, 1),
                $r['reason'] ?? '-',
                ucfirst(strtolower($r['status'] ?? 'pending')),
                $r['reviewed_by'] ?: 'Pending Review'
            ];
        }

        // Grand Total row
        $count = count($records);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Count: {$count}",
            '-',
            '-',
            '-',
            '-',
            number_format($totalReq, 1),
            number_format($totalApp, 1),
            '-',
            '-',
            '-'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count'    => $count,
                'requested_hours' => $totalReq,
                'approved_hours'  => $totalApp
            ],
            'exceptions' => []
        ];
    }

    /**
     * 4. Pending Overtime Approvals
     */
    public function pendingOtApproval(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Record ID', 'OT Date', 'Employee Code', 'Employee Name', 'Department',
            'OT Type', 'Pending Hours', 'Pending Minutes', 'Hourly Rate', 'Estimated Amount', 'Days Pending', 'Status'
        ];

        $builder = $this->db->table('overtime_records otr')
            ->select("otr.id, otr.date, otr.ot_type, otr.overtime_hours, otr.payable_total_minutes, otr.ot_rate, otr.ot_amount, otr.approval_status, otr.created_at, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name")
            ->join('employees e', 'e.id = otr.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->where('otr.approval_status', 'Pending');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $records = $builder->orderBy('otr.date', 'ASC')->get()->getResultArray();

        $rows = [];
        $exceptions = [];
        $sl = 1;
        $totalHours = 0.0;
        $totalMinutes = 0;
        $totalAmount = 0.0;

        foreach ($records as $r) {
            $hours = (float)($r['overtime_hours'] ?? 0.0);
            $minutes = (int)($r['payable_total_minutes'] ?? round($hours * 60));
            $rate = (float)($r['ot_rate'] ?? 0.0);
            $amount = (float)($r['ot_amount'] ?? ($hours * $rate));

            $dateTs = !empty($r['date']) ? strtotime($r['date']) : time();
            $daysPending = max(0, (int)floor((time() - $dateTs) / 86400));

            $totalHours += $hours;
            $totalMinutes += $minutes;
            $totalAmount += $amount;

            if ($daysPending > 7) {
                $exceptions[] = [
                    'employee_code' => $r['employee_code'],
                    'name'          => $r['employee_name'],
                    'issue'         => "Pending OT approval exceeds 7 days ({$daysPending} days)"
                ];
            }

            $rows[] = [
                $sl++,
                $r['id'] ?? '-',
                $r['date'] ?? '-',
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                $r['ot_type'] ?? 'Normal',
                number_format($hours, 1),
                $minutes,
                number_format($rate, 2),
                number_format($amount, 2),
                "{$daysPending} days",
                'Pending Review'
            ];
        }

        // Grand Total row
        $count = count($records);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Pending: {$count}",
            '-',
            '-',
            '-',
            '-',
            number_format($totalHours, 1),
            $totalMinutes,
            '-',
            number_format($totalAmount, 2),
            '-',
            count($exceptions) > 0 ? (count($exceptions) . ' Aged Approvals') : 'In Queue'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'pending_count'    => $count,
                'total_hours'      => $totalHours,
                'total_minutes'    => $totalMinutes,
                'estimated_amount' => $totalAmount,
                'aged_exceptions'  => count($exceptions)
            ],
            'exceptions' => $exceptions
        ];
    }

    /**
     * 5. Overtime Rate & Calculation Audit
     */
    public function otRateAmount(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Employee Code', 'Employee Name', 'Department', 'Base Salary',
            'Divisor Formula', 'Standard Hourly Rate', 'Policy Multiplier', 'Effective OT Rate', 'Status'
        ];

        $salJoin = $this->getActiveSalaryJoin('e', 'es');
        $builder = $this->db->table('employees e')
            ->select("e.id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name, COALESCE(es.basic_salary, e.basic_salary, 0) as basic_salary, COALESCE(es.gross_salary, e.gross_salary, 0) as gross_salary")
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('employee_salaries es', $salJoin, 'left');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $employees = $builder->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

        $rows = [];
        $exceptions = [];
        $sl = 1;
        $totalBase = 0.0;
        $totalHourly = 0.0;
        $totalOtRate = 0.0;

        foreach ($employees as $emp) {
            $basic = (float)($emp['basic_salary'] ?? 0.0);
            if ($basic <= 0) {
                $exceptions[] = [
                    'employee_code' => $emp['employee_code'],
                    'name'          => $emp['employee_name'],
                    'issue'         => 'Missing basic salary for hourly OT derivation'
                ];
                $rows[] = [
                    $sl++,
                    $emp['employee_code'] ?? '-',
                    trim($emp['employee_name'] ?? 'Unknown'),
                    $emp['department_name'] ?? 'General',
                    '0.00',
                    'Basic / (30 * 8)',
                    '0.00',
                    '1.5x',
                    '0.00',
                    'EXCEPTION: No Salary'
                ];
                continue;
            }

            try {
                $otRule = \App\Services\Rules\RuleResolver::resolve($companyId, 'OVERTIME', date('Y-m-d'), $emp);
                $basicsRule = \App\Services\Rules\RuleResolver::resolveForCompany($companyId, 'PAYROLL_BASICS', date('Y-m-d'));
                $divisorDays = (float)$basicsRule->get('daily_rate_divisor');
                $divisorHours = (float)($otRule->params()['divisor_hours'] ?? $basicsRule->get('standard_daily_hours'));
                $multiplier = (float)$otRule->get('normal_multiplier');
                $hourlyRate = round($basic / ($divisorDays * $divisorHours), 2);
                $effectiveOtRate = round($hourlyRate * $multiplier, 2);
                $formulaStr = "Basic / ({$divisorDays}d * {$divisorHours}h)";
            } catch (\Throwable $e) {
                $exceptions[] = [
                    'employee_code' => $emp['employee_code'],
                    'name'          => $emp['employee_name'],
                    'issue'         => 'Overtime rule unconfigured: ' . $e->getMessage()
                ];
                $rows[] = [
                    $sl++,
                    $emp['employee_code'] ?? '-',
                    trim($emp['employee_name'] ?? 'Unknown'),
                    $emp['department_name'] ?? 'General',
                    number_format($basic, 2),
                    'Unconfigured Rule',
                    '0.00',
                    '-',
                    '0.00',
                    'EXCEPTION: Rule Missing'
                ];
                continue;
            }

            $totalBase += $basic;
            $totalHourly += $hourlyRate;
            $totalOtRate += $effectiveOtRate;

            $rows[] = [
                $sl++,
                $emp['employee_code'] ?? '-',
                trim($emp['employee_name'] ?? 'Unknown'),
                $emp['department_name'] ?? 'General',
                number_format($basic, 2),
                $formulaStr,
                number_format($hourlyRate, 2),
                number_format($multiplier, 2) . 'x',
                number_format($effectiveOtRate, 2),
                'Verified'
            ];
        }

        // Grand Total row
        $count = count($employees);
        $avgOtRate = ($count > 0) ? round($totalOtRate / $count, 2) : 0.0;
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Count: {$count}",
            '-',
            number_format($totalBase, 2),
            '-',
            '-',
            '-',
            number_format($avgOtRate, 2) . ' (avg)',
            count($exceptions) > 0 ? (count($exceptions) . ' Missing Salaries') : 'Compliant'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count'    => $count,
                'total_base'      => $totalBase,
                'avg_ot_rate'     => $avgOtRate,
                'exceptions'      => count($exceptions)
            ],
            'exceptions' => $exceptions
        ];
    }

    /**
     * 6. Three-Way Overtime Reconciliation
     */
    public function otReconciliation(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Payroll Month', 'Employee Code', 'Employee Name', 'Department',
            'Attendance Raw OT (Hrs)', 'Approved OT (Hrs)', 'Payroll Paid OT Amount',
            'Variance (Hrs)', 'Reconciliation Status', 'Remarks'
        ];

        $month = $filters['payroll_month'] ?? ($filters['month'] ?? date('Y-m'));
        $from = $month . '-01';
        $to = date('Y-m-t', strtotime($from));

        $builder = $this->db->table('employees e')
            ->select("e.id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name,
                SUM(COALESCE(a.ot_hours, 0)) as raw_att_hours,
                pi.overtime_amount as payroll_paid_amount")
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('attendances a', 'a.employee_id = e.id AND a.date >= ' . $this->db->escape($from) . ' AND a.date <= ' . $this->db->escape($to), 'left')
            ->join('payrolls p', 'p.company_id = ' . $this->db->escape($companyId) . " AND p.payroll_month = '{$month}'", 'left')
            ->join('payroll_items pi', 'pi.payroll_id = p.id AND pi.employee_id = e.id', 'left')
            ->groupBy('e.id, e.employee_code, e.first_name, e.last_name, d.name, pi.overtime_amount');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $records = $builder->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

        $rows = [];
        $exceptions = [];
        $sl = 1;
        $totalRaw = 0.0;
        $totalApp = 0.0;
        $totalPaidAmt = 0.0;

        foreach ($records as $r) {
            $rawHrs = (float)($r['raw_att_hours'] ?? 0.0);
            $paidAmt = (float)($r['payroll_paid_amount'] ?? 0.0);

            // Fetch approved OT from overtime_records
            $appQuery = $this->db->table('overtime_records')
                ->select('SUM(overtime_hours) as app_hrs')
                ->where('employee_id', $r['id'])
                ->where('date >=', $from)
                ->where('date <=', $to)
                ->where('approval_status', 'Approved')
                ->get()
                ->getRowArray();

            $appHrs = (float)($appQuery['app_hrs'] ?? 0.0);
            $varHrs = round($rawHrs - $appHrs, 1);

            if ($rawHrs <= 0 && $appHrs <= 0 && $paidAmt <= 0) {
                continue;
            }

            $totalRaw += $rawHrs;
            $totalApp += $appHrs;
            $totalPaidAmt += $paidAmt;

            $status = ($varHrs == 0) ? 'Reconciled' : (($varHrs > 0) ? 'Unapproved Raw OT' : 'Manual OT Credit');
            $remarks = ($varHrs == 0) ? 'Fully matching' : "Discrepancy of {$varHrs} hrs";

            if ($varHrs != 0) {
                $exceptions[] = [
                    'employee_code' => $r['employee_code'],
                    'name'          => $r['employee_name'],
                    'issue'         => "Overtime reconciliation gap: {$varHrs} hrs"
                ];
            }

            $rows[] = [
                $sl++,
                $month,
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                number_format($rawHrs, 1),
                number_format($appHrs, 1),
                number_format($paidAmt, 2),
                number_format($varHrs, 1),
                $status,
                $remarks
            ];
        }

        // Grand Total row
        $count = count($rows);
        $rows[] = [
            'TOTAL',
            $month,
            'Grand Total',
            "Count: {$count}",
            '-',
            number_format($totalRaw, 1),
            number_format($totalApp, 1),
            number_format($totalPaidAmt, 2),
            number_format(round($totalRaw - $totalApp, 1), 1),
            count($exceptions) > 0 ? (count($exceptions) . ' Gaps Flagged') : 'Balanced',
            '-'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'reconciled_count' => $count,
                'total_raw_hours'  => $totalRaw,
                'total_app_hours'  => $totalApp,
                'total_paid_amount'=> $totalPaidAmt,
                'exceptions'       => count($exceptions)
            ],
            'exceptions' => $exceptions
        ];
    }

    /**
     * 7. Double-Counted & Overlapping OT Exceptions
     */
    public function doubleCountedOtException(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Employee Code', 'Employee Name', 'Department', 'Date',
            'Record Count', 'Total Claimed Hours', 'Exception Reason', 'Severity', 'Recommended Action'
        ];

        $from = $filters['from'] ?? date('Y-m-01');
        $to = $filters['to'] ?? date('Y-m-d');

        // Detect duplicate records on same employee and date
        $builder = $this->db->table('overtime_records otr')
            ->select("otr.employee_id, otr.date, COUNT(otr.id) as rec_count, SUM(otr.overtime_hours) as total_hours, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name")
            ->join('employees e', 'e.id = otr.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->where('otr.date >=', $from)
            ->where('otr.date <=', $to)
            ->groupBy('otr.employee_id, otr.date, e.employee_code, e.first_name, e.last_name, d.name')
            ->having('COUNT(otr.id) > 1');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $records = $builder->get()->getResultArray();

        $rows = [];
        $exceptions = [];
        $sl = 1;

        foreach ($records as $r) {
            $recCount = (int)($r['rec_count'] ?? 0);
            $hours = (float)($r['total_hours'] ?? 0.0);

            $exceptions[] = [
                'employee_code' => $r['employee_code'],
                'name'          => $r['employee_name'],
                'date'          => $r['date'],
                'issue'         => "Multiple overtime records ({$recCount}) on the same date"
            ];

            $rows[] = [
                $sl++,
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                $r['date'] ?? '-',
                $recCount,
                number_format($hours, 1),
                'Duplicate Overtime Records on Same Shift/Date',
                'High',
                'Deduplicate records before payroll processing'
            ];
        }

        // Grand Total row
        $count = count($rows);
        $rows[] = [
            'TOTAL',
            'Grand Total Exceptions',
            "Count: {$count}",
            '-',
            '-',
            '-',
            '-',
            $count > 0 ? "{$count} Duplicates Found" : 'Integrity Verified',
            $count > 0 ? 'Requires Action' : 'Clean',
            'Audit Ledger'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'exception_count' => $count
            ],
            'exceptions' => $exceptions
        ];
    }

    /**
     * 8. Bonus Master Disbursement Register
     */
    public function bonusRegister(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Bonus ID', 'Employee Code', 'Employee Name', 'Department', 'Bonus Title',
            'Category', 'Month/Year', 'Base Salary', 'Prorated Ratio', 'Calculated Amount', 'Status'
        ];

        $builder = $this->db->table('bonus_records br')
            ->select("br.id, br.bonus_title, br.category, br.bonus_month, br.year, br.base_salary, br.prorated_ratio, br.amount, br.status, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name")
            ->join('employees e', 'e.id = br.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');

        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $builder->where('LOWER(br.status)', strtolower($filters['status']));
        }
        if (!empty($filters['year'])) {
            $builder->where('br.year', $filters['year']);
        }

        $records = $builder->orderBy('br.created_at', 'DESC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $totalBase = 0.0;
        $totalBonus = 0.0;

        foreach ($records as $r) {
            $base = (float)($r['base_salary'] ?? 0.0);
            $amount = (float)($r['amount'] ?? 0.0);
            $ratio = (float)($r['prorated_ratio'] ?? 1.0);

            $totalBase += $base;
            $totalBonus += $amount;

            $rows[] = [
                $sl++,
                $r['id'] ?? '-',
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                $r['bonus_title'] ?? 'Festival Bonus',
                $r['category'] ?? 'Festival',
                ($r['bonus_month'] ?? '') . ' ' . ($r['year'] ?? ''),
                number_format($base, 2),
                number_format($ratio * 100, 1) . '%',
                number_format($amount, 2),
                ucfirst(strtolower($r['status'] ?? 'pending'))
            ];
        }

        // Grand Total row
        $count = count($records);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Count: {$count}",
            '-',
            '-',
            '-',
            '-',
            '-',
            number_format($totalBase, 2),
            '-',
            number_format($totalBonus, 2),
            '-'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count' => $count,
                'total_base'   => $totalBase,
                'total_bonus'  => $totalBonus
            ],
            'exceptions' => []
        ];
    }

    /**
     * 9. Bonus Approval & Payroll Settlement Tracker
     */
    public function bonusApprovalPayment(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Bonus ID', 'Employee Code', 'Employee Name', 'Department', 'Bonus Title',
            'Disbursed Amount', 'Approval Status', 'Approved By', 'Payroll Settled', 'Linked Payroll ID', 'Settled At'
        ];

        $builder = $this->db->table('bonus_records br')
            ->select("br.id, br.bonus_title, br.amount, br.status, br.approved_by, br.approved_at, br.is_settled_in_payroll, br.payroll_id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name")
            ->join('employees e', 'e.id = br.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $records = $builder->orderBy('br.created_at', 'DESC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $totalDisbursed = 0.0;
        $settledCount = 0;

        foreach ($records as $r) {
            $amt = (float)($r['amount'] ?? 0.0);
            $isSettled = !empty($r['is_settled_in_payroll']);

            $totalDisbursed += $amt;
            if ($isSettled) {
                $settledCount++;
            }

            $rows[] = [
                $sl++,
                $r['id'] ?? '-',
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                $r['bonus_title'] ?? 'Festival Bonus',
                number_format($amt, 2),
                ucfirst(strtolower($r['status'] ?? 'pending')),
                $r['approved_by'] ?: 'Pending Approval',
                $isSettled ? 'Yes (Settled)' : 'No (Pending)',
                $r['payroll_id'] ?: '-',
                !empty($r['approved_at']) ? date('Y-m-d', strtotime($r['approved_at'])) : '-'
            ];
        }

        // Grand Total row
        $count = count($records);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Count: {$count}",
            '-',
            '-',
            '-',
            number_format($totalDisbursed, 2),
            '-',
            '-',
            "Settled: {$settledCount}/{$count}",
            '-',
            '-'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count'    => $count,
                'total_disbursed' => $totalDisbursed,
                'settled_count'   => $settledCount
            ],
            'exceptions' => []
        ];
    }

    /**
     * 10. Daily Overtime Operational Register
     */
    public function dailyOvertime(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Date', 'Employee Code', 'Employee Name', 'Department', 'Designation',
            'OT Type', 'Start Time', 'End Time', 'Payable Minutes', 'OT Hours',
            'Hourly Rate', 'Total Amount', 'Approval Status', 'Settled In Payroll'
        ];

        $from = $filters['from'] ?? ($filters['from_date'] ?? date('Y-m-01'));
        $to   = $filters['to'] ?? ($filters['to_date'] ?? date('Y-m-d'));
        if (!empty($filters['date'])) {
            $from = $filters['date'];
            $to   = $filters['date'];
        }

        $builder = $this->db->table('overtime_records otr')
            ->select("otr.*, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name, des.name as designation_name")
            ->join('employees e', 'e.id = otr.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('designations des', 'des.id = e.designation_id', 'left')
            ->where('otr.company_id', $companyId)
            ->where('otr.date >=', $from)
            ->where('otr.date <=', $to);

        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $builder->where('otr.approval_status', $filters['status']);
        }
        if (!empty($filters['ot_type']) && $filters['ot_type'] !== 'all') {
            $builder->where('otr.ot_type', $filters['ot_type']);
        }
        if (!empty($filters['employee_id']) && $filters['employee_id'] !== 'all') {
            $builder->where('otr.employee_id', $filters['employee_id']);
        }

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $records = $builder->orderBy('otr.date', 'DESC')->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $totalMinutes = 0;
        $totalHours = 0.0;
        $totalAmount = 0.0;
        $approvedCount = 0;

        foreach ($records as $r) {
            $hrs = (float)($r['overtime_hours'] ?? 0.0);
            $mins = (int)($r['payable_total_minutes'] ?? round($hrs * 60));
            $amt = (float)($r['ot_amount'] ?? 0.0);
            $rate = (float)($r['ot_rate'] ?? 0.0);
            $settled = !empty($r['is_settled']) ? 'Settled' : 'Pending Payroll';

            if (($r['approval_status'] ?? '') === 'Approved') {
                $approvedCount++;
            }

            $totalMinutes += $mins;
            $totalHours   += $hrs;
            $totalAmount  += $amt;

            $rows[] = [
                $sl++,
                $r['date'],
                $r['employee_code'] ?? '-',
                $r['employee_name'] ?? 'Unknown',
                $r['department_name'] ?? 'General',
                $r['designation_name'] ?? 'Staff',
                $r['ot_type'] ?? 'Normal',
                $r['start_time'] ?? '--:--',
                $r['end_time'] ?? '--:--',
                $mins,
                number_format($hrs, 2),
                number_format($rate, 2),
                number_format($amt, 2),
                $r['approval_status'] ?? 'Pending',
                $settled
            ];
        }

        $count = count($records);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Records: {$count}",
            '-',
            '-',
            '-',
            '-',
            '-',
            '-',
            $totalMinutes,
            number_format($totalHours, 2),
            '-',
            number_format($totalAmount, 2),
            "Approved: {$approvedCount}/{$count}",
            '-'
        ];

        return [
            'headers' => $headers,
            'rows'    => $rows,
            'totals'  => [
                'record_count'    => $count,
                'total_hours'     => $totalHours,
                'total_minutes'   => $totalMinutes,
                'total_amount'    => $totalAmount,
                'approved_count'  => $approvedCount,
            ],
            'exceptions' => []
        ];
    }

    /**
     * 11. Weekly Overtime Distribution Report
     */
    public function weeklyOvertime(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Week Period', 'Employee Code', 'Employee Name', 'Department',
            'Regular OT (Hrs)', 'Weekend/Off-Day OT (Hrs)', 'Holiday OT (Hrs)',
            'Total OT Hours', 'Avg Rate', 'Total Amount', 'Approval Status', 'Settled Status'
        ];

        $from = $filters['from'] ?? ($filters['from_date'] ?? date('Y-m-01'));
        $to   = $filters['to'] ?? ($filters['to_date'] ?? date('Y-m-d'));

        $builder = $this->db->table('overtime_records otr')
            ->select("CONCAT(YEAR(otr.date), '-W', LPAD(WEEK(otr.date, 1), 2, '0')) as week_label,
                      MIN(otr.date) as week_start,
                      MAX(otr.date) as week_end,
                      otr.employee_id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name,
                      SUM(CASE WHEN otr.ot_type IN ('Normal', 'Post-Shift', 'Early Arrival') THEN otr.overtime_hours ELSE 0 END) as regular_hours,
                      SUM(CASE WHEN otr.ot_type = 'Weekly Off' THEN otr.overtime_hours ELSE 0 END) as off_hours,
                      SUM(CASE WHEN otr.ot_type IN ('Holiday', 'Special') THEN otr.overtime_hours ELSE 0 END) as holiday_hours,
                      SUM(otr.overtime_hours) as total_hours,
                      AVG(otr.ot_rate) as avg_rate,
                      SUM(otr.ot_amount) as total_amount,
                      MAX(otr.approval_status) as last_status,
                      MIN(otr.is_settled) as min_settled,
                      MAX(otr.is_settled) as max_settled")
            ->join('employees e', 'e.id = otr.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->where('otr.company_id', $companyId)
            ->where('otr.date >=', $from)
            ->where('otr.date <=', $to)
            ->groupBy("CONCAT(YEAR(otr.date), '-W', LPAD(WEEK(otr.date, 1), 2, '0')), otr.employee_id, e.employee_code, e.first_name, e.last_name, d.name");

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $records = $builder->orderBy('week_start', 'DESC')->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $grandHours = 0.0;
        $grandAmount = 0.0;

        foreach ($records as $r) {
            $reg = (float)($r['regular_hours'] ?? 0.0);
            $off = (float)($r['off_hours'] ?? 0.0);
            $hol = (float)($r['holiday_hours'] ?? 0.0);
            $tot = (float)($r['total_hours'] ?? 0.0);
            $rate = (float)($r['avg_rate'] ?? 0.0);
            $amt = (float)($r['total_amount'] ?? 0.0);

            $grandHours  += $tot;
            $grandAmount += $amt;

            $settled = (!empty($r['min_settled']) && !empty($r['max_settled'])) ? 'Fully Settled' : (!empty($r['max_settled']) ? 'Partially Settled' : 'Pending Payroll');

            $weekPeriod = ($r['week_start'] ?? '') . ' to ' . ($r['week_end'] ?? '');

            $rows[] = [
                $sl++,
                $weekPeriod . ' (' . ($r['week_label'] ?? '') . ')',
                $r['employee_code'] ?? '-',
                $r['employee_name'] ?? 'Unknown',
                $r['department_name'] ?? 'General',
                number_format($reg, 2),
                number_format($off, 2),
                number_format($hol, 2),
                number_format($tot, 2),
                number_format($rate, 2),
                number_format($amt, 2),
                $r['last_status'] ?? 'Approved',
                $settled
            ];
        }

        $count = count($records);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Aggregates: {$count}",
            '-',
            '-',
            '-',
            '-',
            '-',
            number_format($grandHours, 2),
            '-',
            number_format($grandAmount, 2),
            '-',
            '-'
        ];

        return [
            'headers' => $headers,
            'rows'    => $rows,
            'totals'  => [
                'aggregate_count' => $count,
                'total_hours'     => $grandHours,
                'total_amount'    => $grandAmount,
            ],
            'exceptions' => []
        ];
    }
}
