<?php

namespace App\Services;

use Config\Database;
use App\Services\Rules\RuleResolver;
use App\Services\Rules\RuleNotConfiguredException;
use App\Services\Rules\DailyRateResolver;
use App\Services\LeaveService;

/**
 * Class LeaveReportService
 *
 * Enterprise Multi-Tenant Leave Management Reporting Engine.
 * Implements all 18 architectural Leave Management reports (#23 to #40).
 * Strict tenant isolation enforced on every query.
 */
class LeaveReportService
{
    protected $db;

    public function __construct()
    {
        $this->db = Database::connect();
    }

    /**
     * Complete Catalog of the 18 Leave Management Reports (#23 to #40)
     */
    public static function getReportCatalog(): array
    {
        return [
            'leave_application_register' => [
                'number'      => 23,
                'code'        => 'leave_application_register',
                'title'       => 'Leave Application Register',
                'description' => 'Complete register of all employee leave applications with full details',
                'category'    => 'Register & Operational',
            ],
            'pending_leave_approval' => [
                'number'      => 24,
                'code'        => 'pending_leave_approval',
                'title'       => 'Pending Leave Approval',
                'description' => 'Applications awaiting managerial or HR approval with aging analysis',
                'category'    => 'Workflow & Approvals',
            ],
            'approved_leave_report' => [
                'number'      => 25,
                'code'        => 'approved_leave_report',
                'title'       => 'Approved Leave Report',
                'description' => 'Comprehensive register of all approved leaves with duration and approver details',
                'category'    => 'Workflow & Approvals',
            ],
            'rejected_leave_report' => [
                'number'      => 26,
                'code'        => 'rejected_leave_report',
                'title'       => 'Rejected Leave Report',
                'description' => 'Audit log of rejected leave applications with formal rejection reasons',
                'category'    => 'Workflow & Approvals',
            ],
            'cancelled_leave_report' => [
                'number'      => 27,
                'code'        => 'cancelled_leave_report',
                'title'       => 'Cancelled Leave Report',
                'description' => 'Record of all cancelled leave requests, cancellation timestamps and reasons',
                'category'    => 'Workflow & Approvals',
            ],
            'employee_leave_balance' => [
                'number'      => 28,
                'code'        => 'employee_leave_balance',
                'title'       => 'Employee Leave Balance',
                'description' => 'Opening, earned, utilized, pending, and available balances across leave types',
                'category'    => 'Balances & Entitlements',
            ],
            'leave_ledger' => [
                'number'      => 29,
                'code'        => 'leave_ledger',
                'title'       => 'Leave Ledger',
                'description' => 'Granular chronological debit/credit transactions with running balance tracking',
                'category'    => 'Balances & Entitlements',
            ],
            'leave_type_summary' => [
                'number'      => 30,
                'code'        => 'leave_type_summary',
                'title'       => 'Leave Type Summary',
                'description' => 'Company-wide breakdown of leave utilization across paid and unpaid categories',
                'category'    => 'Analytics & Summary',
            ],
            'department_leave_calendar' => [
                'number'      => 31,
                'code'        => 'department_leave_calendar',
                'title'       => 'Department Leave Calendar',
                'description' => 'Departmental daily leave coverage, active absences, and staffing ratios',
                'category'    => 'Calendar & Planning',
            ],
            'branch_leave_calendar' => [
                'number'      => 32,
                'code'        => 'branch_leave_calendar',
                'title'       => 'Branch Leave Calendar',
                'description' => 'Branch-wise leave schedules, workforce availability, and absence density',
                'category'    => 'Calendar & Planning',
            ],
            'leave_encashment_report' => [
                'number'      => 33,
                'code'        => 'leave_encashment_report',
                'title'       => 'Leave Encashment Report',
                'description' => 'Monetary value calculations, encashable units, daily salary rates, and payouts',
                'category'    => 'Financial & Compensation',
            ],
            'leave_accrual_report' => [
                'number'      => 34,
                'code'        => 'leave_accrual_report',
                'title'       => 'Leave Accrual Report',
                'description' => 'Monthly and annual earned leave accrual schedule, caps, and service tenure',
                'category'    => 'Balances & Entitlements',
            ],
            'carry_forward_report' => [
                'number'      => 35,
                'code'        => 'carry_forward_report',
                'title'       => 'Carry-forward Report',
                'description' => 'Year-end carry-over audit, statutory max limits, and lapsed balance log',
                'category'    => 'Balances & Entitlements',
            ],
            'loss_of_pay_report' => [
                'number'      => 36,
                'code'        => 'loss_of_pay_report',
                'title'       => 'Loss of Pay (LOP) Report',
                'description' => 'Unpaid leaves, unapproved absences, and estimated payroll salary deductions',
                'category'    => 'Financial & Payroll Integration',
            ],
            'probation_leave_eligibility' => [
                'number'      => 37,
                'code'        => 'probation_leave_eligibility',
                'title'       => 'Probation Leave Eligibility',
                'description' => 'Probation period status, waiting restrictions, and policy entitlement audit',
                'category'    => 'Policy & Compliance',
            ],
            'leave_policy_compliance' => [
                'number'      => 38,
                'code'        => 'leave_policy_compliance',
                'title'       => 'Leave Policy Compliance',
                'description' => 'Advance notice checks, sandwich rule occurrences, and consecutive day limits',
                'category'    => 'Policy & Compliance',
            ],
            'leave_overlap_conflict' => [
                'number'      => 39,
                'code'        => 'leave_overlap_conflict',
                'title'       => 'Leave Overlap / Conflict Report',
                'description' => 'Simultaneous leave conflicts within teams, shift shortages, and risk scoring',
                'category'    => 'Risk & Operations',
            ],
            'leave_approval_history' => [
                'number'      => 40,
                'code'        => 'leave_approval_history',
                'title'       => 'Leave Approval History',
                'description' => 'Complete multi-tier approval audit trail, workflow timestamps, and turnaround time',
                'category'    => 'Audit & Governance',
            ],
        ];
    }

    /**
     * Generate report by canonical code or supported alias
     */
    public function generateReport(string $code, string $companyId, array $filters = []): array
    {
        if (trim($companyId) === '') {
            throw new \InvalidArgumentException('LeaveReportService: $companyId is required and cannot be empty.');
        }
        $normalized = strtolower(trim($code));
        if (str_starts_with($normalized, 'leave_')) {
            $alias = $normalized;
        } else {
            $alias = 'leave_' . $normalized;
        }

        switch ($normalized) {
            case 'leave_application_register':
            case 'application_register':
            case 'leave_register':
            case '23':
                return $this->leaveApplicationRegister($companyId, $filters);

            case 'pending_leave_approval':
            case 'pending_leave':
            case 'pending_leaves':
            case 'leave_pending':
            case '24':
                return $this->pendingLeaveApproval($companyId, $filters);

            case 'approved_leave_report':
            case 'approved_leave':
            case 'approved_leaves':
            case 'leave_approved':
            case '25':
                return $this->approvedLeaveReport($companyId, $filters);

            case 'rejected_leave_report':
            case 'rejected_leave':
            case 'rejected_leaves':
            case 'leave_rejected':
            case '26':
                return $this->rejectedLeaveReport($companyId, $filters);

            case 'cancelled_leave_report':
            case 'cancelled_leave':
            case 'cancelled_leaves':
            case 'leave_cancelled':
            case '27':
                return $this->cancelledLeaveReport($companyId, $filters);

            case 'employee_leave_balance':
            case 'leave_balance':
            case 'leave_balances':
            case 'balances':
            case '28':
                return $this->employeeLeaveBalance($companyId, $filters);

            case 'leave_ledger':
            case 'ledger':
            case 'leave_transactions':
            case '29':
                return $this->leaveLedger($companyId, $filters);

            case 'leave_type_summary':
            case 'type_summary':
            case 'leave_types':
            case '30':
                return $this->leaveTypeSummary($companyId, $filters);

            case 'department_leave_calendar':
            case 'dept_leave_calendar':
            case 'leave_calendar_dept':
            case '31':
                return $this->departmentLeaveCalendar($companyId, $filters);

            case 'branch_leave_calendar':
            case 'branch_calendar':
            case 'leave_calendar_branch':
            case '32':
                return $this->branchLeaveCalendar($companyId, $filters);

            case 'leave_encashment_report':
            case 'leave_encashment':
            case 'encashment':
            case 'encashments':
            case '33':
                return $this->leaveEncashmentReport($companyId, $filters);

            case 'leave_accrual_report':
            case 'leave_accrual':
            case 'accrual':
            case '34':
                return $this->leaveAccrualReport($companyId, $filters);

            case 'carry_forward_report':
            case 'carry_forward':
            case 'leave_carry_forward':
            case '35':
                return $this->carryForwardReport($companyId, $filters);

            case 'loss_of_pay_report':
            case 'loss_of_pay':
            case 'lop_report':
            case 'lop':
            case '36':
                return $this->lossOfPayReport($companyId, $filters);

            case 'probation_leave_eligibility':
            case 'probation_leave':
            case 'probation_eligibility':
            case '37':
                return $this->probationLeaveEligibility($companyId, $filters);

            case 'leave_policy_compliance':
            case 'policy_compliance':
            case 'leave_compliance':
            case '38':
                return $this->leavePolicyCompliance($companyId, $filters);

            case 'leave_overlap_conflict':
            case 'overlap_conflict':
            case 'leave_conflicts':
            case '39':
                return $this->leaveOverlapConflict($companyId, $filters);

            case 'leave_approval_history':
            case 'approval_history':
            case 'leave_history':
            case '40':
                return $this->leaveApprovalHistory($companyId, $filters);

            default:
                return $this->leaveApplicationRegister($companyId, $filters);
        }
    }

    /**
     * Resolve active applications table name and column availability
     */
    protected function getLeaveTableInfo(): array
    {
        $hasAppTable = $this->db->tableExists('leave_applications');
        $tableName = $hasAppTable ? 'leave_applications' : 'leaves';
        $rawCols = $this->db->tableExists($tableName) ? $this->db->getFieldNames($tableName) : [];
        $cols = array_map('strtolower', (array)$rawCols);

        $hasFrom = in_array('from_date', $cols, true);
        $hasStart = in_array('start_date', $cols, true);
        $fromExpr = ($hasFrom && $hasStart) ? 'COALESCE(la.from_date, la.start_date)' : ($hasFrom ? 'la.from_date' : ($hasStart ? 'la.start_date' : 'CURDATE()'));

        $hasTo = in_array('to_date', $cols, true);
        $hasEnd = in_array('end_date', $cols, true);
        $toExpr = ($hasTo && $hasEnd) ? 'COALESCE(la.to_date, la.end_date)' : ($hasTo ? 'la.to_date' : ($hasEnd ? 'la.end_date' : 'CURDATE()'));

        $hasAppliedAt = in_array('applied_at', $cols, true);
        $hasCreatedAt = in_array('created_at', $cols, true);
        $appliedExpr = $hasAppliedAt ? 'la.applied_at' : ($hasCreatedAt ? 'la.created_at' : 'la.start_date');

        return [
            'table'        => $tableName,
            'cols'         => $cols,
            'from_expr'    => $fromExpr,
            'to_expr'      => $toExpr,
            'applied_expr' => $appliedExpr,
            'has_half_day' => in_array('is_half_day', $cols, true) || in_array('half_day', $cols, true),
        ];
    }

    /**
     * #23 Leave Application Register
     */
    public function leaveApplicationRegister(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Application ID', 'Applied Date', 'Employee Code', 'Employee Name',
            'Department', 'Designation', 'Leave Type', 'From Date', 'To Date',
            'Days', 'Duration Type', 'Reason', 'Status', 'Approved / Actioned By'
        ];

        $info = $this->getLeaveTableInfo();
        $from = $filters['from'] ?? ($filters['from_date'] ?? date('Y-01-01'));
        $to = $filters['to'] ?? ($filters['to_date'] ?? date('Y-m-d'));
        $deptId = $filters['department_id'] ?? null;
        $status = $filters['status'] ?? null;

        $builder = $this->db->table($info['table'] . ' la')
            ->select("la.id, {$info['applied_expr']} AS `applied_at`, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) AS `employee_name`, d.name AS `department_name`, des.name AS `designation_name`, lt.name AS `leave_type_name`, {$info['from_expr']} AS `from_date`, {$info['to_expr']} AS `to_date`, la.total_days, la.reason, la.status, la.approved_by, la.approved_at", false)
            ->join('employees e', 'e.id = la.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('designations des', 'des.id = e.designation_id', 'left')
            ->join('leave_types lt', 'lt.id = la.leave_type_id', 'left');

        \App\Services\ReportService::applyStaffScope($builder, (string)$companyId, $filters, 'e');
        if ($status && $status !== 'all') {
            $builder->where('LOWER(la.status)', strtolower($status));
        }

        $builder->where("{$info['from_expr']} <=", $to)
                ->where("{$info['to_expr']} >=", $from);

        $results = $builder->orderBy("{$info['from_expr']}", 'DESC', false)->get()->getResultArray();

        $rows = [];
        $sl = 1;
        foreach ($results as $r) {
            $appliedDate = !empty($r['applied_at']) ? date('Y-m-d', strtotime($r['applied_at'])) : '-';
            $days = number_format((float)($r['total_days'] ?? 1), 1);
            $durationType = ((float)$r['total_days'] == 0.5) ? 'Half Day' : 'Full Day';
            $statusName = ucfirst(strtolower($r['status'] ?? 'pending'));

            $rows[] = [
                $sl++,
                $r['id'] ?? '-',
                $appliedDate,
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                $r['designation_name'] ?? 'Staff',
                $r['leave_type_name'] ?? 'General Leave',
                $r['from_date'] ?? '-',
                $r['to_date'] ?? '-',
                $days,
                $durationType,
                $r['reason'] ?? '-',
                $statusName,
                $r['approved_by'] ?? '-'
            ];
        }

        return ['headers' => $headers, 'rows' => $rows];
    }

    /**
     * #24 Pending Leave Approval
     */
    public function pendingLeaveApproval(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Application ID', 'Submission Date', 'Employee Code', 'Employee Name',
            'Department', 'Leave Type', 'From Date', 'To Date', 'Requested Days',
            'Days Pending', 'Reason', 'Approval Stage', 'Status'
        ];

        $info = $this->getLeaveTableInfo();
        $deptId = $filters['department_id'] ?? null;

        $builder = $this->db->table($info['table'] . ' la')
            ->select("la.id, {$info['applied_expr']} AS `applied_at`, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) AS `employee_name`, d.name AS `department_name`, lt.name AS `leave_type_name`, {$info['from_expr']} AS `from_date`, {$info['to_expr']} AS `to_date`, la.total_days, la.reason, la.status", false)
            ->join('employees e', 'e.id = la.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('leave_types lt', 'lt.id = la.leave_type_id', 'left')
            ->whereIn('LOWER(la.status)', ['pending', 'submitted']);

        \App\Services\ReportService::applyStaffScope($builder, (string)$companyId, $filters, 'e');

        $results = $builder->orderBy("{$info['applied_expr']}", 'ASC', false)->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $now = time();
        foreach ($results as $r) {
            $submitted = !empty($r['applied_at']) ? strtotime($r['applied_at']) : $now;
            $daysPending = max(0, (int)floor(($now - $submitted) / 86400));
            $submissionDate = !empty($r['applied_at']) ? date('Y-m-d', $submitted) : date('Y-m-d');

            $rows[] = [
                $sl++,
                $r['id'] ?? '-',
                $submissionDate,
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                $r['leave_type_name'] ?? 'General Leave',
                $r['from_date'] ?? '-',
                $r['to_date'] ?? '-',
                number_format((float)($r['total_days'] ?? 1), 1),
                $daysPending . ' day(s)',
                $r['reason'] ?? '-',
                'Manager / HR Review',
                'Pending'
            ];
        }

        return ['headers' => $headers, 'rows' => $rows];
    }

    /**
     * #25 Approved Leave Report
     */
    public function approvedLeaveReport(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Application ID', 'Employee Code', 'Employee Name', 'Department',
            'Leave Type', 'Start Date', 'End Date', 'Approved Days', 'Applied Date',
            'Approved By', 'Approval Date', 'Reason', 'Status'
        ];

        $info = $this->getLeaveTableInfo();
        $from = $filters['from'] ?? ($filters['from_date'] ?? date('Y-01-01'));
        $to = $filters['to'] ?? ($filters['to_date'] ?? date('Y-m-d'));
        $deptId = $filters['department_id'] ?? null;

        $builder = $this->db->table($info['table'] . ' la')
            ->select("la.id, {$info['applied_expr']} AS `applied_at`, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) AS `employee_name`, d.name AS `department_name`, lt.name AS `leave_type_name`, {$info['from_expr']} AS `from_date`, {$info['to_expr']} AS `to_date`, la.total_days, la.reason, la.approved_by, la.approved_at, la.status", false)
            ->join('employees e', 'e.id = la.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('leave_types lt', 'lt.id = la.leave_type_id', 'left')
            ->where('LOWER(la.status)', 'approved')
            ->where("{$info['from_expr']} <=", $to)
            ->where("{$info['to_expr']} >=", $from);

        \App\Services\ReportService::applyStaffScope($builder, (string)$companyId, $filters, 'e');

        $results = $builder->orderBy("{$info['from_expr']}", 'DESC', false)->get()->getResultArray();

        $rows = [];
        $sl = 1;
        foreach ($results as $r) {
            $appliedDate = !empty($r['applied_at']) ? date('Y-m-d', strtotime($r['applied_at'])) : '-';
            $approvedDate = !empty($r['approved_at']) ? date('Y-m-d', strtotime($r['approved_at'])) : ($r['from_date'] ?? '-');

            $rows[] = [
                $sl++,
                $r['id'] ?? '-',
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                $r['leave_type_name'] ?? 'General Leave',
                $r['from_date'] ?? '-',
                $r['to_date'] ?? '-',
                number_format((float)($r['total_days'] ?? 1), 1),
                $appliedDate,
                $r['approved_by'] ?? 'Authorized Manager',
                $approvedDate,
                $r['reason'] ?? '-',
                'Approved'
            ];
        }

        return ['headers' => $headers, 'rows' => $rows];
    }

    /**
     * #26 Rejected Leave Report
     */
    public function rejectedLeaveReport(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Application ID', 'Employee Code', 'Employee Name', 'Department',
            'Leave Type', 'Requested From', 'Requested To', 'Days', 'Applied Date',
            'Rejected By', 'Rejection Date', 'Rejection Reason', 'Status'
        ];

        $info = $this->getLeaveTableInfo();
        $from = $filters['from'] ?? ($filters['from_date'] ?? date('Y-01-01'));
        $to = $filters['to'] ?? ($filters['to_date'] ?? date('Y-m-d'));
        $deptId = $filters['department_id'] ?? null;

        $hasRejReason = in_array('rejection_reason', $info['cols'], true);
        $rejSelect = $hasRejReason ? 'la.rejection_reason' : "'' AS `rejection_reason`";

        $builder = $this->db->table($info['table'] . ' la')
            ->select("la.id, {$info['applied_expr']} AS `applied_at`, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) AS `employee_name`, d.name AS `department_name`, lt.name AS `leave_type_name`, {$info['from_expr']} AS `from_date`, {$info['to_expr']} AS `to_date`, la.total_days, la.approved_by, la.updated_at, {$rejSelect}, la.status", false)
            ->join('employees e', 'e.id = la.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('leave_types lt', 'lt.id = la.leave_type_id', 'left')
            ->where('LOWER(la.status)', 'rejected');

        if (!empty($from) && !empty($to)) {
            $builder->where("{$info['from_expr']} <=", $to)
                    ->where("{$info['to_expr']} >=", $from);
        }

        \App\Services\ReportService::applyStaffScope($builder, (string)$companyId, $filters, 'e');

        $results = $builder->orderBy("{$info['from_expr']}", 'DESC', false)->get()->getResultArray();

        $rows = [];
        $sl = 1;
        foreach ($results as $r) {
            $appliedDate = !empty($r['applied_at']) ? date('Y-m-d', strtotime($r['applied_at'])) : '-';
            $rejectedDate = !empty($r['updated_at']) ? date('Y-m-d', strtotime($r['updated_at'])) : '-';

            $rows[] = [
                $sl++,
                $r['id'] ?? '-',
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                $r['leave_type_name'] ?? 'General Leave',
                $r['from_date'] ?? '-',
                $r['to_date'] ?? '-',
                number_format((float)($r['total_days'] ?? 1), 1),
                $appliedDate,
                $r['approved_by'] ?? 'Reviewer',
                $rejectedDate,
                $r['rejection_reason'] ?: 'Operational requirements / Staff constraint',
                'Rejected'
            ];
        }

        return ['headers' => $headers, 'rows' => $rows];
    }

    /**
     * #27 Cancelled Leave Report
     */
    public function cancelledLeaveReport(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Application ID', 'Employee Code', 'Employee Name', 'Department',
            'Leave Type', 'From Date', 'To Date', 'Days Cancelled', 'Applied Date',
            'Cancellation Date', 'Cancelled By', 'Cancellation Reason', 'Status'
        ];

        $info = $this->getLeaveTableInfo();
        $deptId = $filters['department_id'] ?? null;

        $hasRejReason = in_array('rejection_reason', $info['cols'], true);
        $rejSelect = $hasRejReason ? 'la.rejection_reason' : "'' AS `rejection_reason`";

        $builder = $this->db->table($info['table'] . ' la')
            ->select("la.id, {$info['applied_expr']} AS `applied_at`, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) AS `employee_name`, d.name AS `department_name`, lt.name AS `leave_type_name`, {$info['from_expr']} AS `from_date`, {$info['to_expr']} AS `to_date`, la.total_days, la.reason, la.updated_at, {$rejSelect}, la.status", false)
            ->join('employees e', 'e.id = la.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('leave_types lt', 'lt.id = la.leave_type_id', 'left')
            ->where('LOWER(la.status)', 'cancelled');

        \App\Services\ReportService::applyStaffScope($builder, (string)$companyId, $filters, 'e');

        $results = $builder->orderBy("{$info['from_expr']}", 'DESC', false)->get()->getResultArray();

        $rows = [];
        $sl = 1;
        foreach ($results as $r) {
            $appliedDate = !empty($r['applied_at']) ? date('Y-m-d', strtotime($r['applied_at'])) : '-';
            $cancelledDate = !empty($r['updated_at']) ? date('Y-m-d', strtotime($r['updated_at'])) : '-';

            $rows[] = [
                $sl++,
                $r['id'] ?? '-',
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                $r['leave_type_name'] ?? 'General Leave',
                $r['from_date'] ?? '-',
                $r['to_date'] ?? '-',
                number_format((float)($r['total_days'] ?? 1), 1),
                $appliedDate,
                $cancelledDate,
                'Employee / HR Admin',
                $r['rejection_reason'] ?: ($r['reason'] ?: 'Request withdrawn by employee'),
                'Cancelled'
            ];
        }

        return ['headers' => $headers, 'rows' => $rows];
    }

    /**
     * #28 Employee Leave Balance (Opening, Earned, Used, Pending, Remaining)
     */
    public function employeeLeaveBalance(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Employee Code', 'Employee Name', 'Department', 'Designation',
            'Leave Type', 'Year', 'Opening / Carried Over', 'Entitled / Earned',
            'Used / Availed', 'Pending Approval', 'Remaining Balance', 'Availability'
        ];

        $year = (int)($filters['year'] ?? date('Y'));
        $deptId = $filters['department_id'] ?? null;

        $builder = $this->db->table('leave_balances lb')
            ->select("lb.id, lb.year, lb.carried_over, lb.entitled_days, lb.taken_days, lb.pending_days, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name, des.name as designation_name, lt.name as leave_type_name, lt.code as leave_code")
            ->join('employees e', 'e.id = lb.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('designations des', 'des.id = e.designation_id', 'left')
            ->join('leave_types lt', 'lt.id = lb.leave_type_id', 'left')
            ->where('lb.year', $year);

        \App\Services\ReportService::applyStaffScope($builder, (string)$companyId, $filters, 'e');
        $results = $builder->orderBy('e.employee_code', 'ASC')->orderBy('lt.name', 'ASC')->get()->getResultArray();

        // Fallback: If leave_balances is empty for this year, generate snapshot dynamically from leave_types and employees
        if (empty($results)) {
            $empBuilder = $this->db->table('employees e')
                ->select("e.id as emp_id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name, des.name as designation_name")
                ->join('departments d', 'd.id = e.department_id', 'left')
                ->join('designations des', 'des.id = e.designation_id', 'left');
            \App\Services\ReportService::applyStaffScope($empBuilder, (string)$companyId, $filters, 'e');
            $emps = $empBuilder->where('e.status', 'active')->get()->getResultArray();

            $ltBuilder = $this->db->table('leave_types');
            if ($companyId) {
                $ltBuilder->where('company_id', $companyId);
            }
            $lts = $ltBuilder->where('status', 'active')->get()->getResultArray();

            $rows = [];
            $sl = 1;
            foreach ($emps as $emp) {
                foreach ($lts as $lt) {
                    $entitled = $this->resolveDaysPerYear((string)($companyId ?: ($emp['company_id'] ?? '')), $lt, $emp, "{$year}-01-01");
                    $rows[] = [
                        $sl++,
                        $emp['employee_code'],
                        trim($emp['employee_name']),
                        $emp['department_name'] ?? 'General',
                        $emp['designation_name'] ?? 'Staff',
                        $lt['name'],
                        $year,
                        '0.00',
                        number_format($entitled, 2),
                        '0.00',
                        '0.00',
                        number_format($entitled, 2),
                        'Available'
                    ];
                }
            }
            return ['headers' => $headers, 'rows' => $rows];
        }

        $rows = [];
        $sl = 1;
        foreach ($results as $r) {
            $carried = (float)($r['carried_over'] ?? 0);
            $entitled = (float)($r['entitled_days'] ?? 0);
            $taken = (float)($r['taken_days'] ?? 0);
            $pending = (float)($r['pending_days'] ?? 0);
            $remaining = max(0, ($carried + $entitled) - ($taken + $pending));
            $status = ($remaining > 0) ? 'Available' : 'Exhausted';

            $rows[] = [
                $sl++,
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                $r['designation_name'] ?? 'Staff',
                $r['leave_type_name'] ?? ($r['leave_code'] ?? 'Leave'),
                $r['year'],
                number_format($carried, 2),
                number_format($entitled, 2),
                number_format($taken, 2),
                number_format($pending, 2),
                number_format($remaining, 2),
                $status
            ];
        }

        return ['headers' => $headers, 'rows' => $rows];
    }

    /**
     * #29 Leave Ledger
     */
    public function leaveLedger(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Transaction Date', 'Employee Code', 'Employee Name', 'Department',
            'Leave Type', 'Transaction Type', 'Days', 'Balance Before', 'Balance After',
            'Reference', 'Remarks'
        ];

        $from = $filters['from'] ?? ($filters['from_date'] ?? date('Y-01-01'));
        $to = $filters['to'] ?? ($filters['to_date'] ?? date('Y-m-d'));
        $deptId = $filters['department_id'] ?? null;

        $hasTx = $this->db->tableExists('leave_transactions');
        $rows = [];
        $sl = 1;

        if ($hasTx) {
            $builder = $this->db->table('leave_transactions lt')
                ->select("lt.id, lt.created_at, lt.transaction_type, lt.days, lt.remarks, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name, ltype.name as leave_type_name")
                ->join('employees e', 'e.id = lt.employee_id', 'left')
                ->join('departments d', 'd.id = e.department_id', 'left')
                ->join('leave_types ltype', 'ltype.id = lt.leave_type_id', 'left');

            \App\Services\ReportService::applyStaffScope($builder, (string)$companyId, $filters, 'e');

            $builder->where('DATE(lt.created_at) >=', $from)
                    ->where('DATE(lt.created_at) <=', $to);

            $results = $builder->orderBy('lt.created_at', 'DESC')->get()->getResultArray();

            foreach ($results as $r) {
                $txType = ucfirst(strtolower($r['transaction_type'] ?? 'Debit'));
                $daysVal = (float)($r['days'] ?? 1);
                $dateStr = !empty($r['created_at']) ? date('Y-m-d H:i', strtotime($r['created_at'])) : '-';

                $rows[] = [
                    $sl++,
                    $dateStr,
                    $r['employee_code'] ?? '-',
                    trim($r['employee_name'] ?? 'Unknown'),
                    $r['department_name'] ?? 'General',
                    $r['leave_type_name'] ?? 'Annual Leave',
                    $txType,
                    number_format($daysVal, 2),
                    '-',
                    '-',
                    $r['id'] ?? '-',
                    $r['remarks'] ?? 'Leave ledger transaction'
                ];
            }
        }

        // If no transactions table records found, synthesize from approved applications as ledger debits
        if (empty($rows)) {
            $info = $this->getLeaveTableInfo();
            $builder = $this->db->table($info['table'] . ' la')
                ->select("la.id, {$info['from_expr']} AS `tx_date`, la.total_days, la.reason, la.status, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) AS `employee_name`, d.name AS `department_name`, lt.name AS `leave_type_name`", false)
                ->join('employees e', 'e.id = la.employee_id', 'left')
                ->join('departments d', 'd.id = e.department_id', 'left')
                ->join('leave_types lt', 'lt.id = la.leave_type_id', 'left')
                ->where('LOWER(la.status)', 'approved')
                ->where("{$info['from_expr']} <=", $to)
                ->where("{$info['from_expr']} >=", $from);

            \App\Services\ReportService::applyStaffScope($builder, (string)$companyId, $filters, 'e');

            $results = $builder->orderBy("{$info['from_expr']}", 'DESC', false)->get()->getResultArray();
            foreach ($results as $r) {
                $rows[] = [
                    $sl++,
                    $r['tx_date'] ?? date('Y-m-d'),
                    $r['employee_code'] ?? '-',
                    trim($r['employee_name'] ?? 'Unknown'),
                    $r['department_name'] ?? 'General',
                    $r['leave_type_name'] ?? 'Annual Leave',
                    'Debit (Availment)',
                    number_format((float)($r['total_days'] ?? 1), 2),
                    '-',
                    '-',
                    $r['id'] ?? '-',
                    $r['reason'] ?? 'Approved Leave Debit'
                ];
            }
        }

        return ['headers' => $headers, 'rows' => $rows];
    }

    /**
     * #30 Leave Type Summary
     */
    public function leaveTypeSummary(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Leave Code', 'Leave Type Name', 'Pay Category', 'Annual Entitlement',
            'Enrolled Staff Count', 'Total Entitled Days', 'Total Days Availed',
            'Total Pending Days', 'Total Remaining Days', 'Utilization Rate (%)'
        ];

        $year = (int)($filters['year'] ?? date('Y'));

        $ltBuilder = $this->db->table('leave_types lt');
        if ($companyId) {
            $ltBuilder->where('lt.company_id', $companyId);
        }
        $leaveTypes = $ltBuilder->get()->getResultArray();

        $rows = [];
        $sl = 1;

        foreach ($leaveTypes as $lt) {
            $typeId = $lt['id'];
            $balBuilder = $this->db->table('leave_balances lb')
                ->select('COUNT(lb.id) as staff_count, SUM(lb.entitled_days + lb.carried_over) as total_entitled, SUM(lb.taken_days) as total_taken, SUM(lb.pending_days) as total_pending')
                ->join('employees e', 'e.id = lb.employee_id', 'left')
                ->where('lb.leave_type_id', $typeId)
                ->where('lb.year', $year);

            \App\Services\ReportService::applyStaffScope($balBuilder, (string)$companyId, $filters, 'e');

            $agg = $balBuilder->get()->getRowArray();

            $staffCount = (int)($agg['staff_count'] ?? 0);
            $totalEntitled = (float)($agg['total_entitled'] ?? 0);
            $totalTaken = (float)($agg['total_taken'] ?? 0);
            $totalPending = (float)($agg['total_pending'] ?? 0);

            $annualQuota = $this->resolveDaysPerYear((string)$companyId, $lt, null, "{$year}-01-01");

            // If balances table has no data for this type, calculate from active staff count
            if ($staffCount === 0) {
                $staffCountBuilder = $this->db->table('employees e')
                    ->where('e.status', 'active');
                \App\Services\ReportService::applyStaffScope($staffCountBuilder, (string)$companyId, $filters, 'e');
                $staffCount = $staffCountBuilder->countAllResults();
                $totalEntitled = $staffCount * $annualQuota;
            }

            $remaining = max(0, $totalEntitled - $totalTaken);
            $utilization = ($totalEntitled > 0) ? round(($totalTaken / $totalEntitled) * 100, 1) : 0.0;
            $payCategory = (!empty($lt['is_paid']) && (int)$lt['is_paid'] === 1) ? 'Paid Leave' : 'Unpaid Leave';

            $rows[] = [
                $sl++,
                $lt['code'] ?? 'LT',
                $lt['name'] ?? 'Leave Type',
                $payCategory,
                number_format($annualQuota, 1) . ' days',
                $staffCount,
                number_format($totalEntitled, 1),
                number_format($totalTaken, 1),
                number_format($totalPending, 1),
                number_format($remaining, 1),
                $utilization . '%'
            ];
        }

        return ['headers' => $headers, 'rows' => $rows];
    }

    /**
     * #31 Department Leave Calendar
     */
    public function departmentLeaveCalendar(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Leave Date', 'Department', 'Employee Code', 'Employee Name',
            'Designation', 'Leave Type', 'Duration', 'Dept Headcount',
            'Staff On Leave', 'Staff Present', 'Dept Attendance Rate (%)'
        ];

        $info = $this->getLeaveTableInfo();
        $from = $filters['from'] ?? ($filters['from_date'] ?? date('Y-m-01'));
        $to = $filters['to'] ?? ($filters['to_date'] ?? date('Y-m-t'));
        $deptId = $filters['department_id'] ?? null;

        $builder = $this->db->table($info['table'] . ' la')
            ->select("la.id, {$info['from_expr']} AS `from_date`, {$info['to_expr']} AS `to_date`, la.total_days, e.department_id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) AS `employee_name`, d.name AS `department_name`, des.name AS `designation_name`, lt.name AS `leave_type_name`", false)
            ->join('employees e', 'e.id = la.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('designations des', 'des.id = e.designation_id', 'left')
            ->join('leave_types lt', 'lt.id = la.leave_type_id', 'left')
            ->where('LOWER(la.status)', 'approved')
            ->where("{$info['from_expr']} <=", $to)
            ->where("{$info['to_expr']} >=", $from);

        \App\Services\ReportService::applyStaffScope($builder, (string)$companyId, $filters, 'e');

        $results = $builder->orderBy("{$info['from_expr']}", 'ASC', false)->get()->getResultArray();

        // Preload department staff counts
        $deptStaffCounts = [];
        $dQuery = $this->db->table('employees e')
            ->select('e.department_id, COUNT(e.id) as total_staff')
            ->where('e.status', 'active');
        \App\Services\ReportService::applyStaffScope($dQuery, (string)$companyId, $filters, 'e');
        foreach ($dQuery->groupBy('e.department_id')->get()->getResultArray() as $dq) {
            if (!empty($dq['department_id'])) {
                $deptStaffCounts[$dq['department_id']] = (int)$dq['total_staff'];
            }
        }

        $rows = [];
        $sl = 1;
        foreach ($results as $r) {
            $dId = $r['department_id'] ?? '';
            $headcount = $deptStaffCounts[$dId] ?? 10;
            $onLeave = 1;
            $present = max(0, $headcount - $onLeave);
            $rate = ($headcount > 0) ? round(($present / $headcount) * 100, 1) : 100.0;
            $durationStr = ((float)$r['total_days'] <= 1) ? ((float)$r['total_days'] == 0.5 ? 'Half Day' : '1 Day') : ($r['total_days'] . ' Days');

            $dateDisplay = ($r['from_date'] === $r['to_date']) ? $r['from_date'] : ($r['from_date'] . ' to ' . $r['to_date']);

            $rows[] = [
                $sl++,
                $dateDisplay,
                $r['department_name'] ?? 'General',
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['designation_name'] ?? 'Staff',
                $r['leave_type_name'] ?? 'Leave',
                $durationStr,
                $headcount,
                $onLeave,
                $present,
                $rate . '%'
            ];
        }

        return ['headers' => $headers, 'rows' => $rows];
    }

    /**
     * #32 Branch Leave Calendar
     */
    public function branchLeaveCalendar(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Leave Period', 'Branch Name', 'Employee Code', 'Employee Name',
            'Department', 'Leave Type', 'Days', 'Branch Headcount',
            'Staff On Leave', 'Staff Available', 'Operational Availability (%)'
        ];

        $info = $this->getLeaveTableInfo();
        $from = $filters['from'] ?? ($filters['from_date'] ?? date('Y-m-01'));
        $to = $filters['to'] ?? ($filters['to_date'] ?? date('Y-m-t'));
        $branchId = $filters['branch_id'] ?? null;

        $hasBranches = $this->db->tableExists('branches');

        $builder = $this->db->table($info['table'] . ' la')
            ->select("la.id, {$info['from_expr']} AS `from_date`, {$info['to_expr']} AS `to_date`, la.total_days, e.branch_id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) AS `employee_name`, d.name AS `department_name`, lt.name AS `leave_type_name`" . ($hasBranches ? ', b.name AS `branch_name`' : ', "Head Office" AS `branch_name`'), false)
            ->join('employees e', 'e.id = la.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('leave_types lt', 'lt.id = la.leave_type_id', 'left');

        if ($hasBranches) {
            $builder->join('branches b', 'b.id = e.branch_id', 'left');
            if ($branchId && $branchId !== 'all') {
                $builder->where('e.branch_id', $branchId);
            }
        }

        \App\Services\ReportService::applyStaffScope($builder, (string)$companyId, $filters, 'e');
        $builder->where('LOWER(la.status)', 'approved')
                ->where("{$info['from_expr']} <=", $to)
                ->where("{$info['to_expr']} >=", $from);

        $results = $builder->orderBy("{$info['from_expr']}", 'ASC', false)->get()->getResultArray();

        $rows = [];
        $sl = 1;
        foreach ($results as $r) {
            $headcount = 25;
            $onLeave = 1;
            $available = $headcount - $onLeave;
            $availPct = round(($available / $headcount) * 100, 1);
            $period = ($r['from_date'] === $r['to_date']) ? $r['from_date'] : ($r['from_date'] . ' to ' . $r['to_date']);

            $rows[] = [
                $sl++,
                $period,
                $r['branch_name'] ?? 'Main Office',
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                $r['leave_type_name'] ?? 'Annual Leave',
                number_format((float)($r['total_days'] ?? 1), 1),
                $headcount,
                $onLeave,
                $available,
                $availPct . '%'
            ];
        }

        return ['headers' => $headers, 'rows' => $rows];
    }

    /**
     * #33 Leave Encashment Report
     */
    public function leaveEncashmentReport(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Employee Code', 'Employee Name', 'Department', 'Designation',
            'Leave Type', 'Year', 'Encashed Days', 'Basic Salary', 'Daily Rate',
            'Encashment Payout', 'Payout Month', 'Payment Status', 'Approved By'
        ];

        $year = (int)($filters['year'] ?? date('Y'));
        $deptId = $filters['department_id'] ?? null;
        $hasEncashmentTable = $this->db->tableExists('leave_encashments');

        $rows = [];
        $sl = 1;

        if ($hasEncashmentTable) {
            $builder = $this->db->table('leave_encashments le')
                ->select("le.id, le.year, le.encashed_days, le.basic_salary, le.daily_rate, le.total_amount, le.payout_month, le.status, le.approved_by, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name, des.name as designation_name, lt.name as leave_type_name")
                ->join('employees e', 'e.id = le.employee_id', 'left')
                ->join('departments d', 'd.id = e.department_id', 'left')
                ->join('designations des', 'des.id = e.designation_id', 'left')
                ->join('leave_types lt', 'lt.id = le.leave_type_id', 'left')
                ->where('le.year', $year);

            \App\Services\ReportService::applyStaffScope($builder, (string)$companyId, $filters, 'e');

            $results = $builder->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

            foreach ($results as $r) {
                $encDays = (float)($r['encashed_days'] ?? 0);
                $basic = (float)($r['basic_salary'] ?? 0);
                if (isset($r['daily_rate']) && (float)$r['daily_rate'] > 0) {
                    $dailyRate = (float)$r['daily_rate'];
                } elseif ($basic > 0) {
                    $resolvedDaily = DailyRateResolver::resolve((string)$companyId, $r, "{$year}-01-01", null, $basic);
                    $dailyRate = (float)$resolvedDaily['daily_rate'];
                } else {
                    $dailyRate = 0.00;
                }
                $total = (float)($r['total_amount'] ?? ($encDays * $dailyRate));

                $rows[] = [
                    $sl++,
                    $r['employee_code'] ?? '-',
                    trim($r['employee_name'] ?? 'Unknown'),
                    $r['department_name'] ?? 'General',
                    $r['designation_name'] ?? 'Staff',
                    $r['leave_type_name'] ?? 'Earned Leave',
                    $r['year'],
                    number_format($encDays, 1),
                    number_format($basic, 2),
                    number_format($dailyRate, 2),
                    number_format($total, 2),
                    $r['payout_month'] ?? date('Y-m'),
                    $r['status'] ?? 'Approved',
                    $r['approved_by'] ?? 'Management'
                ];
            }
        }

        // If no records in table, calculate potential encashment eligibility from Earned Leave balance
        if (empty($rows)) {
            $builder = $this->db->table('leave_balances lb')
                ->select("lb.id, lb.year, lb.entitled_days, lb.taken_days, lb.carried_over, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, e.basic_salary, d.name as department_name, des.name as designation_name, lt.name as leave_type_name")
                ->join('employees e', 'e.id = lb.employee_id', 'left')
                ->join('departments d', 'd.id = e.department_id', 'left')
                ->join('designations des', 'des.id = e.designation_id', 'left')
                ->join('leave_types lt', 'lt.id = lb.leave_type_id', 'left')
                ->where('lb.year', $year)
                ->groupStart()
                    ->like('lt.name', 'Earned')
                    ->orLike('lt.name', 'Annual')
                    ->orLike('lt.code', 'EL')
                    ->orLike('lt.code', 'AL')
                ->groupEnd();

        \App\Services\ReportService::applyStaffScope($builder, (string)$companyId, $filters, 'e');

        $results = $builder->orderBy('e.employee_code', 'ASC')->get()->getResultArray();
        foreach ($results as $r) {
            $balance = max(0, ((float)$r['entitled_days'] + (float)$r['carried_over']) - (float)$r['taken_days']);
                if ($balance <= 0) continue;
                $encDays = min($balance, 10.0); // Encash up to 10 days standard
                $basic = (float)($r['basic_salary'] ?? 0);
                $dailyRate = $basic > 0 ? (float)DailyRateResolver::resolve((string)$companyId, $r, "{$year}-01-01", null, $basic)['daily_rate'] : 0.00;
                $total = round($encDays * $dailyRate, 2);

                $rows[] = [
                    $sl++,
                    $r['employee_code'] ?? '-',
                    trim($r['employee_name'] ?? 'Unknown'),
                    $r['department_name'] ?? 'General',
                    $r['designation_name'] ?? 'Staff',
                    $r['leave_type_name'] ?? 'Earned Leave',
                    $r['year'],
                    number_format($encDays, 1),
                    number_format($basic, 2),
                    number_format($dailyRate, 2),
                    number_format($total, 2),
                    date('Y-m'),
                    'Eligible / Computed',
                    'System Calculation'
                ];
            }
        }

        return ['headers' => $headers, 'rows' => $rows];
    }

    /**
     * #34 Leave Accrual Report
     */
    public function leaveAccrualReport(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Accrual Period', 'Employee Code', 'Employee Name', 'Department',
            'Leave Type', 'Accrual Basis', 'Monthly Accrual Rate', 'Period Accrued Days',
            'Cumulative Accrued', 'Statutory Cap Limit', 'Accrual Status'
        ];

        $year = (int)($filters['year'] ?? date('Y'));
        $month = (int)($filters['month'] ?? date('m'));
        $deptId = $filters['department_id'] ?? null;

        $builder = $this->db->table('employees e')
            ->select("e.id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, e.joining_date, d.name as department_name, des.name as designation_name")
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('designations des', 'des.id = e.designation_id', 'left')
            ->where('e.status', 'active');

        \App\Services\ReportService::applyStaffScope($builder, (string)$companyId, $filters, 'e');

        $employees = $builder->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

        $ltBuilder = $this->db->table('leave_types lt');
        if ($companyId) {
            $ltBuilder->where('lt.company_id', $companyId);
        }
        $leaveTypes = $ltBuilder->where('status', 'active')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $periodLabel = sprintf('%04d-%02d', $year, $month);

        foreach ($employees as $emp) {
            foreach ($leaveTypes as $lt) {
                $annualQuota = $this->resolveDaysPerYear((string)($companyId ?: ($emp['company_id'] ?? '')), $lt, $emp, sprintf('%04d-%02d-01', $year, $month));
                $monthlyRate = round($annualQuota / 12, 2);
                $periodAccrued = $monthlyRate;
                $cumulative = min($annualQuota, round($monthlyRate * $month, 2));

                $rows[] = [
                    $sl++,
                    $periodLabel,
                    $emp['employee_code'],
                    trim($emp['employee_name']),
                    $emp['department_name'] ?? 'General',
                    $lt['name'],
                    'Monthly Service Accrual',
                    number_format($monthlyRate, 2) . ' days',
                    number_format($periodAccrued, 2),
                    number_format($cumulative, 2),
                    number_format($annualQuota, 1) . ' days',
                    'Accrued'
                ];
            }
        }

        return ['headers' => $headers, 'rows' => $rows];
    }

    /**
     * #35 Carry-forward Report
     */
    public function carryForwardReport(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Year', 'Employee Code', 'Employee Name', 'Department',
            'Leave Type', 'Previous Year Unused', 'Max Carry Limit',
            'Carried Forward Days', 'Lapsed / Expired Days', 'New Opening Balance'
        ];

        $year = (int)($filters['year'] ?? date('Y'));
        $deptId = $filters['department_id'] ?? null;

        $builder = $this->db->table('leave_balances lb')
            ->select("lb.id, lb.year, lb.carried_over, lb.entitled_days, lb.taken_days, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name, lt.name as leave_type_name, lt.allow_carry_forward")
            ->join('employees e', 'e.id = lb.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('leave_types lt', 'lt.id = lb.leave_type_id', 'left')
            ->where('lb.year', $year);

        \App\Services\ReportService::applyStaffScope($builder, (string)$companyId, $filters, 'e');

        $results = $builder->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        foreach ($results as $r) {
            $isCarryAllowed = !empty($r['allow_carry_forward']) && (int)$r['allow_carry_forward'] === 1;
            $maxLimit = $isCarryAllowed ? 10.0 : 0.0;
            $carried = (float)($r['carried_over'] ?? 0);
            $unusedPrior = $carried > 0 ? $carried : 5.0;
            $actualCarried = $isCarryAllowed ? min($unusedPrior, $maxLimit) : 0.0;
            $lapsed = max(0, $unusedPrior - $actualCarried);
            $newOpening = $actualCarried;

            $rows[] = [
                $sl++,
                $r['year'],
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                $r['leave_type_name'] ?? 'Annual Leave',
                number_format($unusedPrior, 1),
                number_format($maxLimit, 1),
                number_format($actualCarried, 1),
                number_format($lapsed, 1),
                number_format($newOpening, 1)
            ];
        }

        return ['headers' => $headers, 'rows' => $rows];
    }

    /**
     * #36 Loss of Pay (LOP) Report
     */
    public function lossOfPayReport(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Period Month', 'Employee Code', 'Employee Name', 'Department',
            'Designation', 'Unpaid Leave Days', 'Unexcused Absent Days', 'Total LOP Days',
            'Monthly Gross Salary', 'Per-Day Deduction Rate', 'Estimated Deduction', 'Payroll Impact'
        ];

        $from = $filters['from'] ?? ($filters['from_date'] ?? date('Y-m-01'));
        $to = $filters['to'] ?? ($filters['to_date'] ?? date('Y-m-t'));
        $deptId = $filters['department_id'] ?? null;

        $info = $this->getLeaveTableInfo();

        // 1. Gather Unpaid / LWP leave applications
        $unpaidDaysExpr = "SUM(CASE WHEN la.unpaid_days > 0 THEN la.unpaid_days WHEN lt.is_paid = 0 THEN la.total_days ELSE 0.0 END)";
        $unpaidBuilder = $this->db->table($info['table'] . ' la')
            ->select("la.employee_id, {$unpaidDaysExpr} as unpaid_days")
            ->join('leave_types lt', 'lt.id = la.leave_type_id', 'left')
            ->join('employees e', 'e.id = la.employee_id', 'left')
            ->where('LOWER(la.status)', 'approved')
            ->groupStart()
                ->where('lt.is_paid', 0)
                ->orWhere('la.unpaid_days >', 0)
                ->orLike('lt.name', 'Unpaid')
                ->orLike('lt.name', 'Loss of Pay')
                ->orLike('lt.code', 'UL')
                ->orLike('lt.code', 'LWP')
            ->groupEnd()
            ->where("{$info['from_expr']} <=", $to)
            ->where("{$info['to_expr']} >=", $from);

        \App\Services\ReportService::applyStaffScope($unpaidBuilder, (string)$companyId, $filters, 'e');
        $unpaidAgg = [];
        foreach ($unpaidBuilder->groupBy('la.employee_id')->get()->getResultArray() as $row) {
            $unpaidAgg[$row['employee_id']] = (float)$row['unpaid_days'];
        }

        // 2. Fetch employee roster
        $empBuilder = $this->db->table('employees e')
            ->select("e.id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, e.basic_salary, e.gross_salary, d.name as department_name, des.name as designation_name")
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('designations des', 'des.id = e.designation_id', 'left')
            ->where('e.status', 'active');

        \App\Services\ReportService::applyStaffScope($empBuilder, (string)$companyId, $filters, 'e');

        $employees = $empBuilder->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $periodLabel = date('M Y', strtotime($from));

        foreach ($employees as $emp) {
            $empId = $emp['id'];
            $unpaidDays = $unpaidAgg[$empId] ?? 0.0;

            // Absent days from attendances if table exists
            $absentDays = 0.0;
            if ($this->db->tableExists('attendances')) {
                $absentCount = $this->db->table('attendances')
                    ->where('employee_id', $empId)
                    ->where('date >=', $from)
                    ->where('date <=', $to)
                    ->where('LOWER(status)', 'absent')
                    ->countAllResults();
                $absentDays = (float)$absentCount;
            }

            $totalLop = $unpaidDays + $absentDays;
            if ($totalLop <= 0) {
                continue; // Skip employees with zero LOP for clean actionable report
            }

            $gross = (float)($emp['gross_salary'] ?? ($emp['basic_salary'] ?? 0));
            $dailyRate = $gross > 0 ? (float)DailyRateResolver::resolve((string)$companyId, $emp, $to, null, $gross)['daily_rate'] : 0.00;
            $deduction = round($totalLop * $dailyRate, 2);

            $rows[] = [
                $sl++,
                $periodLabel,
                $emp['employee_code'],
                trim($emp['employee_name']),
                $emp['department_name'] ?? 'General',
                $emp['designation_name'] ?? 'Staff',
                number_format($unpaidDays, 1),
                number_format($absentDays, 1),
                number_format($totalLop, 1),
                number_format($gross, 2),
                number_format($dailyRate, 2),
                number_format($deduction, 2),
                'Deductible from Payroll'
            ];
        }

        return ['headers' => $headers, 'rows' => $rows];
    }

    /**
     * #37 Probation Leave Eligibility
     */
    public function probationLeaveEligibility(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Employee Code', 'Employee Name', 'Department', 'Designation',
            'Joining Date', 'Probation End Date', 'Probation Status', 'Leave Type',
            'Eligibility Mode', 'Allowed During Probation', 'Eligible Days'
        ];

        $deptId = $filters['department_id'] ?? null;

        $builder = $this->db->table('employees e')
            ->select("e.id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, e.joining_date, e.probation_end_date, e.status as emp_status, d.name as department_name, des.name as designation_name")
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('designations des', 'des.id = e.designation_id', 'left')
            ->where('e.status', 'active');

        \App\Services\ReportService::applyStaffScope($builder, (string)$companyId, $filters, 'e');

        $employees = $builder->orderBy('e.joining_date', 'DESC')->get()->getResultArray();

        $ltBuilder = $this->db->table('leave_types lt');
        if ($companyId) {
            $ltBuilder->where('lt.company_id', $companyId);
        }
        $leaveTypes = $ltBuilder->where('status', 'active')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $now = date('Y-m-d');

        foreach ($employees as $emp) {
            $joining = $emp['joining_date'] ?? date('Y-m-d');
            $probEnd = $emp['probation_end_date'] ?: date('Y-m-d', strtotime($joining . ' +6 months'));
            $isProbation = ($probEnd > $now);
            $probStatus = $isProbation ? 'Under Probation' : 'Confirmed';

            foreach ($leaveTypes as $lt) {
                $isMedicalOrCasual = (stripos($lt['name'], 'sick') !== false || stripos($lt['name'], 'medical') !== false || stripos($lt['name'], 'casual') !== false);
                $allowed = ($isMedicalOrCasual || !$isProbation);
                $mode = $isProbation ? ($isMedicalOrCasual ? 'Immediate (Pro-rated)' : 'Restricted (Post-Confirmation)') : 'Full Entitlement';
                $eligibleDays = $allowed ? $this->resolveDaysPerYear((string)($companyId ?: ($emp['company_id'] ?? '')), $lt, $emp, $now) : 0.0;

                $rows[] = [
                    $sl++,
                    $emp['employee_code'],
                    trim($emp['employee_name']),
                    $emp['department_name'] ?? 'General',
                    $emp['designation_name'] ?? 'Staff',
                    $joining,
                    $probEnd,
                    $probStatus,
                    $lt['name'],
                    $mode,
                    $allowed ? 'Yes' : 'No',
                    number_format($eligibleDays, 1)
                ];
            }
        }

        return ['headers' => $headers, 'rows' => $rows];
    }

    /**
     * #38 Leave Policy Compliance
     */
    public function leavePolicyCompliance(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Application ID', 'Employee Code', 'Employee Name', 'Department',
            'Leave Type', 'Leave Duration', 'Notice Days Given', 'Sandwich Rule Impact',
            'Consecutive Days', 'Policy Status', 'Audit Compliance Result'
        ];

        $info = $this->getLeaveTableInfo();
        $from = $filters['from'] ?? ($filters['from_date'] ?? date('Y-01-01'));
        $to = $filters['to'] ?? ($filters['to_date'] ?? date('Y-m-d'));
        $deptId = $filters['department_id'] ?? null;

        $hasSandwich = in_array('sandwich_rule_applies', $info['cols'], true);
        $sandwichSelect = $hasSandwich ? 'la.sandwich_rule_applies' : '0 AS `sandwich_rule_applies`';

        $builder = $this->db->table($info['table'] . ' la')
            ->select("la.id, {$info['applied_expr']} AS `applied_at`, {$info['from_expr']} AS `from_date`, {$info['to_expr']} AS `to_date`, la.total_days, {$sandwichSelect}, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) AS `employee_name`, d.name AS `department_name`, lt.name AS `leave_type_name`, la.status", false)
            ->join('employees e', 'e.id = la.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('leave_types lt', 'lt.id = la.leave_type_id', 'left')
            ->where("{$info['from_expr']} <=", $to)
            ->where("{$info['to_expr']} >=", $from);

        \App\Services\ReportService::applyStaffScope($builder, (string)$companyId, $filters, 'e');

        $results = $builder->orderBy("{$info['from_expr']}", 'DESC', false)->get()->getResultArray();

        $rows = [];
        $sl = 1;
        foreach ($results as $r) {
            $applied = !empty($r['applied_at']) ? strtotime($r['applied_at']) : strtotime($r['from_date']);
            $start = strtotime($r['from_date']);
            $noticeDays = max(0, (int)floor(($start - $applied) / 86400));
            $days = (float)($r['total_days'] ?? 1);
            $sandwich = !empty($r['sandwich_rule_applies']) ? 'Yes (Weekend Included)' : 'No';

            $compliant = true;
            $flags = [];
            if ($noticeDays < 1 && stripos($r['leave_type_name'] ?? '', 'casual') !== false) {
                $flags[] = 'Short Notice';
            }
            if ($days > 7) {
                $flags[] = 'Long Leave Authorization';
            }
            if (!empty($r['sandwich_rule_applies'])) {
                $flags[] = 'Sandwich Adjusted';
            }

            $auditMsg = empty($flags) ? 'Fully Compliant' : implode('; ', $flags);
            $policyStatus = empty($flags) ? 'Compliant' : 'Flagged for Review';

            $rows[] = [
                $sl++,
                $r['id'] ?? '-',
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                $r['leave_type_name'] ?? 'Leave',
                $r['from_date'] . ' to ' . $r['to_date'],
                $noticeDays . ' day(s)',
                $sandwich,
                number_format($days, 1) . ' days',
                $policyStatus,
                $auditMsg
            ];
        }

        return ['headers' => $headers, 'rows' => $rows];
    }

    /**
     * #39 Leave Overlap / Conflict Report
     */
    public function leaveOverlapConflict(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Conflict Date', 'Department', 'Overlapping Staff Count',
            'Staff On Leave Names', 'Department Total Headcount', 'Active Staff On Duty',
            'Duty Coverage (%)', 'Staffing Shortfall Risk Level'
        ];

        $info = $this->getLeaveTableInfo();
        $from = $filters['from'] ?? ($filters['from_date'] ?? date('Y-m-01'));
        $to = $filters['to'] ?? ($filters['to_date'] ?? date('Y-m-d'));
        $deptId = $filters['department_id'] ?? null;

        $builder = $this->db->table($info['table'] . ' la')
            ->select("la.id, {$info['from_expr']} AS `from_date`, {$info['to_expr']} AS `to_date`, e.department_id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) AS `employee_name`, d.name AS `department_name`", false)
            ->join('employees e', 'e.id = la.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->where('LOWER(la.status)', 'approved')
            ->where("{$info['from_expr']} <=", $to)
            ->where("{$info['to_expr']} >=", $from);

        \App\Services\ReportService::applyStaffScope($builder, (string)$companyId, $filters, 'e');

        $leaves = $builder->get()->getResultArray();

        // Preload department counts
        $deptTotals = [];
        $deptNames = [];
        $dQuery = $this->db->table('employees e')
            ->select('e.department_id, d.name as dept_name, COUNT(e.id) as total')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->where('e.status', 'active');
        \App\Services\ReportService::applyStaffScope($dQuery, (string)$companyId, $filters, 'e');
        foreach ($dQuery->groupBy('e.department_id')->get()->getResultArray() as $row) {
            if (!empty($row['department_id'])) {
                $deptTotals[$row['department_id']] = (int)$row['total'];
                $deptNames[$row['department_id']] = $row['dept_name'] ?? 'General';
            }
        }

        // Map overlaps by date and department
        $dateDeptMap = [];
        foreach ($leaves as $l) {
            $dId = $l['department_id'] ?? 'general';
            $sDate = max($from, $l['from_date']);
            $eDate = min($to, $l['to_date']);

            $curr = strtotime($sDate);
            $end = strtotime($eDate);
            while ($curr <= $end) {
                $dStr = date('Y-m-d', $curr);
                $key = $dStr . '|' . $dId;
                if (!isset($dateDeptMap[$key])) {
                    $dateDeptMap[$key] = [
                        'date'    => $dStr,
                        'dept_id' => $dId,
                        'names'   => [],
                    ];
                }
                $empName = trim($l['employee_name'] ?? $l['employee_code']);
                if (!in_array($empName, $dateDeptMap[$key]['names'], true)) {
                    $dateDeptMap[$key]['names'][] = $empName;
                }
                $curr = strtotime('+1 day', $curr);
            }
        }

        $rows = [];
        $sl = 1;
        foreach ($dateDeptMap as $item) {
            $count = count($item['names']);
            $dId = $item['dept_id'];
            $headcount = $deptTotals[$dId] ?? 10;
            $activeStaff = max(0, $headcount - $count);
            $coveragePct = ($headcount > 0) ? round(($activeStaff / $headcount) * 100, 1) : 100.0;

            $risk = 'Low';
            if ($coveragePct < 50.0 || $count >= 3) {
                $risk = 'High Risk - Critical Shortage';
            } elseif ($coveragePct < 75.0 || $count >= 2) {
                $risk = 'Moderate Risk';
            }

            $rows[] = [
                $sl++,
                $item['date'],
                $deptNames[$dId] ?? 'Department',
                $count,
                implode(', ', $item['names']),
                $headcount,
                $activeStaff,
                $coveragePct . '%',
                $risk
            ];
        }

        // If no overlapping records found, show clean message row
        if (empty($rows)) {
            $rows[] = [
                1,
                date('Y-m-d'),
                'All Departments',
                0,
                'None',
                'N/A',
                'N/A',
                '100%',
                'Low Risk - Zero Overlaps'
            ];
        }

        return ['headers' => $headers, 'rows' => $rows];
    }

    /**
     * #40 Leave Approval History
     */
    public function leaveApprovalHistory(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Application ID', 'Employee Code', 'Employee Name', 'Department',
            'Leave Type', 'Leave Dates', 'Days', 'Submission Time', 'Final Status',
            'Decision Maker', 'Decision Timestamp', 'Turnaround Time (Hours)', 'Approver Remarks'
        ];

        $info = $this->getLeaveTableInfo();
        $from = $filters['from'] ?? ($filters['from_date'] ?? date('Y-01-01'));
        $to = $filters['to'] ?? ($filters['to_date'] ?? date('Y-m-d'));
        $deptId = $filters['department_id'] ?? null;

        $hasRejReason = in_array('rejection_reason', $info['cols'], true);
        $rejSelect = $hasRejReason ? 'la.rejection_reason' : "'' AS `rejection_reason`";

        $builder = $this->db->table($info['table'] . ' la')
            ->select("la.id, {$info['applied_expr']} AS `applied_at`, {$info['from_expr']} AS `from_date`, {$info['to_expr']} AS `to_date`, la.total_days, la.status, la.approved_by, la.approved_at, la.updated_at, {$rejSelect}, la.reason, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) AS `employee_name`, d.name AS `department_name`, lt.name AS `leave_type_name`", false)
            ->join('employees e', 'e.id = la.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('leave_types lt', 'lt.id = la.leave_type_id', 'left')
            ->where("{$info['from_expr']} <=", $to)
            ->where("{$info['to_expr']} >=", $from);

        \App\Services\ReportService::applyStaffScope($builder, (string)$companyId, $filters, 'e');

        $results = $builder->orderBy("{$info['from_expr']}", 'DESC', false)->get()->getResultArray();
        $rows = [];
        $sl = 1;
        foreach ($results as $r) {
            $appliedTime = !empty($r['applied_at']) ? strtotime($r['applied_at']) : strtotime($r['from_date']);
            $decisionTime = !empty($r['approved_at']) ? strtotime($r['approved_at']) : (!empty($r['updated_at']) ? strtotime($r['updated_at']) : $appliedTime);

            $turnaroundHours = max(0, round(($decisionTime - $appliedTime) / 3600, 1));
            $period = ($r['from_date'] === $r['to_date']) ? $r['from_date'] : ($r['from_date'] . ' to ' . $r['to_date']);
            $remarks = !empty($r['rejection_reason']) ? $r['rejection_reason'] : (!empty($r['reason']) ? $r['reason'] : 'Approved as per leave policy');

            $rows[] = [
                $sl++,
                $r['id'] ?? '-',
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                $r['leave_type_name'] ?? 'Leave',
                $period,
                number_format((float)($r['total_days'] ?? 1), 1),
                date('Y-m-d H:i', $appliedTime),
                ucfirst(strtolower($r['status'] ?? 'Pending')),
                $r['approved_by'] ?: 'Management Authority',
                date('Y-m-d H:i', $decisionTime),
                $turnaroundHours . ' hrs',
                $remarks
            ];
        }

        return ['headers' => $headers, 'rows' => $rows];
    }

    /**
     * Authoritatively resolve days_per_year for a leave type from Single Rule Store (LEAVE domain).
     * Strictly throws RuleNotConfiguredException if rule is missing or unconfigured (Global Rule 4).
     */
    protected function resolveDaysPerYear(string $companyId, array $lt, ?array $emp = null, ?string $asOfDate = null): float
    {
        $asOfDate = $asOfDate ?: date('Y-m-d');
        if (!empty($companyId)) {
            try {
                $leaveRule = (new RuleResolver())->resolve($companyId, 'LEAVE', $asOfDate, $emp ?: []);
                $entitlements = (array)$leaveRule->get('entitlements');
                $code = strtoupper(trim((string)($lt['code'] ?? '')));
                $name = $lt['name'] ?? null;
                foreach ($entitlements as $ent) {
                    $entCode = strtoupper(trim((string)($ent['leave_type_code'] ?? '')));
                    if (LeaveService::matchLeaveTypeCode($code, $entCode, $name)) {
                        if (isset($ent['days_per_year']) && is_numeric($ent['days_per_year'])) {
                            return (float)$ent['days_per_year'];
                        }
                    }
                }
            } catch (RuleNotConfiguredException $e) {
                throw $e;
            } catch (\Throwable $e) {
                // fall through to check master record or throw
            }
        }

        if (isset($lt['days_per_year']) && is_numeric($lt['days_per_year'])) {
            return (float)$lt['days_per_year'];
        }

        throw new RuleNotConfiguredException(
            "Leave entitlement days_per_year not configured for leave type '" . ($lt['code'] ?? 'UNKNOWN') . "'",
            $companyId,
            'LEAVE',
            $asOfDate
        );
    }
}
