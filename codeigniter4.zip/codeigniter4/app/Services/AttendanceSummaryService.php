<?php

namespace App\Services;

use App\Models\EmployeeModel;
use App\Models\HolidayModel;
use App\Services\CompanyWeekendService;
use Config\Database;

/**
 * Class AttendanceSummaryService
 *
 * Authoritative single calculation service for all attendance summaries across the entire HRMS.
 * Every Attendance tab (Overview, Today's Muster, Group Matrix, Live Simulation Console, Monthly Muster)
 * consumes this shared service to ensure 100% mathematical parity.
 */
class AttendanceSummaryService
{
    public const MAX_RANGE_DAYS = 62;

    protected $db;

    public function __construct()
    {
        $this->db = Database::connect();
    }

    /**
     * Authoritative single point of classification for one employee on one date.
     * Every employee-day belongs to exactly ONE primary bucket:
     * - 'Present'
     * - 'Half Day'
     * - 'On Leave'
     * - 'Holiday'
     * - 'Weekly Off'
     * - 'Absent'
     * - 'Missing Punch'
     * - 'Not Joined' (excluded from totals)
     *
     * @param array $emp Employee record (associative array)
     * @param string $date Date in YYYY-MM-DD
     * @param array|null $log Attendance log record (or null if unpunched)
     * @param array $ctx Preloaded context lookups (holidays, leaves, weekly_off, duty_assignments, today, etc.)
     * @return array
     */
    public static function classifyDay(array $emp, string $date, ?array $log, array $ctx): array
    {
        $today = $ctx['today'] ?? date('Y-m-d');
        $isFuture = ($date > $today);
        $isPast   = ($date < $today);
        $isToday  = ($date === $today);

        // 1. Joining Date Gate: Not Joined employees are excluded from totals
        $joinDate = null;
        if (function_exists('employee_joining_date')) {
            $joinDate = employee_joining_date($emp);
        }
        if (empty($joinDate)) {
            $joinDate = $emp['joining_date'] ?? ($emp['join_date'] ?? ($emp['employment_start_date'] ?? null));
        }
        if (empty($joinDate) && !empty($emp['created_at'])) {
            $joinDate = substr((string)$emp['created_at'], 0, 10);
        }

        if (!empty($joinDate) && $date < $joinDate) {
            return [
                'bucket'                 => 'Not Joined',
                'status'                 => 'Not Joined',
                'flags'                  => [
                    'late'             => false,
                    'early_out'        => false,
                    'off_day_worked'   => false,
                    'test_punch'       => false,
                    'leave_with_punch' => false,
                    'is_holiday'       => false,
                    'is_weekly_off'    => false,
                    'is_future'        => $isFuture,
                ],
                'minutes'                => [
                    'late_minutes'      => 0,
                    'early_out_minutes' => 0,
                    'work_minutes'      => 0,
                ],
                'hours'                  => [
                    'working_hours'  => 0.0,
                    'overtime_hours' => 0.0,
                ],
                'payable_credit'         => 0.0,
                'off_day_worked_credit'  => 0.0,
                'warning'                => null,
                'check_in'               => null,
                'check_out'              => null,
            ];
        }

        // 2. Identify Test Punches
        $isTestPunch = false;
        if (!empty($log)) {
            $vMethod = (string)($log['verification_method'] ?? '');
            $rem     = (string)($log['remarks'] ?? ($log['notes'] ?? ''));
            if ($vMethod === 'Live Test' || $vMethod === 'SOURCE_LIVE_TEST' || str_contains($rem, '[TEST]')) {
                $isTestPunch = true;
            }
        }
        $includeTest = !empty($ctx['include_test_punches']);
        // If it's a test punch and test punches are excluded, disregard the log for calculation
        $effectiveLog = ($isTestPunch && !$includeTest) ? null : $log;

        // 3. Resolve Off-Day Status (Holiday, Weekly Off, Duty Assignment)
        $empId     = (string)($emp['id'] ?? '');
        $empCode   = (string)($emp['employee_code'] ?? '');
        $dayOfWeek = date('l', strtotime($date));

        // Company-scoped holiday check
        $holidayInfo = null;
        if (isset($ctx['holidays'][$date])) {
            $holidayInfo = $ctx['holidays'][$date];
        } elseif (!empty($ctx['holidays'])) {
            foreach ($ctx['holidays'] as $h) {
                $hStart = $h['from_date'] ?? ($h['date'] ?? '');
                $hEnd   = $h['to_date'] ?? ($h['date'] ?? $hStart);
                if ($date >= $hStart && $date <= $hEnd) {
                    $holidayInfo = $h;
                    break;
                }
            }
        }
        $isHoliday = ($holidayInfo !== null);

        // Weekly Off check (resolved per employee, never hard-coded to Friday)
        $weeklyOffDays = $ctx['weekly_off'][$empId] ?? ($ctx['weekly_off'][$empCode] ?? ($ctx['default_weekly_off'] ?? []));
        $isWeeklyOff = in_array($dayOfWeek, $weeklyOffDays, true);

        // Duty assignment check
        $duty = $ctx['duty_assignments'][$empId][$date] ?? ($ctx['duty_assignments'][$empCode][$date] ?? null);
        $hasConfirmedDuty = ($duty && in_array($duty['status'] ?? '', ['Assigned', 'Confirmed', 'Completed'], true));

        $isOffDay = ($isHoliday || $isWeeklyOff);

        // 4. Approved Leave Check
        $leave = $ctx['leaves'][$empId][$date] ?? ($ctx['leaves'][$empCode][$date] ?? null);
        if (!$leave && !empty($ctx['leaves_raw'])) {
            foreach ($ctx['leaves_raw'] as $lvr) {
                if (((string)($lvr['employee_id'] ?? '') === $empId || (string)($lvr['employee_id'] ?? '') === $empCode)
                    && $date >= $lvr['start_date'] && $date <= $lvr['end_date']) {
                    $leave = $lvr;
                    break;
                }
            }
        }
        $hasLeave = ($leave !== null);

        // 5. Evaluate Punch Data
        $checkIn  = $effectiveLog['check_in'] ?? ($effectiveLog['in_time'] ?? null);
        $checkOut = $effectiveLog['check_out'] ?? ($effectiveLog['out_time'] ?? null);
        if (!$checkIn && !empty($effectiveLog['clock_in'])) {
            $checkIn = date('H:i:s', strtotime($effectiveLog['clock_in']));
        }
        if (!$checkOut && !empty($effectiveLog['clock_out'])) {
            $checkOut = date('H:i:s', strtotime($effectiveLog['clock_out']));
        }
        if ($checkIn === '--:--:--' || $checkIn === '--:--' || $checkIn === '---' || trim((string)$checkIn) === '') {
            $checkIn = null;
        }
        if ($checkOut === '--:--:--' || $checkOut === '--:--' || $checkOut === '---' || trim((string)$checkOut) === '') {
            $checkOut = null;
        }
        $isClosure = \App\Models\AttendanceModel::isClosureLog($effectiveLog);
        $hasPunch = ($checkIn !== null || $checkOut !== null);

        $warning = null;
        $leaveWithPunch = false;
        if ($hasPunch && $hasLeave) {
            $warning = "Employee has approved leave but recorded attendance punches.";
            $leaveWithPunch = true;
        }

        // 6. Primary Bucket Resolution (Mutually Exclusive)
        if ($hasPunch || $isClosure) {
            // Check for Missing Punch anomaly:
            // An unclosed punch on a past day, or check-out without check-in (never Missing Punch on a closure row)
            $isMissingPunch = false;
            if (!$isClosure) {
                if ($isPast && $checkIn !== null && $checkOut === null) {
                    $isMissingPunch = true;
                } elseif ($checkIn === null && $checkOut !== null) {
                    $isMissingPunch = true;
                } elseif (($effectiveLog['status'] ?? '') === 'Missing Punch') {
                    $isMissingPunch = true;
                }
            }

            if ($isMissingPunch) {
                return [
                    'bucket'                 => 'Missing Punch',
                    'status'                 => 'Missing Punch',
                    'flags'                  => [
                        'late'             => false,
                        'early_out'        => false,
                        'off_day_worked'   => $isOffDay,
                        'test_punch'       => $isTestPunch,
                        'leave_with_punch' => $leaveWithPunch,
                        'is_holiday'       => $isHoliday,
                        'is_weekly_off'    => $isWeeklyOff,
                        'is_future'        => false,
                    ],
                    'minutes'                => [
                        'late_minutes'      => 0,
                        'early_out_minutes' => 0,
                        'work_minutes'      => 0,
                    ],
                    'hours'                  => [
                        'working_hours'  => 0.0,
                        'overtime_hours' => 0.0,
                    ],
                    'payable_credit'         => 0.0,
                    'off_day_worked_credit'  => 0.0,
                    'warning'                => $warning ?? 'Incomplete punches recorded on date.',
                    'check_in'               => $checkIn,
                    'check_out'              => $checkOut,
                ];
            }

            // Punch is Present or Half Day
            $workingHours    = (float)($effectiveLog['working_hours'] ?? ($effectiveLog['net_hours'] ?? 0.0));
            $overtimeHours   = (float)($effectiveLog['overtime_hours'] ?? 0.0);
            $lateMinutes     = (int)($effectiveLog['late_minutes'] ?? 0);
            $earlyOutMinutes = $isClosure ? 0 : (int)($effectiveLog['early_out_minutes'] ?? 0);

            if ($workingHours <= 0.0 && $checkIn !== null && $checkOut !== null) {
                $tIn = strtotime($date . ' ' . $checkIn);
                $tOut = strtotime($date . ' ' . $checkOut);
                if ($tOut < $tIn) {
                    $tOut += 86400; // overnight / cross-midnight shift
                }
                if ($tOut > $tIn) {
                    $workingHours = round(($tOut - $tIn) / 3600, 2);
                }
            }
            if ($isClosure && $workingHours <= 0.0 && !empty($effectiveLog['closure_credit_hours'])) {
                $workingHours = round((float)$effectiveLog['closure_credit_hours'], 2);
            }

            $halfDayThreshold = 4.0;
            $isHalfDay = !$isClosure && (($effectiveLog['status'] ?? '') === 'Half Day' || ($checkOut !== null && $workingHours > 0.0 && $workingHours < $halfDayThreshold));

            $isLate = ($lateMinutes > 0 || in_array($effectiveLog['status'] ?? '', ['Late', 'Late & Early Out'], true));
            $isEarlyOut = !$isClosure && ($earlyOutMinutes > 0 || in_array($effectiveLog['status'] ?? '', ['Early Out', 'Late & Early Out'], true));
            $offDayWorked = $isOffDay;

            if ($isClosure) {
                $bucket = 'Present';
                $status = $isLate ? 'Late' : 'Present (Early Closure)';
                $payableCredit = 1.0;
            } elseif ($isHalfDay) {
                $bucket = 'Half Day';
                $status = 'Half Day';
                $payableCredit = 0.5;
            } else {
                $bucket = 'Present';
                if ($isLate && $isEarlyOut) {
                    $status = 'Late & Early Out';
                } elseif ($isLate) {
                    $status = 'Late';
                } elseif ($isEarlyOut) {
                    $status = 'Early Out';
                } elseif ($offDayWorked) {
                    $status = $isHoliday ? 'Holiday Duty Present' : 'Weekend Duty Present';
                } else {
                    $status = ($effectiveLog['status'] ?? '') === 'Present (Unscheduled)' ? 'Present (Unscheduled)' : 'Present';
                }
                $payableCredit = 1.0;
            }

            return [
                'bucket'                 => $bucket,
                'status'                 => $status,
                'flags'                  => [
                    'late'             => $isLate,
                    'early_out'        => $isEarlyOut,
                    'off_day_worked'   => $offDayWorked,
                    'test_punch'       => $isTestPunch,
                    'leave_with_punch' => $leaveWithPunch,
                    'is_holiday'       => $isHoliday,
                    'is_weekly_off'    => $isWeeklyOff,
                    'is_future'        => $isFuture,
                ],
                'minutes'                => [
                    'late_minutes'      => $lateMinutes,
                    'early_out_minutes' => $earlyOutMinutes,
                    'work_minutes'      => (int)round($workingHours * 60),
                ],
                'hours'                  => [
                    'working_hours'  => $workingHours,
                    'overtime_hours' => $overtimeHours,
                ],
                'payable_credit'         => $payableCredit,
                'off_day_worked_credit'  => $offDayWorked ? 1.0 : 0.0,
                'warning'                => $warning,
                'check_in'               => $checkIn,
                'check_out'              => $checkOut,
            ];
        }

        // 7. No Punch: Evaluate Off-Days, Leaves, or Absence
        // Rule: Off-day (Holiday or Weekly Off) beats Absent. Leave on an off-day is NOT counted as leave.
        if ($isOffDay) {
            if ($isHoliday) {
                $bucket = 'Holiday';
                $status = !empty($holidayInfo['name']) ? $holidayInfo['name'] : 'Holiday';
            } else {
                $bucket = 'Weekly Off';
                $status = 'Weekly Off';
            }

            return [
                'bucket'                 => $bucket,
                'status'                 => $status,
                'flags'                  => [
                    'late'             => false,
                    'early_out'        => false,
                    'off_day_worked'   => false,
                    'test_punch'       => false,
                    'leave_with_punch' => false,
                    'is_holiday'       => $isHoliday,
                    'is_weekly_off'    => $isWeeklyOff,
                    'is_future'        => $isFuture,
                ],
                'minutes'                => [
                    'late_minutes'      => 0,
                    'early_out_minutes' => 0,
                    'work_minutes'      => 0,
                ],
                'hours'                  => [
                    'working_hours'  => 0.0,
                    'overtime_hours' => 0.0,
                ],
                'payable_credit'         => 1.0,
                'off_day_worked_credit'  => 0.0,
                'warning'                => null,
                'check_in'               => null,
                'check_out'              => null,
            ];
        }

        // Regular Working Day without Punch
        if ($hasLeave) {
            $isPaid = true;
            if (isset($leave['leave_is_paid'])) {
                $isPaid = (bool)$leave['leave_is_paid'];
            } elseif (isset($leave['is_paid'])) {
                $isPaid = (bool)$leave['is_paid'];
            }

            return [
                'bucket'                 => 'On Leave',
                'status'                 => $leave['leave_type_name'] ?? 'On Leave',
                'flags'                  => [
                    'late'             => false,
                    'early_out'        => false,
                    'off_day_worked'   => false,
                    'test_punch'       => false,
                    'leave_with_punch' => false,
                    'is_holiday'       => false,
                    'is_weekly_off'    => false,
                    'is_future'        => $isFuture,
                ],
                'minutes'                => [
                    'late_minutes'      => 0,
                    'early_out_minutes' => 0,
                    'work_minutes'      => 0,
                ],
                'hours'                  => [
                    'working_hours'  => 0.0,
                    'overtime_hours' => 0.0,
                ],
                'payable_credit'         => $isPaid ? 1.0 : 0.0,
                'off_day_worked_credit'  => 0.0,
                'warning'                => null,
                'check_in'               => null,
                'check_out'              => null,
            ];
        }

        // Regular Working Day: No punch and no leave
        if ($isFuture) {
            $bucket = 'Upcoming';
            $status = 'Upcoming';
            $payableCredit = 0.0;
        } elseif (($effectiveLog['status'] ?? '') === 'Unscheduled') {
            $bucket = 'Unscheduled';
            $status = 'Unscheduled';
            $payableCredit = 0.0;
        } elseif (($effectiveLog['status'] ?? '') === 'Day Off' || ($effectiveLog['status'] ?? '') === 'Off-Day') {
            $bucket = 'Weekly Off';
            $status = 'Day Off';
            $payableCredit = 1.0;
        } else {
            $bucket = 'Absent';
            $status = 'Absent';
            $payableCredit = 0.0;
        }

        return [
            'bucket'                 => $bucket,
            'status'                 => $status,
            'flags'                  => [
                'late'             => false,
                'early_out'        => false,
                'off_day_worked'   => false,
                'test_punch'       => false,
                'leave_with_punch' => false,
                'is_holiday'       => false,
                'is_weekly_off'    => false,
                'is_future'        => $isFuture,
            ],
            'minutes'                => [
                'late_minutes'      => 0,
                'early_out_minutes' => 0,
                'work_minutes'      => 0,
            ],
            'hours'                  => [
                'working_hours'  => 0.0,
                'overtime_hours' => 0.0,
            ],
            'payable_credit'         => $payableCredit,
            'off_day_worked_credit'  => 0.0,
            'warning'                => null,
            'check_in'               => null,
            'check_out'              => null,
        ];
    }

    /**
     * Compute authoritative attendance summary for a single date across eligible active staff.
     */
    public function forDate(string $date, array $filters = []): array
    {
        $companyId   = $filters['company_id'] ?? null;
        $branchId    = $filters['branch_id'] ?? null;
        $deptId      = $filters['department_id'] ?? ($filters['dept_id'] ?? null);
        $shiftId     = $filters['shift_id'] ?? null;
        $search      = $filters['search'] ?? null;
        $statusFilter= $filters['status'] ?? ($filters['statusFilter'] ?? null);

        // 1. Fetch eligible active employees
        $empBuilder = $this->db->table('employees')
            ->select('employees.*, departments.name as department_name, branches.name as branch_name, designations.name as designation_name, shifts.name as shift_name, shifts.start_time, shifts.end_time, shifts.weekly_off as shift_weekly_off')
            ->join('departments', 'departments.id = employees.department_id', 'left')
            ->join('branches', 'branches.id = employees.branch_id', 'left')
            ->join('designations', 'designations.id = employees.designation_id', 'left')
            ->join('shifts', 'shifts.id = employees.shift_id', 'left');

        $empModel = new \App\Models\EmployeeModel();
        $empModel->applyEmploymentTenureFilter($empBuilder, $date, 'employees');
        if ($this->db->fieldExists('deleted_at', 'employees')) {
            $empBuilder->where('employees.deleted_at IS NULL');
        }

        if (!empty($companyId)) {
            $empBuilder->where('employees.company_id', $companyId);
        }
        if (!empty($branchId)) {
            $empBuilder->where('employees.branch_id', $branchId);
        }
        if (!empty($deptId)) {
            // Strict department matching: employees with empty department NEVER pass a department filter
            $empBuilder->where('employees.department_id', $deptId);
        }
        if (!empty($shiftId)) {
            $empBuilder->where('employees.shift_id', $shiftId);
        }
        if (!empty($filters['employee_id'])) {
            $empBuilder->groupStart()
                ->where('employees.id', $filters['employee_id'])
                ->orWhere('employees.employee_code', $filters['employee_id'])
            ->groupEnd();
        }

        $allActive = $empBuilder->orderBy('employees.first_name', 'ASC')->get()->getResultArray();

        // 2. Preload Batch Context
        $empIds = [];
        $empCodes = [];
        foreach ($allActive as $ae) {
            $id = (string)($ae['id'] ?? '');
            if ($id) $empIds[] = $id;
            $code = (string)($ae['employee_code'] ?? '');
            if ($code) $empCodes[] = $code;
        }

        $ctx = $this->preloadContext($allActive, $date, $date, $companyId, $filters);

        // 3. Classify Each Employee and Collect Metrics
        $eligibleEmployees = [];
        $detailedLogs      = [];
        $warnings          = [];

        $presentCount     = 0;
        $halfDayCount     = 0;
        $onLeaveCount     = 0;
        $holidayCount     = 0;
        $weeklyOffCount   = 0;
        $absentCount      = 0;
        $missingPunchCount= 0;
        $lateCount        = 0;
        $earlyOutCount    = 0;
        $offDayWorkedCount= 0;
        $checkedInCount   = 0;
        $checkedOutCount  = 0;

        $totWorkingHours  = 0.0;
        $totOvertimeHours = 0.0;
        $totLateMinutes   = 0;
        $totEarlyOutMins  = 0;

        foreach ($allActive as $emp) {
            $eId   = (string)($emp['id'] ?? '');
            $eCode = (string)($emp['employee_code'] ?? '');

            $log = $ctx['logs'][$eId] ?? ($ctx['logs'][$eCode] ?? null);

            $classification = self::classifyDay($emp, $date, $log, $ctx);

            // Skip Not Joined
            if ($classification['bucket'] === 'Not Joined') {
                continue;
            }

            $eligibleEmployees[] = $emp;

            $b = $classification['bucket'];
            if ($b === 'Present') {
                $presentCount++;
            } elseif ($b === 'Half Day') {
                $halfDayCount++;
            } elseif ($b === 'On Leave') {
                $onLeaveCount++;
            } elseif ($b === 'Holiday') {
                $holidayCount++;
            } elseif ($b === 'Weekly Off') {
                $weeklyOffCount++;
            } elseif ($b === 'Absent') {
                $absentCount++;
            } elseif ($b === 'Missing Punch') {
                $missingPunchCount++;
            }

            if (!empty($classification['flags']['late'])) {
                $lateCount++;
            }
            if (!empty($classification['flags']['early_out'])) {
                $earlyOutCount++;
            }
            if (!empty($classification['flags']['off_day_worked'])) {
                $offDayWorkedCount++;
            }

            if (!empty($classification['check_in'])) {
                $checkedInCount++;
            }
            if (!empty($classification['check_out'])) {
                $checkedOutCount++;
            }

            $totWorkingHours  += (float)($classification['hours']['working_hours'] ?? 0);
            $totOvertimeHours += (float)($classification['hours']['overtime_hours'] ?? 0);
            $totLateMinutes   += (int)($classification['minutes']['late_minutes'] ?? 0);
            $totEarlyOutMins  += (int)($classification['minutes']['early_out_minutes'] ?? 0);

            if (!empty($classification['warning'])) {
                $warnings[] = [
                    'employee_id'   => $eId,
                    'employee_name' => trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')),
                    'date'          => $date,
                    'warning'       => $classification['warning']
                ];
            }

            $fName = trim($emp['first_name'] ?? '');
            $lName = trim($emp['last_name'] ?? '');
            $fullName = trim($fName . ' ' . $lName) ?: ($emp['name'] ?? ($emp['employee_code'] ?? 'Staff'));

            $detailedLogs[] = [
                'id'                  => $log['id'] ?? ('syn-' . $eId . '-' . $date),
                'attendance_id'       => $log['id'] ?? ('syn-' . $eId . '-' . $date),
                'employee_id'         => $eId,
                'employee_code'       => $emp['employee_code'] ?? $eId,
                'employee_name'       => $fullName,
                'department_id'       => $emp['department_id'] ?? '',
                'department_name'     => $emp['department_name'] ?? 'General',
                'branch_id'           => $emp['branch_id'] ?? '',
                'branch_name'         => $emp['branch_name'] ?? 'Main Office',
                'designation_id'      => $emp['designation_id'] ?? '',
                'designation_name'    => $emp['designation_name'] ?? 'Staff',
                'shift_name'          => $emp['shift_name'] ?? 'General Shift',
                'date'                => $date,
                'attendance_date'     => $date,
                'check_in'            => $classification['check_in'] ?: '--:--:--',
                'check_out'           => $classification['check_out'] ?: '--:--:--',
                'working_hours'       => $classification['hours']['working_hours'],
                'overtime_hours'      => $classification['hours']['overtime_hours'],
                'late_minutes'        => $classification['minutes']['late_minutes'],
                'early_out_minutes'   => $classification['minutes']['early_out_minutes'],
                'status'              => $classification['status'],
                'bucket'              => $classification['bucket'],
                'is_late'             => !empty($classification['flags']['late']),
                'is_early_out'        => !empty($classification['flags']['early_out']),
                'off_day_worked'      => !empty($classification['flags']['off_day_worked']),
                'verification_method' => $log['verification_method'] ?? 'Web',
                'photo'               => $emp['photo'] ?? null,
                'avatar'              => $emp['photo'] ?? null,
                'payable_credit'      => $classification['payable_credit'],
                'is_company_closure'  => (int)(\App\Models\AttendanceModel::isClosureLog($log) ? 1 : 0),
                'closure_credit_hours'=> (float)($log['closure_credit_hours'] ?? 0.0),
            ];
        }

        $totalActive = count($eligibleEmployees);
        // Headcount Present Total = Present + Half Day
        $presentTotal = $presentCount + $halfDayCount;
        $presenceRate = $totalActive > 0 ? round(($presentTotal / $totalActive) * 100, 1) : 0.0;
        $punctualityRate = $presentTotal > 0 ? round((max(0, $presentTotal - $lateCount) / $presentTotal) * 100, 1) : 100.0;

        $unmappedBiometricCount = $ctx['unmapped_biometric_count'] ?? 0;

        $stats = [
            'totalActive'              => $totalActive,
            'totalEmployees'           => $totalActive,
            'total_active'             => $totalActive,
            'total_employees'          => $totalActive,
            'present'                  => $presentCount,
            'present_total'            => $presentTotal,
            'presentTotal'             => $presentTotal,
            'halfDay'                  => $halfDayCount,
            'half_day'                 => $halfDayCount,
            'half_day_count'           => $halfDayCount,
            'late'                     => $lateCount,
            'late_count'               => $lateCount,
            'earlyOut'                 => $earlyOutCount,
            'early_out'                => $earlyOutCount,
            'early_out_count'          => $earlyOutCount,
            'onLeave'                  => $onLeaveCount,
            'on_leave'                 => $onLeaveCount,
            'on_leave_count'           => $onLeaveCount,
            'holiday'                  => $holidayCount,
            'holiday_count'            => $holidayCount,
            'weeklyOff'                => $weeklyOffCount,
            'weekly_off_count'         => $weeklyOffCount,
            'absent'                   => $absentCount,
            'absent_count'             => $absentCount,
            'missingPunch'             => $missingPunchCount,
            'missing_punch'            => $missingPunchCount,
            'missing_punch_count'      => $missingPunchCount,
            'offDayWorked'             => $offDayWorkedCount,
            'off_day_worked'           => $offDayWorkedCount,
            'off_day_worked_days'      => $offDayWorkedCount,
            'checkedIn'                => $checkedInCount,
            'checked_in'               => $checkedInCount,
            'checkedOut'               => $checkedOutCount,
            'checked_out'              => $checkedOutCount,
            'totalWorkingHours'        => round($totWorkingHours, 1),
            'totalWorkedHours'         => round($totWorkingHours, 1),
            'total_working_hours'      => round($totWorkingHours, 1),
            'hours'                    => round($totWorkingHours, 1),
            'totalOvertime'            => round($totOvertimeHours, 1),
            'totalOvertimeHours'       => round($totOvertimeHours, 1),
            'total_overtime'           => round($totOvertimeHours, 1),
            'overtime'                 => round($totOvertimeHours, 1),
            'totalLateMinutes'         => $totLateMinutes,
            'total_late_minutes'       => $totLateMinutes,
            'totalEarlyOutMinutes'     => $totEarlyOutMins,
            'total_early_out_minutes'  => $totEarlyOutMins,
            'presenceRate'             => $presenceRate,
            'presence_rate'            => $presenceRate,
            'attendanceRate'           => $presenceRate,
            'punctualityRate'          => $punctualityRate,
            'punctuality_rate'         => $punctualityRate,
            'unmappedBiometricCount'   => $unmappedBiometricCount,
            'unmapped_biometric_count' => $unmappedBiometricCount,
        ];

        // Apply Status / Search filter to detailed logs for UI
        $filteredLogs = $detailedLogs;
        if (!empty($statusFilter) && $statusFilter !== 'all') {
            $filteredLogs = array_values(array_filter($filteredLogs, function ($item) use ($statusFilter) {
                if ($statusFilter === 'Present') {
                    return in_array($item['bucket'], ['Present', 'Half Day'], true);
                }
                if ($statusFilter === 'Late') {
                    return !empty($item['is_late']);
                }
                if ($statusFilter === 'Early Out') {
                    return !empty($item['is_early_out']);
                }
                return strcasecmp($item['bucket'], $statusFilter) === 0 || strcasecmp($item['status'], $statusFilter) === 0;
            }));
        }

        if (!empty($search)) {
            $s = strtolower(trim($search));
            $filteredLogs = array_values(array_filter($filteredLogs, function ($item) use ($s) {
                return str_contains(strtolower($item['employee_name'] ?? ''), $s)
                    || str_contains(strtolower($item['employee_code'] ?? ''), $s)
                    || str_contains(strtolower($item['department_name'] ?? ''), $s);
            }));
        }

        return [
            'date'                   => $date,
            'is_range'               => false,
            'stats'                  => $stats,
            'employees'              => $eligibleEmployees,
            'detailedLogs'           => $filteredLogs,
            'allDetailedLogs'        => $detailedLogs,
            'records'                => $filteredLogs,
            'allRecords'             => $detailedLogs,
            'warnings'               => $warnings,
            'unmappedBiometricCount' => $unmappedBiometricCount,
        ];
    }

    /**
     * Compute authoritative attendance summary across a date range.
     * Uses the exact same classifyDay for every employee x date.
     * Explicitly reports truncation if the range exceeds MAX_RANGE_DAYS.
     */
    public function forRange(string $from, string $to, array $filters = []): array
    {
        if ($from > $to) {
            $tmp = $from;
            $from = $to;
            $to = $tmp;
        }

        $startTs = strtotime($from);
        $endTs   = strtotime($to);
        $totalDays = (int)(($endTs - $startTs) / 86400) + 1;

        $isTruncated = false;
        $truncationMessage = null;
        if ($totalDays > self::MAX_RANGE_DAYS) {
            $cappedEndTs = $startTs + ((self::MAX_RANGE_DAYS - 1) * 86400);
            $cappedTo = date('Y-m-d', $cappedEndTs);
            $isTruncated = true;
            $truncationMessage = "Date range ({$totalDays} days) exceeds maximum limit of " . self::MAX_RANGE_DAYS . " days. Data is displayed from {$from} to {$cappedTo}.";
            $endTs = $cappedEndTs;
            $to = $cappedTo;
            $totalDays = self::MAX_RANGE_DAYS;
        }

        $companyId   = $filters['company_id'] ?? null;
        $branchId    = $filters['branch_id'] ?? null;
        $deptId      = $filters['department_id'] ?? ($filters['dept_id'] ?? null);
        $shiftId     = $filters['shift_id'] ?? null;
        $search      = $filters['search'] ?? null;
        $statusFilter= $filters['status'] ?? ($filters['statusFilter'] ?? null);

        // 1. Fetch eligible active employees
        $empBuilder = $this->db->table('employees')
            ->select('employees.*, departments.name as department_name, branches.name as branch_name, designations.name as designation_name, shifts.name as shift_name, shifts.start_time, shifts.end_time, shifts.weekly_off as shift_weekly_off')
            ->join('departments', 'departments.id = employees.department_id', 'left')
            ->join('branches', 'branches.id = employees.branch_id', 'left')
            ->join('designations', 'designations.id = employees.designation_id', 'left')
            ->join('shifts', 'shifts.id = employees.shift_id', 'left');

        $empModel = new \App\Models\EmployeeModel();
        $empModel->applyEmploymentTenureRangeFilter($empBuilder, $fromDate, $toDate, 'employees');
        if ($this->db->fieldExists('deleted_at', 'employees')) {
            $empBuilder->where('employees.deleted_at IS NULL');
        }

        if (!empty($companyId)) {
            $empBuilder->where('employees.company_id', $companyId);
        }
        if (!empty($branchId)) {
            $empBuilder->where('employees.branch_id', $branchId);
        }
        if (!empty($deptId)) {
            $empBuilder->where('employees.department_id', $deptId);
        }
        if (!empty($shiftId)) {
            $empBuilder->where('employees.shift_id', $shiftId);
        }
        if (!empty($filters['employee_id'])) {
            $empBuilder->groupStart()
                ->where('employees.id', $filters['employee_id'])
                ->orWhere('employees.employee_code', $filters['employee_id'])
            ->groupEnd();
        }

        $allActive = $empBuilder->orderBy('employees.first_name', 'ASC')->get()->getResultArray();

        // 2. Preload Batch Context across entire range
        $ctx = $this->preloadContext($allActive, $from, $to, $companyId, $filters);

        // 3. Classify Each Employee x Date
        $totalEmployeeDays = 0;
        $presentPersonDays = 0;
        $halfDayPersonDays = 0;
        $onLeavePersonDays = 0;
        $holidayPersonDays = 0;
        $weeklyOffPersonDays = 0;
        $absentPersonDays = 0;
        $missingPunchPersonDays = 0;
        $latePersonDays = 0;
        $earlyOutPersonDays = 0;
        $offDayWorkedPersonDays = 0;
        $checkedInPersonDays = 0;
        $checkedOutPersonDays = 0;

        $totWorkingHours  = 0.0;
        $totOvertimeHours = 0.0;
        $totLateMinutes   = 0;
        $totEarlyOutMins  = 0;

        $detailedLogs = [];
        $warnings     = [];

        $uniquePresentEmps = [];
        $uniqueEligibleEmps = [];

        for ($currTs = $startTs; $currTs <= $endTs; $currTs += 86400) {
            $cDate = date('Y-m-d', $currTs);

            foreach ($allActive as $emp) {
                $eId   = (string)($emp['id'] ?? '');
                $eCode = (string)($emp['employee_code'] ?? '');

                $log = $ctx['logs_by_date'][$cDate][$eId] ?? ($ctx['logs_by_date'][$cDate][$eCode] ?? null);

                $classification = self::classifyDay($emp, $cDate, $log, $ctx);

                // Skip if Not Joined as of $cDate
                if ($classification['bucket'] === 'Not Joined') {
                    continue;
                }

                $totalEmployeeDays++;
                $uniqueEligibleEmps[$eId] = true;

                $b = $classification['bucket'];
                if ($b === 'Present') {
                    $presentPersonDays++;
                    $uniquePresentEmps[$eId] = true;
                } elseif ($b === 'Half Day') {
                    $halfDayPersonDays++;
                    $uniquePresentEmps[$eId] = true;
                } elseif ($b === 'On Leave') {
                    $onLeavePersonDays++;
                } elseif ($b === 'Holiday') {
                    $holidayPersonDays++;
                } elseif ($b === 'Weekly Off') {
                    $weeklyOffPersonDays++;
                } elseif ($b === 'Absent') {
                    $absentPersonDays++;
                } elseif ($b === 'Missing Punch') {
                    $missingPunchPersonDays++;
                }

                if (!empty($classification['flags']['late'])) {
                    $latePersonDays++;
                }
                if (!empty($classification['flags']['early_out'])) {
                    $earlyOutPersonDays++;
                }
                if (!empty($classification['flags']['off_day_worked'])) {
                    $offDayWorkedPersonDays++;
                }

                if (!empty($classification['check_in'])) {
                    $checkedInPersonDays++;
                }
                if (!empty($classification['check_out'])) {
                    $checkedOutPersonDays++;
                }

                $totWorkingHours  += (float)($classification['hours']['working_hours'] ?? 0);
                $totOvertimeHours += (float)($classification['hours']['overtime_hours'] ?? 0);
                $totLateMinutes   += (int)($classification['minutes']['late_minutes'] ?? 0);
                $totEarlyOutMins  += (int)($classification['minutes']['early_out_minutes'] ?? 0);

                if (!empty($classification['warning'])) {
                    $warnings[] = [
                        'employee_id'   => $eId,
                        'employee_name' => trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')),
                        'date'          => $cDate,
                        'warning'       => $classification['warning']
                    ];
                }

                $fName = trim($emp['first_name'] ?? '');
                $lName = trim($emp['last_name'] ?? '');
                $fullName = trim($fName . ' ' . $lName) ?: ($emp['name'] ?? ($emp['employee_code'] ?? 'Staff'));

                $detailedLogs[] = [
                    'id'                  => $log['id'] ?? ('syn-' . $eId . '-' . $cDate),
                    'attendance_id'       => $log['id'] ?? ('syn-' . $eId . '-' . $cDate),
                    'employee_id'         => $eId,
                    'employee_code'       => $emp['employee_code'] ?? $eId,
                    'employee_name'       => $fullName,
                    'department_id'       => $emp['department_id'] ?? '',
                    'department_name'     => $emp['department_name'] ?? 'General',
                    'branch_id'           => $emp['branch_id'] ?? '',
                    'branch_name'         => $emp['branch_name'] ?? 'Main Office',
                    'designation_id'      => $emp['designation_id'] ?? '',
                    'designation_name'    => $emp['designation_name'] ?? 'Staff',
                    'shift_name'          => $emp['shift_name'] ?? 'General Shift',
                    'date'                => $cDate,
                    'attendance_date'     => $cDate,
                    'check_in'            => $classification['check_in'] ?: '--:--:--',
                    'check_out'           => $classification['check_out'] ?: '--:--:--',
                    'working_hours'       => $classification['hours']['working_hours'],
                    'overtime_hours'      => $classification['hours']['overtime_hours'],
                    'late_minutes'        => $classification['minutes']['late_minutes'],
                    'early_out_minutes'   => $classification['minutes']['early_out_minutes'],
                    'status'              => $classification['status'],
                    'bucket'              => $classification['bucket'],
                    'is_late'             => !empty($classification['flags']['late']),
                    'is_early_out'        => !empty($classification['flags']['early_out']),
                    'off_day_worked'      => !empty($classification['flags']['off_day_worked']),
                    'verification_method' => $log['verification_method'] ?? 'Web',
                    'photo'               => $emp['photo'] ?? null,
                    'avatar'              => $emp['photo'] ?? null,
                    'payable_credit'      => $classification['payable_credit'],
                    'is_company_closure'  => (int)(\App\Models\AttendanceModel::isClosureLog($log) ? 1 : 0),
                    'closure_credit_hours'=> (float)($log['closure_credit_hours'] ?? 0.0),
                ];
            }
        }

        $totalActive = count($uniqueEligibleEmps);
        $presentTotalPersonDays = $presentPersonDays + $halfDayPersonDays;
        $presenceRate = $totalEmployeeDays > 0 ? round(($presentTotalPersonDays / $totalEmployeeDays) * 100, 1) : 0.0;
        $punctualityRate = $presentTotalPersonDays > 0 ? round((max(0, $presentTotalPersonDays - $latePersonDays) / $presentTotalPersonDays) * 100, 1) : 100.0;

        $unmappedBiometricCount = $ctx['unmapped_biometric_count'] ?? 0;

        $stats = [
            'is_range'                 => true,
            'from_date'                => $from,
            'to_date'                  => $to,
            'total_days'               => $totalDays,
            'total_employee_days'      => $totalEmployeeDays,
            'total_employees'          => $totalActive,
            'totalActive'              => $totalActive,
            'totalEmployees'           => $totalActive,
            'total_active'             => $totalActive,
            'present'                  => $presentPersonDays,
            'present_total'            => $presentTotalPersonDays,
            'presentTotal'             => $presentTotalPersonDays,
            'halfDay'                  => $halfDayPersonDays,
            'half_day'                 => $halfDayPersonDays,
            'half_day_count'           => $halfDayPersonDays,
            'late'                     => $latePersonDays,
            'late_count'               => $latePersonDays,
            'earlyOut'                 => $earlyOutPersonDays,
            'early_out'                => $earlyOutPersonDays,
            'early_out_count'          => $earlyOutPersonDays,
            'onLeave'                  => $onLeavePersonDays,
            'on_leave'                 => $onLeavePersonDays,
            'on_leave_count'           => $onLeavePersonDays,
            'holiday'                  => $holidayPersonDays,
            'holiday_count'            => $holidayPersonDays,
            'weeklyOff'                => $weeklyOffPersonDays,
            'weekly_off_count'         => $weeklyOffPersonDays,
            'absent'                   => $absentPersonDays,
            'absent_count'             => $absentPersonDays,
            'missingPunch'             => $missingPunchPersonDays,
            'missing_punch'            => $missingPunchPersonDays,
            'missing_punch_count'      => $missingPunchPersonDays,
            'offDayWorked'             => $offDayWorkedPersonDays,
            'off_day_worked'           => $offDayWorkedPersonDays,
            'off_day_worked_days'      => $offDayWorkedPersonDays,
            'checkedIn'                => $checkedInPersonDays,
            'checked_in'               => $checkedInPersonDays,
            'checkedOut'               => $checkedOutPersonDays,
            'checked_out'              => $checkedOutPersonDays,
            'totalWorkingHours'        => round($totWorkingHours, 1),
            'totalWorkedHours'         => round($totWorkingHours, 1),
            'total_working_hours'      => round($totWorkingHours, 1),
            'hours'                    => round($totWorkingHours, 1),
            'totalOvertime'            => round($totOvertimeHours, 1),
            'totalOvertimeHours'       => round($totOvertimeHours, 1),
            'total_overtime'           => round($totOvertimeHours, 1),
            'overtime'                 => round($totOvertimeHours, 1),
            'totalLateMinutes'         => $totLateMinutes,
            'total_late_minutes'       => $totLateMinutes,
            'totalEarlyOutMinutes'     => $totEarlyOutMins,
            'total_early_out_minutes'  => $totEarlyOutMins,
            'presenceRate'             => $presenceRate,
            'presence_rate'            => $presenceRate,
            'attendanceRate'           => $presenceRate,
            'punctualityRate'          => $punctualityRate,
            'punctuality_rate'         => $punctualityRate,
            'unmappedBiometricCount'   => $unmappedBiometricCount,
            'unmapped_biometric_count' => $unmappedBiometricCount,
            'unique_present_count'     => count($uniquePresentEmps),
        ];

        // Apply Status / Search filter to detailed logs for UI
        $filteredLogs = $detailedLogs;
        if (!empty($statusFilter) && $statusFilter !== 'all') {
            $filteredLogs = array_values(array_filter($filteredLogs, function ($item) use ($statusFilter) {
                if ($statusFilter === 'Present') {
                    return in_array($item['bucket'], ['Present', 'Half Day'], true);
                }
                if ($statusFilter === 'Late') {
                    return !empty($item['is_late']);
                }
                if ($statusFilter === 'Early Out') {
                    return !empty($item['is_early_out']);
                }
                return strcasecmp($item['bucket'], $statusFilter) === 0 || strcasecmp($item['status'], $statusFilter) === 0;
            }));
        }

        if (!empty($search)) {
            $s = strtolower(trim($search));
            $filteredLogs = array_values(array_filter($filteredLogs, function ($item) use ($s) {
                return str_contains(strtolower($item['employee_name'] ?? ''), $s)
                    || str_contains(strtolower($item['employee_code'] ?? ''), $s)
                    || str_contains(strtolower($item['department_name'] ?? ''), $s);
            }));
        }

        return [
            'from_date'              => $from,
            'to_date'                => $to,
            'is_range'               => true,
            'truncated'              => $isTruncated,
            'truncation_message'     => $truncationMessage,
            'stats'                  => $stats,
            'employees'              => $allActive,
            'detailedLogs'           => $filteredLogs,
            'allDetailedLogs'        => $detailedLogs,
            'records'                => $filteredLogs,
            'allRecords'             => $detailedLogs,
            'warnings'               => $warnings,
            'unmappedBiometricCount' => $unmappedBiometricCount,
        ];
    }

    /**
     * Compute authoritative attendance summary for a single employee over a date range.
     * Strictly company-scoped and employee-scoped.
     * Respects company timezone, shifts, overnight shifts, approved corrections, leaves, and holidays.
     *
     * @param string $employeeId
     * @param string $companyId
     * @param string $from YYYY-MM-DD
     * @param string $to YYYY-MM-DD
     * @param array $options ['today' => YYYY-MM-DD, 'timezone' => string]
     * @return array|null
     */
    public function forEmployee(string $employeeId, string $companyId, string $from, string $to, array $options = []): ?array
    {
        if (empty($employeeId) || empty($companyId)) {
            return null;
        }

        if ($from > $to) {
            $tmp = $from;
            $from = $to;
            $to = $tmp;
        }

        // 1. Fetch target employee strictly within company
        $empBuilder = $this->db->table('employees')
            ->select('employees.*, departments.name as department_name, branches.name as branch_name, designations.name as designation_name, shifts.name as shift_name, shifts.start_time, shifts.end_time, shifts.grace_time, shifts.late_grace_period_mins, shifts.weekly_off as shift_weekly_off, shifts.work_days as shift_work_days, shifts.night_shift')
            ->join('departments', 'departments.id = employees.department_id', 'left')
            ->join('branches', 'branches.id = employees.branch_id', 'left')
            ->join('designations', 'designations.id = employees.designation_id', 'left')
            ->join('shifts', 'shifts.id = employees.shift_id', 'left')
            ->where('employees.id', $employeeId)
            ->where('employees.company_id', $companyId);

        $emp = $empBuilder->get()->getRowArray();
        if (!$emp) {
            return null;
        }

        // 2. Resolve company timezone
        $tzString = $options['timezone'] ?? null;
        if (empty($tzString)) {
            try {
                $comp = $this->db->table('companies')->select('timezone')->where('id', $companyId)->get()->getRowArray();
                if (!empty($comp['timezone'])) {
                    $tzString = trim($comp['timezone']);
                }
            } catch (\Throwable $e) {}
        }
        if (empty($tzString)) {
            $tzString = 'UTC';
        }
        try {
            $tz = new \DateTimeZone($tzString);
        } catch (\Throwable $e) {
            $tz = new \DateTimeZone('UTC');
            $tzString = 'UTC';
        }
        $nowInTz = new \DateTimeImmutable('now', $tz);
        $today = $options['today'] ?? $nowInTz->format('Y-m-d');

        // 3. Preload context for this employee
        $ctx = $this->preloadContext([$emp], $from, $to, $companyId, array_merge($options, [
            'today'    => $today,
            'timezone' => $tzString,
        ]));

        $startTs = strtotime($from);
        $endTs   = strtotime($to);
        $totalDays = (int)(($endTs - $startTs) / 86400) + 1;

        $eId   = (string)($emp['id'] ?? '');
        $eCode = (string)($emp['employee_code'] ?? '');

        $presentCount        = 0;
        $halfDayCount        = 0;
        $onLeaveCount        = 0;
        $holidayCount        = 0;
        $weeklyOffCount      = 0;
        $absentCount         = 0;
        $missingPunchCount   = 0;
        $upcomingCount       = 0;
        $notJoinedCount      = 0;
        $lateCount           = 0;
        $earlyOutCount       = 0;
        $offDayWorkedCount   = 0;
        $eligibleDaysCount   = 0;

        $totWorkingHours  = 0.0;
        $totOvertimeHours = 0.0;
        $totLateMinutes   = 0;
        $totEarlyOutMins  = 0;
        $totPayableCredit = 0.0;

        $dailyBreakdown = [];

        for ($currTs = $startTs; $currTs <= $endTs; $currTs += 86400) {
            $cDate = date('Y-m-d', $currTs);
            $dayOfWeek = date('l', $currTs);

            $log = $ctx['logs_by_date'][$cDate][$eId] ?? ($ctx['logs_by_date'][$cDate][$eCode] ?? null);

            $classification = self::classifyDay($emp, $cDate, $log, $ctx);
            $b = $classification['bucket'];

            if ($b === 'Not Joined') {
                $notJoinedCount++;
            } else {
                $eligibleDaysCount++;

                if ($b === 'Present') {
                    $presentCount++;
                } elseif ($b === 'Half Day') {
                    $halfDayCount++;
                } elseif ($b === 'On Leave') {
                    $onLeaveCount++;
                } elseif ($b === 'Holiday') {
                    $holidayCount++;
                } elseif ($b === 'Weekly Off') {
                    $weeklyOffCount++;
                } elseif ($b === 'Absent') {
                    $absentCount++;
                } elseif ($b === 'Missing Punch') {
                    $missingPunchCount++;
                } elseif ($b === 'Upcoming') {
                    $upcomingCount++;
                }

                if (!empty($classification['flags']['late'])) {
                    $lateCount++;
                }
                if (!empty($classification['flags']['early_out'])) {
                    $earlyOutCount++;
                }
                if (!empty($classification['flags']['off_day_worked'])) {
                    $offDayWorkedCount++;
                }

                $totWorkingHours  += (float)($classification['hours']['working_hours'] ?? 0.0);
                $totOvertimeHours += (float)($classification['hours']['overtime_hours'] ?? 0.0);
                $totLateMinutes   += (int)($classification['minutes']['late_minutes'] ?? 0);
                $totEarlyOutMins  += (int)($classification['minutes']['early_out_minutes'] ?? 0);
                $totPayableCredit += (float)($classification['payable_credit'] ?? 0.0);
            }

            $dailyBreakdown[] = [
                'date'              => $cDate,
                'day_of_week'       => $dayOfWeek,
                'status'            => $classification['status'],
                'bucket'            => $classification['bucket'],
                'check_in'          => $classification['check_in'],
                'check_out'         => $classification['check_out'],
                'working_hours'     => (float)($classification['hours']['working_hours'] ?? 0.0),
                'overtime_hours'    => (float)($classification['hours']['overtime_hours'] ?? 0.0),
                'late_minutes'      => (int)($classification['minutes']['late_minutes'] ?? 0),
                'early_out_minutes' => (int)($classification['minutes']['early_out_minutes'] ?? 0),
                'is_late'           => !empty($classification['flags']['late']),
                'is_early_out'      => !empty($classification['flags']['early_out']),
                'off_day_worked'    => !empty($classification['flags']['off_day_worked']),
                'payable_credit'    => (float)($classification['payable_credit'] ?? 0.0),
                'warning'           => $classification['warning'] ?? null,
            ];
        }

        $presentTotal = $presentCount + $halfDayCount;
        $expectedWorkDays = max(0, $eligibleDaysCount - $holidayCount - $weeklyOffCount - $upcomingCount);
        $presenceRate = $expectedWorkDays > 0 ? round(($presentTotal / $expectedWorkDays) * 100, 1) : ($eligibleDaysCount > 0 ? round(($presentTotal / $eligibleDaysCount) * 100, 1) : 0.0);
        $punctualityRate = $presentTotal > 0 ? round((max(0, $presentTotal - $lateCount) / $presentTotal) * 100, 1) : 100.0;

        $joinDate = function_exists('employee_joining_date') ? employee_joining_date($emp) : ($emp['joining_date'] ?? null);
        $fullName = trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')) ?: ($emp['name'] ?? ($emp['employee_code'] ?? 'Staff'));

        return [
            'from'        => $from,
            'to'          => $to,
            'as_of'       => $today,
            'timezone'    => $tzString,
            'server_time' => $nowInTz->format('c'),
            'employee'    => [
                'id'            => $eId,
                'employee_code' => $eCode,
                'full_name'     => $fullName,
                'department'    => $emp['department_name'] ?? 'General',
                'designation'   => $emp['designation_name'] ?? 'Staff',
                'branch'        => $emp['branch_name'] ?? 'Main Office',
                'shift'         => $emp['shift_name'] ?? 'General Shift',
                'joining_date'  => $joinDate,
                'status'        => $emp['status'] ?? 'Active',
            ],
            'summary'     => [
                'total_days'              => $totalDays,
                'totalDays'               => $totalDays,
                'eligible_days'           => $eligibleDaysCount,
                'present'                 => $presentCount,
                'half_day'                => $halfDayCount,
                'halfDay'                 => $halfDayCount,
                'present_total'           => $presentTotal,
                'presentTotal'            => $presentTotal,
                'late'                    => $lateCount,
                'early_out'               => $earlyOutCount,
                'earlyOut'                => $earlyOutCount,
                'absent'                  => $absentCount,
                'on_leave'                => $onLeaveCount,
                'onLeave'                 => $onLeaveCount,
                'holiday'                 => $holidayCount,
                'weekly_off'              => $weeklyOffCount,
                'weeklyOff'               => $weeklyOffCount,
                'missing_punch'           => $missingPunchCount,
                'missingPunch'            => $missingPunchCount,
                'upcoming'                => $upcomingCount,
                'not_joined'              => $notJoinedCount,
                'off_day_worked'          => $offDayWorkedCount,
                'total_working_hours'     => round($totWorkingHours, 2),
                'totalHours'              => round($totWorkingHours, 2),
                'total_overtime_hours'    => round($totOvertimeHours, 2),
                'totalOt'                 => round($totOvertimeHours, 2),
                'total_late_minutes'      => $totLateMinutes,
                'total_early_out_minutes' => $totEarlyOutMins,
                'payable_days'            => round($totPayableCredit, 2),
                'presence_rate'           => $presenceRate,
                'punctuality_rate'        => $punctualityRate,
                'punctualityRate'         => $punctualityRate,
            ],
            'daily_breakdown' => $dailyBreakdown,
            'records'         => $dailyBreakdown,
        ];
    }

    /**
     * Batch preload context for a date or date range to completely eliminate N+1 queries.
     * Everything is strictly company-scoped.
     */
    protected function preloadContext(array $employees, string $fromDate, string $toDate, ?string $companyId = null, array $filters = []): array
    {
        $today = date('Y-m-d');
        $empIds = [];
        $empCodes = [];
        foreach ($employees as $e) {
            $id = (string)($e['id'] ?? '');
            if ($id) $empIds[] = $id;
            $code = (string)($e['employee_code'] ?? '');
            if ($code) $empCodes[] = $code;
        }

        // 1. Company-scoped Holidays covering the range
        $holidays = [];
        $holidaysLookup = [];
        if ($this->db->tableExists('holidays')) {
            try {
                $rawHolidays = (new HolidayModel())->getOrderedHolidays($companyId);
                foreach ($rawHolidays as $rh) {
                    $hStart = $rh['from_date'] ?? ($rh['date'] ?? '');
                    $hEnd   = $rh['to_date'] ?? ($rh['date'] ?? $hStart);
                    if ($hStart <= $toDate && $hEnd >= $fromDate) {
                        $item = [
                            'id'        => $rh['id'] ?? '',
                            'name'      => $rh['name'] ?? 'Holiday',
                            'from_date' => $hStart,
                            'to_date'   => $hEnd,
                            'type'      => $rh['type'] ?? ($rh['holiday_type'] ?? 'public')
                        ];
                        $holidays[] = $item;

                        // Index by date if single date or discrete span
                        $curH = max($fromDate, $hStart);
                        $maxH = min($toDate, $hEnd);
                        for ($hTs = strtotime($curH); $hTs <= strtotime($maxH); $hTs += 86400) {
                            $holidaysLookup[date('Y-m-d', $hTs)] = $item;
                        }
                    }
                }
            } catch (\Throwable $e) {
                log_message('error', 'AttendanceSummaryService preload holidays error: ' . $e->getMessage());
            }
        }

        // 2. Company-scoped Approved Leaves in range
        $leavesLookup = [];
        $rawLeaves = [];
        if ($this->db->tableExists('leave_applications') && (!empty($empIds) || !empty($empCodes))) {
            try {
                $hasLeaveTypes = $this->db->tableExists('leave_types');
                $lb = $this->db->table('leave_applications')
                    ->where('leave_applications.status', 'Approved')
                    ->where('leave_applications.start_date <=', $toDate)
                    ->where('leave_applications.end_date >=', $fromDate);

                if (!empty($companyId)) {
                    $lb->where('leave_applications.company_id', $companyId);
                }

                $allLookupIds = array_values(array_unique(array_merge($empIds, $empCodes)));
                if (!empty($allLookupIds)) {
                    $lb->whereIn('leave_applications.employee_id', $allLookupIds);
                }

                if ($hasLeaveTypes) {
                    $lb->select('leave_applications.*, leave_types.name as leave_type_name, leave_types.is_paid as leave_is_paid')
                       ->join('leave_types', 'leave_types.id = leave_applications.leave_type_id', 'left');
                } else {
                    $lb->select('leave_applications.*');
                }

                $rawLeaves = $lb->get()->getResultArray();
                foreach ($rawLeaves as $lvr) {
                    $eid = (string)($lvr['employee_id'] ?? '');
                    $lStart = max($fromDate, $lvr['start_date'] ?? $fromDate);
                    $lEnd   = min($toDate, $lvr['end_date'] ?? $toDate);
                    for ($lTs = strtotime($lStart); $lTs <= strtotime($lEnd); $lTs += 86400) {
                        $lDate = date('Y-m-d', $lTs);
                        $leavesLookup[$eid][$lDate] = $lvr;
                    }
                }
            } catch (\Throwable $e) {
                log_message('error', 'AttendanceSummaryService preload leaves error: ' . $e->getMessage());
            }
        }

        // 3. Weekly Off Lookup via CompanyWeekendService (reads rule_definitions via RuleResolver)
        $weeklyOffLookup = CompanyWeekendService::preloadCompanyWeeklyOff($employees, $companyId);
        $defaultWeeklyOff = CompanyWeekendService::getCompanyWeeklyOff($companyId) ?: [];

        // 4. Duty Assignments in range
        $dutyLookup = [];
        if ($this->db->tableExists('duty_assignments') && !empty($empIds)) {
            try {
                $builder = $this->db->table('duty_assignments')
                    ->whereIn('employee_id', $empIds)
                    ->where('duty_date >=', $fromDate)
                    ->where('duty_date <=', $toDate)
                    ->whereIn('status', ['Assigned', 'Confirmed', 'Completed']);

                if (!empty($companyId)) {
                    $builder->where('company_id', $companyId);
                }

                $rows = $builder->orderBy('created_at', 'DESC')->get()->getResultArray();
                foreach ($rows as $row) {
                    $eid = (string)($row['employee_id'] ?? '');
                    $dd  = (string)($row['duty_date'] ?? '');
                    if ($eid && $dd && !isset($dutyLookup[$eid][$dd])) {
                        $dutyLookup[$eid][$dd] = $row;
                    }
                }
            } catch (\Throwable $e) {}
        }

        // 5. Attendance Logs in range
        $logs = [];
        $logsByDate = [];
        if ($this->db->tableExists('attendance_logs')) {
            try {
                $logBuilder = $this->db->table('attendance_logs')
                    ->where('date >=', $fromDate)
                    ->where('date <=', $toDate);

                if (!empty($companyId) && $this->db->fieldExists('company_id', 'attendance_logs')) {
                    $logBuilder->where('company_id', $companyId);
                }

                $rawLogs = $logBuilder->get()->getResultArray();
                foreach ($rawLogs as $l) {
                    $lDate = (string)($l['date'] ?? '');
                    $eid = (string)($l['employee_id'] ?? '');
                    $ecode = (string)($l['employee_code'] ?? '');

                    // Single-date primary map (if from === to)
                    if ($fromDate === $toDate) {
                        if ($eid) $logs[$eid] = $l;
                        if ($ecode) $logs[$ecode] = $l;
                    }

                    // Multi-date map
                    if ($lDate) {
                        if ($eid) $logsByDate[$lDate][$eid] = $l;
                        if ($ecode) $logsByDate[$lDate][$ecode] = $l;
                    }
                }
            } catch (\Throwable $e) {
                log_message('error', 'AttendanceSummaryService preload logs error: ' . $e->getMessage());
            }
        }

        // 5b. Preload Approved Attendance Corrections (regularized punches)
        if ($this->db->tableExists('attendance_corrections') && (!empty($empIds) || !empty($empCodes))) {
            try {
                $allLookupIds = array_values(array_unique(array_merge($empIds, $empCodes)));
                $corrBuilder = $this->db->table('attendance_corrections')
                    ->where('attendance_date >=', $fromDate)
                    ->where('attendance_date <=', $toDate)
                    ->groupStart()
                        ->where('status', 'Approved')
                        ->orWhere('status', 'APPROVED')
                        ->orWhere('status', 'approved')
                    ->groupEnd();

                if (!empty($companyId) && $this->db->fieldExists('company_id', 'attendance_corrections')) {
                    $corrBuilder->where('company_id', $companyId);
                }
                if (!empty($allLookupIds)) {
                    $corrBuilder->whereIn('employee_id', $allLookupIds);
                }

                $approvedCorrections = $corrBuilder->get()->getResultArray();
                foreach ($approvedCorrections as $ac) {
                    $cDate = (string)($ac['attendance_date'] ?? '');
                    $eid   = (string)($ac['employee_id'] ?? '');
                    if (!$cDate || !$eid) {
                        continue;
                    }

                    $existing = $logsByDate[$cDate][$eid] ?? ($logs[$eid] ?? null);
                    $inTime   = !empty($ac['proposed_check_in']) ? $ac['proposed_check_in'] : ($existing['check_in'] ?? ($existing['in_time'] ?? null));
                    $outTime  = !empty($ac['proposed_check_out']) ? $ac['proposed_check_out'] : ($existing['check_out'] ?? ($existing['out_time'] ?? null));

                    $merged = array_merge($existing ?: [], [
                        'id'                  => $existing['id'] ?? ('corr-' . ($ac['id'] ?? bin2hex(random_bytes(6)))),
                        'employee_id'         => $eid,
                        'company_id'          => $ac['company_id'] ?? $companyId,
                        'date'                => $cDate,
                        'check_in'            => $inTime,
                        'check_out'           => $outTime,
                        'in_time'             => $inTime,
                        'out_time'            => $outTime,
                        'status'              => 'Present',
                        'verification_method' => 'Regularized (Manager Approved)',
                        'is_approved'         => 1,
                        'remarks'             => $ac['reason'] ?? 'Regularization approved',
                    ]);

                    if ($fromDate === $toDate) {
                        $logs[$eid] = $merged;
                    }
                    $logsByDate[$cDate][$eid] = $merged;
                }
            } catch (\Throwable $e) {
                log_message('error', 'AttendanceSummaryService preload corrections error: ' . $e->getMessage());
            }
        }

        // 6. Unmapped Biometric punches in range (never modifies Absent)
        $unmappedCount = 0;
        if ($this->db->tableExists('raw_biometric_events')) {
            try {
                $rawBuilder = $this->db->table('raw_biometric_events')
                    ->where('DATE(punch_time) >=', $fromDate)
                    ->where('DATE(punch_time) <=', $toDate)
                    ->where('matching_status', 'UNMATCHED');
                if (!empty($companyId)) {
                    $rawBuilder->where('company_id', $companyId);
                }
                $row = $rawBuilder->select('COUNT(DISTINCT biometric_user_id) as cnt')->get()->getRow();
                $unmappedCount = (int)($row->cnt ?? 0);
            } catch (\Throwable $e) {}
        }

        return [
            'today'                    => $today,
            'holidays'                 => $holidaysLookup,
            'holidays_list'            => $holidays,
            'leaves'                   => $leavesLookup,
            'leaves_raw'               => $rawLeaves,
            'weekly_off'               => $weeklyOffLookup,
            'default_weekly_off'       => $defaultWeeklyOff,
            'duty_assignments'         => $dutyLookup,
            'logs'                     => $logs,
            'logs_by_date'             => $logsByDate,
            'unmapped_biometric_count' => $unmappedCount,
            'include_test_punches'     => !empty($filters['include_test_punches']),
        ];
    }
}
