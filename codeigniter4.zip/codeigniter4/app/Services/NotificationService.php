<?php

namespace App\Services;

use App\Models\NotificationModel;
use App\Models\NotificationSettingModel;
use App\Models\NotificationTemplateModel;
use App\Models\EmailQueueModel;
use App\Models\EmailLogModel;
use App\Models\EmployeeModel;
use App\Models\UserModel;
use App\Services\SmtpConfigResolver;
use App\Services\EmailTemplateRenderer;
use Ramsey\Uuid\Uuid;

class NotificationService
{
    protected NotificationModel $notificationModel;
    protected NotificationSettingModel $settingModel;
    protected NotificationTemplateModel $templateModel;
    protected EmailQueueModel $emailQueueModel;
    protected EmailLogModel $emailLogModel;

    public function __construct()
    {
        $this->notificationModel = new NotificationModel();
        $this->settingModel      = new NotificationSettingModel();
        $this->templateModel     = new NotificationTemplateModel();
        $this->emailQueueModel   = new EmailQueueModel();
        $this->emailLogModel     = new EmailLogModel();
    }

    /**
     * Multi-channel notification dispatcher
     */
    public function send(
        string $userId,
        string $type,
        string $title,
        string $message,
        string $priority = 'Normal',
        string $relatedModule = 'System',
        ?string $relatedEmployeeId = null,
        ?string $relatedEmployeeName = null,
        ?string $createdById = 'SYSTEM',
        ?string $createdByName = 'System Auto',
        ?string $link = null,
        ?string $emailSubject = null,
        ?string $emailBody = null
    ): array {
        // Broadcast handler when userId is 'all'
        if ($userId === 'all') {
            $userModel = new UserModel();
            $broadcastUsers = [];
            try {
                $broadcastUsers = $userModel->where('status', 'active')->findAll();
                if (empty($broadcastUsers)) {
                    $broadcastUsers = $userModel->findAll();
                }
            } catch (\Throwable $e) {
                log_message('error', 'NotificationService::send broadcast fetch users error: ' . $e->getMessage());
            }

            if (empty($broadcastUsers)) {
                log_message('warning', 'NotificationService::send broadcast skipped: no users available in database.');
                return ['status' => 'skipped', 'reason' => 'No users found for broadcast'];
            }

            $results = [];
            foreach ($broadcastUsers as $bUser) {
                $results[] = $this->send(
                    $bUser['id'],
                    $type,
                    $title,
                    $message,
                    $priority,
                    $relatedModule,
                    $relatedEmployeeId,
                    $relatedEmployeeName,
                    $createdById,
                    $createdByName,
                    $link,
                    $emailSubject,
                    $emailBody
                );
            }

            return [
                'status'    => 'success',
                'broadcast' => true,
                'count'     => count($results)
            ];
        }

        // Validate and resolve userId against users table to prevent Foreign Key constraint violations
        $resolvedUserId = $userId;
        $userModel = new UserModel();
        try {
            $userExists = $userModel->find($resolvedUserId);
            if (!$userExists) {
                // Check if userId is an employee_id
                $userByEmp = $userModel->where('employee_id', $resolvedUserId)->first();
                if ($userByEmp) {
                    $resolvedUserId = $userByEmp['id'];
                    $userExists = $userByEmp;
                }
            }

            if (!$userExists) {
                // Check if createdById is a valid user
                if (!empty($createdById) && $createdById !== 'SYSTEM' && $userModel->find($createdById)) {
                    $resolvedUserId = $createdById;
                } else {
                    $firstUser = $userModel->first();
                    if ($firstUser) {
                        log_message('warning', "NotificationService::send: Recipient '{$userId}' not in users table. Falling back to '{$firstUser['id']}'.");
                        $resolvedUserId = $firstUser['id'];
                    } else {
                        log_message('error', "NotificationService::send: Recipient '{$userId}' invalid and no users exist in users table.");
                        return ['status' => 'skipped', 'reason' => 'Recipient not found in database'];
                    }
                }
            }
        } catch (\Throwable $e) {
            log_message('error', 'NotificationService::send user resolution error: ' . $e->getMessage());
        }

        $userSettings = $this->settingModel->getUserSettings($resolvedUserId);

        // Check module alert filtering
        $moduleKey = strtolower($relatedModule) . 'Alerts';
        if (isset($userSettings[$moduleKey]) && !$userSettings[$moduleKey]) {
            return ['status' => 'skipped', 'reason' => 'User disabled alerts for module: ' . $relatedModule];
        }

        $notificationRecord = [];

        // 1. In-App Notification Delivery
        if ($userSettings['inAppEnabled']) {
            $notificationId = Uuid::uuid4()->toString();
            $notificationRecord = [
                'id'                    => $notificationId,
                'user_id'               => $resolvedUserId,
                'title'                 => $title,
                'message'               => $message,
                'type'                  => strtolower($type),
                'priority'              => $priority,
                'related_module'        => ucfirst($relatedModule),
                'related_employee_id'   => $relatedEmployeeId,
                'related_employee_name' => $relatedEmployeeName,
                'created_by'            => $createdById,
                'created_by_name'       => $createdByName,
                'link'                  => $link,
                'is_read'               => 0,
                'created_at'            => date('Y-m-d H:i:s')
            ];

            try {
                $this->notificationModel->insert($notificationRecord);
            } catch (\Throwable $e) {
                log_message('error', 'NotificationService::send in-app insert error: ' . $e->getMessage());
            }
        }

        // 2. Email Delivery Channel
        if ($userSettings['emailEnabled']) {
            $receiverEmail = null;
            $receiverName  = $relatedEmployeeName ?? null;
            $companyId     = null;

            // Resolve email and company from user model
            try {
                $userObj = $userModel->find($resolvedUserId);
                if ($userObj) {
                    $companyId = $userObj['company_id'] ?? null;
                    if (!empty($userObj['email']) && filter_var($userObj['email'], FILTER_VALIDATE_EMAIL)) {
                        $receiverEmail = $userObj['email'];
                        $receiverName  = $userObj['name'] ?? ($userObj['username'] ?? $receiverName);
                    }
                }
            } catch (\Throwable $e) {
                log_message('error', 'NotificationService::send user email resolution error: ' . $e->getMessage());
            }

            // Fallback to employee record if email still not found
            if (empty($receiverEmail) && !empty($relatedEmployeeId)) {
                try {
                    $empModel = new EmployeeModel();
                    $empObj = $empModel->find($relatedEmployeeId);
                    if ($empObj) {
                        $companyId = $companyId ?: ($empObj['company_id'] ?? null);
                        $candidateEmail = $empObj['work_email'] ?? ($empObj['personal_email'] ?? ($empObj['email'] ?? null));
                        if (!empty($candidateEmail) && filter_var($candidateEmail, FILTER_VALIDATE_EMAIL)) {
                            $receiverEmail = $candidateEmail;
                            $candidateName = trim(($empObj['first_name'] ?? '') . ' ' . ($empObj['last_name'] ?? ''));
                            if (!empty($candidateName)) {
                                $receiverName = $candidateName;
                            }
                        }
                    }
                } catch (\Throwable $e) {
                    log_message('error', 'NotificationService::send employee email resolution error: ' . $e->getMessage());
                }
            }

            // If receiver email is absent, skip and log (Rule: no employee@company.com fallback)
            if (empty($receiverEmail)) {
                log_message('info', "NotificationService::send: Outbound email skipped for recipient '{$resolvedUserId}' (Employee: {$relatedEmployeeId}) - no valid email address found.");
            } else {
                $subject = $emailSubject ?: "[HRMS Alert] - {$title}";
                $body    = $emailBody ?: $message;

                try {
                    $this->emailQueueModel->enqueue([
                        'company_id'     => $companyId,
                        'receiver_email' => $receiverEmail,
                        'receiver_name'  => $receiverName ?: 'Employee',
                        'subject'        => $subject,
                        'body'           => $body,
                        'module'         => $relatedModule,
                    ]);
                } catch (\Throwable $e) {
                    log_message('error', 'NotificationService::send email enqueue error: ' . $e->getMessage());
                }
            }
        }

        return [
            'status'       => 'success',
            'notification' => $notificationRecord
        ];
    }

    /**
     * Trigger Leave Multi-Stage Workflow Notifications
     * Stages:
     * - 'submitted': Employee submitted -> Notify Direct Manager
     * - 'manager_approved': Manager approved -> Notify HR Admin
     * - 'hr_approved': HR approved -> Notify Employee with balance update
     * - 'rejected': Rejected by Manager/HR -> Notify Employee with reason
     * - 'cancelled': Cancelled by Employee -> Notify Manager & HR
     */
    public function triggerLeaveWorkflow(
        string $stage,
        string $leaveId,
        string $employeeId,
        string $leaveType,
        string $startDate,
        string $endDate,
        float $totalDays,
        ?string $managerId = null,
        ?string $actorName = 'HR Admin',
        ?string $reason = null
    ): array {
        $employeeModel = new EmployeeModel();
        $emp = $employeeModel->find($employeeId);
        $empName = $emp ? ($emp['first_name'] . ' ' . $emp['last_name']) : 'Employee';
        $userModel = new UserModel();

        switch ($stage) {
            case 'submitted':
                // Notify Manager (or all managers if managerId not set)
                $targetUserId = $managerId ?: 'all';
                $renderer = new EmailTemplateRenderer();
                $rendered = $renderer->render('leave_applied', [
                    'manager_name'  => 'Manager',
                    'employee_name' => $empName,
                    'employee_code' => $emp['employee_code'] ?? $employeeId,
                    'leave_type'    => $leaveType,
                    'days'          => (string)$totalDays,
                    'from_date'     => $startDate,
                    'to_date'       => $endDate,
                    'reason'        => $reason ?: 'Not specified',
                    'approval_link' => base_url("leave"),
                ], $emp['company_id'] ?? null);

                $message = "{$empName} ({$employeeId}) has applied for {$totalDays} day(s) of {$leaveType} from {$startDate} to {$endDate}. Reason: \"{$reason}\". Action required: Manager review.";
                return $this->send(
                    $targetUserId,
                    'leave',
                    $rendered['subject'],
                    $message,
                    'High',
                    'Leave',
                    $employeeId,
                    $empName,
                    $employeeId,
                    $empName,
                    'leave',
                    $rendered['subject'],
                    $rendered['body']
                );

            case 'manager_approved':
                // Notify HR Admin
                $title = "✓ Manager Endorsed Leave: {$empName}";
                $message = "Manager {$actorName} has endorsed the leave request (#{$leaveId}) for {$empName} ({$totalDays} days {$leaveType}). Ready for final HR verification.";
                $renderer = new EmailTemplateRenderer();
                $rendered = $renderer->render('leave_applied', [
                    'manager_name'  => 'HR Team',
                    'employee_name' => $empName,
                    'employee_code' => $emp['employee_code'] ?? $employeeId,
                    'leave_type'    => $leaveType,
                    'days'          => (string)$totalDays,
                    'from_date'     => $startDate,
                    'to_date'       => $endDate,
                    'reason'        => $message,
                    'approval_link' => base_url("leave"),
                ], $emp['company_id'] ?? null);

                return $this->send(
                    'all', // broadcast to HR role users
                    'leave',
                    $title,
                    $message,
                    'Normal',
                    'Leave',
                    $employeeId,
                    $empName,
                    'SYSTEM',
                    "Manager: {$actorName}",
                    'leave',
                    $rendered['subject'],
                    $rendered['body']
                );

            case 'hr_approved':
                // Notify Employee (Final Approval)
                $targetUserId = $emp['user_id'] ?? $employeeId;
                $renderer = new EmailTemplateRenderer();
                $rendered = $renderer->render('leave_approved', [
                    'employee_name'     => $empName,
                    'leave_type'        => $leaveType,
                    'from_date'         => $startDate,
                    'to_date'           => $endDate,
                    'approver_name'     => $actorName,
                    'remaining_balance' => 'Confirmed in portal',
                ], $emp['company_id'] ?? null);

                $message = "Your leave request for {$totalDays} day(s) of {$leaveType} from {$startDate} to {$endDate} has been approved by HR ({$actorName}). Your leave balance ledger has been debited.";
                return $this->send(
                    $targetUserId,
                    'leave',
                    $rendered['subject'],
                    $message,
                    'High',
                    'Leave',
                    $employeeId,
                    $empName,
                    'HR',
                    $actorName,
                    'leave',
                    $rendered['subject'],
                    $rendered['body']
                );

            case 'rejected':
                // Notify Employee of rejection
                $targetUserId = $emp['user_id'] ?? $employeeId;
                $renderer = new EmailTemplateRenderer();
                $rendered = $renderer->render('leave_rejected', [
                    'employee_name' => $empName,
                    'leave_type'    => $leaveType,
                    'from_date'     => $startDate,
                    'to_date'       => $endDate,
                    'reason'        => $reason ?: 'No reason specified',
                ], $emp['company_id'] ?? null);

                $message = "Your leave request (#{$leaveId}) was declined by {$actorName}. Reason: \"{$reason}\". No days were deducted from your balance.";
                return $this->send(
                    $targetUserId,
                    'leave',
                    $rendered['subject'],
                    $message,
                    'High',
                    'Leave',
                    $employeeId,
                    $empName,
                    'SYSTEM',
                    $actorName,
                    'leave',
                    $rendered['subject'],
                    $rendered['body']
                );

            default:
                return ['status' => 'skipped', 'reason' => 'Unknown workflow stage'];
        }
    }

    /**
     * Trigger Attendance Correction / Missed Punch Workflow
     */
    public function triggerAttendanceCorrectionWorkflow(
        string $stage,
        string $correctionId,
        string $employeeId,
        string $date,
        string $correctionType,
        ?string $requestedIn = null,
        ?string $requestedOut = null,
        ?string $reason = null,
        ?string $managerId = null,
        ?string $actorName = 'Manager'
    ): array {
        $employeeModel = new EmployeeModel();
        $emp = $employeeModel->find($employeeId);
        $empName = $emp ? ($emp['first_name'] . ' ' . $emp['last_name']) : 'Employee';
        $userId = $emp['user_id'] ?? $employeeId;

        if ($stage === 'submitted') {
            $targetUserId = $managerId ?: 'all';
            return $this->send(
                $targetUserId,
                'attendance',
                "⏱ Attendance Regularization: {$empName}",
                "{$empName} requested a {$correctionType} for {$date} (In: {$requestedIn}, Out: {$requestedOut}). Reason: \"{$reason}\". Action required: Manager review.",
                'Normal',
                'Attendance',
                $employeeId,
                $empName,
                $employeeId,
                $empName,
                'attendance'
            );
        } elseif ($stage === 'manager_approved') {
            return $this->send(
                'all',
                'attendance',
                "✓ Manager Approved Attendance Correction: {$empName}",
                "Manager {$actorName} approved attendance adjustment for {$empName} on {$date}. Pending final HR sync.",
                'Normal',
                'Attendance',
                $employeeId,
                $empName,
                'SYSTEM',
                "Manager: {$actorName}",
                'attendance'
            );
        } elseif ($stage === 'hr_approved') {
            return $this->send(
                $userId,
                'attendance',
                "✓ Attendance Regularization Approved ({$date})",
                "Your attendance record for {$date} has been regularized and approved. Status is now set to Present.",
                'Normal',
                'Attendance',
                $employeeId,
                $empName,
                'SYSTEM',
                $actorName,
                'attendance'
            );
        }

        return ['status' => 'skipped'];
    }

    /**
     * Trigger Overtime Multi-Tier Approval Workflow
     */
    public function triggerOvertimeWorkflow(
        string $stage,
        string $employeeId,
        float $otHours,
        string $date,
        float $estimatedAmount,
        ?string $managerId = null,
        ?string $actorName = 'Manager',
        ?string $payrollPeriod = 'Current Month'
    ): array {
        $employeeModel = new EmployeeModel();
        $emp = $employeeModel->find($employeeId);
        $empName = $emp ? ($emp['first_name'] . ' ' . $emp['last_name']) : 'Employee';
        $userId = $emp['user_id'] ?? $employeeId;

        if ($stage === 'submitted') {
            $targetUserId = $managerId ?: 'all';
            return $this->send(
                $targetUserId,
                'attendance',
                "⏰ Overtime Claim Submitted: {$empName} ({$otHours}h)",
                "{$empName} logged an overtime claim of {$otHours} hours on {$date} (Est. \${$estimatedAmount}).",
                'Normal',
                'Attendance',
                $employeeId,
                $empName,
                $employeeId,
                $empName,
                'attendance'
            );
        } elseif ($stage === 'manager_approved') {
            return $this->send(
                'all',
                'attendance',
                "✓ Manager Endorsed OT: {$empName} ({$otHours}h)",
                "Manager {$actorName} approved {$otHours} hours OT for {$empName} on {$date}. Transferred to Finance reconciliation batch.",
                'Normal',
                'Attendance',
                $employeeId,
                $empName,
                'SYSTEM',
                "Manager: {$actorName}",
                'payroll'
            );
        } elseif ($stage === 'final_approved') {
            return $this->send(
                $userId,
                'payroll',
                "💰 Overtime Approved & Credited ({$otHours} Hours)",
                "Your overtime of {$otHours} hour(s) on {$date} has been approved. Payout of \${$estimatedAmount} has been reconciled for {$payrollPeriod} payroll.",
                'High',
                'Payroll',
                $employeeId,
                $empName,
                'SYSTEM',
                'Finance Payroll Team',
                'payroll'
            );
        }

        return ['status' => 'skipped'];
    }

    /**
     * Trigger Payroll Multi-Stage & Disbursement Notifications
     */
    public function triggerPayrollWorkflow(
        string $stage,
        string $month,
        string $year,
        string $actorName = 'System',
        int $employeeCount = 0,
        float $totalAmount = 0.0,
        ?string $employeeId = null,
        ?float $netSalary = null,
        ?string $bankAccount = null
    ): array {
        if ($stage === 'disbursed' && $employeeId) {
            $employeeModel = new EmployeeModel();
            $emp = $employeeModel->find($employeeId);
            $empName = $emp ? ($emp['first_name'] . ' ' . $emp['last_name']) : 'Employee';
            $userId = $emp['user_id'] ?? $employeeId;
            $formattedAmount = '$' . number_format($netSalary ?? 0.0, 2);

            $renderer = new EmailTemplateRenderer();
            $rendered = $renderer->render('payslip_ready', [
                'employee_name'    => $empName,
                'payroll_month'    => "{$month} {$year}",
                'cycle_name'       => 'Monthly Regular',
                'gross_salary'     => $formattedAmount,
                'total_deductions' => '$0.00',
                'net_salary'       => $formattedAmount,
                'payslip_link'     => base_url('payroll'),
            ], $emp['company_id'] ?? null);

            return $this->send(
                $userId,
                'payroll',
                $rendered['subject'],
                "Your monthly compensation for {$month} {$year} has been disbursed to account {$bankAccount}. Payslip is ready for download.",
                'High',
                'Payroll',
                $employeeId,
                $empName,
                'SYSTEM',
                'Finance & Payroll',
                'payroll',
                $rendered['subject'],
                $rendered['body']
            );
        }

        // Batch stage notifications to Admins/Finance
        $stageMessages = [
            'Draft' => "⚙️ Payroll Draft Created ({$month} {$year}). Department Managers please verify attendance.",
            'ManagerApproved' => "✓ Manager Approvals Complete for Payroll ({$month} {$year}). HR please verify deductions.",
            'HRApproved' => "✓ HR Verification Finalized ({$month} {$year}). Finance please authorize disbursement.",
            'FinanceApproved' => "🔒 Payroll Locked & Authorized for Bank Disbursement ({$month} {$year}). Total: \${$totalAmount} ({$employeeCount} employees)."
        ];

        return $this->send(
            'all',
            'payroll',
            "Payroll Workflow: {$stage} ({$month} {$year})",
            $stageMessages[$stage] ?? "Payroll batch updated to stage: {$stage}.",
            'High',
            'Payroll',
            null,
            null,
            'SYSTEM',
            $actorName,
            'payroll'
        );
    }

    /**
     * Trigger Roster Shift Change Notification
     */
    public function triggerRosterChange(
        string $employeeId,
        string $shiftName,
        string $startTime,
        string $endTime,
        string $effectiveDate,
        string $changedByName = 'Roster Admin'
    ): array {
        $employeeModel = new EmployeeModel();
        $emp = $employeeModel->find($employeeId);
        $empName = $emp ? ($emp['first_name'] . ' ' . $emp['last_name']) : 'Employee';
        $userId = $emp['user_id'] ?? $employeeId;

        return $this->send(
            $userId,
            'attendance',
            "📅 Roster Shift Assigned: {$shiftName}",
            "Your shift schedule has been updated to \"{$shiftName}\" ({$startTime} - {$endTime}) effective from {$effectiveDate}. Updated by {$changedByName}.",
            'Normal',
            'Attendance',
            $employeeId,
            $empName,
            'SYSTEM',
            $changedByName,
            'roster'
        );
    }

    /**
     * Trigger Company Notice Broadcast
     */
    public function triggerCompanyNotice(
        string $title,
        string $category,
        string $content,
        string $publishedByName = 'Corporate Administration',
        string $targetUserId = 'all'
    ): array {
        return $this->send(
            $targetUserId,
            'system',
            "📢 Company Notice: {$title}",
            "Official Announcement ({$category}): " . substr($content, 0, 150) . "... Published by {$publishedByName}.",
            'High',
            'System',
            null,
            null,
            'SYSTEM',
            $publishedByName,
            'notice'
        );
    }

    /**
     * Trigger Security Alert Notification
     */
    public function triggerSecurityAlert(
        string $userId,
        string $alertType,
        string $details,
        string $ipAddress = '103.25.12.18'
    ): array {
        return $this->send(
            $userId,
            'system',
            "🔐 Security Alert: {$alertType}",
            "Security Event: {$details} (IP: {$ipAddress}). If this was not you, please notify IT Security immediately.",
            'Critical',
            'System',
            null,
            null,
            'SYSTEM',
            'Cybersecurity Sentinel',
            'settings'
        );
    }

    /**
     * Trigger Leave Lifecycle Notifications (Legacy wrapper)
     */
    public function triggerLeaveNotification(
        string $employeeId,
        string $leaveType,
        string $startDate,
        string $endDate,
        string $status,
        string $actorName = 'HR Administration'
    ): array {
        $stage = strtolower($status) === 'approved' ? 'hr_approved' : (strtolower($status) === 'rejected' ? 'rejected' : 'submitted');
        return $this->triggerLeaveWorkflow(
            $stage,
            'LV-' . rand(100, 999),
            $employeeId,
            $leaveType,
            $startDate,
            $endDate,
            1.0,
            null,
            $actorName
        );
    }

    /**
     * Trigger Attendance Late Alert
     */
    public function triggerAttendanceAlert(
        string $employeeId,
        string $type,
        string $date,
        string $time,
        int $minutesLate = 15
    ): array {
        $employeeModel = new EmployeeModel();
        $emp = $employeeModel->find($employeeId);
        $empName = $emp ? ($emp['first_name'] . ' ' . $emp['last_name']) : 'Employee';
        $userId = $emp['user_id'] ?? $employeeId;

        $title = "⚠ Late Attendance Alert Triggered";
        $message = "You were marked late on {$date} at {$time} ({$minutesLate} mins past grace period). Please submit a regularization waiver if applicable.";

        $template = $this->templateModel->getTemplateByCode('attendance_late_alert');
        $emailBody = $template ? str_replace(
            ['{EmployeeName}', '{Date}', '{Minutes}'],
            [$empName, $date, (string) $minutesLate],
            $template['body']
        ) : $message;

        return $this->send(
            $userId,
            'attendance',
            $title,
            $message,
            'Normal',
            'Attendance',
            $employeeId,
            $empName,
            'SYSTEM',
            'Biometric Engine',
            'attendance',
            $template['subject'] ?? "Attendance Late Notice",
            $emailBody
        );
    }

    /**
     * Trigger Payroll Generation / Payslip Available
     */
    public function triggerPayrollNotification(
        string $employeeId,
        string $month,
        string $year,
        float $netAmount
    ): array {
        $employeeModel = new EmployeeModel();
        $emp = $employeeModel->find($employeeId);
        $empName = $emp ? ($emp['first_name'] . ' ' . $emp['last_name']) : 'Employee';
        $userId = $emp['user_id'] ?? $employeeId;

        $formattedAmount = '$' . number_format($netAmount, 2);
        $title = "✓ Payslip Ready for Download ({$month} {$year})";
        $message = "Your salary statement for {$month} {$year} has been processed. Net disbursement: {$formattedAmount}.";

        $template = $this->templateModel->getTemplateByCode('payroll_generated');
        $emailBody = $template ? str_replace(
            ['{EmployeeName}', '{Month}', '{Year}', '{Amount}'],
            [$empName, $month, $year, $formattedAmount],
            $template['body']
        ) : $message;

        return $this->send(
            $userId,
            'payroll',
            $title,
            $message,
            'Normal',
            'Payroll',
            $employeeId,
            $empName,
            'SYSTEM',
            'Payroll Engine',
            'payroll',
            $template['subject'] ?? "Payslip Disbursed - {$month} {$year}",
            $emailBody
        );
    }

    /**
     * Trigger Training Assignment Notification
     */
    public function triggerTrainingNotification(
        string $employeeId,
        string $courseName,
        string $date,
        string $time
    ): array {
        $employeeModel = new EmployeeModel();
        $emp = $employeeModel->find($employeeId);
        $empName = $emp ? ($emp['first_name'] . ' ' . $emp['last_name']) : 'Employee';
        $userId = $emp['user_id'] ?? $employeeId;

        $title = "Training Program Assigned: {$courseName}";
        $message = "You have been enrolled in {$courseName} starting {$date} at {$time}. Mandatory attendance is required.";

        $template = $this->templateModel->getTemplateByCode('training_assigned');
        $emailBody = $template ? str_replace(
            ['{EmployeeName}', '{CourseName}'],
            [$empName, $courseName],
            $template['body']
        ) : $message;

        return $this->send(
            $userId,
            'training',
            $title,
            $message,
            'Normal',
            'Training',
            $employeeId,
            $empName,
            'SYSTEM',
            'L&D Department',
            'training',
            $template['subject'] ?? "New Training Course: {$courseName}",
            $emailBody
        );
    }

    /**
     * Broadcast notification to all or targeted user
     */
    public function broadcast(
        string $title,
        string $message,
        string $module = 'System',
        string $priority = 'Normal',
        string $targetUserId = 'all',
        string $createdById = 'SYSTEM',
        string $createdByName = 'Administrator'
    ): array {
        $relatedEmpName = null;
        $relatedEmpId = null;

        if ($targetUserId !== 'all') {
            try {
                $employeeModel = new EmployeeModel();
                $emp = $employeeModel->find($targetUserId);
                if ($emp) {
                    $relatedEmpId = $emp['id'];
                    $relatedEmpName = $emp['first_name'] . ' ' . $emp['last_name'];
                }
            } catch (\Throwable $e) {
                log_message('error', 'NotificationService::broadcast employee lookup error: ' . $e->getMessage());
            }
        }

        return $this->send(
            $targetUserId,
            strtolower($module),
            $title,
            $message,
            $priority,
            $module,
            $relatedEmpId,
            $relatedEmpName,
            $createdById,
            $createdByName,
            strtolower($module)
        );
    }

    /**
     * Flush / process next item in email queue using company-scoped SMTP config.
     *
     * @param string|null $companyId Optional company ID scope
     * @param int $limit Number of items to process (default 1)
     * @return array|null The processed item record or null if queue is empty
     */
    public function processEmailQueue(?string $companyId = null, int $limit = 1): ?array
    {
        $queue = $this->emailQueueModel->getPendingQueue($limit, $companyId);
        if (empty($queue)) {
            return null;
        }

        $item = $queue[0];
        $itemId = $item['id'];
        $itemCompanyId = $item['company_id'] ?? $companyId;
        $receiverEmail = trim((string)($item['receiver_email'] ?? ''));

        // Validate recipient email
        if (empty($receiverEmail) || !filter_var($receiverEmail, FILTER_VALIDATE_EMAIL)) {
            $errorMessage = 'Recipient email address is missing or invalid: ' . ($receiverEmail ?: '(empty)');
            log_message('warning', "NotificationService::processEmailQueue: Item {$itemId} skipped. {$errorMessage}");

            $retryCount = (int)($item['retry_count'] ?? 0) + 1;
            $this->emailQueueModel->update($itemId, [
                'status'        => 'Failed',
                'error_message' => $errorMessage,
                'retry_count'   => $retryCount,
            ]);

            $this->emailLogModel->logEmail([
                'company_id'     => $itemCompanyId,
                'receiver_email' => $receiverEmail ?: 'no-valid-email',
                'receiver_name'  => $item['receiver_name'] ?? null,
                'subject'        => $item['subject'] ?? 'HRMS Alert',
                'body'           => $item['body'] ?? '',
                'module'         => $item['module'] ?? 'System',
                'status'         => 'Failed',
                'error_message'  => $errorMessage,
                'sent_at'        => null,
                'created_at'     => date('Y-m-d H:i:s'),
            ]);

            $item['status']        = 'Failed';
            $item['error_message'] = $errorMessage;
            $item['retry_count']   = $retryCount;
            return $item;
        }

        // Attempt actual dispatch via CI4 Email with company-specific SMTP config
        try {
            $emailService = SmtpConfigResolver::createEmailService($itemCompanyId);
            $emailService->setTo($receiverEmail, $item['receiver_name'] ?? '');
            $emailService->setSubject($item['subject'] ?? 'HRMS Alert');
            $emailService->setMessage($item['body'] ?? '');

            $sent = $emailService->send(false);

            if ($sent) {
                $sentAt = date('Y-m-d H:i:s');
                $this->emailQueueModel->update($itemId, [
                    'status'        => 'Sent',
                    'sent_at'       => $sentAt,
                    'error_message' => null,
                ]);

                $this->emailLogModel->logEmail([
                    'company_id'     => $itemCompanyId,
                    'receiver_email' => $receiverEmail,
                    'receiver_name'  => $item['receiver_name'] ?? null,
                    'subject'        => $item['subject'] ?? 'HRMS Alert',
                    'body'           => $item['body'] ?? '',
                    'module'         => $item['module'] ?? 'System',
                    'status'         => 'Sent',
                    'error_message'  => null,
                    'sent_at'        => $sentAt,
                    'created_at'     => $item['created_at'] ?? $sentAt,
                ]);

                $item['status']        = 'Sent';
                $item['sent_at']       = $sentAt;
                $item['error_message'] = null;
                return $item;
            }

            // SMTP send returned false
            $debugger = strip_tags((string)$emailService->printDebugger(['headers', 'subject']));
            $errorMessage = !empty($debugger)
                ? mb_substr($debugger, 0, 1000)
                : 'SMTP delivery failed. Verify host, port, credentials, and TLS.';

            log_message('warning', "NotificationService::processEmailQueue: Item {$itemId} delivery failed: {$errorMessage}");

            $retryCount = (int)($item['retry_count'] ?? 0) + 1;
            $this->emailQueueModel->update($itemId, [
                'status'        => 'Failed',
                'error_message' => $errorMessage,
                'retry_count'   => $retryCount,
            ]);

            $this->emailLogModel->logEmail([
                'company_id'     => $itemCompanyId,
                'receiver_email' => $receiverEmail,
                'receiver_name'  => $item['receiver_name'] ?? null,
                'subject'        => $item['subject'] ?? 'HRMS Alert',
                'body'           => $item['body'] ?? '',
                'module'         => $item['module'] ?? 'System',
                'status'         => 'Failed',
                'error_message'  => $errorMessage,
                'sent_at'        => null,
                'created_at'     => date('Y-m-d H:i:s'),
            ]);

            $item['status']        = 'Failed';
            $item['error_message'] = $errorMessage;
            $item['retry_count']   = $retryCount;
            return $item;
        } catch (\Throwable $e) {
            $errorMessage = 'Exception during SMTP send: ' . $e->getMessage();
            log_message('error', "NotificationService::processEmailQueue: Item {$itemId} exception: {$errorMessage}");

            $retryCount = (int)($item['retry_count'] ?? 0) + 1;
            $this->emailQueueModel->update($itemId, [
                'status'        => 'Failed',
                'error_message' => mb_substr($errorMessage, 0, 1000),
                'retry_count'   => $retryCount,
            ]);

            $this->emailLogModel->logEmail([
                'company_id'     => $itemCompanyId,
                'receiver_email' => $receiverEmail,
                'receiver_name'  => $item['receiver_name'] ?? null,
                'subject'        => $item['subject'] ?? 'HRMS Alert',
                'body'           => $item['body'] ?? '',
                'module'         => $item['module'] ?? 'System',
                'status'         => 'Failed',
                'error_message'  => mb_substr($errorMessage, 0, 1000),
                'sent_at'        => null,
                'created_at'     => date('Y-m-d H:i:s'),
            ]);

            $item['status']        = 'Failed';
            $item['error_message'] = $errorMessage;
            $item['retry_count']   = $retryCount;
            return $item;
        }
    }

    /**
     * Send an email directly using company-scoped SMTP config without adding to queue.
     *
     * @param string $receiverEmail
     * @param string $subject
     * @param string $body
     * @param string|null $receiverName
     * @param string|null $companyId
     * @param string $module
     * @return array ['success' => bool, 'message' => string]
     */
    public function sendEmailDirect(
        string $receiverEmail,
        string $subject,
        string $body,
        ?string $receiverName = null,
        ?string $companyId = null,
        string $module = 'System'
    ): array {
        $receiverEmail = trim($receiverEmail);
        if (empty($receiverEmail) || !filter_var($receiverEmail, FILTER_VALIDATE_EMAIL)) {
            log_message('warning', "NotificationService::sendEmailDirect skipped: invalid receiver email '{$receiverEmail}'");
            return [
                'success' => false,
                'message' => 'Receiver email is empty or invalid',
            ];
        }

        try {
            $emailService = SmtpConfigResolver::createEmailService($companyId);
            $emailService->setTo($receiverEmail, $receiverName ?? '');
            $emailService->setSubject($subject);
            $emailService->setMessage($body);

            $sent = $emailService->send(false);
            if ($sent) {
                $sentAt = date('Y-m-d H:i:s');
                $this->emailLogModel->logEmail([
                    'company_id'     => $companyId,
                    'receiver_email' => $receiverEmail,
                    'receiver_name'  => $receiverName,
                    'subject'        => $subject,
                    'body'           => $body,
                    'module'         => $module,
                    'status'         => 'Sent',
                    'error_message'  => null,
                    'sent_at'        => $sentAt,
                ]);
                return ['success' => true, 'message' => 'Email sent successfully'];
            }

            $debugger = strip_tags((string)$emailService->printDebugger(['headers', 'subject']));
            $error = !empty($debugger) ? mb_substr($debugger, 0, 1000) : 'SMTP dispatch failed';

            $this->emailLogModel->logEmail([
                'company_id'     => $companyId,
                'receiver_email' => $receiverEmail,
                'receiver_name'  => $receiverName,
                'subject'        => $subject,
                'body'           => $body,
                'module'         => $module,
                'status'         => 'Failed',
                'error_message'  => $error,
                'sent_at'        => null,
            ]);
            return ['success' => false, 'message' => $error];
        } catch (\Throwable $e) {
            $msg = $e->getMessage();
            log_message('error', "NotificationService::sendEmailDirect exception: {$msg}");
            $this->emailLogModel->logEmail([
                'company_id'     => $companyId,
                'receiver_email' => $receiverEmail,
                'receiver_name'  => $receiverName,
                'subject'        => $subject,
                'body'           => $body,
                'module'         => $module,
                'status'         => 'Failed',
                'error_message'  => mb_substr($msg, 0, 1000),
                'sent_at'        => null,
            ]);
            return ['success' => false, 'message' => $msg];
        }
    }

    /**
     * Employment Period & Contract Expiry Multi-Channel HR Notification Dispatcher
     * Supports: 'Expiring Soon', 'Completed', 'Expired', 'Extension', 'Renewal'
     */
    public function triggerEmploymentPeriodNotification(
        string $status,
        array $employee,
        string $employmentTypeName,
        string $startDate,
        string $endDate,
        int $remainingDays,
        ?string $companyId = null
    ): array {
        $empName = trim(($employee['first_name'] ?? '') . ' ' . ($employee['last_name'] ?? ''));
        $empCode = $employee['employee_code'] ?? ($employee['id'] ?? 'N/A');
        $empId   = $employee['id'] ?? '';

        $titlePrefix = match ($status) {
            'Expiring Soon' => '⏳ [Expiring Soon] Contract Term Approaching Completion',
            'Completed'     => '✓ [Completed Today] Employment Period Completed',
            'Expired'       => '🚨 [Expired] Employment Contract Overdue / Expired',
            'Extension'     => '📝 [Contract Extension] Employment Period Extended',
            'Renewal'       => '🔄 [Contract Renewal] Employment Contract Renewed',
            default         => '📋 [Employment Notice] Contract Term Status Update'
        };

        $title = "{$titlePrefix}: {$empName} ({$empCode})";

        $remainingLabel = match (true) {
            $remainingDays < 0   => abs($remainingDays) . ' day(s) overdue (Expired)',
            $remainingDays === 0 => 'Ends today (0 days remaining)',
            default              => "{$remainingDays} day(s) remaining"
        };

        $priority = match ($status) {
            'Expired'       => 'Urgent',
            'Completed'     => 'High',
            'Expiring Soon' => 'High',
            default         => 'Normal'
        };

        $message = "Employee Name: {$empName}\n"
                 . "Employee ID: {$empCode}\n"
                 . "Employment Type: {$employmentTypeName}\n"
                 . "Start Date: {$startDate}\n"
                 . "End Date: {$endDate}\n"
                 . "Remaining Days: {$remainingLabel}\n"
                 . "Status: {$status}";

        $link = "employees/profile/{$empId}?tab=employment";

        $emailSubject = "[HR Alert] Employment Period {$status}: {$empName} ({$empCode})";
        $emailBody    = "Dear HR Team,\n\n"
                      . "Please be advised of an employment period milestone for the following employee:\n\n"
                      . "• Employee Name: {$empName}\n"
                      . "• Employee ID: {$empCode}\n"
                      . "• Employment Type: {$employmentTypeName}\n"
                      . "• Start Date: {$startDate}\n"
                      . "• End Date: {$endDate}\n"
                      . "• Remaining Days: {$remainingLabel}\n"
                      . "• Status: {$status}\n\n"
                      . "Action Required: Please review this contract for confirmation, extension, or renewal in the Master Console or Employee Profile.\n\n"
                      . "Link: " . base_url($link);

        // Find HR / Admin users for this company
        $userModel = new UserModel();
        $targetUsers = [];
        try {
            $uBuilder = $userModel->builder();
            $uBuilder->select('users.id, users.email, users.username as name')
                     ->join('roles', 'roles.id = users.role_id', 'left')
                     ->groupStart()
                         ->like('roles.slug', 'admin')
                         ->orLike('roles.slug', 'hr')
                         ->orLike('roles.name', 'Admin')
                         ->orLike('roles.name', 'HR')
                     ->groupEnd();

            if (!empty($companyId)) {
                $uBuilder->groupStart()
                         ->where('users.company_id', $companyId)
                         ->orWhere('users.company_id', null)
                         ->groupEnd();
            }

            $targetUsers = $uBuilder->get()->getResultArray();
        } catch (\Throwable $e) {
            log_message('error', 'NotificationService::triggerEmploymentPeriodNotification query error: ' . $e->getMessage());
            $targetUsers = [];
        }

        if (empty($targetUsers)) {
            // Fallback to any company admin or active users
            try {
                $fBuilder = $userModel->builder();
                $fBuilder->select('users.id, users.email, users.username as name');
                if (!empty($companyId)) {
                    $fBuilder->groupStart()
                             ->where('users.company_id', $companyId)
                             ->orWhere('users.company_id', null)
                             ->groupEnd();
                }
                $targetUsers = $fBuilder->limit(10)->get()->getResultArray();
                if (empty($targetUsers)) {
                    $targetUsers = $userModel->builder()->select('users.id, users.email, users.username as name')->limit(10)->get()->getResultArray();
                }
            } catch (\Throwable $ex) {
                log_message('error', 'NotificationService::triggerEmploymentPeriodNotification fallback error: ' . $ex->getMessage());
                $targetUsers = [];
            }
        }

        if (empty($targetUsers)) {
            // Broadcast fallback
            return $this->send(
                'all',
                'employment',
                $title,
                $message,
                $priority,
                'Master',
                $empId,
                $empName,
                'SYSTEM',
                'System Policy Engine',
                $link,
                $emailSubject,
                $emailBody
            );
        }

        $results = [];
        foreach ($targetUsers as $usr) {
            $results[] = $this->send(
                $usr['id'],
                'employment',
                $title,
                $message,
                $priority,
                'Master',
                $empId,
                $empName,
                'SYSTEM',
                'System Policy Engine',
                $link,
                $emailSubject,
                $emailBody
            );
        }

        return ['status' => 'success', 'dispatched' => count($results)];
    }

    /**
     * Dispatch notification to all active HR and Admin users for a company/tenant.
     */
    public function notifyAdmins(
        string $title,
        string $message,
        string $module = 'system',
        ?string $linkOrId = null,
        ?string $companyId = null,
        ?string $employeeId = null
    ): array {
        return $this->notificationModel->notifyAdmins($title, $message, $module, $linkOrId, $companyId, $employeeId);
    }
}
