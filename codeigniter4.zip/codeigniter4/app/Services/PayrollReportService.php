<?php

namespace App\Services;

use Config\Database;
use App\Services\Concerns\JoinsActiveSalary;

/**
 * Class PayrollReportService
 *
 * Enterprise Multi-Tenant Financial & Payroll Gap Reporting Engine.
 * Implements all 9 architectural Payroll reports:
 * 1. gross_to_net
 * 2. department_payroll
 * 3. branch_payroll
 * 4. payroll_variance
 * 5. payroll_exception
 * 6. salary_arrear
 * 7. salary_revision_increment
 * 8. ctc_report
 * 9. payroll_lock_unlock_audit
 *
 * Strict tenant isolation enforced on every query.
 */
class PayrollReportService
{
    use JoinsActiveSalary;

    protected $db;

    public function __construct()
    {
        $this->db = Database::connect();
    }

    /**
     * Complete Catalog of the 9 Financial & Payroll Gap Reports
     */
    public static function getReportCatalog(): array
    {
        return [
            'gross_to_net' => [
                'number'      => 69,
                'code'        => 'gross_to_net',
                'title'       => 'Gross-to-Net Salary Waterfall Register',
                'description' => 'Granular financial breakdown tracing basic, allowances, overtime, statutory deductions to net salary',
                'category'    => 'Payroll & Financial Gaps',
            ],
            'department_payroll' => [
                'number'      => 70,
                'code'        => 'department_payroll',
                'title'       => 'Departmental Payroll Summary',
                'description' => 'Department-wise aggregation of gross pay, statutory taxes, retirement contributions, and total net disbursals',
                'category'    => 'Payroll & Financial Gaps',
            ],
            'branch_payroll' => [
                'number'      => 71,
                'code'        => 'branch_payroll',
                'title'       => 'Branch-wise Payroll Summary',
                'description' => 'Branch location summary of workforce compensation, employer obligations, and regional wage expenditures',
                'category'    => 'Payroll & Financial Gaps',
            ],
            'payroll_variance' => [
                'number'      => 72,
                'code'        => 'payroll_variance',
                'title'       => 'Month-over-Month Payroll Variance Report',
                'description' => 'Analytical delta report comparing current month versus previous month gross, net, and component shifts',
                'category'    => 'Payroll & Financial Gaps',
            ],
            'payroll_exception' => [
                'number'      => 73,
                'code'        => 'payroll_exception',
                'title'       => 'Payroll Integrity & Anomaly Exception Report',
                'description' => 'Compliance audit flagging negative net salaries, missing structures, ceiling breaches, and abnormal salary spikes',
                'category'    => 'Payroll & Financial Gaps',
            ],
            'salary_arrear' => [
                'number'      => 74,
                'code'        => 'salary_arrear',
                'title'       => 'Salary Arrears Register',
                'description' => 'Log of retroactive adjustments, basic salary deltas, retroactive PF contributions, and disbursed arrears',
                'category'    => 'Payroll & Financial Gaps',
            ],
            'salary_revision_increment' => [
                'number'      => 75,
                'code'        => 'salary_revision_increment',
                'title'       => 'Salary Revision & Increment Audit',
                'description' => 'Historical archive of compensation grade revisions, merit increments, and percentage adjustments',
                'category'    => 'Payroll & Financial Gaps',
            ],
            'ctc_report' => [
                'number'      => 76,
                'code'        => 'ctc_report',
                'title'       => 'Cost to Company (CTC) Analysis',
                'description' => 'Total cost to company breakdown incorporating employer PF match, statutory gratuity provisions, and benefits',
                'category'    => 'Payroll & Financial Gaps',
            ],
            'payroll_lock_unlock_audit' => [
                'number'      => 77,
                'code'        => 'payroll_lock_unlock_audit',
                'title'       => 'Payroll Batch Lock & Governance Audit',
                'description' => 'Security and governance audit log of payroll generation locks, batch freeze timestamps, and authorized actors',
                'category'    => 'Payroll & Financial Gaps',
            ],
        ];
    }

    /**
     * Dispatch report generation by code
     */
    public function generateReport(string $code, string $companyId, array $filters = []): array
    {
        if (trim($companyId) === '') {
            throw new \InvalidArgumentException('PayrollReportService: $companyId is required and cannot be empty.');
        }

        $normalized = strtolower(trim($code));

        switch ($normalized) {
            case 'gross_to_net':
            case 'salary_waterfall':
            case '69':
                return $this->grossToNet($companyId, $filters);

            case 'department_payroll':
            case 'dept_payroll':
            case '70':
                return $this->departmentPayroll($companyId, $filters);

            case 'branch_payroll':
            case '71':
                return $this->branchPayroll($companyId, $filters);

            case 'payroll_variance':
            case 'salary_variance':
            case '72':
                return $this->payrollVariance($companyId, $filters);

            case 'payroll_exception':
            case 'payroll_anomalies':
            case '73':
                return $this->payrollException($companyId, $filters);

            case 'salary_arrear':
            case 'arrears_register':
            case '74':
                return $this->salaryArrear($companyId, $filters);

            case 'salary_revision_increment':
            case 'salary_revisions':
            case '75':
                return $this->salaryRevisionIncrement($companyId, $filters);

            case 'ctc_report':
            case 'ctc_analysis':
            case '76':
                return $this->ctcReport($companyId, $filters);

            case 'payroll_lock_unlock_audit':
            case 'payroll_lock_audit':
            case '77':
                return $this->payrollLockUnlockAudit($companyId, $filters);

            default:
                throw new \InvalidArgumentException("PayrollReportService: Unknown report code '{$code}'.");
        }
    }

    /**
     * 1. Gross-to-Net Salary Waterfall Register
     */
    public function grossToNet(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Payroll Month', 'Employee Code', 'Employee Name', 'Department',
            'Basic', 'House Rent', 'Medical', 'Conveyance', 'Allowances', 'Overtime', 'Bonus', 'Gross Salary',
            'Tax (TDS)', 'PF', 'Loan EMI', 'Advance', 'Unpaid LOP', 'Total Deductions', 'Net Salary', 'Status'
        ];

        $month = $filters['payroll_month'] ?? ($filters['month'] ?? date('Y-m'));

        $builder = $this->db->table('payroll_items pi')
            ->select("pi.id, p.payroll_month, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name,
                pi.basic_salary, pi.house_rent, pi.medical, pi.conveyance, pi.allowances, pi.other_allowances, pi.overtime_amount, pi.bonus_amount, pi.gross_salary,
                pi.tax_deduction, pi.pf_deduction, pi.loan_emi, pi.advance_recovery, pi.unpaid_leave_deduction, pi.total_deductions, pi.net_salary, pi.payment_status")
            ->join('payrolls p', 'p.id = pi.payroll_id', 'left')
            ->join('employees e', 'e.id = pi.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');

        if (!empty($filters['payroll_month'])) {
            $builder->where('p.payroll_month', $filters['payroll_month']);
        } elseif (!empty($filters['from']) && !empty($filters['to'])) {
            $builder->where('p.payroll_month >=', date('Y-m', strtotime($filters['from'])))
                    ->where('p.payroll_month <=', date('Y-m', strtotime($filters['to'])));
        }

        $records = $builder->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

        $rows = [];
        $exceptions = [];
        $sl = 1;
        $totalBasic = 0.0;
        $totalGross = 0.0;
        $totalTax = 0.0;
        $totalPf = 0.0;
        $totalDeductions = 0.0;
        $totalNet = 0.0;

        foreach ($records as $r) {
            $basic = (float)($r['basic_salary'] ?? 0.0);
            $hr = (float)($r['house_rent'] ?? 0.0);
            $med = (float)($r['medical'] ?? 0.0);
            $conv = (float)($r['conveyance'] ?? 0.0);
            $allow = (float)($r['allowances'] ?? 0.0) + (float)($r['other_allowances'] ?? 0.0);
            $ot = (float)($r['overtime_amount'] ?? 0.0);
            $bonus = (float)($r['bonus_amount'] ?? 0.0);
            $gross = (float)($r['gross_salary'] ?? 0.0);

            $tax = (float)($r['tax_deduction'] ?? 0.0);
            $pf = (float)($r['pf_deduction'] ?? 0.0);
            $loan = (float)($r['loan_emi'] ?? 0.0);
            $adv = (float)($r['advance_recovery'] ?? 0.0);
            $lop = (float)($r['unpaid_leave_deduction'] ?? 0.0);
            $ded = (float)($r['total_deductions'] ?? 0.0);
            $net = (float)($r['net_salary'] ?? 0.0);

            if ($net < 0) {
                $exceptions[] = [
                    'employee_code' => $r['employee_code'],
                    'name'          => $r['employee_name'],
                    'issue'         => "Negative net salary: {$net}"
                ];
            }

            $totalBasic += $basic;
            $totalGross += $gross;
            $totalTax += $tax;
            $totalPf += $pf;
            $totalDeductions += $ded;
            $totalNet += $net;

            $rows[] = [
                $sl++,
                $r['payroll_month'] ?? '-',
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                number_format($basic, 2),
                number_format($hr, 2),
                number_format($med, 2),
                number_format($conv, 2),
                number_format($allow, 2),
                number_format($ot, 2),
                number_format($bonus, 2),
                number_format($gross, 2),
                number_format($tax, 2),
                number_format($pf, 2),
                number_format($loan, 2),
                number_format($adv, 2),
                number_format($lop, 2),
                number_format($ded, 2),
                number_format($net, 2),
                $r['payment_status'] ?? 'Draft'
            ];
        }

        // Grand Total row
        $count = count($records);
        $rows[] = [
            'TOTAL',
            $month,
            'Grand Total',
            "Count: {$count}",
            '-',
            number_format($totalBasic, 2),
            '-',
            '-',
            '-',
            '-',
            '-',
            '-',
            number_format($totalGross, 2),
            number_format($totalTax, 2),
            number_format($totalPf, 2),
            '-',
            '-',
            '-',
            number_format($totalDeductions, 2),
            number_format($totalNet, 2),
            '-'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count'     => $count,
                'total_basic'      => $totalBasic,
                'total_gross'      => $totalGross,
                'total_tax'        => $totalTax,
                'total_pf'         => $totalPf,
                'total_deductions' => $totalDeductions,
                'total_net'        => $totalNet,
                'exceptions'       => count($exceptions)
            ],
            'exceptions' => $exceptions
        ];
    }

    /**
     * 2. Departmental Payroll Summary
     */
    public function departmentPayroll(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Department Name', 'Headcount', 'Total Basic', 'Total Gross',
            'Total Overtime', 'Total Tax (TDS)', 'Total PF', 'Total Net Disbursed', 'Employer Statutory Costs', 'Total Department CTC'
        ];

        $month = $filters['payroll_month'] ?? ($filters['month'] ?? date('Y-m'));

        $builder = $this->db->table('departments d')
            ->select("d.id, d.name as department_name,
                COUNT(pi.id) as headcount,
                SUM(COALESCE(pi.basic_salary, 0)) as total_basic,
                SUM(COALESCE(pi.gross_salary, 0)) as total_gross,
                SUM(COALESCE(pi.overtime_amount, 0)) as total_ot,
                SUM(COALESCE(pi.tax_deduction, 0)) as total_tax,
                SUM(COALESCE(pi.pf_deduction, 0)) as total_pf,
                SUM(COALESCE(pi.net_salary, 0)) as total_net,
                SUM(COALESCE(pi.employer_pf_contribution, 0) + COALESCE(pi.gratuity_provision, 0)) as employer_costs")
            ->join('employees e', 'e.department_id = d.id AND e.deleted_at IS NULL', 'left')
            ->join('payrolls p', 'p.company_id = ' . $this->db->escape($companyId) . " AND p.payroll_month = '{$month}'", 'left')
            ->join('payroll_items pi', 'pi.payroll_id = p.id AND pi.employee_id = e.id', 'left')
            ->where('d.company_id', $companyId)
            ->groupBy('d.id, d.name');

        $records = $builder->orderBy('total_gross', 'DESC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $grandHeadcount = 0;
        $grandBasic = 0.0;
        $grandGross = 0.0;
        $grandOt = 0.0;
        $grandTax = 0.0;
        $grandPf = 0.0;
        $grandNet = 0.0;
        $grandEmployer = 0.0;
        $grandCtc = 0.0;

        foreach ($records as $r) {
            $hc = (int)($r['headcount'] ?? 0);
            $basic = (float)($r['total_basic'] ?? 0.0);
            $gross = (float)($r['total_gross'] ?? 0.0);
            $ot = (float)($r['total_ot'] ?? 0.0);
            $tax = (float)($r['total_tax'] ?? 0.0);
            $pf = (float)($r['total_pf'] ?? 0.0);
            $net = (float)($r['total_net'] ?? 0.0);
            $empCosts = (float)($r['employer_costs'] ?? 0.0);
            $deptCtc = $gross + $empCosts;

            $grandHeadcount += $hc;
            $grandBasic += $basic;
            $grandGross += $gross;
            $grandOt += $ot;
            $grandTax += $tax;
            $grandPf += $pf;
            $grandNet += $net;
            $grandEmployer += $empCosts;
            $grandCtc += $deptCtc;

            $rows[] = [
                $sl++,
                $r['department_name'] ?? 'General',
                $hc,
                number_format($basic, 2),
                number_format($gross, 2),
                number_format($ot, 2),
                number_format($tax, 2),
                number_format($pf, 2),
                number_format($net, 2),
                number_format($empCosts, 2),
                number_format($deptCtc, 2)
            ];
        }

        // Grand Total row
        $count = count($records);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            $grandHeadcount,
            number_format($grandBasic, 2),
            number_format($grandGross, 2),
            number_format($grandOt, 2),
            number_format($grandTax, 2),
            number_format($grandPf, 2),
            number_format($grandNet, 2),
            number_format($grandEmployer, 2),
            number_format($grandCtc, 2)
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'total_departments' => $count,
                'total_headcount'   => $grandHeadcount,
                'total_gross'       => $grandGross,
                'total_net'         => $grandNet,
                'total_ctc'         => $grandCtc
            ],
            'exceptions' => []
        ];
    }

    /**
     * 3. Branch-wise Payroll Summary
     */
    public function branchPayroll(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Branch Name', 'Employee Count', 'Total Gross Salary', 'Total Deductions',
            'Net Disbursed', 'Employer Benefits/Statutory', 'Average Net per Employee'
        ];

        $month = $filters['payroll_month'] ?? ($filters['month'] ?? date('Y-m'));

        $builder = $this->db->table('branches b')
            ->select("b.id, b.name as branch_name,
                COUNT(pi.id) as emp_count,
                SUM(COALESCE(pi.gross_salary, 0)) as total_gross,
                SUM(COALESCE(pi.total_deductions, 0)) as total_ded,
                SUM(COALESCE(pi.net_salary, 0)) as total_net,
                SUM(COALESCE(pi.employer_pf_contribution, 0) + COALESCE(pi.gratuity_provision, 0)) as total_employer")
            ->join('employees e', 'e.branch_id = b.id AND e.deleted_at IS NULL', 'left')
            ->join('payrolls p', 'p.company_id = ' . $this->db->escape($companyId) . " AND p.payroll_month = '{$month}'", 'left')
            ->join('payroll_items pi', 'pi.payroll_id = p.id AND pi.employee_id = e.id', 'left')
            ->where('b.company_id', $companyId)
            ->groupBy('b.id, b.name');

        $records = $builder->orderBy('total_gross', 'DESC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $grandEmps = 0;
        $grandGross = 0.0;
        $grandDed = 0.0;
        $grandNet = 0.0;
        $grandEmployer = 0.0;

        foreach ($records as $r) {
            $emps = (int)($r['emp_count'] ?? 0);
            $gross = (float)($r['total_gross'] ?? 0.0);
            $ded = (float)($r['total_ded'] ?? 0.0);
            $net = (float)($r['total_net'] ?? 0.0);
            $employer = (float)($r['total_employer'] ?? 0.0);
            $avgNet = ($emps > 0) ? round($net / $emps, 2) : 0.0;

            $grandEmps += $emps;
            $grandGross += $gross;
            $grandDed += $ded;
            $grandNet += $net;
            $grandEmployer += $employer;

            $rows[] = [
                $sl++,
                $r['branch_name'] ?? 'Main Branch',
                $emps,
                number_format($gross, 2),
                number_format($ded, 2),
                number_format($net, 2),
                number_format($employer, 2),
                number_format($avgNet, 2)
            ];
        }

        // Grand Total row
        $count = count($records);
        $overallAvg = ($grandEmps > 0) ? round($grandNet / $grandEmps, 2) : 0.0;
        $rows[] = [
            'TOTAL',
            'Grand Total',
            $grandEmps,
            number_format($grandGross, 2),
            number_format($grandDed, 2),
            number_format($grandNet, 2),
            number_format($grandEmployer, 2),
            number_format($overallAvg, 2)
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'branch_count'    => $count,
                'total_employees' => $grandEmps,
                'total_gross'     => $grandGross,
                'total_net'       => $grandNet
            ],
            'exceptions' => []
        ];
    }

    /**
     * 4. Month-over-Month Payroll Variance Report
     */
    public function payrollVariance(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Employee Code', 'Employee Name', 'Department',
            'Prev Month Gross', 'Current Month Gross', 'Gross Variance ($)', 'Gross Delta (%)',
            'Prev Month Net', 'Current Month Net', 'Net Variance ($)', 'Variance Status'
        ];

        $currentMonth = $filters['payroll_month'] ?? ($filters['month'] ?? date('Y-m'));
        $prevMonth = date('Y-m', strtotime("{$currentMonth}-01 -1 month"));

        $builder = $this->db->table('employees e')
            ->select("e.id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name,
                pi_curr.gross_salary as curr_gross, pi_curr.net_salary as curr_net,
                pi_prev.gross_salary as prev_gross, pi_prev.net_salary as prev_net")
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('payrolls p_curr', 'p_curr.company_id = ' . $this->db->escape($companyId) . " AND p_curr.payroll_month = '{$currentMonth}'", 'left')
            ->join('payroll_items pi_curr', 'pi_curr.payroll_id = p_curr.id AND pi_curr.employee_id = e.id', 'left')
            ->join('payrolls p_prev', 'p_prev.company_id = ' . $this->db->escape($companyId) . " AND p_prev.payroll_month = '{$prevMonth}'", 'left')
            ->join('payroll_items pi_prev', 'pi_prev.payroll_id = p_prev.id AND pi_prev.employee_id = e.id', 'left');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $records = $builder->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

        $rows = [];
        $exceptions = [];
        $sl = 1;
        $totalPrevGross = 0.0;
        $totalCurrGross = 0.0;
        $totalGrossVar = 0.0;
        $totalPrevNet = 0.0;
        $totalCurrNet = 0.0;
        $totalNetVar = 0.0;

        foreach ($records as $r) {
            $prevGross = (float)($r['prev_gross'] ?? 0.0);
            $currGross = (float)($r['curr_gross'] ?? 0.0);
            $prevNet = (float)($r['prev_net'] ?? 0.0);
            $currNet = (float)($r['curr_net'] ?? 0.0);

            if ($prevGross <= 0 && $currGross <= 0) {
                continue;
            }

            $grossDelta = round($currGross - $prevGross, 2);
            $netDelta = round($currNet - $prevNet, 2);
            $grossPct = ($prevGross > 0) ? round(($grossDelta / $prevGross) * 100, 1) : ($currGross > 0 ? 100.0 : 0.0);

            $status = 'Stable';
            if ($grossPct > 20) {
                $status = 'Significant Increase';
            } elseif ($grossPct < -20) {
                $status = 'Significant Decrease';
            } elseif ($prevGross <= 0 && $currGross > 0) {
                $status = 'New Joiner';
            } elseif ($currGross <= 0 && $prevGross > 0) {
                $status = 'Separated / Unpaid';
            }

            if (abs($grossPct) > 50 && $prevGross > 0) {
                $exceptions[] = [
                    'employee_code' => $r['employee_code'],
                    'name'          => $r['employee_name'],
                    'issue'         => "Abnormal salary variance of {$grossPct}%"
                ];
            }

            $totalPrevGross += $prevGross;
            $totalCurrGross += $currGross;
            $totalGrossVar += $grossDelta;
            $totalPrevNet += $prevNet;
            $totalCurrNet += $currNet;
            $totalNetVar += $netDelta;

            $rows[] = [
                $sl++,
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                number_format($prevGross, 2),
                number_format($currGross, 2),
                number_format($grossDelta, 2),
                ($grossDelta >= 0 ? '+' : '') . $grossPct . '%',
                number_format($prevNet, 2),
                number_format($currNet, 2),
                number_format($netDelta, 2),
                $status
            ];
        }

        // Grand Total row
        $count = count($rows);
        $overallGrossPct = ($totalPrevGross > 0) ? round(($totalGrossVar / $totalPrevGross) * 100, 1) : 0.0;
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Count: {$count}",
            '-',
            number_format($totalPrevGross, 2),
            number_format($totalCurrGross, 2),
            number_format($totalGrossVar, 2),
            ($totalGrossVar >= 0 ? '+' : '') . $overallGrossPct . '%',
            number_format($totalPrevNet, 2),
            number_format($totalCurrNet, 2),
            number_format($totalNetVar, 2),
            count($exceptions) > 0 ? (count($exceptions) . ' High Variance Anomalies') : 'Verified'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count'     => $count,
                'prev_total_gross' => $totalPrevGross,
                'curr_total_gross' => $totalCurrGross,
                'gross_variance'   => $totalGrossVar,
                'net_variance'     => $totalNetVar,
                'exceptions'       => count($exceptions)
            ],
            'exceptions' => $exceptions
        ];
    }

    /**
     * 5. Payroll Integrity & Anomaly Exception Report
     */
    public function payrollException(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Payroll Month', 'Employee Code', 'Employee Name', 'Department',
            'Basic', 'Gross', 'Net Salary', 'Exception Type', 'Severity', 'Recommended Action'
        ];

        $month = $filters['payroll_month'] ?? ($filters['month'] ?? date('Y-m'));

        $salJoin = $this->getActiveSalaryJoin('e', 'es');
        $builder = $this->db->table('employees e')
            ->select("e.id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name, COALESCE(es.basic_salary, e.basic_salary, 0) as active_basic, COALESCE(es.gross_salary, e.gross_salary, 0) as active_gross, pi.basic_salary as paid_basic, pi.gross_salary as paid_gross, pi.net_salary as paid_net, pi.unapplied_tax, pi.unapplied_pf, p.payroll_month")
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('employee_salaries es', $salJoin, 'left')
            ->join('payrolls p', 'p.company_id = ' . $this->db->escape($companyId) . " AND p.payroll_month = '{$month}'", 'left')
            ->join('payroll_items pi', 'pi.payroll_id = p.id AND pi.employee_id = e.id', 'left');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $records = $builder->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

        $rows = [];
        $exceptions = [];
        $sl = 1;

        foreach ($records as $r) {
            $activeGross = (float)($r['active_gross'] ?? 0.0);
            $paidGross = (float)($r['paid_gross'] ?? 0.0);
            $paidNet = (float)($r['paid_net'] ?? 0.0);
            $paidBasic = (float)($r['paid_basic'] ?? 0.0);
            $unappliedTax = (float)($r['unapplied_tax'] ?? 0.0);

            // 1. Missing active salary configuration
            if ($activeGross <= 0) {
                $rows[] = [
                    $sl++,
                    $month,
                    $r['employee_code'] ?? '-',
                    trim($r['employee_name'] ?? 'Unknown'),
                    $r['department_name'] ?? 'General',
                    '0.00',
                    '0.00',
                    '0.00',
                    'Missing Active Salary Structure',
                    'Critical',
                    'Assign salary structure before running payroll'
                ];
                $exceptions[] = ['code' => $r['employee_code'], 'type' => 'Missing Structure'];
            }

            // 2. Negative net salary
            if ($paidNet < 0) {
                $rows[] = [
                    $sl++,
                    $month,
                    $r['employee_code'] ?? '-',
                    trim($r['employee_name'] ?? 'Unknown'),
                    $r['department_name'] ?? 'General',
                    number_format($paidBasic, 2),
                    number_format($paidGross, 2),
                    number_format($paidNet, 2),
                    'Negative Net Salary Breached',
                    'Critical',
                    'Apply ceiling deductions limiter immediately'
                ];
                $exceptions[] = ['code' => $r['employee_code'], 'type' => 'Negative Net'];
            }

            // 3. Unapplied statutory deductions (ceiling breach)
            if ($unappliedTax > 0) {
                $rows[] = [
                    $sl++,
                    $month,
                    $r['employee_code'] ?? '-',
                    trim($r['employee_name'] ?? 'Unknown'),
                    $r['department_name'] ?? 'General',
                    number_format($paidBasic, 2),
                    number_format($paidGross, 2),
                    number_format($paidNet, 2),
                    "Unapplied Tax Shortfall: {$unappliedTax}",
                    'High',
                    'Carry forward unapplied tax to subsequent cycle'
                ];
                $exceptions[] = ['code' => $r['employee_code'], 'type' => 'Unapplied Tax'];
            }

            // 4. Zero basic on active gross
            if ($activeGross > 0 && (float)($r['active_basic'] ?? 0.0) <= 0) {
                $rows[] = [
                    $sl++,
                    $month,
                    $r['employee_code'] ?? '-',
                    trim($r['employee_name'] ?? 'Unknown'),
                    $r['department_name'] ?? 'General',
                    '0.00',
                    number_format($activeGross, 2),
                    number_format($paidNet, 2),
                    'Zero Basic Salary on Configured Gross',
                    'High',
                    'Configure standard 50% basic ratio in salary structure'
                ];
                $exceptions[] = ['code' => $r['employee_code'], 'type' => 'Zero Basic'];
            }
        }

        // Grand Total row
        $count = count($rows);
        $rows[] = [
            'TOTAL',
            $month,
            'Grand Total Anomalies',
            "Count: {$count}",
            '-',
            '-',
            '-',
            '-',
            "{$count} Exceptions Flagged",
            $count > 0 ? 'Requires Action' : 'Clean',
            'Resolve with Payroll Manager'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'exception_count' => $count
            ],
            'exceptions' => $exceptions
        ];
    }

    /**
     * 6. Salary Arrears Register
     */
    public function salaryArrear(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Arrear ID', 'Employee Code', 'Employee Name', 'Department',
            'Effective Arrear Month', 'Basic Delta', 'Gross Arrear', 'Employee PF Arrear',
            'Net Arrear Payable', 'Disbursement Month', 'Status'
        ];

        $builder = $this->db->table('salary_arrears sa')
            ->select("sa.id, sa.arrear_month, sa.previous_basic, sa.new_basic, sa.basic_delta, sa.gross_arrear, sa.pf_arrear, sa.net_arrear, sa.disbursed_month, sa.status, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name")
            ->join('employees e', 'e.id = sa.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');

        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $builder->where('LOWER(sa.status)', strtolower($filters['status']));
        }

        $records = $builder->orderBy('sa.created_at', 'DESC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $totalGrossArrear = 0.0;
        $totalPfArrear = 0.0;
        $totalNetArrear = 0.0;

        foreach ($records as $r) {
            $delta = (float)($r['basic_delta'] ?? 0.0);
            $gross = (float)($r['gross_arrear'] ?? 0.0);
            $pf = (float)($r['pf_arrear'] ?? 0.0);
            $net = (float)($r['net_arrear'] ?? 0.0);

            $totalGrossArrear += $gross;
            $totalPfArrear += $pf;
            $totalNetArrear += $net;

            $rows[] = [
                $sl++,
                $r['id'] ?? '-',
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                $r['arrear_month'] ?? '-',
                number_format($delta, 2),
                number_format($gross, 2),
                number_format($pf, 2),
                number_format($net, 2),
                $r['disbursed_month'] ?: 'Pending',
                ucfirst(strtolower($r['status'] ?? 'pending'))
            ];
        }

        // Grand Total row
        $count = count($records);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Count: {$count}",
            '-',
            '-',
            '-',
            '-',
            number_format($totalGrossArrear, 2),
            number_format($totalPfArrear, 2),
            number_format($totalNetArrear, 2),
            '-',
            '-'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count'       => $count,
                'total_gross_arrear' => $totalGrossArrear,
                'total_net_arrear'   => $totalNetArrear
            ],
            'exceptions' => []
        ];
    }

    /**
     * 7. Salary Revision & Increment Audit
     */
    public function salaryRevisionIncrement(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Revision ID', 'Employee Code', 'Employee Name', 'Department',
            'Revision Type', 'Effective Date', 'Previous Basic', 'New Basic',
            'Increment Amount', 'Increment (%)', 'Previous Gross', 'New Gross', 'Status', 'Approved By'
        ];

        $builder = $this->db->table('salary_revisions sr')
            ->select("sr.id, sr.revision_type, sr.effective_date, sr.previous_basic, sr.new_basic, sr.previous_gross, sr.new_gross, sr.status, sr.approved_by, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name")
            ->join('employees e', 'e.id = sr.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');

        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $builder->where('LOWER(sr.status)', strtolower($filters['status']));
        }

        $records = $builder->orderBy('sr.effective_date', 'DESC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $totalPrevGross = 0.0;
        $totalNewGross = 0.0;
        $totalInc = 0.0;

        foreach ($records as $r) {
            $prevBasic = (float)($r['previous_basic'] ?? 0.0);
            $newBasic = (float)($r['new_basic'] ?? 0.0);
            $prevGross = (float)($r['previous_gross'] ?? 0.0);
            $newGross = (float)($r['new_gross'] ?? 0.0);

            $incAmt = round($newGross - $prevGross, 2);
            $incPct = ($prevGross > 0) ? round(($incAmt / $prevGross) * 100, 1) : 0.0;

            $totalPrevGross += $prevGross;
            $totalNewGross += $newGross;
            $totalInc += $incAmt;

            $rows[] = [
                $sl++,
                $r['id'] ?? '-',
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                $r['revision_type'] ?? 'Increment',
                $r['effective_date'] ?? '-',
                number_format($prevBasic, 2),
                number_format($newBasic, 2),
                number_format($incAmt, 2),
                $incPct . '%',
                number_format($prevGross, 2),
                number_format($newGross, 2),
                ucfirst(strtolower($r['status'] ?? 'approved')),
                $r['approved_by'] ?: 'Management'
            ];
        }

        // Grand Total row
        $count = count($records);
        $overallPct = ($totalPrevGross > 0) ? round(($totalInc / $totalPrevGross) * 100, 1) : 0.0;
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Count: {$count}",
            '-',
            '-',
            '-',
            '-',
            '-',
            '-',
            number_format($totalInc, 2),
            $overallPct . '%',
            number_format($totalPrevGross, 2),
            number_format($totalNewGross, 2),
            '-',
            '-'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count'    => $count,
                'total_increment' => $totalInc,
                'avg_percentage'  => $overallPct
            ],
            'exceptions' => []
        ];
    }

    /**
     * 8. Cost to Company (CTC) Analysis
     */
    public function ctcReport(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Employee Code', 'Employee Name', 'Department', 'Designation',
            'Monthly Gross', 'Employer PF Match', 'Gratuity Provision', 'Other Benefits',
            'Total Monthly CTC', 'Total Annual CTC', 'Compliance Status'
        ];

        $salJoin = $this->getActiveSalaryJoin('e', 'es');
        $builder = $this->db->table('employees e')
            ->select("e.id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name, des.name as designation_name, e.pf_status, COALESCE(es.gross_salary, e.gross_salary, 0) as gross_salary, COALESCE(es.basic_salary, e.basic_salary, 0) as basic_salary")
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('designations des', 'des.id = e.designation_id', 'left')
            ->join('employee_salaries es', $salJoin, 'left');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $employees = $builder->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

        $rows = [];
        $exceptions = [];
        $sl = 1;
        $totalGross = 0.0;
        $totalPf = 0.0;
        $totalGratuity = 0.0;
        $totalMonthlyCtc = 0.0;
        $totalAnnualCtc = 0.0;

        foreach ($employees as $emp) {
            $gross = (float)($emp['gross_salary'] ?? 0.0);
            $basic = (float)($emp['basic_salary'] ?? ($gross * 0.5));

            if ($gross <= 0) {
                $exceptions[] = [
                    'employee_code' => $emp['employee_code'],
                    'name'          => $emp['employee_name'],
                    'issue'         => 'Missing salary structure'
                ];
                $rows[] = [
                    $sl++,
                    $emp['employee_code'] ?? '-',
                    trim($emp['employee_name'] ?? 'Unknown'),
                    $emp['department_name'] ?? 'General',
                    $emp['designation_name'] ?? 'Staff',
                    '0.00',
                    '0.00',
                    '0.00',
                    '0.00',
                    '0.00',
                    '0.00',
                    'EXCEPTION: Missing Salary'
                ];
                continue;
            }

            // Employer PF match via RuleResolver
            $pfMatch = 0.0;
            $gratuity = 0.0;
            $isPf = in_array(strtolower((string)($emp['pf_status'] ?? '')), ['enrolled', 'active', 'yes'], true);

            if ($isPf) {
                try {
                    $pfRule = \App\Services\Rules\RuleResolver::resolve($companyId, 'PF', date('Y-m-d'), $emp);
                    $erRate = (float)$pfRule->get('employer_contribution_rate');
                    $pfMatch = round($basic * ($erRate / 100), 2);
                } catch (\Throwable $e) {
                    $exceptions[] = [
                        'employee_code' => $emp['employee_code'],
                        'name'          => $emp['employee_name'],
                        'issue'         => 'PF Rule unconfigured: ' . $e->getMessage()
                    ];
                }
            }

            // Gratuity provision via RuleResolver
            try {
                $gratRule = \App\Services\Rules\RuleResolver::resolve($companyId, 'GRATUITY', date('Y-m-d'), $emp);
                $multDays = (float)$gratRule->get('multiplier_days_per_year');
                $divDays = (float)$gratRule->get('month_divisor_days');
                $annualGratuity = round(($basic * $multDays) / $divDays, 2);
                $gratuity = round($annualGratuity / 12, 2);
            } catch (\Throwable $e) {
                $gratuity = 0.0;
            }

            $other = 0.0;

            $monthlyCtc = round($gross + $pfMatch + $gratuity + $other, 2);
            $annualCtc = round($monthlyCtc * 12, 2);

            $totalGross += $gross;
            $totalPf += $pfMatch;
            $totalGratuity += $gratuity;
            $totalMonthlyCtc += $monthlyCtc;
            $totalAnnualCtc += $annualCtc;

            $rows[] = [
                $sl++,
                $emp['employee_code'] ?? '-',
                trim($emp['employee_name'] ?? 'Unknown'),
                $emp['department_name'] ?? 'General',
                $emp['designation_name'] ?? 'Staff',
                number_format($gross, 2),
                number_format($pfMatch, 2),
                number_format($gratuity, 2),
                number_format($other, 2),
                number_format($monthlyCtc, 2),
                number_format($annualCtc, 2),
                'Compliant'
            ];
        }

        // Grand Total row
        $count = count($employees);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Count: {$count}",
            '-',
            '-',
            number_format($totalGross, 2),
            number_format($totalPf, 2),
            number_format($totalGratuity, 2),
            '-',
            number_format($totalMonthlyCtc, 2),
            number_format($totalAnnualCtc, 2),
            count($exceptions) > 0 ? (count($exceptions) . ' Missing Salaries') : 'Audited'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count'      => $count,
                'total_monthly_ctc' => $totalMonthlyCtc,
                'total_annual_ctc'  => $totalAnnualCtc,
                'exceptions'        => count($exceptions)
            ],
            'exceptions' => $exceptions
        ];
    }

    /**
     * 9. Payroll Batch Lock & Governance Audit
     */
    public function payrollLockUnlockAudit(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Payroll Batch ID', 'Payroll Month', 'Status', 'Lock State',
            'Locked By', 'Locked At', 'Lock Reason', 'Total Employees', 'Net Disbursed', 'Governance Verdict'
        ];

        $builder = $this->db->table('payrolls p')
            ->select("p.id, p.payroll_month, p.status, p.is_locked, p.locked_by, p.locked_at, p.lock_reason, p.total_employees, p.net_disbursed, p.created_at, u.name as locked_by_name")
            ->join('users u', 'u.id = p.locked_by', 'left')
            ->where('p.company_id', $companyId);

        if (!empty($filters['payroll_month'])) {
            $builder->where('p.payroll_month', $filters['payroll_month']);
        } elseif (!empty($filters['from']) && !empty($filters['to'])) {
            $builder->where('p.payroll_month >=', date('Y-m', strtotime($filters['from'])))
                    ->where('p.payroll_month <=', date('Y-m', strtotime($filters['to'])));
        }

        $records = $builder->orderBy('p.payroll_month', 'DESC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $totalEmps = 0;
        $totalDisbursed = 0.0;
        $lockedCount = 0;

        foreach ($records as $r) {
            $isLocked = !empty($r['is_locked']);
            $emps = (int)($r['total_employees'] ?? 0);
            $disb = (float)($r['net_disbursed'] ?? 0.0);

            $totalEmps += $emps;
            $totalDisbursed += $disb;
            if ($isLocked) {
                $lockedCount++;
            }

            $verdict = $isLocked ? 'Immutable & Sealed' : 'Draft / Editable';

            $rows[] = [
                $sl++,
                $r['id'] ?? '-',
                $r['payroll_month'] ?? '-',
                ucfirst(strtolower($r['status'] ?? 'draft')),
                $isLocked ? 'Locked' : 'Unlocked',
                $r['locked_by_name'] ?? ($r['locked_by'] ?: '-'),
                !empty($r['locked_at']) ? date('Y-m-d H:i', strtotime($r['locked_at'])) : '-',
                $r['lock_reason'] ?: 'Standard Monthly Cutoff',
                $emps,
                number_format($disb, 2),
                $verdict
            ];
        }

        // Grand Total row
        $count = count($records);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Batches: {$count}",
            '-',
            "Locked: {$lockedCount}/{$count}",
            '-',
            '-',
            '-',
            $totalEmps,
            number_format($totalDisbursed, 2),
            'Governance Audited'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'batch_count'     => $count,
                'locked_count'    => $lockedCount,
                'total_employees' => $totalEmps,
                'total_disbursed' => $totalDisbursed
            ],
            'exceptions' => []
        ];
    }
}
