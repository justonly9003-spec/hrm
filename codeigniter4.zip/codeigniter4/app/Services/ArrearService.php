<?php

namespace App\Services;

use App\Models\EmployeeModel;
use App\Models\SalaryRevisionModel;
use App\Models\SalaryArrearModel;
use App\Models\ProvidentFundLedgerModel;
use App\Services\Pf\PfCalculator;
use App\Services\Pf\PfEligibilityService;
use Config\Database;

class ArrearService
{
    protected EmployeeModel $employeeModel;
    protected SalaryRevisionModel $revisionModel;
    protected SalaryArrearModel $arrearModel;
    protected ProvidentFundLedgerModel $ledgerModel;
    protected PfCalculator $pfCalculator;
    protected PfEligibilityService $eligibilityService;

    public function __construct(
        ?EmployeeModel $employeeModel = null,
        ?SalaryRevisionModel $revisionModel = null,
        ?SalaryArrearModel $arrearModel = null,
        ?ProvidentFundLedgerModel $ledgerModel = null,
        ?PfCalculator $pfCalculator = null,
        ?PfEligibilityService $eligibilityService = null
    ) {
        $this->employeeModel      = $employeeModel ?? new EmployeeModel();
        $this->revisionModel      = $revisionModel ?? new SalaryRevisionModel();
        $this->arrearModel        = $arrearModel ?? new SalaryArrearModel();
        $this->ledgerModel        = $ledgerModel ?? new ProvidentFundLedgerModel();
        $this->pfCalculator       = $pfCalculator ?? new PfCalculator();
        $this->eligibilityService = $eligibilityService ?? new PfEligibilityService();
    }

    /**
     * Create a salary revision and calculate retroactive arrears atomically in ONE transaction
     * Requirement 6 & 7: Transactional consistency and idempotency
     */
    public function createSalaryRevision(array $data, ?string $actorUserId = null): array
    {
        $db = Database::connect();
        $db->transBegin();

        try {
            $employeeId = $data['employee_id'] ?? '';
            $effectiveDate = $data['effective_date'] ?? date('Y-m-d');
            $revisionType = $data['revision_type'] ?? 'Increment';
            $remarks = $data['remarks'] ?? '';
            $approvedBy = $actorUserId ?: ($data['approved_by'] ?? 'Management');

            $employee = $this->employeeModel->find($employeeId);
            if (!$employee) {
                $db->transRollback();
                return ['success' => false, 'message' => 'Employee not found'];
            }

            $activeSalary = null;
            try {
                $salService = class_exists('\Config\Services') && method_exists('\Config\Services', 'salary')
                    ? \Config\Services::salary()
                    : new \App\Services\EmployeeSalaryService();
                $activeSalary = $salService->getActiveSalary($employeeId, $effectiveDate);
            } catch (\Throwable $e) {
                $activeSalary = null;
            }

            $prevBasic = (float)($activeSalary['basic_salary'] ?? $employee['basic_salary'] ?? 0);
            $prevGross = (float)($activeSalary['gross_salary'] ?? $employee['gross_salary'] ?? 0);

            $newBasic = isset($data['new_basic']) ? (float)$data['new_basic'] : $prevBasic;
            $newGross = isset($data['new_gross']) ? (float)$data['new_gross'] : $prevGross;

            // If new gross is provided but not new basic, or vice versa, calculate proportionately
            if ($newBasic > 0 && $newGross <= 0 && $prevBasic > 0 && $prevGross > 0) {
                $ratio = $prevGross / $prevBasic;
                $newGross = round($newBasic * $ratio, 2);
            } elseif ($newGross > 0 && $newBasic <= 0 && $prevGross > 0 && $prevBasic > 0) {
                $ratio = $prevBasic / $prevGross;
                $newBasic = round($newGross * $ratio, 2);
            }

            // Requirement 7: Idempotency check. If an identical approved revision already exists, return it
            $existingRevision = $this->revisionModel
                ->where('employee_id', $employeeId)
                ->where('effective_date', $effectiveDate)
                ->where('new_basic', $newBasic)
                ->where('new_gross', $newGross)
                ->where('status', 'Approved')
                ->first();

            if ($existingRevision) {
                $existingArrears = $this->arrearModel->where('revision_id', $existingRevision['id'])->findAll();
                $totalGross = 0.0;
                $totalNet = 0.0;
                foreach ($existingArrears as $ea) {
                    $totalGross += (float)$ea['gross_arrear'];
                    $totalNet += (float)$ea['net_arrear'];
                }
                $db->transCommit();
                return [
                    'success'            => true,
                    'revision_id'        => $existingRevision['id'],
                    'total_gross_arrear' => round($totalGross, 2),
                    'total_net_arrear'   => round($totalNet, 2),
                    'arrears_count'      => count($existingArrears),
                    'arrears'            => $existingArrears,
                    'is_duplicate'       => true
                ];
            }

            $revisionId = 'REV-' . bin2hex(random_bytes(6));
            $revisionData = [
                'id'                      => $revisionId,
                'company_id'              => $employee['company_id'] ?? null,
                'employee_id'             => $employeeId,
                'revision_type'           => $revisionType,
                'effective_date'          => $effectiveDate,
                'previous_basic'          => $prevBasic,
                'new_basic'               => $newBasic,
                'previous_gross'          => $prevGross,
                'new_gross'               => $newGross,
                'total_arrear_calculated' => 0.00,
                'remarks'                 => $remarks,
                'status'                  => 'Approved',
                'approved_by'             => $approvedBy,
                'created_at'              => date('Y-m-d H:i:s'),
                'updated_at'              => date('Y-m-d H:i:s')
            ];

            $this->revisionModel->insert($revisionData);

            // Update employee's current salary ONLY if effective date is today or earlier
            // Route through EmployeeSalaryService::assignSalary to maintain audit trail and structure integrity
            $today = date('Y-m-d');
            if ($effectiveDate <= $today) {
                $salaryService = new \App\Services\EmployeeSalaryService();
                $salaryService->assignSalary($employeeId, [
                    'basic_salary'   => $newBasic,
                    'gross_salary'   => $newGross,
                    'effective_from' => $effectiveDate,
                    'notes'          => 'Salary revision: ' . $revisionType . ' (Ref: ' . $revisionId . ')'
                ], $employee['company_id'] ?? null);
            }

            // Calculate retroactive arrears and post draft ledger entries in the same transaction
            $arrears = $this->calculateRetroactiveArrears($revisionId);

            $totalGrossArrear = 0.0;
            $totalNetArrear = 0.0;
            foreach ($arrears as $arr) {
                $totalGrossArrear += (float)$arr['gross_arrear'];
                $totalNetArrear += (float)$arr['net_arrear'];
            }

            $this->revisionModel->update($revisionId, [
                'total_arrear_calculated' => round($totalGrossArrear, 2)
            ]);

            if ($db->transStatus() === false) {
                $db->transRollback();
                return ['success' => false, 'message' => 'Transaction failed during salary revision creation.'];
            }

            $db->transCommit();

            return [
                'success'            => true,
                'revision_id'        => $revisionId,
                'total_gross_arrear' => round($totalGrossArrear, 2),
                'total_net_arrear'   => round($totalNetArrear, 2),
                'arrears_count'      => count($arrears),
                'arrears'            => $arrears
            ];
        } catch (\Throwable $e) {
            $db->transRollback();
            throw $e;
        }
    }

    /**
     * Atomically approve a salary revision, generate arrears and post ledger rows in ONE transaction (Idempotent)
     * Requirement 6 & 7: Salary revision approval, arrear rows and ledger rows in ONE transaction; idempotent.
     */
    public function approveSalaryRevision(string $revisionId, ?string $actorUserId = null): array
    {
        $db = Database::connect();
        $db->transBegin();

        try {
            $revision = $this->revisionModel->where('id', $revisionId)->first();
            if (!$revision) {
                $db->transRollback();
                return ['success' => false, 'message' => 'Salary revision not found'];
            }

            $employeeId = $revision['employee_id'];
            $employee = $this->employeeModel->find($employeeId);
            if (!$employee) {
                $db->transRollback();
                return ['success' => false, 'message' => 'Employee not found'];
            }

            $effectiveDate = $revision['effective_date'];
            $newBasic = (float)$revision['new_basic'];
            $newGross = (float)$revision['new_gross'];
            $approvedBy = $actorUserId ?: ($revision['approved_by'] ?? 'Management');

            // Idempotency check: if already approved and arrears exist, do not duplicate
            $existingArrears = $this->arrearModel->where('revision_id', $revisionId)->findAll();
            if ($revision['status'] === 'Approved' && !empty($existingArrears)) {
                $totalGross = 0.0;
                $totalNet = 0.0;
                foreach ($existingArrears as $ea) {
                    $totalGross += (float)$ea['gross_arrear'];
                    $totalNet += (float)$ea['net_arrear'];
                }
                $db->transCommit();
                return [
                    'success'            => true,
                    'revision_id'        => $revisionId,
                    'total_gross_arrear' => round($totalGross, 2),
                    'total_net_arrear'   => round($totalNet, 2),
                    'arrears_count'      => count($existingArrears),
                    'arrears'            => $existingArrears,
                    'already_approved'   => true
                ];
            }

            // Update status to Approved
            $this->revisionModel->update($revisionId, [
                'status'      => 'Approved',
                'approved_by' => $approvedBy,
                'updated_at'  => date('Y-m-d H:i:s')
            ]);

            // Assign salary if effective today or earlier
            if ($effectiveDate <= date('Y-m-d')) {
                $salaryService = new \App\Services\EmployeeSalaryService();
                $salaryService->assignSalary($employeeId, [
                    'basic_salary'   => $newBasic,
                    'gross_salary'   => $newGross,
                    'effective_from' => $effectiveDate,
                    'notes'          => 'Salary revision: ' . ($revision['revision_type'] ?? 'Increment') . ' (Ref: ' . $revisionId . ')'
                ], $employee['company_id'] ?? null);
            }

            // Calculate arrears and create ledger entries
            $arrears = $this->calculateRetroactiveArrears($revisionId);

            $totalGrossArrear = 0.0;
            $totalNetArrear = 0.0;
            foreach ($arrears as $arr) {
                $totalGrossArrear += (float)$arr['gross_arrear'];
                $totalNetArrear += (float)$arr['net_arrear'];
            }

            $this->revisionModel->update($revisionId, [
                'total_arrear_calculated' => round($totalGrossArrear, 2)
            ]);

            if ($db->transStatus() === false) {
                $db->transRollback();
                return ['success' => false, 'message' => 'Transaction failed during salary revision approval.'];
            }

            $db->transCommit();

            return [
                'success'            => true,
                'revision_id'        => $revisionId,
                'total_gross_arrear' => round($totalGrossArrear, 2),
                'total_net_arrear'   => round($totalNetArrear, 2),
                'arrears_count'      => count($arrears),
                'arrears'            => $arrears
            ];
        } catch (\Throwable $e) {
            $db->transRollback();
            throw $e;
        }
    }

    /**
     * Calculate monthly arrears between effective_date and current month
     * Single Source of Truth: Calls PfCalculator with real earnings map & PF basis configuration.
     * Computes PF as PF(new salary) - PF(old salary) using PfEligibilityService.
     * Includes employer PF arrear (pf_arrear_employer).
     * Allows negative PF delta for salary decrease.
     * Posts draft 'Arrear' entries to provident_fund_ledgers.
     */
    public function calculateRetroactiveArrears(string $revisionId): array
    {
        $revision = $this->revisionModel->find($revisionId);
        if (!$revision) {
            return [];
        }

        $employeeId = $revision['employee_id'];
        $employee = $this->employeeModel->find($employeeId);
        if (!$employee) {
            return [];
        }

        $companyId = (string)($employee['company_id'] ?? '');
        if ($companyId === '') {
            throw new \RuntimeException("Employee {$employeeId} missing company_id for retroactive arrears calculation.");
        }

        $effectiveDate = $revision['effective_date'];
        $effectiveTime = strtotime($effectiveDate);
        $currentTime = time();

        $effectiveMonthStart = date('Y-m-01', $effectiveTime);
        $currentMonthStart   = date('Y-m-01', $currentTime);

        // If effective date is in the future or current month, no historical arrears
        if (strtotime($effectiveMonthStart) >= strtotime($currentMonthStart)) {
            return [];
        }

        $db = Database::connect();
        $calculatedArrears = [];

        // Delete any non-disbursed arrears for this revision before recalculating
        $this->arrearModel->where('revision_id', $revisionId)
                          ->where('status !=', 'Disbursed')
                          ->delete();

        // Also clean up non-posted draft ledger entries for this revision before recalculating
        if ($db->tableExists('provident_fund_ledgers')) {
            $db->table('provident_fund_ledgers')
                ->where('reference_no', 'REV:' . $revisionId)
                ->where('status', 'draft')
                ->where('payroll_id', null)
                ->delete();
        }

        $iterTime = strtotime($effectiveMonthStart);
        $endMonthTime = strtotime($currentMonthStart); // up to, but not including current active payroll month

        while ($iterTime < $endMonthTime) {
            $monthStr = date('Y-m', $iterTime);
            $daysInMonth = (int)date('t', $iterTime);

            // Check if effective date started mid-month in the first month
            $effectiveDay = 1;
            if ($monthStr === date('Y-m', $effectiveTime)) {
                $effectiveDay = (int)date('d', $effectiveTime);
            }
            $applicableDays = $daysInMonth - $effectiveDay + 1;
            $monthFraction = ($applicableDays >= $daysInMonth) ? 1.0 : ($applicableDays / $daysInMonth);

            $prevBasic = (float)$revision['previous_basic'];
            $newBasic  = (float)$revision['new_basic'];
            $prevGross = (float)$revision['previous_gross'];
            $newGross  = (float)$revision['new_gross'];

            // Check if historical payroll item exists for that month
            $payrollItem = null;
            if ($db->tableExists('payrolls') && $db->tableExists('payroll_items')) {
                $payrollItem = $db->table('payroll_items')
                    ->select('payroll_items.*, payrolls.payroll_month, payrolls.month, payrolls.year')
                    ->join('payrolls', 'payrolls.id = payroll_items.payroll_id')
                    ->where('payroll_items.employee_id', $employeeId)
                    ->groupStart()
                        ->where('payrolls.payroll_month', $monthStr)
                        ->orGroupStart()
                            ->where('payrolls.year', (int)date('Y', $iterTime))
                            ->where('payrolls.month', (int)date('n', $iterTime))
                        ->groupEnd()
                    ->groupEnd()
                    ->get()
                    ->getRowArray();
            }

            if ($payrollItem) {
                // Do NOT clamp with max(0, ...): allow negative deltas for salary decrease
                $rawBasicDelta = $newBasic - (float)$payrollItem['basic_salary'];
                $rawGrossDelta = $newGross - (float)$payrollItem['gross_salary'];

                // If paid salary was prorated due to LWP, apply the ratio
                if ((float)$payrollItem['gross_salary'] > 0 && $prevGross > 0) {
                    $ratio = min(1.0, abs((float)$payrollItem['gross_salary'] / $prevGross));
                    $grossDelta = round($rawGrossDelta * $ratio, 2);
                    $basicDelta = round($rawBasicDelta * $ratio, 2);
                } else {
                    $grossDelta = round($rawGrossDelta, 2);
                    $basicDelta = round($rawBasicDelta, 2);
                }

                $oldBasicMonth = (float)$payrollItem['basic_salary'];
                $oldGrossMonth = (float)$payrollItem['gross_salary'];
            } else {
                $basicDelta = round(($newBasic - $prevBasic) * $monthFraction, 2);
                $grossDelta = round(($newGross - $prevGross) * $monthFraction, 2);
                $oldBasicMonth = round($prevBasic * $monthFraction, 2);
                $oldGrossMonth = round($prevGross * $monthFraction, 2);
            }

            $newBasicMonth = round($oldBasicMonth + $basicDelta, 2);
            $newGrossMonth = round($oldGrossMonth + $grossDelta, 2);

            $monthDate = date('Y-m-t', $iterTime);

            // Single Source of Truth: Call PfCalculator with real earnings map & PF basis configuration
            $oldEarnings = ['Basic' => $oldBasicMonth, 'Gross' => $oldGrossMonth];
            $newEarnings = ['Basic' => $newBasicMonth, 'Gross' => $newGrossMonth];

            if ($payrollItem) {
                foreach (['house_rent' => 'HRA', 'medical' => 'Medical', 'conveyance' => 'Transport', 'allowances' => 'Other_Allowances'] as $fCol => $fCode) {
                    if (isset($payrollItem[$fCol])) {
                        $oldEarnings[$fCode] = (float)$payrollItem[$fCol];
                        $newEarnings[$fCode] = (float)$payrollItem[$fCol];
                    }
                }
            }

            $newPf = $this->pfCalculator->calculate([
                'company_id'     => $companyId,
                'employee'       => $employee,
                'effective_date' => $monthDate,
                'earnings'       => $newEarnings,
            ]);

            $oldPf = $this->pfCalculator->calculate([
                'company_id'     => $companyId,
                'employee'       => $employee,
                'effective_date' => $monthDate,
                'earnings'       => $oldEarnings,
            ]);

            // Requirement 2: If employee was not eligible in that month, PF arrear is 0
            if (!$newPf['is_eligible'] && !$oldPf['is_eligible']) {
                $pfArrear = 0.00;
                $pfArrearEmployer = 0.00;
            } else {
                // Requirement 4: Allow negative PF delta for salary decrease, do not clamp to zero
                $pfArrear = round((float)$newPf['employee_deduction'] - (float)$oldPf['employee_deduction'], 2);
                $pfArrearEmployer = round((float)$newPf['employer_contribution'] - (float)$oldPf['employer_contribution'], 2);
            }

            $taxArrear = 0.00;
            $netArrear = round($grossDelta - $pfArrear - $taxArrear, 2);

            if ($grossDelta != 0.0 || $basicDelta != 0.0 || $pfArrear != 0.0 || $pfArrearEmployer != 0.0) {
                $arrearId = 'ARR-' . bin2hex(random_bytes(6));
                $arrearRecord = [
                    'id'                 => $arrearId,
                    'revision_id'        => $revisionId,
                    'employee_id'        => $employeeId,
                    'company_id'         => $employee['company_id'] ?? null,
                    'arrear_month'       => $monthStr,
                    'previous_basic'     => $prevBasic,
                    'new_basic'          => $newBasic,
                    'basic_delta'        => $basicDelta,
                    'previous_gross'     => $prevGross,
                    'new_gross'          => $newGross,
                    'gross_arrear'       => $grossDelta,
                    'pf_arrear'          => $pfArrear,
                    'pf_arrear_employer' => $pfArrearEmployer,
                    'tax_arrear'         => $taxArrear,
                    'net_arrear'         => $netArrear,
                    'payroll_id'         => null,
                    'disbursed_month'    => null,
                    'status'             => 'Approved',
                    'created_at'         => date('Y-m-d H:i:s'),
                    'updated_at'         => date('Y-m-d H:i:s')
                ];

                $this->arrearModel->insert($arrearRecord);
                $calculatedArrears[] = $arrearRecord;

                // Requirement 5: Post arrear PF into provident_fund_ledgers with transaction_type 'Arrear'
                if ($pfArrear != 0.00 || $pfArrearEmployer != 0.00) {
                    $this->ledgerModel->recordArrearContribution([
                        'employee_id'        => $employeeId,
                        'company_id'         => $companyId,
                        'revision_id'        => $revisionId,
                        'arrear_month'       => $monthStr,
                        'basic_delta'        => $basicDelta,
                        'pf_arrear'          => $pfArrear,
                        'pf_arrear_employer' => $pfArrearEmployer,
                        'pf_rule_id'         => $newPf['rule_id'] ?? null,
                    ], $revision['approved_by'] ?? null);
                }
            }

            // Next month
            $iterTime = strtotime('+1 month', $iterTime);
        }

        return $calculatedArrears;
    }


    /**
     * Bulk fetch pending approved arrears for a list of employee IDs (VULN-PAY-20 & PAY-13 fix)
     */
    public function getPendingArrearsForEmployees(array $employeeIds): array
    {
        if (empty($employeeIds)) {
            return [];
        }

        $records = $this->arrearModel
            ->whereIn('employee_id', $employeeIds)
            ->where('status', 'Approved')
            ->where('payroll_id', null)
            ->findAll();

        $grouped = [];
        foreach ($records as $r) {
            $grouped[$r['employee_id']][] = $r;
        }

        return $grouped;
    }

    /**
     * Link arrears to draft payroll without permanently marking them disbursed.
     * VULN-PAY-13 Fix: Arrears remain staged until authoritative finalization.
     * Also links corresponding draft 'Arrear' ledger entries.
     */
    public function linkArrearsToDraft(array $arrearIds, string $payrollId, string $payrollMonth): void
    {
        if (empty($arrearIds)) {
            return;
        }

        $this->arrearModel
            ->whereIn('id', $arrearIds)
            ->set([
                'status'          => 'Pending_Disbursement',
                'payroll_id'      => $payrollId,
                'disbursed_month' => $payrollMonth,
                'updated_at'      => date('Y-m-d H:i:s')
            ])
            ->update();

        // Also link corresponding draft 'Arrear' ledger entries
        $arrears = $this->arrearModel->whereIn('id', $arrearIds)->findAll();
        $db = Database::connect();
        if ($db->tableExists('provident_fund_ledgers') && !empty($arrears)) {
            foreach ($arrears as $arr) {
                $revId = $arr['revision_id'] ?? null;
                $mStr = $arr['arrear_month'] ?? '';
                if ($revId && $mStr) {
                    $m = (int)date('n', strtotime($mStr . '-01'));
                    $y = (int)date('Y', strtotime($mStr . '-01'));
                    $db->table('provident_fund_ledgers')
                        ->where('employee_id', $arr['employee_id'])
                        ->groupStart()
                            ->where('transaction_type', 'Arrear')
                            ->orWhere('transaction_type', 'ARREAR')
                        ->groupEnd()
                        ->where('reference_no', 'REV:' . $revId)
                        ->where('payroll_month', $m)
                        ->where('payroll_year', $y)
                        ->where('status', 'draft')
                        ->update([
                            'payroll_id' => $payrollId,
                            'updated_at' => date('Y-m-d H:i:s')
                        ]);
                }
            }
        }
    }


    /**
     * Atomically finalize all linked arrears for a payroll batch
     * Commits draft 'Arrear' ledger entries to posted with updated running balance.
     */
    public function finalizeBatchArrears(string $payrollId): void
    {
        $this->arrearModel
            ->where('payroll_id', $payrollId)
            ->where('status', 'Pending_Disbursement')
            ->set([
                'status'     => 'Disbursed',
                'updated_at' => date('Y-m-d H:i:s')
            ])
            ->update();

        $db = Database::connect();
        if ($db->tableExists('provident_fund_ledgers')) {
            $ledgerDrafts = $db->table('provident_fund_ledgers')
                ->where('payroll_id', $payrollId)
                ->groupStart()
                    ->where('transaction_type', 'Arrear')
                    ->orWhere('transaction_type', 'ARREAR')
                ->groupEnd()
                ->where('status', 'draft')
                ->get()
                ->getResultArray();

            foreach ($ledgerDrafts as $d) {
                $priorBalance = $this->ledgerModel->getLatestBalance($d['employee_id']);
                $newBal = round($priorBalance + (float)$d['total_contribution'], 2);
                $db->table('provident_fund_ledgers')
                    ->where('id', $d['id'])
                    ->update([
                        'status'          => 'posted',
                        'running_balance' => $newBal,
                        'notes'           => $d['notes'] . ' [Finalized with payroll batch ' . $payrollId . ']',
                        'updated_at'      => date('Y-m-d H:i:s')
                    ]);
            }
        }
    }

    /**
     * Revert disbursed or draft arrears back to approved when payroll batch is regenerated, cancelled or unlocked
     * Decouples or reverts corresponding 'Arrear' ledger entries.
     */
    public function revertPayrollArrears(string $payrollId): void
    {
        $this->arrearModel
            ->where('payroll_id', $payrollId)
            ->set([
                'status'          => 'Approved',
                'payroll_id'      => null,
                'disbursed_month' => null,
                'updated_at'      => date('Y-m-d H:i:s')
            ])
            ->update();

        $db = Database::connect();
        if ($db->tableExists('provident_fund_ledgers')) {
            // Decouple draft arrear ledger entries
            $db->table('provident_fund_ledgers')
                ->where('payroll_id', $payrollId)
                ->groupStart()
                    ->where('transaction_type', 'Arrear')
                    ->orWhere('transaction_type', 'ARREAR')
                ->groupEnd()
                ->where('status', 'draft')
                ->update([
                    'payroll_id' => null,
                    'updated_at' => date('Y-m-d H:i:s')
                ]);

            // Revert posted arrear ledger entries back to draft
            $postedArrears = $db->table('provident_fund_ledgers')
                ->where('payroll_id', $payrollId)
                ->groupStart()
                    ->where('transaction_type', 'Arrear')
                    ->orWhere('transaction_type', 'ARREAR')
                ->groupEnd()
                ->where('status', 'posted')
                ->get()
                ->getResultArray();

            foreach ($postedArrears as $pa) {
                $db->table('provident_fund_ledgers')
                    ->where('id', $pa['id'])
                    ->update([
                        'status'     => 'draft',
                        'payroll_id' => null,
                        'notes'      => $pa['notes'] . ' [Reverted from batch ' . $payrollId . ']',
                        'updated_at' => date('Y-m-d H:i:s')
                    ]);
            }
        }
    }
}

