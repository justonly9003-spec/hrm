<?php

namespace App\Services;

use App\Models\CompanyModel;
use App\Models\DutyAssignmentModel;
use App\Models\HolidayModel;
use App\Models\RuleDefinitionModel;
use App\Services\Rules\RuleParamValidator;
use App\Services\Rules\RuleResolver;
use App\Services\Rules\RuleSeeder;
use App\Services\Rules\RuleWriteService;
use Config\Database;

class CompanyWeekendService
{
    /**
     * Single source of truth for the system default weekly off day.
     * This constant is the ONLY place in the application where a weekend default lives.
     */
    public const DEFAULT_FALLBACK_WEEKLY_OFF = ['Friday'];

    protected static $cachedCompanyWeeklyOff = [];
    protected static $cachedDutyAssignments = [];
    protected static $isResolving = false;
    protected static $allWeekDays = [
        'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'
    ];

    /**
     * Clear in-memory static caches (called after updating company, rule, shift or duty configuration)
     */
    public static function clearCache(?string $companyId = null): void
    {
        if ($companyId) {
            foreach (array_keys(self::$cachedCompanyWeeklyOff) as $key) {
                if (str_starts_with($key, $companyId)) {
                    unset(self::$cachedCompanyWeeklyOff[$key]);
                }
            }
        } else {
            self::$cachedCompanyWeeklyOff = [];
        }
        self::$cachedDutyAssignments = [];
    }

    /**
     * Save and synchronize company weekly off days to rule engine and companies profile.
     * Centralized single entry point for updating weekly off configuration.
     *
     * @param string $companyId
     * @param array $days
     * @param string $actorId
     * @param string $source
     * @param bool $isOwner
     * @return array{ok: bool, errors: array<string>, days: array<string>}
     */
    public static function saveWeeklyOff(string $companyId, array $days, string $actorId, string $source, bool $isOwner = false): array
    {
        $companyId = trim($companyId);
        if ($companyId === '') {
            return [
                'ok'     => false,
                'errors' => ['Company ID is required'],
                'days'   => [],
            ];
        }

        // 1. Normalize each day with ucfirst(strtolower(trim())). Keep only Sunday..Saturday, de-duplicate.
        $normalizedDays = [];
        foreach ($days as $day) {
            if (!is_string($day) && !is_numeric($day)) {
                continue;
            }
            $cleanDay = ucfirst(strtolower(trim((string)$day)));
            if (in_array($cleanDay, self::$allWeekDays, true)) {
                if (!in_array($cleanDay, $normalizedDays, true)) {
                    $normalizedDays[] = $cleanDay;
                }
            }
        }

        // 2. Reject an empty list: return ['ok'=>false,'errors'=>['Select at least one weekly off day'],'days'=>[]]. Never store [].
        if (empty($normalizedDays)) {
            return [
                'ok'     => false,
                'errors' => ['Select at least one weekly off day'],
                'days'   => [],
            ];
        }

        // 3. Load the Active Company-scope ATTENDANCE rule via RuleDefinitionModel. If none exists, call RuleSeeder::seedCompany($companyId, [], date('Y-m-d')) and re-load. If still none, return an error.
        $ruleModel = new RuleDefinitionModel();
        $activeRule = $ruleModel->where('company_id', $companyId)
            ->where('domain', 'ATTENDANCE')
            ->where('scope_level', 'Company')
            ->where('status', 'Active')
            ->orderBy('version_number', 'DESC')
            ->first();

        if (!$activeRule) {
            try {
                RuleSeeder::seedCompany($companyId, [], date('Y-m-d'));
            } catch (\Throwable $se) {
                // Seed fallback handling
            }

            $activeRule = $ruleModel->where('company_id', $companyId)
                ->where('domain', 'ATTENDANCE')
                ->where('scope_level', 'Company')
                ->where('status', 'Active')
                ->orderBy('version_number', 'DESC')
                ->first();
        }

        if (!$activeRule) {
            return [
                'ok'     => false,
                'errors' => ['Active Company-scope ATTENDANCE rule not found for company.'],
                'days'   => [],
            ];
        }

        // 4. Copy the rule params, change ONLY weekly_off_days, validate with RuleParamValidator::validate('ATTENDANCE','Company',$params,false), then publish through RuleWriteService::publish($companyId,'ATTENDANCE','Company',null,$params,date('Y-m-d'),"Weekly off updated via {$source}",$actorId,null,$isOwner). Do not update rule_definitions directly.
        $params = $ruleModel->paramsOf($activeRule);
        $params['weekly_off_days'] = $normalizedDays;

        $validation = RuleParamValidator::validate('ATTENDANCE', 'Company', $params, false, $companyId);
        if (empty($validation['valid'])) {
            $errMsgs = [];
            foreach (($validation['errors'] ?? []) as $err) {
                $errMsgs[] = is_array($err) ? implode(', ', $err) : (string)$err;
            }
            return [
                'ok'     => false,
                'errors' => !empty($errMsgs) ? $errMsgs : ['Validation failed for ATTENDANCE rule parameters.'],
                'days'   => [],
            ];
        }

        try {
            $writeService = new RuleWriteService();
            // Publish through RuleWriteService::publish($companyId, 'ATTENDANCE', 'Company', null, $params, date('Y-m-d'), "Weekly off updated via {$source}", $actorId, null, $isOwner)
            $writeService->publish(
                $companyId,
                'ATTENDANCE',
                'Company',
                null,
                $params,
                date('Y-m-d'),
                "Weekly off updated via {$source}",
                $actorId,
                null,
                $isOwner
            );
        } catch (\Throwable $e) {
            return [
                'ok'     => false,
                'errors' => [$e->getMessage()],
                'days'   => [],
            ];
        }

        // 5. After a successful publish, mirror to companies: weekly_off = json_encode($days), working_days = json_encode(complement of $days in Sunday..Saturday).
        self::syncCompanyMirror($companyId, $normalizedDays);

        // 6. Call self::clearCache($companyId) and RuleResolver::flushAll().
        self::clearCache($companyId);
        if (method_exists(RuleResolver::class, 'flushAll')) {
            RuleResolver::flushAll();
        } else {
            RuleResolver::flush(true);
        }

        // 7. Return ['ok'=>true,'errors'=>[],'days'=>$days].
        return [
            'ok'     => true,
            'errors' => [],
            'days'   => $normalizedDays,
        ];
    }

    /**
     * Synchronize the companies.weekly_off and companies.working_days mirror columns
     * from a canonical list of weekly off days. Never writes an empty list.
     */
    public static function syncCompanyMirror(string $companyId, array $days): bool
    {
        $companyId = trim($companyId);
        if ($companyId === '') {
            return false;
        }

        $normalizedDays = self::parseWeeklyOffField($days);
        if (empty($normalizedDays)) {
            return false;
        }

        $workingDays = array_values(array_diff(self::$allWeekDays, $normalizedDays));

        try {
            $db = Database::connect();
            if ($db->tableExists('companies')) {
                $db->table('companies')
                    ->where('id', $companyId)
                    ->update([
                        'weekly_off'   => json_encode($normalizedDays),
                        'working_days' => json_encode($workingDays),
                        'updated_at'   => date('Y-m-d H:i:s'),
                    ]);
                self::clearCache($companyId);
                return true;
            }
        } catch (\Throwable $ce) {
            try {
                $companyModel = new CompanyModel();
                $companyModel->update($companyId, [
                    'weekly_off'   => json_encode($normalizedDays),
                    'working_days' => json_encode($workingDays),
                    'updated_at'   => date('Y-m-d H:i:s'),
                ]);
                self::clearCache($companyId);
                return true;
            } catch (\Throwable $ce2) {
                return false;
            }
        }

        return false;
    }

    /**
     * Get configured weekly off days for a company or employee.
     * Central Single Source of Truth:
     * Reads directly from ATTENDANCE domain in rule store via RuleResolver.
     *
     * @param string|null $companyId
     * @param string|null $employeeId
     * @param bool $allowSilentFallback Whether to return system default constant if completely unconfigured
     * @param string|null $date
     * @return array List of weekday names, e.g. ['Friday'], ['Friday', 'Saturday'], or [] if not configured
     */
    public static function getCompanyWeeklyOff(?string $companyId = null, $employeeId = null, $allowSilentFallback = false, ?string $date = null): array
    {
        $empContext = null;
        if (is_array($employeeId)) {
            $empContext = $employeeId;
            $employeeId = $empContext['id'] ?? ($empContext['employee_id'] ?? null);
        } elseif (is_string($employeeId) && preg_match('/^\d{4}-\d{2}-\d{2}/', $employeeId)) {
            // Accommodate caller passing ($companyId, $date, ...)
            if (is_array($allowSilentFallback)) {
                $empContext = $allowSilentFallback;
                $date = $employeeId;
                $employeeId = $empContext['id'] ?? ($empContext['employee_id'] ?? null);
                $allowSilentFallback = false;
            } else {
                if ($date === null) {
                    $date = $employeeId;
                    $employeeId = null;
                }
            }
        }

        if (is_string($allowSilentFallback) && preg_match('/^\d{4}-\d{2}-\d{2}/', $allowSilentFallback)) {
            $date = $allowSilentFallback;
            $allowSilentFallback = false;
        }

        $allowSilentFallback = (bool)$allowSilentFallback;
        $date = !empty($date) ? substr(trim($date), 0, 10) : date('Y-m-d');
        $employeeId = is_string($employeeId) ? trim($employeeId) : null;
        $cacheKey = ($companyId ?: 'default_context') . '_' . ($employeeId ?: 'all') . '_' . ($allowSilentFallback ? '1' : '0') . '_' . $date;
        if (isset(self::$cachedCompanyWeeklyOff[$cacheKey])) {
            return self::$cachedCompanyWeeklyOff[$cacheKey];
        }

        // App Admin without selected company: return [] strictly (no random fallback)
        if (empty($companyId) && empty($employeeId)) {
            self::$cachedCompanyWeeklyOff[$cacheKey] = [];
            return [];
        }

        if (self::$isResolving) {
            return $allowSilentFallback ? self::DEFAULT_FALLBACK_WEEKLY_OFF : [];
        }

        self::$isResolving = true;

        try {
            $empContext = null;
            if ($employeeId && class_exists(\App\Models\EmployeeModel::class)) {
                try {
                    $empRow = (new \App\Models\EmployeeModel())->find($employeeId);
                    if ($empRow) {
                        $empContext = $empRow;
                        if (empty($companyId) && !empty($empRow['company_id'])) {
                            $companyId = $empRow['company_id'];
                        }
                    }
                } catch (\Throwable $e) {}
            }

            if (empty($companyId) && function_exists('session')) {
                try {
                    $companyId = session('company_id');
                } catch (\Throwable $e) {}
            }

            // Single Source of Truth: RuleResolver
            if (!empty($companyId) && class_exists(\App\Services\Rules\RuleResolver::class)) {
                try {
                    $resolved = \App\Services\Rules\RuleResolver::resolveStatic(
                        $companyId,
                        'ATTENDANCE',
                        $date,
                        $empContext ?: ($employeeId ? ['id' => $employeeId, 'company_id' => $companyId] : null)
                    );
                    $params = $resolved->params();
                    if (!empty($params['weekly_off_days'])) {
                        $raw = $params['weekly_off_days'];
                        if (is_string($raw)) {
                            $raw = array_values(array_filter(array_map('trim', explode(',', $raw))));
                        }
                        if (is_array($raw) && !empty($raw)) {
                            $parsed = array_values(array_filter(array_map(function($d) {
                                $d = trim((string)$d);
                                return !empty($d) ? ucfirst(strtolower($d)) : null;
                            }, $raw)));

                            self::$cachedCompanyWeeklyOff[$cacheKey] = $parsed;
                            self::$isResolving = false;
                            return $parsed;
                        }
                    }
                } catch (\Throwable $re) {
                    // If company rule is missing in rule_definitions, seed baseline company rules via RuleSeeder
                    try {
                        if (class_exists(\App\Services\Rules\RuleSeeder::class)) {
                            \App\Services\Rules\RuleSeeder::seedCompany($companyId, [], $date);
                            $resolved = \App\Services\Rules\RuleResolver::resolveStatic(
                                $companyId,
                                'ATTENDANCE',
                                $date,
                                $empContext ?: ($employeeId ? ['id' => $employeeId, 'company_id' => $companyId] : null)
                            );
                            $params = $resolved->params();
                            if (!empty($params['weekly_off_days'])) {
                                $raw = $params['weekly_off_days'];
                                if (is_string($raw)) {
                                    $raw = array_values(array_filter(array_map('trim', explode(',', $raw))));
                                }
                                if (is_array($raw) && !empty($raw)) {
                                    $parsed = array_values(array_filter(array_map(function($d) {
                                        $d = trim((string)$d);
                                        return !empty($d) ? ucfirst(strtolower($d)) : null;
                                    }, $raw)));

                                    self::$cachedCompanyWeeklyOff[$cacheKey] = $parsed;
                                    self::$isResolving = false;
                                    return $parsed;
                                }
                            }
                        }
                    } catch (\Throwable $se) {
                        // Ignore seed error
                    }
                }
            }
        } catch (\Throwable $e) {
            // Ignore DB connect failure
        } finally {
            self::$isResolving = false;
        }

        // If tenant has NOT configured any weekly off policy:
        // Do NOT silently return Friday/Saturday unless explicitly requested ($allowSilentFallback = true).
        $fallback = $allowSilentFallback ? self::DEFAULT_FALLBACK_WEEKLY_OFF : [];
        self::$cachedCompanyWeeklyOff[$cacheKey] = $fallback;
        return $fallback;
    }

    /**
     * Backward-compatible alias for getCompanyWeeklyOff
     */
    public static function getCompanyWeekendOffDays(?string $companyId = null, $employeeId = null, $allowSilentFallback = false, ?string $date = null): array
    {
        return self::getCompanyWeeklyOff($companyId, $employeeId, $allowSilentFallback, $date);
    }

    /**
     * Get detailed resolution metadata explaining the exact configuration source
     *
     * @param string|null $companyId
     * @param string|null $employeeId
     * @return array
     */
    public static function getResolvedWeeklyOffDetails(?string $companyId = null, ?string $employeeId = null): array
    {
        $explicitOff = self::getCompanyWeeklyOff($companyId, $employeeId, false);
        $isConfigured = !empty($explicitOff);

        $source = 'not_configured';
        if ($isConfigured) {
            $source = 'rule_definitions';
        }

        return [
            'is_configured'        => $isConfigured,
            'source'               => $source,
            'weekly_off'           => $explicitOff,
            'fallback_weekly_off'  => self::DEFAULT_FALLBACK_WEEKLY_OFF,
            'effective_weekly_off' => $isConfigured ? $explicitOff : self::DEFAULT_FALLBACK_WEEKLY_OFF,
            'display_label'        => $isConfigured ? implode(', ', $explicitOff) : 'Not Configured (Company Default)',
            'status_badge'         => $isConfigured ? 'Configured' : 'Not Configured'
        ];
    }



    /**
     * Get list of standard working days for the company (complement of weekly off)
     *
     * @param string|null $companyId
     * @param mixed $employeeId
     * @param bool $allowSilentFallback
     * @param string|null $date
     * @return array List of weekday names that are working days
     */
    public static function getCompanyWorkingDays(?string $companyId = null, $employeeId = null, bool $allowSilentFallback = true, ?string $date = null): array
    {
        if (is_string($employeeId) && preg_match('/^\d{4}-\d{2}-\d{2}/', $employeeId) && $date === null) {
            $date = $employeeId;
            $employeeId = null;
        }

        $weeklyOff = self::getCompanyWeeklyOff($companyId, $employeeId, $allowSilentFallback, $date);
        if (empty($weeklyOff) && $allowSilentFallback) {
            $weeklyOff = self::DEFAULT_FALLBACK_WEEKLY_OFF;
        }
        $workingDays = [];

        foreach (self::$allWeekDays as $day) {
            if (!in_array($day, $weeklyOff, true)) {
                $workingDays[] = $day;
            }
        }

        return $workingDays;
    }

    /**
     * Check if a specific calendar date is a weekly off / weekend day for the company/employee
     */
    public static function isWeeklyOff(string $date, ?string $companyId = null, ?string $employeeId = null, bool $allowSilentFallback = false): bool
    {
        $dayOfWeek = date('l', strtotime($date));
        $weeklyOffDays = self::getCompanyWeeklyOff($companyId, $employeeId, $allowSilentFallback, $date);
        return in_array($dayOfWeek, $weeklyOffDays, true);
    }

    /**
     * Check if the company/employee has an explicit weekly off configuration in rule store
     */
    public static function hasExplicitWeeklyOffConfig(?string $companyId = null, ?string $employeeId = null): bool
    {
        $explicit = self::getCompanyWeeklyOff($companyId, $employeeId, false);
        return !empty($explicit);
    }

    /**
     * Parse raw weekly_off field from database (JSON array or comma-separated string)
     */
    public static function parseWeeklyOffField($raw): array
    {
        if (empty($raw)) {
            return [];
        }

        $validDays = self::$allWeekDays;
        $normalizeDay = static function ($d) use ($validDays): ?string {
            $clean = trim((string)$d);
            if ($clean === '') {
                return null;
            }
            $formatted = ucfirst(strtolower($clean));
            return in_array($formatted, $validDays, true) ? $formatted : null;
        };

        if (is_array($raw)) {
            return array_values(array_unique(array_filter(array_map($normalizeDay, $raw))));
        }

        if (is_string($raw)) {
            $raw = trim($raw);
            if (str_starts_with($raw, '[') && str_ends_with($raw, ']')) {
                $decoded = json_decode($raw, true);
                if (is_array($decoded)) {
                    return array_values(array_unique(array_filter(array_map($normalizeDay, $decoded))));
                }
            }

            // Comma-separated list
            $parts = explode(',', $raw);
            return array_values(array_unique(array_filter(array_map($normalizeDay, $parts))));
        }

        return [];
    }

    /**
     * Find active Duty Assignment for an employee on a given date with static caching
     */
    public static function getDutyAssignment(string $employeeId, string $date, ?string $companyId = null): ?array
    {
        if (empty($employeeId) || empty($date)) {
            return null;
        }

        $cacheKey = $employeeId . '_' . $date;
        if (array_key_exists($cacheKey, self::$cachedDutyAssignments)) {
            return self::$cachedDutyAssignments[$cacheKey];
        }

        try {
            $db = Database::connect();
            if (!$db->tableExists('duty_assignments')) {
                self::$cachedDutyAssignments[$cacheKey] = null;
                return null;
            }

            $builder = $db->table('duty_assignments')
                ->where('employee_id', $employeeId)
                ->where('duty_date', $date)
                ->whereIn('status', ['Assigned', 'Confirmed', 'Completed']);

            if (!empty($companyId)) {
                $builder->where('company_id', $companyId);
            }

            $row = $builder->orderBy('created_at', 'DESC')->get(1)->getRowArray();
            self::$cachedDutyAssignments[$cacheKey] = $row ?: null;
            return self::$cachedDutyAssignments[$cacheKey];
        } catch (\Throwable $e) {
            self::$cachedDutyAssignments[$cacheKey] = null;
            return null;
        }
    }

    /**
     * Preload Duty Assignments for multiple employees in a single query.
     * Populates in-memory lookup cache to eliminate N+1 queries.
     *
     * @param array $employeeIds
     * @param string $date
     * @param string|null $companyId
     * @return array In-memory map keyed by employee_id
     */
    public static function preloadDutyAssignments(array $employeeIds, string $date, ?string $companyId = null): array
    {
        $cleanIds = array_values(array_filter(array_unique(array_map('strval', $employeeIds))));
        if (empty($cleanIds) || empty($date)) {
            return [];
        }

        $dutyByEmp = [];

        try {
            $db = Database::connect();
            if (!$db->tableExists('duty_assignments')) {
                foreach ($cleanIds as $id) {
                    self::$cachedDutyAssignments[$id . '_' . $date] = null;
                }
                return [];
            }

            $builder = $db->table('duty_assignments')
                ->whereIn('employee_id', $cleanIds)
                ->where('duty_date', $date)
                ->whereIn('status', ['Assigned', 'Confirmed', 'Completed']);

            if (!empty($companyId)) {
                $builder->where('company_id', $companyId);
            }

            $rows = $builder->orderBy('created_at', 'DESC')->get()->getResultArray();
            foreach ($rows as $row) {
                $eId = (string)($row['employee_id'] ?? '');
                if ($eId && !isset($dutyByEmp[$eId])) {
                    $dutyByEmp[$eId] = $row;
                    self::$cachedDutyAssignments[$eId . '_' . $date] = $row;
                }
            }

            // Prime null for any employee with no duty assignment
            foreach ($cleanIds as $id) {
                if (!array_key_exists($id, $dutyByEmp)) {
                    $dutyByEmp[$id] = null;
                    self::$cachedDutyAssignments[$id . '_' . $date] = null;
                }
            }
        } catch (\Throwable $e) {
            foreach ($cleanIds as $id) {
                self::$cachedDutyAssignments[$id . '_' . $date] = null;
            }
        }

        return $dutyByEmp;
    }

    /**
     * Preload Company & Employee weekly-off configuration in 1-2 batched queries.
     * Populates in-memory lookup cache to eliminate N+1 queries during employee calculation loops.
     *
     * @param array $employees List of employee arrays (with shift/weekly_off data)
     * @param string|null $companyId
     * @return array In-memory map keyed by employee_id => array of weekly off days
     */
    public static function preloadCompanyWeeklyOff(array $employees, ?string $companyId = null): array
    {
        if (empty($employees)) {
            return [];
        }

        $weeklyOffByEmp = [];
        $date = date('Y-m-d');

        // Resolve Company-level weekly off once via RuleResolver
        $compWeeklyOff = self::getCompanyWeeklyOff($companyId, null, false, $date);

        // Fast path: Check if any non-company scope rules exist in rule_definitions for ATTENDANCE.
        // If only Company scope exists, every employee shares the company weekly off with 0 redundant queries!
        $hasCustomRules = false;
        try {
            $db = Database::connect();
            if ($db->tableExists('rule_definitions')) {
                $builder = $db->table('rule_definitions')
                    ->where('domain', 'ATTENDANCE')
                    ->where('status', 'Active')
                    ->where('scope_level !=', 'Company');
                if (!empty($companyId)) {
                    $builder->where('company_id', $companyId);
                }
                $hasCustomRules = ($builder->countAllResults() > 0);
            }
        } catch (\Throwable $e) {}

        // Preload weekly off for each employee via RuleResolver
        foreach ($employees as $emp) {
            $empId = (string)($emp['id'] ?? '');
            if (!$empId) {
                continue;
            }

            $empCompanyId = $emp['company_id'] ?? $companyId;
            if (!$hasCustomRules && !empty($compWeeklyOff)) {
                $resolvedDays = $compWeeklyOff;
            } else {
                $resolvedDays = self::getCompanyWeeklyOff($empCompanyId, $empId, false, $date);
                if (empty($resolvedDays) && !empty($compWeeklyOff)) {
                    $resolvedDays = $compWeeklyOff;
                }
            }

            $daysStrict = $resolvedDays ?: [];
            $daysSilent = $resolvedDays ?: self::DEFAULT_FALLBACK_WEEKLY_OFF;

            // Cache in memory under CompanyWeekendService keys so any direct getCompanyWeeklyOff call hits cache!
            $keyBase = ($empCompanyId ?: 'default_context') . '_' . $empId;
            self::$cachedCompanyWeeklyOff[$keyBase . '_0'] = $daysStrict;
            self::$cachedCompanyWeeklyOff[$keyBase . '_1'] = $daysSilent;
            self::$cachedCompanyWeeklyOff[$keyBase . '_0_' . $date] = $daysStrict;
            self::$cachedCompanyWeeklyOff[$keyBase . '_1_' . $date] = $daysSilent;

            // If companyId was passed, also cache with that prefix
            if (!empty($companyId) && (string)$companyId !== (string)$empCompanyId) {
                $altKey = $companyId . '_' . $empId;
                self::$cachedCompanyWeeklyOff[$altKey . '_0'] = $daysStrict;
                self::$cachedCompanyWeeklyOff[$altKey . '_1'] = $daysSilent;
                self::$cachedCompanyWeeklyOff[$altKey . '_0_' . $date] = $daysStrict;
                self::$cachedCompanyWeeklyOff[$altKey . '_1_' . $date] = $daysSilent;
            }

            $weeklyOffByEmp[$empId] = $daysStrict;
        }

        return $weeklyOffByEmp;
    }

    /**
     * Evaluate Day Type according to strict business priority order:
     *
     * 1. Holiday check:
     *    - If is holiday AND duty assigned -> HOLIDAY_DUTY
     *    - If is holiday AND no duty -> HOLIDAY
     * 2. Weekend / Weekly Off check:
     *    - If is weekly off AND duty assigned -> WEEKEND_DUTY
     *    - If is weekly off AND no duty -> WEEKLY_OFF
     * 3. Workday check:
     *    - If duty assigned -> SPECIAL_DUTY / NORMAL_DUTY
     *    - Otherwise -> NORMAL_WORKDAY
     *
     * @param string $date (Y-m-d)
     * @param array $employee Employee record
     * @param array|null $shift Assigned Shift
     * @param array $holidays List of active holidays
     * @param array|null $dutyAssignment Optional pre-fetched duty assignment
     * @return array Evaluation details
     */
    public static function evaluateDayType(
        string $date,
        array $employee,
        ?array $shift = null,
        array $holidays = [],
        ?array $dutyAssignment = null
    ): array {
        $companyId = $employee['company_id'] ?? null;
        $employeeId = $employee['id'] ?? '';
        $branchId = $employee['branch_id'] ?? null;
        $dayOfWeek = date('l', strtotime($date));

        // 1. Check if duty assignment exists
        if ($dutyAssignment === null && !empty($employeeId)) {
            $dutyAssignment = self::getDutyAssignment($employeeId, $date, $companyId);
        }

        $hasDuty = !empty($dutyAssignment) && in_array($dutyAssignment['status'] ?? '', ['Assigned', 'Confirmed', 'Completed']);
        $dutyType = $hasDuty ? ($dutyAssignment['duty_type'] ?? 'WEEKEND_DUTY') : null;

        // 2. Check if Date is a Holiday
        $isHoliday = false;
        $holidayName = '';
        $holidayType = 'Public';

        foreach ($holidays as $h) {
            $hStart = $h['date'] ?? $h['start_date'] ?? $h['from_date'] ?? '';
            $hEnd = $h['end_date'] ?? $h['to_date'] ?? $hStart;
            $hCompId = $h['company_id'] ?? null;
            $hBranchId = $h['branch_id'] ?? null;

            // Scope filter
            if ($hCompId && $companyId && $hCompId !== $companyId) {
                continue;
            }
            if ($hBranchId && $branchId && $hBranchId !== $branchId) {
                continue;
            }

            if ($date >= $hStart && $date <= $hEnd) {
                $isHoliday = true;
                $holidayName = $h['name'] ?? $h['title'] ?? 'Company Holiday';
                $holidayType = $h['type'] ?? 'Public';
                break;
            }
        }

        // 3. Check if Date is a Weekly Off (Weekend)
        $isWeeklyOff = self::isWeeklyOff($date, $companyId, $employeeId);

        // 4. Strict Day Type Determination
        $dayType = 'NORMAL_WORKDAY';
        $badgeClass = 'bg-slate-50 text-slate-700 border-slate-200';
        $statusLabel = 'Normal Workday';

        if ($isHoliday || (($shift['outcome'] ?? '') === 'HOLIDAY')) {
            if ($hasDuty) {
                $dayType = 'HOLIDAY_DUTY';
                $badgeClass = 'bg-purple-100 text-purple-800 border-purple-300 font-bold';
                $statusLabel = 'Holiday Duty';
            } else {
                $dayType = 'HOLIDAY';
                $badgeClass = 'bg-amber-50 text-amber-800 border-amber-200 font-medium';
                $statusLabel = 'Public Holiday';
            }
        } elseif ($isWeeklyOff || (($shift['outcome'] ?? '') === 'WEEKLY_OFF')) {
            if ($hasDuty) {
                $dayType = 'WEEKEND_DUTY';
                $badgeClass = 'bg-indigo-100 text-indigo-800 border-indigo-300 font-bold';
                $statusLabel = 'Weekend Duty';
            } else {
                $dayType = 'WEEKLY_OFF';
                $badgeClass = 'bg-slate-100 text-slate-600 border-slate-200';
                $statusLabel = 'Weekly Off';
            }
        } else {
            if ($hasDuty) {
                $dayType = !empty($dutyType) && $dutyType !== 'WEEKEND_DUTY' ? $dutyType : 'SPECIAL_DUTY';
                $badgeClass = 'bg-cyan-100 text-cyan-800 border-cyan-300 font-bold';
                $statusLabel = 'Special Duty';
            } elseif (($shift['outcome'] ?? '') === 'ROSTER_DAY_OFF' || (!empty($shift['is_day_off']) && ($shift['source'] ?? '') === 'ROSTER_DAY_OFF')) {
                $dayType = 'ROSTER_DAY_OFF';
                $badgeClass = 'bg-gray-100 text-gray-700 border-gray-300';
                $statusLabel = 'Roster Day Off';
            } elseif (($shift['outcome'] ?? '') === 'NO_ASSIGNED_SHIFT' || (isset($shift['is_scheduled']) && !$shift['is_scheduled'])) {
                $dayType = 'UNSCHEDULED';
                $badgeClass = 'bg-slate-100 text-slate-600 border-slate-300';
                $statusLabel = 'No Assigned Shift';
            } else {
                $dayType = 'NORMAL_WORKDAY';
                $badgeClass = 'bg-emerald-50 text-emerald-700 border-emerald-200';
                $statusLabel = 'Working Day';
            }
        }

        return [
            'date'               => $date,
            'day_of_week'        => $dayOfWeek,
            'day_type'           => $dayType,
            'status_label'       => $statusLabel,
            'badge_class'        => $badgeClass,
            'is_weekend'         => $isWeeklyOff,
            'is_weekly_off'      => $isWeeklyOff,
            'is_holiday'         => $isHoliday,
            'holiday_name'       => $holidayName,
            'holiday_type'       => $holidayType,
            'is_duty_assigned'   => $hasDuty,
            'duty_type'          => $dutyType,
            'duty_assignment'    => $dutyAssignment,
            'is_overtime_day'    => ($dayType === 'WEEKEND_DUTY' || $dayType === 'HOLIDAY_DUTY' || $dayType === 'SPECIAL_DUTY')
        ];
    }

    /**
     * Calculate Weekend / Off-day Overtime according to configured policy
     *
     * Supports both business rules:
     * - Rule A: Entire worked shift becomes Overtime (e.g. 8h worked = 8h OT at 2.0x)
     * - Rule B: Only hours beyond scheduled duty become Overtime (e.g. 10h worked on 8h duty = 2h OT)
     *
     * @param float $netWorkedHours Actual net working hours
     * @param float $scheduledShiftHours Standard shift hours (e.g. 8.0)
     * @param string $otTreatment 'All Worked Hours as OT' | 'Hours Beyond Shift as OT'
     * @param float $baseHourlyRate
     * @param float $weekendMultiplier (e.g. 2.0)
     * @param array $otRule Additional rules (rounding, min OT minutes, max daily cap)
     * @return array
     */
    public static function calculateWeekendOvertime(
        float $netWorkedHours,
        float $scheduledShiftHours = 8.0,
        string $otTreatment = 'All Worked Hours as OT',
        float $baseHourlyRate = 83.33,
        float $weekendMultiplier = 2.0,
        array $otRule = []
    ): array {
        if ($netWorkedHours <= 0) {
            return [
                'overtime_hours'     => 0.00,
                'regular_hours'      => 0.00,
                'rate_multiplier'    => $weekendMultiplier,
                'base_hourly_rate'   => $baseHourlyRate,
                'overtime_rate'      => round($baseHourlyRate * $weekendMultiplier, 2),
                'calculated_amount'  => 0.00,
                'treatment_applied'  => $otTreatment
            ];
        }

        $isAllWorkedAsOt = ($otTreatment === 'All Worked Hours as OT' || $otTreatment === 'all_hours_as_ot' || empty($otTreatment));

        $otHours = 0.0;
        $regularHours = 0.0;

        if ($isAllWorkedAsOt) {
            $otHours = $netWorkedHours;
            $regularHours = 0.0;
        } else {
            // Hours beyond scheduled shift
            $otHours = max(0.0, $netWorkedHours - $scheduledShiftHours);
            $regularHours = min($netWorkedHours, $scheduledShiftHours);
        }

        // Apply qualifying threshold (e.g. 30 minutes)
        $minOtMinutes = (int)($otRule['minOtMinutesToQualify'] ?? 0);
        if ($minOtMinutes > 0 && ($otHours * 60) < $minOtMinutes) {
            $otHours = 0.0;
        }

        // Apply daily fatigue cap if configured
        $maxOtCap = (float)($otRule['maxOtHoursPerDay'] ?? 0);
        if ($maxOtCap > 0) {
            $otHours = min($otHours, $maxOtCap);
        }

        // Rounding
        $rounding = $otRule['roundingMethod'] ?? 'Exact';
        if ($rounding === 'Round to 15m' || $rounding === '15 Minutes') {
            $otHours = round($otHours * 4) / 4;
        } elseif ($rounding === 'Round to 30m' || $rounding === '30 Minutes') {
            $otHours = round($otHours * 2) / 2;
        } elseif ($rounding === 'Floor to 30m') {
            $otHours = floor($otHours * 2) / 2;
        } elseif ($rounding === 'Ceil to 30m') {
            $otHours = ceil($otHours * 2) / 2;
        }

        $otRate = round($baseHourlyRate * $weekendMultiplier, 2);
        $otAmount = round($otHours * $otRate, 2);

        return [
            'overtime_hours'     => round($otHours, 2),
            'regular_hours'      => round($regularHours, 2),
            'rate_multiplier'    => $weekendMultiplier,
            'base_hourly_rate'   => $baseHourlyRate,
            'overtime_rate'      => $otRate,
            'calculated_amount'  => $otAmount,
            'treatment_applied'  => $isAllWorkedAsOt ? 'All Worked Hours as OT' : 'Hours Beyond Shift as OT'
        ];
    }
}
