<?php

namespace App\Services\Rules;

class RuleParamValidator
{
    /**
     * Normalize legacy parameter aliases and mappings on a copy of parameters.
     * Does not mutate input array.
     *
     * @param string $domain
     * @param array $params
     * @return array Normalized copy of params
     */
    public static function normalizeLegacyKeys(string $domain, array $params): array
    {
        $normalized = $params;
        $domainUpper = strtoupper($domain);

        if ($domainUpper === 'LEAVE' && isset($normalized['entitlements']) && is_array($normalized['entitlements'])) {
            $entitlements = [];
            foreach ($normalized['entitlements'] as $entitlement) {
                if (is_array($entitlement)) {
                    $item = $entitlement;
                    if (!array_key_exists('accrual_rate_per_month', $item) && array_key_exists('monthly_accrual_rate', $item)) {
                        $item['accrual_rate_per_month'] = $item['monthly_accrual_rate'];
                    }
                    unset($item['leave_type_name'], $item['monthly_accrual_rate']);
                    $entitlements[] = $item;
                } else {
                    $entitlements[] = $entitlement;
                }
            }
            $normalized['entitlements'] = $entitlements;
        }

        return $normalized;
    }

    /**
     * Validate params for a given domain and scope level
     *
     * @param string $domain
     * @param string $scopeLevel
     * @param array $params
     * @param bool $partial If true, missing required keys are ignored (for overrides)
     * @param string|null $companyId Tenant company ID context for lookups
     * @return array ['valid' => bool, 'errors' => array<string, string>, 'clean' => array]
     */
    public static function validate(string $domain, string $scopeLevel, array $params, bool $partial = false, ?string $companyId = null): array
    {
        $normalizedParams = self::normalizeLegacyKeys($domain, $params);

        if ($companyId === null) {
            if (isset($normalizedParams['company_id']) && is_string($normalizedParams['company_id'])) {
                $companyId = $normalizedParams['company_id'];
            } elseif (function_exists('session')) {
                try {
                    $sess = session();
                    if ($sess) {
                        $companyId = $sess->get('company_id') ?: $sess->get('user_company_id');
                    }
                } catch (\Throwable $e) {
                    // ignore
                }
            }
        }

        $domainDef = RuleSchemaRegistry::domain($domain);
        if ($domainDef === null) {
            return [
                'valid'  => false,
                'errors' => ['domain' => "Unknown rule domain '{$domain}'"],
                'clean'  => [],
            ];
        }

        $errors = [];
        $clean  = [];

        // 1. Validate scope level
        $allowedScopes = RuleSchemaRegistry::allowedScopes($domain);
        if (!in_array($scopeLevel, $allowedScopes, true)) {
            $errors['scope_level'] = "Scope level '{$scopeLevel}' is not allowed for domain '{$domain}'. Allowed scopes: " . implode(', ', $allowedScopes);
        }

        $paramDefs = RuleSchemaRegistry::params($domain);
        $paramDefsByKey = [];
        foreach ($paramDefs as $def) {
            if (isset($def['key'])) {
                $paramDefsByKey[$def['key']] = $def;
            }
        }

        // 2. Reject unknown keys
        foreach ($normalizedParams as $key => $val) {
            if (!isset($paramDefsByKey[$key])) {
                $errors[$key] = "Unknown parameter '{$key}' for domain '{$domain}'";
            }
        }

        // 3. Required check (enforced when $partial === false)
        if (!$partial) {
            foreach ($paramDefsByKey as $key => $def) {
                if (!array_key_exists($key, $normalizedParams)) {
                    // For full scope, parameters must be provided unless explicitly marked required: false
                    $isRequired = $def['required'] ?? true;
                    if ($isRequired) {
                        $errors[$key] = "Parameter '{$key}' is required";
                    }
                }
            }
        }

        // 4. Validate each provided parameter against its schema
        foreach ($normalizedParams as $key => $val) {
            if (!isset($paramDefsByKey[$key])) {
                continue; // Already flagged as unknown key
            }

            $def = $paramDefsByKey[$key];
            $fieldResult = self::validateField($key, $val, $def, $domain, $companyId, $normalizedParams, $partial);

            if ($fieldResult['error'] !== null) {
                $errors[$key] = $fieldResult['error'];
            } elseif (array_key_exists('clean', $fieldResult)) {
                $clean[$key] = $fieldResult['clean'];
            }

            // If nested errors exist (for array_of_objects)
            if (!empty($fieldResult['nested_errors'])) {
                foreach ($fieldResult['nested_errors'] as $subKey => $subErr) {
                    $errors[$subKey] = $subErr;
                }
            }
        }

        // 5. Domain-specific formula validation for PF
        if (strtoupper($domain) === 'PF') {
            $extraVars = [];
            if (!empty($companyId)) {
                $compOptions = RuleSchemaRegistry::componentOptions($companyId);
                $extraVars = array_column($compOptions, 'code');
            }
            $pfFormulaCheck = \App\Services\Pf\PfCalculator::validateFormulaFields($normalizedParams, $extraVars);
            if (!$pfFormulaCheck['valid']) {
                foreach ($pfFormulaCheck['errors'] as $fKey => $fErr) {
                    if (!isset($errors[$fKey])) {
                        $errors[$fKey] = $fErr;
                    }
                }
            }
        }

        return [
            'valid'  => empty($errors),
            'errors' => $errors,
            'clean'  => empty($errors) ? $clean : $clean,
        ];
    }

    /**
     * Validate a single field based on its schema definition
     */
    private static function validateField(string $path, mixed $val, array $def, string $domain, ?string $companyId = null, array $context = [], bool $isPartial = false): array
    {
        $type = $def['type'] ?? 'string';
        $nullable = !empty($def['nullable']);

        // Check required_when if defined on the field
        if (!empty($def['required_when']) && is_array($def['required_when'])) {
            $conditionMet = true;
            foreach ($def['required_when'] as $condField => $condVal) {
                if (($context[$condField] ?? null) !== $condVal) {
                    $conditionMet = false;
                    break;
                }
            }
            if ($conditionMet) {
                if ($val === null || (is_array($val) && empty($val)) || (is_string($val) && trim($val) === '')) {
                    $condDesc = implode(', ', array_map(fn($k, $v) => "{$k} is '{$v}'", array_keys($def['required_when']), $def['required_when']));
                    return ['error' => "Parameter '{$path}' cannot be empty when {$condDesc}"];
                }
            }
        }

        // Handle null values
        if ($val === null) {
            if ($nullable || empty($def['required'])) {
                return ['clean' => null, 'error' => null];
            }
            return ['error' => "Parameter '{$path}' cannot be null"];
        }

        // Pending inventory handling
        if (!empty($def['pending_inventory'])) {
            RuleSchemaRegistry::logPendingWarning($domain, $path);
            if (is_string($val) || is_array($val) || is_numeric($val) || is_bool($val)) {
                return ['clean' => $val, 'error' => null];
            }
            return ['error' => "Parameter '{$path}' must be a valid string or object for pending inventory"];
        }

        return match ($type) {
            'bool'               => self::validateBool($path, $val),
            'int'                => self::validateInt($path, $val, $def),
            'decimal'            => self::validateDecimal($path, $val, $def),
            'money'              => self::validateMoney($path, $val, $def),
            'string'             => self::validateString($path, $val, $def, $companyId),
            'enum'               => self::validateEnum($path, $val, $def),
            'enum_list'          => self::validateEnumList($path, $val, $def),
            'component_ref_list' => self::validateComponentRefList($path, $val, $def, $companyId),
            'array_of_objects'   => self::validateArrayOfObjects($path, $val, $def, $domain, $companyId),
            'object'             => self::validateObject($path, $val, $def, $domain, $companyId, $isPartial),
            'array'              => self::validateArray($path, $val),
            'date'               => self::validateDate($path, $val),
            default              => ['error' => "Unknown type '{$type}' for parameter '{$path}'"],
        };
    }

    private static function validateBool(string $path, mixed $val): array
    {
        if (is_bool($val)) {
            return ['clean' => $val, 'error' => null];
        }

        if ($val === 1 || $val === '1' || $val === 'true') {
            return ['clean' => true, 'error' => null];
        }

        if ($val === 0 || $val === '0' || $val === 'false') {
            return ['clean' => false, 'error' => null];
        }

        return ['error' => "Parameter '{$path}' must be a boolean"];
    }

    private static function validateInt(string $path, mixed $val, array $def): array
    {
        if (!is_int($val)) {
            if (!is_numeric($val) || (string)(int)$val !== (string)$val) {
                return ['error' => "Parameter '{$path}' must be an integer"];
            }
        }

        $intVal = (int)$val;

        if (isset($def['min']) && $intVal < $def['min']) {
            return ['error' => "Parameter '{$path}' must be at least {$def['min']}"];
        }

        if (isset($def['max']) && $intVal > $def['max']) {
            return ['error' => "Parameter '{$path}' must be at most {$def['max']}"];
        }

        return ['clean' => $intVal, 'error' => null];
    }

    private static function validateDecimal(string $path, mixed $val, array $def): array
    {
        if (!is_numeric($val)) {
            return ['error' => "Parameter '{$path}' must be a decimal number"];
        }

        $floatVal = (float)$val;

        if (isset($def['min']) && $floatVal < $def['min']) {
            return ['error' => "Parameter '{$path}' must be at least {$def['min']}"];
        }

        if (isset($def['max']) && $floatVal > $def['max']) {
            return ['error' => "Parameter '{$path}' must be at most {$def['max']}"];
        }

        return ['clean' => $floatVal, 'error' => null];
    }

    private static function validateMoney(string $path, mixed $val, array $def): array
    {
        if (!is_numeric($val)) {
            return ['error' => "Parameter '{$path}' must be a valid monetary amount"];
        }

        $moneyVal = round((float)$val, 2);

        if (isset($def['min']) && $moneyVal < $def['min']) {
            return ['error' => "Parameter '{$path}' must be at least {$def['min']}"];
        }

        if (isset($def['max']) && $moneyVal > $def['max']) {
            return ['error' => "Parameter '{$path}' must be at most {$def['max']}"];
        }

        return ['clean' => $moneyVal, 'error' => null];
    }

    private static function validateString(string $path, mixed $val, array $def, ?string $companyId = null): array
    {
        if (!is_string($val)) {
            return ['error' => "Parameter '{$path}' must be a string"];
        }

        if (!empty($def['required']) && trim($val) === '') {
            return ['error' => "Parameter '{$path}' cannot be empty"];
        }

        if (isset($def['max_length']) && mb_strlen($val) > $def['max_length']) {
            return ['error' => "Parameter '{$path}' exceeds maximum length of {$def['max_length']}"];
        }

        if (isset($def['pattern'])) {
            $pattern = '/' . str_replace('/', '\/', $def['pattern']) . '/';
            if (@preg_match($pattern, $val) !== 1) {
                return ['error' => "Parameter '{$path}' does not match required pattern"];
            }
        }

        $isFormulaField = (
            $path === 'custom_formula'
            || $path === 'employer_formula'
            || str_ends_with($path, '.custom_formula')
            || str_ends_with($path, '.employer_formula')
        );
        if ($isFormulaField && trim($val) !== '') {
            $extraVars = [];
            if (!empty($companyId)) {
                $compOptions = RuleSchemaRegistry::componentOptions($companyId);
                $extraVars = array_column($compOptions, 'code');
            }
            $syntaxRes = FormulaEvaluator::testFormulaSyntax($val, $extraVars);
            if (!$syntaxRes['valid']) {
                return ['error' => "Invalid formula in '{$path}': " . ($syntaxRes['error'] ?? 'Invalid syntax')];
            }
        }

        return ['clean' => $val, 'error' => null];
    }

    private static function resolveAllowedEnumValues(array $def): array
    {
        if (isset($def['enum']) && is_array($def['enum'])) {
            return $def['enum'];
        }

        if (isset($def['enum']) && is_string($def['enum'])) {
            return RuleSchemaRegistry::sharedEnum($def['enum']);
        }

        if (isset($def['shared_enum']) && is_string($def['shared_enum'])) {
            return RuleSchemaRegistry::sharedEnum($def['shared_enum']);
        }

        return [];
    }

    private static function validateEnum(string $path, mixed $val, array $def): array
    {
        $allowed = self::resolveAllowedEnumValues($def);

        if (is_string($val)) {
            $trimmed = trim($val);
            foreach ($allowed as $option) {
                if (strcasecmp($trimmed, (string)$option) === 0) {
                    return ['clean' => $option, 'error' => null];
                }
            }
        }

        if (!in_array($val, $allowed, true)) {
            return ['error' => "Parameter '{$path}' must be one of: " . implode(', ', $allowed)];
        }

        return ['clean' => $val, 'error' => null];
    }

    private static function validateEnumList(string $path, mixed $val, array $def): array
    {
        if (!is_array($val)) {
            return ['error' => "Parameter '{$path}' must be a list of values"];
        }

        $allowed = self::resolveAllowedEnumValues($def);
        $clean = [];

        foreach ($val as $idx => $item) {
            if (!in_array($item, $allowed, true)) {
                return ['error' => "Invalid value '{$item}' in '{$path}'. Allowed values: " . implode(', ', $allowed)];
            }
            $clean[] = $item;
        }

        return ['clean' => array_values(array_unique($clean)), 'error' => null];
    }

    private static function validateComponentRefList(string $path, mixed $val, array $def, ?string $companyId): array
    {
        if (!is_array($val)) {
            return ['error' => "Parameter '{$path}' must be a list of component codes"];
        }

        if (empty($val)) {
            return ['clean' => [], 'error' => null];
        }

        $validOptions = !empty($companyId) ? RuleSchemaRegistry::componentOptions($companyId) : [];
        $validCodes = array_column($validOptions, 'code');

        $clean = [];
        foreach ($val as $idx => $code) {
            if (!is_string($code)) {
                return ['error' => "Invalid component code in '{$path}'. Each code must be a string"];
            }
            if (!in_array($code, $validCodes, true)) {
                return ['error' => "Unknown component code '{$code}' for company in '{$path}'"];
            }
            $clean[] = $code;
        }

        return ['clean' => array_values(array_unique($clean)), 'error' => null];
    }

    private static function validateArrayOfObjects(string $path, mixed $val, array $def, string $domain, ?string $companyId = null): array
    {
        if (!is_array($val)) {
            return ['error' => "Parameter '{$path}' must be an array of objects"];
        }

        $itemDefs = $def['item'] ?? [];
        $itemDefsByKey = [];
        foreach ($itemDefs as $iDef) {
            if (isset($iDef['key'])) {
                $itemDefsByKey[$iDef['key']] = $iDef;
            }
        }

        $clean = [];
        $nestedErrors = [];

        // Support unique_by option (string or array) or default unique 'code' for schemes
        $uniqueKeys = [];
        if (!empty($def['unique_by'])) {
            $uniqueKeys = is_array($def['unique_by']) ? $def['unique_by'] : [$def['unique_by']];
        }
        if (empty($uniqueKeys) && ($path === 'schemes' || str_ends_with($path, '.schemes') || $domain === 'BONUS')) {
            if (isset($itemDefsByKey['code'])) {
                $uniqueKeys = ['code'];
            }
        }

        $seenUnique = [];
        foreach ($uniqueKeys as $uk) {
            $seenUnique[$uk] = [];
        }

        foreach ($val as $idx => $itemData) {
            $itemPath = "{$path}.{$idx}";

            if (!is_array($itemData)) {
                $nestedErrors[$itemPath] = "Item at '{$itemPath}' must be an object";
                continue;
            }

            // Check unique constraints across items (case-insensitive, trimmed)
            foreach ($uniqueKeys as $uk) {
                if (array_key_exists($uk, $itemData) && $itemData[$uk] !== null) {
                    $rawVal = is_string($itemData[$uk]) ? strtolower(trim((string)$itemData[$uk])) : (string)$itemData[$uk];
                    if ($rawVal !== '') {
                        if (isset($seenUnique[$uk][$rawVal])) {
                            $prevIdx = $seenUnique[$uk][$rawVal];
                            $subPath = "{$itemPath}.{$uk}";
                            $nestedErrors[$subPath] = "Duplicate {$uk} '{$itemData[$uk]}' in '{$path}' (conflicts with item at index {$prevIdx})";
                        } else {
                            $seenUnique[$uk][$rawVal] = $idx;
                        }
                    }
                }
            }

            $cleanItem = [];

            // Check required fields and required_when in item schema
            foreach ($itemDefsByKey as $iKey => $iDef) {
                $subPath = "{$itemPath}.{$iKey}";

                if (!array_key_exists($iKey, $itemData)) {
                    // Check required_when if omitted
                    if (!empty($iDef['required_when']) && is_array($iDef['required_when'])) {
                        $conditionMet = true;
                        foreach ($iDef['required_when'] as $condField => $condVal) {
                            if (($itemData[$condField] ?? null) !== $condVal) {
                                $conditionMet = false;
                                break;
                            }
                        }
                        if ($conditionMet) {
                            $condDesc = implode(', ', array_map(fn($k, $v) => "{$k} is '{$v}'", array_keys($iDef['required_when']), $iDef['required_when']));
                            $nestedErrors[$subPath] = "Parameter '{$subPath}' cannot be empty when {$condDesc}";
                            continue;
                        }
                    }

                    if (!empty($iDef['required'])) {
                        $nestedErrors[$subPath] = "Parameter '{$subPath}' is required";
                        continue;
                    }

                    // Only harmless defaults for pure display fields or non-business fields (never business-relevant rules)
                    if ($iKey === 'category') {
                        $cleanItem[$iKey] = 'Festival';
                    } elseif ($iKey === 'custom_formula') {
                        $cleanItem[$iKey] = null;
                    } elseif ($iKey === 'included_component_codes') {
                        $cleanItem[$iKey] = [];
                    } elseif ($iKey === 'priority') {
                        $cleanItem[$iKey] = 1;
                    } elseif ($iKey === 'include_probation') {
                        $cleanItem[$iKey] = false;
                    } elseif ($iKey === 'prorate_under_service_days') {
                        $cleanItem[$iKey] = false;
                    } elseif ($iKey === 'prorate_threshold_months') {
                        $cleanItem[$iKey] = 0;
                    } elseif ($iKey === 'prorate_min_ratio') {
                        $cleanItem[$iKey] = 0.0;
                    }
                    continue;
                }

                $subVal = $itemData[$iKey];

                // Check required_when when field is present
                if (!empty($iDef['required_when']) && is_array($iDef['required_when'])) {
                    $conditionMet = true;
                    foreach ($iDef['required_when'] as $condField => $condVal) {
                        if (($itemData[$condField] ?? null) !== $condVal) {
                            $conditionMet = false;
                            break;
                        }
                    }
                    if ($conditionMet) {
                        if ($subVal === null || (is_array($subVal) && empty($subVal)) || (is_string($subVal) && trim($subVal) === '')) {
                            $condDesc = implode(', ', array_map(fn($k, $v) => "{$k} is '{$v}'", array_keys($iDef['required_when']), $iDef['required_when']));
                            $nestedErrors[$subPath] = "Parameter '{$subPath}' cannot be empty when {$condDesc}";
                            continue;
                        }
                    }
                }

                // If subVal is null and field is optional or nullable and condition was not met:
                if ($subVal === null && (empty($iDef['required']) || !empty($iDef['nullable']))) {
                    $cleanItem[$iKey] = null;
                    continue;
                }

                $subResult = self::validateField($subPath, $subVal, $iDef, $domain, $companyId, $itemData);

                if ($subResult['error'] !== null) {
                    $nestedErrors[$subPath] = $subResult['error'];
                } elseif (array_key_exists('clean', $subResult)) {
                    $cleanItem[$iKey] = $subResult['clean'];
                }

                if (!empty($subResult['nested_errors'])) {
                    foreach ($subResult['nested_errors'] as $nk => $ne) {
                        $nestedErrors[$nk] = $ne;
                    }
                }
            }

            // Reject unknown keys in itemData
            foreach ($itemData as $iKey => $iVal) {
                if (!isset($itemDefsByKey[$iKey])) {
                    $subPath = "{$itemPath}.{$iKey}";
                    $nestedErrors[$subPath] = "Unknown parameter '{$iKey}' in '{$path}'";
                }
            }

            $clean[] = $cleanItem;
        }

        return [
            'clean'         => $clean,
            'error'         => null,
            'nested_errors' => $nestedErrors,
        ];
    }

    private static function validateObject(string $path, mixed $val, array $def, string $domain = '', ?string $companyId = null, bool $isPartial = false): array
    {
        if (!is_array($val)) {
            return ['error' => "Parameter '{$path}' must be an object"];
        }

        // If properties schema is defined on the object, validate each child property
        if (!empty($def['properties']) && is_array($def['properties'])) {
            $cleanObj = [];
            $nestedErrors = [];

            foreach ($def['properties'] as $propKey => $propDef) {
                $subPath = "{$path}.{$propKey}";
                if (array_key_exists($propKey, $val)) {
                    $propVal = $val[$propKey];
                    $propRes = self::validateField($subPath, $propVal, $propDef, $domain, $companyId, $val, $isPartial);
                    if ($propRes['error'] !== null) {
                        $nestedErrors[$subPath] = $propRes['error'];
                    } elseif (array_key_exists('clean', $propRes)) {
                        $cleanObj[$propKey] = $propRes['clean'];
                    }
                    if (!empty($propRes['nested_errors'])) {
                        foreach ($propRes['nested_errors'] as $nk => $ne) {
                            $nestedErrors[$nk] = $ne;
                        }
                    }
                } elseif (!$isPartial && !empty($propDef['required'])) {
                    $nestedErrors[$subPath] = "Parameter '{$subPath}' is required";
                }
            }

            // Reject unknown properties in object
            foreach ($val as $k => $v) {
                if (!isset($def['properties'][$k])) {
                    $nestedErrors["{$path}.{$k}"] = "Unknown parameter '{$k}' in '{$path}'";
                }
            }

            return [
                'clean'         => $cleanObj,
                'error'         => null,
                'nested_errors' => $nestedErrors,
            ];
        }

        return ['clean' => $val, 'error' => null];
    }

    private static function validateArray(string $path, mixed $val): array
    {
        if (!is_array($val)) {
            return ['error' => "Parameter '{$path}' must be an array"];
        }

        return ['clean' => $val, 'error' => null];
    }

    private static function validateDate(string $path, mixed $val): array
    {
        if (!is_string($val) || preg_match('/^\d{4}-\d{2}-\d{2}$/', $val) !== 1) {
            return ['error' => "Parameter '{$path}' must be a valid date in YYYY-MM-DD format"];
        }

        [$year, $month, $day] = explode('-', $val);
        if (!checkdate((int)$month, (int)$day, (int)$year)) {
            return ['error' => "Parameter '{$path}' is an invalid calendar date"];
        }

        return ['clean' => $val, 'error' => null];
    }
}
