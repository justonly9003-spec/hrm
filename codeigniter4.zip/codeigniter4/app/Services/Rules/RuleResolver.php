<?php

namespace App\Services\Rules;

use App\Models\RuleDefinitionModel;
use InvalidArgumentException;

class RuleResolver
{
    /**
     * @var object|null
     */
    protected ?object $model = null;

    /**
     * Static injected model for test/mocking isolation
     *
     * @var object|null
     */
    protected static ?object $staticModel = null;

    /**
     * Active instance for instance-bound static delegation
     *
     * @var RuleResolver|null
     */
    protected static ?RuleResolver $activeInstance = null;

    /**
     * Per-request static memo cache
     *
     * @var array<string, ResolvedRule>
     */
    protected static array $staticMemo = [];

    /**
     * Per-request static rows cache by company and domain
     *
     * @var array<string, array>
     */
    protected static array $rowsCache = [];

    /**
     * Per-request static attendance profile memo cache
     *
     * @var array<string, array>
     */
    protected static array $attendanceProfileMemo = [];

    /**
     * Instance memo cache
     *
     * @var array<string, ResolvedRule>
     */
    protected array $memo = [];

    /**
     * @param object|null $model Optional model or fake model for testing
     * @param bool $makeActive Whether this instance should register as the global activeInstance (opt-in)
     */
    public function __construct(?object $model = null, bool $makeActive = false)
    {
        $this->model = $model;
        if ($makeActive) {
            if ($model !== null) {
                self::$staticModel = $model;
            }
            self::$activeInstance = $this;
        }
    }

    /**
     * Explicitly register this instance as the global active resolver.
     */
    public function makeActive(): self
    {
        if ($this->model !== null) {
            self::$staticModel = $this->model;
        }
        self::$activeInstance = $this;
        return $this;
    }

    /**
     * Explicitly set or clear the global active instance.
     */
    public static function setActiveInstance(?RuleResolver $instance): void
    {
        self::$activeInstance = $instance;
        if ($instance !== null && $instance->model !== null) {
            self::$staticModel = $instance->model;
        }
    }

    /**
     * Get the current active instance, or null if none is explicitly registered.
     */
    public static function getActiveInstance(): ?RuleResolver
    {
        return self::$activeInstance;
    }

    /**
     * Get today's date (YYYY-MM-DD) in the configured application timezone.
     */
    public static function today(): string
    {
        $tzString = 'UTC';
        if (function_exists('app_timezone')) {
            try {
                $tzString = app_timezone();
            } catch (\Throwable $e) {}
        } elseif (class_exists(\Config\App::class)) {
            try {
                $appConfig = config('App');
                if (!empty($appConfig->appTimezone)) {
                    $tzString = (string)$appConfig->appTimezone;
                }
            } catch (\Throwable $e) {}
        } else {
            $tzString = date_default_timezone_get() ?: 'UTC';
        }

        try {
            $tz = new \DateTimeZone($tzString);
            return (new \DateTime('now', $tz))->format('Y-m-d');
        } catch (\Throwable $e) {
            return (new \DateTime('now'))->format('Y-m-d');
        }
    }

    /**
     * Resolve effective rule profile for a company, domain, date, and optional employee/scope context.
     * Can be invoked statically: RuleResolver::resolve(...)
     * or on an instance: $resolver->resolve(...)
     *
     * @param string $companyId
     * @param string $domain
     * @param mixed $arg3 Date string (YYYY-MM-DD) or Employee array/scopes
     * @param mixed $arg4 Employee array/scopes or Date string (YYYY-MM-DD)
     * @return ResolvedRule
     * @throws RuleNotConfiguredException
     * @throws InvalidArgumentException
     */
    public static function resolve(
        string $companyId,
        string $domain,
        mixed $arg3 = null,
        mixed $arg4 = null
    ): ResolvedRule {
        $instance = self::$activeInstance ?? new self(self::$staticModel);
        return $instance->resolveInstance($companyId, $domain, $arg3, $arg4);
    }

    /**
     * Resolve effective rule profile on this instance.
     *
     * @param string $companyId
     * @param string $domain
     * @param mixed $date (YYYY-MM-DD)
     * @param mixed $employeeOrScopes
     * @return ResolvedRule
     * @throws RuleNotConfiguredException
     * @throws InvalidArgumentException
     */
    public function resolveInstance(
        string $companyId,
        string $domain,
        mixed $date = null,
        mixed $employeeOrScopes = null
    ): ResolvedRule {
        // Support both (company, domain, date, employee) and (company, domain, employee, date)
        if ((is_array($date) || is_object($date)) && (is_string($employeeOrScopes) || $employeeOrScopes === null)) {
            $temp = is_object($date) ? (json_decode(json_encode($date), true) ?: (array)$date) : $date;
            $date = is_string($employeeOrScopes) ? $employeeOrScopes : self::today();
            $employeeOrScopes = $temp;
        }

        if (is_object($employeeOrScopes)) {
            $employeeOrScopes = json_decode(json_encode($employeeOrScopes), true) ?: (array)$employeeOrScopes;
        }

        $companyId = trim((string)$companyId);
        $domain    = strtoupper(trim((string)$domain));
        if (is_object($date)) {
            if (method_exists($date, 'format')) {
                $date = $date->format('Y-m-d');
            } else {
                $date = self::today();
            }
        } elseif ($date === null || !is_scalar($date) || trim((string)$date) === '') {
            $date = self::today();
        } else {
            $date = substr(trim((string)$date), 0, 10);
        }

        if ($companyId === '') {
            if (is_array($employeeOrScopes) && !empty($employeeOrScopes['company_id'])) {
                $companyId = trim((string)$employeeOrScopes['company_id']);
            }
        }

        if ($companyId === '') {
            throw new InvalidArgumentException("Company ID is required for rule resolution");
        }
        if ($domain === '') {
            throw new InvalidArgumentException("Rule domain is required for rule resolution");
        }
        if ($date === '') {
            throw new InvalidArgumentException("Date is required for rule resolution");
        }

        $scopes  = $this->extractScopeIds($employeeOrScopes, $companyId);

        // Fetch active rows strictly for this company and domain
        $rawRows = $this->fetchRows($companyId, $domain);

        // Optimization: Filter scopes to only levels that actually exist in active rows for this domain/company.
        // If no Employee or Shift scope row exists, all employees share the same company-level resolution memo!
        $activeScopeLevels = [];
        foreach ($rawRows as $r) {
            $rComp = isset($r['company_id']) ? (string)$r['company_id'] : null;
            $rDom  = isset($r['domain']) ? strtoupper((string)$r['domain']) : null;
            $rStat = isset($r['status']) ? (string)$r['status'] : 'Active';
            if ($rComp === $companyId && $rDom === $domain && $rStat === 'Active' && !empty($r['scope_level'])) {
                $activeScopeLevels[$r['scope_level']] = true;
            }
        }

        $effectiveScopes = [];
        foreach ($scopes as $lvl => $val) {
            if (isset($activeScopeLevels[$lvl])) {
                $effectiveScopes[$lvl] = $val;
            }
        }

        $memoKey = $this->buildMemoKey($companyId, $domain, $date, $effectiveScopes);

        if (isset($this->memo[$memoKey])) {
            return $this->memo[$memoKey];
        }
        if (isset(self::$staticMemo[$memoKey])) {
            return self::$staticMemo[$memoKey];
        }

        // Filter active rows belonging strictly to this company and domain
        $companyRows = [];
        foreach ($rawRows as $r) {
            $rComp = isset($r['company_id']) ? (string)$r['company_id'] : null;
            $rDom  = isset($r['domain']) ? strtoupper((string)$r['domain']) : null;
            $rLvl  = isset($r['scope_level']) ? (string)$r['scope_level'] : null;
            $rStat = isset($r['status']) ? (string)$r['status'] : 'Active';

            if ($rComp === $companyId && $rDom === $domain && $rLvl === 'Company' && $rStat === 'Active') {
                $companyRows[] = $r;
            }
        }

        // Company layer is mandatory
        if (empty($companyRows)) {
            try {
                $db = \Config\Database::connect();
                if ($db->tableExists('companies')) {
                    $foundComp = $db->table('companies')
                        ->where('id', $companyId)
                        ->orWhere('code', $companyId)
                        ->get(1)
                        ->getRowArray();
                    if ($foundComp) {
                        $candidateIds = array_values(array_unique(array_filter([
                            $foundComp['id'] ?? null,
                            $foundComp['code'] ?? null,
                        ])));
                        foreach ($candidateIds as $altId) {
                            if ($altId === $companyId) {
                                continue;
                            }
                            $altRows = $this->fetchRows($altId, $domain);
                            foreach ($altRows as $r) {
                                $rComp = isset($r['company_id']) ? (string)$r['company_id'] : null;
                                $rDom  = isset($r['domain']) ? strtoupper((string)$r['domain']) : null;
                                $rLvl  = isset($r['scope_level']) ? (string)$r['scope_level'] : null;
                                $rStat = isset($r['status']) ? (string)$r['status'] : 'Active';

                                if ($rComp === $altId && $rDom === $domain && $rLvl === 'Company' && $rStat === 'Active') {
                                    $companyRows[] = $r;
                                }
                            }
                            if (!empty($companyRows)) {
                                $companyId = $altId;
                                $rawRows = $altRows;
                                break;
                            }
                        }
                    }
                }
            } catch (\Throwable $se) {
                // If company lookup fails, proceed to standard exception throw
            }
        }

        if (empty($companyRows)) {
            throw RuleNotConfiguredException::forDomain(
                $companyId,
                $domain,
                $date,
                "No active Company-level rule configured"
            );
        }

        // Filter Company rows covering $date using activeRowsFor helper
        $effectiveCompanyRows = $this->activeRowsFor($companyRows, 'Company', null, $date);

        if (empty($effectiveCompanyRows)) {
            $earliestEffectiveFrom = null;
            $latestEffectiveTo     = null;
            $hasOpenEndedVersion   = false;

            foreach ($companyRows as $r) {
                $effFrom = isset($r['effective_from']) ? substr((string)$r['effective_from'], 0, 10) : null;
                $effTo   = isset($r['effective_to']) && $r['effective_to'] !== null && $r['effective_to'] !== ''
                    ? substr((string)$r['effective_to'], 0, 10)
                    : null;

                if ($effFrom !== null) {
                    if ($earliestEffectiveFrom === null || $effFrom < $earliestEffectiveFrom) {
                        $earliestEffectiveFrom = $effFrom;
                    }
                }

                if ($effTo === null) {
                    $hasOpenEndedVersion = true;
                } else {
                    if ($latestEffectiveTo === null || $effTo > $latestEffectiveTo) {
                        $latestEffectiveTo = $effTo;
                    }
                }
            }

            if ($earliestEffectiveFrom !== null && $date < $earliestEffectiveFrom) {
                if ($this->model instanceof RuleDefinitionModel) {
                    $earliestCompanyRow = null;
                    foreach ($companyRows as $candidateRow) {
                        if (($candidateRow['status'] ?? '') !== 'Active') {
                            continue;
                        }
                        $candFrom = isset($candidateRow['effective_from']) ? substr((string)$candidateRow['effective_from'], 0, 10) : null;
                        if ($candFrom === $earliestEffectiveFrom) {
                            $earliestCompanyRow = $candidateRow;
                            break;
                        }
                    }

                    if ($earliestCompanyRow !== null) {
                        $yearStart = substr($date, 0, 4) . '-01-01';
                        $healedFrom = $date < $yearStart ? $date : $yearStart;
                        $earliestCompanyRow['effective_from'] = $healedFrom;
                        $effectiveCompanyRows = [$earliestCompanyRow];

                        if (!empty($earliestCompanyRow['id'])) {
                            try {
                                Database::connect()->table('rule_definitions')
                                    ->where('id', $earliestCompanyRow['id'])
                                    ->update(['effective_from' => $healedFrom]);
                            } catch (\Throwable $he) {
                                // Ignore DB update error during read-time self-heal
                            }
                        }
                    }
                }

                if (empty($effectiveCompanyRows)) {
                    throw RuleNotConfiguredException::forDomain(
                        $companyId,
                        $domain,
                        $date,
                        "Date '{$date}' is before first effective version starting '{$earliestEffectiveFrom}'"
                    );
                }
            }

            if (empty($effectiveCompanyRows) && !$hasOpenEndedVersion && $latestEffectiveTo !== null && $date > $latestEffectiveTo) {
                throw RuleNotConfiguredException::forDomain(
                    $companyId,
                    $domain,
                    $date,
                    "Date '{$date}' is after all configured versions ending '{$latestEffectiveTo}'"
                );
            }

            if (empty($effectiveCompanyRows)) {
                throw RuleNotConfiguredException::forDomain(
                    $companyId,
                    $domain,
                    $date,
                    "Date '{$date}' does not fall within any effective Company rule version"
                );
            }
        }

        $companyLayer = reset($effectiveCompanyRows);
        $layers = [$companyLayer];

        // Check child scopes in hierarchy order: Branch -> Department -> Designation -> Shift -> Employee
        $allowedScopes = null;
        if (class_exists(RuleSchemaRegistry::class)) {
            $allowedScopes = RuleSchemaRegistry::allowedScopes($domain);
        }

        $childLevels = ['Branch', 'Department', 'Designation', 'Shift', 'Employee'];
        foreach ($childLevels as $level) {
            if ($allowedScopes !== null && !in_array($level, $allowedScopes, true)) {
                continue;
            }

            $scopeId = isset($scopes[$level]) && $scopes[$level] !== null && $scopes[$level] !== ''
                ? (string)$scopes[$level]
                : null;

            if ($scopeId === null) {
                continue;
            }

            // Find matching active row for this scope level and scope ID covering $date
            $matchingChildRows = $this->activeRowsFor($rawRows, $level, $scopeId, $date);
            if (!empty($matchingChildRows)) {
                $layers[] = reset($matchingChildRows);
            }
        }

        // Merge key-by-key; arrays replaced whole; child layers may hold partial params
        $mergedParams   = [];
        $origins        = [];
        $layerSnapshots = [];

        foreach ($layers as $layer) {
            $scopeLevel = isset($layer['scope_level']) ? (string)$layer['scope_level'] : 'Company';
            $scopeId    = isset($layer['scope_id']) && $layer['scope_id'] !== null ? (string)$layer['scope_id'] : null;
            $versionNum = isset($layer['version_number']) ? (int)$layer['version_number'] : 1;
            $ruleId     = isset($layer['id']) ? (string)$layer['id'] : '';

            $layerSnapshots[] = [
                'scope_level'    => $scopeLevel,
                'scope_id'       => $scopeId,
                'version_number' => $versionNum,
                'rule_id'        => $ruleId,
            ];

            $params = $this->extractRowParams($layer);
            foreach ($params as $key => $val) {
                // Child layers may hold partial params.
                // Arrays replaced whole; scalars merged key-by-key.
                $mergedParams[$key] = $val;
                $origins[$key] = [
                    'scope_level'    => $scopeLevel,
                    'scope_id'       => $scopeId,
                    'version_number' => $versionNum,
                    'rule_id'        => $ruleId,
                ];
            }
        }

        $resolved = new ResolvedRule(
            $companyId,
            $domain,
            $date,
            $mergedParams,
            $layerSnapshots,
            $origins
        );

        if (count($this->memo) > 1000) {
            $this->memo = array_slice($this->memo, -500, null, true);
        }
        if (count(self::$staticMemo) > 1000) {
            self::$staticMemo = array_slice(self::$staticMemo, -500, null, true);
        }

        $this->memo[$memoKey]        = $resolved;
        self::$staticMemo[$memoKey] = $resolved;

        return $resolved;
    }


    /**
     * Clear per-request memo caches
     */
    public function clearMemo(): void
    {
        $this->memo = [];
        self::$staticMemo = [];
        self::$rowsCache = [];
        self::$attendanceProfileMemo = [];
        RuleDefinitionModel::clearParamsCache();
    }

    /**
     * Flush all static and instance memos, rows cache, and attendance profile cache.
     * Clears cached query results across all domains without resetting activeInstance by default.
     */
    public static function flush(bool $resetActive = false): void
    {
        self::$staticMemo = [];
        self::$rowsCache = [];
        self::$attendanceProfileMemo = [];
        RuleDefinitionModel::clearParamsCache();
        if (self::$activeInstance !== null) {
            self::$activeInstance->memo = [];
        }
        if ($resetActive) {
            self::$activeInstance = null;
            self::$staticModel = null;
        }
    }

    /**
     * Clear all cached rule resolutions (alias for flush)
     */
    public static function clearCache(): void
    {
        self::flush();
    }

    /**
     * Static reset for memo cache and active testing state
     */
    public static function resetMemo(): void
    {
        self::$staticMemo = [];
        self::$rowsCache = [];
        self::$attendanceProfileMemo = [];
        self::$activeInstance = null;
        self::$staticModel = null;
        RuleDefinitionModel::clearParamsCache();
    }

    /**
     * Static rule resolution helper
     */
    public static function resolveStatic(string $companyId, string $domain, mixed $arg3 = null, mixed $arg4 = null): ResolvedRule
    {
        return self::resolve($companyId, $domain, $arg3, $arg4);
    }

    /**
     * Resolve rule at Company scope
     */
    public static function resolveForCompany(string $companyId, string $domain, ?string $date = null): ResolvedRule
    {
        return self::resolve($companyId, $domain, $date ?: self::today(), null);
    }

    /**
     * Explain rule parameter origins
     *
     * @return array<string, array{value: mixed, origin: array{scope_level: string, scope_id: ?string, version_number: int, rule_id: string}}>
     */
    public static function explain(string $companyId, string $domain, mixed $arg3 = null, mixed $arg4 = null): array
    {
        $resolved = self::resolve($companyId, $domain, $arg3, $arg4);
        return $resolved->explain();
    }

    /**
     * Reconstruct a ResolvedRule from a stored snapshot for a given company and domain.
     *
     * @param string $companyId
     * @param string $domain
     * @param array<string, mixed> $domainSnapshot
     * @param string|null $date
     * @return ResolvedRule
     */
    public static function resolveSnapshot(string $companyId, string $domain, array $domainSnapshot, ?string $date = null): ResolvedRule
    {
        $instance = self::$activeInstance ?? new self(self::$staticModel);
        return $instance->resolveFromSnapshot($companyId, $domain, $domainSnapshot, $date);
    }

    /**
     * Instance method to reconstruct a ResolvedRule from a stored domain snapshot without re-evaluating live rules.
     *
     * @param string $companyId
     * @param string $domain
     * @param array<string, mixed> $domainSnapshot
     * @param string|null $date
     * @return ResolvedRule
     */
    public function resolveFromSnapshot(string $companyId, string $domain, array $domainSnapshot, ?string $date = null): ResolvedRule
    {
        $companyId = trim($companyId);
        $domain    = strtoupper(trim($domain));
        $date      = !empty($date) ? substr(trim($date), 0, 10) : self::today();

        $snapshotLayers = isset($domainSnapshot['layers']) && is_array($domainSnapshot['layers'])
            ? $domainSnapshot['layers']
            : [];

        $allRows = $this->fetchAllDomainRows($companyId, $domain);
        $rowsById = [];
        foreach ($allRows as $row) {
            if (!empty($row['id'])) {
                $rowsById[(string)$row['id']] = $row;
            }
        }

        $mergedParams   = [];
        $origins        = [];
        $layerSnapshots = [];

        foreach ($snapshotLayers as $snapLayer) {
            if (!is_array($snapLayer)) {
                continue;
            }
            $ruleId     = isset($snapLayer['rule_id']) ? (string)$snapLayer['rule_id'] : (isset($snapLayer['id']) ? (string)$snapLayer['id'] : '');
            $scopeLevel = isset($snapLayer['scope_level']) ? (string)$snapLayer['scope_level'] : 'Company';
            $scopeId    = isset($snapLayer['scope_id']) && $snapLayer['scope_id'] !== '' ? (string)$snapLayer['scope_id'] : null;
            $versionNum = isset($snapLayer['version_number']) ? (int)$snapLayer['version_number'] : 1;

            $matchedRow = null;
            if ($ruleId !== '' && isset($rowsById[$ruleId])) {
                $matchedRow = $rowsById[$ruleId];
            } else {
                foreach ($allRows as $candidate) {
                    $cLevel = isset($candidate['scope_level']) ? (string)$candidate['scope_level'] : '';
                    $cScope = isset($candidate['scope_id']) && $candidate['scope_id'] !== '' ? (string)$candidate['scope_id'] : null;
                    $cVer   = isset($candidate['version_number']) ? (int)$candidate['version_number'] : 0;
                    if ($cLevel === $scopeLevel && $cScope === $scopeId && $cVer === $versionNum) {
                        $matchedRow = $candidate;
                        break;
                    }
                }
            }

            if ($matchedRow !== null) {
                $ruleId     = (string)($matchedRow['id'] ?? $ruleId);
                $scopeLevel = (string)($matchedRow['scope_level'] ?? $scopeLevel);
                $scopeId    = isset($matchedRow['scope_id']) && $matchedRow['scope_id'] !== '' ? (string)$matchedRow['scope_id'] : null;
                $versionNum = (int)($matchedRow['version_number'] ?? $versionNum);
                $params     = $this->extractRowParams($matchedRow);
            } elseif (isset($snapLayer['params']) && is_array($snapLayer['params'])) {
                $params = $snapLayer['params'];
            } else {
                $params = [];
            }

            $layerSnapshots[] = [
                'scope_level'    => $scopeLevel,
                'scope_id'       => $scopeId,
                'version_number' => $versionNum,
                'rule_id'        => $ruleId,
            ];

            foreach ($params as $key => $val) {
                $mergedParams[$key] = $val;
                $origins[$key] = [
                    'scope_level'    => $scopeLevel,
                    'scope_id'       => $scopeId,
                    'version_number' => $versionNum,
                    'rule_id'        => $ruleId,
                ];
            }
        }

        if (empty($mergedParams) && isset($domainSnapshot['params']) && is_array($domainSnapshot['params'])) {
            $fallbackOrigin = !empty($layerSnapshots)
                ? end($layerSnapshots)
                : ['scope_level' => 'Company', 'scope_id' => null, 'version_number' => 1, 'rule_id' => ''];
            foreach ($domainSnapshot['params'] as $key => $val) {
                $mergedParams[$key] = $val;
                $origins[$key] = $fallbackOrigin;
            }
        }

        return new ResolvedRule(
            $companyId,
            $domain,
            $date,
            $mergedParams,
            $layerSnapshots,
            $origins
        );
    }

    /**
     * Build attendance profile legacy structure from rule store (ATTENDANCE + OVERTIME + BONUS + LEAVE).
     * Computes derived values (requiredWorkingDays, requiredWeeklyHours) on the fly without storing them.
     *
     * @param mixed $employee Employee row array, employee ID string, or company ID
     * @param string|null $date Calculation date (YYYY-MM-DD)
     * @return array<string, mixed> Legacy-compatible attendance rule profile shape
     * @throws RuleNotConfiguredException
     */
    public static function attendanceProfile(mixed $employee = null, ?string $date = null): array
    {
        if (is_object($employee)) {
            $employee = json_decode(json_encode($employee), true) ?: (array)$employee;
        }
        $date = !empty($date) ? substr(trim((string)$date), 0, 10) : self::today();
        $companyId = null;
        $empContext = null;

        if (is_array($employee)) {
            $empContext = $employee;
            $companyId = $employee['company_id'] ?? ($employee['companyId'] ?? null);

            if (empty($companyId) && (!empty($employee['id']) || !empty($employee['employee_id']))) {
                $eId = $employee['id'] ?? $employee['employee_id'];
                if (class_exists(\App\Models\EmployeeModel::class)) {
                    try {
                        $empRow = (new \App\Models\EmployeeModel())->find($eId);
                        if ($empRow && !empty($empRow['company_id'])) {
                            $companyId = $empRow['company_id'];
                            $empContext = array_merge($empRow, $employee);
                        }
                    } catch (\Throwable $e) {}
                }
            }
        } elseif (is_string($employee) && trim($employee) !== '') {
            $str = trim($employee);
            // Check if string is a company ID
            $isComp = false;
            try {
                $db = \Config\Database::connect();
                if ($db->tableExists('companies')) {
                    $foundComp = $db->table('companies')->where('id', $str)->get(1)->getRowArray();
                    if ($foundComp) {
                        $companyId = $str;
                        $empContext = ['company_id' => $companyId];
                        $isComp = true;
                    }
                }
            } catch (\Throwable $e) {}

            if (!$isComp) {
                // Try looking up employee
                if (class_exists(\App\Models\EmployeeModel::class)) {
                    try {
                        $empRow = (new \App\Models\EmployeeModel())->find($str);
                        if ($empRow) {
                            $companyId = $empRow['company_id'] ?? null;
                            $empContext = $empRow;
                        }
                    } catch (\Throwable $e) {}
                }
                if (empty($companyId)) {
                    $companyId = $str;
                    $empContext = ['company_id' => $companyId];
                }
            }
        }

        if (empty($companyId) && function_exists('session')) {
            try {
                $companyId = session('company_id');
            } catch (\Throwable $e) {}
        }

        if (empty($companyId)) {
            throw RuleNotConfiguredException::forDomain(
                'unknown',
                'ATTENDANCE',
                $date,
                "Company ID context is required to resolve attendance profile"
            );
        }

        $empIdKey = '';
        if (is_array($empContext)) {
            $empIdKey = (string)($empContext['id'] ?? $empContext['employee_id'] ?? null);
        } elseif (is_scalar($employee) && $employee !== null) {
            $empIdKey = (string)$employee;
        }
        $shiftKey  = is_array($empContext) ? (string)($empContext['shift_id'] ?? null) : '';
        $deptKey   = is_array($empContext) ? (string)($empContext['department_id'] ?? null) : '';
        $branchKey = is_array($empContext) ? (string)($empContext['branch_id'] ?? null) : '';
        $desigKey  = is_array($empContext) ? (string)($empContext['designation_id'] ?? null) : '';

        // Check if active Employee-scope rules exist across consumed domains: ATTENDANCE, OVERTIME, BONUS, LEAVE
        // Share profile across employees only when none do.
        $memoEmpId = $empIdKey;
        $hasEmpRule = false;
        $resolverInst = self::$activeInstance ?? new self(self::$staticModel);
        $model = $resolverInst->getModel();
        $modelId = ($model instanceof RuleDefinitionModel) ? 'db' : spl_object_id($model);

        try {
            $domainsToCheck = ['ATTENDANCE', 'OVERTIME', 'BONUS', 'LEAVE'];
            foreach ($domainsToCheck as $dom) {
                $domRows = $resolverInst->fetchRows($companyId, $dom);
                foreach ($domRows as $dr) {
                    $scopeLevel = $dr['scope_level'] ?? null;
                    $rowStatus  = $dr['status'] ?? null;
                    if ($scopeLevel === 'Employee' && $rowStatus === 'Active') {
                        $hasEmpRule = true;
                        break 2;
                    }
                }
            }
        } catch (\Throwable $e) {}

        if (!$hasEmpRule) {
            $memoEmpId = '';
        }

        $empFlag = $hasEmpRule ? '1' : '0';
        $profileMemoKey = "m:{$modelId}|{$companyId}|{$date}|{$memoEmpId}|{$shiftKey}|{$deptKey}|{$branchKey}|{$desigKey}|emp:{$empFlag}";

        if (isset(self::$attendanceProfileMemo[$profileMemoKey])) {
            return self::$attendanceProfileMemo[$profileMemoKey];
        }

        // 1. Authoritative ATTENDANCE rule from RuleResolver
        $attRule = self::resolveStatic($companyId, 'ATTENDANCE', $date, $empContext);
        $attParams = $attRule->params();

        // 2. Authoritative OVERTIME rule (propagates RuleNotConfiguredException)
        $otRule = self::resolveStatic($companyId, 'OVERTIME', $date, $empContext);
        $otParams = $otRule->params();

        // 3. Authoritative BONUS rule (propagates RuleNotConfiguredException)
        $bonusRule = self::resolveStatic($companyId, 'BONUS', $date, $empContext);
        $bonusParams = $bonusRule->params();

        // 4. Authoritative LEAVE rule (propagates RuleNotConfiguredException)
        $leaveRule = self::resolveStatic($companyId, 'LEAVE', $date, $empContext);

        // Derived working week calculations: rule_definitions ATTENDANCE is single source of truth for weekly off days
        $rawWeeklyOff = $attParams['weekly_off_days'] ?? null;
        if ($rawWeeklyOff === null) {
            try {
                $rawWeeklyOff = $attRule->get('weekly_off_days');
            } catch (\Throwable $e) {}
        }

        if (empty($rawWeeklyOff) && class_exists(\App\Services\CompanyWeekendService::class)) {
            $empId = is_array($empContext) ? ($empContext['id'] ?? ($empContext['employee_id'] ?? null)) : (is_string($empContext) ? $empContext : null);
            $weeklyOffDays = \App\Services\CompanyWeekendService::getCompanyWeeklyOff($companyId, $empId, false, $date);
        } else {
            if (is_string($rawWeeklyOff)) {
                $rawWeeklyOff = array_values(array_filter(array_map('trim', explode(',', $rawWeeklyOff))));
            }
            $weeklyOffDays = array_values(array_filter(array_map(function($d) {
                $d = trim((string)$d);
                return !empty($d) ? ucfirst(strtolower($d)) : null;
            }, (array)($rawWeeklyOff ?: []))));
        }

        // weekEndDay is strictly the day before weekStartDay (Sunday gives Saturday, Saturday gives Friday)
        $weekStartDay = (string)$attRule->get('week_start_day');
        $daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        $startNormalized = ucfirst(strtolower(trim($weekStartDay)));
        $startIdx = array_search($startNormalized, $daysOfWeek, true);
        $weekEndDay = ($startIdx !== false ? $daysOfWeek[($startIdx + 6) % 7] : 'Saturday');

        $requiredWorkingDays = max(1, 7 - count($weeklyOffDays));
        $standardDailyHours = (float)$attRule->get('daily_required_hours');
        $requiredWeeklyHours = (float)($requiredWorkingDays * $standardDailyHours);

        $workingWeek = [
            'weekStartDay'        => $weekStartDay,
            'weekEndDay'          => $weekEndDay,
            'weeklyOffDays'       => $weeklyOffDays,
            'requiredWorkingDays' => $requiredWorkingDays,
            'requiredWeeklyHours' => $requiredWeeklyHours,
            'standardDailyHours'  => $standardDailyHours,
        ];

        // Daily Hours
        $dailyHours = [
            'dailyRequiredHours'     => $standardDailyHours,
            'halfDayThresholdHours'  => (float)$attRule->get('half_day_threshold_hours'),
            'minWorkHoursForPresent' => (float)$attRule->get('min_work_hours_for_present'),
            'officeStartTime'        => (string)$attRule->get('office_start_time'),
            'officeEndTime'          => (string)$attRule->get('office_end_time'),
            'halfDayTime'            => (string)$attRule->get('half_day_time'),
        ];

        // Break Rule
        $breakRule = [
            'enabled'              => !empty($attParams['break_enabled']),
            'breakDurationMinutes' => (int)$attRule->get('break_duration_minutes'),
            'isPaid'               => !empty($attParams['break_is_paid']),
            'unpaidBreakTreatment' => (string)$attRule->get('unpaid_break_treatment'),
            'autoDeductBreak'      => !empty($attParams['break_auto_deduct']),
        ];

        // Late Rule
        $lateRule = [
            'enabled'                         => !empty($attParams['late_enabled']),
            'gracePeriodMinutes'              => (int)$attRule->get('late_grace_minutes'),
            'penaltyMethod'                   => (string)$attRule->get('late_penalty_method'),
            'penaltyDeductionAmountPerMinute' => (float)$attRule->get('late_penalty_per_minute'),
            'consecutiveLateDaysThreshold'    => (int)$attRule->get('late_consecutive_days_threshold'),
            'consecutiveLatePenaltyLeaveDays' => (float)$attRule->get('late_consecutive_penalty_leave_days'),
        ];

        // Early Out Rule
        $earlyOutRule = [
            'enabled'                         => !empty($attParams['early_out_enabled']),
            'earlyOutThresholdMinutes'        => (int)$attRule->get('early_out_threshold_minutes'),
            'penaltyMethod'                   => (string)$attRule->get('early_out_penalty_method'),
            'penaltyDeductionAmountPerMinute' => (float)$attRule->get('early_out_penalty_per_minute'),
        ];

        // Missing Day Rule
        $missingDayRule = [
            'policy'                     => (string)$attRule->get('missing_day_policy'),
            'allowWeeklyBonusIfHoursMet' => !empty($attParams['missing_day_allow_weekly_bonus_if_hours_met']),
        ];

        // Weekly Bonus Rule (from BONUS domain)
        $bonusTiers = [];
        if (!empty($bonusParams['weekly_bonus_tiers']) && is_array($bonusParams['weekly_bonus_tiers'])) {
            foreach ($bonusParams['weekly_bonus_tiers'] as $t) {
                $bMinHours = isset($t['min_hours']) ? (float)$t['min_hours'] : (isset($t['minHours']) ? (float)$t['minHours'] : 0.0);
                $bMaxHours = isset($t['max_hours']) ? (float)$t['max_hours'] : (isset($t['maxHours']) ? (float)$t['maxHours'] : 0.0);
                $bAmount   = isset($t['bonus_amount']) ? (float)$t['bonus_amount'] : (isset($t['bonusAmount']) ? (float)$t['bonusAmount'] : 0.0);
                $tierName  = isset($t['tier_name']) ? (string)$t['tier_name'] : (isset($t['tierName']) ? (string)$t['tierName'] : 'Tier');
                $bonusTiers[] = [
                    'tierName'    => $tierName,
                    'minHours'    => $bMinHours,
                    'maxHours'    => $bMaxHours,
                    'bonusAmount' => $bAmount,
                ];
            }
        }
        $weeklyBonusRule = [
            'enabled'                => !empty($bonusParams['weekly_bonus_enabled']),
            'bonusMethod'            => (string)$bonusRule->get('weekly_bonus_method'),
            'fixedAmount'            => (float)$bonusRule->get('weekly_bonus_fixed_amount'),
            'percentageOfBasic'      => (float)$bonusRule->get('weekly_bonus_percentage_of_basic'),
            'ratePerHour'            => ($bonusRule->has('weekly_bonus_rate_per_hour') && $bonusRule->get('weekly_bonus_rate_per_hour') !== null) ? (float)$bonusRule->get('weekly_bonus_rate_per_hour') : null,
            'minPresentDays'         => (int)$bonusRule->get('weekly_bonus_min_present_days'),
            'minWeeklyHours'         => (float)$bonusRule->get('weekly_bonus_min_weekly_hours'),
            'fullAttendanceRequired' => !empty($bonusParams['weekly_bonus_full_attendance_required']),
            'lateAllowed'            => !empty($bonusParams['weekly_bonus_late_allowed']),
            'maxAllowedLates'        => (int)$bonusRule->get('weekly_bonus_max_allowed_lates'),
            'leaveAllowed'           => !empty($bonusParams['weekly_bonus_leave_allowed']),
            'tiers'                  => $bonusTiers,
        ];

        // Holiday Treatment
        $holidayTreatment = [
            'countsAsWorkingHours'          => !empty($attParams['holiday_counts_as_working_hours']),
            'creditedWorkingHours'          => (float)$attRule->get('holiday_credited_hours'),
            'countsTowardWeeklyRequirement' => !empty($attParams['holiday_counts_toward_weekly_requirement']),
        ];

        // Leave Treatments: from ATTENDANCE rule, or resolved from LEAVE rule entitlements, or throw
        $leaveTreatments = [];
        $rawTreatments = !empty($attParams['leave_treatments']) && is_array($attParams['leave_treatments']) ? $attParams['leave_treatments'] : [];
        if (!empty($rawTreatments)) {
            foreach ($rawTreatments as $lt) {
                $rawCode = isset($lt['leave_type_code']) ? $lt['leave_type_code'] : (isset($lt['leaveTypeCode']) ? $lt['leaveTypeCode'] : '');
                $code = strtoupper(trim((string)$rawCode));
                if ($code === '') {
                    continue;
                }
                $name = isset($lt['leave_type_name']) ? (string)$lt['leave_type_name'] : (isset($lt['leaveTypeName']) ? (string)$lt['leaveTypeName'] : (ucwords(strtolower($code)) . ' Leave'));
                $leaveTreatments[] = [
                    'leaveTypeId'                => strtolower($code),
                    'leaveTypeCode'              => $code,
                    'leaveTypeName'              => $name,
                    'countsAsWorkingDay'         => !empty($lt['counts_as_working_day']) || !empty($lt['countsAsWorkingDay']),
                    'countsAsWorkingHours'       => !empty($lt['counts_as_working_hours']) || !empty($lt['countsAsWorkingHours']),
                    'creditedWorkingHoursPerDay' => isset($lt['credited_hours_per_day']) ? (float)$lt['credited_hours_per_day'] : (isset($lt['creditedWorkingHoursPerDay']) ? (float)$lt['creditedWorkingHoursPerDay'] : $standardDailyHours),
                    'affectsWeeklyBonus'         => !empty($lt['affects_weekly_bonus']) || !empty($lt['affectsWeeklyBonus']),
                    'affectsAttendance'          => !empty($lt['affects_attendance']) || !empty($lt['affectsAttendance']),
                ];
            }
        } else {
            // Resolve from LEAVE rule entitlements or throw RuleNotConfiguredException
            $entitlements = $leaveRule->params()['entitlements'] ?? ($leaveRule->has('entitlements') ? $leaveRule->get('entitlements') : null);
            if (!empty($entitlements) && is_array($entitlements)) {
                foreach ($entitlements as $ent) {
                    $rawCode = isset($ent['leave_type_code']) ? $ent['leave_type_code'] : (isset($ent['leaveTypeCode']) ? $ent['leaveTypeCode'] : '');
                    $code = strtoupper(trim((string)$rawCode));
                    if ($code === '') {
                        continue;
                    }
                    $name = isset($ent['leave_type_name']) ? (string)$ent['leave_type_name'] : (isset($ent['leaveTypeName']) ? (string)$ent['leaveTypeName'] : (ucwords(strtolower($code)) . ' Leave'));
                    $isPaid = !empty($ent['is_paid']);
                    $countsWorkDay = isset($ent['counts_as_working_day']) ? !empty($ent['counts_as_working_day']) : $isPaid;
                    $leaveTreatments[] = [
                        'leaveTypeId'                => strtolower($code),
                        'leaveTypeCode'              => $code,
                        'leaveTypeName'              => $name,
                        'countsAsWorkingDay'         => $countsWorkDay,
                        'countsAsWorkingHours'       => $isPaid,
                        'creditedWorkingHoursPerDay' => $isPaid ? $standardDailyHours : 0.0,
                        'affectsWeeklyBonus'         => $isPaid,
                        'affectsAttendance'          => true,
                    ];
                }
            }

            if (empty($leaveTreatments)) {
                throw RuleNotConfiguredException::forDomain(
                    $companyId,
                    'ATTENDANCE',
                    $date,
                    "Missing leave_treatments in ATTENDANCE rule and no entitlements found in LEAVE rule"
                );
            }
        }

        // Overtime Rule (from OVERTIME domain)
        $overtimeRule = [
            'enableDailyOt'                   => !empty($otParams['enable_daily_ot']),
            'enableWeeklyOt'                  => !empty($otParams['enable_weekly_ot']),
            'enableEarlyArrivalOt'            => !empty($otParams['enable_early_arrival_ot']),
            'enablePostShiftOt'               => isset($otParams['enable_post_shift_ot']) ? !empty($otParams['enable_post_shift_ot']) : true,
            'earlyArrivalGraceMinutes'        => (int)$otRule->get('early_arrival_grace_minutes'),
            'earlyArrivalMinThresholdMinutes' => (int)$otRule->get('early_arrival_min_threshold_minutes'),
            'postShiftGraceMinutes'           => (int)$otRule->get('post_shift_grace_minutes'),
            'postShiftMinThresholdMinutes'    => (int)$otRule->get('post_shift_min_threshold_minutes'),
            'normalDayMultiplier'             => (float)$otRule->get('normal_multiplier'),
            'offDayMultiplier'                => (float)$otRule->get('weekly_off_multiplier'),
            'holidayMultiplier'               => (float)$otRule->get('holiday_multiplier'),
            'specialMultiplier'               => (float)$otRule->get('special_multiplier'),
            'nightMultiplier'                 => (float)$otRule->get('night_multiplier'),
            'minOtUnitMinutes'                => (int)$otRule->get('min_ot_unit_minutes'),
            'minOtMinutesToQualify'           => (int)$otRule->get('min_ot_minutes_to_qualify'),
            'dailyThresholdHours'             => (float)$otRule->get('daily_threshold_hours'),
            'roundingMethod'                  => (string)$otRule->get('rounding_mode'),
            'calculationMethod'               => (string)$otRule->get('calculation_method'),
            'conflictPolicy'                  => (string)$otRule->get('conflict_policy'),
            'salaryBasis'                     => (string)$otRule->get('salary_basis'),
            'divisorMode'                     => (string)$otRule->get('divisor_mode'),
            'divisorDays'                     => (float)DailyRateResolver::resolve($companyId, $empContext, $date, null, 0.0, (string)$otRule->get('divisor_mode'))['divisor_days'],
            'divisorHours'                    => (float)$otRule->get('divisor_hours'),
            'preApprovalRequired'             => !empty($otParams['requires_pre_approval']),
            'postApprovalRequired'            => !empty($otParams['requires_post_approval']),
            'dailyMaxHoursCap'                => (float)$otRule->get('max_daily_ot_hours'),
            'monthlyMaxHoursCap'              => (float)$otRule->get('max_monthly_ot_hours'),
        ];

        $attLayers = $attRule->layers();
        $topLayer = !empty($attLayers) ? $attLayers[count($attLayers) - 1] : [];
        $versionNumber = isset($topLayer['version_number']) ? (int)$topLayer['version_number'] : 1;
        $scopeLevel = !empty($topLayer['scope_level']) ? (string)$topLayer['scope_level'] : 'Company';
        $scopeId = $topLayer['scope_id'] ?? null;

        $profile = [
            'id'                  => !empty($topLayer['id']) ? (string)$topLayer['id'] : ('rd-profile-' . $companyId),
            'company_id'          => $companyId,
            'name'                => 'Authoritative Attendance Rule Profile',
            'description'         => 'Single Source of Truth Attendance, Overtime & Bonus Profile',
            'version'             => $versionNumber,
            'status'              => 'Active',
            'scopeLevel'          => $scopeLevel,
            'scopeId'             => $scopeId,
            'effectiveFrom'       => $date,
            'effectiveTo'         => null,

            'workingWeek'         => $workingWeek,
            'dailyHours'          => $dailyHours,
            'breakRule'           => $breakRule,
            'lateRule'            => $lateRule,
            'earlyOutRule'        => $earlyOutRule,
            'missingDayRule'      => $missingDayRule,
            'weeklyBonusRule'     => $weeklyBonusRule,
            'holidayTreatment'    => $holidayTreatment,
            'leaveTreatments'     => $leaveTreatments,
            'overtimeRule'        => $overtimeRule,

            // Audit rule snapshot across all domains consumed
            'rulesSnapshot'       => [
                'ATTENDANCE' => $attRule->snapshot(),
                'OVERTIME'   => $otRule->snapshot(),
                'BONUS'      => $bonusRule->snapshot(),
                'LEAVE'      => $leaveRule->snapshot(),
            ],
        ];

        if (count(self::$attendanceProfileMemo) > 500) {
            self::$attendanceProfileMemo = array_slice(self::$attendanceProfileMemo, -250, null, true);
        }

        self::$attendanceProfileMemo[$profileMemoKey] = $profile;
        return $profile;
    }

    /**
     * Filter rows by scope level, scope ID (or empty for Company), status Active,
     * and date window [effective_from, effective_to], sorted by version_number DESC.
     *
     * @param array<int, array<string, mixed>> $rows
     * @param string $level
     * @param string|null $scopeId
     * @param string $date
     * @return array<int, array<string, mixed>>
     */
    protected function activeRowsFor(array $rows, string $level, ?string $scopeId, string $date): array
    {
        $filtered = [];
        foreach ($rows as $r) {
            $rLvl  = isset($r['scope_level']) ? (string)$r['scope_level'] : null;
            $rStat = isset($r['status']) ? (string)$r['status'] : 'Active';

            if ($rLvl !== $level || $rStat !== 'Active') {
                continue;
            }

            if ($scopeId === null || $scopeId === '') {
                if (!empty($r['scope_id'])) {
                    continue;
                }
            } else {
                if (!isset($r['scope_id']) || (string)$r['scope_id'] !== (string)$scopeId) {
                    continue;
                }
            }

            $effFrom = isset($r['effective_from']) ? substr((string)$r['effective_from'], 0, 10) : null;
            $effTo   = isset($r['effective_to']) && $r['effective_to'] !== null && $r['effective_to'] !== ''
                ? substr((string)$r['effective_to'], 0, 10)
                : null;

            if ($effFrom === null || $effFrom > $date) {
                continue;
            }
            if ($effTo !== null && $effTo < $date) {
                continue;
            }

            $filtered[] = $r;
        }

        if (!empty($filtered)) {
            usort($filtered, function ($a, $b) {
                $vA = isset($a['version_number']) ? (int)$a['version_number'] : 1;
                $vB = isset($b['version_number']) ? (int)$b['version_number'] : 1;
                return $vB <=> $vA;
            });
        }

        return $filtered;
    }

    /**
     * Instance method to explain rule parameter origins
     *
     * @return array<string, array{value: mixed, origin: array{scope_level: string, scope_id: ?string, version_number: int, rule_id: string}}>
     */
    public function explainInstance(string $companyId, string $domain, mixed $arg3 = null, mixed $arg4 = null): array
    {
        $resolved = $this->resolveInstance($companyId, $domain, $arg3, $arg4);
        return $resolved->explain();
    }

    /**
     * Extract scope IDs from various possible input formats
     *
     * @param mixed $employeeOrScopes
     * @return array<string, string>
     */
    protected function extractScopeIds(mixed $employeeOrScopes, ?string $companyId = null): array
    {
        if ($employeeOrScopes === null || $employeeOrScopes === '') {
            return [];
        }

        if (is_object($employeeOrScopes)) {
            $employeeOrScopes = json_decode(json_encode($employeeOrScopes), true) ?: (array)$employeeOrScopes;
        }

        if (is_string($employeeOrScopes)) {
            if (class_exists(\App\Models\EmployeeModel::class)) {
                try {
                    $empModel = new \App\Models\EmployeeModel();
                    $builder = $empModel;
                    if (!empty($companyId) && $empModel->db && $empModel->db->fieldExists('company_id', 'employees')) {
                        $builder = $builder->where('company_id', $companyId);
                    }
                    $emp = $builder->find($employeeOrScopes);
                    if (!$emp && !empty($companyId) && $empModel->db && $empModel->db->fieldExists('employee_code', 'employees') && $empModel->db->fieldExists('company_id', 'employees')) {
                        $emp = $empModel->where('company_id', $companyId)->where('employee_code', $employeeOrScopes)->first();
                    }
                    if ($emp) {
                        $employeeOrScopes = $emp;
                    } else {
                        if (!empty($companyId) && $empModel->db && $empModel->db->fieldExists('company_id', 'employees')) {
                            $otherEmp = (new \App\Models\EmployeeModel())->find($employeeOrScopes);
                            if ($otherEmp && !empty($otherEmp['company_id']) && (string)$otherEmp['company_id'] !== (string)$companyId) {
                                throw new InvalidArgumentException("Cross-tenant isolation violation: Employee belongs to company '{$otherEmp['company_id']}' but rules requested for company '{$companyId}'");
                            }
                        }
                        return ['Employee' => $employeeOrScopes];
                    }
                } catch (InvalidArgumentException $e) {
                    throw $e;
                } catch (\Throwable $e) {
                    return ['Employee' => $employeeOrScopes];
                }
            } else {
                return ['Employee' => $employeeOrScopes];
            }
        }

        // Cross-tenant boundary check: If employee belongs to another company, do not resolve cross-tenant scopes
        if (!empty($companyId) && is_array($employeeOrScopes) && !empty($employeeOrScopes['company_id']) && (string)$employeeOrScopes['company_id'] !== (string)$companyId) {
            throw new InvalidArgumentException("Cross-tenant isolation violation: Employee belongs to company '{$employeeOrScopes['company_id']}' but rules requested for company '{$companyId}'");
        }

        $scopes = [];

        // Check direct scope level names
        foreach (['Employee', 'Shift', 'Designation', 'Department', 'Branch'] as $lvl) {
            if (isset($employeeOrScopes[$lvl]) && $employeeOrScopes[$lvl] !== null && $employeeOrScopes[$lvl] !== '') {
                $scopes[$lvl] = (string)$employeeOrScopes[$lvl];
            }
        }

        // Check standard employee array database fields
        if (!isset($scopes['Employee'])) {
            $empId = isset($employeeOrScopes['id']) ? $employeeOrScopes['id'] : null;
            if ($empId === null && isset($employeeOrScopes['employee_id'])) {
                $empId = $employeeOrScopes['employee_id'];
            }
            if ($empId === null && isset($employeeOrScopes['employeeId'])) {
                $empId = $employeeOrScopes['employeeId'];
            }
            if ($empId !== null && $empId !== '') {
                $scopes['Employee'] = (string)$empId;
            }
        }

        if (!isset($scopes['Branch'])) {
            $branchId = isset($employeeOrScopes['branch_id']) ? $employeeOrScopes['branch_id'] : null;
            if ($branchId === null && isset($employeeOrScopes['branchId'])) {
                $branchId = $employeeOrScopes['branchId'];
            }
            if ($branchId !== null && $branchId !== '') {
                $scopes['Branch'] = (string)$branchId;
            }
        }

        if (!isset($scopes['Department'])) {
            $deptId = isset($employeeOrScopes['department_id']) ? $employeeOrScopes['department_id'] : null;
            if ($deptId === null && isset($employeeOrScopes['departmentId'])) {
                $deptId = $employeeOrScopes['departmentId'];
            }
            if ($deptId !== null && $deptId !== '') {
                $scopes['Department'] = (string)$deptId;
            }
        }

        if (!isset($scopes['Designation'])) {
            $desigId = isset($employeeOrScopes['designation_id']) ? $employeeOrScopes['designation_id'] : null;
            if ($desigId === null && isset($employeeOrScopes['designationId'])) {
                $desigId = $employeeOrScopes['designationId'];
            }
            if ($desigId !== null && $desigId !== '') {
                $scopes['Designation'] = (string)$desigId;
            }
        }

        if (!isset($scopes['Shift'])) {
            $shiftId = isset($employeeOrScopes['shift_id']) ? $employeeOrScopes['shift_id'] : null;
            if ($shiftId === null && isset($employeeOrScopes['shiftId'])) {
                $shiftId = $employeeOrScopes['shiftId'];
            }
            if ($shiftId !== null && $shiftId !== '') {
                $scopes['Shift'] = (string)$shiftId;
            }
        }

        return $scopes;
    }

    /**
     * Build memo cache key
     *
     * @param string $companyId
     * @param string $domain
     * @param string $date
     * @param array<string, string> $scopes
     * @return string
     */
    protected function buildMemoKey(string $companyId, string $domain, string $date, array $scopes): string
    {
        $model = $this->getModel();
        $modelId = ($model instanceof RuleDefinitionModel) ? 'db' : spl_object_id($model);

        ksort($scopes);
        $scopeParts = [];
        foreach ($scopes as $k => $v) {
            $scopeParts[] = "{$k}={$v}";
        }
        $scopeStr = implode(';', $scopeParts);

        return "m:{$modelId}|{$companyId}|{$domain}|{$date}|{$scopeStr}";
    }

    /**
     * Fetch active rows strictly for company and domain from model
     *
     * @param string $companyId
     * @param string $domain
     * @return array<int, array<string, mixed>>
     */
    protected function fetchRows(string $companyId, string $domain): array
    {
        $model = $this->getModel();
        // Real DB-backed model: key by company+domain so every `new RuleResolver()` shares one cache.
        // Custom/stub models (tests) keep per-object keys to avoid cross-contamination.
        $cacheKey = ($model instanceof \App\Models\RuleDefinitionModel)
            ? "db:{$companyId}:{$domain}"
            : "m:" . spl_object_id($model) . ":{$companyId}:{$domain}";
        if (isset(self::$rowsCache[$cacheKey])) {
            return self::$rowsCache[$cacheKey];
        }

        $result = [];

        if (method_exists($model, 'getActiveRules')) {
            $result = $model->getActiveRules($companyId, $domain);
        } elseif (method_exists($model, 'getRulesForDomain')) {
            $result = $model->getRulesForDomain($companyId, $domain);
        } elseif (method_exists($model, 'getRules')) {
            $result = $model->getRules($companyId, $domain);
        } elseif (method_exists($model, 'where')) {
            $result = $model->where('company_id', $companyId)
                         ->where('domain', $domain)
                         ->where('status', 'Active')
                         ->orderBy('version_number', 'DESC')
                         ->findAll();
        } elseif (property_exists($model, 'rows') && is_array($model->rows)) {
            $matched = [];
            foreach ($model->rows as $r) {
                $rComp = isset($r['company_id']) ? (string)$r['company_id'] : null;
                $rDom  = isset($r['domain']) ? strtoupper((string)$r['domain']) : null;
                $rStat = isset($r['status']) ? (string)$r['status'] : 'Active';

                if ($rComp === $companyId && $rDom === $domain && $rStat === 'Active') {
                    $matched[] = $r;
                }
            }
            $result = $matched;
        }

        if (count(self::$rowsCache) > 200) {
            self::$rowsCache = array_slice(self::$rowsCache, -100, null, true);
        }

        self::$rowsCache[$cacheKey] = $result;
        return $result;
    }

    /**
     * Fetch all rule rows (Active and Archived) for a company and domain to reconstruct historical snapshots.
     *
     * @param string $companyId
     * @param string $domain
     * @return array<int, array<string, mixed>>
     */
    protected function fetchAllDomainRows(string $companyId, string $domain): array
    {
        $model = $this->getModel();

        if (method_exists($model, 'where')) {
            if (method_exists($model, 'builder')) {
                return $model->builder()
                             ->where('company_id', $companyId)
                             ->where('domain', $domain)
                             ->orderBy('version_number', 'DESC')
                             ->get()
                             ->getResultArray();
            }
            return $model->where('company_id', $companyId)
                         ->where('domain', $domain)
                         ->orderBy('version_number', 'DESC')
                         ->findAll();
        }

        if (property_exists($model, 'rows') && is_array($model->rows)) {
            $matched = [];
            foreach ($model->rows as $r) {
                $rComp = isset($r['company_id']) ? (string)$r['company_id'] : null;
                $rDom  = isset($r['domain']) ? strtoupper((string)$r['domain']) : null;
                if ($rComp === $companyId && $rDom === $domain) {
                    $matched[] = $r;
                }
            }
            return $matched;
        }

        return $this->fetchRows($companyId, $domain);
    }

    /**
     * Extract params array from a rule definition row
     *
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    protected function extractRowParams(array $row): array
    {
        if (isset($row['params']) && is_array($row['params'])) {
            return $row['params'];
        }

        $model = $this->getModel();
        if (method_exists($model, 'paramsOf')) {
            return $model->paramsOf($row);
        }

        if (isset($row['params_json'])) {
            if (is_array($row['params_json'])) {
                return $row['params_json'];
            }
            if (is_object($row['params_json'])) {
                return json_decode(json_encode($row['params_json']), true) ?: [];
            }
            if (is_string($row['params_json'])) {
                $decoded = json_decode($row['params_json'], true);
                return is_array($decoded) ? $decoded : [];
            }
        }

        return [];
    }

    /**
     * Helper to compute Bangladesh Fiscal Year (July 1 - June 30)
     */
    public static function getFiscalYear(?string $date = null): string
    {
        return \App\Services\Tax\TaxCalculator::getFiscalYear($date);
    }

    /**
     * Calculate income tax through the authoritative TaxCalculator and RuleResolver
     */
    public static function calculateTax(float $monthlyGross, array $context = []): array
    {
        $calculator = new \App\Services\Tax\TaxCalculator();
        return $calculator->calculateTax($monthlyGross, $context);
    }

    /**
     * Get rule definition model instance
     */
    protected function getModel(): object
    {
        if ($this->model === null) {
            if (self::$staticModel === null) {
                self::$staticModel = new RuleDefinitionModel();
            }
            $this->model = self::$staticModel;
        }

        return $this->model;
    }
}