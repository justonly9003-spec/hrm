<?php

namespace App\Services\Rules;

class ResolvedRule
{
    protected string $companyId;
    protected string $domain;
    protected string $date;

    /**
     * @var array<string, mixed>
     */
    protected array $params;

    /**
     * @var array<int, array<string, mixed>>
     */
    protected array $layers;

    /**
     * @var array<string, array<string, mixed>>
     */
    protected array $origins;

    /**
     * @param string $companyId
     * @param string $domain
     * @param string $date
     * @param array<string, mixed> $params
     * @param array<int, array<string, mixed>> $layers
     * @param array<string, array<string, mixed>> $origins
     */
    public function __construct(
        string $companyId,
        string $domain,
        string $date,
        array $params,
        array $layers,
        array $origins
    ) {
        $this->companyId = $companyId;
        $this->domain    = $domain;
        $this->date      = $date;
        $this->params    = $params;
        $this->layers    = $layers;
        $this->origins   = $origins;
    }

    /**
     * Get a resolved parameter value.
     *
     * @param string $key
     * @return mixed
     * @throws RuleKeyMissingException
     */
    public function get(string $key): mixed
    {
        if (array_key_exists($key, $this->params)) {
            return $this->params[$key];
        }

        throw RuleKeyMissingException::forKey($key, $this->domain);
    }

    /**
     * Magic getter delegating to get() or rule metadata
     */
    public function __get(string $key): mixed
    {
        if ($key === 'effective_rule_id' || $key === 'effectiveRuleId') {
            return $this->effectiveRuleId();
        }
        if ($key === 'effective_version' || $key === 'effectiveVersion') {
            return $this->effectiveVersion();
        }
        if ($key === 'scope_level' || $key === 'scopeLevel') {
            return $this->scopeLevel();
        }
        if ($key === 'scope_id' || $key === 'scopeId') {
            return $this->scopeId();
        }

        return $this->get($key);
    }

    /**
     * Check if parameter key exists
     */
    public function has(string $key): bool
    {
        return array_key_exists($key, $this->params);
    }

    /**
     * Get all resolved parameters
     *
     * @return array<string, mixed>
     */
    public function params(): array
    {
        return $this->params;
    }

    /**
     * Get applied layers in hierarchical order
     *
     * @return array<int, array<string, mixed>>
     */
    public function layers(): array
    {
        return $this->layers;
    }

    /**
     * Returns structured explanation of each parameter value and its originating layer
     *
     * @return array<string, array{value: mixed, origin: array{scope_level: string, scope_id: ?string, version_number: int, rule_id: string}}>
     */
    public function explain(): array
    {
        $result = [];
        foreach ($this->params as $key => $val) {
            $origin = isset($this->origins[$key]) ? $this->origins[$key] : [
                'scope_level'    => 'Company',
                'scope_id'       => null,
                'version_number' => 1,
                'rule_id'        => '',
            ];

            $result[$key] = [
                'value'  => $val,
                'origin' => [
                    'scope_level'    => (string)$origin['scope_level'],
                    'scope_id'       => isset($origin['scope_id']) && $origin['scope_id'] !== null ? (string)$origin['scope_id'] : null,
                    'version_number' => (int)$origin['version_number'],
                    'rule_id'        => (string)$origin['rule_id'],
                ],
            ];
        }

        return $result;
    }

    /**
     * Compute SHA1 of canonical (key-sorted) JSON representation of params
     */
    public function sha1(): string
    {
        return sha1($this->canonicalJson($this->params));
    }

    /**
     * Snapshot = layers + sha1 of canonical (key-sorted) JSON (+ resolved params)
     *
     * @return array{layers: array<int, array<string, mixed>>, sha1: string, params: array<string, mixed>}
     */
    public function snapshot(): array
    {
        return [
            'layers' => $this->layers,
            'sha1'   => $this->sha1(),
            'params' => $this->params,
        ];
    }

    /**
     * Serialize canonical key-sorted JSON
     */
    public function canonicalJson(mixed $data): string
    {
        $sorted = $this->sortRecursive($data);
        return (string)json_encode($sorted, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }

    /**
     * Recursively sort associative arrays by key for canonical serialization
     */
    protected function sortRecursive(mixed $data): mixed
    {
        if (!is_array($data)) {
            return $data;
        }

        // Check if associative array
        $isAssoc = false;
        $expectedIndex = 0;
        foreach ($data as $k => $v) {
            if ($k !== $expectedIndex) {
                $isAssoc = true;
                break;
            }
            $expectedIndex++;
        }

        if ($isAssoc) {
            ksort($data);
        }

        foreach ($data as $k => $v) {
            if (is_array($v)) {
                $data[$k] = $this->sortRecursive($v);
            }
        }

        return $data;
    }

    public function getDate(): string
    {
        return $this->date;
    }

    /**
     * Get the scope level from the most specific layer applied (Company, Branch, Department, Designation, Shift, Employee)
     */
    public function scopeLevel(): string
    {
        if (!empty($this->layers)) {
            for ($i = count($this->layers) - 1; $i >= 0; $i--) {
                $layer = $this->layers[$i];
                if (!empty($layer['scope_level'])) {
                    return (string)$layer['scope_level'];
                }
            }
        }

        return 'Company';
    }

    /**
     * Get the scope ID from the most specific layer applied (or null if Company)
     */
    public function scopeId(): ?string
    {
        if (!empty($this->layers)) {
            for ($i = count($this->layers) - 1; $i >= 0; $i--) {
                $layer = $this->layers[$i];
                if (array_key_exists('scope_id', $layer)) {
                    return $layer['scope_id'];
                }
            }
        }

        return null;
    }

    /**
     * Get the ID of the effective rule (from the most specific layer applied, falling back to Company layer)
     */
    public function effectiveRuleId(): string
    {
        if (!empty($this->layers)) {
            for ($i = count($this->layers) - 1; $i >= 0; $i--) {
                $layer = $this->layers[$i];
                $id = $layer['rule_id'] ?? $layer['id'] ?? '';
                if (!empty($id)) {
                    return (string)$id;
                }
            }
        }

        return '';
    }

    /**
     * Get the base Company rule ID
     */
    public function companyRuleId(): string
    {
        if (!empty($this->layers)) {
            foreach ($this->layers as $layer) {
                if (($layer['scope_level'] ?? '') === 'Company') {
                    $id = $layer['rule_id'] ?? $layer['id'] ?? '';
                    if (!empty($id)) {
                        return (string)$id;
                    }
                }
            }
        }

        return $this->effectiveRuleId();
    }

    /**
     * Get the effective rule version number (from the most specific layer applied)
     */
    public function effectiveVersion(): int
    {
        if (!empty($this->layers)) {
            for ($i = count($this->layers) - 1; $i >= 0; $i--) {
                $layer = $this->layers[$i];
                if (isset($layer['version_number'])) {
                    return (int)$layer['version_number'];
                }
            }
        }

        return 1;
    }
}
