<?php

namespace App\Services\Rules;

class Money
{
    /**
     * Resolve configured money_decimals from PAYROLL_BASICS for a company.
     *
     * @param int|ResolvedRule|string|null $context Explicit integer precision, pre-resolved PAYROLL_BASICS rule, or company_id string
     * @param mixed $employee Optional employee array/context
     * @param string|null $date Effective date (YYYY-MM-DD or YYYY-MM)
     * @return int
     */
    public static function decimals(int|ResolvedRule|string|null $context = null, mixed $employee = null, ?string $date = null): int
    {
        if (is_int($context)) {
            return $context;
        }

        if ($context instanceof ResolvedRule) {
            return (int)$context->get('money_decimals');
        }

        $companyId = is_string($context) ? trim($context) : '';
        if ($companyId === '' && is_array($employee) && !empty($employee['company_id'])) {
            $companyId = trim((string)$employee['company_id']);
        }
        if ($companyId === '' && function_exists('session')) {
            try {
                $companyId = trim((string)(session('selected_company_id') ?: session('company_id') ?: ''));
            } catch (\Throwable $e) {
            }
        }

        if ($companyId === '') {
            throw new RuleNotConfiguredException(
                'Company ID is required to resolve money_decimals from PAYROLL_BASICS.',
                null,
                'PAYROLL_BASICS',
                $date
            );
        }

        $effectiveDate = (!empty($date) && preg_match('/^\d{4}-\d{2}-\d{2}/', $date))
            ? substr($date, 0, 10)
            : ((!empty($date) && preg_match('/^\d{4}-\d{2}$/', $date)) ? "{$date}-01" : date('Y-m-d'));

        $pbRule = is_array($employee)
            ? RuleResolver::resolve($companyId, 'PAYROLL_BASICS', $effectiveDate, $employee)
            : RuleResolver::resolveForCompany($companyId, 'PAYROLL_BASICS', $effectiveDate);

        return (int)$pbRule->get('money_decimals');
    }

    /**
     * Round a monetary amount using money_decimals from PAYROLL_BASICS.
     *
     * @param float $amount Amount to round
     * @param int|ResolvedRule|string|null $decimalsOrCompany Resolved precision (int), PAYROLL_BASICS ResolvedRule, or company_id string
     * @param mixed $employee Optional employee row/scopes when resolving by company_id
     * @param string|null $date Optional effective date when resolving by company_id
     * @return float
     */
    public static function round(
        float $amount,
        int|ResolvedRule|string|null $decimalsOrCompany = null,
        mixed $employee = null,
        ?string $date = null
    ): float {
        $precision = self::decimals($decimalsOrCompany, $employee, $date);
        return round($amount, $precision);
    }
}
