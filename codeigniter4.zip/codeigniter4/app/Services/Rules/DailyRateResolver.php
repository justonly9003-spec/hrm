<?php

namespace App\Services\Rules;

/**
 * Single source of truth for daily salary rate and divisor resolution.
 * Reads daily_rate_mode and daily_rate_divisor from PAYROLL_BASICS via RuleResolver.
 */
class DailyRateResolver
{
    /**
     * Map of supported fixed override modes to divisor days and canonical label.
     */
    private const OVERRIDE_MODE_MAP = [
        'Fixed 26 Days' => ['days' => 26.0, 'mode' => 'Fixed 26 Days'],
        '26'            => ['days' => 26.0, 'mode' => 'Fixed 26 Days'],
        'Fixed 30 Days' => ['days' => 30.0, 'mode' => 'Fixed 30 Days'],
        '30'            => ['days' => 30.0, 'mode' => 'Fixed 30 Days'],
    ];

    /**
     * Resolve daily salary rate and divisor days.
     *
     * @param string $companyId Tenant company ID
     * @param mixed $employee Employee entity/context array, object or ID
     * @param string|null $date Specific date (YYYY-MM-DD)
     * @param string|null $month Month string (YYYY-MM)
     * @param float $salary Base salary for computing daily_rate (optional)
     * @param string|null $overrideDivisorMode Optional mode override (e.g. from OVERTIME divisor_mode: 'Fixed 26 Days', 'Fixed 30 Days', 'Calendar Days', 'Basics')
     * @return array{daily_rate: float, divisor_days: float, divisor_mode: string, days_in_month: int, rate: float, divisor: float}
     * @throws RuleNotConfiguredException
     */
    public static function resolve(
        string $companyId,
        mixed $employee = null,
        ?string $date = null,
        ?string $month = null,
        float $salary = 0.0,
        ?string $overrideDivisorMode = null
    ): array {
        $companyId = trim((string)$companyId);
        if ($companyId === '') {
            throw new RuleNotConfiguredException("Company ID context is required to resolve daily salary rate.");
        }

        // Normalize date and month
        if ($date !== null && $date !== '') {
            $date = substr(trim($date), 0, 10);
            if ($month === null || $month === '') {
                $month = substr($date, 0, 7);
            }
        } elseif ($month !== null && $month !== '') {
            $month = substr(trim($month), 0, 7);
            $date = "{$month}-01";
        } else {
            $date = date('Y-m-d');
            $month = date('Y-m');
        }

        $daysInMonth = (int)date('t', strtotime("{$month}-01"));
        if ($daysInMonth <= 0) {
            throw new RuleNotConfiguredException("Invalid month string '{$month}' provided for daily rate calculation.");
        }

        // Resolve PAYROLL_BASICS authoritative rule
        try {
            $basicsRule = RuleResolver::resolve($companyId, 'PAYROLL_BASICS', $date, $employee);
        } catch (RuleNotConfiguredException $e) {
            if (stripos($e->getMessage(), 'before first effective version') !== false) {
                $basicsRule = RuleResolver::resolve($companyId, 'PAYROLL_BASICS', RuleResolver::today(), $employee);
            } else {
                throw $e;
            }
        }
        $dailyRateMode = (string)$basicsRule->get('daily_rate_mode');
        $dailyRateDivisor = (float)$basicsRule->get('daily_rate_divisor');

        // Check if caller requested an explicit divisor mode (such as OVERTIME divisor_mode)
        $mode = $overrideDivisorMode !== null && $overrideDivisorMode !== '' ? trim($overrideDivisorMode) : null;

        if ($mode !== null && $mode !== 'Basics') {
            if ($mode === 'Calendar Days' || strcasecmp($mode, 'Calendar') === 0) {
                $divisorDays = (float)$daysInMonth;
                $divisorMode = 'Calendar';
            } elseif (isset(self::OVERRIDE_MODE_MAP[$mode])) {
                $divisorDays = self::OVERRIDE_MODE_MAP[$mode]['days'];
                $divisorMode = self::OVERRIDE_MODE_MAP[$mode]['mode'];
            } elseif (is_numeric($mode) && (float)$mode > 0) {
                $divisorDays = (float)$mode;
                $divisorMode = "Fixed {$divisorDays} Days";
            } elseif (strcasecmp($mode, 'Fixed') === 0) {
                $divisorDays = $dailyRateDivisor;
                $divisorMode = 'Fixed';
            } else {
                throw new RuleNotConfiguredException("Unsupported divisor mode '{$mode}' for company '{$companyId}'.");
            }
        } else {
            // Standard PAYROLL_BASICS resolution
            if (strcasecmp($dailyRateMode, 'Calendar') === 0) {
                $divisorDays = (float)$daysInMonth;
                $divisorMode = 'Calendar';
            } elseif (strcasecmp($dailyRateMode, 'Fixed') === 0) {
                $divisorDays = $dailyRateDivisor;
                $divisorMode = 'Fixed';
            } else {
                throw new RuleNotConfiguredException("Unsupported daily_rate_mode '{$dailyRateMode}' in PAYROLL_BASICS for company '{$companyId}'.");
            }
        }

        if ($divisorDays <= 0) {
            throw new RuleNotConfiguredException("Invalid or zero daily rate divisor in PAYROLL_BASICS for company '{$companyId}'.");
        }

        $dailyRate = $salary > 0 ? Money::round($salary / $divisorDays, $basicsRule) : 0.00;

        return [
            'daily_rate'    => $dailyRate,
            'divisor_days'  => $divisorDays,
            'divisor_mode'  => $divisorMode,
            'days_in_month' => $daysInMonth,
            'rate'          => $dailyRate,
            'divisor'       => $divisorDays,
        ];
    }
}
