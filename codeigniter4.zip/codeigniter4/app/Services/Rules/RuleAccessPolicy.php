<?php

namespace App\Services\Rules;

use App\Services\PermissionService;

final class RuleAccessPolicy
{
    /**
     * Check if user or role can view rules.
     * Supports:
     * - RuleAccessPolicy::canView(PermissionService $permissions, ?string $userId): bool
     * - RuleAccessPolicy::canView(string $roleOrUserId, ?PermissionService $permissions = null): bool
     */
    public static function canView($firstArg, $secondArg = null): bool
    {
        return self::check('view', $firstArg, $secondArg);
    }

    /**
     * Check if user or role can manage rules.
     * Supports:
     * - RuleAccessPolicy::canManage(PermissionService $permissions, ?string $userId): bool
     * - RuleAccessPolicy::canManage(string $roleOrUserId, ?PermissionService $permissions = null): bool
     */
    public static function canManage($firstArg, $secondArg = null): bool
    {
        return self::check('manage', $firstArg, $secondArg);
    }

    private static function check(string $action, $firstArg, $secondArg = null): bool
    {
        $permission = 'rules.' . $action;

        if ($firstArg instanceof PermissionService) {
            $permissions = $firstArg;
            $userId = $secondArg;
            return $userId !== null && $userId !== '' && $permissions->hasPermission($userId, $permission);
        }

        $permService = ($secondArg instanceof PermissionService) ? $secondArg : new PermissionService();
        $arg = trim((string)$firstArg);
        if ($arg === '') {
            return false;
        }

        $canonicalRole = $permService->canonicalizeRole($arg);

        if ($canonicalRole === 'software_app_admin' || $canonicalRole === 'company_admin') {
            return true;
        }

        if ($permService->isSoftwareAppAdmin($canonicalRole) || $permService->isCompanyAdmin($canonicalRole) || $permService->isSoftwareAppAdmin($arg)) {
            return true;
        }

        if (str_starts_with($arg, 'usr-') || str_starts_with($arg, 'user-')) {
            return $permService->hasPermission($arg, $permission);
        }

        return $permService->checkDefaultRoleAccess($canonicalRole, 'rules', $action);
    }
}
