<?php

namespace App\Services\Rules;

class FormulaEvaluator
{
    /**
     * Canonical variable alias groups (bidirectional within each group).
     *
     * @var array<string, array<int, string>>
     */
    protected static array $variableAliases = [
        'BASIC'      => ['BASIC', 'BASIC_SALARY', 'BASICSALARY'],
        'GROSS'      => ['GROSS', 'GROSS_SALARY', 'GROSSSALARY'],
        'HOUSE_RENT' => ['HOUSE_RENT', 'HRA', 'HOUSERENT', 'HOUSE_RENT_ALLOWANCE', 'HOUSERENTALLOWANCE'],
        'MEDICAL'    => ['MEDICAL', 'MEDICAL_ALLOWANCE', 'MED', 'MEDICALALLOWANCE'],
        'CONVEYANCE' => ['CONVEYANCE', 'CONVEYANCE_ALLOWANCE', 'TRANSPORT', 'TRANSPORT_ALLOWANCE', 'CONVEYANCEALLOWANCE', 'TRANSPORTALLOWANCE'],
    ];

    /**
     * Safely evaluate a mathematical formula containing variables.
     *
     * @param string $formula Formula string, e.g. "BASIC * 0.07" or "(BASIC + HRA) * 0.10"
     * @param array<string, float|int|numeric> $variables Key-value pool of available variables
     * @return float
     * @throws \InvalidArgumentException On empty formula, unknown variable, invalid characters, unbalanced parentheses, or division by zero
     */
    public static function evaluate(string $formula, array $variables = []): float
    {
        $formula = trim($formula);
        if ($formula === '') {
            throw new \InvalidArgumentException('Formula cannot be empty.');
        }

        // Reject invalid characters before variable substitution
        if (preg_match('/[^a-zA-Z0-9_\.\+\-\*\/\%\^\(\)\s]/', $formula, $badMatch)) {
            throw new \InvalidArgumentException("Invalid character '{$badMatch[0]}' in formula.");
        }

        // Reject malformed number-identifier concatenation (e.g. "2BASIC")
        if (preg_match('/\d[a-zA-Z_]/', $formula, $badSeq)) {
            throw new \InvalidArgumentException("Invalid syntax '{$badSeq[0]}' in formula.");
        }

        // Normalize variables to uppercase for case-insensitivity
        $upperVars = [];
        foreach ($variables as $k => $v) {
            if (!is_numeric($v)) {
                throw new \InvalidArgumentException("Variable '{$k}' must have a numeric value.");
            }
            $val = (float)$v;
            $upperKey = strtoupper(trim((string)$k));
            $upperVars[$upperKey] = $val;

            $cleanKey = strtoupper((string)preg_replace('/[^a-zA-Z0-9]/', '', (string)$k));
            if ($cleanKey !== '') {
                $upperVars[$cleanKey] = $val;
            }
        }

        // Expand variable aliases using single alias map
        foreach (self::$variableAliases as $canonical => $aliases) {
            $resolvedVal = null;
            foreach ($aliases as $alias) {
                if (array_key_exists($alias, $upperVars)) {
                    $resolvedVal = $upperVars[$alias];
                    break;
                }
            }
            if ($resolvedVal !== null) {
                $upperVars[$canonical] = $upperVars[$canonical] ?? $resolvedVal;
                foreach ($aliases as $alias) {
                    $upperVars[$alias] = $upperVars[$alias] ?? $resolvedVal;
                }
            }
        }

        // Substitute variable identifiers using number_format($v, 8, '.', '') so scientific notation never appears
        $sanitized = preg_replace_callback('/[a-zA-Z_][a-zA-Z0-9_]*/', function ($matches) use ($upperVars) {
            $rawIdentifier = $matches[0];
            $identifier = strtoupper($rawIdentifier);
            $cleanIdentifier = (string)preg_replace('/[^A-Z0-9]/', '', $identifier);

            if (array_key_exists($identifier, $upperVars)) {
                $v = (float)$upperVars[$identifier];
                $formatted = number_format($v, 8, '.', '');
                return $v < 0 ? "({$formatted})" : $formatted;
            }
            if ($cleanIdentifier !== '' && array_key_exists($cleanIdentifier, $upperVars)) {
                $v = (float)$upperVars[$cleanIdentifier];
                $formatted = number_format($v, 8, '.', '');
                return $v < 0 ? "({$formatted})" : $formatted;
            }

            throw new \InvalidArgumentException("Unknown variable '{$rawIdentifier}' in formula.");
        }, $formula);

        if ($sanitized === null || preg_match('/[^0-9\.\+\-\*\/\%\^\(\)\s]/', $sanitized, $badMatch)) {
            $ch = $badMatch[0] ?? '';
            throw new \InvalidArgumentException("Invalid character '{$ch}' in formula.");
        }

        return self::computeMathExpression($sanitized);
    }

    /**
     * Safe RPN mathematical evaluator (Shunting-Yard).
     *
     * @param string $expr
     * @return float
     * @throws \InvalidArgumentException
     */
    public static function computeMathExpression(string $expr): float
    {
        $expr = trim($expr);
        if ($expr === '') {
            throw new \InvalidArgumentException('Formula expression cannot be empty.');
        }

        if (preg_match('/[^0-9\.\+\-\*\/\%\^\(\)\s]/', $expr, $badMatch)) {
            throw new \InvalidArgumentException("Invalid character '{$badMatch[0]}' in expression.");
        }

        // Tokenize numbers, unary/binary operators, and parentheses
        $tokens = [];
        $len = strlen($expr);
        $i = 0;
        $prevType = null; // null | 'num' | 'op' | 'uop' | '(' | ')'

        while ($i < $len) {
            $ch = $expr[$i];

            if (ctype_space($ch)) {
                $i++;
                continue;
            }

            // Number literal
            if (ctype_digit($ch) || $ch === '.') {
                if ($prevType === 'num' || $prevType === ')') {
                    throw new \InvalidArgumentException('Missing operator before number in formula.');
                }

                $num = '';
                $dotCount = 0;
                while ($i < $len && (ctype_digit($expr[$i]) || $expr[$i] === '.')) {
                    if ($expr[$i] === '.') {
                        $dotCount++;
                        if ($dotCount > 1) {
                            throw new \InvalidArgumentException("Invalid numeric literal in formula.");
                        }
                    }
                    $num .= $expr[$i];
                    $i++;
                }

                if ($num === '.' || !is_numeric($num)) {
                    throw new \InvalidArgumentException("Invalid numeric literal '{$num}' in formula.");
                }

                $tokens[] = (float)$num;
                $prevType = 'num';
                continue;
            }

            // Unary minus or unary plus (valid at start, after '(', after binary operator, or after unary operator)
            if (($ch === '-' || $ch === '+') && ($prevType === null || $prevType === 'op' || $prevType === 'uop' || $prevType === '(')) {
                $tokens[] = ($ch === '-') ? 'u-' : 'u+';
                $prevType = 'uop';
                $i++;
                continue;
            }

            if ($ch === '(') {
                if ($prevType === 'num' || $prevType === ')') {
                    throw new \InvalidArgumentException('Missing operator before opening parenthesis in formula.');
                }
                $tokens[] = '(';
                $prevType = '(';
                $i++;
                continue;
            }

            if ($ch === ')') {
                if ($prevType === '(') {
                    throw new \InvalidArgumentException('Empty parentheses in formula.');
                }
                if ($prevType !== 'num' && $prevType !== ')') {
                    throw new \InvalidArgumentException('Unexpected closing parenthesis in formula.');
                }
                $tokens[] = ')';
                $prevType = ')';
                $i++;
                continue;
            }

            if (in_array($ch, ['+', '-', '*', '/', '%', '^'], true)) {
                if ($prevType !== 'num' && $prevType !== ')') {
                    throw new \InvalidArgumentException("Unexpected operator '{$ch}' in formula.");
                }
                $tokens[] = $ch;
                $prevType = 'op';
                $i++;
                continue;
            }

            throw new \InvalidArgumentException("Invalid character '{$ch}' in formula.");
        }

        if ($prevType !== 'num' && $prevType !== ')') {
            throw new \InvalidArgumentException('Incomplete formula expression: missing operand at end.');
        }

        // Shunting-Yard algorithm to Postfix (RPN)
        $output = [];
        $ops = [];
        $precedence = [
            '+'  => 1,
            '-'  => 1,
            '*'  => 2,
            '/'  => 2,
            '%'  => 2,
            'u-' => 3,
            'u+' => 3,
            '^'  => 4,
        ];

        foreach ($tokens as $token) {
            if (is_float($token) || is_int($token)) {
                $output[] = (float)$token;
            } elseif ($token === '(') {
                $ops[] = '(';
            } elseif ($token === ')') {
                $foundOpen = false;
                while (!empty($ops)) {
                    $top = array_pop($ops);
                    if ($top === '(') {
                        $foundOpen = true;
                        break;
                    }
                    $output[] = $top;
                }
                if (!$foundOpen) {
                    throw new \InvalidArgumentException('Unbalanced parentheses in formula: unexpected closing parenthesis.');
                }
            } elseif ($token === 'u-' || $token === 'u+') {
                // Prefix unary operators are right-associative and always bind to the following operand/group
                $ops[] = $token;
            } else {
                // Binary operator
                $prec = $precedence[$token] ?? 0;
                $isRightAssoc = ($token === '^');

                while (!empty($ops) && end($ops) !== '(') {
                    $top = end($ops);
                    $topPrec = $precedence[$top] ?? 0;
                    if ($isRightAssoc ? ($topPrec > $prec) : ($topPrec >= $prec)) {
                        $output[] = array_pop($ops);
                    } else {
                        break;
                    }
                }
                $ops[] = $token;
            }
        }

        while (!empty($ops)) {
            $top = array_pop($ops);
            if ($top === '(' || $top === ')') {
                throw new \InvalidArgumentException('Unbalanced parentheses in formula: unclosed opening parenthesis.');
            }
            $output[] = $top;
        }

        // Evaluate RPN
        $stack = [];
        foreach ($output as $t) {
            if (is_float($t) || is_int($t)) {
                $stack[] = (float)$t;
            } elseif ($t === 'u-') {
                if (empty($stack)) {
                    throw new \InvalidArgumentException('Invalid formula syntax: missing operand for unary minus.');
                }
                $a = array_pop($stack);
                $stack[] = -$a;
            } elseif ($t === 'u+') {
                if (empty($stack)) {
                    throw new \InvalidArgumentException('Invalid formula syntax: missing operand for unary plus.');
                }
            } else {
                if (count($stack) < 2) {
                    throw new \InvalidArgumentException("Invalid formula syntax: insufficient operands for operator '{$t}'.");
                }
                $b = array_pop($stack);
                $a = array_pop($stack);

                switch ($t) {
                    case '+':
                        $res = $a + $b;
                        break;
                    case '-':
                        $res = $a - $b;
                        break;
                    case '*':
                        $res = $a * $b;
                        break;
                    case '/':
                        if (abs($b) < 1e-12) {
                            throw new \InvalidArgumentException('Division by zero in formula.');
                        }
                        $res = $a / $b;
                        break;
                    case '%':
                        if (abs($b) < 1e-12) {
                            throw new \InvalidArgumentException('Division by zero in modulo operation.');
                        }
                        $res = fmod($a, $b);
                        break;
                    case '^':
                        $res = pow($a, $b);
                        break;
                    default:
                        throw new \InvalidArgumentException("Unknown operator '{$t}' in formula.");
                }

                if (!is_finite($res)) {
                    throw new \InvalidArgumentException('Formula evaluation produced a non-finite number.');
                }

                $stack[] = (float)$res;
            }
        }

        if (count($stack) !== 1) {
            throw new \InvalidArgumentException('Invalid formula syntax.');
        }

        return round((float)array_pop($stack), 4);
    }

    /**
     * Validate formula syntax and variable references against sample variables.
     *
     * @param string $formula
     * @param array<int|string, mixed> $extraVars Optional additional allowed variable names or key=>val pairs
     * @return array{valid: bool, sample_result?: float, error?: string}
     */
    public static function testFormulaSyntax(string $formula, array $extraVars = []): array
    {
        $formula = trim($formula);
        if ($formula === '') {
            return ['valid' => false, 'error' => 'Formula cannot be empty'];
        }

        try {
            $dummyVars = [
                'BASIC'             => 50000.0,
                'GROSS'             => 80000.0,
                'HOUSE_RENT'        => 15000.0,
                'MEDICAL'           => 5000.0,
                'CONVEYANCE'        => 3000.0,
                'SPECIAL'           => 5000.0,
                'SPECIAL_ALLOWANCE' => 5000.0,
                'DA'                => 2000.0,
                'FOOD'              => 2000.0,
                'FOOD_ALLOWANCE'    => 2000.0,
                'OTHER_ALLOWANCE'   => 1000.0,
                'OTHER_ALLOWANCES'  => 1000.0,
                'RATE'              => 7.0,
                'EMPLOYEE_RATE'     => 7.0,
                'EMPLOYER_RATE'     => 7.0,
                'BASIS'             => 50000.0,
                'VALUE'             => 50.0,
                'TENURE_DAYS'       => 365.0,
                'TENURE_MONTHS'     => 12.0,
            ];

            foreach ($extraVars as $k => $v) {
                if (is_int($k) && is_string($v) && trim($v) !== '') {
                    $dummyVars[trim($v)] = 1000.0;
                } elseif (is_string($k) && is_numeric($v)) {
                    $dummyVars[trim($k)] = (float)$v;
                }
            }

            $result = self::evaluate($formula, $dummyVars);
            return [
                'valid'         => true,
                'sample_result' => $result,
            ];
        } catch (\InvalidArgumentException $e) {
            return [
                'valid' => false,
                'error' => $e->getMessage(),
            ];
        } catch (\Throwable $e) {
            return [
                'valid' => false,
                'error' => $e->getMessage(),
            ];
        }
    }
}

