<?php

namespace App\Services\Rules;

class RuleSchemaRegistry
{
    private static ?array $schema = null;
    /** @var callable|null */
    private static $componentOptionsResolver = null;

    /**
     * Initialize schema from JSON file (static cache)
     */
    public static function init(): void
    {
        if (self::$schema !== null) {
            return;
        }

        $paths = [];
        if (defined('APPPATH')) {
            $paths[] = APPPATH . 'Config/RuleSchema.json';
        }
        $paths[] = __DIR__ . '/../../Config/RuleSchema.json';
        $paths[] = dirname(__DIR__, 2) . '/Config/RuleSchema.json';

        $content = false;
        foreach ($paths as $path) {
            if (file_exists($path)) {
                $content = file_get_contents($path);
                if ($content !== false) {
                    break;
                }
            }
        }

        if ($content === false) {
            throw new \RuntimeException("RuleSchema.json not found in expected Config paths");
        }

        $decoded = json_decode($content, true);
        if (!is_array($decoded)) {
            throw new \RuntimeException("Failed to parse RuleSchema.json: " . json_last_error_msg());
        }

        self::$schema = $decoded;
    }

    /**
     * Clear the static cache (primarily for tests)
     */
    public static function clearCache(): void
    {
        self::$schema = null;
        self::$componentOptionsResolver = null;
    }

    /**
     * Set a custom component options resolver (for testing or overrides)
     */
    public static function setComponentOptionsResolver(?callable $resolver): void
    {
        self::$componentOptionsResolver = $resolver;
    }

    /**
     * Get active earning salary components for a company.
     * Returns array of ['code' => string, 'name' => string]
     */
    public static function componentOptions(string $companyId): array
    {
        if (self::$componentOptionsResolver !== null) {
            return (self::$componentOptionsResolver)($companyId);
        }

        if (empty($companyId)) {
            return [];
        }

        try {
            $model = new \App\Models\SalaryComponentModel();
            $rows = $model->where('company_id', $companyId)
                ->where('type', 'earning')
                ->where('status', 'Active')
                ->orderBy('display_order', 'ASC')
                ->orderBy('name', 'ASC')
                ->findAll();

            $options = [];
            foreach ($rows as $r) {
                $options[] = [
                    'code' => (string)$r['code'],
                    'name' => (string)$r['name'],
                ];
            }
            return $options;
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * Get list of all domain identifiers
     */
    public static function domains(): array
    {
        self::init();
        return array_keys(self::$schema['domains'] ?? []);
    }

    /**
     * Get domain definition array
     */
    public static function domain(string $domain): ?array
    {
        self::init();
        $domainUpper = strtoupper(trim($domain));
        return self::$schema['domains'][$domainUpper] ?? (self::$schema['domains'][$domain] ?? null);
    }

    /**
     * Get list of all param definitions for a domain
     */
    public static function params(string $domain): array
    {
        $domainDef = self::domain($domain);
        if ($domainDef === null || !isset($domainDef['params']) || !is_array($domainDef['params'])) {
            return [];
        }

        return $domainDef['params'];
    }

    /**
     * Get specific param definition by key
     */
    public static function param(string $domain, string $key): ?array
    {
        $params = self::params($domain);
        foreach ($params as $p) {
            if (isset($p['key']) && $p['key'] === $key) {
                if (!empty($p['pending_inventory'])) {
                    self::logPendingWarning($domain, $key);
                }
                return $p;
            }
        }

        return null;
    }

    /**
     * Get allowed scopes for a domain
     */
    public static function allowedScopes(string $domain): array
    {
        $domainDef = self::domain($domain);
        if ($domainDef === null || !isset($domainDef['allowed_scopes']) || !is_array($domainDef['allowed_scopes'])) {
            return ['Company'];
        }

        return $domainDef['allowed_scopes'];
    }

    /**
     * Get default seed values for a domain
     */
    public static function seedValues(string $domain): array
    {
        $params = self::params($domain);
        $seeds = [];

        foreach ($params as $p) {
            if (!isset($p['key'])) {
                continue;
            }
            if (array_key_exists('seed', $p)) {
                $seeds[$p['key']] = $p['seed'];
            }
        }

        return $seeds;
    }

    /**
     * Get list of keys requiring HR/legal confirmation
     */
    public static function confirmKeys(string $domain): array
    {
        $params = self::params($domain);
        $keys = [];

        foreach ($params as $p) {
            if (!empty($p['confirm']) && isset($p['key'])) {
                $keys[] = $p['key'];
            }
        }

        return $keys;
    }

    /**
     * Get list of keys marked as pending inventory
     */
    public static function pendingKeys(string $domain): array
    {
        $params = self::params($domain);
        $keys = [];

        foreach ($params as $p) {
            if (!empty($p['pending_inventory']) && isset($p['key'])) {
                $keys[] = $p['key'];
            }
        }

        return $keys;
    }

    /**
     * Get values for a shared enum
     */
    public static function sharedEnum(string $enumName): array
    {
        self::init();

        $name = $enumName;
        if (str_starts_with($name, 'shared_enums.')) {
            $name = substr($name, strlen('shared_enums.'));
        }

        return self::$schema['shared_enums'][$name] ?? [];
    }

    /**
     * Get raw schema or schema version
     */
    public static function schemaVersion(): int
    {
        self::init();
        return (int)(self::$schema['schema_version'] ?? 1);
    }

    /**
     * Validate params for a domain using RuleParamValidator
     */
    public static function validate(string $domain, array $params, bool $partial = false, string $scopeLevel = 'Company', ?string $companyId = null): array
    {
        $res = RuleParamValidator::validate($domain, $scopeLevel, $params, $partial, $companyId);
        return $res['errors'] ?? [];
    }

    /**
     * Log warning when pending inventory param is touched
     */
    public static function logPendingWarning(string $domain, string $key): void
    {
        if (function_exists('log_message')) {
            log_message('warning', "Pending inventory rule param accessed: {$domain}.{$key}");
        }
    }
}
