<?php

namespace App\Services\Rules;

use App\Models\RuleDefinitionModel;
use App\Models\RuleChangeLogModel;
use Config\Database;
use RuntimeException;

class RuleSeeder
{
    /**
     * Re-entrancy guard to prevent circular recursion during company seeding
     *
     * @var array<string, bool>
     */
    protected static array $seedingCompanies = [];

    /**
     * Re-entrancy guard to prevent circular recursion during leave entitlement synchronization
     *
     * @var array<string, bool>
     */
    protected static array $ensuringLeaveEntitlements = [];

    /**
     * Seeds complete Company-scope rules for a company in a single atomic transaction.
     *
     * For each domain defined in RuleSchemaRegistry:
     * - If NO Company-scope Active (or Draft) version exists for this company and domain:
     *     Inserts version 1:
     *       - effective_from = passed $seedDate (defaults to current date Y-m-d if omitted)
     *       - effective_to = null
     *       - status = 'Active' only for domains with no confirm:true keys; 'Draft' for domains with confirm:true keys
     *       - params = schema seed values (merged with optional $overrides[$domain])
     *       - change_reason = RuleWriteService::SEED_REASON
     * - If an Active (or Draft) Company-scope version already exists:
     *     Existing values are NEVER overwritten (idempotent).
     *
     * Returns an array containing:
     * - seeded_domains: list of domain keys that were newly seeded
     * - skipped_domains: list of domain keys that already had a Company rule
     * - needs_confirmation: list of params requiring HR/legal confirmation
     *
     * @param string $companyId
     * @param array<string, array<string, mixed>>|null $overrides Optional domain-keyed param overrides
     * @param string|null $seedDate Effective start date (YYYY-MM-DD) for seeded rules
     * @return array{
     *     company_id: string,
     *     seeded_domains: array<string>,
     *     skipped_domains: array<string>,
     *     needs_confirmation: array<int, array{domain: string, key: string, label: string, value: mixed, status: string}>
     * }
     */
    public static function seedCompany(string $companyId, ?array $overrides = null, ?string $seedDate = null): array
    {
        $companyId = trim($companyId);
        if ($companyId === '') {
            throw new RuntimeException("Company ID is required to seed rules.");
        }

        if (isset(self::$seedingCompanies[$companyId])) {
            return [
                'company_id'         => $companyId,
                'seeded_domains'     => [],
                'skipped_domains'    => [],
                'needs_confirmation' => [],
            ];
        }
        self::$seedingCompanies[$companyId] = true;

        $effectiveFrom = ($seedDate !== null && trim($seedDate) !== '')
            ? substr(trim($seedDate), 0, 10)
            : date('Y-01-01');

        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $effectiveFrom)) {
            unset(self::$seedingCompanies[$companyId]);
            throw new RuntimeException("Invalid seed date '{$seedDate}'. Expected YYYY-MM-DD.");
        }

        RuleSchemaRegistry::init();
        $domains = RuleSchemaRegistry::domains();

        $db = Database::connect();

        $seededDomains = [];
        $skippedDomains = [];
        $needsConfirmation = [];

        $now = date('Y-m-d H:i:s');

        $db->transBegin();
        try {
            foreach ($domains as $domain) {
                $confirmKeys = RuleSchemaRegistry::confirmKeys($domain);
                $requiresConfirmation = !empty($confirmKeys);

                // Check for existing Active Company-scope rule definition for this company and domain
                $existingActive = $db->table('rule_definitions')
                    ->where('company_id', $companyId)
                    ->where('domain', $domain)
                    ->where('scope_level', 'Company')
                    ->where('status', 'Active')
                    ->get()
                    ->getRowArray();

                if ($existingActive !== null) {
                    if ($domain === 'LEAVE') {
                        self::ensureCompanyLeaveEntitlements($companyId, $effectiveFrom);
                    }
                    $skippedDomains[] = $domain;
                    continue;
                }

                // Also check if a Draft Company-scope rule already exists (from a prior seed awaiting confirmation)
                $existingDraft = $db->table('rule_definitions')
                    ->where('company_id', $companyId)
                    ->where('domain', $domain)
                    ->where('scope_level', 'Company')
                    ->where('status', 'Draft')
                    ->orderBy('version_number', 'DESC')
                    ->get()
                    ->getRowArray();

                if ($existingDraft !== null) {
                    // If no Active rule exists for Company scope, activate this draft rule
                    $db->table('rule_definitions')
                        ->where('id', $existingDraft['id'])
                        ->update([
                            'status'      => 'Active',
                            'approved_by' => 'system_seeder',
                            'updated_at'  => $now,
                        ]);

                    if ($domain === 'LEAVE') {
                        self::ensureCompanyLeaveEntitlements($companyId, $effectiveFrom);
                    }
                    $skippedDomains[] = $domain;
                    $draftParams = json_decode((string)($existingDraft['params_json'] ?? '{}'), true) ?: [];
                    foreach ($confirmKeys as $cKey) {
                        $paramDef = RuleSchemaRegistry::param($domain, $cKey);
                        $needsConfirmation[] = [
                            'domain' => $domain,
                            'key'    => $cKey,
                            'label'  => $paramDef['label'] ?? $cKey,
                            'value'  => $draftParams[$cKey] ?? null,
                            'status' => 'Active',
                        ];
                    }
                    continue;
                }

                // Obtain default seed values from schema
                $seedParams = RuleSchemaRegistry::seedValues($domain);
                $defaultWeeklyOffSeed = $seedParams['weekly_off_days'] ?? null;

                // Apply optional domain overrides if supplied
                if ($overrides !== null && isset($overrides[$domain]) && is_array($overrides[$domain])) {
                    foreach ($overrides[$domain] as $k => $v) {
                        $seedParams[$k] = $v;
                    }
                }

                // Ensure new companies always get weekly_off_days from the schema seed (['Friday']) as an Active ATTENDANCE rule
                if ($domain === 'ATTENDANCE' && empty($seedParams['weekly_off_days']) && !empty($defaultWeeklyOffSeed)) {
                    $seedParams['weekly_off_days'] = $defaultWeeklyOffSeed;
                }

                // Validate the seed params against schema
                $validation = RuleParamValidator::validate($domain, 'Company', $seedParams, false, $companyId);
                if (!$validation['valid']) {
                    $errStr = json_encode($validation['errors']);
                    throw new RuntimeException("Schema seed validation failed for domain '{$domain}': {$errStr}");
                }

                $cleanParams = $validation['clean'];
                $cleanParamsJson = json_encode($cleanParams, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

                // Determine next version number for this (company, domain, Company, null)
                $maxRow = $db->table('rule_definitions')
                    ->selectMax('version_number', 'max_v')
                    ->where('company_id', $companyId)
                    ->where('domain', $domain)
                    ->where('scope_level', 'Company')
                    ->where('scope_id', null)
                    ->get()
                    ->getRowArray();

                $nextVersion = ((int)($maxRow['max_v'] ?? 0)) + 1;
                $newRuleId = 'rd-' . bin2hex(random_bytes(8));

                // Company-scope baseline rules must be Active for operational functionality.
                // confirm:true parameters are surfaced via needs_confirmation for sign-off.
                $seedStatus = 'Active';
                $approvedBy = 'system_seeder';
                $logAction  = 'publish';

                $insertData = [
                    'id'             => $newRuleId,
                    'company_id'     => $companyId,
                    'domain'         => $domain,
                    'scope_level'    => 'Company',
                    'scope_id'       => null,
                    'version_number' => $nextVersion,
                    'effective_from' => $effectiveFrom,
                    'effective_to'   => null,
                    'status'         => $seedStatus,
                    'params_json'    => $cleanParamsJson,
                    'schema_version' => RuleSchemaRegistry::schemaVersion(),
                    'change_reason'  => RuleWriteService::SEED_REASON,
                    'created_by'     => 'system_seeder',
                    'approved_by'    => $approvedBy,
                    'created_at'     => $now,
                    'updated_at'     => $now,
                ];

                $inserted = $db->table('rule_definitions')->insert($insertData);
                if ($inserted === false) {
                    throw new RuntimeException("Failed to insert seeded rule for domain '{$domain}'.");
                }

                // Log action in rule_change_log
                $logged = $db->table('rule_change_log')->insert([
                    'id'              => 'rcl-' . bin2hex(random_bytes(16)),
                    'company_id'      => $companyId,
                    'rule_id'         => $newRuleId,
                    'domain'          => $domain,
                    'action'          => $logAction,
                    'old_params_json' => null,
                    'new_params_json' => $cleanParamsJson,
                    'actor_id'        => 'system_seeder',
                    'reason'          => $insertData['change_reason'],
                    'created_at'      => $now,
                ]);
                if ($logged === false) {
                    throw new RuntimeException("Failed to insert rule_change_log for seeded domain '{$domain}'.");
                }

                $seededDomains[] = $domain;

                // Collect parameters carrying confirm:true for this newly seeded domain
                foreach ($confirmKeys as $cKey) {
                    $paramDef = RuleSchemaRegistry::param($domain, $cKey);
                    $needsConfirmation[] = [
                        'domain' => $domain,
                        'key'    => $cKey,
                        'label'  => $paramDef['label'] ?? $cKey,
                        'value'  => $cleanParams[$cKey] ?? null,
                        'status' => $seedStatus,
                    ];
                }
            }

            if ($db->transStatus() === false) {
                throw new RuntimeException("Database transaction failed while seeding company rules for '{$companyId}'.");
            }
            $db->transCommit();
        } catch (\Throwable $e) {
            $db->transRollback();
            throw $e;
        } finally {
            unset(self::$seedingCompanies[$companyId]);
        }

        RuleResolver::resetMemo();

        return [
            'company_id'         => $companyId,
            'seeded_domains'     => $seededDomains,
            'skipped_domains'    => $skippedDomains,
            'needs_confirmation' => $needsConfirmation,
        ];
    }

    /**
     * Ensures all active leave types for a company and standard seed entitlements
     * (ANNUAL, AL, SL, CL, EL, ML, PL, UL, LWP) exist in the company's rule_definitions (domain: LEAVE).
     * Validates parameters with RuleParamValidator and throws RuntimeException if validation fails (never saves invalid rules).
     *
     * @param string $companyId
     * @param string|null $seedDate Optional seed date if company rules need to be initialized
     * @return array Current complete entitlements list
     */
    public static function ensureCompanyLeaveEntitlements(string $companyId, ?string $seedDate = null): array
    {
        $companyId = trim($companyId);
        if ($companyId === '') {
            return [];
        }

        if (isset(self::$ensuringLeaveEntitlements[$companyId])) {
            return [];
        }
        self::$ensuringLeaveEntitlements[$companyId] = true;

        try {
            RuleSchemaRegistry::init();
            $db = Database::connect();

            if (!$db->tableExists('rule_definitions')) {
                return [];
            }

            $row = $db->table('rule_definitions')
                ->where('company_id', $companyId)
                ->where('domain', 'LEAVE')
                ->where('scope_level', 'Company')
                ->where('status', 'Active')
                ->orderBy('effective_from', 'DESC')
                ->get()
                ->getRowArray();

            if ($row === null) {
                $row = $db->table('rule_definitions')
                    ->where('company_id', $companyId)
                    ->where('domain', 'LEAVE')
                    ->where('scope_level', 'Company')
                    ->where('status', 'Draft')
                    ->orderBy('version_number', 'DESC')
                    ->get()
                    ->getRowArray();
            }

            if ($row === null) {
                // Seed company LEAVE domain if missing (only if not already inside seedCompany)
                if (empty(self::$seedingCompanies[$companyId])) {
                    self::seedCompany($companyId, null, $seedDate ?? date('Y-m-d'));
                }
                $row = $db->table('rule_definitions')
                    ->where('company_id', $companyId)
                    ->where('domain', 'LEAVE')
                    ->where('scope_level', 'Company')
                    ->whereIn('status', ['Active', 'Draft'])
                    ->orderBy('version_number', 'DESC')
                    ->get()
                    ->getRowArray();
            }

            if ($row === null) {
                return [];
            }

        $params = json_decode($row['params_json'] ?? '{}', true) ?: [];
        $currentEntitlements = $params['entitlements'] ?? [];

        $seedParams = RuleSchemaRegistry::seedValues('LEAVE');
        $seedEntitlements = $seedParams['entitlements'] ?? [];

        // Build index of exact codes currently present
        $existingCodesExact = [];
        foreach ($currentEntitlements as $e) {
            $c = strtoupper(trim((string)($e['leave_type_code'] ?? '')));
            if ($c !== '') {
                $existingCodesExact[$c] = true;
            }
        }

        $modified = false;

        $entParamDef = RuleSchemaRegistry::param('LEAVE', 'entitlements');
        $itemFieldSeeds = [];
        if (!empty($entParamDef['item']) && is_array($entParamDef['item'])) {
            foreach ($entParamDef['item'] as $iDef) {
                if (isset($iDef['key']) && array_key_exists('seed', $iDef)) {
                    $itemFieldSeeds[$iDef['key']] = $iDef['seed'];
                }
            }
        }

        // 1. Ensure standard seed entitlements (ANNUAL, AL, SL, CL, EL, ML, PL, UL, LWP) have exact code entries
        foreach ($seedEntitlements as $seedEnt) {
            $sCode = strtoupper(trim((string)($seedEnt['leave_type_code'] ?? '')));
            if ($sCode === '') {
                continue;
            }
            if (!isset($existingCodesExact[$sCode])) {
                // Check if an existing entitlement matches by alias to preserve configured quotas
                $matchedEnt = null;
                foreach ($currentEntitlements as $ce) {
                    $cCode = strtoupper(trim((string)($ce['leave_type_code'] ?? '')));
                    if ($cCode !== '' && \App\Services\Leave\LeaveTypeMatcher::matchLeaveTypeCode($sCode, $cCode)) {
                        $matchedEnt = $ce;
                        break;
                    }
                }

                if ($matchedEnt !== null) {
                    $cloned = $matchedEnt;
                    $cloned['leave_type_code'] = $sCode;
                    $currentEntitlements[] = $cloned;
                } else {
                    $currentEntitlements[] = $seedEnt;
                }
                $existingCodesExact[$sCode] = true;
                $modified = true;
            }
        }

        // 2. Ensure every active record from leave_types table has an exact matching entitlement
        $types = [];
        if ($db->tableExists('leave_types')) {
            $ltBuilder = $db->table('leave_types');
            if ($db->fieldExists('company_id', 'leave_types')) {
                $ltBuilder->groupStart()
                    ->where('company_id', $companyId)
                    ->orWhere('company_id', null)
                    ->orWhere('company_id', '')
                    ->groupEnd();
            }
            $types = $ltBuilder->get()->getResultArray();
            foreach ($types as $lt) {
                $tCode = strtoupper(trim((string)($lt['code'] ?? '')));
                $tName = trim((string)($lt['name'] ?? ''));
                if ($tCode === '') {
                    continue;
                }
                if (!isset($existingCodesExact[$tCode])) {
                    // Check if an existing entitlement matches by alias or name
                    $matchedEnt = null;
                    foreach ($currentEntitlements as $ce) {
                        $cCode = strtoupper(trim((string)($ce['leave_type_code'] ?? '')));
                        if ($cCode !== '' && \App\Services\Leave\LeaveTypeMatcher::matchLeaveTypeCode($tCode, $cCode, $tName)) {
                            $matchedEnt = $ce;
                            break;
                        }
                    }

                    if ($matchedEnt !== null) {
                        $cloned = $matchedEnt;
                        $cloned['leave_type_code'] = $tCode;
                        $currentEntitlements[] = $cloned;
                    } else {
                        // Check if a seed entitlement matches by alias
                        $seedMatch = null;
                        foreach ($seedEntitlements as $se) {
                            $seCode = strtoupper(trim((string)($se['leave_type_code'] ?? '')));
                            if ($seCode !== '' && \App\Services\Leave\LeaveTypeMatcher::matchLeaveTypeCode($tCode, $seCode, $tName)) {
                                $seedMatch = $se;
                                break;
                            }
                        }

                        $currentEntitlements[] = self::buildEntitlementFromSeedAndRow($lt, $seedMatch, $itemFieldSeeds);
                    }
                    $existingCodesExact[$tCode] = true;
                    $modified = true;
                }
            }
        }

        // 3. Ensure all entitlements have complete schema keys from seedValues('LEAVE') + leave_types row
        foreach ($currentEntitlements as &$entItem) {
            $eCode = strtoupper(trim((string)($entItem['leave_type_code'] ?? '')));
            $matchingLt = null;
            if (!empty($types)) {
                foreach ($types as $lt) {
                    $tCode = strtoupper(trim((string)($lt['code'] ?? '')));
                    $tName = trim((string)($lt['name'] ?? ''));
                    if ($tCode === $eCode || \App\Services\Leave\LeaveTypeMatcher::matchLeaveTypeCode($eCode, $tCode, $tName)) {
                        $matchingLt = $lt;
                        break;
                    }
                }
            }
            $matchingSeed = null;
            foreach ($seedEntitlements as $se) {
                $seCode = strtoupper(trim((string)($se['leave_type_code'] ?? '')));
                if ($seCode === $eCode || \App\Services\Leave\LeaveTypeMatcher::matchLeaveTypeCode($eCode, $seCode)) {
                    $matchingSeed = $se;
                    break;
                }
            }

            $baseDefaults = self::buildEntitlementFromSeedAndRow(
                $matchingLt ?? ['code' => $eCode],
                $matchingSeed,
                $itemFieldSeeds
            );

            foreach ($baseDefaults as $defKey => $defVal) {
                if (!array_key_exists($defKey, $entItem) || ($entItem[$defKey] === null && $defVal !== null)) {
                    $entItem[$defKey] = $defVal;
                    $modified = true;
                }
            }
        }
        unset($entItem);

        // Strip any non-schema item properties before validation
        $paramDefs = RuleSchemaRegistry::params('LEAVE');
        $allowedItemKeys = null;
        foreach ($paramDefs as $pDef) {
            if (($pDef['key'] ?? '') === 'entitlements' && isset($pDef['item'])) {
                $allowedItemKeys = array_column($pDef['item'], 'key');
                break;
            }
        }

        if (!empty($allowedItemKeys)) {
            $allowedKeyMap = array_fill_keys($allowedItemKeys, true);
            foreach ($currentEntitlements as &$entItem) {
                $entItem = array_intersect_key($entItem, $allowedKeyMap);
            }
            unset($entItem);
        }

        $params['entitlements'] = $currentEntitlements;

        // Always validate before any save — never save when validation fails: throw
        $validation = RuleParamValidator::validate('LEAVE', 'Company', $params, false, $companyId);
        if (!$validation['valid']) {
            $errStr = json_encode($validation['errors']);
            throw new RuntimeException("Leave entitlements validation failed for company '{$companyId}': {$errStr}");
        }

        if ($modified) {
            $cleanParams = $validation['clean'];
            $existingFrom = substr((string)$row['effective_from'], 0, 10);
            $effectiveFrom = date('Y-m-d');
            if ($existingFrom >= $effectiveFrom) {
                $effectiveFrom = date('Y-m-d', strtotime($existingFrom . ' + 1 day'));
            }

            $writeService = new RuleWriteService($db);
            if (($row['status'] ?? '') === 'Draft') {
                $writeService->updateDraft(
                    (string)$row['id'],
                    $cleanParams,
                    'system_backfill',
                    'Backfill missing leave entitlements to Single Rule Store',
                    $existingFrom,
                    $row['effective_to'] ?? null
                );
            } else {
                $writeService->publishCompanyRule(
                    $companyId,
                    'LEAVE',
                    $cleanParams,
                    'system_backfill',
                    'Backfill missing leave entitlements to Single Rule Store',
                    $effectiveFrom,
                    null,
                    true
                );
            }

            RuleResolver::resetMemo();
            return $cleanParams['entitlements'] ?? $currentEntitlements;
        }

        return $validation['clean']['entitlements'] ?? $currentEntitlements;
        } finally {
            unset(self::$ensuringLeaveEntitlements[$companyId]);
        }
    }

    /**
     * Build a leave entitlement item strictly from RuleSchemaRegistry::seedValues('LEAVE')
     * (plus item field seed defaults) and the leave_types row, with no invented defaults.
     */
    private static function buildEntitlementFromSeedAndRow(array $lt, ?array $seedTemplate, array $itemFieldSeeds): array
    {
        $ent = $itemFieldSeeds;
        if (is_array($seedTemplate)) {
            foreach ($seedTemplate as $k => $v) {
                $ent[$k] = $v;
            }
        }

        $tCode = strtoupper(trim((string)($lt['code'] ?? ($seedTemplate['leave_type_code'] ?? ''))));
        $ent['leave_type_code'] = $tCode;

        if (!empty($lt['applicable_gender'])) {
            $ent['applicable_gender'] = (string)$lt['applicable_gender'];
        }
        if (isset($lt['days_per_year']) && $lt['days_per_year'] !== '') {
            $ent['days_per_year'] = (float)$lt['days_per_year'];
        } elseif (isset($lt['annual_allocation']) && $lt['annual_allocation'] !== '') {
            $ent['days_per_year'] = (float)$lt['annual_allocation'];
        }
        if (array_key_exists('is_paid', $lt) && $lt['is_paid'] !== null && $lt['is_paid'] !== '') {
            $ent['is_paid'] = (bool)$lt['is_paid'];
        }
        if (isset($lt['paid_percentage']) && $lt['paid_percentage'] !== '') {
            $ent['paid_percentage'] = (int)$lt['paid_percentage'];
        }
        if (!empty($lt['accrual_mode'])) {
            $ent['accrual_mode'] = (string)$lt['accrual_mode'];
        }
        if (isset($lt['earn_every_days']) && $lt['earn_every_days'] !== '') {
            $ent['earn_every_days'] = (int)$lt['earn_every_days'];
        }
        if (isset($lt['earn_leave_per_cycle']) && $lt['earn_leave_per_cycle'] !== '') {
            $ent['earn_leave_per_cycle'] = (float)$lt['earn_leave_per_cycle'];
        }
        if (!empty($lt['accrual_credit_timing'])) {
            $ent['accrual_credit_timing'] = (string)$lt['accrual_credit_timing'];
        }
        if (!empty($lt['accrual_start_from'])) {
            $ent['accrual_start_from'] = (string)$lt['accrual_start_from'];
        }
        if (!empty($lt['accrual_fixed_start_date'])) {
            $ent['accrual_fixed_start_date'] = (string)$lt['accrual_fixed_start_date'];
        }
        if (isset($lt['max_balance_cap']) && $lt['max_balance_cap'] !== '') {
            $ent['max_balance_cap'] = (float)$lt['max_balance_cap'];
        }
        if (isset($lt['accrual_rate_per_month']) && $lt['accrual_rate_per_month'] !== '') {
            $ent['accrual_rate_per_month'] = (float)$lt['accrual_rate_per_month'];
        }
        if (!empty($lt['accrual_timing'])) {
            $ent['accrual_timing'] = (string)$lt['accrual_timing'];
        }
        if (isset($lt['allow_carry_forward']) && $lt['allow_carry_forward'] !== '') {
            $ent['carry_forward_allowed'] = (bool)$lt['allow_carry_forward'];
        } elseif (isset($lt['carry_forward_allowed']) && $lt['carry_forward_allowed'] !== '') {
            $ent['carry_forward_allowed'] = (bool)$lt['carry_forward_allowed'];
        }
        if (isset($lt['max_carry_forward_days']) && $lt['max_carry_forward_days'] !== '') {
            $ent['carry_forward_max_days'] = (float)$lt['max_carry_forward_days'];
        } elseif (isset($lt['carry_forward_max_days']) && $lt['carry_forward_max_days'] !== '') {
            $ent['carry_forward_max_days'] = (float)$lt['carry_forward_max_days'];
        }
        if (isset($lt['carry_forward_percentage']) && $lt['carry_forward_percentage'] !== '') {
            $ent['carry_forward_percentage'] = (int)$lt['carry_forward_percentage'];
        }
        if (isset($lt['carry_forward_expiry_months']) && $lt['carry_forward_expiry_months'] !== '') {
            $ent['carry_forward_expiry_months'] = (int)$lt['carry_forward_expiry_months'];
        }
        if (isset($lt['max_consecutive_days']) && $lt['max_consecutive_days'] !== '') {
            $ent['max_consecutive_days'] = (int)$lt['max_consecutive_days'];
        }
        if (isset($lt['min_notice_days']) && $lt['min_notice_days'] !== '') {
            $ent['min_notice_days'] = (int)$lt['min_notice_days'];
        }
        if (isset($lt['allow_half_day']) && $lt['allow_half_day'] !== '') {
            $ent['allow_half_day'] = (bool)$lt['allow_half_day'];
        }
        if (isset($lt['allow_negative_balance']) && $lt['allow_negative_balance'] !== '') {
            $ent['allow_negative_balance'] = (bool)$lt['allow_negative_balance'];
        }
        if (isset($lt['max_negative_days']) && $lt['max_negative_days'] !== '') {
            $ent['max_negative_days'] = (int)$lt['max_negative_days'];
        }
        if (isset($lt['allow_backdated_application']) && $lt['allow_backdated_application'] !== '') {
            $ent['allow_backdated_application'] = (bool)$lt['allow_backdated_application'];
        }
        if (isset($lt['max_backdate_days']) && $lt['max_backdate_days'] !== '') {
            $ent['max_backdate_days'] = (int)$lt['max_backdate_days'];
        }
        if (array_key_exists('backdated_role_requirement', $lt) && $lt['backdated_role_requirement'] !== null) {
            $ent['backdated_role_requirement'] = (string)$lt['backdated_role_requirement'];
        }
        if (isset($lt['allow_future_application']) && $lt['allow_future_application'] !== '') {
            $ent['allow_future_application'] = (bool)$lt['allow_future_application'];
        }
        if (isset($lt['max_future_days']) && $lt['max_future_days'] !== '') {
            $ent['max_future_days'] = (int)$lt['max_future_days'];
        }
        if (isset($lt['sandwich_rule']) && $lt['sandwich_rule'] !== '') {
            $ent['sandwich_rule'] = (bool)$lt['sandwich_rule'];
        }
        if (isset($lt['requires_attachment']) && $lt['requires_attachment'] !== '') {
            $ent['attachment_required'] = (bool)$lt['requires_attachment'];
        } elseif (isset($lt['attachment_required']) && $lt['attachment_required'] !== '') {
            $ent['attachment_required'] = (bool)$lt['attachment_required'];
        }
        if (isset($lt['requires_approval']) && $lt['requires_approval'] !== '') {
            $ent['approval_required'] = (bool)$lt['requires_approval'];
        } elseif (isset($lt['approval_required']) && $lt['approval_required'] !== '') {
            $ent['approval_required'] = (bool)$lt['approval_required'];
        }
        if (isset($lt['is_auto_approved']) && $lt['is_auto_approved'] !== '') {
            $ent['is_auto_approved'] = (bool)$lt['is_auto_approved'];
        }
        if (isset($lt['counts_as_working_day']) && $lt['counts_as_working_day'] !== '') {
            $ent['counts_as_working_day'] = (bool)$lt['counts_as_working_day'];
        }
        if (isset($lt['affects_payroll']) && $lt['affects_payroll'] !== '') {
            $ent['affects_payroll'] = (bool)$lt['affects_payroll'];
        }
        if (isset($lt['allow_encashment']) && $lt['allow_encashment'] !== '') {
            $ent['encashment_allowed'] = (bool)$lt['allow_encashment'];
        } elseif (isset($lt['encashment_allowed']) && $lt['encashment_allowed'] !== '') {
            $ent['encashment_allowed'] = (bool)$lt['encashment_allowed'];
        }
        if (isset($lt['max_encashment_days']) && $lt['max_encashment_days'] !== '') {
            $ent['encashment_max_days'] = (float)$lt['max_encashment_days'];
        } elseif (isset($lt['encashment_max_days']) && $lt['encashment_max_days'] !== '') {
            $ent['encashment_max_days'] = (float)$lt['encashment_max_days'];
        }
        if (isset($lt['min_balance_for_encashment']) && $lt['min_balance_for_encashment'] !== '') {
            $ent['encashment_min_balance_days'] = (float)$lt['min_balance_for_encashment'];
        } elseif (isset($lt['encashment_min_balance_days']) && $lt['encashment_min_balance_days'] !== '') {
            $ent['encashment_min_balance_days'] = (float)$lt['encashment_min_balance_days'];
        }
        if (!empty($lt['encashment_frequency'])) {
            $ent['encashment_frequency'] = (string)$lt['encashment_frequency'];
        }
        if (!empty($lt['encashment_salary_basis'])) {
            $ent['encashment_salary_basis'] = (string)$lt['encashment_salary_basis'];
        }
        if (isset($lt['encashment_divisor']) && $lt['encashment_divisor'] !== '') {
            $ent['encashment_divisor'] = (int)$lt['encashment_divisor'];
        }
        if (array_key_exists('encashment_formula', $lt) && $lt['encashment_formula'] !== null) {
            $ent['encashment_formula'] = (string)$lt['encashment_formula'];
        }
        if (isset($lt['requires_reason']) && $lt['requires_reason'] !== '') {
            $ent['requires_reason'] = (bool)$lt['requires_reason'];
        }
        if (isset($lt['requires_medical_certificate']) && $lt['requires_medical_certificate'] !== '') {
            $ent['requires_medical_certificate'] = (bool)$lt['requires_medical_certificate'];
        }
        if (isset($lt['medical_certificate_threshold_days']) && $lt['medical_certificate_threshold_days'] !== '') {
            $ent['medical_certificate_threshold_days'] = (int)$lt['medical_certificate_threshold_days'];
        }
        if (isset($lt['allow_hourly_leave']) && $lt['allow_hourly_leave'] !== '') {
            $ent['allow_hourly_leave'] = (bool)$lt['allow_hourly_leave'];
        }
        if (isset($lt['min_hourly_hours']) && $lt['min_hourly_hours'] !== '') {
            $ent['min_hourly_hours'] = (float)$lt['min_hourly_hours'];
        }
        if (isset($lt['max_hourly_hours']) && $lt['max_hourly_hours'] !== '') {
            $ent['max_hourly_hours'] = (float)$lt['max_hourly_hours'];
        }
        if (isset($lt['allow_unpaid_split']) && $lt['allow_unpaid_split'] !== '') {
            $ent['allow_unpaid_split'] = (bool)$lt['allow_unpaid_split'];
        }
        if (isset($lt['allow_emergency_absence']) && $lt['allow_emergency_absence'] !== '') {
            $ent['allow_emergency_absence'] = (bool)$lt['allow_emergency_absence'];
        }

        return $ent;
    }
}
