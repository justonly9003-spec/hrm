<?php

namespace App\Services\Rules;

/**
 * PayrollBasics
 *
 * Single source of truth for basic payroll parameters:
 * - Currency code
 *
 * Parameters are resolved exclusively via RuleResolver from domain PAYROLL_BASICS.
 */
class PayrollBasics
{
    protected RuleResolver $resolver;

    public function __construct(?RuleResolver $resolver = null)
    {
        $this->resolver = $resolver ?? new RuleResolver();
    }

    /**
     * Get 3-letter currency code from PAYROLL_BASICS.
     *
     * @param string $companyId
     * @param array|string|null $employee
     * @param string|null $date
     * @return string
     * @throws RuleNotConfiguredException
     * @throws RuleKeyMissingException
     */
    public function currencyCode(string $companyId, array|string|null $employee = null, ?string $date = null): string
    {
        $date = $date ?: date('Y-m-d');
        $rule = $this->resolver->resolve($companyId, 'PAYROLL_BASICS', $date, $employee);
        return (string)$rule->get('currency_code');
    }

    /**
     * Get money_decimals from PAYROLL_BASICS.
     *
     * @param string $companyId
     * @param array|string|null $employee
     * @param string|null $date
     * @return int
     * @throws RuleNotConfiguredException
     * @throws RuleKeyMissingException
     */
    public function moneyDecimals(string $companyId, array|string|null $employee = null, ?string $date = null): int
    {
        $date = $date ?: date('Y-m-d');
        $rule = $this->resolver->resolve($companyId, 'PAYROLL_BASICS', $date, $employee);
        return (int)$rule->get('money_decimals');
    }

    /**
     * Get minimum net salary floor from PAYROLL_BASICS (default 0.0, 0 means no floor).
     *
     * @param string $companyId
     * @param array|string|null $employee
     * @param string|null $date
     * @return float
     * @throws RuleNotConfiguredException
     */
    public function minimumNetSalaryFloor(string $companyId, array|string|null $employee = null, ?string $date = null): float
    {
        $date = $date ?: date('Y-m-d');
        $rule = $this->resolver->resolve($companyId, 'PAYROLL_BASICS', $date, $employee);
        return $rule->has('minimum_net_salary_floor') ? (float)$rule->get('minimum_net_salary_floor') : 0.0;
    }
}

