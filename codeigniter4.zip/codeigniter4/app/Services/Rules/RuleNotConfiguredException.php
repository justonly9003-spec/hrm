<?php

namespace App\Services\Rules;

use RuntimeException;

class RuleNotConfiguredException extends RuntimeException
{
    protected ?string $companyId = null;
    protected ?string $domain = null;
    protected ?string $date = null;

    public function __construct(
        string $message = '',
        ?string $companyId = null,
        ?string $domain = null,
        ?string $date = null,
        int $code = 0,
        ?\Throwable $previous = null
    ) {
        $this->companyId = $companyId;
        $this->domain    = $domain;
        $this->date      = $date;
        parent::__construct($message, $code, $previous);
    }

    public static function forDomain(string $companyId, string $domain, ?string $date = null, string $reason = 'No active Company rule configured'): self
    {
        $message = "Rule not configured for company '{$companyId}', domain '{$domain}'"
            . ($date !== null ? " on date '{$date}'" : "")
            . ": {$reason}";
        return new self($message, $companyId, $domain, $date);
    }

    public function getCompanyId(): ?string
    {
        return $this->companyId;
    }

    public function getDomain(): ?string
    {
        return $this->domain;
    }

    public function getDate(): ?string
    {
        return $this->date;
    }
}
