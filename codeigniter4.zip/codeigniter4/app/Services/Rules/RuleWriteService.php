<?php

namespace App\Services\Rules;

use App\Models\RuleDefinitionModel;
use App\Services\AuditService;
use CodeIgniter\Database\BaseConnection;
use Config\Database;

class RuleWriteService
{
    public const SEED_REASON = 'Initial system default seed v1';
    public const MAKER_CHECKER_MODULE_CODE = 'rules_maker_checker';

    protected BaseConnection $db;
    protected RuleDefinitionModel $ruleModel;

    /**
     * In-memory company setting overrides for maker-checker (used in runtime/tests when DB table is not present).
     *
     * @var array<string, bool>
     */
    protected static array $makerCheckerOverrides = [];

    public function __construct(?BaseConnection $db = null, ?RuleDefinitionModel $ruleModel = null)
    {
        $this->db = $db ?? Database::connect();
        $this->ruleModel = $ruleModel ?? new RuleDefinitionModel();
    }

    /**
     * Check whether maker-checker is enabled for a company.
     * This is a PAYROLL_BASICS-independent company setting and is off (false) by default.
     */
    public function isMakerCheckerEnabled(string $companyId): bool
    {
        $companyId = trim($companyId);
        if ($companyId === '') {
            return false;
        }

        if (array_key_exists($companyId, self::$makerCheckerOverrides)) {
            return self::$makerCheckerOverrides[$companyId];
        }

        try {
            if ($this->db->tableExists('companies') && $this->db->fieldExists('rules_maker_checker_enabled', 'companies')) {
                $compRow = $this->db->table('companies')
                    ->select('rules_maker_checker_enabled')
                    ->where('id', $companyId)
                    ->get()
                    ->getRowArray();
                if ($compRow !== null && isset($compRow['rules_maker_checker_enabled'])) {
                    return (int)$compRow['rules_maker_checker_enabled'] === 1 || $compRow['rules_maker_checker_enabled'] === true;
                }
            }

            if ($this->db->tableExists('company_modules')) {
                $modRow = $this->db->table('company_modules')
                    ->select('is_enabled')
                    ->where('company_id', $companyId)
                    ->where('module_code', self::MAKER_CHECKER_MODULE_CODE)
                    ->get()
                    ->getRowArray();
                if ($modRow !== null && isset($modRow['is_enabled'])) {
                    return (int)$modRow['is_enabled'] === 1 || $modRow['is_enabled'] === true;
                }
            }
        } catch (\Throwable $e) {
            log_message('warning', "Failed to read maker-checker setting for company {$companyId}: " . $e->getMessage());
        }

        return false;
    }

    /**
     * Enable or disable maker-checker for a company (PAYROLL_BASICS-independent company setting).
     */
    public function setMakerCheckerEnabled(string $companyId, bool $enabled): void
    {
        $companyId = trim($companyId);
        if ($companyId === '') {
            throw new \InvalidArgumentException('Company ID is required to configure maker-checker.');
        }

        self::$makerCheckerOverrides[$companyId] = $enabled;

        try {
            if ($this->db->tableExists('companies') && $this->db->fieldExists('rules_maker_checker_enabled', 'companies')) {
                $this->db->table('companies')
                    ->where('id', $companyId)
                    ->update([
                        'rules_maker_checker_enabled' => $enabled ? 1 : 0,
                        'updated_at'                  => date('Y-m-d H:i:s'),
                    ]);
            }

            if ($this->db->tableExists('company_modules')) {
                $cleanCode = preg_replace('/[^A-Za-z0-9]/', '', $companyId);
                $now = date('Y-m-d H:i:s');
                $existing = $this->db->table('company_modules')
                    ->where('company_id', $companyId)
                    ->where('module_code', self::MAKER_CHECKER_MODULE_CODE)
                    ->get()
                    ->getRowArray();

                if ($existing) {
                    $this->db->table('company_modules')
                        ->where('id', $existing['id'])
                        ->update([
                            'is_enabled' => $enabled ? 1 : 0,
                            'updated_at' => $now,
                        ]);
                } else {
                    $this->db->table('company_modules')->insert([
                        'id'          => 'CMOD-' . substr($cleanCode, 0, 16) . '-MAKER_CHECKER',
                        'company_id'  => $companyId,
                        'module_code' => self::MAKER_CHECKER_MODULE_CODE,
                        'is_enabled'  => $enabled ? 1 : 0,
                        'created_at'  => $now,
                        'updated_at'  => $now,
                    ]);
                }
            }
        } catch (\Throwable $e) {
            log_message('warning', "Failed to persist maker-checker setting for company {$companyId}: " . $e->getMessage());
        }
    }

    /**
     * Reset in-memory maker-checker overrides (for tests).
     */
    public static function resetMakerCheckerOverrides(): void
    {
        self::$makerCheckerOverrides = [];
    }

    /**
     * Determine whether the given actor is a Software App Admin.
     */
    public function isActorSoftwareAppAdmin(string $actorId): bool
    {
        $actorId = trim($actorId);
        if ($actorId === '') {
            return false;
        }

        // Check active session if it belongs to $actorId
        try {
            $session = \Config\Services::session(false);
            if ($session && (string)$session->get('user_id') === $actorId) {
                $userCompanyId = $session->get('company_id');
                $roleCompanyId = $session->get('role_company_id');
                $isSystem = (int)($session->get('role_is_system') ?? 0) === 1;
                $role = (string)($session->get('role_code') ?? $session->get('role') ?? $session->get('role_name') ?? '');
                $permService = new \App\Services\PermissionService();
                if (empty($userCompanyId) && empty($roleCompanyId) && $isSystem && $permService->canonicalizeRole($role) === 'software_app_admin') {
                    return true;
                }
            }
        } catch (\Throwable $e) {
            // Ignore session errors in CLI/non-web context
        }

        try {
            if ($this->db->tableExists('users')) {
                $userModel = new \App\Models\UserModel();
                $userRow = $userModel->getUserWithEmployeeContext($actorId);
                if (is_array($userRow)) {
                    $userCompanyId = $userRow['company_id'] ?? null;
                    $roleCompanyId = $userRow['role_company_id'] ?? null;
                    $isSystem = (int)($userRow['role_is_system'] ?? 0) === 1;
                    $userRole = (string)($userRow['role_name'] ?? $userRow['role_code'] ?? '');
                    $permService = new \App\Services\PermissionService();
                    if (empty($userCompanyId) && empty($roleCompanyId) && $isSystem && $permService->canonicalizeRole($userRole) === 'software_app_admin') {
                        return true;
                    }
                }
            }
        } catch (\Throwable $e) {
            // Fall through to false
        }

        return false;
    }

    /**
     * Validate that bonus schemes referenced in existing bonus_records cannot be deleted or have their code renamed.
     * Schemes may only be deactivated by setting status to 'Inactive'.
     * Fails closed on any database or runtime exception.
     *
     * @param string $companyId
     * @param array $newSchemes Array of submitted schemes
     * @param array|null $priorSchemes Prior schemes array or null to inspect all existing versions
     * @return string|null Error string or null if valid
     */
    public function validateNoLockedBonusSchemeDeletion(string $companyId, array $newSchemes, ?array $priorSchemes = null): ?string
    {
        try {
            if (!$this->db->tableExists('bonus_records')) {
                throw new \RuntimeException('Required table bonus_records is not accessible.');
            }

            // Columns queried: scheme_code, scheme_id, bonus_title
            $query = $this->db->table('bonus_records')
                ->select('scheme_code, scheme_id, bonus_title')
                ->where('company_id', $companyId)
                ->get();

            if ($query === false) {
                throw new \RuntimeException('Failed to query bonus_records for locked scheme verification.');
            }

            $records = $query->getResultArray();
            if (empty($records)) {
                return null;
            }

            $lockedCodes = [];
            $lockedTitles = [];
            foreach ($records as $r) {
                $hasCode = !empty($r['scheme_code']);
                $hasId   = !empty($r['scheme_id']);

                if ($hasCode) {
                    $lockedCodes[strtoupper(trim((string)$r['scheme_code']))] = true;
                }
                if ($hasId) {
                    $lockedCodes[strtoupper(trim((string)$r['scheme_id']))] = true;
                }

                // Use bonus_title matching ONLY when a record has both scheme_code and scheme_id empty
                if (!$hasCode && !$hasId && !empty($r['bonus_title'])) {
                    $rawTitle = trim((string)$r['bonus_title']);
                    $lockedTitles[strtolower($rawTitle)] = true;
                }
            }

            // Gather all prior schemes across all versions in rule_definitions for this company
            $allPrior = [];
            if ($priorSchemes !== null && is_array($priorSchemes)) {
                foreach ($priorSchemes as $sc) {
                    $c = strtoupper(trim((string)($sc['code'] ?? '')));
                    if ($c !== '') {
                        $allPrior[$c] = $sc;
                    }
                }
            }

            $existingRules = $this->ruleModel->where('company_id', $companyId)
                ->where('domain', 'BONUS')
                ->findAll();
            foreach ($existingRules as $er) {
                $p = json_decode((string)$er['params_json'], true);
                if (is_array($p) && isset($p['schemes']) && is_array($p['schemes'])) {
                    foreach ($p['schemes'] as $sc) {
                        $c = strtoupper(trim((string)($sc['code'] ?? '')));
                        if ($c !== '' && !isset($allPrior[$c])) {
                            $allPrior[$c] = $sc;
                        }
                    }
                }
            }
            $priorSchemes = array_values($allPrior);

            $newCodes = [];
            foreach ($newSchemes as $ns) {
                if (!empty($ns['code'])) {
                    $newCodes[strtoupper(trim((string)$ns['code']))] = true;
                }
            }

            foreach ($priorSchemes as $ps) {
                $oldCode = strtoupper(trim((string)($ps['code'] ?? '')));
                $oldName = strtolower(trim((string)($ps['name'] ?? '')));
                $oldId   = !empty($ps['id']) ? strtoupper(trim((string)$ps['id'])) : '';
                if ($oldCode === '') {
                    continue;
                }

                $isLocked = isset($lockedCodes[$oldCode])
                    || ($oldId !== '' && isset($lockedCodes[$oldId]))
                    || ($oldName !== '' && isset($lockedTitles[$oldName]));

                if ($isLocked && !isset($newCodes[$oldCode])) {
                    return "Bonus scheme '{$oldCode}' cannot be deleted or have its code renamed because existing bonus records reference it. You may deactivate it by setting status to Inactive instead.";
                }
            }
        } catch (\Throwable $e) {
            log_message('error', "validateNoLockedBonusSchemeDeletion failed for company {$companyId}: " . $e->getMessage());
            return 'Unable to verify locked bonus schemes due to a database error. Saving bonus schemes has been blocked for safety.';
        }

        return null;
    }

    /**
     * Publish a business rule version (Company, Employee, or any allowed scope).
     * Validates schema, checks ranges, closes predecessor at (effective_from - 1 day),
     * inserts Active rule version into rule_definitions, and logs to rule_change_log and AuditService.
     *
     * @param string $companyId Tenant ID
     * @param string $domain PAYROLL_BASICS, ATTENDANCE, OVERTIME, LEAVE, BONUS, PF, GRATUITY, SETTLEMENT, TAX
     * @param string $scopeLevel Company, Branch, Department, Designation, Shift, Employee
     * @param string|null $scopeId Target ID (null for Company)
     * @param array $params Parameter array
     * @param string $actorId User ID
     * @param string $reason Change reason (mandatory for any non-Company scope and for modifying Active rules)
     * @param string|null $effectiveFrom Start date (defaults to today)
     * @param string|null $effectiveTo End date (optional, null = open)
     * @param bool|null $isSoftwareAppAdmin Optional explicit Software App Admin flag
     * @return array Created/Published rule definition array
     */
    public function publishRule(
        string $companyId,
        string $domain,
        string $scopeLevel,
        ?string $scopeId,
        array $params,
        string $actorId,
        string $reason,
        ?string $effectiveFrom = null,
        ?string $effectiveTo = null,
        ?bool $isSoftwareAppAdmin = null
    ): array {
        RuleSchemaRegistry::init();
        $domain = strtoupper(trim($domain));

        $domainDef = RuleSchemaRegistry::domain($domain);
        if ($domainDef === null) {
            throw new \InvalidArgumentException("Unknown rule domain '{$domain}'.");
        }

        $allowedScopes = RuleSchemaRegistry::allowedScopes($domain);
        if (!in_array($scopeLevel, $allowedScopes, true)) {
            throw new \InvalidArgumentException("Scope level '{$scopeLevel}' is not allowed for domain '{$domain}'. Allowed scopes: " . implode(', ', $allowedScopes));
        }

        if ($scopeLevel === 'Company') {
            $scopeId = null;
        } elseif (empty($scopeId)) {
            throw new \InvalidArgumentException("scope_id is required for scope level '{$scopeLevel}'.");
        }

        if ($scopeLevel === 'Employee' && !empty($scopeId)) {
            $scopeId = $this->resolveCanonicalScopeId($companyId, $scopeLevel, $scopeId);
        }

        $reason = trim($reason);
        if ($scopeLevel !== 'Company' && ($reason === '' || strcasecmp($reason, self::SEED_REASON) === 0)) {
            throw new \InvalidArgumentException("An override reason is mandatory when configuring a {$scopeLevel}-specific rule override.");
        }

        if ($this->isMakerCheckerEnabled($companyId)) {
            $isSuperAdmin = $isSoftwareAppAdmin ?? $this->isActorSoftwareAppAdmin($actorId);
            if (!$isSuperAdmin) {
                throw new \RuntimeException("Maker-checker policy violation: the publisher must differ from the creator. Please save a Draft first and have another authorized user publish it.");
            }
        }

        $effectiveFrom = !empty($effectiveFrom) ? substr((string)$effectiveFrom, 0, 10) : date('Y-m-d');
        $effectiveTo = !empty($effectiveTo) ? substr((string)$effectiveTo, 0, 10) : null;

        if ($effectiveTo !== null && $effectiveTo < $effectiveFrom) {
            throw new \InvalidArgumentException("Effective to date ({$effectiveTo}) cannot be before effective from date ({$effectiveFrom}).");
        }

        // If Company scope, merge over active existing company rule parameters so partial updates retain other required fields
        if ($scopeLevel === 'Company') {
            $existingActive = $this->ruleModel->where('company_id', $companyId)
                ->where('domain', $domain)
                ->where('scope_level', 'Company')
                ->where('status', 'Active')
                ->orderBy('effective_from', 'DESC')
                ->first();
            if ($existingActive) {
                $curParams = $this->ruleModel->paramsOf($existingActive);
                $params = array_merge($curParams, $params);
            }
        }

        $partial = ($scopeLevel !== 'Company');
        $valResult = RuleParamValidator::validate($domain, $scopeLevel, $params, $partial, $companyId);
        if (!$valResult['valid']) {
            $errStr = json_encode($valResult['errors']);
            throw new \InvalidArgumentException("Rule parameters failed schema validation: {$errStr}");
        }

        if ($domain === 'BONUS' && isset($valResult['clean']['schemes']) && is_array($valResult['clean']['schemes'])) {
            $lockErr = $this->validateNoLockedBonusSchemeDeletion($companyId, $valResult['clean']['schemes']);
            if ($lockErr !== null) {
                throw new \InvalidArgumentException($lockErr);
            }
        }

        $cleanParamsJson = json_encode($valResult['clean'], JSON_UNESCAPED_SLASHES);

        $this->db->transBegin();
        try {
            // Find active rules for the exact same scope
            $builder = $this->db->table('rule_definitions')
                ->where('company_id', $companyId)
                ->where('domain', $domain)
                ->where('scope_level', $scopeLevel)
                ->where('status', 'Active');

            if ($scopeId === null) {
                $builder->where('scope_id', null);
            } else {
                $builder->where('scope_id', $scopeId);
            }

            $activeRules = $builder->orderBy('effective_from', 'ASC')->get()->getResultArray();

            $predecessorToClose = null;
            foreach ($activeRules as $ar) {
                $arFrom = substr((string)$ar['effective_from'], 0, 10);
                $arTo = !empty($ar['effective_to']) ? substr((string)$ar['effective_to'], 0, 10) : null;

                if ($arFrom < $effectiveFrom) {
                    if ($arTo === null || $arTo >= $effectiveFrom) {
                        if ($predecessorToClose === null || $arFrom > substr((string)$predecessorToClose['effective_from'], 0, 10)) {
                            $predecessorToClose = $ar;
                        }
                    }
                }
            }

            $closedDate = date('Y-m-d', strtotime($effectiveFrom . ' - 1 day'));
            if ($predecessorToClose !== null) {
                $predFrom = substr((string)$predecessorToClose['effective_from'], 0, 10);
                if ($closedDate < $predFrom) {
                    throw new \RuntimeException("Cannot publish: previous active version starts on {$predFrom} which conflicts with effective date {$effectiveFrom}.");
                }
            }

            $infinity = '9999-12-31';
            $candidateEnd = $effectiveTo ?? $infinity;

            foreach ($activeRules as $ar) {
                $arFrom = substr((string)$ar['effective_from'], 0, 10);
                $arTo = !empty($ar['effective_to']) ? substr((string)$ar['effective_to'], 0, 10) : $infinity;

                if ($predecessorToClose !== null && $ar['id'] === $predecessorToClose['id']) {
                    $arTo = $closedDate;
                }

                if ($effectiveFrom <= $arTo && $arFrom <= $candidateEnd) {
                    $activeVersion = $ar['version_number'] ?? '?';
                    $actFrom = substr((string)$ar['effective_from'], 0, 10);
                    $actTo = !empty($ar['effective_to']) ? substr((string)$ar['effective_to'], 0, 10) : 'open-ended';
                    $newEndStr = $effectiveTo ?? 'open-ended';
                    throw new \RuntimeException("Cannot publish: effective range [{$effectiveFrom} to {$newEndStr}] overlaps with existing Active version {$activeVersion} [{$actFrom} to {$actTo}].");
                }
            }

            // Close predecessor
            if ($predecessorToClose !== null) {
                $this->db->table('rule_definitions')
                    ->where('id', $predecessorToClose['id'])
                    ->update([
                        'effective_to' => $closedDate,
                        'updated_at'   => date('Y-m-d H:i:s'),
                    ]);

                $this->db->table('rule_change_log')->insert([
                    'id'              => 'rcl-' . bin2hex(random_bytes(16)),
                    'company_id'      => $companyId,
                    'rule_id'         => $predecessorToClose['id'],
                    'domain'          => $domain,
                    'action'          => 'update',
                    'old_params_json' => $predecessorToClose['params_json'],
                    'new_params_json' => $predecessorToClose['params_json'],
                    'actor_id'        => $actorId,
                    'reason'          => "Closed effective_to to {$closedDate} due to publication of new version",
                    'created_at'      => date('Y-m-d H:i:s'),
                ]);
            }

            // Determine next version number
            $maxRow = $this->db->table('rule_definitions')
                ->selectMax('version_number', 'max_v')
                ->where('company_id', $companyId)
                ->where('domain', $domain)
                ->where('scope_level', $scopeLevel);
            if ($scopeId === null) {
                $maxRow->where('scope_id', null);
            } else {
                $maxRow->where('scope_id', $scopeId);
            }
            $maxResult = $maxRow->get()->getRowArray();
            $nextVersion = ((int)($maxResult['max_v'] ?? 0)) + 1;

            $newId = 'rd-' . bin2hex(random_bytes(8));
            $now = date('Y-m-d H:i:s');
            $insertData = [
                'id'             => $newId,
                'company_id'     => $companyId,
                'domain'         => $domain,
                'scope_level'    => $scopeLevel,
                'scope_id'       => $scopeId,
                'version_number' => $nextVersion,
                'effective_from' => $effectiveFrom,
                'effective_to'   => $effectiveTo,
                'status'         => 'Active',
                'params_json'    => $cleanParamsJson,
                'schema_version' => RuleSchemaRegistry::schemaVersion(),
                'change_reason'  => $reason !== '' ? $reason : null,
                'created_by'     => $actorId,
                'approved_by'    => $actorId,
                'created_at'     => $now,
                'updated_at'     => $now,
            ];
            $this->db->table('rule_definitions')->insert($insertData);

            $this->db->table('rule_change_log')->insert([
                'id'              => 'rcl-' . bin2hex(random_bytes(16)),
                'company_id'      => $companyId,
                'rule_id'         => $newId,
                'domain'          => $domain,
                'action'          => 'publish',
                'old_params_json' => null,
                'new_params_json' => $cleanParamsJson,
                'actor_id'        => $actorId,
                'reason'          => $reason !== '' ? $reason : 'Published rule version',
                'created_at'      => $now,
            ]);

            if ($this->db->transStatus() === false) {
                throw new \RuntimeException("Transaction failed while publishing rule {$domain}.");
            }
            $this->db->transCommit();

            if (strtoupper((string)$domain) === 'ATTENDANCE' && class_exists(\App\Services\CompanyWeekendService::class)) {
                if ($scopeLevel === 'Company' && !empty($valResult['clean']['weekly_off_days']) && is_array($valResult['clean']['weekly_off_days'])) {
                    \App\Services\CompanyWeekendService::syncCompanyMirror($companyId, $valResult['clean']['weekly_off_days']);
                }
                \App\Services\CompanyWeekendService::clearCache($companyId);
            }
            if (method_exists(RuleResolver::class, 'flushAll')) {
                RuleResolver::flushAll();
            } else {
                RuleResolver::flush(true);
            }
        } catch (\Throwable $e) {
            $this->db->transRollback();
            throw $e;
        }

        try {
            AuditService::log(
                $actorId,
                'rule.publish',
                'rule_definitions',
                $newId,
                "Published rule domain {$domain} ({$scopeLevel}) version {$nextVersion}",
                [
                    'domain'         => $domain,
                    'scope_level'    => $scopeLevel,
                    'scope_id'       => $scopeId,
                    'version_number' => $nextVersion,
                    'effective_from' => $effectiveFrom,
                    'effective_to'   => $effectiveTo,
                ]
            );
        } catch (\Throwable $e) {
            log_message('warning', 'Audit log failed for rule.publish: ' . $e->getMessage());
        }

        $fresh = $this->ruleModel->find($newId);
        $fresh['params'] = $this->ruleModel->paramsOf($fresh);

        RuleResolver::flush();

        return $fresh;
    }

    /**
     * Alias for publishRule supporting legacy parameter order used by CompanyController.
     */
    public function publish(
        string $companyId,
        string $domain,
        string $scopeLevel,
        ?string $scopeId,
        array $params,
        ?string $effectiveFrom,
        string $reason,
        string $actorId,
        ?string $effectiveTo = null,
        ?bool $isSoftwareAppAdmin = null
    ): array {
        return $this->publishRule(
            $companyId,
            $domain,
            $scopeLevel,
            $scopeId,
            $params,
            $actorId,
            $reason,
            $effectiveFrom,
            $effectiveTo,
            $isSoftwareAppAdmin
        );
    }

    /**
     * Publish a Company-scoped business rule version.
     */
    public function publishCompanyRule(
        string $companyId,
        string $domain,
        array $params,
        string $actorId,
        string $reason,
        ?string $effectiveFrom = null,
        ?string $effectiveTo = null,
        ?bool $isSoftwareAppAdmin = null
    ): array {
        return $this->publishRule(
            $companyId,
            $domain,
            'Company',
            null,
            $params,
            $actorId,
            $reason,
            $effectiveFrom,
            $effectiveTo,
            $isSoftwareAppAdmin
        );
    }

    /**
     * Publish an already existing draft or active rule version by ID.
     */
    public function publishExistingVersion(
        string $ruleId,
        string $actorId,
        ?string $reason = null,
        ?string $effectiveFrom = null,
        ?string $effectiveTo = null,
        ?bool $isSoftwareAppAdmin = null
    ): array {
        RuleSchemaRegistry::init();
        $rule = $this->ruleModel->find($ruleId);
        if (!$rule) {
            throw new \InvalidArgumentException("Rule version '{$ruleId}' not found.");
        }
        if ($rule['status'] === 'Archived') {
            throw new \InvalidArgumentException("Cannot publish an archived rule version.");
        }

        $changeReason = !empty($reason) ? trim((string)$reason) : trim((string)($rule['change_reason'] ?? ''));
        if ($changeReason === '' || strcasecmp($changeReason, self::SEED_REASON) === 0) {
            throw new \InvalidArgumentException("A valid change reason is mandatory when publishing a rule policy change.");
        }

        // Maker-checker check: publisher must differ from original creator unless Software App Admin
        if ($this->isMakerCheckerEnabled((string)$rule['company_id'])) {
            $isSuperAdmin = $isSoftwareAppAdmin ?? $this->isActorSoftwareAppAdmin($actorId);
            if (!$isSuperAdmin) {
                $creatorId = trim((string)($rule['created_by'] ?? ''));
                if ($creatorId === '' && $this->db->tableExists('rule_change_log')) {
                    $createLog = $this->db->table('rule_change_log')
                        ->where('rule_id', $rule['id'])
                        ->where('action', 'create')
                        ->orderBy('created_at', 'ASC')
                        ->get()
                        ->getRowArray();
                    if ($createLog && !empty($createLog['actor_id'])) {
                        $creatorId = trim((string)$createLog['actor_id']);
                    }
                }
                if ($creatorId !== '' && strcasecmp($creatorId, trim($actorId)) === 0) {
                    throw new \RuntimeException("Maker-checker policy violation: the publisher must differ from the creator of this rule version.");
                }
            }
        }

        if ($rule['scope_level'] === 'Employee' && !empty($rule['scope_id'])) {
            $canonicalScopeId = $this->resolveCanonicalScopeId($rule['company_id'], 'Employee', $rule['scope_id']);
            if ($canonicalScopeId !== null && $canonicalScopeId !== $rule['scope_id']) {
                $this->db->table('rule_definitions')->where('id', $rule['id'])->update(['scope_id' => $canonicalScopeId]);
                $rule['scope_id'] = $canonicalScopeId;
            }
        }

        $params = $this->ruleModel->paramsOf($rule);
        $partial = ($rule['scope_level'] !== 'Company');
        $valResult = RuleParamValidator::validate($rule['domain'], $rule['scope_level'], $params, $partial, $rule['company_id']);
        if (!$valResult['valid']) {
            throw new \InvalidArgumentException("Rule parameters failed schema validation: " . json_encode($valResult['errors']));
        }

        if (strtoupper((string)$rule['domain']) === 'BONUS' && isset($valResult['clean']['schemes']) && is_array($valResult['clean']['schemes'])) {
            $lockErr = $this->validateNoLockedBonusSchemeDeletion((string)$rule['company_id'], $valResult['clean']['schemes']);
            if ($lockErr !== null) {
                throw new \InvalidArgumentException($lockErr);
            }
        }

        $effectiveFrom = $effectiveFrom ? substr((string)$effectiveFrom, 0, 10) : (isset($rule['effective_from']) ? substr((string)$rule['effective_from'], 0, 10) : null);
        $effectiveTo = $effectiveTo ? substr((string)$effectiveTo, 0, 10) : (!empty($rule['effective_to']) ? substr((string)$rule['effective_to'], 0, 10) : null);

        if (empty($effectiveFrom)) {
            throw new \InvalidArgumentException("Effective from date is required to publish a rule.");
        }
        if ($effectiveTo !== null && $effectiveTo < $effectiveFrom) {
            throw new \InvalidArgumentException("Effective to date ({$effectiveTo}) cannot be before effective from date ({$effectiveFrom}).");
        }

        $this->db->transBegin();
        try {
            $builder = $this->db->table('rule_definitions')
                ->where('company_id', $rule['company_id'])
                ->where('domain', $rule['domain'])
                ->where('scope_level', $rule['scope_level'])
                ->where('status', 'Active')
                ->where('id !=', $rule['id']);

            if ($rule['scope_id'] === null) {
                $builder->where('scope_id', null);
            } else {
                $builder->where('scope_id', $rule['scope_id']);
            }

            $activeRules = $builder->orderBy('effective_from', 'ASC')->get()->getResultArray();

            $predecessorToClose = null;
            foreach ($activeRules as $ar) {
                $arFrom = substr((string)$ar['effective_from'], 0, 10);
                $arTo = !empty($ar['effective_to']) ? substr((string)$ar['effective_to'], 0, 10) : null;

                if ($arFrom < $effectiveFrom) {
                    if ($arTo === null || $arTo >= $effectiveFrom) {
                        if ($predecessorToClose === null || $arFrom > substr((string)$predecessorToClose['effective_from'], 0, 10)) {
                            $predecessorToClose = $ar;
                        }
                    }
                }
            }

            $closedDate = date('Y-m-d', strtotime($effectiveFrom . ' - 1 day'));
            if ($predecessorToClose !== null) {
                $predFrom = substr((string)$predecessorToClose['effective_from'], 0, 10);
                if ($closedDate < $predFrom) {
                    throw new \RuntimeException("Cannot publish: previous active version starts on {$predFrom} which conflicts with effective date {$effectiveFrom}.");
                }
            }

            $infinity = '9999-12-31';
            $candidateEnd = $effectiveTo ?? $infinity;

            foreach ($activeRules as $ar) {
                $arFrom = substr((string)$ar['effective_from'], 0, 10);
                $arTo = !empty($ar['effective_to']) ? substr((string)$ar['effective_to'], 0, 10) : $infinity;

                if ($predecessorToClose !== null && $ar['id'] === $predecessorToClose['id']) {
                    $arTo = $closedDate;
                }

                if ($effectiveFrom <= $arTo && $arFrom <= $candidateEnd) {
                    $activeVersion = $ar['version_number'] ?? '?';
                    $actFrom = substr((string)$ar['effective_from'], 0, 10);
                    $actTo = !empty($ar['effective_to']) ? substr((string)$ar['effective_to'], 0, 10) : 'open-ended';
                    $newEndStr = $effectiveTo ?? 'open-ended';
                    throw new \RuntimeException("Cannot publish: effective range [{$effectiveFrom} to {$newEndStr}] overlaps with existing Active version {$activeVersion} [{$actFrom} to {$actTo}].");
                }
            }

            if ($predecessorToClose !== null) {
                $this->db->table('rule_definitions')
                    ->where('id', $predecessorToClose['id'])
                    ->update([
                        'effective_to' => $closedDate,
                        'updated_at'   => date('Y-m-d H:i:s'),
                    ]);

                $this->db->table('rule_change_log')->insert([
                    'id'              => 'rcl-' . bin2hex(random_bytes(16)),
                    'company_id'      => $rule['company_id'],
                    'rule_id'         => $predecessorToClose['id'],
                    'domain'          => $rule['domain'],
                    'action'          => 'update',
                    'old_params_json' => $predecessorToClose['params_json'],
                    'new_params_json' => $predecessorToClose['params_json'],
                    'actor_id'        => $actorId,
                    'reason'          => "Closed effective_to to {$closedDate} due to publication of version {$rule['version_number']}",
                    'created_at'      => date('Y-m-d H:i:s'),
                ]);
            }

            $updatePayload = [
                'status'         => 'Active',
                'effective_from' => $effectiveFrom,
                'effective_to'   => $effectiveTo,
                'approved_by'    => $actorId,
                'updated_at'     => date('Y-m-d H:i:s'),
            ];
            if ($changeReason !== '') {
                $updatePayload['change_reason'] = $changeReason;
            }

            $this->db->table('rule_definitions')
                ->where('id', $rule['id'])
                ->update($updatePayload);

            $this->db->table('rule_change_log')->insert([
                'id'              => 'rcl-' . bin2hex(random_bytes(16)),
                'company_id'      => $rule['company_id'],
                'rule_id'         => $rule['id'],
                'domain'          => $rule['domain'],
                'action'          => 'publish',
                'old_params_json' => null,
                'new_params_json' => $rule['params_json'],
                'actor_id'        => $actorId,
                'reason'          => $changeReason !== '' ? $changeReason : 'Published rule version',
                'created_at'      => date('Y-m-d H:i:s'),
            ]);

            if ($this->db->transStatus() === false) {
                throw new \RuntimeException("Publication transaction aborted due to a database failure.");
            }
            $this->db->transCommit();

            if (strtoupper((string)$rule['domain']) === 'ATTENDANCE' && class_exists(\App\Services\CompanyWeekendService::class)) {
                if (($rule['scope_level'] ?? '') === 'Company' && !empty($valResult['clean']['weekly_off_days']) && is_array($valResult['clean']['weekly_off_days'])) {
                    \App\Services\CompanyWeekendService::syncCompanyMirror((string)$rule['company_id'], $valResult['clean']['weekly_off_days']);
                }
                \App\Services\CompanyWeekendService::clearCache((string)$rule['company_id']);
            }
            if (method_exists(RuleResolver::class, 'flushAll')) {
                RuleResolver::flushAll();
            } else {
                RuleResolver::flush(true);
            }
        } catch (\Throwable $e) {
            $this->db->transRollback();
            throw $e;
        }

        try {
            AuditService::log(
                $actorId,
                'rule.publish',
                'rule_definitions',
                $rule['id'],
                "Published rule domain {$rule['domain']} version {$rule['version_number']}",
                [
                    'status'         => 'Active',
                    'effective_from' => $effectiveFrom,
                    'effective_to'   => $effectiveTo,
                ]
            );
        } catch (\Throwable $e) {
            log_message('warning', 'Audit log failed for rule.publish: ' . $e->getMessage());
        }

        $fresh = $this->ruleModel->find($ruleId);
        $fresh['params'] = $this->ruleModel->paramsOf($fresh);

        RuleResolver::flush();

        return $fresh;
    }

    /**
     * Create a new draft rule version in rule_definitions.
     *
     * @param string $companyId Tenant ID
     * @param string $domain Domain code
     * @param string $scopeLevel Company, Branch, Department, Designation, Shift, Employee
     * @param string|null $scopeId Scope target ID (null for Company)
     * @param array $params Clean or raw parameters matching schema
     * @param string $actorId User ID
     * @param string $reason Mandatory change reason
     * @param string|null $effectiveFrom Start date (defaults to today)
     * @param string|null $effectiveTo End date (optional, null = open)
     * @return array Created Draft rule definition with params
     */
    public function createDraft(
        string $companyId,
        string $domain,
        string $scopeLevel,
        ?string $scopeId,
        array $params,
        string $actorId,
        string $reason,
        ?string $effectiveFrom = null,
        ?string $effectiveTo = null
    ): array {
        RuleSchemaRegistry::init();
        $domain = strtoupper(trim($domain));

        $domainDef = RuleSchemaRegistry::domain($domain);
        if ($domainDef === null) {
            throw new \InvalidArgumentException("Unknown rule domain '{$domain}'.");
        }

        $allowedScopes = RuleSchemaRegistry::allowedScopes($domain);
        if (!in_array($scopeLevel, $allowedScopes, true)) {
            throw new \InvalidArgumentException("Scope level '{$scopeLevel}' is not allowed for domain '{$domain}'. Allowed scopes: " . implode(', ', $allowedScopes));
        }

        if ($scopeLevel === 'Company') {
            $scopeId = null;
        } elseif (empty($scopeId)) {
            throw new \InvalidArgumentException("Scope ID is required when scope level is '{$scopeLevel}'.");
        }

        if ($scopeLevel === 'Employee' && !empty($scopeId)) {
            $scopeId = $this->resolveCanonicalScopeId($companyId, $scopeLevel, $scopeId);
        }

        $reason = trim($reason);
        if ($reason === '' || strcasecmp($reason, self::SEED_REASON) === 0) {
            throw new \InvalidArgumentException("A valid change reason is required when modifying or creating a business rule version.");
        }

        $effectiveFrom = !empty($effectiveFrom) ? substr((string)$effectiveFrom, 0, 10) : date('Y-m-d');
        $effectiveTo = !empty($effectiveTo) ? substr((string)$effectiveTo, 0, 10) : null;

        if ($effectiveTo !== null && $effectiveTo < $effectiveFrom) {
            throw new \InvalidArgumentException("Effective to date ({$effectiveTo}) cannot be before effective from date ({$effectiveFrom}).");
        }

        $partial = ($scopeLevel !== 'Company');
        $valResult = RuleParamValidator::validate($domain, $scopeLevel, $params, $partial, $companyId);
        if (!$valResult['valid']) {
            $errStr = json_encode($valResult['errors']);
            throw new \InvalidArgumentException("Rule parameters failed schema validation: {$errStr}");
        }

        if ($domain === 'BONUS' && isset($valResult['clean']['schemes']) && is_array($valResult['clean']['schemes'])) {
            $lockErr = $this->validateNoLockedBonusSchemeDeletion($companyId, $valResult['clean']['schemes']);
            if ($lockErr !== null) {
                throw new \InvalidArgumentException($lockErr);
            }
        }

        $cleanParamsJson = json_encode($valResult['clean'], JSON_UNESCAPED_SLASHES);

        // Determine next version number for (company_id, domain, scope_level, scope_id)
        $builder = $this->db->table('rule_definitions')
            ->selectMax('version_number', 'max_v')
            ->where('company_id', $companyId)
            ->where('domain', $domain)
            ->where('scope_level', $scopeLevel);

        if ($scopeId === null) {
            $builder->where('scope_id', null);
        } else {
            $builder->where('scope_id', $scopeId);
        }
        $maxRow = $builder->get()->getRowArray();
        $nextVersion = ((int)($maxRow['max_v'] ?? 0)) + 1;

        $newId = 'rd-' . bin2hex(random_bytes(8));
        $now = date('Y-m-d H:i:s');

        $insertData = [
            'id'             => $newId,
            'company_id'     => $companyId,
            'domain'         => $domain,
            'scope_level'    => $scopeLevel,
            'scope_id'       => $scopeId,
            'version_number' => $nextVersion,
            'effective_from' => $effectiveFrom,
            'effective_to'   => $effectiveTo,
            'status'         => 'Draft',
            'params_json'    => $cleanParamsJson,
            'schema_version' => RuleSchemaRegistry::schemaVersion(),
            'change_reason'  => $reason !== '' ? $reason : null,
            'created_by'     => $actorId,
            'created_at'     => $now,
            'updated_at'     => $now,
        ];

        $this->db->transBegin();
        try {
            $inserted = $this->db->table('rule_definitions')->insert($insertData);
            if ($inserted === false) {
                throw new \RuntimeException('Rule draft insert failed.');
            }

            $changeLogged = $this->db->table('rule_change_log')->insert([
                'id'              => 'rcl-' . bin2hex(random_bytes(16)),
                'company_id'      => $companyId,
                'rule_id'         => $newId,
                'domain'          => $domain,
                'action'          => 'create',
                'old_params_json' => null,
                'new_params_json' => $cleanParamsJson,
                'actor_id'        => $actorId,
                'reason'          => $reason !== '' ? $reason : 'Created new rule draft',
                'created_at'      => $now,
            ]);
            if ($changeLogged === false || $this->db->transStatus() === false) {
                throw new \RuntimeException('Rule change log insert failed.');
            }
            $this->db->transCommit();
        } catch (\Throwable $e) {
            $this->db->transRollback();
            throw $e;
        }

        try {
            AuditService::log(
                $actorId,
                'rule.create',
                'rule_definitions',
                $newId,
                "Created draft rule domain {$domain} v{$nextVersion}",
                [
                    'domain'         => $domain,
                    'scope_level'    => $scopeLevel,
                    'scope_id'       => $scopeId,
                    'version_number' => $nextVersion,
                ]
            );
        } catch (\Throwable $e) {
            log_message('warning', 'Audit log failed for rule.create: ' . $e->getMessage());
        }

        $saved = $this->ruleModel->find($newId);
        $saved['params'] = $this->ruleModel->paramsOf($saved);
        return $saved;
    }

    /**
     * Update an existing Draft rule version in place.
     * Only Draft rows may be updated in place. Active rows cannot be edited in place.
     *
     * @param string $ruleId Target draft rule ID
     * @param array $params Parameters to update
     * @param string $actorId User ID
     * @param string $reason Change reason
     * @param string|null $effectiveFrom Start date
     * @param string|null $effectiveTo End date
     * @return array Updated rule definition with params
     */
    public function updateDraft(
        string $ruleId,
        array $params,
        string $actorId,
        string $reason,
        ?string $effectiveFrom = null,
        ?string $effectiveTo = null
    ): array {
        RuleSchemaRegistry::init();
        $rule = $this->ruleModel->find($ruleId);
        if (!$rule) {
            throw new \InvalidArgumentException("Rule version '{$ruleId}' not found.");
        }

        if ($rule['status'] !== 'Draft') {
            throw new \InvalidArgumentException("Only Draft rule versions may be updated in place. Target rule status is '{$rule['status']}'.");
        }

        $reason = trim($reason);
        if ($reason === '' || strcasecmp($reason, self::SEED_REASON) === 0) {
            throw new \InvalidArgumentException("A valid change reason is required when modifying business rules.");
        }

        $effectiveFrom = !empty($effectiveFrom) ? substr((string)$effectiveFrom, 0, 10) : substr((string)$rule['effective_from'], 0, 10);
        $effectiveTo = $effectiveTo !== null ? (!empty($effectiveTo) ? substr((string)$effectiveTo, 0, 10) : null) : (!empty($rule['effective_to']) ? substr((string)$rule['effective_to'], 0, 10) : null);

        if ($effectiveTo !== null && $effectiveTo < $effectiveFrom) {
            throw new \InvalidArgumentException("Effective to date ({$effectiveTo}) cannot be before effective from date ({$effectiveFrom}).");
        }

        $partial = ($rule['scope_level'] !== 'Company');
        $valResult = RuleParamValidator::validate($rule['domain'], $rule['scope_level'], $params, $partial, $rule['company_id']);
        if (!$valResult['valid']) {
            $errStr = json_encode($valResult['errors']);
            throw new \InvalidArgumentException("Rule parameters failed schema validation: {$errStr}");
        }

        if (strtoupper((string)$rule['domain']) === 'BONUS' && isset($valResult['clean']['schemes']) && is_array($valResult['clean']['schemes'])) {
            $existingSchemes = [];
            $oldDecoded = json_decode((string)$rule['params_json'], true);
            if (is_array($oldDecoded) && isset($oldDecoded['schemes']) && is_array($oldDecoded['schemes'])) {
                $existingSchemes = $oldDecoded['schemes'];
            }
            $lockErr = $this->validateNoLockedBonusSchemeDeletion((string)$rule['company_id'], $valResult['clean']['schemes'], !empty($existingSchemes) ? $existingSchemes : null);
            if ($lockErr !== null) {
                throw new \InvalidArgumentException($lockErr);
            }
        }

        $cleanParamsJson = json_encode($valResult['clean'], JSON_UNESCAPED_SLASHES);
        $oldParamsJson = $rule['params_json'];
        $now = date('Y-m-d H:i:s');

        $updateData = [
            'params_json'    => $cleanParamsJson,
            'effective_from' => $effectiveFrom,
            'effective_to'   => $effectiveTo,
            'change_reason'  => $reason !== '' ? $reason : null,
            'updated_by'     => $actorId,
            'updated_at'     => $now,
        ];

        $this->db->transBegin();
        try {
            $updated = $this->db->table('rule_definitions')->where('id', $ruleId)->update($updateData);
            if ($updated === false) {
                throw new \RuntimeException('Rule draft update failed.');
            }

            $changeLogged = $this->db->table('rule_change_log')->insert([
                'id'              => 'rcl-' . bin2hex(random_bytes(16)),
                'company_id'      => $rule['company_id'],
                'rule_id'         => $ruleId,
                'domain'          => $rule['domain'],
                'action'          => 'update',
                'old_params_json' => $oldParamsJson,
                'new_params_json' => $cleanParamsJson,
                'actor_id'        => $actorId,
                'reason'          => $reason !== '' ? $reason : 'Updated rule version parameters',
                'created_at'      => $now,
            ]);
            if ($changeLogged === false || $this->db->transStatus() === false) {
                throw new \RuntimeException('Rule change log insert failed.');
            }
            $this->db->transCommit();
        } catch (\Throwable $e) {
            $this->db->transRollback();
            throw $e;
        }

        try {
            AuditService::log(
                $actorId,
                'rule.update',
                'rule_definitions',
                $ruleId,
                "Updated rule domain {$rule['domain']} v{$rule['version_number']}",
                [
                    'domain'         => $rule['domain'],
                    'scope_level'    => $rule['scope_level'],
                    'scope_id'       => $rule['scope_id'],
                    'version_number' => $rule['version_number'],
                ]
            );
        } catch (\Throwable $e) {
            log_message('warning', 'Audit log failed for rule.update: ' . $e->getMessage());
        }

        $saved = $this->ruleModel->find($ruleId);
        $saved['params'] = $this->ruleModel->paramsOf($saved);

        RuleResolver::flush();

        return $saved;
    }

    /**
     * Archive an active or draft rule version by ID.
     * Enforces that the last active Company-level rule cannot be archived.
     * Runs in a transaction with rule_change_log.
     *
     * @param string $ruleId Target rule ID
     * @param string $actorId User ID performing archive
     * @param string|null $reason Reason for archiving
     * @return array Updated rule definition
     */
    public function archiveRule(string $ruleId, string $actorId, ?string $reason = null): array
    {
        $rule = $this->ruleModel->find($ruleId);
        if (!$rule) {
            throw new \InvalidArgumentException("Rule '{$ruleId}' not found.");
        }
        if ($rule['status'] === 'Archived') {
            $rule['params'] = $this->ruleModel->paramsOf($rule);
            return $rule;
        }

        // Invariant: Cannot archive an Active Company-level rule unless another Active Company-level rule covers today
        if ($rule['status'] === 'Active' && $rule['scope_level'] === 'Company') {
            $today = date('Y-m-d');
            $otherActiveCount = $this->db->table('rule_definitions')
                ->where('company_id', $rule['company_id'])
                ->where('domain', $rule['domain'])
                ->where('scope_level', 'Company')
                ->where('status', 'Active')
                ->where('id !=', $ruleId)
                ->where('effective_from <=', $today)
                ->groupStart()
                    ->where('effective_to IS NULL')
                    ->orWhere('effective_to >=', $today)
                ->groupEnd()
                ->countAllResults();

            if ($otherActiveCount === 0) {
                throw new \RuntimeException("Cannot archive the active Company-level rule for domain '{$rule['domain']}'. At least one other active Company-level rule covering today must be maintained.");
            }
        }

        $reason = !empty($reason) ? trim((string)$reason) : 'Archived rule version';
        $oldStatus = $rule['status'];
        $now = date('Y-m-d H:i:s');

        $this->db->transBegin();
        try {
            $this->db->table('rule_definitions')
                ->where('id', $ruleId)
                ->update([
                    'status'     => 'Archived',
                    'updated_at' => $now,
                ]);

            $this->db->table('rule_change_log')->insert([
                'id'              => 'rcl-' . bin2hex(random_bytes(16)),
                'company_id'      => $rule['company_id'],
                'rule_id'         => $rule['id'],
                'domain'          => $rule['domain'],
                'action'          => 'archive',
                'old_params_json' => $rule['params_json'],
                'new_params_json' => null,
                'actor_id'        => $actorId,
                'reason'          => $reason,
                'created_at'      => $now,
            ]);

            if ($this->db->transStatus() === false) {
                throw new \RuntimeException("Transaction failed while archiving rule {$ruleId}.");
            }
            $this->db->transCommit();
        } catch (\Throwable $e) {
            $this->db->transRollback();
            throw $e;
        }

        try {
            AuditService::log(
                $actorId,
                'rule.archive',
                'rule_definitions',
                $rule['id'],
                "Archived rule domain {$rule['domain']} version {$rule['version_number']}",
                [
                    'previous_status' => $oldStatus,
                    'status'          => 'Archived',
                    'reason'          => $reason,
                ]
            );
        } catch (\Throwable $e) {
            log_message('warning', 'Audit log failed for rule.archive: ' . $e->getMessage());
        }

        $fresh = $this->ruleModel->find($ruleId);
        $fresh['params'] = $this->ruleModel->paramsOf($fresh);

        RuleResolver::flush();

        return $fresh;
    }

    /**
     * Alias for archiveRule.
     */
    public function archive(string $ruleId, string $actorId, ?string $reason = null): array
    {
        return $this->archiveRule($ruleId, $actorId, $reason);
    }

    /**
     * Resolve canonical employee ID if scope is Employee and scope_id is provided.
     * Looks up employee by id or employee_code within the tenant company.
     *
     * @param string $companyId Tenant company ID
     * @param string $scopeLevel Scope level name
     * @param string|null $scopeId Target scope ID or code
     * @return string|null Canonical employee ID or original scope ID
     */
    public function resolveCanonicalScopeId(string $companyId, string $scopeLevel, ?string $scopeId): ?string
    {
        if ($scopeLevel !== 'Employee' || empty($scopeId)) {
            return $scopeId;
        }

        $scopeId = trim((string)$scopeId);
        if ($this->db->tableExists('employees')) {
            $row = $this->db->table('employees')
                ->where('company_id', $companyId)
                ->groupStart()
                    ->where('id', $scopeId)
                    ->orWhere('employee_code', $scopeId)
                ->groupEnd()
                ->get()
                ->getRowArray();
            if ($row && !empty($row['id'])) {
                return (string)$row['id'];
            }
        }

        return $scopeId;
    }
}
