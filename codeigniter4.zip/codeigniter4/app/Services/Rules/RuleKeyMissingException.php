<?php

namespace App\Services\Rules;

use RuntimeException;

class RuleKeyMissingException extends RuntimeException
{
    protected ?string $key = null;
    protected ?string $domain = null;

    public function __construct(
        string $message = '',
        ?string $key = null,
        ?string $domain = null,
        int $code = 0,
        ?\Throwable $previous = null
    ) {
        $this->key    = $key;
        $this->domain = $domain;
        parent::__construct($message, $code, $previous);
    }

    public static function forKey(string $key, ?string $domain = null): self
    {
        $message = "Rule parameter key '{$key}' not found" . ($domain !== null ? " in domain '{$domain}'" : "");
        return new self($message, $key, $domain);
    }

    public function getKey(): ?string
    {
        return $this->key;
    }

    public function getDomain(): ?string
    {
        return $this->domain;
    }
}
