<?php

namespace App\Services\Concerns;

/**
 * Trait JoinsActiveSalary
 *
 * Provides a uniform, resilient SQL JOIN condition for linking an employee
 * to their active row in the `employee_salaries` table across report services.
 */
trait JoinsActiveSalary
{
    /**
     * Resolve active employee salary join condition without assuming is_active column
     */
    protected function getActiveSalaryJoin(string $empAlias = 'e', string $salAlias = 'es'): string
    {
        if (!$this->db->tableExists('employee_salaries')) {
            return "1=0";
        }
        $fields = $this->db->getFieldNames('employee_salaries');
        if (in_array('status', $fields, true)) {
            return "{$salAlias}.employee_id = {$empAlias}.id AND ({$salAlias}.status = 'Active' OR {$salAlias}.status = 'active')";
        }
        if (in_array('is_active', $fields, true)) {
            return "{$salAlias}.employee_id = {$empAlias}.id AND {$salAlias}.is_active = 1";
        }
        return "{$salAlias}.employee_id = {$empAlias}.id";
    }
}
