<?php

namespace App\Services;

use Config\Database;
use App\Services\Rules\RuleSeeder;

/**
 * CompanyInitializationService
 *
 * Handles company-specific master data provisioning upon creation of a new company tenant.
 * Guarantees strict multi-tenant isolation, idempotency (preventing duplicate default records),
 * and transaction safety across all 8 core master data categories:
 * 1. Departments
 * 2. Designations
 * 3. Salary Grades
 * 4. Security Policies
 * 5. Work Shifts
 * 6. Holiday Calendar
 * 7. Employment Types
 * 8. Leave Types (Identity)
 */
class CompanyInitializationService
{
    protected $db;

    public const DEFAULT_SALARY_COMPONENTS = [
        [
            'code'                   => 'BASIC',
            'name'                   => 'Basic Salary',
            'type'                   => 'earning',
            'calculation_type'       => 'fixed',
            'calculation_base'       => 'Basic Salary',
            'amount'                 => 0.00,
            'percentage'             => 0.00,
            'formula'                => null,
            'is_taxable'             => 1,
            'is_pf_applicable'       => 1,
            'include_in_pf_basis'    => 1,
            'is_overtime_applicable' => 0,
            'is_included_in_gross'   => 1,
            'is_included_in_ctc'     => 1,
            'is_statutory'           => 0,
            'is_system'              => 1,
            'is_recurring'           => 1,
            'display_order'          => 1,
            'description'            => 'Base salary component',
            'status'                 => 'Active',
        ],
        [
            'code'                   => 'HRA',
            'name'                   => 'House Rent Allowance',
            'type'                   => 'earning',
            'calculation_type'       => 'percentage',
            'calculation_base'       => 'Basic Salary',
            'amount'                 => 0.00,
            'percentage'             => 40.00,
            'formula'                => null,
            'is_taxable'             => 1,
            'is_pf_applicable'       => 0,
            'include_in_pf_basis'    => 0,
            'is_overtime_applicable' => 0,
            'is_included_in_gross'   => 1,
            'is_included_in_ctc'     => 1,
            'is_statutory'           => 0,
            'is_system'              => 1,
            'is_recurring'           => 1,
            'display_order'          => 2,
            'description'            => 'House Rent Allowance (40% of Basic Salary)',
            'status'                 => 'Active',
        ],
        [
            'code'                   => 'MED',
            'name'                   => 'Medical Allowance',
            'type'                   => 'earning',
            'calculation_type'       => 'fixed',
            'calculation_base'       => 'Basic Salary',
            'amount'                 => 2500.00,
            'percentage'             => 0.00,
            'formula'                => null,
            'is_taxable'             => 1,
            'is_pf_applicable'       => 0,
            'include_in_pf_basis'    => 0,
            'is_overtime_applicable' => 0,
            'is_included_in_gross'   => 1,
            'is_included_in_ctc'     => 1,
            'is_statutory'           => 0,
            'is_system'              => 1,
            'is_recurring'           => 1,
            'display_order'          => 3,
            'description'            => 'Fixed medical allowance',
            'status'                 => 'Active',
        ],
        [
            'code'                   => 'CONV',
            'name'                   => 'Conveyance Allowance',
            'type'                   => 'earning',
            'calculation_type'       => 'fixed',
            'calculation_base'       => 'Basic Salary',
            'amount'                 => 1500.00,
            'percentage'             => 0.00,
            'formula'                => null,
            'is_taxable'             => 0,
            'is_pf_applicable'       => 0,
            'include_in_pf_basis'    => 0,
            'is_overtime_applicable' => 0,
            'is_included_in_gross'   => 1,
            'is_included_in_ctc'     => 1,
            'is_statutory'           => 0,
            'is_system'              => 1,
            'is_recurring'           => 1,
            'display_order'          => 4,
            'description'            => 'Fixed conveyance allowance',
            'status'                 => 'Active',
        ],
        [
            'code'                   => 'SPL',
            'name'                   => 'Special Allowance',
            'type'                   => 'earning',
            'calculation_type'       => 'fixed',
            'calculation_base'       => 'Basic Salary',
            'amount'                 => 2000.00,
            'percentage'             => 0.00,
            'formula'                => null,
            'is_taxable'             => 1,
            'is_pf_applicable'       => 0,
            'include_in_pf_basis'    => 0,
            'is_overtime_applicable' => 0,
            'is_included_in_gross'   => 1,
            'is_included_in_ctc'     => 1,
            'is_statutory'           => 0,
            'is_system'              => 1,
            'is_recurring'           => 1,
            'display_order'          => 5,
            'description'            => 'Special allowance',
            'status'                 => 'Active',
        ],
        [
            'code'                   => 'PF',
            'name'                   => 'Provident Fund (Employee)',
            'type'                   => 'deduction',
            'calculation_type'       => 'percentage',
            'calculation_base'       => 'Basic Salary',
            'amount'                 => 0.00,
            'percentage'             => 0.00,
            'formula'                => null,
            'is_taxable'             => 0,
            'is_pf_applicable'       => 1,
            'include_in_pf_basis'    => 1,
            'is_overtime_applicable' => 0,
            'is_included_in_gross'   => 0,
            'is_included_in_ctc'     => 0,
            'is_statutory'           => 1,
            'is_system'              => 1,
            'is_recurring'           => 1,
            'display_order'          => 6,
            'description'            => 'Rate/amount resolved from PROVIDENT_FUND statutory policy',
            'status'                 => 'Active',
        ],
        [
            'code'                   => 'TAX',
            'name'                   => 'Income Tax TDS',
            'type'                   => 'deduction',
            'calculation_type'       => 'percentage',
            'calculation_base'       => 'Gross Salary',
            'amount'                 => 0.00,
            'percentage'             => 0.00,
            'formula'                => null,
            'is_taxable'             => 0,
            'is_pf_applicable'       => 0,
            'include_in_pf_basis'    => 0,
            'is_overtime_applicable' => 0,
            'is_included_in_gross'   => 0,
            'is_included_in_ctc'     => 0,
            'is_statutory'           => 1,
            'is_system'              => 1,
            'is_recurring'           => 1,
            'display_order'          => 7,
            'description'            => 'Resolved from Income Tax (TDS) policy / tax rules',
            'status'                 => 'Active',
        ],
    ];

    public const DEFAULT_SALARY_STRUCTURE = [
        'code'        => 'STD',
        'name'        => 'Standard Staff Structure',
        'description' => 'Standard Staff Salary Structure template with core allowances and statutory deductions',
        'is_default'  => 1,
        'status'      => 'Active',
        'item_codes'  => ['BASIC', 'HRA', 'MED', 'CONV', 'PF', 'TAX'],
    ];

    public function __construct()
    {
        $this->db = Database::connect();
    }

    /**
     * Pre-warm all relevant models and ensure schemas OUTSIDE of any active transaction.
     * DDL statements (ALTER TABLE, CREATE TABLE) trigger implicit commits in MySQL
     * and MUST NOT be run inside an active database transaction.
     */
    public function prewarmSchemas(): void
    {
        try {
            $this->ensureDesignationsCompanyIdColumn();
            (new \App\Models\CompanyModel())->ensureSchema();
            (new \App\Models\BranchModel())->ensureSchema();
            (new \App\Models\DesignationModel())->ensureSchema();
            (new \App\Models\SalaryGradeModel())->ensureSchema();
            (new \App\Models\SalaryComponentModel())->ensureSchema();
            (new \App\Models\SalaryStructureModel())->ensureSchema();
            (new \App\Models\SalaryStructureItemModel())->ensureSchema();
            (new \App\Models\EmployeeSalaryModel())->ensureSchema();
            (new \App\Models\StatutoryPolicyModel())->ensureSchema();
            (new \App\Models\StatutoryPolicyRuleModel())->ensureSchema();
            (new \App\Models\StatutoryPolicyVersionModel())->ensureSchema();

            // Ensure roles table schema columns and drop single-column unique index on code
            if ($this->db->tableExists('roles')) {
                if (!$this->db->fieldExists('company_id', 'roles')) {
                    \Config\Database::forge()->addColumn('roles', [
                        'company_id' => [
                            'type'       => 'VARCHAR',
                            'constraint' => 36,
                            'null'       => true,
                            'after'      => 'id',
                        ],
                    ]);
                }
                if (!$this->db->fieldExists('is_system', 'roles')) {
                    \Config\Database::forge()->addColumn('roles', [
                        'is_system' => [
                            'type'       => 'TINYINT',
                            'constraint' => 1,
                            'default'    => 0,
                            'null'       => false,
                        ],
                    ]);
                }
                $indexes = $this->db->getIndexData('roles');
                foreach ($indexes as $idx) {
                    $fields = array_map('strtolower', (array)($idx->fields ?? []));
                    $isUnique = !empty($idx->type) && strtoupper((string)$idx->type) === 'UNIQUE';
                    if ($isUnique && $fields === ['code']) {
                        $this->db->query("ALTER TABLE `roles` DROP INDEX `{$idx->name}`");
                    }
                }
            }
        } catch (\Throwable $e) {
            log_message('warning', 'prewarmSchemas encountered exception: ' . $e->getMessage());
        }
    }

    /**
     * Primary entry point to initialize all master data for a specific company tenant.
     *
     * @param string $companyId The unique ID of the company (e.g. COMP-XYZ or comp-001)
     * @param string|null $branchId Optional default branch ID (e.g. Headquarters branch)
     * @param array $options Additional configuration options (e.g. year for holidays)
     * @return array Summary of initialization results
     * @throws \RuntimeException If company does not exist or database operation fails
     */
    public function initializeCompany(string $companyId, ?string $branchId = null, array $options = []): array
    {
        $company = $this->safeGetFirstRow($this->db->table('companies')->where('id', $companyId));
        if (!$company) {
            throw new \RuntimeException("Cannot initialize master data: Company with ID '{$companyId}' does not exist.");
        }

        $compCode = preg_replace('/[^A-Za-z0-9]/', '', (string)($company['code'] ?? 'TENANT'));
        if (empty($compCode)) {
            $compCode = substr(preg_replace('/[^A-Za-z0-9]/', '', $companyId), 0, 8) ?: 'TENANT';
        }
        $compCode = strtoupper($compCode);

        // Resolve default HQ branch if branchId was not provided
        if (empty($branchId)) {
            $branchCols = $this->getTableColumns('branches');
            $builder = $this->db->table('branches')->where('company_id', $companyId);
            if (in_array('is_headquarters', $branchCols, true)) {
                $builder->orderBy('is_headquarters', 'DESC');
            }
            if (in_array('created_at', $branchCols, true)) {
                $builder->orderBy('created_at', 'ASC');
            }
            $hqBranch = $this->safeGetFirstRow($builder);
            $branchId = $hqBranch['id'] ?? null;
        }

        // Pre-warm schemas outside of transaction if not already in an active transaction
        if ((int)($this->db->transDepth ?? 0) === 0) {
            $this->prewarmSchemas();
        }

        $ownsTransaction = false;
        // In CodeIgniter 4, transDepth is a property (not a method) representing active transaction nesting depth
        $depth = (int)($this->db->transDepth ?? 0);
        if ($depth === 0) {
            $this->db->transStart();
            $ownsTransaction = true;
        }

        $results = [
            'success'     => false,
            'company_id'  => $companyId,
            'branch_id'   => $branchId,
            'initialized' => [],
            'skipped'     => [],
            'errors'      => [],
        ];

        try {
            // 1. Departments
            try {
                $deptResult = $this->initializeDepartments($companyId, $branchId, $compCode);
                $results['initialized']['departments'] = $deptResult['created'];
                $results['skipped']['departments']     = $deptResult['skipped'];
                $departmentMap                         = $deptResult['map'];
            } catch (\Throwable $eDept) {
                log_message('error', "Departments initialization failed for {$companyId}: " . $eDept->getMessage());
                $results['errors']['departments'] = $eDept->getMessage();
                $departmentMap = [];
            }

            // 2. Designations (linked to departments and scoped to company)
            try {
                $desigResult = $this->initializeDesignations($companyId, $compCode, $departmentMap);
                $results['initialized']['designations'] = $desigResult['created'];
                $results['skipped']['designations']     = $desigResult['skipped'];
            } catch (\Throwable $eDesig) {
                log_message('error', "Designations initialization failed for {$companyId}: " . $eDesig->getMessage());
                $results['errors']['designations'] = $eDesig->getMessage();
            }

            // 3. Salary Grades
            try {
                $gradesResult = $this->initializeSalaryGrades($companyId, $compCode);
                $results['initialized']['salary_grades'] = $gradesResult['created'];
                $results['skipped']['salary_grades']     = $gradesResult['skipped'];
            } catch (\Throwable $eGrade) {
                log_message('error', "Salary grades initialization failed for {$companyId}: " . $eGrade->getMessage());
                $results['errors']['salary_grades'] = $eGrade->getMessage();
            }

            // 4. Security Policies
            try {
                $secResult = $this->initializeSecurityPolicies($companyId);
                $results['initialized']['security_policies'] = $secResult['created'];
                $results['skipped']['security_policies']     = $secResult['skipped'];
            } catch (\Throwable $eSec) {
                log_message('error', "Security policies initialization failed for {$companyId}: " . $eSec->getMessage());
                $results['errors']['security_policies'] = $eSec->getMessage();
            }

            // 5. Work Shifts
            try {
                $shiftsResult = $this->initializeWorkShifts($companyId, $branchId, $compCode);
                $results['initialized']['work_shifts'] = $shiftsResult['created'];
                $results['skipped']['work_shifts']     = $shiftsResult['skipped'];
            } catch (\Throwable $eShift) {
                log_message('error', "Work shifts initialization failed for {$companyId}: " . $eShift->getMessage());
                $results['errors']['work_shifts'] = $eShift->getMessage();
            }

            // 6. Holiday Calendar
            try {
                $holidaysResult = $this->initializeHolidayCalendar($companyId, $branchId, $compCode, $options);
                $results['initialized']['holidays'] = $holidaysResult['created'];
                $results['skipped']['holidays']     = $holidaysResult['skipped'];
            } catch (\Throwable $eHol) {
                log_message('error', "Holidays initialization failed for {$companyId}: " . $eHol->getMessage());
                $results['errors']['holidays'] = $eHol->getMessage();
            }

            // 7. Employment Types
            try {
                $empTypesResult = $this->initializeEmploymentTypes($companyId, $compCode);
                $results['initialized']['employment_types'] = $empTypesResult['created'];
                $results['skipped']['employment_types']     = $empTypesResult['skipped'];
            } catch (\Throwable $eEt) {
                log_message('error', "Employment types initialization failed for {$companyId}: " . $eEt->getMessage());
                $results['errors']['employment_types'] = $eEt->getMessage();
            }

            // 8. Leave Types (Identity)
            try {
                $leaveResult = $this->initializeLeaveTypesAndQuotas($companyId, $compCode);
                $results['initialized']['leave_types'] = $leaveResult['created_types'];
                $results['skipped']['leave_types']     = $leaveResult['skipped_types'];
            } catch (\Throwable $eLeave) {
                log_message('error', "Leave types initialization failed for {$companyId}: " . $eLeave->getMessage());
                $results['errors']['leave_types'] = $eLeave->getMessage();
            }

            // 9. Salary Components
            try {
                $compResult = $this->initializeSalaryComponents($companyId, $compCode);
                $results['initialized']['salary_components'] = $compResult['created'];
                $results['skipped']['salary_components']     = $compResult['skipped'];
                $componentMap                                = $compResult['map'] ?? [];
            } catch (\Throwable $eComp) {
                log_message('error', "Salary components initialization failed for {$companyId}: " . $eComp->getMessage());
                $results['errors']['salary_components'] = $eComp->getMessage();
                $componentMap = [];
            }

            // 10. Salary Structures & Items
            try {
                $structResult = $this->initializeSalaryStructures($companyId, $compCode, $componentMap);
                $results['initialized']['salary_structures'] = $structResult['created'];
                $results['skipped']['salary_structures']     = $structResult['skipped'];
            } catch (\Throwable $eStruct) {
                log_message('error', "Salary structures initialization failed for {$companyId}: " . $eStruct->getMessage());
                $results['errors']['salary_structures'] = $eStruct->getMessage();
            }

            // 11. Business Rules (RuleSeeder - Company-scope default seed with optional tenant overrides)
            try {
                $ruleOverrides = $options['rule_overrides'] ?? null;
                $seedDate = $options['seed_date'] ?? (!empty($company['created_at']) ? substr((string)$company['created_at'], 0, 10) : date('Y-m-d'));
                $ruleSeedResult = RuleSeeder::seedCompany($companyId, $ruleOverrides, $seedDate);
                $results['initialized']['rules'] = $ruleSeedResult['seeded_domains'];
                $results['skipped']['rules']     = $ruleSeedResult['skipped_domains'];
                $results['rules_confirmation']   = $ruleSeedResult['needs_confirmation'];
            } catch (\Throwable $eRules) {
                log_message('error', "RuleSeeder initialization failed for {$companyId}: " . $eRules->getMessage());
                $results['errors']['rules'] = $eRules->getMessage();
            }

            // 12. Company Roles & Permission Matrices (Company-id wise RBAC isolation)
            try {
                $roleResult = $this->initializeCompanyRoles($companyId, $compCode);
                $results['initialized']['roles'] = $roleResult['created'];
                $results['skipped']['roles']     = $roleResult['skipped'];
            } catch (\Throwable $eRoles) {
                log_message('error', "Roles initialization failed for {$companyId}: " . $eRoles->getMessage());
                $results['errors']['roles'] = $eRoles->getMessage();
            }

            // 13. Asset Categories (Default Seed)
            try {
                $assetCatResult = $this->initializeAssetCategories($companyId, $compCode);
                $results['initialized']['asset_categories'] = $assetCatResult['created'];
                $results['skipped']['asset_categories']     = $assetCatResult['skipped'];
            } catch (\Throwable $eAssetCat) {
                log_message('error', "Asset categories initialization failed for {$companyId}: " . $eAssetCat->getMessage());
                $results['errors']['asset_categories'] = $eAssetCat->getMessage();
            }

            // 14. Dashboard Widgets & Core Assignments (Workforce & Attendance Summary always active for Company Admin and HR Admin)
            try {
                $widgetResult = $this->initializeDashboardWidgets($companyId, $compCode);
                $results['initialized']['dashboard_widgets'] = $widgetResult['created'];
                $results['skipped']['dashboard_widgets']     = $widgetResult['skipped'];
            } catch (\Throwable $eWidgets) {
                log_message('error', "Dashboard widgets initialization failed for {$companyId}: " . $eWidgets->getMessage());
                $results['errors']['dashboard_widgets'] = $eWidgets->getMessage();
            }

            if (!empty($results['errors'])) {
                $errList = [];
                foreach ($results['errors'] as $step => $msg) {
                    $errList[] = "{$step}: {$msg}";
                }
                $compositeMsg = implode(' | ', $errList);
                log_message('error', "Master data initialization failed for {$companyId}: {$compositeMsg}");
                throw new \RuntimeException("Master data initialization failed: {$compositeMsg}");
            }

            if ($ownsTransaction) {
                $this->db->transComplete();
                if ($this->db->transStatus() === false) {
                    throw new \RuntimeException("Database transaction failed during company master data initialization.");
                }
            }

            $results['success'] = true;
            $results['message'] = "Company master data initialized successfully for company '{$company['name']}' [{$compCode}].";

            return $results;
        } catch (\Throwable $e) {
            if ($ownsTransaction) {
                $this->db->transRollback();
            }
            throw $e;
        }
    }

    /**
     * 1. Initialize Default Departments
     */
    public function initializeDepartments(string $companyId, ?string $branchId, string $compCode): array
    {
        $created = [];
        $skipped = [];
        $map     = [];

        $defaultDepts = [
            [
                'code'        => 'MED_NUR',
                'name'        => 'Medical & Nursing',
                'description' => 'Clinical care, physicians, nursing staff, patient triage and medical operations',
            ],
            [
                'code'        => 'RAD',
                'name'        => 'Radiology',
                'description' => 'Diagnostic medical imaging, X-ray, ultrasound, CT, MRI and radiography services',
            ],
            [
                'code'        => 'ADMIN',
                'name'        => 'Administration',
                'description' => 'Hospital/clinic administration, executive leadership, reception, security and office services',
            ],
            [
                'code'        => 'IT',
                'name'        => 'IT',
                'description' => 'Information Technology, systems infrastructure, networks, workstations and tech support',
            ],
            [
                'code'        => 'LAB',
                'name'        => 'Laboratory',
                'description' => 'Clinical pathology, diagnostic laboratory testing, specimen analysis and scientific investigations',
            ],
            [
                'code'        => 'FIN_HR',
                'name'        => 'Finance & HR',
                'description' => 'Financial management, patient accounts, cashiering, human resources and payroll operations',
            ],
            [
                'code'        => 'EXEC',
                'name'        => 'Executive Management',
                'description' => 'Corporate Strategy, Executive Leadership & Board Governance',
            ],
            [
                'code'        => 'HR',
                'name'        => 'Human Resources',
                'description' => 'Talent Acquisition, Employee Relations, Culture & HR Compliance',
            ],
            [
                'code'        => 'FIN',
                'name'        => 'Finance & Accounting',
                'description' => 'Financial Control, Treasury, Payroll Processing & Tax Compliance',
            ],
            [
                'code'        => 'OPS',
                'name'        => 'Business Operations',
                'description' => 'Facilities Management, Supply Chain, Logistics & Office Operations',
            ],
            [
                'code'        => 'MKT',
                'name'        => 'Sales & Marketing',
                'description' => 'Product Marketing, Sales Pipeline, Brand Strategy & Client Acquisition',
            ],
        ];

        $now = date('Y-m-d H:i:s');
        $existingCols = $this->getTableColumns('departments');
        $hasCompanyId = in_array('company_id', $existingCols, true);
        $hasCode      = in_array('code', $existingCols, true);
        $hasName      = in_array('name', $existingCols, true);

        foreach ($defaultDepts as $dept) {
            // Idempotency check: does this department code or name already exist for this company?
            $builder = $this->db->table('departments');
            if ($hasCompanyId) {
                $builder->where('company_id', $companyId);
            }
            if ($hasCode && $hasName) {
                $builder->groupStart()
                    ->where('code', $dept['code'])
                    ->orWhere('name', $dept['name'])
                ->groupEnd();
            } elseif ($hasCode) {
                $builder->where('code', $dept['code']);
            } elseif ($hasName) {
                $builder->where('name', $dept['name']);
            }
            $existing = $this->safeGetFirstRow($builder);

            if ($existing) {
                $skipped[] = $dept['code'];
                $map[$dept['code']] = $existing['id'] ?? null;
                continue;
            }

            $id = 'DEPT-' . $compCode . '-' . $dept['code'];
            // In case of ID collision with another tenant or legacy format
            if ($this->recordExistsById('departments', $id)) {
                $id = 'dept-' . bin2hex(random_bytes(8));
            }

            $record = [
                'id'          => $id,
                'company_id'  => $companyId,
                'branch_id'   => $branchId,
                'name'        => $dept['name'],
                'code'        => $dept['code'],
                'description' => $dept['description'],
                'status'      => 'active',
                'created_at'  => $now,
                'updated_at'  => $now,
            ];

            $this->safeInsert('departments', $record, $existingCols);
            $created[] = $dept['code'];
            $map[$dept['code']] = $id;
        }

        return ['created' => $created, 'skipped' => $skipped, 'map' => $map];
    }

    /**
     * 2. Initialize Default Designations (Job Positions)
     */
    public function initializeDesignations(string $companyId, string $compCode, array $departmentMap): array
    {
        $created = [];
        $skipped = [];

        // Ensure designations table schema has company_id
        $this->ensureDesignationsCompanyIdColumn();

        $defaultDesignations = [
            'MED_NUR' => [
                ['code' => 'PANEL-PHYS', 'name' => 'Panel Physician', 'grade' => 'P-3', 'salary' => 120000, 'desc' => 'Authorized panel physician for clinical assessment and consultations'],
                ['code' => 'SR-NURSE', 'name' => 'Senior Nurse', 'grade' => 'P-2', 'salary' => 45000, 'desc' => 'Supervises nursing duties, patient triage and ward care'],
                ['code' => 'NURSE', 'name' => 'Nurse', 'grade' => 'P-1', 'salary' => 35000, 'desc' => 'General nursing care, clinical assistance and vital signs monitoring'],
            ],
            'RAD' => [
                ['code' => 'RADIOLOGIST', 'name' => 'Radiologist', 'grade' => 'P-3', 'salary' => 140000, 'desc' => 'Specialist physician interpreting diagnostic medical images'],
                ['code' => 'LEAD-RAD', 'name' => 'Lead Radiographer', 'grade' => 'P-2', 'salary' => 60000, 'desc' => 'Supervises imaging procedures and radiography equipment protocols'],
                ['code' => 'RADIOGRAPHER', 'name' => 'Radiographer', 'grade' => 'P-1', 'salary' => 45000, 'desc' => 'Performs diagnostic radiography, X-ray, ultrasound, CT and MRI scans'],
            ],
            'ADMIN' => [
                ['code' => 'CHAIRMAN', 'name' => 'Chairman', 'grade' => 'EXEC-1', 'salary' => 200000, 'desc' => 'Head of the Board of Directors & Corporate Governance'],
                ['code' => 'MD', 'name' => 'Managing Director', 'grade' => 'EXEC-1', 'salary' => 180000, 'desc' => 'Executive leadership and corporate administration'],
                ['code' => 'CLINIC-MGR', 'name' => 'Clinic Manager', 'grade' => 'M-1', 'salary' => 85000, 'desc' => 'Oversees clinic daily operations, patient flow and facility management'],
                ['code' => 'ADMIN-SUP', 'name' => 'Administration Supervisor', 'grade' => 'M-1', 'salary' => 55000, 'desc' => 'Supervises administrative operations, logistics and support services'],
                ['code' => 'OFF-HR-ADMIN', 'name' => 'Officer-HR & Admin', 'grade' => 'P-1', 'salary' => 45000, 'desc' => 'Human resources administration and office coordination'],
                ['code' => 'RECEPTIONIST', 'name' => 'Receptionist', 'grade' => 'S-1', 'salary' => 28000, 'desc' => 'Front desk reception, patient registration and appointment scheduling'],
                ['code' => 'TEL-OPERATOR', 'name' => 'Telephone Operator', 'grade' => 'S-1', 'salary' => 26000, 'desc' => 'Inbound/outbound call management and switchboard handling'],
                ['code' => 'OFF-ASST', 'name' => 'Office Assistant', 'grade' => 'S-1', 'salary' => 22000, 'desc' => 'General clerical duties and office support tasks'],
                ['code' => 'DRIVER', 'name' => 'Driver', 'grade' => 'S-1', 'salary' => 24000, 'desc' => 'Company transport, patient transit and official dispatches'],
                ['code' => 'SEC-GUARD', 'name' => 'Security Guard', 'grade' => 'S-1', 'salary' => 22000, 'desc' => 'Premises security, access control and surveillance'],
                ['code' => 'CLEANER', 'name' => 'Cleaner', 'grade' => 'S-1', 'salary' => 18000, 'desc' => 'Facility hygiene, sanitation and housekeeping'],
            ],
            'IT' => [
                ['code' => 'IT-SUP', 'name' => 'IT Supervisor', 'grade' => 'M-1', 'salary' => 75000, 'desc' => 'Supervises IT support team, server systems and network infrastructure'],
                ['code' => 'IT-EXEC', 'name' => 'IT Executive', 'grade' => 'P-1', 'salary' => 45000, 'desc' => 'Workstation maintenance, software troubleshooting and network administration'],
                ['code' => 'TECH-LEAD', 'name' => 'Technical Lead / IT Manager', 'grade' => 'M-1', 'salary' => 105000, 'desc' => 'Engineering direction and system infrastructure'],
                ['code' => 'SWE', 'name' => 'Senior Software Engineer', 'grade' => 'P-2', 'salary' => 80000, 'desc' => 'Core software architecture and application development'],
                ['code' => 'SYS-ADMIN', 'name' => 'Systems & Cloud Administrator', 'grade' => 'P-1', 'salary' => 58000, 'desc' => 'Network reliability, devops & workstations'],
            ],
            'LAB' => [
                ['code' => 'PATHOLOGIST', 'name' => 'Pathologist', 'grade' => 'P-3', 'salary' => 135000, 'desc' => 'Specialist medical physician in laboratory pathology and tissue/fluid diagnosis'],
                ['code' => 'LAB-MGR', 'name' => 'Laboratory Manager', 'grade' => 'M-1', 'salary' => 95000, 'desc' => 'Directs laboratory operations, diagnostic quality standards and personnel'],
                ['code' => 'LAB-INCHARGE', 'name' => 'Laboratory In Charge', 'grade' => 'M-1', 'salary' => 80000, 'desc' => 'Oversees lab shift operations, specimen processing and instrument calibration'],
                ['code' => 'SCI-OFF', 'name' => 'Scientific Officer', 'grade' => 'P-2', 'salary' => 65000, 'desc' => 'Conducts specialized scientific testing, reagents control and assay validation'],
                ['code' => 'LAB-TECH', 'name' => 'Laboratory Technologist', 'grade' => 'P-1', 'salary' => 45000, 'desc' => 'Conducts diagnostic lab tests, specimen analysis and reporting'],
                ['code' => 'MED-TECH', 'name' => 'Medical Technologist', 'grade' => 'P-1', 'salary' => 45000, 'desc' => 'Clinical laboratory and medical diagnostic technology procedures'],
            ],
            'FIN_HR' => [
                ['code' => 'MGR-ACC-FIN', 'name' => 'Manager (Accounts & Finance)', 'grade' => 'M-1', 'salary' => 95000, 'desc' => 'Head of accounts, financial reporting, budgeting and tax compliance'],
                ['code' => 'CASHIER', 'name' => 'Cashier', 'grade' => 'S-1', 'salary' => 30000, 'desc' => 'Patient billing, cash register collections and payment receipts'],
            ],
            'EXEC' => [
                ['code' => 'CEO', 'name' => 'Chief Executive Officer', 'grade' => 'EXEC-1', 'salary' => 150000, 'desc' => 'Executive Head & Chief Officer'],
                ['code' => 'COO', 'name' => 'Chief Operating Officer', 'grade' => 'EXEC-1', 'salary' => 130000, 'desc' => 'Directs corporate day-to-day operations'],
            ],
            'HR' => [
                ['code' => 'HR-MGR', 'name' => 'Human Resources Manager', 'grade' => 'M-1', 'salary' => 85000, 'desc' => 'Leads organizational talent management'],
                ['code' => 'HR-OFF', 'name' => 'HR & Talent Specialist', 'grade' => 'P-1', 'salary' => 52000, 'desc' => 'Employee relations and recruitment coordination'],
            ],
            'FIN' => [
                ['code' => 'FIN-MGR', 'name' => 'Finance & Accounting Manager', 'grade' => 'M-1', 'salary' => 90000, 'desc' => 'Manages accounts, cash flow and budget audits'],
                ['code' => 'ACC-SR', 'name' => 'Senior Accountant & Payroll Lead', 'grade' => 'P-2', 'salary' => 65000, 'desc' => 'General ledger, payroll calculation & reporting'],
            ],
            'OPS' => [
                ['code' => 'OPS-MGR', 'name' => 'Operations Manager', 'grade' => 'M-1', 'salary' => 85000, 'desc' => 'Oversees business logistics and daily workflows'],
                ['code' => 'OPS-COORD', 'name' => 'Operations Coordinator', 'grade' => 'P-1', 'salary' => 48000, 'desc' => 'Logistical support and facilities coordination'],
            ],
            'MKT' => [
                ['code' => 'MKT-MGR', 'name' => 'Marketing & Communications Manager', 'grade' => 'M-1', 'salary' => 85000, 'desc' => 'Brand strategy and promotional outreach'],
                ['code' => 'BDA', 'name' => 'Business Development Associate', 'grade' => 'P-1', 'salary' => 46000, 'desc' => 'Lead qualification and partnership pipeline'],
            ],
        ];

        $now = date('Y-m-d H:i:s');
        $existingCols = $this->getTableColumns('designations');
        $hasCompanyCol = in_array('company_id', $existingCols, true);
        $hasDesigCode  = in_array('code', $existingCols, true);
        $hasDesigName  = in_array('name', $existingCols, true);
        $hasDeptIdCol  = in_array('department_id', $existingCols, true);

        foreach ($defaultDesignations as $deptCode => $roles) {
            $deptId = $departmentMap[$deptCode] ?? null;

            // Intelligent fallback department resolution
            if (!$deptId) {
                $fallbackMap = [
                    'ADMIN'   => ['EXEC', 'OPS', 'HR'],
                    'FIN_HR'  => ['FIN', 'HR', 'ADMIN'],
                    'MED_NUR' => ['CLINIC', 'MED', 'HEALTH', 'ADMIN'],
                    'LAB'     => ['MED_NUR', 'PATHOLOGY', 'ADMIN'],
                    'RAD'     => ['MED_NUR', 'IMAGING', 'ADMIN'],
                    'EXEC'    => ['ADMIN'],
                    'HR'      => ['FIN_HR', 'ADMIN'],
                    'FIN'     => ['FIN_HR', 'ADMIN'],
                    'OPS'     => ['ADMIN'],
                ];
                if (isset($fallbackMap[$deptCode])) {
                    foreach ($fallbackMap[$deptCode] as $alias) {
                        if (!empty($departmentMap[$alias])) {
                            $deptId = $departmentMap[$alias];
                            break;
                        }
                    }
                }
            }

            // DB fallback if departmentMap didn't resolve the ID
            if (!$deptId && $hasCompanyCol) {
                $deptBuilder = $this->db->table('departments')->where('company_id', $companyId);
                if ($deptCode === 'MED_NUR') {
                    $deptBuilder->groupStart()->like('name', 'Medical')->orLike('name', 'Nursing')->groupEnd();
                } elseif ($deptCode === 'RAD') {
                    $deptBuilder->like('name', 'Radiology');
                } elseif ($deptCode === 'ADMIN') {
                    $deptBuilder->groupStart()->like('name', 'Administration')->orLike('name', 'Executive')->groupEnd();
                } elseif ($deptCode === 'IT') {
                    $deptBuilder->groupStart()->like('name', 'IT')->orLike('name', 'Technology')->orWhere('code', 'IT')->groupEnd();
                } elseif ($deptCode === 'LAB') {
                    $deptBuilder->like('name', 'Laboratory');
                } elseif ($deptCode === 'FIN_HR') {
                    $deptBuilder->groupStart()->like('name', 'Finance')->orLike('name', 'Accounting')->orLike('name', 'HR')->groupEnd();
                }
                $foundDept = $this->safeGetFirstRow($deptBuilder);
                if ($foundDept && !empty($foundDept['id'])) {
                    $deptId = $foundDept['id'];
                }
            }

            // Ultimate fallback to any department belonging to this company
            if (!$deptId && $hasCompanyCol) {
                $firstDept = $this->safeGetFirstRow($this->db->table('departments')->where('company_id', $companyId));
                if ($firstDept && !empty($firstDept['id'])) {
                    $deptId = $firstDept['id'];
                }
            }

            foreach ($roles as $role) {
                // Idempotency check:
                $builder = $this->db->table('designations');
                if ($hasCompanyCol) {
                    $builder->where('company_id', $companyId);
                }
                $builder->groupStart();
                if ($hasDesigCode) {
                    $builder->where('code', $role['code']);
                }
                if ($hasDesigName) {
                    $builder->orWhere('name', $role['name']);
                }
                $builder->groupEnd();

                $existing = $this->safeGetFirstRow($builder);
                if ($existing) {
                    $skipped[] = $role['code'];
                    continue;
                }

                $id = 'DESIG-' . $compCode . '-' . $role['code'];
                if ($this->recordExistsById('designations', $id)) {
                    $id = 'desig-' . bin2hex(random_bytes(8));
                }

                $record = [
                    'id'             => $id,
                    'department_id'  => $deptId,
                    'name'           => $role['name'],
                    'code'           => $role['code'],
                    'grade'          => $role['grade'],
                    'default_salary' => $role['salary'],
                    'description'    => $role['desc'],
                    'status'         => 'active',
                    'created_at'     => $now,
                    'updated_at'     => $now,
                ];

                if ($hasCompanyCol) {
                    $record['company_id'] = $companyId;
                }

                $this->safeInsert('designations', $record, $existingCols);
                $created[] = $role['code'];
            }
        }

        return ['created' => $created, 'skipped' => $skipped];
    }

    /**
     * 3. Initialize Default Salary Grades
     */
    public function initializeSalaryGrades(string $companyId, string $compCode): array
    {
        $created = [];
        $skipped = [];

        if (!$this->db->tableExists('salary_grades')) {
            return ['created' => [], 'skipped' => []];
        }

        // Self-heal table schema if outside transaction
        if ((int)($this->db->transDepth ?? 0) === 0) {
            $salaryGradeModel = new \App\Models\SalaryGradeModel();
            $salaryGradeModel->ensureSchema();
        }

        $defaultGrades = [
            [
                'code'        => 'EXEC-1',
                'name'        => 'Executive Leadership',
                'min'         => 120000.00,
                'max'         => 250000.00,
                'basic'       => 80000.00,
                'hra'         => 30000.00,
                'medical'     => 15000.00,
                'transport'   => 15000.00,
                'description' => 'C-Suite Executives, Managing Directors & Corporate Officers',
            ],
            [
                'code'        => 'M-1',
                'name'        => 'Senior Management',
                'min'         => 80000.00,
                'max'         => 140000.00,
                'basic'       => 50000.00,
                'hra'         => 20000.00,
                'medical'     => 10000.00,
                'transport'   => 10000.00,
                'description' => 'Department Heads, Senior Directors & Functional Managers',
            ],
            [
                'code'        => 'P-3',
                'name'        => 'Specialist Physician & Consultant',
                'min'         => 100000.00,
                'max'         => 220000.00,
                'basic'       => 70000.00,
                'hra'         => 25000.00,
                'medical'     => 15000.00,
                'transport'   => 10000.00,
                'description' => 'Medical Specialists, Panel Physicians, Radiologists & Pathologists',
            ],
            [
                'code'        => 'P-2',
                'name'        => 'Professional Senior Specialist',
                'min'         => 55000.00,
                'max'         => 90000.00,
                'basic'       => 35000.00,
                'hra'         => 15000.00,
                'medical'     => 7000.00,
                'transport'   => 8000.00,
                'description' => 'Senior Engineers, Senior Accountants, Technical Specialists',
            ],
            [
                'code'        => 'P-1',
                'name'        => 'Professional Associate',
                'min'         => 40000.00,
                'max'         => 65000.00,
                'basic'       => 25000.00,
                'hra'         => 10000.00,
                'medical'     => 5000.00,
                'transport'   => 5000.00,
                'description' => 'Associate Engineers, Coordinators, Specialists & Officers',
            ],
            [
                'code'        => 'S-1',
                'name'        => 'Support & Operational Staff',
                'min'         => 28000.00,
                'max'         => 45000.00,
                'basic'       => 18000.00,
                'hra'         => 7000.00,
                'medical'     => 3500.00,
                'transport'   => 3500.00,
                'description' => 'Administrative Assistants, Customer Support & Operational Technicians',
            ],
        ];

        $now = date('Y-m-d H:i:s');
        $existingCols = $this->getTableColumns('salary_grades');
        $hasCompanyId = in_array('company_id', $existingCols, true);
        $hasGradeCode = in_array('grade_code', $existingCols, true);
        $hasCode      = in_array('code', $existingCols, true);
        $hasGradeName = in_array('grade_name', $existingCols, true);
        $hasName      = in_array('name', $existingCols, true);

        foreach ($defaultGrades as $grade) {
            // Idempotency check:
            $builder = $this->db->table('salary_grades');
            if ($hasCompanyId) {
                $builder->where('company_id', $companyId);
            }
            if ($hasGradeCode && $hasCode) {
                $builder->groupStart()
                    ->where('grade_code', $grade['code'])
                    ->orWhere('code', $grade['code'])
                ->groupEnd();
            } elseif ($hasGradeCode) {
                $builder->where('grade_code', $grade['code']);
            } elseif ($hasCode) {
                $builder->where('code', $grade['code']);
            } elseif ($hasGradeName) {
                $builder->where('grade_name', $grade['name']);
            } elseif ($hasName) {
                $builder->where('name', $grade['name']);
            }

            $existing = $this->safeGetFirstRow($builder);

            if ($existing) {
                $skipped[] = $grade['code'];
                continue;
            }

            $id = 'SG-' . $compCode . '-' . $grade['code'];
            if ($this->recordExistsById('salary_grades', $id)) {
                $id = 'sg-' . bin2hex(random_bytes(8));
            }

            $record = [
                'id'                    => $id,
                'company_id'            => $companyId,
                'grade_name'            => $grade['name'],
                'name'                  => $grade['name'],
                'grade_code'            => $grade['code'],
                'code'                  => $grade['code'],
                'min_salary'            => $grade['min'],
                'minimum_salary'        => $grade['min'],
                'max_salary'            => $grade['max'],
                'maximum_salary'        => $grade['max'],
                'description'           => $grade['description'],
                'status'                => 'Active',
                'created_at'            => $now,
                'updated_at'            => $now,
            ];

            $this->safeInsert('salary_grades', $record, $existingCols);
            $created[] = $grade['code'];
        }

        return ['created' => $created, 'skipped' => $skipped];
    }

    /**
     * 4. Initialize Default Security Policies (Company Scoped)
     */
    public function initializeSecurityPolicies(string $companyId): array
    {
        $created = [];
        $skipped = [];

        if (!$this->db->tableExists('system_settings')) {
            return ['created' => [], 'skipped' => []];
        }

        $defaultPolicies = [
            'password_min_length'        => '8',
            'min_password_length'        => '8',
            'password_expiry_days'       => '90',
            'password_require_numbers'   => '1',
            'require_numbers'            => '1',
            'password_require_symbols'   => '1',
            'require_special_chars'      => '1',
            'password_require_uppercase' => '1',
            'require_mixed_case'         => '1',
            'max_login_attempts'         => '5',
            'lockout_duration_minutes'   => '15',
            'lockout_minutes'            => '15',
            'session_timeout_minutes'    => '60',
            'allowed_ip_whitelist'       => '',
            'ip_whitelist'               => '',
            'mfa_policy'                 => 'Optional',
            'require_two_factor'         => '0',
            'enforce_2fa_admins'         => '0',
            'allow_simultaneous_logins'  => '1',
            'disallow_concurrent_logins' => '0',
            'audit_retention_days'       => '365',
        ];

        $now = date('Y-m-d H:i:s');
        $existingCols = $this->getTableColumns('system_settings');
        $hasCompanyId = in_array('company_id', $existingCols, true);
        $hasKey = in_array('setting_key', $existingCols, true) ? 'setting_key' : (in_array('key', $existingCols, true) ? 'key' : null);

        foreach ($defaultPolicies as $key => $val) {
            $builder = $this->db->table('system_settings');
            if ($hasCompanyId) {
                $builder->where('company_id', $companyId);
            }
            if ($hasKey) {
                $builder->where($hasKey, $key);
            }
            $existing = $this->safeGetFirstRow($builder);

            if ($existing) {
                $skipped[] = $key;
                continue;
            }

            $record = [
                'company_id'    => $companyId,
                'setting_group' => 'security',
                'setting_key'   => $key,
                'setting_value' => (string)$val,
                'created_at'    => $now,
                'updated_at'    => $now,
            ];

            // If system_settings uses UUID id primary key
            if (in_array('id', $existingCols, true)) {
                $record['id'] = 'set-' . bin2hex(random_bytes(8));
            }

            $this->safeInsert('system_settings', $record, $existingCols);
            $created[] = $key;
        }

        return ['created' => $created, 'skipped' => $skipped];
    }

    /**
     * 5. Initialize Default Work Shifts
     */
    public function initializeWorkShifts(string $companyId, ?string $branchId, string $compCode): array
    {
        $created = [];
        $skipped = [];

        if (!$this->db->tableExists('shifts')) {
            return ['created' => [], 'skipped' => []];
        }

        $defaultShifts = [
            [
                'code'                     => 'DAY',
                'name'                     => 'General Day Shift',
                'start_time'               => '09:00:00',
                'end_time'                 => '17:00:00',
                'break_start'              => '13:00:00',
                'break_end'                => '14:00:00',
                'break_duration_minutes'   => 60,
                'grace_time'               => 15,
                'late_grace_period_mins'   => 15,
                'minimum_working_hours'    => 8.00,
                'half_day_threshold_hours' => 4.00,
            ],
            [
                'code'                     => 'MORNING',
                'name'                     => 'Early Morning Shift',
                'start_time'               => '08:00:00',
                'end_time'                 => '16:00:00',
                'break_start'              => '12:00:00',
                'break_end'                => '13:00:00',
                'break_duration_minutes'   => 60,
                'grace_time'               => 15,
                'late_grace_period_mins'   => 15,
                'minimum_working_hours'    => 8.00,
                'half_day_threshold_hours' => 4.00,
            ],
            [
                'code'                     => 'EVENING',
                'name'                     => 'Evening Shift',
                'start_time'               => '16:00:00',
                'end_time'                 => '00:00:00',
                'break_start'              => '20:00:00',
                'break_end'                => '21:00:00',
                'break_duration_minutes'   => 60,
                'grace_time'               => 15,
                'late_grace_period_mins'   => 15,
                'minimum_working_hours'    => 8.00,
                'half_day_threshold_hours' => 4.00,
            ],
            [
                'code'                     => 'FLEXI',
                'name'                     => 'Flexible Working Hours',
                'start_time'               => '09:00:00',
                'end_time'                 => '18:00:00',
                'break_start'              => '13:00:00',
                'break_end'                => '14:00:00',
                'break_duration_minutes'   => 60,
                'grace_time'               => 30,
                'late_grace_period_mins'   => 30,
                'minimum_working_hours'    => 8.00,
                'half_day_threshold_hours' => 4.00,
            ],
        ];

        $now = date('Y-m-d H:i:s');
        $existingCols = $this->getTableColumns('shifts');
        $hasCompanyId = in_array('company_id', $existingCols, true);
        $hasCode      = in_array('code', $existingCols, true);
        $hasName      = in_array('name', $existingCols, true);

        foreach ($defaultShifts as $shift) {
            $builder = $this->db->table('shifts');
            if ($hasCompanyId) {
                $builder->where('company_id', $companyId);
            }
            if ($hasCode) {
                $builder->where('code', $shift['code']);
            } elseif ($hasName) {
                $builder->where('name', $shift['name']);
            }
            $existing = $this->safeGetFirstRow($builder);

            if ($existing) {
                $skipped[] = $shift['code'];
                continue;
            }

            $id = 'SHIFT-' . $compCode . '-' . $shift['code'];
            if ($this->recordExistsById('shifts', $id)) {
                $id = 'shift-' . bin2hex(random_bytes(8));
            }

            $record = array_merge($shift, [
                'id'         => $id,
                'company_id' => $companyId,
                'branch_id'  => $branchId,
                'status'     => 'active',
                'created_at' => $now,
                'updated_at' => $now,
            ]);

            $this->safeInsert('shifts', $record, $existingCols);
            $created[] = $shift['code'];
        }

        return ['created' => $created, 'skipped' => $skipped];
    }

    /**
     * 6. Initialize Default Holiday Calendar
     */
    public function initializeHolidayCalendar(string $companyId, ?string $branchId, string $compCode, array $options = []): array
    {
        $created = [];
        $skipped = [];

        if (!$this->db->tableExists('holidays')) {
            return ['created' => [], 'skipped' => []];
        }

        $currentYear = (int)($options['year'] ?? date('Y'));
        $years = [$currentYear];
        // If late in the year (after Sept), also seed upcoming year
        if ((int)date('m') >= 10) {
            $years[] = $currentYear + 1;
        }

        $now = date('Y-m-d H:i:s');
        $existingCols = $this->getTableColumns('holidays');

        // Resolve company's registered country
        $companyCountry = $options['country'] ?? null;
        if (empty($companyCountry)) {
            try {
                $compRow = $this->db->table('companies')->select('country')->where('id', $companyId)->get()->getFirstRow();
                if ($compRow && !empty($compRow->country)) {
                    $companyCountry = $compRow->country;
                }
            } catch (\Throwable $e) {}
        }

        $pubHolidayService = new \App\Services\PublicHolidayService();
        $targetCountry = $companyCountry ?: 'US';

        foreach ($years as $year) {
            $fetched = $pubHolidayService->fetchPublicHolidays($targetCountry, $year);
            $apiHolidays = $fetched['holidays'] ?? [];

            if (!empty($apiHolidays)) {
                $holidays = array_map(function($item, $idx) use ($year) {
                    return [
                        'code'        => 'HOL' . ($idx + 1),
                        'name'        => $item['name'],
                        'date'        => $item['date'],
                        'from_date'   => $item['from_date'] ?? $item['date'],
                        'to_date'     => $item['to_date'] ?? $item['date'],
                        'total_days'  => 1,
                        'type'        => 'public',
                        'description' => $item['description'] ?? 'Official statutory public holiday',
                    ];
                }, $apiHolidays, array_keys($apiHolidays));
            } else {
                $holidays = [
                    [
                        'code'        => 'NYD',
                        'name'        => "New Year's Day",
                        'date'        => "{$year}-01-01",
                        'from_date'   => "{$year}-01-01",
                        'to_date'     => "{$year}-01-01",
                        'total_days'  => 1,
                        'type'        => 'public',
                        'description' => "Statutory New Year's Day celebration",
                    ],
                    [
                        'code'        => 'LABOR',
                        'name'        => "International Workers' Day",
                        'date'        => "{$year}-05-01",
                        'from_date'   => "{$year}-05-01",
                        'to_date'     => "{$year}-05-01",
                        'total_days'  => 1,
                        'type'        => 'public',
                        'description' => "Global Labor & Workers' Solidarity Holiday",
                    ],
                ];
            }

            foreach ($holidays as $h) {
                // Idempotency check:
                $builder = $this->db->table('holidays');
                if (in_array('company_id', $existingCols, true)) {
                    $builder->where('company_id', $companyId);
                }
                if (in_array('name', $existingCols, true)) {
                    $builder->where('name', $h['name']);
                }

                if (in_array('from_date', $existingCols, true)) {
                    $builder->where('from_date', $h['from_date']);
                } elseif (in_array('date', $existingCols, true)) {
                    $builder->where('date', $h['date']);
                }

                $existing = $this->safeGetFirstRow($builder);
                if ($existing) {
                    $skipped[] = "{$h['code']}-{$year}";
                    continue;
                }

                $id = 'HOL-' . $compCode . '-' . $year . '-' . $h['code'];
                if ($this->recordExistsById('holidays', $id)) {
                    $id = 'hol-' . bin2hex(random_bytes(8));
                }

                $record = array_merge($h, [
                    'id'             => $id,
                    'company_id'     => $companyId,
                    'branch_id'      => $branchId,
                    'status'         => 'active',
                    'is_working_day' => 0,
                    'created_at'     => $now,
                    'updated_at'     => $now,
                ]);

                $this->safeInsert('holidays', $record, $existingCols);
                $created[] = "{$h['code']}-{$year}";
            }
        }

        return ['created' => $created, 'skipped' => $skipped];
    }

    /**
     * 7. Initialize Default Employment Types
     */
    public function initializeEmploymentTypes(string $companyId, string $compCode): array
    {
        $created = [];
        $skipped = [];

        if (!$this->db->tableExists('employment_types')) {
            return ['created' => [], 'skipped' => []];
        }

        $defaultTypes = [
            [
                'code'                  => 'FULL-TIME',
                'name'                  => 'Full-Time Regular',
                'description'           => 'Permanent full-time salaried staff with full benefits & standard entitlements.',
                'overtime_eligibility'  => 1,
                'benefits_eligibility'  => 1,
                'payroll_rule'          => 'Standard Monthly',
                'duration_enabled'      => 0,
                'duration_value'        => null,
                'duration_unit'         => null,
                'expiry_reminder_days'  => null,
            ],
            [
                'code'                  => 'PART-TIME',
                'name'                  => 'Part-Time Employee',
                'description'           => 'Part-time hourly or reduced-schedule staff with pro-rata allocations.',
                'overtime_eligibility'  => 1,
                'benefits_eligibility'  => 0,
                'payroll_rule'          => 'Hourly / Pro-Rata',
                'duration_enabled'      => 0,
                'duration_value'        => null,
                'duration_unit'         => null,
                'expiry_reminder_days'  => null,
            ],
            [
                'code'                  => 'PROBATION',
                'name'                  => 'Probationary Staff',
                'description'           => 'Initial evaluation and trial employment period (default 6 months).',
                'overtime_eligibility'  => 0,
                'benefits_eligibility'  => 0,
                'payroll_rule'          => 'Standard Monthly',
                'duration_enabled'      => 1,
                'duration_value'        => 6,
                'duration_unit'         => 'months',
                'expiry_reminder_days'  => 14,
            ],
            [
                'code'                  => 'CONTRACT',
                'name'                  => 'Contract / Fixed-Term',
                'description'           => 'Fixed duration employment contract with renewable tenure.',
                'overtime_eligibility'  => 1,
                'benefits_eligibility'  => 1,
                'payroll_rule'          => 'Contract Stipend',
                'duration_enabled'      => 1,
                'duration_value'        => 12,
                'duration_unit'         => 'months',
                'expiry_reminder_days'  => 30,
            ],
            [
                'code'                  => 'INTERN',
                'name'                  => 'Intern / Trainee',
                'description'           => 'Short-term learning placement or academic internship tenure.',
                'overtime_eligibility'  => 0,
                'benefits_eligibility'  => 0,
                'payroll_rule'          => 'Fixed Stipend',
                'duration_enabled'      => 1,
                'duration_value'        => 3,
                'duration_unit'         => 'months',
                'expiry_reminder_days'  => 7,
            ],
        ];

        $now = date('Y-m-d H:i:s');
        $existingCols = $this->getTableColumns('employment_types');
        $hasCompanyId = in_array('company_id', $existingCols, true);
        $hasCode      = in_array('code', $existingCols, true);
        $hasName      = in_array('name', $existingCols, true);

        foreach ($defaultTypes as $type) {
            $builder = $this->db->table('employment_types');
            if ($hasCompanyId) {
                $builder->where('company_id', $companyId);
            }
            if ($hasCode) {
                $builder->where('code', $type['code']);
            } elseif ($hasName) {
                $builder->where('name', $type['name']);
            }
            $existing = $this->safeGetFirstRow($builder);

            if ($existing) {
                $skipped[] = $type['code'];
                continue;
            }

            $id = 'ET-' . $compCode . '-' . $type['code'];
            if ($this->recordExistsById('employment_types', $id)) {
                $id = 'et-' . bin2hex(random_bytes(8));
            }

            $record = array_merge($type, [
                'id'         => $id,
                'company_id' => $companyId,
                'status'     => 'active',
                'created_at' => $now,
                'updated_at' => $now,
            ]);

            $this->safeInsert('employment_types', $record, $existingCols);
            $created[] = $type['code'];
        }

        return ['created' => $created, 'skipped' => $skipped];
    }

    /**
     * 8. Initialize Default Leave Types & Policies
     */
    public function initializeLeaveTypesAndQuotas(string $companyId, string $compCode): array
    {
        $createdTypes    = [];
        $skippedTypes    = [];
        $createdPolicies = [];
        $skippedPolicies = [];

        if (!$this->db->tableExists('leave_types')) {
            return [
                'created_types'    => [],
                'skipped_types'    => [],
                'created_policies' => [],
                'skipped_policies' => [],
            ];
        }

        $defaultLeaveTypes = [
            [
                'code'              => 'AL',
                'name'              => 'Annual Leave',
                'description'       => 'Statutory paid vacation leave for confirmed full-time staff.',
                'applicable_gender' => 'All',
            ],
            [
                'code'              => 'SL',
                'name'              => 'Sick / Medical Leave',
                'description'       => 'Health-related recovery with medical certificate verification.',
                'applicable_gender' => 'All',
            ],
            [
                'code'              => 'CL',
                'name'              => 'Casual Leave',
                'description'       => 'Short unplanned personal absences and urgent family errands.',
                'applicable_gender' => 'All',
            ],
            [
                'code'              => 'EL',
                'name'              => 'Earned Leave',
                'description'       => 'Accrued service leave with encashment and carry-forward support.',
                'applicable_gender' => 'All',
            ],
            [
                'code'              => 'ML',
                'name'              => 'Maternity Leave',
                'description'       => 'Statutory paid maternity benefit for female personnel.',
                'applicable_gender' => 'Female',
            ],
            [
                'code'              => 'PL',
                'name'              => 'Paternity Leave',
                'description'       => 'Paid parental bonding leave for new fathers.',
                'applicable_gender' => 'Male',
            ],
            [
                'code'              => 'LWP',
                'name'              => 'Leave Without Pay',
                'description'       => 'Authorized unpaid absence subject to management pre-approval.',
                'applicable_gender' => 'All',
            ],
            [
                'code'              => 'SPL',
                'name'              => 'Special Leave',
                'description'       => 'Authorized special leave for exceptional circumstances, bereavement, or statutory duties.',
                'applicable_gender' => 'All',
            ],
        ];

        $now = date('Y-m-d H:i:s');
        $existingCols = $this->getTableColumns('leave_types');
        $hasCompanyId = in_array('company_id', $existingCols, true);
        $hasCode      = in_array('code', $existingCols, true);
        $hasName      = in_array('name', $existingCols, true);

        $typeMap = [];
        foreach ($defaultLeaveTypes as $lt) {
            $builder = $this->db->table('leave_types');
            if ($hasCompanyId) {
                $builder->where('company_id', $companyId);
            }
            if ($hasCode) {
                $builder->where('code', $lt['code']);
            } elseif ($hasName) {
                $builder->where('name', $lt['name']);
            }
            $existing = $this->safeGetFirstRow($builder);

            if ($existing) {
                $skippedTypes[] = $lt['code'];
                $typeMap[$lt['code']] = $existing['id'] ?? null;
                continue;
            }

            $id = 'LT-' . $compCode . '-' . $lt['code'];
            if ($this->recordExistsById('leave_types', $id)) {
                $id = 'lt-' . bin2hex(random_bytes(8));
            }

            $record = array_merge($lt, [
                'id'         => $id,
                'company_id' => $companyId,
                'status'     => 'active',
                'created_at' => $now,
                'updated_at' => $now,
            ]);

            $this->safeInsert('leave_types', $record, $existingCols);
            $createdTypes[] = $lt['code'];
            $typeMap[$lt['code']] = $id;
        }

        return [
            'created_types'    => $createdTypes,
            'skipped_types'    => $skippedTypes,
        ];
    }

    /**
     * 9. Initialize Default Salary Components
     *
     * @param string $companyId
     * @param string $compCode
     * @return array ['created' => array, 'skipped' => array, 'map' => array]
     */
    public function initializeSalaryComponents(string $companyId, string $compCode): array
    {
        $created = [];
        $skipped = [];
        $componentMap = [];

        $table = 'salary_components';
        $allowedCols = $this->getTableColumns($table);
        $now = date('Y-m-d H:i:s');

        foreach (self::DEFAULT_SALARY_COMPONENTS as $def) {
            $code = $def['code'];

            // Idempotent: check if component with same company_id and code exists (where branch_id IS NULL or empty)
            $builder = $this->db->table($table);
            if (in_array('company_id', $allowedCols, true)) {
                $builder->where('company_id', $companyId);
            }
            if (in_array('code', $allowedCols, true)) {
                $builder->where('code', $code);
            } elseif (in_array('name', $allowedCols, true)) {
                $builder->where('name', $def['name']);
            }
            if (in_array('branch_id', $allowedCols, true)) {
                $builder->groupStart()
                    ->where('branch_id', null)
                    ->orWhere('branch_id', '')
                ->groupEnd();
            }
            $existing = $this->safeGetFirstRow($builder);

            if ($existing) {
                $skipped[] = $code;
                $componentMap[$code] = $existing['id'] ?? null;
                continue;
            }

            // ID generation: 'SC-'.$compCode.'-'.$code if <= 36 chars and unused, otherwise 'sc-'.bin2hex(random_bytes(8))
            $candidateId = 'SC-' . $compCode . '-' . $code;
            if (strlen($candidateId) <= 36 && !$this->recordExistsById($table, $candidateId)) {
                $componentId = $candidateId;
            } else {
                $componentId = 'sc-' . bin2hex(random_bytes(8));
            }

            $record = array_merge($def, [
                'id'         => $componentId,
                'company_id' => $companyId,
                'branch_id'  => null,
                'is_system'  => 1,
                'created_at' => $now,
                'updated_at' => $now,
            ]);

            $inserted = $this->safeInsert($table, $record, $allowedCols);
            if ($inserted) {
                $created[] = $code;
                $componentMap[$code] = $componentId;
            }
        }

        return [
            'created' => $created,
            'skipped' => $skipped,
            'map'     => $componentMap,
        ];
    }

    /**
     * 10. Initialize Default Salary Structures & Items
     *
     * @param string $companyId
     * @param string $compCode
     * @param array $componentMap Optional map of code => component_id
     * @return array ['created' => array, 'skipped' => array]
     */
    public function initializeSalaryStructures(string $companyId, string $compCode, array $componentMap = []): array
    {
        $created = [];
        $skipped = [];

        $structTable = 'salary_structures';
        $itemTable   = 'salary_structure_items';
        $structCols  = $this->getTableColumns($structTable);
        $itemCols    = $this->getTableColumns($itemTable);
        $now         = date('Y-m-d H:i:s');

        $structDef = self::DEFAULT_SALARY_STRUCTURE;
        $code = $structDef['code'];

        // Idempotent: check if structure with same company_id and code exists (where branch_id IS NULL or empty)
        $builder = $this->db->table($structTable);
        if (in_array('company_id', $structCols, true)) {
            $builder->where('company_id', $companyId);
        }
        if (in_array('code', $structCols, true)) {
            $builder->where('code', $code);
        } elseif (in_array('name', $structCols, true)) {
            $builder->where('name', $structDef['name']);
        }
        if (in_array('branch_id', $structCols, true)) {
            $builder->groupStart()
                ->where('branch_id', null)
                ->orWhere('branch_id', '')
            ->groupEnd();
        }
        $existing = $this->safeGetFirstRow($builder);

        if ($existing) {
            $skipped[] = $code;
            return [
                'created' => $created,
                'skipped' => $skipped,
            ];
        }

        // Structure ID generation: 'SS-'.$compCode.'-'.$code if <= 36 chars and unused, otherwise 'str-'.bin2hex(random_bytes(8))
        $candidateId = 'SS-' . $compCode . '-' . $code;
        if (strlen($candidateId) <= 36 && !$this->recordExistsById($structTable, $candidateId)) {
            $structureId = $candidateId;
        } else {
            $structureId = 'str-' . bin2hex(random_bytes(8));
        }

        $structRecord = [
            'id'          => $structureId,
            'company_id'  => $companyId,
            'branch_id'   => null,
            'name'        => $structDef['name'],
            'code'        => $structDef['code'],
            'description' => $structDef['description'],
            'is_default'  => $structDef['is_default'],
            'status'      => $structDef['status'],
            'created_at'  => $now,
            'updated_at'  => $now,
        ];

        $inserted = $this->safeInsert($structTable, $structRecord, $structCols);
        if (!$inserted) {
            return [
                'created' => $created,
                'skipped' => $skipped,
            ];
        }

        $created[] = $code;

        // Build component definition lookup
        $compDefs = [];
        foreach (self::DEFAULT_SALARY_COMPONENTS as $cDef) {
            $compDefs[$cDef['code']] = $cDef;
        }

        // Insert structure items: BASIC, HRA, MED, CONV, PF, TAX
        foreach ($structDef['item_codes'] as $itemCode) {
            $cDef = $compDefs[$itemCode] ?? null;
            $componentId = $componentMap[$itemCode] ?? null;

            if (empty($componentId)) {
                $cCols = $this->getTableColumns('salary_components');
                $builder = $this->db->table('salary_components');
                if (in_array('company_id', $cCols, true)) {
                    $builder->where('company_id', $companyId);
                }
                if (in_array('code', $cCols, true)) {
                    $builder->where('code', $itemCode);
                }
                if (in_array('branch_id', $cCols, true)) {
                    $builder->groupStart()
                        ->where('branch_id', null)
                        ->orWhere('branch_id', '')
                    ->groupEnd();
                }
                $compRow = $this->safeGetFirstRow($builder);
                if ($compRow) {
                    $componentId = $compRow['id'] ?? null;
                    if (!$cDef) {
                        $cDef = $compRow;
                    }
                }
            }

            if (empty($componentId)) {
                continue;
            }

            $itemId = 'item-' . bin2hex(random_bytes(8));
            $itemRecord = [
                'id'                   => $itemId,
                'company_id'           => $companyId,
                'structure_id'         => $structureId,
                'component_id'         => $componentId,
                'calculation_type'     => $cDef['calculation_type'] ?? 'fixed',
                'calculation_base'     => $cDef['calculation_base'] ?? 'Basic Salary',
                'default_value'        => (float)($cDef['amount'] ?? 0.00),
                'percentage'           => (float)($cDef['percentage'] ?? 0.00),
                'custom_formula'       => null,
                'is_enabled'           => 1,
                'is_included_in_gross' => (int)($cDef['is_included_in_gross'] ?? 1),
                'is_included_in_ctc'   => (int)($cDef['is_included_in_ctc'] ?? 1),
                'is_taxable'           => (int)($cDef['is_taxable'] ?? 1),
                'is_statutory'         => (int)($cDef['is_statutory'] ?? 0),
                'sort_order'           => (int)($cDef['display_order'] ?? 1),
                'created_at'           => $now,
                'updated_at'           => $now,
            ];

            $this->safeInsert($itemTable, $itemRecord, $itemCols);
        }

        return [
            'created' => $created,
            'skipped' => $skipped,
        ];
    }

    /**
     * Safely executes a query builder get() and retrieves the first row as an array,
     * guarding against query errors, non-object return types, or false results.
     */
    protected function safeGetFirstRow($builder): ?array
    {
        try {
            if (!$builder) {
                return null;
            }
            $result = $builder->get();
            if ($result && is_object($result) && method_exists($result, 'getFirstRow')) {
                return $result->getFirstRow('array') ?: null;
            }
        } catch (\Throwable $e) {
            log_message('warning', 'safeGetFirstRow caught error: ' . $e->getMessage());
        }
        return null;
    }

    /**
     * Helpers for defensive schema inspection and insertion
     */
    protected function getTableColumns(string $table): array
    {
        try {
            return $this->db->getFieldNames($table) ?: [];
        } catch (\Throwable $e) {
            return [];
        }
    }

    protected function recordExistsById(string $table, string $id): bool
    {
        try {
            return (bool)$this->db->table($table)->where('id', $id)->countAllResults();
        } catch (\Throwable $e) {
            return false;
        }
    }

    protected function safeInsert(string $table, array $data, array $allowedColumns): bool
    {
        if (!empty($allowedColumns)) {
            $filtered = [];
            foreach ($data as $key => $value) {
                if (in_array($key, $allowedColumns, true)) {
                    $filtered[$key] = $value;
                }
            }
            $data = $filtered;
        }

        return (bool)$this->db->table($table)->insert($data);
    }

    /**
     * Ensures designations table has company_id column with index
     */
    protected function ensureDesignationsCompanyIdColumn(): void
    {
        try {
            if ((int)($this->db->transDepth ?? 0) > 0) {
                return;
            }
            if ($this->db->tableExists('designations')) {
                $fields = $this->db->getFieldNames('designations');
                $cols = array_map('strtolower', $fields);
                if (!in_array('company_id', $cols, true)) {
                    $forge = Database::forge();
                    $forge->addColumn('designations', [
                        'company_id' => [
                            'type'       => 'VARCHAR',
                            'constraint' => 36,
                            'null'       => true,
                            'after'      => 'id'
                        ]
                    ]);
                    try {
                        $this->db->query("ALTER TABLE designations ADD INDEX idx_designations_company_id (company_id)");
                    } catch (\Throwable $e) {
                        // ignore index creation error
                    }
                }
            }
        } catch (\Throwable $e) {
            // ignore schema error
        }
    }

    /**
     * Initializes company-scoped RBAC roles and default permission matrices.
     * Ensures every tenant company gets its own independent set of standard roles
     * with company_id set, eliminating the need to clone global template roles.
     *
     * @param string $companyId
     * @param string $compCode
     * @return array
     */
    public function initializeCompanyRoles(string $companyId, string $compCode): array
    {
        $created = [];
        $skipped = [];
        $now = date('Y-m-d H:i:s');

        if (!$this->db->tableExists('roles')) {
            return ['created' => $created, 'skipped' => $skipped, 'roles' => []];
        }

        $config = new \Config\Permissions();
        $hasCompanyCol   = $this->db->fieldExists('company_id', 'roles');
        $hasIsSystem     = $this->db->fieldExists('is_system', 'roles');
        $hasPermVersion  = $this->db->fieldExists('permission_version', 'roles');
        $hasRpId         = $this->db->tableExists('role_permissions') && $this->db->fieldExists('id', 'role_permissions');
        $hasRpCreatedAt  = $this->db->tableExists('role_permissions') && $this->db->fieldExists('created_at', 'role_permissions');
        $hasRpScope      = $this->db->tableExists('role_permissions') && $this->db->fieldExists('scope_level', 'role_permissions');

        // Cache all permission IDs by code
        $allPermissions = $this->db->table('permissions')->get()->getResultArray();
        $permIdMap = [];
        foreach ($allPermissions as $p) {
            $permIdMap[$p['code']] = $p['id'];
        }

        $platformList = $config->platformOnlyPermissions ?? [
            'system.view', 'system.manage', 'system.delete', 'company.create', 'platform.admin'
        ];

        // 9 Standard Tenant Roles (software_app_admin is excluded because it is platform root)
        $standardRoles = [
            'company_admin'  => $config->systemRoles['company_admin'] ?? [
                'name' => 'Company Admin', 'code' => 'company_admin', 'description' => 'Top organizational executive and tenant administrative controller'
            ],
            'hr_admin'       => $config->systemRoles['hr_admin'] ?? [
                'name' => 'HR Admin', 'code' => 'hr_admin', 'description' => 'Full human resources, policies, and employee lifecycle management'
            ],
            'hr_officer'     => $config->systemRoles['hr_officer'] ?? [
                'name' => 'HR Officer', 'code' => 'hr_officer', 'description' => 'Day-to-day HR operations, onboarding, and leaves record-keeping'
            ],
            'branch_manager' => $config->systemRoles['branch_manager'] ?? [
                'name' => 'Branch Manager', 'code' => 'branch_manager', 'description' => 'Branch executive overseeing branch operations, attendance, and branch personnel'
            ],
            'finance'        => $config->systemRoles['finance'] ?? [
                'name' => 'Finance', 'code' => 'finance', 'description' => 'Payroll runs, bonus calculations, and loan disbursement authority'
            ],
            'manager'        => $config->systemRoles['manager'] ?? [
                'name' => 'Manager', 'code' => 'manager', 'description' => 'Department head with staff approval, rosters, and KPI assessment authority'
            ],
            'team_leader'    => $config->systemRoles['team_leader'] ?? [
                'name' => 'Team Leader', 'code' => 'team_leader', 'description' => 'Operational unit supervisor with shift and attendance verification'
            ],
            'employee'       => $config->systemRoles['employee'] ?? [
                'name' => 'Employee', 'code' => 'employee', 'description' => 'Staff member self-service portal, clocking, and leave requests'
            ],
            'auditor'        => $config->systemRoles['auditor'] ?? [
                'name' => 'Auditor', 'code' => 'auditor', 'description' => 'Compliance reviewer with read-only audit and analytics export access'
            ],
        ];

        $roleIdByCode = [];

        foreach ($standardRoles as $code => $rDef) {
            // Check if company already has this role
            $builder = $this->db->table('roles');
            if ($hasCompanyCol) {
                $builder->where('company_id', $companyId);
            }
            $existing = $builder->where('code', $code)->get()->getRowArray();

            if ($existing) {
                $roleId = $existing['id'];
                $roleIdByCode[$code] = $roleId;
                $skipped[] = $code;

                // Ensure is_system = 1 and company_id is set
                $updData = [];
                if ($hasIsSystem && empty($existing['is_system'])) {
                    $updData['is_system'] = 1;
                }
                if ($hasCompanyCol && empty($existing['company_id'])) {
                    $updData['company_id'] = $companyId;
                }
                if (!empty($updData)) {
                    $this->db->table('roles')->where('id', $roleId)->update($updData);
                }
            } else {
                $roleId = 'role-' . substr(md5($companyId . ':' . $code), 0, 16);
                // In case of ID collision with legacy global IDs
                if ($this->db->table('roles')->where('id', $roleId)->countAllResults() > 0) {
                    $roleId = 'r-' . bin2hex(random_bytes(8));
                }

                $roleData = [
                    'id'          => $roleId,
                    'name'        => $rDef['name'],
                    'code'        => $code,
                    'description' => $rDef['description'],
                    'status'      => 'Active',
                    'created_at'  => $now,
                    'updated_at'  => $now,
                ];
                if ($hasCompanyCol) {
                    $roleData['company_id'] = $companyId;
                }
                if ($hasIsSystem) {
                    $roleData['is_system'] = 1;
                }
                if ($hasPermVersion) {
                    $roleData['permission_version'] = 1;
                }

                $this->db->table('roles')->insert($roleData);
                $roleIdByCode[$code] = $roleId;
                $created[] = $code;
            }

            // Provision role_permissions for this company role
            if ($this->db->tableExists('role_permissions')) {
                $rolePermCodesWithScope = [];

                if ($code === 'company_admin') {
                    // Company Admin gets all tenant/business permissions
                    foreach ($allPermissions as $p) {
                        $pCode = $p['code'];
                        $isPlatform = in_array($pCode, $platformList, true)
                            || str_starts_with($pCode, 'system.')
                            || str_starts_with($pCode, 'platform.')
                            || in_array($pCode, ['company.create', 'company.delete', 'companies.create', 'companies.delete', 'module_toggle', 'modules.toggle'], true);
                        if (!$isPlatform) {
                            $rolePermCodesWithScope[$pCode] = 'company';
                        }
                    }
                } elseif (isset($config->roleDefaultMatrix[$code])) {
                    $spec = $config->roleDefaultMatrix[$code];
                    $scopeLevel = $spec['scope'] ?? 'company';
                    foreach ($spec['permissions'] ?? [] as $c) {
                        $rolePermCodesWithScope[$c] = $scopeLevel;
                    }
                }

                if (!empty($rolePermCodesWithScope)) {
                    // Expand paired aliases (leaves <-> leave, rostering <-> roster, etc.)
                    $expanded = $rolePermCodesWithScope;
                    foreach ($rolePermCodesWithScope as $c => $sl) {
                        $pairs = [];
                        if (str_starts_with($c, 'leaves.')) {
                            $pairs[] = 'leave.' . substr($c, 7);
                        } elseif (str_starts_with($c, 'leave.')) {
                            $pairs[] = 'leaves.' . substr($c, 6);
                        } elseif (str_starts_with($c, 'rostering.')) {
                            $pairs[] = 'roster.' . substr($c, 10);
                        } elseif (str_starts_with($c, 'roster.')) {
                            $pairs[] = 'rostering.' . substr($c, 7);
                        } elseif (str_starts_with($c, 'company_expense.')) {
                            $pairs[] = 'expenses.' . substr($c, 16);
                        } elseif (str_starts_with($c, 'expenses.')) {
                            $pairs[] = 'company_expense.' . substr($c, 9);
                        } elseif (str_starts_with($c, 'medical_insurance.')) {
                            $pairs[] = 'insurance.' . substr($c, 18);
                        } elseif (str_starts_with($c, 'insurance.')) {
                            $pairs[] = 'medical_insurance.' . substr($c, 10);
                        } elseif (str_starts_with($c, 'directory.')) {
                            $pairs[] = 'employees.' . substr($c, 10);
                        } elseif (str_starts_with($c, 'employees.')) {
                            $pairs[] = 'directory.' . substr($c, 10);
                        } elseif (str_starts_with($c, 'users.')) {
                            $pairs[] = 'user.' . substr($c, 6);
                        } elseif (str_starts_with($c, 'user.')) {
                            $pairs[] = 'users.' . substr($c, 5);
                        } elseif (str_starts_with($c, 'roles.')) {
                            $pairs[] = 'role.' . substr($c, 6);
                        } elseif (str_starts_with($c, 'role.')) {
                            $pairs[] = 'roles.' . substr($c, 5);
                        }
                        foreach ($pairs as $pc) {
                            if (!isset($expanded[$pc]) && isset($permIdMap[$pc])) {
                                $expanded[$pc] = $sl;
                            }
                        }
                    }

                    // Existing role permissions in DB for this role
                    $existingRpPermIds = $this->db->table('role_permissions')
                        ->where('role_id', $roleId)
                        ->select('permission_id')
                        ->get()
                        ->getResultArray();
                    $assignedPermIdSet = array_fill_keys(array_column($existingRpPermIds, 'permission_id'), true);

                    $rpBatch = [];
                    foreach ($expanded as $permCode => $scope) {
                        $pId = $permIdMap[$permCode] ?? null;
                        if (!$pId || isset($assignedPermIdSet[$pId])) {
                            continue;
                        }

                        $rpRow = [
                            'role_id'       => $roleId,
                            'permission_id' => $pId,
                        ];
                        if ($hasRpScope) {
                            $rpRow['scope_level'] = $scope ?: 'company';
                        }
                        if ($hasRpId) {
                            $rpRow['id'] = 'rp-' . substr(md5($roleId . ':' . $pId), 0, 16);
                        }
                        if ($hasRpCreatedAt) {
                            $rpRow['created_at'] = $now;
                        }
                        $rpBatch[] = $rpRow;
                        $assignedPermIdSet[$pId] = true;
                    }

                    if (!empty($rpBatch)) {
                        $this->db->table('role_permissions')->insertBatch($rpBatch);
                    }
                }
            }
        }

        // Migrate any users in this company currently bound to a global/system role to their company's role
        if ($this->db->tableExists('users')) {
            $companyUsers = $this->db->table('users')
                ->where('company_id', $companyId)
                ->get()
                ->getResultArray();

            foreach ($companyUsers as $u) {
                $userRoleId = $u['role_id'] ?? '';
                if (empty($userRoleId)) {
                    continue;
                }

                // Check user's current role
                $currentRole = $this->db->table('roles')->where('id', $userRoleId)->get()->getRowArray();
                if (!$currentRole) {
                    continue;
                }

                $roleCode = $currentRole['code'] ?? '';
                if ($roleCode === 'software_app_admin') {
                    continue; // Software App Admin stays untouched
                }

                // If current role is global (company_id is null/empty or belongs to another company)
                $isGlobalOrCross = empty($currentRole['company_id']) || $currentRole['company_id'] !== $companyId;
                if ($isGlobalOrCross && isset($roleIdByCode[$roleCode])) {
                    $targetRoleId = $roleIdByCode[$roleCode];
                    $this->db->table('users')
                        ->where('id', $u['id'])
                        ->update(['role_id' => $targetRoleId]);
                }
            }
        }

        return ['created' => $created, 'skipped' => $skipped, 'roles' => $roleIdByCode];
    }

    /**
     * Idempotently ensures that standard roles are seeded for a specific company tenant.
     *
     * @param string $companyId
     * @return array
     */
    public function ensureCompanyRoles(string $companyId): array
    {
        if (empty($companyId)) {
            return [];
        }

        $existingCount = $this->db->table('roles')
            ->where('company_id', $companyId)
            ->where('code !=', 'software_app_admin')
            ->countAllResults();

        if ($existingCount < 5) {
            $company = $this->safeGetFirstRow($this->db->table('companies')->where('id', $companyId));
            $compCode = preg_replace('/[^A-Za-z0-9]/', '', (string)($company['code'] ?? 'TENANT'));
            if (empty($compCode)) {
                $compCode = substr(preg_replace('/[^A-Za-z0-9]/', '', $companyId), 0, 8) ?: 'TENANT';
            }
            return $this->initializeCompanyRoles($companyId, strtoupper($compCode));
        }

        return [];
    }

    /**
     * Initializes default asset categories for a company tenant.
     * Seed categories: Laptop, Mobile, Furniture, Vehicle, ID Card/Access, Software License, Other.
     * Administrators can edit or delete these categories as needed.
     *
     * @param string $companyId
     * @param string $compCode
     * @return array
     */
    public function initializeAssetCategories(string $companyId, string $compCode): array
    {
        $created = [];
        $skipped = [];
        $now = date('Y-m-d H:i:s');

        if (!$this->db->tableExists('asset_categories')) {
            return ['created' => $created, 'skipped' => $skipped];
        }

        $defaultCategories = [
            [
                'name'                => 'Laptop',
                'code'                => 'AST-LPT',
                'description'         => 'Company issued laptops, notebooks, and mobile workstations',
                'depreciation_method' => 'straight_line',
                'useful_life_years'   => 3,
                'requires_serial'     => 1,
                'status'              => 'active',
            ],
            [
                'name'                => 'Mobile',
                'code'                => 'AST-MOB',
                'description'         => 'Mobile phones, smartphones, and corporate cellular handsets',
                'depreciation_method' => 'straight_line',
                'useful_life_years'   => 2,
                'requires_serial'     => 1,
                'status'              => 'active',
            ],
            [
                'name'                => 'Furniture',
                'code'                => 'AST-FRN',
                'description'         => 'Office workstations, ergonomic chairs, conference tables, and storage',
                'depreciation_method' => 'straight_line',
                'useful_life_years'   => 5,
                'requires_serial'     => 0,
                'status'              => 'active',
            ],
            [
                'name'                => 'Vehicle',
                'code'                => 'AST-VEH',
                'description'         => 'Corporate pool automobiles, delivery vans, and fleet transport',
                'depreciation_method' => 'straight_line',
                'useful_life_years'   => 5,
                'requires_serial'     => 1,
                'status'              => 'active',
            ],
            [
                'name'                => 'ID Card/Access',
                'code'                => 'AST-ACC',
                'description'         => 'Employee RFID keycards, biometric FOB tokens, and facility badges',
                'depreciation_method' => 'none',
                'useful_life_years'   => null,
                'requires_serial'     => 1,
                'status'              => 'active',
            ],
            [
                'name'                => 'Software License',
                'code'                => 'AST-LIC',
                'description'         => 'Enterprise software licenses, SaaS subscriptions, and digital seats',
                'depreciation_method' => 'straight_line',
                'useful_life_years'   => 1,
                'requires_serial'     => 0,
                'status'              => 'active',
            ],
            [
                'name'                => 'Other',
                'code'                => 'AST-OTH',
                'description'         => 'General hardware, accessories, peripherals, and unclassified equipment',
                'depreciation_method' => 'none',
                'useful_life_years'   => null,
                'requires_serial'     => 0,
                'status'              => 'active',
            ],
        ];

        foreach ($defaultCategories as $cat) {
            $existing = $this->db->table('asset_categories')
                ->where('company_id', $companyId)
                ->where('LOWER(name)', strtolower($cat['name']))
                ->get()
                ->getRowArray();

            if ($existing) {
                $skipped[] = $cat['name'];
                continue;
            }

            $catId = 'astcat-' . bin2hex(random_bytes(8));
            $row = [
                'id'                  => $catId,
                'company_id'          => $companyId,
                'name'                => $cat['name'],
                'code'                => $cat['code'],
                'parent_id'           => null,
                'description'         => $cat['description'],
                'depreciation_method' => $cat['depreciation_method'],
                'useful_life_years'   => $cat['useful_life_years'],
                'requires_serial'     => $cat['requires_serial'],
                'status'              => $cat['status'],
                'created_at'          => $now,
                'updated_at'          => $now,
            ];

            $this->db->table('asset_categories')->insert($row);
            $created[] = $cat['name'];
        }

        return ['created' => $created, 'skipped' => $skipped];
    }

    /**
     * 14. Initialize Dashboard Widgets & Core Assignments for New Company Tenant
     *
     * Ensures all core Workforce & Attendance Summary widgets and cards
     * are ALWAYS active (status=1, is_visible=1, default_status=1) for both
     * `company_admin` and `hr_admin` roles upon tenant provisioning.
     */
    public function initializeDashboardWidgets(string $companyId, string $compCode): array
    {
        $created = [];
        $skipped = [];
        $now = date('Y-m-d H:i:s');

        // Target workforce and attendance widgets that must always be active
        $targetWidgets = [
            'company_executive_kpis'        => ['id' => 'wdg-kpi-01', 'grid_width' => 'full',    'sort' => 1],
            'attendance_overview_kpis'      => ['id' => 'wdg-att-10', 'grid_width' => 'full',    'sort' => 2],
            'attendance_card_present'       => ['id' => 'wdg-att-11', 'grid_width' => 'quarter', 'sort' => 3],
            'attendance_card_late'          => ['id' => 'wdg-att-12', 'grid_width' => 'quarter', 'sort' => 4],
            'attendance_card_absent'        => ['id' => 'wdg-att-13', 'grid_width' => 'quarter', 'sort' => 5],
            'attendance_card_missing_punch' => ['id' => 'wdg-att-14', 'grid_width' => 'quarter', 'sort' => 6],
            'attendance_card_hours_ot'      => ['id' => 'wdg-att-15', 'grid_width' => 'half',    'sort' => 7],
            'hr_attendance_exceptions'      => ['id' => 'wdg-att-02', 'grid_width' => 'half',    'sort' => 8],
            'staff_leave_calendar'          => ['id' => 'wdg-lev-02', 'grid_width' => 'full',    'sort' => 9],
            'employee_clock_card'           => ['id' => 'wdg-att-01', 'grid_width' => 'half',    'sort' => 10],
            'employee_leave_balances'       => ['id' => 'wdg-lev-01', 'grid_width' => 'half',    'sort' => 11],
            'pending_approvals'             => ['id' => 'wdg-app-01', 'grid_width' => 'half',    'sort' => 12],
            'quick_actions'                 => ['id' => 'wdg-qck-01', 'grid_width' => 'half',    'sort' => 13],
        ];

        // 1. Ensure master widgets in dashboard_widgets table have default_status = 1
        if ($this->db->tableExists('dashboard_widgets')) {
            foreach ($targetWidgets as $code => $cfg) {
                $wRow = $this->db->table('dashboard_widgets')
                    ->where('code', $code)
                    ->orWhere('id', $cfg['id'])
                    ->get()
                    ->getRowArray();

                if ($wRow) {
                    if ((int)($wRow['default_status'] ?? 0) === 0) {
                        $this->db->table('dashboard_widgets')
                            ->where('id', $wRow['id'])
                            ->update([
                                'default_status' => 1,
                                'updated_at'     => $now,
                            ]);
                    }
                }
            }
        }

        // 2. Ensure role-level assignments for company_admin and hr_admin in dashboard_widget_assignments
        if ($this->db->tableExists('dashboard_widget_assignments')) {
            $roles = ['company_admin', 'hr_admin'];
            foreach ($roles as $roleCode) {
                foreach ($targetWidgets as $code => $cfg) {
                    $widgetId = $cfg['id'];
                    if ($this->db->tableExists('dashboard_widgets')) {
                        $w = $this->db->table('dashboard_widgets')->where('code', $code)->orWhere('id', $cfg['id'])->get()->getRowArray();
                        if ($w && !empty($w['id'])) {
                            $widgetId = $w['id'];
                        }
                    }

                    $existing = $this->db->table('dashboard_widget_assignments')
                        ->where('scope_type', 'role')
                        ->where('scope_id', $roleCode)
                        ->groupStart()
                            ->where('widget_id', $widgetId)
                            ->orWhere('widget_id', $code)
                        ->groupEnd()
                        ->get()
                        ->getRowArray();

                    $isAttendanceDeck = ($code === 'attendance_overview_kpis' || $widgetId === 'wdg-att-10');
                    $roleStatus = $isAttendanceDeck ? 0 : 1;

                    if ($existing) {
                        if ($isAttendanceDeck) {
                            $this->db->table('dashboard_widget_assignments')
                                ->where('id', $existing['id'])
                                ->update([
                                    'status'     => 0,
                                    'is_visible' => 0,
                                    'updated_at' => $now,
                                ]);
                        } elseif ((int)$existing['status'] === 0 || (int)$existing['is_visible'] === 0) {
                            $this->db->table('dashboard_widget_assignments')
                                ->where('id', $existing['id'])
                                ->update([
                                    'status'     => 1,
                                    'is_visible' => 1,
                                    'updated_at' => $now,
                                ]);
                        }
                    } else {
                        $newId = 'dwa-role-' . substr(md5($roleCode . '-' . $widgetId), 0, 16);
                        $this->db->table('dashboard_widget_assignments')->insert([
                            'id'          => $newId,
                            'scope_type'  => 'role',
                            'scope_id'    => $roleCode,
                            'widget_id'   => $widgetId,
                            'status'      => $roleStatus,
                            'sort_order'  => $cfg['sort'],
                            'position'    => $cfg['sort'],
                            'grid_width'  => $cfg['grid_width'],
                            'grid_height' => 'auto',
                            'is_visible'  => $roleStatus,
                            'settings'    => null,
                            'created_at'  => $now,
                            'updated_at'  => $now,
                        ]);
                    }
                }
            }

            // 3. Create company-scope assignments (scope_type = 'company', scope_id = $companyId)
            foreach ($targetWidgets as $code => $cfg) {
                $widgetId = $cfg['id'];
                if ($this->db->tableExists('dashboard_widgets')) {
                    $w = $this->db->table('dashboard_widgets')->where('code', $code)->orWhere('id', $cfg['id'])->get()->getRowArray();
                    if ($w && !empty($w['id'])) {
                        $widgetId = $w['id'];
                    }
                }

                $existingComp = $this->db->table('dashboard_widget_assignments')
                    ->where('scope_type', 'company')
                    ->where('scope_id', $companyId)
                    ->groupStart()
                        ->where('widget_id', $widgetId)
                        ->orWhere('widget_id', $code)
                    ->groupEnd()
                    ->get()
                    ->getRowArray();

                if ($existingComp) {
                    if ((int)$existingComp['status'] === 0 || (int)$existingComp['is_visible'] === 0) {
                        $this->db->table('dashboard_widget_assignments')
                            ->where('id', $existingComp['id'])
                            ->update([
                                'status'     => 1,
                                'is_visible' => 1,
                                'updated_at' => $now,
                            ]);
                    }
                    $skipped[] = "{$code} (company)";
                } else {
                    $newId = 'dwa-comp-' . substr(md5($companyId . '-' . $widgetId), 0, 16);
                    $this->db->table('dashboard_widget_assignments')->insert([
                        'id'          => $newId,
                        'scope_type'  => 'company',
                        'scope_id'    => $companyId,
                        'widget_id'   => $widgetId,
                        'status'      => 1,
                        'sort_order'  => $cfg['sort'],
                        'position'    => $cfg['sort'],
                        'grid_width'  => $cfg['grid_width'],
                        'grid_height' => 'auto',
                        'is_visible'  => 1,
                        'settings'    => null,
                        'created_at'  => $now,
                        'updated_at'  => $now,
                    ]);
                    $created[] = "{$code} (company)";
                }
            }
        }

        // 4. Update legacy dashboard_company_widgets if table exists
        if ($this->db->tableExists('dashboard_company_widgets')) {
            foreach ($targetWidgets as $code => $cfg) {
                $widgetId = $cfg['id'];
                $existing = $this->db->table('dashboard_company_widgets')
                    ->where('company_id', $companyId)
                    ->where('widget_id', $widgetId)
                    ->get()
                    ->getRowArray();

                if ($existing) {
                    $this->db->table('dashboard_company_widgets')
                        ->where('id', $existing['id'])
                        ->update(['status' => 1, 'updated_at' => $now]);
                } else {
                    $this->db->table('dashboard_company_widgets')->insert([
                        'id'         => 'dcw-' . substr(md5($companyId . '-' . $widgetId), 0, 16),
                        'company_id' => $companyId,
                        'widget_id'  => $widgetId,
                        'status'     => 1,
                        'sort_order' => $cfg['sort'],
                        'created_at' => $now,
                        'updated_at' => $now,
                    ]);
                }
            }
        }

        return ['created' => $created, 'skipped' => $skipped];
    }
}
