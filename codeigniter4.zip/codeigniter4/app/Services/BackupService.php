<?php

namespace App\Services;

use Config\Database;

class BackupService
{
    protected $db;
    protected $backupDir;

    public function __construct()
    {
        $this->db = Database::connect();
        $this->backupDir = rtrim(WRITEPATH, '/\\') . DIRECTORY_SEPARATOR . 'backups' . DIRECTORY_SEPARATOR;
        if (!is_dir($this->backupDir)) {
            @mkdir($this->backupDir, 0750, true);
        }
    }

    /**
     * List all database backups securely
     */
    public function listBackups(): array
    {
        if (!is_dir($this->backupDir)) {
            return [];
        }

        $files = scandir($this->backupDir);
        $backups = [];

        foreach ($files as $file) {
            if ($file === '.' || $file === '..' || !str_ends_with(strtolower($file), '.sql')) {
                continue;
            }

            $fullPath = $this->backupDir . $file;
            $realPath = realpath($fullPath);
            $realDir = realpath($this->backupDir);

            // Path Traversal Security Verification
            if (!$realPath || !$realDir || strpos($realPath, $realDir) !== 0) {
                continue;
            }

            $sizeBytes = filesize($realPath) ?: 0;
            $mtime = filemtime($realPath);

            $backups[] = [
                'filename'       => $file,
                'path'           => $realPath,
                'size_bytes'     => $sizeBytes,
                'size_formatted' => $this->formatBytes($sizeBytes),
                'created_at'     => date('Y-m-d H:i:s', $mtime),
                'type'           => str_contains($file, 'Full') ? 'Full' : 'Database',
                'tables'         => 0
            ];
        }

        usort($backups, fn($a, $b) => strcmp($b['created_at'], $a['created_at']));
        return $backups;
    }

    /**
     * Generate an authoritative SQL Dump Archive
     */
    public function createSqlDump(string $type = 'Full', array $selectedTables = [], string $createdBy = 'Admin'): array
    {
        $allTables = $this->db->listTables();
        $targetTables = (!empty($selectedTables) && is_array($selectedTables)) 
            ? array_intersect($selectedTables, $allTables) 
            : $allTables;

        if (empty($targetTables)) {
            $targetTables = $allTables;
        }

        $timestamp = date('Y-m-d_H-i-s');
        $randomToken = bin2hex(random_bytes(4));
        $filename = "backup_{$type}_{$timestamp}_{$randomToken}.sql";
        $filePath = $this->backupDir . $filename;

        $fp = fopen($filePath, 'w');
        if (!$fp) {
            throw new \RuntimeException("Unable to open backup file '{$filePath}' for writing.");
        }

        fwrite($fp, "-- ========================================================\n");
        fwrite($fp, "-- ENTERPRISE HRMS - SYSTEM DATABASE BACKUP ARCHIVE\n");
        fwrite($fp, "-- Generation Time: " . date('Y-m-d H:i:s T') . "\n");
        fwrite($fp, "-- Created By: " . htmlspecialchars($createdBy, ENT_QUOTES, 'UTF-8') . "\n");
        fwrite($fp, "-- Backup Scope: " . $type . "\n");
        fwrite($fp, "-- Total Tables: " . count($targetTables) . "\n");
        fwrite($fp, "-- ========================================================\n\n");
        fwrite($fp, "SET FOREIGN_KEY_CHECKS=0;\n");
        fwrite($fp, "SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\n");
        fwrite($fp, "SET NAMES utf8mb4;\n\n");

        $totalRows = 0;

        foreach ($targetTables as $table) {
            fwrite($fp, "-- --------------------------------------------------------\n");
            fwrite($fp, "-- Table structure for table `{$table}`\n");
            fwrite($fp, "-- --------------------------------------------------------\n");
            fwrite($fp, "DROP TABLE IF EXISTS `{$table}`;\n");

            // Extract table DDL
            try {
                $createTableQuery = $this->db->query("SHOW CREATE TABLE `{$table}`")->getRowArray();
                if ($createTableQuery && isset($createTableQuery['Create Table'])) {
                    fwrite($fp, $createTableQuery['Create Table'] . ";\n\n");
                }
            } catch (\Throwable $e) {
                fwrite($fp, "-- Failed to extract CREATE TABLE for `{$table}`: " . $e->getMessage() . "\n\n");
            }

            // Extract table data
            fwrite($fp, "-- Dumping data for table `{$table}`\n");
            try {
                $rows = $this->db->table($table)->get()->getResultArray();
                $rowCount = count($rows);
                $totalRows += $rowCount;

                if ($rowCount > 0) {
                    $fields = array_keys($rows[0]);
                    $fieldList = '`' . implode('`, `', $fields) . '`';

                    // Chunk inserts to prevent MySQL packet size issues
                    $chunks = array_chunk($rows, 100);
                    foreach ($chunks as $chunk) {
                        $valueRows = [];
                        foreach ($chunk as $row) {
                            $escapedValues = array_map(function($val) {
                                if ($val === null) return 'NULL';
                                return $this->db->escape($val);
                            }, $row);
                            $valueRows[] = '(' . implode(', ', $escapedValues) . ')';
                        }
                        fwrite($fp, "INSERT INTO `{$table}` ({$fieldList}) VALUES\n" . implode(",\n", $valueRows) . ";\n");
                    }
                }
                fwrite($fp, "\n");
            } catch (\Throwable $e) {
                fwrite($fp, "-- Failed to dump data for `{$table}`: " . $e->getMessage() . "\n\n");
            }
        }

        fwrite($fp, "SET FOREIGN_KEY_CHECKS=1;\n");
        fwrite($fp, "-- ========================================================\n");
        fwrite($fp, "-- End of backup archive\n");
        fwrite($fp, "-- ========================================================\n");

        fclose($fp);

        $sizeBytes = filesize($filePath) ?: 0;

        return [
            'filename'       => $filename,
            'path'           => $filePath,
            'type'           => $type,
            'size'           => $sizeBytes,
            'size_formatted' => $this->formatBytes($sizeBytes),
            'tables'         => count($targetTables),
            'rows'           => $totalRows,
        ];
    }

    /**
     * Restore database from an authenticated SQL Dump file
     */
    public function restoreFromSql(string $filePath, string $restoreType = 'Database', string $restoredBy = 'Admin'): array
    {
        $realPath = realpath($filePath);
        $realDir = realpath($this->backupDir);

        if (!$realPath || !$realDir || strpos($realPath, $realDir) !== 0 || !file_exists($realPath)) {
            throw new \SecurityException("403 Forbidden: Target backup file does not exist or path traversal violation.");
        }

        $t0 = microtime(true);
        $sqlContent = file_get_contents($realPath);
        if ($sqlContent === false || strlen($sqlContent) === 0) {
            throw new \RuntimeException("Backup snapshot file is empty or unreadable.");
        }

        // Split into individual SQL statements safely
        $statements = $this->splitSqlStatements($sqlContent);
        $executed = 0;
        $tablesRestored = [];

        $this->db->transStart();

        try {
            $this->db->query("SET FOREIGN_KEY_CHECKS=0;");

            foreach ($statements as $stmt) {
                $trimmed = trim($stmt);
                if (empty($trimmed)) continue;

                // REL-M07-01: Dangerous SQL Statement Trapping
                if (preg_match('/\b(DROP\s+DATABASE|ALTER\s+USER|SHUTDOWN|GRANT\s+ALL)\b/i', $trimmed)) {
                    throw new \SecurityException("Dangerous statement trapped in backup archive: {$trimmed}");
                }

                // Track restored tables
                if (preg_match('/^(?:CREATE\s+TABLE|DROP\s+TABLE|INSERT\s+INTO)\s+[`]?([a-zA-Z0-9_]+)[`]?/i', $trimmed, $m)) {
                    $tablesRestored[$m[1]] = true;
                }

                $this->db->query($trimmed);
                $executed++;
            }

            $this->db->query("SET FOREIGN_KEY_CHECKS=1;");
            $this->db->transComplete();

            if ($this->db->transStatus() === false) {
                throw new \RuntimeException("Transaction status failed during restore execution.");
            }
        } catch (\Throwable $e) {
            $this->db->transRollback();
            $this->db->query("SET FOREIGN_KEY_CHECKS=1;");
            throw new \RuntimeException("Database restoration aborted and rolled back: " . $e->getMessage());
        }

        $elapsed = round((microtime(true) - $t0) * 1000, 2);

        $result = [
            'status'               => 'SUCCESS',
            'statements_executed'  => $executed,
            'tables_restored'      => count($tablesRestored),
            'duration_ms'          => $elapsed,
            'restored_by'          => $restoredBy,
            'restored_at'          => date('Y-m-d H:i:s')
        ];

        // Record restore event in history log
        $this->recordRestoreEvent([
            'id'                  => 'RST-' . strtoupper(substr(md5(uniqid()), 0, 8)),
            'backupName'          => basename($filePath),
            'restoreType'         => $restoreType,
            'restoredBy'          => $restoredBy,
            'status'              => 'Success',
            'restoredAt'          => date('Y-m-d H:i:s'),
            'duration_ms'         => $elapsed,
            'statements_executed' => $executed,
            'tables_restored'     => count($tablesRestored)
        ]);

        return $result;
    }

    /**
     * Get system database restoration audit history
     */
    public function getRestoreHistory(): array
    {
        $historyFile = $this->backupDir . 'restore_history.json';
        $history = [];

        if (file_exists($historyFile)) {
            $json = @file_get_contents($historyFile);
            if ($json) {
                $decoded = json_decode($json, true);
                if (is_array($decoded)) {
                    $history = $decoded;
                }
            }
        }

        // Also check audit_logs table for any system restoration entries
        try {
            if ($this->db->tableExists('audit_logs')) {
                $builder = $this->db->table('audit_logs')
                    ->groupStart()
                        ->where('module', 'system_restore')
                        ->orWhere('action', 'system.restored')
                        ->orLike('action', 'restore')
                    ->groupEnd()
                    ->orderBy('created_at', 'DESC')
                    ->limit(50);
                $auditEntries = $builder->get()->getResultArray();
                
                $loggedIds = array_column($history, 'id');
                foreach ($auditEntries as $entry) {
                    $entryId = $entry['id'] ?? ('AUD-' . ($entry['created_at'] ?? ''));
                    if (in_array($entryId, $loggedIds)) {
                        continue;
                    }
                    
                    $details = [];
                    if (!empty($entry['details'])) {
                        $details = is_string($entry['details']) ? (@json_decode($entry['details'], true) ?: []) : (array)$entry['details'];
                    }

                    $history[] = [
                        'id'          => $entryId,
                        'backupName'  => $entry['record_id'] ?? ($details['filename'] ?? 'system_database_snapshot.sql'),
                        'restoreType' => $details['restore_type'] ?? 'Database',
                        'restoredBy'  => $entry['user_id'] ?? 'Super Admin',
                        'status'      => 'Success',
                        'restoredAt'  => $entry['created_at'] ?? date('Y-m-d H:i:s'),
                        'duration_ms' => $details['duration_ms'] ?? 0
                    ];
                }
            }
        } catch (\Throwable $e) {
            log_message('error', 'BackupService::getRestoreHistory audit query failed: ' . $e->getMessage());
        }

        // Sort descending by restoredAt
        usort($history, function ($a, $b) {
            return strcmp($b['restoredAt'] ?? '', $a['restoredAt'] ?? '');
        });

        return $history;
    }

    /**
     * Append a restoration execution record to the persistent log file
     */
    public function recordRestoreEvent(array $event): void
    {
        try {
            $historyFile = $this->backupDir . 'restore_history.json';
            $history = [];

            if (file_exists($historyFile)) {
                $json = @file_get_contents($historyFile);
                if ($json) {
                    $decoded = json_decode($json, true);
                    if (is_array($decoded)) {
                        $history = $decoded;
                    }
                }
            }

            array_unshift($history, $event);
            // Keep at most 200 restoration records
            $history = array_slice($history, 0, 200);

            @file_put_contents($historyFile, json_encode($history, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        } catch (\Throwable $e) {
            log_message('error', 'BackupService::recordRestoreEvent failed: ' . $e->getMessage());
        }
    }

    /**
     * Safely split SQL into executable queries handling strings with semicolons
     */
    protected function splitSqlStatements(string $sql): array
    {
        $queries = [];
        $query = '';
        $inString = false;
        $stringChar = '';
        $len = strlen($sql);

        for ($i = 0; $i < $len; $i++) {
            $char = $sql[$i];

            // Comments
            if (!$inString && $char === '-' && isset($sql[$i+1]) && $sql[$i+1] === '-') {
                $endOfLine = strpos($sql, "\n", $i);
                $i = ($endOfLine !== false) ? $endOfLine : $len;
                continue;
            }

            // String boundary
            if ($char === "'" || $char === '"') {
                if (!$inString) {
                    $inString = true;
                    $stringChar = $char;
                } elseif ($stringChar === $char) {
                    // Check escaped quotes
                    if ($i > 0 && $sql[$i-1] !== '\\') {
                        $inString = false;
                    }
                }
            }

            if ($char === ';' && !$inString) {
                $trimmed = trim($query);
                if (!empty($trimmed)) {
                    $queries[] = $trimmed;
                }
                $query = '';
            } else {
                $query .= $char;
            }
        }

        $trimmed = trim($query);
        if (!empty($trimmed)) {
            $queries[] = $trimmed;
        }

        return $queries;
    }

    protected function formatBytes(int $bytes): string
    {
        if ($bytes >= 1073741824) {
            return round($bytes / 1073741824, 2) . ' GB';
        } elseif ($bytes >= 1048576) {
            return round($bytes / 1048576, 2) . ' MB';
        } elseif ($bytes >= 1024) {
            return round($bytes / 1024, 2) . ' KB';
        }
        return $bytes . ' B';
    }
}
