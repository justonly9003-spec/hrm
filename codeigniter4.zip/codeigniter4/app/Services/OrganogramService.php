<?php

namespace App\Services;

use App\Models\EmployeeOrganogramModel;
use App\Models\CompanyModel;
use App\Models\DepartmentModel;
use App\Models\BranchModel;
use App\Services\AuditService;

class OrganogramService
{
    protected EmployeeOrganogramModel $organogramModel;
    protected AuditService $auditService;

    public function __construct()
    {
        $this->organogramModel = new EmployeeOrganogramModel();
        $this->auditService = new AuditService();
    }

    /**
     * Build the organizational hierarchy tree structure in O(N) time complexity
     */
    public function getOrganogramTree(array $filters = [], ?string $companyId = null, bool $isSoftwareAdmin = false): array
    {
        $rawEmployees = $this->organogramModel->getEmployeesForOrganogram($filters, $companyId);
        
        if (empty($rawEmployees)) {
            return [
                'tree'            => [],
                'unassigned'      => [],
                'cyclic'          => [],
                'total_employees' => 0,
                'total_roots'     => 0,
                'max_depth'       => 0,
                'departments'     => [],
                'branches'        => [],
            ];
        }

        // 1. Index all employees by ID and prepare normalized fields
        $indexed = [];
        $childrenMap = [];
        $departmentsSet = [];
        $branchesSet = [];

        foreach ($rawEmployees as $emp) {
            $id = (string)$emp['id'];
            $managerId = !empty($emp['reporting_manager_id']) ? (string)$emp['reporting_manager_id'] : (!empty($emp['manager_id']) ? (string)$emp['manager_id'] : null);
            
            $firstName = $emp['first_name'] ?? '';
            $lastName = $emp['last_name'] ?? '';
            $fullName = trim($firstName . ' ' . $lastName) ?: ($emp['name'] ?? 'Unknown Employee');
            
            $initials = strtoupper(substr($firstName, 0, 1) . substr($lastName, 0, 1));
            if (empty(trim($initials))) {
                $initials = strtoupper(substr($fullName, 0, 2));
            }

            $emp['name'] = $fullName;
            $emp['avatar_initials'] = $initials;
            $emp['manager_id'] = $managerId;
            $emp['reporting_manager_id'] = $managerId;
            $emp['direct_reports_count'] = 0;
            $emp['total_reports_count'] = 0;

            $indexed[$id] = $emp;
            
            if ($managerId) {
                $childrenMap[$managerId][] = $id;
            }

            if (!empty($emp['department_name'])) {
                $departmentsSet[$emp['department_id'] ?? $emp['department_name']] = [
                    'id'   => $emp['department_id'] ?? '',
                    'name' => $emp['department_name'],
                    'code' => $emp['department_code'] ?? '',
                ];
            }

            if (!empty($emp['branch_name'])) {
                $branchesSet[$emp['branch_id'] ?? $emp['branch_name']] = [
                    'id'   => $emp['branch_id'] ?? '',
                    'name' => $emp['branch_name'],
                    'code' => $emp['branch_code'] ?? '',
                ];
            }
        }

        // 2. Individual Reporting Tree Mode (Filter to specific employee lineage)
        if (!empty($filters['individual_id']) && isset($indexed[$filters['individual_id']])) {
            $focusId = (string)$filters['individual_id'];
            $focusedIds = $this->extractLineageIds($focusId, $indexed, $childrenMap);
            
            // Re-index only focused members
            $focusedIndexed = [];
            $focusedChildrenMap = [];
            foreach ($focusedIds as $fId) {
                if (isset($indexed[$fId])) {
                    $focusedIndexed[$fId] = $indexed[$fId];
                    $mId = $indexed[$fId]['manager_id'];
                    if ($mId && in_array($mId, $focusedIds)) {
                        $focusedChildrenMap[$mId][] = $fId;
                    }
                }
            }
            $indexed = $focusedIndexed;
            $childrenMap = $focusedChildrenMap;
        }

        // 3. Compute direct reports count
        foreach ($indexed as $id => $emp) {
            $indexed[$id]['direct_reports_count'] = isset($childrenMap[$id]) ? count($childrenMap[$id]) : 0;
        }

        // 4. Identify Root Nodes and Unassigned Nodes
        $rootNodes = [];
        $unassignedNodes = [];

        foreach ($indexed as $id => $emp) {
            $managerId = $emp['manager_id'];
            
            if (empty($managerId)) {
                // True Root Executive
                $rootNodes[] = $id;
            } elseif (!isset($indexed[$managerId])) {
                // Manager exists in database but outside current filtered scope or inactive
                $unassignedNodes[] = $id;
            }
        }

        // If no root node found (e.g. all have external managers in filtered view), promote unassigned to roots
        if (empty($rootNodes) && !empty($unassignedNodes)) {
            $rootNodes = $unassignedNodes;
            $unassignedNodes = [];
        }

        // 5. Build Recursive Hierarchy Trees
        $visited = [];
        $tree = [];
        $maxDepth = 1;

        foreach ($rootNodes as $rootId) {
            if (!isset($visited[$rootId]) && isset($indexed[$rootId])) {
                $node = $this->buildTreeNode($rootId, $indexed, $childrenMap, $visited, 1, $maxDepth);
                if ($node) {
                    $tree[] = $node;
                }
            }
        }

        // Format unassigned orphan nodes
        $formattedUnassigned = [];
        foreach ($unassignedNodes as $uId) {
            if (!isset($visited[$uId]) && isset($indexed[$uId])) {
                $node = $this->buildTreeNode($uId, $indexed, $childrenMap, $visited, 1, $maxDepth);
                if ($node) {
                    $formattedUnassigned[] = $node;
                }
            }
        }

        // Collect unvisited nodes (circular reporting loops or self-manager)
        $cyclicNodes = [];
        foreach ($indexed as $id => $emp) {
            if (!isset($visited[$id])) {
                $node = $emp;
                $node['depth'] = 1;
                $node['children'] = [];
                $node['is_cyclic'] = true;
                $cyclicNodes[] = $node;
            }
        }

        return [
            'tree'            => $tree,
            'unassigned'      => $formattedUnassigned,
            'cyclic'          => $cyclicNodes,
            'total_employees' => count($indexed),
            'total_roots'     => count($tree),
            'max_depth'       => $maxDepth,
            'departments'     => array_values($departmentsSet),
            'branches'        => array_values($branchesSet),
        ];
    }

    /**
     * Recursively build node with children and calculate subtree metrics
     */
    protected function buildTreeNode(
        string $nodeId, 
        array &$indexed, 
        array &$childrenMap, 
        array &$visited, 
        int $currentDepth, 
        int &$maxDepth
    ): ?array {
        if (isset($visited[$nodeId])) {
            // Prevent circular loop traversal
            return null;
        }

        $visited[$nodeId] = true;
        $maxDepth = max($maxDepth, $currentDepth);

        $node = $indexed[$nodeId];
        $node['depth'] = $currentDepth;
        $node['children'] = [];

        $totalSubtreeCount = 0;

        if (isset($childrenMap[$nodeId]) && !empty($childrenMap[$nodeId])) {
            foreach ($childrenMap[$nodeId] as $childId) {
                if (!isset($visited[$childId]) && isset($indexed[$childId])) {
                    $childNode = $this->buildTreeNode($childId, $indexed, $childrenMap, $visited, $currentDepth + 1, $maxDepth);
                    if ($childNode !== null) {
                        $node['children'][] = $childNode;
                        $totalSubtreeCount += 1 + ($childNode['total_reports_count'] ?? 0);
                    }
                }
            }
        }

        $node['total_reports_count'] = $totalSubtreeCount;
        return $node;
    }

    /**
     * Extract full upstream ancestors and downstream descendants for focused individual view
     */
    protected function extractLineageIds(string $focusId, array &$indexed, array &$childrenMap): array
    {
        $lineage = [$focusId => true];

        // 1. Traverse Upward (Ancestors)
        $currId = $focusId;
        $visitedUp = [$currId => true];
        while ($currId && isset($indexed[$currId])) {
            $mId = $indexed[$currId]['manager_id'];
            if ($mId && isset($indexed[$mId]) && !isset($visitedUp[$mId])) {
                $lineage[$mId] = true;
                $visitedUp[$mId] = true;
                $currId = $mId;
            } else {
                break;
            }
        }

        // 2. Traverse Downward (Descendants)
        $this->collectDescendantIds($focusId, $childrenMap, $lineage);

        return array_keys($lineage);
    }

    /**
     * Recursive collection of descendant IDs
     */
    protected function collectDescendantIds(string $nodeId, array &$childrenMap, array &$result): void
    {
        if (isset($childrenMap[$nodeId])) {
            foreach ($childrenMap[$nodeId] as $cId) {
                if (!isset($result[$cId])) {
                    $result[$cId] = true;
                    $this->collectDescendantIds($cId, $childrenMap, $result);
                }
            }
        }
    }

    /**
     * Get detailed single employee data with ancestry chain and subordinate list
     */
    public function getEmployeeDetails(string $employeeId, ?string $companyId = null): ?array
    {
        $employee = $this->organogramModel->getEmployeeWithHierarchy($employeeId, $companyId);
        if (!$employee) {
            return null;
        }

        // Direct subordinates
        $directReports = $this->organogramModel->getDirectReports($employeeId, $companyId);

        // Build Reporting Ancestry Path (Breadcrumbs: Top Executive -> ... -> Direct Manager)
        $ancestorChain = [];
        $currentManagerId = $employee['manager_id_raw'] ?? $employee['reporting_manager_id'] ?? null;
        $visited = [$employeeId => true];

        while ($currentManagerId && !isset($visited[$currentManagerId])) {
            $visited[$currentManagerId] = true;
            $mgr = $this->organogramModel->getEmployeeWithHierarchy($currentManagerId, $companyId);
            if ($mgr) {
                array_unshift($ancestorChain, [
                    'id'               => $mgr['id'],
                    'name'             => $mgr['name'],
                    'employee_code'    => $mgr['employee_code'],
                    'designation_name' => $mgr['designation_name'],
                    'department_name'  => $mgr['department_name'],
                    'photo'            => $mgr['photo'],
                    'status'           => $mgr['status'],
                ]);
                $currentManagerId = $mgr['manager_id_raw'] ?? $mgr['reporting_manager_id'] ?? null;
            } else {
                break;
            }
        }

        // Find all descendants of this employee to exclude from candidate managers (prevent circular loop)
        $allDescendantIds = $this->getAllDescendantsOfEmployee($employeeId, $companyId);
        $excludedIds = array_merge([$employeeId], $allDescendantIds);

        // Fetch eligible managers
        $allCandidates = $this->organogramModel->getEligibleManagers($companyId, $employeeId);
        $eligibleManagers = [];
        foreach ($allCandidates as $cand) {
            if (!in_array($cand['id'], $excludedIds)) {
                $eligibleManagers[] = $cand;
            }
        }

        return [
            'employee'          => $employee,
            'direct_reports'    => $directReports,
            'ancestor_chain'    => $ancestorChain,
            'eligible_managers' => $eligibleManagers,
            'descendant_count'  => count($allDescendantIds),
        ];
    }

    /**
     * Get all transitive descendant employee IDs of a specific employee
     */
    public function getAllDescendantsOfEmployee(string $employeeId, ?string $companyId = null): array
    {
        $allEmployees = $this->organogramModel->getEmployeesForOrganogram([], $companyId);
        $childrenMap = [];
        foreach ($allEmployees as $emp) {
            $mId = $emp['reporting_manager_id'] ?? $emp['manager_id'] ?? null;
            if ($mId) {
                $childrenMap[$mId][] = $emp['id'];
            }
        }

        $descendants = [];
        $this->collectDescendantIds($employeeId, $childrenMap, $descendants);
        return array_keys($descendants);
    }

    /**
     * Comprehensive Circular Reporting & Validity Verification
     */
    public function validateManagerAssignment(string $employeeId, ?string $newManagerId, ?string $companyId = null): array
    {
        // 1. Check if unassigning manager (valid)
        if (empty($newManagerId) || $newManagerId === 'none' || $newManagerId === 'null') {
            return [
                'valid' => true,
                'sanitized_manager_id' => null,
            ];
        }

        // 2. Rule: Employee cannot be their own manager
        if ($employeeId !== '' && $employeeId === $newManagerId) {
            return [
                'valid' => false,
                'error' => 'An employee cannot be assigned as their own reporting manager.',
            ];
        }

        // 3. Rule: Check if target employee exists (when updating an existing employee)
        $employee = null;
        if ($employeeId !== '') {
            $employee = $this->organogramModel->getEmployeeWithHierarchy($employeeId, $companyId);
            if (!$employee) {
                return [
                    'valid' => false,
                    'error' => 'The target employee record was not found.',
                ];
            }
        }

        // 4. Rule: Check if new manager exists and belongs to the same company
        $newManager = $this->organogramModel->getEmployeeWithHierarchy($newManagerId, $companyId);
        if (!$newManager) {
            return [
                'valid' => false,
                'error' => 'The specified reporting manager was not found or is in a different company.',
            ];
        }

        if ($employee && (string)($newManager['company_id'] ?? '') !== (string)($employee['company_id'] ?? '')) {
            return [
                'valid' => false,
                'error' => 'The specified reporting manager was not found or is in a different company.',
            ];
        }

        if (!$employee && $companyId !== null && (string)($newManager['company_id'] ?? '') !== (string)$companyId) {
            return [
                'valid' => false,
                'error' => 'The specified reporting manager was not found or is in a different company.',
            ];
        }

        // 5. Rule: Check if manager status is active
        $managerStatus = strtolower((string)($newManager['status'] ?? 'active'));
        if (in_array($managerStatus, ['terminated', 'resigned', 'inactive', 'deleted', 'suspended'], true)) {
            return [
                'valid' => false,
                'error' => 'Cannot assign an inactive, terminated, resigned, or suspended employee as a reporting manager.',
            ];
        }

        // 6. CRITICAL RULE: Circular Reference Detection (Anti-Cycle Algorithm)
        // Check if $employeeId is in the upward reporting chain of $newManagerId.
        // If $employeeId is an ancestor of $newManagerId, then assigning $newManagerId as manager of $employeeId
        // would create a closed loop ($employeeId -> ... -> $newManagerId -> $employeeId).
        if ($employeeId !== '') {
            $effectiveCompanyId = $employee['company_id'] ?? $companyId;
            $currCheckId = $newManagerId;
            $visited = [$currCheckId => true];
            $chainNames = [$newManager['name']];

            while ($currCheckId) {
                if ($currCheckId === $employeeId) {
                    $empName = $employee['name'] ?? $employeeId;
                    $chainString = implode(' &rarr; ', array_reverse($chainNames)) . ' &rarr; ' . $empName;
                    return [
                        'valid' => false,
                        'error' => "Circular hierarchy loop detected: {$empName} is already an existing manager in {$newManager['name']}'s reporting chain ({$chainString}). Assigning this relationship would create an invalid infinite loop.",
                    ];
                }

                $currEmp = $this->organogramModel->getEmployeeWithHierarchy($currCheckId, $effectiveCompanyId);
                if (!$currEmp) {
                    break;
                }

                $parentManagerId = $currEmp['manager_id_raw'] ?? $currEmp['reporting_manager_id'] ?? null;
                if ($parentManagerId && !isset($visited[$parentManagerId])) {
                    $visited[$parentManagerId] = true;
                    $chainNames[] = $currEmp['manager_name'] ?: 'Manager';
                    $currCheckId = $parentManagerId;
                } else {
                    break;
                }
            }
        }

        return [
            'valid' => true,
            'sanitized_manager_id' => $newManagerId,
            'employee' => $employee,
            'manager' => $newManager
        ];
    }

    /**
     * Lock the employee row and the ancestor chain of the proposed manager
     * (FOR UPDATE). Deadlocks surface as exceptions and are handled by the caller.
     */
    protected function lockReportingChain($db, string $employeeId, ?string $newManagerId): void
    {
        if (stripos((string)($db->DBDriver ?? ''), 'mysql') === false) {
            return;
        }

        $lock = static function ($db, string $id): ?string {
            $row = $db->query('SELECT id, reporting_manager_id FROM employees WHERE id = ? FOR UPDATE', [$id])->getRowArray();
            return $row && !empty($row['reporting_manager_id']) ? (string)$row['reporting_manager_id'] : null;
        };

        $lock($db, $employeeId);

        $current = $newManagerId !== null ? trim($newManagerId) : '';
        if ($current === '' || in_array(strtolower($current), ['null', 'none'], true)) {
            return;
        }

        $seen = [$employeeId => true];
        $depth = 0;
        while ($current !== null && !isset($seen[$current]) && $depth++ < 200) {
            $seen[$current] = true;
            $current = $lock($db, $current);
        }
    }

    /**
     * Update reporting manager with validation, audit trail, and database persistence
     */
    public function updateReportingManager(string $employeeId, ?string $newManagerId, ?string $companyId = null, ?string $actorUserId = null): array
    {
        $db = \Config\Database::connect();
        $db->transStart();

        // Serialize concurrent reassignments: lock the employee row and then walk
        // UP from the proposed manager, locking every ancestor row. Any concurrent
        // change to an edge on that path needs the lock of its child row, so it
        // must wait for this transaction. (MySQL/InnoDB only; other drivers skip.)
        try {
            $this->lockReportingChain($db, $employeeId, $newManagerId);
        } catch (\Throwable $e) {
            $db->transRollback();
            log_message('error', 'Organogram lock failed: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Another hierarchy change is in progress. Please try again.',
            ];
        }

        $validation = $this->validateManagerAssignment($employeeId, $newManagerId, $companyId);
        if (!$validation['valid']) {
            $db->transComplete();
            return [
                'success' => false,
                'message' => $validation['error'] ?? 'Invalid manager assignment.',
            ];
        }

        $sanitizedId = $validation['sanitized_manager_id'];
        $employee = $validation['employee'] ?? $this->organogramModel->getEmployeeWithHierarchy($employeeId, $companyId);
        $oldManagerName = $employee['manager_name'] ?? 'None (Root)';
        $oldManagerId = $employee['reporting_manager_id'] ?? null;

        $updated = $this->organogramModel->updateReportingManager($employeeId, $sanitizedId);

        if (!$updated) {
            $db->transRollback();
            return [
                'success' => false,
                'message' => 'Database update failed. Please try again.',
            ];
        }

        // Audit Trail
        $newManager = $sanitizedId ? $this->organogramModel->getEmployeeWithHierarchy($sanitizedId, $companyId) : null;
        $newManagerName = $newManager ? $newManager['name'] : 'None (Root)';

        $this->auditService->log(
            $actorUserId,
            'organogram',
            'update_manager',
            $employeeId,
            ['reporting_manager_id' => $oldManagerId, 'manager_name' => $oldManagerName],
            ['reporting_manager_id' => $sanitizedId, 'manager_name' => $newManagerName],
            null,
            null,
            "Reassigned reporting manager for {$employee['name']} from [{$oldManagerName}] to [{$newManagerName}]"
        );

        $db->transComplete();
        if ($db->transStatus() === false) {
            return [
                'success' => false,
                'message' => 'Database transaction failed. Please try again.',
            ];
        }

        return [
            'success' => true,
            'message' => "Successfully updated reporting manager for {$employee['name']} to {$newManagerName}.",
            'data'    => [
                'employee_id'      => $employeeId,
                'manager_id'       => $sanitizedId,
                'manager_name'     => $newManagerName,
                'employee_name'    => $employee['name'],
            ],
        ];
    }
}
