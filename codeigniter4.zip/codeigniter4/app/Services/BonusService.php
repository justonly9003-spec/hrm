<?php

namespace App\Services;

use App\Models\EmployeeModel;
use App\Services\Rules\RuleResolver;
use App\Services\Rules\RuleNotConfiguredException;
use App\Services\Rules\RuleKeyMissingException;
use Config\Database;

/**
 * Service: Bonus & Incentive Engine
 *
 * Rules:
 * - BONUS and PAYROLL_BASICS rules are read strictly via RuleResolver (AGENTS.md Rule 2).
 * - No literal fallbacks for rule values, currencies, or business defaults (AGENTS.md Rule 4).
 * - Multi-tenant isolation enforced via company_id (AGENTS.md Rule 5).
 * - Financial transactions round once at the end of calculation (AGENTS.md Rule 7).
 * - All batch-generated bonuses are created strictly in 'Pending' status. Direct approval during
 *   batch generation is forbidden to prevent workflow bypass.
 * - Idempotency & Regeneration: Each active record has a unique (company_id, duplicate_check_hash).
 *   Soft deletion retires the hash with a unique retired suffix so the allocation can be regenerated
 *   while preserving the deleted record's audit history.
 */
class BonusService
{
    protected $db;
    protected $employeeModel;

    public function __construct()
    {
        $this->db = Database::connect();
        $this->employeeModel = new EmployeeModel();
    }

    /**
     * Legacy table inspection / migration check (no runtime DDL).
     * Kept for interface backward compatibility per AGENTS.md Rule 6.
     */
    public function ensureTablesExist(): void
    {
        // Schema definition is strictly maintained via Database/Migrations.
    }

    /**
     * Resolve Scheme from resolved BONUS domain schemes array.
     * Selects by requested scheme (if provided), or active schemes ordered by priority
     * (lowest integer = highest precedence). Unspecified priorities sort after explicit ones.
     */
    public function resolveScheme(array $schemes, ?string $requestedScheme = null): ?array
    {
        $activeSchemes = array_values(array_filter($schemes, function ($s) {
            return ($s['status'] ?? null) === 'Active';
        }));

        if (empty($activeSchemes)) {
            return null;
        }

        if (!empty($requestedScheme)) {
            $req = trim($requestedScheme);
            foreach ($activeSchemes as $s) {
                if (
                    (isset($s['code']) && strcasecmp((string)$s['code'], $req) === 0) ||
                    (isset($s['id']) && strcasecmp((string)$s['id'], $req) === 0) ||
                    (isset($s['name']) && strcasecmp((string)$s['name'], $req) === 0)
                ) {
                    return $s;
                }
            }
            return null;
        }

        // Scheme choice by priority without literal fallback like 999
        usort($activeSchemes, function ($a, $b) {
            $hasA = isset($a['priority']) && is_numeric($a['priority']);
            $hasB = isset($b['priority']) && is_numeric($b['priority']);
            if ($hasA && $hasB) {
                return (int)$a['priority'] <=> (int)$b['priority'];
            }
            if ($hasA) return -1;
            if ($hasB) return 1;
            return 0;
        });

        return $activeSchemes[0] ?? null;
    }

    /**
     * Generate Idempotency Check Hash with company scoping.
     * Hash covers (company_id, employee_id, scheme_code, month, year).
     */
    public function generateBonusHash(string $empId, string $schemeIdentifier, string $month, int $year, ?string $companyId = null): string
    {
        $prefix = !empty($companyId) ? "{$companyId}_" : '';
        return md5("{$prefix}{$empId}_{$schemeIdentifier}_{$month}_{$year}");
    }

    /**
     * Generate Batch Bonus with Idempotent Deduplication using Rule Store.
     *
     * SECURITY NOTE: All generated bonus allocations are created strictly in 'Pending' status.
     * Any client-supplied 'status' parameter is ignored to eliminate approval workflow bypass.
     * Transition to 'Approved' requires a separate authenticated call with 'bonus.approve' permission.
     */
    public function generateBonusBatch(array $params, array $currentUser): array
    {
        $companyId = $params['company_id'] ?? ($currentUser['company_id'] ?? null);
        if (empty($companyId)) {
            return ['success' => false, 'message' => 'Company context required for bonus calculation.'];
        }

        // Audit identity: require authenticated user id without invented fallback 'system'
        $creatorId = !empty($currentUser['id'])
            ? (string)$currentUser['id']
            : (!empty($currentUser['user_id']) ? (string)$currentUser['user_id'] : null);

        if (empty($creatorId)) {
            return ['success' => false, 'message' => 'An authenticated user identity is required for audited bonus generation.'];
        }

        // Validate month and year without silent literal fallbacks
        if (empty($params['month'])) {
            return ['success' => false, 'message' => 'Validation Error: Bonus month is required.'];
        }
        if (empty($params['year']) || !is_numeric($params['year'])) {
            return ['success' => false, 'message' => 'Validation Error: Bonus year is required.'];
        }

        $monthName = trim((string)$params['month']);
        $year = (int)$params['year'];
        $target = $params['target'] ?? 'all';
        $requestedScheme = $params['scheme_id'] ?? ($params['scheme_code'] ?? null);
        if (empty($requestedScheme)) {
            return ['success' => false, 'message' => 'Validation Error: Bonus scheme is required. Please specify a scheme_id or scheme_code.'];
        }

        // Convert month to standard representation
        $monthNum = (int)date('m', strtotime("{$monthName} 1, 2000"));
        if ($monthNum <= 0) {
            if (is_numeric($monthName) && (int)$monthName >= 1 && (int)$monthName <= 12) {
                $monthNum = (int)$monthName;
                $monthName = date('F', mktime(0, 0, 0, $monthNum, 1));
            } else {
                return ['success' => false, 'message' => "Invalid bonus month supplied: {$monthName}"];
            }
        }
        $asOfDate = !empty($params['as_of_date']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$params['as_of_date'])
            ? $params['as_of_date']
            : date('Y-m-t', strtotime(sprintf('%04d-%02d-01', $year, $monthNum)));

        // Fetch currency from PAYROLL_BASICS domain via RuleResolver (no literal default)
        try {
            $payrollBasics = RuleResolver::resolveForCompany($companyId, 'PAYROLL_BASICS', $asOfDate);
            $currency = trim((string)$payrollBasics->get('currency_code'));
        } catch (RuleNotConfiguredException $e) {
            return [
                'success' => false,
                'message' => 'Payroll basics rule not configured. Currency cannot be determined. Set it up in Rules > PAYROLL_BASICS before generating bonuses.'
            ];
        } catch (RuleKeyMissingException $e) {
            return [
                'success' => false,
                'message' => 'Payroll basics rule is missing currency_code. Set it up in Rules > PAYROLL_BASICS before generating bonuses.'
            ];
        }

        if ($currency === '') {
            return [
                'success' => false,
                'message' => 'Payroll currency is not configured. Set it up in Rules > PAYROLL_BASICS before generating bonuses.'
            ];
        }

        $builder = $this->employeeModel->where('status', \App\Models\EmployeeModel::STATUS_ACTIVE);
        $builder->where('company_id', $companyId);

        if ($target === 'department' && !empty($params['department_id'])) {
            $builder->where('department_id', $params['department_id']);
        } elseif ($target === 'individual' && !empty($params['employee_id'])) {
            $builder->where('id', $params['employee_id']);
        }

        $employees = $builder->findAll();
        if (empty($employees)) {
            return ['success' => false, 'message' => 'No matching active employees found in selected workforce cohort.'];
        }

        $created = 0;
        $skipped = 0;
        $skippedReasons = [];
        $totalDisbursed = 0.0;
        $now = date('Y-m-d H:i:s');

        $salService = class_exists('\Config\Services') && method_exists('\Config\Services', 'salary')
            ? \Config\Services::salary()
            : new \App\Services\EmployeeSalaryService();

        foreach ($employees as $emp) {
            // Resolve BONUS domain for employee
            try {
                $resolvedBonus = RuleResolver::resolve($companyId, 'BONUS', $asOfDate, $emp);
            } catch (\Throwable $e) {
                $skipped++;
                $skippedReasons[] = "Employee {$emp['id']}: Rule resolution failed (" . $e->getMessage() . ")";
                continue;
            }

            $schemes = $resolvedBonus->get('schemes');
            if (!is_array($schemes) || empty($schemes)) {
                $skipped++;
                $skippedReasons[] = "Employee {$emp['id']}: No bonus schemes configured in rule store";
                continue;
            }

            // Choose scheme by priority or matching requested
            $scheme = $this->resolveScheme($schemes, $requestedScheme);
            if (!$scheme) {
                $skipped++;
                $reasonText = !empty($requestedScheme)
                    ? "Requested scheme '{$requestedScheme}' is not active or not applicable"
                    : "No active bonus scheme available";
                $skippedReasons[] = "Employee {$emp['id']}: {$reasonText}";
                continue;
            }

            $schemeIdentifier = (string)($scheme['code'] ?? ($scheme['id'] ?? ''));
            if ($schemeIdentifier === '') {
                $skipped++;
                $skippedReasons[] = "Employee {$emp['id']}: Bonus scheme is missing mandatory code";
                continue;
            }

            // Validate scheme name without literal fallback
            $schemeName = trim((string)($scheme['name'] ?? ''));
            if ($schemeName === '') {
                $skipped++;
                $skippedReasons[] = "Employee {$emp['id']}: Bonus scheme '{$schemeIdentifier}' is missing mandatory name in rule store";
                continue;
            }

            $hash = $this->generateBonusHash($emp['id'], $schemeIdentifier, $monthName, $year, $companyId);

            // Deduplication check: verify existing active bonus record in this company
            $existing = $this->db->table('bonus_records')
                ->where('company_id', $companyId)
                ->where('duplicate_check_hash', $hash)
                ->where('deleted_at IS NULL')
                ->get()
                ->getRowArray();

            if ($existing) {
                $skipped++;
                if ($existing['status'] === 'Rejected') {
                    $skippedReasons[] = "Employee {$emp['id']}: Bonus allocation for scheme '{$schemeIdentifier}' ({$monthName} {$year}) was previously rejected. Delete or cancel the rejected record first to regenerate.";
                } else {
                    $skippedReasons[] = "Employee {$emp['id']}: already generated ({$schemeIdentifier}, {$monthName} {$year})";
                }
                continue;
            }

            // Gross ONLY from EmployeeSalaryService::getActiveSalary; if missing, skip employee and record reason
            $activeSalary = $salService->getActiveSalary($emp['id'], $asOfDate);
            if (!$activeSalary || !isset($activeSalary['gross_salary']) || (float)$activeSalary['gross_salary'] <= 0) {
                $skipped++;
                $skippedReasons[] = "Employee {$emp['id']}: no active salary structure";
                continue;
            }

            $basic = (float)($activeSalary['basic_salary'] ?? 0.0);
            $grossSalary = (float)$activeSalary['gross_salary'];

            // Tenure as of the bonus date using employee_joining_date()
            $joinDate = employee_joining_date($emp);
            if (!$joinDate) {
                $skipped++;
                $skippedReasons[] = "Employee {$emp['id']}: Joining date not configured";
                continue;
            }

            $bonusTimestamp = strtotime($asOfDate);
            $joinTimestamp = strtotime($joinDate);
            if ($joinTimestamp > $bonusTimestamp) {
                $skipped++;
                $skippedReasons[] = "Employee {$emp['id']}: Joined after bonus calculation date ({$joinDate})";
                continue;
            }

            $tenureDays = max(0, (int)floor(($bonusTimestamp - $joinTimestamp) / 86400));
            $tenureMonths = $tenureDays / 30.44;

            // Minimum service eligibility from the scheme (strictly no literal fallback)
            if (!array_key_exists('min_service_days', $scheme) || !is_numeric($scheme['min_service_days'])) {
                $skipped++;
                $skippedReasons[] = "Employee {$emp['id']}: Bonus scheme '{$schemeIdentifier}' is missing mandatory min_service_days in rule store";
                continue;
            }
            $minServiceDays = (int)$scheme['min_service_days'];
            if ($tenureDays < $minServiceDays) {
                $skipped++;
                $skippedReasons[] = "Employee {$emp['id']}: below minimum service ({$minServiceDays} days)";
                continue;
            }

            // Probation eligibility check
            $includeProbation = !empty($scheme['include_probation']);
            if (!$includeProbation) {
                $empStatus = strtolower(trim((string)($emp['status'] ?? '')));
                $probStatus = trim((string)($emp['probation_status'] ?? ''));
                $confirmedDate = $emp['confirmation_date'] ?? $emp['probation_confirmed_date'] ?? null;
                $isConfirmed = (!empty($confirmedDate) && strtotime($confirmedDate) <= $bonusTimestamp)
                    || in_array(strtolower($probStatus), ['completed', 'confirmed', 'not applicable', 'cancelled'], true)
                    || !empty($emp['probation_early_confirmed']);

                $isProbation = false;
                if (!$isConfirmed) {
                    if (in_array($empStatus, ['probation', 'on probation', 'on_probation'], true)) {
                        $isProbation = true;
                    } elseif (in_array(strtolower($probStatus), ['on probation', 'extended'], true)) {
                        $isProbation = true;
                    } elseif (!empty($emp['probation_end_date']) && strtotime($emp['probation_end_date']) >= $bonusTimestamp) {
                        $isProbation = true;
                    }
                }

                if ($isProbation) {
                    $skipped++;
                    $skippedReasons[] = "Employee {$emp['id']}: In probation period and scheme excludes probationary staff";
                    continue;
                }
            }

            // Proration from the scheme (strictly no literal fallbacks)
            $proratedRatio = 1.0;
            if (!empty($scheme['prorate_under_service_days'])) {
                if (!array_key_exists('prorate_threshold_months', $scheme) || !is_numeric($scheme['prorate_threshold_months'])) {
                    $skipped++;
                    $skippedReasons[] = "Employee {$emp['id']}: Bonus scheme '{$schemeIdentifier}' has prorate_under_service_days enabled but missing prorate_threshold_months in rule store";
                    continue;
                }
                if (!array_key_exists('prorate_min_ratio', $scheme) || !is_numeric($scheme['prorate_min_ratio'])) {
                    $skipped++;
                    $skippedReasons[] = "Employee {$emp['id']}: Bonus scheme '{$schemeIdentifier}' has prorate_under_service_days enabled but missing prorate_min_ratio in rule store";
                    continue;
                }
                $thresholdMonths = (int)$scheme['prorate_threshold_months'];
                $prorateMinRatio = (float)$scheme['prorate_min_ratio'];
                if ($thresholdMonths > 0 && $tenureMonths < $thresholdMonths) {
                    $proratedRatio = min(1.0, max($prorateMinRatio, $tenureMonths / (float)$thresholdMonths));
                }
            }

            // Calculation
            $calcType = (string)($scheme['calculation_type'] ?? '');
            if (!in_array($calcType, ['Percentage_Basic', 'Percentage_Gross', 'Flat', 'Formula'], true)) {
                $skipped++;
                $skippedReasons[] = "Employee {$emp['id']}: Scheme has unrecognized calculation type '{$calcType}'";
                continue;
            }

            if (!array_key_exists('value', $scheme) || !is_numeric($scheme['value'])) {
                if ($calcType !== 'Formula') {
                    $skipped++;
                    $skippedReasons[] = "Employee {$emp['id']}: Bonus scheme '{$schemeIdentifier}' is missing mandatory numeric value in rule store";
                    continue;
                }
                $val = 0.0;
            } else {
                $val = (float)$scheme['value'];
            }

            $rawGrossAmount = 0.0;
            $baseSalaryForRecord = $basic;
            $formulaLabel = '';
            $skippedCodes = [];

            if ($calcType === 'Flat') {
                $baseSalaryForRecord = $val;
                $rawGrossAmount = $val;
                $formulaLabel = "{$schemeName} (Flat {$currency} " . number_format($val, 2) . ", Prorated: " . round($proratedRatio * 100) . "%)";
            } elseif (($scheme['salary_basis'] ?? '') === 'Selected Components') {
                $codes = array_map('strtoupper', (array)($scheme['included_component_codes'] ?? []));
                if (empty($codes)) {
                    $skipped++;
                    $skippedReasons[] = "Employee {$emp['id']}: Scheme salary basis is Selected Components but no components are configured";
                    continue;
                }

                $earnings = $activeSalary['earnings'] ?? ($activeSalary['components'] ?? []);
                $baseSalaryForRecord = 0.0;
                $matchedNames = [];
                $matchedCodes = [];
                foreach ($earnings as $e) {
                    $code = strtoupper((string)($e['code'] ?? ($e['component_code'] ?? '')));
                    if (in_array($code, $codes, true)) {
                        $baseSalaryForRecord += (float)($e['amount'] ?? 0);
                        $matchedNames[] = $e['name'] ?? ($e['component_name'] ?? $code);
                        $matchedCodes[] = $code;
                    }
                }
                $skippedCodes = array_values(array_diff($codes, $matchedCodes));
                if (!empty($skippedCodes) && function_exists('log_message')) {
                    log_message('info', "Bonus calculation for employee {$emp['id']} skipped unassigned components: " . implode(', ', $skippedCodes));
                }

                $rawGrossAmount = ($baseSalaryForRecord * $val) / 100;
                $formulaLabel = "{$schemeName} ({$val}% of " . (implode(' + ', $matchedNames) ?: 'Selected Components') . " {$currency} " . number_format($baseSalaryForRecord, 2) . ", Prorated: " . round($proratedRatio * 100) . "%)";
            } elseif ($calcType === 'Percentage_Gross' || ($scheme['salary_basis'] ?? '') === 'Gross Salary') {
                $baseSalaryForRecord = $grossSalary;
                $rawGrossAmount = ($grossSalary * $val) / 100;
                $formulaLabel = "{$schemeName} ({$val}% of Gross {$currency} " . number_format($grossSalary, 2) . ", Prorated: " . round($proratedRatio * 100) . "%)";
            } elseif ($calcType === 'Percentage_Basic' || ($scheme['salary_basis'] ?? '') === 'Basic Salary') {
                $baseSalaryForRecord = $basic;
                $rawGrossAmount = ($basic * $val) / 100;
                $formulaLabel = "{$schemeName} ({$val}% of Basic {$currency} " . number_format($basic, 2) . ", Prorated: " . round($proratedRatio * 100) . "%)";
            } elseif ($calcType === 'Formula') {
                $formulaStr = trim((string)($scheme['custom_formula'] ?? ''));
                if ($formulaStr === '') {
                    $skipped++;
                    $skippedReasons[] = "Employee {$emp['id']}: Scheme calculation type is Formula but custom_formula is not configured in rule store";
                    continue;
                }
                $varPool = [
                    'BASIC'         => $basic,
                    'GROSS'         => $grossSalary,
                    'HOUSE_RENT'    => (float)($activeSalary['snapshot']['house_rent'] ?? 0.0),
                    'MEDICAL'       => (float)($activeSalary['snapshot']['medical'] ?? 0.0),
                    'CONVEYANCE'    => (float)($activeSalary['snapshot']['conveyance'] ?? 0.0),
                    'VALUE'         => $val,
                    'TENURE_DAYS'   => $tenureDays,
                    'TENURE_MONTHS' => $tenureMonths,
                ];
                if (!empty($activeSalary['earnings']) && is_array($activeSalary['earnings'])) {
                    foreach ($activeSalary['earnings'] as $ea) {
                        $cCode = strtoupper(trim((string)($ea['code'] ?? ($ea['component_code'] ?? ''))));
                        if ($cCode !== '') {
                            $varPool[$cCode] = (float)($ea['amount'] ?? 0.0);
                        }
                    }
                }
                try {
                    $calculatedVal = \App\Services\Rules\FormulaEvaluator::evaluate($formulaStr, $varPool);
                    $rawGrossAmount = (float)$calculatedVal;
                    $baseSalaryForRecord = $basic;
                    $formulaLabel = "{$schemeName} (Formula: {$formulaStr}, Prorated: " . round($proratedRatio * 100) . "%)";
                } catch (\InvalidArgumentException $fe) {
                    log_message('error', "BonusService formula evaluation failed for employee {$emp['id']} ('{$formulaStr}'): " . $fe->getMessage());
                    $skipped++;
                    $skippedReasons[] = "Employee {$emp['id']}: Formula evaluation error for '{$formulaStr}': " . $fe->getMessage();
                    continue;
                }
            } else {
                $skipped++;
                $skippedReasons[] = "Employee {$emp['id']}: Unsupported calculation type '{$calcType}'";
                continue;
            }

            // Attendance penalty ratio: defaults to 1.0000 (no penalty)
            $attendancePenaltyRatio = 1.0000;
            $penaltyAuditInfo = ['type' => 'none', 'ratio' => 1.0000];
            if (isset($params['employee_penalties'][$emp['id']]) && is_numeric($params['employee_penalties'][$emp['id']])) {
                $penaltyVal = (float)$params['employee_penalties'][$emp['id']];
                if ($penaltyVal >= 0 && $penaltyVal <= 1) {
                    $attendancePenaltyRatio = $penaltyVal;
                    $penaltyAuditInfo = [
                        'type'       => 'manual_override',
                        'ratio'      => $attendancePenaltyRatio,
                        'reason'     => (string)($params['penalty_reason'] ?? 'Manual override during batch creation'),
                        'applied_by' => $creatorId,
                    ];
                }
            } elseif (!empty($scheme['attendance_penalty_threshold_days'])) {
                $monthEndDate = date('Y-m-t', strtotime($asOfDate));
                $absentCount = (int)$this->db->table('attendance_logs')
                    ->where('employee_id', $emp['id'])
                    ->where('company_id', $companyId)
                    ->where('status', 'Absent')
                    ->where('date >=', $asOfDate)
                    ->where('date <=', $monthEndDate)
                    ->countAllResults();
                if ($absentCount > (int)$scheme['attendance_penalty_threshold_days']) {
                    if (!isset($scheme['attendance_penalty_ratio_per_day']) || !is_numeric($scheme['attendance_penalty_ratio_per_day'])) {
                        $skipped++;
                        $skippedReasons[] = "Employee {$emp['id']}: Absenteeism ({$absentCount} days) exceeds threshold but attendance_penalty_ratio_per_day is not configured in rule store";
                        continue;
                    }
                    $deductionPerDay = (float)$scheme['attendance_penalty_ratio_per_day'];
                    $attendancePenaltyRatio = max(0.0, 1.0 - (($absentCount - (int)$scheme['attendance_penalty_threshold_days']) * $deductionPerDay));
                    $penaltyAuditInfo = [
                        'type'              => 'attendance_driven',
                        'ratio'             => $attendancePenaltyRatio,
                        'absent_count'      => $absentCount,
                        'threshold_days'    => (int)$scheme['attendance_penalty_threshold_days'],
                        'deduction_per_day' => $deductionPerDay,
                    ];
                }
            }

            // Money rule: round once at the end of the calculation
            $grossCalculatedAmount = round($rawGrossAmount, 2);
            $netAmount = round($rawGrossAmount * $proratedRatio * $attendancePenaltyRatio, 2);

            // Construct rules snapshot for audit
            $rulesSnapshot = [
                'BONUS' => [
                    'layers' => array_map(function($l) {
                        return [
                            'rule_id'        => $l['rule_id'] ?? ($l['id'] ?? ''),
                            'scope_level'    => $l['scope_level'] ?? '',
                            'scope_id'       => $l['scope_id'] ?? null,
                            'version_number' => $l['version_number'] ?? 1,
                        ];
                    }, $resolvedBonus->layers()),
                    'hash' => $resolvedBonus->sha1(),
                ],
                'PAYROLL_BASICS' => [
                    'layers' => array_map(function($l) {
                        return [
                            'rule_id'        => $l['rule_id'] ?? ($l['id'] ?? ''),
                            'scope_level'    => $l['scope_level'] ?? '',
                            'scope_id'       => $l['scope_id'] ?? null,
                            'version_number' => $l['version_number'] ?? 1,
                        ];
                    }, $payrollBasics->layers()),
                    'hash' => $payrollBasics->sha1(),
                ],
                'attendance_penalty' => $penaltyAuditInfo,
            ];
            if (!empty($skippedCodes)) {
                $rulesSnapshot['skipped_component_codes'] = $skippedCodes;
            }

            $bonusId = 'BNS-' . bin2hex(random_bytes(8));

            // CRITICAL AUDIT GUARD: Batch-generated bonuses are ALWAYS created as 'Pending'.
            // Approval bypass via request parameter is strictly disallowed.
            $initialStatus = 'Pending';
            $approvedBy = null;
            $approvedAt = null;

            // Department name: use real department if assigned, or null (never invent 'General')
            $departmentName = !empty($emp['department_name'])
                ? (string)$emp['department_name']
                : (!empty($emp['department']) ? (string)$emp['department'] : null);

            $category = isset($scheme['category']) && trim((string)$scheme['category']) !== ''
                ? trim((string)$scheme['category'])
                : null;

            $empDisplayName = trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')) ?: ($emp['name'] ?? 'Employee');

            try {
                $this->db->table('bonus_records')->insert([
                    'id'                       => $bonusId,
                    'company_id'               => $companyId,
                    'employee_id'              => $emp['id'],
                    'employee_name'            => $empDisplayName,
                    'department_id'            => $emp['department_id'] ?? null,
                    'department_name'          => $departmentName,
                    'scheme_id'                => $scheme['code'] ?? ($scheme['id'] ?? $schemeIdentifier),
                    'scheme_code'              => $schemeIdentifier,
                    'bonus_title'              => $schemeName,
                    'category'                 => $category,
                    'bonus_month'              => $monthName,
                    'year'                     => $year,
                    'base_salary'              => round($baseSalaryForRecord, 2),
                    'calculation_formula'      => $formulaLabel,
                    'gross_calculated_amount'  => $grossCalculatedAmount,
                    'tenure_months'            => round($tenureMonths, 1),
                    'prorated_ratio'           => round($proratedRatio, 4),
                    'attendance_penalty_ratio' => round($attendancePenaltyRatio, 4),
                    'amount'                   => $netAmount,
                    'duplicate_check_hash'     => $hash,
                    'rules_snapshot_json'      => json_encode($rulesSnapshot, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                    'status'                   => $initialStatus,
                    'approved_by'              => $approvedBy,
                    'approved_at'              => $approvedAt,
                    'created_by'               => $creatorId,
                    'deleted_at'               => null,
                    'created_at'               => $now,
                    'updated_at'               => $now
                ]);

                $created++;
                $totalDisbursed += $netAmount;
            } catch (\Throwable $ex) {
                // Gracefully handle concurrent duplicate insertion
                if (stripos($ex->getMessage(), 'Duplicate entry') !== false || stripos($ex->getMessage(), 'unique') !== false) {
                    $skipped++;
                    $skippedReasons[] = "Employee {$emp['id']}: already generated ({$schemeIdentifier}, {$monthName} {$year})";
                } else {
                    $skipped++;
                    $skippedReasons[] = "Employee {$emp['id']}: Database insertion error (" . $ex->getMessage() . ")";
                }
            }
        }

        // Group skipped reasons by type with counts (reason text after "Employee <id>:")
        $groupedReasons = [];
        if (!empty($skippedReasons)) {
            foreach ($skippedReasons as $rawReason) {
                $rawReasonStr = (string)$rawReason;
                if (preg_match('/^Employee\s+[^:]+:\s*(.+)$/s', $rawReasonStr, $matches)) {
                    $reasonKey = trim($matches[1]);
                } else {
                    $reasonKey = trim($rawReasonStr);
                }
                $reasonKey = rtrim($reasonKey, '.');
                if ($reasonKey === '') {
                    $reasonKey = 'unknown reason';
                }
                $groupedReasons[$reasonKey] = isset($groupedReasons[$reasonKey]) ? ($groupedReasons[$reasonKey] + 1) : 1;
            }
        }

        $groupedParts = [];
        foreach ($groupedReasons as $reasonKey => $cnt) {
            $groupedParts[] = "{$cnt} {$reasonKey}";
        }

        $skippedSummary = '';
        if ($skipped > 0) {
            $skippedSummary = !empty($groupedParts)
                ? "Skipped {$skipped}: " . implode(', ', $groupedParts) . "."
                : "Skipped {$skipped}.";
        }

        $baseMessage = "Generated {$created} bonus records in Pending status (skipped {$skipped} duplicates/ineligible). Total Payout: {$currency} " . number_format($totalDisbursed, 2) . ".";

        $finalMessage = $baseMessage;
        if ($skipped > 0 && !empty($skippedSummary)) {
            $finalMessage .= " " . $skippedSummary;
        }
        if ($created > 0) {
            $finalMessage .= " (Note: Pending records must be approved before they are integrated into payroll).";
        }

        return [
            'success'         => $created > 0,
            'message'         => $finalMessage,
            'skipped_reasons' => $skippedReasons,
            'grouped_reasons' => $groupedReasons,
            'data'            => [
                'created'         => $created,
                'created_count'   => $created,
                'skipped'         => $skipped,
                'skipped_count'   => $skipped,
                'skipped_reasons' => $skippedReasons,
                'grouped_reasons' => $groupedReasons,
                'skipped_summary' => $skippedSummary,
                'total_disbursed' => $totalDisbursed
            ]
        ];
    }

    /**
     * Approve a pending bonus record with strict atomic concurrency control,
     * tenant boundary verification, and segregation of duties enforcement.
     *
     * @param string $id Bonus record ID
     * @param string|null $scopedCompanyId Current tenant company ID
     * @param array $currentUser Authenticated user context
     * @param bool $isSoftwareAppAdmin Platform superadmin flag
     * @return array [success => bool, code => int, message => string, data => array|null]
     */
    public function approveBonusRecord(string $id, ?string $scopedCompanyId, array $currentUser, bool $isSoftwareAppAdmin = false): array
    {
        $builder = $this->db->table('bonus_records')
            ->select('bonus_records.*, employees.company_id as employee_company_id')
            ->join('employees', 'employees.id = bonus_records.employee_id', 'left')
            ->where('bonus_records.id', $id)
            ->where('bonus_records.deleted_at IS NULL');

        if (!$isSoftwareAppAdmin && !empty($scopedCompanyId)) {
            $builder->where('bonus_records.company_id', $scopedCompanyId);
        }

        $record = $builder->get()->getRowArray();
        if (!$record) {
            return [
                'success' => false,
                'code'    => 404,
                'message' => 'Bonus record not found or has been deleted.'
            ];
        }

        $targetCompany = $record['company_id'] ?: ($record['employee_company_id'] ?? null);
        if (!$isSoftwareAppAdmin && !empty($scopedCompanyId) && !empty($targetCompany) && (string)$targetCompany !== (string)$scopedCompanyId) {
            return [
                'success' => false,
                'code'    => 403,
                'message' => 'Cross-tenant access violation: Cannot approve bonus belonging to another company.'
            ];
        }

        // Segregation of duties: approver cannot approve their own bonus allocation
        if (!empty($currentUser['employee_id']) && (string)$currentUser['employee_id'] === (string)$record['employee_id']) {
            return [
                'success' => false,
                'code'    => 403,
                'message' => 'Segregation of Duties Violation: You cannot approve your own bonus allocation.'
            ];
        }

        // Maker-Checker: user who generated/created the bonus record cannot approve it
        $currentUserId = !empty($currentUser['id'])
            ? (string)$currentUser['id']
            : (!empty($currentUser['user_id']) ? (string)$currentUser['user_id'] : null);
        if (empty($currentUserId)) {
            return [
                'success' => false,
                'code'    => 401,
                'message' => 'Authentication session invalid: Approver user ID is required.'
            ];
        }
        if (!$isSoftwareAppAdmin && !empty($record['created_by']) && (string)$currentUserId === (string)$record['created_by']) {
            return [
                'success' => false,
                'code'    => 403,
                'message' => 'Segregation of Duties Violation: Maker-checker policy prohibits the creator of a bonus record from approving it.'
            ];
        }
        if (!$isSoftwareAppAdmin && !empty($record['swept_by']) && stripos((string)$record['swept_by'], $currentUserId) !== false) {
            return [
                'success' => false,
                'code'    => 403,
                'message' => 'Segregation of Duties Violation: Maker-checker policy prohibits the officer who scheduled the sweep from approving it. A second authorized officer is required.'
            ];
        }

        // Re-check scheduled payout_month at approval (upper bound guard)
        if (!empty($record['payout_month'])) {
            $payoutMonth = trim((string)$record['payout_month']);
            $origSweepDate = !empty($record['swept_at'])
                ? $record['swept_at']
                : (!empty($record['created_at']) ? $record['created_at'] : date('Y-m-d'));
            $maxSweepMonth = date('Y-m', strtotime('+12 months', strtotime($origSweepDate)));
            if ($payoutMonth > $maxSweepMonth) {
                return [
                    'success' => false,
                    'code'    => 422,
                    'message' => "Approval Blocked: Scheduled payout month ({$payoutMonth}) exceeds 12-month upper limit ({$maxSweepMonth})."
                ];
            }
        }

        // Status transition guards
        if (!empty($record['is_settled_in_payroll']) || in_array($record['status'], ['Settled', 'Paid'], true)) {
            return [
                'success' => false,
                'code'    => 409,
                'message' => 'Action Blocked: This bonus allocation has already been settled in payroll and cannot be re-approved.'
            ];
        }

        if ($record['status'] === 'Approved') {
            return [
                'success' => false,
                'code'    => 409,
                'message' => 'Notice: This bonus allocation is already approved.'
            ];
        }

        if ($record['status'] === 'Rejected') {
            return [
                'success' => false,
                'code'    => 409,
                'message' => 'Action Blocked: Rejected bonus records cannot be directly approved without recreation.'
            ];
        }

        if ($record['status'] !== 'Pending') {
            return [
                'success' => false,
                'code'    => 409,
                'message' => "Action Blocked: Only pending records can be approved (current status: {$record['status']})."
            ];
        }

        $now = date('Y-m-d H:i:s');
        $approverName = !empty($currentUser['name'])
            ? (string)$currentUser['name']
            : (!empty($currentUser['email']) ? (string)$currentUser['email'] : 'Authorized Approver');
        $approverIdentity = mb_substr(!empty($currentUserId) ? "{$currentUserId} ({$approverName})" : $approverName, 0, 100);

        $this->db->transStart();

        $updateBuilder = $this->db->table('bonus_records')
            ->where('id', $id)
            ->where('status', 'Pending')
            ->where('deleted_at IS NULL');

        if (!$isSoftwareAppAdmin && !empty($scopedCompanyId)) {
            $updateBuilder->where('company_id', $scopedCompanyId);
        }

        $updateBuilder->update([
            'status'      => 'Approved',
            'approved_by' => $approverIdentity,
            'approved_at' => $now,
            'updated_at'  => $now
        ]);

        $affected = $this->db->affectedRows();
        if ($affected !== 1) {
            $this->db->transRollback();
            return [
                'success' => false,
                'code'    => 409,
                'message' => 'Conflict (409): Bonus record was modified, approved, or rejected by another concurrent transaction.'
            ];
        }

        $this->db->transComplete();

        if ($this->db->transStatus() === false) {
            return [
                'success' => false,
                'code'    => 500,
                'message' => 'Failed to approve bonus record due to database transaction failure.'
            ];
        }

        return [
            'success' => true,
            'code'    => 200,
            'message' => 'Bonus record approved successfully.',
            'data'    => [
                'id'              => $id,
                'previous_status' => $record['status'],
                'new_status'      => 'Approved',
                'amount'          => $record['amount'],
                'approved_by'     => $approverName,
                'approved_at'     => $now
            ]
        ];
    }

    /**
     * Reject a pending bonus record with mandatory reason, atomic concurrency control,
     * and status transition guards.
     */
    public function rejectBonusRecord(string $id, ?string $scopedCompanyId, string $reason, array $currentUser, bool $isSoftwareAppAdmin = false): array
    {
        $trimmedReason = trim($reason);
        if ($trimmedReason === '') {
            return [
                'success' => false,
                'code'    => 422,
                'message' => 'A specific rejection reason is mandatory.'
            ];
        }

        $builder = $this->db->table('bonus_records')
            ->select('bonus_records.*, employees.company_id as employee_company_id')
            ->join('employees', 'employees.id = bonus_records.employee_id', 'left')
            ->where('bonus_records.id', $id)
            ->where('bonus_records.deleted_at IS NULL');

        if (!$isSoftwareAppAdmin && !empty($scopedCompanyId)) {
            $builder->where('bonus_records.company_id', $scopedCompanyId);
        }

        $record = $builder->get()->getRowArray();
        if (!$record) {
            return [
                'success' => false,
                'code'    => 404,
                'message' => 'Bonus record not found or has been deleted.'
            ];
        }

        $targetCompany = $record['company_id'] ?: ($record['employee_company_id'] ?? null);
        if (!$isSoftwareAppAdmin && !empty($scopedCompanyId) && !empty($targetCompany) && (string)$targetCompany !== (string)$scopedCompanyId) {
            return [
                'success' => false,
                'code'    => 403,
                'message' => 'Cross-tenant access violation: Cannot reject bonus belonging to another company.'
            ];
        }

        // Segregation of duties: cannot reject own bonus
        if (!empty($currentUser['employee_id']) && (string)$currentUser['employee_id'] === (string)$record['employee_id']) {
            return [
                'success' => false,
                'code'    => 403,
                'message' => 'Segregation of Duties Violation: You cannot reject your own bonus allocation.'
            ];
        }

        if (!empty($record['is_settled_in_payroll']) || in_array($record['status'], ['Settled', 'Paid'], true)) {
            return [
                'success' => false,
                'code'    => 409,
                'message' => 'Action Blocked: This bonus allocation has already been settled in payroll and cannot be rejected.'
            ];
        }

        if (!in_array($record['status'], ['Pending', 'Approved'], true)) {
            return [
                'success' => false,
                'code'    => 409,
                'message' => "Action Blocked: Only pending or approved records can be rejected (current status: {$record['status']})."
            ];
        }

        if (!empty($record['payroll_id'])) {
            $lockedPayroll = $this->db->table('payrolls')->where('id', $record['payroll_id'])->where('is_locked', 1)->get()->getRowArray();
            if ($lockedPayroll) {
                return [
                    'success' => false,
                    'code'    => 409,
                    'message' => 'Action Blocked: This bonus allocation is finalized in a locked payroll batch and cannot be rejected.'
                ];
            }
        }

        $now = date('Y-m-d H:i:s');
        $actorId = !empty($currentUser['id']) ? (string)$currentUser['id'] : (!empty($currentUser['user_id']) ? (string)$currentUser['user_id'] : null);
        if (empty($actorId)) {
            return [
                'success' => false,
                'code'    => 401,
                'message' => 'An authenticated user identity is required for audited bonus rejection.'
            ];
        }
        $actorName = !empty($currentUser['name']) ? (string)$currentUser['name'] : (!empty($currentUser['email']) ? (string)$currentUser['email'] : 'Authorized User');
        $actorIdentity = mb_substr("{$actorId} ({$actorName})", 0, 100);

        $this->db->transStart();

        $rejectBuilder = $this->db->table('bonus_records')
            ->where('id', $id)
            ->whereIn('status', ['Pending', 'Approved'])
            ->where('deleted_at IS NULL');

        if (!$isSoftwareAppAdmin && !empty($scopedCompanyId)) {
            $rejectBuilder->where('company_id', $scopedCompanyId);
        }

        $updFields = [
            'status'           => 'Rejected',
            'rejection_reason' => $trimmedReason,
            'updated_at'       => $now,
            'payroll_id'       => null,
        ];
        if ($this->db->fieldExists('rejected_by', 'bonus_records')) {
            $updFields['rejected_by'] = $actorIdentity;
        }
        if ($this->db->fieldExists('rejected_at', 'bonus_records')) {
            $updFields['rejected_at'] = $now;
        }
        if ($this->db->fieldExists('approved_by', 'bonus_records')) {
            $updFields['approved_by'] = null;
        }
        if ($this->db->fieldExists('approved_at', 'bonus_records')) {
            $updFields['approved_at'] = null;
        }

        $rejectBuilder->update($updFields);

        // If this bonus was linked to an unlocked draft payroll, sync and deduct from draft payroll_items
        if (!empty($record['payroll_id'])) {
            $linkedPayroll = $this->db->table('payrolls')->where('id', $record['payroll_id'])->get()->getRowArray();
            if ($linkedPayroll) {
                try {
                    $payrollService = new \App\Services\PayrollService();
                    $synced = $payrollService->syncDraftItemBonusChange(
                        $record['payroll_id'],
                        $record['employee_id'],
                        (float)($record['amount'] ?? 0.0),
                        null,
                        $record['id']
                    );
                    if (!$synced) {
                        $this->db->transRollback();
                        return [
                            'success' => false,
                            'code'    => 409,
                            'message' => 'Failed to reject bonus: linked draft payroll item could not be synchronized or batch is locked.'
                        ];
                    }
                } catch (\Throwable $e) {
                    $this->db->transRollback();
                    log_message('error', "Failed to sync draft payroll after bonus rejection: " . $e->getMessage());
                    return [
                        'success' => false,
                        'code'    => 500,
                        'message' => 'Failed to sync draft payroll: ' . $e->getMessage()
                    ];
                }
            }
        }

        $affected = $this->db->affectedRows();
        if ($affected !== 1) {
            $this->db->transRollback();
            return [
                'success' => false,
                'code'    => 409,
                'message' => 'Conflict (409): Bonus record was modified, approved, or rejected by another concurrent transaction.'
            ];
        }

        $this->db->transComplete();

        if ($this->db->transStatus() === false) {
            return [
                'success' => false,
                'code'    => 500,
                'message' => 'Failed to reject bonus record due to database transaction failure.'
            ];
        }

        return [
            'success' => true,
            'code'    => 200,
            'message' => 'Bonus record rejected successfully.',
            'data'    => [
                'id'              => $id,
                'previous_status' => $record['status'],
                'new_status'      => 'Rejected',
                'reason'          => $trimmedReason,
                'rejected_at'     => $now
            ]
        ];
    }

    /**
     * Adjust a bonus record with strict state policy, optimistic locking, and re-approval enforcement.
     *
     * State Policy:
     * 1. Settled or Paid records CANNOT be adjusted (financial lock).
     * 2. Rejected records CANNOT be adjusted (must be recreated).
     * 3. Soft-deleted records CANNOT be adjusted.
     * 4. Only Pending or Approved records can be adjusted.
     * 5. When an Approved record is adjusted, the modification invalidates the prior approval:
     *    the record transitions back to 'Pending' (approved_by and approved_at are reset to NULL),
     *    and reapproval_required is flagged in the audit history.
     * 6. Concurrent edits are guarded via optimistic locking on updated_at and status.
     */
    public function adjustBonusRecord(string $id, ?string $scopedCompanyId, float $newAmount, string $reason, array $currentUser, bool $isSoftwareAppAdmin = false): array
    {
        if ($newAmount < 0) {
            return [
                'success' => false,
                'code'    => 422,
                'message' => 'Validation Error: Bonus amount must be non-negative.'
            ];
        }

        $trimmedReason = trim($reason);
        if ($trimmedReason === '') {
            return [
                'success' => false,
                'code'    => 422,
                'message' => 'Validation Error: A mandatory audited justification reason is required for adjustments.'
            ];
        }

        $builder = $this->db->table('bonus_records')
            ->select('bonus_records.*, employees.company_id as employee_company_id')
            ->join('employees', 'employees.id = bonus_records.employee_id', 'left')
            ->where('bonus_records.id', $id)
            ->where('bonus_records.deleted_at IS NULL');

        if (!$isSoftwareAppAdmin && !empty($scopedCompanyId)) {
            $builder->where('bonus_records.company_id', $scopedCompanyId);
        }

        $record = $builder->get()->getRowArray();
        if (!$record) {
            return [
                'success' => false,
                'code'    => 404,
                'message' => 'Bonus record not found or has been deleted.'
            ];
        }

        $targetCompany = $record['company_id'] ?: ($record['employee_company_id'] ?? null);
        if (!$isSoftwareAppAdmin && !empty($scopedCompanyId) && !empty($targetCompany) && (string)$targetCompany !== (string)$scopedCompanyId) {
            return [
                'success' => false,
                'code'    => 403,
                'message' => 'Cross-tenant access violation: Cannot adjust bonus belonging to another company.'
            ];
        }

        // Segregation of duties: user cannot adjust their own bonus allocation
        if (!empty($currentUser['employee_id']) && (string)$currentUser['employee_id'] === (string)$record['employee_id']) {
            return [
                'success' => false,
                'code'    => 403,
                'message' => 'Segregation of Duties Violation: You cannot adjust your own bonus allocation.'
            ];
        }

        if (!empty($record['is_settled_in_payroll']) || in_array($record['status'], ['Settled', 'Paid'], true)) {
            return [
                'success' => false,
                'code'    => 409,
                'message' => 'Action Blocked: Settled or paid bonus records cannot be adjusted.'
            ];
        }

        if ($record['status'] === 'Rejected') {
            return [
                'success' => false,
                'code'    => 409,
                'message' => 'Action Blocked: Rejected bonus records cannot be adjusted directly.'
            ];
        }

        if (!in_array($record['status'], ['Pending', 'Approved'], true)) {
            return [
                'success' => false,
                'code'    => 409,
                'message' => "Action Blocked: Only Pending or Approved bonus records can be adjusted (current status: {$record['status']})."
            ];
        }

        $history = !empty($record['adjustment_json']) ? json_decode($record['adjustment_json'], true) : [];
        if (!is_array($history)) {
            $history = !empty($history) ? [$history] : [];
        }

        $now = date('Y-m-d H:i:s');
        $priorStatus = $record['status'];
        $reapprovalRequired = ($priorStatus === 'Approved');

        $adjEntry = [
            'original_amount'     => (float)$record['amount'],
            'adjusted_amount'     => round($newAmount, 2),
            'difference'          => round($newAmount - (float)$record['amount'], 2),
            'reason'              => $trimmedReason,
            'prior_status'        => $priorStatus,
            'reapproval_required' => $reapprovalRequired,
            'prior_approved_by'   => $record['approved_by'] ?? null,
            'prior_approved_at'   => $record['approved_at'] ?? null,
            'adjusted_by'         => !empty($currentUser['name']) ? $currentUser['name'] : (!empty($currentUser['email']) ? $currentUser['email'] : 'Authorized User'),
            'adjusted_by_id'      => $currentUser['id'] ?? null,
            'adjusted_at'         => $now
        ];
        $history[] = $adjEntry;

        $this->db->transStart();

        $updateBuilder = $this->db->table('bonus_records')
            ->where('id', $id)
            ->where('deleted_at IS NULL');

        if (!$isSoftwareAppAdmin && !empty($scopedCompanyId)) {
            $updateBuilder->where('company_id', $scopedCompanyId);
        }

        // Optimistic locking on status and updated_at
        $updateBuilder->where('status', $priorStatus);
        if (!empty($record['updated_at'])) {
            $updateBuilder->where('updated_at', $record['updated_at']);
        }

        $updateFields = [
            'amount'          => round($newAmount, 2),
            'adjustment_json' => json_encode($history, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            'updated_at'      => $now
        ];

        if ($reapprovalRequired) {
            $updateFields['status']      = 'Pending';
            $updateFields['approved_by'] = null;
            $updateFields['approved_at'] = null;
            $updateFields['payroll_id']  = null;
        }
        if ($this->db->fieldExists('adjustment_reason', 'bonus_records')) {
            $updateFields['adjustment_reason'] = $trimmedReason;
        }

        $updateBuilder->update($updateFields);

        $affected = $this->db->affectedRows();
        if ($affected !== 1) {
            $this->db->transRollback();
            return [
                'success' => false,
                'code'    => 409,
                'message' => 'Conflict (409): Bonus record was modified concurrently by another transaction. Please refresh and review.'
            ];
        }

        // If this bonus was linked to an unlocked draft payroll, sync and recalculate the draft payroll item
        if (!empty($record['payroll_id'])) {
            try {
                $payrollService = new \App\Services\PayrollService();
                if ($reapprovalRequired) {
                    $deductAmt = (float)$record['amount'];
                    $synced = $payrollService->syncDraftItemBonusChange(
                        $record['payroll_id'],
                        $record['employee_id'],
                        $deductAmt,
                        null,
                        $record['id']
                    );
                } else {
                    $delta = round($newAmount - (float)$record['amount'], 2);
                    if (abs($delta) > 0.001) {
                        $deductAmt = ($delta < 0) ? abs($delta) : 0.0;
                        $synced = $payrollService->syncDraftItemBonusChange(
                            $record['payroll_id'],
                            $record['employee_id'],
                            $deductAmt,
                            null,
                            null,
                            $delta
                        );
                    } else {
                        $synced = true;
                    }
                }
                if (!$synced) {
                    $this->db->transRollback();
                    return [
                        'success' => false,
                        'code'    => 409,
                        'message' => 'Failed to adjust bonus: linked draft payroll item could not be synchronized or batch is locked.'
                    ];
                }
            } catch (\Throwable $e) {
                $this->db->transRollback();
                return [
                    'success' => false,
                    'code'    => 500,
                    'message' => 'Failed to synchronize draft payroll during bonus adjustment: ' . $e->getMessage()
                ];
            }
        }

        $this->db->transComplete();

        if ($this->db->transStatus() === false) {
            return [
                'success' => false,
                'code'    => 500,
                'message' => 'Failed to adjust bonus record due to database transaction failure.'
            ];
        }

        $msg = "Bonus adjusted to " . number_format($newAmount, 2) . ".";
        if ($reapprovalRequired) {
            $msg .= " Record moved to Pending; re-approval is required.";
        }

        return [
            'success' => true,
            'code'    => 200,
            'message' => $msg,
            'data'    => $adjEntry
        ];
    }

    /**
     * Soft delete a bonus record while retiring its idempotency check hash to allow regeneration.
     *
     * Idempotency & Regeneration Policy:
     * - Deleting a bonus record sets `deleted_at` timestamp (soft delete) to retain full historical auditability.
     * - Retires `duplicate_check_hash` with `-retired-<id>-<timestamp>-<rand>` to release the business key
     *   (company_id, duplicate_check_hash) so that the bonus allocation can be legitimately regenerated if desired.
     * - Cannot delete settled/paid records.
     * - Cannot delete approved records directly without prior rejection or cancellation.
     */
    public function softDeleteBonusRecord(string $id, ?string $scopedCompanyId, array $currentUser, bool $isSoftwareAppAdmin = false): array
    {
        $builder = $this->db->table('bonus_records')
            ->select('bonus_records.*, employees.company_id as employee_company_id')
            ->join('employees', 'employees.id = bonus_records.employee_id', 'left')
            ->where('bonus_records.id', $id)
            ->where('bonus_records.deleted_at IS NULL');

        if (!$isSoftwareAppAdmin && !empty($scopedCompanyId)) {
            $builder->where('bonus_records.company_id', $scopedCompanyId);
        }

        $record = $builder->get()->getRowArray();
        if (!$record) {
            return [
                'success' => false,
                'code'    => 404,
                'message' => 'Bonus record not found or has already been deleted.'
            ];
        }

        $targetCompany = $record['company_id'] ?: ($record['employee_company_id'] ?? null);
        if (!$isSoftwareAppAdmin && !empty($scopedCompanyId) && !empty($targetCompany) && (string)$targetCompany !== (string)$scopedCompanyId) {
            return [
                'success' => false,
                'code'    => 403,
                'message' => 'Cross-tenant access violation: Cannot delete bonus belonging to another company.'
            ];
        }

        if (!empty($record['is_settled_in_payroll']) || in_array($record['status'], ['Settled', 'Paid'], true)) {
            return [
                'success' => false,
                'code'    => 409,
                'message' => 'Action Blocked: Cannot delete bonus record that has already been settled in payroll.'
            ];
        }

        if ($record['status'] === 'Approved') {
            return [
                'success' => false,
                'code'    => 409,
                'message' => 'Action Blocked: Approved bonus records cannot be deleted directly. Reject or cancel first.'
            ];
        }

        $now = date('Y-m-d H:i:s');
        $uniqueRetiredHash = ($record['duplicate_check_hash'] ?? 'hash') . '-retired-' . $record['id'] . '-' . time() . '-' . bin2hex(random_bytes(3));

        $this->db->transStart();

        $delBuilder = $this->db->table('bonus_records')
            ->where('id', $id)
            ->where('deleted_at IS NULL');

        if (!$isSoftwareAppAdmin && !empty($scopedCompanyId)) {
            $delBuilder->where('company_id', $scopedCompanyId);
        }

        $delBuilder->update([
            'duplicate_check_hash' => $uniqueRetiredHash,
            'deleted_at'           => $now,
            'updated_at'           => $now
        ]);

        $affected = $this->db->affectedRows();
        if ($affected !== 1) {
            $this->db->transRollback();
            return [
                'success' => false,
                'code'    => 409,
                'message' => 'Conflict (409): Bonus record was already deleted or modified by another concurrent transaction.'
            ];
        }

        $this->db->transComplete();

        if ($this->db->transStatus() === false) {
            return [
                'success' => false,
                'code'    => 500,
                'message' => 'Failed to delete bonus record due to database transaction failure.'
            ];
        }

        return [
            'success' => true,
            'code'    => 200,
            'message' => 'Bonus record removed successfully.',
            'data'    => [
                'id'           => $id,
                'amount'       => $record['amount'],
                'status'       => $record['status'],
                'retired_hash' => $uniqueRetiredHash,
                'deleted_at'   => $now
            ]
        ];
    }
}
