<?php

namespace App\Services;

use App\Models\MedicalInsurance\MedicalInsuranceProviderModel;
use App\Models\MedicalInsurance\MedicalInsurancePlanModel;
use App\Models\MedicalInsurance\EmployeeMedicalInsuranceModel;
use App\Models\MedicalInsurance\MedicalInsuranceDependentModel;
use App\Models\MedicalInsurance\MedicalInsuranceClaimModel;
use App\Models\MedicalInsurance\MedicalInsuranceDocumentModel;
use App\Models\EmployeeModel;

class MedicalInsuranceService
{
    protected $db;
    protected $providerModel;
    protected $planModel;
    protected $enrollmentModel;
    protected $dependentModel;
    protected $claimModel;
    protected $docModel;
    protected $employeeModel;

    public function __construct()
    {
        $this->db              = \Config\Database::connect();
        $this->providerModel   = new MedicalInsuranceProviderModel();
        $this->planModel       = new MedicalInsurancePlanModel();
        $this->enrollmentModel = new EmployeeMedicalInsuranceModel();
        $this->dependentModel  = new MedicalInsuranceDependentModel();
        $this->claimModel      = new MedicalInsuranceClaimModel();
        $this->docModel        = new MedicalInsuranceDocumentModel();
        $this->employeeModel   = new EmployeeModel();
    }

    /**
     * Compute Executive Dashboard Statistics
     */
    public function getDashboardStats(string $companyId, array $filters = []): array
    {
        // 1. Total Active Employees in Company
        $empBuilder = $this->db->table('employees')
            ->where('company_id', $companyId)
            ->where('deleted_at IS NULL');
        
        if (!empty($filters['department_id']) && $filters['department_id'] !== 'all') {
            $empBuilder->where('department_id', $filters['department_id']);
        }
        if (!empty($filters['branch_id']) && $filters['branch_id'] !== 'all') {
            $empBuilder->where('branch_id', $filters['branch_id']);
        }
        $totalEmployees = $empBuilder->countAllResults();

        // 2. Insured Employees (Unique active enrollments)
        $insBuilder = $this->db->table('employee_medical_insurances')
            ->join('employees', 'employees.id = employee_medical_insurances.employee_id', 'inner')
            ->where('employee_medical_insurances.company_id', $companyId)
            ->where('employee_medical_insurances.coverage_status', 'Active');
        
        if (!empty($filters['department_id']) && $filters['department_id'] !== 'all') {
            $insBuilder->where('employees.department_id', $filters['department_id']);
        }
        if (!empty($filters['branch_id']) && $filters['branch_id'] !== 'all') {
            $insBuilder->where('employees.branch_id', $filters['branch_id']);
        }
        if (!empty($filters['plan_id']) && $filters['plan_id'] !== 'all') {
            $insBuilder->where('employee_medical_insurances.plan_id', $filters['plan_id']);
        }
        if (!empty($filters['provider_id']) && $filters['provider_id'] !== 'all') {
            $insBuilder->where('employee_medical_insurances.provider_id', $filters['provider_id']);
        }
        $insuredEmployees = $insBuilder->select('COUNT(DISTINCT employee_medical_insurances.employee_id) as total')->get()->getRowArray()['total'] ?? 0;
        $uninsuredEmployees = max(0, $totalEmployees - (int)$insuredEmployees);

        // 3. Active Plans and Providers
        $activePlans = $this->planModel->where('company_id', $companyId)->where('status', 'Active')->countAllResults();
        $activeProviders = $this->providerModel->where('company_id', $companyId)->where('status', 'Active')->countAllResults();

        // 4. Active Coverage vs Expiring Coverage (next 30 days)
        $activeCoverage = $this->enrollmentModel->where('company_id', $companyId)->where('coverage_status', 'Active')->countAllResults();
        $today = date('Y-m-d');
        $next30Days = date('Y-m-d', strtotime('+30 days'));
        
        $expiringCoverage = $this->enrollmentModel->where('company_id', $companyId)
            ->where('coverage_status', 'Active')
            ->where('expiry_date >=', $today)
            ->where('expiry_date <=', $next30Days)
            ->countAllResults();

        // 5. Total Dependents
        $totalDependents = $this->dependentModel->where('company_id', $companyId)->where('status', 'Active')->countAllResults();

        // 6. Claims metrics
        $claimQuery = $this->db->table('medical_insurance_claims')
            ->where('company_id', $companyId);
        
        if (!empty($filters['from_date'])) {
            $claimQuery->where('claim_date >=', $filters['from_date']);
        }
        if (!empty($filters['to_date'])) {
            $claimQuery->where('claim_date <=', $filters['to_date']);
        }
        if (!empty($filters['plan_id']) && $filters['plan_id'] !== 'all') {
            $claimQuery->where('insurance_id IN (SELECT id FROM employee_medical_insurances WHERE plan_id = ' . $this->db->escape($filters['plan_id']) . ')');
        }

        $allClaims = $claimQuery->get()->getResultArray();
        
        $totalClaims = count($allClaims);
        $pendingClaims = 0;
        $approvedClaims = 0;
        $rejectedClaims = 0;
        $paidClaims = 0;
        $totalClaimedAmount = 0.00;
        $totalApprovedAmount = 0.00;
        $totalPaidAmount = 0.00;

        foreach ($allClaims as $c) {
            $amt = (float)($c['claim_amount'] ?? 0);
            $appAmt = (float)($c['approved_amount'] ?? 0);
            $totalClaimedAmount += $amt;

            if (in_array($c['status'], ['Draft', 'Submitted', 'Under Review'], true)) {
                $pendingClaims++;
            } elseif (in_array($c['status'], ['Approved', 'Partially Approved'], true)) {
                $approvedClaims++;
                $totalApprovedAmount += $appAmt;
            } elseif ($c['status'] === 'Rejected') {
                $rejectedClaims++;
            } elseif ($c['status'] === 'Paid') {
                $paidClaims++;
                $approvedClaims++;
                $totalApprovedAmount += $appAmt;
                $totalPaidAmount += $appAmt;
            }
        }

        // 7. Plan breakdown distribution
        $planBreakdown = $this->db->table('employee_medical_insurances')
            ->select('medical_insurance_plans.name as plan_name, COUNT(*) as enrolled_count, SUM(employee_medical_insurances.employer_contribution + employee_medical_insurances.employee_contribution) as total_premium')
            ->join('medical_insurance_plans', 'medical_insurance_plans.id = employee_medical_insurances.plan_id', 'left')
            ->where('employee_medical_insurances.company_id', $companyId)
            ->where('employee_medical_insurances.coverage_status', 'Active')
            ->groupBy('employee_medical_insurances.plan_id')
            ->get()
            ->getResultArray();

        return [
            'total_employees'       => (int)$totalEmployees,
            'insured_employees'     => (int)$insuredEmployees,
            'uninsured_employees'   => (int)$uninsuredEmployees,
            'active_plans'          => (int)$activePlans,
            'active_providers'      => (int)$activeProviders,
            'active_coverage'       => (int)$activeCoverage,
            'expiring_coverage'     => (int)$expiringCoverage,
            'total_dependents'      => (int)$totalDependents,
            'total_claims'          => (int)$totalClaims,
            'pending_claims'        => (int)$pendingClaims,
            'approved_claims'       => (int)$approvedClaims,
            'rejected_claims'       => (int)$rejectedClaims,
            'paid_claims'           => (int)$paidClaims,
            'total_claimed_amount'  => round($totalClaimedAmount, 2),
            'total_approved_amount' => round($totalApprovedAmount, 2),
            'total_paid_amount'     => round($totalPaidAmount, 2),
            'plan_breakdown'        => $planBreakdown,
        ];
    }

    /**
     * Enroll an individual employee into a plan
     */
    public function enrollIndividual(string $companyId, array $data, ?string $actorId = null): array
    {
        $employeeId = $data['employee_id'] ?? null;
        $planId = $data['plan_id'] ?? null;

        if (!$employeeId || !$planId) {
            throw new \InvalidArgumentException('Employee ID and Plan ID are required for enrollment.');
        }

        // Verify Employee
        $employee = $this->employeeModel->where('company_id', $companyId)->find($employeeId);
        if (!$employee) {
            throw new \InvalidArgumentException('Employee does not exist or does not belong to the active company.');
        }

        // Verify Plan
        $plan = $this->planModel->where('company_id', $companyId)->find($planId);
        if (!$plan) {
            throw new \InvalidArgumentException('Selected insurance plan does not exist in this company.');
        }

        if ($plan['status'] !== 'Active') {
            throw new \InvalidArgumentException('Cannot enroll in an inactive or archived insurance plan.');
        }

        // Check for conflicting active coverage
        $existingActive = $this->enrollmentModel->where('company_id', $companyId)
            ->where('employee_id', $employeeId)
            ->where('coverage_status', 'Active')
            ->first();

        if ($existingActive) {
            throw new \RuntimeException("Employee already has an active medical insurance policy (Policy: {$existingActive['policy_number']}). Please suspend or cancel the current coverage before enrolling in a new plan.");
        }

        // Calculate contributions if not provided
        $employerContrib = isset($data['employer_contribution']) ? (float)$data['employer_contribution'] : 0.00;
        $employeeContrib = isset($data['employee_contribution']) ? (float)$data['employee_contribution'] : 0.00;

        if (!isset($data['employer_contribution']) && !isset($data['employee_contribution'])) {
            $basicOrGross = (float)($employee['basic_salary'] ?? $employee['gross_salary'] ?? 0.00);
            
            if ($plan['employer_contribution_type'] === 'percentage') {
                $employerContrib = round(($basicOrGross * (float)$plan['employer_contribution_value']) / 100, 2);
            } else {
                $employerContrib = (float)$plan['employer_contribution_value'];
            }

            if ($plan['employee_contribution_type'] === 'percentage') {
                $employeeContrib = round(($basicOrGross * (float)$plan['employee_contribution_value']) / 100, 2);
            } else {
                $employeeContrib = (float)$plan['employee_contribution_value'];
            }
        }

        $enrollmentId = 'emi-' . bin2hex(random_bytes(16));
        $policyNumber = !empty($data['policy_number']) ? trim((string)$data['policy_number']) : 'POL-' . date('Y') . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));
        $memberId = !empty($data['member_id']) ? trim((string)$data['member_id']) : 'MED-' . ($employee['employee_code'] ?? substr(bin2hex(random_bytes(3)), 0, 5));

        $record = [
            'id'                    => $enrollmentId,
            'company_id'            => $companyId,
            'employee_id'           => $employeeId,
            'plan_id'               => $planId,
            'provider_id'           => $plan['provider_id'] ?? null,
            'policy_number'         => $policyNumber,
            'member_id'             => $memberId,
            'enrollment_date'       => $data['enrollment_date'] ?? date('Y-m-d'),
            'effective_date'        => $data['effective_date'] ?? date('Y-m-d'),
            'expiry_date'           => !empty($data['expiry_date']) ? $data['expiry_date'] : null,
            'employer_contribution' => $employerContrib,
            'employee_contribution' => $employeeContrib,
            'coverage_status'       => $data['coverage_status'] ?? 'Active',
            'notes'                 => $data['notes'] ?? null,
            'created_by'            => $actorId,
            'updated_by'            => $actorId,
            'created_at'            => date('Y-m-d H:i:s'),
            'updated_at'            => date('Y-m-d H:i:s'),
        ];

        $this->enrollmentModel->insert($record);

        return $record;
    }

    /**
     * Bulk enroll a list of selected employee IDs into a plan inside a transaction
     */
    public function enrollBulk(string $companyId, string $planId, array $employeeIds, string $effectiveDate, ?string $expiryDate = null, ?string $actorId = null): array
    {
        $plan = $this->planModel->where('company_id', $companyId)->find($planId);
        if (!$plan || $plan['status'] !== 'Active') {
            throw new \InvalidArgumentException('Valid active insurance plan is required.');
        }

        $total = count($employeeIds);
        $enrolled = 0;
        $alreadyEnrolled = 0;
        $skipped = 0;
        $failed = 0;
        $details = [];

        $this->db->transStart();

        foreach ($employeeIds as $empId) {
            $emp = $this->employeeModel->where('company_id', $companyId)->find($empId);
            if (!$emp) {
                $skipped++;
                $details[] = ['employee_id' => $empId, 'status' => 'skipped', 'reason' => 'Employee record not found in company'];
                continue;
            }

            // Check if employee already has active coverage
            $existing = $this->enrollmentModel->where('company_id', $companyId)
                ->where('employee_id', $empId)
                ->where('coverage_status', 'Active')
                ->first();

            if ($existing) {
                $alreadyEnrolled++;
                $details[] = ['employee_id' => $empId, 'employee_code' => $emp['employee_code'], 'status' => 'already_enrolled', 'reason' => 'Active policy already exists'];
                continue;
            }

            try {
                $enrollmentData = [
                    'employee_id'    => $empId,
                    'plan_id'        => $planId,
                    'effective_date' => $effectiveDate,
                    'expiry_date'    => $expiryDate,
                    'coverage_status'=> 'Active',
                    'notes'          => 'Bulk employee enrollment execution',
                ];
                $this->enrollIndividual($companyId, $enrollmentData, $actorId);
                $enrolled++;
                $details[] = ['employee_id' => $empId, 'employee_code' => $emp['employee_code'], 'status' => 'enrolled', 'reason' => 'Successfully enrolled'];
            } catch (\Throwable $e) {
                $failed++;
                $details[] = ['employee_id' => $empId, 'employee_code' => $emp['employee_code'] ?? '', 'status' => 'failed', 'reason' => $e->getMessage()];
            }
        }

        $this->db->transComplete();

        if ($this->db->transStatus() === false) {
            throw new \RuntimeException('Database transaction failed during bulk enrollment.');
        }

        return [
            'total'            => $total,
            'enrolled'         => $enrolled,
            'already_enrolled' => $alreadyEnrolled,
            'skipped'          => $skipped,
            'failed'           => $failed,
            'details'          => $details,
        ];
    }

    /**
     * Assign a plan to ALL active employees in the current company inside a transaction
     */
    public function enrollAllActive(string $companyId, string $planId, string $effectiveDate, ?string $expiryDate = null, ?string $actorId = null): array
    {
        $plan = $this->planModel->where('company_id', $companyId)->find($planId);
        if (!$plan || $plan['status'] !== 'Active') {
            throw new \InvalidArgumentException('Valid active insurance plan is required.');
        }

        // Retrieve all active employees in current company
        $activeEmployees = $this->employeeModel->where('company_id', $companyId)
            ->groupStart()
                ->where('status', 'Active')
                ->orWhere('status', 'active')
            ->groupEnd()
            ->where('deleted_at IS NULL')
            ->findAll();

        $total = count($activeEmployees);
        $enrolled = 0;
        $alreadyEnrolled = 0;
        $skipped = 0;
        $failed = 0;
        $details = [];

        $this->db->transStart();

        foreach ($activeEmployees as $emp) {
            $empId = $emp['id'];

            // Check if already covered
            $existing = $this->enrollmentModel->where('company_id', $companyId)
                ->where('employee_id', $empId)
                ->where('coverage_status', 'Active')
                ->first();

            if ($existing) {
                $alreadyEnrolled++;
                $details[] = ['employee_id' => $empId, 'employee_code' => $emp['employee_code'], 'name' => ($emp['first_name'] . ' ' . $emp['last_name']), 'status' => 'already_enrolled', 'policy_number' => $existing['policy_number']];
                continue;
            }

            try {
                $enrollmentData = [
                    'employee_id'    => $empId,
                    'plan_id'        => $planId,
                    'effective_date' => $effectiveDate,
                    'expiry_date'    => $expiryDate,
                    'coverage_status'=> 'Active',
                    'notes'          => 'All-active company-wide enrollment operation',
                ];
                $this->enrollIndividual($companyId, $enrollmentData, $actorId);
                $enrolled++;
                $details[] = ['employee_id' => $empId, 'employee_code' => $emp['employee_code'], 'name' => ($emp['first_name'] . ' ' . $emp['last_name']), 'status' => 'enrolled'];
            } catch (\Throwable $e) {
                $failed++;
                $details[] = ['employee_id' => $empId, 'employee_code' => $emp['employee_code'], 'name' => ($emp['first_name'] . ' ' . $emp['last_name']), 'status' => 'failed', 'reason' => $e->getMessage()];
            }
        }

        $this->db->transComplete();

        if ($this->db->transStatus() === false) {
            throw new \RuntimeException('Database transaction failed while assigning medical insurance plan to all active employees.');
        }

        return [
            'total'            => $total,
            'enrolled'         => $enrolled,
            'already_enrolled' => $alreadyEnrolled,
            'skipped'          => $skipped,
            'failed'           => $failed,
            'details'          => $details,
        ];
    }

    /**
     * Retrieve Comprehensive Employee Insurance Profile
     */
    public function getEmployeeCoverageOverview(string $companyId, string $employeeId): ?array
    {
        $employee = $this->employeeModel->where('company_id', $companyId)->find($employeeId);
        if (!$employee) {
            return null;
        }

        // Active coverage
        $activeCoverage = $this->enrollmentModel->getActiveCoverage($companyId, $employeeId);

        // Coverage history
        $coverageHistory = $this->db->table('employee_medical_insurances')
            ->select('employee_medical_insurances.*, medical_insurance_plans.name as plan_name, medical_insurance_providers.name as provider_name')
            ->join('medical_insurance_plans', 'medical_insurance_plans.id = employee_medical_insurances.plan_id', 'left')
            ->join('medical_insurance_providers', 'medical_insurance_providers.id = employee_medical_insurances.provider_id', 'left')
            ->where('employee_medical_insurances.company_id', $companyId)
            ->where('employee_medical_insurances.employee_id', $employeeId)
            ->orderBy('employee_medical_insurances.effective_date', 'DESC')
            ->get()
            ->getResultArray();

        // Dependents
        $dependents = $this->dependentModel->where('company_id', $companyId)
            ->where('employee_id', $employeeId)
            ->findAll();

        // Claims
        $claims = $this->db->table('medical_insurance_claims')
            ->select('medical_insurance_claims.*, medical_insurance_dependents.name as dependent_name')
            ->join('medical_insurance_dependents', 'medical_insurance_dependents.id = medical_insurance_claims.dependent_id', 'left')
            ->where('medical_insurance_claims.company_id', $companyId)
            ->where('medical_insurance_claims.employee_id', $employeeId)
            ->orderBy('medical_insurance_claims.claim_date', 'DESC')
            ->get()
            ->getResultArray();

        // Claim Documents
        $documents = $this->docModel->where('company_id', $companyId)
            ->where('employee_id', $employeeId)
            ->orderBy('created_at', 'DESC')
            ->findAll();

        return [
            'employee'         => [
                'id'            => $employee['id'],
                'employee_code' => $employee['employee_code'],
                'first_name'    => $employee['first_name'],
                'last_name'     => $employee['last_name'],
                'email'         => $employee['email'],
                'phone'         => $employee['phone'],
                'status'        => $employee['status'],
                'basic_salary'  => $employee['basic_salary'],
                'gross_salary'  => $employee['gross_salary'],
            ],
            'active_coverage'  => $activeCoverage,
            'coverage_history' => $coverageHistory,
            'dependents'       => $dependents,
            'claims'           => $claims,
            'documents'        => $documents,
        ];
    }

    /**
     * Transition a claim's status with workflow validation
     */
    public function transitionClaimStatus(string $claimId, string $newStatus, string $companyId, ?string $actorId = null, array $extraData = []): array
    {
        $claim = $this->claimModel->where('company_id', $companyId)->find($claimId);
        if (!$claim) {
            throw new \InvalidArgumentException('Claim not found or does not belong to active company.');
        }

        $currentStatus = $claim['status'];
        $allowedTransitions = [
            'Draft'              => ['Submitted', 'Cancelled'],
            'Submitted'          => ['Under Review', 'Approved', 'Partially Approved', 'Rejected', 'Cancelled'],
            'Under Review'       => ['Approved', 'Partially Approved', 'Rejected', 'Cancelled'],
            'Approved'           => ['Paid', 'Cancelled'],
            'Partially Approved' => ['Paid', 'Cancelled'],
            'Rejected'           => ['Under Review', 'Cancelled'],
            'Paid'               => [], // Finalized terminal state
            'Cancelled'          => ['Draft'], // Can reopen to draft if requested
        ];

        if (!isset($allowedTransitions[$currentStatus]) || !in_array($newStatus, $allowedTransitions[$currentStatus], true)) {
            throw new \InvalidArgumentException("Invalid status transition from '{$currentStatus}' to '{$newStatus}'.");
        }

        $update = [
            'status'     => $newStatus,
            'updated_by' => $actorId,
            'updated_at' => date('Y-m-d H:i:s'),
        ];

        if ($newStatus === 'Submitted' && empty($claim['submitted_date'])) {
            $update['submitted_date'] = date('Y-m-d');
        }

        if (in_array($newStatus, ['Approved', 'Partially Approved'], true)) {
            $update['approved_date'] = date('Y-m-d');
            if (isset($extraData['approved_amount'])) {
                $appAmt = (float)$extraData['approved_amount'];
                if ($appAmt < 0 || $appAmt > (float)$claim['claim_amount']) {
                    throw new \InvalidArgumentException('Approved amount must be non-negative and cannot exceed total claim amount.');
                }
                $update['approved_amount'] = $appAmt;
                $update['rejected_amount'] = max(0, (float)$claim['claim_amount'] - $appAmt);
                $update['employee_payable_amount'] = $update['rejected_amount'];
            } else {
                $update['approved_amount'] = (float)$claim['claim_amount'];
                $update['rejected_amount'] = 0.00;
                $update['employee_payable_amount'] = 0.00;
            }
        }

        if ($newStatus === 'Rejected') {
            $update['rejected_date'] = date('Y-m-d');
            $update['rejected_amount'] = (float)$claim['claim_amount'];
            $update['approved_amount'] = 0.00;
            $update['employee_payable_amount'] = (float)$claim['claim_amount'];
            if (!empty($extraData['rejection_reason'])) {
                $update['rejection_reason'] = trim((string)$extraData['rejection_reason']);
            }
        }

        if ($newStatus === 'Paid') {
            $update['paid_date'] = date('Y-m-d');
        }

        if (!empty($extraData['remarks'])) {
            $update['remarks'] = trim((string)$extraData['remarks']);
        }

        $this->claimModel->update($claimId, $update);

        return array_merge($claim, $update);
    }

    /**
     * Reports: Employee Insurance Register
     */
    public function getEmployeeInsuranceReport(string $companyId, array $filters = []): array
    {
        $builder = $this->db->table('employee_medical_insurances')
            ->select('employees.first_name,
                      employees.last_name,
                      employees.employee_code,
                      departments.name as department_name,
                      designations.name as designation_name,
                      medical_insurance_plans.name as plan_name,
                      medical_insurance_providers.name as provider_name,
                      employee_medical_insurances.policy_number,
                      employee_medical_insurances.member_id,
                      employee_medical_insurances.effective_date,
                      employee_medical_insurances.expiry_date,
                      employee_medical_insurances.coverage_status,
                      employee_medical_insurances.employer_contribution,
                      employee_medical_insurances.employee_contribution')
            ->join('employees', 'employees.id = employee_medical_insurances.employee_id', 'inner')
            ->join('departments', 'departments.id = employees.department_id', 'left')
            ->join('designations', 'designations.id = employees.designation_id', 'left')
            ->join('medical_insurance_plans', 'medical_insurance_plans.id = employee_medical_insurances.plan_id', 'left')
            ->join('medical_insurance_providers', 'medical_insurance_providers.id = employee_medical_insurances.provider_id', 'left')
            ->where('employee_medical_insurances.company_id', $companyId);

        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $builder->where('employee_medical_insurances.coverage_status', $filters['status']);
        }
        if (!empty($filters['plan_id']) && $filters['plan_id'] !== 'all') {
            $builder->where('employee_medical_insurances.plan_id', $filters['plan_id']);
        }
        if (!empty($filters['department_id']) && $filters['department_id'] !== 'all') {
            $builder->where('employees.department_id', $filters['department_id']);
        }

        return $builder->orderBy('employees.first_name', 'ASC')->get()->getResultArray();
    }

    /**
     * Reports: Expiring Insurance Report
     */
    public function getExpiringInsuranceReport(string $companyId, int $days = 30, ?string $customStart = null, ?string $customEnd = null): array
    {
        $startDate = $customStart ?: date('Y-m-d');
        $endDate = $customEnd ?: date('Y-m-d', strtotime("+{$days} days"));

        return $this->db->table('employee_medical_insurances')
            ->select('employees.first_name,
                      employees.last_name,
                      employees.employee_code,
                      departments.name as department_name,
                      medical_insurance_plans.name as plan_name,
                      medical_insurance_providers.name as provider_name,
                      employee_medical_insurances.policy_number,
                      employee_medical_insurances.member_id,
                      employee_medical_insurances.effective_date,
                      employee_medical_insurances.expiry_date,
                      employee_medical_insurances.coverage_status,
                      DATEDIFF(employee_medical_insurances.expiry_date, CURDATE()) as days_remaining')
            ->join('employees', 'employees.id = employee_medical_insurances.employee_id', 'inner')
            ->join('departments', 'departments.id = employees.department_id', 'left')
            ->join('medical_insurance_plans', 'medical_insurance_plans.id = employee_medical_insurances.plan_id', 'left')
            ->join('medical_insurance_providers', 'medical_insurance_providers.id = employee_medical_insurances.provider_id', 'left')
            ->where('employee_medical_insurances.company_id', $companyId)
            ->where('employee_medical_insurances.coverage_status', 'Active')
            ->where('employee_medical_insurances.expiry_date >=', $startDate)
            ->where('employee_medical_insurances.expiry_date <=', $endDate)
            ->orderBy('employee_medical_insurances.expiry_date', 'ASC')
            ->get()
            ->getResultArray();
    }

    /**
     * Reports: Claims Report
     */
    public function getClaimsReport(string $companyId, array $filters = []): array
    {
        $builder = $this->db->table('medical_insurance_claims')
            ->select('medical_insurance_claims.claim_number,
                      employees.employee_code,
                      CONCAT(employees.first_name, " ", employees.last_name) as employee_name,
                      medical_insurance_dependents.name as dependent_name,
                      medical_insurance_plans.name as plan_name,
                      medical_insurance_providers.name as provider_name,
                      medical_insurance_claims.hospital_name,
                      medical_insurance_claims.treatment_date,
                      medical_insurance_claims.claim_date,
                      medical_insurance_claims.claim_amount,
                      medical_insurance_claims.approved_amount,
                      medical_insurance_claims.rejected_amount,
                      medical_insurance_claims.status,
                      medical_insurance_claims.submitted_date,
                      medical_insurance_claims.approved_date,
                      medical_insurance_claims.paid_date')
            ->join('employees', 'employees.id = medical_insurance_claims.employee_id', 'inner')
            ->join('medical_insurance_dependents', 'medical_insurance_dependents.id = medical_insurance_claims.dependent_id', 'left')
            ->join('employee_medical_insurances', 'employee_medical_insurances.id = medical_insurance_claims.insurance_id', 'left')
            ->join('medical_insurance_plans', 'medical_insurance_plans.id = employee_medical_insurances.plan_id', 'left')
            ->join('medical_insurance_providers', 'medical_insurance_providers.id = employee_medical_insurances.provider_id', 'left')
            ->where('medical_insurance_claims.company_id', $companyId);

        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $builder->where('medical_insurance_claims.status', $filters['status']);
        }
        if (!empty($filters['from_date'])) {
            $builder->where('medical_insurance_claims.claim_date >=', $filters['from_date']);
        }
        if (!empty($filters['to_date'])) {
            $builder->where('medical_insurance_claims.claim_date <=', $filters['to_date']);
        }

        return $builder->orderBy('medical_insurance_claims.claim_date', 'DESC')->get()->getResultArray();
    }

    /**
     * Reports: Contribution Summary Report
     */
    public function getContributionReport(string $companyId, array $filters = []): array
    {
        $builder = $this->db->table('employee_medical_insurances')
            ->select('employees.employee_code,
                      CONCAT(employees.first_name, " ", employees.last_name) as employee_name,
                      medical_insurance_plans.name as plan_name,
                      employee_medical_insurances.employer_contribution,
                      employee_medical_insurances.employee_contribution,
                      (employee_medical_insurances.employer_contribution + employee_medical_insurances.employee_contribution) as total_contribution,
                      employee_medical_insurances.coverage_status')
            ->join('employees', 'employees.id = employee_medical_insurances.employee_id', 'inner')
            ->join('medical_insurance_plans', 'medical_insurance_plans.id = employee_medical_insurances.plan_id', 'left')
            ->where('employee_medical_insurances.company_id', $companyId);

        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $builder->where('employee_medical_insurances.coverage_status', $filters['status']);
        }
        if (!empty($filters['plan_id']) && $filters['plan_id'] !== 'all') {
            $builder->where('employee_medical_insurances.plan_id', $filters['plan_id']);
        }

        return $builder->orderBy('employees.first_name', 'ASC')->get()->getResultArray();
    }

    /**
     * Provider Management: Get Providers with Filters and Pagination
     */
    public function getProviders(string $companyId, array $filters = [], int $limit = 50, int $offset = 0): array
    {
        $builder = $this->db->table('medical_insurance_providers')
            ->where('company_id', $companyId)
            ->where('deleted_at IS NULL');

        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $builder->where('status', $filters['status']);
        }

        if (!empty($filters['search'])) {
            $s = trim((string)$filters['search']);
            $builder->groupStart()
                ->like('name', $s)
                ->orLike('contact_person', $s)
                ->orLike('phone', $s)
                ->orLike('email', $s)
                ->orLike('policy_number', $s)
                ->groupEnd();
        }

        $totalCount = (clone $builder)->countAllResults();

        $rows = $builder->orderBy('created_at', 'DESC')
            ->limit($limit, $offset)
            ->get()
            ->getResultArray();

        // Attach plan count to each provider
        foreach ($rows as &$r) {
            $r['plan_count'] = $this->db->table('medical_insurance_plans')
                ->where('company_id', $companyId)
                ->where('provider_id', $r['id'])
                ->where('deleted_at IS NULL')
                ->countAllResults();
        }

        return [
            'providers' => $rows,
            'total'     => $totalCount,
            'limit'     => $limit,
            'offset'    => $offset,
        ];
    }

    /**
     * Save (Create or Update) Insurance Provider
     */
    public function saveProvider(string $companyId, array $data, ?string $actorId = null): array
    {
        $name = trim((string)($data['name'] ?? ''));
        if (empty($name)) {
            throw new \InvalidArgumentException('Provider name is required.');
        }

        $id = !empty($data['id']) ? trim((string)$data['id']) : null;
        $now = date('Y-m-d H:i:s');

        $record = [
            'company_id'          => $companyId,
            'name'                => $name,
            'contact_person'      => !empty($data['contact_person']) ? trim((string)$data['contact_person']) : null,
            'phone'               => !empty($data['phone']) ? trim((string)$data['phone']) : null,
            'email'               => !empty($data['email']) ? trim((string)$data['email']) : null,
            'address'             => !empty($data['address']) ? trim((string)$data['address']) : null,
            'policy_number'       => !empty($data['policy_number']) ? trim((string)$data['policy_number']) : null,
            'contract_start_date' => !empty($data['contract_start_date']) ? $data['contract_start_date'] : null,
            'contract_end_date'   => !empty($data['contract_end_date']) ? $data['contract_end_date'] : null,
            'status'              => in_array($data['status'] ?? 'Active', ['Active', 'Inactive', 'Terminated'], true) ? $data['status'] : 'Active',
            'notes'               => !empty($data['notes']) ? trim((string)$data['notes']) : null,
            'updated_by'          => $actorId,
            'updated_at'          => $now,
        ];

        if (!empty($id)) {
            $existing = $this->providerModel->where('company_id', $companyId)->find($id);
            if (!$existing) {
                throw new \InvalidArgumentException('Provider not found or does not belong to the active company.');
            }
            $this->providerModel->update($id, $record);
            return array_merge($existing, $record);
        }

        $newId = 'mip-' . bin2hex(random_bytes(16));
        $record['id']         = $newId;
        $record['created_by'] = $actorId;
        $record['created_at'] = $now;

        $this->providerModel->insert($record);
        return $record;
    }

    /**
     * Delete / Deactivate Insurance Provider
     */
    public function deleteProvider(string $companyId, string $id, ?string $actorId = null): bool
    {
        $existing = $this->providerModel->where('company_id', $companyId)->find($id);
        if (!$existing) {
            throw new \InvalidArgumentException('Provider not found or does not belong to the active company.');
        }

        // Check if provider has active plans
        $activePlans = $this->planModel->where('company_id', $companyId)
            ->where('provider_id', $id)
            ->where('status', 'Active')
            ->countAllResults();

        if ($activePlans > 0) {
            throw new \RuntimeException("Cannot delete provider '{$existing['name']}' because it is linked to {$activePlans} active insurance plan(s). Please reassign or archive those plans first.");
        }

        $this->providerModel->delete($id);
        return true;
    }

    /**
     * Plan Management: Get Plans with Provider Details, Filters, Pagination
     */
    public function getPlans(string $companyId, array $filters = [], int $limit = 50, int $offset = 0): array
    {
        $builder = $this->db->table('medical_insurance_plans')
            ->select('medical_insurance_plans.*, medical_insurance_providers.name as provider_name, medical_insurance_providers.contact_person as provider_contact, medical_insurance_providers.phone as provider_phone')
            ->join('medical_insurance_providers', 'medical_insurance_providers.id = medical_insurance_plans.provider_id', 'left')
            ->where('medical_insurance_plans.company_id', $companyId)
            ->where('medical_insurance_plans.deleted_at IS NULL');

        if (!empty($filters['provider_id']) && $filters['provider_id'] !== 'all') {
            $builder->where('medical_insurance_plans.provider_id', $filters['provider_id']);
        }

        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $builder->where('medical_insurance_plans.status', $filters['status']);
        }

        if (!empty($filters['search'])) {
            $s = trim((string)$filters['search']);
            $builder->groupStart()
                ->like('medical_insurance_plans.name', $s)
                ->orLike('medical_insurance_plans.plan_code', $s)
                ->orLike('medical_insurance_providers.name', $s)
                ->groupEnd();
        }

        $totalCount = (clone $builder)->countAllResults();

        $rows = $builder->orderBy('medical_insurance_plans.created_at', 'DESC')
            ->limit($limit, $offset)
            ->get()
            ->getResultArray();

        // Attach active enrollment counts to each plan
        foreach ($rows as &$r) {
            $r['enrolled_count'] = $this->db->table('employee_medical_insurances')
                ->where('company_id', $companyId)
                ->where('plan_id', $r['id'])
                ->where('coverage_status', 'Active')
                ->countAllResults();
        }

        return [
            'plans'  => $rows,
            'total'  => $totalCount,
            'limit'  => $limit,
            'offset' => $offset,
        ];
    }

    /**
     * Save (Create or Update) Insurance Plan
     */
    public function savePlan(string $companyId, array $data, ?string $actorId = null): array
    {
        $name = trim((string)($data['name'] ?? ''));
        $planCode = strtoupper(trim((string)($data['plan_code'] ?? '')));
        $providerId = trim((string)($data['provider_id'] ?? ''));

        if (empty($name) || empty($planCode) || empty($providerId)) {
            throw new \InvalidArgumentException('Plan Name, Plan Code, and Provider ID are required.');
        }

        // Verify provider exists in this company
        $provider = $this->providerModel->where('company_id', $companyId)->find($providerId);
        if (!$provider) {
            throw new \InvalidArgumentException('Selected insurance provider does not exist in this company.');
        }

        $id = !empty($data['id']) ? trim((string)$data['id']) : null;
        $now = date('Y-m-d H:i:s');

        // Check plan code uniqueness within company
        $codeCheck = $this->planModel->where('company_id', $companyId)
            ->where('plan_code', $planCode);
        if (!empty($id)) {
            $codeCheck->where('id !=', $id);
        }
        if ($codeCheck->first()) {
            throw new \InvalidArgumentException("Plan code '{$planCode}' is already in use within your company.");
        }

        $record = [
            'company_id'                  => $companyId,
            'provider_id'                 => $providerId,
            'name'                        => $name,
            'plan_code'                   => $planCode,
            'description'                 => !empty($data['description']) ? trim((string)$data['description']) : null,
            'annual_coverage_limit'       => round((float)($data['annual_coverage_limit'] ?? 0.00), 2),
            'hospitalization_coverage'    => !empty($data['hospitalization_coverage']) ? 1 : 0,
            'opd_coverage'                => !empty($data['opd_coverage']) ? 1 : 0,
            'emergency_coverage'          => !empty($data['emergency_coverage']) ? 1 : 0,
            'maternity_coverage'          => !empty($data['maternity_coverage']) ? 1 : 0,
            'dental_coverage'             => !empty($data['dental_coverage']) ? 1 : 0,
            'vision_coverage'             => !empty($data['vision_coverage']) ? 1 : 0,
            'other_coverage_details'      => !empty($data['other_coverage_details']) ? trim((string)$data['other_coverage_details']) : null,
            'employer_contribution_type'  => in_array($data['employer_contribution_type'] ?? 'percentage', ['percentage', 'fixed'], true) ? $data['employer_contribution_type'] : 'percentage',
            'employer_contribution_value' => round((float)($data['employer_contribution_value'] ?? 0.00), 2),
            'employee_contribution_type'  => in_array($data['employee_contribution_type'] ?? 'percentage', ['percentage', 'fixed'], true) ? $data['employee_contribution_type'] : 'percentage',
            'employee_contribution_value' => round((float)($data['employee_contribution_value'] ?? 0.00), 2),
            'effective_date'              => !empty($data['effective_date']) ? $data['effective_date'] : null,
            'expiry_date'                 => !empty($data['expiry_date']) ? $data['expiry_date'] : null,
            'status'                      => in_array($data['status'] ?? 'Active', ['Active', 'Inactive', 'Archived'], true) ? $data['status'] : 'Active',
            'notes'                       => !empty($data['notes']) ? trim((string)$data['notes']) : null,
            'updated_by'                  => $actorId,
            'updated_at'                  => $now,
        ];

        if (!empty($id)) {
            $existing = $this->planModel->where('company_id', $companyId)->find($id);
            if (!$existing) {
                throw new \InvalidArgumentException('Plan not found or does not belong to the active company.');
            }
            $this->planModel->update($id, $record);
            return array_merge($existing, $record);
        }

        $newId = 'mpl-' . bin2hex(random_bytes(16));
        $record['id']         = $newId;
        $record['created_by'] = $actorId;
        $record['created_at'] = $now;

        $this->planModel->insert($record);
        return $record;
    }

    /**
     * Delete / Archive Insurance Plan
     */
    public function deletePlan(string $companyId, string $id, ?string $actorId = null): bool
    {
        $existing = $this->planModel->where('company_id', $companyId)->find($id);
        if (!$existing) {
            throw new \InvalidArgumentException('Plan not found or does not belong to the active company.');
        }

        $activeEnrollments = $this->enrollmentModel->where('company_id', $companyId)
            ->where('plan_id', $id)
            ->where('coverage_status', 'Active')
            ->countAllResults();

        if ($activeEnrollments > 0) {
            throw new \RuntimeException("Cannot delete plan '{$existing['name']}' because {$activeEnrollments} employee(s) are currently covered under it. Please migrate or cancel the active coverages first.");
        }

        $this->planModel->delete($id);
        return true;
    }

    /**
     * Enrollment Management: Get Enrollments with Details, Filters, Pagination
     */
    public function getEnrollments(string $companyId, array $filters = [], int $limit = 50, int $offset = 0): array
    {
        $builder = $this->db->table('employee_medical_insurances')
            ->select('employee_medical_insurances.*,
                      employees.employee_code,
                      employees.first_name,
                      employees.last_name,
                      employees.email as employee_email,
                      employees.phone as employee_phone,
                      departments.name as department_name,
                      designations.name as designation_name,
                      branches.name as branch_name,
                      medical_insurance_plans.name as plan_name,
                      medical_insurance_plans.plan_code,
                      medical_insurance_plans.annual_coverage_limit,
                      medical_insurance_providers.name as provider_name')
            ->join('employees', 'employees.id = employee_medical_insurances.employee_id', 'left')
            ->join('departments', 'departments.id = employees.department_id', 'left')
            ->join('designations', 'designations.id = employees.designation_id', 'left')
            ->join('branches', 'branches.id = employees.branch_id', 'left')
            ->join('medical_insurance_plans', 'medical_insurance_plans.id = employee_medical_insurances.plan_id', 'left')
            ->join('medical_insurance_providers', 'medical_insurance_providers.id = employee_medical_insurances.provider_id', 'left')
            ->where('employee_medical_insurances.company_id', $companyId);

        if (!empty($filters['employee_id'])) {
            $builder->where('employee_medical_insurances.employee_id', $filters['employee_id']);
        }
        if (!empty($filters['plan_id']) && $filters['plan_id'] !== 'all') {
            $builder->where('employee_medical_insurances.plan_id', $filters['plan_id']);
        }
        if (!empty($filters['provider_id']) && $filters['provider_id'] !== 'all') {
            $builder->where('employee_medical_insurances.provider_id', $filters['provider_id']);
        }
        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $builder->where('employee_medical_insurances.coverage_status', $filters['status']);
        }
        if (!empty($filters['department_id']) && $filters['department_id'] !== 'all') {
            $builder->where('employees.department_id', $filters['department_id']);
        }

        if (!empty($filters['search'])) {
            $s = trim((string)$filters['search']);
            $builder->groupStart()
                ->like('employees.first_name', $s)
                ->orLike('employees.last_name', $s)
                ->orLike('employees.employee_code', $s)
                ->orLike('employee_medical_insurances.policy_number', $s)
                ->orLike('employee_medical_insurances.member_id', $s)
                ->orLike('medical_insurance_plans.name', $s)
                ->groupEnd();
        }

        $totalCount = (clone $builder)->countAllResults();

        $rows = $builder->orderBy('employee_medical_insurances.created_at', 'DESC')
            ->limit($limit, $offset)
            ->get()
            ->getResultArray();

        return [
            'enrollments' => $rows,
            'total'       => $totalCount,
            'limit'       => $limit,
            'offset'      => $offset,
        ];
    }

    /**
     * Update Existing Enrollment Details
     */
    public function updateEnrollment(string $companyId, string $enrollmentId, array $data, ?string $actorId = null): array
    {
        $existing = $this->enrollmentModel->where('company_id', $companyId)->find($enrollmentId);
        if (!$existing) {
            throw new \InvalidArgumentException('Enrollment not found or does not belong to the active company.');
        }

        $update = [
            'updated_by' => $actorId,
            'updated_at' => date('Y-m-d H:i:s'),
        ];

        if (isset($data['policy_number'])) {
            $update['policy_number'] = trim((string)$data['policy_number']);
        }
        if (isset($data['member_id'])) {
            $update['member_id'] = trim((string)$data['member_id']);
        }
        if (!empty($data['effective_date'])) {
            $update['effective_date'] = $data['effective_date'];
        }
        if (array_key_exists('expiry_date', $data)) {
            $update['expiry_date'] = !empty($data['expiry_date']) ? $data['expiry_date'] : null;
        }
        if (isset($data['employer_contribution'])) {
            $update['employer_contribution'] = round((float)$data['employer_contribution'], 2);
        }
        if (isset($data['employee_contribution'])) {
            $update['employee_contribution'] = round((float)$data['employee_contribution'], 2);
        }
        if (isset($data['notes'])) {
            $update['notes'] = trim((string)$data['notes']);
        }

        $this->enrollmentModel->update($enrollmentId, $update);
        return array_merge($existing, $update);
    }

    /**
     * Update Enrollment Coverage Status (e.g. Cancel, Suspend, Activate)
     */
    public function updateEnrollmentStatus(string $companyId, string $enrollmentId, string $newStatus, array $extra = [], ?string $actorId = null): array
    {
        $existing = $this->enrollmentModel->where('company_id', $companyId)->find($enrollmentId);
        if (!$existing) {
            throw new \InvalidArgumentException('Enrollment not found or does not belong to the active company.');
        }

        $allowedStatuses = ['Pending', 'Active', 'Suspended', 'Expired', 'Cancelled'];
        if (!in_array($newStatus, $allowedStatuses, true)) {
            throw new \InvalidArgumentException("Invalid coverage status '{$newStatus}'. Allowed: " . implode(', ', $allowedStatuses));
        }

        // If activating, verify no other active coverage exists for this employee
        if ($newStatus === 'Active' && $existing['coverage_status'] !== 'Active') {
            $conflict = $this->enrollmentModel->where('company_id', $companyId)
                ->where('employee_id', $existing['employee_id'])
                ->where('coverage_status', 'Active')
                ->where('id !=', $enrollmentId)
                ->first();
            if ($conflict) {
                throw new \RuntimeException("Employee already has an active policy (Policy #{$conflict['policy_number']}). Please suspend or cancel that policy first.");
            }
        }

        $update = [
            'coverage_status' => $newStatus,
            'updated_by'      => $actorId,
            'updated_at'      => date('Y-m-d H:i:s'),
        ];

        if ($newStatus === 'Cancelled') {
            $update['cancellation_date'] = !empty($extra['cancellation_date']) ? $extra['cancellation_date'] : date('Y-m-d');
            $update['cancellation_reason'] = !empty($extra['cancellation_reason']) ? trim((string)$extra['cancellation_reason']) : 'Policy cancelled by administrator';
        }

        $this->enrollmentModel->update($enrollmentId, $update);
        return array_merge($existing, $update);
    }

    /**
     * Delete Enrollment
     */
    public function deleteEnrollment(string $companyId, string $enrollmentId, ?string $actorId = null): bool
    {
        $existing = $this->enrollmentModel->where('company_id', $companyId)->find($enrollmentId);
        if (!$existing) {
            throw new \InvalidArgumentException('Enrollment not found or does not belong to the active company.');
        }

        // Check if claims exist on this enrollment
        $claimsCount = $this->claimModel->where('company_id', $companyId)
            ->where('insurance_id', $enrollmentId)
            ->countAllResults();

        if ($claimsCount > 0) {
            throw new \RuntimeException("Cannot delete enrollment because {$claimsCount} medical claim(s) are attached to this insurance policy. Please cancel the policy instead.");
        }

        $this->enrollmentModel->delete($enrollmentId);
        return true;
    }

    /**
     * Dependent Management: Get Dependents with Filters and Pagination
     */
    public function getDependents(string $companyId, array $filters = [], int $limit = 50, int $offset = 0): array
    {
        $builder = $this->db->table('medical_insurance_dependents')
            ->select('medical_insurance_dependents.*,
                      employees.employee_code,
                      employees.first_name,
                      employees.last_name,
                      departments.name as department_name,
                      employee_medical_insurances.policy_number as enrollment_policy_number,
                      employee_medical_insurances.member_id as enrollment_member_id')
            ->join('employees', 'employees.id = medical_insurance_dependents.employee_id', 'left')
            ->join('departments', 'departments.id = employees.department_id', 'left')
            ->join('employee_medical_insurances', 'employee_medical_insurances.id = medical_insurance_dependents.insurance_id', 'left')
            ->where('medical_insurance_dependents.company_id', $companyId);

        if (!empty($filters['employee_id'])) {
            $builder->where('medical_insurance_dependents.employee_id', $filters['employee_id']);
        }
        if (!empty($filters['relationship']) && $filters['relationship'] !== 'all') {
            $builder->where('medical_insurance_dependents.relationship', $filters['relationship']);
        }
        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $builder->where('medical_insurance_dependents.status', $filters['status']);
        }

        if (!empty($filters['search'])) {
            $s = trim((string)$filters['search']);
            $builder->groupStart()
                ->like('medical_insurance_dependents.name', $s)
                ->orLike('medical_insurance_dependents.member_id', $s)
                ->orLike('employees.first_name', $s)
                ->orLike('employees.last_name', $s)
                ->orLike('employees.employee_code', $s)
                ->groupEnd();
        }

        $totalCount = (clone $builder)->countAllResults();

        $rows = $builder->orderBy('medical_insurance_dependents.created_at', 'DESC')
            ->limit($limit, $offset)
            ->get()
            ->getResultArray();

        return [
            'dependents' => $rows,
            'total'      => $totalCount,
            'limit'      => $limit,
            'offset'     => $offset,
        ];
    }

    /**
     * Save (Create or Update) Dependent
     */
    public function saveDependent(string $companyId, array $data, ?string $actorId = null): array
    {
        $employeeId = trim((string)($data['employee_id'] ?? ''));
        $name = trim((string)($data['name'] ?? ''));
        $relationship = trim((string)($data['relationship'] ?? 'Spouse'));

        if (empty($employeeId) || empty($name)) {
            throw new \InvalidArgumentException('Employee and Dependent Name are required.');
        }

        // Verify employee belongs to company
        $emp = $this->employeeModel->where('company_id', $companyId)->find($employeeId);
        if (!$emp) {
            throw new \InvalidArgumentException('Selected employee does not exist in this company.');
        }

        // Try to link to employee's active medical insurance if not specified
        $insuranceId = !empty($data['insurance_id']) ? trim((string)$data['insurance_id']) : null;
        if (empty($insuranceId)) {
            $activePolicy = $this->enrollmentModel->where('company_id', $companyId)
                ->where('employee_id', $employeeId)
                ->where('coverage_status', 'Active')
                ->first();
            if ($activePolicy) {
                $insuranceId = $activePolicy['id'];
            }
        }

        $id = !empty($data['id']) ? trim((string)$data['id']) : null;
        $now = date('Y-m-d H:i:s');

        $record = [
            'company_id'          => $companyId,
            'employee_id'         => $employeeId,
            'insurance_id'        => $insuranceId,
            'name'                => $name,
            'relationship'        => in_array($relationship, ['Spouse', 'Child', 'Parent', 'Other'], true) ? $relationship : 'Other',
            'dob'                 => !empty($data['dob']) ? $data['dob'] : null,
            'gender'              => !empty($data['gender']) ? trim((string)$data['gender']) : null,
            'member_id'           => !empty($data['member_id']) ? trim((string)$data['member_id']) : 'DEP-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6)),
            'policy_number'       => !empty($data['policy_number']) ? trim((string)$data['policy_number']) : null,
            'coverage_start_date' => !empty($data['coverage_start_date']) ? $data['coverage_start_date'] : date('Y-m-d'),
            'coverage_end_date'   => !empty($data['coverage_end_date']) ? $data['coverage_end_date'] : null,
            'status'              => in_array($data['status'] ?? 'Active', ['Active', 'Inactive', 'Suspended', 'Cancelled'], true) ? $data['status'] : 'Active',
            'notes'               => !empty($data['notes']) ? trim((string)$data['notes']) : null,
            'updated_by'          => $actorId,
            'updated_at'          => $now,
        ];

        if (!empty($id)) {
            $existing = $this->dependentModel->where('company_id', $companyId)->find($id);
            if (!$existing) {
                throw new \InvalidArgumentException('Dependent not found or does not belong to active company.');
            }
            $this->dependentModel->update($id, $record);
            return array_merge($existing, $record);
        }

        $newId = 'mid-' . bin2hex(random_bytes(16));
        $record['id']         = $newId;
        $record['created_by'] = $actorId;
        $record['created_at'] = $now;

        $this->dependentModel->insert($record);
        return $record;
    }

    /**
     * Delete Dependent
     */
    public function deleteDependent(string $companyId, string $id, ?string $actorId = null): bool
    {
        $existing = $this->dependentModel->where('company_id', $companyId)->find($id);
        if (!$existing) {
            throw new \InvalidArgumentException('Dependent not found or does not belong to active company.');
        }

        // Check if claims are tied to this dependent
        $claimsCount = $this->claimModel->where('company_id', $companyId)
            ->where('dependent_id', $id)
            ->countAllResults();

        if ($claimsCount > 0) {
            throw new \RuntimeException("Cannot delete dependent '{$existing['name']}' because {$claimsCount} medical claim(s) are attached to this dependent record. Please change status to Inactive instead.");
        }

        $this->dependentModel->delete($id);
        return true;
    }

    /**
     * Claims Management: Get Claims with Full Details, Filters, Pagination
     */
    public function getClaims(string $companyId, array $filters = [], int $limit = 50, int $offset = 0): array
    {
        $builder = $this->db->table('medical_insurance_claims')
            ->select('medical_insurance_claims.*,
                      employees.employee_code,
                      employees.first_name,
                      employees.last_name,
                      departments.name as department_name,
                      medical_insurance_dependents.name as dependent_name,
                      medical_insurance_dependents.relationship as dependent_relationship,
                      medical_insurance_plans.name as plan_name,
                      medical_insurance_plans.plan_code,
                      medical_insurance_providers.name as provider_name,
                      employee_medical_insurances.policy_number,
                      employee_medical_insurances.member_id')
            ->join('employees', 'employees.id = medical_insurance_claims.employee_id', 'left')
            ->join('departments', 'departments.id = employees.department_id', 'left')
            ->join('medical_insurance_dependents', 'medical_insurance_dependents.id = medical_insurance_claims.dependent_id', 'left')
            ->join('employee_medical_insurances', 'employee_medical_insurances.id = medical_insurance_claims.insurance_id', 'left')
            ->join('medical_insurance_plans', 'medical_insurance_plans.id = employee_medical_insurances.plan_id', 'left')
            ->join('medical_insurance_providers', 'medical_insurance_providers.id = employee_medical_insurances.provider_id', 'left')
            ->where('medical_insurance_claims.company_id', $companyId);

        if (!empty($filters['employee_id'])) {
            $builder->where('medical_insurance_claims.employee_id', $filters['employee_id']);
        }
        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $builder->where('medical_insurance_claims.status', $filters['status']);
        }
        if (!empty($filters['plan_id']) && $filters['plan_id'] !== 'all') {
            $builder->where('employee_medical_insurances.plan_id', $filters['plan_id']);
        }
        if (!empty($filters['from_date'])) {
            $builder->where('medical_insurance_claims.claim_date >=', $filters['from_date']);
        }
        if (!empty($filters['to_date'])) {
            $builder->where('medical_insurance_claims.claim_date <=', $filters['to_date']);
        }

        if (!empty($filters['search'])) {
            $s = trim((string)$filters['search']);
            $builder->groupStart()
                ->like('medical_insurance_claims.claim_number', $s)
                ->orLike('medical_insurance_claims.hospital_name', $s)
                ->orLike('employees.first_name', $s)
                ->orLike('employees.last_name', $s)
                ->orLike('employees.employee_code', $s)
                ->orLike('medical_insurance_dependents.name', $s)
                ->groupEnd();
        }

        $totalCount = (clone $builder)->countAllResults();

        $rows = $builder->orderBy('medical_insurance_claims.created_at', 'DESC')
            ->limit($limit, $offset)
            ->get()
            ->getResultArray();

        // Attach document count to each claim
        foreach ($rows as &$r) {
            $r['doc_count'] = $this->db->table('medical_insurance_documents')
                ->where('company_id', $companyId)
                ->where('claim_id', $r['id'])
                ->countAllResults();
        }

        return [
            'claims' => $rows,
            'total'  => $totalCount,
            'limit'  => $limit,
            'offset' => $offset,
        ];
    }

    /**
     * Get Single Claim with Complete Associated Documents and Details
     */
    public function getClaimDetails(string $companyId, string $claimId): ?array
    {
        $claim = $this->db->table('medical_insurance_claims')
            ->select('medical_insurance_claims.*,
                      employees.employee_code,
                      employees.first_name,
                      employees.last_name,
                      employees.email as employee_email,
                      departments.name as department_name,
                      medical_insurance_dependents.name as dependent_name,
                      medical_insurance_dependents.relationship as dependent_relationship,
                      medical_insurance_plans.name as plan_name,
                      medical_insurance_plans.plan_code,
                      medical_insurance_plans.annual_coverage_limit,
                      medical_insurance_providers.name as provider_name,
                      employee_medical_insurances.policy_number,
                      employee_medical_insurances.member_id')
            ->join('employees', 'employees.id = medical_insurance_claims.employee_id', 'left')
            ->join('departments', 'departments.id = employees.department_id', 'left')
            ->join('medical_insurance_dependents', 'medical_insurance_dependents.id = medical_insurance_claims.dependent_id', 'left')
            ->join('employee_medical_insurances', 'employee_medical_insurances.id = medical_insurance_claims.insurance_id', 'left')
            ->join('medical_insurance_plans', 'medical_insurance_plans.id = employee_medical_insurances.plan_id', 'left')
            ->join('medical_insurance_providers', 'medical_insurance_providers.id = employee_medical_insurances.provider_id', 'left')
            ->where('medical_insurance_claims.company_id', $companyId)
            ->where('medical_insurance_claims.id', $claimId)
            ->get()
            ->getRowArray();

        if (!$claim) {
            return null;
        }

        $documents = $this->docModel->where('company_id', $companyId)
            ->where('claim_id', $claimId)
            ->orderBy('created_at', 'DESC')
            ->findAll();

        $claim['documents'] = $documents;

        return $claim;
    }

    /**
     * Create New Medical Claim
     */
    public function createClaim(string $companyId, array $data, ?string $actorId = null): array
    {
        $employeeId = trim((string)($data['employee_id'] ?? ''));
        $hospitalName = trim((string)($data['hospital_name'] ?? ''));
        $claimAmount = round((float)($data['claim_amount'] ?? 0.00), 2);
        $treatmentDate = !empty($data['treatment_date']) ? $data['treatment_date'] : date('Y-m-d');
        $claimDate = !empty($data['claim_date']) ? $data['claim_date'] : date('Y-m-d');

        if (empty($employeeId) || empty($hospitalName) || $claimAmount <= 0) {
            throw new \InvalidArgumentException('Employee, Hospital Name, and valid Claim Amount (> 0) are required.');
        }

        // Verify employee
        $emp = $this->employeeModel->where('company_id', $companyId)->find($employeeId);
        if (!$emp) {
            throw new \InvalidArgumentException('Selected employee does not exist in this company.');
        }

        // Get active or selected insurance enrollment
        $insuranceId = !empty($data['insurance_id']) ? trim((string)$data['insurance_id']) : null;
        if (empty($insuranceId)) {
            $activePolicy = $this->enrollmentModel->where('company_id', $companyId)
                ->where('employee_id', $employeeId)
                ->where('coverage_status', 'Active')
                ->first();
            if (!$activePolicy) {
                throw new \InvalidArgumentException('Employee does not have an active medical insurance enrollment.');
            }
            $insuranceId = $activePolicy['id'];
        } else {
            $policy = $this->enrollmentModel->where('company_id', $companyId)->find($insuranceId);
            if (!$policy) {
                throw new \InvalidArgumentException('Specified insurance enrollment not found in this company.');
            }
        }

        // Dependent check if supplied
        $dependentId = !empty($data['dependent_id']) ? trim((string)$data['dependent_id']) : null;
        if (!empty($dependentId)) {
            $dep = $this->dependentModel->where('company_id', $companyId)
                ->where('employee_id', $employeeId)
                ->find($dependentId);
            if (!$dep) {
                throw new \InvalidArgumentException('Selected dependent does not belong to this employee.');
            }
        }

        $claimId = 'mic-' . bin2hex(random_bytes(16));
        $claimNumber = 'CLM-' . date('Ym') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 5));

        $status = in_array($data['status'] ?? 'Submitted', ['Draft', 'Submitted'], true) ? $data['status'] : 'Submitted';
        $submittedDate = ($status === 'Submitted') ? date('Y-m-d') : null;

        $record = [
            'id'                      => $claimId,
            'company_id'              => $companyId,
            'employee_id'             => $employeeId,
            'dependent_id'            => $dependentId,
            'insurance_id'            => $insuranceId,
            'claim_number'            => $claimNumber,
            'claim_date'              => $claimDate,
            'treatment_date'          => $treatmentDate,
            'hospital_name'           => $hospitalName,
            'treatment_description'   => !empty($data['treatment_description']) ? trim((string)$data['treatment_description']) : null,
            'claim_amount'            => $claimAmount,
            'approved_amount'         => 0.00,
            'rejected_amount'         => 0.00,
            'employee_payable_amount' => 0.00,
            'status'                  => $status,
            'submitted_date'          => $submittedDate,
            'remarks'                 => !empty($data['remarks']) ? trim((string)$data['remarks']) : null,
            'created_by'              => $actorId,
            'updated_by'              => $actorId,
            'created_at'              => date('Y-m-d H:i:s'),
            'updated_at'              => date('Y-m-d H:i:s'),
        ];

        $this->claimModel->insert($record);
        return $record;
    }

    /**
     * Update Claim Information while in Draft or Submitted state
     */
    public function updateClaim(string $companyId, string $claimId, array $data, ?string $actorId = null): array
    {
        $existing = $this->claimModel->where('company_id', $companyId)->find($claimId);
        if (!$existing) {
            throw new \InvalidArgumentException('Claim not found or does not belong to active company.');
        }

        if (!in_array($existing['status'], ['Draft', 'Submitted', 'Under Review'], true)) {
            throw new \RuntimeException("Cannot modify claim in '{$existing['status']}' state. Only Draft, Submitted, or Under Review claims can be modified.");
        }

        $update = [
            'updated_by' => $actorId,
            'updated_at' => date('Y-m-d H:i:s'),
        ];

        if (!empty($data['hospital_name'])) {
            $update['hospital_name'] = trim((string)$data['hospital_name']);
        }
        if (isset($data['treatment_description'])) {
            $update['treatment_description'] = trim((string)$data['treatment_description']);
        }
        if (!empty($data['treatment_date'])) {
            $update['treatment_date'] = $data['treatment_date'];
        }
        if (isset($data['claim_amount'])) {
            $amt = round((float)$data['claim_amount'], 2);
            if ($amt <= 0) {
                throw new \InvalidArgumentException('Claim amount must be greater than zero.');
            }
            $update['claim_amount'] = $amt;
        }
        if (isset($data['remarks'])) {
            $update['remarks'] = trim((string)$data['remarks']);
        }

        $this->claimModel->update($claimId, $update);
        return array_merge($existing, $update);
    }

    /**
     * Delete Claim (only Draft or Cancelled claims)
     */
    public function deleteClaim(string $companyId, string $claimId, ?string $actorId = null): bool
    {
        $existing = $this->claimModel->where('company_id', $companyId)->find($claimId);
        if (!$existing) {
            throw new \InvalidArgumentException('Claim not found or does not belong to active company.');
        }

        if (!in_array($existing['status'], ['Draft', 'Cancelled'], true)) {
            throw new \RuntimeException("Only claims in 'Draft' or 'Cancelled' status can be deleted. Current status is '{$existing['status']}'.");
        }

        // Delete associated documents
        $docs = $this->docModel->where('company_id', $companyId)->where('claim_id', $claimId)->findAll();
        foreach ($docs as $d) {
            if (!empty($d['file_path']) && file_exists($d['file_path'])) {
                @unlink($d['file_path']);
            }
        }
        $this->docModel->where('company_id', $companyId)->where('claim_id', $claimId)->delete();

        $this->claimModel->delete($claimId);
        return true;
    }

    /**
     * Upload and Attach Document to Claim
     */
    public function uploadClaimDocument(string $companyId, string $claimId, $file, array $data, ?string $actorId = null): array
    {
        $claim = $this->claimModel->where('company_id', $companyId)->find($claimId);
        if (!$claim) {
            throw new \InvalidArgumentException('Claim not found or does not belong to active company.');
        }

        if (!$file || !$file->isValid()) {
            throw new \InvalidArgumentException('A valid uploaded file is required.');
        }

        // Limit 15MB
        if ($file->getSizeByUnit('mb') > 15) {
            throw new \InvalidArgumentException('File exceeds maximum allowable size of 15MB.');
        }

        $allowedExts = ['pdf', 'jpg', 'jpeg', 'png', 'webp', 'doc', 'docx'];
        $ext = strtolower($file->getClientExtension());
        if (!in_array($ext, $allowedExts, true)) {
            throw new \InvalidArgumentException("Invalid file extension '.{$ext}'. Allowed: " . implode(', ', $allowedExts));
        }

        $uploadBase = rtrim(WRITEPATH, '/\\') . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'insurance' . DIRECTORY_SEPARATOR . $companyId . DIRECTORY_SEPARATOR;
        if (!is_dir($uploadBase)) {
            @mkdir($uploadBase, 0755, true);
        }

        $safeName = 'doc_' . bin2hex(random_bytes(6)) . '_' . preg_replace('/[^a-zA-Z0-9_\-]/', '_', pathinfo($file->getClientName(), PATHINFO_FILENAME)) . '.' . $ext;
        $file->move($uploadBase, $safeName);

        $docId = 'midoc-' . bin2hex(random_bytes(16));
        $fullPath = $uploadBase . $safeName;

        $docRecord = [
            'id'            => $docId,
            'company_id'    => $companyId,
            'claim_id'      => $claimId,
            'employee_id'   => $claim['employee_id'],
            'document_type' => !empty($data['document_type']) ? trim((string)$data['document_type']) : 'Receipt',
            'title'         => !empty($data['title']) ? trim((string)$data['title']) : $file->getClientName(),
            'file_name'     => $file->getClientName(),
            'file_path'     => $fullPath,
            'file_type'     => $file->getClientMimeType() ?: 'application/octet-stream',
            'file_size'     => (int)$file->getSize(),
            'uploaded_by'   => $actorId,
            'created_at'    => date('Y-m-d H:i:s'),
            'updated_at'    => date('Y-m-d H:i:s'),
        ];

        $this->docModel->insert($docRecord);
        return $docRecord;
    }

    /**
     * Get Single Document with Tenant Verification
     */
    public function getDocument(string $companyId, string $documentId): ?array
    {
        return $this->docModel->where('company_id', $companyId)->find($documentId);
    }

    /**
     * Delete Document
     */
    public function deleteDocument(string $companyId, string $documentId, ?string $actorId = null): bool
    {
        $doc = $this->docModel->where('company_id', $companyId)->find($documentId);
        if (!$doc) {
            throw new \InvalidArgumentException('Document not found or does not belong to active company.');
        }

        if (!empty($doc['file_path']) && file_exists($doc['file_path'])) {
            @unlink($doc['file_path']);
        }

        $this->docModel->delete($documentId);
        return true;
    }
}
