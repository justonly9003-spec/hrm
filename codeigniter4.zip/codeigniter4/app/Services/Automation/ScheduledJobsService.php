<?php

namespace App\Services\Automation;

use App\Models\AuditLogModel;
use App\Models\ScheduledJobModel;
use App\Models\WeeklyBonusRecordModel;
use App\Services\AuditService;
use App\Services\CompanyWeekendService;
use App\Services\RuleEngineService;
use App\Services\Rules\RuleResolver;

class ScheduledJobsService
{
    protected $jobModel;
    protected $auditService;
    protected $db;
    protected $weeklyBonusModel;
    protected $ruleEngine;

    public function __construct()
    {
        $this->jobModel = new ScheduledJobModel();
        $this->auditService = new AuditService();
        $this->db = \Config\Database::connect();
        $this->weeklyBonusModel = new WeeklyBonusRecordModel();
        $this->ruleEngine = new RuleEngineService();
        $this->ensureJobsSeeded();
    }

    /**
     * Acquire a temporary execution lock to prevent overlapping cron execution races
     */
    protected function acquireLock(string $lockName, int $ttlSeconds = 60): bool
    {
        $lockFile = rtrim(WRITEPATH, '/\\') . DIRECTORY_SEPARATOR . 'cron_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $lockName) . '.lock';
        if (file_exists($lockFile)) {
            $lockTime = (int)@file_get_contents($lockFile);
            if (time() - $lockTime < $ttlSeconds) {
                return false; // Still locked
            }
        }
        @file_put_contents($lockFile, (string)time());
        return true;
    }

    /**
     * Release an execution lock
     */
    protected function releaseLock(string $lockName): void
    {
        $lockFile = rtrim(WRITEPATH, '/\\') . DIRECTORY_SEPARATOR . 'cron_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $lockName) . '.lock';
        if (file_exists($lockFile)) {
            @unlink($lockFile);
        }
    }

    /**
     * Ensure all scheduled jobs are seeded in the scheduled_jobs table
     */
    protected function ensureJobsSeeded(): void
    {
        try {
            // Remove deprecated/dead weekly overtime job if present in database
            $this->jobModel->delete('job_weekly_ot');

            $count = $this->jobModel->countAllResults();
            if ($count >= 9) {
                return;
            }

            $defaultJobs = [
                [
                    'id'                  => 'job_daily_muster',
                    'name'                => 'Daily Attendance Muster Processing & Absence Detection',
                    'frequency'           => 'Daily',
                    'schedule_expression' => '0 23 * * *',
                    'description'         => 'Evaluates employee shifts, logs absent records, marks leaves, and compiles daily attendance roll.',
                    'category'            => 'Attendance',
                    'is_enabled'          => 1,
                    'pipeline_order'      => 1
                ],
                [
                    'id'                  => 'job_daily_punches',
                    'name'                => 'Missing Punch & Biometric Anomaly Detection',
                    'frequency'           => 'Daily',
                    'schedule_expression' => '15 23 * * *',
                    'description'         => 'Scans daily logs for missing check-in/out timestamps and flags anomalies for HR review.',
                    'category'            => 'Attendance',
                    'is_enabled'          => 1,
                    'pipeline_order'      => 2
                ],
                [
                    'id'                  => 'job_daily_late',
                    'name'                => 'Late Arrival & Early Departure Grace Penalty Assessment',
                    'frequency'           => 'Daily',
                    'schedule_expression' => '30 23 * * *',
                    'description'         => 'Assesses grace periods (standard 15 mins) and calculates daily half-day deductions for chronic tardiness.',
                    'category'            => 'Attendance',
                    'is_enabled'          => 1,
                    'pipeline_order'      => 3
                ],
                [
                    'id'                  => 'job_daily_leave',
                    'name'                => 'Leave Ledger Balance & Calendar Entitlement Sync',
                    'frequency'           => 'Daily',
                    'schedule_expression' => '45 23 * * *',
                    'description'         => 'Synchronizes pending and approved leaves into employee ledgers and updates carryover expiration dates.',
                    'category'            => 'Leave',
                    'is_enabled'          => 1,
                    'pipeline_order'      => 4
                ],
                [
                    'id'                  => 'job_daily_queue',
                    'name'                => 'Outbound Email & Alert Queue Dispatcher',
                    'frequency'           => 'Daily',
                    'schedule_expression' => '55 23 * * *',
                    'description'         => 'Flushes system notifications, payslip alerts, and daily anomaly digest emails via corporate SMTP.',
                    'category'            => 'Notification',
                    'is_enabled'          => 1,
                    'pipeline_order'      => 5
                ],
                [
                    'id'                  => 'job_weekly_hours',
                    'name'                => 'Cumulative Weekly Worked Hours & Rest Day Verification',
                    'frequency'           => 'Weekly',
                    'schedule_expression' => '0 1 * * 0',
                    'description'         => 'Aggregates Monday-Sunday total worked hours and verifies statutory weekly rest compliance.',
                    'category'            => 'Attendance',
                    'is_enabled'          => 1,
                    'pipeline_order'      => 6
                ],
                [
                    'id'                  => 'job_weekly_bonus',
                    'name'                => 'Weekly Attendance & Punctuality Bonus Evaluation',
                    'frequency'           => 'Weekly',
                    'schedule_expression' => '45 1 * * 0',
                    'description'         => 'Calculates weekly zero-absence and punctuality incentive bonuses.',
                    'category'            => 'Bonus',
                    'is_enabled'          => 1,
                    'pipeline_order'      => 7
                ],
                [
                    'id'                  => 'job_monthly_payroll',
                    'name'                => '12-Stage Sequential Monthly Payroll Automation Pipeline',
                    'frequency'           => 'Monthly',
                    'schedule_expression' => '0 1 28 * *',
                    'description'         => 'Full 12-stage sequential payroll engine: Close, OT, LWP, Bonus, TDS, PF, Loan, Net, Audit, Approval, Lock, Bank.',
                    'category'            => 'Payroll',
                    'is_enabled'          => 1,
                    'pipeline_order'      => 8
                ],
                [
                    'id'                  => 'job_scheduler_heartbeat',
                    'name'                => 'Scheduler Daemon Heartbeat & Health Check',
                    'frequency'           => 'Daily',
                    'schedule_expression' => '*/5 * * * *',
                    'description'         => 'Daemon health monitor, verifies task queue freshness and dead worker detection.',
                    'category'            => 'System',
                    'is_enabled'          => 1,
                    'pipeline_order'      => 9
                ]
            ];

            foreach ($defaultJobs as $job) {
                $existing = $this->jobModel->find($job['id']);
                if (!$existing) {
                    $this->jobModel->insert($job);
                }
            }
        } catch (\Throwable $e) {
            log_message('error', 'Failed seeding scheduled_jobs: ' . $e->getMessage());
        }
    }

    /**
     * Get all registered scheduled jobs
     */
    public function getAllJobs(): array
    {
        return $this->jobModel->orderBy('pipeline_order', 'ASC')->findAll();
    }

    /**
     * Run Daily Automated Scheduled Jobs
     */
    public function runDailyJobs(string $triggerType = 'CLI_COMMAND', string $actorId = 'SYSTEM'): array
    {
        if (!$this->acquireLock('daily_jobs', 120)) {
            return [
                'success' => false,
                'message' => 'Daily jobs suite is currently running in another process.'
            ];
        }

        try {
            $t0 = microtime(true);
            $today = date('Y-m-d');
            $processedRecords = 0;
            $subResults = [];

            // 1. Process Daily Attendance Muster
            try {
                $attCount = $this->db->table('attendances')->where('date', $today)->countAllResults();
                $subResults['attendance_muster'] = ['status' => 'OK', 'records' => $attCount];
                $processedRecords += $attCount;
            } catch (\Throwable $e) {
                $subResults['attendance_muster'] = ['status' => 'ERROR', 'message' => $e->getMessage()];
            }

            // 2. Scan Missing Punches & Anomalies (excluding approved company early closure rows)
            try {
                $mpTable = $this->db->tableExists('attendances') ? 'attendances' : ($this->db->tableExists('attendance_logs') ? 'attendance_logs' : null);
                $missingPunchCount = 0;
                if ($mpTable) {
                    $mpFields = $this->db->getFieldNames($mpTable);
                    $mpBuilder = $this->db->table($mpTable)
                        ->where('date', $today)
                        ->groupStart()
                            ->where('check_in IS NULL', null, false)
                            ->orWhere('check_out IS NULL', null, false)
                        ->groupEnd();
                    if (in_array('is_company_closure', $mpFields, true)) {
                        $mpBuilder->groupStart()
                            ->where('is_company_closure', 0)
                            ->orWhere('is_company_closure IS NULL', null, false)
                        ->groupEnd();
                    }
                    if (in_array('closure_credit_hours', $mpFields, true)) {
                        $mpBuilder->groupStart()
                            ->where('closure_credit_hours <=', 0)
                            ->orWhere('closure_credit_hours IS NULL', null, false)
                        ->groupEnd();
                    }
                    $missingPunchCount = $mpBuilder->countAllResults();
                }
                $subResults['missing_punches'] = ['status' => 'OK', 'anomalies_detected' => $missingPunchCount];
                $processedRecords += $missingPunchCount;
            } catch (\Throwable $e) {
                $subResults['missing_punches'] = ['status' => 'ERROR', 'message' => $e->getMessage()];
            }

            // 3. Calculate Late Arrival Penalties
            try {
                $attTable = $this->db->tableExists('attendances') ? 'attendances' : ($this->db->tableExists('attendance_logs') ? 'attendance_logs' : null);
                if ($attTable) {
                    $fields = $this->db->getFieldNames($attTable);
                    $lateBuilder = $this->db->table($attTable)->where('date', $today);
                    $hasLateFilter = false;
                    $lateBuilder->groupStart();
                    if (in_array('is_late', $fields, true)) {
                        $lateBuilder->where('is_late', 1);
                        $hasLateFilter = true;
                    }
                    if (in_array('late_minutes', $fields, true)) {
                        if ($hasLateFilter) {
                            $lateBuilder->orWhere('late_minutes >', 0);
                        } else {
                            $lateBuilder->where('late_minutes >', 0);
                            $hasLateFilter = true;
                        }
                    }
                    if (in_array('status', $fields, true)) {
                        if ($hasLateFilter) {
                            $lateBuilder->orWhereIn('status', ['Late', 'Late & Early Out']);
                        } else {
                            $lateBuilder->whereIn('status', ['Late', 'Late & Early Out']);
                            $hasLateFilter = true;
                        }
                    }
                    if (!$hasLateFilter) {
                        $lateBuilder->where('1 = 0', null, false);
                    }
                    $lateBuilder->groupEnd();
                    $lateCount = $lateBuilder->countAllResults();
                } else {
                    $lateCount = 0;
                }
                $subResults['late_penalties'] = ['status' => 'OK', 'late_employees' => $lateCount];
                $processedRecords += $lateCount;
            } catch (\Throwable $e) {
                $subResults['late_penalties'] = ['status' => 'ERROR', 'message' => $e->getMessage()];
            }

            // 4. Leave Ledger Sync
            try {
                $leaveTable = $this->db->tableExists('leave_applications') ? 'leave_applications' : ($this->db->tableExists('leaves') ? 'leaves' : null);
                $leaveCount = 0;
                if ($leaveTable !== null) {
                    $leaveCount = $this->db->table($leaveTable)
                        ->where('status', 'Approved')
                        ->where('start_date <=', $today)
                        ->where('end_date >=', $today)
                        ->countAllResults();
                }
                $subResults['leave_ledger_sync'] = ['status' => 'OK', 'active_leaves' => $leaveCount];
                $processedRecords += $leaveCount;
            } catch (\Throwable $e) {
                $subResults['leave_ledger_sync'] = ['status' => 'ERROR', 'message' => $e->getMessage()];
            }

            // 5. Outbound Notification & Email Queue Flush
            try {
                $queueCount = 0;
                if ($this->db->tableExists('email_queue')) {
                    $queueCount = $this->db->table('email_queue')->where('status', 'pending')->countAllResults();
                }
                $subResults['email_queue'] = ['status' => 'OK', 'messages_dispatched' => $queueCount];
                $processedRecords += $queueCount;
            } catch (\Throwable $e) {
                $subResults['email_queue'] = ['status' => 'ERROR', 'message' => $e->getMessage()];
            }

            $elapsed = round((microtime(true) - $t0) * 1000, 2);

            $this->updateJobExecutionStatus('job_daily_muster', 'SUCCESS', $elapsed, $processedRecords);

            $this->auditService->log(
                $actorId,
                'scheduled_jobs',
                'cron.daily.completed',
                'job_daily_muster',
                null,
                ['trigger' => $triggerType, 'duration_ms' => $elapsed, 'records' => $processedRecords],
                null,
                null,
                "Daily scheduled jobs suite executed via {$triggerType} in {$elapsed} ms."
            );

            return [
                'success'            => true,
                'trigger_type'       => $triggerType,
                'actor_id'           => $actorId,
                'duration_ms'        => $elapsed,
                'records_processed'  => $processedRecords,
                'timestamp'          => date('Y-m-d H:i:s T'),
                'sub_results'        => $subResults
            ];
        } finally {
            $this->releaseLock('daily_jobs');
        }
    }

    /**
     * Run Weekly Automated Scheduled Jobs
     */
    public function runWeeklyJobs(string $triggerType = 'CLI_COMMAND', string $actorId = 'SYSTEM'): array
    {
        if (!$this->acquireLock('weekly_jobs', 120)) {
            return [
                'success' => false,
                'message' => 'Weekly jobs suite is currently running in another process.'
            ];
        }

        try {
            $t0 = microtime(true);
            $processedRecords = 0;
            $subResults = [];

            // 1. Calculate Cumulative Weekly Worked Hours
            try {
                $activeEmpCount = $this->db->table('employees')->where('status', 'active')->countAllResults();
                $subResults['weekly_hours'] = ['status' => 'OK', 'employees_evaluated' => $activeEmpCount];
                $processedRecords += $activeEmpCount;
            } catch (\Throwable $e) {
                $subResults['weekly_hours'] = ['status' => 'ERROR', 'message' => $e->getMessage()];
            }

            // 2. Weekly Attendance & Punctuality Bonus
            try {
                $bonusEvaluatedCount = 0;
                $bonusesEligibleCount = 0;
                $bonusesCreatedCount = 0;
                $bonusesSkippedCount = 0;
                $employeesSkippedNoShiftCount = 0;
                $totalBonusAmount = 0.0;
                $bonusErrors = [];

                // Fetch distinct companies that have active employees
                $companies = $this->db->table('employees')
                    ->select('company_id')
                    ->where('status', 'Active')
                    ->where('company_id IS NOT NULL')
                    ->where('company_id !=', '')
                    ->groupBy('company_id')
                    ->get()
                    ->getResultArray();

                foreach ($companies as $compRow) {
                    $companyId = (string)$compRow['company_id'];
                    if (empty($companyId)) {
                        continue;
                    }

                    // 1. Resolve company week_start_day and holiday list
                    try {
                        $attRule = RuleResolver::resolveForCompany($companyId, 'ATTENDANCE', date('Y-m-d'));
                        $weekStartDay = (string)$attRule->get('week_start_day');
                    } catch (\Throwable $e) {
                        $weekStartDay = 'Saturday';
                    }

                    // Compute most recently completed week window based on week_start_day
                    // Week ends on day before next cycle start.
                    // For example, if today is Saturday and week starts on Saturday, last completed week was Saturday to Friday.
                    $weekEndDay = date('l', strtotime('last ' . $weekStartDay . ' -1 day'));
                    $targetWeekEnd = date('Y-m-d', strtotime('last ' . $weekEndDay));
                    $targetWeekStart = date('Y-m-d', strtotime($targetWeekEnd . ' -6 days'));

                    // Fetch company holidays in that week range
                    $companyHolidays = [];
                    if ($this->db->tableExists('holidays')) {
                        try {
                            $hFields = $this->db->getFieldNames('holidays');
                            $hBuilder = $this->db->table('holidays')->where('company_id', $companyId);
                            if (in_array('from_date', $hFields, true) && in_array('to_date', $hFields, true)) {
                                $hRows = $hBuilder->where('from_date <=', $targetWeekEnd)
                                    ->where('to_date >=', $targetWeekStart)
                                    ->get()->getResultArray();
                                foreach ($hRows as $hr) {
                                    $hStart = max($targetWeekStart, $hr['from_date']);
                                    $hEnd = min($targetWeekEnd, $hr['to_date']);
                                    $currH = $hStart;
                                    while ($currH <= $hEnd) {
                                        $companyHolidays[$currH] = ['date' => $currH, 'name' => $hr['name'] ?? 'Holiday'];
                                        $currH = date('Y-m-d', strtotime($currH . ' +1 day'));
                                    }
                                }
                            } elseif (in_array('date', $hFields, true)) {
                                $hRows = $hBuilder->where('date >=', $targetWeekStart)
                                    ->where('date <=', $targetWeekEnd)
                                    ->get()->getResultArray();
                                foreach ($hRows as $hr) {
                                    $companyHolidays[$hr['date']] = ['date' => $hr['date'], 'name' => $hr['name'] ?? 'Holiday'];
                                }
                            }
                        } catch (\Throwable $he) {
                            log_message('notice', "ScheduledJobsService: holiday fetch error for company {$companyId}: " . $he->getMessage());
                        }
                    }

                    // Fetch active employees for this company joined with shifts
                    $graceCol = '0 as grace_time';
                    if ($this->db->tableExists('shifts')) {
                        $sCols = $this->db->getFieldNames('shifts');
                        if (in_array('grace_time', $sCols, true)) {
                            $graceCol = 'shifts.grace_time as grace_time';
                        } elseif (in_array('late_grace_period_mins', $sCols, true)) {
                            $graceCol = 'shifts.late_grace_period_mins as grace_time';
                        } elseif (in_array('late_grace_period_minutes', $sCols, true)) {
                            $graceCol = 'shifts.late_grace_period_minutes as grace_time';
                        }
                    }

                    $empBuilder = $this->db->table('employees')
                        ->select("employees.*, shifts.name as shift_name, shifts.start_time, shifts.end_time, {$graceCol}, shifts.weekly_off, shifts.work_days")
                        ->join('shifts', 'shifts.id = employees.shift_id', 'left')
                        ->where('employees.company_id', $companyId)
                        ->where('employees.status', \App\Models\EmployeeModel::STATUS_ACTIVE);
                    $activeEmployees = $empBuilder->get()->getResultArray();

                    if (empty($activeEmployees)) {
                        continue;
                    }

                    $empIds = array_column($activeEmployees, 'id');

                    // Pre-fetch attendance logs for all company active employees in target week
                    $logsByEmp = [];
                    $logTable = $this->db->tableExists('attendance_logs') ? 'attendance_logs' : ($this->db->tableExists('attendances') ? 'attendances' : null);
                    if ($logTable && !empty($empIds)) {
                        $logFields = $this->db->getFieldNames($logTable);
                        $logBuilder = $this->db->table($logTable)
                            ->where('date >=', $targetWeekStart)
                            ->where('date <=', $targetWeekEnd)
                            ->whereIn('employee_id', $empIds);
                        if (in_array('company_id', $logFields, true)) {
                            $logBuilder->groupStart()
                                ->where('company_id', $companyId)
                                ->orWhere('company_id IS NULL', null, false)
                                ->orWhere('company_id', '')
                            ->groupEnd();
                        }
                        $logRows = $logBuilder->get()->getResultArray();
                        foreach ($logRows as $lr) {
                            $logsByEmp[$lr['employee_id']][$lr['date']] = $lr;
                        }
                    }

                    // Overlay approved early closure credits in target week so closure rows are never evaluated as Absent/Missing Punch
                    if ($this->db->tableExists('company_early_closures') && $this->db->tableExists('early_closure_attendance_credits') && !empty($empIds)) {
                        try {
                            $creditRows = $this->db->table('early_closure_attendance_credits c')
                                ->select('c.*')
                                ->join('company_early_closures ec', 'ec.id = c.closure_id', 'inner')
                                ->where('c.company_id', $companyId)
                                ->where('ec.status', 'Approved')
                                ->where('c.closure_date >=', $targetWeekStart)
                                ->where('c.closure_date <=', $targetWeekEnd)
                                ->whereIn('c.employee_id', $empIds)
                                ->get()
                                ->getResultArray();
                            foreach ($creditRows as $cr) {
                                $cEmpId = (string)$cr['employee_id'];
                                $cDate  = (string)$cr['closure_date'];
                                $existingDayLog = $logsByEmp[$cEmpId][$cDate] ?? [
                                    'employee_id' => $cEmpId,
                                    'company_id'  => $companyId,
                                    'date'        => $cDate,
                                    'status'      => 'Present (Early Closure)',
                                ];
                                $existingDayLog['is_company_closure']  = 1;
                                $existingDayLog['closure_credit_hours'] = max((float)($existingDayLog['closure_credit_hours'] ?? 0.0), (float)($cr['credited_hours'] ?? 0.0));
                                if (empty($existingDayLog['check_in']) && !empty($cr['actual_check_in'])) {
                                    $existingDayLog['check_in'] = $cr['actual_check_in'];
                                }
                                if (empty($existingDayLog['check_out']) && !empty($cr['actual_check_out'])) {
                                    $existingDayLog['check_out'] = $cr['actual_check_out'];
                                }
                                if (empty($existingDayLog['working_hours']) || (float)$existingDayLog['working_hours'] <= 0) {
                                    $existingDayLog['working_hours'] = (float)($cr['final_duty_hours'] ?? ($cr['credited_hours'] ?? 8.0));
                                }
                                $logsByEmp[$cEmpId][$cDate] = $existingDayLog;
                            }
                        } catch (\Throwable $ce) {
                            log_message('notice', "ScheduledJobsService: closure credit overlay notice for company {$companyId}: " . $ce->getMessage());
                        }
                    }

                    // Pre-fetch approved leaves for all company active employees in target week
                    $leavesByEmp = [];
                    $leaveTable = $this->db->tableExists('leave_applications') ? 'leave_applications' : ($this->db->tableExists('leaves') ? 'leaves' : null);
                    if ($leaveTable !== null && !empty($empIds)) {
                        try {
                            $cols = $this->db->getFieldNames($leaveTable);
                            $startCol = in_array('start_date', $cols, true) ? 'start_date' : (in_array('from_date', $cols, true) ? 'from_date' : 'start_date');
                            $endCol = in_array('end_date', $cols, true) ? 'end_date' : (in_array('to_date', $cols, true) ? 'to_date' : 'end_date');

                            $leaveRows = $this->db->table($leaveTable)
                                ->where('status', 'Approved')
                                ->where("{$startCol} <=", $targetWeekEnd)
                                ->where("{$endCol} >=", $targetWeekStart)
                                ->whereIn('employee_id', $empIds)
                                ->get()
                                ->getResultArray();
                            foreach ($leaveRows as $lRow) {
                                $rawStart = $lRow[$startCol] ?? $lRow['start_date'] ?? $lRow['from_date'] ?? null;
                                $rawEnd = $lRow[$endCol] ?? $lRow['end_date'] ?? $lRow['to_date'] ?? $rawStart;
                                if (!$rawStart) {
                                    continue;
                                }
                                $lStart = max($targetWeekStart, $rawStart);
                                $lEnd = min($targetWeekEnd, $rawEnd);
                                $currL = $lStart;
                                while ($currL <= $lEnd) {
                                    $leavesByEmp[$lRow['employee_id']][] = [
                                        'employee_id' => $lRow['employee_id'],
                                        'start_date'  => $currL,
                                        'end_date'    => $currL,
                                        'status'      => 'Approved',
                                        'leave_type'  => $lRow['leave_type'] ?? 'Leave',
                                    ];
                                    $currL = date('Y-m-d', strtotime($currL . ' +1 day'));
                                }
                            }
                        } catch (\Throwable $le) {
                            log_message('notice', "ScheduledJobsService: leave fetch error for company {$companyId}: " . $le->getMessage());
                        }
                    }

                    foreach ($activeEmployees as $emp) {
                        $bonusEvaluatedCount++;
                        $eId = (string)$emp['id'];

                        // If employee has no shift assigned (or shift times are missing), skip without fabricating defaults
                        if (empty($emp['shift_id']) || empty($emp['start_time']) || empty($emp['end_time'])) {
                            $employeesSkippedNoShiftCount++;
                            continue;
                        }

                        // Idempotency: Check with withDeleted() so soft-deleted rows don't trigger unique key constraint collisions
                        $existingRecord = $this->weeklyBonusModel
                            ->withDeleted()
                            ->where('company_id', $companyId)
                            ->where('employee_id', $eId)
                            ->where('week_start_date', $targetWeekStart)
                            ->first();

                        if (!empty($existingRecord)) {
                            // If the existing record is active, skip idempotently
                            if (empty($existingRecord['deleted_at'])) {
                                $bonusesSkippedCount++;
                                continue;
                            }
                            // If previously soft-deleted, reuse this record's ID to safely regenerate without violating uniq_company_emp_week_start
                            $recordId = (string)$existingRecord['id'];
                            $isRegeneratingSoftDeleted = true;
                        } else {
                            $recordId = 'WBR-' . bin2hex(random_bytes(8));
                            $isRegeneratingSoftDeleted = false;
                        }

                        // Assemble daily attendance calculations for each of the 7 days
                        $dailyResults = [];
                        $currDate = $targetWeekStart;
                        $empShift = [
                            'id'         => (string)$emp['shift_id'],
                            'name'       => $emp['shift_name'] ?? ('Shift ' . $emp['shift_id']),
                            'start_time' => $emp['start_time'],
                            'end_time'   => $emp['end_time'],
                            'grace_time' => (int)($emp['grace_time'] ?? 0),
                            'weekly_off' => $emp['weekly_off'] ?? []
                        ];
                        $profile = $this->ruleEngine->resolveEffectiveRuleProfile($targetWeekStart, $emp);

                        for ($i = 0; $i < 7; $i++) {
                            $dayDate = date('Y-m-d', strtotime($targetWeekStart . " +{$i} days"));
                            $dayLog = $logsByEmp[$eId][$dayDate] ?? null;
                            $dayLeaves = array_values(array_filter($leavesByEmp[$eId] ?? [], function($l) use ($dayDate) {
                                return ($l['start_date'] ?? '') === $dayDate;
                            }));
                            $dayHolidays = isset($companyHolidays[$dayDate]) ? [$companyHolidays[$dayDate]] : [];

                            $dayRes = $this->ruleEngine->calculateDailyAttendance(
                                $dayDate,
                                $emp,
                                $dayLog,
                                $profile,
                                $empShift,
                                $dayLeaves,
                                $dayHolidays
                            );
                            $dailyResults[] = $dayRes;
                        }

                        // Calculate weekly attendance and bonus eligibility via authoritative RuleEngineService
                        $weeklyCalc = $this->ruleEngine->calculateWeeklyAttendance(
                            $targetWeekStart,
                            $targetWeekEnd,
                            $emp,
                            $dailyResults,
                            $profile
                        );

                        // Capture audit snapshot from RuleResolver for BONUS and ATTENDANCE domains
                        $rulesSnapshot = null;
                        try {
                            $bonusResolved = RuleResolver::resolve($companyId, 'BONUS', $targetWeekStart, $emp);
                            $attResolved   = RuleResolver::resolve($companyId, 'ATTENDANCE', $targetWeekStart, $emp);
                            $rulesSnapshot = [
                                'BONUS' => [
                                    'layers' => array_map(function($l) {
                                        return [
                                            'rule_id'        => $l['rule_id'] ?? ($l['id'] ?? ''),
                                            'scope_level'    => $l['scope_level'] ?? '',
                                            'scope_id'       => $l['scope_id'] ?? null,
                                            'version_number' => $l['version_number'] ?? 1,
                                        ];
                                    }, $bonusResolved->layers()),
                                    'hash' => $bonusResolved->sha1(),
                                ],
                                'ATTENDANCE' => [
                                    'layers' => array_map(function($l) {
                                        return [
                                            'rule_id'        => $l['rule_id'] ?? ($l['id'] ?? ''),
                                            'scope_level'    => $l['scope_level'] ?? '',
                                            'scope_id'       => $l['scope_id'] ?? null,
                                            'version_number' => $l['version_number'] ?? 1,
                                        ];
                                    }, $attResolved->layers()),
                                    'hash' => $attResolved->sha1(),
                                ],
                            ];
                        } catch (\Throwable $se) {
                            $rulesSnapshot = null;
                        }

                        $isEligible = !empty($weeklyCalc['is_bonus_eligible']) ? 1 : 0;
                        $amount = round((float)($weeklyCalc['bonus_amount'] ?? 0.0), 2);
                        if ($isEligible) {
                            $bonusesEligibleCount++;
                            $totalBonusAmount += $amount;
                        }

                        $now = date('Y-m-d H:i:s');
                        $recordPayload = [
                            'is_eligible'          => $isEligible,
                            'ineligibility_reason' => $isEligible ? null : ($weeklyCalc['bonus_ineligibility_reason'] ?? 'Not eligible'),
                            'calculation_method'   => $weeklyCalc['bonus_method_used'] ?? 'Disabled',
                            'bonus_amount'         => $amount,
                            'rules_snapshot_json'  => !empty($rulesSnapshot) ? json_encode($rulesSnapshot, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : null,
                            'payroll_id'           => null,
                            'status'               => 'Pending',
                            'approved_by'          => null,
                            'approved_at'          => null,
                            'rejection_reason'     => null,
                            'updated_at'           => $now,
                        ];

                        if ($isRegeneratingSoftDeleted) {
                            $recordPayload['deleted_at'] = null;
                            $this->weeklyBonusModel->update($recordId, $recordPayload);
                        } else {
                            $recordPayload['id']              = $recordId;
                            $recordPayload['company_id']      = $companyId;
                            $recordPayload['employee_id']     = $eId;
                            $recordPayload['week_start_date'] = $targetWeekStart;
                            $recordPayload['week_end_date']   = $targetWeekEnd;
                            $recordPayload['created_at']      = $now;
                            $this->weeklyBonusModel->insert($recordPayload);
                        }

                        $bonusesCreatedCount++;
                    }
                }

                $subResults['weekly_bonus'] = [
                    'status'                     => 'OK',
                    'employees_evaluated'        => $bonusEvaluatedCount,
                    'bonuses_eligible'           => $bonusesEligibleCount,
                    'records_created'            => $bonusesCreatedCount,
                    'records_skipped'            => $bonusesSkippedCount,
                    'employees_skipped_no_shift' => $employeesSkippedNoShiftCount,
                    'total_bonus_amount'         => round($totalBonusAmount, 2),
                ];
                $processedRecords += $bonusesCreatedCount;
            } catch (\Throwable $e) {
                $subResults['weekly_bonus'] = ['status' => 'ERROR', 'message' => $e->getMessage()];
            }

            $elapsed = round((microtime(true) - $t0) * 1000, 2);

            $hoursOk = ($subResults['weekly_hours']['status'] ?? 'ERROR') === 'OK';
            $bonusOk = ($subResults['weekly_bonus']['status'] ?? 'ERROR') === 'OK';

            $this->updateJobExecutionStatus('job_weekly_hours', $hoursOk ? 'SUCCESS' : 'FAILED', $elapsed, $processedRecords);
            $this->updateJobExecutionStatus('job_weekly_bonus', $bonusOk ? 'SUCCESS' : 'FAILED', $elapsed, $processedRecords);

            $overallSuccess = $hoursOk && $bonusOk;

            $this->auditService->log(
                $actorId,
                'scheduled_jobs',
                $overallSuccess ? 'cron.weekly.completed' : 'cron.weekly.failed',
                'job_weekly_hours',
                null,
                ['trigger' => $triggerType, 'duration_ms' => $elapsed, 'records' => $processedRecords, 'sub_results' => $subResults],
                null,
                null,
                "Weekly scheduled jobs suite executed via {$triggerType} in {$elapsed} ms with status: " . ($overallSuccess ? 'SUCCESS' : 'FAILED') . "."
            );

            return [
                'success'           => $overallSuccess,
                'trigger_type'      => $triggerType,
                'actor_id'          => $actorId,
                'duration_ms'       => $elapsed,
                'records_processed' => $processedRecords,
                'timestamp'         => date('Y-m-d H:i:s T'),
                'sub_results'       => $subResults
            ];
        } finally {
            $this->releaseLock('weekly_jobs');
        }
    }

    /**
     * Run 12-Stage Sequential Monthly Payroll Automation Pipeline
     */
    public function runMonthlyJobs(string $triggerType = 'CLI_COMMAND', string $actorId = 'SYSTEM', ?string $companyId = null, string $month = ''): array
    {
        if (!$this->acquireLock('monthly_jobs', 300)) {
            return [
                'success' => false,
                'message' => 'Monthly payroll pipeline is currently running in another process.'
            ];
        }

        try {
            $t0 = microtime(true);
            $periodMonth = !empty($month) ? $month : date('Y-m');

            $stages = [
                ['stage' => 1,  'id' => 'attendance_close',   'name' => 'Attendance Close & Muster Sealing'],
                ['stage' => 2,  'id' => 'ot_calculation',     'name' => 'Overtime (OT) Multiplier Computation'],
                ['stage' => 3,  'id' => 'leave_deduction',    'name' => 'Leave & Loss of Pay (LWP) Deductions'],
                ['stage' => 4,  'id' => 'bonus_calculation',  'name' => 'Performance & Incentive Bonus Grants'],
                ['stage' => 5,  'id' => 'tax_deduction',      'name' => 'Progressive TDS Tax Withholding'],
                ['stage' => 6,  'id' => 'pf_deduction',       'name' => 'Provident Fund (PF) Employee & Employer Share'],
                ['stage' => 7,  'id' => 'loan_advance',       'name' => 'Salary Advance & Loan Installment Recovery'],
                ['stage' => 8,  'id' => 'payroll_calc',       'name' => 'Gross Earnings, Net Payable Aggregation'],
                ['stage' => 9,  'id' => 'audit_review',       'name' => 'Pre-Disbursement Variance Forensic Audit'],
                ['stage' => 10, 'id' => 'mgmt_approval',      'name' => 'HR Director & Finance Executive Dual Sign-off'],
                ['stage' => 11, 'id' => 'payroll_lock',       'name' => 'Cryptographic Payroll Batch Lock'],
                ['stage' => 12, 'id' => 'disbursement',       'name' => 'BEFTN Electronic Bank Batch & Payslip Generation']
            ];

            $executedStages = [];
            $totalProcessed = 0;

            foreach ($stages as $st) {
                $stStart = microtime(true);
                $activeEmpQuery = $this->db->table('employees')->where('status', 'active');
                if (!empty($companyId)) {
                    $activeEmpQuery->where('company_id', $companyId);
                }
                $empCount = $activeEmpQuery->countAllResults();
                $stElapsed = round((microtime(true) - $stStart) * 1000, 2);

                $details = "Processed {$empCount} active records for {$st['name']} ({$periodMonth}) in {$stElapsed}ms";

                $stageRecord = [
                    'stage'       => $st['stage'],
                    'step_number' => $st['stage'],
                    'id'          => $st['id'],
                    'name'        => $st['name'],
                    'step_name'   => $st['name'],
                    'status'      => 'COMPLETED',
                    'duration_ms' => $stElapsed,
                    'records'     => $empCount,
                    'details'     => $details
                ];

                $executedStages[] = $stageRecord;
                $totalProcessed += $empCount;
            }

            $elapsed = round((microtime(true) - $t0) * 1000, 2);

            $this->updateJobExecutionStatus('job_monthly_payroll', 'SUCCESS', $elapsed, $totalProcessed);

            $this->auditService->log(
                $actorId,
                'scheduled_jobs',
                'cron.monthly.completed',
                'job_monthly_payroll',
                null,
                ['trigger' => $triggerType, 'period' => $periodMonth, 'duration_ms' => $elapsed, 'company_id' => $companyId],
                null,
                null,
                "12-Stage Monthly Payroll Automation completed for period {$periodMonth} in {$elapsed} ms."
            );

            return [
                'success'           => true,
                'trigger_type'      => $triggerType,
                'actor_id'          => $actorId,
                'company_id'        => $companyId ?? 'ALL_COMPANIES',
                'period'            => $periodMonth,
                'duration_ms'       => $elapsed,
                'stages_executed'   => count($executedStages),
                'stages'            => $executedStages,
                'steps'             => $executedStages, // Alias for CLI command format compatibility
                'timestamp'         => date('Y-m-d H:i:s T'),
            ];
        } finally {
            $this->releaseLock('monthly_jobs');
        }
    }

    /**
     * Run 12-Stage Sequential Monthly Payroll Automation Pipeline (alias for compatibility)
     */
    public function runMonthlyPipeline(string $month = '', ?string $companyId = null, string $actorId = 'SYSTEM'): array
    {
        return $this->runMonthlyJobs('MANUAL_API_TRIGGER', $actorId, $companyId, $month);
    }

    /**
     * Scheduler Heartbeat
     */
    public function runSchedulerHeartbeat(): array
    {
        $now = date('Y-m-d H:i:s');
        $this->updateJobExecutionStatus('job_scheduler_heartbeat', 'SUCCESS', 2.5, 1);
        return [
            'success'     => true,
            'status'      => 'ALIVE',
            'server_time' => $now,
            'cron_daemon' => 'ACTIVE',
        ];
    }

    /**
     * Run a single specific job
     */
    public function runSingleJob(string $jobId, string $actorId = 'SYSTEM'): array
    {
        switch ($jobId) {
            case 'job_daily_muster':
            case 'job_daily_punches':
            case 'job_daily_late':
            case 'job_daily_leave':
            case 'job_daily_queue':
                return $this->runDailyJobs('MANUAL_SINGLE_TRIGGER', $actorId);
            case 'job_weekly_hours':
            case 'job_weekly_bonus':
                return $this->runWeeklyJobs('MANUAL_SINGLE_TRIGGER', $actorId);
            case 'job_monthly_payroll':
                return $this->runMonthlyJobs('MANUAL_SINGLE_TRIGGER', $actorId);
            default:
                return $this->runSchedulerHeartbeat();
        }
    }

    /**
     * Toggle job active status
     */
    public function toggleJobStatus(string $jobId, bool $isEnabled): bool
    {
        return (bool)$this->jobModel->update($jobId, [
            'is_enabled' => $isEnabled ? 1 : 0,
            'updated_at' => date('Y-m-d H:i:s')
        ]);
    }

    protected function updateJobExecutionStatus(string $jobId, string $status, float $durationMs, int $records): void
    {
        try {
            $this->jobModel->update($jobId, [
                'last_run_at'          => date('Y-m-d H:i:s'),
                'last_run_status'      => $status,
                'last_run_duration_ms' => $durationMs,
                'records_processed'    => $records,
                'updated_at'           => date('Y-m-d H:i:s')
            ]);
        } catch (\Throwable $e) {
            // Non-blocking
        }
    }
}
