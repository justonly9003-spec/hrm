<?php

namespace App\Services;

use App\Models\EmployeeModel;
use App\Models\EmployeeSalaryModel;
use App\Models\SalaryStructureModel;
use App\Models\SalaryStructureItemModel;
use App\Models\SalaryComponentModel;
use App\Models\SalaryRevisionModel;
use App\Models\SystemSettingModel;
use App\Services\Tax\TaxCalculator;
use App\Services\Pf\PfCalculator;
use App\Services\SalaryPolicyResolver;
use App\Services\Rules\RuleNotConfiguredException;
use App\Libraries\PayrollCalculator;
use Config\Database;

class EmployeeSalaryService
{
    protected $db;
    protected SystemSettingModel $settingModel;
    protected EmployeeModel $empModel;
    protected EmployeeSalaryModel $salaryModel;
    protected SalaryStructureModel $structureModel;
    protected SalaryStructureItemModel $structureItemModel;
    protected SalaryComponentModel $componentModel;
    protected SalaryRevisionModel $revisionModel;
    protected TaxCalculator $taxCalculator;
    protected SalaryPolicyResolver $policyResolver;
    protected AuditService $auditService;

    public function __construct()
    {
        $this->db = Database::connect();
        $this->settingModel = new SystemSettingModel();
        $this->empModel = new EmployeeModel();
        $this->salaryModel = new EmployeeSalaryModel();
        $this->structureModel = new SalaryStructureModel();
        $this->structureItemModel = new SalaryStructureItemModel();
        $this->componentModel = new SalaryComponentModel();
        $this->revisionModel = new SalaryRevisionModel();
        $this->taxCalculator = new TaxCalculator();
        $this->policyResolver = new SalaryPolicyResolver();
        $this->auditService = new AuditService();
    }

    /**
     * Check if actor is authorized to assign or update salaries
     */
    public function isAuthorizedRole(array $actor, ?string $targetEmployeeId = null): bool
    {
        if (empty($actor)) {
            $session = \Config\Services::session();
            if ($session && $session->has('user_id')) {
                $actor = [
                    'id'          => $session->get('user_id'),
                    'role_code'   => $session->get('role_code'),
                    'role_name'   => $session->get('role'),
                    'role'        => $session->get('role'),
                    'employee_id' => $session->get('employee_id'),
                ];
            }
        }

        $permService = new \App\Services\PermissionService();
        $canonicalRole = $permService->canonicalizeRole($actor['role_code'] ?? $actor['role_name'] ?? $actor['role'] ?? '');

        // Employee self-assignment strictly forbidden
        if ($canonicalRole === 'employee' || $canonicalRole === 'role_emp') {
            return false;
        }

        $isPrivilegedAdmin = $permService->isSoftwareAppAdmin($canonicalRole)
            || $canonicalRole === 'company_admin'
            || $canonicalRole === 'hr_admin'
            || $permService->isHRAdmin($canonicalRole);

        // If target employee is the actor themselves, reject standard employees and non-privileged roles
        $actorEmployeeId = $actor['employee_id'] ?? null;
        if ($targetEmployeeId !== null && $actorEmployeeId !== null && (string)$actorEmployeeId === (string)$targetEmployeeId) {
            if (!$isPrivilegedAdmin) {
                return false;
            }
        }

        if ($permService->isSoftwareAppAdmin($canonicalRole) || $canonicalRole === 'company_admin') {
            return true;
        }

        // Check if permissions array is pre-supplied in $actor (e.g., in test or explicit context)
        if (!empty($actor['permissions']) && is_array($actor['permissions'])) {
            $hasView = in_array('employee.view_salary', $actor['permissions'], true)
                || in_array('employees.view_salary', $actor['permissions'], true)
                || in_array('directory.view_salary', $actor['permissions'], true);
            $hasPayroll = in_array('payroll.create', $actor['permissions'], true)
                || in_array('payroll.edit', $actor['permissions'], true)
                || in_array('payroll.manage', $actor['permissions'], true);
            return $hasView && $hasPayroll;
        }

        // Evaluate via PermissionService for this actor user ID
        $userId = (string)($actor['id'] ?? '');
        if ($userId === '') {
            return false;
        }

        $hasViewSalary = $permService->hasPermission('employee.view_salary', $userId)
            || $permService->hasPermission('employees.view_salary', $userId)
            || $permService->hasPermission('directory.view_salary', $userId);

        $hasPayrollPerm = $permService->hasPermission('payroll.create', $userId)
            || $permService->hasPermission('payroll.edit', $userId)
            || $permService->hasPermission('payroll.manage', $userId);

        return $hasViewSalary && $hasPayrollPerm;
    }

    /**
     * Get salary setup view data for an employee
     */
    public function getSalarySetup(string $employeeId, ?string $companyId = null): array
    {
        $employee = $this->empModel->find($employeeId);
        if (!$employee) {
            throw new \RuntimeException("Employee not found: {$employeeId}");
        }

        $empCompanyId = $employee['company_id'] ?? $companyId;
        $empBranchId  = $employee['branch_id'] ?? null;

        // Current active salary assignment
        $activeSalary = $this->getActiveSalary($employeeId);

        // Salary history with decoded snapshots
        $rawSalaryHistory = $this->salaryModel
            ->where('employee_id', $employeeId)
            ->orderBy('effective_from', 'DESC')
            ->orderBy('created_at', 'DESC')
            ->findAll();

        $salaryHistory = [];
        foreach ($rawSalaryHistory as $sh) {
            $parsedComponents = [];
            if (!empty($sh['custom_components_json'])) {
                $decoded = json_decode($sh['custom_components_json'], true);
                if (is_array($decoded)) {
                    $parsedComponents = $decoded;
                }
            }
            $salaryHistory[] = [
                'id'                           => $sh['id'],
                'employee_id'                  => $sh['employee_id'],
                'structure_id'                 => $sh['structure_id'],
                'basic_salary'                 => (float)($sh['basic_salary'] ?? 0),
                'gross_salary'                 => (float)($sh['gross_salary'] ?? 0),
                'total_deductions'             => (float)($sh['total_deductions'] ?? $parsedComponents['total_deductions'] ?? 0),
                'net_salary'                   => (float)($sh['net_salary'] ?? $parsedComponents['net_salary'] ?? 0),
                'ctc'                          => (float)($sh['ctc'] ?? $parsedComponents['ctc'] ?? 0),
                'effective_from'               => $sh['effective_from'],
                'effective_to'                 => $sh['effective_to'],
                'status'                       => $sh['status'],
                'created_at'                   => $sh['created_at'],
                'snapshot'                     => $parsedComponents,
            ];
        }

        $revisions = $this->revisionModel
            ->where('employee_id', $employeeId)
            ->orderBy('effective_date', 'DESC')
            ->orderBy('created_at', 'DESC')
            ->findAll();

        // Available structures for this employee's company & branch
        $structuresBuilder = $this->structureModel->where('status', 'Active');
        if (!empty($empCompanyId)) {
            $structuresBuilder->where('company_id', $empCompanyId);
        }
        if (!empty($empBranchId)) {
            $structuresBuilder->groupStart()
                ->where('branch_id', $empBranchId)
                ->orWhere('branch_id IS NULL')
                ->groupEnd();
        } else {
            $structuresBuilder->where('branch_id IS NULL');
        }
        $rawStructures = $structuresBuilder->findAll();

        // Attach structure items with component definitions
        $structures = [];
        foreach ($rawStructures as $st) {
            $items = $this->structureItemModel
                ->where('structure_id', $st['id'])
                ->orderBy('sort_order', 'ASC')
                ->findAll();

            $enrichedItems = [];
            foreach ($items as $item) {
                $compDef = $this->componentModel->find($item['component_id']);
                $compIsActive = $compDef ? ((($compDef['status'] ?? 'Active') === 'Active') && (isset($compDef['is_active']) ? (int)(bool)$compDef['is_active'] === 1 : true)) : false;
                if (!$compIsActive) {
                    continue;
                }
                $pfBasisEligible = $compDef['include_in_pf_basis'] ?? ($compDef['is_pf_applicable'] ?? ($compDef['pf_basis_eligible'] ?? 1));
                $enrichedItems[] = array_merge($item, [
                    'component_name'      => $compDef['name'] ?? '',
                    'component_code'      => $compDef['code'] ?? '',
                    'type'                => $compDef['type'] ?? 'earning',
                    'is_taxable'          => $compDef['is_taxable'] ?? 1,
                    'include_in_pf_basis' => $pfBasisEligible,
                    'is_pf_applicable'    => $pfBasisEligible,
                    'status'              => 'Active',
                    'is_active'           => 1,
                    'master_is_active'    => true,
                ]);
            }
            $st['items'] = $enrichedItems;
            $structures[] = $st;
        }

        // Available components for this employee's company & branch
        $componentsBuilder = $this->componentModel->where('status', 'Active');
        if (!empty($empCompanyId)) {
            $componentsBuilder->where('company_id', $empCompanyId);
        }
        if (!empty($empBranchId)) {
            $componentsBuilder->groupStart()
                ->where('branch_id', $empBranchId)
                ->orWhere('branch_id IS NULL')
                ->orWhere('branch_id', '')
                ->groupEnd();
        } else {
            $componentsBuilder->groupStart()
                ->where('branch_id IS NULL')
                ->orWhere('branch_id', '')
                ->groupEnd();
        }
        $rawComponents = $componentsBuilder->orderBy('display_order', 'ASC')->findAll();
        $components = [];
        foreach ($rawComponents as $rc) {
            $normalized = \App\Controllers\Payroll\SalaryComponentMasterController::normalizeComponentRecord($rc);
            if ($normalized['status'] === 'Active' && (int)$normalized['is_active'] === 1) {
                $components[] = $normalized;
            }
        }

        // Determine configured salary status
        $isConfigured = false;
        if ($activeSalary !== null && ((float)$activeSalary['gross_salary'] > 0 || (float)$activeSalary['basic_salary'] > 0)) {
            $isConfigured = true;
        } elseif (!empty($employee['salary_status']) && $employee['salary_status'] === 'CONFIGURED' && ((float)($employee['gross_salary'] ?? 0) > 0 || (float)($employee['basic_salary'] ?? 0) > 0)) {
            $isConfigured = true;
        }

        // Dynamic statutory preview
        $basic = $activeSalary['basic_salary'] ?? (float)($employee['basic_salary'] ?? 0);
        $gross = $activeSalary['gross_salary'] ?? (float)($employee['gross_salary'] ?? $basic);

        $empContext = [
            'employee_id'        => $employeeId,
            'company_id'         => $empCompanyId,
            'branch_id'          => $empBranchId,
            'grade_id'           => $employee['salary_grade_id'] ?? null,
            'employment_type_id' => $employee['employment_type_id'] ?? null,
            'effective_date'     => date('Y-m-d'),
        ];

        $pfPreview = ['employee_deduction' => 0.00, 'employer_contribution' => 0.00, 'rule_name' => 'N/A'];
        $taxPreview = ['monthly_tax_deduction' => 0.00];

        if ($gross > 0 && $isConfigured) {
            try {
                $pfCalc = new PfCalculator();
                $empPfEarnings = [
                    'Basic'        => $basic,
                    'Basic_Salary' => $basic,
                    'Gross'        => $gross,
                    'Gross_Salary' => $gross,
                ];
                if (!empty($activeSalary['snapshot']['earnings']) && is_array($activeSalary['snapshot']['earnings'])) {
                    foreach ($activeSalary['snapshot']['earnings'] as $ea) {
                        $cCode = trim((string)($ea['component_code'] ?? $ea['code'] ?? ''));
                        if ($cCode !== '') $empPfEarnings[$cCode] = (float)($ea['amount'] ?? 0.0);
                        $cName = trim((string)($ea['name'] ?? $ea['component_name'] ?? ''));
                        if ($cName !== '') $empPfEarnings[$cName] = (float)($ea['amount'] ?? 0.0);
                    }
                }
                if (!empty($activeSalary['snapshot']['house_rent'])) {
                    $empPfEarnings['House_Rent'] = (float)$activeSalary['snapshot']['house_rent'];
                    $empPfEarnings['HRA'] = (float)$activeSalary['snapshot']['house_rent'];
                    $empPfEarnings['House Rent'] = (float)$activeSalary['snapshot']['house_rent'];
                }
                if (!empty($activeSalary['snapshot']['medical'])) {
                    $empPfEarnings['Medical'] = (float)$activeSalary['snapshot']['medical'];
                    $empPfEarnings['Medical_Allowance'] = (float)$activeSalary['snapshot']['medical'];
                }
                if (!empty($activeSalary['snapshot']['conveyance'])) {
                    $empPfEarnings['Conveyance'] = (float)$activeSalary['snapshot']['conveyance'];
                    $empPfEarnings['Transport'] = (float)$activeSalary['snapshot']['conveyance'];
                }

                $statutoryPf = $pfCalc->calculate([
                    'company_id'     => $empCompanyId,
                    'employee'       => array_merge($employee, [
                        'pf_settings' => $activeSalary['pf_settings'] ?? null,
                    ]),
                    'effective_date' => date('Y-m-d'),
                    'earnings'       => $empPfEarnings,
                ]);

                $pfPreview = [
                    'employee_deduction'    => (float)($statutoryPf['employee_deduction'] ?? 0.00),
                    'employer_contribution' => (float)($statutoryPf['employer_contribution'] ?? 0.00),
                    'total_pf'              => (float)($statutoryPf['total_pf'] ?? round(((float)($statutoryPf['employee_deduction'] ?? 0.00)) + ((float)($statutoryPf['employer_contribution'] ?? 0.00)), 2)),
                    'rule_name'             => $statutoryPf['rule_name'] ?? 'Provident Fund',
                    'is_eligible'           => $statutoryPf['is_eligible'] ?? false,
                    'reason'                => $statutoryPf['reason'] ?? '',
                    'snapshot'              => $statutoryPf['snapshot'] ?? null,
                ];
            } catch (\InvalidArgumentException $e) {
                log_message('error', 'PF formula calculation preview error: ' . $e->getMessage());
                $pfPreview['reason'] = $e->getMessage();
            } catch (\Throwable $e) {
                log_message('warning', 'PF calculation preview error: ' . $e->getMessage());
            }

            try {
                $taxContext = array_merge($empContext, [
                    'annual_tax_amount' => $activeSalary['tax_settings']['annual_tax_amount'] ?? null,
                    'calculation_mode'  => $activeSalary['tax_settings']['calculation_mode'] ?? null,
                    'custom_tax_amount' => $activeSalary['tax_settings']['custom_tax_amount'] ?? null,
                ]);
                $taxPreview = $this->taxCalculator->calculateTax($gross, $taxContext);
            } catch (\Throwable $e) {
                log_message('warning', 'Tax calculation preview error: ' . $e->getMessage());
            }
        }

        return [
            'employee'        => $employee,
            'is_configured'   => $isConfigured,
            'salary_status'   => $isConfigured ? 'CONFIGURED' : 'NOT_CONFIGURED',
            'active_salary'   => $activeSalary,
            'salary_history'  => $salaryHistory,
            'revisions'       => $revisions,
            'structures'      => $structures,
            'components'      => $components,
            'pf_preview'      => $pfPreview,
            'tax_preview'     => $taxPreview,
        ];
    }

    /**
     * Normalise employee tax settings coming from the form or from legacy callers.
     * Returns the full normalised tax_settings array.
     */
    private function normalizeTaxSettings(array $data, string $taxRuleMode, string $effectiveFrom, ?array $previousSettings = null): array
    {
        $raw = is_array($data['tax_settings'] ?? null) ? $data['tax_settings'] : [];

        // 1) Decide the mode
        $flag = strtolower(trim((string)($raw['auto_calculation'] ?? '')));
        if ($flag === '') { // legacy callers: derive from calculation_mode / mode
            $legacy = ucfirst(strtolower(trim((string)($raw['calculation_mode'] ?? $raw['mode'] ?? $taxRuleMode))));
            $flag = ($legacy === 'Fixed') ? 'inactive' : (($legacy === 'Exempt') ? 'exempt' : 'active');
        }
        if (!in_array($flag, ['active', 'inactive', 'exempt'], true)) {
            throw new \InvalidArgumentException('Invalid Auto Tax Calculation value. Use Active or Deactive.');
        }
        $mode = ($flag === 'active') ? 'Auto' : (($flag === 'exempt') ? 'Exempt' : 'Fixed');

        // 2) Annual amount (fall back to legacy monthly x 12)
        $annualRaw = $raw['annual_tax_amount'] ?? null;
        if ($annualRaw === null || $annualRaw === '') {
            $monthlyLegacy = $raw['custom_tax_amount'] ?? $raw['fixed_amount'] ?? $data['tax_fixed_amount'] ?? $data['tax_custom_amount'] ?? 0;
            $annualRaw = is_numeric($monthlyLegacy) ? ((float)$monthlyLegacy * 12) : 0;
        }
        if (!is_numeric($annualRaw) || (float)$annualRaw < 0 || (float)$annualRaw > 100000000) {
            throw new \InvalidArgumentException('Annual Tax Amount must be a number between 0 and 100,000,000.');
        }
        $annual = round((float)$annualRaw, 2);

        // 3) Reason is mandatory whenever Auto calculation is not Active
        $reason = trim((string)($raw['override_reason'] ?? $data['tax_override_reason'] ?? ''));
        if ($mode !== 'Auto' && mb_strlen($reason) < 3) {
            throw new \InvalidArgumentException('A reason is mandatory when Auto Tax Calculation is Deactive.');
        }

        // 4) Fiscal year the amount belongs to. Keep the old year when the amount did not change.
        $taxYear = \App\Services\Tax\TaxCalculator::getFiscalYear($effectiveFrom);
        if ($previousSettings && isset($previousSettings['annual_tax_amount'], $previousSettings['annual_tax_year'])
            && abs((float)$previousSettings['annual_tax_amount'] - $annual) < 0.005) {
            $taxYear = (string)$previousSettings['annual_tax_year'];
        }

        return array_merge($raw, [
            'category'          => $raw['category'] ?? $raw['tax_category'] ?? null,
            'tin'               => $raw['tin'] ?? $raw['tax_identification_number'] ?? null,
            'calculation_mode'  => $mode,
            'auto_calculation'  => $flag,
            'annual_tax_amount' => $annual,
            'annual_tax_year'   => $taxYear,
            'custom_tax_amount' => round($annual / 12, 2),   // derived monthly value, keeps legacy consumers working
            'is_override'       => ($mode !== 'Auto'),
            'override_reason'   => $reason,
        ]);
    }

    /**
     * Process an evaluated earning item: update gross salary, variables pool, legacy fields, and build earning record.
     */
    private function processEvaluatedEarningItem(
        array $item,
        string $code,
        string $name,
        string $calcType,
        string $calcBase,
        float $rateOrAmount,
        float $amount,
        ?string $formula,
        bool $isEnabled,
        bool $includedInGross,
        float &$grossSalary,
        array &$variablesPool,
        float &$legacyHouseRent,
        float &$legacyMedical,
        float &$legacyConveyance,
        float &$legacyOtherAllowances
    ): array {
        if ($isEnabled && $includedInGross) {
            $grossSalary += $amount;
            $variablesPool['Gross'] = $grossSalary;
            $variablesPool['GrossSalary'] = $grossSalary;
        }

        // Track legacy fields for backward compatibility
        if (in_array($code, ['HRA', 'HOUSE_RENT']) || stripos($name, 'house rent') !== false) {
            $legacyHouseRent = $amount;
        } elseif (in_array($code, ['MED', 'MEDICAL']) || stripos($name, 'medical') !== false) {
            $legacyMedical = $amount;
        } elseif (in_array($code, ['CONV', 'TRANSPORT', 'TRAVEL']) || stripos($name, 'conveyance') !== false || stripos($name, 'transport') !== false) {
            $legacyConveyance = $amount;
        } elseif ($code !== 'BASIC' && stripos($name, 'basic') === false) {
            $legacyOtherAllowances += $amount;
        }

        return [
            'component_id'         => $item['component_id'] ?? $item['id'] ?? ('comp-' . strtolower($code)),
            'code'                 => $code,
            'name'                 => $name,
            'type'                 => 'earning',
            'calculation_type'     => $calcType,
            'calculation_base'     => $calcBase,
            'rate_or_amount'       => $rateOrAmount,
            'amount'               => $amount,
            'custom_formula'       => $formula,
            'is_enabled'           => (bool)$isEnabled,
            'is_overridden'        => (bool)($item['is_overridden'] ?? $item['isOverridden'] ?? false),
            'is_included_in_gross' => (bool)$includedInGross,
            'is_taxable'           => (bool)($item['is_taxable'] ?? $item['isTaxable'] ?? true),
        ];
    }

    /**
     * Assign, customize, or update employee salary structure
     * Supports:
     * 1. Assign existing template
     * 2. Create individual / custom salary structure directly for employee
     * 3. Copy from existing structure and customize
     *
     * NO MANDATORY COMPONENTS ENFORCED.
     */
    public function assignSalary(string $employeeId, array $data, ?string $companyId = null, ?array $actor = null): array
    {
        // 1. Resolve Actor if not explicitly supplied
        if (empty($actor)) {
            $session = \Config\Services::session();
            if ($session && $session->has('user_id')) {
                $actor = [
                    'id'          => $session->get('user_id'),
                    'role_code'   => $session->get('role_code'),
                    'role_name'   => $session->get('role'),
                    'role'        => $session->get('role'),
                    'name'        => $session->get('user_name') ?: $session->get('username'),
                    'employee_id' => $session->get('employee_id'),
                ];
            }
        }

        // Fail-closed: Explicit authorized actor context is required (no 'system' / 'superadmin' fallback)
        if (empty($actor) || empty($actor['id'])) {
            return [
                'success' => false,
                'status'  => 403,
                'code'    => 403,
                'message' => '403 Forbidden: Authorized actor context is required to assign employee salary.'
            ];
        }

        $actorUserId = (string)$actor['id'];

        // 1. RBAC Check
        if (!$this->isAuthorizedRole($actor, $employeeId)) {
            return [
                'success' => false,
                'status'  => 403,
                'message' => '403 Forbidden: You do not have permission to assign or modify employee salaries. Self-service salary assignment is strictly prohibited.'
            ];
        }

        // 2. Fetch and Validate Employee Scoping
        $employee = $this->empModel->find($employeeId);
        if (!$employee) {
            return [
                'success' => false,
                'status'  => 404,
                'message' => "Employee not found: {$employeeId}"
            ];
        }

        if (empty($companyId)) {
            $companyId = $employee['company_id'] ?? (session()->get('company_id') ?? '');
        }

        $actorRole = strtolower(trim((string)($actor['role_code'] ?? $actor['role_name'] ?? $actor['role'] ?? '')));
        if ($actorRole !== 'software_app_admin' && !empty($employee['company_id']) && $companyId !== '' && $employee['company_id'] !== $companyId) {
            return [
                'success' => false,
                'status'  => 403,
                'message' => '403 Forbidden: Tenant isolation violation. Cannot modify salary for an employee belonging to another company.'
            ];
        }

        $effectiveFrom = trim((string)($data['effective_from'] ?? ''));
        if (empty($effectiveFrom) || !strtotime($effectiveFrom)) {
            $effectiveFrom = date('Y-m-d');
        }

        $structureId = !empty($data['structure_id']) ? trim((string)$data['structure_id']) : null;
        $isCustom = !empty($data['is_custom']) || $structureId === 'CUSTOM' || empty($structureId);
        $structureName = trim((string)($data['structure_name'] ?? ''));

        // 3. Resolve Input Components
        // Components can be passed directly as $data['components'], $data['items'], or $data['overrides']
        $inputComponents = $data['components'] ?? $data['items'] ?? $data['overrides'] ?? null;
        if (is_string($inputComponents)) {
            $decoded = json_decode($inputComponents, true);
            if (is_array($decoded)) {
                $inputComponents = $decoded;
            }
        }

        // If no explicit components provided but structure_id given, load template items
        if (empty($inputComponents) && !empty($structureId) && $structureId !== 'CUSTOM') {
            $template = $this->structureModel->find($structureId);
            if ($template) {
                $structureName = $structureName ?: ($template['name'] ?? '');
                $templateItems = $this->structureItemModel
                    ->where('structure_id', $structureId)
                    ->orderBy('sort_order', 'ASC')
                    ->findAll();

                $inputComponents = [];
                foreach ($templateItems as $ti) {
                    $compDef = $this->componentModel->find($ti['component_id']);
                    if ($compDef) {
                        $compIsActive = ((($compDef['status'] ?? 'Active') === 'Active') && (isset($compDef['is_active']) ? (int)(bool)$compDef['is_active'] === 1 : true));
                        if (!$compIsActive) {
                            continue;
                        }
                        $tiCalcType = $ti['calculation_type'] ?? $compDef['calculation_type'] ?? 'fixed';
                        $tiRawVal = (float)($ti['default_value'] ?? $ti['percentage'] ?? $compDef['amount'] ?? 0);
                        $tiRateOrAmt = in_array($tiCalcType, ['percentage', 'percent_basic', 'percent_gross'], true) ? normalize_percentage($tiRawVal) : $tiRawVal;
                        $inputComponents[] = [
                            'component_id'     => $ti['component_id'],
                            'code'             => $compDef['code'],
                            'name'             => $compDef['name'],
                            'type'             => $compDef['type'],
                            'calculation_type' => $tiCalcType,
                            'calculation_base' => $ti['calculation_base'] ?? $compDef['calculation_base'] ?? 'Basic Salary',
                            'rate_or_amount'   => $tiRateOrAmt,
                            'custom_formula'   => $ti['custom_formula'] ?? $compDef['formula'] ?? null,
                            'is_enabled'       => (bool)($ti['is_enabled'] ?? 1),
                            'is_included_in_gross' => (bool)($ti['is_included_in_gross'] ?? $compDef['is_included_in_gross'] ?? 1),
                            'is_included_in_ctc'   => (bool)($ti['is_included_in_ctc'] ?? $compDef['is_included_in_ctc'] ?? 1),
                            'is_taxable'       => (bool)($ti['is_taxable'] ?? $compDef['is_taxable'] ?? 1),
                            'is_statutory'     => (bool)($ti['is_statutory'] ?? $compDef['is_statutory'] ?? 0),
                        ];
                    }
                }
            }
        }

        // If still empty, check legacy fields (basic_salary, house_rent, medical, etc.)
        if (empty($inputComponents)) {
            $basicSalaryRaw = $data['basic_salary'] ?? null;
            if ($basicSalaryRaw !== null && is_numeric($basicSalaryRaw)) {
                $bVal = round((float)$basicSalaryRaw, 2);
                $inputComponents = [];

                if ($bVal >= 0) {
                    $inputComponents[] = [
                        'component_id'     => 'comp-basic',
                        'code'             => 'BASIC',
                        'name'             => 'Basic Salary',
                        'type'             => 'earning',
                        'calculation_type' => 'fixed',
                        'calculation_base' => 'Basic Salary',
                        'rate_or_amount'   => $bVal,
                        'is_enabled'       => true,
                        'is_included_in_gross' => true,
                        'is_included_in_ctc'   => true,
                    ];
                }

                $hrVal = (float)($data['house_rent_value'] ?? $data['house_rent_allowance'] ?? 0);
                $hrType = ($data['house_rent_type'] ?? 'fixed') === 'percentage' ? 'percentage' : 'fixed';
                if ($hrVal > 0) {
                    $inputComponents[] = [
                        'component_id'     => 'comp-hra',
                        'code'             => 'HRA',
                        'name'             => 'House Rent Allowance',
                        'type'             => 'earning',
                        'calculation_type' => $hrType,
                        'calculation_base' => 'Basic Salary',
                        'rate_or_amount'   => $hrVal,
                        'is_enabled'       => true,
                        'is_included_in_gross' => true,
                        'is_included_in_ctc'   => true,
                    ];
                }

                $medVal = (float)($data['medical_value'] ?? $data['medical_allowance'] ?? 0);
                $medType = ($data['medical_type'] ?? 'fixed') === 'percentage' ? 'percentage' : 'fixed';
                if ($medVal > 0) {
                    $inputComponents[] = [
                        'component_id'     => 'comp-med',
                        'code'             => 'MED',
                        'name'             => 'Medical Allowance',
                        'type'             => 'earning',
                        'calculation_type' => $medType,
                        'calculation_base' => 'Basic Salary',
                        'rate_or_amount'   => $medVal,
                        'is_enabled'       => true,
                        'is_included_in_gross' => true,
                        'is_included_in_ctc'   => true,
                    ];
                }

                $convVal = (float)($data['conveyance_allowance'] ?? $data['transport_allowance'] ?? 0);
                if ($convVal > 0) {
                    $inputComponents[] = [
                        'component_id'     => 'comp-conv',
                        'code'             => 'CONV',
                        'name'             => 'Conveyance Allowance',
                        'type'             => 'earning',
                        'calculation_type' => 'fixed',
                        'calculation_base' => 'Basic Salary',
                        'rate_or_amount'   => $convVal,
                        'is_enabled'       => true,
                        'is_included_in_gross' => true,
                        'is_included_in_ctc'   => true,
                    ];
                }

                $otherVal = (float)($data['other_allowances'] ?? 0);
                if ($otherVal > 0) {
                    $inputComponents[] = [
                        'component_id'     => 'comp-other',
                        'code'             => 'OTHER',
                        'name'             => 'Other Allowances',
                        'type'             => 'earning',
                        'calculation_type' => 'fixed',
                        'calculation_base' => 'Basic Salary',
                        'rate_or_amount'   => $otherVal,
                        'is_enabled'       => true,
                        'is_included_in_gross' => true,
                        'is_included_in_ctc'   => true,
                    ];
                }
            }
        }

        if (empty($inputComponents) || !is_array($inputComponents)) {
            return [
                'success' => false,
                'status'  => 400,
                'message' => 'No salary components provided. Please select or add at least one salary component.'
            ];
        }

        // Phase 0: Validate components against policy-driven boundaries.
        // Overtime cannot be added as a salary structure component. Overtime is policy-driven via RuleResolver (OVERTIME domain).
        foreach ($inputComponents as $item) {
            $calcType = strtolower((string)($item['calculation_type'] ?? $item['calculationType'] ?? ''));
            $code = strtoupper(trim((string)($item['code'] ?? $item['component_code'] ?? '')));
            $name = trim((string)($item['name'] ?? $item['component_name'] ?? ''));
            if ($calcType === 'overtime based' || in_array($code, ['OT', 'OVERTIME'], true) || stripos($name, 'overtime') !== false) {
                return [
                    'success' => false,
                    'status'  => 422,
                    'message' => 'Overtime cannot be added as a salary structure component. Overtime is strictly policy-driven (RuleResolver OVERTIME domain) and calculated exclusively via OvertimeCalculationService from approved attendance records.'
                ];
            }
        }

        // Filter out inactive components so they are never in working mode or saved into active salary
        $activeInputComponents = [];
        foreach ($inputComponents as $item) {
            $isInactive = (isset($item['status']) && strtolower(trim((string)$item['status'])) === 'inactive')
                || (isset($item['is_active']) && ($item['is_active'] === false || $item['is_active'] === 0 || $item['is_active'] === '0' || $item['is_active'] === 'false'))
                || (isset($item['master_is_active']) && $item['master_is_active'] === false);

            if (!$isInactive) {
                $targetCompId = $item['component_id'] ?? $item['id'] ?? null;
                $compDef = null;
                if (!empty($targetCompId)) {
                    $compDef = $this->componentModel->find($targetCompId);
                }
                if (!$compDef && !empty($item['code'] ?? $item['component_code'] ?? null)) {
                    $compDef = $this->componentModel->where('company_id', $companyId)->where('code', $item['code'] ?? $item['component_code'])->first();
                }
                if ($compDef && ((($compDef['status'] ?? 'Active') === 'Inactive') || (isset($compDef['is_active']) && empty($compDef['is_active'])))) {
                    $isInactive = true;
                }
            }

            if (!$isInactive) {
                $activeInputComponents[] = $item;
            }
        }
        $inputComponents = $activeInputComponents;

        // Ensure statutory components (PF, Tax TDS, ER PF Match) are present in input components if applicable
        $isPfEligible = isset($data['pf_settings']['eligible'])
            ? !empty($data['pf_settings']['eligible'])
            : (isset($data['pf_settings']['is_eligible'])
                ? !empty($data['pf_settings']['is_eligible'])
                : (isset($data['pf_eligible'])
                    ? !empty($data['pf_eligible'])
                    : (isset($data['is_pf_applicable'])
                        ? (bool)$data['is_pf_applicable']
                        : (!empty($employee['is_pf_applicable'])))));

        $hasPfDeduction = false;
        $hasErPfContribution = false;
        $hasTaxDeduction = false;

        foreach ($inputComponents as $ci) {
            $cType = strtolower(trim((string)($ci['type'] ?? '')));
            $cCode = strtoupper(trim((string)($ci['code'] ?? $ci['component_code'] ?? '')));
            $cName = strtolower(trim((string)($ci['name'] ?? $ci['component_name'] ?? '')));

            if ($cType === 'deduction') {
                if (in_array($cCode, ['PF', 'EMP_PF', 'PROVIDENT_FUND', 'EMPLOYEE_PF'], true) || strpos($cName, 'provident') !== false) {
                    $hasPfDeduction = true;
                }
                if (in_array($cCode, ['TDS', 'TAX', 'INCOME_TAX'], true) || (strpos($cName, 'tax') !== false && strpos($cName, 'professional') === false)) {
                    $hasTaxDeduction = true;
                }
            } elseif ($cType === 'employer_contribution' || $cType === 'contribution') {
                if (in_array($cCode, ['ER_PF', 'EMPLOYER_PF', 'COMP_PF'], true) || strpos($cName, 'provident') !== false) {
                    $hasErPfContribution = true;
                }
            }
        }

        if ($isPfEligible) {
            $pfRuleCompany = \App\Services\Rules\RuleResolver::resolve($companyId, 'PF', $effectiveFrom, $employee);
            $defaultPfEmpRate = (float)$pfRuleCompany->get('employee_rate');
            $defaultPfCompRate = (float)$pfRuleCompany->get('employer_rate');
            $pfContribType = (string)$pfRuleCompany->get('contribution_type');
            $pfCalcBasis = (string)$pfRuleCompany->get('calculation_basis');

            if (!$hasPfDeduction) {
                $pfEmpRateInput = !empty($data['pf_settings']['is_override']) && isset($data['pf_settings']['employee_rate'])
                    ? (float)$data['pf_settings']['employee_rate']
                    : $defaultPfEmpRate;
                $inputComponents[] = [
                    'component_id'     => 'comp-pf',
                    'code'             => 'EMP_PF',
                    'name'             => 'Provident Fund (Employee)',
                    'type'             => 'deduction',
                    'calculation_type' => !empty($data['pf_settings']['calculation_type']) ? (string)$data['pf_settings']['calculation_type'] : $pfContribType,
                    'calculation_base' => !empty($data['pf_settings']['calculation_base']) ? (string)$data['pf_settings']['calculation_base'] : $pfCalcBasis,
                    'rate_or_amount'   => $pfEmpRateInput,
                    'is_enabled'       => true,
                    'is_statutory'     => true,
                ];
            }

            if (!$hasErPfContribution) {
                $pfCoRateInput = !empty($data['pf_settings']['is_override']) && isset($data['pf_settings']['company_rate'])
                    ? (float)$data['pf_settings']['company_rate']
                    : $defaultPfCompRate;
                $inputComponents[] = [
                    'component_id'       => 'comp-er-pf',
                    'code'               => 'ER_PF',
                    'name'               => 'Employer Provident Fund Match',
                    'type'               => 'employer_contribution',
                    'calculation_type'   => !empty($data['pf_settings']['calculation_type']) ? (string)$data['pf_settings']['calculation_type'] : $pfContribType,
                    'calculation_base'   => !empty($data['pf_settings']['calculation_base']) ? (string)$data['pf_settings']['calculation_base'] : $pfCalcBasis,
                    'rate_or_amount'     => $pfCoRateInput,
                    'is_enabled'         => true,
                    'is_included_in_ctc' => true,
                ];
            }
        }

        $previousSalaryRecord = $this->salaryModel
            ->where('employee_id', $employeeId)
            ->where('status', 'Active')
            ->orderBy('effective_from', 'DESC')
            ->first();
        $previousTaxSettings = null;
        if ($previousSalaryRecord && !empty($previousSalaryRecord['custom_components_json'])) {
            $prevSnapshot = json_decode($previousSalaryRecord['custom_components_json'], true);
            if (is_array($prevSnapshot) && !empty($prevSnapshot['tax_settings']) && is_array($prevSnapshot['tax_settings'])) {
                $previousTaxSettings = $prevSnapshot['tax_settings'];
            }
        }

        $taxRuleCompany = \App\Services\Rules\RuleResolver::resolve($companyId, 'TAX', $effectiveFrom, $employee);
        $taxRuleMode = (string)$taxRuleCompany->get('calculation_mode');
        try {
            $data['tax_settings'] = $this->normalizeTaxSettings($data, $taxRuleMode, $effectiveFrom, $previousTaxSettings);
        } catch (\InvalidArgumentException $e) {
            return [
                'success' => false,
                'status'  => 422,
                'code'    => 422,
                'message' => $e->getMessage()
            ];
        }
        $taxMode = (string)($data['tax_settings']['calculation_mode'] ?? $taxRuleMode);
        if (!$hasTaxDeduction && $taxMode !== 'Exempt') {
            $inputComponents[] = [
                'component_id'     => 'comp-tax',
                'code'             => 'TDS',
                'name'             => 'Income Tax (TDS Withholding)',
                'type'             => 'deduction',
                'calculation_type' => ($taxMode === 'Fixed') ? 'fixed' : 'slab',
                'calculation_base' => 'Gross Salary',
                'rate_or_amount'   => (float)($data['tax_settings']['custom_tax_amount'] ?? 0),
                'is_enabled'       => true,
                'is_statutory'     => true,
            ];
        }

        // 4. Dynamic Evaluation Engine (Earnings -> Deductions -> Employer Contributions)
        $evaluatedEarnings = [];
        $evaluatedDeductions = [];
        $evaluatedEmployerContributions = [];
        $evaluatedAllComponents = [];

        // Phase 1: Identify Basic Salary (if any exists)
        $basicSalary = 0.00;
        $explicitBasic = null;
        if (isset($data['basic_salary']) && is_numeric($data['basic_salary']) && (float)$data['basic_salary'] >= 0) {
            $explicitBasic = round((float)$data['basic_salary'], 2);
        }

        foreach ($inputComponents as $item) {
            $rawEnabled = $item['is_enabled'] ?? $item['isEnabled'] ?? null;
            $isEnabled = ($rawEnabled === null) ? true : ($rawEnabled !== false && $rawEnabled !== 0 && $rawEnabled !== '0' && $rawEnabled !== 'false');
            if (!$isEnabled) continue;

            $type = strtolower((string)($item['type'] ?? 'earning'));
            $code = strtoupper(trim((string)($item['code'] ?? $item['component_code'] ?? '')));
            $name = trim((string)($item['name'] ?? $item['component_name'] ?? ''));

            if ($type === 'earning' && ($code === 'BASIC' || stripos($name, 'basic') !== false)) {
                $val = (float)($item['rate_or_amount'] ?? $item['rateOrAmount'] ?? $item['amount'] ?? 0);
                if ($val > 0) {
                    $basicSalary = round($val, 2);
                }
                break;
            }
        }

        // Explicit basic_salary from input always takes precedence if provided and numeric
        if ($explicitBasic !== null) {
            $basicSalary = $explicitBasic;
        }

        // If basicSalary is still 0, check employee existing basic_salary as a fallback
        if ($basicSalary <= 0 && $explicitBasic === null && !empty($employee['basic_salary']) && (float)$employee['basic_salary'] > 0) {
            $basicSalary = round((float)$employee['basic_salary'], 2);
        }

        // Synchronize or inject BASIC component into $inputComponents so earnings and gross reflect it
        $foundBasicComp = false;
        foreach ($inputComponents as &$cItem) {
            $cType = strtolower((string)($cItem['type'] ?? 'earning'));
            $cCode = strtoupper(trim((string)($cItem['code'] ?? $cItem['component_code'] ?? '')));
            $cName = trim((string)($cItem['name'] ?? $cItem['component_name'] ?? ''));
            if ($cType === 'earning' && ($cCode === 'BASIC' || stripos($cName, 'basic') !== false)) {
                $foundBasicComp = true;
                if ($basicSalary >= 0) {
                    $cItem['rate_or_amount'] = $basicSalary;
                    $cItem['amount'] = $basicSalary;
                }
                break;
            }
        }
        unset($cItem);

        if (!$foundBasicComp && $basicSalary > 0) {
            array_unshift($inputComponents, [
                'component_id'         => 'comp-basic',
                'code'                 => 'BASIC',
                'name'                 => 'Basic Salary',
                'type'                 => 'earning',
                'calculation_type'     => 'fixed',
                'calculation_base'     => 'Basic Salary',
                'rate_or_amount'       => $basicSalary,
                'amount'               => $basicSalary,
                'is_enabled'           => true,
                'is_included_in_gross' => true,
                'is_included_in_ctc'   => true,
            ]);
        }

        // Validate basic salary against the employee's assigned salary grade band (warning or error, configurable)
        $gradeId = !empty($data['salary_grade_id']) 
            ? $data['salary_grade_id'] 
            : (!empty($data['grade_id']) ? $data['grade_id'] : ($employee['salary_grade_id'] ?? null));
        $gradeWarning = null;

        if (!empty($gradeId)) {
            $grade = null;
            try {
                $grade = $this->db->table('salary_grades')->where('id', $gradeId)->get()->getRowArray();
            } catch (\Throwable $e) {
                $grade = null;
            }

            if ($grade) {
                $gradeMin = (float)($grade['min_salary'] ?? ($grade['minimum_salary'] ?? 0));
                $gradeMax = (float)($grade['max_salary'] ?? ($grade['maximum_salary'] ?? 0));
                $gradeName = $grade['grade_name'] ?? ($grade['name'] ?? $gradeId);

                $isOutOfBand = false;
                if ($gradeMin > 0 && $basicSalary < $gradeMin) {
                    $isOutOfBand = true;
                }
                if ($gradeMax > 0 && $basicSalary > $gradeMax) {
                    $isOutOfBand = true;
                }

                if ($isOutOfBand) {
                    // Configurable validation mode: check $data['grade_validation_mode'], then setting, default 'warning'
                    $validationMode = strtolower(trim((string)($data['grade_validation_mode'] ?? '')));
                    if ($validationMode === '') {
                        try {
                            $validationMode = strtolower((string)$this->settingModel->getSetting('salary_grade_validation_mode', $companyId, 'warning'));
                        } catch (\Throwable $e) {
                            $validationMode = 'warning';
                        }
                    }

                    $msg = sprintf(
                        'Basic salary (%s) is outside the configured band for grade "%s" (Min: %s, Max: %s).',
                        number_format($basicSalary, 2),
                        $gradeName,
                        number_format($gradeMin, 2),
                        number_format($gradeMax, 2)
                    );

                    if ($validationMode === 'error' || $validationMode === 'strict') {
                        return [
                            'success'          => false,
                            'status'           => 422,
                            'message'          => $msg,
                            'grade_validation' => [
                                'valid'      => false,
                                'grade_id'   => $gradeId,
                                'grade_name' => $gradeName,
                                'min_salary' => $gradeMin,
                                'max_salary' => $gradeMax,
                                'basic'      => $basicSalary,
                            ],
                        ];
                    }

                    $gradeWarning = $msg;
                }
            }
        }

        // Phase 2: Evaluate All Earnings
        $grossSalary = 0.00;
        $legacyHouseRent = 0.00;
        $legacyMedical = 0.00;
        $legacyConveyance = 0.00;
        $legacyOtherAllowances = 0.00;

        // Standard monthly hours and overtime multiplier resolved strictly from Rule Store (OVERTIME + PAYROLL_BASICS)
        $effDate = $data['effective_from'] ?? ($data['effective_date'] ?? date('Y-m-d'));
        $otRule = \App\Services\Rules\RuleResolver::resolve($companyId, 'OVERTIME', $effDate, $employee);
        $basicsRule = \App\Services\Rules\RuleResolver::resolveForCompany($companyId, 'PAYROLL_BASICS', $effDate);

        $otMultiplier = (float)$otRule->get('normal_multiplier');
        if ($otMultiplier <= 0) {
            throw new \App\Services\Rules\RuleNotConfiguredException("Missing or zero normal_multiplier in OVERTIME rule for company {$companyId}.");
        }

        $divMode = (string)$otRule->get('divisor_mode');
        $rateInfo = \App\Services\Rules\DailyRateResolver::resolve($companyId, $employee, $effDate, null, $basicSalary, $divMode);
        $divisorDays = (float)$rateInfo['divisor_days'];

        if ($divisorDays <= 0) {
            throw new \App\Services\Rules\RuleNotConfiguredException("Invalid or zero divisor days in overtime rule calculation.");
        }

        $divisorHours = (float)($otRule->params()['divisor_hours'] ?? $basicsRule->get('standard_daily_hours'));
        if ($divisorHours <= 0) {
            throw new \App\Services\Rules\RuleNotConfiguredException("Invalid or zero standard daily hours in overtime rule calculation.");
        }

        $stdMonthlyHours = round($divisorDays * $divisorHours, 2);

        $variablesPool = [
            'Basic'                  => $basicSalary,
            'BASIC'                  => $basicSalary,
            'basic'                  => $basicSalary,
            'BasicSalary'            => $basicSalary,
            'Gross'                  => $basicSalary,
            'GrossSalary'            => $basicSalary,
            'standard_monthly_hours' => $stdMonthlyHours,
            'StandardMonthlyHours'   => $stdMonthlyHours,
            'ot_multiplier'          => $otMultiplier,
            'OtMultiplier'           => $otMultiplier,
            'salary_basis'           => $basicSalary,
            'Days'                   => 30,
        ];

        // Phase 2: Evaluate Earnings (Two-Phase Execution)
        // Step 1: Evaluate components that do not depend on Gross
        $evaluatedEarningsByIndex = [];
        $grossDependentEarnings = [];

        foreach ($inputComponents as $idx => $item) {
            $type = strtolower((string)($item['type'] ?? 'earning'));
            if ($type !== 'earning') continue;

            $rawEnabled = $item['is_enabled'] ?? $item['isEnabled'] ?? null;
            $isEnabled = ($rawEnabled === null) ? true : ($rawEnabled !== false && $rawEnabled !== 0 && $rawEnabled !== '0' && $rawEnabled !== 'false');
            $code = strtoupper(trim((string)($item['code'] ?? $item['component_code'] ?? '')));
            $name = trim((string)($item['name'] ?? $item['component_name'] ?? ''));
            $calcType = strtolower((string)($item['calculation_type'] ?? $item['calculationType'] ?? 'fixed'));
            $calcBase = (string)($item['calculation_base'] ?? $item['calculationBase'] ?? 'Basic Salary');
            $rateOrAmount = (float)($item['rate_or_amount'] ?? $item['rateOrAmount'] ?? $item['amount'] ?? 0);
            $formula = $item['custom_formula'] ?? $item['customFormula'] ?? $item['formula'] ?? null;
            $includedInGross = $item['is_included_in_gross'] ?? $item['isIncludedInGross'] ?? true;
            $hasOverride = !empty($item['is_overridden']) && isset($item['amount']) && is_numeric($item['amount']);

            $isGrossDependent = !$hasOverride && ($code !== 'BASIC') && (
                $calcType === 'percent_gross' ||
                strcasecmp($calcBase, 'Gross Salary') === 0 ||
                strcasecmp($calcBase, 'Gross') === 0 ||
                (!empty($formula) && stripos($formula, 'gross') !== false)
            );

            if ($isGrossDependent) {
                $grossDependentEarnings[$idx] = $item;
                continue;
            }

            $amount = 0.00;
            if ($isEnabled) {
                if ($hasOverride) {
                    $amount = round((float)$item['amount'], 2);
                } elseif ($code === 'BASIC' || stripos($name, 'basic') !== false) {
                    $amount = $basicSalary;
                } elseif ($calcType === 'fixed' || $calcType === 'fixed amount') {
                    $amount = round((float)($item['amount'] ?? $rateOrAmount), 2);
                } elseif ($calcType === 'percentage' || $calcType === 'percent_basic') {
                    $pct = normalize_percentage($rateOrAmount);
                    $amount = round($basicSalary * ($pct / 100), 2);
                } elseif ($calcType === 'formula' && !empty($formula)) {
                    $amount = PayrollCalculator::evaluateSalaryFormula($formula, $variablesPool);
                } elseif ($calcType === 'attendance-based') {
                    // Base salary structures represent standard monthly entitlement. Dynamic attendance proration happens at payroll execution.
                    $amount = round($rateOrAmount > 0 ? $rateOrAmount : ($basicSalary > 0 ? $basicSalary : 0), 2);
                } elseif ($calcType === 'working day-based') {
                    $amount = round($basicSalary, 2);
                } elseif ($calcType === 'overtime based') {
                    // Overtime is policy-driven (RuleResolver OVERTIME domain) and not evaluated in base structure assignments.
                    $amount = 0.00;
                } elseif ($calcType === 'dynamic') {
                    $amount = !empty($formula) ? PayrollCalculator::evaluateSalaryFormula($formula, $variablesPool) : round((float)($item['amount'] ?? $rateOrAmount), 2);
                } elseif ($calcType === 'custom input' || $calcType === 'manual') {
                    $amount = round((float)($item['amount'] ?? $rateOrAmount), 2);
                } else {
                    $amount = round((float)($item['amount'] ?? $rateOrAmount), 2);
                }
            }

            if ($code !== '') {
                $variablesPool[$code] = $amount;
            }
            $cleanName = preg_replace('/[^a-zA-Z0-9]/', '', $name);
            if ($cleanName !== '') {
                $variablesPool[$cleanName] = $amount;
            }

            $evaluatedEarningsByIndex[$idx] = $this->processEvaluatedEarningItem(
                $item,
                $code,
                $name,
                $calcType,
                $calcBase,
                $rateOrAmount,
                $amount,
                $formula,
                (bool)$isEnabled,
                (bool)$includedInGross,
                $grossSalary,
                $variablesPool,
                $legacyHouseRent,
                $legacyMedical,
                $legacyConveyance,
                $legacyOtherAllowances
            );
        }

        // Step 2: Determine final grossSalary from base earnings
        $grossSalary = round($grossSalary, 2);
        $variablesPool['Gross'] = $grossSalary;
        $variablesPool['GrossSalary'] = $grossSalary;

        // Step 3: Evaluate "% of Gross" components with final grossSalary
        foreach ($grossDependentEarnings as $idx => $item) {
            $isEnabled = $item['is_enabled'] ?? $item['isEnabled'] ?? true;
            $code = strtoupper(trim((string)($item['code'] ?? $item['component_code'] ?? '')));
            $name = trim((string)($item['name'] ?? $item['component_name'] ?? ''));
            $calcType = strtolower((string)($item['calculation_type'] ?? $item['calculationType'] ?? 'fixed'));
            $calcBase = (string)($item['calculation_base'] ?? $item['calculationBase'] ?? 'Gross Salary');
            $rateOrAmount = (float)($item['rate_or_amount'] ?? $item['rateOrAmount'] ?? $item['amount'] ?? 0);
            $formula = $item['custom_formula'] ?? $item['customFormula'] ?? $item['formula'] ?? null;
            $includedInGross = $item['is_included_in_gross'] ?? $item['isIncludedInGross'] ?? true;

            $amount = 0.00;
            if ($isEnabled) {
                if ($calcType === 'percentage' || $calcType === 'percent_basic' || $calcType === 'percent_gross') {
                    $pct = normalize_percentage($rateOrAmount);
                    $amount = round($grossSalary * ($pct / 100), 2);
                } elseif ($calcType === 'formula' && !empty($formula)) {
                    $amount = PayrollCalculator::evaluateSalaryFormula($formula, $variablesPool);
                } else {
                    $amount = round((float)($item['amount'] ?? $rateOrAmount), 2);
                }
            }

            if ($code !== '') {
                $variablesPool[$code] = $amount;
            }
            $cleanName = preg_replace('/[^a-zA-Z0-9]/', '', $name);
            if ($cleanName !== '') {
                $variablesPool[$cleanName] = $amount;
            }

            $evaluatedEarningsByIndex[$idx] = $this->processEvaluatedEarningItem(
                $item,
                $code,
                $name,
                $calcType,
                $calcBase,
                $rateOrAmount,
                $amount,
                $formula,
                (bool)$isEnabled,
                (bool)$includedInGross,
                $grossSalary,
                $variablesPool,
                $legacyHouseRent,
                $legacyMedical,
                $legacyConveyance,
                $legacyOtherAllowances
            );
        }

        ksort($evaluatedEarningsByIndex);
        $evaluatedEarnings = array_values($evaluatedEarningsByIndex);
        foreach ($evaluatedEarnings as $ei) {
            $evaluatedAllComponents[] = $ei;
        }

        $grossSalary = round($grossSalary, 2);
        $variablesPool['Gross'] = $grossSalary;
        $variablesPool['GrossSalary'] = $grossSalary;

        // Phase 3: Evaluate Deductions (Two-Phase Execution)
        $totalDeductions = 0.00;
        $taxableSalary = $grossSalary;
        $serviceErPfMatch = null;
        $serviceErPfRate = 0.00;
        $serviceEmpPfDeduction = null;
        $serviceTaxMonthly = null;

        $evaluatedDeductionsByIndex = [];
        $grossDependentDeductions = [];

        foreach ($inputComponents as $idx => $item) {
            $type = strtolower((string)($item['type'] ?? ''));
            if ($type !== 'deduction') continue;

            $code = strtoupper(trim((string)($item['code'] ?? $item['component_code'] ?? '')));
            $name = trim((string)($item['name'] ?? $item['component_name'] ?? ''));
            $calcType = strtolower((string)($item['calculation_type'] ?? $item['calculationType'] ?? 'fixed'));
            $calcBase = (string)($item['calculation_base'] ?? $item['calculationBase'] ?? 'Basic Salary');
            $formula = $item['custom_formula'] ?? $item['customFormula'] ?? $item['formula'] ?? null;
            $hasOverride = !empty($item['is_overridden']) && isset($item['amount']) && is_numeric($item['amount']);
            $isPfComponent = in_array($code, ['EMP_PF', 'PF', 'PROVIDENT_FUND', 'EMPLOYEE_PF'], true) || stripos($name, 'provident fund') !== false;

            $isGrossDependent = !$hasOverride && (
                $calcType === 'percent_gross' ||
                strcasecmp($calcBase, 'Gross Salary') === 0 ||
                strcasecmp($calcBase, 'Gross') === 0 ||
                strcasecmp($calcBase, 'Taxable Salary') === 0 ||
                $calcType === 'slab' ||
                (!empty($formula) && stripos($formula, 'gross') !== false) ||
                ($isPfComponent && ($calcType === 'percent_gross' || strcasecmp($calcBase, 'Gross Salary') === 0 || strcasecmp($calcBase, 'Gross') === 0))
            );

            if ($isGrossDependent) {
                $grossDependentDeductions[$idx] = $item;
                continue;
            }

            // Evaluate non-gross deduction
            $rawEnabled = $item['is_enabled'] ?? $item['isEnabled'] ?? null;
            $isEnabled = ($rawEnabled === null) ? true : ($rawEnabled !== false && $rawEnabled !== 0 && $rawEnabled !== '0' && $rawEnabled !== 'false');
            $rateOrAmount = (float)($item['rate_or_amount'] ?? $item['rateOrAmount'] ?? $item['amount'] ?? 0);
            $amount = 0.00;

            if ($isEnabled) {
                if ($isPfComponent) {
                    $isEligible = isset($data['pf_settings']['eligible'])
                        ? !empty($data['pf_settings']['eligible'])
                        : (isset($data['pf_settings']['is_eligible'])
                            ? !empty($data['pf_settings']['is_eligible'])
                            : (isset($data['pf_eligible'])
                                ? !empty($data['pf_eligible'])
                                : (isset($data['is_pf_applicable'])
                                    ? (bool)$data['is_pf_applicable']
                                    : (isset($existingAssignment['is_pf_applicable'])
                                        ? (bool)$existingAssignment['is_pf_applicable']
                                        : (!empty($employee['is_pf_applicable']))))));

                    $pfStatus = $isEligible ? 'Enrolled' : 'Not Enrolled';
                    if (isset($data['pf_status'])) {
                        $pfStatus = trim((string)$data['pf_status']);
                    } elseif (!$isEligible) {
                        if (isset($existingAssignment['pf_status'])) {
                            $pfStatus = trim((string)$existingAssignment['pf_status']);
                        } elseif (isset($employee['pf_status'])) {
                            $pfStatus = trim((string)$employee['pf_status']);
                        }
                    }
                    if ($pfStatus !== 'Enrolled') {
                        $isEligible = false;
                    }

                    if (!$isEligible) {
                        $amount = 0.00;
                        $rateOrAmount = 0.00;
                        $serviceErPfMatch = 0.00;
                        $serviceErPfRate = 0.00;
                    } else {
                        $hasPfOverride = !empty($data['has_pf_override']) || 
                                         !empty($data['is_pf_override']) || 
                                         !empty($item['is_overridden']) || 
                                         !empty($existingAssignment['has_pf_override']);

                        $pfCalc = new PfCalculator();
                        $pfEmployeeContext = array_merge($employee, [
                            'is_pf_applicable' => $isEligible ? 1 : 0,
                            'pf_status'        => $pfStatus,
                            'pf_settings'      => [
                                'eligible'        => $isEligible,
                                'is_override'     => $hasPfOverride,
                                'override_reason' => trim((string)($data['pf_settings']['override_reason'] ?? $data['pf_override_reason'] ?? '')),
                            ],
                        ]);

                        $pfCalcContext = [
                            'company_id'     => $companyId,
                            'employee'       => $pfEmployeeContext,
                            'effective_date' => $effectiveFrom,
                            'basic'          => $basicSalary,
                            'gross'          => $grossSalary,
                            'earnings'       => [
                                'Basic' => $basicSalary,
                                'Gross' => $grossSalary,
                            ],
                        ];
                        if ($hasPfOverride) {
                            $pfRuleCompany = \App\Services\Rules\RuleResolver::resolve($companyId, 'PF', $effectiveFrom, $employee);
                            $empRate = isset($data['pf_settings']['employee_rate'])
                                ? (float)$data['pf_settings']['employee_rate']
                                : (isset($data['employee_rate']) ? (float)$data['employee_rate'] : ($rateOrAmount > 0 ? $rateOrAmount : (float)$pfRuleCompany->get('employee_rate')));
                            $compRate = isset($data['pf_settings']['employer_rate'])
                                ? (float)$data['pf_settings']['employer_rate']
                                : (isset($data['employer_rate']) ? (float)$data['employer_rate'] : (float)$pfRuleCompany->get('employer_rate'));
                            $pfCalcContext['rule_override'] = [
                                'employee_rate' => $empRate,
                                'employer_rate' => $compRate,
                            ];
                        }

                        try {
                            $pfCalcResult = $pfCalc->calculate($pfCalcContext);
                        } catch (\InvalidArgumentException $e) {
                            log_message('error', 'EmployeeSalaryService PF formula calculation error: ' . $e->getMessage());
                            throw $e;
                        }

                        $amount           = (float)($pfCalcResult['employee_deduction'] ?? 0.00);
                        $rateOrAmount     = (float)($pfCalcResult['employee_rate_applied'] ?? 0.00);
                        $serviceErPfMatch = (float)($pfCalcResult['employer_contribution'] ?? 0.00);
                        $serviceErPfRate  = (float)($pfCalcResult['employer_rate_applied'] ?? 0.00);
                    }
                } elseif ($hasOverride) {
                    $amount = round((float)$item['amount'], 2);
                } elseif ($calcType === 'fixed' || $calcType === 'fixed amount') {
                    $amount = round((float)($item['amount'] ?? $rateOrAmount), 2);
                } elseif ($calcType === 'percentage' || $calcType === 'percent_basic') {
                    $pct = normalize_percentage($rateOrAmount);
                    $amount = round($basicSalary * ($pct / 100), 2);
                } elseif ($calcType === 'formula' && !empty($formula)) {
                    $amount = PayrollCalculator::evaluateSalaryFormula($formula, $variablesPool);
                } elseif ($calcType === 'dynamic') {
                    $amount = !empty($formula) ? PayrollCalculator::evaluateSalaryFormula($formula, $variablesPool) : round((float)($item['amount'] ?? $rateOrAmount), 2);
                } else {
                    $amount = round((float)($item['amount'] ?? $rateOrAmount), 2);
                }
            }

            if ($code !== '') {
                $variablesPool[$code] = $amount;
            }
            $cleanName = preg_replace('/[^a-zA-Z0-9]/', '', $name);
            if ($cleanName !== '') {
                $variablesPool[$cleanName] = $amount;
            }

            if ($isEnabled) {
                $totalDeductions += $amount;
            }

            $deductionItem = [
                'component_id'     => $item['component_id'] ?? $item['id'] ?? ('comp-' . strtolower($code)),
                'code'             => $code,
                'name'             => $name,
                'type'             => 'deduction',
                'calculation_type' => $calcType,
                'calculation_base' => $calcBase,
                'rate_or_amount'   => $rateOrAmount,
                'amount'           => $amount,
                'custom_formula'   => $formula,
                'is_enabled'       => (bool)$isEnabled,
                'is_overridden'    => (bool)($item['is_overridden'] ?? $item['isOverridden'] ?? false),
                'is_statutory'     => (bool)($item['is_statutory'] ?? $item['isStatutory'] ?? false),
            ];

            $evaluatedDeductionsByIndex[$idx] = $deductionItem;
        }

        // Step 4: Evaluate "% of Gross" deduction components using final $grossSalary
        foreach ($grossDependentDeductions as $idx => $item) {
            $isEnabled = $item['is_enabled'] ?? $item['isEnabled'] ?? true;
            $code = strtoupper(trim((string)($item['code'] ?? $item['component_code'] ?? '')));
            $name = trim((string)($item['name'] ?? $item['component_name'] ?? ''));
            $calcType = strtolower((string)($item['calculation_type'] ?? $item['calculationType'] ?? 'fixed'));
            $calcBase = (string)($item['calculation_base'] ?? $item['calculationBase'] ?? 'Basic Salary');
            $rateOrAmount = (float)($item['rate_or_amount'] ?? $item['rateOrAmount'] ?? $item['amount'] ?? 0);
            $formula = $item['custom_formula'] ?? $item['customFormula'] ?? $item['formula'] ?? null;
            $taxRuleId = $item['tax_rule_id'] ?? $item['taxRuleId'] ?? null;
            $isPfComponent = in_array($code, ['EMP_PF', 'PF', 'PROVIDENT_FUND', 'EMPLOYEE_PF'], true) || stripos($name, 'provident fund') !== false;
            $isTaxComponent = in_array($code, ['TAX', 'TDS', 'TAX_TDS', 'ITAX', 'INC_TAX', 'PAYE', 'WITHHOLDING_TAX'], true) || stripos($name, 'income tax') !== false;

            $amount = 0.00;
            if ($isEnabled) {
                if ($isPfComponent) {
                    $isEligible = isset($data['pf_settings']['eligible'])
                        ? !empty($data['pf_settings']['eligible'])
                        : (isset($data['pf_settings']['is_eligible'])
                            ? !empty($data['pf_settings']['is_eligible'])
                            : (isset($data['pf_eligible'])
                                ? !empty($data['pf_eligible'])
                                : (isset($data['is_pf_applicable'])
                                    ? (bool)$data['is_pf_applicable']
                                    : (isset($existingAssignment['is_pf_applicable'])
                                        ? (bool)$existingAssignment['is_pf_applicable']
                                        : (!empty($employee['is_pf_applicable']))))));

                    $pfStatus = $isEligible ? 'Enrolled' : 'Not Enrolled';
                    if (isset($data['pf_status'])) {
                        $pfStatus = trim((string)$data['pf_status']);
                    } elseif (isset($existingAssignment['pf_status'])) {
                        $pfStatus = trim((string)$existingAssignment['pf_status']);
                    } elseif (isset($employee['pf_status'])) {
                        $pfStatus = trim((string)$employee['pf_status']);
                    }
                    if ($pfStatus !== 'Enrolled') {
                        $isEligible = false;
                    }

                    if (!$isEligible) {
                        $amount = 0.00;
                        $rateOrAmount = 0.00;
                        $serviceErPfMatch = 0.00;
                        $serviceErPfRate = 0.00;
                    } else {
                        $hasPfOverride = !empty($data['has_pf_override']) || 
                                         !empty($data['is_pf_override']) || 
                                         !empty($item['is_overridden']) || 
                                         !empty($existingAssignment['has_pf_override']);

                        $pfCalc = new PfCalculator();
                        $pfEmployeeContext = array_merge($employee, [
                            'is_pf_applicable' => $isEligible ? 1 : 0,
                            'pf_status'        => $pfStatus,
                            'pf_settings'      => [
                                'eligible'        => $isEligible,
                                'is_override'     => $hasPfOverride,
                                'override_reason' => trim((string)($data['pf_settings']['override_reason'] ?? $data['pf_override_reason'] ?? '')),
                            ],
                        ]);

                        $pfCalcContext = [
                            'company_id'     => $companyId,
                            'employee'       => $pfEmployeeContext,
                            'effective_date' => $effectiveFrom,
                            'basic'          => $basicSalary,
                            'gross'          => $grossSalary,
                            'earnings'       => [
                                'Basic' => $basicSalary,
                                'Gross' => $grossSalary,
                            ],
                        ];
                        if ($hasPfOverride) {
                            $pfRuleCompany = \App\Services\Rules\RuleResolver::resolve($companyId, 'PF', $effectiveFrom, $employee);
                            $empRate = isset($data['pf_settings']['employee_rate'])
                                ? (float)$data['pf_settings']['employee_rate']
                                : (isset($data['employee_rate']) ? (float)$data['employee_rate'] : ($rateOrAmount > 0 ? $rateOrAmount : (float)$pfRuleCompany->get('employee_rate')));
                            $compRate = isset($data['pf_settings']['employer_rate'])
                                ? (float)$data['pf_settings']['employer_rate']
                                : (isset($data['employer_rate']) ? (float)$data['employer_rate'] : (float)$pfRuleCompany->get('employer_rate'));
                            $pfCalcContext['rule_override'] = [
                                'employee_rate' => $empRate,
                                'employer_rate' => $compRate,
                            ];
                        }

                        try {
                            $pfCalcResult = $pfCalc->calculate($pfCalcContext);
                        } catch (\InvalidArgumentException $e) {
                            log_message('error', 'EmployeeSalaryService PF formula calculation error: ' . $e->getMessage());
                            throw $e;
                        }

                        $amount           = (float)($pfCalcResult['employee_deduction'] ?? 0.00);
                        $rateOrAmount     = (float)($pfCalcResult['employee_rate_applied'] ?? 0.00);
                        $serviceErPfMatch = (float)($pfCalcResult['employer_contribution'] ?? 0.00);
                        $serviceErPfRate  = (float)($pfCalcResult['employer_rate_applied'] ?? 0.00);
                    }
                } elseif ($calcType === 'percentage' || $calcType === 'percent_basic' || $calcType === 'percent_gross') {
                    $pct = normalize_percentage($rateOrAmount);
                    $baseVal = ($calcBase === 'Taxable Salary') ? $taxableSalary
                             : (($calcBase === 'Basic Salary') ? $basicSalary : $grossSalary);
                    $amount = round($baseVal * ($pct / 100), 2);
                } elseif ($isTaxComponent || $calcType === 'slab') {
                    $taxSettings = $data['tax_settings'] ?? ($existingAssignment['tax_settings'] ?? []);
                    if (empty($taxSettings['category']) && !empty($employee['tax_category'])) {
                        $taxSettings['category'] = $employee['tax_category'];
                    }
                    if (empty($taxSettings['tin']) && !empty($employee['tax_identification_number'])) {
                        $taxSettings['tin'] = $employee['tax_identification_number'];
                    }

                    $taxContext = [
                        'company_id'       => $companyId,
                        'employee_id'      => $employeeId,
                        'tax_rule_id'      => $taxRuleId,
                        'earnings'         => $evaluatedEarnings,
                        'gross'            => $taxableSalary,
                        'taxable_gross'    => $taxableSalary,
                        'house_rent'       => $legacyHouseRent,
                        'medical'          => $legacyMedical,
                        'conveyance'       => $legacyConveyance,
                        'other_allowances' => $legacyOtherAllowances,
                    ];

                    $taxRes = $this->policyResolver->resolveIncomeTax(
                        $companyId,
                        $effectiveFrom,
                        $basicSalary,
                        $taxableSalary,
                        $taxSettings,
                        $employee,
                        $taxContext
                    );
                    $amount = (float)($taxRes['amount'] ?? 0.00);
                    $rateOrAmount = $amount;
                    $calcType = ($taxRes['calculation_mode'] === 'Fixed') ? 'fixed' : (($taxRes['calculation_mode'] === 'Exempt') ? 'exempt' : 'slab');
                } elseif ($calcType === 'formula' && !empty($formula)) {
                    $amount = PayrollCalculator::evaluateSalaryFormula($formula, $variablesPool);
                } elseif ($calcType === 'dynamic') {
                    $amount = !empty($formula) ? PayrollCalculator::evaluateSalaryFormula($formula, $variablesPool) : round((float)($item['amount'] ?? $rateOrAmount), 2);
                } else {
                    $amount = round((float)($item['amount'] ?? $rateOrAmount), 2);
                }
            }

            if ($code !== '') {
                $variablesPool[$code] = $amount;
            }
            $cleanName = preg_replace('/[^a-zA-Z0-9]/', '', $name);
            if ($cleanName !== '') {
                $variablesPool[$cleanName] = $amount;
            }

            if ($isEnabled) {
                $totalDeductions += $amount;
            }

            $deductionItem = [
                'component_id'     => $item['component_id'] ?? $item['id'] ?? ('comp-' . strtolower($code)),
                'code'             => $code,
                'name'             => $name,
                'type'             => 'deduction',
                'calculation_type' => $calcType,
                'calculation_base' => $calcBase,
                'rate_or_amount'   => $rateOrAmount,
                'amount'           => $amount,
                'custom_formula'   => $formula,
                'is_enabled'       => (bool)$isEnabled,
                'is_overridden'    => (bool)($item['is_overridden'] ?? $item['isOverridden'] ?? false),
                'is_statutory'     => (bool)($item['is_statutory'] ?? $item['isStatutory'] ?? false),
            ];

            $evaluatedDeductionsByIndex[$idx] = $deductionItem;
        }

        ksort($evaluatedDeductionsByIndex);
        $evaluatedDeductions = array_values($evaluatedDeductionsByIndex);
        foreach ($evaluatedDeductions as $di) {
            $evaluatedAllComponents[] = $di;
        }

        $totalDeductions = round($totalDeductions, 2);
        $netSalary = round(max(0, $grossSalary - $totalDeductions), 2);

        // Phase 4: Evaluate Employer Contributions
        $totalEmployerContributions = 0.00;
        foreach ($inputComponents as $item) {
            $type = strtolower((string)($item['type'] ?? ''));
            if ($type !== 'employer_contribution' && $type !== 'employer contribution') continue;

            $isEnabled = $item['is_enabled'] ?? $item['isEnabled'] ?? true;
            $code = strtoupper(trim((string)($item['code'] ?? $item['component_code'] ?? '')));
            $name = trim((string)($item['name'] ?? $item['component_name'] ?? ''));
            $calcType = strtolower((string)($item['calculation_type'] ?? $item['calculationType'] ?? 'fixed'));
            $calcBase = (string)($item['calculation_base'] ?? $item['calculationBase'] ?? 'Basic Salary');
            $rateOrAmount = (float)($item['rate_or_amount'] ?? $item['rateOrAmount'] ?? $item['amount'] ?? 0);
            $formula = $item['custom_formula'] ?? $item['customFormula'] ?? $item['formula'] ?? null;

            $isErPf = in_array($code, ['ER_PF', 'EMPLOYER_PF', 'COMP_PF'], true) || stripos($name, 'provident fund') !== false;

            $amount = 0.00;
            if ($isEnabled) {
                if ($isErPf && $serviceErPfMatch !== null) {
                    $amount = $serviceErPfMatch;
                    $rateOrAmount = $serviceErPfRate;
                } elseif ($calcType === 'fixed' || $calcType === 'fixed amount') {
                    $amount = round($rateOrAmount, 2);
                } elseif ($calcType === 'percentage' || $calcType === 'percent_basic' || $calcType === 'percent_gross') {
                    $pct = normalize_percentage($rateOrAmount);
                    $baseVal = ($calcBase === 'Gross Salary' || $calcType === 'percent_gross') ? $grossSalary : ($basicSalary > 0 ? $basicSalary : $grossSalary);
                    $amount = round($baseVal * ($pct / 100), 2);
                } elseif ($calcType === 'formula' && !empty($formula)) {
                    $amount = PayrollCalculator::evaluateSalaryFormula($formula, $variablesPool);
                } elseif ($calcType === 'dynamic') {
                    $amount = !empty($formula) ? PayrollCalculator::evaluateSalaryFormula($formula, $variablesPool) : round((float)($item['amount'] ?? $rateOrAmount), 2);
                } elseif ($calcType === 'custom input' || $calcType === 'manual') {
                    $amount = round((float)($item['amount'] ?? $rateOrAmount), 2);
                } else {
                    $amount = round($rateOrAmount, 2);
                }
            }

            if ($code !== '') {
                $variablesPool[$code] = $amount;
            }
            $cleanName = preg_replace('/[^a-zA-Z0-9]/', '', $name);
            if ($cleanName !== '') {
                $variablesPool[$cleanName] = $amount;
            }

            if ($isEnabled) {
                $totalEmployerContributions += $amount;
            }

            $erItem = [
                'component_id'        => $item['component_id'] ?? $item['id'] ?? ('comp-' . strtolower($code)),
                'code'                => $code,
                'name'                => $name,
                'type'                => 'employer_contribution',
                'calculation_type'    => $calcType,
                'calculation_base'    => $calcBase,
                'rate_or_amount'      => $rateOrAmount,
                'amount'              => $amount,
                'custom_formula'      => $formula,
                'is_enabled'          => (bool)$isEnabled,
                'is_overridden'       => (bool)($item['is_overridden'] ?? $item['isOverridden'] ?? false),
                'is_included_in_ctc'  => (bool)($item['is_included_in_ctc'] ?? $item['isIncludedInCTC'] ?? true),
            ];

            $evaluatedEmployerContributions[] = $erItem;
            $evaluatedAllComponents[] = $erItem;
        }

        $totalEmployerContributions = round($totalEmployerContributions, 2);
        $ctc = round($grossSalary + $totalEmployerContributions, 2);

        // 5. Query Existing Active Salary to construct Previous Historical Snapshot
        $existingSalary = $this->salaryModel
            ->where('employee_id', $employeeId)
            ->where('status', 'Active')
            ->orderBy('effective_from', 'DESC')
            ->first();

        $existingSnapshot = [];
        if ($existingSalary && !empty($existingSalary['custom_components_json'])) {
            $dec = json_decode($existingSalary['custom_components_json'], true);
            if (is_array($dec)) {
                $existingSnapshot = $dec;
            }
        }

        $priorHistory = $data['history_snapshots'] ?? $data['historySnapshots'] ?? $existingSnapshot['history_snapshots'] ?? $existingSnapshot['historySnapshots'] ?? [];
        if (!is_array($priorHistory)) {
            $priorHistory = [];
        }

        $prevSnapshot = null;
        if ($existingSalary) {
            $prevSnapshot = [
                'id'                   => 'SNAP-' . ($existingSalary['id'] ?? $employeeId) . '-' . substr((string)time(), -6),
                'employeeId'           => $employeeId,
                'employee_id'          => $employeeId,
                'companyId'            => $employee['company_id'] ?? $companyId,
                'company_id'           => $employee['company_id'] ?? $companyId,
                'structureId'          => $existingSalary['structure_id'] ?? null,
                'structure_id'         => $existingSalary['structure_id'] ?? null,
                'structureName'        => $existingSnapshot['structure_name'] ?? $existingSnapshot['structureName'] ?? 'Previous Salary Structure',
                'structure_name'       => $existingSnapshot['structure_name'] ?? $existingSnapshot['structureName'] ?? 'Previous Salary Structure',
                'version'              => (int)($existingSnapshot['version'] ?? $existingSnapshot['snapshot_version'] ?? 1),
                'snapshot_version'     => (int)($existingSnapshot['version'] ?? $existingSnapshot['snapshot_version'] ?? 1),
                'assignmentType'       => $existingSnapshot['assignmentType'] ?? $existingSnapshot['assignment_type'] ?? ($existingSalary['structure_id'] ? 'template' : 'customized'),
                'assignment_type'      => $existingSnapshot['assignmentType'] ?? $existingSnapshot['assignment_type'] ?? ($existingSalary['structure_id'] ? 'template' : 'customized'),
                'effectiveFrom'        => $existingSalary['effective_from'] ?? date('Y-m-d'),
                'effective_from'       => $existingSalary['effective_from'] ?? date('Y-m-d'),
                'effectiveTo'          => $effectiveFrom,
                'effective_to'         => $effectiveFrom,
                'status'               => 'Revised',
                'basicSalary'          => (float)($existingSalary['basic_salary'] ?? 0),
                'basic_salary'         => (float)($existingSalary['basic_salary'] ?? 0),
                'grossSalary'          => (float)($existingSalary['gross_salary'] ?? 0),
                'gross_salary'         => (float)($existingSalary['gross_salary'] ?? 0),
                'totalEarnings'        => (float)($existingSalary['gross_salary'] ?? 0),
                'total_earnings'       => (float)($existingSalary['gross_salary'] ?? 0),
                'totalDeductions'      => (float)($existingSalary['total_deductions'] ?? 0),
                'total_deductions'     => (float)($existingSalary['total_deductions'] ?? 0),
                'netSalary'            => (float)($existingSalary['net_salary'] ?? 0),
                'net_salary'           => (float)($existingSalary['net_salary'] ?? 0),
                'totalEmployerCost'    => (float)($existingSalary['ctc'] ?? 0),
                'ctc'                  => (float)($existingSalary['ctc'] ?? 0),
                'components'           => $existingSnapshot['all_components'] ?? $existingSnapshot['components'] ?? [],
                'all_components'       => $existingSnapshot['all_components'] ?? $existingSnapshot['components'] ?? [],
                'calculationBreakdown' => $existingSnapshot,
                'pfEligible'           => $existingSnapshot['pf_settings']['eligible'] ?? ($existingSnapshot['pf_eligible'] ?? ((int)($employee['is_pf_applicable'] ?? 0) === 1 && ($employee['pf_status'] ?? 'Enrolled') === 'Enrolled')),
                'pfDeductionType'      => $existingSnapshot['pf_settings']['type'] ?? ($existingSnapshot['pf_settings']['calculation_type'] ?? 'percentage'),
                'pfEmployeeShare'      => (float)($existingSnapshot['pf_settings']['employee_rate'] ?? 0),
                'pfEmployerShare'      => (float)($existingSnapshot['pf_settings']['employer_rate'] ?? 0),
                'pfDeductionBase'      => $existingSnapshot['pf_settings']['base'] ?? ($existingSnapshot['pf_settings']['calculation_base'] ?? 'Basic Salary'),
                'taxConfig'            => $existingSnapshot['tax_settings'] ?? [],
                'revisionReason'       => $data['notes'] ?? (!empty($data['is_resync']) ? 'Re-synced with master template' : 'Salary Structure Revision'),
                'revision_reason'      => $data['notes'] ?? (!empty($data['is_resync']) ? 'Re-synced with master template' : 'Salary Structure Revision'),
                'revisedBy'            => $actor['name'] ?? $actor['id'] ?? 'HR Admin',
                'revised_by'           => $actor['name'] ?? $actor['id'] ?? 'HR Admin',
                'revisedAt'            => date('Y-m-d H:i:s'),
                'revised_at'           => date('Y-m-d H:i:s')
            ];
            $updatedHistorySnapshots = array_merge([$prevSnapshot], $priorHistory);
            $newVersion = ((int)($existingSnapshot['version'] ?? $existingSnapshot['snapshot_version'] ?? 1)) + 1;
        } else {
            $updatedHistorySnapshots = $priorHistory;
            $newVersion = 1;
        }

        // 6. Build Complete Historical Snapshot (Dual Snake/CamelCase for React and CI4 parity)
        $snapshotId = 'snap-' . bin2hex(random_bytes(8));
        $snapshot = [
            'snapshot_version'             => $newVersion,
            'version'                      => $newVersion,
            'snapshot_id'                  => $snapshotId,
            'id'                           => $snapshotId,
            'employee_id'                  => $employeeId,
            'employeeId'                   => $employeeId,
            'employee_code'                => $employee['employee_code'] ?? '',
            'company_id'                   => $employee['company_id'] ?? $companyId,
            'companyId'                    => $employee['company_id'] ?? $companyId,
            'branch_id'                    => $employee['branch_id'] ?? null,
            'branchId'                     => $employee['branch_id'] ?? null,
            'structure_id'                 => $isCustom ? 'CUSTOM' : $structureId,
            'structureId'                  => $isCustom ? 'CUSTOM' : $structureId,
            'structure_name'               => $structureName ?: ($isCustom ? 'Individual Custom Structure' : 'Salary Structure'),
            'structureName'                => $structureName ?: ($isCustom ? 'Individual Custom Structure' : 'Salary Structure'),
            'is_custom'                    => $isCustom,
            'assignment_type'              => $isCustom ? 'customized' : 'template',
            'assignmentType'               => $isCustom ? 'customized' : 'template',
            'effective_from'               => $effectiveFrom,
            'effectiveFrom'                => $effectiveFrom,
            'effective_to'                 => null,
            'effectiveTo'                  => null,
            'status'                       => 'Active',
            'basic_salary'                 => $basicSalary,
            'basicSalary'                  => $basicSalary,
            'gross_salary'                 => $grossSalary,
            'grossSalary'                  => $grossSalary,
            'total_earnings'               => $grossSalary,
            'totalEarnings'                => $grossSalary,
            'total_deductions'             => $totalDeductions,
            'totalDeductions'              => $totalDeductions,
            'net_salary'                   => $netSalary,
            'netSalary'                    => $netSalary,
            'total_employer_contributions' => $totalEmployerContributions,
            'totalEmployerCost'            => $ctc,
            'ctc'                          => $ctc,
            'earnings'                     => $evaluatedEarnings,
            'deductions'                   => $evaluatedDeductions,
            'employer_contributions'       => $evaluatedEmployerContributions,
            'all_components'               => $evaluatedAllComponents,
            'components'                   => $evaluatedAllComponents,
            'overrides'                    => $evaluatedAllComponents,
            'assigned_by'                  => $actor['id'] ?? 'admin',
            'assigned_by_role'             => $actorRole,
            'assigned_at'                  => date('Y-m-d H:i:s'),
            'notes'                        => $data['notes'] ?? 'Salary Structure Setup',
            'revision_reason'              => $data['notes'] ?? 'Salary Structure Setup',
            'revisionReason'               => $data['notes'] ?? 'Salary Structure Setup',
            'revised_by'                   => $actor['name'] ?? $actor['id'] ?? 'HR Admin',
            'revisedBy'                    => $actor['name'] ?? $actor['id'] ?? 'HR Admin',
            'revised_at'                   => date('Y-m-d H:i:s'),
            'revisedAt'                    => date('Y-m-d H:i:s'),
            'history_snapshots'            => $updatedHistorySnapshots,
            'historySnapshots'             => $updatedHistorySnapshots,
            // Backward compatibility convenience properties
            'house_rent'                   => $legacyHouseRent,
            'medical'                      => $legacyMedical,
            'conveyance'                   => $legacyConveyance,
            'other_allowances'             => $legacyOtherAllowances,
            'pf_settings'                  => [
                'eligible'        => isset($data['pf_settings']['eligible']) ? (bool)$data['pf_settings']['eligible'] : (isset($data['pf_settings']['is_eligible']) ? (bool)$data['pf_settings']['is_eligible'] : (isset($data['pf_eligible']) ? (bool)$data['pf_eligible'] : ((int)($employee['is_pf_applicable'] ?? 0) === 1 && ($employee['pf_status'] ?? 'Enrolled') === 'Enrolled'))),
                'is_override'     => !empty($data['pf_settings']['is_override']) || !empty($data['is_pf_override']) || !empty($data['has_pf_override']),
                'override_reason' => trim((string)($data['pf_settings']['override_reason'] ?? $data['pf_override_reason'] ?? '')),
            ],
            'tax_settings'                 => [
                'category'          => $data['tax_settings']['category'] ?? $data['tax_settings']['tax_category'] ?? $data['tax_category'] ?? $employee['tax_category'] ?? 'General',
                'tin'               => $data['tax_settings']['tin'] ?? $data['tax_settings']['tax_identification_number'] ?? $data['tax_identification_number'] ?? $employee['tax_identification_number'] ?? '',
                'calculation_mode'  => $data['tax_settings']['calculation_mode'] ?? $data['tax_settings']['mode'] ?? $taxRuleMode,
                'auto_calculation'   => $data['tax_settings']['auto_calculation'] ?? (($data['tax_settings']['calculation_mode'] ?? '') === 'Fixed' ? 'inactive' : (($data['tax_settings']['calculation_mode'] ?? '') === 'Exempt' ? 'exempt' : 'active')),
                'annual_tax_amount' => isset($data['tax_settings']['annual_tax_amount']) ? (float)$data['tax_settings']['annual_tax_amount'] : round((float)($data['tax_settings']['custom_tax_amount'] ?? 0) * 12, 2),
                'annual_tax_year'   => $data['tax_settings']['annual_tax_year'] ?? \App\Services\Tax\TaxCalculator::getFiscalYear($effectiveFrom),
                'custom_tax_amount' => (float)($data['tax_settings']['custom_tax_amount'] ?? $data['tax_settings']['fixed_amount'] ?? $data['tax_fixed_amount'] ?? $data['tax_custom_amount'] ?? 0),
                'is_override'       => !empty($data['tax_settings']['is_override']) || in_array(($data['tax_settings']['calculation_mode'] ?? $data['tax_settings']['mode'] ?? $taxRuleMode), ['Fixed', 'Exempt'], true),
                'override_reason'   => trim((string)($data['tax_settings']['override_reason'] ?? $data['tax_override_reason'] ?? '')),
            ],
            'gratuity_settings'            => [
                'is_override'     => !empty($data['gratuity_settings']['is_override']) || !empty($data['is_gratuity_override']),
                'override_reason' => trim((string)($data['gratuity_settings']['override_reason'] ?? $data['gratuity_override_reason'] ?? '')),
                'amount'          => (float)($data['gratuity_settings']['amount'] ?? $data['gratuity_amount'] ?? 0),
            ],
        ];

        // 7. Database Transaction
        $db = Database::connect();
        $db->transStart();

        $previousBasic = 0.00;
        $previousGross = 0.00;

        if ($existingSalary) {
            $previousBasic = (float)$existingSalary['basic_salary'];
            $previousGross = (float)$existingSalary['gross_salary'];

            $effectiveTo = date('Y-m-d', strtotime($effectiveFrom . ' -1 day'));
            if ($effectiveTo < $existingSalary['effective_from']) {
                $effectiveTo = $effectiveFrom;
            }

            $this->salaryModel->update($existingSalary['id'], [
                'status'       => 'Revised',
                'effective_to' => $effectiveTo,
                'updated_at'   => date('Y-m-d H:i:s')
            ]);
        } elseif ((float)($employee['gross_salary'] ?? $employee['basic_salary'] ?? 0) > 0) {
            $previousBasic = (float)($employee['basic_salary'] ?? 0);
            $previousGross = (float)($employee['gross_salary'] ?? $previousBasic);
        }

        // Insert new active snapshot in employee_salaries
        $newSalaryId = 'sal-' . bin2hex(random_bytes(8));
        $salaryRecord = [
            'id'                           => $newSalaryId,
            'company_id'                   => $employee['company_id'] ?? $companyId,
            'employee_id'                  => $employeeId,
            'structure_id'                 => $isCustom ? null : $structureId,
            'basic_salary'                 => $basicSalary,
            'gross_salary'                 => $grossSalary,
            'total_deductions'             => $totalDeductions,
            'net_salary'                   => $netSalary,
            'ctc'                          => $ctc,
            'custom_components_json'       => json_encode($snapshot),
            'effective_from'               => $effectiveFrom,
            'effective_to'                 => null,
            'status'                       => 'Active',
            'created_at'                   => date('Y-m-d H:i:s'),
            'updated_at'                   => date('Y-m-d H:i:s')
        ];
        $this->salaryModel->insert($salaryRecord);

        // When gratuity is overridden for an employee, ensure Employee-scope rule exists in rule_definitions (Rule 3 via RuleWriteService)
        if (!empty($snapshot['gratuity_settings']['is_override'])) {
            $overrideReason = trim((string)($snapshot['gratuity_settings']['override_reason'] ?? ''));
            if ($overrideReason === '') {
                throw new \InvalidArgumentException("An override reason is mandatory when configuring an employee-specific gratuity rule.");
            }
            $customAmount = (float)($snapshot['gratuity_settings']['amount'] ?? 0);
            
            // Check existing Employee-scope GRATUITY rule
            $existingEmpRule = (new \App\Models\RuleDefinitionModel())->where('company_id', $employee['company_id'])
                ->where('domain', 'GRATUITY')
                ->where('scope_level', 'Employee')
                ->where('scope_id', $employeeId)
                ->where('status', 'Active')
                ->first();

            $params = [
                'custom_monthly_amount' => $customAmount,
                'override_reason'       => $overrideReason,
            ];

            $needsPublish = true;
            if ($existingEmpRule) {
                $curParams = (new \App\Models\RuleDefinitionModel())->paramsOf($existingEmpRule);
                if ((float)($curParams['custom_monthly_amount'] ?? -1) === $customAmount && ($existingEmpRule['change_reason'] ?? '') === $overrideReason) {
                    $needsPublish = false;
                }
            }

            if ($needsPublish) {
                $ruleWriteService = new \App\Services\Rules\RuleWriteService();
                $ruleWriteService->publishRule(
                    $employee['company_id'],
                    'GRATUITY',
                    'Employee',
                    $employeeId,
                    $params,
                    $actorUserId,
                    $overrideReason,
                    $effectiveFrom
                );
            }
        }

        // When Provident Fund is overridden for an employee, ensure Employee-scope rule exists in rule_definitions (Rule 3 via RuleWriteService)
        $hasPfOverride = !empty($snapshot['pf_settings']['is_override']) || !empty($data['has_pf_override']) || !empty($data['is_pf_override']);
        if ($hasPfOverride) {
            $pfOverrideReason = trim((string)($snapshot['pf_settings']['override_reason'] ?? $data['pf_override_reason'] ?? ''));
            if ($pfOverrideReason === '') {
                throw new \InvalidArgumentException("An override reason is mandatory when configuring an employee-specific Provident Fund rule.");
            }
            $pfRuleCompany = \App\Services\Rules\RuleResolver::resolve($employee['company_id'], 'PF', $effectiveFrom, $employee);
            $empRate = isset($snapshot['pf_settings']['employee_rate'])
                ? (float)$snapshot['pf_settings']['employee_rate']
                : (isset($data['employee_rate']) ? (float)$data['employee_rate'] : (float)$pfRuleCompany->get('employee_rate'));
            $compRate = isset($snapshot['pf_settings']['employer_rate'])
                ? (float)$snapshot['pf_settings']['employer_rate']
                : (isset($data['employer_rate']) ? (float)$data['employer_rate'] : (float)$pfRuleCompany->get('employer_rate'));

            $existingEmpPfRule = (new \App\Models\RuleDefinitionModel())->where('company_id', $employee['company_id'])
                ->where('domain', 'PF')
                ->where('scope_level', 'Employee')
                ->where('scope_id', $employeeId)
                ->where('status', 'Active')
                ->first();

            $pfParams = [
                'employee_rate' => $empRate,
                'employer_rate' => $compRate,
            ];

            $needsPfPublish = true;
            if ($existingEmpPfRule) {
                $curParams = (new \App\Models\RuleDefinitionModel())->paramsOf($existingEmpPfRule);
                if ((float)($curParams['employee_rate'] ?? -1) === $empRate && (float)($curParams['employer_rate'] ?? -1) === $compRate && ($existingEmpPfRule['change_reason'] ?? '') === $pfOverrideReason) {
                    $needsPfPublish = false;
                }
            }

            if ($needsPfPublish) {
                $ruleWriteService = new \App\Services\Rules\RuleWriteService();
                $ruleWriteService->publishRule(
                    $employee['company_id'],
                    'PF',
                    'Employee',
                    $employeeId,
                    $pfParams,
                    $actorUserId,
                    $pfOverrideReason,
                    $effectiveFrom
                );
            }
        } else {
            // When employee override is removed, archive active Employee-scope PF rule if present
            $existingEmpPfRule = (new \App\Models\RuleDefinitionModel())->where('company_id', $employee['company_id'])
                ->where('domain', 'PF')
                ->where('scope_level', 'Employee')
                ->where('scope_id', $employeeId)
                ->where('status', 'Active')
                ->first();
            if ($existingEmpPfRule) {
                $ruleWriteService = new \App\Services\Rules\RuleWriteService();
                $ruleWriteService->archiveRule(
                    $existingEmpPfRule['id'],
                    $actorUserId,
                    'Employee PF override removed during salary assignment update'
                );
            }
        }

        // When Income Tax is overridden for an employee, ensure Employee-scope rule exists in rule_definitions (Rule 3 via RuleWriteService)
        $hasTaxOverride = !empty($snapshot['tax_settings']['is_override']) || !empty($data['has_tax_override']) || !empty($data['is_tax_override']) || in_array(($snapshot['tax_settings']['calculation_mode'] ?? $taxRuleMode), ['Fixed', 'Exempt'], true);
        if ($hasTaxOverride) {
            $taxOverrideReason = trim((string)($snapshot['tax_settings']['override_reason'] ?? $data['tax_override_reason'] ?? ''));
            $taxModeToSet = (string)($snapshot['tax_settings']['calculation_mode'] ?? $taxRuleMode);
            $customTaxAmt = (float)($snapshot['tax_settings']['custom_tax_amount'] ?? 0);

            $existingEmpTaxRule = (new \App\Models\RuleDefinitionModel())->where('company_id', $employee['company_id'])
                ->where('domain', 'TAX')
                ->where('scope_level', 'Employee')
                ->where('scope_id', $employeeId)
                ->where('status', 'Active')
                ->first();

            $taxParams = [
                'calculation_mode' => $taxModeToSet,
                'fixed_tax_amount' => $customTaxAmt,
            ];

            $needsTaxPublish = true;
            if ($existingEmpTaxRule) {
                $curParams = (new \App\Models\RuleDefinitionModel())->paramsOf($existingEmpTaxRule);
                if (($curParams['calculation_mode'] ?? '') === $taxModeToSet && (float)($curParams['fixed_tax_amount'] ?? -1) === $customTaxAmt && ($existingEmpTaxRule['change_reason'] ?? '') === $taxOverrideReason) {
                    $needsTaxPublish = false;
                }
            }

            if ($needsTaxPublish) {
                $ruleWriteService = new \App\Services\Rules\RuleWriteService();
                $ruleWriteService->publishRule(
                    $employee['company_id'],
                    'TAX',
                    'Employee',
                    $employeeId,
                    $taxParams,
                    $actorUserId,
                    $taxOverrideReason,
                    $effectiveFrom
                );
            }
        } else {
            // When employee tax override is removed, archive active Employee-scope TAX rule if present
            $existingEmpTaxRule = (new \App\Models\RuleDefinitionModel())->where('company_id', $employee['company_id'])
                ->where('domain', 'TAX')
                ->where('scope_level', 'Employee')
                ->where('scope_id', $employeeId)
                ->where('status', 'Active')
                ->first();
            if ($existingEmpTaxRule) {
                $ruleWriteService = new \App\Services\Rules\RuleWriteService();
                $ruleWriteService->archiveRule(
                    $existingEmpTaxRule['id'],
                    $actorUserId,
                    'Employee Tax override removed during salary assignment update'
                );
            }
        }

        // Update employee table (safe fields + backward compat allowances)
        $employeeUpdate = [
            'basic_salary'         => $basicSalary,
            'gross_salary'         => $grossSalary,
            'house_rent_allowance' => $legacyHouseRent,
            'medical_allowance'    => $legacyMedical,
            'conveyance_allowance' => $legacyConveyance,
            'transport_allowance'  => $legacyConveyance,
            'other_allowances'     => $legacyOtherAllowances,
            'salary_status'        => ($basicSalary > 0 || $grossSalary > 0) ? 'CONFIGURED' : 'NOT_CONFIGURED',
            'updated_at'           => date('Y-m-d H:i:s')
        ];
        $taxCategory = trim((string)($data['tax_settings']['category'] ?? $data['tax_settings']['tax_category'] ?? $data['tax_category'] ?? ''));
        if ($taxCategory !== '') {
            $employeeUpdate['tax_category'] = $taxCategory;
        }
        $taxTin = trim((string)($data['tax_settings']['tin'] ?? $data['tax_settings']['tax_identification_number'] ?? $data['tax_identification_number'] ?? ''));
        if ($taxTin !== '') {
            $employeeUpdate['tax_identification_number'] = $taxTin;
        }

        $rawPfInput = $data['pf_settings']['eligible'] ?? $data['pf_settings']['is_eligible'] ?? $data['pf_eligible'] ?? null;
        if ($rawPfInput !== null) {
            $currentPfApplicable = (int)($employee['is_pf_applicable'] ?? 0);
            $currentPfStatus = $employee['pf_status'] ?? ($currentPfApplicable === 1 ? 'Enrolled' : 'Not Enrolled');
            $newPfApplicable = (bool)$rawPfInput ? 1 : 0;
            $newPfStatus = $newPfApplicable ? 'Enrolled' : 'Not Enrolled';
            if ($newPfApplicable !== $currentPfApplicable || $newPfStatus !== $currentPfStatus) {
                $employeeUpdate['is_pf_applicable'] = $newPfApplicable;
                $employeeUpdate['pf_status']        = $newPfStatus;
            }
        }

        \App\Models\EmployeeModel::withSalarySync(function() use ($employeeId, $employeeUpdate) {
            $this->empModel->update($employeeId, $employeeUpdate);
        });

        if (isset($employeeUpdate['is_pf_applicable'])) {
            try {
                $pfEligibilityService = new \App\Services\Pf\PfEligibilityService();
                $pfEligibilityService->changeEligibility(
                    (string)($employee['company_id'] ?? $companyId),
                    (string)$employeeId,
                    $employeeUpdate['is_pf_applicable'] ? 'Eligible' : 'Not Eligible',
                    $effectiveFrom ?: date('Y-m-d'),
                    null,
                    $employeeUpdate['is_pf_applicable'] ? null : 'Updated via salary structure assignment',
                    $employee['pf_member_id'] ?? null,
                    $actor['id'] ?? null,
                    $data['notes'] ?? null
                );
            } catch (\Throwable $e) {
                log_message('error', "PF changeEligibility in EmployeeSalaryService failed for employee {$employeeId}: " . $e->getMessage());
            }
        }

        // Log salary revision history with complete serialized snapshot
        $revisionType = $previousGross > 0 ? ($grossSalary > $previousGross ? 'Increment' : 'Adjustment') : 'Initial Assignment';
        $this->revisionModel->insert([
            'id'                      => 'rev-' . bin2hex(random_bytes(8)),
            'company_id'              => $employee['company_id'] ?? $companyId,
            'employee_id'             => $employeeId,
            'revision_type'           => $revisionType,
            'effective_date'          => $effectiveFrom,
            'previous_basic'          => $previousBasic,
            'new_basic'               => $basicSalary,
            'previous_gross'          => $previousGross,
            'new_gross'               => $grossSalary,
            'total_arrear_calculated' => 0.00,
            'remarks'                 => $data['notes'] ?? ($previousGross > 0 ? 'Salary Structure Update' : 'Initial Salary Structure Assignment'),
            'snapshot_json'           => json_encode($prevSnapshot ?: $snapshot),
            'status'                  => 'Approved',
            'approved_by'             => $actor['name'] ?? $actor['id'] ?? 'HR Admin',
            'created_at'              => date('Y-m-d H:i:s'),
            'updated_at'              => date('Y-m-d H:i:s')
        ]);

        $db->transComplete();

        if ($db->transStatus() === false) {
            return [
                'success' => false,
                'status'  => 500,
                'message' => 'Database transaction failed while saving employee salary structure.'
            ];
        }

        // Audit Trail
        try {
            $this->auditService->log(
                $actor['id'] ?? 'admin',
                'SALARY_STRUCTURE_ASSIGNMENT',
                'employee_salaries',
                $newSalaryId,
                "Configured salary structure for {$employee['employee_code']} ({$employee['first_name']} {$employee['last_name']}): Basic \${$basicSalary}, Gross \${$grossSalary}, Net \${$netSalary}, Effective {$effectiveFrom}",
                ['company_id' => $employee['company_id'] ?? $companyId]
            );
        } catch (\Throwable $e) {
            log_message('warning', 'Audit log failed: ' . $e->getMessage());
        }

        return [
            'success'          => true,
            'status'           => 200,
            'message'          => "Salary structure successfully configured and assigned for {$employee['first_name']} {$employee['last_name']}.",
            'salary_id'        => $newSalaryId,
            'basic_salary'     => $basicSalary,
            'gross_salary'     => $grossSalary,
            'total_deductions' => $totalDeductions,
            'net_salary'       => $netSalary,
            'ctc'              => $ctc,
            'salary_status'    => 'CONFIGURED',
            'components'       => $snapshot,
            'warning'          => $gradeWarning,
            'warnings'         => $gradeWarning ? [$gradeWarning] : [],
        ];
    }

    /**
     * Re-sync employee salary structure with master template:
     * - Fetches current active salary structure and master template
     * - Re-maps components from the master template using employee's basic salary
     * - Captures complete previous structure as an EmployeeSalarySnapshot and archives it
     * - Replaces employee's customized components with fresh template components
     * - Performs transactional recalculation and assignment
     * - Mirrors EmployeeSalaryStructureView.tsx handleConfirmResync logic
     */
    public function resyncSalaryStructure(string $employeeId, array $data, string $companyId, array $actor): array
    {
        // 1. RBAC Check
        if (!$this->isAuthorizedRole($actor, $employeeId)) {
            return [
                'success' => false,
                'status'  => 403,
                'message' => '403 Forbidden: You do not have permission to modify employee salary structure.'
            ];
        }

        // 2. Fetch Employee & Scoping
        $employee = $this->empModel->find($employeeId);
        if (!$employee) {
            return [
                'success' => false,
                'status'  => 404,
                'message' => "Employee not found: {$employeeId}"
            ];
        }

        $actorRole = strtolower(trim((string)($actor['role_code'] ?? $actor['role_name'] ?? $actor['role'] ?? '')));
        if ($actorRole !== 'software_app_admin' && !empty($employee['company_id']) && $employee['company_id'] !== $companyId) {
            return [
                'success' => false,
                'status'  => 403,
                'message' => '403 Forbidden: Tenant isolation violation. Cannot modify salary for an employee belonging to another company.'
            ];
        }

        // 3. Resolve Active Salary and Target Template
        $activeSalary = $this->salaryModel
            ->where('employee_id', $employeeId)
            ->where('status', 'Active')
            ->orderBy('effective_from', 'DESC')
            ->first();

        $templateId = trim((string)($data['structure_id'] ?? $data['companyRuleId'] ?? ($activeSalary['structure_id'] ?? '')));
        if (empty($templateId) || $templateId === 'CUSTOM') {
            // Try to find default active company template
            $empComp = $employee['company_id'] ?? $companyId;
            $defaultTemplate = $this->structureModel
                ->where('company_id', $empComp)
                ->where('status', 'Active')
                ->first();
            if ($defaultTemplate) {
                $templateId = $defaultTemplate['id'];
            }
        }

        if (empty($templateId)) {
            return [
                'success' => false,
                'status'  => 400,
                'message' => 'No master salary structure template found to re-sync with.'
            ];
        }

        $template = $this->structureModel->find($templateId);
        if (!$template) {
            return [
                'success' => false,
                'status'  => 404,
                'message' => "Master salary structure template '{$templateId}' not found."
            ];
        }

        // 4. Resolve Basic Salary
        $resolvedBasic = $data['basic_salary'] ?? $data['basicSalary'] ?? ($activeSalary['basic_salary'] ?? ($employee['basic_salary'] ?? ($template['default_basic_salary'] ?? null)));
        if ($resolvedBasic === null || $resolvedBasic === '') {
            $empName = trim(($employee['first_name'] ?? '') . ' ' . ($employee['last_name'] ?? ''));
            $empLabel = !empty($empName) ? "{$empName} ({$employeeId})" : $employeeId;
            $empComp = $employee['company_id'] ?? $companyId;
            throw new RuleNotConfiguredException(
                "Basic salary not configured for employee '{$empLabel}' in company '{$empComp}'.",
                (string)$empComp,
                'PAYROLL_BASICS'
            );
        }
        $baseVal = max(0.0, (float)$resolvedBasic);

        // 5. Fetch Template Items and Map Fresh Components
        $templateItems = $this->structureItemModel
            ->where('structure_id', $template['id'])
            ->orderBy('sort_order', 'ASC')
            ->findAll();

        $freshComponents = [];
        foreach ($templateItems as $ti) {
            $compDef = $this->componentModel->find($ti['component_id']);
            if (!$compDef) {
                continue;
            }

            $calcType = $ti['calculation_type'] ?? $compDef['calculation_type'] ?? 'fixed';
            $calcBase = $ti['calculation_base'] ?? $compDef['calculation_base'] ?? 'Basic Salary';
            $rawRate = (float)($ti['default_value'] ?? $ti['percentage'] ?? $compDef['amount'] ?? 0);
            $rateOrAmount = in_array($calcType, ['percentage', 'percent_basic', 'percent_gross'], true) ? normalize_percentage($rawRate) : $rawRate;
            $formula = $ti['custom_formula'] ?? $compDef['formula'] ?? null;

            $freshComponents[] = [
                'component_id'         => $compDef['id'],
                'componentId'          => $compDef['id'],
                'code'                 => $compDef['code'],
                'name'                 => $compDef['name'],
                'type'                 => $compDef['type'],
                'calculation_type'     => $calcType,
                'calculationType'      => $calcType,
                'calculation_base'     => $calcBase,
                'calculationBase'      => $calcBase,
                'rate_or_amount'       => $rateOrAmount,
                'rateOrAmount'         => $rateOrAmount,
                'custom_formula'       => $formula,
                'formula'              => $formula,
                'is_enabled'           => (bool)($ti['is_enabled'] ?? 1),
                'isEnabled'            => (bool)($ti['is_enabled'] ?? 1),
                'is_overridden'        => false,
                'isOverridden'         => false,
                'is_included_in_gross' => (bool)($ti['is_included_in_gross'] ?? $compDef['is_included_in_gross'] ?? 1),
                'is_included_in_ctc'   => (bool)($ti['is_included_in_ctc'] ?? $compDef['is_included_in_ctc'] ?? 1),
                'is_taxable'           => (bool)($ti['is_taxable'] ?? $compDef['is_taxable'] ?? 1),
                'is_statutory'         => (bool)($ti['is_statutory'] ?? $compDef['is_statutory'] ?? 0),
            ];
        }

        // 6. Build Assign Payload
        $effectiveFrom = trim((string)($data['effective_from'] ?? ''));
        if (empty($effectiveFrom) || !strtotime($effectiveFrom)) {
            $effectiveFrom = date('Y-m-d');
        }

        $assignPayload = [
            'basic_salary'         => $baseVal,
            'effective_from'       => $effectiveFrom,
            'structure_id'         => $template['id'],
            'structure_name'       => $template['name'],
            'is_custom'            => false,
            'components'           => $freshComponents,
            'pf_settings'          => $data['pf_settings'] ?? null,
            'tax_settings'         => $data['tax_settings'] ?? null,
            'notes'                => "Re-synced with master template '{$template['name']}'",
            'is_resync'            => true,
        ];

        return $this->assignSalary($employeeId, $assignPayload, $companyId, $actor);
    }

    protected static array $salaryCache = [];

    public static function clearSalaryCache(): void
    {
        self::$salaryCache = [];
    }

    /**
     * Preload active salary records for multiple employees into memory cache
     */
    public function preloadActiveSalaries(array $employeeIds, ?string $asOfDate = null): void
    {
        $date = !empty($asOfDate) ? substr(trim((string)$asOfDate), 0, 10) : date('Y-m-d');
        if (empty($employeeIds)) {
            return;
        }
        $uncached = [];
        $employeeObjMap = [];
        foreach ($employeeIds as $item) {
            if (is_array($item)) {
                $eid = trim((string)($item['id'] ?? ''));
                if ($eid !== '') {
                    $employeeObjMap[$eid] = $item;
                }
                $ecode = trim((string)($item['employee_code'] ?? ''));
                if ($ecode !== '') {
                    $employeeObjMap[$ecode] = $item;
                }
            } else {
                $eid = trim((string)$item);
            }
            if ($eid !== '' && !array_key_exists($eid . '|' . $date, self::$salaryCache)) {
                $uncached[] = $eid;
            }
        }
        $uncached = array_values(array_unique($uncached));
        if (empty($uncached)) {
            return;
        }

        try {
            $records = [];
            if ($this->db->tableExists('employee_salaries')) {
                $records = $this->salaryModel
                    ->whereIn('employee_id', $uncached)
                    ->groupStart()
                        ->where('status', 'Active')
                        ->orWhere('status', 'Revised')
                    ->groupEnd()
                    ->where('effective_from <=', $date)
                    ->groupStart()
                        ->where('effective_to IS NULL')
                        ->orWhere('effective_to >=', $date)
                    ->groupEnd()
                    ->orderBy('effective_from', 'DESC')
                    ->orderBy('created_at', 'DESC')
                    ->findAll();
            }

            $seen = [];
            foreach ($records as $record) {
                $eid = (string)($record['employee_id'] ?? '');
                if ($eid !== '' && !isset($seen[$eid])) {
                    $seen[$eid] = $record;
                }
            }

            $missingIds = [];
            foreach ($uncached as $eid) {
                if (isset($seen[$eid])) {
                    $record = $seen[$eid];
                    $snapshot = [];
                    if (!empty($record['custom_components_json'])) {
                        $decoded = json_decode($record['custom_components_json'], true);
                        if (is_array($decoded)) {
                            $snapshot = $decoded;
                        }
                    }
                    $basic = (float)($record['basic_salary'] ?? $snapshot['basic_salary'] ?? 0);
                    $gross = (float)($record['gross_salary'] ?? $snapshot['gross_salary'] ?? 0);
                    $deductions = (float)($record['total_deductions'] ?? $snapshot['total_deductions'] ?? 0);
                    $net = (float)($record['net_salary'] ?? $snapshot['net_salary'] ?? max(0, $gross - $deductions));
                    $ctc = (float)($record['ctc'] ?? $snapshot['ctc'] ?? $gross);

                    $cachedData = [
                        'id'               => $record['id'] ?? '',
                        'employee_id'      => $eid,
                        'structure_id'     => $record['structure_id'] ?? null,
                        'structure_name'   => 'Salary Structure',
                        'currency'         => $record['currency'] ?? 'BDT',
                        'basic_salary'     => $basic,
                        'gross_salary'     => $gross,
                        'total_deductions' => $deductions,
                        'net_salary'       => $net,
                        'ctc'              => $ctc,
                        'effective_from'   => $record['effective_from'] ?? $date,
                        'effective_to'     => $record['effective_to'] ?? null,
                        'status'           => $record['status'] ?? 'Active',
                        'components'       => $snapshot,
                        'earnings'         => $snapshot['earnings'] ?? [],
                        'deductions'       => $snapshot['deductions'] ?? [],
                    ];
                    self::$salaryCache[$eid . '|' . $date] = $cachedData;
                    if (!isset(self::$salaryCache[$eid])) {
                        self::$salaryCache[$eid] = $cachedData;
                    }
                } else {
                    $missingIds[] = $eid;
                }
            }

            // Batch preload fallback employee records to eliminate per-employee fallback lookups
            if (!empty($missingIds)) {
                $missingToQuery = [];
                $fallbackMap = [];
                foreach ($missingIds as $mid) {
                    if (isset($employeeObjMap[$mid])) {
                        $fallbackMap[$mid] = $employeeObjMap[$mid];
                    } else {
                        $missingToQuery[] = $mid;
                    }
                }

                if (!empty($missingToQuery)) {
                    try {
                        $fallbackEmps = $this->empModel->whereIn('id', $missingToQuery)->findAll();
                        foreach ($fallbackEmps as $fe) {
                            $fallbackMap[(string)($fe['id'] ?? '')] = $fe;
                        }
                    } catch (\Throwable $e) {}
                }

                foreach ($missingIds as $mid) {
                    $cacheKey = $mid . '|' . $date;
                    if (isset($fallbackMap[$mid])) {
                        $employee = $fallbackMap[$mid];
                        $basic = (float)($employee['basic_salary'] ?? 0);
                        $gross = (float)($employee['gross_salary'] ?? 0);

                        if (($employee['salary_status'] ?? '') === 'NOT_CONFIGURED' || ($basic <= 0 && $gross <= 0)) {
                            self::$salaryCache[$cacheKey] = null;
                            if (!isset(self::$salaryCache[$mid])) {
                                self::$salaryCache[$mid] = null;
                            }
                            continue;
                        }

                        $houseRent = (float)($employee['house_rent_allowance'] ?? 0);
                        $medical = (float)($employee['medical_allowance'] ?? 0);
                        $conveyance = (float)($employee['conveyance_allowance'] ?? $employee['transport_allowance'] ?? 0);
                        $other = (float)($employee['other_allowances'] ?? 0);
                        if ($gross <= 0) {
                            $gross = $basic + $houseRent + $medical + $conveyance + $other;
                        }

                        $fallbackEarnings = [];
                        if ($basic > 0) {
                            $fallbackEarnings[] = ['code' => 'BASIC', 'name' => 'Basic Salary', 'amount' => $basic, 'type' => 'earning'];
                        }
                        if ($houseRent > 0) {
                            $fallbackEarnings[] = ['code' => 'HRA', 'name' => 'House Rent Allowance (HRA)', 'amount' => $houseRent, 'type' => 'earning'];
                        }
                        if ($medical > 0) {
                            $fallbackEarnings[] = ['code' => 'MED', 'name' => 'Medical Allowance', 'amount' => $medical, 'type' => 'earning'];
                        }
                        if ($conveyance > 0) {
                            $fallbackEarnings[] = ['code' => 'CONV', 'name' => 'Conveyance Allowance', 'amount' => $conveyance, 'type' => 'earning'];
                        }
                        if ($other > 0) {
                            $fallbackEarnings[] = ['code' => 'OTHER', 'name' => 'Other Allowances', 'amount' => $other, 'type' => 'earning'];
                        }

                        $fallbackData = [
                            'id'             => 'legacy-' . $mid,
                            'employee_id'    => $mid,
                            'structure_id'   => null,
                            'structure_name' => 'Standard Salary Structure',
                            'currency'       => 'BDT',
                            'basic_salary'   => $basic,
                            'gross_salary'   => $gross,
                            'total_deductions' => 0.00,
                            'net_salary'     => $gross,
                            'ctc'            => $gross,
                            'effective_from' => employee_joining_date($employee) ?? date('Y-m-d'),
                            'effective_to'   => null,
                            'status'         => 'Active',
                            'components'     => [
                                'basic_salary'     => $basic,
                                'house_rent'       => $houseRent,
                                'medical'          => $medical,
                                'conveyance'       => $conveyance,
                                'other_allowances' => $other,
                                'gross_salary'     => $gross
                            ],
                            'earnings'       => $fallbackEarnings,
                            'deductions'     => [],
                            'employer_contributions' => [],
                            'all_components' => $fallbackEarnings
                        ];
                        self::$salaryCache[$cacheKey] = $fallbackData;
                        if (!isset(self::$salaryCache[$mid])) {
                            self::$salaryCache[$mid] = $fallbackData;
                        }
                        $midCode = trim((string)($employee['employee_code'] ?? ''));
                        if ($midCode !== '') {
                            self::$salaryCache[$midCode . '|' . $date] = $fallbackData;
                            if (!isset(self::$salaryCache[$midCode])) {
                                self::$salaryCache[$midCode] = $fallbackData;
                            }
                        }
                    } else {
                        self::$salaryCache[$cacheKey] = null;
                        if (!isset(self::$salaryCache[$mid])) {
                            self::$salaryCache[$mid] = null;
                        }
                    }
                }
            }
        } catch (\Throwable $e) {
            // Guarantee all uncached IDs are registered as null to prevent falling through to N+1 queries
            foreach ($uncached as $eid) {
                if (!array_key_exists($eid . '|' . $date, self::$salaryCache)) {
                    self::$salaryCache[$eid . '|' . $date] = null;
                }
            }
        }
    }

    /**
     * Recalculates PF components for the active salary in-place without creating a new revision.
     * Keeps Salary tab in sync with the Provident Fund configuration.
     *
     * @param string $employeeId
     * @return bool
     */
    public function recalculatePfForActiveSalary(string $employeeId): bool
    {
        $employee = $this->empModel->find($employeeId);
        if (!$employee) {
            return false;
        }

        $activeSalary = $this->salaryModel
            ->where('employee_id', $employeeId)
            ->where('status', 'Active')
            ->first();

        if (!$activeSalary) {
            return true;
        }

        $isPfEligible = ((int)($employee['is_pf_applicable'] ?? 0) === 1) && (($employee['pf_status'] ?? 'Enrolled') === 'Enrolled');

        $snapshot = [];
        if (!empty($activeSalary['custom_components_json'])) {
            $decoded = json_decode($activeSalary['custom_components_json'], true);
            if (is_array($decoded)) {
                $snapshot = $decoded;
            }
        }

        $basic = (float)($activeSalary['basic_salary'] ?? $employee['basic_salary'] ?? 0);
        $gross = (float)($activeSalary['gross_salary'] ?? $employee['gross_salary'] ?? $basic);

        $empDeduction = 0.0;
        $erContribution = 0.0;

        if ($isPfEligible && $gross > 0) {
            try {
                $pfCalc = new PfCalculator();
                $empPfEarnings = [
                    'Basic'        => $basic,
                    'Basic_Salary' => $basic,
                    'Gross'        => $gross,
                    'Gross_Salary' => $gross,
                ];
                if (!empty($snapshot['earnings']) && is_array($snapshot['earnings'])) {
                    foreach ($snapshot['earnings'] as $ea) {
                        $cCode = trim((string)($ea['component_code'] ?? $ea['code'] ?? ''));
                        if ($cCode !== '') $empPfEarnings[$cCode] = (float)($ea['amount'] ?? 0.0);
                        $cName = trim((string)($ea['name'] ?? $ea['component_name'] ?? ''));
                        if ($cName !== '') $empPfEarnings[$cName] = (float)($ea['amount'] ?? 0.0);
                    }
                }

                $pfRes = $pfCalc->calculate([
                    'company_id'     => $employee['company_id'],
                    'employee'       => $employee,
                    'effective_date' => date('Y-m-d'),
                    'earnings'       => $empPfEarnings,
                ]);

                $empDeduction = (float)($pfRes['employee_deduction'] ?? 0.0);
                $erContribution = (float)($pfRes['employer_contribution'] ?? 0.0);
            } catch (\InvalidArgumentException $e) {
                log_message('error', "recalculatePfForActiveSalary PF formula error: " . $e->getMessage());
                throw $e;
            } catch (\Throwable $e) {
                log_message('warning', "recalculatePfForActiveSalary calculate error: " . $e->getMessage());
            }
        }

        // Update deductions array
        $deductions = is_array($snapshot['deductions'] ?? null) ? $snapshot['deductions'] : [];
        $pfFound = false;
        foreach ($deductions as $idx => &$d) {
            $c = strtoupper(trim((string)($d['code'] ?? '')));
            $n = strtolower(trim((string)($d['name'] ?? '')));
            if ($c === 'PF' || str_contains($n, 'provident fund')) {
                $pfFound = true;
                if ($isPfEligible) {
                    $d['amount'] = $empDeduction;
                } else {
                    unset($deductions[$idx]);
                }
            }
        }
        unset($d);

        if (!$pfFound && $isPfEligible && $empDeduction > 0) {
            $deductions[] = [
                'component_id'        => 'comp-stat-pf',
                'name'                => 'Provident Fund',
                'component_name'      => 'Provident Fund',
                'code'                => 'PF',
                'component_code'      => 'PF',
                'type'                => 'deduction',
                'calculation_type'    => 'rule',
                'amount'              => $empDeduction,
                'rate_percentage'     => null,
                'is_taxable'          => 0,
                'include_in_pf_basis' => 0,
            ];
        }
        $snapshot['deductions'] = array_values($deductions);

        // Update employer contributions array
        $erContribs = is_array($snapshot['employer_contributions'] ?? null) ? $snapshot['employer_contributions'] : [];
        $erPfFound = false;
        foreach ($erContribs as $idx => &$ec) {
            $c = strtoupper(trim((string)($ec['code'] ?? '')));
            $n = strtolower(trim((string)($ec['name'] ?? '')));
            if ($c === 'ER_PF' || str_contains($n, 'provident fund') || str_contains($n, 'er pf')) {
                $erPfFound = true;
                if ($isPfEligible) {
                    $ec['amount'] = $erContribution;
                } else {
                    unset($erContribs[$idx]);
                }
            }
        }
        unset($ec);

        if (!$erPfFound && $isPfEligible && $erContribution > 0) {
            $erContribs[] = [
                'component_id'        => 'comp-stat-er-pf',
                'name'                => 'Employer PF Contribution',
                'component_name'      => 'Employer PF Contribution',
                'code'                => 'ER_PF',
                'component_code'      => 'ER_PF',
                'type'                => 'employer_contribution',
                'calculation_type'    => 'rule',
                'amount'              => $erContribution,
                'rate_percentage'     => null,
                'is_taxable'          => 0,
                'include_in_pf_basis' => 0,
            ];
        }
        $snapshot['employer_contributions'] = array_values($erContribs);

        // Update pf_settings in snapshot
        $snapshot['pf_settings'] = [
            'eligible'        => $isPfEligible,
            'is_eligible'     => $isPfEligible,
            'status'          => $employee['pf_status'] ?? ($isPfEligible ? 'Enrolled' : 'Not Enrolled'),
            'member_id'       => $employee['pf_member_id'] ?? '',
            'employee_amount' => $empDeduction,
            'employer_amount' => $erContribution,
        ];

        // Recalculate totals
        $totDeductions = 0.0;
        foreach ($snapshot['deductions'] as $d) {
            $totDeductions += (float)($d['amount'] ?? 0);
        }
        $totDeductions = round($totDeductions, 2);
        $netSalary = round(max(0, $gross - $totDeductions), 2);

        $totEr = 0.0;
        foreach ($snapshot['employer_contributions'] as $ec) {
            $totEr += (float)($ec['amount'] ?? 0);
        }
        $ctc = round($gross + $totEr, 2);

        $snapshot['total_deductions'] = $totDeductions;
        $snapshot['net_salary'] = $netSalary;
        $snapshot['ctc'] = $ctc;

        // In-place update to employee_salaries without changing version or history
        $this->salaryModel->update($activeSalary['id'], [
            'total_deductions'       => $totDeductions,
            'net_salary'             => $netSalary,
            'ctc'                    => $ctc,
            'custom_components_json' => json_encode($snapshot),
            'updated_at'             => date('Y-m-d H:i:s'),
        ]);

        // Mirror cached fields to employee record
        try {
            $this->empModel->update($employeeId, [
                'net_salary' => $netSalary,
                'ctc'        => $ctc,
            ]);
        } catch (\Throwable $e) {}

        // Invalidate in-memory salary caches
        self::$salaryCache = [];

        return true;
    }

    /**
     * Get active salary record for an employee as of a specific date
     * Reads strictly the snapshot effective for that date to guarantee payroll isolation
     */
    public function getActiveSalary(string $employeeId, ?string $asOfDate = null): ?array
    {
        $date = !empty($asOfDate) ? substr(trim((string)$asOfDate), 0, 10) : date('Y-m-d');
        $cleanId = trim((string)$employeeId);
        $cacheKey = $cleanId . '|' . $date;
        if (array_key_exists($cacheKey, self::$salaryCache)) {
            return self::$salaryCache[$cacheKey];
        }
        if (array_key_exists($cleanId, self::$salaryCache)) {
            return self::$salaryCache[$cacheKey] = self::$salaryCache[$cleanId];
        }

        $record = $this->salaryModel
            ->where('employee_id', $employeeId)
            ->groupStart()
                ->where('status', 'Active')
                ->orWhere('status', 'Revised')
            ->groupEnd()
            ->where('effective_from <=', $date)
            ->groupStart()
                ->where('effective_to IS NULL')
                ->orWhere('effective_to >=', $date)
            ->groupEnd()
            ->orderBy('effective_from', 'DESC')
            ->orderBy('created_at', 'DESC')
            ->first();

        if ($record) {
            $snapshot = [];
            if (!empty($record['custom_components_json'])) {
                $decoded = json_decode($record['custom_components_json'], true);
                if (is_array($decoded)) {
                    $snapshot = $decoded;
                }
            }

            $basic = (float)($record['basic_salary'] ?? $snapshot['basic_salary'] ?? 0);
            $gross = (float)($record['gross_salary'] ?? $snapshot['gross_salary'] ?? 0);
            $deductions = (float)($record['total_deductions'] ?? $snapshot['total_deductions'] ?? 0);
            $net = (float)($record['net_salary'] ?? $snapshot['net_salary'] ?? max(0, $gross - $deductions));
            $ctc = (float)($record['ctc'] ?? $snapshot['ctc'] ?? $gross);

            // Populate legacy components map
            $componentsMap = $snapshot;
            if (empty($componentsMap['house_rent']) && !empty($snapshot['earnings'])) {
                foreach ($snapshot['earnings'] as $ea) {
                    $code = strtoupper($ea['code'] ?? '');
                    if ($code === 'HRA' || stripos($ea['name'] ?? '', 'house rent') !== false) {
                        $componentsMap['house_rent'] = (float)$ea['amount'];
                    } elseif ($code === 'MED' || stripos($ea['name'] ?? '', 'medical') !== false) {
                        $componentsMap['medical'] = (float)$ea['amount'];
                    } elseif ($code === 'CONV' || stripos($ea['name'] ?? '', 'transport') !== false) {
                        $componentsMap['conveyance'] = (float)$ea['amount'];
                    }
                }
            }

            // Resolve structure name
            $structureName = $snapshot['structure_name'] ?? null;
            if (empty($structureName) && !empty($record['structure_id']) && $record['structure_id'] !== 'CUSTOM') {
                $st = $this->structureModel->find($record['structure_id']);
                if ($st) {
                    $structureName = $st['name'] ?? null;
                }
            }
            if (empty($structureName)) {
                $structureName = !empty($record['structure_id']) && $record['structure_id'] === 'CUSTOM'
                    ? 'Individual Custom Structure'
                    : 'Standard Salary Structure';
            }

            // Ensure earnings breakdown is rich
            $earnings = $snapshot['earnings'] ?? [];
            if (empty($earnings)) {
                if (!empty($record['structure_id']) && $record['structure_id'] !== 'CUSTOM') {
                    $stItems = $this->structureItemModel
                        ->where('structure_id', $record['structure_id'])
                        ->orderBy('sort_order', 'ASC')
                        ->findAll();
                    foreach ($stItems as $si) {
                        $compDef = $this->componentModel->find($si['component_id']);
                        if ($compDef && ($compDef['type'] ?? 'earning') === 'earning') {
                            $calcType = $si['calculation_type'] ?? $compDef['calculation_type'] ?? 'fixed';
                            $val = (float)($si['default_value'] ?? $si['percentage'] ?? $compDef['amount'] ?? 0);
                            $amt = $val;
                            if ($calcType === 'percentage') {
                                $pct = normalize_percentage($val);
                                $amt = round($basic * ($pct / 100), 2);
                            }
                            $earnings[] = [
                                'component_id'     => $si['component_id'],
                                'code'             => $compDef['code'] ?? '',
                                'name'             => $compDef['name'] ?? 'Allowance',
                                'type'             => 'earning',
                                'calculation_type' => $calcType,
                                'amount'           => $amt,
                                'is_enabled'       => true,
                            ];
                        }
                    }
                }
                if (empty($earnings)) {
                    if ($basic > 0) {
                        $earnings[] = ['code' => 'BASIC', 'name' => 'Basic Salary', 'amount' => $basic, 'type' => 'earning'];
                    }
                    $hr = (float)($componentsMap['house_rent'] ?? 0);
                    if ($hr > 0) {
                        $earnings[] = ['code' => 'HRA', 'name' => 'House Rent Allowance (HRA)', 'amount' => $hr, 'type' => 'earning'];
                    }
                    $med = (float)($componentsMap['medical'] ?? 0);
                    if ($med > 0) {
                        $earnings[] = ['code' => 'MED', 'name' => 'Medical Allowance', 'amount' => $med, 'type' => 'earning'];
                    }
                    $conv = (float)($componentsMap['conveyance'] ?? 0);
                    if ($conv > 0) {
                        $earnings[] = ['code' => 'CONV', 'name' => 'Conveyance Allowance', 'amount' => $conv, 'type' => 'earning'];
                    }
                    $other = (float)($componentsMap['other_allowances'] ?? 0);
                    if ($other > 0) {
                        $earnings[] = ['code' => 'OTHER', 'name' => 'Other / Special Allowance', 'amount' => $other, 'type' => 'earning'];
                    }
                }
            }

            // Ensure deductions breakdown is rich
            $deductionsList = $snapshot['deductions'] ?? [];
            if (empty($deductionsList) && !empty($record['structure_id']) && $record['structure_id'] !== 'CUSTOM') {
                $stItems = $this->structureItemModel
                    ->where('structure_id', $record['structure_id'])
                    ->orderBy('sort_order', 'ASC')
                    ->findAll();
                foreach ($stItems as $si) {
                    $compDef = $this->componentModel->find($si['component_id']);
                    if ($compDef && ($compDef['type'] ?? '') === 'deduction') {
                        $calcType = $si['calculation_type'] ?? $compDef['calculation_type'] ?? 'fixed';
                        $val = (float)($si['default_value'] ?? $si['percentage'] ?? $compDef['amount'] ?? 0);
                        $amt = $val;
                        if ($calcType === 'percentage') {
                            $pct = normalize_percentage($val);
                            $amt = round($basic * ($pct / 100), 2);
                        }
                        $deductionsList[] = [
                            'component_id'     => $si['component_id'],
                            'code'             => $compDef['code'] ?? '',
                            'name'             => $compDef['name'] ?? 'Deduction',
                            'type'             => 'deduction',
                            'calculation_type' => $calcType,
                            'amount'           => $amt,
                            'is_enabled'       => true,
                        ];
                    }
                }
            }

            $res = [
                'id'                           => $record['id'],
                'employee_id'                  => $record['employee_id'],
                'structure_id'                 => $record['structure_id'],
                'structure_name'               => $structureName,
                'basic_salary'                 => $basic,
                'gross_salary'                 => $gross,
                'total_deductions'             => $deductions,
                'net_salary'                   => $net,
                'ctc'                          => $ctc,
                'effective_from'               => $record['effective_from'],
                'effective_to'                 => $record['effective_to'],
                'status'                       => $record['status'],
                'components'                   => $componentsMap,
                'earnings'                     => $earnings,
                'deductions'                   => $deductionsList,
                'employer_contributions'       => $snapshot['employer_contributions'] ?? [],
                'all_components'               => $snapshot['all_components'] ?? [],
                'is_custom'                    => empty($record['structure_id']) || $record['structure_id'] === 'CUSTOM' || (!empty($snapshot['is_custom'])),
                'isCustom'                     => empty($record['structure_id']) || $record['structure_id'] === 'CUSTOM' || (!empty($snapshot['is_custom'])),
                'version'                      => (int)($snapshot['version'] ?? $snapshot['snapshot_version'] ?? 1),
                'snapshot_version'             => (int)($snapshot['version'] ?? $snapshot['snapshot_version'] ?? 1),
                'history_snapshots'            => $snapshot['history_snapshots'] ?? $snapshot['historySnapshots'] ?? [],
                'historySnapshots'             => $snapshot['history_snapshots'] ?? $snapshot['historySnapshots'] ?? [],
                'pf_settings'                  => $snapshot['pf_settings'] ?? null,
                'tax_settings'                 => $snapshot['tax_settings'] ?? [
                    'category'         => $snapshot['tax_category'] ?? $snapshot['category'] ?? 'General',
                    'tin'              => $snapshot['tax_identification_number'] ?? $snapshot['tin'] ?? '',
                    'calculation_mode' => 'Auto',
                    'is_override'      => false,
                    'override_reason'  => '',
                    'custom_tax_amount'=> 0.0,
                ],
                'notes'                        => $snapshot['notes'] ?? null,
            ];
            return self::$salaryCache[$cacheKey] = $res;
        }

        // Fallback check on employee record (for unmigrated legacy records)
        $employee = $this->empModel->find($employeeId);
        if (!$employee) {
            self::$salaryCache[$cacheKey] = null;
            return null;
        }

        $basic = (float)($employee['basic_salary'] ?? 0);
        $gross = (float)($employee['gross_salary'] ?? 0);

        if (($employee['salary_status'] ?? '') === 'NOT_CONFIGURED' || ($basic <= 0 && $gross <= 0)) {
            self::$salaryCache[$cacheKey] = null;
            return null;
        }

        $houseRent = (float)($employee['house_rent_allowance'] ?? 0);
        $medical = (float)($employee['medical_allowance'] ?? 0);
        $conveyance = (float)($employee['conveyance_allowance'] ?? $employee['transport_allowance'] ?? 0);
        $other = (float)($employee['other_allowances'] ?? 0);
        if ($gross <= 0) {
            $gross = $basic + $houseRent + $medical + $conveyance + $other;
        }

        $fallbackEarnings = [];
        if ($basic > 0) {
            $fallbackEarnings[] = ['code' => 'BASIC', 'name' => 'Basic Salary', 'amount' => $basic, 'type' => 'earning'];
        }
        if ($houseRent > 0) {
            $fallbackEarnings[] = ['code' => 'HRA', 'name' => 'House Rent Allowance (HRA)', 'amount' => $houseRent, 'type' => 'earning'];
        }
        if ($medical > 0) {
            $fallbackEarnings[] = ['code' => 'MED', 'name' => 'Medical Allowance', 'amount' => $medical, 'type' => 'earning'];
        }
        if ($conveyance > 0) {
            $fallbackEarnings[] = ['code' => 'CONV', 'name' => 'Conveyance Allowance', 'amount' => $conveyance, 'type' => 'earning'];
        }
        if ($other > 0) {
            $fallbackEarnings[] = ['code' => 'OTHER', 'name' => 'Other Allowances', 'amount' => $other, 'type' => 'earning'];
        }

        $res = [
            'id'             => 'legacy-' . $employeeId,
            'employee_id'    => $employeeId,
            'structure_id'   => null,
            'structure_name' => 'Standard Salary Structure',
            'basic_salary'   => $basic,
            'gross_salary'   => $gross,
            'total_deductions' => 0.00,
            'net_salary'     => $gross,
            'ctc'            => $gross,
            'effective_from' => employee_joining_date($employee) ?? date('Y-m-d'),
            'effective_to'   => null,
            'status'         => 'Active',
            'components'     => [
                'basic_salary'     => $basic,
                'house_rent'       => $houseRent,
                'medical'          => $medical,
                'conveyance'       => $conveyance,
                'other_allowances' => $other,
                'gross_salary'     => $gross
            ],
            'earnings'       => $fallbackEarnings,
            'deductions'     => [],
            'employer_contributions' => [],
            'all_components' => $fallbackEarnings
        ];
        return self::$salaryCache[$cacheKey] = $res;
    }

    /**
     * Check if an employee is payroll eligible for a given period
     * Does NOT require mandatory basic salary - valid as long as configured gross salary > 0
     */
    public function isPayrollEligible(string $employeeId, string $periodMonth): array
    {
        $employee = $this->empModel->find($employeeId);
        if (!$employee) {
            return [
                'eligible' => false,
                'reason'   => "Employee record not found: {$employeeId}"
            ];
        }

        if (strtolower((string)($employee['status'] ?? '')) !== 'active') {
            return [
                'eligible' => false,
                'reason'   => "Employee status is not active ({$employee['status']})"
            ];
        }

        // Period end date
        $monthEnd = date('Y-m-t', strtotime($periodMonth . '-01'));
        $activeSalary = $this->getActiveSalary($employeeId, $monthEnd);

        if (!$activeSalary || ((float)$activeSalary['gross_salary'] <= 0 && (float)$activeSalary['basic_salary'] <= 0)) {
            return [
                'eligible' => false,
                'reason'   => "Salary configuration required (No configured salary for employee {$employee['employee_code']})"
            ];
        }

        return [
            'eligible' => true,
            'salary'   => $activeSalary
        ];
    }
}
