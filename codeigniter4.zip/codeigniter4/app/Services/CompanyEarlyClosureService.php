<?php

namespace App\Services;

use App\Models\CompanyEarlyClosureModel;
use App\Models\AttendanceClosureCreditModel;
use App\Models\AttendanceModel;
use App\Models\NotificationModel;
use App\Services\AuditService;
use App\Services\RuleEngineService;
use Config\Database;
use Ramsey\Uuid\Uuid;

class CompanyEarlyClosureService
{
    protected $db;
    protected $closureModel;
    protected $creditModel;
    protected $attendanceModel;
    protected $auditService;
    protected $notificationModel;

    public function __construct()
    {
        $this->db = Database::connect();
        $this->closureModel = new CompanyEarlyClosureModel();
        $this->creditModel = new AttendanceClosureCreditModel();
        $this->attendanceModel = new AttendanceModel();
        $this->auditService = new AuditService();
        $this->notificationModel = new NotificationModel();

        $this->closureModel->ensureTableExists();
        $this->creditModel->ensureTableExists();
        $this->attendanceModel->ensureAttendanceColumns();
    }

    /**
     * Parse time string (HH:MM or HH:MM:SS or YYYY-MM-DD HH:MM:SS) into total minutes from midnight
     */
    public static function timeToMinutes(?string $time): int
    {
        if (empty($time) || $time === '--' || $time === '--:--' || $time === '--:--:--') {
            return 0;
        }
        $trimmed = trim($time);
        if (strpos($trimmed, ' ') !== false) {
            $parts = explode(' ', $trimmed);
            $trimmed = end($parts);
        }
        $parts = explode(':', $trimmed);
        $hours = (int)($parts[0] ?? 0);
        $mins = (int)($parts[1] ?? 0);
        return ($hours * 60) + $mins;
    }

    /**
     * Convert integer minutes to HH:MM format strictly for display
     */
    public static function minutesToHHMM(int $minutes): string
    {
        $minutes = max(0, $minutes);
        $hours = intdiv($minutes, 60);
        $rem = $minutes % 60;
        return sprintf('%02d:%02d', $hours, $rem);
    }

    /**
     * Calculate duration in integer minutes between two timestamps, accounting for overnight crossing
     */
    public static function calculateDurationMinutes(?string $startTime, ?string $endTime): int
    {
        if (empty($startTime) || empty($endTime)) {
            return 0;
        }
        $trimmedStart = trim($startTime);
        $trimmedEnd = trim($endTime);
        if (strlen($trimmedStart) > 10 && strlen($trimmedEnd) > 10 && strpos($trimmedStart, '-') !== false && strpos($trimmedEnd, '-') !== false) {
            $t1 = strtotime($trimmedStart);
            $t2 = strtotime($trimmedEnd);
            if ($t1 !== false && $t2 !== false && $t2 >= $t1) {
                return (int)intdiv($t2 - $t1, 60);
            }
        }
        $startMins = self::timeToMinutes($trimmedStart);
        $endMins = self::timeToMinutes($trimmedEnd);
        if ($endMins < $startMins) {
            // Night shift crossing midnight
            return ($endMins + 1440) - $startMins;
        }
        return $endMins - $startMins;
    }

    /**
     * Preview affected employees and hours calculations for an early closure event
     */
    public function previewClosure(array $params, ?string $companyId): array
    {
        $closureDate = $params['closure_date'] ?? date('Y-m-d');
        $closureTime = $params['closure_time'] ?? '12:00:00';
        if (strlen($closureTime) === 5) {
            $closureTime .= ':00';
        }

        $scopeType = $params['scope_type'] ?? 'company';
        $branchId = $params['branch_id'] ?? null;
        $departmentId = $params['department_id'] ?? null;
        $shiftId = $params['shift_id'] ?? null;
        $targetEmployeeIds = $params['target_employee_ids'] ?? [];
        if (is_string($targetEmployeeIds)) {
            $targetEmployeeIds = json_decode($targetEmployeeIds, true) ?: array_filter(array_map('trim', explode(',', $targetEmployeeIds)));
        }

        // 1. Query candidate employees strictly within tenant
        $builder = $this->db->table('employees')
            ->select('employees.*, 
                      departments.name as department_name, 
                      designations.name as designation_name,
                      branches.name as branch_name,
                      shifts.name as shift_name,
                      shifts.start_time as shift_start_time,
                      shifts.end_time as shift_end_time')
            ->join('departments', 'departments.id = employees.department_id', 'left')
            ->join('designations', 'designations.id = employees.designation_id', 'left')
            ->join('branches', 'branches.id = employees.branch_id', 'left')
            ->join('shifts', 'shifts.id = employees.shift_id', 'left')
            ->where('employees.status', \App\Models\EmployeeModel::STATUS_ACTIVE);

        if (!empty($companyId)) {
            $builder->where('employees.company_id', $companyId);
        }

        if ($scopeType === 'branch' && !empty($branchId)) {
            $builder->where('employees.branch_id', $branchId);
        } elseif ($scopeType === 'department' && !empty($departmentId)) {
            $builder->where('employees.department_id', $departmentId);
        } elseif ($scopeType === 'shift' && !empty($shiftId)) {
            $builder->where('employees.shift_id', $shiftId);
        } elseif ($scopeType === 'selected_employees' && !empty($targetEmployeeIds)) {
            $builder->whereIn('employees.id', $targetEmployeeIds);
        }

        $candidates = $builder->get()->getResultArray();

        $previewList = [];
        $totalCreditedHours = 0.0;
        $totalCreditedMinutes = 0;
        $totalScheduledHours = 0.0;
        $totalScheduledMinutes = 0;
        $eligibleCount = 0;
        $ineligibleCount = 0;

        $closureSeconds = strtotime("{$closureDate} {$closureTime}");

        $shiftModel = new \App\Models\ShiftModel();

        foreach ($candidates as $emp) {
            $empId = $emp['id'];

            // P0-004: Centralized Shift Resolution (Duty Assignment -> Shift Swap -> Roster -> Master -> Default)
            $effectiveShift = $shiftModel->resolveEffectiveShift($empId, $closureDate, $emp);
            $shiftStart = $effectiveShift['start_time'] ?? null;
            $shiftEnd = $effectiveShift['end_time'] ?? null;

            // Check Day Off outcome (Holiday, Weekly Off, Roster Day Off)
            if (!empty($effectiveShift['is_day_off'])) {
                $previewList[] = [
                    'employee_id' => $empId,
                    'employee_code' => $emp['employee_code'] ?? 'EMP',
                    'name' => trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')),
                    'department' => $emp['department_name'] ?? 'General',
                    'shift_name' => $effectiveShift['name'] ?? 'Day Off',
                    'scheduled_start' => null,
                    'scheduled_end' => null,
                    'scheduled_duration_hours' => 0.00,
                    'required_duty_minutes' => 0,
                    'required_duty_display' => '00:00',
                    'actual_check_in' => null,
                    'actual_check_out' => null,
                    'actual_worked_minutes' => 0,
                    'actual_worked_hours' => 0.00,
                    'actual_worked_display' => '00:00',
                    'credited_minutes' => 0,
                    'credited_hours' => 0.00,
                    'credited_time_display' => '00:00',
                    'final_duty_minutes' => 0,
                    'final_duty_hours' => 0.00,
                    'final_duty_display' => '00:00',
                    'daily_ot_minutes' => 0,
                    'daily_ot_hours' => 0.00,
                    'daily_ot_display' => '00:00',
                    'is_eligible' => false,
                    'ineligibility_reason' => 'Scheduled Day Off (' . ($effectiveShift['source'] ?? 'Off') . ')'
                ];
                $ineligibleCount++;
                continue;
            }

            // Check Unscheduled outcome
            if (empty($effectiveShift['is_scheduled']) || empty($shiftStart) || empty($shiftEnd)) {
                $previewList[] = [
                    'employee_id' => $empId,
                    'employee_code' => $emp['employee_code'] ?? 'EMP',
                    'name' => trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')),
                    'department' => $emp['department_name'] ?? 'General',
                    'shift_name' => $effectiveShift['name'] ?? 'Unscheduled',
                    'scheduled_start' => null,
                    'scheduled_end' => null,
                    'scheduled_duration_hours' => 0.00,
                    'required_duty_minutes' => 0,
                    'required_duty_display' => '00:00',
                    'actual_check_in' => null,
                    'actual_check_out' => null,
                    'actual_worked_minutes' => 0,
                    'actual_worked_hours' => 0.00,
                    'actual_worked_display' => '00:00',
                    'credited_minutes' => 0,
                    'credited_hours' => 0.00,
                    'credited_time_display' => '00:00',
                    'final_duty_minutes' => 0,
                    'final_duty_hours' => 0.00,
                    'final_duty_display' => '00:00',
                    'daily_ot_minutes' => 0,
                    'daily_ot_hours' => 0.00,
                    'daily_ot_display' => '00:00',
                    'is_eligible' => false,
                    'ineligibility_reason' => 'No Scheduled Shift (Unscheduled)'
                ];
                $ineligibleCount++;
                continue;
            }

            // Integer minute Required Duty calculation
            $requiredDutyMinutes = self::calculateDurationMinutes($shiftStart, $shiftEnd);
            if ($requiredDutyMinutes <= 0 && !empty($effectiveShift['net_work_hours'])) {
                $requiredDutyMinutes = (int)round((float)$effectiveShift['net_work_hours'] * 60);
            }
            $shiftDuration = $requiredDutyMinutes > 0 ? round($requiredDutyMinutes / 60, 2) : 0.00;

            // P0-002: Immutable Settled Payroll Protection
            if ($this->attendanceModel->isAttendanceSettled($empId, $closureDate)) {
                $previewList[] = [
                    'employee_id' => $empId,
                    'employee_code' => $emp['employee_code'] ?? 'EMP',
                    'name' => trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')),
                    'department' => $emp['department_name'] ?? 'General',
                    'shift_name' => $effectiveShift['name'] ?? ($emp['shift_name'] ?? 'Standard Shift'),
                    'scheduled_start' => $shiftStart,
                    'scheduled_end' => $shiftEnd,
                    'scheduled_duration_hours' => $shiftDuration,
                    'required_duty_minutes' => $requiredDutyMinutes,
                    'required_duty_display' => self::minutesToHHMM($requiredDutyMinutes),
                    'actual_check_in' => null,
                    'actual_check_out' => null,
                    'actual_worked_minutes' => 0,
                    'actual_worked_hours' => 0.00,
                    'actual_worked_display' => '00:00',
                    'credited_minutes' => 0,
                    'credited_hours' => 0.00,
                    'credited_time_display' => '00:00',
                    'final_duty_minutes' => 0,
                    'final_duty_hours' => 0.00,
                    'final_duty_display' => '00:00',
                    'daily_ot_minutes' => 0,
                    'daily_ot_hours' => 0.00,
                    'daily_ot_display' => '00:00',
                    'is_eligible' => false,
                    'ineligibility_reason' => 'Attendance settled and locked in payroll'
                ];
                $ineligibleCount++;
                continue;
            }

            // Check approved leave
            $leave = $this->db->table('leave_applications')
                ->where('employee_id', $empId)
                ->where('start_date <=', $closureDate)
                ->where('end_date >=', $closureDate)
                ->whereIn('status', ['Approved', 'Confirmed'])
                ->get()
                ->getRowArray();

            if ($leave) {
                $previewList[] = [
                    'employee_id' => $empId,
                    'employee_code' => $emp['employee_code'] ?? 'EMP',
                    'name' => trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')),
                    'department' => $emp['department_name'] ?? 'General',
                    'shift_name' => $emp['shift_name'] ?? 'Standard Shift',
                    'scheduled_start' => $shiftStart,
                    'scheduled_end' => $shiftEnd,
                    'scheduled_duration_hours' => $shiftDuration,
                    'required_duty_minutes' => $requiredDutyMinutes,
                    'required_duty_display' => self::minutesToHHMM($requiredDutyMinutes),
                    'actual_check_in' => null,
                    'actual_check_out' => null,
                    'actual_worked_minutes' => 0,
                    'actual_worked_hours' => 0.00,
                    'actual_worked_display' => '00:00',
                    'credited_minutes' => 0,
                    'credited_hours' => 0.00,
                    'credited_time_display' => '00:00',
                    'final_duty_minutes' => 0,
                    'final_duty_hours' => 0.00,
                    'final_duty_display' => '00:00',
                    'daily_ot_minutes' => 0,
                    'daily_ot_hours' => 0.00,
                    'daily_ot_display' => '00:00',
                    'is_eligible' => false,
                    'ineligibility_reason' => 'On Approved Leave (' . ($leave['leave_type'] ?? 'Leave') . ')'
                ];
                $ineligibleCount++;
                continue;
            }

            // Check existing attendance log
            $attLog = $this->db->table('attendance_logs')
                ->where('employee_id', $empId)
                ->where('date', $closureDate)
                ->get()
                ->getRowArray();

            $checkIn = $attLog['check_in'] ?? $attLog['in_time'] ?? null;
            $checkOut = $attLog['check_out'] ?? $attLog['out_time'] ?? null;

            // An employee is eligible if they physically clocked in on or before the closure time
            if (empty($checkIn)) {
                $previewList[] = [
                    'employee_id' => $empId,
                    'employee_code' => $emp['employee_code'] ?? 'EMP',
                    'name' => trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')),
                    'department' => $emp['department_name'] ?? 'General',
                    'shift_name' => $emp['shift_name'] ?? 'Standard Shift',
                    'scheduled_start' => $shiftStart,
                    'scheduled_end' => $shiftEnd,
                    'scheduled_duration_hours' => $shiftDuration,
                    'required_duty_minutes' => $requiredDutyMinutes,
                    'required_duty_display' => self::minutesToHHMM($requiredDutyMinutes),
                    'actual_check_in' => null,
                    'actual_check_out' => null,
                    'actual_worked_minutes' => 0,
                    'actual_worked_hours' => 0.00,
                    'actual_worked_display' => '00:00',
                    'credited_minutes' => 0,
                    'credited_hours' => 0.00,
                    'credited_time_display' => '00:00',
                    'final_duty_minutes' => 0,
                    'final_duty_hours' => 0.00,
                    'final_duty_display' => '00:00',
                    'daily_ot_minutes' => 0,
                    'daily_ot_hours' => 0.00,
                    'daily_ot_display' => '00:00',
                    'is_eligible' => false,
                    'ineligibility_reason' => 'Absent (No check-in recorded)'
                ];
                $ineligibleCount++;
                continue;
            }

            // Calculate actual worked in integer minutes from preserved clock-in and clock-out timestamps
            // If they clocked out before or at closure time, use their check-out time.
            // If they haven't clocked out yet, their exit is effectively the authorized closure time.
            $effectiveOut = $checkOut ?: $closureTime;
            $actualWorkedMinutes = self::calculateDurationMinutes($checkIn, $effectiveOut);

            // Calculate Credited Time as Required Duty Minutes minus Actual Worked Minutes, when an approved adjustment applies.
            // Do not automatically grant credited time unless the attendance rules or an approved adjustment authorize it.
            $creditedMinutes = max(0, $requiredDutyMinutes - $actualWorkedMinutes);

            // Calculate Final Duty as Actual Worked Minutes plus Approved Credited Minutes.
            $finalDutyMinutes = $actualWorkedMinutes + $creditedMinutes;

            // Authoritative Rule: Early closure credit must NEVER produce Daily OT!
            // Daily OT = MAX(0, Actual Worked Minutes - Required Duty Minutes)
            $dailyOtMinutes = max(0, $actualWorkedMinutes - $requiredDutyMinutes);

            $actualWorkedHours = round($actualWorkedMinutes / 60, 2);
            $creditHours = round($creditedMinutes / 60, 2);
            $finalDutyHours = round($finalDutyMinutes / 60, 2);
            $dailyOtHours = round($dailyOtMinutes / 60, 2);

            $totalCreditedMinutes += $creditedMinutes;
            $totalCreditedHours += $creditHours;
            $totalScheduledMinutes += $requiredDutyMinutes;
            $totalScheduledHours += $shiftDuration;
            $eligibleCount++;

            $previewList[] = [
                'employee_id' => $empId,
                'employee_code' => $emp['employee_code'] ?? 'EMP',
                'name' => trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')),
                'department' => $emp['department_name'] ?? 'General',
                'shift_name' => $emp['shift_name'] ?? 'Standard Shift',
                'scheduled_start' => $shiftStart,
                'scheduled_end' => $shiftEnd,
                'scheduled_duration_hours' => $shiftDuration,
                'required_duty_minutes' => $requiredDutyMinutes,
                'required_duty_display' => self::minutesToHHMM($requiredDutyMinutes),
                'actual_check_in' => $checkIn,
                'actual_check_out' => $effectiveOut,
                'actual_worked_minutes' => $actualWorkedMinutes,
                'actual_worked_hours' => $actualWorkedHours,
                'actual_worked_display' => self::minutesToHHMM($actualWorkedMinutes),
                'credited_minutes' => $creditedMinutes,
                'credited_hours' => $creditHours,
                'credited_time_display' => self::minutesToHHMM($creditedMinutes),
                'final_duty_minutes' => $finalDutyMinutes,
                'final_duty_hours' => $finalDutyHours,
                'final_duty_display' => self::minutesToHHMM($finalDutyMinutes),
                'daily_ot_minutes' => $dailyOtMinutes,
                'daily_ot_hours' => $dailyOtHours,
                'daily_ot_display' => self::minutesToHHMM($dailyOtMinutes),
                'is_eligible' => true,
                'ineligibility_reason' => null
            ];
        }

        return [
            'summary' => [
                'closure_date' => $closureDate,
                'closure_time' => $closureTime,
                'scope_type' => $scopeType,
                'total_candidates' => count($candidates),
                'eligible_count' => $eligibleCount,
                'ineligible_count' => $ineligibleCount,
                'total_scheduled_minutes' => $totalScheduledMinutes,
                'total_scheduled_display' => self::minutesToHHMM($totalScheduledMinutes),
                'total_scheduled_hours' => round($totalScheduledHours, 2),
                'total_credited_minutes' => $totalCreditedMinutes,
                'total_credited_display' => self::minutesToHHMM($totalCreditedMinutes),
                'total_credited_hours' => round($totalCreditedHours, 2),
            ],
            'employees' => $previewList
        ];
    }

    /**
     * Create an early closure event (Draft status)
     */
    public function createClosure(array $data, array $currentUser): array
    {
        $companyId = $data['company_id'] ?? null;
        if (empty($companyId)) {
            throw new \InvalidArgumentException('Company ID is required for corporate early closure.');
        }

        $reason = trim($data['reason'] ?? '');
        if (empty($reason)) {
            throw new \InvalidArgumentException('Corporate justification/reason is required.');
        }

        $closureDate = $data['closure_date'] ?? date('Y-m-d');
        $closureTime = $data['closure_time'] ?? '12:00:00';
        if (strlen($closureTime) === 5) {
            $closureTime .= ':00';
        }

        $preview = $this->previewClosure($data, $companyId);
        $eligibleList = array_filter($preview['employees'], fn($e) => $e['is_eligible']);

        $closureId = Uuid::uuid4()->toString();
        $targetEmpIds = $data['target_employee_ids'] ?? null;
        if (is_array($targetEmpIds)) {
            $targetEmpIds = json_encode($targetEmpIds);
        }

        $this->db->transStart();

        $closureRecord = [
            'id' => $closureId,
            'company_id' => $companyId,
            'branch_id' => $data['branch_id'] ?? null,
            'department_id' => $data['department_id'] ?? null,
            'shift_id' => $data['shift_id'] ?? null,
            'closure_date' => $closureDate,
            'closure_time' => $closureTime,
            'scope_type' => $data['scope_type'] ?? 'company',
            'target_employee_ids' => $targetEmpIds,
            'status' => 'Draft',
            'reason' => $reason,
            'admin_notes' => null,
            'affected_employee_count' => count($eligibleList),
            'total_credited_hours' => $preview['summary']['total_credited_hours'],
            'created_by' => $currentUser['id'] ?? 'SYSTEM',
            'created_by_name' => $currentUser['name'] ?? $currentUser['username'] ?? 'Admin',
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $this->closureModel->insert($closureRecord);

        // Insert individual credit draft records
        foreach ($eligibleList as $item) {
            $creditRecord = [
                'id'                       => Uuid::uuid4()->toString(),
                'closure_id'               => $closureId,
                'company_id'               => $companyId,
                'employee_id'              => $item['employee_id'],
                'attendance_date'          => $closureDate,
                'scheduled_start'          => $item['scheduled_start'],
                'scheduled_end'            => $item['scheduled_end'],
                'scheduled_duration_hours' => $item['scheduled_duration_hours'],
                'required_duty_minutes'    => $item['required_duty_minutes'],
                'actual_check_in'          => $item['actual_check_in'],
                'actual_check_out'         => $item['actual_check_out'],
                'actual_worked_minutes'    => $item['actual_worked_minutes'],
                'actual_worked_hours'      => $item['actual_worked_hours'],
                // Draft stores the calculated credit (Required Duty - Actual Worked); it only becomes effective on approval
                'credited_minutes'         => $item['credited_minutes'],
                'credited_hours'           => $item['credited_hours'],
                'final_duty_minutes'       => $item['final_duty_minutes'],
                'final_duty_hours'         => $item['final_duty_hours'],
                'original_status'          => 'Present',
                'final_status'             => 'Present (Early Closure)',
                'status'                   => 'Draft',
                'created_at'               => date('Y-m-d H:i:s')
            ];
            $this->creditModel->insert($creditRecord);
        }

        $this->db->transComplete();

        if ($this->db->transStatus() === false) {
            throw new \RuntimeException('Failed to create company early closure event in database.');
        }

        $this->auditService->log(
            $currentUser['id'] ?? null,
            'attendance',
            'company_early_closure.create_draft',
            $closureId,
            null,
            $closureRecord,
            null,
            null,
            "Created early closure draft for {$closureDate} at {$closureTime} affecting " . count($eligibleList) . " employees."
        );

        return array_merge($closureRecord, ['preview' => $preview]);
    }

    /**
     * Submit an early closure event for approval
     */
    public function submitClosure(string $closureId, array $currentUser): array
    {
        $closure = $this->closureModel->find($closureId);
        if (!$closure) {
            throw new \RuntimeException("Closure event not found: {$closureId}");
        }

        // Tenant isolation: closure must belong to the actor's company
        if (empty($currentUser) || !(new \App\Services\PermissionService())->validateTenantScope($currentUser, $closure['company_id'])) {
            throw new \RuntimeException('403 Forbidden: Cross-tenant early closure operation prohibited.');
        }

        if ($closure['status'] !== 'Draft') {
            throw new \RuntimeException("Only Draft closures can be submitted. Current status: {$closure['status']}");
        }

        $updateData = [
            'status' => 'Submitted',
            'submitted_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $this->closureModel->update($closureId, $updateData);

        $this->auditService->log(
            $currentUser['id'] ?? null,
            'attendance',
            'company_early_closure.submit',
            $closureId,
            ['status' => 'Draft'],
            ['status' => 'Submitted'],
            null,
            null,
            "Submitted early closure event for authoritative approval."
        );

        return array_merge($closure, $updateData);
    }

    /**
     * Authoritatively approve an early closure event, credit all eligible employees,
     * preserve physical punches, and notify all affected employees.
     */
    public function approveClosure(string $closureId, string $adminNotes, array $currentUser): array
    {
        // 1. Mandatory Admin Note validation
        $cleanNotes = trim($adminNotes);
        if (empty($cleanNotes)) {
            throw new \InvalidArgumentException('Mandatory Admin Note / Approval Reason cannot be empty or whitespace only.');
        }

        $closure = $this->closureModel->find($closureId);
        if (!$closure) {
            throw new \RuntimeException("Closure event not found: {$closureId}");
        }

        // Tenant isolation: closure must belong to the actor's company
        if (empty($currentUser) || !(new \App\Services\PermissionService())->validateTenantScope($currentUser, $closure['company_id'])) {
            throw new \RuntimeException('403 Forbidden: Cross-tenant early closure operation prohibited.');
        }

        // 2. IDEMPOTENCY GUARD: If already approved, do not double credit!
        if ($closure['status'] === 'Approved') {
            return [
                'success' => true,
                'message' => 'Closure is already approved and attendance credits were applied (Idempotent call).',
                'closure' => $closure
            ];
        }

        if (!in_array($closure['status'], ['Draft', 'Submitted'], true)) {
            throw new \RuntimeException("Cannot approve closure in status: {$closure['status']}");
        }

        $companyId = $closure['company_id'];
        $closureDate = $closure['closure_date'];
        $closureTime = $closure['closure_time'];

        // 3. Operational Approval Window & Payroll Lock Validation (Authoritative Rule 5)
        $this->validateApprovalWindow($companyId, $closureDate);

        $approvedBy = $currentUser['id'] ?? 'ADMIN';
        $approvedByName = $currentUser['name'] ?? $currentUser['username'] ?? 'HR Admin';
        $now = date('Y-m-d H:i:s');

        $this->db->transStart();

        // 4. Update closure record
        $closureUpdate = [
            'status' => 'Approved',
            'admin_notes' => $cleanNotes,
            'approved_by' => $approvedBy,
            'approved_by_name' => $approvedByName,
            'approved_at' => $now,
            'updated_at' => $now
        ];
        $this->closureModel->update($closureId, $closureUpdate);

        // 5. Fetch all individual credit records for this closure
        $credits = $this->creditModel->where('closure_id', $closureId)->findAll();

        foreach ($credits as $credit) {
            $empId = $credit['employee_id'];

            // P0-002: Immutable Settled Payroll Protection
            if ($this->attendanceModel->isAttendanceSettled($empId, $closureDate)) {
                $this->creditModel->update($credit['id'], [
                    'status' => 'Skipped',
                    'notes' => 'Skipped: Attendance settled and locked in payroll',
                    'updated_at' => $now
                ]);
                continue;
            }

            $shiftStart = $credit['scheduled_start'] ?? '08:00';
            $shiftEnd = $credit['scheduled_end'] ?? '16:00';
            $checkIn = $credit['actual_check_in'] ?? null;
            $checkOut = $credit['actual_check_out'] ?? null;

            // 1. Calculate Required Duty Minutes (Configured Shift)
            $startMins = self::timeToMinutes($shiftStart);
            $endMins = self::timeToMinutes($shiftEnd);
            $reqMins = ($endMins < $startMins) ? ($endMins + 1440 - $startMins) : ($endMins - $startMins);
            if ($reqMins <= 0 && !empty($credit['required_duty_minutes'])) {
                $reqMins = (int)$credit['required_duty_minutes'];
            } elseif ($reqMins <= 0 && !empty($credit['scheduled_duration_hours'])) {
                $reqMins = (int)round((float)$credit['scheduled_duration_hours'] * 60);
            }
            if ($reqMins <= 0) {
                $reqMins = 480;
            }

            // 2. Calculate Actual Worked from preserved clock-in and clock-out timestamps
            $actualMins = 0;
            if (!empty($checkIn) && !empty($checkOut)) {
                $actualMins = self::calculateDurationMinutes($checkIn, $checkOut);
            } elseif (!empty($credit['actual_worked_minutes'])) {
                $actualMins = (int)$credit['actual_worked_minutes'];
            } elseif (!empty($credit['actual_worked_hours'])) {
                $actualMins = (int)round((float)$credit['actual_worked_hours'] * 60);
            }

            // 3. Calculate Credited Time as Required Duty Minutes minus Actual Worked Minutes, when an approved adjustment applies.
            $creditedMins = max(0, $reqMins - $actualMins);

            // 4. Calculate Final Duty as Actual Worked Minutes plus Approved Credited Minutes.
            $finalDutyMins = $actualMins + $creditedMins;

            $actualWorkedHours = round($actualMins / 60, 2);
            $creditedHours = round($creditedMins / 60, 2);
            $finalDutyHours = round($finalDutyMins / 60, 2);

            // Calculate physical overtime if any prior to closure (Scenario I)
            $physicalOtMins = max(0, $actualMins - $reqMins);
            $physicalOt = round($physicalOtMins / 60, 2);

            // Update credit record with integer minutes and approved status
            $this->creditModel->update($credit['id'], [
                'required_duty_minutes' => $reqMins,
                'actual_worked_minutes' => $actualMins,
                'credited_minutes'      => $creditedMins,
                'final_duty_minutes'    => $finalDutyMins,
                'actual_worked_hours'   => $actualWorkedHours,
                'credited_hours'        => $creditedHours,
                'final_duty_hours'      => $finalDutyHours,
                'status'                => 'Approved',
                'approved_by'           => $approvedBy,
                'approved_at'           => $now,
                'notes'                 => $cleanNotes,
                'updated_at'            => $now
            ]);

            // 6. Update or insert into attendance_logs WITHOUT falsifying physical punches
            $existingLog = $this->db->table('attendance_logs')
                ->where('employee_id', $empId)
                ->where('date', $closureDate)
                ->get()
                ->getRowArray();

            $logData = [
                'is_company_closure'    => 1,
                'closure_event_id'      => $closureId,
                'closure_credit_hours'  => $creditedHours,
                'actual_worked_hours'   => $actualWorkedHours,
                'actual_in_time'        => $credit['actual_check_in'] ?: ($existingLog['check_in'] ?? null),
                'actual_out_time'       => $credit['actual_check_out'] ?: ($existingLog['check_out'] ?? null),
                'check_in'              => $credit['actual_check_in'] ?: ($existingLog['check_in'] ?? null),
                'check_out'             => $credit['actual_check_out'] ?: ($existingLog['check_out'] ?? null),
                'in_time'               => $credit['actual_check_in'] ?: ($existingLog['in_time'] ?? null),
                'out_time'              => $credit['actual_check_out'] ?: ($existingLog['out_time'] ?? null),
                'gross_hours'           => round($finalDutyHours + $physicalOt, 2),
                'net_hours'             => round($finalDutyHours + $physicalOt, 2),
                'working_hours'         => round($finalDutyHours + $physicalOt, 2),
                'worked_hours'          => $actualWorkedHours,
                'regular_hours'         => $finalDutyHours,
                // CRITICAL RULE: Early closure credit NEVER produces Daily OT. Only physical OT prior to closure is preserved.
                'overtime_hours'        => $physicalOt,
                'manual_overtime_hours' => 0.00,
                'early_out_minutes'     => 0, // Waive early exit penalty per corporate closure
                'status'                => 'Present',
                'day_type'              => 'NORMAL_WORKDAY',
                'ot_approval_status'    => $physicalOt > 0 ? 'Approved' : 'Not Required',
                'is_ot_payable'         => $physicalOt > 0 ? 1 : 0,
                'is_approved'           => 1,
                'approved_by'           => $approvedByName,
                'verification_method'   => 'Company Early Closure Approved',
                'remarks'               => "Early Closure ({$closureTime}) Credit: " . self::minutesToHHMM($creditedMins) . " approved. Reason: {$cleanNotes}",
                'updated_at'            => $now
            ];

            // Filter against existing table fields for safe mutation
            $tableFields = $this->db->getFieldNames('attendance_logs');
            $safeLogData = [];
            foreach ($logData as $col => $val) {
                if (in_array($col, $tableFields, true)) {
                    $safeLogData[$col] = $val;
                }
            }

            if ($existingLog) {
                $this->db->table('attendance_logs')->where('id', $existingLog['id'])->update($safeLogData);
                $this->creditModel->update($credit['id'], ['attendance_log_id' => $existingLog['id']]);
            } else {
                $safeLogData['id'] = Uuid::uuid4()->toString();
                $safeLogData['employee_id'] = $empId;
                $safeLogData['company_id'] = $companyId;
                $safeLogData['date'] = $closureDate;
                $safeLogData['created_at'] = $now;
                $this->db->table('attendance_logs')->insert($safeLogData);
                $this->creditModel->update($credit['id'], ['attendance_log_id' => $safeLogData['id']]);
            }

            // Synchronize with 'attendances' table if it exists in the database
            if ($this->db->tableExists('attendances')) {
                $attFields = $this->db->getFieldNames('attendances');
                $safeAttData = [];
                $attMap = array_merge($logData, [
                    'worked_hours'         => $actualWorkedHours,
                    'working_hours'        => round($finalDutyHours + $physicalOt, 2),
                    'actual_worked_hours'  => $actualWorkedHours,
                    'closure_credit_hours' => $creditedHours,
                ]);
                foreach ($attMap as $col => $val) {
                    if (in_array($col, $attFields, true)) {
                        $safeAttData[$col] = $val;
                    }
                }
                if (!empty($safeAttData)) {
                    $existingAtt = $this->db->table('attendances')
                        ->where('employee_id', $empId)
                        ->where('date', $closureDate)
                        ->get()
                        ->getRowArray();
                    if ($existingAtt) {
                        $this->db->table('attendances')->where('id', $existingAtt['id'])->update($safeAttData);
                    } else {
                        $safeAttData['id'] = Uuid::uuid4()->toString();
                        $safeAttData['employee_id'] = $empId;
                        $safeAttData['date'] = $closureDate;
                        if (in_array('company_id', $attFields, true)) {
                            $safeAttData['company_id'] = $companyId;
                        }
                        $this->db->table('attendances')->insert($safeAttData);
                    }
                }
            }
        }

        $this->db->transComplete();

        if ($this->db->transStatus() === false) {
            throw new \RuntimeException('Database transaction failed during early closure approval.');
        }

        // 6. Forensic Audit Log
        $this->auditService->log(
            $currentUser['id'] ?? null,
            'attendance',
            'company_early_closure.approve',
            $closureId,
            ['status' => $closure['status']],
            ['status' => 'Approved', 'admin_notes' => $cleanNotes],
            null,
            null,
            "Approved Company Early Closure for {$closureDate}. Credited " . count($credits) . " employees with total {$closure['total_credited_hours']} hours."
        );

        // 7. Employee Notifications
        foreach ($credits as $credit) {
            try {
                $creditedDisplay = self::minutesToHHMM((int)($credit['credited_minutes'] ?? round((float)($credit['credited_hours'] ?? 0) * 60)));
                $finalDutyDisplay = self::minutesToHHMM((int)($credit['final_duty_minutes'] ?? round((float)($credit['final_duty_hours'] ?? 0) * 60)));
                $this->notificationModel->insert([
                    'id' => Uuid::uuid4()->toString(),
                    'user_id' => null, // Delivered by employee context
                    'title' => 'Company Early Closure Credit Approved',
                    'message' => "The company officially closed early on {$closureDate} at {$closureTime}. You have been credited {$creditedDisplay} for a full working day duty of {$finalDutyDisplay} without OT impact. Note: {$cleanNotes}",
                    'type' => 'attendance_closure',
                    'priority' => 'Normal',
                    'related_module' => 'attendance',
                    'related_employee_id' => $credit['employee_id'],
                    'created_by' => $approvedBy,
                    'created_by_name' => $approvedByName,
                    'icon' => 'calendar-check',
                    'link' => '/attendance?tab=corrections',
                    'is_read' => 0,
                    'created_at' => $now
                ]);
            } catch (\Throwable $e) {
                log_message('error', "Notification dispatch error: " . $e->getMessage());
            }
        }

        return [
            'success' => true,
            'message' => "Company Early Closure approved successfully. " . count($credits) . " employees credited with full-day attendance.",
            'closure' => array_merge($closure, $closureUpdate)
        ];
    }

    /**
     * Cancel an early closure event and safely revoke credited hours
     */
    public function cancelClosure(string $closureId, string $reason, array $currentUser): array
    {
        $cleanReason = trim($reason);
        if (empty($cleanReason)) {
            throw new \InvalidArgumentException('Mandatory cancellation reason is required.');
        }

        $closure = $this->closureModel->find($closureId);
        if (!$closure) {
            throw new \RuntimeException("Closure event not found: {$closureId}");
        }

        // 1. Authenticate actor
        if (empty($currentUser) || empty($currentUser['id'])) {
            throw new \RuntimeException('Authentication required to cancel early closure event.');
        }

        // 2. Validate tenant isolation
        $permService = new \App\Services\PermissionService();
        if (!$permService->validateTenantScope($currentUser, $closure['company_id'])) {
            throw new \RuntimeException('403 Forbidden: Cross-tenant early closure cancellation prohibited.');
        }

        // 3. Validate closure state
        if (in_array($closure['status'], ['Cancelled', 'Rejected'], true)) {
            throw new \RuntimeException("Cannot cancel closure in status: {$closure['status']}");
        }

        // 4. Validate operational approval window / payroll lock
        $this->validateApprovalWindow($closure['company_id'], $closure['closure_date']);

        // 5. Settled Payroll Protection: If attendance is settled, CANNOT revoke credits!
        $credits = $this->creditModel->where('closure_id', $closureId)->findAll();
        foreach ($credits as $credit) {
            $empId = $credit['employee_id'];
            $closureDate = $closure['closure_date'];
            $logId = $credit['attendance_log_id'] ?? null;
            if ($this->attendanceModel->isAttendanceSettled($empId, $closureDate, $logId)) {
                throw new \RuntimeException("Cancellation Rejected: Attendance record on {$closureDate} for employee {$empId} is settled and locked in payroll. Early closure credits cannot be retroactively revoked.");
            }
        }

        $now = date('Y-m-d H:i:s');
        $cancelledBy = $currentUser['id'] ?? 'ADMIN';

        $this->db->transStart();

        $this->closureModel->update($closureId, [
            'status' => 'Cancelled',
            'admin_notes' => ($closure['admin_notes'] ? $closure['admin_notes'] . " | " : "") . "Cancelled: " . $cleanReason,
            'cancelled_by' => $cancelledBy,
            'cancelled_at' => $now,
            'updated_at' => $now
        ]);

        foreach ($credits as $credit) {
            $this->creditModel->update($credit['id'], [
                'status'             => 'Revoked',
                'credited_minutes'   => 0,
                'credited_hours'     => 0.00,
                'final_duty_minutes' => (int)($credit['actual_worked_minutes'] ?? 0),
                'final_duty_hours'   => (float)($credit['actual_worked_hours'] ?? 0.00),
                'notes'              => 'Revoked on event cancellation',
                'updated_at'         => $now
            ]);

            // Revert attendance log if it had closure credit
            if (!empty($credit['attendance_log_id'])) {
                $actual = (float)($credit['actual_worked_hours'] ?? round(((int)($credit['actual_worked_minutes'] ?? 0)) / 60, 2));
                $this->db->table('attendance_logs')
                    ->where('id', $credit['attendance_log_id'])
                    ->update([
                        'is_company_closure'   => 0,
                        'closure_credit_hours' => 0.00,
                        'net_hours'            => $actual,
                        'working_hours'        => $actual,
                        'regular_hours'        => $actual,
                        'remarks'              => "Company Early Closure revoked on {$now}",
                        'updated_at'           => $now
                    ]);
            }
        }

        $this->db->transComplete();

        if ($this->db->transStatus() === false) {
            throw new \RuntimeException('Failed to cancel early closure event: database transaction failed.');
        }

        $this->auditService->log(
            $currentUser['id'] ?? null,
            'attendance',
            'company_early_closure.cancel',
            $closureId,
            ['status' => $closure['status']],
            ['status' => 'Cancelled', 'reason' => $cleanReason],
            null,
            null,
            "Cancelled Company Early Closure event {$closureId}."
        );

        return ['success' => true, 'message' => 'Company Early Closure event cancelled and credits revoked.'];
    }

    /**
     * Reject a submitted early closure event (Authoritative Rule 14)
     */
    public function rejectClosure(string $closureId, string $rejectionReason, array $currentUser): array
    {
        $cleanReason = trim($rejectionReason);
        if (empty($cleanReason)) {
            throw new \InvalidArgumentException('Mandatory rejection reason is required.');
        }

        $closure = $this->closureModel->find($closureId);
        if (!$closure) {
            throw new \RuntimeException("Closure event not found: {$closureId}");
        }

        // Tenant isolation: closure must belong to the actor's company
        if (empty($currentUser) || !(new \App\Services\PermissionService())->validateTenantScope($currentUser, $closure['company_id'])) {
            throw new \RuntimeException('403 Forbidden: Cross-tenant early closure operation prohibited.');
        }

        if (!in_array($closure['status'], ['Draft', 'Submitted'], true)) {
            throw new \RuntimeException("Cannot reject closure in status: {$closure['status']}");
        }

        $now = date('Y-m-d H:i:s');
        $rejectedBy = $currentUser['id'] ?? 'ADMIN';

        $this->closureModel->update($closureId, [
            'status' => 'Rejected',
            'admin_notes' => ($closure['admin_notes'] ? $closure['admin_notes'] . " | " : "") . "Rejected: {$cleanReason}",
            'updated_at' => $now
        ]);

        $this->creditModel->where('closure_id', $closureId)->set([
            'status'           => 'Rejected',
            'credited_minutes' => 0,
            'credited_hours'   => 0.00,
            'updated_at'       => $now
        ])->update();

        $this->auditService->log(
            $currentUser['id'] ?? null,
            'attendance',
            'company_early_closure.reject',
            $closureId,
            ['status' => $closure['status']],
            ['status' => 'Rejected', 'reason' => $cleanReason],
            null,
            null,
            "Rejected Company Early Closure event {$closureId}. Reason: {$cleanReason}"
        );

        return ['success' => true, 'message' => 'Company Early Closure event rejected.'];
    }

    /**
     * Authoritative Validation: Approval Window & Payroll Lock Check (Authoritative Rule 5)
     * Rejects approval if:
     * - The closure date falls in a locked payroll cycle
     * - The closure date falls in a finalized payroll period
     * - The closure date falls in an active payroll generation lock
     * - The closure date is in a historical period outside policy window (>90 days)
     */
    public function validateApprovalWindow(string $companyId, string $closureDate): void
    {
        $payrollMonth = date('Y-m', strtotime($closureDate));

        // 1. Check if payrolls table has locked or finalized cycle for this company & month
        if ($this->db->tableExists('payrolls')) {
            $lockedPayroll = $this->db->table('payrolls')
                ->where('company_id', $companyId)
                ->groupStart()
                    ->where('payroll_month', $payrollMonth)
                    ->orWhere('month', $payrollMonth)
                ->groupEnd()
                ->groupStart()
                    ->where('is_locked', 1)
                    ->orWhereIn('status', ['Finalized', 'Approved', 'Paid', 'Locked'])
                ->groupEnd()
                ->get()
                ->getRowArray();

            if ($lockedPayroll) {
                throw new \RuntimeException("Approval Rejected: Closure date ({$closureDate}) falls in a locked or finalized payroll period ({$payrollMonth}). Attendance records cannot be retroactively modified.");
            }
        }

        // 2. Check active payroll generation locks
        if ($this->db->tableExists('payroll_generation_locks')) {
            $activeLock = $this->db->table('payroll_generation_locks')
                ->where('company_id', $companyId)
                ->where('payroll_month', $payrollMonth)
                ->where('expires_at >', date('Y-m-d H:i:s'))
                ->get()
                ->getRowArray();

            if ($activeLock) {
                throw new \RuntimeException("Approval Rejected: Payroll cycle for {$payrollMonth} is currently undergoing batch processing/locked.");
            }
        }

        // 3. Historical policy check: older than 90 days
        $daysDiff = (time() - strtotime($closureDate)) / 86400;
        if ($daysDiff > 90) {
            throw new \RuntimeException("Approval Rejected: Closure date ({$closureDate}) is outside the allowable historical operational policy window (maximum 90 days).");
        }
    }
}
