<?php

namespace App\Services;

use App\Models\EmployeeModel;
use App\Models\ShiftModel;
use App\Models\HolidayModel;
use App\Models\LeaveModel;
use App\Services\CompanyWeekendService;
use App\Services\Rules\RuleNotConfiguredException;
use App\Services\Rules\RuleResolver;
use Config\Database;

/**
 * Enterprise Attendance, Overtime & Bonus Rule Engine Service
 *
 * Implements:
 * 1. Rule Hierarchy & Resolver (Employee -> Shift -> Designation -> Department -> Branch -> Company -> Global)
 * 2. Dynamic Standard Daily Working Hours
 * 3. Daily Attendance & Punctuality Engine (Grace, 5 Late Penalty methods, 5 Early Out penalty methods)
 * 4. Daily & Weekly Overtime Engine (1.5x Normal, 2.0x Off-Day, 2.0x/2.5x Holiday, Rounding, Divisor Days/Hours)
 * 5. Overtime Conflict Policy (Anti-Double-Counting, Higher-of-Daily-or-Weekly, Daily Only, Weekly Only)
 * 6. Missing Day Policies (No Overtime, Actual Hours Only, Pro-rated Target)
 * 7. Weekly & Periodic Bonus Rule Engine (Fixed, Percentage, Hour-based, Tier-based)
 * 8. Leave & Holiday Crediting Treatments
 * 9. Automated Test Suite Runner (TEST-1 to TEST-8)
 * 10. Live Sandbox Simulation Engine
 */
class RuleEngineService
{
    protected $db;
    public static bool $skipClosureLookup = false;
    protected ?\App\Services\EmployeeSalaryService $salaryService = null;

    protected function getSalaryService(): \App\Services\EmployeeSalaryService
    {
        if ($this->salaryService === null) {
            $this->salaryService = class_exists('\Config\Services') && method_exists('\Config\Services', 'salary')
                ? \Config\Services::salary()
                : new \App\Services\EmployeeSalaryService();
        }
        return $this->salaryService;
    }

    public const DAYS_OF_WEEK = [
        'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'
    ];

    public function __construct()
    {
        $this->db = Database::connect();
    }

    /**
     * Get DayOfWeek from ISO date string (YYYY-MM-DD)
     */
    public static function getDayOfWeekFromDate(string $dateStr): string
    {
        $dayIndex = (int)date('w', strtotime($dateStr));
        return self::DAYS_OF_WEEK[$dayIndex] ?? 'Sunday';
    }

    /**
     * Convert HH:MM or HH:MM:SS to total minutes
     */
    public static function timeStringToMinutes(?string $timeStr): int
    {
        if (empty($timeStr)) {
            return 0;
        }
        $trimmed = trim($timeStr);
        if (strpos($trimmed, ' ') !== false) {
            $parts = explode(' ', $trimmed);
            $trimmed = end($parts);
        }
        $parts = explode(':', $trimmed);
        $hours = isset($parts[0]) ? (int)$parts[0] : 0;
        $mins = isset($parts[1]) ? (int)$parts[1] : 0;
        return ($hours * 60) + $mins;
    }

    /**
     * RULE HIERARCHY & EFFECTIVE DATE RESOLVER
     *
     * Single Source of Truth: Delegates to RuleResolver::attendanceProfile().
     */
    public function resolveEffectiveRuleProfile(string $date, array $employee, ?array $allProfiles = null): array
    {
        return \App\Services\Rules\RuleResolver::attendanceProfile($employee, $date);
    }

    /**
     * DAILY ATTENDANCE & HOURS ENGINE
     *
     * Calculates Gross, Break, Net, Late, Early Out, Regular, and Daily OT for a single date
     */
    public function calculateDailyAttendance(
        string $date,
        array $employee,
        ?array $log,
        array $ruleProfile = [],
        ?array $shift = null,
        array $leaves = [],
        array $holidays = [],
        ?array $dutyAssignmentLookup = null,
        ?array $weeklyOffLookup = null
    ): array {
        if (empty($ruleProfile)) {
            $ruleProfile = $this->resolveEffectiveRuleProfile($date, $employee);
        }

        $dayOfWeek = self::getDayOfWeekFromDate($date);
        $today = date('Y-m-d');

        // STRICT CORE BUSINESS RULE:
        // Attendance records and daily calculation only exist from official joining date onward.
        $empJoinDate = employee_joining_date($employee) ?? $employee['employment_start_date'] ?? $employee['joinDate'] ?? null;
        if (!empty($empJoinDate) && $date < $empJoinDate) {
            return [
                'date' => $date,
                'employee_id' => $employee['id'] ?? '',
                'day_of_week' => $dayOfWeek,
                'day_type' => 'BEFORE_JOINING',
                'status' => 'Before Joining',
                'status_label' => 'Before Joining',
                'is_before_joining' => true,
                'is_future_date' => false,
                'is_duty_assigned' => false,
                'duty_type' => null,
                'duty_assignment' => null,
                'check_in' => null,
                'check_out' => null,
                'is_weekly_off' => false,
                'weekly_off_days' => [],
                'is_holiday' => false,
                'holiday_name' => null,
                'is_on_leave' => false,
                'leave_type' => null,
                'is_paid_leave' => false,
                'gross_hours' => 0.0,
                'break_hours' => 0.0,
                'unpaid_break_hours' => 0.0,
                'net_hours' => 0.0,
                'credited_hours' => 0.0,
                'total_effective_hours' => 0.0,
                'late_minutes' => 0,
                'is_late' => false,
                'late_penalty_deduction' => 0.0,
                'late_penalty_hours' => 0.0,
                'late_penalty_message' => null,
                'early_out_minutes' => 0,
                'is_early_out' => false,
                'early_out_penalty_deduction' => 0.0,
                'early_out_penalty_hours' => 0.0,
                'regular_hours' => 0.0,
                'standard_daily_hours' => 0.0,
                'scheduled_hours' => 0.0,
                'daily_overtime_hours' => 0.0,
                'off_day_overtime_hours' => 0.0,
                'holiday_overtime_hours' => 0.0,
                'total_overtime_hours' => 0.0,
                'payable_overtime_hours' => 0.0,
                'overtime_amount' => 0.0,
                'loss_of_pay_days' => 0.0,
                'payable_days' => 0.0,
                'remarks' => "Outside employment period (Joined on {$empJoinDate})"
            ];
        }

        // Future dates cannot appear as actual attendance records unless explicitly simulated by Live Control
        if ($date > $today && empty($log['allow_future_simulation'])) {
            return [
                'date' => $date,
                'employee_id' => $employee['id'] ?? '',
                'day_of_week' => $dayOfWeek,
                'day_type' => 'FUTURE_DATE',
                'status' => 'Future Date',
                'status_label' => 'Future Date',
                'is_before_joining' => false,
                'is_future_date' => true,
                'is_duty_assigned' => false,
                'duty_type' => null,
                'duty_assignment' => null,
                'check_in' => null,
                'check_out' => null,
                'is_weekly_off' => false,
                'weekly_off_days' => [],
                'is_holiday' => false,
                'holiday_name' => null,
                'is_on_leave' => false,
                'leave_type' => null,
                'is_paid_leave' => false,
                'gross_hours' => 0.0,
                'break_hours' => 0.0,
                'unpaid_break_hours' => 0.0,
                'net_hours' => 0.0,
                'credited_hours' => 0.0,
                'total_effective_hours' => 0.0,
                'late_minutes' => 0,
                'is_late' => false,
                'late_penalty_deduction' => 0.0,
                'late_penalty_hours' => 0.0,
                'late_penalty_message' => null,
                'early_out_minutes' => 0,
                'is_early_out' => false,
                'early_out_penalty_deduction' => 0.0,
                'early_out_penalty_hours' => 0.0,
                'regular_hours' => 0.0,
                'standard_daily_hours' => 0.0,
                'scheduled_hours' => 0.0,
                'daily_overtime_hours' => 0.0,
                'off_day_overtime_hours' => 0.0,
                'holiday_overtime_hours' => 0.0,
                'total_overtime_hours' => 0.0,
                'payable_overtime_hours' => 0.0,
                'overtime_amount' => 0.0,
                'loss_of_pay_days' => 0.0,
                'payable_days' => 0.0,
                'remarks' => "Future date"
            ];
        }

        $companyId = $employee['company_id'] ?? null;
        $employeeId = $employee['id'] ?? '';

        // Fetch active duty assignment (if any) BEFORE resolving scheduled hours & day type
        if (isset($log['duty_assignment'])) {
            $dutyAssignment = $log['duty_assignment'];
        } elseif ($dutyAssignmentLookup !== null && array_key_exists((string)$employeeId, $dutyAssignmentLookup)) {
            $dutyAssignment = $dutyAssignmentLookup[(string)$employeeId];
        } else {
            $dutyAssignment = \App\Services\CompanyWeekendService::getDutyAssignment($employeeId, $date, $companyId);
        }

        // Resolve Scheduled Working Hours from Shift, Duty Assignment, or Rule Profile (never hardcode!)
        $scheduledHours = null;
        if (!empty($dutyAssignment['scheduled_hours']) && (float)$dutyAssignment['scheduled_hours'] > 0) {
            $scheduledHours = (float)$dutyAssignment['scheduled_hours'];
        } elseif (!empty($shift['working_hours']) && (float)$shift['working_hours'] > 0) {
            $scheduledHours = (float)$shift['working_hours'];
        } elseif (!empty($shift['duration_hours']) && (float)$shift['duration_hours'] > 0) {
            $scheduledHours = (float)$shift['duration_hours'];
        } elseif (!empty($shift['start_time']) && !empty($shift['end_time'])) {
            $sIn = self::timeStringToMinutes($shift['start_time']);
            $sOut = self::timeStringToMinutes($shift['end_time']);
            $shiftGrossMins = ($sOut >= $sIn) ? ($sOut - $sIn) : ($sOut + 1440 - $sIn);
            $bRule = $ruleProfile['breakRule'] ?? $ruleProfile['break_rule'] ?? null;
            $bEnabled = false;
            $bPaid = false;
            $bDurationMins = 0;
            if ($bRule !== null) {
                $bEnabled = !empty($bRule['enabled']) && $bRule['enabled'] !== 'false' && $bRule['enabled'] !== false;
                $bPaid = !empty($bRule['isPaid']) || !empty($bRule['is_paid']);
                $bDurationMins = (int)($bRule['breakDurationMinutes'] ?? $bRule['break_duration_minutes'] ?? 0);
            }
            $bMins = ($bEnabled && !$bPaid) ? $bDurationMins : 0;
            $shiftNetMins = max(0, $shiftGrossMins - $bMins);
            if ($shiftNetMins > 0) {
                $scheduledHours = round($shiftNetMins / 60, 2);
            }
        }

        // Dynamic Standard Daily Hours (authoritative hierarchy)
        $standardDailyHours = (float)(
            $scheduledHours
            ?? $ruleProfile['workingWeek']['standardDailyHours']
            ?? $ruleProfile['overtimeRule']['dailyThresholdHours']
            ?? $ruleProfile['dailyHours']['dailyRequiredHours']
            ?? 8.0
        );

        // Evaluate Day Type with strict priority (Holiday -> Weekend/Weekly Off -> Workday)
        $dayTypeEval = \App\Services\CompanyWeekendService::evaluateDayType($date, $employee, $shift, $holidays, $dutyAssignment);
        $dayType = $dayTypeEval['day_type'];
        $isWeeklyOff = $dayTypeEval['is_weekly_off'];
        $isHoliday = $dayTypeEval['is_holiday'];
        $holidayName = $dayTypeEval['holiday_name'] ?: null;
        if ($weeklyOffLookup !== null && array_key_exists((string)$employeeId, $weeklyOffLookup)) {
            $weeklyOffDays = $weeklyOffLookup[(string)$employeeId];
        } else {
            $weeklyOffDays = \App\Services\CompanyWeekendService::getCompanyWeeklyOff($companyId, $employeeId);
        }

        $empId = $employee['id'] ?? $employee['employee_id'] ?? ($log['employee_id'] ?? null);
        $logDate = $log['date'] ?? $log['punch_date'] ?? $date ?: date('Y-m-d');

        // Check if on Approved Leave
        $isOnLeave = false;
        $leaveType = null;
        $matchedLeave = null;
        foreach ($leaves as $l) {
            $empMatch = ($l['employee_id'] ?? $l['employeeId'] ?? '') === ($employee['id'] ?? '');
            $status = $l['status'] ?? '';
            $start = $l['start_date'] ?? $l['startDate'] ?? $l['from_date'] ?? $l['fromDate'] ?? '';
            $end = $l['end_date'] ?? $l['endDate'] ?? $l['to_date'] ?? $l['toDate'] ?? '';

            if ($empMatch && in_array($status, ['Approved', 'Confirmed'], true) && $date >= $start && $date <= $end) {
                $isOnLeave = true;
                $matchedLeave = $l;
                $leaveType = $l['leave_type_name'] ?? $l['leaveTypeName'] ?? $l['leave_type'] ?? $l['leaveType'] ?? $l['leave_type_code'] ?? 'Leave';
                break;
            }
        }

        // Leave treatment
        $leaveTreatments = $ruleProfile['leaveTreatments'] ?? [];
        $leaveTreatment = null;
        foreach ($leaveTreatments as $lt) {
            if (
                strtolower($lt['leaveTypeId'] ?? '') === strtolower($leaveType ?? '') ||
                strtolower($lt['leaveTypeName'] ?? '') === strtolower($leaveType ?? '')
            ) {
                $leaveTreatment = $lt;
                break;
            }
        }

        if (!$leaveTreatment) {
            $isPaidType = null;
            if ($matchedLeave !== null) {
                if (isset($matchedLeave['leave_is_paid'])) {
                    $isPaidType = !empty($matchedLeave['leave_is_paid']);
                } elseif (isset($matchedLeave['is_paid'])) {
                    $isPaidType = !empty($matchedLeave['is_paid']);
                }
            }

            $companyId = $employee['company_id'] ?? $log['company_id'] ?? null;
            if ($isPaidType === null && !empty($companyId)) {
                try {
                    $leaveRule = \App\Services\Rules\RuleResolver::resolve($companyId, 'LEAVE', $logDate, $employee);
                    $entitlements = $leaveRule->get('entitlements') ?: [];
                    $ltSearch = strtoupper(trim((string)($leaveType ?? '')));
                    foreach ($entitlements as $ent) {
                        if (strtoupper(trim((string)($ent['leave_type_code'] ?? ''))) === $ltSearch
                            || strtoupper(trim((string)($ent['leave_type_name'] ?? ''))) === $ltSearch) {
                            $isPaidType = !empty($ent['is_paid']);
                            break;
                        }
                    }
                } catch (\Throwable $e) {
                    log_message('error', 'RuleEngineService calculateDailyAttendance LEAVE resolution error: ' . $e->getMessage());
                }
            }

            if ($isPaidType === null) {
                $isPaidType = false;
            }

            $leaveTreatment = [
                'leaveTypeId' => 'default',
                'leaveTypeName' => $leaveType ?? 'Leave',
                'countsAsWorkingDay' => strtolower($leaveType ?? '') !== 'emergency' && strtolower($leaveType ?? '') !== 'unpaid',
                'countsAsWorkingHours' => $isPaidType,
                'creditedWorkingHoursPerDay' => $isPaidType ? $standardDailyHours : 0.0,
                'affectsOvertime' => false,
                'affectsWeeklyBonus' => true,
                'affectsAttendance' => true,
            ];
        }

        $isPaidLeave = !empty($leaveTreatment['countsAsWorkingHours']);

        $grossHours = 0.0;
        $breakHours = 0.0;
        $unpaidBreakHours = 0.0;
        $netHours = 0.0;
        $creditedHours = 0.0;
        $lateMinutes = 0;
        $isLate = false;
        $latePenaltyDeduction = 0.0;
        $latePenaltyHours = 0.0;
        $latePenaltyMessage = '';

        $earlyOutMinutes = 0;
        $isEarlyOut = false;
        $earlyOutPenaltyDeduction = 0.0;
        $earlyOutPenaltyHours = 0.0;

        $regularHours = 0.0;
        $dailyOvertimeHours = 0.0;
        $offDayOvertimeHours = 0.0;
        $holidayOvertimeHours = 0.0;

        $checkIn = $log['check_in'] ?? $log['checkIn'] ?? $log['in_time'] ?? (isset($log['clock_in']) ? date('H:i', strtotime($log['clock_in'])) : null);
        $checkOut = $log['check_out'] ?? $log['checkOut'] ?? $log['out_time'] ?? (isset($log['clock_out']) ? date('H:i', strtotime($log['clock_out'])) : null);

        // Corporate Early Closure Integration: also hydrate closure columns from DB if caller omitted them
        $skipClosureDb = self::$skipClosureLookup || !empty($log['skip_closure_lookup']) || !empty($employee['skip_closure_lookup']);
        if (!$skipClosureDb && is_array($log) && !array_key_exists('is_company_closure', $log) && !array_key_exists('isCompanyClosure', $log) && !array_key_exists('closure_credit_hours', $log)) {
            if (!empty($log['id']) || (!empty($empId) && !empty($logDate))) {
                try {
                    $db = \Config\Database::connect();
                    if ($db->tableExists('attendance_logs')) {
                        $qb = $db->table('attendance_logs');
                        if (!empty($log['id']) && $log['id'] !== 'seed') {
                            $qb->where('id', $log['id']);
                        } else {
                            $qb->where('employee_id', (string)$empId)->where('date', (string)$logDate);
                            if (!empty($employee['company_id'])) {
                                $qb->where('company_id', (string)$employee['company_id']);
                            }
                        }
                        $dbLogRow = $qb->get()->getRowArray();
                        if (is_array($dbLogRow) && \App\Models\AttendanceModel::isClosureLog($dbLogRow)) {
                            foreach (['is_company_closure', 'closure_credit_hours', 'actual_worked_hours', 'working_hours', 'late_minutes', 'status', 'remarks'] as $cCol) {
                                if (!isset($log[$cCol]) && isset($dbLogRow[$cCol])) {
                                    $log[$cCol] = $dbLogRow[$cCol];
                                }
                            }
                        }
                    }
                } catch (\Throwable $e) {
                    // Ignore DB lookup errors in pure in-memory contexts
                }
            }
        }

        $closureCredit = (float)($log['closure_credit_hours'] ?? $log['closureCreditHours'] ?? 0.0);
        $isCompanyClosure = \App\Models\AttendanceModel::isClosureLog($log) || !empty($log['isCompanyClosure']) || $closureCredit > 0;
        if ($isCompanyClosure && $closureCredit > 0) {
            $creditedHours += $closureCredit;
        }
        $activeSal = null;
        if (!empty($empId)) {
            try {
                $normDate = !empty($logDate) ? substr(trim((string)$logDate), 0, 10) : date('Y-m-d');
                $activeSal = $this->getSalaryService()->getActiveSalary((string)$empId, $normDate);
            } catch (\Throwable $e) {
                $activeSal = null;
            }
        }
        $basicSalary = (float)($activeSal['basic_salary'] ?? $employee['basic_salary'] ?? $employee['basicSalary'] ?? 0.0);
        $grossSalary = (float)($activeSal['gross_salary'] ?? $employee['gross_salary'] ?? $employee['grossSalary'] ?? $basicSalary);

        $earlyArrivalMinutes = 0;
        $earlyOtMinutes = 0;
        $postShiftMinutes = 0;
        $postShiftOtMinutes = 0;
        $otCalculationMode = 'Shift-Based (Shift vs Actual IN/OUT)';

        // Shift timings resolution
        $shiftStartTime = $shift['start_time'] ?? $shift['startTime'] ?? null;
        $shiftEndTime = $shift['end_time'] ?? $shift['endTime'] ?? null;
        $hasExplicitShift = (!empty($shiftStartTime) && !empty($shiftEndTime));

        $effectiveShiftStart = $shiftStartTime ?: '09:00';
        $effectiveShiftEnd = $shiftEndTime ?: '18:00';
        $shiftStartMins = self::timeStringToMinutes($effectiveShiftStart);
        $shiftEndMins = self::timeStringToMinutes($effectiveShiftEnd);

        $isOvernightShift = ($shiftEndMins <= $shiftStartMins) || !empty($shift['is_night_shift']) || !empty($shift['is_cross_midnight']);
        $effShiftEndMins = $isOvernightShift ? ($shiftEndMins + 1440) : $shiftEndMins;

        // Resolve grace period through fallback chain: rule profile -> shift grace_time -> company default
        $lateRule = $ruleProfile['lateRule'] ?? $ruleProfile['late_rule'] ?? ['enabled' => true, 'penaltyMethod' => 'Warning'];

        $profileGrace = null;
        if (isset($lateRule['gracePeriodMinutes']) && $lateRule['gracePeriodMinutes'] !== '' && $lateRule['gracePeriodMinutes'] !== null) {
            $profileGrace = (int)$lateRule['gracePeriodMinutes'];
        } elseif (isset($lateRule['grace_period_minutes']) && $lateRule['grace_period_minutes'] !== '' && $lateRule['grace_period_minutes'] !== null) {
            $profileGrace = (int)$lateRule['grace_period_minutes'];
        } elseif (isset($ruleProfile['late_grace_minutes']) && $ruleProfile['late_grace_minutes'] !== '' && $ruleProfile['late_grace_minutes'] !== null) {
            $profileGrace = (int)$ruleProfile['late_grace_minutes'];
        }

        $shiftGrace = null;
        if (isset($shift['grace_time']) && $shift['grace_time'] !== '' && $shift['grace_time'] !== null) {
            $shiftGrace = (int)$shift['grace_time'];
        } elseif (isset($shift['graceTime']) && $shift['graceTime'] !== '' && $shift['graceTime'] !== null) {
            $shiftGrace = (int)$shift['graceTime'];
        }

        $companyDefaultGrace = null;
        if (!empty($companyId)) {
            try {
                $policySettings = \App\Models\AttendanceModel::getPolicySettings($companyId);
                if (isset($policySettings['graceTime']) && $policySettings['graceTime'] !== '' && $policySettings['graceTime'] !== null) {
                    $companyDefaultGrace = (int)$policySettings['graceTime'];
                }
            } catch (\Throwable $e) {}
            if ($companyDefaultGrace === null) {
                try {
                    $attRule = \App\Services\Rules\RuleResolver::resolveForCompany($companyId, 'ATTENDANCE', $date);
                    $companyDefaultGrace = (int)$attRule->get('late_grace_minutes');
                } catch (\Throwable $e) {}
            }
        }
        if ($companyDefaultGrace === null) {
            $companyDefaultGrace = 15;
        }

        // Hierarchy: If profile has specific non-Company scope, profile wins.
        // If profile is Company scope and shift has explicit grace_time, shift wins.
        // Otherwise: rule profile -> shift grace_time -> company default.
        $profileScope = $ruleProfile['scopeLevel'] ?? $ruleProfile['scope_level'] ?? null;
        if ($profileGrace !== null && $profileScope === 'Company' && $shiftGrace !== null) {
            $gracePeriod = $shiftGrace;
        } else {
            $gracePeriod = $profileGrace ?? $shiftGrace ?? $companyDefaultGrace;
        }

        // Evaluate Late Arrival whenever check_in is present (regardless of whether checkout has occurred yet)
        $isScheduledShift = $hasExplicitShift && empty($shift['is_day_off']) && ($shift['outcome'] ?? '') !== 'NO_ASSIGNED_SHIFT' && ($shift['outcome'] ?? '') !== 'ROSTER_DAY_OFF' && (isset($shift['is_scheduled']) ? !empty($shift['is_scheduled']) : true);
        if (!empty($checkIn)) {
            $inMins = self::timeStringToMinutes($checkIn);
            if (!empty($lateRule['enabled']) && !$isWeeklyOff && !$isHoliday && $isScheduledShift) {
                if ($inMins > ($shiftStartMins + $gracePeriod)) {
                    $isLate = true;
                    $lateMinutes = $inMins - $shiftStartMins;
                    $method = $lateRule['penaltyMethod'] ?? $lateRule['penalty_method'] ?? 'Warning';

                    switch ($method) {
                        case 'Warning':
                            $latePenaltyMessage = "Late by {$lateMinutes}m (Grace: {$gracePeriod}m) - Warning logged";
                            break;
                        case 'Deduction':
                            $ratePerMin = (float)($lateRule['penaltyDeductionAmountPerMinute'] ?? $lateRule['penalty_deduction_amount_per_minute'] ?? ($basicSalary / (22 * $standardDailyHours * 60)));
                            $latePenaltyDeduction = round($lateMinutes * $ratePerMin, 2);
                            $latePenaltyMessage = "Late deduction of BDT {$latePenaltyDeduction}";
                            break;
                        case 'Reduce working hours':
                            $latePenaltyHours = round($lateMinutes / 60, 2);
                            $latePenaltyMessage = "Reduced working hours by {$latePenaltyHours}h";
                            break;
                        case 'Leave deduction':
                            $latePenaltyMessage = "Late flagged for monthly leave quota deduction per attendance rule";
                            break;
                        case 'Ignore':
                        default:
                            $latePenaltyMessage = "Late by {$lateMinutes}m (penalty ignored per rule profile)";
                            break;
                    }
                }
            }
        }

        if ($isCompanyClosure && !$isLate) {
            $existingLateMins = (int)($log['late_minutes'] ?? 0);
            $existingNormStatus = \App\Models\AttendanceModel::normalizeAttendanceStatus($log['status'] ?? '');
            if ($existingLateMins > 0 || in_array($existingNormStatus, ['Late', 'Late & Early Out'], true)) {
                $isLate = true;
                $lateMinutes = max($lateMinutes, $existingLateMins);
            }
        }

        $physicalNetHours = 0.0;
        if (!empty($checkIn) && !empty($checkOut)) {
            $inMins = self::timeStringToMinutes($checkIn);
            $outMins = self::timeStringToMinutes($checkOut);

            // Handle overnight shifts if checkout < checkin
            $grossMins = $outMins >= $inMins ? ($outMins - $inMins) : ($outMins + 1440 - $inMins);
            $grossHours = round($grossMins / 60, 2);

            // Break rule: Break hours MUST NOT be included in OT when unpaid
            $breakRule = $ruleProfile['breakRule'] ?? $ruleProfile['break_rule'] ?? null;
            if ($breakRule === null && !empty($employee['company_id'])) {
                try {
                    $attResolved = \App\Services\Rules\RuleResolver::resolveStatic((string)$employee['company_id'], 'ATTENDANCE', $date, $employee);
                    $attParams = $attResolved->params();
                    $breakRule = [
                        'enabled'              => !empty($attParams['break_enabled']),
                        'breakDurationMinutes' => (int)$attResolved->get('break_duration_minutes'),
                        'isPaid'               => !empty($attParams['break_is_paid']),
                        'unpaidBreakTreatment' => (string)$attResolved->get('unpaid_break_treatment'),
                        'autoDeductBreak'      => !empty($attParams['break_auto_deduct']),
                    ];
                } catch (\Throwable $e) {
                    $breakRule = ['enabled' => false, 'breakDurationMinutes' => 0, 'isPaid' => true, 'autoDeductBreak' => false];
                }
            }

            $isBreakEnabled = false;
            $isBreakPaid = false;
            $autoDeductBreak = false;
            $breakMins = 0;

            if ($breakRule !== null) {
                $isBreakEnabled = !empty($breakRule['enabled']) && $breakRule['enabled'] !== 'false' && $breakRule['enabled'] !== false && $breakRule['enabled'] !== 0 && $breakRule['enabled'] !== '0';
                $isBreakPaid = !empty($breakRule['isPaid']) || !empty($breakRule['is_paid']);
                $autoDeductBreak = !isset($breakRule['autoDeductBreak']) && !isset($breakRule['auto_deduct_break']) 
                    ? true 
                    : (!empty($breakRule['autoDeductBreak']) || !empty($breakRule['auto_deduct_break']));
                $breakMins = (int)($breakRule['breakDurationMinutes'] ?? $breakRule['break_duration_minutes'] ?? 0);
            }

            if ($isBreakEnabled) {
                $hasLoggedBreak = isset($log['break_hours']) && $log['break_hours'] !== null && $log['break_hours'] !== '';
                if ($hasLoggedBreak) {
                    $breakHours = round((float)$log['break_hours'], 2);
                } elseif ($autoDeductBreak && $breakMins > 0) {
                    // Only auto-deduct if employee actually worked long enough to take a break (> break duration and >= 4.0h)
                    if ($grossMins > $breakMins && $grossHours >= 4.0) {
                        $breakHours = round($breakMins / 60, 2);
                    }
                }

                if (!$isBreakPaid && $breakHours > 0) {
                    $unpaidBreakHours = $breakHours;
                }
            }

            // Formula: net_worked_hours = MAX(0, gross_hours - unpaid_break_hours)
            $netHours = max(0.0, round($grossHours - $unpaidBreakHours, 2));
            if ($latePenaltyHours > 0) {
                $netHours = max(0.0, round($netHours - $latePenaltyHours, 2));
            }

            $effOutMins = ($outMins < $inMins || ($isOvernightShift && $outMins <= $shiftEndMins)) ? ($outMins + 1440) : $outMins;

            // Early Departure evaluation
            $earlyOutRule = $ruleProfile['earlyOutRule'] ?? $ruleProfile['early_out_rule'] ?? ['enabled' => true, 'earlyOutThresholdMinutes' => 0, 'penaltyMethod' => 'Warning'];
            if (!empty($earlyOutRule['enabled']) && !$isWeeklyOff && !$isHoliday && !$isCompanyClosure && $isScheduledShift) {
                $earlyThreshold = (int)($earlyOutRule['earlyOutThresholdMinutes'] ?? $earlyOutRule['early_out_threshold_minutes'] ?? 0);
                if ($effOutMins < ($effShiftEndMins - $earlyThreshold)) {
                    $isEarlyOut = true;
                    $earlyOutMinutes = $effShiftEndMins - $effOutMins;
                    $method = $earlyOutRule['penaltyMethod'] ?? $earlyOutRule['penalty_method'] ?? 'Warning';

                    switch ($method) {
                        case 'Deduction':
                            $ratePerMin = (float)($earlyOutRule['penaltyDeductionAmountPerMinute'] ?? $earlyOutRule['penalty_deduction_amount_per_minute'] ?? ($basicSalary / (22 * $standardDailyHours * 60)));
                            $earlyOutPenaltyDeduction = round($earlyOutMinutes * $ratePerMin, 2);
                            break;
                        case 'Reduce working hours':
                            $earlyOutPenaltyHours = round($earlyOutMinutes / 60, 2);
                            $netHours = max(0.0, round($netHours - $earlyOutPenaltyHours, 2));
                            break;
                        case 'Warning':
                        case 'Leave deduction':
                        case 'Ignore':
                        default:
                            break;
                    }
                }
            }

            // Standard work allocation
            $physicalNetHours = $netHours;
            if ($isCompanyClosure) {
                $isEarlyOut = false;
                $earlyOutMinutes = 0;
                $earlyOutPenaltyDeduction = 0.0;
                $earlyOutPenaltyHours = 0.0;
                $netHours = max((float)($log['working_hours'] ?? 0.0), round($physicalNetHours + $closureCredit, 2));
                if ($netHours <= 0.0) {
                    $netHours = $standardDailyHours;
                }
            }
            $regularHours = min($standardDailyHours, $netHours);
        } elseif (!empty($log['working_hours']) && (float)$log['working_hours'] > 0) {
            $netHours = (float)$log['working_hours'];
            $physicalNetHours = isset($log['actual_worked_hours']) ? (float)$log['actual_worked_hours'] : max(0.0, round($netHours - $closureCredit, 2));
            $grossHours = $netHours;
            $regularHours = min($netHours, $standardDailyHours);
        } elseif ($isCompanyClosure && $closureCredit > 0) {
            $physicalNetHours = isset($log['actual_worked_hours']) ? (float)$log['actual_worked_hours'] : 0.0;
            $netHours = max(round($physicalNetHours + $closureCredit, 2), $standardDailyHours);
            $grossHours = $netHours;
            $regularHours = min($standardDailyHours, $netHours);
        } elseif ($isOnLeave) {
            if (!empty($leaveTreatment['countsAsWorkingHours'])) {
                $creditedHours = (float)($leaveTreatment['creditedWorkingHoursPerDay'] ?? $standardDailyHours);
            }
        } elseif ($isHoliday) {
            $holidayTreatment = $ruleProfile['holidayTreatment'] ?? ['countsAsWorkingHours' => true, 'creditedWorkingHours' => 8.0];
            if (!empty($holidayTreatment['countsAsWorkingHours'])) {
                $creditedHours = (float)($holidayTreatment['creditedWorkingHours'] ?? $standardDailyHours);
            }
        }

        // Determine final status
        $halfDayThreshold = (float)($ruleProfile['dailyHours']['halfDayThresholdHours'] ?? 4.0);
        $status = 'Absent';
        if ($isOnLeave) {
            $status = 'On Leave';
        } elseif ($dayType === 'HOLIDAY_DUTY' && empty($checkIn)) {
            $status = 'Absent (Holiday Duty)';
        } elseif ($dayType === 'WEEKEND_DUTY' && empty($checkIn)) {
            $status = 'Absent (Weekend Duty)';
        } elseif ($isHoliday && empty($checkIn)) {
            $status = 'Holiday';
        } elseif ($isWeeklyOff && empty($checkIn)) {
            $status = 'Weekly Off';
        } elseif (($dayType === 'ROSTER_DAY_OFF' || ($shift['outcome'] ?? '') === 'ROSTER_DAY_OFF' || !empty($shift['is_day_off'])) && empty($checkIn)) {
            $status = 'Day Off';
        } elseif (($dayType === 'UNSCHEDULED' || ($shift['outcome'] ?? '') === 'NO_ASSIGNED_SHIFT' || (isset($shift['is_scheduled']) && !$shift['is_scheduled'])) && empty($checkIn)) {
            $status = 'Unscheduled';
        } elseif ($isCompanyClosure && (!empty($checkIn) || $closureCredit > 0 || !empty($log['working_hours']) || \App\Models\AttendanceModel::isClosureLog($log))) {
            $status = $isLate ? 'Late' : 'Present (Early Closure)';
            $isEarlyOut = false;
            $earlyOutMinutes = 0;
            if ($netHours <= 0) {
                $netHours = max((float)($log['working_hours'] ?? 0.0), $closureCredit > 0 ? round($physicalNetHours + $closureCredit, 2) : $standardDailyHours);
                if ($netHours <= 0) {
                    $netHours = $standardDailyHours;
                }
            }
            if ($regularHours <= 0) {
                $regularHours = min($standardDailyHours, $netHours);
            }
        } elseif (!empty($checkIn)) {
            if (empty($checkOut)) {
                // If company early closure applies: dismissals at closure do not require evening check-out
                if ($isCompanyClosure) {
                    $status = $isLate ? 'Late' : 'Present (Early Closure)';
                    $isEarlyOut = false;
                    $earlyOutMinutes = 0;
                    if ($netHours <= 0) {
                        $netHours = (float)($log['working_hours'] ?? $standardDailyHours);
                    }
                    if ($regularHours <= 0) {
                        $regularHours = min($standardDailyHours, $netHours);
                    }
                } elseif ($date >= $today) {
                    if ($dayType === 'WEEKEND_DUTY') {
                        $status = 'Weekend Duty Present';
                    } elseif ($dayType === 'HOLIDAY_DUTY') {
                        $status = 'Holiday Duty Present';
                    } elseif ($isWeeklyOff || $dayType === 'ROSTER_DAY_OFF') {
                        $status = 'Off-Day Work';
                    } elseif ($dayType === 'UNSCHEDULED' || ($shift['outcome'] ?? '') === 'NO_ASSIGNED_SHIFT') {
                        $status = 'Present (Unscheduled)';
                    } elseif ($isLate) {
                        $status = 'Late';
                    } else {
                        $status = 'Present';
                    }
                } else {
                    $status = 'Missing Punch';
                    $netHours = 0.0;
                    $regularHours = 0.0;
                    $dailyOvertimeHours = 0.0;
                }
            } elseif ($dayType === 'WEEKEND_DUTY') {
                $status = 'Weekend Duty Present';
            } elseif ($dayType === 'HOLIDAY_DUTY') {
                $status = 'Holiday Duty Present';
            } elseif ($isWeeklyOff || $dayType === 'ROSTER_DAY_OFF') {
                $status = 'Off-Day Work';
            } elseif ($dayType === 'UNSCHEDULED' || ($shift['outcome'] ?? '') === 'NO_ASSIGNED_SHIFT') {
                $status = 'Present (Unscheduled)';
            } elseif ($isCompanyClosure) {
                $status = $isLate ? 'Late' : 'Present (Early Closure)';
            } elseif (!$isCompanyClosure && $netHours < $halfDayThreshold) {
                $status = 'Half Day';
            } elseif ($isLate && $isEarlyOut) {
                $status = 'Late & Early Out';
            } elseif ($isLate) {
                $status = 'Late';
            } elseif ($isEarlyOut) {
                $status = 'Early Out';
            } else {
                $status = 'Present';
            }
        } elseif (!empty($checkOut) && empty($checkIn)) {
            if ($isCompanyClosure) {
                $status = $isLate ? 'Late' : 'Present (Early Closure)';
                $isEarlyOut = false;
                $earlyOutMinutes = 0;
                if ($netHours <= 0) {
                    $netHours = (float)($log['working_hours'] ?? $standardDailyHours);
                }
                if ($regularHours <= 0) {
                    $regularHours = min($standardDailyHours, $netHours);
                }
            } else {
                $status = 'Missing Punch';
                $netHours = 0.0;
                $regularHours = 0.0;
                $dailyOvertimeHours = 0.0;
            }
        }

        $dailyOvertimeHours = 0.0;
        $offDayOvertimeHours = 0.0;
        $holidayOvertimeHours = 0.0;
        $earlyArrivalMinutes = 0;
        $earlyArrivalOtMinutes = 0;
        $earlyArrivalOtHours = 0.0;
        $postShiftMinutes = 0;
        $postShiftOtMinutes = 0;
        $postShiftOtHours = 0.0;
        $otApprovalStatus = 'Not Required';
        $otAmount = 0.0;
        $baseHourlyRate = 0.0;
        $normalMultiplier = 1.0;
        $offDayMultiplier = 1.0;
        $holidayMultiplier = 1.0;
        $otMultiplier = 1.0;
        $otRate = 0.0;
        $otCalculationMode = 'None';
        $isOtPayable = false;

        if (!empty($checkIn) && !empty($checkOut)) {
            if (($shift['outcome'] ?? '') === 'NO_ASSIGNED_SHIFT' || $dayType === 'UNSCHEDULED') {
                $dailyOvertimeHours = 0.0;
                $offDayOvertimeHours = 0.0;
                $holidayOvertimeHours = 0.0;
                $earlyArrivalMinutes = 0;
                $earlyArrivalOtMinutes = 0;
                $earlyArrivalOtHours = 0.0;
                $postShiftMinutes = 0;
                $postShiftOtMinutes = 0;
                $postShiftOtHours = 0.0;
                $otApprovalStatus = 'Pending Approval';
                $otAmount = 0.0;
                $isOtPayable = false;
            } else {
                $otService = new \App\Services\Overtime\OvertimeCalculationService();
                $otCalc = [];
                try {
                    $otCalc = $otService->calculateDailyOvertime(
                        $employee,
                        $log ?: ['date' => $date, 'check_in' => $checkIn, 'check_out' => $checkOut],
                        $shift,
                        null,
                        $holidays
                    );
                } catch (\Throwable $e) {
                    log_message('notice', 'Daily overtime calculation notice in calculateDailyAttendance: ' . $e->getMessage());
                }

            $earlyArrivalMinutes = (int)($otCalc['raw_early_minutes'] ?? 0);
            $earlyArrivalOtMinutes = (int)($otCalc['payable_early_minutes'] ?? 0);
            $earlyArrivalOtHours = round($earlyArrivalOtMinutes / 60, 2);

            $postShiftMinutes = (int)($otCalc['raw_post_minutes'] ?? 0);
            $postShiftOtMinutes = (int)($otCalc['payable_post_minutes'] ?? 0);
            $postShiftOtHours = round($postShiftOtMinutes / 60, 2);

            if ($otCalc['ot_type'] === 'Holiday') {
                $holidayOvertimeHours = (float)$otCalc['overtime_hours'];
                $holidayMultiplier = (float)$otCalc['multiplier'];
                $otMultiplier = $holidayMultiplier;
            } elseif ($otCalc['ot_type'] === 'Weekly Off') {
                $offDayOvertimeHours = (float)$otCalc['overtime_hours'];
                $offDayMultiplier = (float)$otCalc['multiplier'];
                $otMultiplier = $offDayMultiplier;
            } else {
                $dailyOvertimeHours = (float)$otCalc['overtime_hours'];
                $normalMultiplier = (float)$otCalc['multiplier'];
                $otMultiplier = $normalMultiplier;
            }

            $otApprovalStatus = $otCalc['approval_status'];
            $otAmount = (float)$otCalc['ot_amount'];
            $baseHourlyRate = (float)$otCalc['hourly_rate'];
            $otRate = (float)$otCalc['ot_rate'];
            $otCalculationMode = $otCalc['ot_type'];
            $isOtPayable = ($otApprovalStatus === 'Approved');

            // Closure credit must NEVER generate daily overtime
            if ($isCompanyClosure && $physicalNetHours <= $standardDailyHours && !$isHoliday && !$isWeeklyOff) {
                $dailyOvertimeHours = 0.0;
                $earlyArrivalOtMinutes = 0;
                $earlyArrivalOtHours = 0.0;
                $postShiftOtMinutes = 0;
                $postShiftOtHours = 0.0;
                $otAmount = 0.0;
                $isOtPayable = false;
                $otApprovalStatus = 'Not Required';
            }
        }
    }

        $totalOvertimeHours = round($dailyOvertimeHours + $offDayOvertimeHours + $holidayOvertimeHours, 2);
        $totalEffectiveHours = $isCompanyClosure
            ? round(max($netHours, $physicalNetHours + $creditedHours), 2)
            : round($netHours + $creditedHours, 2);

        return [
            'date' => $date,
            'employee_id' => $employee['id'] ?? '',
            'day_of_week' => $dayOfWeek,
            'day_type' => $dayType,
            'status_label' => $dayTypeEval['status_label'] ?? $status,
            'is_duty_assigned' => !empty($dutyAssignment),
            'duty_type' => $dutyAssignment['duty_type'] ?? null,
            'duty_assignment' => $dutyAssignment,
            'check_in' => $checkIn,
            'check_out' => $checkOut,
            'is_weekly_off' => $isWeeklyOff,
            'weekly_off_days' => $weeklyOffDays,
            'is_holiday' => $isHoliday,
            'holiday_name' => $holidayName,
            'is_on_leave' => $isOnLeave,
            'leave_type' => $leaveType,
            'is_paid_leave' => $isPaidLeave,
            'is_company_closure' => $isCompanyClosure ? 1 : 0,
            'closure_credit_hours' => $closureCredit,
            'physical_net_hours' => $physicalNetHours,
            'gross_hours' => $grossHours,
            'break_hours' => $breakHours,
            'unpaid_break_hours' => $unpaidBreakHours,
            'net_hours' => $netHours,
            'credited_hours' => $creditedHours,
            'total_effective_hours' => $totalEffectiveHours,
            'late_minutes' => $lateMinutes,
            'is_late' => $isLate,
            'late_penalty_deduction' => $latePenaltyDeduction,
            'late_penalty_hours' => $latePenaltyHours,
            'late_penalty_message' => $latePenaltyMessage,
            'early_out_minutes' => $earlyOutMinutes,
            'is_early_out' => $isEarlyOut,
            'early_out_penalty_deduction' => $earlyOutPenaltyDeduction,
            'early_out_penalty_hours' => $earlyOutPenaltyHours,
            'regular_hours' => $regularHours,
            'standard_daily_hours' => $standardDailyHours,
            'daily_overtime_hours' => $dailyOvertimeHours,
            'off_day_overtime_hours' => $offDayOvertimeHours,
            'holiday_overtime_hours' => $holidayOvertimeHours,
            'total_overtime_hours' => $totalOvertimeHours,
            'early_arrival_minutes' => $earlyArrivalMinutes,
            'early_arrival_ot_minutes' => $earlyArrivalOtMinutes,
            'early_arrival_ot_hours' => $earlyArrivalOtHours,
            'post_shift_minutes' => $postShiftMinutes,
            'post_shift_ot_minutes' => $postShiftOtMinutes,
            'post_shift_ot_hours' => $postShiftOtHours,
            'shift_start_time' => $shiftStartTime ?? null,
            'shift_end_time' => $shiftEndTime ?? null,
            'ot_calculation_mode' => $otCalculationMode,
            'ot_approval_status' => $otApprovalStatus,
            'ot_multiplier' => $otMultiplier,
            'off_day_multiplier' => $offDayMultiplier,
            'holiday_multiplier' => $holidayMultiplier,
            'base_hourly_rate' => $baseHourlyRate,
            'ot_rate' => $otRate,
            'ot_amount' => $otAmount,
            'is_ot_payable' => $isOtPayable,
            'grace_minutes' => $gracePeriod,
            'grace_period' => $gracePeriod,
            'status' => $status,
            'rule_profile_applied' => [
                'id' => $ruleProfile['id'] ?? 'RULE-GLOBAL',
                'name' => $ruleProfile['name'] ?? 'Global Standard Attendance & Overtime Policy',
                'version' => $ruleProfile['version'] ?? 1,
                'scope_level' => $ruleProfile['scopeLevel'] ?? 'Global'
            ]
        ];
    }

    /**
     * WEEKLY AGGREGATION & BONUS ENGINE
     *
     * Aggregates daily calculations across a working week and computes:
     * - Hours and Attendance Totals (Actual Worked, Regular, Credited)
     * - Attendance Anomaly Deductions (Late, Early Out, Unpaid Leave)
     * - Weekly & Periodic Bonus Rule Engine
     */
    public function calculateWeeklyAttendance(
        string $weekStartDate,
        string $weekEndDate,
        array $employee,
        array $dailyResults,
        array $ruleProfile
    ): array {
        $weekNumber = (int)date('W', strtotime($weekStartDate));

        $presentDaysCount = 0;
        $absentDaysCount = 0;
        $leaveDaysCount = 0;
        $holidayDaysCount = 0;
        $weeklyOffDaysWorked = 0;
        $lateDaysCount = 0;
        $missingPunchDaysCount = 0;

        $actualWorkedHours = 0.0;
        $creditedHours = 0.0;
        $totalRegularHoursSum = 0.0;

        $totalLateDeduction = 0.0;
        $totalEarlyOutDeduction = 0.0;
        $totalUnpaidLeaveDeduction = 0.0;

        $empId = $employee['id'] ?? $employee['employee_id'] ?? null;
        $asOfDate = !empty($dailyResults) ? ($dailyResults[0]['date'] ?? date('Y-m-d')) : date('Y-m-d');
        $activeSal = null;
        if (!empty($empId)) {
            try {
                $normAsOfDate = !empty($asOfDate) ? substr(trim((string)$asOfDate), 0, 10) : date('Y-m-d');
                $activeSal = $this->getSalaryService()->getActiveSalary((string)$empId, $normAsOfDate);
            } catch (\Throwable $e) {
                $activeSal = null;
            }
        }
        $basicSalary = (float)($activeSal['basic_salary'] ?? $employee['basic_salary'] ?? $employee['basicSalary'] ?? 0.0);

        // Resolve company_id strictly
        $companyId = $employee['company_id'] ?? ($employee['companyId'] ?? null);
        if (empty($companyId) && function_exists('session')) {
            try {
                $companyId = (string)(session('selected_company_id') ?: session('company_id') ?: '');
            } catch (\Throwable $e) {}
        }
        if (empty($companyId)) {
            throw new RuleNotConfiguredException("Missing company_id for attendance and bonus rule resolution.");
        }

        // Dynamically derive required working days from employee weekly-off and standard daily hours from PAYROLL_BASICS
        $workingDays = CompanyWeekendService::getCompanyWorkingDays($companyId, $empId);
        $requiredWorkingDays = count($workingDays);
        if ($requiredWorkingDays <= 0) {
            throw new RuleNotConfiguredException(
                "No working days configured for company '{$companyId}' and employee '{$empId}'",
                $companyId,
                'ATTENDANCE',
                $asOfDate
            );
        }

        $basicsRule = RuleResolver::resolveForCompany($companyId, 'PAYROLL_BASICS', $asOfDate);
        $standardDailyHours = (float)$basicsRule->get('standard_daily_hours');
        if ($standardDailyHours <= 0) {
            throw new RuleNotConfiguredException(
                "Invalid or zero standard_daily_hours in PAYROLL_BASICS for company '{$companyId}'",
                $companyId,
                'PAYROLL_BASICS',
                $asOfDate
            );
        }
        $requiredWeeklyHours = round($requiredWorkingDays * $standardDailyHours, 2);

        foreach ($dailyResults as $day) {
            $dayCredited = (float)($day['credited_hours'] ?? $day['creditedHours'] ?? $day['closure_credit_hours'] ?? 0);
            $dayNet = (float)($day['net_hours'] ?? $day['netHours'] ?? $day['working_hours'] ?? 0);
            if (\App\Models\AttendanceModel::isClosureLog($day) && $dayCredited > 0) {
                $dayActual = isset($day['physical_net_hours'])
                    ? (float)$day['physical_net_hours']
                    : (isset($day['actual_worked_hours'])
                        ? (float)$day['actual_worked_hours']
                        : max(0.0, round($dayNet - $dayCredited, 2)));
            } else {
                $dayActual = $dayNet;
            }
            $actualWorkedHours += $dayActual;
            $creditedHours += $dayCredited;
            $totalRegularHoursSum += (float)($day['regular_hours'] ?? $day['regularHours'] ?? 0);

            $totalLateDeduction += (float)($day['late_penalty_deduction'] ?? $day['latePenaltyDeduction'] ?? 0);
            $totalEarlyOutDeduction += (float)($day['early_out_penalty_deduction'] ?? $day['earlyOutPenaltyDeduction'] ?? 0);

            $st = $day['status'] ?? 'Absent';
            if (\App\Models\AttendanceModel::isPresentLike($st, $day)) {
                $presentDaysCount++;
            } elseif ($st === 'Missing Punch') {
                $missingPunchDaysCount++;
            } elseif ($st === 'On Leave') {
                $leaveDaysCount++;
                if (empty($day['is_paid_leave']) && empty($day['isPaidLeave'])) {
                    $divisorDays = (float)$basicsRule->get('daily_rate_divisor');
                    if ($divisorDays <= 0) {
                        throw new RuleNotConfiguredException(
                            "Invalid or zero daily_rate_divisor in PAYROLL_BASICS for company '{$companyId}'",
                            $companyId,
                            'PAYROLL_BASICS',
                            $asOfDate
                        );
                    }
                    $dailyRate = $basicSalary / $divisorDays;
                    $totalUnpaidLeaveDeduction += round($dailyRate, 2);
                }
            } elseif ($st === 'Holiday') {
                $holidayDaysCount++;
            } elseif ($st === 'Absent') {
                $absentDaysCount++;
            }

            if (!empty($day['is_weekly_off']) || !empty($day['isWeeklyOff'])) {
                if (($day['net_hours'] ?? $day['netHours'] ?? 0) > 0) {
                    $weeklyOffDaysWorked++;
                }
            }

            if (!empty($day['is_late']) || !empty($day['isLate'])) {
                $lateDaysCount++;
            }
        }

        $totalComputedHours = round($actualWorkedHours + $creditedHours, 2);
        $regularHours = round($totalRegularHoursSum, 2);

        $isAllDaysCompleted = ($presentDaysCount + $leaveDaysCount + $holidayDaysCount) >= $requiredWorkingDays;
        $missingDayRule = $ruleProfile['missingDayRule'] ?? ['policy' => 'Actual Hours Only'];

        // WEEKLY BONUS CALCULATION WITH RULE RESOLVER (Single Source of Truth)
        $resolvedBonus = RuleResolver::resolve($companyId, 'BONUS', $asOfDate, $employee);
        $bonusRuleParams = $resolvedBonus->params();

        if (!array_key_exists('weekly_bonus_enabled', $bonusRuleParams)) {
            throw new RuleNotConfiguredException(
                "Missing required 'weekly_bonus_enabled' rule parameter for company '{$companyId}'",
                $companyId,
                'BONUS',
                $asOfDate
            );
        }

        $bonusEnabled = (bool)$bonusRuleParams['weekly_bonus_enabled'];
        $isBonusEligible = false;
        $bonusIneligibilityReason = '';
        $bonusAmount = 0.0;
        $bonusMethodUsed = 'Disabled';

        if ($bonusEnabled) {
            $requiredParams = [
                'weekly_bonus_method',
                'weekly_bonus_min_present_days',
                'weekly_bonus_min_weekly_hours',
                'weekly_bonus_max_allowed_lates',
                'weekly_bonus_full_attendance_required',
                'weekly_bonus_late_allowed',
                'weekly_bonus_leave_allowed',
            ];

            foreach ($requiredParams as $reqParam) {
                if (!array_key_exists($reqParam, $bonusRuleParams)) {
                    throw new RuleNotConfiguredException(
                        "Missing required '{$reqParam}' rule parameter for company '{$companyId}'",
                        $companyId,
                        'BONUS',
                        $asOfDate
                    );
                }
            }

            $method = (string)$bonusRuleParams['weekly_bonus_method'];
            $bonusMethodUsed = $method;
            $minDays = (int)$bonusRuleParams['weekly_bonus_min_present_days'];
            $minHours = (float)$bonusRuleParams['weekly_bonus_min_weekly_hours'];
            $maxLates = (int)$bonusRuleParams['weekly_bonus_max_allowed_lates'];
            $fullAttendanceRequired = (bool)$bonusRuleParams['weekly_bonus_full_attendance_required'];
            $lateAllowed = (bool)$bonusRuleParams['weekly_bonus_late_allowed'];
            $leaveAllowed = (bool)$bonusRuleParams['weekly_bonus_leave_allowed'];

            if (!$isAllDaysCompleted && empty($missingDayRule['allowWeeklyBonusIfHoursMet']) && ($missingDayRule['policy'] ?? '') === 'No Weekly Bonus') {
                $isBonusEligible = false;
                $bonusIneligibilityReason = "Missing working days: required {$requiredWorkingDays}, completed {$presentDaysCount}";
            } elseif ($presentDaysCount < $minDays) {
                $isBonusEligible = false;
                $bonusIneligibilityReason = "Present days ({$presentDaysCount}) below required minimum ({$minDays})";
            } elseif (($actualWorkedHours + $creditedHours) < $minHours) {
                $isBonusEligible = false;
                $effectiveQualifyingHours = round($actualWorkedHours + $creditedHours, 2);
                $bonusIneligibilityReason = "Weekly qualifying hours ({$effectiveQualifyingHours}h) below minimum ({$minHours}h)";
            } elseif ($fullAttendanceRequired && $absentDaysCount > 0) {
                $isBonusEligible = false;
                $bonusIneligibilityReason = "Full attendance required; recorded {$absentDaysCount} absent days";
            } elseif (!$lateAllowed && $lateDaysCount > $maxLates) {
                $isBonusEligible = false;
                $bonusIneligibilityReason = "Exceeded allowed late days (recorded {$lateDaysCount}, max allowed {$maxLates})";
            } elseif (!$leaveAllowed && $leaveDaysCount > 0) {
                $isBonusEligible = false;
                $bonusIneligibilityReason = "Leave taken during bonus qualification period";
            } else {
                $isBonusEligible = true;
            }

            if ($isBonusEligible) {
                switch ($method) {
                    case 'Fixed Amount':
                        if (!array_key_exists('weekly_bonus_fixed_amount', $bonusRuleParams)) {
                            throw new RuleNotConfiguredException(
                                "Missing required 'weekly_bonus_fixed_amount' rule parameter for company '{$companyId}'",
                                $companyId,
                                'BONUS',
                                $asOfDate
                            );
                        }
                        $bonusAmount = (float)$bonusRuleParams['weekly_bonus_fixed_amount'];
                        break;

                    case 'Percentage of Basic':
                        if (!array_key_exists('weekly_bonus_percentage_of_basic', $bonusRuleParams)) {
                            throw new RuleNotConfiguredException(
                                "Missing required 'weekly_bonus_percentage_of_basic' rule parameter for company '{$companyId}'",
                                $companyId,
                                'BONUS',
                                $asOfDate
                            );
                        }
                        $pct = (float)$bonusRuleParams['weekly_bonus_percentage_of_basic'];
                        $bonusAmount = round(($basicSalary * ($pct / 100)) / 4.33, 2);
                        break;

                    case 'Hour Based':
                        $overrideRate = null;
                        if (isset($bonusRuleParams['weekly_bonus_rate_per_hour']) && $bonusRuleParams['weekly_bonus_rate_per_hour'] !== null && (float)$bonusRuleParams['weekly_bonus_rate_per_hour'] > 0) {
                            $overrideRate = (float)$bonusRuleParams['weekly_bonus_rate_per_hour'];
                        }

                        if ($overrideRate !== null) {
                            $ratePerHour = $overrideRate;
                        } else {
                            // Compute employee's own hourly rate using OvertimeCalculationService::calculateHourlyRate()
                            $divMode = (string)$basicsRule->get('daily_rate_mode');
                            $divisorDays = (float)$basicsRule->get('daily_rate_divisor');
                            $stDailyHours = (float)$basicsRule->get('standard_daily_hours');

                            $otPolicy = [
                                'salary_basis'         => 'Basic Salary',
                                'divisor_mode'         => ($divMode === 'Calendar') ? 'Calendar Days' : 'Custom',
                                'divisor_days'         => $divisorDays,
                                'standard_daily_hours' => $stDailyHours,
                                'divisor_hours'        => $stDailyHours,
                            ];

                            $otCalcService = new \App\Services\Overtime\OvertimeCalculationService();
                            $hourlyRateResult = $otCalcService->calculateHourlyRate($employee, $otPolicy, $asOfDate);
                            $ratePerHour = (float)($hourlyRateResult['hourly_rate'] ?? 0.0);
                        }

                        $bonusHours = max(0.0, $actualWorkedHours - $requiredWeeklyHours);
                        $bonusAmount = round($bonusHours * $ratePerHour, 2);
                        break;

                    case 'Tier Based':
                        if (!array_key_exists('weekly_bonus_tiers', $bonusRuleParams)) {
                            throw new RuleNotConfiguredException(
                                "Missing required 'weekly_bonus_tiers' rule parameter for company '{$companyId}'",
                                $companyId,
                                'BONUS',
                                $asOfDate
                            );
                        }
                        $rawTiers = $bonusRuleParams['weekly_bonus_tiers'];
                        if (!is_array($rawTiers)) {
                            throw new RuleNotConfiguredException(
                                "Invalid or non-array 'weekly_bonus_tiers' rule parameter for company '{$companyId}'",
                                $companyId,
                                'BONUS',
                                $asOfDate
                            );
                        }
                        $matchedAmount = 0.0;
                        foreach ($rawTiers as $t) {
                            $tMin = (float)($t['min_hours'] ?? $t['minHours'] ?? 0);
                            $tMax = (float)($t['max_hours'] ?? $t['maxHours'] ?? 0);
                            $tAmt = (float)($t['bonus_amount'] ?? $t['bonusAmount'] ?? 0);
                            if ($actualWorkedHours >= $tMin && $actualWorkedHours <= $tMax) {
                                $matchedAmount = $tAmt;
                                break;
                            }
                        }
                        if ($matchedAmount <= 0 && !empty($rawTiers)) {
                            // Check if above highest tier
                            usort($rawTiers, function($a, $b) {
                                $bMax = (float)($b['max_hours'] ?? $b['maxHours'] ?? 0);
                                $aMax = (float)($a['max_hours'] ?? $a['maxHours'] ?? 0);
                                return $bMax <=> $aMax;
                            });
                            $topTier = reset($rawTiers);
                            $topMax = (float)($topTier['max_hours'] ?? $topTier['maxHours'] ?? 0);
                            if ($topTier && $actualWorkedHours > $topMax) {
                                $matchedAmount = (float)($topTier['bonus_amount'] ?? $topTier['bonusAmount'] ?? 0);
                            }
                        }
                        $bonusAmount = $matchedAmount;
                        break;

                    default:
                        throw new RuleNotConfiguredException(
                            "Unsupported weekly_bonus_method '{$method}' for company '{$companyId}'",
                            $companyId,
                            'BONUS',
                            $asOfDate
                        );
                }
            }
        } else {
            $bonusIneligibilityReason = 'Weekly Bonus is disabled in rule configuration';
        }

        return [
            'week_number' => $weekNumber,
            'week_start_date' => $weekStartDate,
            'week_end_date' => $weekEndDate,
            'employee_id' => $employee['id'] ?? '',
            'employee_name' => trim(($employee['first_name'] ?? '') . ' ' . ($employee['last_name'] ?? $employee['name'] ?? '')),
            'required_working_days' => $requiredWorkingDays,
            'required_weekly_hours' => $requiredWeeklyHours,
            'present_days_count' => $presentDaysCount,
            'absent_days_count' => $absentDaysCount,
            'leave_days_count' => $leaveDaysCount,
            'holiday_days_count' => $holidayDaysCount,
            'weekly_off_days_worked' => $weeklyOffDaysWorked,
            'late_days_count' => $lateDaysCount,
            'missing_punch_count' => $missingPunchDaysCount,
            'actual_worked_hours' => $actualWorkedHours,
            'credited_hours' => $creditedHours,
            'total_computed_hours' => $totalComputedHours,
            'regular_hours' => $regularHours,
            'is_bonus_eligible' => $isBonusEligible,
            'bonus_ineligibility_reason' => $bonusIneligibilityReason,
            'bonus_amount' => $bonusAmount,
            'bonus_method_used' => $bonusMethodUsed,
            'total_late_deduction' => $totalLateDeduction,
            'total_early_out_deduction' => $totalEarlyOutDeduction,
            'total_unpaid_leave_deduction' => $totalUnpaidLeaveDeduction,
            'daily_breakdown' => $dailyResults,
            'rule_profile_applied' => [
                'id' => $ruleProfile['id'] ?? 'RULE-GLOBAL',
                'name' => $ruleProfile['name'] ?? 'Global Standard Attendance & Overtime Policy',
                'version' => $ruleProfile['version'] ?? 1,
                'scope_level' => $ruleProfile['scopeLevel'] ?? 'Global'
            ]
        ];
    }

    // =========================================================================
    // SIMULATION TEST SUITE ONLY (ISOLATED FIXTURES - NOT FOR PRODUCTION FLOWS)
    // =========================================================================
    // The fixtures below are strictly used by the Attendance Rule Engine
    // Test Runner UI to verify edge-case calculation parity against specifications.
    // They are completely isolated from live attendance and payroll execution.
    // =========================================================================

    /**
     * Resolve valid company ID for simulation fixtures.
     * Checks passed companyId, profile lists, session, CompanyModel, rule_definitions, and companies table.
     */
    protected function resolveSimulationCompanyId(?string $companyId = null, ?array $profiles = null): ?string
    {
        if (!empty($companyId)) {
            return (string)$companyId;
        }

        if (!empty($profiles)) {
            foreach ($profiles as $p) {
                if (!empty($p['company_id'])) {
                    return (string)$p['company_id'];
                }
            }
        }

        if (function_exists('session')) {
            try {
                $sessComp = session('selected_company_id') ?: session('company_id');
                if (!empty($sessComp)) {
                    return (string)$sessComp;
                }
            } catch (\Throwable $e) {}
        }

        try {
            $compModel = new \App\Models\CompanyModel();
            $first = $compModel->select('id')->orderBy('id', 'ASC')->first();
            if (!empty($first['id'])) {
                return (string)$first['id'];
            }
        } catch (\Throwable $e) {}

        try {
            $db = \Config\Database::connect();
            if ($db->tableExists('rule_definitions')) {
                $firstRule = $db->table('rule_definitions')
                    ->select('company_id')
                    ->where('company_id IS NOT NULL')
                    ->where('company_id !=', '')
                    ->get(1)
                    ->getRowArray();
                if (!empty($firstRule['company_id'])) {
                    return (string)$firstRule['company_id'];
                }
            }
        } catch (\Throwable $e) {}

        try {
            $db = \Config\Database::connect();
            if ($db->tableExists('companies')) {
                $first = $db->table('companies')->select('id')->orderBy('id', 'ASC')->get(1)->getRowArray();
                if (!empty($first['id'])) {
                    return (string)$first['id'];
                }
            }
        } catch (\Throwable $e) {}

        try {
            $db = \Config\Database::connect();
            if ($db->tableExists('employees')) {
                $firstEmp = $db->table('employees')->select('company_id')->where('company_id IS NOT NULL')->where('company_id !=', '')->get(1)->getRowArray();
                if (!empty($firstEmp['company_id'])) {
                    return (string)$firstEmp['company_id'];
                }
            }
        } catch (\Throwable $e) {}

        return null;
    }

}
