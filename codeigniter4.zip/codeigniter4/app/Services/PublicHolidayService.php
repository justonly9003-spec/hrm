<?php

namespace App\Services;

use App\Models\CompanyModel;
use App\Models\HolidayModel;
use CodeIgniter\I18n\Time;
use Config\Database;

/**
 * Public Holiday Service
 *
 * Single point of truth for fetching, parsing, caching, and synchronizing
 * statutory public holidays from an authoritative Holiday API (Nager.Date v3 by default,
 * configurable via HOLIDAY_API_BASE_URL and optional HOLIDAY_API_KEY).
 *
 * Includes:
 * - Country-specific statutory holiday resolution (ISO-3166-1 alpha-2)
 * - Multi-year holiday retrieval
 * - Response parsing & normalization to the application's holidays schema
 * - Multi-layer in-memory and persistent caching to prevent API rate limits
 * - Strict de-duplication when persisting holidays into the company calendar
 * - Resilient offline/timeout fallback mechanism
 * - Explicit distinction between general public holidays and financial market holidays
 */
class PublicHolidayService
{
    /**
     * Default public holiday API base endpoint (Nager.Date v3 - Free, no registration required, 110+ countries)
     */
    public const DEFAULT_API_BASE_URL = 'https://date.nager.at/api/v3';

    /**
     * Request timeout in seconds
     */
    protected int $timeout = 5;

    /**
     * Request-level in-memory cache
     */
    protected static array $inMemoryCache = [];

    /**
     * Country Name to ISO 3166-1 alpha-2 mapping dictionary
     */
    protected static array $countryCodeMap = [
        'UNITED STATES'          => 'US',
        'USA'                    => 'US',
        'BANGLADESH'             => 'BD',
        'UNITED KINGDOM'          => 'GB',
        'UK'                     => 'GB',
        'GREAT BRITAIN'          => 'GB',
        'CANADA'                 => 'CA',
        'AUSTRALIA'              => 'AU',
        'INDIA'                  => 'IN',
        'GERMANY'                => 'DE',
        'FRANCE'                 => 'FR',
        'JAPAN'                  => 'JP',
        'SINGAPORE'              => 'SG',
        'MALAYSIA'               => 'MY',
        'UNITED ARAB EMIRATES'   => 'AE',
        'UAE'                    => 'AE',
        'SAUDI ARABIA'           => 'SA',
        'PAKISTAN'               => 'PK',
        'NETHERLANDS'            => 'NL',
        'SWITZERLAND'            => 'CH',
        'SWEDEN'                 => 'SE',
        'NORWAY'                 => 'NO',
        'DENMARK'                => 'DK',
        'FINLAND'                => 'FI',
        'IRELAND'                => 'IE',
        'NEW ZEALAND'            => 'NZ',
        'SOUTH AFRICA'           => 'ZA',
        'BRAZIL'                 => 'BR',
        'MEXICO'                 => 'MX',
        'SPAIN'                  => 'ES',
        'ITALY'                  => 'IT',
        'TURKEY'                 => 'TR',
        'INDONESIA'              => 'ID',
        'PHILIPPINES'            => 'PH',
        'VIETNAM'                => 'VN',
        'THAILAND'               => 'TH',
        'CHINA'                  => 'CN',
        'HONG KONG'              => 'HK',
        'SOUTH KOREA'            => 'KR',
        'KOREA'                  => 'KR',
        'EGYPT'                  => 'EG',
        'NIGERIA'                => 'NG',
        'KENYA'                  => 'KE',
    ];

    /**
     * Clear all static in-memory caches
     */
    public static function clearCache(): void
    {
        self::$inMemoryCache = [];
    }

    /**
     * Get API Base URL from environment or default
     */
    public function getApiBaseUrl(): string
    {
        $url = env('HOLIDAY_API_BASE_URL') ?: (getenv('HOLIDAY_API_BASE_URL') ?: self::DEFAULT_API_BASE_URL);
        return rtrim((string)$url, '/');
    }

    /**
     * Convert country name or code to ISO 3166-1 alpha-2 uppercase
     */
    public function resolveCountryCode(?string $country): ?string
    {
        if (empty($country)) {
            return null;
        }

        $clean = strtoupper(trim($country));
        if (strlen($clean) === 2 && ctype_alpha($clean)) {
            return $clean;
        }

        return self::$countryCodeMap[$clean] ?? null;
    }

    /**
     * Check if country is recognized
     */
    public function isCountrySupported(?string $country): bool
    {
        $code = $this->resolveCountryCode($country);
        return !empty($code);
    }

    /**
     * Get supported country list with ISO code and display name
     */
    public function getSupportedCountries(): array
    {
        $list = [
            ['code' => 'US', 'name' => 'United States'],
            ['code' => 'BD', 'name' => 'Bangladesh'],
            ['code' => 'GB', 'name' => 'United Kingdom'],
            ['code' => 'CA', 'name' => 'Canada'],
            ['code' => 'AU', 'name' => 'Australia'],
            ['code' => 'IN', 'name' => 'India'],
            ['code' => 'DE', 'name' => 'Germany'],
            ['code' => 'FR', 'name' => 'France'],
            ['code' => 'JP', 'name' => 'Japan'],
            ['code' => 'SG', 'name' => 'Singapore'],
            ['code' => 'MY', 'name' => 'Malaysia'],
            ['code' => 'AE', 'name' => 'United Arab Emirates'],
            ['code' => 'SA', 'name' => 'Saudi Arabia'],
            ['code' => 'NL', 'name' => 'Netherlands'],
            ['code' => 'CH', 'name' => 'Switzerland'],
            ['code' => 'IE', 'name' => 'Ireland'],
            ['code' => 'NZ', 'name' => 'New Zealand'],
            ['code' => 'BR', 'name' => 'Brazil'],
            ['code' => 'ZA', 'name' => 'South Africa'],
            ['code' => 'ES', 'name' => 'Spain'],
            ['code' => 'IT', 'name' => 'Italy'],
        ];

        usort($list, fn($a, $b) => strcmp($a['name'], $b['name']));
        return $list;
    }

    /**
     * Fetch public holidays from API for a country and year with caching and fallback.
     *
     * @param string $country Country name or ISO alpha-2 code
     * @param int|null $year Year (defaults to current year)
     * @return array{success: bool, source: string, country_code: string, year: int, holidays: array, message: string}
     */
    public function fetchPublicHolidays(string $country, ?int $year = null): array
    {
        $year = $year ?: (int)date('Y');
        $countryCode = $this->resolveCountryCode($country);

        if (!$countryCode) {
            return [
                'success'      => false,
                'source'       => 'validation_error',
                'country_code' => '',
                'year'         => $year,
                'holidays'     => [],
                'message'      => "Unsupported or invalid country: '{$country}'. Please provide a valid ISO-2 country code.",
            ];
        }

        $cacheKey = "api_{$countryCode}_{$year}";
        if (isset(self::$inMemoryCache[$cacheKey])) {
            return [
                'success'      => true,
                'source'       => 'in_memory_cache',
                'country_code' => $countryCode,
                'year'         => $year,
                'holidays'     => self::$inMemoryCache[$cacheKey],
                'message'      => 'Holidays loaded from memory cache.',
            ];
        }

        // Check CI4 file/redis cache if available
        $ciCache = null;
        if (function_exists('cache')) {
            try {
                $ciCache = cache();
                if ($ciCache && ($cachedData = $ciCache->get("pub_hol_{$countryCode}_{$year}"))) {
                    if (is_array($cachedData) && !empty($cachedData)) {
                        self::$inMemoryCache[$cacheKey] = $cachedData;
                        return [
                            'success'      => true,
                            'source'       => 'system_cache',
                            'country_code' => $countryCode,
                            'year'         => $year,
                            'holidays'     => $cachedData,
                            'message'      => 'Holidays loaded from system cache.',
                        ];
                    }
                }
            } catch (\Throwable $e) {}
        }

        $apiUrl = $this->getApiBaseUrl() . "/PublicHolidays/{$year}/{$countryCode}";
        $rawResponse = null;
        $httpCode = 0;
        $errorMessage = '';

        try {
            if (class_exists(\Config\Services::class) && method_exists(\Config\Services::class, 'curlrequest')) {
                $client = \Config\Services::curlrequest([
                    'timeout'     => $this->timeout,
                    'http_errors' => false,
                    'headers'     => [
                        'Accept'     => 'application/json',
                        'User-Agent' => 'Enterprise-HRMS-Holiday-Engine/1.0',
                    ],
                ]);
                $response = $client->get($apiUrl);
                $httpCode = $response->getStatusCode();
                $rawResponse = $response->getBody();
            } else {
                $context = stream_context_create([
                    'http' => [
                        'method'  => 'GET',
                        'timeout' => $this->timeout,
                        'header'  => "Accept: application/json\r\nUser-Agent: Enterprise-HRMS-Holiday-Engine/1.0\r\n",
                    ],
                ]);
                $rawResponse = @file_get_contents($apiUrl, false, $context);
                $httpCode = $rawResponse !== false ? 200 : 0;
            }
        } catch (\Throwable $ex) {
            $errorMessage = $ex->getMessage();
            $rawResponse = null;
        }

        if ($rawResponse !== null && ($httpCode === 200 || $httpCode === 0)) {
            $parsed = json_decode((string)$rawResponse, true);
            if (is_array($parsed)) {
                $normalized = $this->normalizeApiResponse($parsed, $countryCode, $year);

                self::$inMemoryCache[$cacheKey] = $normalized;
                if ($ciCache) {
                    try {
                        // Cache for 24 hours (86400 seconds)
                        $ciCache->save("pub_hol_{$countryCode}_{$year}", $normalized, 86400);
                    } catch (\Throwable $e) {}
                }

                return [
                    'success'      => true,
                    'source'       => 'holiday_api',
                    'country_code' => $countryCode,
                    'year'         => $year,
                    'holidays'     => $normalized,
                    'message'      => sprintf('Retrieved %d official public holidays from API for %s (%d).', count($normalized), $countryCode, $year),
                ];
            }
        }

        // Graceful fallback to static standard statutory holidays when API is unreachable
        $fallbackHolidays = $this->getStaticFallbackHolidays($countryCode, $year);
        self::$inMemoryCache[$cacheKey] = $fallbackHolidays;

        return [
            'success'      => false,
            'source'       => 'fallback_offline',
            'country_code' => $countryCode,
            'year'         => $year,
            'holidays'     => $fallbackHolidays,
            'message'      => "Public Holiday API unreachable ({$errorMessage}). Providing standard statutory gazetted schedule.",
        ];
    }

    /**
     * Normalize JSON response from Nager.Date v3 or compatible holiday API
     */
    public function normalizeApiResponse(array $items, string $countryCode, int $year): array
    {
        $normalized = [];
        $seen = [];

        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }

            $date = $item['date'] ?? null;
            $name = trim((string)($item['name'] ?? ($item['localName'] ?? 'Public Holiday')));
            if (!$date || !$name || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
                continue;
            }

            // Deduplicate within API response
            $dedupKey = $date . '_' . strtolower($name);
            if (isset($seen[$dedupKey])) {
                continue;
            }
            $seen[$dedupKey] = true;

            $types = $item['types'] ?? [];
            $typeStr = 'Public Holiday';
            if (is_array($types)) {
                if (in_array('Bank', $types, true) || in_array('Optional', $types, true)) {
                    $typeStr = 'Bank Holiday';
                } elseif (in_array('Observance', $types, true)) {
                    $typeStr = 'Observance';
                }
            }

            $normalized[] = [
                'name'                 => $name,
                'local_name'           => $item['localName'] ?? $name,
                'date'                 => $date,
                'from_date'            => $date,
                'to_date'              => $date,
                'total_days'           => 1,
                'type'                 => 'public',
                'holiday_type'         => $typeStr,
                'is_working_day'       => 0,
                'description'          => "Official statutory public holiday for {$countryCode}",
                'status'               => 'Active',
                'is_market_holiday'    => false, // Default is general public holiday; market holidays separate
            ];
        }

        usort($normalized, fn($a, $b) => strcmp($a['date'], $b['date']));
        return $normalized;
    }

    /**
     * Synchronize / Import public holidays into a company's calendar table.
     * Fully idempotent: will NOT duplicate existing holiday records on the same date with the same name.
     *
     * @param string $companyId
     * @param string $country
     * @param int|null $year
     * @param string|null $branchId Optional branch scope
     * @return array{success: bool, imported: int, skipped: int, total: int, holidays: array, message: string}
     */
    public function importHolidaysForCompany(string $companyId, string $country, ?int $year = null, ?string $branchId = null): array
    {
        $companyId = trim($companyId);
        if ($companyId === '') {
            return [
                'success'  => false,
                'imported' => 0,
                'skipped'  => 0,
                'total'    => 0,
                'holidays' => [],
                'message'  => 'Company ID context is required to synchronize holidays.',
            ];
        }

        $year = $year ?: (int)date('Y');
        $fetchResult = $this->fetchPublicHolidays($country, $year);
        $holidays = $fetchResult['holidays'];

        if (empty($holidays)) {
            return [
                'success'  => false,
                'imported' => 0,
                'skipped'  => 0,
                'total'    => 0,
                'holidays' => [],
                'message'  => $fetchResult['message'] ?: 'No public holidays available to import.',
            ];
        }

        $db = Database::connect();
        if (!$db->tableExists('holidays')) {
            return [
                'success'  => false,
                'imported' => 0,
                'skipped'  => 0,
                'total'    => count($holidays),
                'holidays' => [],
                'message'  => "Table 'holidays' does not exist in the database.",
            ];
        }

        $tableCols = $db->getFieldNames('holidays');
        $hasCol = fn(string $c): bool => in_array($c, $tableCols, true);

        // Fetch existing holidays for this company and year to prevent duplicates
        $builder = $db->table('holidays')->where('company_id', $companyId);
        if ($branchId && $hasCol('branch_id')) {
            $builder->groupStart()
                ->where('branch_id', $branchId)
                ->orWhere('branch_id IS NULL')
                ->orWhere('branch_id', '')
            ->groupEnd();
        }
        if ($hasCol('from_date')) {
            $builder->where('from_date >=', "{$year}-01-01")->where('from_date <=', "{$year}-12-31");
        } elseif ($hasCol('date')) {
            $builder->where('date >=', "{$year}-01-01")->where('date <=', "{$year}-12-31");
        }

        $existingRows = $builder->get()->getResultArray();
        $existingLookup = [];
        foreach ($existingRows as $er) {
            $d = $er['from_date'] ?? ($er['date'] ?? '');
            $n = strtolower(trim((string)($er['name'] ?? '')));
            if ($d && $n) {
                $existingLookup[$d . '_' . $n] = true;
            }
        }

        $imported = 0;
        $skipped = 0;
        $importedRows = [];
        $now = date('Y-m-d H:i:s');

        foreach ($holidays as $h) {
            $hDate = $h['date'];
            $hName = $h['name'];
            $lookupKey = $hDate . '_' . strtolower($hName);

            if (isset($existingLookup[$lookupKey])) {
                $skipped++;
                continue;
            }

            $id = 'hol-' . bin2hex(random_bytes(6));
            $record = [
                'id'   => $id,
                'name' => $hName,
            ];

            if ($hasCol('company_id')) {
                $record['company_id'] = $companyId;
            }
            if ($hasCol('branch_id')) {
                $record['branch_id'] = $branchId ?: null;
            }
            if ($hasCol('date')) {
                $record['date'] = $hDate;
            }
            if ($hasCol('from_date')) {
                $record['from_date'] = $hDate;
            }
            if ($hasCol('to_date')) {
                $record['to_date'] = $hDate;
            }
            if ($hasCol('total_days')) {
                $record['total_days'] = 1;
            }
            if ($hasCol('type')) {
                $record['type'] = 'public';
            }
            if ($hasCol('holiday_type')) {
                $record['holiday_type'] = $h['holiday_type'] ?? 'Public Holiday';
            }
            if ($hasCol('description')) {
                $record['description'] = $h['description'] ?? 'Official public holiday';
            }
            if ($hasCol('is_working_day')) {
                $record['is_working_day'] = 0;
            }
            if ($hasCol('status')) {
                $record['status'] = 'Active';
            }
            if ($hasCol('priority')) {
                $record['priority'] = 1;
            }
            if ($hasCol('attendance_behavior')) {
                $record['attendance_behavior'] = 'Standard';
            }
            if ($hasCol('compensatory_off_enabled')) {
                $record['compensatory_off_enabled'] = 1;
            }
            if ($hasCol('created_at')) {
                $record['created_at'] = $now;
            }
            if ($hasCol('updated_at')) {
                $record['updated_at'] = $now;
            }

            $db->table('holidays')->insert($record);
            $existingLookup[$lookupKey] = true;
            $imported++;
            $importedRows[] = $record;
        }

        // Invalidate holiday cache so attendance and calendar views immediately see updated holidays
        HolidayModel::clearHolidayCache();
        CompanyWeekendService::clearCache($companyId);

        return [
            'success'  => true,
            'imported' => $imported,
            'skipped'  => $skipped,
            'total'    => count($holidays),
            'holidays' => $importedRows,
            'message'  => sprintf('Successfully imported %d public holidays (%d already existing) for %d.', $imported, $skipped, $year),
        ];
    }

    /**
     * Standard statutory offline fallback gazetted holidays for common jurisdictions
     */
    protected function getStaticFallbackHolidays(string $countryCode, int $year): array
    {
        $base = [
            [
                'name'              => "New Year's Day",
                'date'              => "{$year}-01-01",
                'from_date'         => "{$year}-01-01",
                'to_date'           => "{$year}-01-01",
                'total_days'        => 1,
                'type'              => 'public',
                'holiday_type'      => 'Public Holiday',
                'is_working_day'    => 0,
                'description'       => "International New Year's Day",
                'status'            => 'Active',
                'is_market_holiday' => false,
            ],
            [
                'name'              => "International Workers' Day",
                'date'              => "{$year}-05-01",
                'from_date'         => "{$year}-05-01",
                'to_date'           => "{$year}-05-01",
                'total_days'        => 1,
                'type'              => 'public',
                'holiday_type'      => 'Public Holiday',
                'is_working_day'    => 0,
                'description'       => "May Day / Workers' Solidarity Holiday",
                'status'            => 'Active',
                'is_market_holiday' => false,
            ],
        ];

        if ($countryCode === 'US') {
            $base[] = ['name' => "Independence Day", 'date' => "{$year}-07-04", 'from_date' => "{$year}-07-04", 'to_date' => "{$year}-07-04", 'total_days' => 1, 'type' => 'public', 'holiday_type' => 'Public Holiday', 'is_working_day' => 0, 'description' => 'US National Independence Day', 'status' => 'Active', 'is_market_holiday' => false];
            $base[] = ['name' => "Thanksgiving Day", 'date' => "{$year}-11-26", 'from_date' => "{$year}-11-26", 'to_date' => "{$year}-11-26", 'total_days' => 1, 'type' => 'public', 'holiday_type' => 'Public Holiday', 'is_working_day' => 0, 'description' => 'Annual Thanksgiving observance', 'status' => 'Active', 'is_market_holiday' => false];
            $base[] = ['name' => "Christmas Day", 'date' => "{$year}-12-25", 'from_date' => "{$year}-12-25", 'to_date' => "{$year}-12-25", 'total_days' => 1, 'type' => 'public', 'holiday_type' => 'Public Holiday', 'is_working_day' => 0, 'description' => 'Christmas Day observance', 'status' => 'Active', 'is_market_holiday' => false];
        } elseif ($countryCode === 'BD') {
            $base[] = ['name' => "International Mother Language Day", 'date' => "{$year}-02-21", 'from_date' => "{$year}-02-21", 'to_date' => "{$year}-02-21", 'total_days' => 1, 'type' => 'public', 'holiday_type' => 'Public Holiday', 'is_working_day' => 0, 'description' => 'Shaheed Day & International Mother Language Day', 'status' => 'Active', 'is_market_holiday' => false];
            $base[] = ['name' => "Independence Day", 'date' => "{$year}-03-26", 'from_date' => "{$year}-03-26", 'to_date' => "{$year}-03-26", 'total_days' => 1, 'type' => 'public', 'holiday_type' => 'Public Holiday', 'is_working_day' => 0, 'description' => 'Bangladesh Independence Day', 'status' => 'Active', 'is_market_holiday' => false];
            $base[] = ['name' => "Bengali New Year (Pohela Boishakh)", 'date' => "{$year}-04-14", 'from_date' => "{$year}-04-14", 'to_date' => "{$year}-04-14", 'total_days' => 1, 'type' => 'public', 'holiday_type' => 'Public Holiday', 'is_working_day' => 0, 'description' => 'First day of the Bengali calendar', 'status' => 'Active', 'is_market_holiday' => false];
            $base[] = ['name' => "Victory Day", 'date' => "{$year}-12-16", 'from_date' => "{$year}-12-16", 'to_date' => "{$year}-12-16", 'total_days' => 1, 'type' => 'public', 'holiday_type' => 'Public Holiday', 'is_working_day' => 0, 'description' => 'National Victory Day of Bangladesh', 'status' => 'Active', 'is_market_holiday' => false];
        } elseif ($countryCode === 'GB') {
            $base[] = ['name' => "Good Friday", 'date' => "{$year}-04-03", 'from_date' => "{$year}-04-03", 'to_date' => "{$year}-04-03", 'total_days' => 1, 'type' => 'public', 'holiday_type' => 'Bank Holiday', 'is_working_day' => 0, 'description' => 'UK Bank Holiday', 'status' => 'Active', 'is_market_holiday' => false];
            $base[] = ['name' => "Easter Monday", 'date' => "{$year}-04-06", 'from_date' => "{$year}-04-06", 'to_date' => "{$year}-04-06", 'total_days' => 1, 'type' => 'public', 'holiday_type' => 'Bank Holiday', 'is_working_day' => 0, 'description' => 'UK Bank Holiday', 'status' => 'Active', 'is_market_holiday' => false];
            $base[] = ['name' => "Christmas Day", 'date' => "{$year}-12-25", 'from_date' => "{$year}-12-25", 'to_date' => "{$year}-12-25", 'total_days' => 1, 'type' => 'public', 'holiday_type' => 'Bank Holiday', 'is_working_day' => 0, 'description' => 'Christmas Day', 'status' => 'Active', 'is_market_holiday' => false];
            $base[] = ['name' => "Boxing Day", 'date' => "{$year}-12-26", 'from_date' => "{$year}-12-26", 'to_date' => "{$year}-12-26", 'total_days' => 1, 'type' => 'public', 'holiday_type' => 'Bank Holiday', 'is_working_day' => 0, 'description' => 'Boxing Day', 'status' => 'Active', 'is_market_holiday' => false];
        } else {
            $base[] = ['name' => "Year-End Holiday", 'date' => "{$year}-12-31", 'from_date' => "{$year}-12-31", 'to_date' => "{$year}-12-31", 'total_days' => 1, 'type' => 'public', 'holiday_type' => 'Public Holiday', 'is_working_day' => 0, 'description' => 'Statutory Year-End Observance', 'status' => 'Active', 'is_market_holiday' => false];
        }

        return $base;
    }
}
