<?php

namespace App\Services;

use Config\Database;
use App\Services\Tax\TaxCalculator;
use App\Services\Rules\RuleResolver;
use App\Services\Concerns\JoinsActiveSalary;

/**
 * Class TaxReportService
 *
 * Enterprise Multi-Tenant Statutory Tax & Compliance Reporting Engine.
 * Implements all 8 architectural Tax reports:
 * 1. employee_tax_computation
 * 2. monthly_tax_deduction_register
 * 3. annual_tax_summary
 * 4. tax_slab_detail
 * 5. tax_exemption_rebate
 * 6. tax_payment_reconciliation
 * 7. tax_rule_version
 * 8. tax_exception
 *
 * Strict tenant isolation enforced on every query.
 */
class TaxReportService
{
    use JoinsActiveSalary;

    protected $db;
    protected TaxCalculator $calculator;

    public function __construct()
    {
        $this->db = Database::connect();
        $this->calculator = new TaxCalculator();
    }

    /**
     * Resolve TIN column expression safely supporting tax_identification_number, tin_number, or tin
     */
    protected function getTinSelect(string $empAlias = 'e'): string
    {
        $fields = $this->db->tableExists('employees') ? $this->db->getFieldNames('employees') : [];
        if (in_array('tax_identification_number', $fields, true)) {
            return "{$empAlias}.tax_identification_number as tin_number";
        }
        if (in_array('tin_number', $fields, true)) {
            return "{$empAlias}.tin_number";
        }
        if (in_array('tin', $fields, true)) {
            return "{$empAlias}.tin as tin_number";
        }
        return "NULL as tin_number";
    }

    /**
     * Resolve TIN column expression for GROUP BY clause
     */
    protected function getTinGroupBy(string $empAlias = 'e'): string
    {
        $fields = $this->db->tableExists('employees') ? $this->db->getFieldNames('employees') : [];
        if (in_array('tax_identification_number', $fields, true)) {
            return "{$empAlias}.tax_identification_number";
        }
        if (in_array('tin_number', $fields, true)) {
            return "{$empAlias}.tin_number";
        }
        if (in_array('tin', $fields, true)) {
            return "{$empAlias}.tin";
        }
        return "{$empAlias}.id";
    }

    /**
     * Resolve tax category column expression safely
     */
    protected function getTaxCategorySelect(string $empAlias = 'e'): string
    {
        $fields = $this->db->tableExists('employees') ? $this->db->getFieldNames('employees') : [];
        if (in_array('tax_category', $fields, true)) {
            return "{$empAlias}.tax_category";
        }
        return "'General' as tax_category";
    }

    /**
     * Resolve gender column expression safely
     */
    protected function getGenderSelect(string $empAlias = 'e'): string
    {
        $fields = $this->db->tableExists('employees') ? $this->db->getFieldNames('employees') : [];
        if (in_array('gender', $fields, true)) {
            return "{$empAlias}.gender";
        }
        return "'All' as gender";
    }

    /**
     * Complete Catalog of the 8 Statutory Tax Reports
     */
    public static function getReportCatalog(): array
    {
        return [
            'employee_tax_computation' => [
                'number'      => 41,
                'code'        => 'employee_tax_computation',
                'title'       => 'Employee Tax Computation Report',
                'description' => 'Comprehensive tax computation showing salary breakdown, exemptions, taxable base, and progressive slab liability',
                'category'    => 'Statutory Tax & Compliance',
            ],
            'monthly_tax_deduction_register' => [
                'number'      => 42,
                'code'        => 'monthly_tax_deduction_register',
                'title'       => 'Monthly Tax Deduction Register',
                'description' => 'Monthly register of tax deducted from payroll with TIN, payment status, and rule versions',
                'category'    => 'Statutory Tax & Compliance',
            ],
            'annual_tax_summary' => [
                'number'      => 43,
                'code'        => 'annual_tax_summary',
                'title'       => 'Annual Tax Summary (Fiscal Year)',
                'description' => 'Fiscal year annual tax summary of cumulative earnings, taxable income, deducted tax, and balance',
                'category'    => 'Statutory Tax & Compliance',
            ],
            'tax_slab_detail' => [
                'number'      => 44,
                'code'        => 'tax_slab_detail',
                'title'       => 'Tax Slab Breakdown Detail',
                'description' => 'Granular bracket-by-bracket assessment showing how taxable income distributes across statutory tax slabs',
                'category'    => 'Statutory Tax & Compliance',
            ],
            'tax_exemption_rebate' => [
                'number'      => 45,
                'code'        => 'tax_exemption_rebate',
                'title'       => 'Tax Exemption & Rebate Analysis',
                'description' => 'Exemptions audit covering medical, conveyance, and house rent allowances alongside investment tax rebates',
                'category'    => 'Statutory Tax & Compliance',
            ],
            'tax_payment_reconciliation' => [
                'number'      => 46,
                'code'        => 'tax_payment_reconciliation',
                'title'       => 'Tax Payment Reconciliation (Calculated vs Deducted)',
                'description' => 'Audit reconciliation identifying discrepancies, shortfall, excess, or unapplied tax from ceiling breaches',
                'category'    => 'Statutory Tax & Compliance',
            ],
            'tax_rule_version' => [
                'number'      => 47,
                'code'        => 'tax_rule_version',
                'title'       => 'Tax Rule Version & Audit Log',
                'description' => 'Historical audit of tax rule versions, parameter snapshots, and calculation modes applied per payroll run',
                'category'    => 'Statutory Tax & Compliance',
            ],
            'tax_exception' => [
                'number'      => 48,
                'code'        => 'tax_exception',
                'title'       => 'Tax Exception & Anomaly Report',
                'description' => 'Compliance exceptions highlighting missing TINs, zero tax on high earners, negative values, and abnormal variations',
                'category'    => 'Statutory Tax & Compliance',
            ],
        ];
    }

    /**
     * Dispatch report generation by code
     */
    public function generateReport(string $code, string $companyId, array $filters = []): array
    {
        if (trim($companyId) === '') {
            throw new \InvalidArgumentException('TaxReportService: $companyId is required and cannot be empty.');
        }

        $normalized = strtolower(trim($code));

        switch ($normalized) {
            case 'employee_tax_computation':
            case 'tax_computation':
            case '41':
                return $this->employeeTaxComputation($companyId, $filters);

            case 'monthly_tax_deduction_register':
            case 'monthly_tax_deduction':
            case 'tax_deduction_register':
            case '42':
                return $this->monthlyTaxDeductionRegister($companyId, $filters);

            case 'annual_tax_summary':
            case 'annual_tax':
            case 'fiscal_tax_summary':
            case '43':
                return $this->annualTaxSummary($companyId, $filters);

            case 'tax_slab_detail':
            case 'tax_slabs':
            case 'slab_detail':
            case '44':
                return $this->taxSlabDetail($companyId, $filters);

            case 'tax_exemption_rebate':
            case 'tax_exemptions':
            case 'tax_rebate':
            case '45':
                return $this->taxExemptionRebate($companyId, $filters);

            case 'tax_payment_reconciliation':
            case 'tax_reconciliation':
            case 'tax_vs_deducted':
            case '46':
                return $this->taxPaymentReconciliation($companyId, $filters);

            case 'tax_rule_version':
            case 'tax_rules':
            case 'rule_version':
            case '47':
                return $this->taxRuleVersion($companyId, $filters);

            case 'tax_exception':
            case 'tax_exceptions':
            case 'tax_anomaly':
            case '48':
                return $this->taxException($companyId, $filters);

            default:
                throw new \InvalidArgumentException("TaxReportService: Unknown report code '{$code}'.");
        }
    }

    /**
     * 1. Employee Tax Computation Report
     */
    public function employeeTaxComputation(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Employee Code', 'Employee Name', 'Department', 'Designation', 'TIN',
            'Tax Year', 'Gross Salary', 'Total Exemptions', 'Taxable Income',
            'Annual Tax Liability', 'Rebate Applied', 'Net Annual Tax', 'Monthly Tax', 'Tax Status'
        ];

        $month = $filters['payroll_month'] ?? ($filters['month'] ?? date('Y-m'));
        if (strlen($month) === 2 && !empty($filters['year'])) {
            $month = $filters['year'] . '-' . str_pad($month, 2, '0', STR_PAD_LEFT);
        }
        $taxYear = $filters['tax_year'] ?? TaxCalculator::getFiscalYear($month . '-01');

        $tinCol = $this->getTinSelect('e');
        $taxCatCol = $this->getTaxCategorySelect('e');
        $genderCol = $this->getGenderSelect('e');
        $salJoin = $this->getActiveSalaryJoin('e', 'es');

        $builder = $this->db->table('employees e')
            ->select("e.id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name, des.name as designation_name, {$tinCol}, {$taxCatCol}, {$genderCol}, COALESCE(es.basic_salary, e.basic_salary, 0) as basic_salary, COALESCE(es.gross_salary, e.gross_salary, 0) as gross_salary, COALESCE(e.medical_allowance, 0) as medical_allowance, COALESCE(e.house_rent_allowance, 0) as house_rent_allowance, COALESCE(e.conveyance_allowance, 0) as conveyance_allowance")
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('designations des', 'des.id = e.designation_id', 'left')
            ->join('employee_salaries es', $salJoin, 'left');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $employees = $builder->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

        $rows = [];
        $exceptions = [];
        $sl = 1;
        $totalGross = 0.0;
        $totalExempt = 0.0;
        $totalTaxable = 0.0;
        $totalAnnualTax = 0.0;
        $totalRebate = 0.0;
        $totalNetAnnual = 0.0;
        $totalMonthly = 0.0;

        foreach ($employees as $emp) {
            $gross = (float)($emp['gross_salary'] ?? 0.0);
            $basic = (float)($emp['basic_salary'] ?? 0.0);

            // Never silently assume zero: report missing salary structure as exception
            if ($gross <= 0 || $basic <= 0) {
                $exceptions[] = [
                    'employee_code' => $emp['employee_code'],
                    'name'          => $emp['employee_name'],
                    'issue'         => 'Missing active salary structure / zero basic salary',
                ];
                $rows[] = [
                    $sl++,
                    $emp['employee_code'] ?? '-',
                    trim($emp['employee_name'] ?? 'Unknown'),
                    $emp['department_name'] ?? 'General',
                    $emp['designation_name'] ?? 'Staff',
                    $emp['tin_number'] ?: '[MISSING TIN]',
                    $taxYear,
                    '0.00',
                    '0.00',
                    '0.00',
                    '0.00',
                    '0.00',
                    '0.00',
                    '0.00',
                    'EXCEPTION: Missing Salary'
                ];
                continue;
            }

            try {
                $calc = $this->calculator->calculateTax($gross, [
                    'company_id'     => $companyId,
                    'employee_id'    => $emp['id'],
                    'employee'       => $emp,
                    'basic'          => $basic,
                    'effective_date' => $month . '-01',
                    'category'       => $emp['tax_category'] ?? 'General',
                    'gender'         => $emp['gender'] ?? 'All',
                ]);

                $exempt = (float)($calc['exemptions']['total_exemptions'] ?? 0.0);
                $taxable = (float)($calc['annual_taxable_income'] ?? 0.0);
                $annualLiability = (float)($calc['annual_tax_liability'] ?? 0.0);
                $rebate = (float)($calc['rebate_applied'] ?? 0.0);
                $netAnnual = (float)($calc['net_annual_tax'] ?? max(0, $annualLiability - $rebate));
                $monthlyTax = (float)($calc['monthly_tax_deduction'] ?? round($netAnnual / 12, 2));
                $status = ($netAnnual > 0) ? 'Taxable' : 'Exempt';

                $totalGross += $gross;
                $totalExempt += $exempt;
                $totalTaxable += $taxable;
                $totalAnnualTax += $annualLiability;
                $totalRebate += $rebate;
                $totalNetAnnual += $netAnnual;
                $totalMonthly += $monthlyTax;

                $rows[] = [
                    $sl++,
                    $emp['employee_code'] ?? '-',
                    trim($emp['employee_name'] ?? 'Unknown'),
                    $emp['department_name'] ?? 'General',
                    $emp['designation_name'] ?? 'Staff',
                    $emp['tin_number'] ?: '[MISSING TIN]',
                    $taxYear,
                    number_format($gross, 2),
                    number_format($exempt, 2),
                    number_format($taxable, 2),
                    number_format($annualLiability, 2),
                    number_format($rebate, 2),
                    number_format($netAnnual, 2),
                    number_format($monthlyTax, 2),
                    $status
                ];
            } catch (\Throwable $e) {
                $exceptions[] = [
                    'employee_code' => $emp['employee_code'],
                    'name'          => $emp['employee_name'],
                    'issue'         => 'Tax Rule Error: ' . $e->getMessage(),
                ];
                $rows[] = [
                    $sl++,
                    $emp['employee_code'] ?? '-',
                    trim($emp['employee_name'] ?? 'Unknown'),
                    $emp['department_name'] ?? 'General',
                    $emp['designation_name'] ?? 'Staff',
                    $emp['tin_number'] ?: '[MISSING TIN]',
                    $taxYear,
                    number_format($gross, 2),
                    '0.00',
                    '0.00',
                    '0.00',
                    '0.00',
                    '0.00',
                    '0.00',
                    'EXCEPTION: Rule Unconfigured'
                ];
            }
        }

        // Grand Total row
        $recordCount = count($employees);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Count: {$recordCount}",
            '-',
            '-',
            '-',
            $taxYear,
            number_format($totalGross, 2),
            number_format($totalExempt, 2),
            number_format($totalTaxable, 2),
            number_format($totalAnnualTax, 2),
            number_format($totalRebate, 2),
            number_format($totalNetAnnual, 2),
            number_format($totalMonthly, 2),
            count($exceptions) > 0 ? (count($exceptions) . ' Exceptions') : 'Compliant'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count' => $recordCount,
                'gross'        => $totalGross,
                'exemptions'   => $totalExempt,
                'taxable'      => $totalTaxable,
                'monthly_tax'  => $totalMonthly,
                'exceptions'   => count($exceptions)
            ],
            'exceptions' => $exceptions
        ];
    }

    /**
     * 2. Monthly Tax Deduction Register
     */
    public function monthlyTaxDeductionRegister(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Payroll Month', 'Tax Year', 'Employee Code', 'Employee Name', 'Department',
            'TIN', 'Gross Salary', 'Tax Deduction', 'Unapplied Tax', 'Payment Status', 'Rule Version'
        ];

        $tinCol = $this->getTinSelect('e');

        $builder = $this->db->table('payroll_items pi')
            ->select("pi.id, p.payroll_month, pi.tax_year, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name, {$tinCol}, pi.gross_salary, pi.tax_deduction, pi.unapplied_tax, pi.payment_status, COALESCE(pi.rule_version, pi.tax_rule_version, 1) as rule_version, pi.rules_snapshot_json")
            ->join('payrolls p', 'p.id = pi.payroll_id', 'left')
            ->join('employees e', 'e.id = pi.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');

        if (!empty($filters['payroll_month'])) {
            $builder->where('p.payroll_month', $filters['payroll_month']);
        } elseif (!empty($filters['from']) && !empty($filters['to'])) {
            $fromMonth = date('Y-m', strtotime($filters['from']));
            $toMonth = date('Y-m', strtotime($filters['to']));
            $builder->where('p.payroll_month >=', $fromMonth)->where('p.payroll_month <=', $toMonth);
        }
        if (!empty($filters['tax_year'])) {
            $builder->where('pi.tax_year', $filters['tax_year']);
        }

        $records = $builder->orderBy('p.payroll_month', 'DESC')->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

        $rows = [];
        $exceptions = [];
        $sl = 1;
        $totalGross = 0.0;
        $totalTax = 0.0;
        $totalUnapplied = 0.0;

        foreach ($records as $r) {
            $gross = (float)($r['gross_salary'] ?? 0.0);
            $tax = (float)($r['tax_deduction'] ?? 0.0);
            $unapplied = (float)($r['unapplied_tax'] ?? 0.0);
            $tin = $r['tin_number'] ?: '[MISSING TIN]';

            if (empty($r['tin_number'])) {
                $exceptions[] = [
                    'employee_code' => $r['employee_code'],
                    'name'          => $r['employee_name'],
                    'issue'         => 'Missing Tax Identification Number (TIN)'
                ];
            }

            $totalGross += $gross;
            $totalTax += $tax;
            $totalUnapplied += $unapplied;

            $taxYearVal = $r['tax_year'] ?? TaxCalculator::getFiscalYear(($r['payroll_month'] ?? date('Y-m')) . '-01');

            $rows[] = [
                $sl++,
                $r['payroll_month'] ?? '-',
                $taxYearVal,
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                $tin,
                number_format($gross, 2),
                number_format($tax, 2),
                number_format($unapplied, 2),
                $r['payment_status'] ?? 'Draft',
                'v' . ($r['rule_version'] ?? 1)
            ];
        }

        // Grand Total row
        $count = count($records);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Count: {$count}",
            '-',
            '-',
            '-',
            '-',
            number_format($totalGross, 2),
            number_format($totalTax, 2),
            number_format($totalUnapplied, 2),
            count($exceptions) > 0 ? (count($exceptions) . ' TIN Exceptions') : 'Clean',
            '-'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count'    => $count,
                'gross_salary'    => $totalGross,
                'tax_deduction'   => $totalTax,
                'unapplied_tax'   => $totalUnapplied,
                'tin_exceptions'  => count($exceptions)
            ],
            'exceptions' => $exceptions
        ];
    }

    /**
     * 3. Annual Tax Summary (Fiscal Year)
     */
    public function annualTaxSummary(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Tax Year', 'Employee Code', 'Employee Name', 'Department', 'TIN',
            'Months Paid', 'Cumulative Gross', 'Cumulative Taxable', 'Total Tax Deducted',
            'Projected Annual Tax', 'Balance / Variance', 'Compliance Status'
        ];

        $targetTaxYear = $filters['tax_year'] ?? TaxCalculator::getFiscalYear();

        $tinCol = $this->getTinSelect('e');
        $tinGroup = $this->getTinGroupBy('e');
        $taxCatCol = $this->getTaxCategorySelect('e');
        $genderCol = $this->getGenderSelect('e');
        $salJoin = $this->getActiveSalaryJoin('e', 'es');

        $builder = $this->db->table('employees e')
            ->select("e.id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name, {$tinCol}, {$taxCatCol}, {$genderCol}, COALESCE(es.gross_salary, e.gross_salary, 0) as gross_salary, COALESCE(es.basic_salary, e.basic_salary, 0) as basic_salary, COUNT(pi.id) as months_paid, SUM(COALESCE(pi.gross_salary, 0)) as cum_gross, SUM(COALESCE(pi.tax_deduction, 0)) as cum_tax")
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('employee_salaries es', $salJoin, 'left')
            ->join('payroll_items pi', 'pi.employee_id = e.id AND (pi.tax_year = ' . $this->db->escape($targetTaxYear) . ' OR pi.tax_year IS NULL)', 'left')
            ->groupBy("e.id, e.employee_code, e.first_name, e.last_name, d.name, {$tinGroup}, es.gross_salary, e.gross_salary, es.basic_salary, e.basic_salary");

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $records = $builder->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

        $rows = [];
        $exceptions = [];
        $sl = 1;
        $totalCumGross = 0.0;
        $totalCumTax = 0.0;
        $totalProjected = 0.0;
        $totalVariance = 0.0;

        foreach ($records as $r) {
            $monthsPaid = (int)($r['months_paid'] ?? 0);
            $cumGross = (float)($r['cum_gross'] ?? 0.0);
            $cumTax = (float)($r['cum_tax'] ?? 0.0);
            $monthlyGross = (float)($r['gross_salary'] ?? ($monthsPaid > 0 ? ($cumGross / $monthsPaid) : 0.0));
            $basic = (float)($r['basic_salary'] ?? ($monthlyGross * 0.5));

            if ($monthlyGross <= 0) {
                $exceptions[] = [
                    'employee_code' => $r['employee_code'],
                    'name'          => $r['employee_name'],
                    'issue'         => 'No payroll items or active salary record for fiscal year ' . $targetTaxYear,
                ];
                $rows[] = [
                    $sl++,
                    $targetTaxYear,
                    $r['employee_code'] ?? '-',
                    trim($r['employee_name'] ?? 'Unknown'),
                    $r['department_name'] ?? 'General',
                    $r['tin_number'] ?: '[MISSING TIN]',
                    $monthsPaid,
                    '0.00',
                    '0.00',
                    '0.00',
                    '0.00',
                    '0.00',
                    'EXCEPTION: No Earnings'
                ];
                continue;
            }

            try {
                $calc = $this->calculator->calculateTax($monthlyGross, [
                    'company_id'  => $companyId,
                    'employee_id' => $r['id'],
                    'employee'    => $r,
                    'basic'       => $basic,
                    'category'    => $r['tax_category'] ?? 'General',
                    'gender'      => $r['gender'] ?? 'All',
                ]);

                $annualTaxable = (float)($calc['annual_taxable_income'] ?? ($cumGross * 0.8));
                $projectedAnnual = (float)($calc['net_annual_tax'] ?? 0.0);
                $variance = round($projectedAnnual - $cumTax, 2);
                $status = ($variance <= 0) ? 'Fully Deducted' : 'Pending TDS';

                $totalCumGross += $cumGross;
                $totalCumTax += $cumTax;
                $totalProjected += $projectedAnnual;
                $totalVariance += $variance;

                $rows[] = [
                    $sl++,
                    $targetTaxYear,
                    $r['employee_code'] ?? '-',
                    trim($r['employee_name'] ?? 'Unknown'),
                    $r['department_name'] ?? 'General',
                    $r['tin_number'] ?: '[MISSING TIN]',
                    $monthsPaid,
                    number_format($cumGross, 2),
                    number_format($annualTaxable, 2),
                    number_format($cumTax, 2),
                    number_format($projectedAnnual, 2),
                    number_format($variance, 2),
                    $status
                ];
            } catch (\Throwable $e) {
                $exceptions[] = [
                    'employee_code' => $r['employee_code'],
                    'name'          => $r['employee_name'],
                    'issue'         => 'Calculation error: ' . $e->getMessage()
                ];
                $rows[] = [
                    $sl++,
                    $targetTaxYear,
                    $r['employee_code'] ?? '-',
                    trim($r['employee_name'] ?? 'Unknown'),
                    $r['department_name'] ?? 'General',
                    $r['tin_number'] ?: '[MISSING TIN]',
                    $monthsPaid,
                    number_format($cumGross, 2),
                    '0.00',
                    number_format($cumTax, 2),
                    '0.00',
                    '0.00',
                    'EXCEPTION: Rule Error'
                ];
            }
        }

        // Grand Total row
        $count = count($records);
        $rows[] = [
            'TOTAL',
            $targetTaxYear,
            'Grand Total',
            "Count: {$count}",
            '-',
            '-',
            '-',
            number_format($totalCumGross, 2),
            '-',
            number_format($totalCumTax, 2),
            number_format($totalProjected, 2),
            number_format($totalVariance, 2),
            count($exceptions) > 0 ? (count($exceptions) . ' Exceptions') : 'Audited'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count'    => $count,
                'cumulative_gross'=> $totalCumGross,
                'tax_deducted'    => $totalCumTax,
                'projected_annual'=> $totalProjected,
                'variance'        => $totalVariance,
                'exceptions'      => count($exceptions)
            ],
            'exceptions' => $exceptions
        ];
    }

    /**
     * 4. Tax Slab Breakdown Detail
     */
    public function taxSlabDetail(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Employee Code', 'Employee Name', 'Category', 'Taxable Income',
            'Slab 1 (0%)', 'Slab 2 (5%)', 'Slab 3 (10%)', 'Slab 4 (15%)', 'Slab 5 (20%)', 'Slab 6 (25%)', 'Total Slab Tax'
        ];

        $taxCatCol = $this->getTaxCategorySelect('e');
        $genderCol = $this->getGenderSelect('e');
        $salJoin = $this->getActiveSalaryJoin('e', 'es');

        $builder = $this->db->table('employees e')
            ->select("e.id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name, {$taxCatCol}, {$genderCol}, COALESCE(es.gross_salary, e.gross_salary, 0) as gross_salary, COALESCE(es.basic_salary, e.basic_salary, 0) as basic_salary")
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('employee_salaries es', $salJoin, 'left');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $employees = $builder->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

        $rows = [];
        $exceptions = [];
        $sl = 1;
        $totalTaxable = 0.0;
        $totalSlab1 = 0.0;
        $totalSlab2 = 0.0;
        $totalSlab3 = 0.0;
        $totalSlab4 = 0.0;
        $totalSlab5 = 0.0;
        $totalSlab6 = 0.0;
        $grandTotalTax = 0.0;

        foreach ($employees as $emp) {
            $gross = (float)($emp['gross_salary'] ?? 0.0);
            if ($gross <= 0) {
                $exceptions[] = [
                    'employee_code' => $emp['employee_code'],
                    'name'          => $emp['employee_name'],
                    'issue'         => 'Missing salary structure'
                ];
                continue;
            }

            try {
                $calc = $this->calculator->calculateTax($gross, [
                    'company_id'  => $companyId,
                    'employee_id' => $emp['id'],
                    'employee'    => $emp,
                    'basic'       => $emp['basic_salary'] ?? ($gross * 0.5),
                    'category'    => $emp['tax_category'] ?? 'General',
                    'gender'      => $emp['gender'] ?? 'All',
                ]);

                $taxable = (float)($calc['annual_taxable_income'] ?? 0.0);
                $slabs = $calc['slabs_breakdown'] ?? $calc['slab_breakdown'] ?? [];

                // Standard slab parsing
                $s1 = (float)($slabs[0]['tax'] ?? 0.0);
                $s2 = (float)($slabs[1]['tax'] ?? 0.0);
                $s3 = (float)($slabs[2]['tax'] ?? 0.0);
                $s4 = (float)($slabs[3]['tax'] ?? 0.0);
                $s5 = (float)($slabs[4]['tax'] ?? 0.0);
                $s6 = (float)($slabs[5]['tax'] ?? 0.0);
                $tot = (float)($calc['gross_annual_tax'] ?? ($s1 + $s2 + $s3 + $s4 + $s5 + $s6));

                $totalTaxable += $taxable;
                $totalSlab1 += $s1;
                $totalSlab2 += $s2;
                $totalSlab3 += $s3;
                $totalSlab4 += $s4;
                $totalSlab5 += $s5;
                $totalSlab6 += $s6;
                $grandTotalTax += $tot;

                $rows[] = [
                    $sl++,
                    $emp['employee_code'] ?? '-',
                    trim($emp['employee_name'] ?? 'Unknown'),
                    $emp['tax_category'] ?? 'General',
                    number_format($taxable, 2),
                    number_format($s1, 2),
                    number_format($s2, 2),
                    number_format($s3, 2),
                    number_format($s4, 2),
                    number_format($s5, 2),
                    number_format($s6, 2),
                    number_format($tot, 2)
                ];
            } catch (\Throwable $e) {
                $exceptions[] = [
                    'employee_code' => $emp['employee_code'],
                    'name'          => $emp['employee_name'],
                    'issue'         => 'Tax slab calculation failed: ' . $e->getMessage()
                ];
            }
        }

        // Grand Total row
        $count = count($rows);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Count: {$count}",
            '-',
            number_format($totalTaxable, 2),
            number_format($totalSlab1, 2),
            number_format($totalSlab2, 2),
            number_format($totalSlab3, 2),
            number_format($totalSlab4, 2),
            number_format($totalSlab5, 2),
            number_format($totalSlab6, 2),
            number_format($grandTotalTax, 2)
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count' => $count,
                'taxable'      => $totalTaxable,
                'total_tax'    => $grandTotalTax,
                'exceptions'   => count($exceptions)
            ],
            'exceptions' => $exceptions
        ];
    }

    /**
     * 5. Tax Exemption & Rebate Analysis
     */
    public function taxExemptionRebate(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Employee Code', 'Employee Name', 'Basic Salary', 'House Rent Exemption',
            'Medical Exemption', 'Conveyance Exemption', 'Total Exemptions',
            'Investment Amount', 'Allowable Rebate', 'Net Exemption Benefit'
        ];

        $salJoin = $this->getActiveSalaryJoin('e', 'es');

        $builder = $this->db->table('employees e')
            ->select("e.id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name, COALESCE(es.gross_salary, e.gross_salary, 0) as gross_salary, COALESCE(es.basic_salary, e.basic_salary, 0) as basic_salary, COALESCE(e.house_rent_allowance, 0) as house_rent_allowance, COALESCE(e.medical_allowance, 0) as medical_allowance, COALESCE(e.conveyance_allowance, 0) as conveyance_allowance")
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('employee_salaries es', $salJoin, 'left');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $employees = $builder->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

        $rows = [];
        $exceptions = [];
        $sl = 1;
        $totBasic = 0.0;
        $totHr = 0.0;
        $totMed = 0.0;
        $totConv = 0.0;
        $totExempt = 0.0;
        $totInvest = 0.0;
        $totRebate = 0.0;
        $totBenefit = 0.0;

        foreach ($employees as $emp) {
            $gross = (float)($emp['gross_salary'] ?? 0.0);
            $basic = (float)($emp['basic_salary'] ?? 0.0);

            if ($gross <= 0 || $basic <= 0) {
                $exceptions[] = [
                    'employee_code' => $emp['employee_code'],
                    'name'          => $emp['employee_name'],
                    'issue'         => 'Missing salary structure'
                ];
                continue;
            }

            try {
                $calc = $this->calculator->calculateTax($gross, [
                    'company_id'  => $companyId,
                    'employee_id' => $emp['id'],
                    'employee'    => $emp,
                    'basic'       => $basic,
                ]);

                $ex = $calc['exemptions'] ?? [];
                $hrEx = (float)($ex['house_rent_exemption'] ?? 0.0);
                $medEx = (float)($ex['medical_exemption'] ?? 0.0);
                $convEx = (float)($ex['conveyance_exemption'] ?? 0.0);
                $totEx = (float)($ex['total_exemptions'] ?? ($hrEx + $medEx + $convEx));
                $rebate = (float)($calc['rebate_applied'] ?? 0.0);
                $invest = (float)($calc['investment_declared'] ?? ($rebate > 0 ? ($rebate / 0.15) : 0.0));
                $netBenefit = $totEx + $rebate;

                $totBasic += $basic;
                $totHr += $hrEx;
                $totMed += $medEx;
                $totConv += $convEx;
                $totExempt += $totEx;
                $totInvest += $invest;
                $totRebate += $rebate;
                $totBenefit += $netBenefit;

                $rows[] = [
                    $sl++,
                    $emp['employee_code'] ?? '-',
                    trim($emp['employee_name'] ?? 'Unknown'),
                    number_format($basic, 2),
                    number_format($hrEx, 2),
                    number_format($medEx, 2),
                    number_format($convEx, 2),
                    number_format($totEx, 2),
                    number_format($invest, 2),
                    number_format($rebate, 2),
                    number_format($netBenefit, 2)
                ];
            } catch (\Throwable $e) {
                $exceptions[] = [
                    'employee_code' => $emp['employee_code'],
                    'name'          => $emp['employee_name'],
                    'issue'         => 'Exemption calculation error: ' . $e->getMessage()
                ];
            }
        }

        // Grand Total row
        $count = count($rows);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Count: {$count}",
            number_format($totBasic, 2),
            number_format($totHr, 2),
            number_format($totMed, 2),
            number_format($totConv, 2),
            number_format($totExempt, 2),
            number_format($totInvest, 2),
            number_format($totRebate, 2),
            number_format($totBenefit, 2)
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count'     => $count,
                'total_exemptions' => $totExempt,
                'total_rebates'    => $totRebate,
                'total_benefit'    => $totBenefit,
                'exceptions'       => count($exceptions)
            ],
            'exceptions' => $exceptions
        ];
    }

    /**
     * 6. Tax Payment Reconciliation (Calculated vs Deducted)
     */
    public function taxPaymentReconciliation(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Payroll Month', 'Employee Code', 'Employee Name', 'Department',
            'Calculated Tax', 'Actual Deducted Tax', 'Unapplied Tax', 'Variance',
            'Reconciliation Status', 'Remarks'
        ];

        $builder = $this->db->table('payroll_items pi')
            ->select("pi.id, p.payroll_month, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name, pi.gross_salary, pi.tax_deduction, pi.unapplied_tax, pi.components_breakdown_json")
            ->join('payrolls p', 'p.id = pi.payroll_id', 'left')
            ->join('employees e', 'e.id = pi.employee_id', 'left')
            ->join('departments d', 'd.id = e.department_id', 'left');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');

        if (!empty($filters['payroll_month'])) {
            $builder->where('p.payroll_month', $filters['payroll_month']);
        } elseif (!empty($filters['from']) && !empty($filters['to'])) {
            $builder->where('p.payroll_month >=', date('Y-m', strtotime($filters['from'])))
                    ->where('p.payroll_month <=', date('Y-m', strtotime($filters['to'])));
        }

        $records = $builder->orderBy('p.payroll_month', 'DESC')->get()->getResultArray();

        $rows = [];
        $exceptions = [];
        $sl = 1;
        $totalCalc = 0.0;
        $totalDeducted = 0.0;
        $totalUnapplied = 0.0;
        $totalVariance = 0.0;

        foreach ($records as $r) {
            $deducted = (float)($r['tax_deduction'] ?? 0.0);
            $unapplied = (float)($r['unapplied_tax'] ?? 0.0);

            // Extract calculated tax from breakdown if available, else deducted + unapplied
            $calculated = $deducted + $unapplied;
            if (!empty($r['components_breakdown_json'])) {
                $decoded = json_decode($r['components_breakdown_json'], true);
                if (isset($decoded['tax_details']['monthly_tax'])) {
                    $calculated = (float)$decoded['tax_details']['monthly_tax'];
                }
            }

            $variance = round($calculated - $deducted, 2);
            $status = 'Matched';
            $remarks = 'Full deduction';

            if ($unapplied > 0) {
                $status = 'Ceiling Breach';
                $remarks = 'Unapplied tax due to statutory minimum net salary protection';
                $exceptions[] = [
                    'employee_code' => $r['employee_code'],
                    'name'          => $r['employee_name'],
                    'issue'         => "Shortfall of {$unapplied} due to net salary protection ceiling"
                ];
            } elseif ($variance > 0) {
                $status = 'Under-deducted';
                $remarks = "Shortfall of {$variance}";
                $exceptions[] = [
                    'employee_code' => $r['employee_code'],
                    'name'          => $r['employee_name'],
                    'issue'         => "Tax under-deducted by {$variance}"
                ];
            } elseif ($variance < 0) {
                $status = 'Over-deducted';
                $remarks = "Excess deduction of " . abs($variance);
            }

            $totalCalc += $calculated;
            $totalDeducted += $deducted;
            $totalUnapplied += $unapplied;
            $totalVariance += $variance;

            $rows[] = [
                $sl++,
                $r['payroll_month'] ?? '-',
                $r['employee_code'] ?? '-',
                trim($r['employee_name'] ?? 'Unknown'),
                $r['department_name'] ?? 'General',
                number_format($calculated, 2),
                number_format($deducted, 2),
                number_format($unapplied, 2),
                number_format($variance, 2),
                $status,
                $remarks
            ];
        }

        // Grand Total row
        $count = count($records);
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Count: {$count}",
            '-',
            '-',
            number_format($totalCalc, 2),
            number_format($totalDeducted, 2),
            number_format($totalUnapplied, 2),
            number_format($totalVariance, 2),
            count($exceptions) > 0 ? (count($exceptions) . ' Discrepancies') : 'Reconciled',
            '-'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'record_count' => $count,
                'calculated'   => $totalCalc,
                'deducted'     => $totalDeducted,
                'unapplied'    => $totalUnapplied,
                'variance'     => $totalVariance,
                'exceptions'   => count($exceptions)
            ],
            'exceptions' => $exceptions
        ];
    }

    /**
     * 7. Tax Rule Version & Audit Log
     */
    public function taxRuleVersion(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Payroll Month', 'Tax Year', 'Rule Domain', 'Rule Version',
            'Rule Snapshot Hash', 'Employees Processed', 'Total Tax Disbursed', 'Calculation Mode', 'Lock Status'
        ];

        $builder = $this->db->table('payrolls p')
            ->select("p.id, p.payroll_month, p.is_locked, p.status as payroll_status, COUNT(pi.id) as emp_count, SUM(pi.tax_deduction) as total_tax, MIN(COALESCE(pi.rule_version, 1)) as min_rule_version, MAX(COALESCE(pi.rule_version, 1)) as max_rule_version, MIN(pi.tax_year) as tax_year, MIN(pi.rules_snapshot_json) as sample_snapshot")
            ->join('payroll_items pi', 'pi.payroll_id = p.id', 'left')
            ->where('p.company_id', $companyId)
            ->groupBy('p.id, p.payroll_month, p.is_locked, p.status');

        if (!empty($filters['payroll_month'])) {
            $builder->where('p.payroll_month', $filters['payroll_month']);
        } elseif (!empty($filters['from']) && !empty($filters['to'])) {
            $builder->where('p.payroll_month >=', date('Y-m', strtotime($filters['from'])))
                    ->where('p.payroll_month <=', date('Y-m', strtotime($filters['to'])));
        }

        $batches = $builder->orderBy('p.payroll_month', 'DESC')->get()->getResultArray();

        $rows = [];
        $sl = 1;
        $totalEmps = 0;
        $totalTax = 0.0;

        foreach ($batches as $b) {
            $taxYearVal = $b['tax_year'] ?? TaxCalculator::getFiscalYear(($b['payroll_month'] ?? date('Y-m')) . '-01');
            $ruleVer = ($b['min_rule_version'] == $b['max_rule_version']) ? ('v' . $b['min_rule_version']) : ("v{$b['min_rule_version']}-v{$b['max_rule_version']}");
            
            $hash = 'N/A';
            $calcMode = 'Standard Statutory';
            if (!empty($b['sample_snapshot'])) {
                $decoded = json_decode($b['sample_snapshot'], true);
                if (isset($decoded['TAX']['hash'])) {
                    $hash = substr((string)$decoded['TAX']['hash'], 0, 12);
                } elseif (isset($decoded['TAX'])) {
                    $hash = substr(sha1(json_encode($decoded['TAX'])), 0, 12);
                }
            }

            $empCount = (int)($b['emp_count'] ?? 0);
            $taxDisbursed = (float)($b['total_tax'] ?? 0.0);
            $lockStatus = !empty($b['is_locked']) ? 'Locked (Immutable)' : 'Active / Unlocked';

            $totalEmps += $empCount;
            $totalTax += $taxDisbursed;

            $rows[] = [
                $sl++,
                $b['payroll_month'] ?? '-',
                $taxYearVal,
                'TAX',
                $ruleVer,
                $hash,
                $empCount,
                number_format($taxDisbursed, 2),
                $calcMode,
                $lockStatus
            ];
        }

        // Grand Total row
        $rows[] = [
            'TOTAL',
            'Grand Total',
            "Batches: " . count($batches),
            'TAX',
            '-',
            '-',
            $totalEmps,
            number_format($totalTax, 2),
            '-',
            'Audited'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'batches_count' => count($batches),
                'total_employees' => $totalEmps,
                'total_tax'       => $totalTax
            ],
            'exceptions' => []
        ];
    }

    /**
     * 8. Tax Exception & Anomaly Report
     */
    public function taxException(string $companyId, array $filters = []): array
    {
        $headers = [
            'Sl', 'Employee Code', 'Employee Name', 'Department', 'TIN Status',
            'Gross Salary', 'Tax Amount', 'Exception Type', 'Severity', 'Recommended Action'
        ];

        $tinCol = $this->getTinSelect('e');
        $taxCatCol = $this->getTaxCategorySelect('e');
        $salJoin = $this->getActiveSalaryJoin('e', 'es');

        $builder = $this->db->table('employees e')
            ->select("e.id, e.employee_code, CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as employee_name, d.name as department_name, {$tinCol}, {$taxCatCol}, COALESCE(es.gross_salary, e.gross_salary, 0) as gross_salary, COALESCE(es.basic_salary, e.basic_salary, 0) as basic_salary")
            ->join('departments d', 'd.id = e.department_id', 'left')
            ->join('employee_salaries es', $salJoin, 'left');

        ReportService::applyStaffScope($builder, $companyId, $filters, 'e');
        $employees = $builder->orderBy('e.employee_code', 'ASC')->get()->getResultArray();

        $rows = [];
        $exceptions = [];
        $sl = 1;

        foreach ($employees as $emp) {
            $gross = (float)($emp['gross_salary'] ?? 0.0);
            $tin = trim((string)($emp['tin_number'] ?? ''));

            // 1. Missing TIN Exception
            if (empty($tin)) {
                $rows[] = [
                    $sl++,
                    $emp['employee_code'] ?? '-',
                    trim($emp['employee_name'] ?? 'Unknown'),
                    $emp['department_name'] ?? 'General',
                    'Missing',
                    number_format($gross, 2),
                    '0.00',
                    'Missing Tax Identification Number (TIN)',
                    'High',
                    'Collect TIN certificate before next payroll submission'
                ];
                $exceptions[] = ['code' => $emp['employee_code'], 'type' => 'Missing TIN'];
            }

            // 2. Missing Salary Structure Exception
            if ($gross <= 0) {
                $rows[] = [
                    $sl++,
                    $emp['employee_code'] ?? '-',
                    trim($emp['employee_name'] ?? 'Unknown'),
                    $emp['department_name'] ?? 'General',
                    $tin ? 'Valid' : 'Missing',
                    '0.00',
                    '0.00',
                    'Unconfigured / Missing Active Salary Record',
                    'Critical',
                    'Configure grade and basic salary structure immediately'
                ];
                $exceptions[] = ['code' => $emp['employee_code'], 'type' => 'Missing Salary'];
                continue;
            }

            // 3. Tax Calculation Anomaly Check
            try {
                $calc = $this->calculator->calculateTax($gross, [
                    'company_id'  => $companyId,
                    'employee_id' => $emp['id'],
                    'employee'    => $emp,
                    'basic'       => $emp['basic_salary'] ?? ($gross * 0.5),
                    'category'    => $emp['tax_category'] ?? 'General',
                ]);

                $monthlyTax = (float)($calc['monthly_tax_deduction'] ?? 0.0);

                // Zero tax on annual gross > 400,000 threshold
                if ($gross * 12 > 400000 && $monthlyTax <= 0 && ($calc['calculation_mode'] ?? '') !== 'Exempt') {
                    $rows[] = [
                        $sl++,
                        $emp['employee_code'] ?? '-',
                        trim($emp['employee_name'] ?? 'Unknown'),
                        $emp['department_name'] ?? 'General',
                        $tin ? 'Valid' : 'Missing',
                        number_format($gross, 2),
                        '0.00',
                        'Zero Tax on Income Above Statutory Exemption Limit',
                        'Medium',
                        'Verify tax exemptions and investment rebate declarations'
                    ];
                    $exceptions[] = ['code' => $emp['employee_code'], 'type' => 'Zero Tax Above Threshold'];
                }

                // Negative Tax Anomaly
                if ($monthlyTax < 0) {
                    $rows[] = [
                        $sl++,
                        $emp['employee_code'] ?? '-',
                        trim($emp['employee_name'] ?? 'Unknown'),
                        $emp['department_name'] ?? 'General',
                        $tin ? 'Valid' : 'Missing',
                        number_format($gross, 2),
                        number_format($monthlyTax, 2),
                        'Negative Tax Value Computed',
                        'Critical',
                        'Review tax rebate cap and formula bounds'
                    ];
                    $exceptions[] = ['code' => $emp['employee_code'], 'type' => 'Negative Tax'];
                }
            } catch (\Throwable $e) {
                $rows[] = [
                    $sl++,
                    $emp['employee_code'] ?? '-',
                    trim($emp['employee_name'] ?? 'Unknown'),
                    $emp['department_name'] ?? 'General',
                    $tin ? 'Valid' : 'Missing',
                    number_format($gross, 2),
                    '0.00',
                    'Tax Rule Evaluation Failure: ' . $e->getMessage(),
                    'High',
                    'Verify company TAX domain configuration in RuleDefinitions'
                ];
                $exceptions[] = ['code' => $emp['employee_code'], 'type' => 'Rule Failure'];
            }
        }

        // Grand Total row
        $count = count($rows);
        $rows[] = [
            'TOTAL',
            'Grand Total Exceptions',
            "Count: {$count}",
            '-',
            '-',
            '-',
            '-',
            "{$count} Exceptions Flagged",
            $count > 0 ? 'Requires Action' : 'Clean',
            'Export and resolve with HR & Legal'
        ];

        return [
            'headers'    => $headers,
            'rows'       => $rows,
            'totals'     => [
                'exception_count' => $count
            ],
            'exceptions' => $exceptions
        ];
    }
}
