<?php

namespace App\Services;

use App\Models\EmployeeModel;
use App\Models\EmploymentTypeModel;
use App\Models\EmploymentHistoryModel;
use App\Services\NotificationService;

class EmploymentPeriodService
{
    protected EmployeeModel $employeeModel;
    protected EmploymentTypeModel $typeModel;
    protected EmploymentHistoryModel $historyModel;
    protected NotificationService $notificationService;

    public function __construct()
    {
        $this->employeeModel       = new EmployeeModel();
        $this->typeModel           = new EmploymentTypeModel();
        $this->historyModel        = new EmploymentHistoryModel();
        $this->notificationService = new NotificationService();
    }

    /**
     * Safely generate a UUID v4 string with zero external dependency.
     */
    protected function generateUuid(): string
    {
        if (class_exists(\Ramsey\Uuid\Uuid::class)) {
            try {
                return \Ramsey\Uuid\Uuid::uuid4()->toString();
            } catch (\Throwable $e) {}
        }

        try {
            $bytes = random_bytes(16);
        } catch (\Throwable $e) {
            $bytes = openssl_random_pseudo_bytes(16);
        }
        $bytes[6] = chr(ord($bytes[6]) & 0x0f | 0x40);
        $bytes[8] = chr(ord($bytes[8]) & 0x3f | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($bytes), 4));
    }

    /**
     * Calculate contract / period end date based on start date, duration value, and duration unit.
     * Example:
     * - Start Date = 01-01-2026, Duration = 6 Months -> End Date = 30-06-2026
     * - Start Date = 01-01-2026, Duration = 1 Year   -> End Date = 31-12-2026
     * - Start Date = 01-01-2026, Duration = 90 Days  -> End Date = 31-03-2026
     */
    public function calculateEndDate(string $startDate, int $durationValue, string $durationUnit = 'Months'): string
    {
        if (empty($startDate) || $durationValue <= 0) {
            return $startDate;
        }

        try {
            $dt = new \DateTime($startDate);
            $unit = ucfirst(strtolower(trim($durationUnit)));

            if ($unit === 'Days' || $unit === 'Day') {
                $daysToAdd = max(0, $durationValue - 1);
                $dt->modify("+{$daysToAdd} days");
            } elseif ($unit === 'Months' || $unit === 'Month') {
                $dt->modify("+{$durationValue} months");
                $dt->modify("-1 day");
            } elseif ($unit === 'Years' || $unit === 'Year') {
                $dt->modify("+{$durationValue} years");
                $dt->modify("-1 day");
            } else {
                // Fallback default months
                $dt->modify("+{$durationValue} months");
                $dt->modify("-1 day");
            }

            return $dt->format('Y-m-d');
        } catch (\Throwable $e) {
            return $startDate;
        }
    }

    /**
     * Determine dynamic employment period status based on dates and reminder threshold.
     * Statuses:
     * - 'Active': In progress with remaining days > reminder threshold
     * - 'Expiring Soon': Remaining days <= reminder days threshold (and > 0)
     * - 'Completed': Remaining days == 0 (today is the final contract day)
     * - 'Expired': Remaining days < 0 (contract has elapsed past the end date)
     */
    public function determineStatus(string $startDate, ?string $endDate, int $reminderDays = 15, ?string $referenceDate = null): array
    {
        $today = $referenceDate ? date('Y-m-d', strtotime($referenceDate)) : date('Y-m-d');

        if (empty($endDate)) {
            return [
                'status'           => 'Active',
                'remaining_days'   => null,
                'is_expiring_soon' => false,
                'is_completed'     => false,
                'is_expired'       => false,
                'is_active'        => true,
                'badge_class'      => 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-200/60'
            ];
        }

        $refTime = strtotime($today);
        $endTime = strtotime($endDate);
        $diffDays = (int) round(($endTime - $refTime) / 86400);

        if ($diffDays < 0) {
            return [
                'status'           => 'Expired',
                'remaining_days'   => $diffDays,
                'is_expiring_soon' => false,
                'is_completed'     => false,
                'is_expired'       => true,
                'is_active'        => false,
                'badge_class'      => 'bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-400 border border-rose-200/60'
            ];
        }

        if ($diffDays === 0) {
            return [
                'status'           => 'Completed',
                'remaining_days'   => 0,
                'is_expiring_soon' => false,
                'is_completed'     => true,
                'is_expired'       => false,
                'is_active'        => false,
                'badge_class'      => 'bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-400 border border-blue-200/60'
            ];
        }

        if ($diffDays <= $reminderDays) {
            return [
                'status'           => 'Expiring Soon',
                'remaining_days'   => $diffDays,
                'is_expiring_soon' => true,
                'is_completed'     => false,
                'is_expired'       => false,
                'is_active'        => true,
                'badge_class'      => 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400 border border-amber-200/60'
            ];
        }

        return [
            'status'           => 'Active',
            'remaining_days'   => $diffDays,
            'is_expiring_soon' => false,
            'is_completed'     => false,
            'is_expired'       => false,
            'is_active'        => true,
            'badge_class'      => 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-200/60'
        ];
    }

    /**
     * Synchronize and evaluate an employee's employment period upon assignment or update.
     */
    public function syncEmployeePeriod(
        string $employeeId,
        array $overrides = [],
        ?string $actorId = null,
        ?string $actorName = null,
        string $actionType = 'Assignment'
    ): array {
        $employee = $this->employeeModel->find($employeeId);
        if (!$employee) {
            return ['status' => 'error', 'message' => 'Employee not found'];
        }

        $typeId = $overrides['employment_type_id'] ?? $employee['employment_type_id'] ?? null;
        $empType = $typeId ? $this->typeModel->find($typeId) : null;

        // Use employee's Joining Date as the start date
        $startDate = $overrides['employment_start_date'] 
                     ?? employee_joining_date($overrides) 
                     ?? employee_joining_date($employee) 
                     ?? $employee['employment_start_date'] 
                     ?? date('Y-m-d');

        $isDurationEnabled = false;
        if (isset($overrides['duration_enabled'])) {
            $isDurationEnabled = (bool)$overrides['duration_enabled'];
        } elseif (!empty($empType) && !empty($empType['duration_enabled'])) {
            $isDurationEnabled = true;
        }

        $empProbStatus = strtolower(trim($employee['probation_status'] ?? ''));
        $isProbationConfirmed = !empty($employee['probation_confirmed_date']) || !empty($employee['confirmation_date']) || in_array($empProbStatus, ['completed', 'confirmed', 'not applicable', 'cancelled'], true);

        $isProbationType = !$isProbationConfirmed && (
            (!empty($empType) && (stripos($empType['name'] ?? '', 'probation') !== false || stripos($empType['code'] ?? '', 'prob') !== false))
            || (\App\Models\EmployeeModel::normalizeStatus($employee['status'] ?? '', true) === \App\Models\EmployeeModel::STATUS_PROBATION)
            || in_array($empProbStatus, ['active', 'pending', 'extended', 'on probation'], true)
        );

        $empTypeDurationVal = !empty($empType['duration_value']) ? (int)$empType['duration_value'] : null;
        $empTypeDurationUnit = !empty($empType['duration_unit']) ? $empType['duration_unit'] : 'Months';

        if (!$isDurationEnabled && empty($overrides['employment_end_date'])) {
            // Open-ended employment contract without fixed duration
            $updateData = [
                'employment_type_id'       => $typeId,
                'employment_start_date'    => $startDate,
                'employment_end_date'      => null,
                'employment_duration_value'=> null,
                'employment_duration_unit' => null,
                'employment_period_status' => 'Active'
            ];

            if ($isProbationType && $empTypeDurationVal !== null) {
                $calcProbEnd = $this->calculateEndDate($startDate, $empTypeDurationVal, $empTypeDurationUnit);
                $updateData['probation_start_date']     = $startDate;
                $updateData['probation_end_date']       = $calcProbEnd;
                $updateData['probation_duration_value'] = $empTypeDurationVal;
                $updateData['probation_duration_unit']  = $empTypeDurationUnit;
                if (empty($employee['probation_confirmed_date']) && empty($employee['confirmation_date']) && ($employee['probation_status'] ?? '') !== 'Completed') {
                    $updateData['probation_status'] = 'Active';
                }
            }

            $this->employeeModel->update($employeeId, $updateData);

            return [
                'status'         => 'success',
                'has_duration'   => false,
                'period_status'  => 'Active',
                'remaining_days' => null
            ];
        }

        // Duration is enabled - calculate employee-specific end date: Joining Date + Employment Type Duration
        $durationValue = isset($overrides['employment_duration_value']) && $overrides['employment_duration_value'] !== ''
            ? (int)$overrides['employment_duration_value']
            : (!empty($empType['duration_value']) ? (int)$empType['duration_value'] : 0);

        $durationUnit = !empty($overrides['employment_duration_unit'])
            ? $overrides['employment_duration_unit']
            : (!empty($empType['duration_unit']) ? $empType['duration_unit'] : 'Months');

        $autoCalculate = isset($overrides['employment_auto_calculate'])
            ? (int)$overrides['employment_auto_calculate']
            : 1;

        $reminderDays = isset($overrides['employment_expiry_reminder_days']) && $overrides['employment_expiry_reminder_days'] !== ''
            ? (int)$overrides['employment_expiry_reminder_days']
            : (!empty($empType['expiry_reminder_days']) ? (int)$empType['expiry_reminder_days'] : 0);

        // Automatically calculate: Employee End Date = Joining Date + Duration
        if ($autoCalculate && $durationValue > 0) {
            $endDate = $this->calculateEndDate($startDate, $durationValue, $durationUnit);
        } else {
            $endDate = !empty($overrides['employment_end_date'])
                ? $overrides['employment_end_date']
                : ($employee['employment_end_date'] ?? $this->calculateEndDate($startDate, $durationValue, $durationUnit));
        }

        $statusEvaluation = $this->determineStatus($startDate, $endDate, $reminderDays);

        $updateData = [
            'employment_type_id'            => $typeId,
            'employment_start_date'         => $startDate,
            'employment_end_date'           => $endDate,
            'employment_duration_value'     => $durationValue,
            'employment_duration_unit'      => $durationUnit,
            'employment_auto_calculate'     => $autoCalculate,
            'employment_expiry_reminder_days'=> $reminderDays,
            'employment_period_status'      => $statusEvaluation['status']
        ];

        if ($isProbationType) {
            $updateData['probation_start_date']     = $startDate;
            $updateData['probation_end_date']       = $endDate;
            $updateData['probation_duration_value'] = $durationValue;
            $updateData['probation_duration_unit']  = $durationUnit;
            if (empty($employee['probation_confirmed_date']) && empty($employee['confirmation_date']) && ($employee['probation_status'] ?? '') !== 'Completed') {
                $updateData['probation_status'] = 'Active';
            }
        }

        $this->employeeModel->update($employeeId, $updateData);

        // Record history - preserve existing employee employment periods
        $historyId = $this->generateUuid();
        $this->historyModel->insert([
            'id'                  => $historyId,
            'employee_id'         => $employeeId,
            'company_id'          => $employee['company_id'] ?? null,
            'employment_type_id'  => $typeId,
            'employment_type_name'=> $empType['name'] ?? 'Contractual / Probation',
            'start_date'          => $startDate,
            'end_date'            => $endDate,
            'duration_value'      => $durationValue,
            'duration_unit'       => $durationUnit,
            'action_type'         => $actionType,
            'status'              => $statusEvaluation['status'],
            'remarks'             => $overrides['remarks'] ?? ($actionType . ": Calculated from Joining Date {$startDate} + {$durationValue} {$durationUnit} = {$endDate}"),
            'created_by'          => $actorId,
            'created_by_name'     => $actorName,
            'created_at'          => date('Y-m-d H:i:s'),
            'updated_at'          => date('Y-m-d H:i:s')
        ]);

        // Send notification if expiring soon, completed, or expired
        if (in_array($statusEvaluation['status'], ['Expiring Soon', 'Completed', 'Expired'])) {
            $this->notificationService->triggerEmploymentPeriodNotification(
                $statusEvaluation['status'],
                $employee,
                $empType['name'] ?? 'Contract',
                $startDate,
                $endDate,
                (int)$statusEvaluation['remaining_days'],
                $employee['company_id'] ?? null
            );
        }

        return [
            'status'         => 'success',
            'has_duration'   => true,
            'start_date'     => $startDate,
            'end_date'       => $endDate,
            'duration_value' => $durationValue,
            'duration_unit'  => $durationUnit,
            'period_status'  => $statusEvaluation['status'],
            'remaining_days' => $statusEvaluation['remaining_days'],
            'history_id'     => $historyId
        ];
    }

    /**
     * Extend, Renew, Confirm Early, or Override an employee's employment period.
     * Supports:
     * - 'Extension' / 'Manual Extension': Extends current contract period
     * - 'Probation Extension': Extends probation duration with probation status tracking
     * - 'Early Confirmation': Confirms probation early, sets confirmation date and active status
     * - 'Renewal': Renews or transitions to a new employment type
     * - 'Duration Override': Employee-specific duration override
     */
    public function extendOrRenewPeriod(
        string $employeeId,
        array $payload,
        ?string $actorId = null,
        ?string $actorName = null
    ): array {
        $employee = $this->employeeModel->find($employeeId);
        if (!$employee) {
            return ['status' => 'error', 'message' => 'Employee record not found'];
        }

        $rawAction  = $payload['action_type'] ?? 'Extension';
        $actionType = ucwords(strtolower(trim($rawAction)));
        $newTypeId  = $payload['employment_type_id'] ?? $employee['employment_type_id'];
        $empType    = $newTypeId ? $this->typeModel->find($newTypeId) : null;

        // Handle Early Confirmation
        if (in_array($actionType, ['Early Confirmation', 'Confirmation', 'Confirm Early'])) {
            $confirmDate = !empty($payload['confirmation_date']) ? $payload['confirmation_date'] : date('Y-m-d');
            $remarks = $payload['remarks'] ?? "Early confirmation approved on {$confirmDate}";

            $empUpdate = [
                'status'                  => 'Active',
                'employment_type_id'      => $newTypeId,
                'employment_period_status'=> 'Completed'
            ];
            if ($this->employeeModel->db->fieldExists('probation_confirmed_date', 'employees')) {
                $empUpdate['probation_confirmed_date'] = $confirmDate;
            }
            if ($this->employeeModel->db->fieldExists('probation_status', 'employees')) {
                $empUpdate['probation_status'] = 'Confirmed';
            }
            if ($this->employeeModel->db->fieldExists('probation_notes', 'employees')) {
                $empUpdate['probation_notes'] = $remarks;
            }

            $this->employeeModel->update($employeeId, $empUpdate);

            $historyId = $this->generateUuid();
            $this->historyModel->insert([
                'id'                  => $historyId,
                'employee_id'         => $employeeId,
                'company_id'          => $employee['company_id'] ?? null,
                'employment_type_id'  => $newTypeId,
                'employment_type_name'=> $empType['name'] ?? 'Confirmed Staff',
                'start_date'          => $employee['employment_start_date'] ?? employee_joining_date($employee) ?? date('Y-m-d'),
                'end_date'            => $confirmDate,
                'duration_value'      => $employee['employment_duration_value'] ?? 0,
                'duration_unit'       => $employee['employment_duration_unit'] ?? 'Months',
                'action_type'         => 'Early Confirmation',
                'status'              => 'Completed',
                'remarks'             => $remarks,
                'created_by'          => $actorId,
                'created_by_name'     => $actorName,
                'created_at'          => date('Y-m-d H:i:s'),
                'updated_at'          => date('Y-m-d H:i:s')
            ]);

            $this->notificationService->triggerEmploymentPeriodNotification(
                'Early Confirmation',
                $employee,
                $empType['name'] ?? 'Permanent Staff',
                $employee['employment_start_date'] ?? employee_joining_date($employee) ?? date('Y-m-d'),
                $confirmDate,
                0,
                $employee['company_id'] ?? null
            );

            return [
                'status'        => 'success',
                'message'       => "Employee successfully confirmed early on {$confirmDate}.",
                'start_date'    => $employee['employment_start_date'] ?? employee_joining_date($employee),
                'end_date'      => $confirmDate,
                'period_status' => 'Completed',
                'remaining_days'=> 0
            ];
        }

        // Determine Start Date based on action
        if ($actionType === 'Renewal') {
            $startDate = !empty($payload['start_date'])
                ? $payload['start_date']
                : (!empty($employee['employment_end_date'])
                    ? date('Y-m-d', strtotime('+1 day', strtotime($employee['employment_end_date'])))
                    : date('Y-m-d'));
        } elseif (in_array($actionType, ['Probation Extension', 'Extension', 'Manual Extension'])) {
            // Extension continues from current end date or current start date
            $startDate = !empty($payload['start_date'])
                ? $payload['start_date']
                : (!empty($employee['employment_end_date'])
                    ? date('Y-m-d', strtotime('+1 day', strtotime($employee['employment_end_date'])))
                    : ($employee['employment_start_date'] ?? employee_joining_date($employee) ?? date('Y-m-d')));
        } else {
            // Duration Override or other adjustments
            $startDate = !empty($payload['start_date'])
                ? $payload['start_date']
                : ($employee['employment_start_date'] ?? employee_joining_date($employee) ?? date('Y-m-d'));
        }

        $durationValue = isset($payload['duration_value']) && $payload['duration_value'] !== ''
            ? (int)$payload['duration_value']
            : ($empType['duration_value'] ?? 3);

        $durationUnit = !empty($payload['duration_unit'])
            ? $payload['duration_unit']
            : ($empType['duration_unit'] ?? 'Months');

        $autoCalculate = isset($payload['auto_calculate']) ? (int)$payload['auto_calculate'] : 1;
        $reminderDays  = isset($payload['reminder_days']) && $payload['reminder_days'] !== ''
            ? (int)$payload['reminder_days']
            : ($empType['expiry_reminder_days'] ?? 15);

        if ($autoCalculate && $durationValue > 0) {
            $endDate = $this->calculateEndDate($startDate, $durationValue, $durationUnit);
        } else {
            $endDate = !empty($payload['end_date'])
                ? $payload['end_date']
                : $this->calculateEndDate($startDate, $durationValue, $durationUnit);
        }

        $statusEvaluation = $this->determineStatus($startDate, $endDate, $reminderDays);

        // Update employee
        $empUpdate = [
            'employment_type_id'            => $newTypeId,
            'employment_start_date'         => $startDate,
            'employment_end_date'           => $endDate,
            'employment_duration_value'     => $durationValue,
            'employment_duration_unit'      => $durationUnit,
            'employment_auto_calculate'     => $autoCalculate,
            'employment_expiry_reminder_days'=> $reminderDays,
            'employment_period_status'      => $statusEvaluation['status']
        ];

        if ($actionType === 'Probation Extension') {
            if ($this->employeeModel->db->fieldExists('probation_extended_date', 'employees')) {
                $empUpdate['probation_extended_date'] = $endDate;
            }
            if ($this->employeeModel->db->fieldExists('probation_status', 'employees')) {
                $empUpdate['probation_status'] = 'Extended';
            }
            if ($this->employeeModel->db->fieldExists('probation_notes', 'employees')) {
                $empUpdate['probation_notes'] = $payload['remarks'] ?? "Probation extended by {$durationValue} {$durationUnit} until {$endDate}";
            }
        }

        $this->employeeModel->update($employeeId, $empUpdate);

        // Insert new contract history
        $historyId = $this->generateUuid();
        $this->historyModel->insert([
            'id'                  => $historyId,
            'employee_id'         => $employeeId,
            'company_id'          => $employee['company_id'] ?? null,
            'employment_type_id'  => $newTypeId,
            'employment_type_name'=> $empType['name'] ?? ($actionType . ' Contract'),
            'start_date'          => $startDate,
            'end_date'            => $endDate,
            'duration_value'      => $durationValue,
            'duration_unit'       => $durationUnit,
            'action_type'         => $actionType,
            'status'              => $statusEvaluation['status'],
            'remarks'             => $payload['remarks'] ?? ($actionType . ": {$durationValue} {$durationUnit} from {$startDate} until {$endDate}"),
            'created_by'          => $actorId,
            'created_by_name'     => $actorName,
            'created_at'          => date('Y-m-d H:i:s'),
            'updated_at'          => date('Y-m-d H:i:s')
        ]);

        // Notify HR and Admin
        $this->notificationService->triggerEmploymentPeriodNotification(
            $actionType,
            $employee,
            $empType['name'] ?? 'Contract',
            $startDate,
            $endDate,
            (int)($statusEvaluation['remaining_days'] ?? 0),
            $employee['company_id'] ?? null
        );

        return [
            'status'        => 'success',
            'message'       => "Employment period successfully updated ({$actionType}).",
            'start_date'    => $startDate,
            'end_date'      => $endDate,
            'period_status' => $statusEvaluation['status'],
            'remaining_days'=> $statusEvaluation['remaining_days']
        ];
    }

    /**
     * Run batch scan across all active employees to detect expiring, completed, or expired employment periods.
     * Dispatches multi-channel HR notifications for any newly matched employee.
     */
    public function runBatchExpiryScan(?string $companyId = null, ?string $asOfDate = null): array
    {
        $referenceDate = $asOfDate ?: date('Y-m-d');
        
        $db = $this->employeeModel->db;
        $hasEndDate = false;
        try {
            if ($db->tableExists('employees')) {
                $cols = $db->getFieldNames('employees');
                $hasEndDate = in_array('employment_end_date', $cols, true);
            }
        } catch (\Throwable $e) {
            $hasEndDate = false;
        }

        $builder = $this->employeeModel->builder();
        $builder->select('employees.*, employment_types.name as employment_type_name, employment_types.duration_enabled, employment_types.duration_value as type_duration_value, employment_types.duration_unit as type_duration_unit, employment_types.expiry_reminder_days as default_reminder_days')
                ->join('employment_types', 'employment_types.id = employees.employment_type_id', 'left');

        if ($hasEndDate) {
            $builder->groupStart()
                ->where('employees.employment_end_date IS NOT NULL', null, false)
                ->orWhere('employment_types.duration_enabled', 1)
            ->groupEnd();
        } else {
            $builder->where('employment_types.duration_enabled', 1);
        }

        $builder->where('employees.status !=', \App\Models\EmployeeModel::STATUS_TERMINATED)
                ->where('employees.status !=', \App\Models\EmployeeModel::STATUS_RESIGNED);

        if (!empty($companyId)) {
            $builder->where('employees.company_id', $companyId);
        }

        $employees = $builder->get()->getResultArray();

        $metrics = [
            'total_scanned'      => count($employees),
            'active_count'       => 0,
            'expiring_soon_count'=> 0,
            'completed_count'    => 0,
            'expired_count'      => 0,
            'notifications_sent' => 0,
            'as_of_date'         => $referenceDate,
            'records'            => []
        ];

        foreach ($employees as $emp) {
            $startDate = $emp['employment_start_date'] ?? employee_joining_date($emp) ?? $referenceDate;
            $endDate   = $emp['employment_end_date'] ?? null;
            $reminder  = !empty($emp['employment_expiry_reminder_days'])
                ? (int)$emp['employment_expiry_reminder_days']
                : (!empty($emp['default_reminder_days']) ? (int)$emp['default_reminder_days'] : 15);

            if (empty($endDate) && !empty($emp['duration_enabled'])) {
                $durVal = !empty($emp['employment_duration_value']) ? (int)$emp['employment_duration_value'] : (!empty($emp['type_duration_value']) ? (int)$emp['type_duration_value'] : 6);
                $durUnit = !empty($emp['employment_duration_unit']) ? $emp['employment_duration_unit'] : (!empty($emp['type_duration_unit']) ? $emp['type_duration_unit'] : 'Months');
                $endDate = $this->calculateEndDate($startDate, $durVal, $durUnit);
            }

            if (empty($endDate)) {
                $metrics['active_count']++;
                continue;
            }

            $eval = $this->determineStatus($startDate, $endDate, $reminder, $referenceDate);
            $newStatus = $eval['status'];

            // Count metrics
            if ($newStatus === 'Active') {
                $metrics['active_count']++;
            } elseif ($newStatus === 'Expiring Soon') {
                $metrics['expiring_soon_count']++;
            } elseif ($newStatus === 'Completed') {
                $metrics['completed_count']++;
            } elseif ($newStatus === 'Expired') {
                $metrics['expired_count']++;
            }

            // Update database status if changed
            if (($emp['employment_period_status'] ?? '') !== $newStatus) {
                $this->employeeModel->update($emp['id'], [
                    'employment_period_status' => $newStatus
                ]);
            }

            // Check if notification is required:
            // Send if status is 'Expiring Soon', 'Completed', or 'Expired',
            // AND either never notified for this status or not notified in the last 24 hours
            $shouldNotify = in_array($newStatus, ['Expiring Soon', 'Completed', 'Expired']);
            $lastStatus   = $emp['employment_last_notified_status'] ?? null;
            $lastNotified = $emp['employment_last_notified_at'] ?? null;

            $cooldownPassed = true;
            if ($lastNotified && (strtotime($referenceDate) - strtotime($lastNotified)) < 86400 && $lastStatus === $newStatus) {
                $cooldownPassed = false;
            }

            if ($shouldNotify && ($lastStatus !== $newStatus || $cooldownPassed)) {
                $this->notificationService->triggerEmploymentPeriodNotification(
                    $newStatus,
                    $emp,
                    $emp['employment_type_name'] ?? 'Contract Type',
                    $startDate,
                    $endDate,
                    (int)$eval['remaining_days'],
                    $emp['company_id'] ?? null
                );

                $this->employeeModel->update($emp['id'], [
                    'employment_last_notified_at'    => date('Y-m-d H:i:s'),
                    'employment_last_notified_status'=> $newStatus
                ]);

                $metrics['notifications_sent']++;
            }

            $metrics['records'][] = [
                'employee_id'    => $emp['id'],
                'employee_code'  => $emp['employee_code'] ?? 'EMP',
                'name'           => trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')),
                'type_name'      => $emp['employment_type_name'] ?? 'General',
                'start_date'     => $startDate,
                'end_date'       => $endDate,
                'remaining_days' => $eval['remaining_days'],
                'status'         => $newStatus,
                'badge_class'    => $eval['badge_class'],
                'reminder_days'  => $reminder
            ];
        }

        return $metrics;
    }
}
