<?php

namespace App\Services;

use App\Models\ShiftModel;
use App\Models\ShiftSwapModel;
use App\Models\RosterModel;
use App\Models\RosterAssignmentModel;
use App\Models\EmployeeModel;
use App\Models\DepartmentModel;
use App\Models\NotificationModel;
use App\Models\LeaveModel;
use App\Models\HolidayModel;
use App\Services\RuleEngineService;
use App\Services\AuditService;
use Config\Database;

class RosterService
{
    protected $db;
    protected $shiftModel;
    protected $swapModel;
    protected $rosterModel;
    protected $assignmentModel;
    protected $empModel;
    protected $ruleEngine;

    public function __construct()
    {
        $this->db = Database::connect();
        $this->shiftModel = new ShiftModel();
        $this->swapModel = new ShiftSwapModel();
        $this->rosterModel = new RosterModel();
        $this->assignmentModel = new RosterAssignmentModel();
        $this->empModel = new EmployeeModel();
        $this->ruleEngine = new RuleEngineService();
    }

    /**
     * Build the 7-day Running Shift Roster Matrix
     */
    public function getWeeklyRosterMatrix(?string $startDate = null, ?string $departmentId = null, ?string $branchId = null, ?string $shiftId = null, ?string $search = null, ?string $companyId = null): array
    {
        // 1. Calculate Week Dates (Default: Current week starting Sunday)
        if (!$startDate) {
            $currentDayOfWeek = (int)date('w'); // 0 (Sun) to 6 (Sat)
            $startDate = date('Y-m-d', strtotime("-{$currentDayOfWeek} days"));
        } else {
            $timestamp = strtotime($startDate);
            $dayOfWeek = (int)date('w', $timestamp);
            $startDate = date('Y-m-d', strtotime("-{$dayOfWeek} days", $timestamp));
        }

        $weekDays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        $weekDates = [];
        for ($i = 0; $i < 7; $i++) {
            $date = date('Y-m-d', strtotime("+{$i} days", strtotime($startDate)));
            $weekDates[] = [
                'day_name' => $weekDays[$i],
                'short_day' => substr($weekDays[$i], 0, 3),
                'date' => $date,
                'formatted' => date('d M', strtotime($date)),
                'is_today' => ($date === date('Y-m-d'))
            ];
        }
        $endDate = $weekDates[6]['date'];

        return $this->buildMatrixForDateRange($startDate, $endDate, $weekDates, $departmentId, $branchId, $shiftId, $search, $companyId);
    }

    /**
     * Build the Full Month Roster Matrix
     */
    public function getMonthlyRosterMatrix(string $yearMonth, ?string $departmentId = null, ?string $branchId = null, ?string $shiftId = null, ?string $search = null, ?string $companyId = null): array
    {
        $startDate = $yearMonth . '-01';
        $daysInMonth = (int)date('t', strtotime($startDate));
        $endDate = $yearMonth . '-' . sprintf('%02d', $daysInMonth);

        $monthDates = [];
        for ($i = 1; $i <= $daysInMonth; $i++) {
            $date = $yearMonth . '-' . sprintf('%02d', $i);
            $dayIndex = (int)date('w', strtotime($date));
            $dayName = RuleEngineService::DAYS_OF_WEEK[$dayIndex] ?? 'Sunday';
            $monthDates[] = [
                'day_name' => $dayName,
                'short_day' => substr($dayName, 0, 3),
                'date' => $date,
                'day_number' => $i,
                'formatted' => date('d M', strtotime($date)),
                'is_today' => ($date === date('Y-m-d'))
            ];
        }

        return $this->buildMatrixForDateRange($startDate, $endDate, $monthDates, $departmentId, $branchId, $shiftId, $search, $companyId, 'monthly');
    }

    /**
     * Core matrix builder for any given date array
     */
    protected function buildMatrixForDateRange(string $startDate, string $endDate, array $dateSlots, ?string $departmentId, ?string $branchId, ?string $shiftId, ?string $search, ?string $companyId, string $viewMode = 'weekly'): array
    {
        // 1. Fetch Active Shifts
        $rawShifts = $this->shiftModel->getActiveShifts($companyId);
        if (empty($rawShifts)) {
            $defaultWorkDays = \App\Services\CompanyWeekendService::getCompanyWorkingDays($companyId);
            $defaultWeeklyOff = \App\Services\CompanyWeekendService::getCompanyWeeklyOff($companyId);
            $rawShifts = [
                [
                    'id' => 'shift-001',
                    'name' => 'General Day Shift (9 AM - 6 PM)',
                    'code' => 'SHIFT-DAY-GEN',
                    'start_time' => '09:00:00',
                    'end_time' => '18:00:00',
                    'break_start' => '13:00:00',
                    'break_end' => '14:00:00',
                    'break_duration_minutes' => 60,
                    'grace_time' => 15,
                    'late_grace_period_minutes' => 15,
                    'late_threshold_minutes' => 60,
                    'early_out_threshold_minutes' => 15,
                    'half_day_threshold_hours' => 4.0,
                    'minimum_working_hours' => 8.0,
                    'absent_threshold_hours' => 2.0,
                    'work_days_array' => $defaultWorkDays,
                    'weekly_off_array' => $defaultWeeklyOff,
                    'color' => '#10b981',
                    'badge_class' => 'bg-emerald-50 text-emerald-700 border-emerald-200',
                    'total_hours' => 9.0,
                    'net_work_hours' => 8.0,
                    'min_staffing_required' => 1,
                    'is_night_shift' => 0
                ]
            ];
        }

        $shiftsById = [];
        foreach ($rawShifts as $s) {
            $shiftsById[$s['id']] = $s;
        }
        $defaultShift = reset($rawShifts);

        // 2. Fetch Employees with Department and Shift details
        $empBuilder = $this->empModel->select("
            employees.*,
            departments.name as department_name,
            designations.name as designation_name,
            branches.name as branch_name,
            shifts.name as shift_name,
            shifts.code as shift_code,
            shifts.start_time as shift_start,
            shifts.end_time as shift_end
        ")
        ->join('departments', 'departments.id = employees.department_id', 'left')
        ->join('designations', 'designations.id = employees.designation_id', 'left')
        ->join('branches', 'branches.id = employees.branch_id', 'left')
        ->join('shifts', 'shifts.id = employees.shift_id', 'left')
        ->where('employees.status', \App\Models\EmployeeModel::STATUS_ACTIVE);

        if ($companyId) {
            $empBuilder->where('employees.company_id', $companyId);
        }
        if ($departmentId && $departmentId !== 'all') {
            $empBuilder->where('employees.department_id', $departmentId);
        }
        if ($branchId && $branchId !== 'all') {
            $empBuilder->where('employees.branch_id', $branchId);
        }
        if ($shiftId && $shiftId !== 'all') {
            $empBuilder->where('employees.shift_id', $shiftId);
        }
        if ($search) {
            $empBuilder->groupStart()
                ->like('employees.first_name', $search)
                ->orLike('employees.last_name', $search)
                ->orLike('employees.employee_code', $search)
                ->groupEnd();
        }

        $employees = $empBuilder->orderBy('employees.first_name', 'ASC')->findAll();

        // 3. Fetch specific Roster Assignments for this date range if present
        $rosterAssignments = [];
        if ($this->db->tableExists('roster_assignments')) {
            $raBuilder = $this->db->table('roster_assignments')
                ->where('roster_assignments.date >=', $startDate)
                ->where('roster_assignments.date <=', $endDate);
            if (!empty($companyId)) {
                $raBuilder->join('employees', 'employees.id = roster_assignments.employee_id', 'inner')
                    ->where('employees.company_id', $companyId);
            }
            $assignments = $raBuilder->get()->getResultArray();
            foreach ($assignments as $ra) {
                $rosterAssignments[$ra['employee_id']][$ra['date']] = $ra;
            }
        }

        // 4. Fetch Approved Leaves for the period to show Leave status
        $approvedLeaves = [];
        $leaveTable = $this->db->tableExists('leave_applications') ? 'leave_applications' : ($this->db->tableExists('leaves') ? 'leaves' : null);
        if ($leaveTable !== null) {
            $cols = $this->db->getFieldNames($leaveTable);
            $startCol = in_array('start_date', $cols, true) ? 'start_date' : (in_array('from_date', $cols, true) ? 'from_date' : 'start_date');
            $endCol = in_array('end_date', $cols, true) ? 'end_date' : (in_array('to_date', $cols, true) ? 'to_date' : 'end_date');

            $leaveBuilder = $this->db->table($leaveTable)
                ->select("{$leaveTable}.*, leave_types.name as leave_type_name")
                ->join('leave_types', "leave_types.id = {$leaveTable}.leave_type_id", 'left')
                ->where("{$leaveTable}.status", 'Approved')
                ->where("{$leaveTable}.{$startCol} <=", $endDate)
                ->where("{$leaveTable}.{$endCol} >=", $startDate);
            if (!empty($companyId)) {
                $leaveBuilder->join('employees', "employees.id = {$leaveTable}.employee_id", 'inner')
                    ->where('employees.company_id', $companyId);
            }
            $leaves = $leaveBuilder->get()->getResultArray();
            foreach ($leaves as $lv) {
                $empId = $lv['employee_id'];
                $rawStart = $lv[$startCol] ?? $lv['start_date'] ?? $lv['from_date'] ?? null;
                $rawEnd = $lv[$endCol] ?? $lv['end_date'] ?? $lv['to_date'] ?? $rawStart;
                if (!$rawStart) {
                    continue;
                }
                $lStart = max($startDate, $rawStart);
                $lEnd = min($endDate, $rawEnd);
                $curr = strtotime($lStart);
                $endTs = strtotime($lEnd);
                while ($curr <= $endTs) {
                    $dStr = date('Y-m-d', $curr);
                    $approvedLeaves[$empId][$dStr] = $lv['leave_type_name'] ?? 'Leave';
                    $curr = strtotime('+1 day', $curr);
                }
            }
        }

        // 5. Fetch Holidays
        $holidaysMap = [];
        if ($this->db->tableExists('holidays')) {
            $hBuilder = $this->db->table('holidays')
                ->where('date >=', $startDate)
                ->where('date <=', $endDate);
            if (!empty($companyId) && $this->db->fieldExists('company_id', 'holidays')) {
                $hBuilder->groupStart()
                    ->where('company_id', $companyId)
                    ->orWhere('company_id IS NULL')
                    ->orWhere('company_id', '')
                ->groupEnd();
            }
            $holidays = $hBuilder->get()->getResultArray();
            foreach ($holidays as $h) {
                $holidaysMap[$h['date']] = $h['name'];
            }
        }

        // 6. Build Employee Matrix Rows
        $matrixRows = [];
        $totalScheduledShifts = 0;
        $totalNightShifts = 0;
        $totalDutyHours = 0;

        foreach ($employees as $emp) {
            $assignedShiftId = $emp['shift_id'] ?? $defaultShift['id'];
            $activeShift = $shiftsById[$assignedShiftId] ?? $defaultShift;

            $empRow = [
                'id' => $emp['id'],
                'code' => $emp['employee_code'],
                'name' => trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')),
                'avatar' => !empty($emp['photo']) ? $emp['photo'] : (!empty($emp['avatar']) ? $emp['avatar'] : 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&auto=format&fit=crop&q=80'),
                'department_name' => $emp['department_name'] ?? 'General',
                'department_id' => $emp['department_id'] ?? '',
                'designation_name' => $emp['designation_name'] ?? 'Staff',
                'branch_name' => $emp['branch_name'] ?? 'Headquarters',
                'branch_id' => $emp['branch_id'] ?? '',
                'shift' => $activeShift,
                'days' => [],
                'total_duty_days' => 0,
                'total_duty_hours' => 0
            ];

            foreach ($dateSlots as $slot) {
                $dayName = $slot['day_name'];
                $curDate = $slot['date'];

                // Check leave status
                $leaveTitle = $approvedLeaves[$emp['id']][$curDate] ?? null;
                $holidayTitle = $holidaysMap[$curDate] ?? null;

                // Check override in roster_assignments
                $override = $rosterAssignments[$emp['id']][$curDate] ?? null;
                $dutyAssignment = \App\Services\CompanyWeekendService::getDutyAssignment($emp['id'], $curDate, $companyId);
                $isCompanyWeeklyOff = \App\Services\CompanyWeekendService::isWeeklyOff($curDate, $companyId, $emp['id']);
                
                $isOverride = !empty($override);
                $isDraft = $isOverride && (int)($override['is_published'] ?? 1) === 0;
                $isPublished = $isOverride && (int)($override['is_published'] ?? 1) === 1;
                $isDayOff = $isOverride && !empty($override['is_day_off']);
                $assignmentId = $override['id'] ?? null;

                // Pre-check payroll settlement for employee on this date
                $isSettled = false;
                if (!empty($emp['id']) && !empty($curDate)) {
                    $isSettled = $this->isPayrollSettled($companyId ?: ($emp['company_id'] ?? ''), $curDate, $emp['id']);
                }

                if ($isDraft) {
                    // Draft assignment: visible for planning in roster matrix, but does not affect attendance
                    $overrideShiftId = $override['shift_id'] ?? null;
                    $draftShift = (!empty($overrideShiftId) && isset($shiftsById[$overrideShiftId])) ? $shiftsById[$overrideShiftId] : $activeShift;
                    $dayShift = $draftShift;

                    if ($isDayOff) {
                        $isDuty = false;
                        $statusLabel = 'Off (Draft)';
                        $statusCode = 'OFF';
                        $hours = 0;
                    } else {
                        $isDuty = true;
                        $statusLabel = 'Duty (Draft)';
                        $statusCode = 'DUTY';
                        $hours = $dayShift['net_work_hours'] ?? 8.0;
                    }
                } elseif ($leaveTitle) {
                    $isDuty = false;
                    $dayShift = $activeShift;
                    $statusLabel = 'Leave (' . $leaveTitle . ')';
                    $statusCode = 'LEAVE';
                    $hours = 0;
                } else {
                    // ENG-02: Authoritative Centralized Shift Resolution (P0-004 hierarchy)
                    // Priority: 1. Duty Assignment -> 2. Approved Shift Swap -> 3. Roster Assignment -> 4. Master Shift -> 5. Default Fallback
                    $effectiveShift = $this->shiftModel->resolveEffectiveShift($emp['id'], $curDate, $emp);
                    $dayShift = $effectiveShift;

                    if ($effectiveShift['source'] === 'DUTY_ASSIGNMENT') {
                        $isDuty = true;
                        if ($holidayTitle) {
                            $statusCode = 'HOLIDAY_DUTY';
                            $statusLabel = 'Holiday Duty';
                        } elseif ($isCompanyWeeklyOff) {
                            $statusCode = 'WEEKEND_DUTY';
                            $statusLabel = 'Weekend Duty';
                        } else {
                            $statusCode = 'DUTY';
                            $statusLabel = 'Special Duty';
                        }
                        $hours = $dayShift['net_work_hours'] ?? 8.0;
                    } elseif ($effectiveShift['source'] === 'SHIFT_SWAP') {
                        $isDuty = true;
                        $statusCode = 'DUTY';
                        $statusLabel = 'Duty (Swap)';
                        $hours = $dayShift['net_work_hours'] ?? 8.0;
                    } elseif ($effectiveShift['source'] === 'ROSTER_DAY_OFF' || ($effectiveShift['outcome'] ?? '') === 'ROSTER_DAY_OFF') {
                        $isDuty = false;
                        $statusLabel = 'Off (Scheduled)';
                        $statusCode = 'OFF';
                        $hours = 0;
                    } elseif ($effectiveShift['source'] === 'ROSTER_ASSIGNMENT') {
                        $override = $rosterAssignments[$emp['id']][$curDate] ?? null;
                        $isOff = !empty($override['is_weekend']) || !empty($override['is_day_off']);
                        $isDuty = !$isOff;
                        $statusLabel = $isDuty ? 'Duty' : 'Off';
                        $statusCode = $isDuty ? 'DUTY' : 'OFF';
                        $hours = $isDuty ? ($dayShift['net_work_hours'] ?? 8.0) : 0;
                    } elseif ($effectiveShift['outcome'] === 'NO_ASSIGNED_SHIFT') {
                        $isDuty = false;
                        $statusLabel = 'Unscheduled';
                        $statusCode = 'UNSCHEDULED';
                        $hours = 0;
                    } elseif ($effectiveShift['outcome'] === 'HOLIDAY' || $holidayTitle) {
                        $isDuty = false;
                        $statusLabel = 'Holiday (' . ($effectiveShift['holiday_name'] ?? $holidayTitle ?? 'Holiday') . ')';
                        $statusCode = 'HOLIDAY';
                        $hours = 0;
                    } elseif ($effectiveShift['outcome'] === 'WEEKLY_OFF' || $isCompanyWeeklyOff) {
                        $isDuty = false;
                        $statusLabel = 'Weekly Off';
                        $statusCode = 'OFF';
                        $hours = 0;
                    } else {
                        $isDuty = !empty($effectiveShift['is_scheduled']) && empty($effectiveShift['is_day_off']);
                        $statusLabel = $isDuty ? 'Duty' : 'Off';
                        $statusCode = $isDuty ? 'DUTY' : 'OFF';
                        $hours = $isDuty ? ($dayShift['net_work_hours'] ?? 8.0) : 0;
                    }
                }

                // Detect cell-level conflict warnings
                $conflictWarning = null;
                $holidayWarning = null;
                if ($leaveTitle && $isDuty) {
                    $conflictWarning = "Employee scheduled for duty during approved leave: {$leaveTitle}";
                } elseif ($holidayTitle && $isDuty) {
                    $holidayWarning = "Company Holiday: {$holidayTitle}";
                }

                if ($isDuty) {
                    $empRow['total_duty_days']++;
                    $empRow['total_duty_hours'] += $hours;
                    $totalScheduledShifts++;
                    $totalDutyHours += $hours;
                    if (!empty($dayShift['is_night_shift'])) {
                        $totalNightShifts++;
                    }
                }

                $empRow['days'][$curDate] = [
                    'date'             => $curDate,
                    'day_name'         => $dayName,
                    'is_duty'          => $isDuty,
                    'status_code'      => $statusCode,
                    'status_label'     => $statusLabel,
                    'shift'            => $dayShift,
                    'hours'            => $hours,
                    'leave_title'      => $leaveTitle,
                    'holiday_title'    => $holidayTitle,
                    'is_override'      => $isOverride,
                    'is_draft'         => $isDraft,
                    'is_published'     => $isPublished,
                    'is_day_off'       => $isDayOff,
                    'assignment_id'    => $assignmentId,
                    'conflict_warning' => $conflictWarning,
                    'holiday_warning'  => $holidayWarning,
                    'payroll_settled'  => $isSettled,
                ];
            }

            $empRow['total_week_duty_days'] = $empRow['total_duty_days'];
            $empRow['total_week_hours'] = round($empRow['total_duty_hours'], 1);

            $matrixRows[] = $empRow;
        }

        // 7. Calculate Staffing Coverage
        $coverage = $this->calculateCoverageForSlots($dateSlots, $rawShifts, $matrixRows);

        // 8. Detect Conflicts
        $conflicts = $this->detectMatrixConflicts($dateSlots, $matrixRows);

        $currentDayOfWeek = (int)date('w');
        return [
            'view_mode' => $viewMode,
            'start_date' => $startDate,
            'end_date' => $endDate,
            'prev_week_start' => date('Y-m-d', strtotime('-7 days', strtotime($startDate))),
            'next_week_start' => date('Y-m-d', strtotime('+7 days', strtotime($startDate))),
            'this_week_start' => date('Y-m-d', strtotime("-{$currentDayOfWeek} days")),
            'week_dates' => $dateSlots,
            'date_slots' => $dateSlots,
            'shifts' => $rawShifts,
            'matrix' => $matrixRows,
            'coverage' => $coverage,
            'conflicts' => $conflicts,
            'stats' => [
                'total_employees' => count($employees),
                'total_scheduled_shifts' => $totalScheduledShifts,
                'total_night_shifts' => $totalNightShifts,
                'total_duty_hours' => round($totalDutyHours, 1),
                'avg_hours_per_emp' => count($employees) > 0 ? round($totalDutyHours / count($employees), 1) : 0,
                'total_conflicts_count' => count($conflicts),
                'understaffed_slots_count' => $coverage['understaffed_count'] ?? 0
            ]
        ];
    }

    /**
     * Calculate Staffing Coverage for slots
     */
    protected function calculateCoverageForSlots(array $dateSlots, array $shifts, array $matrixRows): array
    {
        $coverageByDate = [];
        $totalSlots = 0;
        $understaffedCount = 0;
        $optimalCount = 0;
        $overstaffedCount = 0;

        foreach ($dateSlots as $slot) {
            $date = $slot['date'];
            $coverageByDate[$date] = [
                'date' => $date,
                'day_name' => $slot['day_name'],
                'shifts' => []
            ];

            foreach ($shifts as $shift) {
                $shiftId = $shift['id'];
                $required = (int)($shift['min_staffing_required'] ?? 1);
                $scheduled = 0;
                $assignedStaff = [];

                foreach ($matrixRows as $emp) {
                    $dayInfo = $emp['days'][$date] ?? null;
                    if ($dayInfo && $dayInfo['is_duty'] && ($dayInfo['shift']['id'] ?? '') === $shiftId) {
                        $scheduled++;
                        $assignedStaff[] = [
                            'id' => $emp['id'],
                            'name' => $emp['name'],
                            'avatar' => $emp['avatar'],
                            'code' => $emp['code']
                        ];
                    }
                }

                $diff = $scheduled - $required;
                if ($scheduled < $required) {
                    $status = 'Understaffed';
                    $understaffedCount++;
                } elseif ($scheduled === $required) {
                    $status = 'Optimal';
                    $optimalCount++;
                } else {
                    $status = 'Overstaffed';
                    $overstaffedCount++;
                }
                $totalSlots++;

                $coverageByDate[$date]['shifts'][$shiftId] = [
                    'shift_id' => $shiftId,
                    'shift_name' => $shift['name'],
                    'shift_code' => $shift['code'] ?? 'SHIFT',
                    'color' => $shift['color'] ?? '#6366f1',
                    'required_headcount' => $required,
                    'scheduled_headcount' => $scheduled,
                    'difference' => $diff,
                    'status' => $status,
                    'assigned_employees' => $assignedStaff
                ];
            }
        }

        $overallCompliance = $totalSlots > 0 ? round((($optimalCount + $overstaffedCount) / $totalSlots) * 100, 1) : 100;

        return [
            'by_date' => $coverageByDate,
            'total_slots' => $totalSlots,
            'understaffed_count' => $understaffedCount,
            'optimal_count' => $optimalCount,
            'overstaffed_count' => $overstaffedCount,
            'coverage_percentage' => $overallCompliance
        ];
    }

    /**
     * Detect Rest Time, Consecutive Nights, and Leave Conflicts
     */
    protected function detectMatrixConflicts(array $dateSlots, array $matrixRows): array
    {
        $conflicts = [];
        $dates = array_column($dateSlots, 'date');
        sort($dates);

        foreach ($matrixRows as $emp) {
            $consecutiveNights = 0;
            $prevDutyDay = null;
            $prevShift = null;

            foreach ($dates as $d) {
                $dayData = $emp['days'][$d] ?? null;
                if (!$dayData) continue;

                // 1. Leave Collision
                if (!empty($dayData['leave_title']) && $dayData['is_duty']) {
                    $conflicts[] = [
                        'employee_id' => $emp['id'],
                        'employee_name' => $emp['name'],
                        'date' => $d,
                        'type' => 'LEAVE_COLLISION',
                        'severity' => 'error',
                        'message' => "{$emp['name']} is assigned a duty shift on {$d} while on approved {$dayData['leave_title']}."
                    ];
                }

                if ($dayData['is_duty']) {
                    $curShift = $dayData['shift'];
                    $isNight = !empty($curShift['is_night_shift']);

                    // 2. Consecutive Night Shifts Limit (Warn after 3 in a row)
                    if ($isNight) {
                        $consecutiveNights++;
                        if ($consecutiveNights >= 4) {
                            $conflicts[] = [
                                'employee_id' => $emp['id'],
                                'employee_name' => $emp['name'],
                                'date' => $d,
                                'type' => 'CONSECUTIVE_NIGHTS',
                                'severity' => 'warning',
                                'message' => "{$emp['name']} has {$consecutiveNights} consecutive night shifts ending on {$d} without adequate rest interval."
                            ];
                        }
                    } else {
                        $consecutiveNights = 0;
                    }

                    // 3. Insufficient Rest Violation (< 8 hours between consecutive days)
                    if ($prevDutyDay && $prevShift) {
                        $prevDateTs = strtotime($prevDutyDay);
                        $curDateTs = strtotime($d);
                        if ($curDateTs - $prevDateTs === 86400) {
                            // Consecutive calendar days
                            $prevEndTimeStr = $prevShift['end_time'] ?? '18:00:00';
                            $curStartTimeStr = $curShift['start_time'] ?? '09:00:00';
                            
                            $prevEndTs = strtotime("$prevDutyDay $prevEndTimeStr");
                            if (!empty($prevShift['is_night_shift']) || strtotime("$prevDutyDay $prevEndTimeStr") < strtotime("$prevDutyDay {$prevShift['start_time']}")) {
                                $prevEndTs += 86400; // end time is next morning
                            }

                            $curStartTs = strtotime("$d $curStartTimeStr");
                            $restHours = ($curStartTs - $prevEndTs) / 3600;

                            if ($restHours < 8.0 && $restHours >= 0) {
                                $conflicts[] = [
                                    'employee_id' => $emp['id'],
                                    'employee_name' => $emp['name'],
                                    'date' => $d,
                                    'type' => 'INSUFFICIENT_REST',
                                    'severity' => 'warning',
                                    'message' => "Insufficient rest period (" . round($restHours, 1) . " hours) between {$prevDutyDay} and {$d} for {$emp['name']} (Minimum 8h required)."
                                ];
                            }
                        }
                    }

                    $prevDutyDay = $d;
                    $prevShift = $curShift;
                } else {
                    $consecutiveNights = 0;
                    $prevDutyDay = null;
                    $prevShift = null;
                }
            }
        }

        return $conflicts;
    }

    /**
     * Check if a specific date or period is locked by settled payroll (Rule P0-002 / Decision 3)
     */
    public function isPayrollSettled(string $companyId, string $date, ?string $employeeId = null): bool
    {
        $attModel = new \App\Models\AttendanceModel();
        if (!empty($employeeId)) {
            return $attModel->isAttendanceSettled($employeeId, $date, null, $companyId);
        }

        if ($this->db->tableExists('payroll_run_locks') && !empty($companyId)) {
            $month = substr($date, 0, 7);
            $builder = $this->db->table('payroll_run_locks')->where('company_id', $companyId);
            if ($this->db->fieldExists('payroll_month', 'payroll_run_locks')) {
                $builder->where('payroll_month', $month);
            } elseif ($this->db->fieldExists('period_month', 'payroll_run_locks')) {
                $builder->where('period_month', $month);
            }
            if ($this->db->fieldExists('status', 'payroll_run_locks')) {
                $builder->whereIn('status', ['LOCKED', 'SETTLED', 'FINALIZED']);
            }
            if ($builder->countAllResults() > 0) {
                return true;
            }
        }

        return false;
    }

    /**
     * Concurrency-safe, transactional update-or-insert for roster assignments.
     * Prevents duplicate employee+date records across concurrent requests.
     */
    public function upsertRosterAssignment(string $employeeId, ?string $shiftId, string $date, array $extra = []): array
    {
        if (!$this->db->tableExists('roster_assignments')) {
            return ['id' => null, 'action' => 'none'];
        }

        $now = date('Y-m-d H:i:s');
        $existing = $this->db->table('roster_assignments')
            ->where('employee_id', $employeeId)
            ->where('date', $date)
            ->get()
            ->getRowArray();

        $targetIsPublished = isset($extra['is_published']) ? (int)$extra['is_published'] : ($existing ? (int)$existing['is_published'] : 1);
        $targetIsDayOff = isset($extra['is_day_off']) ? (int)$extra['is_day_off'] : 0;

        if ($existing) {
            $wasPublished = !empty($existing['is_published']);

            $updatePayload = [
                'shift_id'     => $shiftId,
                'is_day_off'   => $targetIsDayOff,
                'is_published' => $targetIsPublished,
                'updated_at'   => $now,
            ];
            if (isset($extra['notes'])) {
                $updatePayload['notes'] = $extra['notes'];
            }
            if (isset($extra['is_weekend'])) {
                $updatePayload['is_weekend'] = (int)$extra['is_weekend'];
            }
            if (isset($extra['roster_id'])) {
                $updatePayload['roster_id'] = $extra['roster_id'];
            }

            $this->db->table('roster_assignments')
                ->where('id', $existing['id'])
                ->update($updatePayload);

            // Audit log if editing a published roster assignment
            if ($wasPublished) {
                $auditService = new AuditService();
                $auditService->log(
                    $extra['user_id'] ?? null,
                    'roster',
                    'assignment.published_edited',
                    $existing['id'],
                    [
                        'shift_id'     => $existing['shift_id'],
                        'is_day_off'   => (int)$existing['is_day_off'],
                        'is_published' => (int)$existing['is_published'],
                    ],
                    [
                        'shift_id'     => $shiftId,
                        'is_day_off'   => $targetIsDayOff,
                        'is_published' => $targetIsPublished,
                    ],
                    $extra['company_id'] ?? null,
                    null,
                    "Modified published roster assignment for employee {$employeeId} on {$date}" . (!empty($extra['reason']) ? " (Reason: {$extra['reason']})" : "")
                );
            }

            return ['id' => $existing['id'], 'action' => 'updated'];
        }

        $id = 'ra-' . bin2hex(random_bytes(6));
        $insertPayload = [
            'id'           => $id,
            'roster_id'    => $extra['roster_id'] ?? 'ros-custom',
            'employee_id'  => $employeeId,
            'shift_id'     => $shiftId,
            'date'         => $date,
            'is_weekend'   => isset($extra['is_weekend']) ? (int)$extra['is_weekend'] : 0,
            'is_day_off'   => $targetIsDayOff,
            'is_published' => $targetIsPublished,
            'notes'        => $extra['notes'] ?? null,
            'created_at'   => $now,
            'updated_at'   => $now,
        ];

        try {
            $this->db->table('roster_assignments')->insert($insertPayload);
            return ['id' => $id, 'action' => 'inserted'];
        } catch (\Throwable $e) {
            // Concurrent insert caught by DB unique constraint (uk_roster_emp_date)
            // Safely fallback to updating the existing record
            $concurrentExisting = $this->db->table('roster_assignments')
                ->where('employee_id', $employeeId)
                ->where('date', $date)
                ->get()
                ->getRowArray();

            if ($concurrentExisting) {
                $this->db->table('roster_assignments')
                    ->where('id', $concurrentExisting['id'])
                    ->update([
                        'shift_id'     => $shiftId,
                        'is_day_off'   => $targetIsDayOff,
                        'is_published' => $targetIsPublished,
                        'notes'        => $extra['notes'] ?? ($concurrentExisting['notes'] ?? null),
                        'updated_at'   => $now,
                    ]);
                return ['id' => $concurrentExisting['id'], 'action' => 'updated_concurrent'];
            }
            throw $e;
        }
    }

    /**
     * Instant Shift Assignment / Re-assignment for Employee
     */
    public function assignShiftToEmployee(string $employeeId, ?string $shiftId, ?string $date = null, ?string $performedByUserId = null, array $options = []): array
    {
        $employee = $this->empModel->find($employeeId);
        if (!$employee) {
            return ['success' => false, 'message' => 'Employee record not found.'];
        }

        $companyId = $options['company_id'] ?? ($employee['company_id'] ?? null);
        $isDayOff = !empty($options['is_day_off']);
        $isPublished = isset($options['is_published']) ? (int)$options['is_published'] : 1;

        if (!$isDayOff) {
            if (empty($shiftId)) {
                return ['success' => false, 'message' => 'Shift schedule definition ID is required.'];
            }
            $shift = $this->shiftModel->find($shiftId);
            if (!$shift) {
                return ['success' => false, 'message' => 'Shift schedule definition not found.'];
            }
            $shiftName = $shift['name'];
        } else {
            // Day off assignment
            $shiftId = $shiftId ?: ($employee['shift_id'] ?? null);
            $shiftName = 'Day Off';
        }

        $oldShiftId = $employee['shift_id'];

        if ($date) {
            // Guard: Payroll settlement lock
            if ($this->isPayrollSettled($companyId ?: '', $date, $employeeId)) {
                return [
                    'success' => false,
                    'message' => "Cannot assign or modify shift for employee {$employee['employee_code']} on {$date} as it is settled and locked in payroll."
                ];
            }

            // Specific Date Override via roster_assignments
            $this->upsertRosterAssignment($employeeId, $shiftId, $date, [
                'roster_id'    => $options['roster_id'] ?? 'ros-custom',
                'is_day_off'   => $isDayOff ? 1 : 0,
                'is_published' => $isPublished,
                'notes'        => $options['notes'] ?? null,
                'user_id'      => $performedByUserId,
                'company_id'   => $companyId,
                'reason'       => $options['reason'] ?? null,
            ]);

            $actionText = $isDayOff ? "Marked as Day Off" : "Assigned shift '{$shiftName}'";
            $message = "Schedule successfully updated: {$actionText} on {$date} (" . ($isPublished ? 'Published' : 'Draft') . ").";
        } else {
            // Update Base Master Shift - Permanent employee master shift assignment stays a separate operation
            $this->empModel->update($employeeId, [
                'shift_id' => $shiftId,
                'updated_at' => date('Y-m-d H:i:s')
            ]);
            $message = "Permanent master shift successfully assigned to '{$shiftName}'.";
        }

        // Audit Trail
        $auditService = new AuditService();
        $auditService->log(
            $performedByUserId,
            'roster',
            'shift.assigned',
            $employeeId,
            ['shift_id' => $oldShiftId],
            [
                'shift_id'     => $shiftId,
                'shift_name'   => $shiftName,
                'date'         => $date,
                'is_day_off'   => $isDayOff,
                'is_published' => $isPublished
            ],
            $companyId,
            null,
            "Assigned {$shiftName} to employee {$employee['first_name']} {$employee['last_name']}" . ($date ? " for date {$date}" : '') . (!empty($options['reason']) ? " (Reason: {$options['reason']})" : "")
        );

        return [
            'success' => true,
            'message' => $message
        ];
    }

    /**
     * Bulk Assign Shift to Multiple Employees Across Custom Date Range
     */
    public function bulkAssignShifts(array $employeeIds, ?string $shiftId, string $startDate, string $endDate, ?array $daysOfWeek = null, ?string $performedByUserId = null, array $options = []): array
    {
        $companyId = $options['company_id'] ?? null;
        $deptId = $options['department_id'] ?? null;
        $branchId = $options['branch_id'] ?? null;
        $isDayOff = !empty($options['is_day_off']);
        $isPublished = isset($options['is_published']) ? (int)$options['is_published'] : 1;

        // If employeeIds is empty, resolve employees by department / branch / company
        if (empty($employeeIds)) {
            $builder = $this->empModel->select('id, employee_code, first_name, last_name, shift_id, company_id')
                ->where('status', \App\Models\EmployeeModel::STATUS_ACTIVE);
            if (!empty($companyId)) {
                $builder->where('company_id', $companyId);
            }
            if (!empty($deptId) && $deptId !== 'all') {
                $builder->where('department_id', $deptId);
            }
            if (!empty($branchId) && $branchId !== 'all') {
                $builder->where('branch_id', $branchId);
            }
            $targetEmployees = $builder->findAll();
            $employeeIds = array_column($targetEmployees, 'id');
        } else {
            $targetEmployees = $this->empModel->whereIn('id', $employeeIds)->findAll();
        }

        if (empty($employeeIds)) {
            return ['success' => false, 'message' => 'No active employees found matching the assignment criteria.'];
        }

        $shiftName = 'Day Off';
        if (!$isDayOff) {
            if (empty($shiftId)) {
                return ['success' => false, 'message' => 'Target shift definition ID is required.'];
            }
            $shift = $this->shiftModel->find($shiftId);
            if (!$shift) {
                return ['success' => false, 'message' => 'Target shift definition not found.'];
            }
            $shiftName = $shift['name'];
        }

        $allWeekDays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        $activeDays = $daysOfWeek ?: $allWeekDays;

        $curr = strtotime($startDate);
        $endTs = strtotime($endDate);

        // Pre-validate payroll settlement across the entire range
        $currCheck = $curr;
        while ($currCheck <= $endTs) {
            $curDate = date('Y-m-d', $currCheck);
            $dayName = RuleEngineService::DAYS_OF_WEEK[(int)date('w', $currCheck)] ?? 'Sunday';
            if (in_array($dayName, $activeDays)) {
                foreach ($targetEmployees as $emp) {
                    if ($this->isPayrollSettled($companyId ?: ($emp['company_id'] ?? ''), $curDate, $emp['id'])) {
                        return [
                            'success' => false,
                            'message' => "Cannot perform bulk assignment: Employee {$emp['employee_code']} ({$emp['first_name']}) has settled payroll on {$curDate}."
                        ];
                    }
                }
            }
            $currCheck = strtotime('+1 day', $currCheck);
        }

        $totalInserted = 0;
        $this->db->transStart();

        try {
            while ($curr <= $endTs) {
                $curDate = date('Y-m-d', $curr);
                $dayName = RuleEngineService::DAYS_OF_WEEK[(int)date('w', $curr)] ?? 'Sunday';

                if (in_array($dayName, $activeDays)) {
                    foreach ($targetEmployees as $emp) {
                        $empId = $emp['id'];
                        $finalShiftId = $shiftId ?: ($emp['shift_id'] ?? null);
                        $this->upsertRosterAssignment($empId, $finalShiftId, $curDate, [
                            'roster_id'    => $options['roster_id'] ?? 'ros-bulk',
                            'is_weekend'   => 0,
                            'is_day_off'   => $isDayOff ? 1 : 0,
                            'is_published' => $isPublished,
                            'notes'        => $options['notes'] ?? null,
                            'user_id'      => $performedByUserId,
                            'company_id'   => $companyId,
                            'reason'       => $options['reason'] ?? 'Bulk roster assignment'
                        ]);
                        $totalInserted++;
                    }
                }
                $curr = strtotime('+1 day', $curr);
            }

            $this->db->transComplete();

            if ($this->db->transStatus() === false) {
                return ['success' => false, 'message' => 'Bulk shift assignment transaction failed and was rolled back.'];
            }
        } catch (\Throwable $e) {
            $this->db->transRollback();
            return ['success' => false, 'message' => 'Bulk shift assignment transaction aborted: ' . $e->getMessage()];
        }

        // Audit Trail
        $auditService = new AuditService();
        $auditService->log(
            $performedByUserId,
            'roster',
            'shifts.bulk_assigned',
            null,
            null,
            [
                'shift_id'     => $shiftId,
                'count'        => count($employeeIds),
                'start_date'   => $startDate,
                'end_date'     => $endDate,
                'is_day_off'   => $isDayOff,
                'is_published' => $isPublished,
                'company_id'   => $companyId,
                'department_id'=> $deptId,
                'branch_id'    => $branchId,
            ],
            $companyId,
            null,
            "Bulk assigned '{$shiftName}' to " . count($employeeIds) . " staff members from {$startDate} to {$endDate} (" . ($isPublished ? 'Published' : 'Draft') . ")."
        );

        $statusStr = $isPublished ? 'Published' : 'Draft';
        return [
            'success'     => true,
            'message'     => "Bulk assignment '{$shiftName}' successfully applied across {$totalInserted} schedule slots as {$statusStr}.",
            'total_slots' => $totalInserted
        ];
    }

    /**
     * Copy schedule allocations from a source week into a target week (saved as Draft)
     */
    public function copyPreviousWeekRoster(string $companyId, string $sourceWeekStart, string $targetWeekStart, array $employeeIds = [], ?string $departmentId = null, ?string $branchId = null, ?string $performedByUserId = null): array
    {
        $sourceStartTs = strtotime($sourceWeekStart);
        $targetStartTs = strtotime($targetWeekStart);

        if (!$sourceStartTs || !$targetStartTs) {
            return ['success' => false, 'message' => 'Invalid source or target week start date specified.'];
        }

        $sourceEndDate = date('Y-m-d', strtotime('+6 days', $sourceStartTs));
        $targetEndDate = date('Y-m-d', strtotime('+6 days', $targetStartTs));

        // Fetch employees
        $empBuilder = $this->empModel->select('id, employee_code, first_name, last_name, shift_id, company_id')
            ->where('status', \App\Models\EmployeeModel::STATUS_ACTIVE);
        if (!empty($companyId)) {
            $empBuilder->where('company_id', $companyId);
        }
        if (!empty($departmentId) && $departmentId !== 'all') {
            $empBuilder->where('department_id', $departmentId);
        }
        if (!empty($branchId) && $branchId !== 'all') {
            $empBuilder->where('branch_id', $branchId);
        }
        if (!empty($employeeIds)) {
            $empBuilder->whereIn('id', $employeeIds);
        }

        $employees = $empBuilder->findAll();
        if (empty($employees)) {
            return ['success' => false, 'message' => 'No active employees found to copy schedules for.'];
        }

        // Fetch existing source assignments
        $empIdList = array_column($employees, 'id');
        $sourceAssignments = [];
        if ($this->db->tableExists('roster_assignments') && !empty($empIdList)) {
            $rows = $this->db->table('roster_assignments')
                ->whereIn('employee_id', $empIdList)
                ->where('date >=', $sourceWeekStart)
                ->where('date <=', $sourceEndDate)
                ->get()
                ->getResultArray();
            foreach ($rows as $r) {
                $sourceAssignments[$r['employee_id']][$r['date']] = $r;
            }
        }

        // Check target dates for settled payroll
        for ($i = 0; $i < 7; $i++) {
            $targetDate = date('Y-m-d', strtotime("+{$i} days", $targetStartTs));
            foreach ($employees as $emp) {
                if ($this->isPayrollSettled($companyId, $targetDate, $emp['id'])) {
                    return [
                        'success' => false,
                        'message' => "Cannot copy roster: Employee {$emp['employee_code']} has settled payroll on {$targetDate}."
                    ];
                }
            }
        }

        $copiedCount = 0;
        $this->db->transStart();

        try {
            for ($i = 0; $i < 7; $i++) {
                $srcDate = date('Y-m-d', strtotime("+{$i} days", $sourceStartTs));
                $tgtDate = date('Y-m-d', strtotime("+{$i} days", $targetStartTs));

                foreach ($employees as $emp) {
                    $empId = $emp['id'];
                    $srcAss = $sourceAssignments[$empId][$srcDate] ?? null;

                    if ($srcAss) {
                        $shiftId = $srcAss['shift_id'] ?? ($emp['shift_id'] ?? null);
                        $isDayOff = (int)($srcAss['is_day_off'] ?? 0);
                        $isWeekend = (int)($srcAss['is_weekend'] ?? 0);
                        $notes = $srcAss['notes'] ?? null;
                    } else {
                        // Resolve default shift for source day
                        $resolved = $this->shiftModel->resolveEffectiveShift($empId, $srcDate, $emp);
                        $shiftId = $resolved['shift_id'] ?? ($emp['shift_id'] ?? null);
                        $isDayOff = !empty($resolved['is_day_off']) ? 1 : 0;
                        $isWeekend = ($resolved['outcome'] ?? '') === 'WEEKLY_OFF' ? 1 : 0;
                        $notes = 'Copied from regular schedule';
                    }

                    if ($shiftId !== null || $isDayOff === 1) {
                        // Always copy into target as Draft (is_published = 0) so manager reviews before publishing!
                        $this->upsertRosterAssignment($empId, $shiftId, $tgtDate, [
                            'roster_id'    => 'ros-copy',
                            'is_day_off'   => $isDayOff,
                            'is_weekend'   => $isWeekend,
                            'is_published' => 0, // DRAFT
                            'notes'        => $notes,
                            'user_id'      => $performedByUserId,
                            'company_id'   => $companyId,
                            'reason'       => "Copied from week {$sourceWeekStart}"
                        ]);
                        $copiedCount++;
                    }
                }
            }

            $this->db->transComplete();

            if ($this->db->transStatus() === false) {
                return ['success' => false, 'message' => 'Copying roster failed and was rolled back.'];
            }
        } catch (\Throwable $e) {
            $this->db->transRollback();
            return ['success' => false, 'message' => 'Copying roster transaction aborted: ' . $e->getMessage()];
        }

        // Audit Trail
        $auditService = new AuditService();
        $auditService->log(
            $performedByUserId,
            'roster',
            'roster.copied_week',
            null,
            null,
            [
                'source_week_start' => $sourceWeekStart,
                'target_week_start' => $targetWeekStart,
                'slots_copied'      => $copiedCount,
                'employee_count'    => count($employees),
                'company_id'        => $companyId
            ],
            $companyId,
            null,
            "Copied roster schedule from week {$sourceWeekStart} into week {$targetWeekStart} as Draft ({$copiedCount} slots)."
        );

        return [
            'success'      => true,
            'message'      => "Successfully copied schedule from {$sourceWeekStart} into {$targetWeekStart} ({$copiedCount} slots saved as Draft).",
            'copied_count' => $copiedCount
        ];
    }

    /**
     * Publish draft roster assignments across a date range for a tenant
     */
    public function publishRosterRange(string $companyId, string $startDate, string $endDate, ?string $departmentId = null, ?string $branchId = null, ?string $performedByUserId = null, ?string $name = null): array
    {
        if (empty($companyId) || empty($startDate) || empty($endDate)) {
            return ['success' => false, 'message' => 'Company ID, start date, and end date are required to publish roster.'];
        }

        // Fetch scoped employee IDs
        $empBuilder = $this->empModel->select('id')->where('company_id', $companyId);
        if (!empty($departmentId) && $departmentId !== 'all') {
            $empBuilder->where('department_id', $departmentId);
        }
        if (!empty($branchId) && $branchId !== 'all') {
            $empBuilder->where('branch_id', $branchId);
        }
        $empList = array_column($empBuilder->findAll(), 'id');

        if (empty($empList)) {
            return ['success' => false, 'message' => 'No employees found in the specified scope.'];
        }

        // Update roster_assignments from Draft to Published
        $this->db->transStart();

        $updateBuilder = $this->db->table('roster_assignments')
            ->whereIn('employee_id', $empList)
            ->where('date >=', $startDate)
            ->where('date <=', $endDate);

        $now = date('Y-m-d H:i:s');
        $rosterName = $name ?: 'Roster Cycle ' . date('d M', strtotime($startDate)) . ' - ' . date('d M Y', strtotime($endDate));
        $rosterId = 'ros-' . bin2hex(random_bytes(6));

        // Create published roster tracking header
        $this->rosterModel->insert([
            'id'            => $rosterId,
            'company_id'    => $companyId,
            'branch_id'     => (!empty($branchId) && $branchId !== 'all') ? $branchId : null,
            'department_id' => (!empty($departmentId) && $departmentId !== 'all') ? $departmentId : null,
            'name'          => $rosterName,
            'start_date'    => $startDate,
            'end_date'      => $endDate,
            'roster_type'   => 'Weekly',
            'status'        => 'published',
            'published_by'  => $performedByUserId,
            'published_at'  => $now,
            'created_at'    => $now,
            'updated_at'    => $now
        ]);

        $updateBuilder->update([
            'is_published' => 1,
            'roster_id'    => $rosterId,
            'updated_at'   => $now
        ]);

        $affectedCount = $this->db->affectedRows();
        $this->db->transComplete();

        if ($this->db->transStatus() === false) {
            return ['success' => false, 'message' => 'Publishing roster failed and was rolled back.'];
        }

        // Audit Trail
        $auditService = new AuditService();
        $auditService->log(
            $performedByUserId,
            'roster',
            'roster.published',
            $rosterId,
            null,
            [
                'roster_id'   => $rosterId,
                'name'        => $rosterName,
                'start_date'  => $startDate,
                'end_date'    => $endDate,
                'company_id'  => $companyId,
                'slots_count' => $affectedCount
            ],
            $companyId,
            null,
            "Published roster '{$rosterName}' for period {$startDate} to {$endDate} ({$affectedCount} slots made effective)."
        );

        return [
            'success'         => true,
            'message'         => "Roster '{$rosterName}' published successfully. {$affectedCount} schedule slots are now active and effective for attendance.",
            'published_count' => $affectedCount,
            'roster_id'       => $rosterId
        ];
    }

    /**
     * Check conflicts across employees and date range
     */
    public function checkRosterConflicts(string $companyId, array $employeeIds, string $startDate, string $endDate): array
    {
        $matrixData = $this->buildMatrixForDateRange($startDate, $endDate, $this->getWeeklyRosterMatrix($startDate, null, null, null, null, $companyId)['week_dates'], null, null, null, null, $companyId);
        return $matrixData['conflicts'] ?? [];
    }

    /**
     * Retrieve Assignment History & Revisions from audit_logs
     */
    public function getAssignmentHistory(string $companyId, ?string $employeeId = null, ?string $startDate = null, ?string $endDate = null, int $limit = 50): array
    {
        if (!$this->db->tableExists('audit_logs')) {
            return [];
        }

        $builder = $this->db->table('audit_logs')
            ->select('audit_logs.*, users.email as actor_email, users.username as actor_name')
            ->join('users', 'users.id = audit_logs.user_id', 'left')
            ->where('audit_logs.module', 'roster')
            ->orderBy('audit_logs.created_at', 'DESC')
            ->limit($limit);

        if (!empty($companyId)) {
            $builder->where('audit_logs.company_id', $companyId);
        }
        if (!empty($employeeId)) {
            $builder->where('audit_logs.target_id', $employeeId);
        }
        if (!empty($startDate)) {
            $builder->where('audit_logs.created_at >=', $startDate . ' 00:00:00');
        }
        if (!empty($endDate)) {
            $builder->where('audit_logs.created_at <=', $endDate . ' 23:59:59');
        }

        $logs = $builder->get()->getResultArray();
        $history = [];

        foreach ($logs as $log) {
            $oldVals = !empty($log['old_values']) ? json_decode($log['old_values'], true) : [];
            $newVals = !empty($log['new_values']) ? json_decode($log['new_values'], true) : [];

            $history[] = [
                'id'           => $log['id'],
                'action'       => $log['action'],
                'actor'        => $log['actor_name'] ?: ($log['actor_email'] ?: 'System / Admin'),
                'target_id'    => $log['target_id'],
                'old_values'   => $oldVals,
                'new_values'   => $newVals,
                'details'      => $log['details'] ?: $log['action'],
                'created_at'   => $log['created_at']
            ];
        }

        return $history;
    }

    /**
     * Auto-Assign Shifts & Rotation Engine (Phase 8)
     * 
     * Separates two distinct modes:
     * 1. 'master'   - Permanent master shift assignment (existing behaviour, kept separate).
     * 2. 'calendar' - Calendar roster generation: creates date-specific DRAFT roster_assignments for selected period.
     * 
     * Supported algorithms:
     * - 'rotate': Balanced rotation (even distribution across active shifts)
     * - 'standard': Standardize day shift across all staff
     * - 'department': Departmental heuristic split
     * - 'night_rotation': 30% Night, 40% Day, 30% Morning
     * - 'weekly_rotation': Rotates shift cycle every 7 days across the period
     * - 'monthly_rotation': Rotates shift cycle every calendar month across the period
     * - 'daily_rotation': Rotates shift cycle every calendar day across the period
     */
    public function autoAssignShifts(string $strategy = 'rotate', ?string $departmentId = null, ?string $branchId = null, ?string $companyId = null, ?string $performedByUserId = null, array $options = []): array
    {
        $mode = strtolower(trim((string)($options['mode'] ?? '')));

        // Mode 1: Permanent master shift assignment
        if ($mode === 'master' || $mode === 'permanent' || $mode === 'permanent_master') {
            return $this->autoAssignMasterShifts($strategy, $departmentId, $branchId, $companyId, $performedByUserId, $options);
        }

        // Backward compatibility: If no options are provided and mode was not set, run master assignment
        if (empty($options) && empty($mode)) {
            return $this->autoAssignMasterShifts($strategy, $departmentId, $branchId, $companyId, $performedByUserId, $options);
        }

        // Mode 2: Calendar roster generation (Default for scheduling)
        $startDate = $options['start_date'] ?? date('Y-m-d');
        $endDate = $options['end_date'] ?? date('Y-m-d', strtotime('+6 days'));

        return $this->generateCalendarRoster(
            $strategy,
            $startDate,
            $endDate,
            $departmentId,
            $branchId,
            $companyId,
            $performedByUserId,
            $options
        );
    }

    /**
     * Mode 1: Permanent master shift assignment (updates employees.shift_id on master employee records)
     */
    public function autoAssignMasterShifts(string $strategy = 'rotate', ?string $departmentId = null, ?string $branchId = null, ?string $companyId = null, ?string $performedByUserId = null, array $options = []): array
    {
        $shifts = $this->shiftModel->getActiveShifts($companyId);
        if (empty($shifts)) {
            return ['success' => false, 'message' => 'No active shift schedules available in the system.'];
        }

        $empBuilder = $this->empModel->where('status', \App\Models\EmployeeModel::STATUS_ACTIVE);
        if ($companyId) $empBuilder->where('company_id', $companyId);
        if ($departmentId && $departmentId !== 'all') $empBuilder->where('department_id', $departmentId);
        if ($branchId && $branchId !== 'all') $empBuilder->where('branch_id', $branchId);
        if (!empty($options['employee_ids']) && is_array($options['employee_ids'])) {
            $empBuilder->whereIn('id', $options['employee_ids']);
        }

        $employees = $empBuilder->orderBy('id', 'ASC')->findAll();
        if (empty($employees)) {
            return ['success' => false, 'message' => 'No active employees found matching the filter criteria.'];
        }

        $classifiedShifts = $this->classifyShiftsForRotation($shifts);
        $dayShift = $classifiedShifts['day'];
        $morningShift = $classifiedShifts['morning'];
        $nightShift = $classifiedShifts['night'];

        $reassignedCount = 0;
        $distribution = [];

        foreach ($employees as $index => $emp) {
            $targetShiftId = $this->determineTargetShiftForAlgorithm(
                $strategy,
                $index,
                0,
                $emp,
                $shifts,
                $dayShift,
                $morningShift,
                $nightShift
            );

            if ($targetShiftId !== $emp['shift_id']) {
                $this->empModel->update($emp['id'], [
                    'shift_id'   => $targetShiftId,
                    'updated_at' => date('Y-m-d H:i:s'),
                ]);
                $reassignedCount++;
            }

            $distribution[$targetShiftId] = ($distribution[$targetShiftId] ?? 0) + 1;
        }

        // Audit Trail
        $strategyLabel = $this->getStrategyLabel($strategy);
        $auditService = new AuditService();
        $auditService->log(
            $performedByUserId,
            'roster',
            'shifts.auto_assigned_master',
            null,
            null,
            ['strategy' => $strategy, 'reassigned_count' => $reassignedCount, 'distribution' => $distribution, 'mode' => 'master'],
            $companyId,
            null,
            "Permanent master shifts auto-assigned to " . count($employees) . " employees using '{$strategyLabel}' strategy."
        );

        return [
            'success'          => true,
            'mode'             => 'master',
            'strategy'         => $strategy,
            'strategy_label'   => $strategyLabel,
            'reassigned_count' => $reassignedCount,
            'distribution'     => $distribution,
            'message'          => "Permanent master shifts updated for {$reassignedCount} employees using '{$strategyLabel}' strategy."
        ];
    }

    /**
     * Mode 2: Calendar roster generation (creates date-specific DRAFT roster_assignments for selected period)
     * 
     * Business rules:
     * - Generated output MUST be DRAFT (is_published = 0).
     * - Admin reviews, then publishes.
     * - NEVER overwrite or destroy existing published assignments (is_published = 1).
     * - Preserves published assignments and reports PUBLISHED_CONFLICT.
     * - Respects settled payroll dates and reports SETTLED_PAYROLL.
     * - Concurrency-safe against unique key collision (uk_roster_emp_date).
     */
    public function generateCalendarRoster(
        string $strategy = 'rotate',
        string $startDate = '',
        string $endDate = '',
        ?string $departmentId = null,
        ?string $branchId = null,
        ?string $companyId = null,
        ?string $performedByUserId = null,
        array $options = []
    ): array {
        $startDate = $startDate ?: ($options['start_date'] ?? date('Y-m-d'));
        $endDate = $endDate ?: ($options['end_date'] ?? date('Y-m-d', strtotime('+6 days')));

        if (empty($startDate) || empty($endDate) || strtotime($startDate) > strtotime($endDate)) {
            return ['success' => false, 'message' => 'A valid date range is required for calendar roster generation (start date must be on or before end date).'];
        }

        $shifts = $this->shiftModel->getActiveShifts($companyId);
        if (empty($shifts)) {
            return ['success' => false, 'message' => 'No active shift schedules available in the system.'];
        }

        $shiftsMap = [];
        foreach ($shifts as $s) {
            $shiftsMap[$s['id']] = $s;
        }

        $classifiedShifts = $this->classifyShiftsForRotation($shifts);
        $dayShift = $classifiedShifts['day'];
        $morningShift = $classifiedShifts['morning'];
        $nightShift = $classifiedShifts['night'];

        $empBuilder = $this->empModel->where('status', \App\Models\EmployeeModel::STATUS_ACTIVE);
        if ($companyId) $empBuilder->where('company_id', $companyId);
        if ($departmentId && $departmentId !== 'all') $empBuilder->where('department_id', $departmentId);
        if ($branchId && $branchId !== 'all') $empBuilder->where('branch_id', $branchId);
        if (!empty($options['employee_ids']) && is_array($options['employee_ids'])) {
            $empBuilder->whereIn('id', $options['employee_ids']);
        }

        $employees = $empBuilder->orderBy('id', 'ASC')->findAll();
        if (empty($employees)) {
            return ['success' => false, 'message' => 'No active employees found matching the filter criteria.'];
        }

        $periodDates = [];
        $currTs = strtotime($startDate);
        $endTs = strtotime($endDate);
        while ($currTs <= $endTs) {
            $periodDates[] = date('Y-m-d', $currTs);
            $currTs += 86400;
        }

        $weekendService = new \App\Services\CompanyWeekendService();
        $assignDayOffOnWeekend = !empty($options['assign_day_off_on_weekend']);

        // Pre-fetch existing assignments for targeted employees across period
        $existingAssignments = [];
        if ($this->db->tableExists('roster_assignments')) {
            $existingRows = $this->db->table('roster_assignments')
                ->whereIn('employee_id', array_column($employees, 'id'))
                ->where('date >=', $startDate)
                ->where('date <=', $endDate)
                ->get()
                ->getResultArray();
            foreach ($existingRows as $row) {
                $existingAssignments[$row['employee_id'] . '_' . $row['date']] = $row;
            }
        }

        // Pre-fetch approved leaves in period
        $approvedLeaves = [];
        if ($this->db->tableExists('leave_applications')) {
            $leaves = $this->db->table('leave_applications')
                ->whereIn('employee_id', array_column($employees, 'id'))
                ->where('status', 'Approved')
                ->where('start_date <=', $endDate)
                ->where('end_date >=', $startDate)
                ->get()
                ->getResultArray();
            foreach ($leaves as $lv) {
                $lvStart = max(strtotime($startDate), strtotime($lv['start_date']));
                $lvEnd = min(strtotime($endDate), strtotime($lv['end_date']));
                for ($t = $lvStart; $t <= $lvEnd; $t += 86400) {
                    $approvedLeaves[$lv['employee_id'] . '_' . date('Y-m-d', $t)] = $lv;
                }
            }
        }

        // Pre-fetch company holidays in period
        $companyHolidays = [];
        if ($this->db->tableExists('holidays')) {
            $holidays = $this->db->table('holidays')
                ->where('company_id', $companyId)
                ->where('holiday_date >=', $startDate)
                ->where('holiday_date <=', $endDate)
                ->get()
                ->getResultArray();
            foreach ($holidays as $h) {
                $companyHolidays[$h['holiday_date']] = $h['name'] ?? 'Holiday';
            }
        }

        $strategyLabel = $this->getStrategyLabel($strategy);
        $rosterName = $options['roster_name'] ?? ('Draft ' . $strategyLabel . ' (' . date('d M', strtotime($startDate)) . ' - ' . date('d M Y', strtotime($endDate)) . ')');
        $rosterId = 'ros-draft-' . bin2hex(random_bytes(6));
        $now = date('Y-m-d H:i:s');

        // Create draft header in rosters table if exists
        if ($this->db->tableExists('rosters')) {
            $this->rosterModel->insert([
                'id'            => $rosterId,
                'company_id'    => $companyId,
                'branch_id'     => (!empty($branchId) && $branchId !== 'all') ? $branchId : null,
                'department_id' => (!empty($departmentId) && $departmentId !== 'all') ? $departmentId : null,
                'name'          => $rosterName,
                'start_date'    => $startDate,
                'end_date'      => $endDate,
                'roster_type'   => count($periodDates) > 14 ? 'Monthly' : 'Weekly',
                'status'        => 'draft',
                'created_at'    => $now,
                'updated_at'    => $now
            ]);
        }

        $createdCount = 0;
        $updatedDraftCount = 0;
        $skippedPublishedCount = 0;
        $skippedSettledCount = 0;
        $conflicts = [];
        $distribution = [];

        foreach ($employees as $empIndex => $emp) {
            $empName = trim($emp['first_name'] . ' ' . ($emp['last_name'] ?? ''));
            $empCode = $emp['employee_code'] ?? '';

            foreach ($periodDates as $dayIndex => $dateStr) {
                $key = $emp['id'] . '_' . $dateStr;
                $existing = $existingAssignments[$key] ?? null;

                // 1. Settled Payroll Protection: never mutate settled/locked payroll records
                if ($this->isPayrollSettled($companyId, $dateStr, $emp['id'])) {
                    $skippedSettledCount++;
                    $conflicts[] = [
                        'employee_id'   => $emp['id'],
                        'employee_name' => $empName,
                        'employee_code' => $empCode,
                        'date'          => $dateStr,
                        'type'          => 'SETTLED_PAYROLL',
                        'severity'      => 'locked',
                        'message'       => "Date {$dateStr} is locked in settled payroll. Slot preserved without modification."
                    ];
                    continue;
                }

                $isWeekend = $weekendService->isCompanyWeekend($dateStr, $companyId) ? 1 : 0;
                $isDayOff = ($assignDayOffOnWeekend && $isWeekend) ? 1 : 0;

                // Determine target shift for the algorithm
                $targetShiftId = $this->determineTargetShiftForAlgorithm(
                    $strategy,
                    $empIndex,
                    $dayIndex,
                    $emp,
                    $shifts,
                    $dayShift,
                    $morningShift,
                    $nightShift,
                    $startDate,
                    $dateStr
                );

                $targetShiftName = $shiftsMap[$targetShiftId]['name'] ?? 'Scheduled Shift';

                // 2. CRITICAL: Never overwrite or destroy existing PUBLISHED assignments
                if ($existing && !empty($existing['is_published'])) {
                    $skippedPublishedCount++;
                    $existingShiftName = $shiftsMap[$existing['shift_id']]['name'] ?? (!empty($existing['is_day_off']) ? 'Scheduled Day Off' : 'Published Shift');

                    $conflicts[] = [
                        'employee_id'        => $emp['id'],
                        'employee_name'      => $empName,
                        'employee_code'      => $empCode,
                        'date'               => $dateStr,
                        'type'               => 'PUBLISHED_CONFLICT',
                        'severity'           => 'conflict',
                        'current_shift_id'   => $existing['shift_id'],
                        'current_shift_name' => $existingShiftName,
                        'proposed_shift_id'  => $targetShiftId,
                        'proposed_shift_name'=> $targetShiftName,
                        'message'            => "Published assignment ({$existingShiftName}) already exists on {$dateStr} for {$empName} and was preserved untouched."
                    ];
                    // DO NOT TOUCH PUBLISHED ASSIGNMENTS
                    continue;
                }

                // 3. Informational conflict / warning checks
                if (isset($approvedLeaves[$key])) {
                    $conflicts[] = [
                        'employee_id'   => $emp['id'],
                        'employee_name' => $empName,
                        'employee_code' => $empCode,
                        'date'          => $dateStr,
                        'type'          => 'LEAVE_COLLISION',
                        'severity'      => 'warning',
                        'message'       => "Employee {$empName} has approved leave on {$dateStr}."
                    ];
                }
                if (isset($companyHolidays[$dateStr])) {
                    $conflicts[] = [
                        'employee_id'   => $emp['id'],
                        'employee_name' => $empName,
                        'employee_code' => $empCode,
                        'date'          => $dateStr,
                        'type'          => 'HOLIDAY_DUTY',
                        'severity'      => 'info',
                        'message'       => "Assigned draft duty falls on official holiday ({$companyHolidays[$dateStr]}) on {$dateStr}."
                    ];
                }

                // 4. Update existing DRAFT or Insert new DRAFT
                if ($existing && empty($existing['is_published'])) {
                    $this->db->table('roster_assignments')
                        ->where('id', $existing['id'])
                        ->update([
                            'shift_id'     => $targetShiftId,
                            'roster_id'    => $rosterId,
                            'is_weekend'   => $isWeekend,
                            'is_day_off'   => $isDayOff,
                            'is_published' => 0, // DRAFT!
                            'notes'        => "Auto-assigned draft ({$strategyLabel})",
                            'updated_at'   => $now,
                        ]);
                    $updatedDraftCount++;
                    $distribution[$targetShiftId] = ($distribution[$targetShiftId] ?? 0) + 1;
                } else {
                    $assignId = 'ra-' . bin2hex(random_bytes(6));
                    $insertData = [
                        'id'           => $assignId,
                        'roster_id'    => $rosterId,
                        'employee_id'  => $emp['id'],
                        'shift_id'     => $targetShiftId,
                        'date'         => $dateStr,
                        'is_weekend'   => $isWeekend,
                        'is_day_off'   => $isDayOff,
                        'is_published' => 0, // DRAFT!
                        'notes'        => "Auto-assigned draft ({$strategyLabel})",
                        'created_at'   => $now,
                        'updated_at'   => $now,
                    ];

                    try {
                        $this->db->table('roster_assignments')->insert($insertData);
                        $createdCount++;
                        $distribution[$targetShiftId] = ($distribution[$targetShiftId] ?? 0) + 1;
                    } catch (\Throwable $e) {
                        // Concurrency collision handler:
                        $concurrentRow = $this->db->table('roster_assignments')
                            ->where('employee_id', $emp['id'])
                            ->where('date', $dateStr)
                            ->get()
                            ->getRowArray();

                        if ($concurrentRow) {
                            if (!empty($concurrentRow['is_published'])) {
                                // Concurrent published assignment detected: NEVER overwrite published!
                                $skippedPublishedCount++;
                                $conflicts[] = [
                                    'employee_id'        => $emp['id'],
                                    'employee_name'      => $empName,
                                    'employee_code'      => $empCode,
                                    'date'               => $dateStr,
                                    'type'               => 'PUBLISHED_CONFLICT',
                                    'severity'           => 'conflict',
                                    'current_shift_id'   => $concurrentRow['shift_id'],
                                    'current_shift_name' => $shiftsMap[$concurrentRow['shift_id']]['name'] ?? 'Published Shift',
                                    'proposed_shift_id'  => $targetShiftId,
                                    'proposed_shift_name'=> $targetShiftName,
                                    'message'            => "Concurrent published assignment detected on {$dateStr} and preserved untouched."
                                ];
                            } else {
                                // Concurrent draft: safe to update
                                $this->db->table('roster_assignments')
                                    ->where('id', $concurrentRow['id'])
                                    ->update([
                                        'shift_id'     => $targetShiftId,
                                        'roster_id'    => $rosterId,
                                        'is_published' => 0,
                                        'notes'        => "Auto-assigned draft ({$strategyLabel})",
                                        'updated_at'   => $now,
                                    ]);
                                $updatedDraftCount++;
                                $distribution[$targetShiftId] = ($distribution[$targetShiftId] ?? 0) + 1;
                            }
                        }
                    }
                }
            }
        }

        // Audit Trail
        $auditService = new AuditService();
        $auditService->log(
            $performedByUserId,
            'roster',
            'roster.auto_assigned_draft',
            $rosterId,
            null,
            [
                'roster_id'               => $rosterId,
                'name'                    => $rosterName,
                'strategy'                => $strategy,
                'start_date'              => $startDate,
                'end_date'                => $endDate,
                'created_count'           => $createdCount,
                'updated_draft_count'     => $updatedDraftCount,
                'skipped_published_count' => $skippedPublishedCount,
                'skipped_settled_count'   => $skippedSettledCount,
                'conflicts_count'         => count($conflicts),
                'distribution'            => $distribution,
                'mode'                    => 'calendar'
            ],
            $companyId,
            null,
            "Generated DRAFT roster '{$rosterName}' for " . count($employees) . " employees ({$createdCount} created, {$updatedDraftCount} updated drafts, {$skippedPublishedCount} published untouched, " . count($conflicts) . " conflicts)."
        );

        $totalDraftSlots = $createdCount + $updatedDraftCount;
        $conflictText = count($conflicts) > 0 ? " (" . count($conflicts) . " conflicts reported, {$skippedPublishedCount} published slots preserved)" : "";

        return [
            'success'                 => true,
            'mode'                    => 'calendar',
            'strategy'                => $strategy,
            'strategy_label'          => $strategyLabel,
            'roster_id'               => $rosterId,
            'roster_name'             => $rosterName,
            'start_date'              => $startDate,
            'end_date'                => $endDate,
            'total_employees'         => count($employees),
            'created_count'           => $createdCount,
            'updated_draft_count'     => $updatedDraftCount,
            'skipped_published_count' => $skippedPublishedCount,
            'skipped_settled_count'   => $skippedSettledCount,
            'total_draft_slots'       => $totalDraftSlots,
            'conflicts_count'         => count($conflicts),
            'conflicts'               => $conflicts,
            'distribution'            => $distribution,
            'message'                 => "Draft roster generated for " . count($employees) . " employees from {$startDate} to {$endDate} ({$totalDraftSlots} draft slots ready for review{$conflictText})."
        ];
    }

    /**
     * Classify active shifts into Day, Morning, and Night categories
     */
    public function classifyShiftsForRotation(array $shifts): array
    {
        $dayShift = null;
        $morningShift = null;
        $nightShift = null;

        foreach ($shifts as $s) {
            $name = strtolower($s['name'] ?? '');
            $code = strtoupper($s['code'] ?? '');
            $isNight = !empty($s['night_shift']) || !empty($s['is_night_shift']) || str_contains($name, 'night') || (strtotime($s['end_time'] ?? '') < strtotime($s['start_time'] ?? ''));
            if ($isNight && $nightShift === null) {
                $nightShift = $s;
            } elseif ((str_contains($name, 'morning') || str_contains($name, 'early') || str_contains($code, 'MORN')) && $morningShift === null) {
                $morningShift = $s;
            } elseif ((str_contains($name, 'day') || str_contains($name, 'gen') || str_contains($name, 'regular') || str_contains($code, 'DAY') || str_contains($code, 'GEN')) && $dayShift === null) {
                $dayShift = $s;
            }
        }

        $dayShift = $dayShift ?? $shifts[0];
        $morningShift = $morningShift ?? ($shifts[1] ?? $shifts[0]);
        $nightShift = $nightShift ?? ($shifts[2] ?? $shifts[count($shifts) - 1]);

        return [
            'day'     => $dayShift,
            'morning' => $morningShift,
            'night'   => $nightShift
        ];
    }

    /**
     * Determine target shift ID based on selected rotation algorithm
     */
    public function determineTargetShiftForAlgorithm(
        string $strategy,
        int $empIndex,
        int $dayIndex,
        array $emp,
        array $shifts,
        array $dayShift,
        array $morningShift,
        array $nightShift,
        string $startDate = '',
        string $currentDate = ''
    ): string {
        $shiftCount = count($shifts);
        if ($shiftCount === 0) {
            return $emp['shift_id'] ?? '';
        }

        if ($strategy === 'rotate') {
            // Balanced rotation across the workforce
            $shiftIndex = $empIndex % $shiftCount;
            return $shifts[$shiftIndex]['id'];
        }

        if ($strategy === 'standard') {
            // Standardize General Day Shift
            return $dayShift['id'];
        }

        if ($strategy === 'department') {
            // Departmental split heuristic
            $deptId = strtoupper($emp['department_id'] ?? '');
            if (str_contains($deptId, 'ENG') || str_contains($deptId, 'TECH') || str_contains($deptId, 'DEV') || str_contains($deptId, 'IT')) {
                return $dayShift['id'];
            }
            if (str_contains($deptId, 'HR') || str_contains($deptId, 'FIN') || str_contains($deptId, 'ACC') || str_contains($deptId, 'ADMIN')) {
                return $morningShift['id'];
            }
            return $nightShift['id'];
        }

        if ($strategy === 'night_rotation') {
            // 30% Night, 40% Day, 30% Morning
            $mod = $empIndex % 10;
            if ($mod < 3) {
                return $nightShift['id'];
            }
            if ($mod < 7) {
                return $dayShift['id'];
            }
            return $morningShift['id'];
        }

        if ($strategy === 'weekly_rotation') {
            // Rotates shift cycle every 7 calendar days
            $weekOffset = 0;
            if (!empty($startDate) && !empty($currentDate)) {
                $diffDays = (int)floor((strtotime($currentDate) - strtotime($startDate)) / 86400);
                $weekOffset = (int)floor($diffDays / 7);
            }
            $shiftIndex = ($empIndex + $weekOffset) % $shiftCount;
            if ($shiftIndex < 0) $shiftIndex += $shiftCount;
            return $shifts[$shiftIndex]['id'];
        }

        if ($strategy === 'monthly_rotation') {
            // Rotates shift cycle every calendar month
            $monthOffset = 0;
            if (!empty($startDate) && !empty($currentDate)) {
                $startYear = (int)date('Y', strtotime($startDate));
                $startMonth = (int)date('m', strtotime($startDate));
                $curYear = (int)date('Y', strtotime($currentDate));
                $curMonth = (int)date('m', strtotime($currentDate));
                $monthOffset = (($curYear - $startYear) * 12) + ($curMonth - $startMonth);
            }
            $shiftIndex = ($empIndex + $monthOffset) % $shiftCount;
            if ($shiftIndex < 0) $shiftIndex += $shiftCount;
            return $shifts[$shiftIndex]['id'];
        }

        if ($strategy === 'daily_rotation') {
            // Rotates shift cycle every calendar day
            $shiftIndex = ($empIndex + $dayIndex) % $shiftCount;
            return $shifts[$shiftIndex]['id'];
        }

        // Default fallback to balanced rotation
        return $shifts[$empIndex % $shiftCount]['id'];
    }

    /**
     * Human-readable algorithm labels
     */
    public function getStrategyLabel(string $strategy): string
    {
        return match ($strategy) {
            'rotate'           => 'Balanced Workforce Rotation',
            'standard'         => 'Standardize Day Shift',
            'department'       => 'Departmental Split',
            'night_rotation'   => 'Night Heavy Rotation',
            'weekly_rotation'  => 'Weekly Shift Rotation',
            'monthly_rotation' => 'Monthly Shift Rotation',
            'daily_rotation'   => 'Daily Shift Rotation',
            default            => ucfirst(str_replace('_', ' ', $strategy)),
        };
    }

    /**
     * Create Shift Swap Request
     */
    public function createShiftSwapRequest(array $data, ?string $performedByUserId = null): array
    {
        $requesterId = $data['requester_id'] ?? '';
        $targetId = $data['target_employee_id'] ?? '';
        $reason = trim($data['reason'] ?? '');
        $swapDate = $data['swap_date'] ?? date('Y-m-d');

        if (!$requesterId || !$targetId || !$reason) {
            return ['success' => false, 'message' => 'Please select both employees and provide a valid reason.'];
        }

        if ($requesterId === $targetId) {
            return ['success' => false, 'message' => 'You cannot swap a shift with the same employee.'];
        }

        if ($swapDate < date('Y-m-d')) {
            return ['success' => false, 'message' => 'Shift swap date cannot be earlier than today.'];
        }

        $reqEmp = $this->empModel->find($requesterId);
        $tarEmp = $this->empModel->find($targetId);

        if (!$reqEmp || !$tarEmp) {
            return ['success' => false, 'message' => 'One or both employee profiles could not be found.'];
        }

        // SEC-ATT-06: Cross-tenant swap check
        if (!empty($reqEmp['company_id']) && !empty($tarEmp['company_id']) && (string)$reqEmp['company_id'] !== (string)$tarEmp['company_id']) {
            return ['success' => false, 'message' => '403 Forbidden: Shift swaps between employees of different companies are strictly prohibited.'];
        }

        $this->ensureSwapTableExists();

        $existingPending = $this->swapModel
            ->where('requester_id', $requesterId)
            ->where('target_employee_id', $targetId)
            ->where('swap_date', $swapDate)
            ->where('status', 'Pending')
            ->first();

        if ($existingPending) {
            return ['success' => false, 'message' => 'A pending shift swap request already exists for these employees on this date.'];
        }

        try {
            $reqEff = $this->shiftModel->resolveEffectiveShift($requesterId, $swapDate, $reqEmp);
            $tarEff = $this->shiftModel->resolveEffectiveShift($targetId, $swapDate, $tarEmp);

            $reqIsDayOff = !empty($reqEff['is_day_off']) || in_array($reqEff['outcome'] ?? '', ['ROSTER_DAY_OFF', 'WEEKLY_OFF'], true);
            $tarIsDayOff = !empty($tarEff['is_day_off']) || in_array($tarEff['outcome'] ?? '', ['ROSTER_DAY_OFF', 'WEEKLY_OFF'], true);

            if ($reqIsDayOff || empty($reqEff['shift_id']) || $tarIsDayOff || empty($tarEff['shift_id'])) {
                return [
                    'success' => false,
                    'message' => 'Shift swap is not possible: one employee has no working shift on that date.',
                ];
            }

            $reqShiftId = $reqEff['shift_id'];
            $tarShiftId = $tarEff['shift_id'];
        } catch (\Throwable $e) {
            $shifts = $this->shiftModel->getActiveShifts();
            $defaultShiftId = !empty($shifts) ? $shifts[0]['id'] : 'shift-001';

            $reqShiftId = $reqEmp['shift_id'] ?: $defaultShiftId;
            $tarShiftId = $tarEmp['shift_id'] ?: $defaultShiftId;
        }

        $swapId = 'SW-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));

        $this->swapModel->insert([
            'id' => $swapId,
            'company_id' => $reqEmp['company_id'] ?? null,
            'branch_id' => $reqEmp['branch_id'] ?? null,
            'requester_id' => $requesterId,
            'requester_shift_id' => $reqShiftId,
            'target_employee_id' => $targetId,
            'target_employee_shift_id' => $tarShiftId,
            'requested_shift_id' => $tarShiftId,
            'swap_date' => $swapDate,
            'reason' => $reason,
            'status' => 'Pending',
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ]);

        // Trigger Notification
        if ($this->db->tableExists('notifications') && $this->db->tableExists('users')) {
            try {
                $targetCompanyId = $tarEmp['company_id'] ?? null;
                $userBuilder = $this->db->table('users')->where('employee_id', $targetId);
                if (!empty($targetCompanyId) && $this->db->fieldExists('company_id', 'users')) {
                    $userBuilder->where('company_id', $targetCompanyId);
                }
                $targetUser = $userBuilder->get()->getRowArray();

                if (!empty($targetUser['id'])) {
                    $notifData = [
                        'id'         => 'notif-' . bin2hex(random_bytes(6)),
                        'user_id'    => $targetUser['id'],
                        'title'      => 'Shift Swap Request',
                        'message'    => "{$reqEmp['first_name']} requested a shift swap with you for {$swapDate}: '{$reason}'",
                        'type'       => 'roster',
                        'is_read'    => 0,
                        'created_at' => date('Y-m-d H:i:s'),
                    ];

                    if ($this->db->fieldExists('company_id', 'notifications')) {
                        $notifData['company_id'] = $targetCompanyId;
                    }
                    if ($this->db->fieldExists('employee_id', 'notifications')) {
                        $notifData['employee_id'] = $targetId;
                    }

                    $notifModel = new NotificationModel();
                    $notifModel->protect(false)->insert($notifData);
                }
            } catch (\Throwable $e) {
                log_message('error', 'Shift swap notification skipped: ' . $e->getMessage());
            }
        }

        return [
            'success' => true,
            'message' => 'Shift swap request submitted successfully.',
            'swap_id' => $swapId
        ];
    }

    /**
     * Approve Shift Swap Request & Automatically Swap Active Shifts
     */
    public function approveShiftSwapRequest(string $swapId, ?string $reviewedByUserId = null): array
    {
        $this->ensureSwapTableExists();
        $swap = $this->swapModel->find($swapId);

        if (!$swap) {
            return ['success' => false, 'message' => 'Shift swap request not found.'];
        }

        if ($swap['status'] !== 'Pending') {
            return ['success' => false, 'message' => "This swap request is already '{$swap['status']}'."];
        }

        $requesterId = $swap['requester_id'];
        $targetId = $swap['target_employee_id'];
        $swapDate = $swap['swap_date'] ?? date('Y-m-d');

        $reqEmp = $this->empModel->find($requesterId);
        $tarEmp = $this->empModel->find($targetId);

        if (!$reqEmp || !$tarEmp) {
            return ['success' => false, 'message' => 'Associated employee accounts not found.'];
        }

        // SEC-ATT-06: Cross-tenant swap approval check
        if (!empty($reqEmp['company_id']) && !empty($tarEmp['company_id']) && (string)$reqEmp['company_id'] !== (string)$tarEmp['company_id']) {
            return ['success' => false, 'message' => '403 Forbidden: Cross-tenant shift swap cannot be approved.'];
        }

        $newReqShiftId = $swap['target_employee_shift_id'] ?: $tarEmp['shift_id'];
        $newTarShiftId = $swap['requester_shift_id'] ?: $reqEmp['shift_id'];

        $this->db->transStart();

        // If swapDate is specified, assign on date slot in roster_assignments
        if ($swapDate && $this->db->tableExists('roster_assignments')) {
            // Update Requester Assignment for swap date
            $this->upsertRosterAssignment($requesterId, $newReqShiftId, $swapDate, [
                'roster_id'    => 'ros-swap',
                'is_weekend'   => 0,
                'is_day_off'   => 0,
                'is_published' => 1,
                'notes'        => 'Shift swapped with ' . ($tarEmp['first_name'] ?? 'Colleague'),
            ]);

            // Update Target Employee Assignment for swap date
            $this->upsertRosterAssignment($targetId, $newTarShiftId, $swapDate, [
                'roster_id'    => 'ros-swap',
                'is_weekend'   => 0,
                'is_day_off'   => 0,
                'is_published' => 1,
                'notes'        => 'Shift swapped with ' . ($reqEmp['first_name'] ?? 'Colleague'),
            ]);
        }

        // NOTE: Master shift assignments (employees.shift_id) are intentionally NOT updated.
        // A shift swap is effective only for the requested swap_date.

        // Update swap request status
        $this->swapModel->update($swapId, [
            'status' => 'Approved',
            'reviewed_by' => $reviewedByUserId,
            'reviewed_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ]);

        $this->db->transComplete();

        // Audit Trail
        $auditService = new AuditService();
        $auditService->log(
            $reviewedByUserId,
            'roster',
            'swap.approved',
            $swapId,
            ['status' => 'Pending'],
            ['status' => 'Approved', 'requester_new_shift' => $newReqShiftId, 'target_new_shift' => $newTarShiftId],
            null,
            null,
            "Approved shift swap between {$reqEmp['first_name']} and {$tarEmp['first_name']} for {$swapDate}."
        );

        return [
            'success' => true,
            'message' => 'Shift swap approved and employee schedules updated successfully.'
        ];
    }

    /**
     * Reject Shift Swap Request
     */
    public function rejectShiftSwapRequest(string $swapId, ?string $reason = null, ?string $reviewedByUserId = null): array
    {
        $this->ensureSwapTableExists();
        $swap = $this->swapModel->find($swapId);

        if (!$swap) {
            return ['success' => false, 'message' => 'Shift swap request not found.'];
        }

        $this->swapModel->update($swapId, [
            'status' => 'Rejected',
            'rejection_reason' => $reason ?: 'Shift swap request declined by manager.',
            'reviewed_by' => $reviewedByUserId,
            'reviewed_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ]);

        // AUD-01: Audit Trail for Shift Swap Rejection
        $auditService = new AuditService();
        $auditService->log(
            $reviewedByUserId,
            'roster',
            'swap.rejected',
            $swapId,
            ['status' => $swap['status']],
            ['status' => 'Rejected', 'rejection_reason' => $reason ?: 'Shift swap request declined by manager.'],
            null,
            null,
            "Rejected shift swap request {$swapId} for swap date {$swap['swap_date']}. Reason: " . ($reason ?: 'Declined by manager.')
        );

        return [
            'success' => true,
            'message' => 'Shift swap request has been rejected.'
        ];
    }

    /**
     * Publish a New Roster Period
     */
    public function publishRoster(array $data, ?string $performedByUserId = null): array
    {
        $name = trim($data['name'] ?? '');
        $startDate = $data['start_date'] ?? '';
        $endDate = $data['end_date'] ?? '';
        $departmentId = !empty($data['department_id']) ? $data['department_id'] : null;
        $branchId = !empty($data['branch_id']) ? $data['branch_id'] : null;
        $rosterType = !empty($data['roster_type']) ? $data['roster_type'] : 'Weekly';

        if (!$name || !$startDate || !$endDate) {
            return ['success' => false, 'message' => 'Roster name, start date, and end date are required.'];
        }

        $rosterId = 'ros-' . bin2hex(random_bytes(6));
        $this->rosterModel->insert([
            'id' => $rosterId,
            'company_id' => $data['company_id'] ?? null,
            'branch_id' => $branchId,
            'department_id' => $departmentId,
            'name' => $name,
            'start_date' => $startDate,
            'end_date' => $endDate,
            'roster_type' => $rosterType,
            'status' => 'published',
            'published_by' => $performedByUserId,
            'published_at' => date('Y-m-d H:i:s'),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ]);

        // SEC-03: Mark assignments as published STRICTLY SCOPED to employees of this tenant
        if ($this->db->tableExists('roster_assignments')) {
            $builder = $this->db->table('roster_assignments')
                ->where('roster_assignments.date >=', $startDate)
                ->where('roster_assignments.date <=', $endDate);

            $companyId = $data['company_id'] ?? null;
            if (!empty($companyId)) {
                $empQuery = $this->db->table('employees')
                    ->select('id')
                    ->where('company_id', $companyId);
                if ($departmentId && $departmentId !== 'all') {
                    $empQuery->where('department_id', $departmentId);
                }
                if ($branchId && $branchId !== 'all') {
                    $empQuery->where('branch_id', $branchId);
                }
                $empList = array_column($empQuery->get()->getResultArray(), 'id');

                if (!empty($empList)) {
                    $builder->whereIn('roster_assignments.employee_id', $empList);
                    $builder->update(['is_published' => 1, 'roster_id' => $rosterId]);
                }
            } else {
                $builder->update(['is_published' => 1, 'roster_id' => $rosterId]);
            }
        }

        // AUD-01: Audit Trail for Roster Schedule Publishing
        $auditService = new AuditService();
        $auditService->log(
            $performedByUserId,
            'roster',
            'roster.published',
            $rosterId,
            null,
            [
                'roster_id'     => $rosterId,
                'name'          => $name,
                'start_date'    => $startDate,
                'end_date'      => $endDate,
                'company_id'    => $data['company_id'] ?? null,
                'department_id' => $departmentId,
                'branch_id'     => $branchId
            ],
            null,
            null,
            "Published and locked roster schedule '{$name}' from {$startDate} to {$endDate}."
        );

        return [
            'success' => true,
            'message' => "Roster schedule '{$name}' published and locked successfully.",
            'roster_id' => $rosterId
        ];
    }

    /**
     * Helper to ensure shift_swap_requests table exists
     */
    protected function ensureSwapTableExists(): void
    {
        if (!$this->db->tableExists('shift_swap_requests')) {
            $forge = \Config\Database::forge();
            $forge->addField([
                'id' => ['type' => 'VARCHAR', 'constraint' => 36],
                'company_id' => ['type' => 'VARCHAR', 'constraint' => 36, 'null' => true],
                'branch_id' => ['type' => 'VARCHAR', 'constraint' => 36, 'null' => true],
                'requester_id' => ['type' => 'VARCHAR', 'constraint' => 36],
                'requester_shift_id' => ['type' => 'VARCHAR', 'constraint' => 36, 'null' => true],
                'target_employee_id' => ['type' => 'VARCHAR', 'constraint' => 36],
                'target_employee_shift_id' => ['type' => 'VARCHAR', 'constraint' => 36, 'null' => true],
                'requested_shift_id' => ['type' => 'VARCHAR', 'constraint' => 36, 'null' => true],
                'swap_date' => ['type' => 'DATE', 'null' => true],
                'reason' => ['type' => 'TEXT'],
                'status' => ['type' => 'ENUM', 'constraint' => ['Pending', 'Approved', 'Rejected', 'Cancelled'], 'default' => 'Pending'],
                'reviewed_by' => ['type' => 'VARCHAR', 'constraint' => 36, 'null' => true],
                'reviewed_at' => ['type' => 'DATETIME', 'null' => true],
                'rejection_reason' => ['type' => 'TEXT', 'null' => true],
                'created_at' => ['type' => 'DATETIME', 'null' => true],
                'updated_at' => ['type' => 'DATETIME', 'null' => true],
            ]);
            $forge->addKey('id', true);
            $forge->createTable('shift_swap_requests', true);
        }
    }
}
