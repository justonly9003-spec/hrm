<?php

namespace App\Services;

/**
 * DashboardWidgetRegistry
 * 
 * Centralized registry of all HCM dashboard widgets.
 * Every dashboard feature is registered as a widget with:
 * - Defined interfaces
 * - Data dependencies
 * - Authoritative services/models
 * - Permissions and subscription tiers
 * - Role targeting and layout grid widths
 * 
 * RULE: Zero duplicated business logic. Widgets consume authoritative services.
 */
class DashboardWidgetRegistry
{
    /**
     * Approved Category Navigation Groups (Phase 2 & Phase 3)
     */
    public const CATEGORY_GROUP_OVERVIEW   = 'overview';
    public const CATEGORY_GROUP_ATTENDANCE = 'attendance';
    public const CATEGORY_GROUP_LEAVES     = 'leaves';
    public const CATEGORY_GROUP_PAYROLL    = 'payroll';

    public const CATEGORY_GROUPS = [
        self::CATEGORY_GROUP_OVERVIEW => [
            'id'          => self::CATEGORY_GROUP_OVERVIEW,
            'title'       => 'Overview',
            'icon'        => 'layout-dashboard',
            'description' => 'Executive summary, operational KPIs, pending approvals, and workforce distribution.',
        ],
        self::CATEGORY_GROUP_ATTENDANCE => [
            'id'          => self::CATEGORY_GROUP_ATTENDANCE,
            'title'       => 'Attendance & Shifts',
            'icon'        => 'clock',
            'description' => 'Live clock terminal, attendance exceptions, shift rosters, and daily presence trends.',
        ],
        self::CATEGORY_GROUP_LEAVES => [
            'id'          => self::CATEGORY_GROUP_LEAVES,
            'title'       => 'Leaves & Roster',
            'icon'        => 'calendar-days',
            'description' => 'Leave entitlements, departmental absence calendar, and upcoming scheduled leaves.',
        ],
        self::CATEGORY_GROUP_PAYROLL => [
            'id'          => self::CATEGORY_GROUP_PAYROLL,
            'title'       => 'Payroll & Compliance',
            'icon'        => 'receipt',
            'description' => 'Monthly payroll variance, compliance document tracking, audit logs, and system health.',
        ],
    ];

    /**
     * Authoritative list of platform-level widget codes restricted exclusively to software_app_admin.
     */
    public const PLATFORM_WIDGET_CODES = [
        'appadmin_platform_overview',
        'appadmin_company_fleet',
        'appadmin_system_health',
        'appadmin_kpis',
        'system_health_telemetry',
    ];

    /**
     * Authoritative list of self-service widget codes permitted in employee/self scope.
     */
    public const SELF_SERVICE_ALLOWED_CODES = [
        'employee_clock_card',
        'employee_leave_balances',
        'employee_quick_actions',
        'employee_recent_activity',
        'staff_leave_calendar',
        'employee_my_calendar',
        'company_holiday_calendar',
        'company_notice_board',
        'employee_recent_notices',
        'employee_tasks',
    ];

    /**
     * Check if a widget code is a platform-level widget.
     */
    public static function isPlatformWidget(string $code): bool
    {
        return in_array($code, self::PLATFORM_WIDGET_CODES, true);
    }

    /**
     * Check if a widget code is allowed in self-service employee scope.
     */
    public static function isSelfServiceAllowed(string $code): bool
    {
        return in_array($code, self::SELF_SERVICE_ALLOWED_CODES, true);
    }

    /**
     * Complete Master Catalog of HCM Dashboard Widgets
     */
    public static function getMasterCatalog(): array
    {
        return [
            // ==========================================
            // 1. EXECUTIVE & WORKFORCE KPIS (W-01, W-02)
            // ==========================================
            'executive_kpis' => [
                'id'                    => 'wdg-kpi-01',
                'code'                  => 'company_executive_kpis',
                'title'                 => 'Executive Operations & Workforce KPIs',
                'description'           => 'High-level executive strip: Total headcount, attendance rate today, on-leave count, and pending approvals.',
                'category'              => 'kpi',
                'view_path'             => 'dashboard/widgets/executive_kpis',
                'icon'                  => 'briefcase',
                'module_code'           => 'dashboard',
                'permission_code'       => 'dashboard.view',
                'target_roles'          => ['company_admin', 'hr_admin', 'finance', 'auditor'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 1,
                'grid_width'            => 'full',
                'data_dependencies'     => ['stats', 'attendance_stats', 'department_count', 'branch_count', 'monthly_payroll', 'attendance_overview_stats'],
                'authoritative_service' => 'App\Services\DashboardService',
            ],

            // ==========================================
            // 2. LIVE ATTENDANCE & BIOMETRIC CLOCK (W-14)
            // ==========================================
            'clock_card' => [
                'id'                    => 'wdg-att-01',
                'code'                  => 'employee_clock_card',
                'title'                 => 'Today\'s Attendance & Punch Card',
                'description'           => 'Live clock-in/out terminal with GPS geofence radar, live ticking seconds, and punch state indicator.',
                'category'              => 'ess',
                'view_path'             => 'dashboard/widgets/clock_card',
                'icon'                  => 'clock',
                'module_code'           => 'attendance',
                'permission_code'       => 'attendance.view',
                'target_roles'          => ['employee', 'manager', 'team_leader', 'hr_admin', 'company_admin'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 2,
                'grid_width'            => 'half',
                'data_dependencies'     => ['employee_profile', 'today_attendance', 'assigned_shift', 'geofence_config'],
                'authoritative_service' => 'App\Services\AttendanceService',
            ],

            // ==========================================
            // 3. ATTENDANCE EXCEPTIONS & IRREGULARITIES (W-03)
            // ==========================================
            'hr_attendance_exceptions' => [
                'id'                    => 'wdg-att-02',
                'code'                  => 'hr_attendance_exceptions',
                'title'                 => 'Today\'s Attendance Exceptions',
                'description'           => 'Daily exception log: Late arrivals, early exits, missing check-outs, and unexcused absences.',
                'category'              => 'attendance',
                'view_path'             => 'dashboard/widgets/hr_attendance_exceptions',
                'icon'                  => 'clock-alert',
                'module_code'           => 'attendance',
                'permission_code'       => 'attendance.view',
                'target_roles'          => ['hr_admin', 'company_admin', 'auditor'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 3,
                'grid_width'            => 'half',
                'data_dependencies'     => ['late_employees', 'absent_employees', 'missing_punches'],
                'authoritative_service' => 'App\Services\AttendanceService',
            ],

            // ==========================================
            // 4. LEAVE BALANCES & QUOTAS (W-15, W-18)
            // ==========================================
            'leave_balances' => [
                'id'                    => 'wdg-lev-01',
                'code'                  => 'employee_leave_balances',
                'title'                 => 'My Leave Quotas & Entitlements',
                'description'           => 'Categorized leave balance cards: Annual, Casual, Sick, and Emergency leave quotas with used days.',
                'category'              => 'leave',
                'view_path'             => 'dashboard/widgets/leave_balances',
                'icon'                  => 'wallet-cards',
                'module_code'           => 'leaves',
                'permission_code'       => 'leaves.view',
                'target_roles'          => ['employee', 'manager', 'team_leader', 'hr_admin', 'company_admin'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 4,
                'grid_width'            => 'half',
                'data_dependencies'     => ['leave_balances', 'leave_entitlements', 'recent_leave_history'],
                'authoritative_service' => 'App\Services\LeaveService',
            ],

            // ==========================================
            // 5. PENDING APPROVALS QUEUE (W-06)
            // ==========================================
            'pending_approvals' => [
                'id'                    => 'wdg-app-01',
                'code'                  => 'company_pending_approvals',
                'title'                 => 'Action Required: Pending Approvals Queue',
                'description'           => 'Unified pending queue for Leave Applications and Regularizations.',
                'category'              => 'overview',
                'view_path'             => 'dashboard/widgets/pending_approvals',
                'icon'                  => 'check-circle-2',
                'module_code'           => 'dashboard',
                'permission_code'       => 'dashboard.view',
                'target_roles'          => ['company_admin', 'hr_admin'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 5,
                'grid_width'            => 'half',
                'data_dependencies'     => ['pending_leaves', 'pending_regularizations'],
                'authoritative_service' => 'App\Services\DashboardService',
            ],

            // ==========================================
            // 6. STAFF LEAVE & ABSENCE CALENDAR (W-24, W-25)
            // ==========================================
            'staff_leave_calendar' => [
                'id'                    => 'wdg-cal-01',
                'code'                  => 'staff_leave_calendar',
                'title'                 => 'Staff Absence & Leave Roster Calendar',
                'description'           => 'Interactive monthly absence matrix with week-start day configuration, department filter, and drill-down drawer.',
                'category'              => 'leave',
                'view_path'             => 'dashboard/widgets/staff_leave_calendar',
                'icon'                  => 'calendar-days',
                'module_code'           => 'leaves',
                'permission_code'       => 'leaves.view',
                'target_roles'          => ['company_admin', 'hr_admin', 'manager', 'employee', 'software_app_admin', 'auditor'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 6,
                'grid_width'            => 'full',
                'data_dependencies'     => ['calendar_leaves', 'calendar_holidays', 'company_weekend', 'departments_list'],
                'authoritative_service' => 'App\Services\CompanyWeekendService',
            ],

            // ==========================================
            // 7. DEPARTMENTAL WORKFORCE DISTRIBUTION (W-03)
            // ==========================================
            'department_distribution' => [
                'id'                    => 'wdg-wfk-01',
                'code'                  => 'company_department_distribution',
                'title'                 => 'Departmental Workforce Distribution',
                'description'           => 'Visual headcount bar distribution across business units with target headcount comparison.',
                'category'              => 'workforce',
                'view_path'             => 'dashboard/widgets/department_distribution',
                'icon'                  => 'pie-chart',
                'module_code'           => 'master',
                'permission_code'       => 'master.view',
                'target_roles'          => ['company_admin', 'hr_admin', 'auditor'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 7,
                'grid_width'            => 'half',
                'data_dependencies'     => ['department_distribution', 'gender_ratio', 'total_employees'],
                'authoritative_service' => 'App\Services\DashboardService',
            ],

            // ==========================================
            // 8. 7-DAY ROLLING ATTENDANCE TREND (W-04)
            // ==========================================
            'attendance_trend' => [
                'id'                    => 'wdg-att-03',
                'code'                  => 'attendance_trend',
                'title'                 => '7-Day Rolling Attendance Trend',
                'description'           => 'Rolling 7-day attendance visualizer comparing Present, Late Arrivals, and Absences.',
                'category'              => 'analytics',
                'view_path'             => 'dashboard/widgets/attendance_trend',
                'icon'                  => 'trending-up',
                'module_code'           => 'attendance',
                'permission_code'       => 'attendance.view',
                'target_roles'          => ['company_admin', 'hr_admin', 'manager', 'auditor'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 8,
                'grid_width'            => 'half',
                'data_dependencies'     => ['rolling_attendance_trend'],
                'authoritative_service' => 'App\Services\AttendanceService',
            ],

            // ==========================================
            // 9. LIVE ATTENDANCE STREAM (W-05)
            // ==========================================
            'live_attendance_stream' => [
                'id'                    => 'wdg-att-04',
                'code'                  => 'live_attendance_stream',
                'title'                 => 'Real-Time Punch Stream',
                'description'           => 'Live-updating stream of employee check-ins with verification badges (Biometric, QR, Web, GPS).',
                'category'              => 'operations',
                'view_path'             => 'dashboard/widgets/live_attendance_stream',
                'icon'                  => 'radio',
                'module_code'           => 'attendance',
                'permission_code'       => 'attendance.view',
                'target_roles'          => ['company_admin', 'hr_admin', 'manager'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 9,
                'grid_width'            => 'half',
                'data_dependencies'     => ['recent_punches_stream'],
                'authoritative_service' => 'App\Services\AttendanceService',
            ],

            // ==========================================
            // 10. PAYROLL COST SUMMARY (W-07)
            // ==========================================
            'payroll_cost_summary' => [
                'id'                    => 'wdg-pay-01',
                'code'                  => 'payroll_cost_summary',
                'title'                 => 'Monthly Payroll Cost & Commitments',
                'description'           => 'Current month gross payroll projection, basic vs allowances split, statutory deductions, and status.',
                'category'              => 'payroll',
                'view_path'             => 'dashboard/widgets/payroll_cost_summary',
                'icon'                  => 'credit-card',
                'module_code'           => 'payroll',
                'permission_code'       => 'payroll.view',
                'target_roles'          => ['company_admin', 'finance', 'auditor'],
                'min_subscription_plan' => 'professional',
                'default_status'        => 1,
                'default_sort_order'    => 10,
                'grid_width'            => 'half',
                'data_dependencies'     => ['monthly_payroll_estimate', 'payroll_breakdown', 'payroll_status'],
                'authoritative_service' => 'App\Services\PayrollService',
            ],

            // ==========================================
            // 11. MULTI-TENANT COMPANY FLEET (W-08, W-11)
            // ==========================================
            'company_fleet' => [
                'id'                    => 'wdg-appadmin-02',
                'code'                  => 'appadmin_company_fleet',
                'title'                 => 'Organization & Tenant Fleet',
                'description'           => 'Multi-tenant organization status, active subscriptions, and user quotas across the platform.',
                'category'              => 'platform',
                'view_path'             => 'dashboard/widgets/company_fleet',
                'icon'                  => 'layers',
                'module_code'           => null,
                'permission_code'       => 'companies.view',
                'target_roles'          => ['software_app_admin'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 11,
                'grid_width'            => 'half',
                'data_dependencies'     => ['tenant_fleet_list', 'tenant_stats'],
                'authoritative_service' => 'App\Services\DashboardService',
            ],

            // ==========================================
            // 12. PLATFORM OVERVIEW (W-12)
            // ==========================================
            'platform_overview' => [
                'id'                    => 'wdg-appadmin-01',
                'code'                  => 'appadmin_platform_overview',
                'title'                 => 'Multi-Tenant Platform KPIs',
                'description'           => 'Global platform counts: Total organizations, active subscriptions, platform MRR, and total users.',
                'category'              => 'platform',
                'view_path'             => 'dashboard/widgets/platform_overview',
                'icon'                  => 'building-2',
                'module_code'           => null,
                'permission_code'       => 'companies.view',
                'target_roles'          => ['software_app_admin'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 12,
                'grid_width'            => 'full',
                'data_dependencies'     => ['platform_kpis', 'mrr_summary'],
                'authoritative_service' => 'App\Services\DashboardService',
            ],

            // ==========================================
            // 13. SYSTEM HEALTH & INFRASTRUCTURE (W-13)
            // ==========================================
            'system_health' => [
                'id'                    => 'wdg-appadmin-03',
                'code'                  => 'appadmin_system_health',
                'title'                 => 'System Infrastructure & Health',
                'description'           => 'Database connectivity, memory utilization, cache efficiency, and background queue health.',
                'category'              => 'system',
                'view_path'             => 'dashboard/widgets/system_health',
                'icon'                  => 'activity',
                'module_code'           => 'system',
                'permission_code'       => 'system.view',
                'target_roles'          => ['software_app_admin'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 13,
                'grid_width'            => 'half',
                'data_dependencies'     => ['system_health_metrics'],
                'authoritative_service' => 'App\Services\DashboardService',
            ],

            // ==========================================
            // 14. SECURITY AUDIT LOG STREAM (W-09, W-14)
            // ==========================================
            'audit_stream' => [
                'id'                    => 'wdg-appadmin-04',
                'code'                  => 'appadmin_audit_stream',
                'title'                 => 'Security & Compliance Audit Stream',
                'description'           => 'Real-time security log: User logins, role elevations, sensitive permission changes, and security warnings.',
                'category'              => 'security',
                'view_path'             => 'dashboard/widgets/audit_stream',
                'icon'                  => 'shield-alert',
                'module_code'           => 'system',
                'permission_code'       => 'system.view',
                'target_roles'          => ['software_app_admin', 'company_admin', 'auditor'],
                'min_subscription_plan' => 'professional',
                'default_status'        => 1,
                'default_sort_order'    => 14,
                'grid_width'            => 'full',
                'data_dependencies'     => ['audit_logs_recent'],
                'authoritative_service' => 'App\Services\AuditService',
            ],

            // ==========================================
            // 15. MANAGER TEAM OVERVIEW & ROSTER (W-09, W-13, W-15)
            // ==========================================
            'team_overview' => [
                'id'                    => 'wdg-mgr-01',
                'code'                  => 'manager_team_overview',
                'title'                 => 'Department Team Roster & Presence',
                'description'           => 'Live team attendance status, present members, on-leave count, and Team Hub vs Personal ESS toggle.',
                'category'              => 'workforce',
                'view_path'             => 'dashboard/widgets/team_overview',
                'icon'                  => 'user-check',
                'module_code'           => 'attendance',
                'permission_code'       => 'attendance.view',
                'target_roles'          => ['manager', 'team_leader'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 15,
                'grid_width'            => 'full',
                'data_dependencies'     => ['team_members', 'team_attendance', 'team_stats'],
                'authoritative_service' => 'App\Services\AttendanceService',
            ],

            // ==========================================
            // 16. MANAGER TEAM APPROVALS QUEUE (W-12, W-16)
            // ==========================================
            'team_approvals' => [
                'id'                    => 'wdg-mgr-03',
                'code'                  => 'manager_team_approvals',
                'title'                 => 'Direct Reports Approvals Queue',
                'description'           => 'Tabbed approval queue for direct subordinates: Leave requests and shift swaps.',
                'category'              => 'overview',
                'view_path'             => 'dashboard/widgets/team_approvals',
                'icon'                  => 'clipboard-check',
                'module_code'           => 'leaves',
                'permission_code'       => 'leaves.view',
                'target_roles'          => ['manager', 'team_leader'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 16,
                'grid_width'            => 'half',
                'data_dependencies'     => ['team_pending_leaves', 'team_pending_ot'],
                'authoritative_service' => 'App\Services\LeaveService',
            ],

            // ==========================================
            // 17. 7-DAY SHIFT ROSTER SNAPSHOT (W-11, W-17)
            // ==========================================
            'shift_snapshot' => [
                'id'                    => 'wdg-mgr-04',
                'code'                  => 'manager_shift_roster_snapshot',
                'title'                 => '7-Day Shift Roster Snapshot',
                'description'           => '7-day shift coverage matrix for direct reports with assigned shifts and weekly-off indicators.',
                'category'              => 'attendance',
                'view_path'             => 'dashboard/widgets/shift_snapshot',
                'icon'                  => 'calendar-range',
                'module_code'           => 'rostering',
                'permission_code'       => 'rostering.view',
                'target_roles'          => ['manager', 'team_leader'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 17,
                'grid_width'            => 'half',
                'data_dependencies'     => ['weekly_roster_matrix', 'shifts_list'],
                'authoritative_service' => 'App\Services\RosterService',
            ],

            // ==========================================
            // 18. BROADCAST NOTICES & BULLETIN (W-23, W-18)
            // ==========================================
            'notices_bulletin' => [
                'id'                    => 'wdg-emp-04',
                'code'                  => 'employee_recent_notices',
                'title'                 => 'Company Broadcasts & Bulletins',
                'description'           => 'Company bulletins, policy updates, and circulars with category badges and published dates.',
                'category'              => 'social',
                'view_path'             => 'dashboard/widgets/notices_bulletin',
                'icon'                  => 'megaphone',
                'module_code'           => 'notices',
                'permission_code'       => 'notices.view',
                'target_roles'          => ['*'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 18,
                'grid_width'            => 'half',
                'data_dependencies'     => ['company_notices'],
                'authoritative_service' => 'App\Services\DashboardService',
            ],

            // ==========================================
            // 19. BRANCH BIRTHDAYS & CELEBRATIONS (W-26, W-27, W-19)
            // ==========================================
            'branch_celebrations' => [
                'id'                    => 'wdg-soc-01',
                'code'                  => 'branch_celebrations',
                'title'                 => 'Branch Celebrations & Milestones',
                'description'           => 'Branch-isolated birthdays, work anniversaries, and new joiners with interactive congratulations and confetti.',
                'category'              => 'social',
                'view_path'             => 'dashboard/widgets/branch_celebrations',
                'icon'                  => 'party-popper',
                'module_code'           => 'dashboard',
                'permission_code'       => 'dashboard.view',
                'target_roles'          => ['*'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 19,
                'grid_width'            => 'half',
                'data_dependencies'     => ['branch_birthdays_today', 'branch_upcoming_birthdays', 'branch_anniversaries', 'branch_new_joiners'],
                'authoritative_service' => 'App\Services\DashboardService',
            ],

            // ==========================================
            // 20. DEPARTMENT LEAVE VISIBILITY (W-28, W-20)
            // ==========================================
            'department_leaves' => [
                'id'                    => 'wdg-soc-02',
                'code'                  => 'department_leaves',
                'title'                 => 'Department Colleagues on Leave',
                'description'           => 'Peer absence tracker scoped strictly to employee department with privacy masking on reasons.',
                'category'              => 'social',
                'view_path'             => 'dashboard/widgets/department_leaves',
                'icon'                  => 'user-minus',
                'module_code'           => 'leaves',
                'permission_code'       => 'leaves.view',
                'target_roles'          => ['*'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 20,
                'grid_width'            => 'half',
                'data_dependencies'     => ['dept_leaves_today', 'dept_upcoming_leaves'],
                'authoritative_service' => 'App\Services\LeaveService',
            ],

            // ==========================================
            // 21. EMPLOYEE QUICK ACTION DECK (W-16, W-21)
            // ==========================================
            'employee_quick_actions' => [
                'id'                    => 'wdg-ess-01',
                'code'                  => 'employee_quick_actions',
                'title'                 => 'Quick Self-Service Actions',
                'description'           => 'Quick launch deck: Apply for Leave, Regularize Attendance, View Payslips.',
                'category'              => 'ess',
                'view_path'             => 'dashboard/widgets/employee_quick_actions',
                'icon'                  => 'zap',
                'module_code'           => 'dashboard',
                'permission_code'       => 'dashboard.view',
                'target_roles'          => ['employee', 'manager', 'team_leader', 'hr_admin', 'company_admin'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 21,
                'grid_width'            => 'full',
                'data_dependencies'     => ['quick_action_routes'],
                'authoritative_service' => 'App\Services\DashboardService',
            ],

            // ==========================================
            // 22. PERSONAL TASKS & TO-DO CHECKLIST (W-11, W-22)
            // ==========================================
            'employee_tasks' => [
                'id'                    => 'wdg-ess-02',
                'code'                  => 'employee_tasks',
                'title'                 => 'My Workplace Action Items & Tasks',
                'description'           => 'Personal daily task checklist with priority badges (High, Medium, Low) and reactive completion.',
                'category'              => 'ess',
                'view_path'             => 'dashboard/widgets/employee_tasks',
                'icon'                  => 'check-square',
                'module_code'           => 'dashboard',
                'permission_code'       => 'dashboard.view',
                'target_roles'          => ['*'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 22,
                'grid_width'            => 'half',
                'data_dependencies'     => ['user_tasks_list'],
                'authoritative_service' => 'App\Services\DashboardService',
            ],

            // ==========================================
            // 23. SHIFT SWAP TERMINAL (W-22, W-24)
            // ==========================================
            'shift_swap_terminal' => [
                'id'                    => 'wdg-ops-02',
                'code'                  => 'shift_swap_terminal',
                'title'                 => 'Shift Exchange & Swap Requests',
                'description'           => 'Peer shift swap requests awaiting supervisor endorsement and schedule conflict validation.',
                'category'              => 'operations',
                'view_path'             => 'dashboard/widgets/shift_swap_terminal',
                'icon'                  => 'repeat',
                'module_code'           => 'rostering',
                'permission_code'       => 'rostering.view',
                'target_roles'          => ['manager', 'hr_admin', 'company_admin'],
                'min_subscription_plan' => 'professional',
                'default_status'        => 1,
                'default_sort_order'    => 24,
                'grid_width'            => 'half',
                'data_dependencies'     => ['pending_shift_swaps'],
                'authoritative_service' => 'App\Services\RosterService',
            ],

            // ==========================================
            // 25. ORGANOGRAM HIERARCHY PREVIEW (W-23, W-25)
            // ==========================================
            'organogram_preview' => [
                'id'                    => 'wdg-anl-01',
                'code'                  => 'organogram_preview',
                'title'                 => 'Company Organogram & Hierarchy',
                'description'           => 'Department leadership snapshot showing departmental heads and direct reporting lines.',
                'category'              => 'analytics',
                'view_path'             => 'dashboard/widgets/organogram_preview',
                'icon'                  => 'git-pull-request',
                'module_code'           => 'directory',
                'permission_code'       => 'directory.view',
                'target_roles'          => ['company_admin', 'hr_admin', 'manager'],
                'min_subscription_plan' => 'professional',
                'default_status'        => 1,
                'default_sort_order'    => 25,
                'grid_width'            => 'half',
                'data_dependencies'     => ['department_heads_summary'],
                'authoritative_service' => 'App\Services\OrganogramService',
            ],

            // ==========================================
            // 26. PERFORMANCE GOALS & REVIEWS (W-25, W-26)
            // ==========================================
            'performance_goals' => [
                'id'                    => 'wdg-anl-02',
                'code'                  => 'performance_goals',
                'title'                 => 'Performance Review Cycles & OKRs',
                'description'           => 'Active appraisal cycles, quarterly goal completion progress, and self-review deadlines.',
                'category'              => 'analytics',
                'view_path'             => 'dashboard/widgets/performance_goals',
                'icon'                  => 'target',
                'module_code'           => 'performance',
                'permission_code'       => 'performance.view',
                'target_roles'          => ['company_admin', 'hr_admin', 'manager', 'employee'],
                'min_subscription_plan' => 'enterprise',
                'default_status'        => 1,
                'default_sort_order'    => 26,
                'grid_width'            => 'half',
                'data_dependencies'     => ['active_performance_cycle', 'goals_progress'],
                'authoritative_service' => 'App\Services\PerformanceService',
            ],

            // ==========================================
            // 27. TRAINING & CERTIFICATIONS (W-26, W-27)
            // ==========================================
            'training_certifications' => [
                'id'                    => 'wdg-ops-03',
                'code'                  => 'training_certifications',
                'title'                 => 'Upcoming Training Programs & Certifications',
                'description'           => 'Enrolled professional development courses, mandatory compliance sessions, and expiring certificates.',
                'category'              => 'operations',
                'view_path'             => 'dashboard/widgets/training_certifications',
                'icon'                  => 'graduation-cap',
                'module_code'           => 'training',
                'permission_code'       => 'training.view',
                'target_roles'          => ['hr_admin', 'company_admin', 'employee'],
                'min_subscription_plan' => 'enterprise',
                'default_status'        => 1,
                'default_sort_order'    => 27,
                'grid_width'            => 'half',
                'data_dependencies'     => ['upcoming_trainings'],
                'authoritative_service' => 'App\Services\DashboardService',
            ],

            // ==========================================
            // 28. COMPLIANCE & DOCUMENT EXPIRY (W-27, W-28)
            // ==========================================
            'compliance_doc_expiry' => [
                'id'                    => 'wdg-ops-04',
                'code'                  => 'compliance_doc_expiry',
                'title'                 => 'Document Expiry & Compliance Alerts',
                'description'           => 'Immigration visas, passports, labor contracts, and professional licenses expiring within 30-60 days.',
                'category'              => 'operations',
                'view_path'             => 'dashboard/widgets/compliance_doc_expiry',
                'icon'                  => 'alert-triangle',
                'module_code'           => 'directory',
                'permission_code'       => 'directory.view',
                'target_roles'          => ['hr_admin', 'company_admin', 'auditor'],
                'min_subscription_plan' => 'professional',
                'default_status'        => 1,
                'default_sort_order'    => 28,
                'grid_width'            => 'half',
                'data_dependencies'     => ['expiring_documents_list'],
                'authoritative_service' => 'App\Services\DashboardService',
            ],

            // ==========================================
            // 29. ATTENDANCE OVERVIEW: 12-CARD MASTER KPI DECK
            // ==========================================
            'attendance_overview_kpis' => [
                'id'                    => 'wdg-att-10',
                'code'                  => 'attendance_overview_kpis',
                'title'                 => 'Attendance Master Overview KPI Deck',
                'description'           => 'Complete 12-card overview KPI deck: Headcount, Present, Absent, Late, Early Out, Half Day, Leave, Holiday, Weekly Off, Missing Punch, Worked & OT Hours.',
                'category'              => 'attendance',
                'view_path'             => 'dashboard/widgets/attendance_overview_kpis',
                'icon'                  => 'layout-grid',
                'module_code'           => 'attendance',
                'permission_code'       => 'attendance.view',
                'target_roles'          => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'branch_manager', 'manager'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 29,
                'grid_width'            => 'full',
                'data_dependencies'     => ['attendance_overview_stats'],
                'authoritative_service' => 'App\Services\AttendanceRuleEngine',
            ],

            // ==========================================
            // 30. ATTENDANCE SINGLE PART: PRESENT HEADCOUNT & RATE
            // ==========================================
            'attendance_card_present' => [
                'id'                    => 'wdg-att-11',
                'code'                  => 'attendance_card_present',
                'title'                 => 'Today\'s Workforce Presence',
                'description'           => 'Single metric card displaying today\'s active staff present headcount and overall presence rate percentage.',
                'category'              => 'kpi',
                'view_path'             => 'dashboard/widgets/attendance_card_present',
                'icon'                  => 'check-circle-2',
                'module_code'           => 'attendance',
                'permission_code'       => 'attendance.view',
                'target_roles'          => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'branch_manager', 'manager'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 30,
                'grid_width'            => 'quarter',
                'data_dependencies'     => ['attendance_overview_stats'],
                'authoritative_service' => 'App\Services\AttendanceRuleEngine',
            ],

            // ==========================================
            // 31. ATTENDANCE SINGLE PART: LATE ARRIVALS & GRACE
            // ==========================================
            'attendance_card_late' => [
                'id'                    => 'wdg-att-12',
                'code'                  => 'attendance_card_late',
                'title'                 => 'Today\'s Late Arrivals',
                'description'           => 'Single metric card displaying count of employees clocking in after the configured shift grace period.',
                'category'              => 'kpi',
                'view_path'             => 'dashboard/widgets/attendance_card_late',
                'icon'                  => 'clock',
                'module_code'           => 'attendance',
                'permission_code'       => 'attendance.view',
                'target_roles'          => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'branch_manager', 'manager'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 31,
                'grid_width'            => 'quarter',
                'data_dependencies'     => ['attendance_overview_stats', 'attendance_policy_settings'],
                'authoritative_service' => 'App\Services\AttendanceRuleEngine',
            ],

            // ==========================================
            // 32. ATTENDANCE SINGLE PART: UNACCOUNTED ABSENCES
            // ==========================================
            'attendance_card_absent' => [
                'id'                    => 'wdg-att-13',
                'code'                  => 'attendance_card_absent',
                'title'                 => 'Today\'s Unaccounted Absences',
                'description'           => 'Single metric card displaying count of unaccounted employee absences today.',
                'category'              => 'kpi',
                'view_path'             => 'dashboard/widgets/attendance_card_absent',
                'icon'                  => 'x-circle',
                'module_code'           => 'attendance',
                'permission_code'       => 'attendance.view',
                'target_roles'          => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'branch_manager', 'manager'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 32,
                'grid_width'            => 'quarter',
                'data_dependencies'     => ['attendance_overview_stats'],
                'authoritative_service' => 'App\Services\AttendanceRuleEngine',
            ],

            // ==========================================
            // 33. ATTENDANCE SINGLE PART: MISSING PUNCH
            // ==========================================
            'attendance_card_missing_punch' => [
                'id'                    => 'wdg-att-14',
                'code'                  => 'attendance_card_missing_punch',
                'title'                 => 'Missing Punch Irregularities',
                'description'           => 'Single metric card tracking single IN or single OUT punch irregularities needing reconciliation.',
                'category'              => 'kpi',
                'view_path'             => 'dashboard/widgets/attendance_card_missing_punch',
                'icon'                  => 'alert-triangle',
                'module_code'           => 'attendance',
                'permission_code'       => 'attendance.view',
                'target_roles'          => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'branch_manager', 'manager'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 33,
                'grid_width'            => 'quarter',
                'data_dependencies'     => ['attendance_overview_stats'],
                'authoritative_service' => 'App\Services\AttendanceRuleEngine',
            ],

            // ==========================================
            // 34. ATTENDANCE SINGLE PART: WORKED HOURS & OVERTIME
            // ==========================================
            'attendance_card_hours_ot' => [
                'id'                    => 'wdg-att-15',
                'code'                  => 'attendance_card_hours_ot',
                'title'                 => 'Productive Hours & Overtime Meter',
                'description'           => 'Aggregate card displaying today\'s net productive worked hours alongside payable overtime hours.',
                'category'              => 'kpi',
                'view_path'             => 'dashboard/widgets/attendance_card_hours_ot',
                'icon'                  => 'trending-up',
                'module_code'           => 'attendance',
                'permission_code'       => 'attendance.view',
                'target_roles'          => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'branch_manager', 'manager', 'finance'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 34,
                'grid_width'            => 'half',
                'data_dependencies'     => ['attendance_overview_stats'],
                'authoritative_service' => 'App\Services\AttendanceRuleEngine',
            ],

            // ==========================================
            // 35. LIVE WORKFORCE ACTIVITY HIGHLIGHTS
            // ==========================================
            'attendance_live_activity' => [
                'id'                    => 'wdg-att-16',
                'code'                  => 'attendance_live_activity',
                'title'                 => 'Today\'s Live Workforce Activity Highlights',
                'description'           => 'Executive preview table of today\'s live employee punch arrivals, worked hours, and status badges with fast actions.',
                'category'              => 'operations',
                'view_path'             => 'dashboard/widgets/attendance_live_activity',
                'icon'                  => 'calendar-check',
                'module_code'           => 'attendance',
                'permission_code'       => 'attendance.view',
                'target_roles'          => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'branch_manager', 'manager'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 35,
                'grid_width'            => 'full',
                'data_dependencies'     => ['attendance_today_logs'],
                'authoritative_service' => 'App\Services\AttendanceRuleEngine',
            ],

            // ==========================================
            // 36. DEPARTMENT-WISE ATTENDANCE BREAKDOWN
            // ==========================================
            'attendance_department_breakdown' => [
                'id'                    => 'wdg-att-17',
                'code'                  => 'attendance_department_breakdown',
                'title'                 => 'Department-Wise Attendance Breakdown',
                'description'           => 'Live departmental presence rate progress bars, total staff, present, late, on-leave, and absent distribution.',
                'category'              => 'overview',
                'view_path'             => 'dashboard/widgets/attendance_department_breakdown',
                'icon'                  => 'bar-chart-2',
                'module_code'           => 'attendance',
                'permission_code'       => 'attendance.view',
                'target_roles'          => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'branch_manager'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 7,
                'grid_width'            => 'half',
                'data_dependencies'     => ['attendance_dept_breakdown'],
                'authoritative_service' => 'App\Services\AttendanceRuleEngine',
            ],

            // ==========================================
            // 37. KEY EMPLOYEE ATTENDANCE ROSTER
            // ==========================================
            'attendance_key_roster' => [
                'id'                    => 'wdg-att-18',
                'code'                  => 'attendance_key_roster',
                'title'                 => 'Key Employee Attendance Roster',
                'description'           => 'Stream of key staff members showing avatar, check-in punch timestamp, and color-coded status badge.',
                'category'              => 'operations',
                'view_path'             => 'dashboard/widgets/attendance_key_roster',
                'icon'                  => 'users',
                'module_code'           => 'attendance',
                'permission_code'       => 'attendance.view',
                'target_roles'          => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'branch_manager', 'manager'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 37,
                'grid_width'            => 'half',
                'data_dependencies'     => ['attendance_today_logs'],
                'authoritative_service' => 'App\Services\AttendanceRuleEngine',
            ],

            // ==========================================
            // 38. ATTENDANCE REGULARIZATION ACTION QUEUE
            // ==========================================
            'attendance_regularization_queue' => [
                'id'                    => 'wdg-att-19',
                'code'                  => 'attendance_regularization_queue',
                'title'                 => 'Attendance Regularization Action Queue',
                'description'           => 'Pending attendance corrections and punch discrepancy approvals with inline one-click approve/reject actions.',
                'category'              => 'overview',
                'view_path'             => 'dashboard/widgets/attendance_regularization_queue',
                'icon'                  => 'shield-alert',
                'module_code'           => 'attendance',
                'permission_code'       => 'attendance.regularize_approve',
                'target_roles'          => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'branch_manager', 'manager'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 38,
                'grid_width'            => 'half',
                'data_dependencies'     => ['attendance_pending_corrections'],
                'authoritative_service' => 'App\Models\AttendanceModel',
            ],

            // ==========================================
            // 39. ACTIVE ATTENDANCE POLICY SUMMARY
            // ==========================================
            'attendance_policy_summary' => [
                'id'                    => 'wdg-att-20',
                'code'                  => 'attendance_policy_summary',
                'title'                 => 'Active Attendance Policy Engine Summary',
                'description'           => 'Summary of active shift timing, grace period buffer, half-day threshold, overtime multiplier, geofence radius, and weekend rules.',
                'category'              => 'attendance',
                'view_path'             => 'dashboard/widgets/attendance_policy_summary',
                'icon'                  => 'sliders',
                'module_code'           => 'attendance',
                'permission_code'       => 'attendance.view',
                'target_roles'          => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'branch_manager', 'manager'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 39,
                'grid_width'            => 'half',
                'data_dependencies'     => ['attendance_policy_settings'],
                'authoritative_service' => 'App\Models\AttendanceModel',
            ],

            // ==========================================
            // 40. TODAY'S LATE ARRIVALS ROSTER
            // ==========================================
            'attendance_late_arrivals' => [
                'id'                    => 'wdg-att-21',
                'code'                  => 'attendance_late_arrivals',
                'title'                 => 'Today\'s Late Arrivals Roster',
                'description'           => 'Live list of employees who checked in late today with their check-in time and exact delay minutes.',
                'category'              => 'attendance',
                'view_path'             => 'dashboard/widgets/attendance_late_arrivals',
                'icon'                  => 'clock',
                'module_code'           => 'attendance',
                'permission_code'       => 'attendance.view',
                'target_roles'          => ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'branch_manager', 'manager'],
                'min_subscription_plan' => 'starter',
                'default_status'        => 1,
                'default_sort_order'    => 40,
                'grid_width'            => 'half',
                'data_dependencies'     => ['attendance_today_logs', 'attendance_overview_stats'],
                'authoritative_service' => 'App\Services\AttendanceRuleEngine',
            ],
        ];
    }

    /**
     * Get list of all registered widget definitions formatted for DB seeding
     */
    public static function getSeedingList(): array
    {
        $list = [];
        foreach (self::getMasterCatalog() as $w) {
            $list[] = [
                'id'                    => $w['id'],
                'code'                  => $w['code'],
                'title'                 => $w['title'],
                'description'           => $w['description'],
                'category'              => $w['category'],
                'view_path'             => $w['view_path'],
                'icon'                  => $w['icon'],
                'module_code'           => $w['module_code'],
                'permission_code'       => $w['permission_code'],
                'target_roles'          => json_encode($w['target_roles']),
                'min_subscription_plan' => $w['min_subscription_plan'],
                'default_status'        => $w['default_status'],
                'default_sort_order'    => $w['default_sort_order'],
                'grid_width'            => $w['grid_width'],
            ];
        }
        return $list;
    }

    /**
     * Get a specific widget definition by code
     */
    public static function getByCode(string $code): ?array
    {
        $catalog = self::getMasterCatalog();
        foreach ($catalog as $key => $def) {
            if ($def['code'] === $code || $key === $code) {
                return $def;
            }
        }
        return null;
    }

    /**
     * Resolve the approved category group for a widget by its code, id, or catalog key.
     * Mappings correspond to the approved 4 Dashboard categories (Phase 2 & Phase 3):
     * 1. Overview (Default)
     * 2. Attendance & Shifts
     * 3. Leaves & Roster
     * 4. Payroll & Compliance
     */
    public static function resolveCategoryGroup(string $widgetCodeOrId): string
    {
        static $map = [
            // Overview Group (15 widgets)
            'company_executive_kpis'          => self::CATEGORY_GROUP_OVERVIEW,
            'executive_kpis'                  => self::CATEGORY_GROUP_OVERVIEW,
            'wdg-kpi-01'                      => self::CATEGORY_GROUP_OVERVIEW,
            'company_department_distribution' => self::CATEGORY_GROUP_OVERVIEW,
            'department_distribution'         => self::CATEGORY_GROUP_OVERVIEW,
            'wdg-wfk-01'                      => self::CATEGORY_GROUP_OVERVIEW,
            'company_pending_approvals'       => self::CATEGORY_GROUP_OVERVIEW,
            'pending_approvals'               => self::CATEGORY_GROUP_OVERVIEW,
            'wdg-app-01'                      => self::CATEGORY_GROUP_OVERVIEW,
            'manager_team_approvals'          => self::CATEGORY_GROUP_OVERVIEW,
            'team_approvals'                  => self::CATEGORY_GROUP_OVERVIEW,
            'wdg-mgr-03'                      => self::CATEGORY_GROUP_OVERVIEW,
            'attendance_regularization_queue' => self::CATEGORY_GROUP_OVERVIEW,
            'wdg-att-19'                      => self::CATEGORY_GROUP_OVERVIEW,
            'manager_team_overview'           => self::CATEGORY_GROUP_OVERVIEW,
            'team_overview'                   => self::CATEGORY_GROUP_OVERVIEW,
            'wdg-mgr-01'                      => self::CATEGORY_GROUP_OVERVIEW,
            'employee_quick_actions'          => self::CATEGORY_GROUP_OVERVIEW,
            'wdg-ess-01'                      => self::CATEGORY_GROUP_OVERVIEW,
            'employee_tasks'                  => self::CATEGORY_GROUP_OVERVIEW,
            'wdg-ess-02'                      => self::CATEGORY_GROUP_OVERVIEW,
            'employee_recent_notices'         => self::CATEGORY_GROUP_OVERVIEW,
            'notices_bulletin'                => self::CATEGORY_GROUP_OVERVIEW,
            'wdg-emp-04'                      => self::CATEGORY_GROUP_OVERVIEW,
            'branch_celebrations'             => self::CATEGORY_GROUP_OVERVIEW,
            'wdg-soc-01'                      => self::CATEGORY_GROUP_OVERVIEW,
            'organogram_preview'              => self::CATEGORY_GROUP_OVERVIEW,
            'wdg-anl-01'                      => self::CATEGORY_GROUP_OVERVIEW,
            'performance_goals'               => self::CATEGORY_GROUP_OVERVIEW,
            'wdg-anl-02'                      => self::CATEGORY_GROUP_OVERVIEW,
            'training_certifications'         => self::CATEGORY_GROUP_OVERVIEW,
            'wdg-ops-03'                      => self::CATEGORY_GROUP_OVERVIEW,
            'appadmin_platform_overview'      => self::CATEGORY_GROUP_OVERVIEW,
            'platform_overview'               => self::CATEGORY_GROUP_OVERVIEW,
            'wdg-appadmin-01'                 => self::CATEGORY_GROUP_OVERVIEW,
            'appadmin_company_fleet'          => self::CATEGORY_GROUP_OVERVIEW,
            'company_fleet'                   => self::CATEGORY_GROUP_OVERVIEW,
            'wdg-appadmin-02'                 => self::CATEGORY_GROUP_OVERVIEW,
            'attendance_department_breakdown' => self::CATEGORY_GROUP_OVERVIEW,
            'department_breakdown'            => self::CATEGORY_GROUP_OVERVIEW,
            'wdg-att-17'                      => self::CATEGORY_GROUP_OVERVIEW,

            // Attendance & Shifts Group (16 widgets)
            'employee_clock_card'             => self::CATEGORY_GROUP_ATTENDANCE,
            'clock_card'                      => self::CATEGORY_GROUP_ATTENDANCE,
            'wdg-att-01'                      => self::CATEGORY_GROUP_ATTENDANCE,
            'hr_attendance_exceptions'        => self::CATEGORY_GROUP_ATTENDANCE,
            'wdg-att-02'                      => self::CATEGORY_GROUP_ATTENDANCE,
            'attendance_trend'                => self::CATEGORY_GROUP_ATTENDANCE,
            'wdg-att-03'                      => self::CATEGORY_GROUP_ATTENDANCE,
            'live_attendance_stream'          => self::CATEGORY_GROUP_ATTENDANCE,
            'wdg-att-04'                      => self::CATEGORY_GROUP_ATTENDANCE,
            'manager_shift_roster_snapshot'   => self::CATEGORY_GROUP_ATTENDANCE,
            'shift_snapshot'                  => self::CATEGORY_GROUP_ATTENDANCE,
            'wdg-mgr-04'                      => self::CATEGORY_GROUP_ATTENDANCE,
            'shift_swap_terminal'             => self::CATEGORY_GROUP_ATTENDANCE,
            'wdg-ops-02'                      => self::CATEGORY_GROUP_ATTENDANCE,
            'attendance_overview_kpis'        => self::CATEGORY_GROUP_ATTENDANCE,
            'wdg-att-10'                      => self::CATEGORY_GROUP_ATTENDANCE,
            'attendance_card_present'         => self::CATEGORY_GROUP_ATTENDANCE,
            'wdg-att-11'                      => self::CATEGORY_GROUP_ATTENDANCE,
            'attendance_card_late'            => self::CATEGORY_GROUP_ATTENDANCE,
            'wdg-att-12'                      => self::CATEGORY_GROUP_ATTENDANCE,
            'attendance_card_absent'          => self::CATEGORY_GROUP_ATTENDANCE,
            'wdg-att-13'                      => self::CATEGORY_GROUP_ATTENDANCE,
            'attendance_card_missing_punch'   => self::CATEGORY_GROUP_ATTENDANCE,
            'wdg-att-14'                      => self::CATEGORY_GROUP_ATTENDANCE,
            'attendance_card_hours_ot'        => self::CATEGORY_GROUP_ATTENDANCE,
            'wdg-att-15'                      => self::CATEGORY_GROUP_ATTENDANCE,
            'attendance_live_activity'        => self::CATEGORY_GROUP_ATTENDANCE,
            'wdg-att-16'                      => self::CATEGORY_GROUP_ATTENDANCE,
            'attendance_key_roster'           => self::CATEGORY_GROUP_ATTENDANCE,
            'wdg-att-18'                      => self::CATEGORY_GROUP_ATTENDANCE,
            'attendance_policy_summary'       => self::CATEGORY_GROUP_ATTENDANCE,
            'wdg-att-20'                      => self::CATEGORY_GROUP_ATTENDANCE,
            'attendance_late_arrivals'        => self::CATEGORY_GROUP_ATTENDANCE,
            'wdg-att-21'                      => self::CATEGORY_GROUP_ATTENDANCE,

            // Leaves & Roster Group (3 widgets)
            'employee_leave_balances'         => self::CATEGORY_GROUP_LEAVES,
            'leave_balances'                  => self::CATEGORY_GROUP_LEAVES,
            'wdg-lev-01'                      => self::CATEGORY_GROUP_LEAVES,
            'staff_leave_calendar'            => self::CATEGORY_GROUP_LEAVES,
            'wdg-cal-01'                      => self::CATEGORY_GROUP_LEAVES,
            'department_leaves'               => self::CATEGORY_GROUP_LEAVES,
            'wdg-soc-02'                      => self::CATEGORY_GROUP_LEAVES,

            // Payroll & Compliance Group (4 widgets)
            'payroll_cost_summary'            => self::CATEGORY_GROUP_PAYROLL,
            'wdg-pay-01'                      => self::CATEGORY_GROUP_PAYROLL,
            'compliance_doc_expiry'           => self::CATEGORY_GROUP_PAYROLL,
            'wdg-ops-04'                      => self::CATEGORY_GROUP_PAYROLL,
            'appadmin_system_health'          => self::CATEGORY_GROUP_PAYROLL,
            'system_health'                   => self::CATEGORY_GROUP_PAYROLL,
            'wdg-appadmin-03'                 => self::CATEGORY_GROUP_PAYROLL,
            'appadmin_audit_stream'           => self::CATEGORY_GROUP_PAYROLL,
            'audit_stream'                    => self::CATEGORY_GROUP_PAYROLL,
            'wdg-appadmin-04'                 => self::CATEGORY_GROUP_PAYROLL,
        ];

        return $map[$widgetCodeOrId] ?? self::CATEGORY_GROUP_OVERVIEW;
    }

    /**
     * Get all category groups
     */
    public static function getCategoryGroups(): array
    {
        return self::CATEGORY_GROUPS;
    }
}
