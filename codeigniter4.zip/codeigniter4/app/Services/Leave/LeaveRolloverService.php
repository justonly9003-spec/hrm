<?php

namespace App\Services\Leave;

use App\Models\EmployeeModel;
use App\Models\LeaveTypeModel;
use App\Models\LeaveTransactionModel;
use App\Services\Rules\RuleResolver;
use App\Services\Leave\LeaveAccrualCalculator;
use App\Services\AuditService;

class LeaveRolloverService
{
    protected $db;
    protected EmployeeModel $employeeModel;
    protected LeaveTypeModel $leaveTypeModel;
    protected LeaveTransactionModel $transactionModel;

    public function __construct()
    {
        $this->db = \Config\Database::connect();
        $this->employeeModel = new EmployeeModel();
        $this->leaveTypeModel = new LeaveTypeModel();
        $this->transactionModel = new LeaveTransactionModel();
    }

    /**
     * Run Year-End Rollover for all active employees
     * Enforces strict year guard and carries forward negative balance deficits when permitted
     */
    public function runYearEndRollover(
        int $fromYear,
        int $toYear,
        ?string $companyId = null,
        string $performedBy = 'Year-End Rollover Wizard',
        bool $isDryRun = false
    ): array {
        $currYear = (int)date('Y');
        // 1. Strict Year Guard
        if ($fromYear < 2000 || $toYear < 2000 || $toYear !== ($fromYear + 1)) {
            $msg = "Invalid rollover years: destination year ({$toYear}) must be exactly consecutive to source year ({$fromYear}).";
            return [
                'success'         => false,
                'message'         => $msg,
                'summary'         => $msg,
                'processed'       => 0,
                'carried_forward' => 0.0,
                'expired'         => 0.0,
                'records'         => [],
            ];
        }

        // Prevent premature rollover before source year is completed (unless dry-run preview simulation)
        if (!$isDryRun && $fromYear >= $currYear) {
            $isLastDayOfYear = (date('m-d') === '12-31' && $fromYear === $currYear);
            if (!$isLastDayOfYear) {
                $msg = "Year-end rollover for {$fromYear} cannot be executed before the year has ended. The current year is still active.";
                return [
                    'success'         => false,
                    'message'         => $msg,
                    'summary'         => $msg,
                    'processed'       => 0,
                    'carried_forward' => 0.0,
                    'expired'         => 0.0,
                    'records'         => [],
                ];
            }
        }

        // Prevent double execution on an already closed fiscal year
        if (!$isDryRun && $companyId && $this->db->tableExists('leave_year_closings')) {
            $existingClosed = $this->db->table('leave_year_closings')
                ->where('company_id', $companyId)
                ->where('leave_year', $fromYear)
                ->where('status', 'Closed')
                ->get()
                ->getRowArray();
            if ($existingClosed) {
                $msg = "Year-end rollover for {$fromYear} has already been closed (Closing ID: {$existingClosed['id']}). To re-run rollover, the year must be formally reopened first.";
                return [
                    'success'         => false,
                    'message'         => $msg,
                    'summary'         => $msg,
                    'processed'       => 0,
                    'carried_forward' => 0.0,
                    'expired'         => 0.0,
                    'records'         => [],
                ];
            }
        }

        $empBuilder = $this->db->table('employees')
            ->select('employees.*, departments.name as department_name, designations.name as designation_name')
            ->join('departments', 'departments.id = employees.department_id', 'left')
            ->join('designations', 'designations.id = employees.designation_id', 'left')
            ->whereNotIn('employees.status', [
                EmployeeModel::STATUS_RESIGNED,
                EmployeeModel::STATUS_TERMINATED,
                EmployeeModel::STATUS_INACTIVE,
            ]);

        if ($companyId) {
            $empBuilder->where('employees.company_id', $companyId);
        }

        $employees = $empBuilder->get()->getResultArray();
        $leaveTypes = $this->leaveTypeModel->getActiveTypes($companyId);

        $processedRecords = [];
        $totalCarriedForward = 0.0;
        $totalExpired = 0.0;
        $errors = [];
        $alreadyProcessed = 0;

        $leaveService = new \App\Services\LeaveService();

        $companyVersionMap = [];
        $getClosingVersion = function (string $cId) use (&$companyVersionMap, $fromYear): int {
            if ($cId === '') {
                return 1;
            }
            if (!isset($companyVersionMap[$cId])) {
                $latest = null;
                if ($this->db->tableExists('leave_year_closings')) {
                    $latest = $this->db->table('leave_year_closings')
                        ->where('company_id', $cId)
                        ->where('leave_year', $fromYear)
                        ->orderBy('version', 'DESC')
                        ->get()
                        ->getRowArray();
                }
                $companyVersionMap[$cId] = $latest ? ((int)($latest['version'] ?? 1) + 1) : 1;
            }
            return $companyVersionMap[$cId];
        };

        foreach ($employees as $emp) {
            $empCompanyId = $emp['company_id'] ?: $companyId;
            $leaveRule = null;
            if ($empCompanyId) {
                try {
                    $leaveRule = (new RuleResolver())->resolve($empCompanyId, 'LEAVE', "{$toYear}-01-01", $emp);
                } catch (\Throwable $e) {
                    log_message('warning', 'rolloverBalances leaveRule resolution error: ' . $e->getMessage());
                    $leaveRule = null;
                }
            }

            $ruleTypes = $leaveRule ? ($leaveRule->has('entitlements') ? ($leaveRule->get('entitlements') ?: []) : ($leaveRule->params()['leave_types'] ?? [])) : [];

            foreach ($leaveTypes as $lt) {
                if (!empty($lt['company_id']) && (string)$lt['company_id'] !== (string)$empCompanyId) {
                    continue;
                }

                if ($isDryRun) {
                    $bal = $leaveService->getEmployeeBalanceReadOnly($emp['id'], $lt['id'], $fromYear, $lt);
                } else {
                    $bal = $leaveService->getEmployeeBalance($emp['id'], $lt['id'], $fromYear, $lt);
                }

                $avail = (float)($bal['available_balance'] ?? 0.0);
                // Year guard / negative balance handling: exactly 0 balance has nothing to roll over
                if ($avail == 0.0) {
                    continue;
                }

                $ruleType = null;
                $ltCode = strtoupper($lt['code'] ?? '');
                foreach ($ruleTypes as $rt) {
                    if (($rt['leave_type_id'] ?? '') === $lt['id'] 
                        || strtoupper($rt['leave_type_code'] ?? '') === $ltCode 
                        || ($rt['leaveTypeName'] ?? '') === $lt['name']) {
                        $ruleType = $rt;
                        break;
                    }
                }

                // calculateCarryForward properly handles negative balance ($avail < 0) as well as positive balance
                $cfResult = LeaveAccrualCalculator::calculateCarryForward($avail, $ruleType ?: $lt);
                $carriedForward = $cfResult['carried_forward'];
                $expired = $cfResult['expired'];
                $effectiveDate = "{$toYear}-01-01";

                if ($carriedForward == 0.0 && $expired == 0.0) {
                    continue;
                }

                $targetLeaveTypeId = $lt['id'];
                if (!empty($ruleType['carry_forward_leave_type_ids']) && is_array($ruleType['carry_forward_leave_type_ids'])) {
                    $targetLeaveTypeId = reset($ruleType['carry_forward_leave_type_ids']) ?: $lt['id'];
                }

                $closingVersion = $getClosingVersion((string)$empCompanyId);
                $srcHash = substr(md5((string)$lt['id']), 0, 8);
                $cfCycleNo = "ROLLOVER-CF-{$fromYear}-{$toYear}-v{$closingVersion}-{$srcHash}";
                $oldCfCycleNo = "ROLLOVER-CF-{$fromYear}-{$toYear}-{$srcHash}";
                $expCycleNo = "ROLLOVER-EXP-{$fromYear}-v{$closingVersion}-{$srcHash}";
                $oldExpCycleNo = "ROLLOVER-EXP-{$fromYear}-{$srcHash}";

                $recItem = [
                    'employee_id'        => $emp['id'],
                    'employee_name'      => trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')) ?: $emp['employee_code'],
                    'employee_code'      => $emp['employee_code'] ?? '',
                    'department_name'    => $emp['department_name'] ?? '',
                    'leave_type_id'      => $lt['id'],
                    'leave_type_name'    => $lt['name'],
                    'target_type_id'     => $targetLeaveTypeId,
                    'closing_balance'    => round($avail, 2),
                    'carried_forward'    => round($carriedForward, 2),
                    'expired'            => round($expired, 2),
                    'new_opening_balance'=> round($carriedForward, 2)
                ];

                if ($isDryRun) {
                    $totalCarriedForward += $carriedForward;
                    $totalExpired += $expired;
                    $processedRecords[] = $recItem;
                } else {
                    $expIdempotencyKey = "EXPIRE-{$empCompanyId}-{$emp['id']}-{$lt['id']}-{$fromYear}-v{$closingVersion}";
                    $cfIdempotencyKey = "ROLLOVER-{$empCompanyId}-{$emp['id']}-{$targetLeaveTypeId}-{$fromYear}-{$toYear}-v{$closingVersion}";

                    // Check if an unreversed Carry Forward or Expiration already exists from $fromYear to $toYear
                    $isAlreadyDone = false;
                    $reversedTxRows = $this->db->table('leave_transactions')
                        ->select('reversal_of')
                        ->where('company_id', $empCompanyId)
                        ->where('transaction_type', 'Reversal')
                        ->where('reversal_of IS NOT NULL')
                        ->get()->getResultArray();
                    $reversedTxIds = array_values(array_filter(array_column($reversedTxRows, 'reversal_of')));

                    if ($carriedForward != 0.0) {
                        $cfQuery = $this->db->table('leave_transactions')
                            ->where('company_id', $empCompanyId)
                            ->where('employee_id', $emp['id'])
                            ->where('leave_type_id', $targetLeaveTypeId)
                            ->where('leave_year', $toYear)
                            ->where('transaction_type', 'Carry Forward')
                            ->like('cycle_no', "ROLLOVER-CF-{$fromYear}-{$toYear}", 'after');
                        if (!empty($reversedTxIds)) {
                            $cfQuery->whereNotIn('id', $reversedTxIds);
                        }
                        if ($cfQuery->countAllResults() > 0) {
                            $isAlreadyDone = true;
                        }
                    } elseif ($expired > 0.0) {
                        $expQuery = $this->db->table('leave_transactions')
                            ->where('company_id', $empCompanyId)
                            ->where('employee_id', $emp['id'])
                            ->where('leave_type_id', $lt['id'])
                            ->where('leave_year', $fromYear)
                            ->where('transaction_type', 'Expiration')
                            ->like('cycle_no', "ROLLOVER-EXP-{$fromYear}", 'after');
                        if (!empty($reversedTxIds)) {
                            $expQuery->whereNotIn('id', $reversedTxIds);
                        }
                        if ($expQuery->countAllResults() > 0) {
                            $isAlreadyDone = true;
                        }
                    }

                    if ($isAlreadyDone) {
                        $alreadyProcessed++;
                        continue;
                    }

                    $this->db->transStart();
                    try {
                        $ruleVersion = method_exists($leaveRule, 'effectiveVersion') ? ($leaveRule->effectiveVersion() ?? 1) : 1;

                        // 1. Post Expiration
                        if ($expired > 0.0) {
                            $this->transactionModel->insert([
                                'id'               => 'tx-' . bin2hex(random_bytes(6)),
                                'company_id'       => $empCompanyId,
                                'employee_id'      => $emp['id'],
                                'leave_type_id'    => $lt['id'],
                                'leave_year'       => $fromYear,
                                'transaction_type' => 'Expiration',
                                'days'             => -$expired,
                                'cycle_no'         => $expCycleNo,
                                'idempotency_key'  => $expIdempotencyKey,
                                'policy_version'   => $ruleVersion,
                                'effective_date'   => "{$fromYear}-12-31",
                                'description'      => "Year-end quota expiration for {$fromYear} (v{$closingVersion})",
                                'performed_by'     => $performedBy,
                                'created_at'       => date('Y-m-d H:i:s'),
                            ]);
                        }

                        // 2. Post Carry Forward (positive surplus or negative deficit)
                        if ($carriedForward != 0.0) {
                            $this->transactionModel->insert([
                                'id'               => 'tx-' . bin2hex(random_bytes(6)),
                                'company_id'       => $empCompanyId,
                                'employee_id'      => $emp['id'],
                                'leave_type_id'    => $targetLeaveTypeId,
                                'leave_year'       => $toYear,
                                'transaction_type' => 'Carry Forward',
                                'days'             => $carriedForward,
                                'cycle_no'         => $cfCycleNo,
                                'idempotency_key'  => $cfIdempotencyKey,
                                'policy_version'   => $ruleVersion,
                                'effective_date'   => $effectiveDate,
                                'description'      => ($carriedForward < 0.0)
                                    ? "Negative balance carry-forward deficit from {$fromYear} (v{$closingVersion})"
                                    : "Carry forward from {$fromYear} to {$toYear} (v{$closingVersion})",
                                'performed_by'     => $performedBy,
                                'created_at'       => date('Y-m-d H:i:s'),
                            ]);

                            // Lock target balance row in $toYear
                            $targetBal = $this->db->query(
                                "SELECT * FROM leave_balances WHERE employee_id = ? AND leave_type_id = ? AND year = ? FOR UPDATE",
                                [$emp['id'], $targetLeaveTypeId, $toYear]
                            )->getRowArray();

                            if ($targetBal) {
                                $newCf = (float)($targetBal['carry_forward_days'] ?? 0.0) + $carriedForward;
                                $upData = [
                                    'carry_forward_days' => $newCf,
                                    'updated_at'         => date('Y-m-d H:i:s'),
                                ];
                                if ($this->db->fieldExists('carried_over', 'leave_balances')) {
                                    $upData['carried_over'] = (float)($targetBal['carried_over'] ?? 0.0) + $carriedForward;
                                }
                                $this->db->table('leave_balances')->where('id', $targetBal['id'])->update($upData);
                            } else {
                                $insertBal = [
                                    'id'                     => 'bal-' . bin2hex(random_bytes(6)),
                                    'employee_id'            => $emp['id'],
                                    'leave_type_id'          => $targetLeaveTypeId,
                                    'year'                   => $toYear,
                                    'opening_balance'        => 0.0,
                                    'allocated_days'         => 0.0,
                                    'accrued_days'           => 0.0,
                                    'carry_forward_days'     => $carriedForward,
                                    'approved_leave_days'    => 0.0,
                                    'pending_leave_days'     => 0.0,
                                    'unpaid_adjustment_days' => 0.0,
                                    'encashed_days'          => 0.0,
                                    'manual_adjustment_days' => 0.0,
                                    'created_at'             => date('Y-m-d H:i:s'),
                                    'updated_at'             => date('Y-m-d H:i:s')
                                ];
                                if ($this->db->fieldExists('carried_over', 'leave_balances')) {
                                    $insertBal['carried_over'] = $carriedForward;
                                }
                                $this->db->table('leave_balances')->insert($insertBal);
                            }
                        }

                        $this->db->transComplete();

                        if ($this->db->transStatus()) {
                            $totalCarriedForward += $carriedForward;
                            $totalExpired += $expired;
                            $processedRecords[] = $recItem;
                        } else {
                            $errors[] = "Failed transaction for employee {$emp['employee_code']} on {$lt['name']}.";
                        }
                    } catch (\Throwable $ex) {
                        $this->db->transRollback();
                        $errors[] = "Error for {$emp['employee_code']}: " . $ex->getMessage();
                    }
                }
            }
        }

        // Audit log
        if (!$isDryRun && count($processedRecords) > 0) {
            try {
                $auditService = new AuditService();
                $auditService->log(
                    $companyId,
                    $performedBy,
                    'leave',
                    'leave.year_end_rollover',
                    "rollover-{$fromYear}-{$toYear}",
                    null,
                    [
                        'from_year'        => $fromYear,
                        'to_year'          => $toYear,
                        'employees_count'  => count($employees),
                        'records_count'    => count($processedRecords),
                        'total_carried'    => $totalCarriedForward,
                        'total_expired'    => $totalExpired,
                    ],
                    "Completed Year-End Rollover from {$fromYear} to {$toYear}"
                );
            } catch (\Throwable $e) {
                log_message('error', 'runYearEndRollover audit error: ' . $e->getMessage());
            }
        }

        $procCount = count($processedRecords);
        $summary = "Year-end rollover from {$fromYear} to {$toYear} completed: {$procCount} records processed, {$totalCarriedForward} days carried forward, {$totalExpired} days expired.";

        // 4. Record Year Closing in leave_year_closings
        if (!$isDryRun && $this->db->tableExists('leave_year_closings')) {
            try {
                $closingCompanyId = (string)($companyId ?: ($employees[0]['company_id'] ?? ''));
                if (!empty($closingCompanyId)) {
                    $nextVersion = $getClosingVersion($closingCompanyId);
                    $closingId = 'lyc-' . bin2hex(random_bytes(6));
                    $closingCycleNo = "ROLLOVER-{$fromYear}-{$toYear}-v{$nextVersion}-" . date('Ymd-His');

                    $this->db->table('leave_year_closings')->insert([
                        'id'            => $closingId,
                        'company_id'    => $closingCompanyId,
                        'leave_year'    => $fromYear,
                        'cycle_no'      => $closingCycleNo,
                        'version'       => $nextVersion,
                        'status'        => 'Closed',
                        'closed_at'     => date('Y-m-d H:i:s'),
                        'closed_by'     => $performedBy,
                        'closing_notes' => "Rollover executed from {$fromYear} to {$toYear} (v{$nextVersion}). {$procCount} records processed.",
                        'summary_json'  => json_encode([
                            'from_year'        => $fromYear,
                            'to_year'          => $toYear,
                            'closing_version'  => $nextVersion,
                            'employees_count'  => count($employees),
                            'processed_count'  => $procCount,
                            'total_carried'    => round($totalCarriedForward, 2),
                            'total_expired'    => round($totalExpired, 2),
                            'executed_at'      => date('Y-m-d H:i:s'),
                            'executed_by'      => $performedBy,
                        ]),
                        'created_at'    => date('Y-m-d H:i:s'),
                        'updated_at'    => date('Y-m-d H:i:s'),
                    ]);
                }
            } catch (\Throwable $ce) {
                log_message('error', 'runYearEndRollover closing table error: ' . $ce->getMessage());
            }
        }

        return [
            'success'          => empty($errors),
            'message'          => $summary,
            'summary'          => $summary,
            'from_year'        => $fromYear,
            'to_year'          => $toYear,
            'is_dry_run'       => $isDryRun,
            'processed_count'  => $procCount,
            'already_processed'=> $alreadyProcessed,
            'total_carried'    => round($totalCarriedForward, 2),
            'total_expired'    => round($totalExpired, 2),
            'records'          => $processedRecords,
            'errors'           => $errors
        ];
    }

    /**
     * Reopen a closed leave year with atomic ledger reversals and audit trail.
     * Posts reversal transactions (transaction_type = 'Reversal', reversal_of = original row id)
     * for both Carry Forward and Expiration entries in one single transaction.
     */
    public function reopenYear(int $year, string $companyId, string $reopenedBy, string $reason): array
    {
        $reason = trim($reason);
        if ($reason === '') {
            return ['success' => false, 'message' => 'Mandatory reason is required to reopen a closed leave year.'];
        }

        if (!$this->db->tableExists('leave_year_closings')) {
            return ['success' => false, 'message' => 'leave_year_closings table does not exist.'];
        }

        $latestClosing = $this->db->table('leave_year_closings')
            ->where('company_id', $companyId)
            ->where('leave_year', $year)
            ->orderBy('version', 'DESC')
            ->get()
            ->getRowArray();

        if (!$latestClosing || $latestClosing['status'] !== 'Closed') {
            return [
                'success' => false,
                'message' => "Leave year {$year} is not in Closed status."
            ];
        }

        $closingVersion = (int)($latestClosing['version'] ?? 1);
        $summaryJson = !empty($latestClosing['summary_json']) ? json_decode($latestClosing['summary_json'], true) : [];
        $toYear = isset($summaryJson['to_year']) ? (int)$summaryJson['to_year'] : ($year + 1);

        // Fetch already reversed transaction IDs to prevent double-reversals
        $alreadyReversedRows = $this->db->table('leave_transactions')
            ->select('reversal_of')
            ->where('company_id', $companyId)
            ->where('transaction_type', 'Reversal')
            ->where('reversal_of IS NOT NULL', null, false)
            ->get()
            ->getResultArray();
        $reversedIdList = array_values(array_filter(array_column($alreadyReversedRows, 'reversal_of')));

        // Query original Carry Forward transactions from this closing
        $cfBuilder = $this->db->table('leave_transactions')
            ->where('company_id', $companyId)
            ->where('leave_year', $toYear)
            ->where('transaction_type', 'Carry Forward');
        if (!empty($reversedIdList)) {
            $cfBuilder->whereNotIn('id', $reversedIdList);
        }
        $cfBuilder->groupStart()
            ->like('cycle_no', "ROLLOVER-CF-{$year}-{$toYear}", 'after')
            ->orLike('idempotency_key', "ROLLOVER-{$companyId}-", 'after')
        ->groupEnd();
        $cfTransactions = $cfBuilder->get()->getResultArray();

        // Query original Expiration transactions from this closing
        $expBuilder = $this->db->table('leave_transactions')
            ->where('company_id', $companyId)
            ->where('leave_year', $year)
            ->where('transaction_type', 'Expiration');
        if (!empty($reversedIdList)) {
            $expBuilder->whereNotIn('id', $reversedIdList);
        }
        $expBuilder->groupStart()
            ->like('cycle_no', "ROLLOVER-EXP-{$year}", 'after')
            ->orLike('idempotency_key', "EXPIRE-{$companyId}-", 'after')
        ->groupEnd();
        $expTransactions = $expBuilder->get()->getResultArray();

        $this->db->transStart();

        $reversedCount = 0;
        $now = date('Y-m-d H:i:s');
        $today = date('Y-m-d');

        // 1. Post reversal for Carry Forward and restore leave_balances in $toYear
        foreach ($cfTransactions as $cfTx) {
            $origDays = (float)($cfTx['days'] ?? 0.0);
            $revDays = -$origDays;

            $revTxId = 'tx-' . bin2hex(random_bytes(6));
            $revIdempotencyKey = "REV-CF-{$companyId}-{$cfTx['employee_id']}-{$cfTx['leave_type_id']}-v{$closingVersion}-" . substr(md5($cfTx['id']), 0, 8);

            $this->transactionModel->insert([
                'id'               => $revTxId,
                'company_id'       => $companyId,
                'employee_id'      => $cfTx['employee_id'],
                'leave_type_id'    => $cfTx['leave_type_id'],
                'leave_year'       => $toYear,
                'transaction_type' => 'Reversal',
                'days'             => $revDays,
                'cycle_no'         => "REVERSAL-CF-{$year}-{$toYear}-v{$closingVersion}",
                'idempotency_key'  => $revIdempotencyKey,
                'reversal_of'      => $cfTx['id'],
                'policy_version'   => $cfTx['policy_version'] ?? 1,
                'effective_date'   => $today,
                'description'      => "Reversal of carry-forward from {$year} due to fiscal year reopening: {$reason}",
                'performed_by'     => $reopenedBy,
                'created_at'       => $now,
            ]);

            // Deduct original carry-forward from target year balance (with lock)
            $targetYear = (int)($cfTx['leave_year'] ?? $toYear);
            $targetBal = $this->db->query(
                "SELECT * FROM leave_balances WHERE employee_id = ? AND leave_type_id = ? AND year = ? FOR UPDATE",
                [$cfTx['employee_id'], $cfTx['leave_type_id'], $targetYear]
            )->getRowArray();

            if ($targetBal) {
                $newCf = max(0.0, (float)($targetBal['carry_forward_days'] ?? 0.0) - $origDays);
                $upData = [
                    'carry_forward_days' => $newCf,
                    'updated_at'         => $now,
                ];
                if ($this->db->fieldExists('carried_over', 'leave_balances')) {
                    $upData['carried_over'] = max(0.0, (float)($targetBal['carried_over'] ?? 0.0) - $origDays);
                }
                if ((float)($targetBal['opening_balance'] ?? 0.0) > 0.0) {
                    $upData['opening_balance'] = max(0.0, (float)$targetBal['opening_balance'] - $origDays);
                }
                $this->db->table('leave_balances')->where('id', $targetBal['id'])->update($upData);
            }

            $reversedCount++;
        }

        // 2. Post reversal for Expiration transactions in $year
        foreach ($expTransactions as $expTx) {
            $origDays = (float)($expTx['days'] ?? 0.0);
            $revDays = -$origDays; // Expiration was negative, reversal is positive

            $revTxId = 'tx-' . bin2hex(random_bytes(6));
            $revIdempotencyKey = "REV-EXP-{$companyId}-{$expTx['employee_id']}-{$expTx['leave_type_id']}-v{$closingVersion}-" . substr(md5($expTx['id']), 0, 8);

            $this->transactionModel->insert([
                'id'               => $revTxId,
                'company_id'       => $companyId,
                'employee_id'      => $expTx['employee_id'],
                'leave_type_id'    => $expTx['leave_type_id'],
                'leave_year'       => $year,
                'transaction_type' => 'Reversal',
                'days'             => $revDays,
                'cycle_no'         => "REVERSAL-EXP-{$year}-v{$closingVersion}",
                'idempotency_key'  => $revIdempotencyKey,
                'reversal_of'      => $expTx['id'],
                'policy_version'   => $expTx['policy_version'] ?? 1,
                'effective_date'   => $today,
                'description'      => "Reversal of quota expiration for {$year} due to fiscal year reopening: {$reason}",
                'performed_by'     => $reopenedBy,
                'created_at'       => $now,
            ]);

            $reversedCount++;
        }

        // 3. Mark closing status as Reopened
        $this->db->table('leave_year_closings')
            ->where('id', $latestClosing['id'])
            ->update([
                'status'        => 'Reopened',
                'reopened_at'   => $now,
                'reopened_by'   => $reopenedBy,
                'reopen_reason' => $reason,
                'updated_at'    => $now,
            ]);

        $this->db->transComplete();

        if (!$this->db->transStatus()) {
            return [
                'success' => false,
                'message' => "Database transaction failed while reversing ledger entries for reopening year {$year}."
            ];
        }

        // 4. Audit Log
        try {
            $auditService = new AuditService();
            $auditService->log(
                $companyId,
                $reopenedBy,
                'leave',
                'leave.year_reopened',
                $latestClosing['id'],
                null,
                [
                    'leave_year'      => $year,
                    'closing_id'      => $latestClosing['id'],
                    'closing_version' => $closingVersion,
                    'reversed_count'  => $reversedCount,
                    'reopened_by'     => $reopenedBy,
                    'reopen_reason'   => $reason,
                ],
                "Reopened leave year {$year} with {$reversedCount} ledger reversals: {$reason}"
            );
        } catch (\Throwable $e) {
            log_message('notice', 'reopenYear audit log: ' . $e->getMessage());
        }

        return [
            'success'        => true,
            'message'        => "Leave year {$year} has been successfully reopened with {$reversedCount} ledger reversals.",
            'closing_id'     => $latestClosing['id'],
            'version'        => $closingVersion,
            'reversed_count' => $reversedCount,
            'status'         => 'Reopened',
        ];
    }

    /**
     * Get the latest closing record for a company and year
     */
    public function getYearClosingStatus(int $year, string $companyId): ?array
    {
        if (!$this->db->tableExists('leave_year_closings')) {
            return null;
        }

        return $this->db->table('leave_year_closings')
            ->where('company_id', $companyId)
            ->where('leave_year', $year)
            ->orderBy('version', 'DESC')
            ->get()
            ->getRowArray();
    }
}
