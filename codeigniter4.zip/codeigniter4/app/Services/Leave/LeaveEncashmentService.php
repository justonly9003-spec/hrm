<?php

namespace App\Services\Leave;

use App\Models\EmployeeModel;
use App\Models\LeaveTypeModel;
use App\Models\LeaveTransactionModel;
use App\Services\Rules\RuleResolver;
use App\Services\Rules\RuleNotConfiguredException;
use App\Services\EmployeeSalaryService;
use App\Services\AttendanceService;
use App\Services\AuditService;

class LeaveEncashmentService
{
    protected $db;
    protected EmployeeModel $employeeModel;
    protected LeaveTypeModel $leaveTypeModel;
    protected LeaveTransactionModel $transactionModel;

    public function __construct()
    {
        $this->db = \Config\Database::connect();
        $this->employeeModel = new EmployeeModel();
        $this->leaveTypeModel = new LeaveTypeModel();
        $this->transactionModel = new LeaveTransactionModel();
    }

    /**
     * Calculate encashment cash value live based on Single Rule Store rules
     */
    public function calculateEncashmentAmount(
        string $employeeId,
        string $leaveTypeId,
        float $days,
        ?array $leaveTypeData = null,
        ?array $employeeData = null
    ): array {
        $asOfDate = date('Y-m-d');
        $activeSal = null;
        try {
            $salService = class_exists('\Config\Services') && method_exists('\Config\Services', 'salary')
                ? \Config\Services::salary()
                : new EmployeeSalaryService();
            $activeSal = $salService->getActiveSalary($employeeId, $asOfDate);
        } catch (\Throwable $e) {
            log_message('warning', 'calculateEncashmentAmount getActiveSalary error: ' . $e->getMessage());
            $activeSal = null;
        }

        $emp = $employeeData ?: $this->db->table('employees')->where('id', $employeeId)->get()->getRowArray();
        $companyId = $emp['company_id'] ?? '';
        if (empty($companyId) && function_exists('session') && session()->has('company_id')) {
            $companyId = session()->get('company_id');
        }
        if (empty($companyId)) {
            throw new RuleNotConfiguredException("Company ID is required to calculate encashment amount.");
        }

        // 1. Resolve daily rate divisor from PAYROLL_BASICS rule
        $pbRule = (new RuleResolver())->resolve($companyId, 'PAYROLL_BASICS', $asOfDate, $emp);
        $divisor = (int)$pbRule->get('daily_rate_divisor');
        if ($divisor <= 0) {
            throw new RuleNotConfiguredException("Valid daily_rate_divisor is required in PAYROLL_BASICS rule.", $companyId, 'PAYROLL_BASICS', $asOfDate);
        }
        $currencyCode = (string)$pbRule->get('currency_code');

        // 2. Resolve LEAVE entitlement rules
        $leaveRule = (new RuleResolver())->resolve($companyId, 'LEAVE', $asOfDate, $emp);
        $entitlements = $leaveRule->get('entitlements') ?: [];

        $lt = $leaveTypeData ?: $this->db->table('leave_types')->where('id', $leaveTypeId)->get()->getRowArray();
        $ltCode = strtoupper($lt['code'] ?? '');
        $ruleEnt = null;
        foreach ($entitlements as $ent) {
            if (strtoupper($ent['leave_type_code'] ?? '') === $ltCode || ($ent['leave_type_id'] ?? '') === $leaveTypeId) {
                $ruleEnt = $ent;
                break;
            }
        }

        $encashBasis = $ruleEnt['encashment_salary_basis'] ?? 'Basic Salary';
        $customDivisor = (!empty($ruleEnt['encashment_divisor']) && (int)$ruleEnt['encashment_divisor'] > 0)
            ? (int)$ruleEnt['encashment_divisor']
            : $divisor;

        // Authoritatively extract basic and gross salary without undefined variable errors
        $basic = (float)($activeSal['basic_salary'] ?? $emp['basic_salary'] ?? $emp['salary'] ?? 0.0);
        $gross = (float)($activeSal['gross_salary'] ?? $emp['gross_salary'] ?? $emp['current_salary'] ?? $basic);

        switch ($encashBasis) {
            case 'Gross Salary':
            case 'Daily Salary':
                $ratePerDay = $gross / (float)$customDivisor;
                break;
            case 'Fixed Rate':
                $fixedRate = (float)($ruleEnt['encashment_fixed_rate'] ?? 0.0);
                $ratePerDay = $fixedRate;
                break;
            default: // Basic Salary
                $ratePerDay = $basic / (float)$customDivisor;
                break;
        }

        // Round ONCE at the end of calculation per Rule 7
        $totalAmount = \App\Services\Rules\Money::round($ratePerDay * $days, $pbRule);
        $dailyRateRounded = \App\Services\Rules\Money::round($ratePerDay, $pbRule);

        return [
            'employee_id'    => $employeeId,
            'leave_type_id'  => $leaveTypeId,
            'days'           => $days,
            'rate_per_day'   => $dailyRateRounded,
            'daily_rate'     => $dailyRateRounded,
            'amount'         => $totalAmount,
            'total_amount'   => $totalAmount,
            'currency'       => $currencyCode,
            'basic'          => \App\Services\Rules\Money::round($basic, $pbRule),
            'basic_salary'   => \App\Services\Rules\Money::round($basic, $pbRule),
            'gross'          => \App\Services\Rules\Money::round($gross, $pbRule),
            'gross_salary'   => \App\Services\Rules\Money::round($gross, $pbRule),
            'salary_basis'   => $encashBasis,
            'divisor'        => $customDivisor,
        ];
    }

    /**
     * Get encashable days for an employee & leave type
     */
    public function getEncashableDays(string $employeeId, string $leaveTypeId, ?int $year = null): array
    {
        $year = $year ?: (int)date('Y');
        $lt = $this->db->table('leave_types')->where('id', $leaveTypeId)->get()->getRowArray();
        if (!$lt) {
            return ['encashable' => false, 'available_days' => 0, 'encashable_days' => 0, 'reason' => 'Leave type not found'];
        }

        $emp = $this->db->table('employees')->where('id', $employeeId)->get()->getRowArray();
        if (!$emp) {
            return ['encashable' => false, 'available_days' => 0, 'encashable_days' => 0, 'reason' => 'Employee not found'];
        }

        $companyId = $emp['company_id'] ?? '';
        $ruleEnt = null;
        if (!empty($companyId)) {
            try {
                $leaveRule = (new RuleResolver())->resolve($companyId, 'LEAVE', date('Y-m-d'), $emp);
                $entitlements = $leaveRule->get('entitlements') ?: [];
                $ltCode = strtoupper($lt['code'] ?? '');
                foreach ($entitlements as $ent) {
                    if (strtoupper($ent['leave_type_code'] ?? '') === $ltCode || ($ent['leave_type_id'] ?? '') === $leaveTypeId) {
                        $ruleEnt = $ent;
                        break;
                    }
                }
            } catch (\Throwable $e) {
                log_message('warning', 'getEncashableDays leaveRule error: ' . $e->getMessage());
            }
        }

        // Must read from RuleResolver entitlements without legacy leave_types fallback
        $isEncashable = !empty($ruleEnt['encashment_allowed']) || !empty($ruleEnt['is_encashable']);

        if (!$isEncashable) {
            return [
                'encashable'      => false,
                'available_days'  => 0,
                'encashable_days' => 0,
                'reason'          => "Leave type '{$lt['name']}' is not eligible for cash encashment under organization rules."
            ];
        }

        $leaveService = new \App\Services\LeaveService();
        $liveBal = $leaveService->getEmployeeBalanceReadOnly($employeeId, $leaveTypeId, $year);
        $avail = (float)($liveBal['available_balance'] ?? 0.0);

        $minBalance = isset($ruleEnt['encashment_min_balance_days']) && is_numeric($ruleEnt['encashment_min_balance_days'])
            ? (float)$ruleEnt['encashment_min_balance_days']
            : (isset($ruleEnt['min_balance_for_encashment']) && is_numeric($ruleEnt['min_balance_for_encashment'])
                ? (float)$ruleEnt['min_balance_for_encashment']
                : 0.0);

        $maxDays = isset($ruleEnt['encashment_max_days']) && is_numeric($ruleEnt['encashment_max_days'])
            ? (float)$ruleEnt['encashment_max_days']
            : (isset($ruleEnt['max_encashment_days']) && is_numeric($ruleEnt['max_encashment_days'])
                ? (float)$ruleEnt['max_encashment_days']
                : 0.0);

        // max_encashment_days is an annual limit. Track and deduct days already encashed in current year
        $alreadyEncashed = (float)($liveBal['encashed_days'] ?? 0.0);
        $surplus = max(0.0, $avail - $minBalance);
        $remainingAnnualLimit = ($maxDays > 0) ? max(0.0, $maxDays - $alreadyEncashed) : $surplus;
        $encashableDays = min($surplus, $remainingAnnualLimit);

        return [
            'encashable'             => true,
            'available_days'         => round($avail, 2),
            'min_balance'            => round($minBalance, 2),
            'max_limit'              => round($maxDays, 2),
            'already_encashed_year'  => round($alreadyEncashed, 2),
            'remaining_annual_limit' => round($remainingAnnualLimit, 2),
            'encashable_days'        => round($encashableDays, 2),
        ];
    }

    /**
     * Process cash encashment atomically with cycle_no idempotency and dry-run support
     */
    public function processEncashment(string $employeeId, string $leaveTypeId, float $days, string $processedBy, ?string $reason = null, string $status = 'Approved', bool $isDryRun = false): array
    {
        if ($days <= 0) {
            return ['success' => false, 'message' => 'Days to encash must be greater than zero.'];
        }

        $attService = new AttendanceService();
        if ($attService->isAttendanceSettled($employeeId, date('Y-m-d'))) {
            return [
                'success' => false,
                'message' => '422 Unprocessable Entity: Cannot process encashment. The current payroll cycle has already been settled and locked.'
            ];
        }

        $emp = $this->db->table('employees')->where('id', $employeeId)->get()->getRowArray();
        if (!$emp) {
            return ['success' => false, 'message' => 'Employee not found.'];
        }

        $leaveType = $this->db->table('leave_types')->where('id', $leaveTypeId)->get()->getRowArray();
        if (!$leaveType) {
            return ['success' => false, 'message' => 'Leave category not found.'];
        }

        if (!empty($leaveType['company_id']) && (string)$leaveType['company_id'] !== (string)($emp['company_id'] ?? '')) {
            return ['success' => false, 'message' => '403 Forbidden: Leave category belongs to another organization.'];
        }

        $encashInfo = $this->getEncashableDays($employeeId, $leaveTypeId);
        if (!$encashInfo['encashable']) {
            return ['success' => false, 'message' => $encashInfo['reason'] ?? 'Leave not encashable.'];
        }

        if ($days > $encashInfo['encashable_days']) {
            return [
                'success' => false,
                'message' => "Encashment of {$days} days exceeds the allowed encashable limit of {$encashInfo['encashable_days']} days."
            ];
        }

        $year = (int)date('Y');
        $cycleNo = "ENCASH-{$year}-" . date('Y-m') . "-{$leaveTypeId}";
        $idempotencyKey = "ENCASH-{$year}-" . date('Ym') . "-{$employeeId}-{$leaveTypeId}";

        // Idempotency check: prevent duplicate encashment posting in the same cycle
        if ($this->db->tableExists('leave_transactions')) {
            $existingTx = $this->db->table('leave_transactions')
                ->where('employee_id', $employeeId)
                ->where('leave_type_id', $leaveTypeId)
                ->where('transaction_type', 'Encashment')
                ->groupStart()
                    ->where('cycle_no', $cycleNo)
                    ->orWhere('idempotency_key', $idempotencyKey)
                ->groupEnd()
                ->countAllResults();

            if ($existingTx > 0) {
                return [
                    'success' => false,
                    'message' => "Encashment for cycle {$cycleNo} has already been processed for this employee and leave type."
                ];
            }
        }

        // Calculate amount
        $calc = $this->calculateEncashmentAmount($employeeId, $leaveTypeId, $days, $leaveType, $emp);
        $totalAmount = $calc['amount'];
        $isApproved = (strtolower(trim($status)) === 'approved');

        // Dry-run simulation: evaluate policies and return simulated financial impact without modifying state
        if ($isDryRun) {
            return [
                'success'       => true,
                'dry_run'       => true,
                'message'       => "Dry run simulation: Encashment of {$days} days for {$calc['currency']} " . number_format($totalAmount, 2) . " verified.",
                'encashment_id' => 'SIMULATED-' . bin2hex(random_bytes(6)),
                'amount'        => $totalAmount,
                'rate_per_day'  => $calc['rate_per_day'],
                'currency'      => $calc['currency'],
                'days'          => $days,
                'cycle_no'      => $cycleNo,
                'idempotency_key' => $idempotencyKey,
                'status'        => $isApproved ? 'Approved' : 'Pending'
            ];
        }

        $this->db->transStart();

        $balanceRow = $this->db->query(
            "SELECT * FROM leave_balances WHERE employee_id = ? AND leave_type_id = ? AND year = ? FOR UPDATE",
            [$employeeId, $leaveTypeId, $year]
        )->getRowArray();

        if (!$balanceRow) {
            $this->db->transRollback();
            return ['success' => false, 'message' => 'No leave quota balance record found for this employee and leave type.'];
        }

        if ($isApproved) {
            $this->db->query(
                "UPDATE leave_balances SET encashed_days = encashed_days + ? WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                [$days, $employeeId, $leaveTypeId, $year]
            );
        }

        $encashId = 'tx-' . bin2hex(random_bytes(6));
        $encashMasterId = 'ENCASH-' . bin2hex(random_bytes(6));

        if ($this->db->tableExists('leave_encashments')) {
            $this->db->table('leave_encashments')->insert([
                'id'            => $encashMasterId,
                'company_id'    => $emp['company_id'] ?? null,
                'employee_id'   => $employeeId,
                'leave_type_id' => $leaveTypeId,
                'year'          => $year,
                'encashed_days' => $days,
                'daily_rate'    => $calc['rate_per_day'],
                'basic_salary'  => $calc['basic'],
                'total_amount'  => $totalAmount,
                'status'        => $isApproved ? 'Approved' : 'Pending',
                'applied_at'    => date('Y-m-d H:i:s'),
                'approved_by'   => $isApproved ? $processedBy : null,
                'approved_at'   => $isApproved ? date('Y-m-d H:i:s') : null,
                'payout_month'  => date('Y-m'),
                'notes'         => $reason ?: "Leave encashment of {$days} days processed",
                'created_at'    => date('Y-m-d H:i:s'),
                'updated_at'    => date('Y-m-d H:i:s')
            ]);
        }

        if ($isApproved) {
            $txData = [
                'id'               => $encashId,
                'company_id'       => $emp['company_id'] ?? null,
                'employee_id'      => $employeeId,
                'leave_type_id'    => $leaveTypeId,
                'leave_year'       => $year,
                'transaction_type' => 'Encashment',
                'days'             => $days,
                'amount'           => $totalAmount,
                'reference_id'     => $encashMasterId,
                'cycle_no'         => $cycleNo,
                'idempotency_key'  => $idempotencyKey,
                'policy_version'   => 1,
                'description'      => $reason ?: "Encashment of {$days} days @ {$calc['currency']} {$calc['rate_per_day']}/day ({$calc['salary_basis']})",
                'performed_by'     => $processedBy,
                'created_at'       => date('Y-m-d H:i:s')
            ];
            try {
                $this->transactionModel->insert($txData);
            } catch (\Throwable $e) {
                if (str_contains($e->getMessage(), 'Duplicate entry') || str_contains($e->getMessage(), 'uq_leave_tx_idempotency') || str_contains($e->getMessage(), '1062')) {
                    $this->db->transRollback();
                    return [
                        'success' => false,
                        'message' => "Encashment for cycle {$cycleNo} has already been processed for this employee and leave type."
                    ];
                }
                throw $e;
            }
        }

        // Audit log
        try {
            $auditService = new AuditService();
            $auditService->log(
                $emp['company_id'] ?? null,
                $processedBy,
                'leave',
                $isApproved ? 'leave.encashed' : 'leave.encash_requested',
                $encashMasterId,
                null,
                [
                    'employee_id'   => $employeeId,
                    'leave_type_id' => $leaveTypeId,
                    'days'          => $days,
                    'amount'        => $totalAmount,
                    'status'        => $isApproved ? 'Approved' : 'Pending',
                    'reason'        => $reason
                ],
                $reason ?: "Encashment of {$days} days (" . ($isApproved ? 'Approved' : 'Pending') . ")"
            );
        } catch (\Throwable $e) {
            log_message('error', 'processEncashment audit error: ' . $e->getMessage());
        }

        $this->db->transComplete();

        $actionWord = $isApproved ? 'encashed' : 'requested for encashment';
        return [
            'success'       => $this->db->transStatus(),
            'message'       => "Successfully {$actionWord} {$days} days for {$calc['currency']} " . number_format($totalAmount, 2),
            'encashment_id' => $encashMasterId,
            'amount'        => $totalAmount,
            'rate_per_day'  => $calc['rate_per_day'],
            'currency'      => $calc['currency'],
            'days'          => $days,
            'status'        => $isApproved ? 'Approved' : 'Pending'
        ];
    }

    /**
     * Approve pending encashment request
     */
    public function approveEncashment(string $encashmentId, string $approvedBy): array
    {
        $this->db->transStart();

        $encashment = $this->db->table('leave_encashments')
            ->where('id', $encashmentId)
            ->get()->getRowArray();

        if (!$encashment) {
            $this->db->transRollback();
            return ['success' => false, 'message' => 'Encashment record not found.'];
        }

        if (strtolower($encashment['status']) !== 'pending') {
            $this->db->transRollback();
            return ['success' => false, 'message' => "Encashment is already {$encashment['status']}."];
        }

        $employeeId = $encashment['employee_id'];
        $leaveTypeId = $encashment['leave_type_id'];
        $days = (float)$encashment['encashed_days'];
        $year = (int)$encashment['year'];

        $this->db->query(
            "UPDATE leave_balances SET encashed_days = encashed_days + ? WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
            [$days, $employeeId, $leaveTypeId, $year]
        );

        $this->db->table('leave_encashments')
            ->where('id', $encashmentId)
            ->update([
                'status'      => 'Approved',
                'approved_by' => $approvedBy,
                'approved_at' => date('Y-m-d H:i:s'),
                'updated_at'  => date('Y-m-d H:i:s')
            ]);

        $emp = $this->db->table('employees')->where('id', $employeeId)->get()->getRowArray();
        $cycleNo = "ENCASH-{$year}-" . date('Y-m') . "-{$leaveTypeId}";
        $idempotencyKey = "ENCASH-{$year}-" . date('Ym') . "-{$employeeId}-{$leaveTypeId}";

        $txId = 'tx-' . bin2hex(random_bytes(6));
        $this->transactionModel->insert([
            'id'               => $txId,
            'company_id'       => $emp['company_id'] ?? null,
            'employee_id'      => $employeeId,
            'leave_type_id'    => $leaveTypeId,
            'leave_year'       => $year,
            'transaction_type' => 'Encashment',
            'days'             => $days,
            'amount'           => (float)$encashment['total_amount'],
            'reference_id'     => $encashmentId,
            'cycle_no'         => $cycleNo,
            'idempotency_key'  => $idempotencyKey,
            'policy_version'   => 1,
            'description'      => "Encashment approved of {$days} days",
            'performed_by'     => $approvedBy,
            'created_at'       => date('Y-m-d H:i:s')
        ]);

        $this->db->transComplete();

        return [
            'success' => $this->db->transStatus(),
            'message' => "Encashment {$encashmentId} successfully approved."
        ];
    }
}
