<?php

namespace App\Services\Leave;

use App\Models\EmployeeModel;
use App\Models\LeaveModel;
use App\Models\LeaveTypeModel;
use App\Models\LeaveBalanceModel;
use App\Models\LeaveTransactionModel;
use App\Models\NotificationModel;
use App\Services\Rules\RuleResolver;
use App\Services\Rules\RuleNotConfiguredException;
use App\Services\AttendanceService;
use App\Services\AuditService;
use App\Services\LeaveService;

class LeaveApplicationService
{
    protected $db;
    protected EmployeeModel $employeeModel;
    protected LeaveModel $leaveModel;
    protected LeaveTypeModel $leaveTypeModel;
    protected LeaveBalanceModel $balanceModel;
    protected LeaveTransactionModel $transactionModel;
    protected LeaveService $leaveService;

    public function __construct(?LeaveService $leaveService = null)
    {
        $this->db = \Config\Database::connect();
        $this->employeeModel = new EmployeeModel();
        $this->leaveModel = new LeaveModel();
        $this->leaveTypeModel = new LeaveTypeModel();
        $this->balanceModel = new LeaveBalanceModel();
        $this->transactionModel = new LeaveTransactionModel();
        $this->leaveService = $leaveService ?: new LeaveService();
    }

    /**
     * Lock and retrieve a single row using SELECT ... FOR UPDATE.
     */
    protected function lockRow(string $table, array $criteria): ?array
    {
        $builder = $this->db->table($table);
        foreach ($criteria as $k => $v) {
            $builder->where($k, $v);
        }
        $sql = $builder->getCompiledSelect() . ' FOR UPDATE';
        $query = $this->db->query($sql);
        return $query ? $query->getRowArray() : null;
    }

    protected function findEmployeeByActorId(string $actorId): ?array
    {
        $employee = $this->db->table('employees')
            ->where('id', $actorId)
            ->get()
            ->getRowArray();
        if ($employee) {
            return $employee;
        }

        $user = $this->db->table('users')
            ->select('employee_id')
            ->where('id', $actorId)
            ->get()
            ->getRowArray();
        if (empty($user['employee_id'])) {
            return null;
        }

        return $this->db->table('employees')
            ->where('id', $user['employee_id'])
            ->get()
            ->getRowArray() ?: null;
    }

    /**
     * Authoritative Service-Level Tenant Isolation Verification
     * Verifies that the acting user/employee belongs to the target employee's company
     * (Software App Admins excepted as defined in existing code).
     */
    public function verifyTenantIsolation(string $actingId, string $targetCompanyId, string $action = 'operation', string $actorLabel = 'User'): ?array
    {
        if (trim($actingId) === '' || trim($targetCompanyId) === '') {
            return null;
        }

        $actingCompanyId = '';
        $rawRole = 'employee';

        $userRow = $this->db->table('users')
            ->select('users.*, roles.code as role_code, roles.name as role_name')
            ->join('roles', 'roles.id = users.role_id', 'left')
            ->where('users.id', $actingId)
            ->get()->getRowArray();

        if (!$userRow) {
            $userRow = $this->db->table('users')
                ->select('users.*, roles.code as role_code, roles.name as role_name')
                ->join('roles', 'roles.id = users.role_id', 'left')
                ->where('users.email', $actingId)
                ->orWhere('users.username', $actingId)
                ->get()->getRowArray();
        }

        if ($userRow) {
            $actingCompanyId = (string)($userRow['company_id'] ?? '');
            $rawRole = $userRow['role_code'] ?? $userRow['role_name'] ?? $userRow['role'] ?? 'employee';
            if ($actingCompanyId === '' && !empty($userRow['employee_id'])) {
                $uEmp = $this->db->table('employees')->where('id', $userRow['employee_id'])->get()->getRowArray();
                if ($uEmp && !empty($uEmp['company_id'])) {
                    $actingCompanyId = (string)$uEmp['company_id'];
                }
            }
        } else {
            $empRow = $this->db->table('employees')->where('id', $actingId)->get()->getRowArray();
            if ($empRow) {
                $actingCompanyId = (string)($empRow['company_id'] ?? '');
                $uRow = $this->db->table('users')
                    ->select('users.*, roles.code as role_code, roles.name as role_name')
                    ->join('roles', 'roles.id = users.role_id', 'left')
                    ->where('users.employee_id', $empRow['id'])
                    ->get()->getRowArray();
                if ($uRow) {
                    $rawRole = $uRow['role_code'] ?? $uRow['role_name'] ?? $uRow['role'] ?? 'employee';
                    if ($actingCompanyId === '' && !empty($uRow['company_id'])) {
                        $actingCompanyId = (string)$uRow['company_id'];
                    }
                }
            }
        }

        if ($actingCompanyId === '' && function_exists('session') && session()->has('company_id')) {
            $actingCompanyId = (string)session()->get('company_id');
        }

        $permService = new \App\Services\PermissionService();
        $canonicalRole = $permService->canonicalizeRole($rawRole);
        $isSoftwareAdmin = ($canonicalRole === 'software_app_admin');

        if (!$isSoftwareAdmin && function_exists('session') && session()->has('user_id')) {
            $sessRole = session()->get('role') ?? session()->get('user_role') ?? '';
            if ($permService->canonicalizeRole($sessRole) === 'software_app_admin') {
                $isSoftwareAdmin = true;
            }
        }

        if (!$isSoftwareAdmin && !empty($actingCompanyId) && !empty($targetCompanyId) && $actingCompanyId !== $targetCompanyId) {
            return [
                'success' => false,
                'message' => "403 Forbidden: Cross-tenant {$action} denied. {$actorLabel} does not belong to the target employee organization."
            ];
        }

        return null;
    }

    /**
     * Resolve standard daily required work hours dynamically from shift or ATTENDANCE rule.
     * No literal fallback.
     */
    public function getStandardDailyHours(string $companyId, array $employee, string $date): float
    {
        if (!empty($employee['shift_id'])) {
            $shift = $this->db->table('shifts')->where('id', $employee['shift_id'])->get()->getRowArray();
            if ($shift) {
                $shiftHours = (float)($shift['total_hours'] ?? $shift['standard_hours'] ?? 0);
                if ($shiftHours > 0) {
                    return $shiftHours;
                }
            }
        }

        try {
            $attRule = (new RuleResolver())->resolve($companyId, 'ATTENDANCE', $date, $employee);
            $dailyReq = (float)$attRule->get('daily_required_hours');
            if ($dailyReq > 0) {
                return $dailyReq;
            }
        } catch (\Throwable $e) {
            log_message('warning', "getStandardDailyHours: failed to resolve ATTENDANCE rule for company {$companyId}: " . $e->getMessage());
        }

        throw new RuleNotConfiguredException(
            "Standard daily required work hours are not configured in ATTENDANCE rule for company {$companyId}.",
            $companyId,
            'ATTENDANCE',
            $date
        );
    }

    /**
     * Resolve whether sandwich rule is enabled for the company/entitlement from Single Rule Store.
     * Enforces that per-type sandwich_rule: false switches sandwich off, and respects applies_to_paid_only.
     */
    public function isSandwichEnabled(string $companyId, array $employee, array $ruleEnt, string $date, ?bool $isPaid = null): bool
    {
        return $this->leaveService->isSandwichEnabled($companyId, $employee, $ruleEnt, $date, $isPaid);
    }

    /**
     * Determine if Manager tier endorsement is required based on required approvers.
     * Required: true only when the tier-1 approver label ('Manager') is in required_approvers AND there is more than one approver.
     *
     * @param array $requiredApprovers
     * @return bool
     */
    public static function isManagerTierRequired(array $requiredApprovers): bool
    {
        return count($requiredApprovers) > 1 && in_array('Manager', $requiredApprovers, true);
    }

    /**
     * Determine auto-approval decision according to company policy and applicant class.
     * Normal employees applying for themselves can auto-approve via is_auto_approved or auto_approve_under_days.
     * Approver-class users (HR / Manager) applying for themselves CANNOT auto-approve when approval_required=true.
     * Backdated applications requiring approvers and emergency leave CANNOT auto-approve.
     *
     * @param array $context
     * @return bool
     */
    public static function determineAutoApproval(array $context): bool
    {
        $isBackdated = !empty($context['is_backdated']);
        $backdatedRole = trim((string)($context['backdated_role'] ?? ''));
        $isOwnApplication = !empty($context['is_own_application']);
        $isHR = !empty($context['is_hr']) || !empty($context['can_manage_leave']);
        $isManager = $isHR || !empty($context['is_manager']);
        $approvalRequired = !isset($context['approval_required']) || (bool)$context['approval_required'];
        $isAutoApprovedRule = !empty($context['is_auto_approved']);
        $autoApproveUnderDays = (float)($context['auto_approve_under_days'] ?? 0);
        $chargeableDays = (float)($context['chargeable_days'] ?? ($context['total_days'] ?? 0));
        $isEmergency = !empty($context['is_emergency']);

        $isAutoApproved = false;
        if ($isBackdated) {
            $isAutoApproved = false;
        } elseif ($isOwnApplication && ($isHR || $isManager) && $approvalRequired) {
            $isAutoApproved = false;
        } elseif (!$approvalRequired) {
            $isAutoApproved = true;
        } elseif ($isAutoApprovedRule) {
            $isAutoApproved = true;
        } elseif ($autoApproveUnderDays > 0 && $chargeableDays < $autoApproveUnderDays) {
            $isAutoApproved = true;
        }

        // Emergency leave cannot be auto-approved; requires explicit managerial/HR review
        if ($isEmergency) {
            $isAutoApproved = false;
        }

        return $isAutoApproved;
    }

    /**
     * Resolve tier condition from approval_workflow for given duration.
     * Handles fractional days (e.g. 0.5, 2.5, 7.5) so that no duration skips required tiers.
     */
    public static function resolveTierCondition(array $tierConditions, float $totalDays): ?array
    {
        if (empty($tierConditions)) {
            return null;
        }

        // Sort by min_days ASC
        usort($tierConditions, function ($a, $b) {
            return ((float)($a['min_days'] ?? 0)) <=> ((float)($b['min_days'] ?? 0));
        });

        // 1. Direct range match: min_days <= totalDays <= max_days
        foreach ($tierConditions as $tc) {
            $minD = (float)($tc['min_days'] ?? 0);
            $maxD = (float)($tc['max_days'] ?? 9999);
            if ($totalDays >= $minD && $totalDays <= $maxD) {
                return $tc;
            }
        }

        // 2. Ceiling match: for integer boundary policies like 1-2, 3-7, 8-999:
        // 0.5d -> ceil = 1 (matches 1-2)
        // 2.5d -> ceil = 3 (matches 3-7)
        // 7.5d -> ceil = 8 (matches 8-999)
        $ceilDays = (float)ceil($totalDays);
        foreach ($tierConditions as $tc) {
            $minD = (float)($tc['min_days'] ?? 0);
            $maxD = (float)($tc['max_days'] ?? 9999);
            if ($ceilDays >= $minD && $ceilDays <= $maxD) {
                return $tc;
            }
        }

        // 3. Boundary fallbacks
        $firstTier = $tierConditions[0];
        if ($totalDays < (float)($firstTier['min_days'] ?? 0)) {
            return $firstTier;
        }

        $lastTier = end($tierConditions);
        if ($totalDays > (float)($lastTier['max_days'] ?? 9999)) {
            return $lastTier;
        }

        return null;
    }

    /**
     * Resolve list of required approver roles for an application duration.
     * E.g.
     *   1-2 days (or <= 2d): ['Manager']
     *   3-7 days: ['Manager', 'HR Admin']
     *   8+ days: ['Manager', 'Department Head', 'HR Admin']
     *
     * @param array $approvalWorkflow
     * @param float $totalDays
     * @return array
     */
    public static function getRequiredApproversForDays(array $approvalWorkflow, float $totalDays): array
    {
        $tierConditions = $approvalWorkflow['tier_conditions'] ?? [];
        if (!empty($tierConditions) && is_array($tierConditions)) {
            $matchedTier = self::resolveTierCondition($tierConditions, $totalDays);
            if ($matchedTier && !empty($matchedTier['required_approvers']) && is_array($matchedTier['required_approvers'])) {
                return array_values($matchedTier['required_approvers']);
            }
        }

        if (($approvalWorkflow['workflow_type'] ?? '') === 'Multi-Tier') {
            $reqApprovers = $approvalWorkflow['required_approvers'] ?? [];
            if (!empty($reqApprovers) && is_array($reqApprovers)) {
                return array_values($reqApprovers);
            }
            return ['Manager', 'HR Admin'];
        }

        return ['Manager'];
    }

    /**
     * Resolve required approvers for an application, applying extra tiers for backdated applications.
     */
    public static function resolveRequiredApproversForApplication(array $approvalWorkflow, float $totalDays, bool $isBackdated = false, string $backdatedRole = ''): array
    {
        $requiredApprovers = self::getRequiredApproversForDays($approvalWorkflow, $totalDays);

        if ($isBackdated && !empty($backdatedRole)) {
            $normBackdatedRole = trim($backdatedRole);
            if (in_array($normBackdatedRole, ['Manager and HR', 'Manager & HR'], true)) {
                if (!in_array('Manager', $requiredApprovers, true)) {
                    array_unshift($requiredApprovers, 'Manager');
                }
                if (!in_array('HR Admin', $requiredApprovers, true) && !in_array('HR', $requiredApprovers, true) && !in_array('HR Administration', $requiredApprovers, true)) {
                    $requiredApprovers[] = 'HR Admin';
                }
            } elseif (in_array($normBackdatedRole, ['HR Only', 'HR'], true)) {
                // HR decides instead of the line manager, but the day-based tiers are never weakened:
                // if the base tiers already include HR (longer leaves), keep them unchanged.
                $hasHr = in_array('HR Admin', $requiredApprovers, true)
                    || in_array('HR', $requiredApprovers, true)
                    || in_array('HR Administration', $requiredApprovers, true);
                if (!$hasHr) {
                    // Swap only the Manager tier for HR; keep any other tier (e.g. Department Head).
                    $requiredApprovers = array_values(array_filter(
                        $requiredApprovers,
                        static fn($a) => $a !== 'Manager'
                    ));
                    $requiredApprovers[] = 'HR Admin';
                }
            } elseif (in_array($normBackdatedRole, ['Manager', 'Manager Only'], true)) {
                // Manager must be part of the chain, but HR / Department Head tiers are never removed.
                if (!in_array('Manager', $requiredApprovers, true)) {
                    array_unshift($requiredApprovers, 'Manager');
                }
            }
        }

        return $requiredApprovers;
    }

    /**
     * Check if a given user/employee ID belongs to Software App Admin.
     */
    protected function isSoftwareAppAdminFromId(string $id): bool
    {
        $permService = new \App\Services\PermissionService();
        $user = $this->db->table('users')
            ->select('users.*, roles.code as role_code, roles.name as role_name')
            ->join('roles', 'roles.id = users.role_id', 'left')
            ->where('users.id', $id)
            ->get()->getRowArray();
        if ($user) {
            $rawRole = $user['role_code'] ?? $user['role_name'] ?? $user['role'] ?? 'employee';
            return $permService->canonicalizeRole($rawRole) === 'software_app_admin';
        }
        return false;
    }

    /**
     * Build dynamic approval steps according to the required approvers resolved from company leave policy.
     */
    public function buildApprovalSteps(string $appId, array $requiredApprovers, array $emp, bool $isAutoApproved = false): array
    {
        $steps = [];
        $stepOrder = 1;
        $now = date('Y-m-d H:i:s');
        $status = $isAutoApproved ? 'Approved' : 'Pending';
        $comments = $isAutoApproved ? 'Auto-approved per company leave policy' : null;
        $actedAt = $isAutoApproved ? $now : null;

        foreach ($requiredApprovers as $role) {
            $normRole = trim((string)$role);
            if (strcasecmp($normRole, 'Manager') === 0 || strcasecmp($normRole, 'Line Manager') === 0) {
                $mgrId = $emp['reporting_to'] ?? $emp['manager_id'] ?? $emp['line_manager_id'] ?? $emp['reporting_manager_id'] ?? null;
                // If the employee is their own line manager, escalate to department head or HR
                if (!empty($mgrId) && (string)$mgrId === (string)($emp['id'] ?? '')) {
                    $deptId = $emp['department_id'] ?? null;
                    $deptRow = $deptId ? $this->db->table('departments')->where('id', $deptId)->get()->getRowArray() : null;
                    $deptHeadId = $deptRow['head_id'] ?? null;
                    if (!empty($deptHeadId) && (string)$deptHeadId !== (string)($emp['id'] ?? '')) {
                        $mgrId = $deptHeadId;
                    } else {
                        $mgrId = null; // Escalate to HR
                    }
                }
                $steps[] = [
                    'id'             => 'las-' . bin2hex(random_bytes(6)),
                    'application_id' => $appId,
                    'step_order'     => $stepOrder++,
                    'approver_id'    => $mgrId,
                    'approver_role'  => 'Line Manager',
                    'status'         => $status,
                    'comments'       => $comments,
                    'acted_at'       => $actedAt,
                    'created_at'     => $now,
                    'updated_at'     => $now,
                ];
            } elseif (strcasecmp($normRole, 'Department Head') === 0 || strcasecmp($normRole, 'Dept Head') === 0) {
                $deptHeadId = $emp['dept_head_id'] ?? null;
                $deptId = $emp['department_id'] ?? null;
                if (empty($deptHeadId) && !empty($deptId)) {
                    $deptRow = $this->db->table('departments')->where('id', $deptId)->get()->getRowArray();
                    $deptHeadId = $deptRow['head_id'] ?? null;
                }
                $steps[] = [
                    'id'             => 'las-' . bin2hex(random_bytes(6)),
                    'application_id' => $appId,
                    'step_order'     => $stepOrder++,
                    'approver_id'    => $deptHeadId,
                    'approver_role'  => 'Department Head',
                    'status'         => $status,
                    'comments'       => $comments,
                    'acted_at'       => $actedAt,
                    'created_at'     => $now,
                    'updated_at'     => $now,
                ];
            } elseif (strcasecmp($normRole, 'HR Admin') === 0 || strcasecmp($normRole, 'HR') === 0 || strcasecmp($normRole, 'HR Administration') === 0) {
                $steps[] = [
                    'id'             => 'las-' . bin2hex(random_bytes(6)),
                    'application_id' => $appId,
                    'step_order'     => $stepOrder++,
                    'approver_id'    => null,
                    'approver_role'  => 'HR Administration',
                    'status'         => $status,
                    'comments'       => $comments,
                    'acted_at'       => $actedAt,
                    'created_at'     => $now,
                    'updated_at'     => $now,
                ];
            } else {
                $steps[] = [
                    'id'             => 'las-' . bin2hex(random_bytes(6)),
                    'application_id' => $appId,
                    'step_order'     => $stepOrder++,
                    'approver_id'    => null,
                    'approver_role'  => $normRole,
                    'status'         => $status,
                    'comments'       => $comments,
                    'acted_at'       => $actedAt,
                    'created_at'     => $now,
                    'updated_at'     => $now,
                ];
            }
        }

        return $steps;
    }

    /**
     * Synchronize approved leave dates into attendance logs.
     * Protects existing Present, Late, Holiday, and Weekly Off statuses.
     */
    public function syncApprovedLeaveAttendance(string $employeeId, ?string $empCompanyId, string $fromDate, string $toDate, string $leaveTypeId, bool $isHalfDay = false, bool $sandwichRule = false, ?array $calcRes = null, ?bool $isPaid = null): void
    {
        $start = new \DateTime($fromDate);
        $end = new \DateTime($toDate);

        if ($calcRes === null) {
            $calcRes = $this->leaveService->calculateLeaveDays($employeeId, $fromDate, $toDate, $isHalfDay, $sandwichRule, null, $isPaid);
        }

        $chargeableDates = [];
        if (!empty($calcRes['breakdown'])) {
            foreach ($calcRes['breakdown'] as $b) {
                if (($b['chargeable'] ?? 0) > 0) {
                    $chargeableDates[$b['date']] = true;
                }
            }
        } else {
            $cTmp = clone $start;
            while ($cTmp <= $end) {
                $chargeableDates[$cTmp->format('Y-m-d')] = true;
                $cTmp->modify('+1 day');
            }
        }

        $curr = clone $start;
        while ($curr <= $end) {
            $dateStr = $curr->format('Y-m-d');
            if (empty($chargeableDates[$dateStr])) {
                $curr->modify('+1 day');
                continue;
            }

            $attExists = $this->db->table('attendance_logs')
                ->where('employee_id', $employeeId)
                ->where('date', $dateStr)
                ->get()
                ->getRowArray();

            if ($attExists) {
                $existingStatus = strtolower(trim((string)($attExists['status'] ?? '')));
                // Do not overwrite Holiday, Weekly Off, Present, or Late
                if (!in_array($existingStatus, ['holiday', 'weekly off', 'present', 'late'], true)) {
                    $this->db->table('attendance_logs')
                        ->where('id', $attExists['id'])
                        ->update([
                            'status'              => $isHalfDay ? 'Half Day' : 'On Leave',
                            'leave_type_id'       => $leaveTypeId,
                            'is_approved'         => 1,
                            'verification_method' => 'SYSTEM_LEAVE_SYNC',
                            'updated_at'          => date('Y-m-d H:i:s')
                        ]);
                }
            } else {
                $this->db->table('attendance_logs')->insert([
                    'id'                  => 'att-' . bin2hex(random_bytes(6)),
                    'company_id'          => $empCompanyId,
                    'employee_id'         => $employeeId,
                    'date'                => $dateStr,
                    'status'              => $isHalfDay ? 'Half Day' : 'On Leave',
                    'leave_type_id'       => $leaveTypeId,
                    'working_hours'       => 0.0,
                    'late_minutes'        => 0,
                    'is_approved'         => 1,
                    'verification_method' => 'SYSTEM_LEAVE_SYNC',
                    'created_at'          => date('Y-m-d H:i:s'),
                    'updated_at'          => date('Y-m-d H:i:s')
                ]);
            }
            $curr->modify('+1 day');
        }
    }

    /**
     * Apply for leave with concurrency protection, rule validation, and anti-race locks.
     */
    public function applyLeave(array $data): array
    {
        $employeeId       = $data['employee_id'] ?? null;
        $leaveTypeId      = $data['leave_type_id'] ?? null;
        $fromDate         = $data['from_date'] ?? $data['start_date'] ?? null;
        $toDate           = $data['to_date'] ?? $data['end_date'] ?? $fromDate;
        $reason           = trim($data['reason'] ?? '');
        $isHalfDay        = (!empty($data['is_half_day']) || (!empty($data['half_day']) && strcasecmp((string)$data['half_day'], 'None') !== 0))
            && (string)$fromDate === (string)$toDate;
        $isHourly         = !empty($data['is_hourly']) || !empty($data['hourly']);
        $hourlyHours      = (float)($data['hourly_hours'] ?? $data['hours'] ?? 0);
        $emergencyContact = $data['emergency_contact'] ?? null;
        $attachmentPath   = $data['attachment_path'] ?? null;
        $coveringEmpId    = $data['covering_employee_id'] ?? null;

        if (empty($employeeId)) {
            return ['success' => false, 'message' => 'Employee ID is required.'];
        }

        if (!$leaveTypeId || !$fromDate || !$toDate) {
            return ['success' => false, 'message' => 'Missing required leave fields (Employee, Type, Dates).'];
        }

        if (strtotime($fromDate) > strtotime($toDate)) {
            return ['success' => false, 'message' => 'From Date cannot be later than To Date.'];
        }

        // 1. Employee verification
        $emp = $this->db->table('employees')->where('id', $employeeId)->get()->getRowArray();
        if (!$emp) {
            return ['success' => false, 'message' => 'Employee record not found.'];
        }
        $empStatus = EmployeeModel::normalizeStatus($emp['status'] ?? EmployeeModel::STATUS_ACTIVE, true);
        if (in_array($empStatus, [
            EmployeeModel::STATUS_RESIGNED,
            EmployeeModel::STATUS_TERMINATED,
            EmployeeModel::STATUS_SUSPENDED,
            EmployeeModel::STATUS_INACTIVE,
        ], true)) {
            $statusLabel = EmployeeModel::STATUS_LABELS[$empStatus] ?? ucfirst($empStatus);
            return ['success' => false, 'message' => "Application rejected: Employee status is currently '{$statusLabel}'."];
        }

        // 2. Leave Category verification
        $leaveType = $this->db->table('leave_types')->where('id', $leaveTypeId)->get()->getRowArray();
        if (!$leaveType) {
            return ['success' => false, 'message' => 'Leave category not found.'];
        }
        if (strcasecmp((string)($leaveType['status'] ?? 'Active'), 'Inactive') === 0) {
            return ['success' => false, 'message' => "Leave category '{$leaveType['name']}' is currently inactive."];
        }

        $empCompanyId = (string)($emp['company_id'] ?? '');
        if (!empty($leaveType['company_id']) && (string)$leaveType['company_id'] !== $empCompanyId) {
            return ['success' => false, 'message' => '403 Forbidden: Selected leave category belongs to another organization.'];
        }

        if (!empty($coveringEmpId)) {
            $coveringEmp = $this->db->table('employees')->where('id', $coveringEmpId)->get()->getRowArray();
            if (!$coveringEmp || (string)($coveringEmp['company_id'] ?? '') !== $empCompanyId) {
                return ['success' => false, 'message' => '403 Forbidden: Covering employee must belong to the same organization.'];
            }
        }

        $actingUserId = $data['applied_by'] ?? $data['user_id'] ?? null;
        if (!empty($actingUserId) && (string)$actingUserId !== (string)$employeeId) {
            $tenantViolation = $this->verifyTenantIsolation((string)$actingUserId, $empCompanyId, 'application', 'User');
            if ($tenantViolation !== null) {
                return $tenantViolation;
            }
        }

        // 3. Resolve Rule from Single Rule Store (LEAVE domain)
        $ruleEnt = $this->leaveService->resolveLeaveEntitlement($empCompanyId, $emp, $leaveType, $fromDate);
        $rules = $this->leaveService->resolveApplicationRules($ruleEnt, $leaveType);

        // Gender Eligibility Verification
        $genderCheck = LeaveService::checkGenderEligibility($emp, $leaveType, $ruleEnt);
        if (!$genderCheck['eligible']) {
            return [
                'success'              => false,
                'message'              => $genderCheck['reason'] ?? 'Employee is not eligible for this leave type based on gender policy.',
                'is_gender_restricted' => true,
                'gender_check'         => $genderCheck,
            ];
        }

        $isPaid = $rules['is_paid'];
        $sandwich = $this->isSandwichEnabled($empCompanyId, $emp, $ruleEnt, $fromDate, $isPaid);

        // 4. Backdated & Future Date Restrictions
        $today = date('Y-m-d');
        $isBackdated = ($fromDate < $today);
        $isFuture = ($fromDate > $today);

        $allowBackdated = isset($rules['allow_backdated_application']) ? (bool)$rules['allow_backdated_application'] : true;
        $maxBackdateDays = (int)($rules['max_backdate_days'] ?? 0);
        $backdatedRole = trim((string)($rules['backdated_role_requirement'] ?? ''));

        $actingUserId = $data['applied_by'] ?? $data['user_id'] ?? null;
        $isHR = !empty($data['can_manage_leave']) || !empty($data['is_hr']);
        $isManager = $isHR || !empty($data['is_manager']);
        $isOwnApplication = !empty($data['is_own_application']);

        if (!empty($actingUserId)) {
            if ((string)$actingUserId === (string)$employeeId) {
                $isOwnApplication = true;
            } else {
                $actingEmpCheck = $this->findEmployeeByActorId((string)$actingUserId);
                if ($actingEmpCheck && (string)$actingEmpCheck['id'] === (string)$employeeId) {
                    $isOwnApplication = true;
                }
            }

            try {
                $permService = new \App\Services\PermissionService();
                if ($permService->isSoftwareAppAdmin()) {
                    $isHR = true;
                    $isManager = true;
                } else {
                    $isHR = $isHR
                         || $permService->can($actingUserId, 'leave.manage', ['company_id' => $empCompanyId])->isAllowed()
                         || $permService->can($actingUserId, 'leave.approve', ['company_id' => $empCompanyId])->isAllowed()
                         || $permService->can($actingUserId, 'leaves.manage', ['company_id' => $empCompanyId])->isAllowed()
                         || $permService->can($actingUserId, 'leaves.approve', ['company_id' => $empCompanyId])->isAllowed();
                    $isManager = $isHR 
                         || $permService->can($actingUserId, 'leave.endorse', ['company_id' => $empCompanyId])->isAllowed()
                         || $permService->can($actingUserId, 'leaves.endorse', ['company_id' => $empCompanyId])->isAllowed();
                }
            } catch (\Throwable $e) {
                // Ignore permission check error
            }

            if (!$isManager) {
                try {
                    $actingEmp = $this->findEmployeeByActorId((string)$actingUserId);
                    if ($actingEmp) {
                        // Check reportees via actual reporting_manager_id and manager_id columns (never non-existent supervisor_id)
                        $builder = $this->db->table('employees')->where('status', 'Active');
                        $hasCol = false;
                        if ($this->db->fieldExists('reporting_manager_id', 'employees') && $this->db->fieldExists('manager_id', 'employees')) {
                            $builder->groupStart()
                                ->where('reporting_manager_id', $actingEmp['id'])
                                ->orWhere('manager_id', $actingEmp['id'])
                                ->groupEnd();
                            $hasCol = true;
                        } elseif ($this->db->fieldExists('reporting_manager_id', 'employees')) {
                            $builder->where('reporting_manager_id', $actingEmp['id']);
                            $hasCol = true;
                        } elseif ($this->db->fieldExists('manager_id', 'employees')) {
                            $builder->where('manager_id', $actingEmp['id']);
                            $hasCol = true;
                        }
                        if ($hasCol && $builder->countAllResults() > 0) {
                            $isManager = true;
                        }
                    }
                } catch (\Throwable $e) {
                    // Ignore DB check failure
                }
            }
        }
        if (!empty($data['can_manage_leave'])) {
            $isHR = true;
            $isManager = true;
        }

        // When applying for their own leave, managers and HR staff act as regular applicants:
        // they cannot bypass notice periods, backdate limits, or emergency absence restrictions for their own leave.
        $canBypassLimits = (!$isOwnApplication && ($isHR || $isManager));

        $rawEmergency = !empty($data['is_emergency']) || !empty($data['is_urgent']);
        $allowEmergencyAbsence = (bool)($rules['allow_emergency_absence'] ?? false);
        $isEmergency = false;

        if ($rawEmergency) {
            if (!$canBypassLimits && !$allowEmergencyAbsence) {
                return [
                    'success' => false,
                    'message' => "Emergency absence is not permitted for '{$leaveType['name']}'. Only HR and managers can submit emergency requests for this leave category."
                ];
            }

            // Reason check: emergency absence strictly requires a substantive explanation
            $rawReason = trim((string)($data['reason'] ?? ''));
            if (strlen($rawReason) < 5) {
                return [
                    'success' => false,
                    'message' => "A valid, detailed reason explaining the emergency absence is mandatory."
                ];
            }

            $isEmergency = true;
        }

        $ltCode = strtoupper(trim((string)($leaveType['code'] ?? '')));
        $ltName = strtolower(trim((string)($leaveType['name'] ?? '')));
        $isSickLeave = ($ltCode === 'SL' || strpos($ltName, 'sick') !== false || strpos($ltCode, 'SICK') !== false);

        if ($isBackdated) {
            $diffDays = (int)ceil((strtotime($today) - strtotime($fromDate)) / 86400);

            if (!$canBypassLimits) {
                if (!$allowBackdated) {
                    return ['success' => false, 'message' => "Backdated leave applications are strictly disabled for '{$leaveType['name']}'."];
                }
                if ($maxBackdateDays > 0 && $diffDays > $maxBackdateDays) {
                    if ($isEmergency) {
                        return ['success' => false, 'message' => "Backdated limit exceeded for '{$leaveType['name']}': Maximum allowed is {$maxBackdateDays} days in the past (requested {$diffDays} days ago). Emergency applications exceeding this limit must be submitted by HR or a Manager."];
                    }
                    return ['success' => false, 'message' => "Backdated limit exceeded for '{$leaveType['name']}': Maximum allowed is {$maxBackdateDays} days in the past (requested {$diffDays} days ago)."];
                }
            }
        }

        $allowFuture = !empty($rules['allow_future_application']);
        $maxFutureDays = (int)($rules['max_future_days'] ?? 0);
        if ($isFuture && $allowFuture && $maxFutureDays > 0) {
            $futureDays = (int)ceil((strtotime($fromDate) - strtotime($today)) / 86400);
            if ($futureDays > $maxFutureDays) {
                return ['success' => false, 'message' => "Future leave limit exceeded: Applications cannot be submitted more than {$maxFutureDays} days in advance (requested {$futureDays} days in advance)."];
            }
        }

        // 5. Minimum Notice Period (Exempt for: HR recording for others, managers recording for others, permitted emergency applications, and same-day sick leave)
        $minNoticeDays = (int)($rules['min_notice_days'] ?? 0);
        if (!$isBackdated && $minNoticeDays > 0) {
            $isSameDaySick = ($isSickLeave && $fromDate === $today);
            $isExemptFromNotice = ($canBypassLimits || ($isEmergency && $allowEmergencyAbsence) || $isSameDaySick);

            if (!$isExemptFromNotice) {
                $noticeDays = (int)floor((strtotime($fromDate) - strtotime($today)) / 86400);
                if ($noticeDays < $minNoticeDays) {
                    return ['success' => false, 'message' => "Notice period requirement not met: '{$leaveType['name']}' requires at least {$minNoticeDays} days advance notice (provided {$noticeDays} days)."];
                }
            }
        }

        // 6. Half-Day and Hourly Controls
        $allowHalfDay = $rules['allow_half_day'];
        if ($isHalfDay && !$allowHalfDay) {
            return ['success' => false, 'message' => "Half-day applications are not permitted for '{$leaveType['name']}'."];
        }

        $allowHourly = $rules['allow_hourly_leave'];
        if ($isHourly) {
            if (!$allowHourly) {
                return ['success' => false, 'message' => "Hourly leave is not allowed for '{$leaveType['name']}'."];
            }
            $minHourly = (float)($rules['min_hourly_hours'] ?? 0);
            $maxHourly = (float)($rules['max_hourly_hours'] ?? 0);
            if ($minHourly > 0 && $hourlyHours < $minHourly) {
                return ['success' => false, 'message' => "Minimum hourly leave duration is {$minHourly} hours."];
            }
            if ($maxHourly > 0 && $hourlyHours > $maxHourly) {
                return ['success' => false, 'message' => "Maximum hourly leave duration is {$maxHourly} hours."];
            }
        }

        // 7. Probation & Waiting Period Eligibility
        try {
            $probationService = new \App\Services\ProbationLeaveEligibilityService();
            $eligibilityCheck = $probationService->checkLeaveEligibility($employeeId, $leaveTypeId, $fromDate);
            if (!$eligibilityCheck['is_eligible']) {
                $blockedMsg = !empty($eligibilityCheck['blocked_reason'])
                    ? $eligibilityCheck['blocked_reason']
                    : "Leave type is not available during probation period.";
                return [
                    'success'                 => false,
                    'message'                 => $blockedMsg,
                    'is_probation_restricted' => true,
                    'eligibility'             => $eligibilityCheck
                ];
            }
        } catch (\Throwable $e) {
            log_message('error', 'Probation eligibility check error in applyLeave: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Unable to verify probation eligibility. Please try again or contact HR.'];
        }

        // 8. Calculate Chargeable Days
        if ($isHourly) {
            $standardDailyHours = $this->getStandardDailyHours($empCompanyId, $emp, $fromDate);
            $chargeableDays = round($hourlyHours / $standardDailyHours, 2);
            $calc = [
                'chargeable_days'  => $chargeableDays,
                'sandwich_applies' => false,
                'sandwich_days'    => 0
            ];
        } else {
            $calc = $this->leaveService->calculateLeaveDays($employeeId, $fromDate, $toDate, $isHalfDay, $sandwich, null, $isPaid);
            $chargeableDays = $calc['chargeable_days'];
        }

        if ($chargeableDays <= 0) {
            return ['success' => false, 'message' => 'Calculated leave duration is 0 days. Please select a valid working date range.'];
        }

        $maxConsecutive = (int)($rules['max_consecutive_days'] ?? 0);
        if ($maxConsecutive > 0 && $chargeableDays > $maxConsecutive) {
            return ['success' => false, 'message' => "Consecutive days limit exceeded: '{$leaveType['name']}' allows a maximum of {$maxConsecutive} consecutive days per application (requested {$chargeableDays} days)."];
        }

        // 9. Mandatory Attachment & Medical Certificate Check
        $reqAttach = (bool)($rules['requires_attachment'] ?? false);
        if ($reqAttach && empty($attachmentPath)) {
            return ['success' => false, 'message' => "An attachment is mandatory for '{$leaveType['name']}' applications."];
        }

        $reqMed = (bool)($rules['requires_medical_certificate'] ?? false);
        $medThreshold = (int)($rules['medical_certificate_threshold_days'] ?? 0);
        if ($reqMed && $chargeableDays > $medThreshold && empty($attachmentPath)) {
            return ['success' => false, 'message' => "Medical Certificate Required: '{$leaveType['name']}' requests exceeding {$medThreshold} days require an attached medical certificate."];
        }

        $reqReason = (bool)($rules['requires_reason'] ?? true);
        if ($reqReason && (empty($reason) || strlen($reason) < 3)) {
            return ['success' => false, 'message' => 'A valid reason for leave is required.'];
        }

        // 10. Concurrency & Transaction Safe Reservation
        $this->db->transStart();

        // 10a. Prevent race conditions: lock employee row FOR UPDATE
        $empLock = $this->lockRow('employees', ['id' => $employeeId]);
        if (!$empLock) {
            $this->db->transRollback();
            return ['success' => false, 'message' => 'Employee lock acquisition failed. Please retry.'];
        }

        // 10b. Check Overlapping Leaves (accounting for both from_date/to_date and start_date/end_date)
        $existingOverlap = $this->db->table('leave_applications')
            ->where('employee_id', $employeeId)
            ->whereIn('status', ['Approved', 'Pending', 'Endorsed'])
            ->groupStart()
                ->where(new \CodeIgniter\Database\RawSql(
                    'COALESCE(`from_date`, `start_date`) <= ' . $this->db->escape($toDate)
                ))
                ->where(new \CodeIgniter\Database\RawSql(
                    'COALESCE(`to_date`, `end_date`) >= ' . $this->db->escape($fromDate)
                ))
            ->groupEnd()
            ->countAllResults();

        if ($existingOverlap > 0) {
            $this->db->transRollback();
            return ['success' => false, 'message' => 'An active or pending leave application already exists within the requested dates.'];
        }

        // 10c. Multi-year balance verification with row locking FOR UPDATE
        $allowNegative = (bool)($rules['allow_negative_balance'] ?? false);
        $maxNegative = (float)($rules['max_negative_days'] ?? 0.0);

        $yearSplitCharge = $this->leaveService->splitLeaveDaysByYear($employeeId, $fromDate, $toDate, (float)$chargeableDays, $isHalfDay, !empty($calc['sandwich_applies']), $isPaid, $ruleEnt);
        $totalCoveredPaid = 0.0;
        $totalNeededUnpaid = 0.0;
        $shortageFound = false;
        $paidByYear = [];
        $unpaidByYear = [];

        foreach ($yearSplitCharge as $yr => $yrDays) {
            $this->lockRow('leave_balances', [
                'employee_id'   => $employeeId,
                'leave_type_id' => $leaveTypeId,
                'year'          => $yr,
            ]);

            $bounds = \App\Services\Leave\LeaveAccrualCalculator::getLeavePeriodBounds($emp, $ruleEnt, $fromDate);
            $asOfCheckDate = ($yr === (int)$bounds['period_year']) ? $fromDate : $bounds['start_date'];
            $liveBal = $this->leaveService->getEmployeeBalance($employeeId, $leaveTypeId, $yr, $leaveType, false, $asOfCheckDate);
            $availBal = (float)($liveBal['available_balance'] ?? 0.0);

            if ($isPaid && ($availBal < $yrDays)) {
                $yrShortage = $yrDays - $availBal;
                if ($allowNegative && $maxNegative > 0 && $yrShortage <= $maxNegative) {
                    $totalCoveredPaid += $yrDays;
                    $paidByYear[$yr] = (float)$yrDays;
                    $unpaidByYear[$yr] = 0.0;
                } else {
                    $shortageFound = true;
                    $covered = max(0.0, min($availBal, $yrDays));
                    $unpaidPart = $yrDays - $covered;
                    $totalCoveredPaid += $covered;
                    $totalNeededUnpaid += $unpaidPart;
                    $paidByYear[$yr] = round($covered, 2);
                    $unpaidByYear[$yr] = round($unpaidPart, 2);
                }
            } else {
                $totalCoveredPaid += $yrDays;
                $paidByYear[$yr] = $isPaid ? (float)$yrDays : 0.0;
                $unpaidByYear[$yr] = $isPaid ? 0.0 : (float)$yrDays;
            }
        }

        $paidPercentage = isset($rules['paid_percentage']) && is_numeric($rules['paid_percentage'])
            ? (float)$rules['paid_percentage']
            : (isset($ruleEnt['paid_percentage']) && is_numeric($ruleEnt['paid_percentage']) ? (float)$ruleEnt['paid_percentage'] : 100.0);
        if ($paidPercentage < 0.0) $paidPercentage = 0.0;
        if ($paidPercentage > 100.0) $paidPercentage = 100.0;

        $paidDays = (float)$chargeableDays;
        $unpaidDays = 0.0;
        $unpaidTypeId = null;
        $splitReason = null;

        if ($isPaid && $shortageFound) {
            if (isset($rules['allow_unpaid_split'])) {
                $splitAllowedByRule = (bool)$rules['allow_unpaid_split'];
            } elseif (isset($ruleEnt['allow_unpaid_split'])) {
                $splitAllowedByRule = (bool)$ruleEnt['allow_unpaid_split'];
            } else {
                $leaveRule = (new RuleResolver())->resolve($empCompanyId, 'LEAVE', $fromDate, $emp);
                $leaveRuleParams = $leaveRule->params();
                if (isset($leaveRuleParams['allow_unpaid_split'])) {
                    $splitAllowedByRule = (bool)$leaveRuleParams['allow_unpaid_split'];
                } else {
                    $this->db->transRollback();
                    throw new \App\Services\Rules\RuleNotConfiguredException("Rule parameter 'allow_unpaid_split' is not configured for '{$leaveType['name']}'", null, 'LEAVE', $fromDate);
                }
            }

            if (!$splitAllowedByRule) {
                $this->db->transRollback();
                return [
                    'success' => false,
                    'message' => "Insufficient leave balance in {$leaveType['name']} ({$totalCoveredPaid} day(s) available, {$chargeableDays} day(s) requested). Splitting into unpaid leave is disabled by company policy."
                ];
            }

            $isConfirmed = !empty($data['confirm_unpaid_split']) || !empty($data['allow_unpaid_split']);
            $coveredPaid = round($totalCoveredPaid, 2);
            $scaledCoveredPaid = round($coveredPaid * ($paidPercentage / 100.0), 2);
            $scaledNeededUnpaid = round($chargeableDays - $scaledCoveredPaid, 2);

            if (!$isConfirmed) {
                $this->db->transRollback();
                return [
                    'success'                     => false,
                    'requires_split_confirmation' => true,
                    'available_balance'           => $coveredPaid,
                    'chargeable_days'             => $chargeableDays,
                    'covered_paid_days'           => $scaledCoveredPaid,
                    'needed_unpaid_days'          => $scaledNeededUnpaid,
                    'message'                     => "Insufficient leave balance in {$leaveType['name']} ({$coveredPaid} day(s) available, {$chargeableDays} day(s) requested). Please confirm if you wish to apply the remaining {$scaledNeededUnpaid} day(s) as unpaid leave (Loss of Pay)."
                ];
            }

            $unpaidType = $this->leaveService->resolveAuthoritativeUnpaidLeaveType($empCompanyId);
            $unpaidTypeId = $unpaidType['id'] ?? null;
            $paidDays = $scaledCoveredPaid;
            $unpaidDays = $scaledNeededUnpaid;

            // Scale per-year paid and unpaid amounts to match $paidPercentage
            foreach ($yearSplitCharge as $yr => $yrDays) {
                $cov = (float)($paidByYear[$yr] ?? 0.0);
                $p = round($cov * ($paidPercentage / 100.0), 2);
                $paidByYear[$yr] = $p;
                $unpaidByYear[$yr] = round($yrDays - $p, 2);
            }
            $sumPaid = round(array_sum($paidByYear), 2);
            if ($sumPaid !== $paidDays && !empty($paidByYear)) {
                $diff = round($paidDays - $sumPaid, 2);
                $lastYr = array_key_last($paidByYear);
                $paidByYear[$lastYr] = round($paidByYear[$lastYr] + $diff, 2);
                $unpaidByYear[$lastYr] = round($yearSplitCharge[$lastYr] - $paidByYear[$lastYr], 2);
            }

            $splitReason = "Insufficient balance in {$leaveType['name']} (available: {$coveredPaid}d, requested: {$chargeableDays}d). Confirmed split into {$paidDays} paid day(s) and {$unpaidDays} unpaid loss-of-pay day(s).";
        } elseif (!$isPaid || $paidPercentage <= 0.0) {
            $paidDays = 0.0;
            $unpaidDays = (float)$chargeableDays;
            foreach ($yearSplitCharge as $yr => $yrDays) {
                $paidByYear[$yr] = 0.0;
                $unpaidByYear[$yr] = (float)$yrDays;
            }
            $unpaidType = $this->leaveService->resolveAuthoritativeUnpaidLeaveType($empCompanyId);
            $unpaidTypeId = $unpaidType['id'] ?? null;
        } else {
            if ($paidPercentage < 100.0) {
                $paidDays = round($chargeableDays * ($paidPercentage / 100.0), 2);
                $unpaidDays = round($chargeableDays - $paidDays, 2);
                foreach ($yearSplitCharge as $yr => $yrDays) {
                    $p = round($yrDays * ($paidPercentage / 100.0), 2);
                    $paidByYear[$yr] = $p;
                    $unpaidByYear[$yr] = round($yrDays - $p, 2);
                }
                $sumPaid = round(array_sum($paidByYear), 2);
                if ($sumPaid !== $paidDays && !empty($paidByYear)) {
                    $diff = round($paidDays - $sumPaid, 2);
                    $lastYr = array_key_last($paidByYear);
                    $paidByYear[$lastYr] = round($paidByYear[$lastYr] + $diff, 2);
                    $unpaidByYear[$lastYr] = round($yearSplitCharge[$lastYr] - $paidByYear[$lastYr], 2);
                }
                $unpaidType = $this->leaveService->resolveAuthoritativeUnpaidLeaveType($empCompanyId);
                $unpaidTypeId = $unpaidType['id'] ?? null;
                $splitReason = "Partially paid leave ({$paidPercentage}% paid). {$paidDays} paid day(s) and {$unpaidDays} unpaid loss-of-pay day(s).";
            } else {
                $paidDays = (float)$chargeableDays;
                $unpaidDays = 0.0;
                foreach ($yearSplitCharge as $yr => $yrDays) {
                    $paidByYear[$yr] = (float)$yrDays;
                    $unpaidByYear[$yr] = 0.0;
                }
            }
        }

        // Guarantee unpaid_leave_type_id is populated whenever unpaid days exist
        if ($unpaidDays > 0 && empty($unpaidTypeId)) {
            $unpaidType = $this->leaveService->resolveAuthoritativeUnpaidLeaveType($empCompanyId);
            $unpaidTypeId = $unpaidType['id'] ?? null;
        }

        // 10d. Resolve approval workflow and required tiers for this duration
        $approvalWorkflow = [];
        try {
            $leaveRule = (new RuleResolver())->resolve($empCompanyId, 'LEAVE', $fromDate, $emp);
            $approvalWorkflow = $leaveRule->get('approval_workflow') ?: [];
        } catch (\Throwable $wfEx) {
            log_message('warning', "applyLeave: failed to resolve LEAVE rule workflow: {$wfEx->getMessage()}");
        }

        $requiredApprovers = self::resolveRequiredApproversForApplication($approvalWorkflow, (float)$chargeableDays, $isBackdated, $backdatedRole);

        $requiresManagerTier = self::isManagerTierRequired($requiredApprovers);
        $requiresDeptHead = in_array('Department Head', $requiredApprovers, true);
        $requiresHrAdmin = in_array('HR Admin', $requiredApprovers, true) || in_array('HR', $requiredApprovers, true) || in_array('HR Administration', $requiredApprovers, true);

        // Evaluate auto-approval criteria:
        // 1. Rule specifies approval is not required (approval_required = false)
        // 2. Rule explicitly marks type as auto-approved (is_auto_approved = true)
        // 3. Application duration is under auto_approve_under_days threshold
        // Backdated applications requiring approvers and managers applying for their own leave CANNOT auto-approve.
        $autoApproveUnderDays = (float)($approvalWorkflow['auto_approve_under_days'] ?? ($rules['auto_approve_under_days'] ?? 0));
        $approvalRequired = (bool)($rules['approval_required'] ?? true);
        $isAutoApprovedRule = !empty($rules['is_auto_approved']);

        $isAutoApproved = self::determineAutoApproval([
            'is_backdated'            => $isBackdated,
            'backdated_role'          => $backdatedRole,
            'is_own_application'      => $isOwnApplication,
            'is_hr'                   => $isHR,
            'is_manager'              => $isManager,
            'approval_required'       => $approvalRequired,
            'is_auto_approved'        => $isAutoApprovedRule,
            'auto_approve_under_days' => $autoApproveUnderDays,
            'chargeable_days'         => $chargeableDays,
            'is_emergency'            => $isEmergency,
        ]);

        // Attendance settlement lock check for auto-approval: cannot auto-approve if any day is settled in payroll
        if ($isAutoApproved) {
            $attService = new AttendanceService();
            $chkCurr = clone (new \DateTime($fromDate));
            $chkEnd = new \DateTime($toDate);
            while ($chkCurr <= $chkEnd) {
                if ($attService->isAttendanceSettled($employeeId, $chkCurr->format('Y-m-d'))) {
                    $isAutoApproved = false;
                    break;
                }
                $chkCurr->modify('+1 day');
            }
        }

        // 10e. Insert Application
        $appId = 'lv-' . bin2hex(random_bytes(6));
        $now = date('Y-m-d H:i:s');
        $insertPayload = [
            'id'                   => $appId,
            'employee_id'          => $employeeId,
            'leave_type_id'        => $leaveTypeId,
            'from_date'            => $fromDate,
            'to_date'              => $toDate,
            'start_date'           => $fromDate,
            'end_date'             => $toDate,
            'total_days'           => $chargeableDays,
            'paid_days'            => $paidDays,
            'unpaid_days'          => $unpaidDays,
            'unpaid_leave_type_id' => $unpaidTypeId,
            'split_reason'         => $splitReason,
            'year_split'           => json_encode(['paid' => $paidByYear, 'unpaid' => $unpaidByYear]),
            'half_day'             => $isHalfDay ? (!empty($data['half_day']) && in_array($data['half_day'], ['First Half', 'Second Half'], true) ? $data['half_day'] : 'First Half') : 'None',
            'is_half_day'          => $isHalfDay ? 1 : 0,
            'is_hourly'            => $isHourly ? 1 : 0,
            'hourly_hours'         => $isHourly ? $hourlyHours : 0.00,
            'is_emergency'         => $isEmergency ? 1 : 0,
            'is_backdated'         => $isBackdated ? 1 : 0,
            'backdated_role'       => $isBackdated ? ($backdatedRole ?: null) : null,
            'sandwich_rule_applies'=> !empty($calc['sandwich_applies']) ? 1 : 0,
            'sandwich_days_count'  => (int)($calc['sandwich_days'] ?? 0),
            'reason'               => $reason,
            'emergency_contact'    => $emergencyContact,
            'attachment_path'      => $attachmentPath,
            'covering_employee_id' => $coveringEmpId,
            'applied_at'           => $now,
            'created_at'           => $now,
            'updated_at'           => $now
        ];

        if ($isAutoApproved) {
            $insertPayload['status']               = 'Approved';
            $insertPayload['approved_by']          = 'SYSTEM_AUTO';
            $insertPayload['approved_at']          = $now;
            if ($requiresManagerTier || in_array('Manager', $requiredApprovers, true)) {
                $insertPayload['manager_status']       = 'Approved';
                $insertPayload['manager_name']         = 'Auto-Approved (Policy)';
                $insertPayload['manager_endorsed_at']  = $now;
                $insertPayload['manager_remarks']      = 'Auto-approved per company leave policy';
            }
            if ($requiresDeptHead) {
                $insertPayload['dept_head_status']      = 'Approved';
                $insertPayload['dept_head_name']        = 'Auto-Approved (Policy)';
                $insertPayload['dept_head_endorsed_at'] = $now;
                $insertPayload['dept_head_remarks']     = 'Auto-approved per company leave policy';
            }
            if ($requiresHrAdmin) {
                $insertPayload['hr_status']      = 'Approved';
                $insertPayload['hr_name']        = 'Auto-Approved (Policy)';
                $insertPayload['hr_approved_at'] = $now;
                $insertPayload['hr_remarks']     = 'Auto-approved per company leave policy';
            }
        } else {
            $insertPayload['status']         = 'Pending';
            $insertPayload['manager_status'] = ($requiresManagerTier || in_array('Manager', $requiredApprovers, true)) ? 'Pending' : null;
            if ($requiresHrAdmin) {
                $insertPayload['hr_status'] = 'Pending';
            }
            if ($requiresDeptHead) {
                $insertPayload['dept_head_status'] = 'Pending';
            }
        }

        $this->leaveModel->insert($insertPayload);

        // 10f. Balance and ledger update
        if ($isAutoApproved) {
            // Auto-approved leave: deduct paid days directly into approved_leave_days and insert Deduction transaction
            if ($paidDays > 0) {
                foreach ($paidByYear as $yr => $yrDays) {
                    $yrDays = (float)$yrDays;
                    if ($yrDays <= 0) continue;

                    $this->lockRow('leave_balances', [
                        'employee_id'   => $employeeId,
                        'leave_type_id' => $leaveTypeId,
                        'year'          => $yr,
                    ]);

                    $existingBal = $this->db->table('leave_balances')
                        ->where('employee_id', $employeeId)
                        ->where('leave_type_id', $leaveTypeId)
                        ->where('year', $yr)
                        ->get()->getRowArray();

                    if ($existingBal) {
                        $this->db->query(
                            "UPDATE leave_balances SET approved_leave_days = approved_leave_days + ? 
                             WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                            [$yrDays, $employeeId, $leaveTypeId, $yr]
                        );
                    } else {
                        $this->balanceModel->insert([
                            'id'                     => 'bal-' . bin2hex(random_bytes(6)),
                            'employee_id'            => $employeeId,
                            'leave_type_id'          => $leaveTypeId,
                            'year'                   => $yr,
                            'opening_balance'        => 0.0,
                            'allocated_days'         => 0.0,
                            'accrued_days'           => 0.0,
                            'carry_forward_days'     => 0.0,
                            'approved_leave_days'    => $yrDays,
                            'pending_leave_days'     => 0.0,
                            'unpaid_adjustment_days' => 0.0,
                            'encashed_days'          => 0.0,
                            'created_at'             => $now,
                            'updated_at'             => $now
                        ]);
                    }

                    $startOfYear = "{$yr}-01-01";
                    $endOfYear   = "{$yr}-12-31";
                    $effDate = ($fromDate > $startOfYear) ? $fromDate : $startOfYear;
                    if ($effDate > $endOfYear) $effDate = $endOfYear;
                    if ($effDate > $toDate) $effDate = $toDate;
                    $txDate = ($yr === (int)date('Y')) ? date('Y-m-d') : $effDate;

                    $this->transactionModel->insert([
                        'id'                     => 'tx-' . bin2hex(random_bytes(6)),
                        'company_id'             => $empCompanyId,
                        'employee_id'            => $employeeId,
                        'leave_type_id'          => $leaveTypeId,
                        'leave_year'             => (int)$yr,
                        'transaction_type'       => 'Deduction',
                        'days'                   => $yrDays,
                        'reference_id'           => $appId,
                        'cycle_no'               => "LEAVE-APP-{$appId}",
                        'idempotency_key'        => "LEAVE-APP-{$appId}-DED-PAID-{$yr}",
                        'related_application_id' => $appId,
                        'remarks'                => 'Auto-approved leave application deduction (Paid)',
                        'effective_date'         => $effDate,
                        'transaction_date'       => $txDate
                    ]);
                }
            }

            // Unpaid days handling if applicable
            if ($unpaidDays > 0 && !empty($unpaidTypeId)) {
                foreach ($unpaidByYear as $yr => $yrDays) {
                    $yrDays = (float)$yrDays;
                    if ($yrDays <= 0) continue;

                    $existingUlBal = $this->db->table('leave_balances')
                        ->where('employee_id', $employeeId)
                        ->where('leave_type_id', $unpaidTypeId)
                        ->where('year', $yr)
                        ->get()->getRowArray();

                    if ($existingUlBal) {
                        $this->db->query(
                            "UPDATE leave_balances SET approved_leave_days = approved_leave_days + ?, unpaid_adjustment_days = unpaid_adjustment_days + ? 
                             WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                            [$yrDays, $yrDays, $employeeId, $unpaidTypeId, $yr]
                        );
                    } else {
                        $this->balanceModel->insert([
                            'id'                     => 'bal-' . bin2hex(random_bytes(6)),
                            'employee_id'            => $employeeId,
                            'leave_type_id'          => $unpaidTypeId,
                            'year'                   => $yr,
                            'opening_balance'        => 0.0,
                            'allocated_days'         => 0.0,
                            'accrued_days'           => 0.0,
                            'carry_forward_days'     => 0.0,
                            'approved_leave_days'    => $yrDays,
                            'pending_leave_days'     => 0.0,
                            'unpaid_adjustment_days' => $yrDays,
                            'encashed_days'          => 0.0,
                            'created_at'             => $now,
                            'updated_at'             => $now
                        ]);
                    }

                    $startOfYear = "{$yr}-01-01";
                    $effDate = ($fromDate > $startOfYear) ? $fromDate : $startOfYear;
                    $txDate = ($yr === (int)date('Y')) ? date('Y-m-d') : $effDate;

                    $this->transactionModel->insert([
                        'id'                     => 'tx-' . bin2hex(random_bytes(6)),
                        'company_id'             => $empCompanyId,
                        'employee_id'            => $employeeId,
                        'leave_type_id'          => $unpaidTypeId,
                        'leave_year'             => (int)$yr,
                        'transaction_type'       => 'Deduction',
                        'days'                   => $yrDays,
                        'reference_id'           => $appId,
                        'cycle_no'               => "LEAVE-APP-{$appId}-UNPAID",
                        'idempotency_key'        => "LEAVE-APP-{$appId}-DED-UNPAID-{$yr}",
                        'related_application_id' => $appId,
                        'remarks'                => "Auto-approved leave application deduction (Unpaid loss of pay: {$yrDays} days)",
                        'effective_date'         => $effDate,
                        'transaction_date'       => $txDate
                    ]);
                }
            }

            // Sync attendance logs for auto-approved leave
            $this->syncApprovedLeaveAttendance($employeeId, $empCompanyId, $fromDate, $toDate, $leaveTypeId, $isHalfDay, !empty($calc['sandwich_applies']), $calc);
        } else {
            // Standard pending workflow: increment pending_leave_days atomically for the paid component
            if ($paidDays > 0) {
                foreach ($paidByYear as $yr => $yrDays) {
                    if ($yrDays <= 0) continue;
                    $yrBalanceRow = $this->lockRow('leave_balances', [
                        'employee_id'   => $employeeId,
                        'leave_type_id' => $leaveTypeId,
                        'year'          => $yr,
                    ]);

                    if ($yrBalanceRow) {
                        $this->db->query(
                            "UPDATE leave_balances SET pending_leave_days = pending_leave_days + ? 
                             WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                            [$yrDays, $employeeId, $leaveTypeId, $yr]
                        );
                    } else {
                        $this->balanceModel->insert([
                            'id'                     => 'bal-' . bin2hex(random_bytes(6)),
                            'employee_id'            => $employeeId,
                            'leave_type_id'          => $leaveTypeId,
                            'year'                   => $yr,
                            'opening_balance'        => 0.0,
                            'allocated_days'         => 0.0,
                            'accrued_days'           => 0.0,
                            'carry_forward_days'     => 0.0,
                            'approved_leave_days'    => 0.0,
                            'pending_leave_days'     => $yrDays,
                            'unpaid_adjustment_days' => 0.0,
                            'encashed_days'          => 0.0,
                            'created_at'             => $now,
                            'updated_at'             => $now
                        ]);
                    }
                }
            }

            // Standard pending workflow: increment pending_leave_days atomically for the unpaid component
            if ($unpaidDays > 0 && !empty($unpaidTypeId)) {
                foreach ($unpaidByYear as $yr => $yrDays) {
                    $yrDays = (float)$yrDays;
                    if ($yrDays <= 0) continue;

                    $yrUlBalanceRow = $this->lockRow('leave_balances', [
                        'employee_id'   => $employeeId,
                        'leave_type_id' => $unpaidTypeId,
                        'year'          => $yr,
                    ]);

                    if ($yrUlBalanceRow) {
                        $this->db->query(
                            "UPDATE leave_balances SET pending_leave_days = pending_leave_days + ? 
                             WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                            [$yrDays, $employeeId, $unpaidTypeId, $yr]
                        );
                    } else {
                        $this->balanceModel->insert([
                            'id'                     => 'bal-' . bin2hex(random_bytes(6)),
                            'employee_id'            => $employeeId,
                            'leave_type_id'          => $unpaidTypeId,
                            'year'                   => $yr,
                            'opening_balance'        => 0.0,
                            'allocated_days'         => 0.0,
                            'accrued_days'           => 0.0,
                            'carry_forward_days'     => 0.0,
                            'approved_leave_days'    => 0.0,
                            'pending_leave_days'     => $yrDays,
                            'unpaid_adjustment_days' => 0.0,
                            'encashed_days'          => 0.0,
                            'created_at'             => $now,
                            'updated_at'             => $now
                        ]);
                    }
                }
            }
        }

        // 10g. Record dynamic approval steps in leave_approval_steps based on required approvers
        if ($this->db->tableExists('leave_approval_steps')) {
            try {
                $approvalSteps = $this->buildApprovalSteps($appId, $requiredApprovers, $emp, $isAutoApproved);
                if (!empty($approvalSteps)) {
                    $this->db->table('leave_approval_steps')->insertBatch($approvalSteps);
                }
            } catch (\Throwable $stepEx) {
                log_message('notice', 'applyLeave approval steps error: ' . $stepEx->getMessage());
            }
        }

        // Notify HR / Admins
        try {
            $empName = trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? ''));
            $notifTitle = $isAutoApproved ? 'Leave Application Auto-Approved' : 'New Leave Application';
            $notifDesc = $isAutoApproved
                ? "{$empName}'s leave application for {$chargeableDays} days {$leaveType['name']} ({$fromDate} to {$toDate}) was auto-approved per policy."
                : "{$empName} applied for {$chargeableDays} days {$leaveType['name']} ({$fromDate} to {$toDate}).";
            $this->leaveService->notifyAdmins(
                $notifTitle,
                $notifDesc,
                'leave',
                $appId,
                $empCompanyId,
                $employeeId
            );
        } catch (\Throwable $e) {
            log_message('error', 'applyLeave admin notification error: ' . $e->getMessage());
        }

        $transactionStatusBeforeComplete = $this->db->transStatus();
        $dbErrorBeforeComplete = $transactionStatusBeforeComplete ? null : $this->db->error();
        $transactionCompleted = $this->db->transComplete();
        if (!$transactionStatusBeforeComplete || !$transactionCompleted) {
            $dbError = $dbErrorBeforeComplete ?? $this->db->error();
            log_message(
                'error',
                'applyLeave transaction failed for application ' . $appId . ': '
                . ($dbError['code'] ?? 'unknown') . ' '
                . ($dbError['message'] ?? 'Database transaction reported failure without an error message.')
            );

            return [
                'success' => false,
                'message' => 'Leave application could not be saved because a database operation failed. Please try again or contact HR.'
            ];
        }

        return [
            'success'          => true,
            'application_id'   => $appId,
            'total_days'       => $chargeableDays,
            'paid_days'        => $paidDays,
            'unpaid_days'      => $unpaidDays,
            'status'           => $isAutoApproved ? 'Approved' : 'Pending',
            'is_auto_approved' => $isAutoApproved,
            'message'          => $isAutoApproved
                ? 'Leave application submitted and auto-approved per company leave policy.'
                : 'Leave application submitted successfully.'
        ];
    }

    /**
     * Endorse leave application by reporting manager.
     */
    public function endorseLeave(string $applicationId, string $managerId, ?string $managerName = null, ?string $remarks = null): array
    {
        if (trim($applicationId) === '') {
            return ['success' => false, 'message' => 'Application ID is required.'];
        }

        $app = $this->leaveModel->find($applicationId);
        if (!$app) {
            return ['success' => false, 'message' => 'Leave application not found.'];
        }

        $targetEmp = $this->db->table('employees')->where('id', $app['employee_id'])->get()->getRowArray();
        $targetCompanyId = (string)($targetEmp['company_id'] ?? ($app['company_id'] ?? ''));

        // Authoritative Service-Level Tenant Isolation Check: Manager must belong to target employee's company
        $tenantViolation = $this->verifyTenantIsolation($managerId, $targetCompanyId, 'endorsement', 'Manager');
        if ($tenantViolation !== null) {
            return $tenantViolation;
        }

        $currentStatus = strtolower(trim((string)($app['status'] ?? 'pending')));
        if (!in_array($currentStatus, ['pending', 'endorsed'], true)) {
            return ['success' => false, 'message' => "Application is already {$app['status']} and cannot be endorsed."];
        }

        // Caller user and employee resolution
        $mgrUser = $this->db->table('users')->where('id', $managerId)->get()->getRowArray();
        $mgrEmpId = $mgrUser['employee_id'] ?? null;
        if (!$mgrEmpId) {
            $mgrEmpRow = $this->db->table('employees')->where('id', $managerId)->get()->getRowArray();
            if ($mgrEmpRow) {
                $mgrEmpId = $mgrEmpRow['id'];
            }
        }

        // Self-Endorsement Policy Check (exempt privileged admin roles)
        $isPrivilegedAdmin = $this->isSoftwareAppAdminFromId($managerId);
        if (!$isPrivilegedAdmin && !empty($managerId)) {
            $userRow = $this->db->table('users')
                ->select('users.*, roles.code as role_code, roles.name as role_name')
                ->join('roles', 'roles.id = users.role_id', 'left')
                ->groupStart()
                    ->where('users.id', $managerId)
                    ->orWhere('users.employee_id', $managerId)
                ->groupEnd()
                ->get()->getRowArray();
            $permService = new \App\Services\PermissionService();
            $canonicalRole = $permService->canonicalizeRole($userRow['role_code'] ?? $userRow['role_name'] ?? '');
            if ($canonicalRole === 'company_admin' || $canonicalRole === 'hr_admin' || $permService->isHRAdmin($canonicalRole)) {
                $isPrivilegedAdmin = true;
            }
        }
        if (!$isPrivilegedAdmin && ($managerId === $app['employee_id'] || ($mgrEmpId && $mgrEmpId === $app['employee_id']))) {
            return [
                'success' => false,
                'message' => 'Self-endorsement violation: You cannot endorse your own leave application.'
            ];
        }

        $callerIds = array_values(array_filter([$managerId, $mgrEmpId]));

        // Direct Manager Scoping Check: Caller must be the employee's designated manager or department head
        $targetManagerIds = array_values(array_filter([
            $targetEmp['reporting_manager_id'] ?? null,
            $targetEmp['manager_id'] ?? null,
            $targetEmp['line_manager_id'] ?? null,
            $targetEmp['reporting_to'] ?? null,
        ]));

        $deptId = $targetEmp['department_id'] ?? null;
        $deptRow = $deptId ? $this->db->table('departments')->where('id', $deptId)->get()->getRowArray() : null;
        $deptHeadEmpId = $deptRow['head_id'] ?? null;

        // If employee has no separate line manager, the department head acts as direct manager
        if (empty($targetManagerIds) && !empty($deptHeadEmpId)) {
            $targetManagerIds[] = $deptHeadEmpId;
        }

        $isCallerDeptHead = (!empty($deptHeadEmpId) && in_array((string)$deptHeadEmpId, array_map('strval', $callerIds), true));
        $isSameManagerAndDeptHead = $isCallerDeptHead || (!empty($deptHeadEmpId) && in_array((string)$deptHeadEmpId, array_map('strval', $targetManagerIds), true));

        // Resolve approval workflow and required tiers for this application
        $fromDate = $app['from_date'] ?? $app['start_date'] ?? date('Y-m-d');
        $totalDays = (float)($app['total_days'] ?? 1.0);
        $approvalWorkflow = [];
        try {
            $leaveRule = RuleResolver::resolve($targetCompanyId, 'LEAVE', $fromDate, $targetEmp);
            $approvalWorkflow = $leaveRule->get('approval_workflow') ?: [];
        } catch (\Throwable $e) {
            log_message('notice', "Workflow resolution notice in endorseLeave for app {$applicationId}: " . $e->getMessage());
        }

        $requiredApprovers = self::resolveRequiredApproversForApplication(
            $approvalWorkflow,
            $totalDays,
            (bool)($app['is_backdated'] ?? false),
            (string)($app['backdated_role'] ?? '')
        );
        $requiresManagerTier = self::isManagerTierRequired($requiredApprovers);
        $requiresDeptHead = in_array('Department Head', $requiredApprovers, true);
        $requiresHrAdmin = in_array('HR Admin', $requiredApprovers, true) || in_array('HR', $requiredApprovers, true) || in_array('HR Administration', $requiredApprovers, true);

        // Check if already endorsed by Line Manager
        if (in_array(strtolower((string)($app['manager_status'] ?? '')), ['approved', 'endorsed'], true)) {
            // Check if caller is Department Head and application requires Dept Head endorsement
            if ($isCallerDeptHead && $requiresDeptHead) {
                return $this->endorseDeptHead($applicationId, $managerId, $managerName, $remarks);
            }
            return ['success' => false, 'message' => 'This application is already endorsed by the department manager.'];
        }

        $isSoftwareAdmin = $this->isSoftwareAppAdminFromId($managerId);
        $isOverrideAdmin = false;
        if (!empty($managerId)) {
            try {
                $permService = new \App\Services\PermissionService();
                $isOverrideAdmin = $permService->can($managerId, 'leave.override_tier', ['company_id' => $targetCompanyId])->isAllowed()
                    || $permService->can($managerId, 'leaves.override_tier', ['company_id' => $targetCompanyId])->isAllowed();
            } catch (\Throwable $e) {
                $isOverrideAdmin = false;
            }
        }

        $isDirectManager = false;
        foreach ($callerIds as $idToCheck) {
            if (in_array($idToCheck, $targetManagerIds, true) || ($isCallerDeptHead && $isSameManagerAndDeptHead)) {
                $isDirectManager = true;
                break;
            }
        }

        if (!$isDirectManager && !$isSoftwareAdmin && !$isOverrideAdmin && !$isPrivilegedAdmin) {
            return [
                'success' => false,
                'message' => 'Unauthorized: You can only endorse leave applications for your direct reports.'
            ];
        }

        if (!$requiresManagerTier && !in_array('Manager', $requiredApprovers, true) && !$isOverrideAdmin && !$isSoftwareAdmin) {
            return [
                'success' => false,
                'message' => 'Manager endorsement is not required for this leave application per company policy.'
            ];
        }

        $mgrName = $managerName;
        if (empty($mgrName)) {
            $mgrEmp = $mgrEmpId ? $this->employeeModel->find($mgrEmpId) : $this->employeeModel->find($managerId);
            $mgrName = $mgrEmp ? trim(($mgrEmp['first_name'] ?? '') . ' ' . ($mgrEmp['last_name'] ?? '')) : ($mgrUser['username'] ?? 'Reporting Manager');
        }

        $now = date('Y-m-d H:i:s');
        $this->db->transStart();

        $updateData = [
            'manager_status'      => 'Endorsed',
            'manager_id'          => $mgrEmpId ?: $managerId,
            'manager_name'        => $mgrName,
            'manager_endorsed_at' => $now,
            'manager_remarks'     => $remarks ?: 'Endorsed by reporting manager',
            'status'              => 'Endorsed',
            'updated_at'          => $now
        ];

        // If the reporting manager is ALSO the Department Head, satisfy Department Head endorsement simultaneously
        if ($isSameManagerAndDeptHead) {
            $updateData['dept_head_status']      = 'Endorsed';
            $updateData['dept_head_id']          = $mgrEmpId ?: $managerId;
            $updateData['dept_head_name']        = $mgrName;
            $updateData['dept_head_endorsed_at'] = $now;
            $updateData['dept_head_remarks']     = $remarks ?: 'Endorsed as Department Head (Dual-role line manager)';
        }

        $this->leaveModel->update($applicationId, $updateData);

        // Update Step 1 (Line Manager) and Step 2 (Department Head if dual-role) in leave_approval_steps
        if ($this->db->tableExists('leave_approval_steps')) {
            try {
                $step1 = $this->db->table('leave_approval_steps')
                    ->where('application_id', $applicationId)
                    ->groupStart()
                        ->where('step_order', 1)
                        ->orWhere('approver_role', 'Line Manager')
                    ->groupEnd()
                    ->get()
                    ->getRowArray();

                if ($step1) {
                    $this->db->table('leave_approval_steps')
                        ->where('id', $step1['id'])
                        ->update([
                            'approver_id' => $mgrEmpId ?: $managerId,
                            'status'      => 'Approved',
                            'comments'    => $remarks ?: 'Endorsed by reporting manager',
                            'acted_at'    => $now,
                            'updated_at'  => $now,
                        ]);
                } else {
                    $this->db->table('leave_approval_steps')->insert([
                        'id'             => 'las-' . bin2hex(random_bytes(6)),
                        'application_id' => $applicationId,
                        'step_order'     => 1,
                        'approver_id'    => $mgrEmpId ?: $managerId,
                        'approver_role'  => 'Line Manager',
                        'status'         => 'Approved',
                        'comments'       => $remarks ?: 'Endorsed by reporting manager',
                        'acted_at'       => $now,
                        'created_at'     => $now,
                        'updated_at'     => $now,
                    ]);
                }

                if ($isSameManagerAndDeptHead) {
                    $this->db->table('leave_approval_steps')
                        ->where('application_id', $applicationId)
                        ->where('approver_role', 'Department Head')
                        ->update([
                            'approver_id' => $mgrEmpId ?: $managerId,
                            'status'      => 'Approved',
                            'comments'    => $remarks ?: 'Endorsed as Department Head (Dual-role line manager)',
                            'acted_at'    => $now,
                            'updated_at'  => $now,
                        ]);
                }
            } catch (\Throwable $stepEx) {
                log_message('notice', 'endorseLeave step update error: ' . $stepEx->getMessage());
            }
        }

        // Notify HR / Admins of endorsement
        try {
            $appCompanyId = $app['company_id'] ?? null;
            if (empty($appCompanyId) && !empty($app['employee_id'])) {
                $appEmp = $this->employeeModel->find($app['employee_id']);
                $appCompanyId = $appEmp['company_id'] ?? null;
            }
            $this->leaveService->notifyAdmins(
                'Leave Endorsed by Manager',
                "Leave application {$applicationId} has been endorsed by {$mgrName} and is awaiting further approval.",
                'leave',
                $applicationId,
                $appCompanyId,
                $app['employee_id'] ?? null
            );
        } catch (\Throwable $e) {
            log_message('error', 'endorse admin notification error: ' . $e->getMessage());
        }

        $this->db->transComplete();

        return [
            'success' => $this->db->transStatus(),
            'message' => 'Leave application endorsed successfully and forwarded for further approval.'
        ];
    }

    /**
     * Endorse leave application by Department Head (Tier 2 of 3-tier policy).
     */
    public function endorseDeptHead(string $applicationId, string $deptHeadId, ?string $deptHeadName = null, ?string $remarks = null): array
    {
        if (trim($applicationId) === '') {
            return ['success' => false, 'message' => 'Application ID is required.'];
        }

        $app = $this->leaveModel->find($applicationId);
        if (!$app) {
            return ['success' => false, 'message' => 'Leave application not found.'];
        }

        $targetEmp = $this->db->table('employees')->where('id', $app['employee_id'])->get()->getRowArray();
        $targetCompanyId = (string)($targetEmp['company_id'] ?? ($app['company_id'] ?? ''));

        $tenantViolation = $this->verifyTenantIsolation($deptHeadId, $targetCompanyId, 'endorsement', 'Department Head');
        if ($tenantViolation !== null) {
            return $tenantViolation;
        }

        $currentStatus = strtolower(trim((string)($app['status'] ?? 'pending')));
        if (!in_array($currentStatus, ['pending', 'endorsed'], true)) {
            return ['success' => false, 'message' => "Application is already {$app['status']} and cannot be endorsed."];
        }

        if (in_array(strtolower((string)($app['dept_head_status'] ?? '')), ['approved', 'endorsed'], true)) {
            return ['success' => false, 'message' => 'This application is already endorsed by the Department Head.'];
        }

        // Caller identity resolution
        $callerUser = $this->db->table('users')->where('id', $deptHeadId)->get()->getRowArray();
        $callerEmpId = $callerUser['employee_id'] ?? null;
        if (!$callerEmpId) {
            $callerEmpRow = $this->db->table('employees')->where('id', $deptHeadId)->get()->getRowArray();
            if ($callerEmpRow) {
                $callerEmpId = $callerEmpRow['id'];
            }
        }

        // Self-endorsement check (exempt privileged admin roles)
        $isSoftwareAdmin = $this->isSoftwareAppAdminFromId($deptHeadId);
        $isPrivilegedAdmin = $isSoftwareAdmin;
        if (!$isPrivilegedAdmin && !empty($deptHeadId)) {
            $userRow = $this->db->table('users')
                ->select('users.*, roles.code as role_code, roles.name as role_name')
                ->join('roles', 'roles.id = users.role_id', 'left')
                ->groupStart()
                    ->where('users.id', $deptHeadId)
                    ->orWhere('users.employee_id', $deptHeadId)
                ->groupEnd()
                ->get()->getRowArray();
            $permService = new \App\Services\PermissionService();
            $canonicalRole = $permService->canonicalizeRole($userRow['role_code'] ?? $userRow['role_name'] ?? '');
            if ($canonicalRole === 'company_admin' || $canonicalRole === 'hr_admin' || $permService->isHRAdmin($canonicalRole)) {
                $isPrivilegedAdmin = true;
            }
        }
        if (!$isPrivilegedAdmin && ($deptHeadId === $app['employee_id'] || ($callerEmpId && $callerEmpId === $app['employee_id']))) {
            return [
                'success' => false,
                'message' => 'Self-endorsement violation: You cannot endorse your own leave application.'
            ];
        }

        $isSoftwareAdmin = $this->isSoftwareAppAdminFromId($deptHeadId);
        $isOverrideAdmin = false;
        if (!empty($deptHeadId)) {
            try {
                $permService = new \App\Services\PermissionService();
                $isOverrideAdmin = $permService->can($deptHeadId, 'leave.override_tier', ['company_id' => $targetCompanyId])->isAllowed()
                    || $permService->can($deptHeadId, 'leaves.override_tier', ['company_id' => $targetCompanyId])->isAllowed();
            } catch (\Throwable $e) {
                $isOverrideAdmin = false;
            }
        }

        $deptId = $targetEmp['department_id'] ?? null;
        $dept = $deptId ? $this->db->table('departments')->where('id', $deptId)->get()->getRowArray() : null;
        $deptHeadEmpId = $dept['head_id'] ?? null;

        $callerCheckIds = array_values(array_filter([$deptHeadId, $callerEmpId]));
        $isDeptHead = false;
        foreach ($callerCheckIds as $idToCheck) {
            if (!empty($deptHeadEmpId) && (string)$idToCheck === (string)$deptHeadEmpId) {
                $isDeptHead = true;
                break;
            }
        }

        $targetManagerIds = array_values(array_filter([
            $targetEmp['reporting_manager_id'] ?? null,
            $targetEmp['manager_id'] ?? null,
            $targetEmp['line_manager_id'] ?? null,
            $targetEmp['reporting_to'] ?? null,
        ]));

        $managerEndorser = $app['manager_id'] ?? null;
        $isSameManagerAndDeptHead = false;
        if (!empty($deptHeadEmpId)) {
            if (in_array((string)$deptHeadEmpId, array_map('strval', $targetManagerIds), true)
                || (!empty($managerEndorser) && (string)$managerEndorser === (string)$deptHeadEmpId)
                || ($isDeptHead && empty($targetManagerIds))) {
                $isSameManagerAndDeptHead = true;
            }
        }

        // Separation of duties from Line Manager:
        // Enforced when the employee has a distinct line manager different from the Department Head.
        // If employee reports directly to Dept Head (or manager is Dept Head), dual-role endorsement is permitted.
        if (!$isSoftwareAdmin && !$isOverrideAdmin && !$isSameManagerAndDeptHead) {
            if ($managerEndorser && in_array($managerEndorser, $callerCheckIds, true)) {
                return [
                    'success' => false,
                    'message' => 'Separation of duties violation: Department Head endorsement must be performed by a different person than the Line Manager.'
                ];
            }
        }

        if (!$isDeptHead && !$isSoftwareAdmin && !$isOverrideAdmin && !$isPrivilegedAdmin) {
            return [
                'success' => false,
                'message' => 'Unauthorized: You can only endorse leave applications as the Department Head of the employee\'s department.'
            ];
        }

        // Prerequisite: Line manager endorsement required first if Manager tier is in policy
        $fromDate = $app['from_date'] ?? $app['start_date'] ?? date('Y-m-d');
        try {
            $leaveRule = RuleResolver::resolve($targetCompanyId, 'LEAVE', $fromDate, $targetEmp);
            $approvalWorkflow = $leaveRule->get('approval_workflow') ?: [];
            $totalDays = (float)($app['total_days'] ?? 1.0);
            $requiredApprovers = self::resolveRequiredApproversForApplication(
                $approvalWorkflow,
                $totalDays,
                (bool)($app['is_backdated'] ?? false),
                (string)($app['backdated_role'] ?? '')
            );
            $requiresManagerTier = self::isManagerTierRequired($requiredApprovers);
            if ($requiresManagerTier || in_array('Manager', $requiredApprovers, true)) {
                $mgrStatus = strtolower(trim((string)($app['manager_status'] ?? '')));
                if (!in_array($mgrStatus, ['approved', 'endorsed'], true) && !$isOverrideAdmin && !$isSameManagerAndDeptHead) {
                    return [
                        'success' => false,
                        'message' => 'Line Manager endorsement is required before Department Head endorsement according to company leave policy.'
                    ];
                }
            }
        } catch (\Throwable $e) {
            log_message('warning', 'endorseDeptHead workflow resolution warning: ' . $e->getMessage());
        }

        $resolvedName = $deptHeadName;
        if (empty($resolvedName)) {
            $dhEmp = $callerEmpId ? $this->employeeModel->find($callerEmpId) : null;
            $resolvedName = $dhEmp ? trim(($dhEmp['first_name'] ?? '') . ' ' . ($dhEmp['last_name'] ?? '')) : ($callerUser['username'] ?? 'Department Head');
        }

        $now = date('Y-m-d H:i:s');
        $this->db->transStart();

        $updateData = [
            'dept_head_status'      => 'Endorsed',
            'dept_head_id'          => $callerEmpId ?: $deptHeadId,
            'dept_head_name'        => $resolvedName,
            'dept_head_endorsed_at' => $now,
            'dept_head_remarks'     => $remarks ?: 'Endorsed by Department Head',
            'status'                => 'Endorsed',
            'updated_at'            => $now,
        ];

        // If line manager was not yet endorsed and this is dual-role, also satisfy manager endorsement
        if ($isSameManagerAndDeptHead && !in_array(strtolower(trim((string)($app['manager_status'] ?? ''))), ['approved', 'endorsed'], true)) {
            $updateData['manager_status']      = 'Endorsed';
            $updateData['manager_id']          = $callerEmpId ?: $deptHeadId;
            $updateData['manager_name']        = $resolvedName;
            $updateData['manager_endorsed_at'] = $now;
            $updateData['manager_remarks']     = $remarks ?: 'Endorsed by Department Head (Dual-role line manager)';
        }

        $this->leaveModel->update($applicationId, $updateData);

        // Update Step for Department Head (and Line Manager if dual-role) in leave_approval_steps
        if ($this->db->tableExists('leave_approval_steps')) {
            try {
                $dhStep = $this->db->table('leave_approval_steps')
                    ->where('application_id', $applicationId)
                    ->where('approver_role', 'Department Head')
                    ->get()
                    ->getRowArray();

                if ($dhStep) {
                    $this->db->table('leave_approval_steps')
                        ->where('id', $dhStep['id'])
                        ->update([
                            'approver_id' => $callerEmpId ?: $deptHeadId,
                            'status'      => 'Approved',
                            'comments'    => $remarks ?: 'Endorsed by Department Head',
                            'acted_at'    => $now,
                            'updated_at'  => $now,
                        ]);
                }

                if ($isSameManagerAndDeptHead) {
                    $this->db->table('leave_approval_steps')
                        ->where('application_id', $applicationId)
                        ->groupStart()
                            ->where('step_order', 1)
                            ->orWhere('approver_role', 'Line Manager')
                        ->groupEnd()
                        ->update([
                            'approver_id' => $callerEmpId ?: $deptHeadId,
                            'status'      => 'Approved',
                            'comments'    => $remarks ?: 'Endorsed by Department Head (Dual-role line manager)',
                            'acted_at'    => $now,
                            'updated_at'  => $now,
                        ]);
                }
            } catch (\Throwable $stepEx) {
                log_message('notice', 'endorseDeptHead step update error: ' . $stepEx->getMessage());
            }
        }

        // Notify HR of endorsement
        try {
            $this->leaveService->notifyAdmins(
                'Leave Endorsed by Department Head',
                "Leave application {$applicationId} has been endorsed by Department Head ({$resolvedName}) and is awaiting final HR approval.",
                'leave',
                $applicationId,
                $targetCompanyId,
                $app['employee_id'] ?? null
            );
        } catch (\Throwable $e) {
            log_message('error', 'endorseDeptHead admin notification error: ' . $e->getMessage());
        }

        $this->db->transComplete();

        return [
            'success' => $this->db->transStatus(),
            'message' => 'Leave application endorsed by Department Head successfully and forwarded for final HR approval.'
        ];
    }

    /**
     * Unified approval authorization and scope check for a leave application.
     * Enforces:
     * 1. Self-approval blocked (applicant cannot approve own request)
     * 2. Tenant isolation (approver and target employee must share company, software_app_admin excepted)
     * 3. Segregation of duties (endorser cannot grant final approval)
     * 4. Multi-tier prerequisites (Tier 1 manager endorsement required before Tier 2 approval)
     * 5. Tier-specific permission & scope rules:
     *    - For tiers where required approvers is only ["Manager"] (no HR tier):
     *      Direct manager or assigned step approver is allowed, with scope checked
     *      against employee reporting relationship (no leave.approve decision required).
     *      Non-managers require leave.approve / leave.manage with organizational scope.
     *    - For tiers with HR Admin:
     *      Strictly requires leave.hr_approve or leave.manage (with organizational scope).
     *      Managers holding only leave.endorse / leave.approve are denied (403).
     *
     * @param array $app Leave application record
     * @param array $targetEmp Target employee record
     * @param array|null $approverUser User details of the approver
     * @param array|null $approverEmp Employee details of the approver
     * @param string|null $approverId Approver User ID or Employee ID
     * @param array|null $approvalWorkflow Optional resolved approval workflow
     * @param \App\Services\PermissionService|null $permService Optional permission service
     * @param mixed $db Optional database connection
     * @return array ['allowed' => bool, 'code' => int, 'message' => string]
     */
    /**
     * Shared helper to verify approver's organizational scope against the target employee.
     * Enforces fail-closed evaluation:
     * - Any exception, missing approverUser, or missing targetEmp results in 403 denial.
     * - Under DB: calls $permService->can() and $permService->assertInScope().
     * - Under in-memory fallback: validates branch/department matching; denies if missing
     *   branch/department data and role is not company-wide.
     *
     * @param array $app
     * @param array|null $targetEmp
     * @param array|null $approverUser
     * @param array|null $approverEmp
     * @param string $approverId
     * @param string|null $approverUserId
     * @param string $scopePerm
     * @param string $targetCompanyId
     * @param \App\Services\PermissionService $permService
     * @param mixed $db
     * @return array ['allowed' => bool, 'code' => int, 'message' => string]
     */
    private static function verifyApproverScope(
        array $app,
        ?array $targetEmp,
        ?array $approverUser,
        ?array $approverEmp,
        string $approverId,
        ?string $approverUserId,
        string $scopePerm,
        string $targetCompanyId,
        \App\Services\PermissionService $permService,
        $db = null
    ): array {
        $appId = (string)($app['id'] ?? 'unknown');
        $checkApproverId = (string)($approverUserId ?: ($approverId ?: 'unknown'));

        // If approverUser is empty, attempt lookup if db is available
        if (empty($approverUser) && $db && !empty($approverId)) {
            try {
                $userRow = $db->table('users')
                    ->select('users.*, roles.code as role_code, roles.name as role_name')
                    ->join('roles', 'roles.id = users.role_id', 'left')
                    ->where('users.id', $approverId)
                    ->get()->getRowArray();
                if ($userRow) {
                    $approverUser = $userRow;
                    $approverUserId = (string)$userRow['id'];
                    $empId = $userRow['employee_id'] ?? null;
                    if ($empId && empty($approverEmp)) {
                        $approverEmp = $db->table('employees')->where('id', $empId)->get()->getRowArray();
                    }
                } else {
                    $empRow = $db->table('employees')->where('id', $approverId)->get()->getRowArray();
                    if ($empRow) {
                        $approverEmp = $empRow;
                        $uLinked = $db->table('users')
                            ->select('users.*, roles.code as role_code, roles.name as role_name')
                            ->join('roles', 'roles.id = users.role_id', 'left')
                            ->where('users.employee_id', $empRow['id'])
                            ->get()->getRowArray();
                        if ($uLinked) {
                            $approverUser = $uLinked;
                            $approverUserId = (string)$uLinked['id'];
                        }
                    }
                }
            } catch (\Throwable $e) {
                log_message('error', "Approver user lookup in verifyApproverScope threw exception for application {$appId}, approver {$checkApproverId}: " . $e->getMessage());
                return [
                    'allowed' => false,
                    'code'    => 403,
                    'message' => '403 Forbidden: Unable to verify your authorized organizational scope.',
                ];
            }
        }

        if (!empty($approverEmp) && !empty($approverUser)) {
            $approverUser['branch_id'] = $approverUser['branch_id'] ?? ($approverEmp['branch_id'] ?? null);
            $approverUser['department_id'] = $approverUser['department_id'] ?? ($approverEmp['department_id'] ?? null);
            $approverUser['employee_id'] = $approverUser['employee_id'] ?? ($approverEmp['id'] ?? null);
        }

        // Fail-closed if approverUser or targetEmp cannot be resolved
        if (empty($approverUser) || empty($targetEmp)) {
            log_message('error', "verifyApproverScope failed closed for application {$appId}, approver {$checkApproverId}. approverUser: " . (empty($approverUser) ? 'missing' : 'present') . ", targetEmp: " . (empty($targetEmp) ? 'missing' : 'present'));
            return [
                'allowed' => false,
                'code'    => 403,
                'message' => '403 Forbidden: Unable to verify your authorized organizational scope.',
            ];
        }

        if ($db) {
            try {
                $checkId = $approverUserId ?: ($approverUser['id'] ?? $approverId);
                $decision = $permService->can($checkId, $scopePerm, ['company_id' => $targetCompanyId]);
                if (!$decision->isAllowed()) {
                    return [
                        'allowed' => false,
                        'code'    => 403,
                        'message' => '403 Forbidden: You do not have authority to approve this leave application.',
                    ];
                }
                if (!$permService->assertInScope($approverUser, $decision, $targetEmp)) {
                    return [
                        'allowed' => false,
                        'code'    => 403,
                        'message' => '403 Forbidden: Target employee is outside your authorized organizational scope.',
                    ];
                }
            } catch (\Throwable $e) {
                log_message('error', "Permission service scope check exception in verifyApproverScope for application {$appId}, approver {$checkApproverId}: " . $e->getMessage());
                return [
                    'allowed' => false,
                    'code'    => 403,
                    'message' => '403 Forbidden: Unable to verify your authorized organizational scope.',
                ];
            }
        } else {
            try {
                // In-memory scope comparison when DB is not provided
                $rawRole = $approverUser['role_code'] ?? $approverUser['role_name'] ?? $approverUser['role'] ?? 'employee';
                $canonicalRole = $permService->canonicalizeRole($rawRole);
                $approverScope = strtolower(trim((string)($approverUser['scope'] ?? ($approverUser['scope_level'] ?? ''))));

                $isCompanyWide = ($canonicalRole === 'software_app_admin')
                    || ($canonicalRole === 'company_admin')
                    || in_array($approverScope, ['company', 'all'], true);

                if ($isCompanyWide) {
                    return [
                        'allowed' => true,
                        'code'    => 200,
                        'message' => 'Authorized with company-wide scope.',
                    ];
                }

                $approverBranch = $approverUser['branch_id'] ?? ($approverEmp['branch_id'] ?? null);
                $targetBranch = $targetEmp['branch_id'] ?? null;
                $approverDept = $approverUser['department_id'] ?? ($approverEmp['department_id'] ?? null);
                $targetDept = $targetEmp['department_id'] ?? null;

                $hasApproverOrgData = !empty($approverBranch) || !empty($approverDept);
                $hasTargetOrgData = !empty($targetBranch) || !empty($targetDept);

                // If approver or target has no branch/department data and role is not company-wide, deny
                if (!$hasApproverOrgData || !$hasTargetOrgData) {
                    return [
                        'allowed' => false,
                        'code'    => 403,
                        'message' => '403 Forbidden: Unable to verify your authorized organizational scope.',
                    ];
                }

                if ($approverScope === 'branch') {
                    if (empty($approverBranch) || empty($targetBranch) || (string)$approverBranch !== (string)$targetBranch) {
                        return [
                            'allowed' => false,
                            'code'    => 403,
                            'message' => '403 Forbidden: Target employee is outside your authorized organizational scope.',
                        ];
                    }
                }

                if ($approverScope === 'department') {
                    if (empty($approverDept) || empty($targetDept) || (string)$approverDept !== (string)$targetDept) {
                        return [
                            'allowed' => false,
                            'code'    => 403,
                            'message' => '403 Forbidden: Target employee is outside your authorized organizational scope.',
                        ];
                    }
                }

                if (!empty($approverBranch) && !empty($targetBranch) && (string)$approverBranch !== (string)$targetBranch) {
                    return [
                        'allowed' => false,
                        'code'    => 403,
                        'message' => '403 Forbidden: Target employee is outside your authorized organizational scope.',
                    ];
                }

                if (!empty($approverDept) && !empty($targetDept) && (string)$approverDept !== (string)$targetDept) {
                    return [
                        'allowed' => false,
                        'code'    => 403,
                        'message' => '403 Forbidden: Target employee is outside your authorized organizational scope.',
                    ];
                }
            } catch (\Throwable $inMemEx) {
                log_message('error', "In-memory scope verification failed for application {$appId}, approver {$checkApproverId}: " . $inMemEx->getMessage());
                return [
                    'allowed' => false,
                    'code'    => 403,
                    'message' => '403 Forbidden: Unable to verify your authorized organizational scope.',
                ];
            }
        }

        return [
            'allowed' => true,
            'code'    => 200,
            'message' => 'Authorized to approve.',
        ];
    }

    public static function checkApprovalPolicy(
        array $app,
        $targetEmp,
        ?array $approverUser = null,
        ?array $approverEmp = null,
        ?string $approverId = null,
        ?array $approvalWorkflow = null,
        ?\App\Services\PermissionService $permService = null,
        $db = null
    ): array {
        $appId = (string)($app['id'] ?? 'unknown');
        $approverLogId = (string)($approverId ?: 'unknown');

        // Parameter normalization: support both ($app, $targetEmp, ...) and ($app, $approverId, $approverUser, ...)
        if (is_string($targetEmp) && !empty($targetEmp)) {
            $passedId = $targetEmp;
            if ($approverId === null) {
                $approverId = $passedId;
                $approverLogId = $passedId;
            }
            if (is_array($approvalWorkflow) && isset($approvalWorkflow['company_id']) && !isset($approvalWorkflow['workflow_type'])) {
                $targetEmp = $approvalWorkflow;
                $approvalWorkflow = null;
            } elseif (is_array($approverEmp) && isset($approverEmp['company_id']) && isset($approverEmp['reporting_manager_id'])) {
                $targetEmp = $approverEmp;
                $approverEmp = null;
            } else {
                $targetEmp = null;
            }
        }
        if (!is_array($targetEmp)) {
            $targetEmp = null;
        }

        if ($targetEmp === null && $db && !empty($app['employee_id'])) {
            try {
                $targetEmp = $db->table('employees')->where('id', $app['employee_id'])->get()->getRowArray();
            } catch (\Throwable $targetEx) {
                log_message('error', "Failed to load target employee for app {$appId} in checkApprovalPolicy: " . $targetEx->getMessage());
            }
        }

        $permService = $permService ?: new \App\Services\PermissionService();
        $approverEmpId = $approverEmp['id'] ?? ($approverUser['employee_id'] ?? null);
        $approverUserId = $approverUser['id'] ?? null;
        $appEmpId = (string)($app['employee_id'] ?? '');

        if ($approverEmpId !== null) {
            $approverEmpId = (string)$approverEmpId;
        }
        if ($approverUserId !== null) {
            $approverUserId = (string)$approverUserId;
        }

        $approverCheckIds = array_values(array_unique(array_filter([
            $approverId,
            $approverUserId,
            $approverEmpId,
            $approverEmp['id'] ?? null,
            $approverUser['employee_id'] ?? null,
        ])));

        // If approverUser or approverEmp is not supplied, attempt lookup if db is available
        if ($db) {
            if ($approverUser === null && $approverId !== null) {
                try {
                    $uRow = $db->table('users')
                        ->select('users.*, roles.code as role_code, roles.name as role_name')
                        ->join('roles', 'roles.id = users.role_id', 'left')
                        ->where('users.id', $approverId)
                        ->get()->getRowArray();
                    if ($uRow) {
                        $approverUser = $uRow;
                        $approverUserId = (string)$uRow['id'];
                        $approverCheckIds[] = $approverUserId;
                        if (!empty($uRow['employee_id'])) {
                            $approverEmpId = (string)$uRow['employee_id'];
                            $approverCheckIds[] = $approverEmpId;
                        }
                    } else {
                        $eRow = $db->table('employees')->where('id', $approverId)->get()->getRowArray();
                        if ($eRow) {
                            $approverEmp = $eRow;
                            $approverEmpId = (string)$eRow['id'];
                            $approverCheckIds[] = $approverEmpId;
                            $uLinked = $db->table('users')
                                ->select('users.*, roles.code as role_code, roles.name as role_name')
                                ->join('roles', 'roles.id = users.role_id', 'left')
                                ->where('users.employee_id', $eRow['id'])
                                ->get()->getRowArray();
                            if ($uLinked) {
                                $approverUser = $uLinked;
                                $approverUserId = (string)$uLinked['id'];
                                $approverCheckIds[] = $approverUserId;
                            }
                        }
                    }
                } catch (\Throwable $e) {
                    log_message('error', "User lookup failed in checkApprovalPolicy for app {$appId}, approver {$approverLogId}: " . $e->getMessage());
                }
            }
            if ($approverEmp === null && !empty($approverEmpId)) {
                try {
                    $approverEmp = $db->table('employees')->where('id', $approverEmpId)->get()->getRowArray();
                } catch (\Throwable $e) {
                    log_message('error', "Employee lookup failed in checkApprovalPolicy for app {$appId}, approver {$approverLogId}: " . $e->getMessage());
                }
            }
            if ($approverUser === null && !empty($approverEmpId)) {
                try {
                    $uLinked = $db->table('users')
                        ->select('users.*, roles.code as role_code, roles.name as role_name')
                        ->join('roles', 'roles.id = users.role_id', 'left')
                        ->where('users.employee_id', $approverEmpId)
                        ->get()->getRowArray();
                    if ($uLinked) {
                        $approverUser = $uLinked;
                        $approverUserId = (string)$uLinked['id'];
                        $approverCheckIds[] = $approverUserId;
                    }
                } catch (\Throwable $e) {
                    log_message('error', "Linked user lookup failed in checkApprovalPolicy for app {$appId}, approver {$approverLogId}: " . $e->getMessage());
                }
            }
        }

        if ($approverEmp && $approverUser) {
            $approverUser['branch_id'] = $approverUser['branch_id'] ?? ($approverEmp['branch_id'] ?? null);
            $approverUser['department_id'] = $approverUser['department_id'] ?? ($approverEmp['department_id'] ?? null);
            $approverUser['employee_id'] = $approverUser['employee_id'] ?? ($approverEmp['id'] ?? null);
        }

        // 1. Self-approval check (exempt privileged admin roles holding leave approval permissions)
        $rawRole = $approverUser['role_code'] ?? $approverUser['role_name'] ?? $approverUser['role'] ?? 'employee';
        $canonicalRole = $permService->canonicalizeRole($rawRole);
        $isSoftwareAdmin = ($canonicalRole === 'software_app_admin');
        $isCompanyAdmin = ($canonicalRole === 'company_admin');
        $isHrAdmin = ($canonicalRole === 'hr_admin' || $permService->isHRAdmin($rawRole));
        $isPrivilegedAdmin = $isSoftwareAdmin || $isCompanyAdmin || $isHrAdmin;
        $isSelfApproval = (!empty($appEmpId) && in_array($appEmpId, array_map('strval', $approverCheckIds), true));

        if ($isSelfApproval && !$isPrivilegedAdmin) {
            return [
                'allowed' => false,
                'code'    => 403,
                'message' => 'Self-approval violation: You cannot approve your own leave application. An authorized manager or HR must approve it.',
            ];
        }

        // 2. Tenant isolation
        $approverCompanyId = (string)($approverUser['company_id'] ?? ($approverEmp['company_id'] ?? ''));
        $targetCompanyId = (string)($targetEmp['company_id'] ?? ($app['company_id'] ?? ''));

        $rawRole = $approverUser['role_code'] ?? $approverUser['role_name'] ?? $approverUser['role'] ?? 'employee';
        $canonicalRole = $permService->canonicalizeRole($rawRole);
        $isSoftwareAdmin = ($canonicalRole === 'software_app_admin');

        if (!$isSoftwareAdmin && !empty($approverCompanyId) && !empty($targetCompanyId) && $approverCompanyId !== $targetCompanyId) {
            return [
                'allowed' => false,
                'code'    => 403,
                'message' => '403 Forbidden: Cross-tenant approval denied. Approver does not belong to the target employee organization.',
            ];
        }

        // 3. Resolve approval workflow & required approvers
        $fromDate = $app['from_date'] ?? $app['start_date'] ?? date('Y-m-d');
        $totalDays = (float)($app['total_days'] ?? 1.0);

        if ($approvalWorkflow === null) {
            try {
                $leaveRule = RuleResolver::resolve($targetCompanyId, 'LEAVE', $fromDate, $targetEmp);
                $approvalWorkflow = $leaveRule->get('approval_workflow');
            } catch (\Throwable $e) {
                return [
                    'allowed' => false,
                    'code'    => 422,
                    'message' => 'Leave approval workflow is not configured for this organization: ' . $e->getMessage(),
                ];
            }
        }

        $requiredApprovers = self::resolveRequiredApproversForApplication(
            $approvalWorkflow ?: [],
            $totalDays,
            (bool)($app['is_backdated'] ?? false),
            (string)($app['backdated_role'] ?? '')
        );
        $requiresManagerTier = self::isManagerTierRequired($requiredApprovers);
        $requiresDeptHead = in_array('Department Head', $requiredApprovers, true);
        $requiresHrAdmin = in_array('HR Admin', $requiredApprovers, true) || in_array('HR', $requiredApprovers, true) || in_array('HR Administration', $requiredApprovers, true);

        // Check override tier admin
        $isOverrideAdmin = false;
        $candidateIds = array_values(array_unique(array_filter([$approverUserId, $approverId])));
        foreach ($candidateIds as $cId) {
            try {
                if (
                    $permService->can($cId, 'leave.override_tier', ['company_id' => $targetCompanyId])->isAllowed() ||
                    $permService->can($cId, 'leaves.override_tier', ['company_id' => $targetCompanyId])->isAllowed()
                ) {
                    $isOverrideAdmin = true;
                    break;
                }
            } catch (\Throwable $e) {
                log_message('notice', "Override tier check exception for app {$appId}, candidate {$cId}: " . $e->getMessage());
            }
        }

        // 4. Separation of duties: endorser cannot give final approval in multi-tier (exempt privileged self-approval)
        if (count($requiredApprovers) > 1 && !$isSoftwareAdmin && !$isOverrideAdmin && !($isPrivilegedAdmin && $isSelfApproval)) {
            $mgrEndorserId = (string)($app['manager_id'] ?? '');
            $dhEndorserId = (string)($app['dept_head_id'] ?? '');

            if ($mgrEndorserId !== '' && in_array($mgrEndorserId, array_map('strval', $approverCheckIds), true)) {
                return [
                    'allowed' => false,
                    'code'    => 403,
                    'message' => 'Separation of duties violation: The same person cannot endorse as Manager and also approve the same leave application.',
                ];
            }
            if ($dhEndorserId !== '' && in_array($dhEndorserId, array_map('strval', $approverCheckIds), true)) {
                return [
                    'allowed' => false,
                    'code'    => 403,
                    'message' => 'Separation of duties violation: The same person cannot endorse as Department Head and also approve the same leave application.',
                ];
            }
        }

        // 5. Multi-tier prerequisite endorsement checks (if multi-tier required)
        if ($requiresManagerTier && !$isSoftwareAdmin && !$isOverrideAdmin && !($isPrivilegedAdmin && $isSelfApproval)) {
            $managerStatus = strtolower(trim((string)($app['manager_status'] ?? '')));
            $isManagerEndorsed = in_array($managerStatus, ['approved', 'endorsed'], true);
            if (!$isManagerEndorsed) {
                return [
                    'allowed' => false,
                    'code'    => 403,
                    'message' => 'Tier 1 supervisor endorsement is required before Tier 2 approval according to company leave policy.',
                ];
            }
        }

        if ($requiresDeptHead && !$isSoftwareAdmin && !$isOverrideAdmin && !($isPrivilegedAdmin && $isSelfApproval)) {
            $deptHeadStatus = strtolower(trim((string)($app['dept_head_status'] ?? '')));
            $isDeptHeadEndorsed = in_array($deptHeadStatus, ['approved', 'endorsed'], true);
            if (!$isDeptHeadEndorsed) {
                return [
                    'allowed' => false,
                    'code'    => 403,
                    'message' => 'Department Head endorsement is required before final HR approval according to company leave policy.',
                ];
            }
        }

        // 6. Check candidate permissions
        $hasLeaveManage = false;
        $hasLeaveApprove = false;
        $hasLeaveHrApprove = false;
        $hasLeaveEndorse = false;

        $userPerms = [];
        if (!empty($approverUser['permissions']) && is_array($approverUser['permissions'])) {
            $userPerms = $approverUser['permissions'];
        }

        if (in_array('leave.manage', $userPerms, true) || in_array('leaves.manage', $userPerms, true)) {
            $hasLeaveManage = true;
        }
        if (in_array('leave.hr_approve', $userPerms, true) || in_array('leaves.hr_approve', $userPerms, true)) {
            $hasLeaveHrApprove = true;
        }
        if (in_array('leave.approve', $userPerms, true) || in_array('leaves.approve', $userPerms, true)) {
            $hasLeaveApprove = true;
        }
        if (in_array('leave.endorse', $userPerms, true) || in_array('leaves.endorse', $userPerms, true)) {
            $hasLeaveEndorse = true;
        }

        if ($db) {
            foreach ($candidateIds as $cId) {
                try {
                    if (!$hasLeaveManage && (
                        $permService->hasPermission($cId, 'leave.manage') ||
                        $permService->hasPermission($cId, 'leaves.manage') ||
                        $permService->can($cId, 'leave.manage', ['company_id' => $targetCompanyId])->isAllowed() ||
                        $permService->can($cId, 'leaves.manage', ['company_id' => $targetCompanyId])->isAllowed()
                    )) {
                        $hasLeaveManage = true;
                    }
                    if (!$hasLeaveHrApprove && (
                        $permService->hasPermission($cId, 'leave.hr_approve') ||
                        $permService->hasPermission($cId, 'leaves.hr_approve') ||
                        $permService->can($cId, 'leave.hr_approve', ['company_id' => $targetCompanyId])->isAllowed() ||
                        $permService->can($cId, 'leaves.hr_approve', ['company_id' => $targetCompanyId])->isAllowed()
                    )) {
                        $hasLeaveHrApprove = true;
                    }
                    if (!$hasLeaveApprove && (
                        $permService->hasPermission($cId, 'leave.approve') ||
                        $permService->hasPermission($cId, 'leaves.approve') ||
                        $permService->can($cId, 'leave.approve', ['company_id' => $targetCompanyId])->isAllowed() ||
                        $permService->can($cId, 'leaves.approve', ['company_id' => $targetCompanyId])->isAllowed()
                    )) {
                        $hasLeaveApprove = true;
                    }
                    if (!$hasLeaveEndorse && (
                        $permService->hasPermission($cId, 'leave.endorse') ||
                        $permService->hasPermission($cId, 'leaves.endorse') ||
                        $permService->can($cId, 'leave.endorse', ['company_id' => $targetCompanyId])->isAllowed() ||
                        $permService->can($cId, 'leaves.endorse', ['company_id' => $targetCompanyId])->isAllowed()
                    )) {
                        $hasLeaveEndorse = true;
                    }
                } catch (\Throwable $e) {
                    log_message('notice', "Permission lookup exception in checkApprovalPolicy for candidate {$cId}: " . $e->getMessage());
                }
            }
        }

        if ($canonicalRole === 'company_admin') {
            $hasLeaveManage = true;
        }

        $hasAnyLeavePermission = $hasLeaveManage || $hasLeaveHrApprove || $hasLeaveApprove || $hasLeaveEndorse;
        if (!$isSoftwareAdmin && !$isOverrideAdmin && !$hasAnyLeavePermission) {
            return [
                'allowed' => false,
                'code'    => 403,
                'message' => '403 Forbidden: You do not have authority to approve this leave application.',
            ];
        }

        // Direct manager check (reporting relationship)
        $targetManagerIds = array_values(array_unique(array_filter([
            $targetEmp['reporting_manager_id'] ?? null,
            $targetEmp['manager_id'] ?? null,
            $targetEmp['line_manager_id'] ?? null,
            $targetEmp['reporting_to'] ?? null,
            $targetEmp['dept_head_id'] ?? null,
        ])));

        $deptId = $targetEmp['department_id'] ?? null;
        if (empty($targetManagerIds) && !empty($deptId) && $db && method_exists($db, 'tableExists') && $db->tableExists('departments')) {
            try {
                $deptRow = $db->table('departments')->where('id', $deptId)->get()->getRowArray();
                if (!empty($deptRow['head_id'])) {
                    $targetManagerIds[] = $deptRow['head_id'];
                }
            } catch (\Throwable $e) {
                log_message('notice', "Department head lookup exception for department {$deptId}: " . $e->getMessage());
            }
        }

        $isDirectManager = false;
        foreach ($approverCheckIds as $chkId) {
            if (in_array((string)$chkId, array_map('strval', $targetManagerIds), true)) {
                $isDirectManager = true;
                break;
            }
        }

        // Step approver check
        $isStepApprover = false;
        if (!empty($app['id']) && $db && method_exists($db, 'tableExists') && $db->tableExists('leave_approval_steps')) {
            try {
                $stepBuilder = $db->table('leave_approval_steps')
                    ->where('application_id', $app['id'])
                    ->where('status', 'Pending')
                    ->groupStart();
                $hasStepClause = false;
                foreach ($approverCheckIds as $cId) {
                    if ($hasStepClause) {
                        $stepBuilder->orWhere('approver_id', $cId);
                    } else {
                        $stepBuilder->where('approver_id', $cId);
                        $hasStepClause = true;
                    }
                }
                if ($hasStepClause && $stepBuilder->groupEnd()->countAllResults() > 0) {
                    $isStepApprover = true;
                }
            } catch (\Throwable $e) {
                log_message('notice', "Step approver check exception for app {$appId}: " . $e->getMessage());
            }
        }

        // 7. Tier-specific authority & scope rules
        if ($requiresHrAdmin) {
            // Tier with HR Admin (e.g. 3-7 days, 8+ days):
            // Requires leave.hr_approve or leave.manage (or Software Admin / Override Admin).
            if (!$isSoftwareAdmin && !$isOverrideAdmin && !$hasLeaveHrApprove && !$hasLeaveManage && !($isPrivilegedAdmin && ($hasLeaveApprove || $hasLeaveHrApprove || $hasLeaveManage))) {
                return [
                    'allowed' => false,
                    'code'    => 403,
                    'message' => '403 Forbidden: Final approval for this leave tier requires leave.hr_approve or leave.manage permission.',
                ];
            }

            // Software Admin, Override-tier admin, and privileged self-approver with approval permissions bypass direct scope check
            if ($isSoftwareAdmin || $isOverrideAdmin || ($isPrivilegedAdmin && $isSelfApproval && ($hasLeaveApprove || $hasLeaveHrApprove || $hasLeaveManage))) {
                return [
                    'allowed' => true,
                    'code'    => 200,
                    'message' => 'Authorized to approve as administrator.',
                ];
            }

            $scopePerm = $hasLeaveHrApprove ? 'leave.hr_approve' : 'leave.manage';
            return self::verifyApproverScope(
                $app,
                $targetEmp,
                $approverUser,
                $approverEmp,
                (string)$approverId,
                $approverUserId,
                $scopePerm,
                $targetCompanyId,
                $permService,
                $db
            );
        } else {
            // Manager-only tier (no HR tier, e.g. 1-2 days where required approvers is only ["Manager"]):
            // Direct manager or assigned step approver is allowed, with scope checked
            // against employee's reporting relationship (no leave.approve decision required).
            if ($isDirectManager || $isStepApprover) {
                return [
                    'allowed' => true,
                    'code'    => 200,
                    'message' => 'Authorized to approve as direct manager or step approver.',
                ];
            }

            // If not direct manager and not step approver:
            if ($isSoftwareAdmin || $isOverrideAdmin || ($isPrivilegedAdmin && $isSelfApproval && ($hasLeaveApprove || $hasLeaveHrApprove || $hasLeaveManage))) {
                return [
                    'allowed' => true,
                    'code'    => 200,
                    'message' => 'Authorized to approve as administrator.',
                ];
            }

            // Approver is NOT the employee's direct manager or step approver:
            // Non-direct manager:
            // If they have leave.approve or leave.manage, perform scope check via shared helper:
            if ($hasLeaveApprove || $hasLeaveManage) {
                $scopePerm = $hasLeaveApprove ? 'leave.approve' : 'leave.manage';
                return self::verifyApproverScope(
                    $app,
                    $targetEmp,
                    $approverUser,
                    $approverEmp,
                    (string)$approverId,
                    $approverUserId,
                    $scopePerm,
                    $targetCompanyId,
                    $permService,
                    $db
                );
            }

            // Approver holds only leave.endorse (or has no leave.approve/leave.manage)
            // and is NOT the employee's direct manager or step approver.
            // Their reporting scope does not cover this employee.
            return [
                'allowed' => false,
                'code'    => 403,
                'message' => '403 Forbidden: Target employee is outside your authorized organizational scope.',
            ];
        }

        return [
            'allowed' => true,
            'code'    => 200,
            'message' => 'Authorized to approve.',
        ];
    }

    /**
     * Instance wrapper for checkApprovalPolicy.
     */
    public function canApproveApplication(
        array $app,
        array $targetEmp,
        ?array $approverUser = null,
        ?array $approverEmp = null,
        ?string $approverId = null,
        ?array $approvalWorkflow = null
    ): array {
        return self::checkApprovalPolicy($app, $targetEmp, $approverUser, $approverEmp, $approverId, $approvalWorkflow, new \App\Services\PermissionService(), $this->db);
    }

    /**
     * Approve leave application with re-checked balance, attendance protection, and atomic state transition.
     */
    public function approveLeave(string $applicationId, string $approverId, ?string $remarks = null): array
    {
        if (trim($applicationId) === '') {
            return ['success' => false, 'message' => 'Application ID is required.'];
        }

        $app = $this->leaveModel->find($applicationId);
        if (!$app) {
            return ['success' => false, 'message' => 'Leave application not found.'];
        }

        if (strtolower((string)($app['status'] ?? '')) === 'approved') {
            return ['success' => false, 'message' => 'This application is already approved.'];
        }
        if (in_array(strtolower((string)($app['status'] ?? '')), ['cancelled', 'rejected'], true)) {
            return ['success' => false, 'message' => "Cannot approve a {$app['status']} leave application."];
        }

        // Target employee details
        $targetEmp = $this->db->table('employees')->where('id', $app['employee_id'])->get()->getRowArray();
        $targetCompanyId = (string)($targetEmp['company_id'] ?? '');

        // Resolve Approver User and Employee identities
        $approverUser = null;
        $approverEmp = null;
        $approverEmpId = null;
        $approverUserId = null;

        $userRow = $this->db->table('users')
            ->select('users.*, roles.code as role_code, roles.name as role_name')
            ->join('roles', 'roles.id = users.role_id', 'left')
            ->where('users.id', $approverId)
            ->get()->getRowArray();

        if ($userRow) {
            $approverUser = $userRow;
            $approverUserId = $userRow['id'];
            $approverEmpId = $userRow['employee_id'] ?? null;
            if ($approverEmpId) {
                $approverEmp = $this->db->table('employees')->where('id', $approverEmpId)->get()->getRowArray();
            }
        } else {
            // Check if $approverId is an employee ID
            $empRow = $this->db->table('employees')->where('id', $approverId)->get()->getRowArray();
            if ($empRow) {
                $approverEmp = $empRow;
                $approverEmpId = $empRow['id'];
                $approverUser = $this->db->table('users')
                    ->select('users.*, roles.code as role_code, roles.name as role_name')
                    ->join('roles', 'roles.id = users.role_id', 'left')
                    ->where('users.employee_id', $empRow['id'])
                    ->get()->getRowArray();
                $approverUserId = $approverUser['id'] ?? null;
            }
        }

        if ($approverEmp && $approverUser) {
            $approverUser['branch_id'] = $approverUser['branch_id'] ?? ($approverEmp['branch_id'] ?? null);
            $approverUser['department_id'] = $approverUser['department_id'] ?? ($approverEmp['department_id'] ?? null);
            $approverUser['employee_id'] = $approverUser['employee_id'] ?? ($approverEmp['id'] ?? null);
        }

        // Unified preliminary authorization and scope check
        try {
            $auth = $this->canApproveApplication($app, $targetEmp, $approverUser, $approverEmp, $approverId);
        } catch (\Throwable $authEx) {
            log_message('error', "Exception in preliminary canApproveApplication for application {$applicationId}, approver {$approverId}: " . $authEx->getMessage());
            return [
                'success' => false,
                'code'    => 403,
                'message' => '403 Forbidden: Unable to verify your authorized organizational scope.',
            ];
        }
        if (!$auth['allowed']) {
            return [
                'success' => false,
                'code'    => $auth['code'] ?? 403,
                'message' => $auth['message'],
            ];
        }

        $fromDate = $app['from_date'] ?? $app['start_date'] ?? date('Y-m-d');
        $toDate = $app['to_date'] ?? $app['end_date'] ?? $fromDate;
        $start = new \DateTime($fromDate);
        $end = new \DateTime($toDate);

        // Check settled attendance
        $attService = new AttendanceService();
        $currDate = clone $start;
        while ($currDate <= $end) {
            $dateStr = $currDate->format('Y-m-d');
            if ($attService->isAttendanceSettled($app['employee_id'], $dateStr)) {
                return [
                    'success' => false,
                    'message' => "422 Unprocessable Entity: Cannot approve leave application. Attendance on {$dateStr} is locked and settled in payroll."
                ];
            }
            $currDate->modify('+1 day');
        }

        // Probation check
        try {
            $probService = new \App\Services\ProbationLeaveEligibilityService();
            $eligCheck = $probService->checkLeaveEligibility($app['employee_id'], $app['leave_type_id'], $fromDate);
            if (!$eligCheck['is_eligible']) {
                $msg = !empty($eligCheck['blocked_reason'])
                    ? $eligCheck['blocked_reason']
                    : "Approval blocked: Employee is not yet eligible for this leave type during probation period.";
                return ['success' => false, 'message' => $msg];
            }
        } catch (\Throwable $e) {
            log_message('error', 'Probation check in approveLeave: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Unable to verify probation eligibility. Please contact HR.'];
        }

        $this->db->transStart();

        $lockedApp = $this->lockRow('leave_applications', ['id' => $applicationId]);
        if (!$lockedApp) {
            $this->db->transRollback();
            return ['success' => false, 'message' => 'This leave application is no longer available.'];
        }

        $currLockedStatus = strtolower(trim((string)($lockedApp['status'] ?? '')));
        if ($currLockedStatus === 'approved') {
            $this->db->transRollback();
            return ['success' => true, 'message' => 'This leave application has already been approved.'];
        }
        if ($currLockedStatus === 'rejected') {
            $this->db->transRollback();
            return ['success' => false, 'message' => 'Cannot approve: This leave application was already rejected.'];
        }
        if ($currLockedStatus === 'cancelled') {
            $this->db->transRollback();
            return ['success' => false, 'message' => 'Cannot approve: This leave application was cancelled or withdrawn.'];
        }
        if (!in_array($currLockedStatus, ['pending', 'endorsed', ''], true)) {
            $this->db->transRollback();
            return ['success' => false, 'message' => "Application cannot be approved from its current status ('{$lockedApp['status']}'). Please refresh the page."];
        }

        $employeeId = $lockedApp['employee_id'];
        $empRow = $this->db->table('employees')->where('id', $employeeId)->get()->getRowArray();
        $empCompanyId = (string)($empRow['company_id'] ?? '');
        $totalDays = (float)($lockedApp['total_days'] ?? 1.0);

        try {
            $leaveRule = RuleResolver::resolve($empCompanyId, 'LEAVE', $fromDate, $empRow);
            $approvalWorkflow = $leaveRule->get('approval_workflow');
        } catch (\Throwable $e) {
            $this->db->transRollback();
            return [
                'success' => false,
                'message' => 'Leave approval workflow is not configured for this organization: ' . $e->getMessage()
            ];
        }

        $workflowType = $approvalWorkflow['workflow_type'] ?? null;
        if (empty($workflowType)) {
            $this->db->transRollback();
            return [
                'success' => false,
                'message' => 'Leave approval workflow is not configured for this organization: workflow_type is missing.'
            ];
        }

        $requiredApprovers = self::resolveRequiredApproversForApplication(
            $approvalWorkflow ?: [],
            $totalDays,
            (bool)($lockedApp['is_backdated'] ?? false),
            (string)($lockedApp['backdated_role'] ?? '')
        );
        $requiresManagerTier = self::isManagerTierRequired($requiredApprovers);
        $requiresDeptHead = in_array('Department Head', $requiredApprovers, true);
        $requiresHrAdmin = in_array('HR Admin', $requiredApprovers, true) || in_array('HR', $requiredApprovers, true) || in_array('HR Administration', $requiredApprovers, true);

        // Unified approval authority and scope check on locked record
        try {
            $authLocked = $this->canApproveApplication($lockedApp, $empRow, $approverUser, $approverEmp, $approverId, $approvalWorkflow);
        } catch (\Throwable $authEx) {
            $this->db->transRollback();
            log_message('error', "Exception in locked canApproveApplication for application {$applicationId}, approver {$approverId}: " . $authEx->getMessage());
            return [
                'success' => false,
                'code'    => 403,
                'message' => '403 Forbidden: Unable to verify your authorized organizational scope.',
            ];
        }
        if (!$authLocked['allowed']) {
            $this->db->transRollback();
            return [
                'success' => false,
                'code'    => $authLocked['code'] ?? 403,
                'message' => $authLocked['message'],
            ];
        }

        $leaveTypeId = $lockedApp['leave_type_id'];
        $paidDays = isset($lockedApp['paid_days']) ? (float)$lockedApp['paid_days'] : $totalDays;
        $unpaidDays = (float)($lockedApp['unpaid_days'] ?? 0.0);
        $unpaidTypeId = $lockedApp['unpaid_leave_type_id'] ?? null;
        $isHalfDay = !empty($lockedApp['is_half_day']);
        $sandwichRule = !empty($lockedApp['sandwich_rule']) || !empty($lockedApp['sandwich_rule_applies']) || !empty($lockedApp['apply_sandwich_rule']);

        // BALANCE RE-CHECK before approving
        $leaveTypeRow = $this->db->table('leave_types')->where('id', $leaveTypeId)->get()->getRowArray();
        $ruleEnt = $this->leaveService->resolveLeaveEntitlement($empCompanyId, $empRow, $leaveTypeRow, $fromDate);
        $allowNegative = (bool)($ruleEnt['allow_negative_balance'] ?? false);
        $maxNegative = (float)($ruleEnt['max_negative_days'] ?? 0.0);

        $yearSplitData = $this->leaveService->resolveApplicationYearSplit($lockedApp, $paidDays, $unpaidDays, $fromDate, $toDate, $isHalfDay, $sandwichRule);
        $yearSplitPaid = $yearSplitData['paid'];
        $yearSplitUnpaid = $yearSplitData['unpaid'];

        if ($paidDays > 0) {
            foreach ($yearSplitPaid as $yr => $yrDays) {
                if ($yrDays <= 0) continue;
                $this->lockRow('leave_balances', [
                    'employee_id'   => $employeeId,
                    'leave_type_id' => $leaveTypeId,
                    'year'          => $yr,
                ]);

                $liveBal = $this->leaveService->getEmployeeBalance($employeeId, $leaveTypeId, $yr, $leaveTypeRow, false, $fromDate);
                $avail = (float)($liveBal['available_balance'] ?? 0.0);
                $minAllowed = ($allowNegative && $maxNegative > 0) ? -$maxNegative : 0.0;
                if ($avail < $minAllowed) {
                    $this->db->transRollback();
                    return [
                        'success' => false,
                        'message' => "Approval blocked: Employee leave quota has been depleted by a concurrent transaction (Available: {$avail}, Required: {$yrDays})."
                    ];
                }
            }
        }

        // Accurate State & Audit Trail Update
        $approverDisplayName = null;
        if (!empty($approverUser)) {
            $approverDisplayName = trim(($approverUser['first_name'] ?? '') . ' ' . ($approverUser['last_name'] ?? '')) ?: ($approverUser['username'] ?? 'Approver');
        } elseif (!empty($approverEmp)) {
            $approverDisplayName = trim(($approverEmp['first_name'] ?? '') . ' ' . ($approverEmp['last_name'] ?? ''));
        }

        $now = date('Y-m-d H:i:s');
        $updateData = [
            'status'      => 'Approved',
            'approved_by' => $approverId,
            'approved_at' => $now,
            'updated_at'  => $now,
        ];

        if ($requiresHrAdmin) {
            // Multi-tier with HR Admin / final approval tier: record final approval without overwriting manager fields.
            // "HR Admin" is not a distinct role; anyone with leave.approve or leave.manage (e.g. another manager) can give this approval.
            $updateData['hr_status']      = 'Approved';
            $updateData['hr_id']          = $approverId;
            $updateData['hr_name']        = $approverDisplayName ?: 'HR Administrator';
            $updateData['hr_approved_at'] = $now;
            $updateData['hr_remarks']     = $remarks ?: 'Final approval confirmed';
        } else {
            // Single-tier Manager approval: store as manager approval; do NOT set hr_status or hr_id to manager
            $updateData['manager_status']      = 'Approved';
            $updateData['manager_id']          = $approverEmpId ?: $approverId;
            $updateData['manager_name']        = $approverDisplayName ?: 'Reporting Manager';
            $updateData['manager_endorsed_at'] = $now;
            $updateData['manager_remarks']     = $remarks ?: 'Approved by Reporting Manager';
            $updateData['hr_status']           = null;
            $updateData['hr_id']               = null;
            $updateData['hr_approved_at']      = null;
            $updateData['hr_remarks']          = null;
        }

        $currentRawStatus = trim((string)($lockedApp['status'] ?? ''));
        $allowedStatuses = array_values(array_unique(array_filter(['Pending', 'pending', 'Endorsed', 'endorsed', 'Approved', 'approved', $currentRawStatus])));
        $this->db->table('leave_applications')
            ->where('id', $applicationId)
            ->whereIn('status', $allowedStatuses)
            ->update($updateData);

        if ($this->db->affectedRows() === 0) {
            $freshApp = $this->db->table('leave_applications')->where('id', $applicationId)->get()->getRowArray();
            $freshStatus = strtolower(trim((string)($freshApp['status'] ?? '')));
            if ($freshStatus === 'approved') {
                log_message('info', "Leave application {$applicationId} was already approved concurrently.");
            } else {
                $this->db->transRollback();
                $actualStatus = !empty($freshApp['status']) ? $freshApp['status'] : 'Modified';
                return [
                    'success' => false,
                    'message' => "Action conflict: The leave application status was already changed to '{$actualStatus}' by another user or session. Please refresh the page."
                ];
            }
        }

        // Update leave_approval_steps: mark corresponding step as Approved
        if ($this->db->tableExists('leave_approval_steps')) {
            try {
                if ($requiresHrAdmin) {
                    $this->db->table('leave_approval_steps')
                        ->where('application_id', $applicationId)
                        ->groupStart()
                            ->where('approver_role', 'HR Administration')
                            ->orWhere('approver_role', 'HR Admin')
                            ->orWhere('approver_role', 'HR')
                        ->groupEnd()
                        ->update([
                            'approver_id' => $approverId,
                            'status'      => 'Approved',
                            'comments'    => $remarks ?: 'Final approval confirmed',
                            'acted_at'    => $now,
                            'updated_at'  => $now,
                        ]);
                } else {
                    $this->db->table('leave_approval_steps')
                        ->where('application_id', $applicationId)
                        ->groupStart()
                            ->where('step_order', 1)
                            ->orWhere('approver_role', 'Line Manager')
                        ->groupEnd()
                        ->update([
                            'approver_id' => $approverEmpId ?: $approverId,
                            'status'      => 'Approved',
                            'comments'    => $remarks ?: 'Approved by Reporting Manager',
                            'acted_at'    => $now,
                            'updated_at'  => $now,
                        ]);
                }
            } catch (\Throwable $stepEx) {
                log_message('notice', 'approveLeave step update error: ' . $stepEx->getMessage());
            }
        }

        $fromYear = (int)date('Y', strtotime($fromDate));
        $toYear   = (int)date('Y', strtotime($toDate));

        $isCrossYear = ($fromYear !== $toYear);
        if (!$isCrossYear) {
            $activeYears = [];
            foreach ($yearSplitPaid as $y => $d) {
                if ((float)$d > 0) $activeYears[(string)$y] = true;
            }
            foreach ($yearSplitUnpaid as $y => $d) {
                if ((float)$d > 0) $activeYears[(string)$y] = true;
            }
            if (count($activeYears) > 1) {
                $isCrossYear = true;
            }
        }

        // Post Paid Component to leave_balances and leave_transactions
        if ($paidDays > 0) {
            foreach ($yearSplitPaid as $yr => $yrDays) {
                $yrDays = (float)$yrDays;
                if ($yrDays <= 0) continue;

                $startOfYear = "{$yr}-01-01";
                $endOfYear   = "{$yr}-12-31";
                $effectiveDateForYear = ($fromDate > $startOfYear) ? $fromDate : $startOfYear;
                if ($effectiveDateForYear > $endOfYear) $effectiveDateForYear = $endOfYear;
                if ($effectiveDateForYear > $toDate) $effectiveDateForYear = $toDate;
                $txDate = ($yr === (int)date('Y') && !$isCrossYear) ? date('Y-m-d') : $effectiveDateForYear;

                $idempotencyKey = $isCrossYear
                    ? "LEAVE-APP-{$applicationId}-DED-PAID-{$yr}"
                    : "LEAVE-APP-{$applicationId}-DED-PAID";
                $cycleNo = $isCrossYear
                    ? "LEAVE-APP-{$applicationId}-{$yr}"
                    : "LEAVE-APP-{$applicationId}";

                // Check for existing transaction to prevent duplicate deductions on re-approval
                $existingTx = $this->db->table('leave_transactions')
                    ->where('company_id', $empCompanyId)
                    ->where('idempotency_key', $idempotencyKey)
                    ->get()
                    ->getRowArray();

                if (!$existingTx) {
                    $existingTx = $this->db->table('leave_transactions')
                        ->where('employee_id', $employeeId)
                        ->where('leave_type_id', $leaveTypeId)
                        ->where('leave_year', (int)$yr)
                        ->where('transaction_type', 'Deduction')
                        ->groupStart()
                            ->where('reference_id', $applicationId)
                            ->orWhere('related_application_id', $applicationId)
                            ->orWhere('cycle_no', $cycleNo)
                        ->groupEnd()
                        ->get()
                        ->getRowArray();
                }

                $isReversedTx = false;
                if ($existingTx) {
                    $revCount = $this->db->table('leave_transactions')
                        ->where('employee_id', $employeeId)
                        ->where('transaction_type', 'Reversal')
                        ->groupStart()
                            ->where('reversal_of', $existingTx['id'])
                            ->orWhere('reference_id', $applicationId)
                            ->orWhere('related_application_id', $applicationId)
                        ->groupEnd()
                        ->countAllResults();
                    if ($revCount > 0) {
                        $isReversedTx = true;
                        $idempotencyKey = "LEAVE-APP-{$applicationId}-DED-PAID" . ($isCrossYear ? "-{$yr}" : '') . "-REAPP";
                        $cycleNo = "LEAVE-APP-{$applicationId}" . ($isCrossYear ? "-{$yr}" : '') . "-REAPP";
                    }
                }

                if ($existingTx && !$isReversedTx) {
                    // Already posted - ensure pending_leave_days is decremented without double-adding to approved_leave_days
                    $this->db->query(
                        "UPDATE leave_balances 
                         SET pending_leave_days = CASE WHEN (pending_leave_days - ?) < 0 THEN 0 ELSE (pending_leave_days - ?) END
                         WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                        [$yrDays, $yrDays, $employeeId, $leaveTypeId, $yr]
                    );
                    continue;
                }

                $balanceRow = $this->lockRow('leave_balances', [
                    'employee_id'   => $employeeId,
                    'leave_type_id' => $leaveTypeId,
                    'year'          => $yr,
                ]);

                if ($balanceRow) {
                    $this->db->query(
                        "UPDATE leave_balances 
                         SET approved_leave_days = approved_leave_days + ?,
                             pending_leave_days = CASE WHEN (pending_leave_days - ?) < 0 THEN 0 ELSE (pending_leave_days - ?) END
                         WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                        [$yrDays, $yrDays, $yrDays, $employeeId, $leaveTypeId, $yr]
                    );
                } else {
                    $this->balanceModel->insert([
                        'id'                     => 'bal-' . bin2hex(random_bytes(6)),
                        'employee_id'            => $employeeId,
                        'leave_type_id'          => $leaveTypeId,
                        'year'                   => $yr,
                        'opening_balance'        => 0.0,
                        'allocated_days'         => 0.0,
                        'accrued_days'           => 0.0,
                        'carry_forward_days'     => 0.0,
                        'approved_leave_days'    => $yrDays,
                        'pending_leave_days'     => 0.0,
                        'unpaid_adjustment_days' => 0.0,
                        'encashed_days'          => 0.0,
                        'created_at'             => date('Y-m-d H:i:s'),
                        'updated_at'             => date('Y-m-d H:i:s')
                    ]);
                }

                $this->transactionModel->insert([
                    'id'                     => 'tx-' . bin2hex(random_bytes(6)),
                    'company_id'             => $empCompanyId,
                    'employee_id'            => $employeeId,
                    'leave_type_id'          => $leaveTypeId,
                    'leave_year'             => (int)$yr,
                    'transaction_type'       => 'Deduction',
                    'days'                   => $yrDays,
                    'reference_id'           => $applicationId,
                    'cycle_no'               => $cycleNo,
                    'idempotency_key'        => $idempotencyKey,
                    'related_application_id' => $applicationId,
                    'remarks'                => $remarks ?: 'Approved leave application deduction (Paid)',
                    'effective_date'         => $effectiveDateForYear,
                    'transaction_date'       => $txDate
                ]);
            }
        }

        // Post Unpaid Component if applicable
        if ($unpaidDays > 0) {
            if (empty($unpaidTypeId)) {
                $resolvedUl = $this->leaveService->resolveAuthoritativeUnpaidLeaveType($empCompanyId ?: '');
                $unpaidTypeId = $resolvedUl['id'] ?? null;
                if (!empty($unpaidTypeId)) {
                    $this->db->table('leave_applications')
                        ->where('id', $applicationId)
                        ->update(['unpaid_leave_type_id' => $unpaidTypeId]);
                }
            }

            $targetUnpaidTypeId = $unpaidTypeId;
            if (!empty($targetUnpaidTypeId)) {
                foreach ($yearSplitUnpaid as $yr => $yrDays) {
                    $yrDays = (float)$yrDays;
                    if ($yrDays <= 0) continue;

                    $startOfYear = "{$yr}-01-01";
                    $endOfYear   = "{$yr}-12-31";
                    $effectiveDateForYear = ($fromDate > $startOfYear) ? $fromDate : $startOfYear;
                    if ($effectiveDateForYear > $endOfYear) $effectiveDateForYear = $endOfYear;
                    if ($effectiveDateForYear > $toDate) $effectiveDateForYear = $toDate;
                    $txDate = ($yr === (int)date('Y') && !$isCrossYear) ? date('Y-m-d') : $effectiveDateForYear;

                    $idempotencyKey = $isCrossYear
                        ? "LEAVE-APP-{$applicationId}-DED-UNPAID-{$yr}"
                        : "LEAVE-APP-{$applicationId}-DED-UNPAID";
                    $cycleNo = $isCrossYear
                        ? "LEAVE-APP-{$applicationId}-UNPAID-{$yr}"
                        : "LEAVE-APP-{$applicationId}-UNPAID";

                    $existingTx = $this->db->table('leave_transactions')
                        ->where('company_id', $empCompanyId)
                        ->where('idempotency_key', $idempotencyKey)
                        ->get()
                        ->getRowArray();

                    if (!$existingTx) {
                        $existingTx = $this->db->table('leave_transactions')
                            ->where('employee_id', $employeeId)
                            ->where('leave_type_id', $targetUnpaidTypeId)
                            ->where('leave_year', (int)$yr)
                            ->where('transaction_type', 'Deduction')
                            ->groupStart()
                                ->where('reference_id', $applicationId)
                                ->orWhere('related_application_id', $applicationId)
                                ->orWhere('cycle_no', $cycleNo)
                            ->groupEnd()
                            ->get()
                            ->getRowArray();
                    }

                    $isReversedUnpaid = false;
                    if ($existingTx) {
                        $revCount = $this->db->table('leave_transactions')
                            ->where('employee_id', $employeeId)
                            ->where('transaction_type', 'Reversal')
                            ->groupStart()
                                ->where('reversal_of', $existingTx['id'])
                                ->orWhere('reference_id', $applicationId)
                                ->orWhere('related_application_id', $applicationId)
                            ->groupEnd()
                            ->countAllResults();
                        if ($revCount > 0) {
                            $isReversedUnpaid = true;
                            $idempotencyKey = "LEAVE-APP-{$applicationId}-DED-UNPAID" . ($isCrossYear ? "-{$yr}" : '') . "-REAPP";
                            $cycleNo = "LEAVE-APP-{$applicationId}-UNPAID" . ($isCrossYear ? "-{$yr}" : '') . "-REAPP";
                        }
                    }

                    if ($existingTx && !$isReversedUnpaid) {
                        $this->db->query(
                            "UPDATE leave_balances 
                             SET pending_leave_days = CASE WHEN (pending_leave_days - ?) < 0 THEN 0 ELSE (pending_leave_days - ?) END
                             WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                            [$yrDays, $yrDays, $employeeId, $targetUnpaidTypeId, $yr]
                        );
                        continue;
                    }

                    $unpaidBalRow = $this->lockRow('leave_balances', [
                        'employee_id'   => $employeeId,
                        'leave_type_id' => $targetUnpaidTypeId,
                        'year'          => $yr,
                    ]);

                    if ($unpaidBalRow) {
                        $this->db->query(
                            "UPDATE leave_balances 
                             SET approved_leave_days = approved_leave_days + ?,
                                 pending_leave_days = CASE WHEN (pending_leave_days - ?) < 0 THEN 0 ELSE (pending_leave_days - ?) END,
                                 unpaid_adjustment_days = unpaid_adjustment_days + ?
                             WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                            [$yrDays, $yrDays, $yrDays, $yrDays, $employeeId, $targetUnpaidTypeId, $yr]
                        );
                    } else {
                        $this->balanceModel->insert([
                            'id'                     => 'bal-' . bin2hex(random_bytes(6)),
                            'employee_id'            => $employeeId,
                            'leave_type_id'          => $targetUnpaidTypeId,
                            'year'                   => $yr,
                            'opening_balance'        => 0.0,
                            'allocated_days'         => 0.0,
                            'accrued_days'           => 0.0,
                            'carry_forward_days'     => 0.0,
                            'approved_leave_days'    => $yrDays,
                            'pending_leave_days'     => 0.0,
                            'unpaid_adjustment_days' => $yrDays,
                            'encashed_days'          => 0.0,
                            'created_at'             => date('Y-m-d H:i:s'),
                            'updated_at'             => date('Y-m-d H:i:s')
                        ]);
                    }

                    $this->transactionModel->insert([
                        'id'                     => 'tx-' . bin2hex(random_bytes(6)),
                        'company_id'             => $empCompanyId,
                        'employee_id'            => $employeeId,
                        'leave_type_id'          => $targetUnpaidTypeId,
                        'leave_year'             => (int)$yr,
                        'transaction_type'       => 'Deduction',
                        'days'                   => $yrDays,
                        'reference_id'           => $applicationId,
                        'cycle_no'               => $cycleNo,
                        'idempotency_key'        => $idempotencyKey,
                        'related_application_id' => $applicationId,
                        'remarks'                => ($remarks ?: 'Approved leave application deduction') . " (Unpaid loss of pay: {$yrDays} days)",
                        'effective_date'         => $effectiveDateForYear,
                        'transaction_date'       => $txDate
                    ]);
                }
            }
        }

        // Attendance Sync with protection against overwriting Present / Late attendance
        $calcRes = $this->leaveService->calculateLeaveDays($employeeId, $fromDate, $toDate, $isHalfDay, $sandwichRule, null, ($paidDays > 0));
        $chargeableDates = [];
        if (!empty($calcRes['breakdown'])) {
            foreach ($calcRes['breakdown'] as $b) {
                if (($b['chargeable'] ?? 0) > 0) {
                    $chargeableDates[$b['date']] = true;
                }
            }
        } else {
            $cTmp = clone $start;
            while ($cTmp <= $end) {
                $chargeableDates[$cTmp->format('Y-m-d')] = true;
                $cTmp->modify('+1 day');
            }
        }

        $curr = clone $start;
        while ($curr <= $end) {
            $dateStr = $curr->format('Y-m-d');
            if (empty($chargeableDates[$dateStr])) {
                $curr->modify('+1 day');
                continue;
            }

            $attExists = $this->db->table('attendance_logs')
                ->where('employee_id', $employeeId)
                ->where('date', $dateStr)
                ->get()
                ->getRowArray();

            if ($attExists) {
                $existingStatus = strtolower(trim((string)($attExists['status'] ?? '')));
                // Do not overwrite Holiday, Weekly Off, Present, or Late
                if (!in_array($existingStatus, ['holiday', 'weekly off', 'present', 'late'], true)) {
                    $this->db->table('attendance_logs')
                        ->where('id', $attExists['id'])
                        ->update([
                            'status'      => $isHalfDay ? 'Half Day' : 'On Leave',
                            'is_approved' => 1,
                            'updated_at'  => date('Y-m-d H:i:s')
                        ]);
                } elseif ($isHalfDay && in_array($existingStatus, ['present', 'late'], true)) {
                    // For half-day, if already present/late, preserve punch and note half day leave
                    $this->db->table('attendance_logs')
                        ->where('id', $attExists['id'])
                        ->update([
                            'status'      => 'Half Day',
                            'updated_at'  => date('Y-m-d H:i:s')
                        ]);
                }
            } else {
                $this->db->table('attendance_logs')->insert([
                    'id'                  => 'att-' . bin2hex(random_bytes(6)),
                    'company_id'          => $empCompanyId,
                    'employee_id'         => $employeeId,
                    'date'                => $dateStr,
                    'status'              => $isHalfDay ? 'Half Day' : 'On Leave',
                    'working_hours'       => 0.0,
                    'late_minutes'        => 0,
                    'is_approved'         => 1,
                    'verification_method' => 'SYSTEM_LEAVE_SYNC',
                    'created_at'          => date('Y-m-d H:i:s'),
                    'updated_at'          => date('Y-m-d H:i:s')
                ]);
            }

            $curr->modify('+1 day');
        }

        // Notify applicant
        try {
            $notifModel = new NotificationModel();
            $notifModel->insert([
                'id'                => 'notif-' . bin2hex(random_bytes(6)),
                'user_id'           => $employeeId,
                'title'             => 'Leave Application Approved',
                'message'           => "Your leave application from {$fromDate} to {$toDate} has been approved.",
                'type'              => 'leave',
                'priority'          => 'Normal',
                'related_module'    => 'Leave',
                'related_entity_id' => $applicationId,
                'is_read'           => 0,
                'created_at'        => date('Y-m-d H:i:s')
            ]);
        } catch (\Throwable $e) {
            log_message('error', 'approve applicant notification error: ' . $e->getMessage());
        }

        $this->db->transComplete();

        if ($this->db->transStatus() === false) {
            return [
                'success' => false,
                'message' => 'Failed to approve leave application due to a database transaction error.'
            ];
        }

        return [
            'success' => true,
            'message' => 'Leave application approved successfully.'
        ];
    }

    /**
     * Batch approve applications with per-record scope check and transaction safety.
     */
    public function batchApprove(array $applicationIds, string $approverId, ?string $remarks = null): array
    {
        if (empty($applicationIds)) {
            return [
                'success' => false,
                'message' => 'No application IDs provided for batch approval.',
            ];
        }

        $approvedCount = 0;
        $failedIds = [];
        $errors = [];

        foreach ($applicationIds as $id) {
            $res = $this->approveLeave($id, $approverId, $remarks);
            if ($res['success']) {
                $approvedCount++;
            } else {
                $failedIds[] = $id;
                $errors[] = "Application {$id}: " . ($res['message'] ?? 'Failed to approve');
            }
        }

        return [
            'success'        => empty($failedIds),
            'approved_count' => $approvedCount,
            'failed_count'   => count($failedIds),
            'failed_ids'     => $failedIds,
            'errors'         => $errors,
            'message'        => "Batch approval completed: {$approvedCount} approved, " . count($failedIds) . ' failed.'
        ];
    }

    /**
     * Reject leave application with mandatory reason and pending quota release.
     */
    public function rejectLeave(string $applicationId, string $approverId, string $rejectionReason): array
    {
        if (trim($applicationId) === '') {
            return ['success' => false, 'message' => 'Application ID is required.'];
        }

        $rejectionReason = trim($rejectionReason);
        if ($rejectionReason === '') {
            return ['success' => false, 'message' => 'Rejection reason is mandatory.'];
        }

        $app = $this->leaveModel->find($applicationId);
        if (!$app) {
            return ['success' => false, 'message' => 'Leave application not found.'];
        }

        $targetEmp = $this->db->table('employees')->where('id', $app['employee_id'])->get()->getRowArray();
        $targetCompanyId = (string)($targetEmp['company_id'] ?? ($app['company_id'] ?? ''));

        // Authoritative Service-Level Tenant Isolation Check: Approver must belong to target employee's company
        $tenantViolation = $this->verifyTenantIsolation($approverId, $targetCompanyId, 'rejection', 'Approver');
        if ($tenantViolation !== null) {
            return $tenantViolation;
        }

        $curStatus = strtolower(trim((string)($app['status'] ?? 'pending')));
        if ($curStatus === 'rejected') {
            return ['success' => false, 'message' => 'This application is already rejected.'];
        }

        // Hard Exception (b): Self-review violation - Nobody can review or reject their own request
        $approverUser = null;
        $approverEmp = null;
        $approverEmpId = null;
        $approverUserId = null;

        $userRow = $this->db->table('users')
            ->select('users.*, roles.code as role_code, roles.name as role_name')
            ->join('roles', 'roles.id = users.role_id', 'left')
            ->where('users.id', $approverId)
            ->get()->getRowArray();

        if ($userRow) {
            $approverUser = $userRow;
            $approverUserId = $userRow['id'];
            $approverEmpId = $userRow['employee_id'] ?? null;
            if ($approverEmpId) {
                $approverEmp = $this->db->table('employees')->where('id', $approverEmpId)->get()->getRowArray();
            }
        } else {
            // Check if $approverId is an employee ID
            $empRow = $this->db->table('employees')->where('id', $approverId)->get()->getRowArray();
            if ($empRow) {
                $approverEmp = $empRow;
                $approverEmpId = $empRow['id'];
                $approverUser = $this->db->table('users')
                    ->select('users.*, roles.code as role_code, roles.name as role_name')
                    ->join('roles', 'roles.id = users.role_id', 'left')
                    ->where('users.employee_id', $empRow['id'])
                    ->get()->getRowArray();
                $approverUserId = $approverUser['id'] ?? null;
            }
        }

        if ($approverEmp && $approverUser) {
            $approverUser['branch_id'] = $approverUser['branch_id'] ?? ($approverEmp['branch_id'] ?? null);
            $approverUser['department_id'] = $approverUser['department_id'] ?? ($approverEmp['department_id'] ?? null);
            $approverUser['employee_id'] = $approverUser['employee_id'] ?? ($approverEmp['id'] ?? null);
        }

        $permService = new \App\Services\PermissionService();
        $canonicalRole = $permService->canonicalizeRole($approverUser['role_code'] ?? $approverUser['role_name'] ?? '');
        $isPrivilegedAdmin = ($canonicalRole === 'software_app_admin' || $canonicalRole === 'company_admin' || $canonicalRole === 'hr_admin' || $permService->isHRAdmin($approverUser['role_code'] ?? $approverUser['role_name'] ?? ''));

        if (!$isPrivilegedAdmin && ($approverId === $app['employee_id'] || ($approverEmpId && $approverEmpId === $app['employee_id']))) {
            return [
                'success' => false,
                'message' => 'Self-review violation: You cannot review or reject your own leave application.'
            ];
        }

        // Service-level organizational scope check: Approver must have scope over target employee
        if (empty($approverUser) || empty($targetEmp)) {
            log_message('error', "Scope check missing entity in rejectLeave for leave application {$applicationId}, approver {$approverId}. ApproverUser: " . (empty($approverUser) ? 'missing' : 'present') . ", TargetEmp: " . (empty($targetEmp) ? 'missing' : 'present'));
            return [
                'success' => false,
                'code'    => 403,
                'message' => '403 Forbidden: Unable to verify your authorized organizational scope.'
            ];
        }
        if ($canonicalRole !== 'software_app_admin') {
            try {
                $isEndorsed = in_array(strtolower(trim((string)($app['status'] ?? ''))), ['endorsed'], true)
                    || in_array(strtolower(trim((string)($app['manager_status'] ?? ''))), ['approved', 'endorsed'], true);
                $scopePerm = $isEndorsed ? 'leave.hr_approve' : 'leave.reject';
                $checkId = $approverUserId ?: $approverId;
                $decision = $permService->can($checkId, $scopePerm, ['company_id' => $targetCompanyId]);
                if (!$decision->isAllowed()) {
                    $scopePerm = 'leave.reject';
                    $decision = $permService->can($checkId, $scopePerm, ['company_id' => $targetCompanyId]);
                }
                if (!$decision->isAllowed()) {
                    $scopePerm = 'leaves.reject';
                    $decision = $permService->can($checkId, $scopePerm, ['company_id' => $targetCompanyId]);
                }
                if (!$decision->isAllowed()) {
                    $scopePerm = 'leave.manage';
                    $decision = $permService->can($checkId, $scopePerm, ['company_id' => $targetCompanyId]);
                }
                if (!$decision->isAllowed()) {
                    $scopePerm = 'leaves.manage';
                    $decision = $permService->can($checkId, $scopePerm, ['company_id' => $targetCompanyId]);
                }
                if (!$decision->isAllowed()) {
                    return [
                        'success' => false,
                        'code'    => 403,
                        'message' => '403 Forbidden: You do not have permission to reject this leave application.'
                    ];
                }
                if (!$permService->assertInScope($approverUser, $decision, $targetEmp)) {
                    return [
                        'success' => false,
                        'code'    => 403,
                        'message' => '403 Forbidden: Target employee is outside your authorized organizational scope.'
                    ];
                }
            } catch (\Throwable $e) {
                log_message('error', "Scope check exception in rejectLeave for application {$applicationId}, approver {$approverId}: " . $e->getMessage());
                return [
                    'success' => false,
                    'code'    => 403,
                    'message' => '403 Forbidden: Unable to verify your authorized organizational scope.'
                ];
            }
        }

        $fromDate = $app['from_date'] ?? $app['start_date'] ?? date('Y-m-d');
        $toDate = $app['to_date'] ?? $app['end_date'] ?? $fromDate;
        $paidDays = isset($app['paid_days']) ? (float)$app['paid_days'] : (float)($app['total_days'] ?? 1.0);
        $isHalfDay = !empty($app['is_half_day']);
        $sandwichRule = !empty($app['sandwich_rule']) || !empty($app['sandwich_rule_applies']);

        $this->db->transStart();

        $lockedApp = $this->lockRow('leave_applications', ['id' => $applicationId]);
        if (!$lockedApp || strtolower($lockedApp['status'] ?? '') === 'rejected') {
            $this->db->transRollback();
            return ['success' => false, 'message' => 'Leave application already rejected or modified concurrently.'];
        }

        $this->db->table('leave_applications')
            ->where('id', $applicationId)
            ->whereNotIn('status', ['Rejected', 'rejected'])
            ->update([
                'status'           => 'Rejected',
                'rejection_reason' => $rejectionReason,
                'approved_by'      => $approverId,
                'hr_status'        => 'Rejected',
                'hr_id'            => $approverId,
                'updated_at'       => date('Y-m-d H:i:s')
            ]);

        // Update leave_approval_steps: mark active and subsequent steps as Rejected
        if ($this->db->tableExists('leave_approval_steps')) {
            try {
                $pendingSteps = $this->db->table('leave_approval_steps')
                    ->where('application_id', $applicationId)
                    ->where('status', 'Pending')
                    ->orderBy('step_order', 'ASC')
                    ->get()
                    ->getResultArray();

                if (!empty($pendingSteps)) {
                    $firstPending = $pendingSteps[0];
                    $this->db->table('leave_approval_steps')
                        ->where('id', $firstPending['id'])
                        ->update([
                            'approver_id' => $approverId,
                            'status'      => 'Rejected',
                            'comments'    => $rejectionReason,
                            'acted_at'    => date('Y-m-d H:i:s'),
                            'updated_at'  => date('Y-m-d H:i:s'),
                        ]);

                    for ($i = 1; $i < count($pendingSteps); $i++) {
                        $this->db->table('leave_approval_steps')
                            ->where('id', $pendingSteps[$i]['id'])
                            ->update([
                                'status'     => 'Rejected',
                                'comments'   => 'Terminated due to prior rejection',
                                'acted_at'   => date('Y-m-d H:i:s'),
                                'updated_at' => date('Y-m-d H:i:s'),
                            ]);
                    }
                } else {
                    $this->db->table('leave_approval_steps')->insert([
                        'id'             => 'las-' . bin2hex(random_bytes(6)),
                        'application_id' => $applicationId,
                        'step_order'     => 1,
                        'approver_id'    => $approverId,
                        'approver_role'  => 'Authorized Officer',
                        'status'         => 'Rejected',
                        'comments'       => $rejectionReason,
                        'acted_at'       => date('Y-m-d H:i:s'),
                        'created_at'     => date('Y-m-d H:i:s'),
                        'updated_at'     => date('Y-m-d H:i:s'),
                    ]);
                }
            } catch (\Throwable $stepEx) {
                log_message('notice', 'rejectLeave step update error: ' . $stepEx->getMessage());
            }
        }

        // Release pending quota if previously in Pending or Endorsed status
        if (in_array(strtolower($lockedApp['status'] ?? ''), ['pending', 'endorsed'], true)) {
            $unpaidDays = (float)($lockedApp['unpaid_days'] ?? 0.0);
            $unpaidTypeId = $lockedApp['unpaid_leave_type_id'] ?? null;
            if ($paidDays > 0) {
                $yearSplitData = $this->leaveService->resolveApplicationYearSplit($lockedApp, $paidDays, 0.0, $fromDate, $toDate, $isHalfDay, $sandwichRule);
                $yearSplitPaid = $yearSplitData['paid'];
                foreach ($yearSplitPaid as $yr => $yrDays) {
                    if ($yrDays <= 0) continue;
                    $this->lockRow('leave_balances', [
                        'employee_id'   => $lockedApp['employee_id'],
                        'leave_type_id' => $lockedApp['leave_type_id'],
                        'year'          => $yr,
                    ]);

                    $this->db->query(
                        "UPDATE leave_balances 
                         SET pending_leave_days = CASE WHEN (pending_leave_days - ?) < 0 THEN 0 ELSE (pending_leave_days - ?) END
                         WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                        [$yrDays, $yrDays, $lockedApp['employee_id'], $lockedApp['leave_type_id'], $yr]
                    );
                }
            }
            if ($unpaidDays > 0 && !empty($unpaidTypeId)) {
                $yearSplitData = $this->leaveService->resolveApplicationYearSplit($lockedApp, $paidDays, $unpaidDays, $fromDate, $toDate, $isHalfDay, $sandwichRule);
                $yearSplitUnpaid = $yearSplitData['unpaid'];
                foreach ($yearSplitUnpaid as $yr => $yrDays) {
                    if ($yrDays <= 0) continue;
                    $this->lockRow('leave_balances', [
                        'employee_id'   => $lockedApp['employee_id'],
                        'leave_type_id' => $unpaidTypeId,
                        'year'          => $yr,
                    ]);

                    $this->db->query(
                        "UPDATE leave_balances 
                         SET pending_leave_days = CASE WHEN (pending_leave_days - ?) < 0 THEN 0 ELSE (pending_leave_days - ?) END
                         WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                        [$yrDays, $yrDays, $lockedApp['employee_id'], $unpaidTypeId, $yr]
                    );
                }
            }
        }

        // Notify Applicant
        try {
            $notifModel = new NotificationModel();
            $notifModel->insert([
                'id'                => 'notif-' . bin2hex(random_bytes(6)),
                'user_id'           => $lockedApp['employee_id'],
                'title'             => 'Leave Application Rejected',
                'message'           => "Your leave application from {$fromDate} to {$toDate} was rejected: {$rejectionReason}",
                'type'              => 'leave',
                'priority'          => 'Normal',
                'related_module'    => 'Leave',
                'related_entity_id' => $applicationId,
                'is_read'           => 0,
                'created_at'        => date('Y-m-d H:i:s')
            ]);
        } catch (\Throwable $e) {
            log_message('error', 'reject applicant notification error: ' . $e->getMessage());
        }

        $this->db->transComplete();

        return [
            'success' => $this->db->transStatus(),
            'message' => 'Leave application rejected successfully.'
        ];
    }

    /**
     * Batch reject applications.
     */
    public function batchReject(array $applicationIds, string $approverId, string $reason): array
    {
        if (empty($applicationIds)) {
            return [
                'success' => false,
                'message' => 'No application IDs provided for batch rejection.',
            ];
        }

        $rejectedCount = 0;
        $failedIds = [];
        $errors = [];

        foreach ($applicationIds as $id) {
            $res = $this->rejectLeave($id, $approverId, $reason);
            if ($res['success']) {
                $rejectedCount++;
            } else {
                $failedIds[] = $id;
                $errors[] = "Application {$id}: " . ($res['message'] ?? 'Failed to reject');
            }
        }

        return [
            'success'        => empty($failedIds),
            'rejected_count' => $rejectedCount,
            'failed_count'   => count($failedIds),
            'failed_ids'     => $failedIds,
            'errors'         => $errors,
            'message'        => "Batch rejection completed: {$rejectedCount} rejected, " . count($failedIds) . ' failed.'
        ];
    }

    /**
     * Cancel leave application with strict past-leave guards, mandatory reason, and full quota restoration.
     */
    public function cancelLeave(
        string $applicationId,
        string $userId,
        ?string $employeeId = null,
        bool $isAdmin = false,
        ?string $reason = null
    ): array {
        if (trim($applicationId) === '') {
            return ['success' => false, 'message' => 'Application ID is required.'];
        }

        $reason = trim((string)($reason ?: ''));
        if ($reason === '') {
            return ['success' => false, 'message' => 'Mandatory cancellation reason must be provided.'];
        }

        $app = $this->leaveModel->find($applicationId);
        if (!$app) {
            return ['success' => false, 'message' => 'Leave application not found.'];
        }

        $targetEmp = $this->db->table('employees')->where('id', $app['employee_id'])->get()->getRowArray();
        $targetCompanyId = (string)($targetEmp['company_id'] ?? ($app['company_id'] ?? ''));

        // Authoritative Service-Level Tenant Isolation Check: Acting user must belong to target employee's company
        $tenantViolation = $this->verifyTenantIsolation($userId, $targetCompanyId, 'cancellation', 'User');
        if ($tenantViolation !== null) {
            return $tenantViolation;
        }

        if (!empty($employeeId)) {
            $empTenantViolation = $this->verifyTenantIsolation($employeeId, $targetCompanyId, 'cancellation', 'User');
            if ($empTenantViolation !== null) {
                return $empTenantViolation;
            }
        }

        if (!$isAdmin) {
            if (empty($employeeId)) {
                return ['success' => false, 'message' => 'Unauthorized: Employee identification required.'];
            }
            if ((string)($app['employee_id'] ?? '') !== (string)$employeeId) {
                return ['success' => false, 'message' => 'Unauthorized: You can only cancel your own leave applications.'];
            }
        }

        $initialStatus = strtolower(trim((string)($app['status'] ?? 'pending')));
        if (in_array($initialStatus, ['cancelled', 'rejected'], true)) {
            return ['success' => false, 'message' => 'This leave application is already ' . $initialStatus . ' and cannot be cancelled.'];
        }

        $fromDate = $app['from_date'] ?? $app['start_date'] ?? date('Y-m-d');
        $toDate = $app['to_date'] ?? $app['end_date'] ?? $fromDate;
        $start = new \DateTime($fromDate);
        $end = new \DateTime($toDate);

        // Resolve company LEAVE rule to enforce cancellation policy for employees
        if (!$isAdmin) {
            $leaveRule = null;
            try {
                if ($targetEmp) {
                    $leaveRule = (new RuleResolver())->resolve($targetCompanyId, 'LEAVE', $fromDate, $targetEmp);
                } else {
                    $leaveRule = RuleResolver::resolveForCompany($targetCompanyId, 'LEAVE', $fromDate);
                }
            } catch (\Throwable $re) {
                try {
                    $leaveRule = RuleResolver::resolveForCompany($targetCompanyId, 'LEAVE', $fromDate);
                } catch (\Throwable $ce) {
                    // Rule not resolvable, keep safe default
                }
            }

            $approvalWf = $leaveRule ? ($leaveRule->get('approval_workflow') ?: []) : [];
            $allowCancellation = $approvalWf['allow_employee_cancellation'] ?? true;
            if (!$allowCancellation) {
                return [
                    'success' => false,
                    'message' => '422 Unprocessable Entity: Employee cancellation is disabled by company leave policy. Please contact HR.'
                ];
            }

            $cancelWindow = trim((string)($approvalWf['cancellation_window'] ?? 'Before leave start'));
            $today = date('Y-m-d');
            if ($cancelWindow === 'Before approval only' && $initialStatus === 'approved') {
                return [
                    'success' => false,
                    'message' => '422 Unprocessable Entity: Employees cannot cancel approved leave. Please contact HR.'
                ];
            } elseif ($cancelWindow === 'Before leave start') {
                if ($fromDate <= $today) {
                    return [
                        'success' => false,
                        'message' => '422 Unprocessable Entity: Employees cannot cancel leave that has already started or concluded. Please contact HR.'
                    ];
                }
            } elseif ($cancelWindow === 'Before leave end') {
                if ($toDate < $today) {
                    return [
                        'success' => false,
                        'message' => '422 Unprocessable Entity: Employees cannot cancel leave that has already concluded. Please contact HR.'
                    ];
                }
            } elseif ($cancelWindow === 'Anytime') {
                // Allowed, subject only to attendance settlement locks below
            } else {
                // Default fallback to safe start date check for approved leave
                if ($initialStatus === 'approved' && $fromDate <= $today) {
                    return [
                        'success' => false,
                        'message' => '422 Unprocessable Entity: Employees cannot cancel approved leave that has already started or concluded. Please contact HR.'
                    ];
                }
            }
        }

        // Attendance settlement lock check
        if ($initialStatus === 'approved') {
            $attService = new AttendanceService();
            $curr = clone $start;
            while ($curr <= $end) {
                $d = $curr->format('Y-m-d');
                if ($attService->isAttendanceSettled($app['employee_id'], $d)) {
                    return [
                        'success' => false,
                        'message' => "422 Unprocessable Entity: Cannot cancel leave application. Attendance on {$d} is locked and settled in payroll."
                    ];
                }
                $curr->modify('+1 day');
            }
        }

        $this->db->transStart();

        $lockedApp = $this->lockRow('leave_applications', ['id' => $applicationId]);
        if (!$lockedApp) {
            $this->db->transRollback();
            return ['success' => false, 'message' => 'Leave application not found.'];
        }

        $prevStatus = strtolower(trim((string)($lockedApp['status'] ?? 'pending')));
        if (in_array($prevStatus, ['cancelled', 'rejected'], true)) {
            $this->db->transRollback();
            return ['success' => false, 'message' => 'Leave application has already been cancelled or rejected.'];
        }

        $this->db->table('leave_applications')
            ->where('id', $applicationId)
            ->whereNotIn('status', ['Cancelled', 'cancelled', 'Rejected', 'rejected'])
            ->update([
                'status'           => 'Cancelled',
                'rejection_reason' => $reason,
                'updated_at'       => date('Y-m-d H:i:s')
            ]);

        if ($this->db->affectedRows() === 0) {
            $checkApp = $this->db->table('leave_applications')->where('id', $applicationId)->get()->getRowArray();
            $checkStatus = strtolower(trim((string)($checkApp['status'] ?? '')));
            if ($checkStatus === 'cancelled') {
                $this->db->transRollback();
                return ['success' => true, 'message' => 'Leave application is already cancelled.'];
            }
            $this->db->transRollback();
            $actualStatus = !empty($checkApp['status']) ? $checkApp['status'] : 'Modified';
            return ['success' => false, 'message' => "Action conflict: Leave application status was changed to '{$actualStatus}' by another user or session. Please refresh the page."];
        }

        $paidDays = isset($lockedApp['paid_days']) ? (float)$lockedApp['paid_days'] : (float)($lockedApp['total_days'] ?? 1.0);
        $unpaidDays = (float)($lockedApp['unpaid_days'] ?? 0.0);
        $unpaidTypeId = $lockedApp['unpaid_leave_type_id'] ?? null;
        $isHalfDay = !empty($lockedApp['is_half_day']);
        $sandwichRule = !empty($lockedApp['sandwich_rule']) || !empty($lockedApp['sandwich_rule_applies']) || !empty($lockedApp['apply_sandwich_rule']);

        $empRow = $this->db->table('employees')->where('id', $lockedApp['employee_id'])->get()->getRowArray();
        $empCompanyId = $empRow['company_id'] ?? null;
        $fromYear = (int)date('Y', strtotime($fromDate));
        $toYear   = (int)date('Y', strtotime($toDate));

        $yearSplitData = $this->leaveService->resolveApplicationYearSplit($lockedApp, $paidDays, $unpaidDays, $fromDate, $toDate, $isHalfDay, $sandwichRule);
        $yearSplitPaid = $yearSplitData['paid'];
        $yearSplitUnpaid = $yearSplitData['unpaid'];

        $isCrossYear = ($fromYear !== $toYear);
        if (!$isCrossYear) {
            $activeYears = [];
            foreach ($yearSplitPaid as $y => $d) {
                if ((float)$d > 0) $activeYears[(string)$y] = true;
            }
            foreach ($yearSplitUnpaid as $y => $d) {
                if ((float)$d > 0) $activeYears[(string)$y] = true;
            }
            if (count($activeYears) > 1) {
                $isCrossYear = true;
            }
        }

        if ($prevStatus === 'approved') {
            // Restore approved balance per split year for paid component using CASE WHEN
            if ($paidDays > 0) {
                foreach ($yearSplitPaid as $yr => $yrDays) {
                    $yrDays = (float)$yrDays;
                    if ($yrDays <= 0) continue;

                    $this->lockRow('leave_balances', [
                        'employee_id'   => $lockedApp['employee_id'],
                        'leave_type_id' => $lockedApp['leave_type_id'],
                        'year'          => $yr,
                    ]);

                    $this->db->query(
                        "UPDATE leave_balances 
                         SET approved_leave_days = CASE WHEN (approved_leave_days - ?) < 0 THEN 0 ELSE (approved_leave_days - ?) END
                         WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                        [$yrDays, $yrDays, $lockedApp['employee_id'], $lockedApp['leave_type_id'], $yr]
                    );

                    // Locate original deduction transaction for this specific year to maintain link in reversal_of
                    $dedKeyWithYear = "LEAVE-APP-{$applicationId}-DED-PAID-{$yr}";
                    $dedKeyWithoutYear = "LEAVE-APP-{$applicationId}-DED-PAID";

                    $origPaidTx = $this->db->table('leave_transactions')
                        ->where('employee_id', $lockedApp['employee_id'])
                        ->where('leave_type_id', $lockedApp['leave_type_id'])
                        ->where('leave_year', (int)$yr)
                        ->where('transaction_type', 'Deduction')
                        ->groupStart()
                            ->where('idempotency_key', $dedKeyWithYear)
                            ->orWhere('idempotency_key', $dedKeyWithoutYear)
                            ->orWhere('reference_id', $applicationId)
                            ->orWhere('related_application_id', $applicationId)
                        ->groupEnd()
                        ->orderBy("CASE WHEN idempotency_key LIKE '%DED-PAID%' THEN 1 ELSE 2 END", 'ASC', false)
                        ->get()->getRowArray();

                    if (!$origPaidTx) {
                        $origPaidTx = $this->db->table('leave_transactions')
                            ->where('employee_id', $lockedApp['employee_id'])
                            ->where('leave_type_id', $lockedApp['leave_type_id'])
                            ->where('transaction_type', 'Deduction')
                            ->groupStart()
                                ->where('idempotency_key', $dedKeyWithYear)
                                ->orWhere('idempotency_key', $dedKeyWithoutYear)
                                ->orWhere('reference_id', $applicationId)
                                ->orWhere('related_application_id', $applicationId)
                            ->groupEnd()
                            ->orderBy("CASE WHEN idempotency_key LIKE '%DED-PAID%' THEN 1 ELSE 2 END", 'ASC', false)
                            ->get()->getRowArray();
                    }

                    $startOfYear = "{$yr}-01-01";
                    $endOfYear   = "{$yr}-12-31";
                    $effectiveDateForYear = ($fromDate > $startOfYear) ? $fromDate : $startOfYear;
                    if ($effectiveDateForYear > $endOfYear) $effectiveDateForYear = $endOfYear;
                    if ($effectiveDateForYear > $toDate) $effectiveDateForYear = $toDate;
                    $txDate = ($yr === (int)date('Y') && !$isCrossYear) ? date('Y-m-d') : $effectiveDateForYear;

                    $revIdempotencyKey = $isCrossYear
                        ? "LEAVE-CANCEL-{$applicationId}-REV-PAID-{$yr}"
                        : "LEAVE-CANCEL-{$applicationId}-REV-PAID";
                    $revCycleNo = $isCrossYear
                        ? "LEAVE-CANCEL-{$applicationId}-PAID-{$yr}"
                        : "LEAVE-CANCEL-{$applicationId}-PAID";

                    $existingRev = $this->db->table('leave_transactions')
                        ->where('company_id', $empCompanyId)
                        ->where('idempotency_key', $revIdempotencyKey)
                        ->get()->getRowArray();

                    if (!$existingRev) {
                        $this->transactionModel->insert([
                            'id'                     => 'tx-' . bin2hex(random_bytes(6)),
                            'company_id'             => $empCompanyId,
                            'employee_id'            => $lockedApp['employee_id'],
                            'leave_type_id'          => $lockedApp['leave_type_id'],
                            'leave_year'             => (int)$yr,
                            'transaction_type'       => 'Reversal',
                            'days'                   => $yrDays,
                            'reference_id'           => $applicationId,
                            'cycle_no'               => $revCycleNo,
                            'idempotency_key'        => $revIdempotencyKey,
                            'reversal_of'            => $origPaidTx['id'] ?? null,
                            'related_application_id' => $applicationId,
                            'remarks'                => "Leave cancellation credit reversal (Paid): {$reason}",
                            'effective_date'         => $effectiveDateForYear,
                            'transaction_date'       => $txDate
                        ]);
                    }
                }
            }

            // Restore unpaid component (both approved_leave_days and unpaid_adjustment_days)
            if ($unpaidDays > 0) {
                if (empty($unpaidTypeId)) {
                    $resolvedUl = $this->leaveService->resolveAuthoritativeUnpaidLeaveType($empCompanyId ?: '');
                    $unpaidTypeId = $resolvedUl['id'] ?? null;
                }
                $targetUnpaidTypeId = $unpaidTypeId;
                foreach ($yearSplitUnpaid as $yr => $yrDays) {
                    $yrDays = (float)$yrDays;
                    if ($yrDays <= 0) continue;

                    if (!empty($targetUnpaidTypeId)) {
                        $this->lockRow('leave_balances', [
                            'employee_id'   => $lockedApp['employee_id'],
                            'leave_type_id' => $targetUnpaidTypeId,
                            'year'          => $yr,
                        ]);

                        $this->db->query(
                            "UPDATE leave_balances 
                             SET approved_leave_days = CASE WHEN (approved_leave_days - ?) < 0 THEN 0 ELSE (approved_leave_days - ?) END,
                                 unpaid_adjustment_days = CASE WHEN (unpaid_adjustment_days - ?) < 0 THEN 0 ELSE (unpaid_adjustment_days - ?) END
                             WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                            [$yrDays, $yrDays, $yrDays, $yrDays, $lockedApp['employee_id'], $targetUnpaidTypeId, $yr]
                        );
                    }

                    // Locate original unpaid deduction transaction for this specific year
                    $dedKeyWithYear = "LEAVE-APP-{$applicationId}-DED-UNPAID-{$yr}";
                    $dedKeyWithoutYear = "LEAVE-APP-{$applicationId}-DED-UNPAID";

                    $origUnpaidTx = $this->db->table('leave_transactions')
                        ->where('employee_id', $lockedApp['employee_id'])
                        ->where('leave_type_id', $targetUnpaidTypeId)
                        ->where('leave_year', (int)$yr)
                        ->where('transaction_type', 'Deduction')
                        ->groupStart()
                            ->where('idempotency_key', $dedKeyWithYear)
                            ->orWhere('idempotency_key', $dedKeyWithoutYear)
                            ->orWhere('reference_id', $applicationId)
                            ->orWhere('related_application_id', $applicationId)
                        ->groupEnd()
                        ->orderBy("CASE WHEN idempotency_key LIKE '%DED-UNPAID%' THEN 1 ELSE 2 END", 'ASC', false)
                        ->get()->getRowArray();

                    if (!$origUnpaidTx) {
                        $origUnpaidTx = $this->db->table('leave_transactions')
                            ->where('employee_id', $lockedApp['employee_id'])
                            ->where('leave_type_id', $targetUnpaidTypeId)
                            ->where('transaction_type', 'Deduction')
                            ->groupStart()
                                ->where('idempotency_key', $dedKeyWithYear)
                                ->orWhere('idempotency_key', $dedKeyWithoutYear)
                                ->orWhere('reference_id', $applicationId)
                                ->orWhere('related_application_id', $applicationId)
                            ->groupEnd()
                            ->orderBy("CASE WHEN idempotency_key LIKE '%DED-UNPAID%' THEN 1 ELSE 2 END", 'ASC', false)
                            ->get()->getRowArray();
                    }

                    $startOfYear = "{$yr}-01-01";
                    $endOfYear   = "{$yr}-12-31";
                    $effectiveDateForYear = ($fromDate > $startOfYear) ? $fromDate : $startOfYear;
                    if ($effectiveDateForYear > $endOfYear) $effectiveDateForYear = $endOfYear;
                    if ($effectiveDateForYear > $toDate) $effectiveDateForYear = $toDate;
                    $txDate = ($yr === (int)date('Y') && !$isCrossYear) ? date('Y-m-d') : $effectiveDateForYear;

                    $revIdempotencyKey = $isCrossYear
                        ? "LEAVE-CANCEL-{$applicationId}-REV-UNPAID-{$yr}"
                        : "LEAVE-CANCEL-{$applicationId}-REV-UNPAID";
                    $revCycleNo = $isCrossYear
                        ? "LEAVE-CANCEL-{$applicationId}-UNPAID-{$yr}"
                        : "LEAVE-CANCEL-{$applicationId}-UNPAID";

                    $existingRev = $this->db->table('leave_transactions')
                        ->where('company_id', $empCompanyId)
                        ->where('idempotency_key', $revIdempotencyKey)
                        ->get()->getRowArray();

                    if (!$existingRev) {
                        $this->transactionModel->insert([
                            'id'                     => 'tx-' . bin2hex(random_bytes(6)),
                            'company_id'             => $empCompanyId,
                            'employee_id'            => $lockedApp['employee_id'],
                            'leave_type_id'          => $targetUnpaidTypeId,
                            'leave_year'             => (int)$yr,
                            'transaction_type'       => 'Reversal',
                            'days'                   => $yrDays,
                            'reference_id'           => $applicationId,
                            'cycle_no'               => $revCycleNo,
                            'idempotency_key'        => $revIdempotencyKey,
                            'reversal_of'            => $origUnpaidTx['id'] ?? null,
                            'related_application_id' => $applicationId,
                            'remarks'                => "Leave cancellation credit reversal (Unpaid): {$reason}",
                            'effective_date'         => $effectiveDateForYear,
                            'transaction_date'       => $txDate
                        ]);
                    }
                }
            }

            // Attendance restoration: restore attendance logs to original state (Present if punches, Holiday, Weekly Off, or Absent)
            $configuredWeeklyOff = \App\Services\CompanyWeekendService::getCompanyWeeklyOff($empCompanyId, $lockedApp['employee_id']);

            $holidaysInRange = [];
            if ($this->db->tableExists('holidays')) {
                try {
                    $fields = $this->db->getFieldNames('holidays');
                    $hBuilder = $this->db->table('holidays');
                    if (!empty($empCompanyId) && in_array('company_id', $fields, true)) {
                        $hBuilder->groupStart()
                            ->where('company_id', $empCompanyId)
                            ->orWhere('company_id IS NULL')
                            ->groupEnd();
                    }
                    if (in_array('from_date', $fields, true) && in_array('to_date', $fields, true)) {
                        $hRows = $hBuilder->where('from_date <=', $toDate)->where('to_date >=', $fromDate)->get()->getResultArray();
                        foreach ($hRows as $h) {
                            $hStart = new \DateTime($h['from_date']);
                            $hEnd = new \DateTime($h['to_date']);
                            $hC = clone $hStart;
                            while ($hC <= $hEnd) {
                                $holidaysInRange[$hC->format('Y-m-d')] = true;
                                $hC->modify('+1 day');
                            }
                        }
                    } elseif (in_array('date', $fields, true)) {
                        $hRows = $hBuilder->where('date >=', $fromDate)->where('date <=', $toDate)->get()->getResultArray();
                        foreach ($hRows as $h) {
                            $holidaysInRange[$h['date']] = true;
                        }
                    }
                } catch (\Throwable $e) {
                    log_message('error', 'cancelLeave holiday query error: ' . $e->getMessage());
                }
            }

            $curr = clone $start;
            while ($curr <= $end) {
                $dateStr = $curr->format('Y-m-d');
                $attLog = $this->db->table('attendance_logs')
                    ->where('employee_id', $lockedApp['employee_id'])
                    ->where('date', $dateStr)
                    ->get()
                    ->getRowArray();

                if ($attLog && in_array(strtolower((string)$attLog['status']), ['on leave', 'half day'], true)) {
                    if (($attLog['verification_method'] ?? '') === 'SYSTEM_LEAVE_SYNC') {
                        $this->db->table('attendance_logs')->where('id', $attLog['id'])->delete();
                    } else {
                        $hasPunches = !empty($attLog['punch_in']) || !empty($attLog['clock_in']) || !empty($attLog['in_time']) || !empty($attLog['check_in']);
                        if ($hasPunches) {
                            $restoreStatus = 'Present';
                        } elseif (isset($holidaysInRange[$dateStr])) {
                            $restoreStatus = 'Holiday';
                        } elseif (in_array($curr->format('l'), $configuredWeeklyOff, true)) {
                            $restoreStatus = 'Weekly Off';
                        } else {
                            $restoreStatus = 'Absent';
                        }

                        $this->db->table('attendance_logs')
                            ->where('id', $attLog['id'])
                            ->update([
                                'status'      => $restoreStatus,
                                'is_approved' => 0,
                                'updated_at'  => date('Y-m-d H:i:s')
                            ]);
                    }
                }
                $curr->modify('+1 day');
            }
        } elseif ($paidDays > 0 || $unpaidDays > 0) {
            // If was Pending / Endorsed, release pending_leave_days using CASE WHEN
            if ($paidDays > 0) {
                foreach ($yearSplitPaid as $yr => $yrDays) {
                    if ($yrDays <= 0) continue;
                    $this->lockRow('leave_balances', [
                        'employee_id'   => $lockedApp['employee_id'],
                        'leave_type_id' => $lockedApp['leave_type_id'],
                        'year'          => $yr,
                    ]);

                    $this->db->query(
                        "UPDATE leave_balances 
                         SET pending_leave_days = CASE WHEN (pending_leave_days - ?) < 0 THEN 0 ELSE (pending_leave_days - ?) END
                         WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                        [$yrDays, $yrDays, $lockedApp['employee_id'], $lockedApp['leave_type_id'], $yr]
                    );
                }
            }

            // Restore pending balance for unpaid component (if configured)
            if ($unpaidDays > 0 && !empty($unpaidTypeId)) {
                foreach ($yearSplitUnpaid as $yr => $yrDays) {
                    if ($yrDays <= 0) continue;
                    $this->lockRow('leave_balances', [
                        'employee_id'   => $lockedApp['employee_id'],
                        'leave_type_id' => $unpaidTypeId,
                        'year'          => $yr,
                    ]);

                    $this->db->query(
                        "UPDATE leave_balances 
                         SET pending_leave_days = CASE WHEN (pending_leave_days - ?) < 0 THEN 0 ELSE (pending_leave_days - ?) END
                         WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                        [$yrDays, $yrDays, $lockedApp['employee_id'], $unpaidTypeId, $yr]
                    );
                }
            }
        }

        $this->db->transComplete();

        return [
            'success' => $this->db->transStatus(),
            'message' => 'Leave application cancelled successfully.'
        ];
    }

    /**
     * Recompute backdated decision from start date and leave policy rules.
     */
    public static function recomputeBackdatedDecision(string $fromDate, array $rules): array
    {
        $today = date('Y-m-d');
        $isBackdated = ($fromDate < $today);
        $backdatedRole = $isBackdated ? trim((string)($rules['backdated_role_requirement'] ?? '')) : null;
        return [
            'is_backdated'   => $isBackdated,
            'backdated_role' => ($isBackdated && !empty($backdatedRole)) ? $backdatedRole : null,
        ];
    }

    /**
     * Update leave application and recompute backdated status and approval steps.
     */
    public function updateLeave(string $applicationId, array $data, ?string $editorId = null): array
    {
        return $this->leaveService->updateLeave($applicationId, $data, (string)($editorId ?? ''));
    }
}
