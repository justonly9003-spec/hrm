<?php

namespace App\Services\Leave;

class LeaveTypeMatcher
{
    /**
     * Resolve a raw leave name or code to its canonical code (e.g. 'Special Leave' => 'SPL').
     */
    public static function canonicalLeaveTypeCode(string $nameOrCode): string
    {
        $u = strtoupper(trim($nameOrCode));
        if ($u === '') {
            return '';
        }
        $canonicalMap = [
            'AL'        => 'AL', 'ANNUAL' => 'AL', 'ANNUAL LEAVE' => 'AL', 'EARNED / ANNUAL LEAVE' => 'AL', 'ANNUAL / EARNED LEAVE' => 'AL',
            'SL'        => 'SL', 'SICK' => 'SL', 'SICK LEAVE' => 'SL', 'MEDICAL' => 'SL', 'MEDICAL LEAVE' => 'SL', 'SICK / MEDICAL LEAVE' => 'SL', 'SICK/MEDICAL LEAVE' => 'SL',
            'CL'        => 'CL', 'CASUAL' => 'CL', 'CASUAL LEAVE' => 'CL',
            'EL'        => 'EL', 'EARNED' => 'EL', 'EARNED LEAVE' => 'EL',
            'ML'        => 'ML', 'MATERNITY' => 'ML', 'MATERNITY LEAVE' => 'ML',
            'PL'        => 'PL', 'PATERNITY' => 'PL', 'PATERNITY LEAVE' => 'PL',
            'SPL'       => 'SPL', 'SPECIAL' => 'SPL', 'SPECIAL LEAVE' => 'SPL',
            'UL'        => 'UL', 'UNPAID' => 'UL', 'LWP' => 'UL', 'UNPAID LEAVE' => 'UL', 'LEAVE WITHOUT PAY' => 'UL', 'LOSS OF PAY' => 'UL', 'UNPAID LEAVE (LOSS OF PAY)' => 'UL', 'UNPAID LEAVE (LOP)' => 'UL',
        ];
        return $canonicalMap[$u] ?? $u;
    }

    /**
     * Match master leave type code/name with rule definition entitlement code/name using standard business aliases.
     */
    public static function matchLeaveTypeCode(string $codeA, ?string $codeB = null, ?string $typeName = null): mixed
    {
        // When called with 1 argument, act as canonical code resolver
        if ($codeB === null) {
            return self::canonicalLeaveTypeCode($codeA);
        }

        $a = strtoupper(trim($codeA));
        $b = strtoupper(trim($codeB));
        if ($a === '' && $b === '') {
            return false;
        }

        // 1. Exact-code pass first
        if ($a !== '' && $b !== '' && $a === $b) {
            return true;
        }

        $canonicalGroup = [
            'AL'        => 'AL', 'ANNUAL' => 'AL', 'ANNUAL LEAVE' => 'AL', 'EARNED / ANNUAL LEAVE' => 'AL', 'ANNUAL / EARNED LEAVE' => 'AL',
            'SL'        => 'SL', 'SICK' => 'SL', 'SICK LEAVE' => 'SL', 'MEDICAL' => 'SL', 'MEDICAL LEAVE' => 'SL', 'SICK / MEDICAL LEAVE' => 'SL', 'SICK/MEDICAL LEAVE' => 'SL',
            'CL'        => 'CL', 'CASUAL' => 'CL', 'CASUAL LEAVE' => 'CL',
            'EL'        => 'EL', 'EARNED' => 'EL', 'EARNED LEAVE' => 'EL',
            'ML'        => 'ML', 'MATERNITY' => 'ML', 'MATERNITY LEAVE' => 'ML',
            'PL'        => 'PL', 'PATERNITY' => 'PL', 'PATERNITY LEAVE' => 'PL',
            'SPL'       => 'SPL', 'SPECIAL' => 'SPL', 'SPECIAL LEAVE' => 'SPL',
            'UL'        => 'UL', 'UNPAID' => 'UL', 'LWP' => 'UL', 'UNPAID LEAVE' => 'UL', 'LEAVE WITHOUT PAY' => 'UL', 'LOSS OF PAY' => 'UL', 'UNPAID LEAVE (LOSS OF PAY)' => 'UL', 'UNPAID LEAVE (LOP)' => 'UL',
        ];

        $groupA = ($a !== '' && isset($canonicalGroup[$a])) ? $canonicalGroup[$a] : null;
        $groupB = ($b !== '' && isset($canonicalGroup[$b])) ? $canonicalGroup[$b] : null;

        // If both codes belong to known distinct canonical groups, they CANNOT match
        if ($groupA !== null && $groupB !== null) {
            return $groupA === $groupB;
        }

        $aliases = [
            'AL'        => ['AL', 'ANNUAL', 'ANNUAL LEAVE', 'EARNED / ANNUAL LEAVE', 'ANNUAL / EARNED LEAVE'],
            'ANNUAL'    => ['AL', 'ANNUAL', 'ANNUAL LEAVE', 'EARNED / ANNUAL LEAVE', 'ANNUAL / EARNED LEAVE'],
            'SL'        => ['SL', 'SICK', 'SICK LEAVE', 'MEDICAL', 'MEDICAL LEAVE', 'SICK / MEDICAL LEAVE', 'SICK/MEDICAL LEAVE'],
            'SICK'      => ['SL', 'SICK', 'SICK LEAVE', 'MEDICAL', 'MEDICAL LEAVE', 'SICK / MEDICAL LEAVE', 'SICK/MEDICAL LEAVE'],
            'MEDICAL'   => ['SL', 'SICK', 'SICK LEAVE', 'MEDICAL', 'MEDICAL LEAVE', 'SICK / MEDICAL LEAVE', 'SICK/MEDICAL LEAVE'],
            'CL'        => ['CL', 'CASUAL', 'CASUAL LEAVE'],
            'CASUAL'    => ['CL', 'CASUAL', 'CASUAL LEAVE'],
            'EL'        => ['EL', 'EARNED', 'EARNED LEAVE'],
            'EARNED'    => ['EL', 'EARNED', 'EARNED LEAVE'],
            'ML'        => ['ML', 'MATERNITY', 'MATERNITY LEAVE'],
            'MATERNITY' => ['ML', 'MATERNITY', 'MATERNITY LEAVE'],
            'PL'        => ['PL', 'PATERNITY', 'PATERNITY LEAVE'],
            'PATERNITY' => ['PL', 'PATERNITY', 'PATERNITY LEAVE'],
            'SPL'       => ['SPL', 'SPECIAL', 'SPECIAL LEAVE'],
            'SPECIAL'   => ['SPL', 'SPECIAL', 'SPECIAL LEAVE'],
            'UL'        => ['UL', 'UNPAID', 'LWP', 'UNPAID LEAVE', 'LEAVE WITHOUT PAY', 'LOSS OF PAY', 'UNPAID LEAVE (LOSS OF PAY)', 'UNPAID LEAVE (LOP)'],
            'UNPAID'    => ['UL', 'UNPAID', 'LWP', 'UNPAID LEAVE', 'LEAVE WITHOUT PAY', 'LOSS OF PAY', 'UNPAID LEAVE (LOSS OF PAY)', 'UNPAID LEAVE (LOP)'],
            'LWP'       => ['UL', 'UNPAID', 'LWP', 'UNPAID LEAVE', 'LEAVE WITHOUT PAY', 'LOSS OF PAY', 'UNPAID LEAVE (LOSS OF PAY)', 'UNPAID LEAVE (LOP)'],
        ];

        $genericCodes = ['', 'LV', 'LEAVE'];

        // 2. Compare against $b's alias list
        if ($b !== '' && isset($aliases[$b])) {
            if ($a !== '' && in_array($a, $aliases[$b], true)) {
                return true;
            }
            if (!empty($typeName)) {
                $normType = strtoupper(trim($typeName));
                if (in_array($normType, $aliases[$b], true)) {
                    if (in_array($a, $genericCodes, true) || $groupA === ($canonicalGroup[$b] ?? null)) {
                        return true;
                    }
                }
            }
        }

        // 3. Compare against $a's alias list
        if ($a !== '' && isset($aliases[$a])) {
            if ($b !== '' && in_array($b, $aliases[$a], true)) {
                return true;
            }
            if (!empty($typeName)) {
                $normType = strtoupper(trim($typeName));
                if (in_array($normType, $aliases[$a], true)) {
                    if (in_array($b, $genericCodes, true) || $groupB === ($canonicalGroup[$a] ?? null)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }
}
