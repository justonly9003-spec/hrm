<?php

namespace App\Services\Leave;

use App\Services\Rules\RuleNotConfiguredException;

/**
 * LeaveAccrualCalculator
 *
 * Pure, deterministic, zero-DB-write domain calculation service.
 * Implements the centralized Leave Rule Engine for on-the-fly leave derivation,
 * dynamic calendar day accruals, carry-forward rollover evaluations, and live balance derivations.
 */
class LeaveAccrualCalculator
{
    /**
     * Calculate earned leave days for an employee up to a specific as-of date.
     *
     * @param array  $employee        Employee record (must contain joining_date or relevant start date)
     * @param array  $entitlementRule Entitlement configuration for the leave type
     * @param string $asOfDate        Target calculation date (YYYY-MM-DD)
     * @return float Total earned days
     *
     * @throws RuleNotConfiguredException When required rule parameters are missing
     */
    public static function calculateEarnedDays(array $employee, array $entitlementRule, string $asOfDate): float
    {
        $accrualMode = $entitlementRule['accrual_mode'] ?? null;
        if (empty($accrualMode)) {
            throw new RuleNotConfiguredException(
                "Leave accrual_mode is not configured for leave type '" . ($entitlementRule['leave_type_code'] ?? 'UNKNOWN') . "'",
                $employee['company_id'] ?? null,
                'LEAVE',
                $asOfDate
            );
        }

        // Support for historical version slices across rule boundaries
        if (!empty($entitlementRule['slices']) && is_array($entitlementRule['slices'])) {
            $total = 0.0;
            foreach ($entitlementRule['slices'] as $slice) {
                $sliceRule = $slice['rule'] ?? [];
                $sliceStart = $slice['start_date'] ?? $asOfDate;
                $sliceEnd = min($asOfDate, $slice['end_date'] ?? $asOfDate);
                if ($sliceEnd >= $sliceStart) {
                    $total += self::calculateEarnedDaysForSpan($employee, $sliceRule, $sliceStart, $sliceEnd);
                }
            }
            return round($total, 2);
        }

        return match ($accrualMode) {
            'Calendar days'    => self::calculateCalendarDaysEarned($employee, $entitlementRule, $asOfDate),
            'Fixed yearly days' => self::calculateFixedYearlyEarned($employee, $entitlementRule, $asOfDate),
            'Monthly accrual'  => self::calculateMonthlyAccrualEarned($employee, $entitlementRule, $asOfDate),
            'Pro-rata'         => self::calculateProRataEarned($employee, $entitlementRule, $asOfDate),
            'Service-based'    => self::calculateServiceBasedEarned($employee, $entitlementRule, $asOfDate),
            default            => throw new RuleNotConfiguredException(
                "Unsupported leave accrual_mode '{$accrualMode}' for leave type '" . ($entitlementRule['leave_type_code'] ?? 'UNKNOWN') . "'",
                $employee['company_id'] ?? null,
                'LEAVE',
                $asOfDate
            ),
        };
    }

    /**
     * Calendar days accrual mode:
     * N calendar days elapsed = X leave day(s).
     *
     * Timing semantics:
     * - on_completion: cycles = floor(daysElapsed / N)
     * - at_cycle_start: cycles = ceil(daysElapsed / N)
     */
    protected static function calculateCalendarDaysEarned(array $employee, array $entitlementRule, string $asOfDate): float
    {
        $N = $entitlementRule['earn_every_days'] ?? null;
        if ($N === null || !is_numeric($N) || (int)$N < 1) {
            throw new RuleNotConfiguredException(
                "Rule parameter 'earn_every_days' (N) must be configured and >= 1 for Calendar days accrual",
                $employee['company_id'] ?? null,
                'LEAVE',
                $asOfDate
            );
        }
        $N = (int)$N;

        $timing = $entitlementRule['accrual_credit_timing'] ?? null;
        if (empty($timing) || !in_array($timing, ['on_completion', 'at_cycle_start'], true)) {
            throw new RuleNotConfiguredException(
                "Rule parameter 'accrual_credit_timing' must be explicitly configured as 'on_completion' or 'at_cycle_start'",
                $employee['company_id'] ?? null,
                'LEAVE',
                $asOfDate
            );
        }

        $X = isset($entitlementRule['earn_leave_per_cycle']) && is_numeric($entitlementRule['earn_leave_per_cycle'])
            ? (float)$entitlementRule['earn_leave_per_cycle']
            : null;
        if ($X === null || $X <= 0) {
            throw new RuleNotConfiguredException(
                "Rule parameter 'earn_leave_per_cycle' must be configured and > 0 for Calendar days accrual",
                $employee['company_id'] ?? null,
                'LEAVE',
                $asOfDate
            );
        }

        // Determine base start date
        $startFrom = $entitlementRule['accrual_start_from'] ?? 'joining_date';
        $startDate = match ($startFrom) {
            'confirm_date' => $employee['confirm_date'] ?? $employee['confirmed_date'] ?? $employee['probation_end_date'] ?? null,
            'fixed_date'   => $entitlementRule['accrual_fixed_start_date'] ?? null,
            default        => $employee['joining_date'] ?? $employee['date_of_joining'] ?? $employee['employment_start_date'] ?? null,
        };

        if (empty($startDate)) {
            throw new RuleNotConfiguredException(
                "Accrual start date is missing for employee (accrual_start_from: '{$startFrom}')",
                $employee['company_id'] ?? null,
                'LEAVE',
                $asOfDate
            );
        }

        // Probation check: if employee is on probation and probation config disables accrual
        $empStatus = \App\Models\EmployeeModel::normalizeStatus($employee['status'] ?? \App\Models\EmployeeModel::STATUS_ACTIVE, true);
        $isProbation = ($empStatus === \App\Models\EmployeeModel::STATUS_PROBATION)
            || (!empty($employee['probation_end_date']) && $asOfDate <= $employee['probation_end_date'])
            || (empty($employee['confirm_date']) && !empty($employee['probation_duration_value']));

        $probation = $entitlementRule['probation'] ?? [];
        if ($isProbation && isset($probation['accrue_during_probation']) && !$probation['accrue_during_probation']) {
            return 0.0;
        }

        // Per-period clipping: ensure accrual respects carry_forward_period (Calendar, Fiscal, or Anniversary)
        $periodBounds = self::getLeavePeriodBounds($employee, $entitlementRule, $asOfDate);
        $effStartDate = max($periodBounds['start_date'], substr($startDate, 0, 10));

        $d0 = new \DateTimeImmutable($effStartDate);
        $d1 = new \DateTimeImmutable(substr($asOfDate, 0, 10));
        if ($d1 < $d0) {
            return 0.0;
        }

        // Inclusive calendar day count: (asOfDate - effStartDate) + 1
        $daysElapsed = $d0->diff($d1)->days + 1;
        if ($daysElapsed <= 0) {
            return 0.0;
        }

        $cycles = ($timing === 'on_completion')
            ? (int)floor($daysElapsed / $N)
            : (int)ceil($daysElapsed / $N);

        $earned = round($cycles * $X, 2);

        // Per-year cap if days_per_year is configured
        if (isset($entitlementRule['days_per_year']) && (float)$entitlementRule['days_per_year'] > 0) {
            $annualCap = (float)$entitlementRule['days_per_year'];
            if ($earned > $annualCap) {
                $earned = $annualCap;
            }
        }

        if (isset($entitlementRule['max_balance_cap']) && $entitlementRule['max_balance_cap'] !== null && (float)$entitlementRule['max_balance_cap'] > 0) {
            $cap = (float)$entitlementRule['max_balance_cap'];
            if ($earned > $cap) {
                $earned = $cap;
            }
        }

        return $earned;
    }

    /**
     * Fixed yearly days: full allocation is available from start of year or employment
     */
    protected static function calculateFixedYearlyEarned(array $employee, array $entitlementRule, string $asOfDate): float
    {
        $days = (float)($entitlementRule['days_per_year'] ?? 0.0);
        $startDate = $employee['joining_date'] ?? $employee['date_of_joining'] ?? $employee['employment_start_date'] ?? null;
        if (!empty($startDate) && strtotime($asOfDate) < strtotime($startDate)) {
            return 0.0;
        }

        return round($days, 2);
    }

    /**
     * Monthly accrual mode
     */
    protected static function calculateMonthlyAccrualEarned(array $employee, array $entitlementRule, string $asOfDate): float
    {
        $rate = isset($entitlementRule['accrual_rate_per_month']) && $entitlementRule['accrual_rate_per_month'] !== null
            ? (float)$entitlementRule['accrual_rate_per_month']
            : null;

        if ($rate === null) {
            $annual = (float)($entitlementRule['days_per_year'] ?? 0.0);
            if ($annual <= 0) {
                throw new RuleNotConfiguredException(
                    "Either 'accrual_rate_per_month' or 'days_per_year' must be configured for Monthly accrual",
                    $employee['company_id'] ?? null,
                    'LEAVE',
                    $asOfDate
                );
            }
            $rate = $annual / 12.0;
        }

        $startDate = $employee['joining_date'] ?? $employee['date_of_joining'] ?? $employee['employment_start_date'] ?? null;
        if (!empty($startDate) && strtotime($asOfDate) < strtotime($startDate)) {
            return 0.0;
        }

        $periodBounds = self::getLeavePeriodBounds($employee, $entitlementRule, $asOfDate);
        $effStartDate = !empty($startDate) ? max($periodBounds['start_date'], substr($startDate, 0, 10)) : $periodBounds['start_date'];

        $d0 = new \DateTime($effStartDate);
        $d1 = new \DateTime($asOfDate);
        if ($d1 < $d0) {
            return 0.0;
        }

        $monthsElapsed = (($d1->format('Y') - $d0->format('Y')) * 12) + ($d1->format('n') - $d0->format('n')) + 1;
        $earned = round(max(0, $monthsElapsed) * $rate, 2);

        $annualCap = (float)($entitlementRule['days_per_year'] ?? 0.0);
        if ($annualCap > 0 && $earned > $annualCap) {
            $earned = $annualCap;
        }

        if (isset($entitlementRule['max_balance_cap']) && $entitlementRule['max_balance_cap'] !== null && (float)$entitlementRule['max_balance_cap'] > 0) {
            $cap = (float)$entitlementRule['max_balance_cap'];
            if ($earned > $cap) {
                $earned = $cap;
            }
        }

        return $earned;
    }

    /**
     * Pro-rata accrual based on days in period
     */
    protected static function calculateProRataEarned(array $employee, array $entitlementRule, string $asOfDate): float
    {
        $annual = (float)($entitlementRule['days_per_year'] ?? 0.0);
        if ($annual <= 0) {
            return 0.0;
        }

        $periodBounds = self::getLeavePeriodBounds($employee, $entitlementRule, $asOfDate);
        $daysInPeriod = max(1, $periodBounds['total_days']);

        $startDate = $employee['joining_date'] ?? $employee['date_of_joining'] ?? $periodBounds['start_date'];
        $effStart = max($periodBounds['start_date'], $startDate);

        if (strtotime($asOfDate) < strtotime($effStart)) {
            return 0.0;
        }

        $daysElapsed = (int)round((strtotime($asOfDate) - strtotime($effStart)) / 86400) + 1;
        $earned = round(($daysElapsed / $daysInPeriod) * $annual, 2);

        return min($annual, $earned);
    }

    /**
     * Service-based accrual
     */
    protected static function calculateServiceBasedEarned(array $employee, array $entitlementRule, string $asOfDate): float
    {
        $startDate = $employee['joining_date'] ?? $employee['date_of_joining'] ?? null;
        if (empty($startDate)) {
            return (float)($entitlementRule['days_per_year'] ?? 0.0);
        }

        $t0 = strtotime($startDate);
        $t1 = strtotime($asOfDate);
        if ($t1 < $t0) {
            return 0.0;
        }

        $yearsOfService = (int)floor(($t1 - $t0) / (365.25 * 86400));
        $base = (float)($entitlementRule['days_per_year'] ?? 0.0);

        // Additional day per year of completed service, capped if configured
        $bonusDays = $yearsOfService;
        return round($base + $bonusDays, 2);
    }

    /**
     * Calculate earned days across a specific date window (for rule transition version slices)
     */
    public static function calculateEarnedDaysForSpan(array $employee, array $rule, string $startDate, string $endDate): float
    {
        $N = (int)($rule['earn_every_days'] ?? 0);
        if ($N <= 0) {
            return 0.0;
        }

        $X = isset($rule['earn_leave_per_cycle']) && is_numeric($rule['earn_leave_per_cycle'])
            ? (float)$rule['earn_leave_per_cycle']
            : throw new RuleNotConfiguredException(
                "Rule parameter 'earn_leave_per_cycle' must be configured for Calendar days accrual",
                $employee['company_id'] ?? null,
                'LEAVE',
                $endDate
            );
        $timing = $rule['accrual_credit_timing'] ?? 'on_completion';

        $d0 = new \DateTimeImmutable(substr($startDate, 0, 10));
        $d1 = new \DateTimeImmutable(substr($endDate, 0, 10));
        if ($d1 < $d0) {
            return 0.0;
        }
        $days = $d0->diff($d1)->days + 1;
        if ($days <= 0) {
            return 0.0;
        }

        $cycles = ($timing === 'on_completion')
            ? (int)floor($days / $N)
            : (int)ceil($days / $N);

        return round($cycles * $X, 2);
    }

    /**
     * Evaluate Carry Forward & Expiry
     *
     * @param float $availableBalance Closing available balance of prior period
     * @param array $entitlementRule  Leave type entitlement rule
     * @return array ['carried_forward' => float, 'expired' => float]
     */
    public static function calculateCarryForward(float $availableBalance, array $entitlementRule): array
    {
        if ($availableBalance < 0.0) {
            $allowNegative = !empty($entitlementRule['allow_negative_balance'])
                || !empty($entitlementRule['carry_forward_negative_balance']);
            return [
                'carried_forward' => $allowNegative ? round($availableBalance, 2) : 0.0,
                'expired'         => 0.0,
            ];
        }

        if ($availableBalance == 0.0) {
            return [
                'carried_forward' => 0.0,
                'expired'         => 0.0,
            ];
        }

        $allowed = isset($entitlementRule['carry_forward_allowed'])
            ? (bool)$entitlementRule['carry_forward_allowed']
            : !empty($entitlementRule['allow_carry_forward']);

        if (!$allowed) {
            return [
                'carried_forward' => 0.0,
                'expired'         => round($availableBalance, 2),
            ];
        }

        // Apply carry_forward_percentage (default 100% of available balance is eligible)
        $cfPercentage = isset($entitlementRule['carry_forward_percentage']) && is_numeric($entitlementRule['carry_forward_percentage'])
            ? (float)$entitlementRule['carry_forward_percentage']
            : 100.0;
        if ($cfPercentage < 0.0) $cfPercentage = 0.0;
        if ($cfPercentage > 100.0) $cfPercentage = 100.0;

        $eligibleByPercentage = round($availableBalance * ($cfPercentage / 100.0), 2);
        $percentageExpired = max(0.0, round($availableBalance - $eligibleByPercentage, 2));

        // null = unlimited carry forward! 0 = none! >0 = capped carry forward!
        $maxDays = array_key_exists('carry_forward_max_days', $entitlementRule)
            ? $entitlementRule['carry_forward_max_days']
            : ($entitlementRule['max_carry_forward_days'] ?? null);

        if ($maxDays === null || $maxDays === '') {
            $carried = $eligibleByPercentage;
            $expired = $percentageExpired;
        } else {
            $maxFloat = (float)$maxDays;
            if ($maxFloat <= 0.0) {
                $carried = 0.0;
                $expired = round($availableBalance, 2);
            } else {
                $carried = min($eligibleByPercentage, $maxFloat);
                $expired = round($percentageExpired + max(0.0, $eligibleByPercentage - $carried), 2);
            }
        }

        // Policy Cap: Overall max_balance_cap strictly limits maximum accumulated balance,
        // even when annual carry forward itself has no yearly limit (carry_forward_max_days = null).
        if (isset($entitlementRule['max_balance_cap']) && $entitlementRule['max_balance_cap'] !== null && (float)$entitlementRule['max_balance_cap'] > 0) {
            $cap = (float)$entitlementRule['max_balance_cap'];
            if ($carried > $cap) {
                $expired += ($carried - $cap);
                $carried = $cap;
            }
        }

        return [
            'carried_forward' => round($carried, 2),
            'expired'         => round($expired, 2),
        ];
    }

    /**
     * Compute authoritative Live Balance as of a specific date.
     *
     * Balance = earned(asOfDate) + carry_forward - approved - pending - unpaid - encashed - expired
     *
     * @param array  $employee        Employee record
     * @param array  $entitlementRule Entitlement rule from RuleResolver
     * @param array  $ledgerTotals    Aggregated totals from leave ledger / transactions / applications
     * @param string $asOfDate        Target date (YYYY-MM-DD)
     * @return array Complete live balance breakdown
     */
    public static function calculateLiveBalance(array $employee, array $entitlementRule, array $ledgerTotals, string $asOfDate): array
    {
        $periodBounds = self::getLeavePeriodBounds($employee, $entitlementRule, $asOfDate);

        $earned = self::calculateEarnedDays($employee, $entitlementRule, $asOfDate);

        $opening      = (float)($ledgerTotals['opening_balance'] ?? 0.0);
        $carryForward = (float)($ledgerTotals['carry_forward'] ?? $ledgerTotals['carry_forward_days'] ?? 0.0);
        $approved     = (float)($ledgerTotals['approved'] ?? $ledgerTotals['approved_leave_days'] ?? 0.0);
        $pending      = (float)($ledgerTotals['pending'] ?? $ledgerTotals['pending_leave_days'] ?? 0.0);
        $unpaid       = (float)($ledgerTotals['unpaid'] ?? $ledgerTotals['unpaid_adjustment_days'] ?? 0.0);
        $encashed     = (float)($ledgerTotals['encashed'] ?? $ledgerTotals['encashed_days'] ?? 0.0);
        $expired      = (float)($ledgerTotals['expired'] ?? $ledgerTotals['expired_days'] ?? 0.0);

        // Evaluate carry_forward_expiry_months: carried-forward days expire after N months from period start
        $expiryMonths = isset($entitlementRule['carry_forward_expiry_months']) && is_numeric($entitlementRule['carry_forward_expiry_months'])
            ? (int)$entitlementRule['carry_forward_expiry_months']
            : null;

        if ($expiryMonths !== null && $expiryMonths > 0 && $carryForward > 0) {
            $periodStart = $periodBounds['start_date'];
            $expiryDate = date('Y-m-d', strtotime("{$periodStart} +{$expiryMonths} months"));
            if ($asOfDate >= $expiryDate) {
                $expired += $carryForward;
                $carryForward = 0.0;
            }
        }

        $manualAdj = (float)($ledgerTotals['manual_adjustment_days'] ?? 0.0);

        // Balances are authoritatively rule-derived; stored allocated_days and accrued_days
        // from DB columns are not added to entitlement (Phase B Single Rule Store architecture).
        $baseEntitlement = $opening + $earned + $carryForward;

        $cap = isset($entitlementRule['max_balance_cap']) && $entitlementRule['max_balance_cap'] !== null && (float)$entitlementRule['max_balance_cap'] > 0
            ? (float)$entitlementRule['max_balance_cap']
            : null;

        if ($cap !== null && $baseEntitlement > $cap) {
            $baseEntitlement = $cap;
        }

        $totalEntitlement = $baseEntitlement + $manualAdj;
        // Anti-double-count: approved tracks approved days for the quota; unpaid adjustments are Loss of Pay (LOP) payroll tracking, not an additional balance deduction on top of approved leave
        $totalDeductions = $approved + $pending + $encashed + $expired;

        // Negative balance policy handling: if negative balance is allowed, floor at -max_negative_days (or unconstrained negative), otherwise 0.0
        $allowNegative = !empty($entitlementRule['allow_negative_balance']);
        $maxNegative = isset($entitlementRule['max_negative_days']) && is_numeric($entitlementRule['max_negative_days'])
            ? (float)$entitlementRule['max_negative_days']
            : 0.0;
        $minFloor = $allowNegative ? ($maxNegative > 0 ? -$maxNegative : -999999.0) : 0.0;

        $rawAvailable = round($totalEntitlement - $totalDeductions, 2);
        $available = max($minFloor, $rawAvailable);

        if ($cap !== null && $available > ($cap + max(0.0, $manualAdj))) {
            $available = round($cap + max(0.0, $manualAdj), 2);
        }

        $totalUsed = $approved + $encashed + $expired;

        return [
            'as_of_date'             => $asOfDate,
            'opening_balance'        => round($opening, 2),
            'earned_days'            => round($earned, 2),
            'accrued_days'           => round($earned, 2),
            'allocated_days'         => round($earned, 2),
            'manual_adjustment_days' => round($manualAdj, 2),
            'carry_forward_days'     => round($carryForward, 2),
            'total_entitlement'      => round($totalEntitlement, 2),
            'approved_leave_days'    => round($approved, 2),
            'pending_leave_days'     => round($pending, 2),
            'unpaid_adjustment_days' => round($unpaid, 2),
            'encashed_days'          => round($encashed, 2),
            'expired_days'           => round($expired, 2),
            'total_deductions'       => round($totalDeductions, 2),
            'total_used'             => round($totalUsed, 2),
            'available_balance'      => round($available, 2),
            'remaining_after_pending'=> round($available, 2),
            'max_balance_cap'        => $cap,
            'period_mode'            => $periodBounds['period_mode'],
            'period_start_date'      => $periodBounds['start_date'],
            'period_end_date'        => $periodBounds['end_date'],
            'period_year'            => $periodBounds['period_year'],
            'period_label'           => $periodBounds['period_label'],
            'period_bounds'          => $periodBounds,
        ];
    }

    /**
     * Compute a deterministic, standardized cycle number string.
     * Used for idempotent ledger posting in leave_transactions.cycle_no.
     */
    public static function getCycleNumber(array $employee, array $entitlementRule, string $asOfDate): string
    {
        $mode = $entitlementRule['accrual_mode'] ?? 'Fixed yearly days';

        if ($mode === 'Calendar days') {
            $N = (int)($entitlementRule['earn_every_days'] ?? 1);
            $timing = $entitlementRule['accrual_credit_timing'] ?? 'on_completion';
            $startFrom = $entitlementRule['accrual_start_from'] ?? 'joining_date';
            $startDate = match ($startFrom) {
                'confirm_date' => $employee['confirm_date'] ?? $employee['confirmed_date'] ?? $employee['probation_end_date'] ?? null,
                'fixed_date'   => $entitlementRule['accrual_fixed_start_date'] ?? null,
                default        => $employee['joining_date'] ?? $employee['date_of_joining'] ?? $employee['employment_start_date'] ?? null,
            };

            if (empty($startDate)) {
                return "CYCLE-{$N}D-" . date('Ymd', strtotime($asOfDate));
            }

            $periodBounds = self::getLeavePeriodBounds($employee, $entitlementRule, $asOfDate);
            $effStartDate = max($periodBounds['start_date'], substr($startDate, 0, 10));

            $d0 = new \DateTimeImmutable($effStartDate);
            $d1 = new \DateTimeImmutable(substr($asOfDate, 0, 10));
            if ($d1 < $d0) {
                return "CYCLE-{$N}D-0";
            }
            $daysElapsed = $d0->diff($d1)->days + 1;
            if ($daysElapsed <= 0) {
                return "CYCLE-{$N}D-0";
            }

            $cycleIdx = ($timing === 'on_completion')
                ? (int)floor($daysElapsed / $N)
                : (int)ceil($daysElapsed / $N);

            return "CYCLE-{$N}D-{$cycleIdx}";
        }

        if ($mode === 'Monthly accrual') {
            return "MONTH-" . date('Y-m', strtotime($asOfDate));
        }

        $periodBounds = self::getLeavePeriodBounds($employee, $entitlementRule, $asOfDate);
        return "PERIOD-" . $periodBounds['period_year'];
    }

    /**
     * Resolves the authoritative leave entitlement period boundary [start_date, end_date]
     * based on carry_forward_period ('calendar_year', 'fiscal_year', 'joining_anniversary').
     *
     * @param array $employee Employee row (includes company_id, joining_date, etc.)
     * @param array $entitlementRule Entitlement rule definition
     * @param string $asOfDate Target calculation date (YYYY-MM-DD)
     * @param array|null $company Optional company row (with fiscal_year_start)
     * @return array ['period_mode' => string, 'start_date' => string, 'end_date' => string, 'period_year' => int, 'period_label' => string, 'total_days' => int]
     */
    public static function getLeavePeriodBounds(array $employee, array $entitlementRule, string $asOfDate, ?array $company = null): array
    {
        $rawPeriod = (string)($entitlementRule['carry_forward_period'] ?? 'calendar_year');
        $periodMode = strtolower(trim(str_replace(' ', '_', $rawPeriod)));

        if ($periodMode === 'fiscal_year') {
            $fyStartMonth = 7; // Bangladesh fiscal year start (July) standard
            if ($company !== null && isset($company['fiscal_year_start']) && is_numeric($company['fiscal_year_start'])) {
                $fyStartMonth = (int)$company['fiscal_year_start'];
            } elseif (!empty($employee['company_id'])) {
                try {
                    $cRow = \Config\Database::connect()->table('companies')
                        ->select('fiscal_year_start')
                        ->where('id', $employee['company_id'])
                        ->get()->getRowArray();
                    if ($cRow && isset($cRow['fiscal_year_start']) && is_numeric($cRow['fiscal_year_start'])) {
                        $fyStartMonth = (int)$cRow['fiscal_year_start'];
                    }
                } catch (\Throwable $e) {
                    // Fall back to July
                }
            }
            if ($fyStartMonth < 1 || $fyStartMonth > 12) {
                $fyStartMonth = 7;
            }

            $asOfYear = (int)date('Y', strtotime($asOfDate));
            $asOfMonth = (int)date('n', strtotime($asOfDate));

            if ($asOfMonth >= $fyStartMonth) {
                $start = sprintf('%04d-%02d-01', $asOfYear, $fyStartMonth);
                $end = (new \DateTime(sprintf('%04d-%02d-01', $asOfYear + 1, $fyStartMonth)))->modify('-1 day')->format('Y-m-d');
                $periodYear = $asOfYear;
                $label = "FY {$asOfYear}-" . ($asOfYear + 1);
            } else {
                $start = sprintf('%04d-%02d-01', $asOfYear - 1, $fyStartMonth);
                $end = (new \DateTime(sprintf('%04d-%02d-01', $asOfYear, $fyStartMonth)))->modify('-1 day')->format('Y-m-d');
                $periodYear = $asOfYear - 1;
                $label = "FY " . ($asOfYear - 1) . "-{$asOfYear}";
            }
        } elseif ($periodMode === 'joining_anniversary') {
            $joinDate = $employee['joining_date'] ?? $employee['date_of_joining'] ?? $employee['employment_start_date'] ?? null;
            if (!empty($joinDate)) {
                $joinDt = new \DateTime(substr($joinDate, 0, 10));
                $joinMonth = (int)$joinDt->format('n');
                $joinDay = (int)$joinDt->format('j');
                $asOfYear = (int)date('Y', strtotime($asOfDate));

                $daysInJoinMonth = (int)date('t', strtotime(sprintf('%04d-%02d-01', $asOfYear, $joinMonth)));
                $annivDayThisYear = min($joinDay, $daysInJoinMonth);
                $annivDateThisYear = sprintf('%04d-%02d-%02d', $asOfYear, $joinMonth, $annivDayThisYear);

                if ($asOfDate >= $annivDateThisYear) {
                    $start = $annivDateThisYear;
                    $nextYear = $asOfYear + 1;
                    $daysInNext = (int)date('t', strtotime(sprintf('%04d-%02d-01', $nextYear, $joinMonth)));
                    $nextAnniv = sprintf('%04d-%02d-%02d', $nextYear, $joinMonth, min($joinDay, $daysInNext));
                    $end = (new \DateTime($nextAnniv))->modify('-1 day')->format('Y-m-d');
                    $periodYear = $asOfYear;
                    $label = "Anniversary {$asOfYear}-" . ($asOfYear + 1);
                } else {
                    $prevYear = $asOfYear - 1;
                    $daysInPrev = (int)date('t', strtotime(sprintf('%04d-%02d-01', $prevYear, $joinMonth)));
                    $prevAnniv = sprintf('%04d-%02d-%02d', $prevYear, $joinMonth, min($joinDay, $daysInPrev));
                    $start = $prevAnniv;
                    $end = (new \DateTime($annivDateThisYear))->modify('-1 day')->format('Y-m-d');
                    $periodYear = $asOfYear - 1;
                    $label = "Anniversary " . ($asOfYear - 1) . "-{$asOfYear}";
                }
            } else {
                $asOfYear = (int)date('Y', strtotime($asOfDate));
                $start = "{$asOfYear}-01-01";
                $end = "{$asOfYear}-12-31";
                $periodYear = $asOfYear;
                $label = (string)$asOfYear;
            }
        } else {
            // calendar_year (default)
            $asOfYear = (int)date('Y', strtotime($asOfDate));
            $start = "{$asOfYear}-01-01";
            $end = "{$asOfYear}-12-31";
            $periodYear = $asOfYear;
            $label = (string)$asOfYear;
        }

        $d0 = new \DateTime($start);
        $d1 = new \DateTime($end);
        $totalDays = (int)$d0->diff($d1)->days + 1;

        return [
            'period_mode' => $periodMode,
            'start_date'  => $start,
            'end_date'    => $end,
            'period_year' => $periodYear,
            'period_label'=> $label,
            'total_days'  => $totalDays,
        ];
    }
}
