<?php

namespace App\Services\Leave;

use App\Models\EmployeeModel;
use App\Models\LeaveTypeModel;
use App\Models\LeaveTransactionModel;
use App\Models\LeaveBalanceModel;
use App\Services\Rules\RuleResolver;
use App\Services\Rules\RuleNotConfiguredException;
use App\Services\Leave\LeaveAccrualCalculator;
use App\Services\AuditService;

class LeaveAccrualService
{
    protected $db;
    protected EmployeeModel $employeeModel;
    protected LeaveTypeModel $leaveTypeModel;
    protected LeaveBalanceModel $balanceModel;
    protected LeaveTransactionModel $transactionModel;

    public function __construct()
    {
        $this->db = \Config\Database::connect();
        $this->employeeModel = new EmployeeModel();
        $this->leaveTypeModel = new LeaveTypeModel();
        $this->balanceModel = new LeaveBalanceModel();
        $this->transactionModel = new LeaveTransactionModel();
    }

    /**
     * Authoritative Service-Level Tenant Isolation Verification
     * Verifies that the acting user/employee belongs to the target employee's company
     * (Software App Admins excepted as defined in existing code).
     */
    public function verifyTenantIsolation(string $actingId, string $targetCompanyId, string $action = 'adjustment', string $actorLabel = 'User'): ?array
    {
        if (trim($actingId) === '' || trim($targetCompanyId) === '') {
            return null;
        }

        $actingCompanyId = '';
        $rawRole = 'employee';

        $userRow = $this->db->table('users')
            ->select('users.*, roles.code as role_code, roles.name as role_name')
            ->join('roles', 'roles.id = users.role_id', 'left')
            ->where('users.id', $actingId)
            ->get()->getRowArray();

        if (!$userRow) {
            $userRow = $this->db->table('users')
                ->select('users.*, roles.code as role_code, roles.name as role_name')
                ->join('roles', 'roles.id = users.role_id', 'left')
                ->where('users.email', $actingId)
                ->orWhere('users.username', $actingId)
                ->get()->getRowArray();
        }

        if ($userRow) {
            $actingCompanyId = (string)($userRow['company_id'] ?? '');
            $rawRole = $userRow['role_code'] ?? $userRow['role_name'] ?? $userRow['role'] ?? 'employee';
            if ($actingCompanyId === '' && !empty($userRow['employee_id'])) {
                $uEmp = $this->db->table('employees')->where('id', $userRow['employee_id'])->get()->getRowArray();
                if ($uEmp && !empty($uEmp['company_id'])) {
                    $actingCompanyId = (string)$uEmp['company_id'];
                }
            }
        } else {
            $empRow = $this->db->table('employees')->where('id', $actingId)->get()->getRowArray();
            if ($empRow) {
                $actingCompanyId = (string)($empRow['company_id'] ?? '');
                $uRow = $this->db->table('users')
                    ->select('users.*, roles.code as role_code, roles.name as role_name')
                    ->join('roles', 'roles.id = users.role_id', 'left')
                    ->where('users.employee_id', $empRow['id'])
                    ->get()->getRowArray();
                if ($uRow) {
                    $rawRole = $uRow['role_code'] ?? $uRow['role_name'] ?? $uRow['role'] ?? 'employee';
                    if ($actingCompanyId === '' && !empty($uRow['company_id'])) {
                        $actingCompanyId = (string)$uRow['company_id'];
                    }
                }
            }
        }

        if ($actingCompanyId === '' && function_exists('session') && session()->has('company_id')) {
            $actingCompanyId = (string)session()->get('company_id');
        }

        $permService = new \App\Services\PermissionService();
        $canonicalRole = $permService->canonicalizeRole($rawRole);
        $isSoftwareAdmin = ($canonicalRole === 'software_app_admin');

        if (!$isSoftwareAdmin && function_exists('session') && session()->has('user_id')) {
            $sessRole = session()->get('role') ?? session()->get('user_role') ?? '';
            if ($permService->canonicalizeRole($sessRole) === 'software_app_admin') {
                $isSoftwareAdmin = true;
            }
        }

        if (!$isSoftwareAdmin && !empty($actingCompanyId) && !empty($targetCompanyId) && $actingCompanyId !== $targetCompanyId) {
            return [
                'success' => false,
                'message' => "403 Forbidden: Cross-tenant {$action} denied. {$actorLabel} does not belong to the target employee organization."
            ];
        }

        return null;
    }

    /**
     * Run monthly / periodic leave accrual batch
     */
    public function runAccrualBatch(
        string $asOfDate,
        ?string $companyId = null,
        string $performedBy = 'System Accrual Batch',
        bool $isDryRun = false
    ): array {
        $asOfDate = trim($asOfDate);
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $asOfDate) || !strtotime($asOfDate)) {
            return [
                'success'           => false,
                'message'           => 'Invalid as_of_date format. Standard YYYY-MM-DD required.',
                'summary'           => 'Invalid as_of_date format. Standard YYYY-MM-DD required.',
                'as_of_date'        => $asOfDate,
                'is_dry_run'        => $isDryRun,
                'processed_count'   => 0,
                'already_processed' => 0,
                'total_accrued'     => 0.0,
                'records'           => [],
                'errors'            => ['Invalid as_of_date format.'],
            ];
        }

        $year = (int)date('Y', strtotime($asOfDate));

        $empBuilder = $this->db->table('employees')
            ->select('employees.*, departments.name as department_name, designations.name as designation_name')
            ->join('departments', 'departments.id = employees.department_id', 'left')
            ->join('designations', 'designations.id = employees.designation_id', 'left')
            ->whereNotIn('employees.status', [
                EmployeeModel::STATUS_RESIGNED,
                EmployeeModel::STATUS_TERMINATED,
                EmployeeModel::STATUS_INACTIVE,
            ]);

        if ($companyId) {
            $empBuilder->where('employees.company_id', $companyId);
        }

        $employees = $empBuilder->get()->getResultArray();
        $leaveTypes = $this->leaveTypeModel->getActiveTypes($companyId);

        $processed = [];
        $errors = [];
        $alreadyProcessed = 0;
        $skippedFixedYearly = 0;
        $skippedNoEntitlement = 0;
        $skippedZeroIncrement = 0;
        $skippedCrossTenant = 0;
        $skippedProbation = 0;
        $skippedMissingConfirmDate = 0;
        $totalAccrued = 0.0;
        $skipBreakdown = [];

        $leaveService = new \App\Services\LeaveService();

        foreach ($employees as $emp) {
            $empCompanyId = $emp['company_id'] ?: $companyId;
            $leaveRule = null;
            if ($empCompanyId) {
                try {
                    $leaveRule = (new RuleResolver())->resolve($empCompanyId, 'LEAVE', $asOfDate, $emp);
                } catch (\Throwable $e) {
                    log_message('warning', 'runAccrualBatch leaveRule error: ' . $e->getMessage());
                    $leaveRule = null;
                }
            }

            $entitlements = $leaveRule ? ($leaveRule->get('entitlements') ?: []) : [];

            foreach ($leaveTypes as $lt) {
                if (!empty($lt['company_id']) && (string)$lt['company_id'] !== (string)$empCompanyId) {
                    $skippedCrossTenant++;
                    continue;
                }

                $ruleEnt = null;
                $ltCode = strtoupper($lt['code'] ?? '');
                foreach ($entitlements as $ent) {
                    if (strtoupper($ent['leave_type_code'] ?? '') === $ltCode || ($ent['leave_type_id'] ?? '') === $lt['id']) {
                        $ruleEnt = $ent;
                        break;
                    }
                }

                if (!$ruleEnt) {
                    $skippedNoEntitlement++;
                    $skipBreakdown[] = [
                        'employee_id' => $emp['id'],
                        'employee_code' => $emp['employee_code'] ?? '',
                        'leave_type' => $lt['name'],
                        'reason' => 'No matching rule entitlement defined',
                    ];
                    continue;
                }

                $accrualMode = $ruleEnt['accrual_mode'] ?? 'Fixed yearly days';
                if ($accrualMode === 'Fixed yearly days') {
                    $skippedFixedYearly++; // Fixed yearly is credited at year start, not periodic batch
                    $skipBreakdown[] = [
                        'employee_id' => $emp['id'],
                        'employee_code' => $emp['employee_code'] ?? '',
                        'leave_type' => $lt['name'],
                        'reason' => 'Fixed yearly quota credited at year start, excluded from periodic accrual',
                    ];
                    continue;
                }

                // Check start date requirement when policy requires confirmation date
                $startFrom = $ruleEnt['accrual_start_from'] ?? 'joining_date';
                if ($startFrom === 'confirm_date') {
                    $confDate = $emp['confirm_date'] ?? $emp['confirmed_date'] ?? $emp['probation_end_date'] ?? null;
                    if (empty($confDate)) {
                        $skippedMissingConfirmDate++;
                        $skipBreakdown[] = [
                            'employee_id'   => $emp['id'],
                            'employee_code' => $emp['employee_code'] ?? '',
                            'leave_type'    => $lt['name'],
                            'reason'        => 'Missing confirmation date: Accrual start policy is set to confirm_date',
                        ];
                        continue;
                    }
                }

                // Check probation policy: if employee is on probation and probation rule blocks accrual
                $empStatus = \App\Models\EmployeeModel::normalizeStatus($emp['status'] ?? \App\Models\EmployeeModel::STATUS_ACTIVE, true);
                $isProbation = ($empStatus === \App\Models\EmployeeModel::STATUS_PROBATION)
                    || (!empty($emp['probation_end_date']) && $asOfDate <= $emp['probation_end_date'])
                    || (empty($emp['confirm_date']) && !empty($emp['probation_duration_value']));

                $probation = $ruleEnt['probation'] ?? [];
                if ($isProbation && isset($probation['accrue_during_probation']) && !$probation['accrue_during_probation']) {
                    $skippedProbation++;
                    $skipBreakdown[] = [
                        'employee_id'   => $emp['id'],
                        'employee_code' => $emp['employee_code'] ?? '',
                        'leave_type'    => $lt['name'],
                        'reason'        => 'Employee currently on probation and policy excludes accrual during probation',
                    ];
                    continue;
                }

                $cycleNo = LeaveAccrualCalculator::getCycleNumber($emp, $ruleEnt, $asOfDate);

                // Check idempotency
                $existing = $this->db->table('leave_transactions')
                    ->where('employee_id', $emp['id'])
                    ->where('leave_type_id', $lt['id'])
                    ->where('transaction_type', 'Accrual')
                    ->where('cycle_no', $cycleNo)
                    ->countAllResults();

                if ($existing > 0) {
                    $alreadyProcessed++;
                    $skipBreakdown[] = [
                        'employee_id' => $emp['id'],
                        'employee_code' => $emp['employee_code'] ?? '',
                        'leave_type' => $lt['name'],
                        'cycle_no' => $cycleNo,
                        'reason' => 'Already processed for this accrual cycle',
                    ];
                    continue;
                }

                // Calculate incremental earned
                $earnedCumulative = LeaveAccrualCalculator::calculateEarnedDays($emp, $ruleEnt, $asOfDate);

                // Fetch current ledger accrued from DB leave_transactions directly (authoritative single source of truth)
                $ledgerSumRow = $this->db->table('leave_transactions')
                    ->selectSum('days')
                    ->where('employee_id', $emp['id'])
                    ->where('leave_type_id', $lt['id'])
                    ->where('leave_year', $year)
                    ->where('transaction_type', 'Accrual')
                    ->get()
                    ->getRowArray();
                $prevAccrued = (float)($ledgerSumRow['days'] ?? 0.0);
                $increment = round(max(0.0, $earnedCumulative - $prevAccrued), 2);

                if ($increment <= 0.0) {
                    $skippedZeroIncrement++;
                    $skipBreakdown[] = [
                        'employee_id' => $emp['id'],
                        'employee_code' => $emp['employee_code'] ?? '',
                        'leave_type' => $lt['name'],
                        'earned_cumulative' => $earnedCumulative,
                        'prev_accrued' => $prevAccrued,
                        'reason' => 'Earned cumulative quota is less than or equal to previously accrued days',
                    ];
                    continue;
                }

                $rec = [
                    'employee_id'     => $emp['id'],
                    'employee_name'   => trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')),
                    'leave_type_id'   => $lt['id'],
                    'leave_type_name' => $lt['name'],
                    'increment'       => $increment,
                    'cycle_no'        => $cycleNo,
                ];

                if ($isDryRun) {
                    $processed[] = $rec;
                    $totalAccrued += $increment;
                } else {
                    $this->db->transStart();
                    try {
                        $accrualIdempotencyKey = "ACCRUAL-{$empCompanyId}-{$emp['id']}-{$lt['id']}-{$cycleNo}";
                        $ruleVersion = method_exists($leaveRule, 'effectiveVersion') ? ($leaveRule->effectiveVersion() ?? 1) : 1;

                        $this->transactionModel->insert([
                            'id'               => 'tx-' . bin2hex(random_bytes(6)),
                            'company_id'       => $empCompanyId,
                            'employee_id'      => $emp['id'],
                            'leave_type_id'    => $lt['id'],
                            'leave_year'       => $year,
                            'transaction_type' => 'Accrual',
                            'days'             => $increment,
                            'cycle_no'         => $cycleNo,
                            'idempotency_key'  => $accrualIdempotencyKey,
                            'policy_version'   => $ruleVersion,
                            'effective_date'   => $asOfDate,
                            'description'      => "Periodic accrual credit for cycle {$cycleNo}",
                            'performed_by'     => $performedBy,
                            'created_at'       => date('Y-m-d H:i:s'),
                        ]);

                        $balRow = $this->db->query(
                            "SELECT * FROM leave_balances WHERE employee_id = ? AND leave_type_id = ? AND year = ? FOR UPDATE",
                            [$emp['id'], $lt['id'], $year]
                        )->getRowArray();

                        if ($balRow) {
                            $this->db->query(
                                "UPDATE leave_balances SET accrued_days = accrued_days + ? WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                                [$increment, $emp['id'], $lt['id'], $year]
                            );
                        } else {
                            $this->db->table('leave_balances')->insert([
                                'id'                     => 'bal-' . bin2hex(random_bytes(6)),
                                'employee_id'            => $emp['id'],
                                'leave_type_id'          => $lt['id'],
                                'year'                   => $year,
                                'opening_balance'        => 0.0,
                                'allocated_days'         => 0.0,
                                'accrued_days'           => $increment,
                                'carry_forward_days'     => 0.0,
                                'approved_leave_days'    => 0.0,
                                'pending_leave_days'     => 0.0,
                                'unpaid_adjustment_days' => 0.0,
                                'encashed_days'          => 0.0,
                                'manual_adjustment_days' => 0.0,
                                'created_at'             => date('Y-m-d H:i:s'),
                                'updated_at'             => date('Y-m-d H:i:s')
                            ]);
                        }

                        $this->db->transComplete();
                        if ($this->db->transStatus()) {
                            $processed[] = $rec;
                            $totalAccrued += $increment;
                        } else {
                            $errors[] = "Failed to post accrual for employee {$emp['employee_code']} on {$lt['name']}.";
                        }
                    } catch (\Throwable $ex) {
                        $this->db->transRollback();
                        $errors[] = "Error for {$emp['employee_code']}: " . $ex->getMessage();
                    }
                }
            }
        }

        $procCount = count($processed);
        $totalSkipped = $alreadyProcessed + $skippedFixedYearly + $skippedNoEntitlement + $skippedZeroIncrement + $skippedCrossTenant + $skippedProbation + $skippedMissingConfirmDate;
        $summary = "Accrual batch completed: {$procCount} records processed, {$alreadyProcessed} already processed, {$skippedFixedYearly} fixed yearly skipped, {$skippedProbation} probation skipped, {$skippedMissingConfirmDate} unconfirmed skipped, {$skippedZeroIncrement} zero-increment skipped, {$totalAccrued} days total accrued.";

        if (!$isDryRun && $procCount > 0) {
            try {
                $auditService = new AuditService();
                $auditService->log(
                    $companyId,
                    $performedBy,
                    'leave',
                    'leave.accrual_batch',
                    "accrual-{$asOfDate}",
                    null,
                    [
                        'as_of_date'                   => $asOfDate,
                        'company_id'                   => $companyId,
                        'processed_count'              => $procCount,
                        'already_processed'            => $alreadyProcessed,
                        'skipped_fixed_yearly'         => $skippedFixedYearly,
                        'skipped_probation'            => $skippedProbation,
                        'skipped_missing_confirm_date' => $skippedMissingConfirmDate,
                        'skipped_no_entitlement'       => $skippedNoEntitlement,
                        'skipped_zero_increment'       => $skippedZeroIncrement,
                        'total_skipped'                => $totalSkipped,
                        'total_accrued'                => round($totalAccrued, 2),
                    ],
                    $summary
                );
            } catch (\Throwable $e) {
                log_message('error', 'runAccrualBatch audit error: ' . $e->getMessage());
            }
        }
        return [
            'success'                      => empty($errors),
            'message'                      => $summary,
            'summary'                      => $summary,
            'as_of_date'                   => $asOfDate,
            'is_dry_run'                   => $isDryRun,
            'processed_count'              => $procCount,
            'already_processed'            => $alreadyProcessed,
            'skipped_fixed_yearly'         => $skippedFixedYearly,
            'skipped_probation'            => $skippedProbation,
            'skipped_missing_confirm_date' => $skippedMissingConfirmDate,
            'skipped_no_entitlement'       => $skippedNoEntitlement,
            'skipped_zero_increment'       => $skippedZeroIncrement,
            'skipped_cross_tenant'         => $skippedCrossTenant,
            'total_skipped'                => $totalSkipped,
            'total_accrued'                => round($totalAccrued, 2),
            'records'                      => $processed,
            'skip_breakdown'               => $skipBreakdown,
            'errors'                       => $errors
        ];
    }

    /**
     * Adjust leave balance with mandatory reason and complete audit log
     */
    public function adjustBalance(
        string $employeeId,
        string $leaveTypeId,
        int $year,
        float $days,
        string $type,
        string $remarks,
        string $adjustedBy,
        ?string $idempotencyKey = null
    ): array {
        $type = ucfirst(strtolower(trim($type)));
        if (!in_array($type, ['Credit', 'Debit'], true)) {
            return ['success' => false, 'message' => 'Type must be Credit or Debit.'];
        }

        if ($days <= 0) {
            return ['success' => false, 'message' => 'Adjustment days must be greater than zero.'];
        }

        $remarks = trim($remarks);
        if ($remarks === '') {
            return ['success' => false, 'message' => 'Mandatory reason/remarks required for leave balance adjustment.'];
        }

        $emp = $this->db->table('employees')->where('id', $employeeId)->get()->getRowArray();
        if (!$emp) {
            return ['success' => false, 'message' => 'Employee not found.'];
        }

        $lt = $this->db->table('leave_types')->where('id', $leaveTypeId)->get()->getRowArray();
        if (!$lt) {
            return ['success' => false, 'message' => 'Leave type not found.'];
        }

        $companyId = (string)($emp['company_id'] ?? '');

        // Authoritative Service-Level Tenant Isolation Check: Adjusting actor must belong to target employee's company
        if (!empty($adjustedBy)) {
            $isolationErr = $this->verifyTenantIsolation($adjustedBy, $companyId, 'adjustment', 'User');
            if ($isolationErr !== null) {
                return $isolationErr;
            }
        }

        // Authoritative idempotency key handling:
        // Use supplied key (e.g. fresh UUID from modal), or generate a unique key per request (never derive permanent md5 from content)
        $hasExplicitKey = ($idempotencyKey !== null && trim($idempotencyKey) !== '');
        if ($hasExplicitKey) {
            $idempotencyKey = trim($idempotencyKey);
        } else {
            $idempotencyKey = 'adj_' . bin2hex(random_bytes(16));
        }

        // Duplicate rejection guard against re-posting identical adjustment key
        if (!empty($idempotencyKey)) {
            $dupQuery = $this->db->table('leave_transactions')
                ->where('idempotency_key', $idempotencyKey);
            if (!empty($companyId)) {
                $dupQuery->where('company_id', $companyId);
            }
            if ($dupQuery->countAllResults() > 0) {
                return [
                    'success' => false,
                    'message' => 'Duplicate adjustment rejected. This adjustment has already been applied.'
                ];
            }
        }
        // Attendance / Payroll Settlement Check: Locked payroll cannot have leave balance manipulated
        $attService = new \App\Services\AttendanceService();
        if ($attService->isAttendanceSettled($employeeId, date('Y-m-d'))) {
            return [
                'success' => false,
                'message' => '422 Unprocessable Entity: Cannot adjust leave balance. The current payroll cycle has already been settled and locked.'
            ];
        }

        if ($type === 'Debit') {
            $leaveService = new \App\Services\LeaveService();
            $live = $leaveService->getEmployeeBalanceReadOnly($employeeId, $leaveTypeId, $year, $lt);
            $avail = (float)($live['available_balance'] ?? 0.0);
            $allowNegative = (bool)($lt['allow_negative_balance'] ?? 0);
            $maxNegative = (float)($lt['max_negative_days'] ?? 0);

            if ($avail < $days && !$allowNegative) {
                return ['success' => false, 'message' => "Debit adjustment of {$days} days exceeds available balance ({$avail} days)."];
            }

            if ($avail < $days && $allowNegative && $maxNegative > 0 && ($days - $avail) > $maxNegative) {
                return ['success' => false, 'message' => "Debit adjustment exceeds maximum allowed negative balance of {$maxNegative} days."];
            }
        }

        $signedDays = ($type === 'Debit') ? -$days : $days;

        $this->db->transBegin();

        try {
            $balanceRow = $this->db->query(
                "SELECT * FROM leave_balances WHERE employee_id = ? AND leave_type_id = ? AND year = ? FOR UPDATE",
                [$employeeId, $leaveTypeId, $year]
            )->getRowArray();

            if ($balanceRow) {
                $this->db->query(
                    "UPDATE leave_balances SET manual_adjustment_days = manual_adjustment_days + ? WHERE employee_id = ? AND leave_type_id = ? AND year = ?",
                    [$signedDays, $employeeId, $leaveTypeId, $year]
                );
            } else {
                $this->db->table('leave_balances')->insert([
                    'id'                     => 'bal-' . bin2hex(random_bytes(6)),
                    'employee_id'            => $employeeId,
                    'leave_type_id'          => $leaveTypeId,
                    'year'                   => $year,
                    'opening_balance'        => 0.0,
                    'allocated_days'         => 0.0,
                    'accrued_days'           => 0.0,
                    'carry_forward_days'     => 0.0,
                    'approved_leave_days'    => 0.0,
                    'pending_leave_days'     => 0.0,
                    'unpaid_adjustment_days' => 0.0,
                    'encashed_days'          => 0.0,
                    'manual_adjustment_days' => $signedDays,
                    'created_at'             => date('Y-m-d H:i:s'),
                    'updated_at'             => date('Y-m-d H:i:s'),
                ]);
            }

            $txId = 'tx-' . bin2hex(random_bytes(6));
            $txData = [
                'id'               => $txId,
                'company_id'       => $companyId ?: null,
                'employee_id'      => $employeeId,
                'leave_type_id'    => $leaveTypeId,
                'leave_year'       => $year,
                'transaction_type' => 'Adjustment',
                'days'             => $signedDays,
                'cycle_no'         => null,
                'idempotency_key'  => $idempotencyKey,
                'policy_version'   => 1,
                'description'      => "Manual {$type} adjustment: {$remarks}",
                'performed_by'     => $adjustedBy,
                'created_at'       => date('Y-m-d H:i:s'),
            ];
            $this->transactionModel->insert($txData);

            if ($this->db->transStatus() === false) {
                $dbError = $this->db->error();
                $this->db->transRollback();
                $errStr = ($dbError['message'] ?? '') . ' ' . ($dbError['code'] ?? '');
                if (stripos($errStr, 'Duplicate') !== false || stripos($errStr, '1062') !== false || stripos($errStr, 'idempotency_key') !== false || stripos($errStr, 'idx_leave_tx_') !== false) {
                    return [
                        'success' => false,
                        'message' => 'Duplicate adjustment rejected. This adjustment has already been applied.'
                    ];
                }
                return [
                    'success' => false,
                    'message' => 'Failed to process leave balance adjustment due to a database transaction error.'
                ];
            }

            $this->db->transCommit();

            // Mandatory Audit Log after transaction commit
            try {
                $auditService = new AuditService();
                $auditService->log(
                    $emp['company_id'] ?? null,
                    $adjustedBy,
                    'leave',
                    'leave.adjusted',
                    $txId,
                    null,
                    [
                        'employee_id'   => $employeeId,
                        'leave_type_id' => $leaveTypeId,
                        'year'          => $year,
                        'days'          => $signedDays,
                        'type'          => $type,
                        'reason'        => $remarks,
                    ],
                    "Manual {$type} adjustment of {$days} days for {$lt['name']}: {$remarks}"
                );
            } catch (\Throwable $e) {
                log_message('error', 'adjustBalance audit error: ' . $e->getMessage());
            }

            return [
                'success' => true,
                'message' => "Successfully adjusted {$days} days ({$type}) for {$lt['name']} with reason recorded."
            ];
        } catch (\Throwable $e) {
            $this->db->transRollback();
            log_message('error', 'adjustBalance transaction error: ' . $e->getMessage());
            $errorMsg = $e->getMessage();
            if (stripos($errorMsg, 'Duplicate entry') !== false || stripos($errorMsg, '1062') !== false || stripos($errorMsg, 'idempotency_key') !== false || stripos($errorMsg, 'idx_leave_tx_') !== false) {
                return [
                    'success' => false,
                    'message' => 'Duplicate adjustment rejected. This adjustment has already been applied.'
                ];
            }
            return [
                'success' => false,
                'message' => 'Leave balance adjustment failed due to an unexpected system error. Please contact HR administration.'
            ];
        }
    }
}
