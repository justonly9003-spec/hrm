<?php

namespace App\Services;

use App\Models\EmployeeModel;
use App\Models\ShiftModel;
use App\Services\RuleEngineService;
use Config\Database;

/**
 * Live Attendance Event & Performance Simulation Service
 *
 * Drives manual and simulated attendance events through the real enterprise
 * Attendance Engine, Rule Hierarchy, Shift Engine, Overtime Calculations,
 * Leave Validations, and Database State.
 */
class AttendanceEventService
{
    protected $db;
    protected $ruleEngine;

    public const SOURCE_LIVE_TEST = 'live_test';
    public const TEST_TAG = '[Live Test Event]';

    public function __construct()
    {
        $this->db = Database::connect();
        $this->ruleEngine = new RuleEngineService();
    }

    /**
     * Process a single live attendance event through the real HRMS rule engine
     */
    public function processSingleEvent(string $employeeId, string $eventType, string $date, ?string $time = null, array $options = [], ?string $companyId = null): array
    {
        $startMicro = microtime(true);

        $eventType = strtoupper(trim($eventType));
        if ($eventType === 'RESET') {
            $eventType = 'RESET_ATTENDANCE';
        }

        if (empty($date)) {
            $date = date('Y-m-d');
        }
        if (empty($time)) {
            $time = date('H:i:s');
        } elseif (strlen($time) === 5) {
            $time .= ':00';
        }

        if ($companyId === null && !empty($options['company_id'])) {
            $companyId = $options['company_id'];
        }

        // 1. Fetch real employee: first try exact match on employees.id (if companyId given, require company_id = companyId)
        $builder = $this->db->table('employees')
            ->select('employees.*, 
                      departments.name as department_name, 
                      designations.name as designation_name,
                      branches.name as branch_name,
                      shifts.id as shift_table_id,
                      shifts.name as shift_name,
                      shifts.start_time as shift_start_time,
                      shifts.end_time as shift_end_time')
            ->join('departments', 'departments.id = employees.department_id', 'left')
            ->join('designations', 'designations.id = employees.designation_id', 'left')
            ->join('branches', 'branches.id = employees.branch_id', 'left')
            ->join('shifts', 'shifts.id = employees.shift_id', 'left')
            ->where('employees.id', $employeeId);

        if (!empty($companyId)) {
            $builder->where('employees.company_id', $companyId);
        }
        $emp = $builder->get()->getRowArray();

        // Only if that finds nothing, try employee_code AND company_id = companyId
        if (!$emp) {
            if (!empty($companyId)) {
                $emp = $this->db->table('employees')
                    ->select('employees.*, 
                              departments.name as department_name, 
                              designations.name as designation_name,
                              branches.name as branch_name,
                              shifts.id as shift_table_id,
                              shifts.name as shift_name,
                              shifts.start_time as shift_start_time,
                              shifts.end_time as shift_end_time')
                    ->join('departments', 'departments.id = employees.department_id', 'left')
                    ->join('designations', 'designations.id = employees.designation_id', 'left')
                    ->join('branches', 'branches.id = employees.branch_id', 'left')
                    ->join('shifts', 'shifts.id = employees.shift_id', 'left')
                    ->where('employees.company_id', $companyId)
                    ->where('employees.employee_code', $employeeId)
                    ->get()
                    ->getRowArray();
            } else {
                // If companyId is null and id lookup fails, fail closed (skip punch with log)
                log_message('error', "processSingleEvent: Ambiguous employee lookup for code '{$employeeId}'. No company context provided and ID lookup failed.");
                $durationMs = round((microtime(true) - $startMicro) * 1000, 2);
                return [
                    'success'       => false,
                    'event'         => $eventType,
                    'employee_id'   => $employeeId,
                    'employee_code' => $employeeId,
                    'employee_name' => 'Unknown',
                    'department'    => 'Unknown',
                    'designation'   => 'Unknown',
                    'shift'         => 'Standard',
                    'timestamp'     => $time,
                    'date'          => $date,
                    'status'        => 'Failed',
                    'duration_ms'   => $durationMs,
                    'message'       => "Ambiguous employee code '{$employeeId}': company context is required.",
                    'error'         => 'Ambiguous employee code without company context'
                ];
            }
        }

        if (!$emp) {
            $durationMs = round((microtime(true) - $startMicro) * 1000, 2);
            return [
                'success'       => false,
                'event'         => $eventType,
                'employee_id'   => $employeeId,
                'employee_code' => $employeeId,
                'employee_name' => 'Unknown',
                'department'    => 'Unknown',
                'designation'   => 'Unknown',
                'shift'         => 'Standard',
                'timestamp'     => $time,
                'date'          => $date,
                'status'        => 'Failed',
                'duration_ms'   => $durationMs,
                'message'       => "Employee [{$employeeId}] profile not found in system.",
                'error'         => 'Employee not found'
            ];
        }

        $empRealId = $emp['id'];
        $empCode = $emp['employee_code'] ?? $emp['id'];
        $empName = trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')) ?: $empCode;
        $deptName = $emp['department_name'] ?? 'General';
        $desigName = $emp['designation_name'] ?? 'Staff';
        $shiftName = $emp['shift_name'] ?? 'Regular Shift';
        $shiftStart = $emp['shift_start_time'] ?? null;
        $shiftEnd = $emp['shift_end_time'] ?? null;
        
        $shiftGrace = 15;
        $shiftEarlyGrace = 0;
        $shiftId = $emp['shift_id'] ?? $emp['shift_table_id'] ?? null;
        if (!empty($shiftId) && $this->db->tableExists('shifts')) {
            $shiftRow = $this->db->table('shifts')->where('id', $shiftId)->get()->getRowArray();
            if ($shiftRow) {
                $shiftGrace = (int)($shiftRow['late_grace_period_mins'] ?? $shiftRow['late_grace_period_minutes'] ?? $shiftRow['grace_time'] ?? 15);
                $shiftEarlyGrace = (int)($shiftRow['early_exit_grace_mins'] ?? $shiftRow['early_out_threshold_minutes'] ?? 0);
            }
        }

        // Canonical shift resolution: respect assigned shift, duty assignments, shift swaps, and rosters
        $shiftModel = new \App\Models\ShiftModel();
        $effectiveShift = $shiftModel->resolveEffectiveShift($empRealId, $date, $emp);
        if (!empty($effectiveShift)) {
            $shiftName = $effectiveShift['name'] ?? $shiftName;
            $shiftStart = $effectiveShift['start_time'] ?? $shiftStart;
            $shiftEnd = $effectiveShift['end_time'] ?? $shiftEnd;
            $shiftGrace = (int)($effectiveShift['late_grace_period_mins'] ?? $effectiveShift['grace_time'] ?? $shiftGrace);
            $shiftEarlyGrace = (int)($effectiveShift['early_exit_grace_mins'] ?? $shiftEarlyGrace);
            $emp['shift_id'] = $effectiveShift['shift_id'] ?? null;
            $emp['shift_name'] = $shiftName;
            $emp['shift_start_time'] = $shiftStart;
            $emp['shift_end_time'] = $shiftEnd;
            $emp['is_scheduled'] = !empty($effectiveShift['is_scheduled']);
            $emp['is_day_off'] = !empty($effectiveShift['is_day_off']);
            $emp['shift_outcome'] = $effectiveShift['outcome'] ?? 'SCHEDULED_SHIFT';
            $emp['effective_shift'] = $effectiveShift;
        }

        $emp['shift_grace_mins'] = $shiftGrace;
        $emp['shift_early_grace_mins'] = $shiftEarlyGrace;

        // When marking Present, if override_weekend_holiday is enabled on a day off, hydrate base shift timings
        if (!empty($options['override_weekend_holiday']) && !empty($effectiveShift['is_day_off'])) {
            if (empty($shiftStart) && !empty($effectiveShift['base_start_time'])) {
                $shiftStart = $effectiveShift['base_start_time'];
                $emp['shift_start_time'] = $shiftStart;
            }
            if (empty($shiftEnd) && !empty($effectiveShift['base_end_time'])) {
                $shiftEnd = $effectiveShift['base_end_time'];
                $emp['shift_end_time'] = $shiftEnd;
            }
            if (!empty($shiftStart) && !empty($shiftEnd)) {
                $emp['is_scheduled'] = true;
                $effectiveShift['is_scheduled'] = true;
                $effectiveShift['is_day_off'] = false;
                $effectiveShift['start_time'] = $shiftStart;
                $effectiveShift['end_time'] = $shiftEnd;
            }
        }

        // When marking Present, the in_time and event time must strictly match assigned shift schedule
        if ($eventType === 'MARK_PRESENT') {
            if (empty($shiftStart) || empty($shiftEnd) || empty($emp['is_scheduled']) || !empty($effectiveShift['is_day_off'])) {
                $durationMs = round((microtime(true) - $startMicro) * 1000, 2);
                return [
                    'success'       => false,
                    'event'         => $eventType,
                    'employee_id'   => $empRealId,
                    'employee_code' => $empCode,
                    'employee_name' => $empName,
                    'department'    => $deptName,
                    'designation'   => $desigName,
                    'shift'         => $shiftName,
                    'timestamp'     => $time,
                    'date'          => $date,
                    'status'        => 'Failed',
                    'duration_ms'   => $durationMs,
                    'message'       => "Cannot mark present: Employee has no scheduled shift or is on a scheduled day off on {$date}.",
                    'error'         => 'No scheduled shift'
                ];
            }
            $time = $shiftStart;
        }

        // 2. Check real employment status (Active vs Resigned/Terminated)
        $empStatus = \App\Models\EmployeeModel::normalizeStatus($emp['status'] ?? \App\Models\EmployeeModel::STATUS_ACTIVE, true);
        if (in_array($empStatus, [
            \App\Models\EmployeeModel::STATUS_RESIGNED,
            \App\Models\EmployeeModel::STATUS_TERMINATED,
            \App\Models\EmployeeModel::STATUS_INACTIVE,
        ], true)) {
            $durationMs = round((microtime(true) - $startMicro) * 1000, 2);
            $statusLabel = \App\Models\EmployeeModel::getStatusLabel($empStatus);
            return [
                'success'       => false,
                'event'         => $eventType,
                'employee_id'   => $empRealId,
                'employee_code' => $empCode,
                'employee_name' => $empName,
                'department'    => $deptName,
                'designation'   => $desigName,
                'shift'         => $shiftName,
                'timestamp'     => $time,
                'date'          => $date,
                'status'        => 'Failed',
                'duration_ms'   => $durationMs,
                'message'       => "Event rejected: Employee {$empName} is {$statusLabel}.",
                'error'         => "Inactive status: {$statusLabel}"
            ];
        }

        // 2b. Canonical Join-Date Check (Never create or count attendance for dates before join date)
        $joiningDate = self::resolveEmployeeJoiningDate($emp);
        if (!empty($joiningDate) && $date < $joiningDate) {
            $durationMs = round((microtime(true) - $startMicro) * 1000, 2);
            return [
                'success'       => false,
                'skipped'       => true,
                'event'         => $eventType,
                'employee_id'   => $empRealId,
                'employee_code' => $empCode,
                'employee_name' => $empName,
                'department'    => $deptName,
                'designation'   => $desigName,
                'shift'         => $shiftName,
                'timestamp'     => $time,
                'date'          => $date,
                'status'        => 'Skipped',
                'duration_ms'   => $durationMs,
                'message'       => "Event skipped: Date {$date} is before {$empName}'s join date ({$joiningDate}).",
                'reason'        => 'Before join date',
                'error'         => 'Before join date'
            ];
        }

        // 3. Real Leave Integration Check
        $isOnLeave = false;
        $leaveType = '';
        if ($this->db->tableExists('leave_applications')) {
            $leaveApp = $this->db->table('leave_applications')
                ->where('status', 'Approved')
                ->where('start_date <=', $date)
                ->where('end_date >=', $date)
                ->groupStart()
                    ->where('employee_id', $empRealId)
                    ->orWhere('employee_id', $empCode)
                ->groupEnd()
                ->get()
                ->getRowArray();

            if ($leaveApp) {
                $isOnLeave = true;
                $leaveType = $leaveApp['leave_type_id'] ?? $leaveApp['leave_type'] ?? 'Approved Leave';
            }
        }

        // If employee has approved leave and tester tries check-in without override
        if ($isOnLeave && in_array($eventType, ['CHECK_IN', 'LATE_CHECK_IN'], true) && empty($options['override_leave'])) {
            $durationMs = round((microtime(true) - $startMicro) * 1000, 2);
            return [
                'success'       => false,
                'event'         => $eventType,
                'employee_id'   => $empRealId,
                'employee_code' => $empCode,
                'employee_name' => $empName,
                'department'    => $deptName,
                'designation'   => $desigName,
                'shift'         => $shiftName,
                'timestamp'     => $time,
                'date'          => $date,
                'status'        => 'On Leave',
                'leave_status'  => $leaveType,
                'duration_ms'   => $durationMs,
                'message'       => "Leave Conflict: {$empName} has an Approved Leave ({$leaveType}) on {$date}.",
                'error'         => 'Approved leave conflict'
            ];
        }

        // 4. Real Holiday & Weekly Off Detection
        $isHoliday = false;
        $holidayName = '';
        $holiday = $this->isCompanyHoliday($date, $emp['company_id'] ?? null);
        if ($holiday) {
            $isHoliday = true;
            $holidayName = $holiday['name'] ?? 'Company Holiday';
        }

        $dayOfWeek = date('l', strtotime($date));

        // 5. Centralized Shift Resolution (Phase 3)
        $shiftModel = new ShiftModel();
        $effectiveShift = $shiftModel->resolveEffectiveShift($empRealId, $date, $emp);
        $shiftName = $effectiveShift['name'] ?? $shiftName;
        $shiftStart = $effectiveShift['start_time'] ?? $shiftStart;
        $shiftEnd = $effectiveShift['end_time'] ?? $shiftEnd;
        $shiftGrace = (int)($effectiveShift['late_grace_period_mins'] ?? $shiftGrace);
        $shiftEarlyGrace = (int)($effectiveShift['early_exit_grace_mins'] ?? $shiftEarlyGrace);
        $emp['shift_id'] = $effectiveShift['shift_id'] ?? null;
        $emp['shift_start_time'] = $shiftStart;
        $emp['shift_end_time'] = $shiftEnd;
        $emp['shift_grace_mins'] = $shiftGrace;
        $emp['shift_early_grace_mins'] = $shiftEarlyGrace;
        $emp['is_scheduled'] = !empty($effectiveShift['is_scheduled']);
        $emp['is_day_off'] = !empty($effectiveShift['is_day_off']);
        $emp['shift_outcome'] = $effectiveShift['outcome'] ?? 'SCHEDULED_SHIFT';
        $emp['effective_shift'] = $effectiveShift;

        if (!empty($options['override_weekend_holiday']) && !empty($effectiveShift['is_day_off'])) {
            if (empty($shiftStart) && !empty($effectiveShift['base_start_time'])) {
                $shiftStart = $effectiveShift['base_start_time'];
                $emp['shift_start_time'] = $shiftStart;
            }
            if (empty($shiftEnd) && !empty($effectiveShift['base_end_time'])) {
                $shiftEnd = $effectiveShift['base_end_time'];
                $emp['shift_end_time'] = $shiftEnd;
            }
            if (!empty($shiftStart) && !empty($shiftEnd)) {
                $emp['is_scheduled'] = true;
                $emp['is_day_off'] = false;
                $effectiveShift['is_scheduled'] = true;
                $effectiveShift['is_day_off'] = false;
                $effectiveShift['start_time'] = $shiftStart;
                $effectiveShift['end_time'] = $shiftEnd;
                $emp['effective_shift'] = $effectiveShift;
            }
        }

        // 6. Resolve Effective Rule Profile via RuleEngineService
        try {
            $ruleProfile = $this->ruleEngine->resolveEffectiveRuleProfile($date, $emp);
        } catch (\Throwable $ruleEx) {
            try {
                $ruleProfile = $this->ruleEngine->resolveEffectiveRuleProfile(\App\Services\Rules\RuleResolver::today(), $emp);
            } catch (\Throwable $fallbackEx) {
                $durationMs = round((microtime(true) - $startMicro) * 1000, 2);
                return [
                    'success'       => false,
                    'event'         => $eventType,
                    'employee_id'   => $empRealId,
                    'employee_code' => $empCode,
                    'employee_name' => $empName,
                    'department'    => $deptName,
                    'designation'   => $desigName,
                    'shift'         => $shiftName,
                    'timestamp'     => $time,
                    'date'          => $date,
                    'status'        => 'Failed',
                    'duration_ms'   => $durationMs,
                    'message'       => $ruleEx->getMessage(),
                    'error'         => 'Rule not configured'
                ];
            }
        }
        $configuredWeeklyOff = \App\Services\CompanyWeekendService::getCompanyWeeklyOff($emp['company_id'] ?? null, $empRealId, false, $date);
        $isWeeklyOff = in_array($dayOfWeek, (array)$configuredWeeklyOff, true);

        // 7. Fetch existing attendance record for date
        $existing = $this->db->table('attendance_logs')
            ->groupStart()
                ->where('employee_id', $empRealId)
                ->orWhere('employee_id', $empCode)
            ->groupEnd()
            ->where('date', $date)
            ->get()
            ->getRowArray();

        // SEC-MOD02-002: Settled Payroll Protection
        $attModel = new \App\Models\AttendanceModel();
        if ($attModel->isAttendanceSettled($empRealId, $date, $existing['id'] ?? null) && !in_array($eventType, ['RESET_ATTENDANCE', 'RESET'], true)) {
            $durationMs = round((microtime(true) - $startMicro) * 1000, 2);
            return [
                'success'       => false,
                'event'         => $eventType,
                'employee_id'   => $empRealId,
                'employee_code' => $empCode,
                'employee_name' => $empName,
                'department'    => $deptName,
                'designation'   => $desigName,
                'shift'         => $shiftName,
                'timestamp'     => $time,
                'date'          => $date,
                'status'        => 'Locked',
                'duration_ms'   => $durationMs,
                'message'       => "422 Unprocessable Entity: Attendance for {$empName} on {$date} is locked and settled in payroll.",
                'error'         => 'Settled payroll record'
            ];
        }

        $existingCheckIn = $existing['check_in'] ?? $existing['in_time'] ?? null;
        $existingCheckOut = $existing['check_out'] ?? $existing['out_time'] ?? null;

        // 8. Execute Requested Event
        $resultData = [];
        switch (strtoupper($eventType)) {
            case 'CHECK_IN':
                $resultData = $this->handleCheckIn($emp, $date, $time, $ruleProfile, $existing, false, $options);
                break;

            case 'LATE_CHECK_IN':
                $resultData = $this->handleCheckIn($emp, $date, $time, $ruleProfile, $existing, true, $options);
                break;

            case 'CHECK_OUT':
                $resultData = $this->handleCheckOut($emp, $date, $time, $ruleProfile, $existing, false, $options);
                break;

            case 'EARLY_CHECK_OUT':
                $resultData = $this->handleCheckOut($emp, $date, $time, $ruleProfile, $existing, true, $options);
                break;

            case 'MARK_PRESENT':
                $resultData = $this->handleMarkPresent($emp, $date, $ruleProfile, $options);
                break;

            case 'MARK_ABSENT':
                $resultData = $this->handleMarkAbsent($emp, $date, $options);
                break;

            case 'RESET':
            case 'RESET_ATTENDANCE':
                $resultData = $this->handleResetSingle($emp, $date);
                break;

            default:
                $resultData = [
                    'success' => false,
                    'status'  => 'Error',
                    'message' => "Unsupported event type: {$eventType}",
                    'error'   => 'Unknown event type'
                ];
                break;
        }

        $durationMs = round((microtime(true) - $startMicro) * 1000, 2);

        return array_merge([
            'event'         => $eventType,
            'employee_id'   => $empRealId,
            'employee_code' => $empCode,
            'employee_name' => $empName,
            'department'    => $deptName,
            'designation'   => $desigName,
            'shift'         => $shiftName,
            'timestamp'     => $time,
            'date'          => $date,
            'duration_ms'   => $durationMs,
            'is_holiday'    => $isHoliday,
            'is_weekly_off' => $isWeeklyOff,
            'holiday_name'  => $holidayName,
            'leave_status'  => $isOnLeave ? $leaveType : 'None'
        ], $resultData);
    }

    /**
     * Handle Check-In (Standard or Late)
     */
    protected function handleCheckIn(array $emp, string $date, string $time, array $ruleProfile, ?array $existing, bool $forceLate = false, array $options = []): array
    {
        $empId = $emp['id'];
        $shiftStart = $emp['shift_start_time'] ?? null;
        $shiftGrace = (int)($emp['shift_grace_mins'] ?? 15);
        $isScheduled = !empty($emp['is_scheduled']) && !empty($shiftStart);

        // If force late requested and no specific late time was provided, use shift start + grace + 25 mins if scheduled
        if ($forceLate && empty($options['custom_time']) && $isScheduled) {
            $shiftStartSec = strtotime("{$date} {$shiftStart}");
            $lateSec = $shiftStartSec + (($shiftGrace + 25) * 60);
            $time = date('H:i:s', $lateSec);
        }

        $lateMinutes = 0;
        if (!empty($emp['is_day_off']) || ($emp['shift_outcome'] ?? '') === 'WEEKLY_OFF' || ($emp['shift_outcome'] ?? '') === 'ROSTER_DAY_OFF') {
            $status = 'Off-Day Work';
        } elseif (!$isScheduled) {
            $status = 'Present (Unscheduled)';
        } else {
            $status = 'Present';
            $inMins = RuleEngineService::timeStringToMinutes($time);
            $shiftStartMins = RuleEngineService::timeStringToMinutes($shiftStart);
            if ($inMins > ($shiftStartMins + $shiftGrace)) {
                $lateMinutes = $inMins - $shiftStartMins;
                $status = 'Late';
            }
        }

        // If already checked in and re-punch is not forced
        if (!empty($existing) && !empty($existing['check_in']) && empty($options['force_update'])) {
            $inTs = strtotime($date . ' ' . $existing['check_in']);
            $nowTs = strtotime($date . ' ' . $time);
            if ($inTs !== false && $nowTs !== false && abs($nowTs - $inTs) < 60) {
                return [
                    'success'      => true,
                    'type'         => 'Idempotent-Ignored',
                    'status'       => $existing['status'] ?? 'Present',
                    'check_in'     => $existing['check_in'],
                    'check_out'    => $existing['check_out'] ?? null,
                    'late_minutes' => (int)($existing['late_minutes'] ?? 0),
                    'message'      => "Check-in already registered (idempotent retry).",
                ];
            }
            return [
                'success'      => false,
                'status'       => $existing['status'] ?? 'Present',
                'check_in'     => $existing['check_in'],
                'check_out'    => $existing['check_out'] ?? null,
                'late_minutes' => (int)($existing['late_minutes'] ?? 0),
                'message'      => "Employee {$emp['first_name']} already checked in today at {$existing['check_in']}.",
                'error'        => 'Already checked in'
            ];
        }

        $logId = !empty($existing['id']) ? $existing['id'] : ('att-' . bin2hex(random_bytes(8)));
        $checkOutTime = $existing['check_out'] ?? null;

        // If check_out is also present, evaluate complete day with RuleEngineService
        $workingHours = 0.0;
        $overtimeHours = 0.0;
        $earlyOutMinutes = (int)($existing['early_out_minutes'] ?? 0);

        if (!empty($checkOutTime)) {
            $effectiveShift = $emp['effective_shift'] ?? ['start_time' => $shiftStart, 'end_time' => $emp['shift_end_time'] ?? null];
            $calc = $this->ruleEngine->calculateDailyAttendance(
                $date,
                $emp,
                ['check_in' => $time, 'check_out' => $checkOutTime, 'allow_future_simulation' => true],
                $ruleProfile,
                $effectiveShift
            );
            $status = $calc['status'];
            $workingHours = $calc['net_hours'];
            $overtimeHours = $calc['daily_overtime_hours'] + $calc['off_day_overtime_hours'] + $calc['holiday_overtime_hours'];
            $lateMinutes = $calc['late_minutes'];
            $earlyOutMinutes = $calc['early_out_minutes'];
        }

        $effectiveShift = $emp['effective_shift'] ?? ['start_time' => $shiftStart, 'end_time' => $emp['shift_end_time'] ?? null];
        $rosterRef = $effectiveShift['assignment_id'] ?? $effectiveShift['source'] ?? 'EMPLOYEE_DEFAULT';

        $logPayload = [
            'id'                     => $logId,
            'employee_id'            => $empId,
            'company_id'             => $emp['company_id'] ?? null,
            'branch_id'              => $emp['branch_id'] ?? null,
            'shift_id'               => $emp['shift_id'] ?? null,
            'date'                   => $date,
            'attendance_date'        => $date,
            'shift_date'             => $date,
            'checkout_date'          => !empty($checkOutTime) ? $date : null,
            'roster_reference'       => $rosterRef,
            'schedule_snapshot_json' => json_encode($effectiveShift),
            'check_in'               => $time,
            'in_time'                => $time,
            'clock_in'               => "{$date} {$time}",
            'late_minutes'           => $lateMinutes,
            'early_out_minutes'      => $earlyOutMinutes,
            'early_leaving_minutes'  => $earlyOutMinutes,
            'working_hours'          => $workingHours,
            'overtime_hours'         => $overtimeHours,
            'status'                 => $status,
            'day_type'               => !empty($emp['is_day_off']) ? 'WEEKEND_DUTY' : 'NORMAL_WORKDAY',
            'verification_method'    => self::SOURCE_LIVE_TEST,
            'remarks'                => self::TEST_TAG . ($forceLate ? ' Late Check-In' : ' Check-In Event'),
            'is_approved'            => 1,
            'updated_at'             => date('Y-m-d H:i:s')
        ];

        if (!empty($existing)) {
            $this->db->table('attendance_logs')->where('id', $existing['id'])->update($logPayload);
            $this->syncAttendancesTable($logPayload);
        } else {
            $logPayload['created_at'] = date('Y-m-d H:i:s');
            $this->db->table('attendance_logs')->insert($logPayload);
            $this->syncAttendancesTable($logPayload, true);
        }

        $msgLate = $lateMinutes > 0 ? " [LATE: {$lateMinutes} min]" : " [ON TIME]";
        return [
            'success'       => true,
            'status'        => $status,
            'check_in'      => $time,
            'check_out'     => $checkOutTime,
            'late_minutes'  => $lateMinutes,
            'early_out_mins'=> $earlyOutMinutes,
            'working_hours' => $workingHours,
            'overtime_hours'=> $overtimeHours,
            'message'       => "Check-In recorded at {$time}{$msgLate}. Status: {$status}."
        ];
    }

    /**
     * Handle Check-Out (Standard or Early)
     */
    protected function handleCheckOut(array $emp, string $date, string $time, array $ruleProfile, ?array $existing, bool $forceEarly = false, array $options = []): array
    {
        $empId = $emp['id'];
        $shiftStart = $emp['shift_start_time'] ?? null;
        $shiftEnd = $emp['shift_end_time'] ?? null;
        $shiftEarlyGrace = (int)($emp['shift_early_grace_mins'] ?? 0);
        $isScheduled = !empty($emp['is_scheduled']) && !empty($shiftStart) && !empty($shiftEnd);

        // If force early requested and no specific custom time, use 1.5 hours prior to shift end if scheduled
        if ($forceEarly && empty($options['custom_time']) && $isScheduled) {
            $shiftEndSec = strtotime("{$date} {$shiftEnd}");
            $earlySec = $shiftEndSec - (90 * 60); // 90 mins early
            $time = date('H:i:s', $earlySec);
        }

        // Infer check-in if not existing (check today or yesterday for overnight shifts)
        $checkInTime = $existing['check_in'] ?? $existing['in_time'] ?? null;
        $targetDate = $date;
        $targetLog = $existing;
        $isOvernightPair = false;
        $effectiveShift = $emp['effective_shift'] ?? ['start_time' => $shiftStart, 'end_time' => $shiftEnd];

        if (empty($checkInTime)) {
            $yesterday = date('Y-m-d', strtotime($date . ' -1 day'));
            $yesterdayLog = $this->db->table('attendance_logs')
                ->where('employee_id', $empId)
                ->where('date', $yesterday)
                ->get()
                ->getRowArray();

            $yesterdayIsOvernight = false;
            $yesterdayShift = null;
            if ($yesterdayLog && !empty($yesterdayLog['check_in']) && (empty($yesterdayLog['check_out']) || $yesterdayLog['check_out'] === '00:00:00') && !\App\Models\AttendanceModel::isClosureLog($yesterdayLog)) {
                if (!empty($yesterdayLog['schedule_snapshot_json'])) {
                    $yesterdayShift = json_decode($yesterdayLog['schedule_snapshot_json'], true);
                }
                if (!$yesterdayShift) {
                    $shiftModel = new ShiftModel();
                    $yesterdayShift = $shiftModel->resolveEffectiveShift($empId, $yesterday, $emp);
                }
                if ($yesterdayShift) {
                    $yStartMins = RuleEngineService::timeStringToMinutes($yesterdayShift['start_time'] ?? '09:00');
                    $yEndMins = RuleEngineService::timeStringToMinutes($yesterdayShift['end_time'] ?? '18:00');
                    $yesterdayIsOvernight = ($yEndMins <= $yStartMins) || !empty($yesterdayShift['is_night_shift']) || !empty($yesterdayShift['is_cross_midnight']);
                }
            }

            if ($yesterdayIsOvernight) {
                $targetLog = $yesterdayLog;
                $targetDate = $yesterday;
                $checkInTime = $yesterdayLog['check_in'];
                $isOvernightPair = true;
                $effectiveShift = $yesterdayShift;
            } else {
                // Auto infer check-in at shift start so check-out calculation has valid duration if scheduled
                $checkInTime = $isScheduled ? $shiftStart : $time;
            }
        }

        // Run full evaluation through RuleEngineService
        $calc = $this->ruleEngine->calculateDailyAttendance(
            $targetDate,
            $emp,
            ['check_in' => $checkInTime, 'check_out' => $time, 'allow_future_simulation' => true],
            $ruleProfile,
            $effectiveShift
        );

        $logId = !empty($targetLog['id']) ? $targetLog['id'] : ('att-' . bin2hex(random_bytes(8)));
        $workingHours = $calc['net_hours'];
        $overtimeHours = $calc['daily_overtime_hours'] + $calc['off_day_overtime_hours'] + $calc['holiday_overtime_hours'];
        $lateMinutes = $calc['late_minutes'];
        $earlyOutMinutes = $calc['early_out_minutes'];
        $status = $calc['status'];

        $rosterRef = $effectiveShift['assignment_id'] ?? $effectiveShift['source'] ?? ($targetLog['roster_reference'] ?? 'EMPLOYEE_DEFAULT');
        $logPayload = [
            'id'                     => $logId,
            'employee_id'            => $empId,
            'company_id'             => $emp['company_id'] ?? null,
            'branch_id'              => $emp['branch_id'] ?? null,
            'shift_id'               => $effectiveShift['shift_id'] ?? ($emp['shift_id'] ?? null),
            'date'                   => $targetDate,
            'attendance_date'        => $targetDate,
            'shift_date'             => $targetDate,
            'checkout_date'          => $date,
            'roster_reference'       => $rosterRef,
            'schedule_snapshot_json' => json_encode($effectiveShift),
            'check_in'               => $checkInTime,
            'in_time'                => $checkInTime,
            'check_out'              => $time,
            'out_time'               => $time,
            'clock_in'               => "{$targetDate} {$checkInTime}",
            'clock_out'              => "{$date} {$time}",
            'gross_hours'            => (float)($calc['gross_hours'] ?? 0.0),
            'break_hours'            => (float)($calc['break_hours'] ?? 0.0),
            'net_hours'              => $workingHours,
            'working_hours'          => $workingHours,
            'regular_hours'          => (float)($calc['regular_hours'] ?? 0.0),
            'overtime_hours'         => $overtimeHours,
            'late_minutes'           => $lateMinutes,
            'early_out_minutes'      => $earlyOutMinutes,
            'early_leaving_minutes'  => $earlyOutMinutes,
            'status'                 => $status,
            'day_type'               => $calc['day_type'] ?? 'NORMAL_WORKDAY',
            'verification_method'    => self::SOURCE_LIVE_TEST,
            'remarks'                => self::TEST_TAG . ($forceEarly ? ' Early Check-Out' : ' Check-Out Event') . ($isOvernightPair ? ' (Overnight)' : ''),
            'is_approved'            => 1,
            'updated_at'             => date('Y-m-d H:i:s')
        ];

        if (!empty($targetLog)) {
            $this->db->table('attendance_logs')->where('id', $targetLog['id'])->update($logPayload);
            $this->syncAttendancesTable($logPayload);
        } else {
            $logPayload['created_at'] = date('Y-m-d H:i:s');
            $this->db->table('attendance_logs')->insert($logPayload);
            $this->syncAttendancesTable($logPayload, true);
        }

        $msgOt = $overtimeHours > 0 ? " [OT: {$overtimeHours}h]" : "";
        $msgEarly = $earlyOutMinutes > 0 ? " [EARLY: {$earlyOutMinutes}m]" : "";
        return [
            'success'       => true,
            'status'        => $status,
            'check_in'      => $checkInTime,
            'check_out'     => $time,
            'late_minutes'  => $lateMinutes,
            'early_out_mins'=> $earlyOutMinutes,
            'working_hours' => $workingHours,
            'overtime_hours'=> $overtimeHours,
            'message'       => "Check-Out recorded at {$time}. Duration: {$workingHours}h{$msgOt}{$msgEarly}. Status: {$status}."
        ];
    }

    /**
     * Mark Complete Full Day Present (Shift-wise On-time Check-In & On-time Check-Out)
     */
    protected function handleMarkPresent(array $emp, string $date, array $ruleProfile, array $options = []): array
    {
        $shiftStart = $emp['shift_start_time'] ?? null;
        $shiftEnd = $emp['shift_end_time'] ?? null;

        $shiftModel = new ShiftModel();
        $effectiveShift = $shiftModel->resolveEffectiveShift($emp['id'], $date, $emp);
        if (empty($shiftStart) || empty($shiftEnd)) {
            $shiftStart = $effectiveShift['start_time'] ?? null;
            $shiftEnd = $effectiveShift['end_time'] ?? null;
            $emp['shift_id'] = $effectiveShift['shift_id'] ?? null;
            $emp['shift_start_time'] = $shiftStart;
            $emp['shift_end_time'] = $shiftEnd;
            $emp['is_scheduled'] = !empty($effectiveShift['is_scheduled']);
            $emp['shift_outcome'] = $effectiveShift['outcome'] ?? 'SCHEDULED_SHIFT';
        }

        if (!empty($options['override_weekend_holiday']) && !empty($effectiveShift['is_day_off'])) {
            if (empty($shiftStart) && !empty($effectiveShift['base_start_time'])) {
                $shiftStart = $effectiveShift['base_start_time'];
            }
            if (empty($shiftEnd) && !empty($effectiveShift['base_end_time'])) {
                $shiftEnd = $effectiveShift['base_end_time'];
            }
            if (!empty($shiftStart) && !empty($shiftEnd)) {
                $effectiveShift['is_scheduled'] = true;
                $effectiveShift['is_day_off'] = false;
                $effectiveShift['start_time'] = $shiftStart;
                $effectiveShift['end_time'] = $shiftEnd;
                $emp['shift_start_time'] = $shiftStart;
                $emp['shift_end_time'] = $shiftEnd;
                $emp['is_scheduled'] = true;
            }
        }

        if (empty($shiftStart) || empty($shiftEnd) || empty($effectiveShift['is_scheduled']) || !empty($effectiveShift['is_day_off'])) {
            return [
                'success' => false,
                'status'  => 'Failed',
                'message' => "Cannot mark present: Employee has no scheduled shift or is on a scheduled day off on {$date}."
            ];
        }

        if ($shiftStart && strlen($shiftStart) === 5) $shiftStart .= ':00';
        if ($shiftEnd && strlen($shiftEnd) === 5) $shiftEnd .= ':00';

        $calc = $this->ruleEngine->calculateDailyAttendance(
            $date,
            $emp,
            ['check_in' => $shiftStart, 'check_out' => $shiftEnd, 'allow_future_simulation' => true],
            $ruleProfile,
            $effectiveShift
        );

        $startSec = strtotime("2000-01-01 {$shiftStart}");
        $endSec = strtotime("2000-01-01 {$shiftEnd}");
        $isOvernight = ($endSec < $startSec);
        if ($isOvernight) $endSec += 86400; // overnight shift
        $grossHours = round(($endSec - $startSec) / 3600, 2);
        $netHours = !empty($calc['net_hours']) ? (float)$calc['net_hours'] : $grossHours;
        $outDate = $isOvernight ? date('Y-m-d', strtotime("{$date} +1 day")) : $date;

        $existing = $this->db->table('attendance_logs')
            ->where('employee_id', $emp['id'])
            ->where('date', $date)
            ->get()
            ->getRowArray();

        $logId = !empty($existing['id']) ? $existing['id'] : ('att-' . bin2hex(random_bytes(8)));
        $rosterRef = $effectiveShift['assignment_id'] ?? $effectiveShift['source'] ?? 'EMPLOYEE_DEFAULT';
        $logPayload = [
            'id'                     => $logId,
            'employee_id'            => $emp['id'],
            'company_id'             => $emp['company_id'] ?? null,
            'branch_id'              => $emp['branch_id'] ?? null,
            'shift_id'               => $emp['shift_id'] ?? null,
            'date'                   => $date,
            'attendance_date'        => $date,
            'shift_date'             => $date,
            'checkout_date'          => $outDate,
            'roster_reference'       => $rosterRef,
            'schedule_snapshot_json' => json_encode($effectiveShift),
            'check_in'               => $shiftStart,
            'in_time'                => $shiftStart,
            'check_out'              => $shiftEnd,
            'out_time'               => $shiftEnd,
            'clock_in'               => "{$date} {$shiftStart}",
            'clock_out'              => "{$outDate} {$shiftEnd}",
            'gross_hours'            => $grossHours,
            'break_hours'            => (float)($calc['break_hours'] ?? 0.0),
            'net_hours'              => $netHours,
            'working_hours'          => $netHours,
            'regular_hours'          => (float)($calc['regular_hours'] ?? $netHours),
            'overtime_hours'         => 0.00,
            'late_minutes'           => 0,
            'early_out_minutes'      => 0,
            'early_leaving_minutes'  => 0,
            'status'                 => 'Present',
            'day_type'               => $calc['day_type'] ?? 'NORMAL_WORKDAY',
            'verification_method'    => self::SOURCE_LIVE_TEST,
            'remarks'                => self::TEST_TAG . " Marked Present (Shift: {$shiftStart} - {$shiftEnd})",
            'is_approved'            => 1,
            'updated_at'             => date('Y-m-d H:i:s')
        ];

        if (!empty($existing)) {
            $this->db->table('attendance_logs')->where('id', $existing['id'])->update($logPayload);
            $this->syncAttendancesTable($logPayload);
        } else {
            $logPayload['created_at'] = date('Y-m-d H:i:s');
            $this->db->table('attendance_logs')->insert($logPayload);
            $this->syncAttendancesTable($logPayload, true);
        }

        return [
            'success'       => true,
            'status'        => 'Present',
            'check_in'      => $shiftStart,
            'check_out'     => $shiftEnd,
            'late_minutes'  => 0,
            'early_out_mins'=> 0,
            'working_hours' => $logPayload['working_hours'],
            'overtime_hours'=> 0.00,
            'message'       => "Marked Full Day Present ({$shiftStart} - {$shiftEnd}, {$logPayload['working_hours']} hrs)."
        ];
    }

    /**
     * Mark Absent for the date
     */
    protected function handleMarkAbsent(array $emp, string $date, array $options = []): array
    {
        $existing = $this->db->table('attendance_logs')
            ->where('employee_id', $emp['id'])
            ->where('date', $date)
            ->get()
            ->getRowArray();

        $logId = !empty($existing['id']) ? $existing['id'] : ('att-' . bin2hex(random_bytes(8)));
        $logPayload = [
            'id'                  => $logId,
            'employee_id'         => $emp['id'],
            'company_id'          => $emp['company_id'] ?? null,
            'branch_id'           => $emp['branch_id'] ?? null,
            'shift_id'            => $emp['shift_id'] ?? null,
            'date'                => $date,
            'check_in'            => null,
            'in_time'             => null,
            'check_out'           => null,
            'out_time'            => null,
            'clock_in'            => null,
            'clock_out'           => null,
            'late_minutes'        => 0,
            'early_out_minutes'   => 0,
            'early_leaving_minutes' => 0,
            'working_hours'       => 0.00,
            'overtime_hours'      => 0.00,
            'status'              => 'Absent',
            'verification_method' => self::SOURCE_LIVE_TEST,
            'remarks'             => self::TEST_TAG . ' Marked Absent',
            'is_approved'         => 1,
            'updated_at'          => date('Y-m-d H:i:s')
        ];

        if (!empty($existing)) {
            $this->db->table('attendance_logs')->where('id', $existing['id'])->update($logPayload);
            $this->syncAttendancesTable($logPayload);
        } else {
            $logPayload['created_at'] = date('Y-m-d H:i:s');
            $this->db->table('attendance_logs')->insert($logPayload);
            $this->syncAttendancesTable($logPayload, true);
        }

        return [
            'success'       => true,
            'status'        => 'Absent',
            'check_in'      => null,
            'check_out'     => null,
            'late_minutes'  => 0,
            'early_out_mins'=> 0,
            'working_hours' => 0.00,
            'overtime_hours'=> 0.00,
            'message'       => "Marked Absent on {$date}."
        ];
    }

    /**
     * Reset/Delete single employee test attendance
     */
    protected function handleResetSingle(array $emp, string $date): array
    {
        $deleted = 0;
        $logs = $this->db->table('attendance_logs')
            ->where('employee_id', $emp['id'])
            ->where('date', $date)
            ->groupStart()
                ->where('verification_method', self::SOURCE_LIVE_TEST)
                ->orLike('remarks', self::TEST_TAG)
            ->groupEnd()
            ->get()
            ->getResultArray();

        foreach ($logs as $l) {
            $this->db->table('attendance_logs')->where('id', $l['id'])->delete();
            if ($this->db->tableExists('attendances')) {
                $this->db->table('attendances')->where('id', $l['id'])->delete();
            }
            $deleted++;
        }

        return [
            'success'       => true,
            'status'        => 'Cleared',
            'check_in'      => null,
            'check_out'     => null,
            'late_minutes'  => 0,
            'early_out_mins'=> 0,
            'working_hours' => 0.00,
            'overtime_hours'=> 0.00,
            'message'       => "Test attendance record cleared for {$emp['first_name']} on {$date}."
        ];
    }

    /**
     * Synchronize with 'attendances' table if it exists
     */
    protected function syncAttendancesTable(array $payload, bool $isInsert = false): void
    {
        if (!$this->db->tableExists('attendances')) {
            return;
        }

        try {
            $tableFields = $this->db->getFieldNames('attendances');
            $safePayload = [];
            foreach ($payload as $col => $val) {
                if (in_array($col, $tableFields, true)) {
                    $safePayload[$col] = $val;
                }
            }

            if (empty($safePayload['id'])) {
                return;
            }

            $existing = $this->db->table('attendances')->where('id', $safePayload['id'])->get()->getRowArray();
            if ($existing) {
                $this->db->table('attendances')->where('id', $safePayload['id'])->update($safePayload);
            } else {
                $this->db->table('attendances')->insert($safePayload);
            }
        } catch (\Throwable $e) {
            // Silently ignore schema disparity
        }
    }

    /**
     * Process Bulk Attendance Events with Detailed Performance Analytics
     */
    public function processBulk(array $employeeIds, string $eventType, string $date, ?string $time = null, array $options = []): array
    {
        $startMicro = microtime(true);
        $results = [];
        $successCount = 0;
        $failedCount = 0;
        $skippedCount = 0;
        $latencies = [];

        // For MARK_PRESENT, do not enforce a fixed global punch time; respect each employee's effective shift
        if ($eventType === 'MARK_PRESENT') {
            $time = null;
        }

        foreach ($employeeIds as $empId) {
            $singleStart = microtime(true);
            $res = $this->processSingleEvent($empId, $eventType, $date, $time, $options);
            $singleLatency = round((microtime(true) - $singleStart) * 1000, 2);
            $latencies[] = $singleLatency;

            if ($res['success']) {
                $successCount++;
            } else {
                $failedCount++;
            }
            if (!empty($res['skipped'])) {
                $skippedCount++;
            }
            $results[] = $res;
        }

        $totalDurationSec = round(microtime(true) - $startMicro, 4);
        $totalDurationMs = round($totalDurationSec * 1000, 2);
        $totalEvents = count($employeeIds);
        $avgDurationMs = $totalEvents > 0 ? round($totalDurationMs / $totalEvents, 2) : 0.0;
        $minDurationMs = !empty($latencies) ? min($latencies) : 0.0;
        $maxDurationMs = !empty($latencies) ? max($latencies) : 0.0;
        $eventsPerSec = $totalDurationSec > 0 ? round($totalEvents / $totalDurationSec, 1) : 0.0;

        return [
            'success'            => true,
            'event_type'         => $eventType,
            'date'               => $date,
            'timestamp'          => $time ?: date('H:i:s'),
            'total_requested'    => $totalEvents,
            'success_count'      => $successCount,
            'failed_count'       => $failedCount,
            'skipped_count'      => $skippedCount,
            'total_time_sec'     => $totalDurationSec,
            'total_time_ms'      => $totalDurationMs,
            'avg_duration_ms'    => $avgDurationMs,
            'min_duration_ms'    => $minDurationMs,
            'max_duration_ms'    => $maxDurationMs,
            'events_per_second'  => $eventsPerSec,
            'events'             => $results,
            'summary_message'    => "Processed {$totalEvents} events in {$totalDurationSec}s ({$avgDurationMs} ms/event). Success: {$successCount}, Failed: {$failedCount}" . ($skippedCount > 0 ? ", Skipped: {$skippedCount}" : "") . "."
        ];
    }

    /**
     * Run Randomized Performance Stress Simulation
     */
    public function runSimulation(array $config): array
    {
        $startMicro = microtime(true);

        $empCount = (int)($config['employee_count'] ?? 50);
        $eventType = $config['event_type'] ?? 'REALISTIC_DAY'; // 'CHECK_IN', 'CHECK_OUT', 'REALISTIC_DAY'
        $date = $config['date'] ?? date('Y-m-d');
        $startTimeRange = $config['start_time_range'] ?? '08:30:00';
        $endTimeRange = $config['end_time_range'] ?? '10:00:00';
        $deptId = $config['department_id'] ?? null;
        $branchId = $config['branch_id'] ?? null;

        // Fetch active employees up to count
        $builder = $this->db->table('employees')->where('status', \App\Models\EmployeeModel::STATUS_ACTIVE);
        if (!empty($config['company_id'])) $builder->where('company_id', $config['company_id']);
        if ($deptId) $builder->where('department_id', $deptId);
        if ($branchId) $builder->where('branch_id', $branchId);
        $employees = $builder->limit($empCount)->get()->getResultArray();

        if (empty($employees)) {
            return [
                'success' => false,
                'message' => 'No active employees found matching the simulation criteria.'
            ];
        }

        $allEvents = [];
        $successCount = 0;
        $failedCount = 0;
        $latencies = [];

        $startTs = strtotime("{$date} {$startTimeRange}");
        $endTs = strtotime("{$date} {$endTimeRange}");
        if ($endTs <= $startTs) {
            $endTs = $startTs + (90 * 60);
        }

        foreach ($employees as $idx => $emp) {
            $empId = $emp['id'];

            if ($eventType === 'REALISTIC_DAY') {
                // Generate randomized realistic in-time
                $randInTs = rand($startTs, $endTs);
                $randInTime = date('H:i:s', $randInTs);

                // Step 1: Check In
                $s1 = microtime(true);
                $resIn = $this->processSingleEvent($empId, 'CHECK_IN', $date, $randInTime, ['custom_time' => true]);
                $lat1 = round((microtime(true) - $s1) * 1000, 2);
                $latencies[] = $lat1;
                $allEvents[] = $resIn;
                if ($resIn['success']) $successCount++; else $failedCount++;

                // Step 2: Check Out (Worked 7.5 to 10.5 hours)
                $workedHours = 7.5 + (rand(0, 30) / 10.0); // e.g. 7.5 to 10.5 hrs
                $randOutTs = $randInTs + (int)($workedHours * 3600);
                $randOutTime = date('H:i:s', $randOutTs);

                $s2 = microtime(true);
                $resOut = $this->processSingleEvent($empId, 'CHECK_OUT', $date, $randOutTime, ['custom_time' => true]);
                $lat2 = round((microtime(true) - $s2) * 1000, 2);
                $latencies[] = $lat2;
                $allEvents[] = $resOut;
                if ($resOut['success']) $successCount++; else $failedCount++;

            } elseif ($eventType === 'CHECK_IN') {
                $randInTs = rand($startTs, $endTs);
                $randInTime = date('H:i:s', $randInTs);

                $s = microtime(true);
                $res = $this->processSingleEvent($empId, 'CHECK_IN', $date, $randInTime, ['custom_time' => true]);
                $lat = round((microtime(true) - $s) * 1000, 2);
                $latencies[] = $lat;
                $allEvents[] = $res;
                if ($res['success']) $successCount++; else $failedCount++;

            } elseif ($eventType === 'CHECK_OUT') {
                $outStartTs = strtotime("{$date} 17:00:00");
                $outEndTs = strtotime("{$date} 20:30:00");
                $randOutTs = rand($outStartTs, $outEndTs);
                $randOutTime = date('H:i:s', $randOutTs);

                $s = microtime(true);
                $res = $this->processSingleEvent($empId, 'CHECK_OUT', $date, $randOutTime, ['custom_time' => true]);
                $lat = round((microtime(true) - $s) * 1000, 2);
                $latencies[] = $lat;
                $allEvents[] = $res;
                if ($res['success']) $successCount++; else $failedCount++;
            }
        }

        $totalDurationSec = round(microtime(true) - $startMicro, 4);
        $totalDurationMs = round($totalDurationSec * 1000, 2);
        $totalEvents = count($allEvents);
        $avgDurationMs = $totalEvents > 0 ? round($totalDurationMs / $totalEvents, 2) : 0.0;
        $minDurationMs = !empty($latencies) ? min($latencies) : 0.0;
        $maxDurationMs = !empty($latencies) ? max($latencies) : 0.0;
        $eventsPerSec = $totalDurationSec > 0 ? round($totalEvents / $totalDurationSec, 1) : 0.0;

        return [
            'success'            => true,
            'simulation_type'    => $eventType,
            'date'               => $date,
            'employees_count'    => count($employees),
            'total_events'       => $totalEvents,
            'success_count'      => $successCount,
            'failed_count'       => $failedCount,
            'total_time_sec'     => $totalDurationSec,
            'total_time_ms'      => $totalDurationMs,
            'avg_duration_ms'    => $avgDurationMs,
            'min_duration_ms'    => $minDurationMs,
            'max_duration_ms'    => $maxDurationMs,
            'events_per_second'  => $eventsPerSec,
            'events'             => $allEvents,
            'summary_message'    => "Executed simulation for " . count($employees) . " employees ({$totalEvents} events) in {$totalDurationSec}s ({$avgDurationMs} ms/event, {$eventsPerSec} events/sec)."
        ];
    }

    /**
     * Safe Test Data Cleanup Engine
     * ONLY deletes records marked with verification_method = 'live_test' OR remarks containing '[Live Test Event]'
     * NEVER touches real biometric / manual production records.
     */
    public function resetTestData(string $scope, array $options = []): array
    {
        $date = $options['date'] ?? date('Y-m-d');
        $employeeIds = $options['employee_ids'] ?? [];
        $companyId = $options['company_id'] ?? null;

        $builder = $this->db->table('attendance_logs')
            ->groupStart()
                ->where('verification_method', self::SOURCE_LIVE_TEST)
                ->orLike('remarks', self::TEST_TAG)
            ->groupEnd();

        if (!empty($companyId)) {
            $builder->whereIn('employee_id', function ($subQuery) use ($companyId) {
                return $subQuery->select('id')->from('employees')->where('company_id', $companyId);
            });
        }

        $fromDate = $options['from_date'] ?? $date;
        $toDate = $options['to_date'] ?? $date;

        if ($scope === 'selected' && !empty($employeeIds)) {
            $builder->whereIn('employee_id', $employeeIds);
            if (!empty($date)) {
                $builder->where('date', $date);
            }
        } elseif ($scope === 'range') {
            $builder->where('date >=', $fromDate)->where('date <=', $toDate);
        } elseif ($scope === 'date') {
            $builder->where('date', $date);
        } elseif ($scope === 'all') {
            // All test records across the entire history
        }

        $recordsToDelete = $builder->get()->getResultArray();
        $deletedCount = 0;

        foreach ($recordsToDelete as $rec) {
            $this->db->table('attendance_logs')->where('id', $rec['id'])->delete();
            if ($this->db->tableExists('attendances')) {
                $this->db->table('attendances')->where('id', $rec['id'])->delete();
            }
            $deletedCount++;
        }

        return [
            'success'       => true,
            'scope'         => $scope,
            'date'          => $date,
            'deleted_count' => $deletedCount,
            'message'       => "Cleaned up {$deletedCount} live test attendance records safely."
        ];
    }

    /**
     * Fetch Live Active Employees with Real Database Attendance State for Date or Date Range
     */
    public function getLiveEmployeeList(string $date, array $filters = []): array
    {
        $companyId = $filters['company_id'] ?? null;
        $fromDate = $filters['from_date'] ?? $date;
        $toDate = $filters['to_date'] ?? $date;
        $isRange = ($filters['date_mode'] ?? 'single') === 'range' || ($fromDate !== $toDate);
        if ($fromDate > $toDate) {
            $tmp = $fromDate;
            $fromDate = $toDate;
            $toDate = $tmp;
        }
        $skipWeekends = !in_array($filters['skip_weekends'] ?? true, [false, 0, '0', 'false'], true);
        $skipHolidays = !in_array($filters['skip_holidays'] ?? true, [false, 0, '0', 'false'], true);

        $empFields = $this->db->getFieldNames('employees');
        $dateCols = [];
        foreach (['joining_date', 'join_date', 'hire_date'] as $col) {
            if (in_array($col, $empFields, true)) {
                $dateCols[] = "employees.{$col}";
            }
        }
        $dateColsSelect = !empty($dateCols) ? (', ' . implode(', ', $dateCols)) : '';

        $builder = $this->db->table('employees')
            ->select('employees.id, employees.employee_code, employees.first_name, employees.last_name, 
                      employees.email, employees.status as employee_status, employees.photo, employees.photo as avatar,
                      employees.company_id' . $dateColsSelect . ',
                      departments.id as department_id, departments.name as department_name,
                      designations.id as designation_id, designations.name as designation_name,
                      branches.id as branch_id, branches.name as branch_name,
                      shifts.id as shift_id, shifts.name as shift_name,
                      shifts.start_time as shift_start_time, shifts.end_time as shift_end_time')
            ->join('departments', 'departments.id = employees.department_id', 'left')
            ->join('designations', 'designations.id = employees.designation_id', 'left')
            ->join('branches', 'branches.id = employees.branch_id', 'left')
            ->join('shifts', 'shifts.id = employees.shift_id', 'left')
            ->where('employees.status', \App\Models\EmployeeModel::STATUS_ACTIVE);

        if (!empty($companyId)) {
            $builder->where('employees.company_id', $companyId);
        }
        if (!empty($filters['department_id'])) {
            $builder->where('employees.department_id', $filters['department_id']);
        }
        if (!empty($filters['branch_id'])) {
            $builder->where('employees.branch_id', $filters['branch_id']);
        }
        if (!empty($filters['shift_id'])) {
            $builder->where('employees.shift_id', $filters['shift_id']);
        }
        if (!empty($filters['search'])) {
            $s = trim($filters['search']);
            $builder->groupStart()
                ->like('employees.first_name', $s)
                ->orLike('employees.last_name', $s)
                ->orLike('employees.employee_code', $s)
                ->orLike('departments.name', $s)
                ->orLike('designations.name', $s)
            ->groupEnd();
        }

        $employees = $builder->orderBy('employees.first_name', 'ASC')->get()->getResultArray();
        if (empty($employees)) {
            return [];
        }

        $empIds = array_column($employees, 'id');
        $empCodes = array_filter(array_column($employees, 'employee_code'));
        $allLookupIds = array_values(array_unique(array_merge($empIds, $empCodes)));

        // Range Mode Processing
        if ($isRange) {
            $startTs = strtotime($fromDate);
            $endTs = strtotime($toDate);
            // Allow up to 3 years (1095 days)
            if (($endTs - $startTs) / 86400 > 1095) {
                $endTs = $startTs + (1095 * 86400);
            }

            $holidaysByDate = $skipHolidays ? $this->getCompanyHolidaysInRange($fromDate, $toDate, $companyId) : [];
            $workingDates = [];
            for ($currTs = $startTs; $currTs <= $endTs; $currTs += 86400) {
                $currDate = date('Y-m-d', $currTs);
                if ($skipWeekends && \App\Services\CompanyWeekendService::isWeeklyOff($currDate, $companyId)) {
                    continue;
                }
                if ($skipHolidays && !empty($holidaysByDate[$currDate])) {
                    continue;
                }
                $workingDates[] = $currDate;
            }

            // Batch fetch attendance logs across range
            $logsByEmpAndDate = [];
            if (!empty($allLookupIds)) {
                $logRows = $this->db->table('attendance_logs')
                    ->whereIn('employee_id', $allLookupIds)
                    ->where('date >=', $fromDate)
                    ->where('date <=', $toDate)
                    ->get()
                    ->getResultArray();
                foreach ($logRows as $lr) {
                    $logsByEmpAndDate[$lr['employee_id']][$lr['date']] = $lr;
                }
            }

            // Batch fetch approved leaves across range
            $leavesByEmpAndDate = [];
            if ($this->db->tableExists('leave_applications') && !empty($allLookupIds)) {
                $leaveRows = $this->db->table('leave_applications')
                    ->where('status', 'Approved')
                    ->where('start_date <=', $toDate)
                    ->where('end_date >=', $fromDate)
                    ->whereIn('employee_id', $allLookupIds)
                    ->get()
                    ->getResultArray();
                foreach ($leaveRows as $lvr) {
                    $lStart = max($fromDate, $lvr['start_date'] ?? $fromDate);
                    $lEnd = min($toDate, $lvr['end_date'] ?? $toDate);
                    $curL = $lStart;
                    $lType = $lvr['leave_type_id'] ?? $lvr['leave_type'] ?? 'Approved Leave';
                    while ($curL <= $lEnd) {
                        $leavesByEmpAndDate[$lvr['employee_id']][$curL] = $lType;
                        $curL = date('Y-m-d', strtotime($curL . ' +1 day'));
                    }
                }
            }

            $result = [];
            foreach ($employees as $e) {
                $empId = $e['id'];
                $empCode = $e['employee_code'];
                $joiningDate = self::resolveEmployeeJoiningDate($e);

                // Filter working dates to strictly ON or AFTER employee join date
                $empWorkingDates = array_values(array_filter($workingDates, function($d) use ($joiningDate) {
                    return empty($joiningDate) || $d >= $joiningDate;
                }));

                $presentDays = 0;
                $lateDays = 0;
                $absentDays = 0;
                $leaveDays = 0;
                $workingHours = 0.0;
                $overtimeHours = 0.0;
                $lastCheckIn = null;
                $lastCheckOut = null;

                foreach ($empWorkingDates as $wd) {
                    $hasLeave = $leavesByEmpAndDate[$empId][$wd] ?? ($leavesByEmpAndDate[$empCode][$wd] ?? null);
                    if ($hasLeave) {
                        $leaveDays++;
                        continue;
                    }

                    $log = $logsByEmpAndDate[$empId][$wd] ?? ($logsByEmpAndDate[$empCode][$wd] ?? null);
                    if (!empty($log)) {
                        $st = $log['status'] ?? 'Present';
                        $isPresLog = ($st === 'Present' || $st === 'Late' || $st === 'Half Day' || $st === 'Present (Early Closure)' || $st === 'Approved Early Closure' || str_starts_with($st, 'Present') || (!empty($log['closure_credit_hours']) && (float)$log['closure_credit_hours'] > 0));
                        if ($isPresLog) {
                            $presentDays++;
                        } elseif ($st === 'Absent') {
                            $absentDays++;
                        } else {
                            $presentDays++;
                        }
                        if ((!empty($log['late_minutes']) && (int)$log['late_minutes'] > 0) || $st === 'Late') {
                            $lateDays++;
                        }
                        $workingHours += (float)($log['working_hours'] ?? 0);
                        $overtimeHours += (float)($log['overtime_hours'] ?? 0);
                        $lastCheckIn = $log['check_in'] ?? $lastCheckIn;
                        $lastCheckOut = $log['check_out'] ?? $lastCheckOut;
                    } else {
                        $absentDays++;
                    }
                }

                if (count($empWorkingDates) === 0) {
                    if (!empty($joiningDate) && count($workingDates) > 0) {
                        $status = "Before join date";
                    } else {
                        $status = "No Working Days";
                    }
                } else {
                    $status = "P: {$presentDays} | L: {$lateDays} | A: {$absentDays} | LV: {$leaveDays}";
                }

                $result[] = [
                    'id'                  => $empId,
                    'employee_code'       => $empCode,
                    'first_name'          => $e['first_name'] ?? '',
                    'last_name'           => $e['last_name'] ?? '',
                    'name'                => trim(($e['first_name'] ?? '') . ' ' . ($e['last_name'] ?? '')),
                    'full_name'           => trim(($e['first_name'] ?? '') . ' ' . ($e['last_name'] ?? '')),
                    'company_id'          => $e['company_id'] ?? $companyId,
                    'photo'               => $e['photo'] ?? $e['avatar'] ?? null,
                    'avatar'              => $e['avatar'] ?? $e['photo'] ?? null,
                    'department_id'       => $e['department_id'],
                    'department_name'     => $e['department_name'] ?? 'General',
                    'department'          => $e['department_name'] ?? 'General',
                    'designation_id'      => $e['designation_id'] ?? null,
                    'designation_name'    => $e['designation_name'] ?? 'Staff',
                    'role'                => $e['designation_name'] ?? 'Staff',
                    'branch_id'           => $e['branch_id'] ?? null,
                    'branch_name'         => $e['branch_name'] ?? 'HQ',
                    'shift_id'            => $e['shift_id'],
                    'shift_name'          => $e['shift_name'] ?? 'Day Shift (09:00 - 18:00)',
                    'shift_start_time'    => $e['shift_start_time'] ?? '09:00:00',
                    'shift_end_time'      => $e['shift_end_time'] ?? '18:00:00',
                    'start_time'          => $e['shift_start_time'] ?? '09:00:00',
                    'end_time'            => $e['shift_end_time'] ?? '18:00:00',
                    'shift_grace_mins'    => 15,
                    'has_log'             => ($presentDays > 0 || $leaveDays > 0),
                    'is_test_record'      => true,
                    'source'              => self::SOURCE_LIVE_TEST,
                    'verification_source' => 'Range Muster',
                    'check_in'            => $lastCheckIn,
                    'check_out'           => $lastCheckOut,
                    'status'              => $status,
                    'live_status'         => $status,
                    'range_working_days'  => count($empWorkingDates),
                    'range_present_days'  => $presentDays,
                    'range_late_days'     => $lateDays,
                    'range_absent_days'   => $absentDays,
                    'range_leave_days'    => $leaveDays,
                    'present_count'       => $presentDays,
                    'late_count'          => $lateDays,
                    'absent_count'        => $absentDays,
                    'leave_count'         => $leaveDays,
                    'late_status'         => $lateDays > 0,
                    'late_minutes'        => $lateDays > 0 ? 1 : 0,
                    'early_out_minutes'   => 0,
                    'working_hours'       => round($workingHours, 1),
                    'overtime_hours'      => round($overtimeHours, 1),
                    'leave_status'        => $leaveDays > 0 ? 'Approved Leave' : 'None',
                    'is_holiday'          => false,
                    'holiday_name'        => '',
                    'is_weekly_off'       => false,
                    'joining_date'        => $joiningDate
                ];
            }
            return $result;
        }

        // Single Date Mode Processing
        $logs = $this->db->table('attendance_logs')
            ->where('date', $date)
            ->whereIn('employee_id', $allLookupIds)
            ->get()
            ->getResultArray();
        $logsByEmp = [];
        foreach ($logs as $l) {
            $logsByEmp[$l['employee_id']] = $l;
        }

        $leavesByEmp = [];
        if ($this->db->tableExists('leave_applications')) {
            $leaves = $this->db->table('leave_applications')
                ->where('status', 'Approved')
                ->where('start_date <=', $date)
                ->where('end_date >=', $date)
                ->whereIn('employee_id', $allLookupIds)
                ->get()
                ->getResultArray();
            foreach ($leaves as $lv) {
                $leavesByEmp[$lv['employee_id']] = $lv['leave_type_id'] ?? $lv['leave_type'] ?? 'Approved Leave';
            }
        }

        $holiday = $this->isCompanyHoliday($date, $companyId);
        $isHoliday = !empty($holiday);
        $holidayName = $holiday['name'] ?? ($holiday['title'] ?? '');

        $result = [];
        foreach ($employees as $e) {
            $empId = $e['id'];
            $empCode = $e['employee_code'];
            $empCompanyId = $e['company_id'] ?? $companyId;
            $joiningDate = self::resolveEmployeeJoiningDate($e);
            $isBeforeJoin = (!empty($joiningDate) && $date < $joiningDate);
            $isWeeklyOff = \App\Services\CompanyWeekendService::isWeeklyOff($date, $empCompanyId, $empId);
            $log = $logsByEmp[$empId] ?? ($logsByEmp[$empCode] ?? null);
            $leaveStatus = $leavesByEmp[$empId] ?? ($leavesByEmp[$empCode] ?? null);

            $hasLog = !empty($log);
            $checkIn = $log['check_in'] ?? $log['in_time'] ?? null;
            $checkOut = $log['check_out'] ?? $log['out_time'] ?? null;
            $status = $log['status'] ?? null;
            $lateMinutes = (int)($log['late_minutes'] ?? 0);
            $earlyOutMinutes = (int)($log['early_out_minutes'] ?? ($log['early_leaving_minutes'] ?? 0));
            $workingHours = (float)($log['working_hours'] ?? 0.00);
            $overtimeHours = (float)($log['overtime_hours'] ?? 0.00);
            $isTestRecord = (($log['verification_method'] ?? '') === self::SOURCE_LIVE_TEST) || (strpos($log['remarks'] ?? '', self::TEST_TAG) !== false);

            if ($isBeforeJoin) {
                $status = 'Before join date';
            } elseif (!$status) {
                if ($leaveStatus) {
                    $status = 'On Leave';
                } elseif ($isHoliday) {
                    $status = 'Holiday';
                } elseif ($isWeeklyOff) {
                    $status = 'Weekly Off';
                } else {
                    $status = 'Absent';
                }
            }

            $result[] = [
                'id'                => $empId,
                'employee_code'     => $empCode,
                'first_name'        => $e['first_name'] ?? '',
                'last_name'         => $e['last_name'] ?? '',
                'name'              => trim(($e['first_name'] ?? '') . ' ' . ($e['last_name'] ?? '')),
                'full_name'         => trim(($e['first_name'] ?? '') . ' ' . ($e['last_name'] ?? '')),
                'company_id'        => $empCompanyId,
                'photo'             => $e['photo'] ?? $e['avatar'] ?? null,
                'avatar'            => $e['avatar'] ?? $e['photo'] ?? null,
                'department_id'     => $e['department_id'],
                'department_name'   => $e['department_name'] ?? 'General',
                'department'        => $e['department_name'] ?? 'General',
                'designation_id'    => $e['designation_id'] ?? null,
                'designation_name'  => $e['designation_name'] ?? 'Staff',
                'role'              => $e['designation_name'] ?? 'Staff',
                'branch_id'         => $e['branch_id'] ?? null,
                'branch_name'       => $e['branch_name'] ?? 'HQ',
                'shift_id'          => $e['shift_id'],
                'shift_name'        => $e['shift_name'] ?? 'Day Shift (09:00 - 18:00)',
                'shift_start_time'  => $e['shift_start_time'] ?? '09:00:00',
                'shift_end_time'    => $e['shift_end_time'] ?? '18:00:00',
                'start_time'        => $e['shift_start_time'] ?? '09:00:00',
                'end_time'          => $e['shift_end_time'] ?? '18:00:00',
                'shift_grace_mins'  => (int)($e['shift_grace_mins'] ?? 15),
                'has_log'           => $hasLog,
                'is_test_record'    => $isTestRecord,
                'source'            => $isTestRecord ? self::SOURCE_LIVE_TEST : ($log['verification_method'] ?? ($hasLog ? 'DB' : '')),
                'verification_source' => $log['verification_method'] ?? ($hasLog ? 'DB' : 'None'),
                'check_in'          => $checkIn,
                'check_out'         => $checkOut,
                'status'            => $status,
                'live_status'       => $status,
                'late_status'       => $lateMinutes > 0,
                'late_minutes'      => $lateMinutes,
                'early_out_minutes' => $earlyOutMinutes,
                'working_hours'     => $workingHours,
                'overtime_hours'    => $overtimeHours,
                'leave_status'      => $leaveStatus ?: 'None',
                'is_holiday'        => $isHoliday,
                'holiday_name'      => $holidayName,
                'is_weekly_off'     => $isWeeklyOff,
                'joining_date'      => $joiningDate,
                'is_before_join'    => $isBeforeJoin
            ];
        }

        return $result;
    }

    /**
     * Fetch Live Counters & KPI Metrics for Date or Date Range
     */
    public function getLiveSummary(string $date, array $filters = []): array
    {
        $companyId = $filters['company_id'] ?? null;
        $fromDate = $filters['from_date'] ?? $date;
        $toDate = $filters['to_date'] ?? $date;
        $isRange = ($filters['date_mode'] ?? 'single') === 'range' || ($fromDate !== $toDate);
        if ($fromDate > $toDate) {
            $tmp = $fromDate;
            $fromDate = $toDate;
            $toDate = $tmp;
        }
        $skipWeekends = !in_array($filters['skip_weekends'] ?? true, [false, 0, '0', 'false'], true);
        $skipHolidays = !in_array($filters['skip_holidays'] ?? true, [false, 0, '0', 'false'], true);

        $empFields = $this->db->getFieldNames('employees');
        $selectCols = ['id', 'employee_code', 'company_id', 'branch_id', 'department_id', 'shift_id'];
        foreach (['joining_date', 'join_date', 'hire_date'] as $col) {
            if (in_array($col, $empFields, true)) {
                $selectCols[] = $col;
            }
        }

        // Fetch active employees matching criteria
        $builder = $this->db->table('employees')
            ->select(implode(', ', $selectCols))
            ->where('status', \App\Models\EmployeeModel::STATUS_ACTIVE);
        if (!empty($companyId)) $builder->where('company_id', $companyId);
        if (!empty($filters['department_id'])) $builder->where('department_id', $filters['department_id']);
        if (!empty($filters['branch_id'])) $builder->where('branch_id', $filters['branch_id']);
        if (!empty($filters['shift_id'])) $builder->where('shift_id', $filters['shift_id']);
        $activeEmployees = $builder->get()->getResultArray();
        $totalActive = count($activeEmployees);

        if (empty($activeEmployees)) {
            return [
                'total_employees'       => 0,
                'present'               => 0,
                'late'                  => 0,
                'absent'                => 0,
                'on_leave'              => 0,
                'checked_in'            => 0,
                'checked_out'           => 0,
                'early_out'             => 0,
                'overtime_employees'    => 0,
                'overtime_hours'        => 0.0,
                'total_working_hours'   => 0.0,
                'pending'               => 0,
                'test_records_count'    => 0,
                'presence_rate'         => 0.0,
                'punctuality_rate'      => 0.0
            ];
        }

        $empIds = array_column($activeEmployees, 'id');
        $empCodes = array_filter(array_column($activeEmployees, 'employee_code'));
        $allLookupIds = array_values(array_unique(array_merge($empIds, $empCodes)));

        // Range Mode Summary Calculation
        if ($isRange) {
            $startTs = strtotime($fromDate);
            $endTs = strtotime($toDate);
            if (($endTs - $startTs) / 86400 > 1095) {
                $endTs = $startTs + (1095 * 86400);
            }

            $holidaysByDate = $skipHolidays ? $this->getCompanyHolidaysInRange($fromDate, $toDate, $companyId) : [];
            $workingDates = [];
            $skippedWeekends = 0;
            $skippedHolidays = 0;

            for ($currTs = $startTs; $currTs <= $endTs; $currTs += 86400) {
                $currDate = date('Y-m-d', $currTs);
                $isWk = \App\Services\CompanyWeekendService::isWeeklyOff($currDate, $companyId);
                $isHol = !empty($holidaysByDate[$currDate]);

                if ($skipWeekends && $isWk) {
                    $skippedWeekends++;
                    continue;
                }
                if ($skipHolidays && $isHol) {
                    $skippedHolidays++;
                    continue;
                }
                $workingDates[] = $currDate;
            }

            // Total eligible employee-days (skipping days before each employee's join date)
            $totalEligibleEmployeeDays = 0;
            foreach ($activeEmployees as $emp) {
                $jDate = self::resolveEmployeeJoiningDate($emp);
                foreach ($workingDates as $wd) {
                    if (empty($jDate) || $wd >= $jDate) {
                        $totalEligibleEmployeeDays++;
                    }
                }
            }

            // Batch fetch attendance logs across range
            $logs = [];
            if (!empty($allLookupIds)) {
                $logs = $this->db->table('attendance_logs')
                    ->whereIn('employee_id', $allLookupIds)
                    ->where('date >=', $fromDate)
                    ->where('date <=', $toDate)
                    ->get()
                    ->getResultArray();
            }

            $present = 0;
            $late = 0;
            $halfDay = 0;
            $checkedIn = 0;
            $checkedOut = 0;
            $earlyOut = 0;
            $overtimeCount = 0;
            $totalOvertimeHours = 0.0;
            $totalWorkingHours = 0.0;
            $testRecordsCount = 0;

            foreach ($logs as $l) {
                $hasIn = !empty($l['check_in']);
                $hasOut = !empty($l['check_out']);
                $st = $l['status'] ?? 'Present';
                $isTest = (($l['verification_method'] ?? '') === self::SOURCE_LIVE_TEST) || (strpos($l['remarks'] ?? '', self::TEST_TAG) !== false);
                if ($isTest) $testRecordsCount++;

                if ($hasIn) $checkedIn++;
                if ($hasOut) $checkedOut++;

                if ($st === 'Present' || $st === 'Present (Early Closure)' || $st === 'Approved Early Closure' || str_starts_with($st, 'Present') || (!empty($l['closure_credit_hours']) && (float)$l['closure_credit_hours'] > 0)) $present++;
                elseif ($st === 'Late') { $late++; $present++; }
                elseif ($st === 'Half Day') { $halfDay++; $present++; }
                elseif ($st === 'Early Out' || $st === 'Late & Early Out' || $st === 'Weekend Duty Present' || $st === 'Holiday Duty Present') { $present++; }

                if (!empty($l['late_minutes']) && (int)$l['late_minutes'] > 0 && $st !== 'Late') {
                    $late++;
                }
                if (!empty($l['early_out_minutes']) && (int)$l['early_out_minutes'] > 0) {
                    $earlyOut++;
                }

                $ot = (float)($l['overtime_hours'] ?? 0);
                if ($ot > 0) {
                    $overtimeCount++;
                    $totalOvertimeHours += $ot;
                }
                $totalWorkingHours += (float)($l['working_hours'] ?? 0);
            }

            // Approved leaves in range
            $onLeave = 0;
            if ($this->db->tableExists('leave_applications') && !empty($allLookupIds)) {
                $leaveRows = $this->db->table('leave_applications')
                    ->where('status', 'Approved')
                    ->where('start_date <=', $toDate)
                    ->where('end_date >=', $fromDate)
                    ->whereIn('employee_id', $allLookupIds)
                    ->get()
                    ->getResultArray();
                foreach ($leaveRows as $lvr) {
                    $lStart = max($fromDate, $lvr['start_date'] ?? $fromDate);
                    $lEnd = min($toDate, $lvr['end_date'] ?? $toDate);
                    $curL = $lStart;
                    while ($curL <= $lEnd) {
                        if (in_array($curL, $workingDates, true)) {
                            $onLeave++;
                        }
                        $curL = date('Y-m-d', strtotime($curL . ' +1 day'));
                    }
                }
            }

            $recordedCount = $present + $onLeave;
            $absent = max(0, $totalEligibleEmployeeDays - $recordedCount);
            $pending = max(0, $totalEligibleEmployeeDays - $checkedIn - $onLeave);

            $presenceRate = $totalEligibleEmployeeDays > 0 ? round(($present / $totalEligibleEmployeeDays) * 100, 1) : 0.0;
            $punctualityRate = $present > 0 ? round((($present - $late) / $present) * 100, 1) : 0.0;

            return [
                'is_range'              => true,
                'total_employees'       => $totalActive,
                'working_days'          => count($workingDates),
                'total_employee_days'   => $totalEligibleEmployeeDays,
                'present'               => $present,
                'late'                  => $late,
                'absent'                => $absent,
                'on_leave'              => $onLeave,
                'checked_in'            => $checkedIn,
                'checked_out'           => $checkedOut,
                'early_out'             => $earlyOut,
                'overtime_employees'    => $overtimeCount,
                'overtime_hours'        => round($totalOvertimeHours, 1),
                'total_working_hours'   => round($totalWorkingHours, 1),
                'pending'               => $pending,
                'test_records_count'    => $testRecordsCount,
                'presence_rate'         => $presenceRate,
                'punctuality_rate'      => $punctualityRate,
                'skipped_weekends'      => $skippedWeekends,
                'skipped_holidays'      => $skippedHolidays
            ];
        }

        // Single Date Mode Summary Calculation
        // Only count employees active and joined ON or BEFORE $date
        $joinedActiveCount = 0;
        foreach ($activeEmployees as $emp) {
            $jDate = self::resolveEmployeeJoiningDate($emp);
            if (empty($jDate) || $jDate <= $date) {
                $joinedActiveCount++;
            }
        }

        $logs = [];
        if (!empty($allLookupIds)) {
            $logs = $this->db->table('attendance_logs')
                ->where('date', $date)
                ->whereIn('employee_id', $allLookupIds)
                ->get()
                ->getResultArray();
        }

        $present = 0;
        $late = 0;
        $halfDay = 0;
        $checkedIn = 0;
        $checkedOut = 0;
        $earlyOut = 0;
        $overtimeCount = 0;
        $totalOvertimeHours = 0.0;
        $totalWorkingHours = 0.0;
        $testRecordsCount = 0;

        foreach ($logs as $l) {
            $hasIn = !empty($l['check_in']);
            $hasOut = !empty($l['check_out']);
            $st = $l['status'] ?? 'Present';
            $isTest = (($l['verification_method'] ?? '') === self::SOURCE_LIVE_TEST) || (strpos($l['remarks'] ?? '', self::TEST_TAG) !== false);
            if ($isTest) $testRecordsCount++;

            if ($hasIn) $checkedIn++;
            if ($hasOut) $checkedOut++;

            if ($st === 'Present' || $st === 'Present (Early Closure)' || $st === 'Approved Early Closure' || str_starts_with($st, 'Present') || (!empty($l['closure_credit_hours']) && (float)$l['closure_credit_hours'] > 0)) $present++;
            elseif ($st === 'Late') { $late++; $present++; }
            elseif ($st === 'Half Day') { $halfDay++; $present++; }
            elseif ($st === 'Early Out' || $st === 'Late & Early Out' || $st === 'Weekend Duty Present' || $st === 'Holiday Duty Present') { $present++; }

            if (!empty($l['late_minutes']) && (int)$l['late_minutes'] > 0 && $st !== 'Late') {
                $late++;
            }

            if (!empty($l['early_out_minutes']) && (int)$l['early_out_minutes'] > 0) {
                $earlyOut++;
            }

            $ot = (float)($l['overtime_hours'] ?? 0);
            if ($ot > 0) {
                $overtimeCount++;
                $totalOvertimeHours += $ot;
            }
            $totalWorkingHours += (float)($l['working_hours'] ?? 0);
        }

        // Leave count on date
        $onLeave = 0;
        if ($this->db->tableExists('leave_applications') && !empty($allLookupIds)) {
            $onLeave = $this->db->table('leave_applications')
                ->where('status', 'Approved')
                ->where('start_date <=', $date)
                ->where('end_date >=', $date)
                ->whereIn('employee_id', $allLookupIds)
                ->countAllResults();
        }

        $recordedCount = $present + $onLeave;
        $absent = max(0, $joinedActiveCount - $recordedCount);
        $pending = max(0, $joinedActiveCount - $checkedIn - $onLeave);

        $presenceRate = $joinedActiveCount > 0 ? round(($present / $joinedActiveCount) * 100, 1) : 0.0;
        $punctualityRate = $present > 0 ? round((($present - $late) / $present) * 100, 1) : 0.0;

        return [
            'total_employees'       => $joinedActiveCount,
            'present'               => $present,
            'late'                  => $late,
            'absent'                => $absent,
            'on_leave'              => $onLeave,
            'checked_in'            => $checkedIn,
            'checked_out'           => $checkedOut,
            'early_out'             => $earlyOut,
            'overtime_employees'    => $overtimeCount,
            'overtime_hours'        => round($totalOvertimeHours, 1),
            'total_working_hours'   => round($totalWorkingHours, 1),
            'pending'               => $pending,
            'test_records_count'    => $testRecordsCount,
            'presence_rate'         => $presenceRate,
            'punctuality_rate'      => $punctualityRate
        ];
    }

    /**
     * Resolve Employee Canonical Joining Date with Unified Multi-Column Support
     */
    public static function resolveEmployeeJoiningDate(array $emp): ?string
    {
        $raw = !empty($emp['joining_date']) && $emp['joining_date'] !== '0000-00-00'
            ? $emp['joining_date']
            : (!empty($emp['join_date']) && $emp['join_date'] !== '0000-00-00'
                ? $emp['join_date']
                : (!empty($emp['hire_date']) && $emp['hire_date'] !== '0000-00-00'
                    ? $emp['hire_date']
                    : null));

        if (empty($raw)) {
            return null;
        }
        $sub = substr(trim((string)$raw), 0, 10);
        return preg_match('/^\d{4}-\d{2}-\d{2}$/', $sub) ? $sub : null;
    }

    /**
     * Check if a given date is a configured company holiday (supports multi-day and single-day)
     */
    public function isCompanyHoliday(string $date, ?string $companyId = null): ?array
    {
        $holidays = $this->getCompanyHolidaysInRange($date, $date, $companyId);
        return $holidays[$date] ?? null;
    }

    /**
     * Batch fetch all company holidays overlapping a date range
     */
    public function getCompanyHolidaysInRange(string $fromDate, string $toDate, ?string $companyId = null): array
    {
        if (!$this->db->tableExists('holidays')) {
            return [];
        }
        try {
            $builder = $this->db->table('holidays');
            $fields = $this->db->getFieldNames('holidays');

            $builder->groupStart();
            $hasDateClause = false;
            if (in_array('from_date', $fields, true) && in_array('to_date', $fields, true)) {
                $builder->groupStart()
                    ->where('from_date <=', $toDate)
                    ->where('to_date >=', $fromDate)
                ->groupEnd();
                $hasDateClause = true;
            }
            if (in_array('date', $fields, true)) {
                if ($hasDateClause) {
                    $builder->orGroupStart()
                        ->where('date >=', $fromDate)
                        ->where('date <=', $toDate)
                    ->groupEnd();
                } else {
                    $builder->where('date >=', $fromDate)->where('date <=', $toDate);
                    $hasDateClause = true;
                }
            }
            if (in_array('from_date', $fields, true)) {
                $builder->orGroupStart()
                    ->where('from_date >=', $fromDate)
                    ->where('from_date <=', $toDate)
                ->groupEnd();
            }
            $builder->groupEnd();

            if (!$hasDateClause) {
                return [];
            }

            if ($companyId && in_array('company_id', $fields, true)) {
                $builder->groupStart()
                    ->where('company_id', $companyId)
                    ->orWhere('company_id IS NULL')
                    ->orWhere('company_id', '')
                ->groupEnd();
            }

            if (in_array('status', $fields, true)) {
                $builder->whereNotIn('status', ['Cancelled', 'cancelled', 'Inactive', 'inactive']);
            }

            $rows = $builder->get()->getResultArray();
            $holidaysByDate = [];
            foreach ($rows as $r) {
                $hName = $r['name'] ?? $r['title'] ?? 'Company Holiday';
                $from = !empty($r['from_date']) ? $r['from_date'] : ($r['date'] ?? null);
                $to = !empty($r['to_date']) ? $r['to_date'] : ($r['date'] ?? $from);
                if ($from && $to) {
                    $cur = $from;
                    while ($cur <= $to) {
                        if ($cur >= $fromDate && $cur <= $toDate) {
                            $holidaysByDate[$cur] = [
                                'id'   => $r['id'] ?? '',
                                'name' => $hName,
                                'date' => $cur
                            ];
                        }
                        $cur = date('Y-m-d', strtotime($cur . ' +1 day'));
                    }
                } elseif (!empty($r['date']) && $r['date'] >= $fromDate && $r['date'] <= $toDate) {
                    $holidaysByDate[$r['date']] = [
                        'id'   => $r['id'] ?? '',
                        'name' => $hName,
                        'date' => $r['date']
                    ];
                }
            }
            return $holidaysByDate;
        } catch (\Throwable $e) {
            return [];
        }
    }
}
