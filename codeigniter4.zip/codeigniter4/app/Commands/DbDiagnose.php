<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use Config\Database;

/**
 * Diagnostic tool to inspect database schema, tables, columns,
 * duplicate roles/permissions, and foreign key constraints before running seeds.
 */
class DbDiagnose extends BaseCommand
{
    protected $group       = 'Database';
    protected $name        = 'db:diagnose';
    protected $description = 'Inspects database schema, identifies missing columns, duplicate roles/permissions, and foreign key constraint issues prior to seeding.';
    protected $usage       = 'db:diagnose [options]';
    protected $arguments   = [];
    protected $options     = [
        '--fix'     => 'Automatically attempts to resolve safe schema discrepancies like missing employment_types columns and duplicate permissions.',
        '--verbose' => 'Shows comprehensive column and constraint details for all inspected tables.',
        '--json'    => 'Outputs results in pure JSON format for API integration.',
    ];

    public function run(array $params)
    {
        $fixMode = array_key_exists('fix', $params) || CLI::getOption('fix');
        $verbose = array_key_exists('verbose', $params) || CLI::getOption('verbose');
        $jsonMode = array_key_exists('json', $params) || CLI::getOption('json');

        $db = Database::connect();

        if (!$jsonMode) {
            CLI::write("================================================================", 'cyan');
            CLI::write("   ENTERPRISE HRMS - DATABASE & SEED PRE-FLIGHT DIAGNOSTIC     ", 'yellow');
            CLI::write("================================================================", 'cyan');
            CLI::write("Database Driver : " . $db->DBDriver . " | Database: " . $db->database, 'white');
            CLI::write("Timestamp       : " . date('Y-m-d H:i:s T'), 'white');
            CLI::newLine();
        }

        $results = [
            'status' => 'OK',
            'errors_count' => 0,
            'warnings_count' => 0,
            'checks' => [],
            'table_columns' => [],
            'duplicate_roles' => [],
            'duplicate_permissions' => [],
            'orphan_foreign_keys' => [],
            'recommendations' => [],
            'applied_fixes' => [],
        ];

        // 1. Table Existence Check
        $expectedTables = [
            'companies', 'branches', 'departments', 'designations',
            'employment_types', 'shifts', 'roles', 'permissions',
            'role_permissions', 'employees', 'users', 'leave_types',
            'leave_balances', 'attendances', 'payrolls', 'notices',
            'notifications', 'audit_logs', 'system_settings'
        ];

        $existingTables = $db->listTables();
        $missingTables = array_diff($expectedTables, $existingTables);

        if (!empty($missingTables)) {
            $results['errors_count'] += count($missingTables);
            $results['status'] = 'FAIL';
            $results['checks']['missing_tables'] = $missingTables;
            if (!$jsonMode) {
                CLI::error("[FAIL] Missing Required Tables: " . implode(', ', $missingTables));
            }
        } else {
            $results['checks']['missing_tables'] = [];
            if (!$jsonMode) {
                CLI::write("[PASS] All core required tables exist (" . count($expectedTables) . " checked).", 'green');
            }
        }

        // 2. Critical Columns Inspection (Specifically employment_types & employees)
        $columnRequirements = [
            'employment_types' => [
                'required' => ['id', 'name', 'code', 'status'],
                'optional' => ['company_id', 'description', 'created_at', 'updated_at'],
                'recommend_for_seeder' => ['company_id', 'description']
            ],
            'employees' => [
                'required' => [
                    'id', 'employee_code', 'company_id', 'branch_id', 'department_id',
                    'designation_id', 'employment_type_id', 'shift_id', 'first_name',
                    'last_name', 'official_email', 'status'
                ],
                'optional' => ['gender', 'dob', 'personal_email', 'phone', 'joining_date', 'basic_salary', 'created_at', 'updated_at'],
                'recommend_for_seeder' => ['id', 'company_id', 'branch_id', 'department_id', 'designation_id', 'employment_type_id', 'shift_id']
            ],
            'departments' => [
                'required' => ['id', 'name', 'code', 'status'],
                'optional' => ['company_id', 'branch_id', 'description', 'created_at', 'updated_at'],
                'recommend_for_seeder' => ['company_id', 'branch_id', 'code']
            ],
            'designations' => [
                'required' => ['id', 'name', 'code', 'status'],
                'optional' => ['department_id', 'grade', 'created_at', 'updated_at'],
                'recommend_for_seeder' => ['department_id', 'code']
            ],
            'roles' => [
                'required' => ['id', 'name', 'code', 'status'],
                'optional' => ['description', 'is_system', 'created_at', 'updated_at'],
                'recommend_for_seeder' => ['code', 'name']
            ],
            'permissions' => [
                'required' => ['id', 'name', 'code', 'module'],
                'optional' => ['description', 'created_at', 'updated_at'],
                'recommend_for_seeder' => ['code', 'module']
            ],
            'role_permissions' => [
                'required' => ['id', 'role_id', 'permission_id'],
                'optional' => ['created_at'],
                'recommend_for_seeder' => ['role_id', 'permission_id']
            ],
            'users' => [
                'required' => ['id', 'username', 'email', 'password_hash', 'role_id', 'status'],
                'optional' => ['employee_id', 'company_id', 'branch_id', 'department_id', 'created_at', 'updated_at'],
                'recommend_for_seeder' => ['role_id', 'employee_id']
            ],
            'leave_types' => [
                'required' => ['id', 'name', 'code', 'days_per_year', 'status'],
                'optional' => ['company_id', 'is_paid', 'allow_carry_forward', 'created_at', 'updated_at'],
                'recommend_for_seeder' => ['code', 'name']
            ],
            'leave_balances' => [
                'required' => ['id', 'employee_id', 'leave_type_id', 'year'],
                'optional' => ['entitled_days', 'allocated_days', 'taken_days', 'used_days', 'carried_over', 'carried_forward_days', 'pending_days', 'created_at', 'updated_at'],
                'recommend_for_seeder' => ['employee_id', 'leave_type_id', 'year']
            ],
            'attendances' => [
                'required' => ['id', 'employee_id', 'date'],
                'optional' => ['company_id', 'branch_id', 'shift_id', 'clock_in', 'clock_out', 'total_hours', 'overtime_hours', 'status', 'is_late', 'created_at', 'updated_at'],
                'recommend_for_seeder' => ['employee_id', 'date', 'status']
            ],
            'payrolls' => [
                'required' => ['id', 'employee_id', 'month', 'year', 'basic_salary', 'net_salary'],
                'optional' => ['company_id', 'batch_id', 'house_rent', 'medical_allowance', 'conveyance_allowance', 'overtime_amount', 'bonus', 'gross_salary', 'tax_deduction', 'provident_fund', 'total_deductions', 'status', 'is_locked', 'payment_date', 'payment_method', 'created_at', 'updated_at'],
                'recommend_for_seeder' => ['employee_id', 'month', 'year', 'basic_salary', 'net_salary']
            ],
            'system_settings' => [
                'required' => ['setting_key'],
                'optional' => ['id', 'company_id', 'setting_value', 'description', 'group_name', 'created_at', 'updated_at'],
                'recommend_for_seeder' => ['company_id', 'group_name']
            ]
        ];

        if (!$jsonMode) {
            CLI::newLine();
            CLI::write("--- [1] Table Schema & Missing Column Verification ---", 'cyan');
        }

        foreach ($columnRequirements as $tableName => $spec) {
            if (!in_array($tableName, $existingTables)) {
                continue;
            }

            $fields = $db->getFieldNames($tableName);
            $results['table_columns'][$tableName] = $fields;

            $missingReq = array_diff($spec['required'], $fields);
            $missingOpt = array_diff($spec['recommend_for_seeder'], $fields);

            if (!empty($missingReq)) {
                $results['errors_count'] += count($missingReq);
                $results['status'] = 'FAIL';
                if (!$jsonMode) {
                    CLI::error("  [FAIL] `{$tableName}` is MISSING required columns: " . implode(', ', $missingReq));
                }
                $results['recommendations'][] = "ALTER TABLE `{$tableName}` ADD missing required columns: " . implode(', ', $missingReq);
            }

            if (!empty($missingOpt)) {
                $results['warnings_count'] += count($missingOpt);
                if (!$jsonMode) {
                    CLI::write("  [WARN] `{$tableName}` is missing recommended seeder column(s): " . implode(', ', $missingOpt), 'yellow');
                }
                
                // Specific suggestion for employment_types missing company_id or extended attributes
                if ($tableName === 'employment_types') {
                    $fixSql = "ALTER TABLE `employment_types` ADD COLUMN `company_id` VARCHAR(36) NULL AFTER `id`, ADD COLUMN `description` TEXT NULL AFTER `code`, ADD COLUMN `overtime_eligibility` VARCHAR(50) DEFAULT 'Yes' NULL AFTER `description`, ADD COLUMN `benefits_eligibility` VARCHAR(255) NULL AFTER `overtime_eligibility`, ADD COLUMN `payroll_rule` VARCHAR(255) NULL AFTER `benefits_eligibility`;";
                    $results['recommendations'][] = $fixSql;
                    
                    if ($fixMode) {
                        try {
                            if (!$db->fieldExists('company_id', 'employment_types')) {
                                $db->query("ALTER TABLE `employment_types` ADD COLUMN `company_id` VARCHAR(36) NULL AFTER `id`");
                            }
                            if (!$db->fieldExists('description', 'employment_types')) {
                                $db->query("ALTER TABLE `employment_types` ADD COLUMN `description` TEXT NULL AFTER `code`");
                            }
                            if (!$db->fieldExists('overtime_eligibility', 'employment_types')) {
                                $db->query("ALTER TABLE `employment_types` ADD COLUMN `overtime_eligibility` VARCHAR(50) DEFAULT 'Yes' NULL AFTER `description`");
                            }
                            if (!$db->fieldExists('benefits_eligibility', 'employment_types')) {
                                $db->query("ALTER TABLE `employment_types` ADD COLUMN `benefits_eligibility` VARCHAR(255) NULL AFTER `overtime_eligibility`");
                            }
                            if (!$db->fieldExists('payroll_rule', 'employment_types')) {
                                $db->query("ALTER TABLE `employment_types` ADD COLUMN `payroll_rule` VARCHAR(255) NULL AFTER `benefits_eligibility`");
                            }
                            $results['applied_fixes'][] = "Added extended columns (company_id, description, overtime_eligibility, benefits_eligibility, payroll_rule) to `employment_types` table.";
                            if (!$jsonMode) {
                                CLI::write("  [AUTO-FIXED] Enhanced `employment_types` schema with extended columns.", 'green');
                            }
                        } catch (\Exception $e) {
                            if (!$jsonMode) {
                                CLI::error("  [AUTO-FIX FAILED] " . $e->getMessage());
                            }
                        }
                    }
                }

                // Specific suggestion for system_settings missing company_id
                if ($tableName === 'system_settings' && in_array('company_id', $missingOpt)) {
                    $fixSql = "ALTER TABLE `system_settings` ADD COLUMN `company_id` VARCHAR(36) NULL AFTER `id`, ADD COLUMN `description` TEXT NULL, ADD COLUMN `group_name` VARCHAR(50) DEFAULT 'general' NULL;";
                    $results['recommendations'][] = $fixSql;
                    
                    if ($fixMode) {
                        try {
                            if (!$db->fieldExists('company_id', 'system_settings')) {
                                $db->query("ALTER TABLE `system_settings` ADD COLUMN `company_id` VARCHAR(36) NULL AFTER `id`");
                            }
                            if (!$db->fieldExists('description', 'system_settings')) {
                                $db->query("ALTER TABLE `system_settings` ADD COLUMN `description` TEXT NULL");
                            }
                            if (!$db->fieldExists('group_name', 'system_settings')) {
                                $db->query("ALTER TABLE `system_settings` ADD COLUMN `group_name` VARCHAR(50) DEFAULT 'general' NULL");
                            }
                            $results['applied_fixes'][] = "Added `company_id`, `description`, and `group_name` to `system_settings` table.";
                            if (!$jsonMode) {
                                CLI::write("  [AUTO-FIXED] Added `company_id`, `description`, and `group_name` columns to `system_settings`.", 'green');
                            }
                        } catch (\Exception $e) {
                            if (!$jsonMode) {
                                CLI::error("  [AUTO-FIX FAILED] " . $e->getMessage());
                            }
                        }
                    }
                }
            }

            if ($tableName === 'employees') {
                $hasEmail = in_array('email', $fields);
                $hasOfficial = in_array('official_email', $fields);
                
                // Check for empty string email entries that conflict with unique indexes
                if ($hasEmail) {
                    $blankEmails = $db->query("SELECT COUNT(*) as cnt FROM `employees` WHERE `email` = ''")->getRow()?->cnt ?? 0;
                    if ($blankEmails > 1) {
                        $results['warnings_count']++;
                        if (!$jsonMode) {
                            CLI::write("  [WARN] `employees` table has {$blankEmails} records with blank email string ('' which triggers UNIQUE KEY collision).", 'yellow');
                        }
                        $results['recommendations'][] = "UPDATE `employees` SET `email` = CONCAT('emp_', id, '@hrms.local') WHERE `email` = '';";
                        
                        if ($fixMode) {
                            try {
                                $db->query("UPDATE `employees` SET `email` = CONCAT('emp_', id, '@hrms.local') WHERE `email` = ''");
                                $results['applied_fixes'][] = "Cleaned duplicate blank email records in `employees` table.";
                                if (!$jsonMode) {
                                    CLI::write("  [AUTO-FIXED] Fixed {$blankEmails} blank email entries in `employees`.", 'green');
                                }
                            } catch (\Exception $e) {
                                if (!$jsonMode) {
                                    CLI::error("  [AUTO-FIX FAILED] " . $e->getMessage());
                                }
                            }
                        }
                    }
                }
            }

            if (empty($missingReq) && empty($missingOpt)) {
                if (!$jsonMode && $verbose) {
                    CLI::write("  [PASS] `{$tableName}` has all " . count($fields) . " expected columns.", 'green');
                }
            }
        }

        // 3. Duplicate Roles and Permissions Verification
        if (!$jsonMode) {
            CLI::newLine();
            CLI::write("--- [2] Duplicate Roles & Permissions Conflict Check ---", 'cyan');
        }

        // Duplicate Roles
        if (in_array('roles', $existingTables)) {
            $duplicateRoleCodes = $db->query("
                SELECT code, COUNT(*) as cnt, GROUP_CONCAT(id SEPARATOR ', ') as ids, GROUP_CONCAT(name SEPARATOR ', ') as names
                FROM `roles`
                GROUP BY code
                HAVING cnt > 1
            ")->getResultArray();

            if (!empty($duplicateRoleCodes)) {
                $results['warnings_count'] += count($duplicateRoleCodes);
                $results['duplicate_roles'] = $duplicateRoleCodes;
                if (!$jsonMode) {
                    CLI::error("  [CONFLICT] Duplicate Role Codes detected in `roles` table:");
                    foreach ($duplicateRoleCodes as $dup) {
                        CLI::write("    - Code '{$dup['code']}' occurs {$dup['cnt']} times (IDs: {$dup['ids']})", 'red');
                    }
                }
                $results['recommendations'][] = "Deduplicate `roles` rows with identical `code` values before seeding.";
            } else {
                if (!$jsonMode) {
                    CLI::write("  [PASS] No duplicate role codes detected in `roles`.", 'green');
                }
            }
        }

        // Duplicate Permissions
        if (in_array('permissions', $existingTables)) {
            $duplicatePermCodes = $db->query("
                SELECT code, COUNT(*) as cnt, GROUP_CONCAT(id SEPARATOR ', ') as ids, GROUP_CONCAT(name SEPARATOR ', ') as names
                FROM `permissions`
                GROUP BY code
                HAVING cnt > 1
            ")->getResultArray();

            if (!empty($duplicatePermCodes)) {
                $results['warnings_count'] += count($duplicatePermCodes);
                $results['duplicate_permissions'] = $duplicatePermCodes;
                if (!$jsonMode) {
                    CLI::error("  [CONFLICT] Duplicate Permission Codes detected in `permissions` table:");
                    foreach ($duplicatePermCodes as $dup) {
                        CLI::write("    - Code '{$dup['code']}' occurs {$dup['cnt']} times (IDs: {$dup['ids']})", 'red');
                    }
                }
                $results['recommendations'][] = "Remove duplicate permission records to ensure unique code constraints.";

                if ($fixMode) {
                    try {
                        // Deduplicate keeping the first ID
                        foreach ($duplicatePermCodes as $dup) {
                            $idList = explode(', ', $dup['ids']);
                            $keepId = array_shift($idList);
                            if (!empty($idList)) {
                                foreach ($idList as $remId) {
                                    $remId = trim($remId);
                                    // Update any role_permissions to keepId first
                                    $db->table('role_permissions')->where('permission_id', $remId)->update(['permission_id' => $keepId]);
                                    // Delete duplicate permission
                                    $db->table('permissions')->where('id', $remId)->delete();
                                }
                            }
                        }
                        $results['applied_fixes'][] = "Cleaned and merged duplicate permissions in `permissions` table.";
                        if (!$jsonMode) {
                            CLI::write("  [AUTO-FIXED] Merged duplicate permissions and updated role_permissions links.", 'green');
                        }
                    } catch (\Exception $e) {
                        if (!$jsonMode) {
                            CLI::error("  [AUTO-FIX FAILED] " . $e->getMessage());
                        }
                    }
                }
            } else {
                if (!$jsonMode) {
                    CLI::write("  [PASS] No duplicate permission codes detected in `permissions`.", 'green');
                }
            }
        }

        // Duplicate Role-Permission Mappings
        if (in_array('role_permissions', $existingTables)) {
            $dupRolePerms = $db->query("
                SELECT role_id, permission_id, COUNT(*) as cnt
                FROM `role_permissions`
                GROUP BY role_id, permission_id
                HAVING cnt > 1
            ")->getResultArray();

            if (!empty($dupRolePerms)) {
                $results['warnings_count'] += count($dupRolePerms);
                if (!$jsonMode) {
                    CLI::write("  [WARN] Found " . count($dupRolePerms) . " redundant duplicate role-permission mappings.", 'yellow');
                }
            } else {
                if (!$jsonMode) {
                    CLI::write("  [PASS] Role-permission pivot table is clean without duplicates.", 'green');
                }
            }
        }

        // 4. Foreign Key Constraints & Dangling Reference Checks
        if (!$jsonMode) {
            CLI::newLine();
            CLI::write("--- [3] Referential Integrity & Foreign Key Inspection ---", 'cyan');
        }

        $foreignKeyChecks = [
            [
                'name' => 'employees -> designations',
                'parent' => 'designations',
                'parent_col' => 'id',
                'child' => 'employees',
                'child_col' => 'designation_id',
            ],
            [
                'name' => 'employees -> departments',
                'parent' => 'departments',
                'parent_col' => 'id',
                'child' => 'employees',
                'child_col' => 'department_id',
            ],
            [
                'name' => 'employees -> companies',
                'parent' => 'companies',
                'parent_col' => 'id',
                'child' => 'employees',
                'child_col' => 'company_id',
            ],
            [
                'name' => 'employees -> employment_types',
                'parent' => 'employment_types',
                'parent_col' => 'id',
                'child' => 'employees',
                'child_col' => 'employment_type_id',
            ],
            [
                'name' => 'employees -> shifts',
                'parent' => 'shifts',
                'parent_col' => 'id',
                'child' => 'employees',
                'child_col' => 'shift_id',
            ],
            [
                'name' => 'users -> roles',
                'parent' => 'roles',
                'parent_col' => 'id',
                'child' => 'users',
                'child_col' => 'role_id',
            ],
            [
                'name' => 'designations -> departments',
                'parent' => 'departments',
                'parent_col' => 'id',
                'child' => 'designations',
                'child_col' => 'department_id',
            ]
        ];

        foreach ($foreignKeyChecks as $chk) {
            if (!in_array($chk['parent'], $existingTables) || !in_array($chk['child'], $existingTables)) {
                continue;
            }

            if (!$db->fieldExists($chk['child_col'], $chk['child']) || !$db->fieldExists($chk['parent_col'], $chk['parent'])) {
                continue;
            }

            $sql = "
                SELECT c.id as child_id, c.{$chk['child_col']} as referenced_val
                FROM `{$chk['child']}` c
                LEFT JOIN `{$chk['parent']}` p ON c.{$chk['child_col']} = p.{$chk['parent_col']}
                WHERE c.{$chk['child_col']} IS NOT NULL 
                  AND c.{$chk['child_col']} != '' 
                  AND p.{$chk['parent_col']} IS NULL
                LIMIT 10
            ";

            try {
                $orphans = $db->query($sql)->getResultArray();
                if (!empty($orphans)) {
                    $results['errors_count'] += count($orphans);
                    $results['orphan_foreign_keys'][] = [
                        'relation' => $chk['name'],
                        'child_table' => $chk['child'],
                        'parent_table' => $chk['parent'],
                        'orphans' => $orphans
                    ];

                    if (!$jsonMode) {
                        CLI::error("  [ORPHAN FK] Relation `{$chk['name']}` has broken references:");
                        foreach ($orphans as $orphan) {
                            CLI::write("    - Record ID '{$orphan['child_id']}' references non-existent {$chk['parent']}.{$chk['parent_col']} = '{$orphan['referenced_val']}'", 'red');
                        }
                    }
                    $results['recommendations'][] = "Fix orphaned `{$chk['child']}.{$chk['child_col']}` values referencing missing `{$chk['parent']}` rows.";
                } else {
                    if (!$jsonMode && $verbose) {
                        CLI::write("  [PASS] Integrity verified for `{$chk['name']}`.", 'green');
                    }
                }
            } catch (\Exception $e) {
                // Table might be empty or query failed
            }
        }

        // 5. Seed Pre-flight Summary
        if (!$jsonMode) {
            CLI::newLine();
            CLI::write("================================================================", 'cyan');
            CLI::write("                    DIAGNOSTIC SUMMARY                          ", 'yellow');
            CLI::write("================================================================", 'cyan');

            if ($results['errors_count'] === 0 && $results['warnings_count'] === 0) {
                CLI::write(" STATUS: [PERFECT] Database schema & constraints are 100% seed-ready!", 'green');
            } elseif ($results['errors_count'] === 0) {
                CLI::write(" STATUS: [READY WITH WARNINGS] Database can be seeded safely.", 'yellow');
            } else {
                CLI::write(" STATUS: [ACTION REQUIRED] Please resolve errors before running DatabaseSeeder.", 'red');
            }

            CLI::write(" Total Errors   : " . $results['errors_count'], $results['errors_count'] > 0 ? 'red' : 'green');
            CLI::write(" Total Warnings : " . $results['warnings_count'], $results['warnings_count'] > 0 ? 'yellow' : 'green');

            if (!empty($results['applied_fixes'])) {
                CLI::newLine();
                CLI::write("--- Applied Auto-Fixes ---", 'green');
                foreach ($results['applied_fixes'] as $fix) {
                    CLI::write("  + {$fix}", 'green');
                }
            }

            if (!empty($results['recommendations'])) {
                CLI::newLine();
                CLI::write("--- Recommended Corrective SQL / Actions ---", 'yellow');
                foreach ($results['recommendations'] as $rec) {
                    CLI::write("  > {$rec}", 'white');
                }
            }

            CLI::newLine();
            CLI::write("To re-run with automated fixes: php spark db:diagnose --fix", 'cyan');
            CLI::write("To execute seeders:            php spark db:seed DatabaseSeeder", 'cyan');
            CLI::newLine();
        } else {
            echo json_encode($results, JSON_PRETTY_PRINT);
        }

        return $results['errors_count'] === 0 ? 0 : 1;
    }
}
