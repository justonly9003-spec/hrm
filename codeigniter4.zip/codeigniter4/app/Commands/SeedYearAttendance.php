<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;

class SeedYearAttendance extends BaseCommand
{
    protected $group       = 'HRMS Database';
    protected $name        = 'attendance:seed-year';
    protected $description = 'Generates full 1-2 years of rich historical attendance data with check-in/out for all employees.';
    protected $usage       = 'attendance:seed-year [--days <number>] [--from <YYYY-MM-DD>] [--wipe]';
    protected $arguments   = [];
    protected $options     = [
        '--days' => 'Number of days to generate back from today.',
        '--from' => 'Specific start date (default: 2024-01-01 to cover 2024, 2025, 2026).',
        '--wipe' => 'Wipe existing attendance records before generation.',
    ];

    public function run(array $params)
    {
        $isProduction = (defined('ENVIRONMENT') && strtolower(ENVIRONMENT) === 'production')
            || strtolower((string)env('CI_ENVIRONMENT')) === 'production'
            || strtolower((string)getenv('CI_ENVIRONMENT')) === 'production';

        if ($isProduction) {
            CLI::error('Security Violation: attendance:seed-year cannot be executed in production environment.');
            return;
        }

        CLI::write("================================================================", 'cyan');
        CLI::write("    ENTERPRISE HRMS - ATTENDANCE & CHECK-IN/OUT GENERATOR ENGINE", 'white', 'blue');
        CLI::write("================================================================", 'cyan');

        $daysOption = $params['days'] ?? CLI::getOption('days');
        $fromOption = $params['from'] ?? CLI::getOption('from');
        $wipe = (bool)($params['wipe'] ?? CLI::getOption('wipe') ?? false);

        $db = \Config\Database::connect();
        $today = date('Y-m-d');

        if (!empty($fromOption)) {
            $startDate = $fromOption;
        } elseif (!empty($daysOption)) {
            $days = (int)$daysOption;
            $startDate = date('Y-m-d', strtotime("-{$days} days"));
        } else {
            $startDate = '2024-01-01';
        }

        CLI::write("Target Period : {$startDate} to {$today}");

        $hasAttendancesTable = $db->tableExists('attendances');
        $hasLogsTable = $db->tableExists('attendance_logs');

        if (!$hasAttendancesTable && !$hasLogsTable) {
            CLI::error("[ERROR] Neither `attendances` nor `attendance_logs` tables exist in database.");
            return;
        }

        if ($wipe) {
            CLI::write("Wiping previous attendance records in range...", 'yellow');
            if ($hasAttendancesTable) {
                $db->table('attendances')->where('date >=', $startDate)->delete();
            }
            if ($hasLogsTable) {
                $db->table('attendance_logs')->where('date >=', $startDate)->delete();
            }
            CLI::write("Wipe complete.", 'green');
        }

        // Initialize Seeder with Config\Database
        $config = new \Config\Database();
        $seeder = new \App\Database\Seeds\YearAttendanceSeeder($config);
        $seeder->startDate = $startDate;
        $seeder->totalDays = null;
        $seeder->run();

        // Get counts
        $attCount = $hasAttendancesTable ? $db->table('attendances')->where('date >=', $startDate)->countAllResults() : 0;
        $logCount = $hasLogsTable ? $db->table('attendance_logs')->where('date >=', $startDate)->countAllResults() : 0;

        CLI::newLine();
        CLI::write("================================================================", 'green');
        CLI::write(" SUCCESS: Attendance History & Check-In/Out Seeded Successfully!", 'black', 'green');
        CLI::write("================================================================", 'green');
        if ($hasAttendancesTable) {
            CLI::write(" `attendances` table records: {$attCount}", 'white');
        }
        if ($hasLogsTable) {
            CLI::write(" `attendance_logs` table records: {$logCount}", 'white');
        }
        CLI::write(" Period Covered: {$startDate} to {$today} (All 2024, 2025, 2026 dates included)", 'cyan');
        CLI::newLine();
    }
}
