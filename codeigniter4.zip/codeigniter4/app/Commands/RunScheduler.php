<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Services\Automation\ScheduledJobsService;

class RunScheduler extends BaseCommand
{
    protected $group       = 'Automation';
    protected $name        = 'cron:scheduler';
    protected $description = 'Runs scheduled jobs: attendance processing, leave accruals, payroll pipeline, and celebration alerts. Crontab: * * * * * cd /path/to/codeigniter4 && php spark cron:scheduler >> /dev/null 2>&1';
    protected $usage       = 'cron:scheduler [--daily|--weekly|--monthly|--all|--force]';
    protected $options     = [
        '--daily'   => 'Force trigger daily jobs (attendance, leave accruals, celebration alerts)',
        '--weekly'  => 'Force trigger weekly jobs (worked hours, OT reconciliation, bonus grants)',
        '--monthly' => 'Force trigger monthly payroll & leave rollover pipeline',
        '--all'     => 'Run all automation suites in sequence',
    ];

    public function run(array $params)
    {
        $service = new ScheduledJobsService();
        $currentTime = date('H:i');
        $currentDay = (int)date('w'); // 0 = Sunday
        $currentDate = (int)date('j'); // 1 to 31

        $runAll     = CLI::getOption('all') !== null;
        $runDaily   = $runAll || CLI::getOption('daily') !== null || CLI::getOption('force-daily') !== null;
        $runWeekly  = $runAll || CLI::getOption('weekly') !== null || CLI::getOption('force-weekly') !== null;
        $runMonthly = $runAll || CLI::getOption('monthly') !== null || CLI::getOption('force-monthly') !== null;

        // Auto schedule triggers if no specific flag passed
        if (!$runAll && !$runDaily && !$runWeekly && !$runMonthly) {
            // Daily check (23:00 - 23:59 or end of day)
            if ($currentTime >= '23:00' && $currentTime <= '23:15') {
                $runDaily = true;
            }
            // Weekly check (Sunday 02:00)
            if ($currentDay === 0 && $currentTime >= '02:00' && $currentTime <= '02:15') {
                $runWeekly = true;
            }
            // Monthly check (28th of month 01:00)
            if ($currentDate === 28 && $currentTime >= '01:00' && $currentTime <= '01:15') {
                $runMonthly = true;
            }

            // If still nothing and run without flags, run daily tasks by default
            if (!$runDaily && !$runWeekly && !$runMonthly) {
                $runDaily = true;
            }
        }

        CLI::write("[" . date('Y-m-d H:i:s') . "] 🚀 Evaluating Enterprise HRMS Automation Scheduler...", 'cyan');

        if ($runDaily) {
            CLI::write("-> 🕒 Executing Daily Automation Suite (Attendance, Leave Sync, Celebrations)...", 'yellow');
            $res = $service->runDailyJobs('CRON_CLI_TRIGGER');
            CLI::write("-> ✅ Daily Suite completed in {$res['duration_ms']}ms", 'green');
        }

        if ($runWeekly) {
            CLI::write("-> 🕒 Executing Weekly Automation Suite (Hours, Overtime, Incentives)...", 'yellow');
            $res = $service->runWeeklyJobs('CRON_CLI_TRIGGER');
            CLI::write("-> ✅ Weekly Suite completed in {$res['duration_ms']}ms", 'green');
        }

        if ($runMonthly) {
            CLI::write("-> 🕒 Executing Monthly Payroll & Leave Rollover Pipeline...", 'yellow');
            $res = $service->runMonthlyPipeline(date('Y-m'), 'COMP-01');
            CLI::write("-> ✅ Monthly Pipeline completed in {$res['duration_ms']}ms", 'green');
        }

        CLI::write("[" . date('Y-m-d H:i:s') . "] ✨ Scheduler cycle finished successfully.", 'white');
    }
}
