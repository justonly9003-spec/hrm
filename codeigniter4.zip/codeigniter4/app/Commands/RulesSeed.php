<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Models\CompanyModel;
use App\Services\Rules\RuleSeeder;

class RulesSeed extends BaseCommand
{
    protected $group       = 'Rules';
    protected $name        = 'rules:seed';
    protected $description = 'Seeds complete Company-scope business rules for companies with idempotent preservation.';
    protected $usage       = 'rules:seed [company_id|--all]';
    protected $arguments   = [
        'company_id' => 'The ID or code of the company to seed (e.g. COMP-APEX or comp-001).',
    ];
    protected $options     = [
        '--all'       => 'Seed complete Company-scope default rules for all registered companies.',
        '--seed-date' => 'Effective start date (YYYY-MM-DD) for seeded rules (defaults to company created_at or today).',
    ];

    public function run(array $params)
    {
        CLI::write("================================================================", 'cyan');
        CLI::write("           BUSINESS RULES DEFAULT SEEDER UTILITY                ", 'white', 'blue');
        CLI::write("================================================================", 'cyan');

        $companyModel = new CompanyModel();

        $targetId = $params[0] ?? null;
        $allFlag  = CLI::getOption('all');
        $cliSeedDate = CLI::getOption('seed-date');

        $companiesToProcess = [];

        if ($allFlag || $targetId === '--all') {
            $companiesToProcess = $companyModel->findAll();
        } elseif (!empty($targetId)) {
            $comp = $companyModel->find($targetId) ?: $companyModel->where('code', $targetId)->first();
            if (!$comp) {
                CLI::error("Company not found with ID or code: '{$targetId}'");
                return;
            }
            $companiesToProcess[] = $comp;
        } else {
            CLI::error("Please specify a company_id or pass --all flag.");
            CLI::write("Usage: php spark {$this->usage}", 'yellow');
            return;
        }

        if (empty($companiesToProcess)) {
            CLI::write("No companies found to process.", 'yellow');
            return;
        }

        CLI::write("Found " . count($companiesToProcess) . " company tenant(s) to process.");
        CLI::newLine();

        $totalSeededCount = 0;
        $allNeedsConfirmation = [];

        foreach ($companiesToProcess as $comp) {
            $cId   = $comp['id'];
            $cName = $comp['name'] ?? 'N/A';
            $cCode = $comp['code'] ?? 'N/A';

            CLI::write("----------------------------------------------------------------", 'dark_gray');
            CLI::write("Processing: {$cName} [ID: {$cId}, Code: {$cCode}]", 'yellow');

            try {
                $seedDate = !empty($cliSeedDate)
                    ? (string)$cliSeedDate
                    : (!empty($comp['created_at']) ? substr((string)$comp['created_at'], 0, 10) : date('Y-m-d'));
                $result = RuleSeeder::seedCompany($cId, null, $seedDate);

                $seeded = $result['seeded_domains'];
                $skipped = $result['skipped_domains'];
                $needsConfirm = $result['needs_confirmation'];

                $totalSeededCount += count($seeded);

                if (!empty($seeded)) {
                    CLI::write("✓ Newly seeded domains (" . count($seeded) . "): " . implode(', ', $seeded), 'green');
                } else {
                    CLI::write("• No new domains seeded (all " . count($skipped) . " domains already have active Company rules).", 'white');
                }

                if (!empty($skipped)) {
                    CLI::write("• Skipped existing active domains (" . count($skipped) . "): " . implode(', ', $skipped), 'dark_gray');
                }

                if (!empty($needsConfirm)) {
                    foreach ($needsConfirm as $nc) {
                        $allNeedsConfirmation[] = array_merge(['company_name' => $cName, 'company_id' => $cId], $nc);
                    }
                }
            } catch (\Throwable $e) {
                CLI::error("✗ Failed for company '{$cName}': " . $e->getMessage());
            }
        }

        CLI::newLine();

        // Print "NEEDS HR CONFIRMATION" report if any parameters carried confirm:true
        if (!empty($allNeedsConfirmation)) {
            CLI::write("================================================================", 'yellow');
            CLI::write("                 NEEDS HR CONFIRMATION                          ", 'black', 'yellow');
            CLI::write("================================================================", 'yellow');
            CLI::write("The following seeded parameters carry legal/statutory implications and require explicit HR review and sign-off:", 'white');
            CLI::newLine();

            $thead = ['Company', 'Domain', 'Parameter Key', 'Label', 'Seeded Value'];
            $tbody = [];

            foreach ($allNeedsConfirmation as $item) {
                $valStr = is_array($item['value'])
                    ? json_encode($item['value'])
                    : (is_bool($item['value']) ? ($item['value'] ? 'true' : 'false') : (string)($item['value'] ?? 'null'));

                $tbody[] = [
                    $item['company_name'],
                    $item['domain'],
                    $item['key'],
                    $item['label'],
                    $valStr,
                ];
            }

            CLI::table($tbody, $thead);
        } else {
            CLI::write("• No new parameters require HR confirmation.", 'green');
        }

        CLI::newLine();
        CLI::write("================================================================", 'cyan');
        CLI::write("                  SEEDING FINISHED                              ", 'white', 'green');
        CLI::write("Total domains newly seeded across companies: {$totalSeededCount}", 'white');
        CLI::write("================================================================", 'cyan');
    }
}
