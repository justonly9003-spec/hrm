<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;

class AuditLegacyEmployeeRefs extends BaseCommand
{
    protected $group       = 'Employees';
    protected $name        = 'employees:audit-legacy-refs';
    protected $description = 'Read-only audit of employee-reference columns to detect legacy codes vs canonical IDs, convertible rows, ambiguous rows, and orphan references.';
    protected $usage       = 'employees:audit-legacy-refs [--company <company_id>] [--verbose] [--json]';
    protected $arguments   = [];
    protected $options     = [
        '--company' => 'Optional company_id filter to scope the audit to a single tenant.',
        '--verbose' => 'Display sample values for convertible, ambiguous, and orphan records.',
        '--json'    => 'Emit machine-readable JSON summary output.',
    ];

    /**
     * Primary target reference columns to convert
     */
    protected array $targetRefColumns = [
        ['table' => 'attendance_logs',                  'column' => 'employee_id'],
        ['table' => 'attendance_corrections',             'column' => 'employee_id'],
        ['table' => 'biometric_mappings',                 'column' => 'employee_id'],
        ['table' => 'raw_biometric_events',              'column' => 'resolved_employee_id'],
        ['table' => 'unmatched_biometric_identities',     'column' => 'resolved_employee_id'],
        ['table' => 'unmatched_biometric_identities',     'column' => 'mapped_employee_id'], // alias/actual column in schema
        ['table' => 'biometric_attendance_events',       'column' => 'employee_id'],
        ['table' => 'attendances',                       'column' => 'employee_id'],
        ['table' => 'attendance_gps_logs',               'column' => 'employee_id'],
        ['table' => 'duty_assignments',                  'column' => 'employee_id'],
        ['table' => 'roster_assignments',                'column' => 'employee_id'],
        ['table' => 'shift_swap_requests',               'column' => 'requester_id'],
        ['table' => 'shift_swap_requests',               'column' => 'target_employee_id'],
    ];

    /**
     * Additional columns discovered via codebase grep that join on employee_code
     */
    protected array $additionalRefColumns = [
        ['table' => 'leave_applications',                'column' => 'employee_id'],
        ['table' => 'leave_applications',                'column' => 'covering_employee_id'],
        ['table' => 'leaves',                            'column' => 'employee_id'],
    ];

    /**
     * Device identity columns: DO NOT CONVERT, report uniqueness per (company_id, device, user_id)
     */
    protected array $deviceIdentityColumns = [
        [
            'table'        => 'biometric_mappings',
            'user_col'     => 'biometric_user_id',
            'device_col'   => 'device_id',
            'tenant_col'   => 'company_id',
            'emp_link_col' => 'employee_id',
            'is_event_log' => false,
        ],
        [
            'table'        => 'unmatched_biometric_identities',
            'user_col'     => 'biometric_user_id',
            'device_col'   => 'device_id',
            'tenant_col'   => 'company_id',
            'emp_link_col' => 'mapped_employee_id',
            'is_event_log' => false,
        ],
        [
            'table'        => 'raw_biometric_events',
            'user_col'     => 'biometric_user_id',
            'device_col'   => 'device_id',
            'tenant_col'   => 'company_id',
            'emp_link_col' => 'resolved_employee_id',
            'is_event_log' => true,
        ],
        [
            'table'        => 'biometric_attendance_events',
            'user_col'     => 'device_user_id',
            'device_col'   => 'device_id',
            'tenant_col'   => 'company_id',
            'emp_link_col' => 'employee_id',
            'is_event_log' => true,
        ],
    ];

    public function run(array $params)
    {
        $db = \Config\Database::connect();

        $companyFilter = $params['company'] ?? CLI::getOption('company');
        $isVerbose     = CLI::getOption('verbose') !== null || in_array('--verbose', $params, true);
        $isJson        = CLI::getOption('json') !== null || in_array('--json', $params, true);

        if (!$isJson) {
            CLI::write("================================================================================", 'cyan');
            CLI::write("          READ-ONLY AUDIT: LEGACY EMPLOYEE CODES VS CANONICAL IDs               ", 'white', 'blue');
            CLI::write("================================================================================", 'cyan');
            CLI::write("Company Filter : " . ($companyFilter ?: 'ALL COMPANIES (Global)'), 'yellow');
            CLI::write("Timestamp      : " . date('Y-m-d H:i:s'), 'white');
            CLI::newLine();
        }

        if (!$db->tableExists('employees')) {
            if ($isJson) {
                echo json_encode(['success' => false, 'error' => 'Table `employees` does not exist.'], JSON_PRETTY_PRINT);
            } else {
                CLI::error("FATAL: Table `employees` does not exist in the active database.");
            }
            return;
        }

        // Build in-memory employee lookup indices for performance
        $empLookup = $this->buildEmployeeLookupIndex($db);

        $allTargets = array_merge(
            array_map(fn($t) => array_merge($t, ['group' => 'TARGET']), $this->targetRefColumns),
            array_map(fn($t) => array_merge($t, ['group' => 'DISCOVERED_VIA_GREP']), $this->additionalRefColumns)
        );

        $reportResults = [];

        foreach ($allTargets as $target) {
            $table  = $target['table'];
            $column = $target['column'];
            $grp    = $target['group'];

            if (!$db->tableExists($table)) {
                $reportResults[] = [
                    'table'          => $table,
                    'column'         => $column,
                    'group'          => $grp,
                    'status'         => 'MISSING_TABLE',
                    'has_company_id' => false,
                    'total_rows'     => 0,
                    'already_id'     => 0,
                    'convertible'    => 0,
                    'ambiguous'      => 0,
                    'orphan'         => 0,
                    'cross_company'  => 0,
                    'samples'        => [],
                ];
                continue;
            }

            if (!$db->fieldExists($column, $table)) {
                $reportResults[] = [
                    'table'          => $table,
                    'column'         => $column,
                    'group'          => $grp,
                    'status'         => 'MISSING_COLUMN',
                    'has_company_id' => $db->fieldExists('company_id', $table),
                    'total_rows'     => 0,
                    'already_id'     => 0,
                    'convertible'    => 0,
                    'ambiguous'      => 0,
                    'orphan'         => 0,
                    'cross_company'  => 0,
                    'samples'        => [],
                ];
                continue;
            }

            $hasCompanyId = $db->fieldExists('company_id', $table);
            $auditData    = $this->auditReferenceColumn($db, $table, $column, $hasCompanyId, $empLookup, $companyFilter);

            $reportResults[] = array_merge([
                'table'          => $table,
                'column'         => $column,
                'group'          => $grp,
                'status'         => 'ACTIVE',
                'has_company_id' => $hasCompanyId,
            ], $auditData);
        }

        // Audit device identities
        $deviceResults = [];
        foreach ($this->deviceIdentityColumns as $devTarget) {
            $deviceResults[] = $this->auditDeviceIdentity($db, $devTarget, $companyFilter);
        }

        if ($isJson) {
            echo json_encode([
                'success'           => true,
                'company_filter'    => $companyFilter,
                'generated_at'      => date('Y-m-d H:i:s'),
                'reference_columns' => $reportResults,
                'device_identities' => $deviceResults,
            ], JSON_PRETTY_PRINT);
            return;
        }

        // Render CLI Table for Reference Columns
        CLI::write("1. EMPLOYEE REFERENCE COLUMNS AUDIT (TARGETS + DISCOVERED)", 'green');
        CLI::write(str_repeat('-', 100), 'cyan');

        $headers = ['Table.Column', 'Has CoID', 'Total', 'Already ID', 'Convertible', 'Ambiguous', 'Orphan', 'Cross-Co', 'Status'];
        $rows = [];

        foreach ($reportResults as $res) {
            $tableCol = "{$res['table']}.{$res['column']}";
            if ($res['status'] !== 'ACTIVE') {
                $rows[] = [
                    $tableCol,
                    $res['has_company_id'] ? 'Yes' : 'No',
                    '-',
                    '-',
                    '-',
                    '-',
                    '-',
                    '-',
                    "[{$res['status']}]"
                ];
                continue;
            }

            $statusText = 'OK';
            if ($res['ambiguous'] > 0 || $res['cross_company'] > 0) {
                $statusText = 'ATTN: AMBIGUOUS';
            } elseif ($res['orphan'] > 0) {
                $statusText = 'ATTN: ORPHAN';
            } elseif ($res['convertible'] > 0) {
                $statusText = 'NEEDS BACKFILL';
            }

            $rows[] = [
                $tableCol,
                $res['has_company_id'] ? 'Yes' : 'No',
                number_format($res['total_rows']),
                number_format($res['already_id']),
                number_format($res['convertible']),
                number_format($res['ambiguous']),
                number_format($res['orphan']),
                number_format($res['cross_company']),
                $statusText,
            ];
        }

        $this->printFormattedTable($headers, $rows);

        CLI::newLine();
        CLI::write("2. DEVICE IDENTITIES UNIQUENESS AUDIT (DO NOT CONVERT)", 'green');
        CLI::write(str_repeat('-', 100), 'cyan');

        $devHeaders = ['Table', 'Device User Col', 'Device Col', 'Total Rows', 'Distinct Tuples', 'Duplicate Tuples', 'Multi-Emp Conflicts', 'Uniqueness Verdict'];
        $devRows = [];

        foreach ($deviceResults as $dRes) {
            if ($dRes['status'] !== 'ACTIVE') {
                $devRows[] = [
                    $dRes['table'],
                    $dRes['user_col'],
                    $dRes['device_col'] ?? 'N/A',
                    '-',
                    '-',
                    '-',
                    '-',
                    "[{$dRes['status']}]"
                ];
                continue;
            }

            $devRows[] = [
                $dRes['table'],
                $dRes['user_col'],
                $dRes['device_col'],
                number_format($dRes['total_rows']),
                number_format($dRes['distinct_tuples']),
                number_format($dRes['duplicate_tuples_count']),
                number_format($dRes['multi_emp_conflicts_count']),
                $dRes['verdict']
            ];
        }

        $this->printFormattedTable($devHeaders, $devRows);

        if ($isVerbose) {
            CLI::newLine();
            CLI::write("3. VERBOSE DETAILS & SAMPLE VALUES", 'yellow');
            CLI::write(str_repeat('-', 100), 'yellow');

            foreach ($reportResults as $res) {
                if ($res['status'] !== 'ACTIVE') {
                    continue;
                }
                if ($res['convertible'] === 0 && $res['ambiguous'] === 0 && $res['orphan'] === 0 && $res['cross_company'] === 0) {
                    continue;
                }

                CLI::write("Table: {$res['table']}.{$res['column']}", 'cyan');
                if (!empty($res['samples']['convertible'])) {
                    CLI::write("  - Convertible samples (code -> single id): " . implode(', ', array_map(fn($s) => "{$s['code']} => {$s['id']}", array_slice($res['samples']['convertible'], 0, 5))));
                }
                if (!empty($res['samples']['ambiguous'])) {
                    CLI::write("  - Ambiguous samples (code -> multiple matches): " . implode(', ', array_map(fn($s) => "{$s['code']} (" . count($s['matched_ids']) . " matches: " . implode('/', $s['matched_ids']) . ")", array_slice($res['samples']['ambiguous'], 0, 5))), 'red');
                }
                if (!empty($res['samples']['orphan'])) {
                    CLI::write("  - Orphan samples (code/value -> 0 matches): " . implode(', ', array_slice($res['samples']['orphan'], 0, 5)), 'red');
                }
                if (!empty($res['samples']['cross_company'])) {
                    CLI::write("  - Cross-company mismatches: " . implode(', ', array_map(fn($s) => "val:{$s['value']} (co:{$s['row_company_id']} vs emp_co:{$s['emp_company_id']})", array_slice($res['samples']['cross_company'], 0, 5))), 'yellow');
                }
            }
        }

        CLI::newLine();
        CLI::write("================================================================================", 'cyan');
        CLI::write("AUDIT COMPLETED. Review the figures above before proceeding to Step 2 Backfill.", 'white', 'blue');
        CLI::write("================================================================================", 'cyan');
    }

    /**
     * Builds memory-efficient lookup tables for employees
     */
    protected function buildEmployeeLookupIndex(\CodeIgniter\Database\BaseConnection $db): array
    {
        $rows = $db->table('employees')
            ->select('id, company_id, employee_code')
            ->get()
            ->getResultArray();

        $idMap                = []; // id => ['company_id' => ..., 'employee_code' => ...]
        $codeCompanyMap       = []; // [company_id][code] => [ids]
        $codeGlobalMap        = []; // [code] => [ ['id' => ..., 'company_id' => ...] ]

        foreach ($rows as $r) {
            $id   = (string)$r['id'];
            $cid  = (string)$r['company_id'];
            $code = trim((string)($r['employee_code'] ?? ''));

            $idMap[$id] = [
                'company_id'    => $cid,
                'employee_code' => $code,
            ];

            if ($code !== '') {
                $codeCompanyMap[$cid][$code][] = $id;
                $codeGlobalMap[$code][] = [
                    'id'         => $id,
                    'company_id' => $cid,
                ];
            }
        }

        return [
            'id_map'           => $idMap,
            'code_company_map' => $codeCompanyMap,
            'code_global_map'  => $codeGlobalMap,
        ];
    }

    /**
     * Audits a specific employee-reference column
     */
    protected function auditReferenceColumn(
        \CodeIgniter\Database\BaseConnection $db,
        string $table,
        string $column,
        bool $hasCompanyId,
        array $empLookup,
        ?string $companyFilter
    ): array {
        $builder = $db->table($table);
        $builder->where("`{$column}` IS NOT NULL");
        $builder->where("`{$column}` !=", '');

        if ($companyFilter && $hasCompanyId) {
            $builder->where('company_id', $companyFilter);
        }

        // Fetch distinct values to minimize memory overhead
        if ($hasCompanyId) {
            $builder->select("`{$column}` AS ref_value, company_id, COUNT(*) AS row_count", false);
            $builder->groupBy(["`{$column}`", "company_id"]);
        } else {
            $builder->select("`{$column}` AS ref_value, COUNT(*) AS row_count", false);
            $builder->groupBy("`{$column}`");
        }

        $groups = $builder->get()->getResultArray();

        $totalRows     = 0;
        $alreadyId     = 0;
        $convertible   = 0;
        $ambiguous     = 0;
        $orphan        = 0;
        $crossCompany  = 0;

        $samples = [
            'convertible'   => [],
            'ambiguous'     => [],
            'orphan'        => [],
            'cross_company' => [],
        ];

        foreach ($groups as $grp) {
            $val   = (string)$grp['ref_value'];
            $cnt   = (int)$grp['row_count'];
            $coId  = $hasCompanyId ? (string)($grp['company_id'] ?? '') : null;

            $totalRows += $cnt;

            // 1. Does the value directly match an employees.id?
            if (isset($empLookup['id_map'][$val])) {
                $alreadyId += $cnt;
                continue;
            }

            // 2. Value is not an employees.id. Check if it matches employee_code.
            if ($hasCompanyId && $coId !== null) {
                $matchesInCompany = $empLookup['code_company_map'][$coId][$val] ?? [];
                $matchCount = count($matchesInCompany);

                if ($matchCount === 1) {
                    // Exactly ONE matching employee in the same company: CONVERTIBLE
                    $convertible += $cnt;
                    if (count($samples['convertible']) < 10) {
                        $samples['convertible'][] = [
                            'code'       => $val,
                            'id'         => $matchesInCompany[0],
                            'company_id' => $coId,
                        ];
                    }
                } elseif ($matchCount > 1) {
                    // More than one matching employee with this code in the same company: AMBIGUOUS
                    $ambiguous += $cnt;
                    if (count($samples['ambiguous']) < 10) {
                        $samples['ambiguous'][] = [
                            'code'        => $val,
                            'matched_ids' => $matchesInCompany,
                            'company_id'  => $coId,
                        ];
                    }
                } else {
                    // Zero matches in this company. Check if code exists globally in another company.
                    $globalMatches = $empLookup['code_global_map'][$val] ?? [];
                    if (!empty($globalMatches)) {
                        $crossCompany += $cnt;
                        if (count($samples['cross_company']) < 10) {
                            $samples['cross_company'][] = [
                                'value'          => $val,
                                'row_company_id' => $coId,
                                'emp_company_id' => $globalMatches[0]['company_id'],
                            ];
                        }
                    } else {
                        $orphan += $cnt;
                        if (count($samples['orphan']) < 10) {
                            $samples['orphan'][] = $val;
                        }
                    }
                }
            } else {
                // Table has NO company_id.
                $globalMatches = $empLookup['code_global_map'][$val] ?? [];
                $matchCount = count($globalMatches);

                if ($matchCount === 1) {
                    // Exactly ONE matching employee globally: CONVERTIBLE
                    $convertible += $cnt;
                    if (count($samples['convertible']) < 10) {
                        $samples['convertible'][] = [
                            'code'       => $val,
                            'id'         => $globalMatches[0]['id'],
                            'company_id' => $globalMatches[0]['company_id'],
                        ];
                    }
                } elseif ($matchCount > 1) {
                    // Matches employees across multiple companies: AMBIGUOUS
                    $ambiguous += $cnt;
                    if (count($samples['ambiguous']) < 10) {
                        $samples['ambiguous'][] = [
                            'code'        => $val,
                            'matched_ids' => array_column($globalMatches, 'id'),
                            'companies'   => array_column($globalMatches, 'company_id'),
                        ];
                    }
                } else {
                    // Zero matches globally: ORPHAN
                    $orphan += $cnt;
                    if (count($samples['orphan']) < 10) {
                        $samples['orphan'][] = $val;
                    }
                }
            }
        }

        return [
            'total_rows'    => $totalRows,
            'already_id'    => $alreadyId,
            'convertible'   => $convertible,
            'ambiguous'     => $ambiguous,
            'orphan'        => $orphan,
            'cross_company' => $crossCompany,
            'samples'       => $samples,
        ];
    }

    /**
     * Audits device identity uniqueness per (company_id, device, user_id)
     */
    protected function auditDeviceIdentity(
        \CodeIgniter\Database\BaseConnection $db,
        array $config,
        ?string $companyFilter
    ): array {
        $table      = $config['table'];
        $userCol    = $config['user_col'];
        $tenantCol  = $config['tenant_col'];
        $linkCol    = $config['emp_link_col'];
        $isEventLog = $config['is_event_log'];

        if (!$db->tableExists($table)) {
            return [
                'table'                      => $table,
                'user_col'                   => $userCol,
                'device_col'                 => $config['device_col'],
                'status'                     => 'MISSING_TABLE',
                'total_rows'                 => 0,
                'distinct_tuples'            => 0,
                'duplicate_tuples_count'     => 0,
                'multi_emp_conflicts_count'  => 0,
                'verdict'                    => 'MISSING_TABLE',
            ];
        }

        if (!$db->fieldExists($userCol, $table)) {
            return [
                'table'                      => $table,
                'user_col'                   => $userCol,
                'device_col'                 => $config['device_col'],
                'status'                     => 'MISSING_COLUMN',
                'total_rows'                 => 0,
                'distinct_tuples'            => 0,
                'duplicate_tuples_count'     => 0,
                'multi_emp_conflicts_count'  => 0,
                'verdict'                    => 'MISSING_COLUMN',
            ];
        }

        $deviceCol = null;
        if ($db->fieldExists($config['device_col'], $table)) {
            $deviceCol = $config['device_col'];
        } elseif ($db->fieldExists('device_serial', $table)) {
            $deviceCol = 'device_serial';
        }

        $hasTenantCol = $db->fieldExists($tenantCol, $table);
        $hasLinkCol   = $linkCol && $db->fieldExists($linkCol, $table);

        $builder = $db->table($table);
        $builder->where("`{$userCol}` IS NOT NULL");
        $builder->where("`{$userCol}` !=", '');

        if ($companyFilter && $hasTenantCol) {
            $builder->where($tenantCol, $companyFilter);
        }

        $totalRows = (int)$builder->countAllResults(false);

        // Group by (company_id, device, user_id)
        $selectCols = ["`{$userCol}` AS uid", "COUNT(*) AS occurrence_count"];
        $groupCols  = ["`{$userCol}`"];

        if ($hasTenantCol) {
            $selectCols[] = "`{$tenantCol}` AS tenant_id";
            $groupCols[]  = "`{$tenantCol}`";
        }
        if ($deviceCol) {
            $selectCols[] = "COALESCE(`{$deviceCol}`, 'GLOBAL_DEVICE') AS dev_id";
            $groupCols[]  = "COALESCE(`{$deviceCol}`, 'GLOBAL_DEVICE')";
        }
        if ($hasLinkCol) {
            $selectCols[] = "COUNT(DISTINCT `{$linkCol}`) AS distinct_emp_count";
        }

        $groupedBuilder = $db->table($table)
            ->select(implode(', ', $selectCols), false)
            ->where("`{$userCol}` IS NOT NULL")
            ->where("`{$userCol}` !=", '');

        if ($companyFilter && $hasTenantCol) {
            $groupedBuilder->where($tenantCol, $companyFilter);
        }

        $groupedBuilder->groupBy($groupCols);
        $tupleRows = $groupedBuilder->get()->getResultArray();

        $distinctTuples    = count($tupleRows);
        $duplicateTuples   = 0;
        $multiEmpConflicts = 0;

        foreach ($tupleRows as $tr) {
            $occs = (int)$tr['occurrence_count'];
            if (!$isEventLog && $occs > 1) {
                // For mapping/master identity tables, having > 1 record for the same device+user is a duplicate
                $duplicateTuples++;
            }
            if ($hasLinkCol && isset($tr['distinct_emp_count']) && (int)$tr['distinct_emp_count'] > 1) {
                // If the same device user is associated with more than one employee ID
                $multiEmpConflicts++;
            }
        }

        $verdict = 'UNIQUE';
        if ($multiEmpConflicts > 0) {
            $verdict = 'CONFLICT: MULTI-EMP';
        } elseif (!$isEventLog && $duplicateTuples > 0) {
            $verdict = 'DUPLICATES FOUND';
        } elseif ($isEventLog) {
            $verdict = 'UNIQUE IDENTITIES';
        }

        return [
            'table'                     => $table,
            'user_col'                  => $userCol,
            'device_col'                => $deviceCol ?: 'NONE',
            'status'                    => 'ACTIVE',
            'total_rows'                => $totalRows,
            'distinct_tuples'           => $distinctTuples,
            'duplicate_tuples_count'    => $duplicateTuples,
            'multi_emp_conflicts_count' => $multiEmpConflicts,
            'verdict'                   => $verdict,
        ];
    }

    /**
     * Helper to print formatted ASCII tables in CLI
     */
    protected function printFormattedTable(array $headers, array $rows): void
    {
        $colWidths = [];
        foreach ($headers as $i => $h) {
            $colWidths[$i] = strlen($h);
        }

        foreach ($rows as $row) {
            foreach ($row as $i => $cell) {
                $colWidths[$i] = max($colWidths[$i], strlen((string)$cell));
            }
        }

        // Print header
        $headerLine = '';
        foreach ($headers as $i => $h) {
            $headerLine .= str_pad($h, $colWidths[$i] + 2);
        }
        CLI::write($headerLine, 'yellow');

        $separatorLine = '';
        foreach ($colWidths as $w) {
            $separatorLine .= str_repeat('-', $w + 2);
        }
        CLI::write($separatorLine, 'dark_gray');

        // Print rows
        foreach ($rows as $row) {
            $rowLine = '';
            foreach ($row as $i => $cell) {
                $rowLine .= str_pad((string)$cell, $colWidths[$i] + 2);
            }
            CLI::write($rowLine);
        }
    }
}
