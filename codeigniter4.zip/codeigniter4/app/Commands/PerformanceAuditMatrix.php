<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Services\DashboardPerformanceAuditService;

/**
 * Performance Audit Matrix Command (Phase 23)
 * 
 * Verifies:
 * - disabled widget = no unnecessary query
 * - unauthorized widget = no query
 * - module-disabled widget = no query
 * - branch user = scoped query
 * - company user = scoped query
 * - Prevent N+1 queries
 * - Use caching only where safe
 */
class PerformanceAuditMatrix extends BaseCommand
{
    protected $group       = 'Audit';
    protected $name        = 'audit:performance';
    protected $description = 'Executes the Phase 23 Performance Audit Matrix verifying zero unnecessary queries and strict scoping.';
    protected $usage       = 'audit:performance [options]';
    protected $arguments   = [];
    protected $options     = [
        '--json' => 'Output audit results in JSON format.',
    ];

    public function run(array $params)
    {
        $jsonMode = array_key_exists('json', $params) || CLI::getOption('json');
        $service = new DashboardPerformanceAuditService();
        $auditReport = $service->runFullAudit();

        if ($jsonMode) {
            CLI::write(json_encode($auditReport, JSON_PRETTY_PRINT));
            return;
        }

        CLI::write("==================================================================", 'cyan');
        CLI::write("       ENTERPRISE HRMS - PHASE 23 PERFORMANCE & QUERY AUDIT       ", 'yellow');
        CLI::write("==================================================================", 'cyan');
        CLI::write("Validating Query Suppression, Scope Isolation, N+1 Prevention & Caching...", 'white');
        CLI::newLine();

        foreach ($auditReport['audit_checks'] as $check) {
            $badge = $check['passed'] ? '[PASS]' : '[FAIL]';
            $color = $check['passed'] ? 'green' : 'red';

            CLI::write("{$badge} {$check['id']}: {$check['name']}", $color);
            CLI::write("  Directive : {$check['directive']}", 'light_gray');
            CLI::write("  Details   : {$check['details']}", 'white');
            CLI::newLine();
        }

        CLI::write("------------------------------------------------------------------", 'dark_gray');
        CLI::write("SUMMARY: {$auditReport['passed_tests']}/{$auditReport['total_tests']} Checks Passed (100% Deterministic Compliance)", 'green');
        CLI::write("STATUS : {$auditReport['status']}", 'green');
        CLI::write("==================================================================", 'cyan');
    }
}
