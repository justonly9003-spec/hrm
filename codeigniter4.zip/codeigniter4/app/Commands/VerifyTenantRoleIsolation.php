<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use Config\Database;
use App\Services\PermissionService;

/**
 * Verify Tenant Role Isolation Command
 *
 * Verifies that role permissions are strictly isolated per company tenant:
 * Creates two companies with an hr_officer role each, grants directory.delete
 * to Company A only, and asserts Company B's hr_officer is denied.
 *
 * Usage: php spark rbac:verify-tenant-roles
 */
class VerifyTenantRoleIsolation extends BaseCommand
{
    protected $group       = 'Security';
    protected $name        = 'rbac:verify-tenant-roles';
    protected $description = 'Asserts multi-tenant role isolation: company B hr_officer is denied permissions granted only to company A.';
    protected $usage       = 'rbac:verify-tenant-roles';
    protected $arguments   = [];
    protected $options     = [];

    public function run(array $params)
    {
        CLI::write("==================================================================", 'cyan');
        CLI::write("       RBAC MULTI-TENANT ROLE ISOLATION VERIFICATION SUITE        ", 'yellow');
        CLI::write("==================================================================", 'cyan');

        $db = Database::connect();
        $permService = new PermissionService($db);
        $session = function_exists('session') ? session() : (class_exists('\Config\Services') ? \Config\Services::session() : null);

        PermissionService::clearCache();

        $passed = 0;
        $failed = 0;

        // Generate isolated test tenant fixtures
        $suffix = bin2hex(random_bytes(4));
        $compAId = 'comp-iso-a-' . $suffix;
        $compBId = 'comp-iso-b-' . $suffix;
        $roleAId = 'role-iso-hro-a-' . $suffix;
        $roleBId = 'role-iso-hro-b-' . $suffix;
        $userAId = 'usr-iso-a-' . $suffix;
        $userBId = 'usr-iso-b-' . $suffix;
        $userCId = 'usr-iso-c-nocomp-' . $suffix;
        $rolePermAId = 'rp-iso-a-' . $suffix;
        $customPermCreated = false;

        try {
            // 1. Ensure directory.delete permission exists in permissions table
            $permRow = $db->table('permissions')->where('code', 'directory.delete')->get()->getRowArray();
            if (!$permRow) {
                $dirDelPermId = 'perm-iso-dir-del-' . $suffix;
                $db->table('permissions')->insert([
                    'id'          => $dirDelPermId,
                    'code'        => 'directory.delete',
                    'module'      => 'directory',
                    'action'      => 'delete',
                    'name'        => 'Delete Employees',
                    'description' => 'Test directory delete permission',
                    'created_at'  => date('Y-m-d H:i:s'),
                    'updated_at'  => date('Y-m-d H:i:s'),
                ]);
                $customPermCreated = true;
            } else {
                $dirDelPermId = $permRow['id'];
            }

            // 2. Create Company A and Company B
            $db->table('companies')->insert([
                'id'         => $compAId,
                'name'       => 'Tenant Alpha Isolation Ltd',
                'code'       => 'ISO_A_' . strtoupper($suffix),
                'status'     => 'Active',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

            $db->table('companies')->insert([
                'id'         => $compBId,
                'name'       => 'Tenant Beta Isolation Ltd',
                'code'       => 'ISO_B_' . strtoupper($suffix),
                'status'     => 'Active',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

            // 3. Create hr_officer role in Company A and hr_officer role in Company B
            $db->table('roles')->insert([
                'id'          => $roleAId,
                'company_id'  => $compAId,
                'code'        => 'hr_officer',
                'name'        => 'HR Officer',
                'description' => 'HR Officer for Tenant Alpha',
                'status'      => 'Active',
                'is_system'   => 1,
                'created_at'  => date('Y-m-d H:i:s'),
                'updated_at'  => date('Y-m-d H:i:s'),
            ]);

            $db->table('roles')->insert([
                'id'          => $roleBId,
                'company_id'  => $compBId,
                'code'        => 'hr_officer',
                'name'        => 'HR Officer',
                'description' => 'HR Officer for Tenant Beta',
                'status'      => 'Active',
                'is_system'   => 1,
                'created_at'  => date('Y-m-d H:i:s'),
                'updated_at'  => date('Y-m-d H:i:s'),
            ]);

            // 4. Grant directory.delete to Company A's hr_officer ONLY
            $db->table('role_permissions')->insert([
                'id'            => $rolePermAId,
                'role_id'       => $roleAId,
                'permission_id' => $dirDelPermId,
            ]);

            // 5. Create active users for both companies
            $db->table('users')->insert([
                'id'            => $userAId,
                'username'      => 'user_iso_a_' . $suffix,
                'email'         => 'user_iso_a_' . $suffix . '@example.com',
                'password_hash' => password_hash('Secret123!', PASSWORD_BCRYPT),
                'role_id'       => $roleAId,
                'company_id'    => $compAId,
                'status'        => 'active',
                'created_at'    => date('Y-m-d H:i:s'),
                'updated_at'    => date('Y-m-d H:i:s'),
            ]);

            $db->table('users')->insert([
                'id'            => $userBId,
                'username'      => 'user_iso_b_' . $suffix,
                'email'         => 'user_iso_b_' . $suffix . '@example.com',
                'password_hash' => password_hash('Secret123!', PASSWORD_BCRYPT),
                'role_id'       => $roleBId,
                'company_id'    => $compBId,
                'status'        => 'active',
                'created_at'    => date('Y-m-d H:i:s'),
                'updated_at'    => date('Y-m-d H:i:s'),
            ]);

            // Create user with no company_id (not software admin)
            $db->table('users')->insert([
                'id'            => $userCId,
                'username'      => 'user_iso_c_' . $suffix,
                'email'         => 'user_iso_c_' . $suffix . '@example.com',
                'password_hash' => password_hash('Secret123!', PASSWORD_BCRYPT),
                'role_id'       => $roleAId,
                'company_id'    => null,
                'status'        => 'active',
                'created_at'    => date('Y-m-d H:i:s'),
                'updated_at'    => date('Y-m-d H:i:s'),
            ]);

            PermissionService::clearCache();

            // -------------------------------------------------------------
            // ASSERTION 1: Company A hr_officer has directory.delete (ALLOW)
            // -------------------------------------------------------------
            CLI::write("[Assertion 1] Evaluating Company A hr_officer (directory.delete)...", 'white');
            $allowedA = $permService->checkDefaultRoleAccess('hr_officer', 'directory', 'delete', $compAId);
            if ($allowedA === true) {
                CLI::write("  -> PASSED: Company A hr_officer is granted directory.delete as configured.", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: Company A hr_officer was unexpectedly DENIED directory.delete.", 'red');
                $failed++;
            }

            // -------------------------------------------------------------
            // ASSERTION 2: Company B hr_officer is DENIED directory.delete
            // -------------------------------------------------------------
            CLI::write("[Assertion 2] Evaluating Company B hr_officer (directory.delete)...", 'white');
            $allowedB = $permService->checkDefaultRoleAccess('hr_officer', 'directory', 'delete', $compBId);
            if ($allowedB === false) {
                CLI::write("  -> PASSED: Company B hr_officer is strictly DENIED directory.delete (no leak from Company A).", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: CRITICAL SECURITY BUG: Company B hr_officer was granted directory.delete from Company A!", 'red');
                $failed++;
            }

            // -------------------------------------------------------------
            // ASSERTION 3: Resolve by current user's role_id (User A in Company A)
            // -------------------------------------------------------------
            CLI::write("[Assertion 3] Evaluating User A by user ID (directory.delete)...", 'white');
            $userAllowedA = $permService->checkDefaultRoleAccess('hr_officer', 'directory', 'delete', null, $userAId);
            if ($userAllowedA === true) {
                CLI::write("  -> PASSED: User A resolved by users.role_id correctly inherits Company A grant.", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: User A was denied directory.delete.", 'red');
                $failed++;
            }

            // -------------------------------------------------------------
            // ASSERTION 4: Resolve by current user's role_id (User B in Company B)
            // -------------------------------------------------------------
            CLI::write("[Assertion 4] Evaluating User B by user ID (directory.delete)...", 'white');
            $userAllowedB = $permService->checkDefaultRoleAccess('hr_officer', 'directory', 'delete', null, $userBId);
            if ($userAllowedB === false) {
                CLI::write("  -> PASSED: User B resolved by users.role_id is strictly DENIED directory.delete.", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: User B was incorrectly granted directory.delete.", 'red');
                $failed++;
            }

            // -------------------------------------------------------------
            // ASSERTION 5: Session-based company resolution
            // -------------------------------------------------------------
            if ($session) {
                CLI::write("[Assertion 5] Evaluating via session company_id...", 'white');
                $session->set('company_id', $compAId);
                $sessAllowedA = $permService->checkDefaultRoleAccess('hr_officer', 'directory', 'delete');

                $session->set('company_id', $compBId);
                $sessAllowedB = $permService->checkDefaultRoleAccess('hr_officer', 'directory', 'delete');

                if ($sessAllowedA === true && $sessAllowedB === false) {
                    CLI::write("  -> PASSED: Session company_id correctly scopes evaluation (Company A = ALLOW, Company B = DENY).", 'green');
                    $passed++;
                } else {
                    CLI::write("  -> FAILED: Session-scoped evaluation mismatch (A={$sessAllowedA}, B={$sessAllowedB}).", 'red');
                    $failed++;
                }
                $session->remove('company_id');
            }

            // -------------------------------------------------------------
            // ASSERTION 6: User with no company ID and not software admin is DENIED
            // -------------------------------------------------------------
            CLI::write("[Assertion 6] Evaluating non-software-admin user with no company_id...", 'white');
            $userNoCompAllowed = $permService->checkDefaultRoleAccess('hr_officer', 'directory', 'delete', null, $userCId);
            if ($userNoCompAllowed === false) {
                CLI::write("  -> PASSED: User with no company_id and non-software-admin is strictly DENIED.", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: User with no company_id was granted access.", 'red');
                $failed++;
            }

        } finally {
            // Teardown test fixtures to keep database clean and idempotent
            $db->table('role_permissions')->where('id', $rolePermAId)->delete();
            $db->table('users')->whereIn('id', [$userAId, $userBId, $userCId])->delete();
            $db->table('roles')->whereIn('id', [$roleAId, $roleBId])->delete();
            $db->table('companies')->whereIn('id', [$compAId, $compBId])->delete();
            if ($customPermCreated) {
                $db->table('permissions')->where('id', $dirDelPermId)->delete();
            }
            if ($session) {
                $session->remove('company_id');
            }
            PermissionService::clearCache();
        }

        CLI::newLine();
        CLI::write("------------------------------------------------------------------", 'cyan');
        CLI::write("VERIFICATION RESULTS: {$passed} PASSED / {$failed} FAILED", $failed === 0 ? 'green' : 'red');
        CLI::write("------------------------------------------------------------------", 'cyan');

        return $failed === 0 ? 0 : 1;
    }
}
