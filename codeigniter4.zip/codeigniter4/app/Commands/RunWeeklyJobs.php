<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Services\Automation\ScheduledJobsService;

class RunWeeklyJobs extends BaseCommand
{
    protected $group       = 'Automation';
    protected $name        = 'cron:weekly';
    protected $description = 'Executes Weekly Automated Scheduled Jobs (Weekly worked-hour calculation, Weekly OT, Weekly bonus)';
    protected $usage       = 'cron:weekly [options]';
    protected $options     = [
        '--user' => 'User ID triggering the manual command',
        '--json' => 'Output results as pure JSON'
    ];

    public function run(array $params)
    {
        $jsonMode = array_key_exists('json', $params) || CLI::getOption('json');
        $userId = CLI::getOption('user') ?? 'CRON_SYSTEM';

        $service = new ScheduledJobsService();

        if (!$jsonMode) {
            CLI::write("================================================================", 'cyan');
            CLI::write("       ENTERPRISE HRMS - WEEKLY SCHEDULED JOBS RUNNER           ", 'yellow');
            CLI::write("================================================================", 'cyan');
            CLI::write("Start Time : " . date('Y-m-d H:i:s'), 'white');
            CLI::newLine();
            CLI::write("1. Calculating cumulative weekly worked hours...", 'yellow');
        }

        $result = $service->runWeeklyJobs('CLI_COMMAND', $userId);

        if (!$jsonMode) {
            $sub = $result['sub_results'] ?? [];

            if (($sub['weekly_hours']['status'] ?? '') === 'OK') {
                CLI::write("   [OK] Weekly worked-hours computed for active employees.", 'green');
            } else {
                CLI::write("   [FAIL] Weekly worked-hours error: " . ($sub['weekly_hours']['message'] ?? 'Execution failed'), 'red');
            }

            CLI::write("2. Evaluating weekly punctuality & attendance bonuses...", 'yellow');
            if (($sub['weekly_bonus']['status'] ?? '') === 'OK') {
                $created = $sub['weekly_bonus']['records_created'] ?? 0;
                $eligible = $sub['weekly_bonus']['bonuses_eligible'] ?? 0;
                CLI::write("   [OK] Weekly bonus calculations completed ({$eligible} eligible, {$created} records created).", 'green');
            } else {
                CLI::write("   [FAIL] Weekly bonus calculations error: " . ($sub['weekly_bonus']['message'] ?? 'Execution failed'), 'red');
            }

            CLI::newLine();
            CLI::write("----------------------------------------------------------------", 'cyan');
            if (!empty($result['success'])) {
                CLI::write("ALL WEEKLY JOBS COMPLETED SUCCESSFULLY IN " . $result['duration_ms'] . " ms", 'green');
            } else {
                CLI::write("WEEKLY JOBS COMPLETED WITH ERRORS IN " . $result['duration_ms'] . " ms", 'red');
            }
            CLI::write("----------------------------------------------------------------", 'cyan');
        } else {
            CLI::write(json_encode($result, JSON_PRETTY_PRINT));
        }
    }
}
