<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use CodeIgniter\Database\ConnectionInterface;

class PfAuditDemoRows extends BaseCommand
{
    public const CLASSIFICATION_DEMO       = 'DEMO';
    public const CLASSIFICATION_SUSPICIOUS = 'SUSPICIOUS';
    public const CLASSIFICATION_REAL       = 'REAL';

    protected $group       = 'Payroll';
    protected $name        = 'pf:audit-demo-rows';
    protected $description = 'Read-only audit of provident_fund_ledgers to detect seeded demo rows matching exact DemoProvidentFundLedgerSeeder signatures.';
    protected $usage       = 'pf:audit-demo-rows [--verbose] [--json]';
    protected $arguments   = [];
    protected $options     = [
        '--verbose' => 'Display detailed row listings including reference_no, payroll_id, notes, and suspicious reasons.',
        '--json'    => 'Emit machine-readable JSON output.',
    ];

    /**
     * Exact demo signatures extracted strictly from DemoProvidentFundLedgerSeeder.
     * A row is DEMO if and only if it matches ALL THREE:
     * 1. company_id in demoCompanies
     * 2. employee_id in demoEmployees
     * 3. id starts with 'PFL-OPEN-' or 'PFL-2026'
     */
    public array $demoCompanies = ['COMP-001', 'COMP-002'];
    public array $demoEmployees = ['EMP-001', 'EMP-002', 'EMP-003', 'EMP-004', 'EMP-005'];

    /**
     * Classify a ledger row as DEMO, SUSPICIOUS, or REAL.
     *
     * - DEMO: matches company_id AND employee_id AND demo ID pattern.
     * - SUSPICIOUS: matches any 1 or 2 of the demo conditions, but not all 3. Must be reviewed manually and never counted as demo.
     * - REAL: matches none of the demo conditions.
     */
    public function classifyRow(array $row): string
    {
        $id         = (string)($row['id'] ?? '');
        $companyId  = (string)($row['company_id'] ?? '');
        $employeeId = (string)($row['employee_id'] ?? '');

        $matchesCompany  = in_array($companyId, $this->demoCompanies, true);
        $matchesEmployee = in_array($employeeId, $this->demoEmployees, true);
        $matchesId       = str_starts_with($id, 'PFL-OPEN-') || str_starts_with($id, 'PFL-2026');

        if ($matchesCompany && $matchesEmployee && $matchesId) {
            return self::CLASSIFICATION_DEMO;
        }

        if ($matchesCompany || $matchesEmployee || $matchesId) {
            return self::CLASSIFICATION_SUSPICIOUS;
        }

        return self::CLASSIFICATION_REAL;
    }

    /**
     * Explain why a row is classified as suspicious for human review.
     */
    public function getSuspiciousReason(array $row): string
    {
        $id         = (string)($row['id'] ?? '');
        $companyId  = (string)($row['company_id'] ?? '');
        $employeeId = (string)($row['employee_id'] ?? '');

        $matchesCompany  = in_array($companyId, $this->demoCompanies, true);
        $matchesEmployee = in_array($employeeId, $this->demoEmployees, true);
        $matchesId       = str_starts_with($id, 'PFL-OPEN-') || str_starts_with($id, 'PFL-2026');

        $reasons = [];
        if ($matchesId && !$matchesCompany) {
            $reasons[] = "Demo ID pattern in non-demo company '{$companyId}'";
        }
        if ($matchesId && !$matchesEmployee) {
            $reasons[] = "Demo ID pattern with non-demo employee '{$employeeId}'";
        }
        if ($matchesCompany && !$matchesId) {
            $reasons[] = "Demo company '{$companyId}' with non-demo ID pattern";
        }
        if ($matchesCompany && !$matchesEmployee) {
            $reasons[] = "Demo company '{$companyId}' with non-demo employee '{$employeeId}'";
        }
        if ($matchesEmployee && !$matchesCompany) {
            $reasons[] = "Demo employee '{$employeeId}' in non-demo company '{$companyId}'";
        }
        if ($matchesEmployee && !$matchesId) {
            $reasons[] = "Demo employee '{$employeeId}' with non-demo ID pattern";
        }

        return empty($reasons) ? 'Partial demo signature match' : implode('; ', array_unique($reasons));
    }

    /**
     * Execute pure read-only audit of provident_fund_ledgers.
     * Returns structured results without writing or mutating any data.
     */
    public function audit(?ConnectionInterface $db = null): array
    {
        $db = $db ?? \Config\Database::connect();

        if (!$db->tableExists('provident_fund_ledgers')) {
            return [
                'table_exists'          => false,
                'total_ledger_rows'     => 0,
                'demo_rows'             => [],
                'suspicious_rows'       => [],
                'per_company'           => [],
                'select_sql'            => '',
                'delete_sql'            => '',
            ];
        }

        // 1. Total ledger rows and counts grouped per company
        $companyTotals = [];
        $totalRowsResult = $db->table('provident_fund_ledgers')
            ->select('company_id, COUNT(*) as row_count')
            ->groupBy('company_id')
            ->get()
            ->getResultArray();

        $totalLedgerRows = 0;
        foreach ($totalRowsResult as $tr) {
            $cId = (string)($tr['company_id'] ?? '');
            if ($cId === '') {
                $cId = 'UNKNOWN';
            }
            $count = (int)$tr['row_count'];
            $companyTotals[$cId] = $count;
            $totalLedgerRows += $count;
        }

        // 2. Fetch candidate rows that match ANY demo characteristic (company, employee, or ID pattern)
        // Note: reference_no, payroll_id, and notes are NOT in WHERE because real 2026 transactions
        // legitimately generate 'PF-TXN-2026%' references in ProvidentFundLedgerModel.
        $builder = $db->table('provident_fund_ledgers');
        $builder->groupStart()
            ->whereIn('company_id', $this->demoCompanies)
            ->orWhereIn('employee_id', $this->demoEmployees)
            ->orLike('id', 'PFL-OPEN-', 'after')
            ->orLike('id', 'PFL-2026', 'after')
        ->groupEnd();

        $candidates = $builder->orderBy('transaction_date', 'ASC')
            ->orderBy('id', 'ASC')
            ->get()
            ->getResultArray();

        $demoRows = [];
        $suspiciousRows = [];
        $demoCountByComp = [];
        $suspiciousCountByComp = [];

        foreach ($candidates as $row) {
            $classification = $this->classifyRow($row);
            $cId = (string)($row['company_id'] ?? '');
            if ($cId === '') {
                $cId = 'UNKNOWN';
            }

            if ($classification === self::CLASSIFICATION_DEMO) {
                $demoRows[] = $row;
                $demoCountByComp[$cId] = ($demoCountByComp[$cId] ?? 0) + 1;
            } elseif ($classification === self::CLASSIFICATION_SUSPICIOUS) {
                $row['suspicious_reason'] = $this->getSuspiciousReason($row);
                $suspiciousRows[] = $row;
                $suspiciousCountByComp[$cId] = ($suspiciousCountByComp[$cId] ?? 0) + 1;
            }
        }

        // 3. Compile per-company breakdown
        $allCompanyIds = array_unique(array_merge(
            array_keys($companyTotals),
            array_keys($demoCountByComp),
            array_keys($suspiciousCountByComp)
        ));
        sort($allCompanyIds);

        $perCompany = [];
        foreach ($allCompanyIds as $cId) {
            $total      = $companyTotals[$cId] ?? 0;
            $demo       = $demoCountByComp[$cId] ?? 0;
            $suspicious = $suspiciousCountByComp[$cId] ?? 0;

            $status = 'CLEAN';
            if ($demo > 0) {
                $status = 'DEMO DETECTED';
            } elseif ($suspicious > 0) {
                $status = 'SUSPICIOUS';
            }

            $perCompany[$cId] = [
                'company_id'      => $cId,
                'total_rows'      => $total,
                'demo_rows'       => $demo,
                'suspicious_rows' => $suspicious,
                'status'          => $status,
            ];
        }

        // Safe WHERE clause with explicit parentheses:
        // (id LIKE 'PFL-OPEN-%' OR id LIKE 'PFL-2026%') AND company_id IN (...) AND employee_id IN (...)
        $companiesList = "'" . implode("', '", $this->demoCompanies) . "'";
        $employeesList = "'" . implode("', '", $this->demoEmployees) . "'";
        $whereClause = "(id LIKE 'PFL-OPEN-%' OR id LIKE 'PFL-2026%') AND company_id IN ({$companiesList}) AND employee_id IN ({$employeesList})";

        $selectSql = "SELECT * FROM provident_fund_ledgers WHERE {$whereClause};";
        $deleteSql = "-- DELETE FROM provident_fund_ledgers WHERE {$whereClause};";

        return [
            'table_exists'          => true,
            'total_ledger_rows'     => $totalLedgerRows,
            'demo_rows'             => $demoRows,
            'suspicious_rows'       => $suspiciousRows,
            'per_company'           => $perCompany,
            'select_sql'            => $selectSql,
            'delete_sql'            => $deleteSql,
        ];
    }

    public function run(array $params)
    {
        $db = \Config\Database::connect();

        $isVerbose = CLI::getOption('verbose') !== null || in_array('--verbose', $params, true);
        $isJson    = CLI::getOption('json') !== null || in_array('--json', $params, true);

        if (!$isJson) {
            CLI::write("================================================================================", 'cyan');
            CLI::write("           READ-ONLY AUDIT: PROVIDENT FUND LEDGER DEMO ROWS                      ", 'white', 'blue');
            CLI::write("================================================================================", 'cyan');
            CLI::write("Timestamp : " . date('Y-m-d H:i:s'), 'white');
            CLI::newLine();
        }

        $audit = $this->audit($db);

        if (!$audit['table_exists']) {
            if ($isJson) {
                echo json_encode(['success' => false, 'error' => 'Table `provident_fund_ledgers` does not exist.'], JSON_PRETTY_PRINT);
            } else {
                CLI::error("Table `provident_fund_ledgers` does not exist in the active database.");
            }
            return;
        }

        $totalLedgerRows = $audit['total_ledger_rows'];
        $demoRows        = $audit['demo_rows'];
        $suspiciousRows  = $audit['suspicious_rows'];
        $perCompany      = $audit['per_company'];
        $demoCount       = count($demoRows);
        $suspiciousCount = count($suspiciousRows);

        $totalDemoAmount = 0.00;
        foreach ($demoRows as $r) {
            $totalDemoAmount += (float)($r['total_contribution'] ?? 0.00);
        }

        if ($isJson) {
            echo json_encode([
                'success'               => true,
                'total_ledger_rows'     => $totalLedgerRows,
                'demo_rows_count'       => $demoCount,
                'suspicious_rows_count' => $suspiciousCount,
                'total_demo_amount'     => round($totalDemoAmount, 2),
                'per_company'           => array_values($perCompany),
                'demo_rows'             => $demoRows,
                'suspicious_rows'       => $suspiciousRows,
                'safe_sql'              => [
                    'backup' => 'CREATE TABLE provident_fund_ledgers_backup AS SELECT * FROM provident_fund_ledgers;',
                    'select' => $audit['select_sql'],
                    'delete' => $audit['delete_sql'],
                ],
            ], JSON_PRETTY_PRINT);
            return;
        }

        CLI::write("Total Ledger Records : " . number_format($totalLedgerRows), 'white');
        CLI::write("Demo Records Found   : " . number_format($demoCount), $demoCount > 0 ? 'red' : 'green');
        CLI::write("Suspicious Records   : " . number_format($suspiciousCount), $suspiciousCount > 0 ? 'yellow' : 'green');
        CLI::write("Total Demo Volume    : " . number_format($totalDemoAmount, 2), 'white');
        CLI::newLine();

        // 1. PER-COMPANY BREAKDOWN TABLE
        CLI::write("PER-COMPANY BREAKDOWN:", 'yellow');
        $compHeaders = ['Company ID', 'Total Rows', 'Demo Rows', 'Suspicious Rows', 'Status'];
        $compRows = [];
        foreach ($perCompany as $cStats) {
            $compRows[] = [
                $cStats['company_id'],
                (string)$cStats['total_rows'],
                (string)$cStats['demo_rows'],
                (string)$cStats['suspicious_rows'],
                $cStats['status'],
            ];
        }
        $this->printFormattedTable($compHeaders, $compRows);
        CLI::newLine();

        // 2. DEMO RECORDS SECTION
        if ($demoCount > 0) {
            CLI::write("CONFIRMED DEMO RECORDS:", 'red');
            $displayDemo = $isVerbose ? $demoRows : array_slice($demoRows, 0, 10);

            if ($isVerbose) {
                $demoHeaders = ['ID', 'Company', 'Employee', 'Type', 'Date', 'Total Contrib', 'Running Bal', 'Status', 'Ref No', 'Payroll ID', 'Notes'];
                $demoTableData = [];
                foreach ($displayDemo as $dr) {
                    $demoTableData[] = [
                        $dr['id'],
                        $dr['company_id'],
                        $dr['employee_id'],
                        $dr['transaction_type'] ?? '-',
                        $dr['transaction_date'] ?? '-',
                        number_format((float)($dr['total_contribution'] ?? 0), 2),
                        number_format((float)($dr['running_balance'] ?? 0), 2),
                        $dr['status'] ?? '-',
                        $dr['reference_no'] ?? '-',
                        $dr['payroll_id'] ?? '-',
                        $dr['notes'] ?? '-',
                    ];
                }
            } else {
                $demoHeaders = ['ID', 'Company', 'Employee', 'Type', 'Date', 'Total Contrib', 'Running Bal', 'Status'];
                $demoTableData = [];
                foreach ($displayDemo as $dr) {
                    $demoTableData[] = [
                        $dr['id'],
                        $dr['company_id'],
                        $dr['employee_id'],
                        $dr['transaction_type'] ?? '-',
                        $dr['transaction_date'] ?? '-',
                        number_format((float)($dr['total_contribution'] ?? 0), 2),
                        number_format((float)($dr['running_balance'] ?? 0), 2),
                        $dr['status'] ?? '-',
                    ];
                }
            }

            $this->printFormattedTable($demoHeaders, $demoTableData);

            if (!$isVerbose && $demoCount > 10) {
                CLI::write("... and " . ($demoCount - 10) . " more demo rows. Pass --verbose to see all columns and rows.", 'dark_gray');
            }
            CLI::newLine();
        } else {
            CLI::write("CLEAN: No seeded demo rows detected in `provident_fund_ledgers`.", 'green');
            CLI::newLine();
        }

        // 3. SUSPICIOUS RECORDS SECTION
        if ($suspiciousCount > 0) {
            CLI::write("SUSPICIOUS RECORDS DETECTED (Review Manually - Not counted as demo):", 'yellow');
            $displaySuspicious = $isVerbose ? $suspiciousRows : array_slice($suspiciousRows, 0, 10);

            if ($isVerbose) {
                $suspHeaders = ['ID', 'Company', 'Employee', 'Date', 'Reason', 'Ref No', 'Payroll ID'];
                $suspTableData = [];
                foreach ($displaySuspicious as $sr) {
                    $suspTableData[] = [
                        $sr['id'],
                        $sr['company_id'],
                        $sr['employee_id'],
                        $sr['transaction_date'] ?? '-',
                        $sr['suspicious_reason'] ?? '-',
                        $sr['reference_no'] ?? '-',
                        $sr['payroll_id'] ?? '-',
                    ];
                }
            } else {
                $suspHeaders = ['ID', 'Company', 'Employee', 'Date', 'Reason'];
                $suspTableData = [];
                foreach ($displaySuspicious as $sr) {
                    $suspTableData[] = [
                        $sr['id'],
                        $sr['company_id'],
                        $sr['employee_id'],
                        $sr['transaction_date'] ?? '-',
                        $sr['suspicious_reason'] ?? '-',
                    ];
                }
            }

            $this->printFormattedTable($suspHeaders, $suspTableData);

            if (!$isVerbose && $suspiciousCount > 10) {
                CLI::write("... and " . ($suspiciousCount - 10) . " more suspicious rows. Pass --verbose to see all.", 'dark_gray');
            }
            CLI::newLine();
        }

        // 4. SAFE REMEDIATION ADVICE
        CLI::write("SAFE REMEDIATION INSTRUCTIONS FOR PRODUCTION:", 'yellow');
        CLI::write("1. Always back up the table before performing any deletion:");
        CLI::write("   CREATE TABLE provident_fund_ledgers_backup AS SELECT * FROM provident_fund_ledgers;", 'cyan');
        CLI::newLine();
        CLI::write("2. Inspect the exact demo rows using this safe SELECT query:");
        CLI::write("   " . $audit['select_sql'], 'white');
        CLI::newLine();
        CLI::write("3. Only after manual verification, execute the purge (commented out for safety):");
        CLI::write("   " . $audit['delete_sql'], 'dark_gray');
        CLI::newLine();
    }

    protected function printFormattedTable(array $headers, array $rows): void
    {
        $colWidths = [];
        foreach ($headers as $i => $h) {
            $colWidths[$i] = strlen($h);
        }

        foreach ($rows as $row) {
            foreach ($row as $i => $cell) {
                $colWidths[$i] = max($colWidths[$i], strlen((string)$cell));
            }
        }

        $headerLine = '';
        foreach ($headers as $i => $h) {
            $headerLine .= str_pad($h, $colWidths[$i] + 2);
        }
        CLI::write($headerLine, 'yellow');

        $sep = '';
        foreach ($colWidths as $w) {
            $sep .= str_repeat('-', $w + 2);
        }
        CLI::write($sep, 'dark_gray');

        foreach ($rows as $row) {
            $rowLine = '';
            foreach ($row as $i => $cell) {
                $rowLine .= str_pad((string)$cell, $colWidths[$i] + 2);
            }
            CLI::write($rowLine);
        }
    }
}

