<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use Config\Database;
use App\Services\AttendanceReportService;
use App\Services\ReportService;

/**
 * Class VerifyAttendanceReports
 *
 * Verifies all 22 Attendance & Time Management Reports for:
 * 1. Schema integrity & valid return structures (meta, headers, rows).
 * 2. Complete coverage of the 22 required reports.
 * 3. Multi-tenant isolation (no cross-tenant data leakage).
 * 4. DDE / CSV Formula injection sanitization defenses.
 *
 * Usage: php spark attendance:verify-reports
 */
class VerifyAttendanceReports extends BaseCommand
{
    protected $group       = 'Attendance';
    protected $name        = 'attendance:verify-reports';
    protected $description = 'Verifies all 22 Attendance & Time Management Reports with tenant isolation assertions.';
    protected $usage       = 'attendance:verify-reports';

    public function run(array $params)
    {
        CLI::write("==================================================================", 'cyan');
        CLI::write("    22 ATTENDANCE & TIME MANAGEMENT REPORTS VERIFICATION SUITE    ", 'yellow');
        CLI::write("==================================================================", 'cyan');

        $db = Database::connect();
        $reportService = new AttendanceReportService();

        // 1. Verify Catalog Completeness
        $catalog = AttendanceReportService::getReportCatalog();
        CLI::write("Verifying Report Catalog Completeness (22 Reports Expected)...", 'white');

        if (count($catalog) !== 22) {
            CLI::write("  -> FAILED: Expected exactly 22 reports in catalog, found: " . count($catalog), 'red');
            return 1;
        }
        CLI::write("  -> PASSED: All 22 Attendance & Time Management Reports registered.", 'green');

        // Create temporary isolated test companies
        $suffix = bin2hex(random_bytes(3));
        $compAId = 'comp-rep-a-' . $suffix;
        $compBId = 'comp-rep-b-' . $suffix;
        $empAId  = 'emp-rep-a-' . $suffix;
        $empBId  = 'emp-rep-b-' . $suffix;
        $deptAId = 'dept-rep-a-' . $suffix;
        $deptBId = 'dept-rep-b-' . $suffix;
        $shiftAId = 'shift-rep-a-' . $suffix;
        $logAId   = 'att-rep-a-' . $suffix;
        $logBId   = 'att-rep-b-' . $suffix;
        $corrAId  = 'corr-rep-a-' . $suffix;

        $passed = 0;
        $failed = 0;

        try {
            // Setup fixtures for Company A
            $db->table('companies')->insert([
                'id'         => $compAId,
                'name'       => 'Report Test Tenant Alpha',
                'code'       => 'REP_A_' . strtoupper($suffix),
                'status'     => 'Active',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

            $db->table('departments')->insert([
                'id'         => $deptAId,
                'company_id' => $compAId,
                'name'       => 'Engineering Alpha',
                'code'       => 'ENG_A',
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            $db->table('shifts')->insert([
                'id'         => $shiftAId,
                'company_id' => $compAId,
                'name'       => 'Morning Shift Alpha',
                'code'       => 'MS_A',
                'start_time' => '09:00:00',
                'end_time'   => '18:00:00',
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            $db->table('employees')->insert([
                'id'            => $empAId,
                'company_id'    => $compAId,
                'department_id' => $deptAId,
                'shift_id'      => $shiftAId,
                'employee_code' => 'EMP_A_' . strtoupper($suffix),
                'first_name'    => 'Rahim',
                'last_name'     => 'Ahmed',
                'joining_date'  => date('Y-m-01'),
                'status'        => 'Active',
                'created_at'    => date('Y-m-d H:i:s'),
            ]);

            // Setup fixtures for Company B
            $db->table('companies')->insert([
                'id'         => $compBId,
                'name'       => 'Report Test Tenant Beta',
                'code'       => 'REP_B_' . strtoupper($suffix),
                'status'     => 'Active',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

            $db->table('departments')->insert([
                'id'         => $deptBId,
                'company_id' => $compBId,
                'name'       => 'Operations Beta',
                'code'       => 'OPS_B',
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            $db->table('employees')->insert([
                'id'            => $empBId,
                'company_id'    => $compBId,
                'department_id' => $deptBId,
                'employee_code' => 'EMP_B_' . strtoupper($suffix),
                'first_name'    => 'Karim',
                'last_name'     => 'Chowdhury',
                'joining_date'  => date('Y-m-01'),
                'status'        => 'Active',
                'created_at'    => date('Y-m-d H:i:s'),
            ]);

            // Insert attendance log for Company A
            $attTable = $db->tableExists('attendance_logs') ? 'attendance_logs' : 'attendances';
            $db->table($attTable)->insert([
                'id'             => $logAId,
                'company_id'     => $compAId,
                'employee_id'    => $empAId,
                'shift_id'       => $shiftAId,
                'date'           => date('Y-m-d'),
                'check_in'       => '09:25:00',
                'check_out'      => '18:10:00',
                'working_hours'  => 8.75,
                'regular_hours'  => 8.00,
                'overtime_hours' => 0.75,
                'late_minutes'   => 25,
                'is_late'        => 1,
                'status'         => 'Late',
                'created_at'     => date('Y-m-d H:i:s'),
            ]);

            // Insert attendance log for Company B
            $db->table($attTable)->insert([
                'id'             => $logBId,
                'company_id'     => $compBId,
                'employee_id'    => $empBId,
                'date'           => date('Y-m-d'),
                'check_in'       => '09:00:00',
                'check_out'      => '18:00:00',
                'working_hours'  => 9.00,
                'status'         => 'Present',
                'created_at'     => date('Y-m-d H:i:s'),
            ]);

            // Insert correction for Company A
            if ($db->tableExists('attendance_corrections')) {
                $db->table('attendance_corrections')->insert([
                    'id'                 => $corrAId,
                    'company_id'         => $compAId,
                    'employee_id'        => $empAId,
                    'attendance_date'    => date('Y-m-d'),
                    'request_type'       => 'Check-in Adjustment',
                    'original_check_in'  => '09:25:00',
                    'proposed_check_in'  => '09:00:00',
                    'reason'             => 'Biometric device delayed scan',
                    'status'             => 'Approved',
                    'created_at'         => date('Y-m-d H:i:s'),
                ]);
            }

            // Test CSV Formula injection sanitization defense
            CLI::write("\nVerifying CSV Formula Injection Sanitization Defense...", 'white');
            $dangerousPayloads = [
                '=1+2',
                '@SUM(A1:A10)',
                '-5+10',
                '+cmd|calc',
                "=cmd|'/C calc'!A0",
                "\tDangerousTab",
                "%Formula",
            ];

            $allSanitized = true;
            foreach ($dangerousPayloads as $payload) {
                $cleaned = ReportService::sanitizeCell($payload);
                if (!str_starts_with($cleaned, "'")) {
                    $allSanitized = false;
                    CLI::write("  -> FAILED: Payload {$payload} was not escaped with leading single quote: {$cleaned}", 'red');
                }
            }
            if ($allSanitized) {
                CLI::write("  -> PASSED: All CSV formula triggers (=, +, -, @, tab, %) sanitized securely.", 'green');
            }

            CLI::newLine();
            CLI::write("Verifying Generation & Tenant Isolation of All 22 Reports:", 'cyan');

            $filtersA = [
                'from_date' => date('Y-m-01'),
                'to_date'   => date('Y-m-d'),
                'date'      => date('Y-m-d'),
                'year'      => (int)date('Y'),
                'month'     => (int)date('n'),
            ];

            foreach ($catalog as $code => $item) {
                $num   = $item['number'];
                $title = $item['title'];

                try {
                    $resultA = $reportService->generateReport($code, $compAId, $filtersA);

                    // Check return contract
                    if (!isset($resultA['meta']) || !isset($resultA['headers']) || !isset($resultA['rows'])) {
                        CLI::write("  [#{$num}] {$title}: FAILED (Missing meta/headers/rows array structure)", 'red');
                        $failed++;
                        continue;
                    }

                    if (empty($resultA['headers']) || !is_array($resultA['headers'])) {
                        CLI::write("  [#{$num}] {$title}: FAILED (Headers array is empty or invalid)", 'red');
                        $failed++;
                        continue;
                    }

                    // Check tenant isolation: Company B employee must NEVER appear in Company A report
                    $crossTenantLeak = false;
                    foreach ($resultA['rows'] as $row) {
                        $rowStr = implode(' ', array_map('strval', $row));
                        if (str_contains($rowStr, 'EMP_B_' . strtoupper($suffix)) || str_contains($rowStr, 'Karim Chowdhury')) {
                            $crossTenantLeak = true;
                            break;
                        }
                    }

                    if ($crossTenantLeak) {
                        CLI::write("  [#{$num}] {$title}: FAILED (CRITICAL: Company B employee found in Company A report!)", 'red');
                        $failed++;
                        continue;
                    }

                    CLI::write("  [#{$num}] {$title}: PASSED (" . count($resultA['rows']) . " rows, " . count($resultA['headers']) . " cols)", 'green');
                    $passed++;

                } catch (\Throwable $e) {
                    CLI::write("  [#{$num}] {$title}: EXCEPTION: " . $e->getMessage(), 'red');
                    $failed++;
                }
            }

        } finally {
            // Teardown test fixtures
            if (isset($corrAId) && $db->tableExists('attendance_corrections')) {
                $db->table('attendance_corrections')->where('id', $corrAId)->delete();
            }
            if (isset($logAId) && isset($logBId)) {
                $attTable = $db->tableExists('attendance_logs') ? 'attendance_logs' : 'attendances';
                $db->table($attTable)->whereIn('id', [$logAId, $logBId])->delete();
            }
            if (isset($empAId) && isset($empBId)) {
                $db->table('employees')->whereIn('id', [$empAId, $empBId])->delete();
            }
            if (isset($shiftAId)) {
                $db->table('shifts')->where('id', $shiftAId)->delete();
            }
            if (isset($deptAId) && isset($deptBId)) {
                $db->table('departments')->whereIn('id', [$deptAId, $deptBId])->delete();
            }
            if (isset($compAId) && isset($compBId)) {
                $db->table('companies')->whereIn('id', [$compAId, $compBId])->delete();
            }
        }

        CLI::newLine();
        CLI::write("==================================================================", 'cyan');
        CLI::write("FINAL RESULTS: {$passed} / 22 REPORTS PASSED | {$failed} FAILED", $failed === 0 ? 'green' : 'red');
        CLI::write("==================================================================", 'cyan');

        return $failed === 0 ? 0 : 1;
    }
}
