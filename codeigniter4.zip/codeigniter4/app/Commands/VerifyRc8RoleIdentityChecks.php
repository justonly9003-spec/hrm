<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Controllers\Users\RolePermissionController;
use App\Services\PermissionService;
use App\Models\UserModel;

class VerifyRc8RoleIdentityChecks extends BaseCommand
{
    protected $group       = 'Verification';
    protected $name        = 'verify:rc8-role-identity';
    protected $description = 'Verifies RC-8: Role-name identity checks, is_system guards, and privileged role identifier protection.';

    public function run(array $params)
    {
        CLI::write("==================================================================", 'cyan');
        CLI::write("    VERIFY RC-8: ROLE-NAME IDENTITY CHECKS & IS_SYSTEM GUARDS     ", 'yellow');
        CLI::write("==================================================================", 'cyan');

        $passed = 0;
        $failed = 0;

        // -------------------------------------------------------------
        // Check 1: RolePermissionController::isPrivilegedRoleIdentifier blocks aliases
        // -------------------------------------------------------------
        CLI::write("\n[Check 1] RolePermissionController::isPrivilegedRoleIdentifier blocks all privileged aliases...", 'white');

        $blockedIdentifiers = [
            'software_admin',
            'softwareadmin',
            'software_administrator',
            'softwareadministrator',
            'software_app_admin',
            'software_app_administrator',
            'r_sa',
            'role_sa',
            'role_super_admin',
            'company_admin',
            'companyadmin',
            'company_administrator',
            'r_ca',
            'role_ca',
            'role_company_admin',
            'super_admin',
            'superadmin',
            'super_administrator',
            'root',
            'admin',
            'administrator',
            'hr_admin',
            'hradmin',
            'hr_administrator',
            'r_hra',
            'role_hra',
        ];

        $check1Ok = true;
        foreach ($blockedIdentifiers as $identifier) {
            $isPrivCode = RolePermissionController::isPrivilegedRoleIdentifier('Custom Role', $identifier);
            $isPrivName = RolePermissionController::isPrivilegedRoleIdentifier($identifier, 'custom_code');

            if (!$isPrivCode) {
                CLI::error("  ✖ Code '{$identifier}' was NOT detected as privileged!");
                $check1Ok = false;
            }
            if (!$isPrivName) {
                CLI::error("  ✖ Name '{$identifier}' was NOT detected as privileged!");
                $check1Ok = false;
            }
        }

        // Allowed custom identifiers should NOT be blocked
        $allowedIdentifiers = [
            ['Accountant', 'accountant'],
            ['Compliance Officer', 'compliance_officer'],
            ['Field Agent', 'field_agent'],
            ['IT Support', 'it_support'],
            ['Software Engineer', 'software_engineer'],
            ['Sales Lead', 'sales_lead'],
        ];

        foreach ($allowedIdentifiers as $pair) {
            [$name, $code] = $pair;
            if (RolePermissionController::isPrivilegedRoleIdentifier($name, $code)) {
                CLI::error("  ✖ Legitimate custom role '{$name}' / '{$code}' was falsely flagged as privileged!");
                $check1Ok = false;
            }
        }

        if ($check1Ok) {
            CLI::write("  ✔ All privileged role identifiers and aliases are strictly blocked from creation/mimicry.", 'green');
            $passed++;
        } else {
            $failed++;
        }

        // -------------------------------------------------------------
        // Check 2: UserModel::getUserWithEmployeeContext platform admin guard
        // -------------------------------------------------------------
        CLI::write("\n[Check 2] UserModel::getUserWithEmployeeContext tenant clearance guard...", 'white');

        $permService = new PermissionService();

        // Simulate tenant user with a role named software_app_admin but having company_id
        $tenantUserRow = [
            'id'              => 'usr-test-001',
            'username'        => 'tenant_user',
            'company_id'      => 'comp-acme',
            'branch_id'       => 'br-01',
            'department_id'   => 'dept-01',
            'role_name'       => 'Software App Admin',
            'role_code'       => 'software_app_admin',
            'role_is_system'  => 0,
            'role_company_id' => 'comp-acme',
        ];

        $isSystemRole = (int)($tenantUserRow['role_is_system'] ?? 0) === 1;
        $isGlobalRole = empty($tenantUserRow['role_company_id']);
        $isGlobalUser = empty($tenantUserRow['company_id']);
        $canonicalRole = $permService->canonicalizeRole($tenantUserRow['role_code']);

        $shouldClearTenant = ($isSystemRole && $isGlobalRole && $isGlobalUser && $canonicalRole === 'software_app_admin');

        if (!$shouldClearTenant && $tenantUserRow['company_id'] === 'comp-acme') {
            CLI::write("  ✔ Tenant user with role named 'software_app_admin' preserves company_id and is not cleared to global.", 'green');
            $passed++;
        } else {
            CLI::error("  ✖ Tenant user was improperly elevated to global platform scope!");
            $failed++;
        }

        // -------------------------------------------------------------
        // Check 3: BaseController::isSoftwareAppAdmin identity verification logic
        // -------------------------------------------------------------
        CLI::write("\n[Check 3] BaseController::isSoftwareAppAdmin() requires is_system=1 AND company_id IS NULL...", 'white');

        // Create anonymous controller instance to test isSoftwareAppAdmin logic
        $testController = new class extends \App\Controllers\BaseController {
            public function setCurrentUserForTest(?array $user) {
                $this->currentUser = $user;
            }
        };

        $scenarios = [
            'Tenant user claiming software_app_admin' => [
                'user' => [
                    'id'              => 'usr-1',
                    'company_id'      => 'comp-01',
                    'role_code'       => 'software_app_admin',
                    'role_name'       => 'Software App Admin',
                    'role_is_system'  => 1,
                    'role_company_id' => null,
                ],
                'expected' => false,
            ],
            'Tenant role with is_system=0' => [
                'user' => [
                    'id'              => 'usr-2',
                    'company_id'      => null,
                    'role_code'       => 'software_app_admin',
                    'role_name'       => 'Software App Admin',
                    'role_is_system'  => 0,
                    'role_company_id' => null,
                ],
                'expected' => false,
            ],
            'Tenant-scoped role with company_id' => [
                'user' => [
                    'id'              => 'usr-3',
                    'company_id'      => null,
                    'role_code'       => 'software_app_admin',
                    'role_name'       => 'Software App Admin',
                    'role_is_system'  => 1,
                    'role_company_id' => 'comp-01',
                ],
                'expected' => false,
            ],
            'True Platform Admin (is_system=1, company_id=null)' => [
                'user' => [
                    'id'              => 'usr-root',
                    'company_id'      => null,
                    'role_code'       => 'software_app_admin',
                    'role_name'       => 'Software App Admin',
                    'role_is_system'  => 1,
                    'role_company_id' => null,
                ],
                'expected' => true,
            ],
        ];

        $check3Ok = true;
        foreach ($scenarios as $name => $spec) {
            $testController->setCurrentUserForTest($spec['user']);
            $actual = $testController->isSoftwareAppAdmin();
            if ($actual !== $spec['expected']) {
                CLI::error("  ✖ Scenario '{$name}': expected " . var_export($spec['expected'], true) . ", got " . var_export($actual, true));
                $check3Ok = false;
            }
        }

        if ($check3Ok) {
            CLI::write("  ✔ BaseController::isSoftwareAppAdmin accurately guards platform admin status.", 'green');
            $passed++;
        } else {
            $failed++;
        }

        // -------------------------------------------------------------
        // Check 4: PermissionService::validateTenantScope cross-tenant isolation
        // -------------------------------------------------------------
        CLI::write("\n[Check 4] PermissionService::validateTenantScope cross-tenant isolation...", 'white');

        $imposterUser = [
            'id'              => 'usr-imposter',
            'company_id'      => 'comp-alpha',
            'role_code'       => 'software_app_admin',
            'role_name'       => 'Software App Admin',
            'role_is_system'  => 0,
            'role_company_id' => 'comp-alpha',
        ];

        $trueRootUser = [
            'id'              => 'usr-root',
            'company_id'      => null,
            'role_code'       => 'software_app_admin',
            'role_name'       => 'Software App Admin',
            'role_is_system'  => 1,
            'role_company_id' => null,
        ];

        $imposterCanAccessBeta = $permService->validateTenantScope($imposterUser, 'comp-beta');
        $trueRootCanAccessBeta = $permService->validateTenantScope($trueRootUser, 'comp-beta');

        if (!$imposterCanAccessBeta && $trueRootCanAccessBeta) {
            CLI::write("  ✔ Imposter tenant user cannot access other tenants; True Root can access all tenants.", 'green');
            $passed++;
        } else {
            CLI::error("  ✖ Cross-tenant validation failed (imposter: " . var_export($imposterCanAccessBeta, true) . ", root: " . var_export($trueRootCanAccessBeta, true) . ")");
            $failed++;
        }

        // -------------------------------------------------------------
        // Summary
        // -------------------------------------------------------------
        CLI::write("\n==================================================================", 'cyan');
        CLI::write("RC-8 VERIFICATION RESULT: {$passed} PASSED, {$failed} FAILED", $failed === 0 ? 'green' : 'red');
        CLI::write("==================================================================", 'cyan');

        return $failed === 0 ? 0 : 1;
    }
}
