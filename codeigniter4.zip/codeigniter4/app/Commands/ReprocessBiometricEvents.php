<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Services\ZKTecoService;

class ReprocessBiometricEvents extends BaseCommand
{
    protected $group       = 'Biometric Hardware';
    protected $name        = 'biometric:reprocess';
    protected $description = 'Reprocesses raw biometric attendance events using the corrected ZKTeco binary packet parser, fixing corrupted device_user_id and event_time.';
    protected $usage       = 'biometric:reprocess [--device <device_id>] [--company <company_id>] [--limit <number>]';
    protected $arguments   = [];
    protected $options     = [
        '--device'  => 'Optional Device ID or Serial Number to filter records.',
        '--company' => 'Optional Company ID (e.g. COMP-TESTCO) to filter records.',
        '--limit'   => 'Maximum records to reprocess (default: all).',
    ];

    public function run(array $params)
    {
        CLI::write("================================================================", 'cyan');
        CLI::write("   ZKTECO RAW BIOMETRIC PACKET REPROCESSOR & AUDIT UTILITY      ", 'white', 'blue');
        CLI::write("================================================================", 'cyan');

        $deviceId = $params['device'] ?? CLI::getOption('device');
        $companyId = $params['company'] ?? CLI::getOption('company');
        $limit = (int)($params['limit'] ?? CLI::getOption('limit') ?? 0);

        CLI::write("Device Filter  : " . ($deviceId ?: 'ALL DEVICES'));
        CLI::write("Company Filter : " . ($companyId ?: 'ALL COMPANIES'));
        CLI::write("Record Limit   : " . ($limit > 0 ? $limit : 'UNLIMITED'));
        CLI::newLine();

        $service = new ZKTecoService();
        CLI::write("Starting binary re-parsing of raw_payload events...", 'yellow');

        $result = $service->reprocessBiometricEvents($deviceId, $companyId, $limit);

        CLI::newLine();
        CLI::write("================================================================", 'cyan');
        CLI::write("                   REPROCESSING SUMMARY                         ", 'white', 'green');
        CLI::write("================================================================", 'cyan');
        CLI::write("Total Inspected : " . number_format($result['total_processed']));
        CLI::write("Total Updated   : " . number_format($result['total_updated']));
        CLI::write("Employee Mapped : " . number_format($result['total_mapped']));
        CLI::write("Unmatched Staff : " . number_format($result['total_unmatched']) . " (preserved awaiting linking)");
        CLI::write("Errors          : " . number_format($result['total_errors']));

        if (!empty($result['sample_errors'])) {
            CLI::newLine();
            CLI::write("Sample Errors:", 'red');
            foreach ($result['sample_errors'] as $err) {
                CLI::write(" - {$err}", 'red');
            }
        }

        CLI::newLine();
        CLI::write("Reprocessing complete. raw_payload integrity preserved.", 'green');
    }
}
