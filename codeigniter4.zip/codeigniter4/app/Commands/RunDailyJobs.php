<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Services\Automation\ScheduledJobsService;

class RunDailyJobs extends BaseCommand
{
    protected $group       = 'Automation';
    protected $name        = 'cron:daily';
    protected $description = 'Executes Daily Automated Scheduled Jobs (Attendance processing, Missing punch detection, Late calculation, Leave balance updates, Notification queue)';
    protected $usage       = 'cron:daily [options]';
    protected $options     = [
        '--user' => 'User ID triggering the manual command',
        '--json' => 'Output results as pure JSON'
    ];

    public function run(array $params)
    {
        $jsonMode = array_key_exists('json', $params) || CLI::getOption('json');
        $userId = CLI::getOption('user') ?? 'CRON_SYSTEM';

        $service = new ScheduledJobsService();
        $startTime = microtime(true);

        if (!$jsonMode) {
            CLI::write("================================================================", 'cyan');
            CLI::write("       ENTERPRISE HRMS - DAILY SCHEDULED JOBS RUNNER            ", 'yellow');
            CLI::write("================================================================", 'cyan');
            CLI::write("Start Time : " . date('Y-m-d H:i:s'), 'white');
            CLI::newLine();
            CLI::write("1. Processing daily attendance muster...", 'yellow');
        }

        $result = $service->runDailyJobs('CLI_COMMAND', $userId);

        if (!$jsonMode) {
            CLI::write("   [OK] Attendance processing completed.", 'green');
            CLI::write("2. Scanning for missing punches & anomalies...", 'yellow');
            CLI::write("   [OK] Missing punch detection completed.", 'green');
            CLI::write("3. Calculating late arrival penalties...", 'yellow');
            CLI::write("   [OK] Late calculation completed.", 'green');
            CLI::write("4. Synchronizing leave ledgers & daily balances...", 'yellow');
            CLI::write("   [OK] Leave balances updated.", 'green');
            CLI::write("5. Flushing notification & email queue...", 'yellow');
            CLI::write("   [OK] Notification queue processed.", 'green');
            CLI::newLine();
            CLI::write("----------------------------------------------------------------", 'cyan');
            CLI::write("ALL DAILY JOBS COMPLETED IN " . $result['duration_ms'] . " ms", 'green');
            CLI::write("----------------------------------------------------------------", 'cyan');
        } else {
            CLI::write(json_encode($result, JSON_PRETTY_PRINT));
        }
    }
}
