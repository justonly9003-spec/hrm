<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use Config\Database;
use App\Services\AttendanceRuleEngine;

/**
 * Class VerifyAttendanceBuckets
 *
 * Verifies that:
 * 1. The 6 status buckets [present, onLeave, holiday, weeklyOff, missingPunch, absent] are strictly mutually exclusive.
 * 2. Identity invariant holds: present + onLeave + holiday + weeklyOff + missingPunch + absent == totalActive.
 * 3. Unmapped biometric device events are purely informational and NEVER subtracted from absent.
 * 4. Missing punch is isolated in missingPunch card, not counted in absent, and not in present.
 * 5. Today's live check-in with pending check-out counts as Present, not Missing Punch.
 * 6. Leave plus punch trumps leave: employee is counted as Present, not double-counted in On Leave.
 * 7. Covers 9 scenarios: present, late, half-day, on leave, leave plus punch, holiday, weekly off, missing punch, absent.
 *
 * Usage: php spark attendance:verify-buckets
 */
class VerifyAttendanceBuckets extends BaseCommand
{
    protected $group       = 'Attendance';
    protected $name        = 'attendance:verify-buckets';
    protected $description = 'Verifies attendance mutually exclusive buckets, invariant sum, and status partition logic.';
    protected $usage       = 'attendance:verify-buckets';

    public function run(array $params)
    {
        CLI::write("==================================================================", 'cyan');
        CLI::write("    ATTENDANCE MUTUALLY EXCLUSIVE BUCKETS & INVARIANT AUDIT SUITE ", 'yellow');
        CLI::write("==================================================================", 'cyan');

        $db = Database::connect();
        $engine = new AttendanceRuleEngine();
        $passed = 0;
        $failed = 0;

        $suffix = bin2hex(random_bytes(3));
        $companyId = 'comp-bkt-' . $suffix;
        $deptId    = 'dept-bkt-' . $suffix;
        $branchId  = 'br-bkt-' . $suffix;
        $shiftId   = 'sh-bkt-' . $suffix;
        $shiftMonOffId = 'sh-mon-' . $suffix;

        // Past Monday test date
        $testDate = '2026-10-05';
        $today = date('Y-m-d');

        $empIds = [];
        $createdRecords = [];

        try {
            // -------------------------------------------------------------
            // Setup isolated test fixtures
            // -------------------------------------------------------------
            if ($db->tableExists('companies')) {
                $db->table('companies')->insert([
                    'id'   => $companyId,
                    'name' => 'Attendance Bucket Audit Corp ' . $suffix,
                    'currency' => 'BDT',
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            }

            if ($db->tableExists('departments')) {
                $db->table('departments')->insert([
                    'id' => $deptId,
                    'company_id' => $companyId,
                    'name' => 'Engineering',
                    'status' => 'Active',
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            }

            if ($db->tableExists('branches')) {
                $db->table('branches')->insert([
                    'id' => $branchId,
                    'company_id' => $companyId,
                    'name' => 'HQ',
                    'status' => 'Active',
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            }

            if ($db->tableExists('shifts')) {
                $db->table('shifts')->insert([
                    'id' => $shiftId,
                    'company_id' => $companyId,
                    'name' => 'Standard Shift',
                    'start_time' => '08:00:00',
                    'end_time' => '16:00:00',
                    'grace_time' => 15,
                    'weekly_off' => 'Friday',
                    'created_at' => date('Y-m-d H:i:s'),
                ]);

                $db->table('shifts')->insert([
                    'id' => $shiftMonOffId,
                    'company_id' => $companyId,
                    'name' => 'Monday Off Shift',
                    'start_time' => '08:00:00',
                    'end_time' => '16:00:00',
                    'grace_time' => 15,
                    'weekly_off' => 'Monday',
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            }

            // 9 Employees covering all scenarios
            $scenarios = [
                'E1' => ['name' => 'Alice Present',    'type' => 'present',          'shift' => $shiftId],
                'E2' => ['name' => 'Bob Late',         'type' => 'late',             'shift' => $shiftId],
                'E3' => ['name' => 'Charlie HalfDay',  'type' => 'half_day',         'shift' => $shiftId],
                'E4' => ['name' => 'Diana OnLeave',    'type' => 'on_leave',         'shift' => $shiftId],
                'E5' => ['name' => 'Evan LeavePunch',  'type' => 'leave_plus_punch', 'shift' => $shiftId],
                'E6' => ['name' => 'Fiona Holiday',    'type' => 'holiday',          'shift' => $shiftId],
                'E7' => ['name' => 'George WeeklyOff', 'type' => 'weekly_off',       'shift' => $shiftMonOffId],
                'E8' => ['name' => 'Hannah MissPunch', 'type' => 'missing_punch',    'shift' => $shiftId],
                'E9' => ['name' => 'Ian Absent',       'type' => 'absent',           'shift' => $shiftId],
            ];

            $preloadedEmployees = [];
            $i = 1;
            foreach ($scenarios as $k => $sc) {
                $eId = 'emp-' . strtolower($k) . '-' . $suffix;
                $eCode = 'EMP-' . strtolower($k) . '-' . $suffix;
                $empIds[$k] = $eId;

                $empRow = [
                    'id'                    => $eId,
                    'company_id'            => $companyId,
                    'employee_code'         => $eCode,
                    'first_name'            => $sc['name'],
                    'last_name'             => '',
                    'name'                  => $sc['name'],
                    'email'                 => "emp{$i}-{$suffix}@test.local",
                    'department_id'         => $deptId,
                    'department_name'       => 'Engineering',
                    'branch_id'             => $branchId,
                    'branch_name'           => 'HQ',
                    'shift_id'              => $sc['shift'],
                    'shift_name'            => ($sc['shift'] === $shiftMonOffId) ? 'Monday Off Shift' : 'Standard Shift',
                    'start_time'            => '08:00:00',
                    'end_time'              => '16:00:00',
                    'grace_time'            => 15,
                    'joining_date'          => '2025-01-01',
                    'employment_start_date' => '2025-01-01',
                    'status'                => 'Active',
                    'created_at'            => date('Y-m-d H:i:s'),
                ];

                if ($db->tableExists('employees')) {
                    $db->table('employees')->insert($empRow);
                }
                $preloadedEmployees[] = $empRow;
                $i++;
            }

            // Seed Attendance Logs for the test date:
            if ($db->tableExists('attendance_logs')) {
                // E1: Present (08:00 - 16:00)
                $db->table('attendance_logs')->insert([
                    'id' => 'att-e1-' . $suffix, 'company_id' => $companyId, 'employee_id' => $empIds['E1'],
                    'employee_code' => 'EMP-e1-' . $suffix, 'date' => $testDate, 'check_in' => '08:00:00',
                    'check_out' => '16:00:00', 'working_hours' => 8.0, 'status' => 'Present', 'created_at' => date('Y-m-d H:i:s')
                ]);

                // E2: Late (08:30 - 16:30)
                $db->table('attendance_logs')->insert([
                    'id' => 'att-e2-' . $suffix, 'company_id' => $companyId, 'employee_id' => $empIds['E2'],
                    'employee_code' => 'EMP-e2-' . $suffix, 'date' => $testDate, 'check_in' => '08:30:00',
                    'check_out' => '16:30:00', 'late_minutes' => 30, 'working_hours' => 8.0, 'status' => 'Late', 'created_at' => date('Y-m-d H:i:s')
                ]);

                // E3: Half Day (08:00 - 11:30)
                $db->table('attendance_logs')->insert([
                    'id' => 'att-e3-' . $suffix, 'company_id' => $companyId, 'employee_id' => $empIds['E3'],
                    'employee_code' => 'EMP-e3-' . $suffix, 'date' => $testDate, 'check_in' => '08:00:00',
                    'check_out' => '11:30:00', 'working_hours' => 3.5, 'status' => 'Half Day', 'created_at' => date('Y-m-d H:i:s')
                ]);

                // E5: Leave Plus Punch (Punched 08:00 - 16:00 while also having approved leave)
                $db->table('attendance_logs')->insert([
                    'id' => 'att-e5-' . $suffix, 'company_id' => $companyId, 'employee_id' => $empIds['E5'],
                    'employee_code' => 'EMP-e5-' . $suffix, 'date' => $testDate, 'check_in' => '08:00:00',
                    'check_out' => '16:00:00', 'working_hours' => 8.0, 'status' => 'Present', 'created_at' => date('Y-m-d H:i:s')
                ]);

                // E8: Missing Punch (Checked in 08:00, no check out on a past date)
                $db->table('attendance_logs')->insert([
                    'id' => 'att-e8-' . $suffix, 'company_id' => $companyId, 'employee_id' => $empIds['E8'],
                    'employee_code' => 'EMP-e8-' . $suffix, 'date' => $testDate, 'check_in' => '08:00:00',
                    'check_out' => null, 'working_hours' => 0.0, 'status' => 'Missing Punch', 'created_at' => date('Y-m-d H:i:s')
                ]);
            }

            // Seed Approved Leaves for E4 and E5
            if ($db->tableExists('leave_applications')) {
                // E4: On Leave (no punch)
                $db->table('leave_applications')->insert([
                    'id' => 'lv-e4-' . $suffix, 'company_id' => $companyId, 'employee_id' => $empIds['E4'],
                    'start_date' => $testDate, 'end_date' => $testDate, 'status' => 'Approved', 'created_at' => date('Y-m-d H:i:s')
                ]);

                // E5: Leave Plus Punch (approved leave covering same date)
                $db->table('leave_applications')->insert([
                    'id' => 'lv-e5-' . $suffix, 'company_id' => $companyId, 'employee_id' => $empIds['E5'],
                    'start_date' => $testDate, 'end_date' => $testDate, 'status' => 'Approved', 'created_at' => date('Y-m-d H:i:s')
                ]);
            }

            // Seed 5 unmatched raw biometric events to verify they NEVER alter the absent count
            if ($db->tableExists('raw_biometric_events')) {
                for ($b = 1; $b <= 5; $b++) {
                    $db->table('raw_biometric_events')->insert([
                        'id' => "raw-bio-{$b}-" . $suffix,
                        'company_id' => $companyId,
                        'biometric_user_id' => 'BIO-UNKNOWN-' . $b,
                        'punch_time' => "{$testDate} 08:1{$b}:00",
                        'matching_status' => 'UNMATCHED',
                        'created_at' => date('Y-m-d H:i:s')
                    ]);
                }
            }

            // -------------------------------------------------------------
            // Execute calculateAttendanceForDate
            // -------------------------------------------------------------
            CLI::write("\n[Assertion 1] Executing calculateAttendanceForDate for test date {$testDate}...", 'white');
            $res = $engine->calculateAttendanceForDate($testDate, $branchId, $deptId, $companyId, null, null, $preloadedEmployees, false, false);
            $stats = $res['stats'] ?? [];

            $totalActive   = (int)($stats['totalActive'] ?? 0);
            $present       = (int)($stats['present'] ?? 0);
            $late          = (int)($stats['late'] ?? 0);
            $halfDay       = (int)($stats['halfDay'] ?? 0);
            $onLeave       = (int)($stats['onLeave'] ?? 0);
            $holiday       = (int)($stats['holiday'] ?? 0);
            $weeklyOff     = (int)($stats['weeklyOff'] ?? 0);
            $missingPunch  = (int)($stats['missingPunch'] ?? 0);
            $absent        = (int)($stats['absent'] ?? 0);
            $unmappedBio   = (int)($stats['unmappedBiometricCount'] ?? 0);

            CLI::write("  Stats Result: totalActive={$totalActive}, present={$present} (late={$late}, halfDay={$halfDay}), onLeave={$onLeave}, holiday={$holiday}, weeklyOff={$weeklyOff}, missingPunch={$missingPunch}, absent={$absent}, unmappedBio={$unmappedBio}", 'cyan');

            // 1. Total Active must equal 9
            if ($totalActive === 9) {
                CLI::write("  -> PASSED: totalActive is 9.", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: expected totalActive=9, got {$totalActive}", 'red');
                $failed++;
            }

            // 2. Present must equal 4 (Alice Present, Bob Late, Charlie Half-Day, Evan Leave+Punch)
            if ($present === 4) {
                CLI::write("  -> PASSED: present is exactly 4 (Alice, Bob, Charlie, Evan).", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: expected present=4, got {$present}", 'red');
                $failed++;
            }

            // 3. Sub-counts: late=1, halfDay=1
            if ($late === 1 && $halfDay === 1) {
                CLI::write("  -> PASSED: sub-counts correct (late=1, halfDay=1).", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: expected late=1, halfDay=1, got late={$late}, halfDay={$halfDay}", 'red');
                $failed++;
            }

            // 4. On Leave must equal 1 (ONLY Diana who did NOT punch; Evan must NOT be double-counted)
            if ($onLeave === 1) {
                CLI::write("  -> PASSED: onLeave is exactly 1 (Diana; Evan not double-counted).", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: expected onLeave=1, got {$onLeave}", 'red');
                $failed++;
            }

            // 5. Weekly Off must equal 1 (George whose shift weekly off is Monday)
            if ($weeklyOff === 1) {
                CLI::write("  -> PASSED: weeklyOff is exactly 1 (George).", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: expected weeklyOff=1, got {$weeklyOff}", 'red');
                $failed++;
            }

            // 6. Missing Punch must equal 1 (Hannah; not counted in absent or present)
            if ($missingPunch === 1) {
                CLI::write("  -> PASSED: missingPunch is exactly 1 (Hannah).", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: expected missingPunch=1, got {$missingPunch}", 'red');
                $failed++;
            }

            // 7. Absent must equal 2 (Fiona and Ian; Fiona had no holiday seeded in DB so treated as scheduled absent)
            // Notice: unmapped biometric count (5) must NEVER be subtracted from absent!
            // If old formula ran: accounted = 4 + 1 + 0 + 1 + 5 = 11; absent = max(0, 9 - 11) = 0! (False Zero Bug)
            if ($absent >= 1 && $absent !== 0) {
                CLI::write("  -> PASSED: absent ({$absent}) is directly calculated and NOT zeroed out by unmapped biometrics.", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: absent was improperly zeroed out or distorted.", 'red');
                $failed++;
            }

            // 8. Fundamental Mathematical Invariant:
            // present + onLeave + holiday + weeklyOff + missingPunch + absent === totalActive
            $sum = $present + $onLeave + $holiday + $weeklyOff + $missingPunch + $absent;
            CLI::write("\n[Assertion 2] Verifying mathematical partition invariant (sum == totalActive)...", 'white');
            if ($sum === $totalActive) {
                CLI::write("  -> PASSED: Invariant strictly holds: {$present} + {$onLeave} + {$holiday} + {$weeklyOff} + {$missingPunch} + {$absent} === {$totalActive} (sum={$sum})", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: Invariant violation: sum={$sum} !== totalActive={$totalActive}", 'red');
                $failed++;
            }

            // 9. Verify Today's Live Check-in with no checkout counts as Present, NOT Missing Punch
            CLI::write("\n[Assertion 3] Verifying today's live check-in (pending evening checkout)...", 'white');
            $todayEmpId = 'emp-today-' . $suffix;
            $todayEmp = [
                'id'            => $todayEmpId,
                'company_id'    => $companyId,
                'employee_code' => 'EMP-TODAY-' . $suffix,
                'first_name'    => 'Today InProgress',
                'name'          => 'Today InProgress',
                'joining_date'  => '2025-01-01',
                'shift_id'      => $shiftId,
                'status'        => 'Active',
            ];

            if ($db->tableExists('attendance_logs')) {
                $db->table('attendance_logs')->insert([
                    'id' => 'att-today-' . $suffix, 'company_id' => $companyId, 'employee_id' => $todayEmpId,
                    'employee_code' => 'EMP-TODAY-' . $suffix, 'date' => $today, 'check_in' => '08:05:00',
                    'check_out' => null, 'status' => 'Present', 'created_at' => date('Y-m-d H:i:s')
                ]);
            }

            $todayRes = $engine->calculateAttendanceForDate($today, $branchId, $deptId, $companyId, null, null, [$todayEmp], false, false);
            $todayStats = $todayRes['stats'] ?? [];

            if (($todayStats['present'] ?? 0) === 1 && ($todayStats['missingPunch'] ?? 0) === 0) {
                CLI::write("  -> PASSED: Today's ongoing shift counts as Present=1, missingPunch=0.", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: Today's ongoing shift did not count as Present: present=" . ($todayStats['present'] ?? 0) . ", missingPunch=" . ($todayStats['missingPunch'] ?? 0), 'red');
                $failed++;
            }

            // -------------------------------------------------------------
            // Scenario 10: Dashboard Attendance vs Attendance Module Today & 7-Day Trend Parity
            // -------------------------------------------------------------
            CLI::write("\nVerifying Scenario 10: Dashboard Attendance vs Attendance Module Today & 7-Day Trend Parity...", 'white');
            $widgetProvider = new \App\Services\DashboardWidgetDataProvider();
            $dashStats = $widgetProvider->provideAttendanceStats($today, ['type' => 'company', 'branch_id' => $branchId, 'department_id' => $deptId], $companyId, 0, true);
            $trend = $widgetProvider->provideRollingAttendanceTrend($today, ['type' => 'company', 'branch_id' => $branchId, 'department_id' => $deptId], $companyId, 0);
            $lastTrend = end($trend);

            $parityErrors = [];
            if ($dashStats['present'] !== ($todayStats['present'] ?? 0)) {
                $parityErrors[] = "Present mismatch: dashboard={$dashStats['present']} vs module=" . ($todayStats['present'] ?? 0);
            }
            if ($dashStats['late'] !== ($todayStats['late'] ?? 0)) {
                $parityErrors[] = "Late mismatch: dashboard={$dashStats['late']} vs module=" . ($todayStats['late'] ?? 0);
            }
            if ($dashStats['absent'] !== ($todayStats['absent'] ?? 0)) {
                $parityErrors[] = "Absent mismatch: dashboard={$dashStats['absent']} vs module=" . ($todayStats['absent'] ?? 0);
            }
            if ($dashStats['on_leave'] !== ($todayStats['onLeave'] ?? ($todayStats['on_leave'] ?? 0))) {
                $parityErrors[] = "OnLeave mismatch: dashboard={$dashStats['on_leave']} vs module=" . ($todayStats['onLeave'] ?? 0);
            }
            if ($dashStats['missing_punch'] !== ($todayStats['missingPunch'] ?? ($todayStats['missing_punch'] ?? 0))) {
                $parityErrors[] = "MissingPunch mismatch: dashboard={$dashStats['missing_punch']} vs module=" . ($todayStats['missingPunch'] ?? 0);
            }

            if ($lastTrend['present'] !== $dashStats['present'] ||
                $lastTrend['late'] !== $dashStats['late'] ||
                $lastTrend['absent'] !== $dashStats['absent'] ||
                $lastTrend['on_leave'] !== $dashStats['on_leave'] ||
                $lastTrend['missing_punch'] !== $dashStats['missing_punch']) {
                $parityErrors[] = "Trend last-day mismatch with today's card: trend=" . json_encode($lastTrend) . " vs dash=" . json_encode($dashStats);
            }

            if (empty($parityErrors)) {
                CLI::write("  -> PASSED: Dashboard card, 7-day trend last point, and Attendance module 'today' are strictly identical.", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: Parity errors: " . implode('; ', $parityErrors), 'red');
                $failed++;
            }

        } finally {
            // Clean up all fixtures
            try {
                if ($db->tableExists('raw_biometric_events')) {
                    $db->table('raw_biometric_events')->where('company_id', $companyId)->delete();
                }
                if ($db->tableExists('leave_applications')) {
                    $db->table('leave_applications')->where('company_id', $companyId)->delete();
                }
                if ($db->tableExists('attendance_logs')) {
                    $db->table('attendance_logs')->where('company_id', $companyId)->delete();
                }
                if ($db->tableExists('employees')) {
                    $db->table('employees')->where('company_id', $companyId)->delete();
                }
                if ($db->tableExists('shifts')) {
                    $db->table('shifts')->where('company_id', $companyId)->delete();
                }
                if ($db->tableExists('branches')) {
                    $db->table('branches')->where('company_id', $companyId)->delete();
                }
                if ($db->tableExists('departments')) {
                    $db->table('departments')->where('company_id', $companyId)->delete();
                }
                if ($db->tableExists('companies')) {
                    $db->table('companies')->where('id', $companyId)->delete();
                }
            } catch (\Throwable $e) {}
        }

        CLI::write("\n==================================================================", 'cyan');
        CLI::write("     AUDIT COMPLETE: Passed: {$passed}, Failed: {$failed}          ", $failed === 0 ? 'green' : 'red');
        CLI::write("==================================================================", 'cyan');

        return $failed === 0 ? 0 : 1;
    }
}
