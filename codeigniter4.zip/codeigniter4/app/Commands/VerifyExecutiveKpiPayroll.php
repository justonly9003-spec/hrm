<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use Config\Database;
use App\Services\DashboardWidgetRegistry;
use App\Services\DashboardWidgetDataProvider;
use App\Services\PermissionService;

/**
 * VerifyExecutiveKpiPayroll Command
 *
 * Verifies that:
 * 1. The widget 'company_executive_kpis' contains 'monthly_payroll' in its data_dependencies.
 * 2. When a payroll run exists for the current month, providePayrollSummary() runs and returns the exact net total.
 * 3. The executive KPI card view renders the exact same payroll total with the company currency (not '$').
 * 4. Permissions are strictly respected: users with payroll view permission see the total,
 *    while users without permission see '—'.
 *
 * Usage: php spark verify:executive-kpi-payroll
 */
class VerifyExecutiveKpiPayroll extends BaseCommand
{
    protected $group       = 'Verification';
    protected $name        = 'verify:executive-kpi-payroll';
    protected $description = 'Verifies executive KPI card payroll dependency, currency formatting, and RBAC view permissions';
    protected $usage       = 'verify:executive-kpi-payroll';

    public function run(array $params)
    {
        CLI::write("==================================================================", 'cyan');
        CLI::write("      EXECUTIVE KPI PAYROLL SUMMARY & RBAC VERIFICATION SUITE      ", 'yellow');
        CLI::write("==================================================================", 'cyan');

        $db = Database::connect();
        $permService = new PermissionService($db);
        $dataProvider = new DashboardWidgetDataProvider();

        $passed = 0;
        $failed = 0;

        $suffix = bin2hex(random_bytes(4));
        $companyId   = 'comp-kpi-' . $suffix;
        $employeeId  = 'emp-kpi-' . $suffix;
        $adminUserId = 'usr-admin-' . $suffix;
        $empUserId   = 'usr-emp-' . $suffix;
        $adminRoleId = 'role-cadmin-' . $suffix;
        $empRoleId   = 'role-emp-' . $suffix;
        $payrollId   = 'pr-kpi-' . $suffix;
        $itemId      = 'pi-kpi-' . $suffix;

        $currentMonth = date('Y-m');
        $currentMonthNum = (int)date('m');
        $currentYear = (int)date('Y');
        $testNetSalary = 54321.00;

        try {
            // -------------------------------------------------------------
            // ASSERTION 1: Widget registry dependency check
            // -------------------------------------------------------------
            CLI::write("[Assertion 1] Checking 'company_executive_kpis' data_dependencies in registry...", 'white');
            $catalogDef = DashboardWidgetRegistry::getByCode('company_executive_kpis');
            $deps = $catalogDef['data_dependencies'] ?? [];

            if (in_array('monthly_payroll', $deps, true)) {
                CLI::write("  -> PASSED: 'monthly_payroll' is properly registered in data_dependencies.", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: 'monthly_payroll' missing from company_executive_kpis data_dependencies.", 'red');
                $failed++;
            }

            // -------------------------------------------------------------
            // Setup test fixtures
            // -------------------------------------------------------------
            CLI::write("[Setup] Inserting isolated test company, roles, employees, and payroll fixtures...", 'white');

            // 1. Company with currency BDT (not USD or $)
            $db->table('companies')->insert([
                'id'              => $companyId,
                'name'            => 'Apex KPI Test Corp ' . $suffix,
                'code'            => 'KPI-' . strtoupper($suffix),
                'currency'        => 'BDT',
                'currency_symbol' => '৳',
                'status'          => 'active',
                'created_at'      => date('Y-m-d H:i:s'),
                'updated_at'      => date('Y-m-d H:i:s'),
            ]);

            // 2. Roles
            $db->table('roles')->insert([
                'id'          => $adminRoleId,
                'company_id'  => $companyId,
                'code'        => 'company_admin',
                'name'        => 'Company Admin',
                'status'      => 'Active',
                'created_at'  => date('Y-m-d H:i:s'),
            ]);

            $db->table('roles')->insert([
                'id'          => $empRoleId,
                'company_id'  => $companyId,
                'code'        => 'employee',
                'name'        => 'Employee',
                'status'      => 'Active',
                'created_at'  => date('Y-m-d H:i:s'),
            ]);

            // 3. Permissions for admin
            $permRows = $db->table('permissions')->whereIn('code', ['dashboard.view', 'payroll.view'])->get()->getResultArray();
            $existingPermCodes = array_column($permRows, 'code');

            if (!in_array('dashboard.view', $existingPermCodes, true)) {
                $db->table('permissions')->insert([
                    'id'         => 'perm-dash-' . $suffix,
                    'code'       => 'dashboard.view',
                    'module'     => 'dashboard',
                    'action'     => 'view',
                    'name'       => 'Dashboard View',
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            }
            if (!in_array('payroll.view', $existingPermCodes, true)) {
                $db->table('permissions')->insert([
                    'id'         => 'perm-pay-' . $suffix,
                    'code'       => 'payroll.view',
                    'module'     => 'payroll',
                    'action'     => 'view',
                    'name'       => 'Payroll View',
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            }

            // Grant dashboard.view and payroll.view to admin
            $db->table('role_permissions')->insert([
                'id'            => 'rp-adm-dash-' . $suffix,
                'role_id'       => $adminRoleId,
                'company_id'    => $companyId,
                'permission_id' => 'payroll.view',
                'created_at'    => date('Y-m-d H:i:s'),
            ]);

            // 4. Employee & Users
            $db->table('employees')->insert([
                'id'            => $employeeId,
                'company_id'    => $companyId,
                'employee_code' => 'EMP-' . strtoupper($suffix),
                'first_name'    => 'Rahim',
                'last_name'     => 'Uddin',
                'status'        => 'Active',
                'created_at'    => date('Y-m-d H:i:s'),
            ]);

            $db->table('users')->insert([
                'id'          => $adminUserId,
                'company_id'  => $companyId,
                'role_id'     => $adminRoleId,
                'username'    => 'admin_' . $suffix,
                'email'       => 'admin_' . $suffix . '@example.com',
                'status'      => 'Active',
                'created_at'  => date('Y-m-d H:i:s'),
            ]);

            $db->table('users')->insert([
                'id'          => $empUserId,
                'company_id'  => $companyId,
                'role_id'     => $empRoleId,
                'employee_id' => $employeeId,
                'username'    => 'emp_' . $suffix,
                'email'       => 'emp_' . $suffix . '@example.com',
                'status'      => 'Active',
                'created_at'  => date('Y-m-d H:i:s'),
            ]);

            // 5. Create payroll run for the current month
            $db->table('payrolls')->insert([
                'id'               => $payrollId,
                'company_id'       => $companyId,
                'payroll_month'    => $currentMonth,
                'month'            => $currentMonthNum,
                'year'             => $currentYear,
                'status'           => 'Approved',
                'is_locked'        => 1,
                'total_employees'  => 1,
                'basic_salary'     => 40000.00,
                'gross_salary'     => 60000.00,
                'total_deductions' => 5679.00,
                'net_disbursed'    => $testNetSalary,
                'net_salary'       => $testNetSalary,
                'created_at'       => date('Y-m-d H:i:s'),
            ]);

            if ($db->tableExists('payroll_items')) {
                $db->table('payroll_items')->insert([
                    'id'           => $itemId,
                    'company_id'   => $companyId,
                    'payroll_id'   => $payrollId,
                    'employee_id'  => $employeeId,
                    'basic_salary' => 40000.00,
                    'gross_salary' => 60000.00,
                    'net_salary'   => $testNetSalary,
                    'created_at'   => date('Y-m-d H:i:s'),
                ]);
            }

            PermissionService::clearCache();

            // -------------------------------------------------------------
            // ASSERTION 2: Data Provider calculates exact payroll for authorized user
            // -------------------------------------------------------------
            CLI::write("[Assertion 2] Invoking data provider for authorized user (company_admin)...", 'white');
            $activeWidgets = [
                [
                    'id'        => 'wdg-kpi-01',
                    'code'      => 'company_executive_kpis',
                    'status'    => 1,
                    'is_visible'=> 1,
                ]
            ];

            $adminPayload = $dataProvider->provideDataForActiveWidgets(
                $activeWidgets,
                'company_admin',
                $companyId,
                $adminUserId,
                ['type' => 'company', 'company_id' => $companyId]
            );

            $adminPayroll = (float)($adminPayload['monthly_payroll'] ?? 0.0);
            if (abs($adminPayroll - $testNetSalary) < 0.01) {
                CLI::write("  -> PASSED: providePayrollSummary returned exact net total ({$adminPayroll}).", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: Expected {$testNetSalary}, got {$adminPayroll}.", 'red');
                $failed++;
            }

            // -------------------------------------------------------------
            // ASSERTION 3: Executive KPI view renders the amount with company currency (not '$')
            // -------------------------------------------------------------
            CLI::write("[Assertion 3] Checking rendered executive KPI card HTML for authorized user...", 'white');
            $companyRow = $db->table('companies')->where('id', $companyId)->get()->getRowArray();
            $viewData = [
                'company' => $companyRow,
                'metrics' => [
                    'current_month_name' => date('F Y'),
                    'workforce'          => $adminPayload,
                    'data'               => $adminPayload,
                ],
            ];

            $renderedHtml = view('dashboard/widgets/executive_kpis', $viewData);

            $formattedExpected = number_format($testNetSalary, 2);
            $hasFormattedTotal = strpos($renderedHtml, $formattedExpected) !== false;
            $hasCompanyCurrency = strpos($renderedHtml, 'BDT') !== false;
            $hasDollarSignIcon = strpos($renderedHtml, 'data-lucide="dollar-sign"') !== false;

            if ($hasFormattedTotal && $hasCompanyCurrency && !$hasDollarSignIcon) {
                CLI::write("  -> PASSED: Card shows 'BDT {$formattedExpected}' and currency-neutral icon.", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: HTML output mismatch (hasFormatted={$hasFormattedTotal}, hasCurrency={$hasCompanyCurrency}, hasDollarIcon={$hasDollarSignIcon}).", 'red');
                $failed++;
            }

            // -------------------------------------------------------------
            // ASSERTION 4: Data Provider withholds payroll from unauthorized user
            // -------------------------------------------------------------
            CLI::write("[Assertion 4] Invoking data provider for unauthorized user (employee)...", 'white');
            $empPayload = $dataProvider->provideDataForActiveWidgets(
                $activeWidgets,
                'employee',
                $companyId,
                $empUserId,
                ['type' => 'company', 'company_id' => $companyId]
            );

            $empCanView = $empPayload['can_view_payroll'] ?? false;
            $empPayroll = $empPayload['monthly_payroll'];

            if ($empCanView === false && $empPayroll === null) {
                CLI::write("  -> PASSED: Unauthorized user cannot view payroll; monthly_payroll is null.", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: Payroll was not withheld from unauthorized user.", 'red');
                $failed++;
            }

            // -------------------------------------------------------------
            // ASSERTION 5: Executive KPI view renders '—' for unauthorized user
            // -------------------------------------------------------------
            CLI::write("[Assertion 5] Checking rendered executive KPI card HTML for unauthorized user...", 'white');
            $empViewData = [
                'company' => $companyRow,
                'metrics' => [
                    'current_month_name' => date('F Y'),
                    'workforce'          => $empPayload,
                    'data'               => $empPayload,
                ],
            ];

            $empRenderedHtml = view('dashboard/widgets/executive_kpis', $empViewData);
            $hasEmDash = strpos($empRenderedHtml, '—') !== false;
            $leaksAmount = strpos($empRenderedHtml, $formattedExpected) !== false;

            if ($hasEmDash && !$leaksAmount) {
                CLI::write("  -> PASSED: Card displays '—' and does not leak payroll figures.", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: Em-dash missing or amount leaked in unauthorized view.", 'red');
                $failed++;
            }

        } finally {
            // Teardown test fixtures
            if ($db->tableExists('payroll_items')) {
                $db->table('payroll_items')->where('id', $itemId)->delete();
            }
            $db->table('payrolls')->where('id', $payrollId)->delete();
            $db->table('role_permissions')->where('id', 'rp-adm-dash-' . $suffix)->delete();
            $db->table('users')->whereIn('id', [$adminUserId, $empUserId])->delete();
            $db->table('employees')->where('id', $employeeId)->delete();
            $db->table('roles')->whereIn('id', [$adminRoleId, $empRoleId])->delete();
            $db->table('companies')->where('id', $companyId)->delete();
            $db->table('permissions')->whereIn('id', ['perm-dash-' . $suffix, 'perm-pay-' . $suffix])->delete();

            PermissionService::clearCache();
        }

        CLI::newLine();
        CLI::write("------------------------------------------------------------------", 'cyan');
        CLI::write("VERIFICATION RESULTS: {$passed} PASSED / {$failed} FAILED", $failed === 0 ? 'green' : 'red');
        CLI::write("------------------------------------------------------------------", 'cyan');

        return $failed === 0 ? 0 : 1;
    }
}
