<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Models\BiometricDeviceModel;
use App\Services\ZKTecoService;

class BiometricSync extends BaseCommand
{
    /**
     * The Command's Group
     *
     * @var string
     */
    protected $group = 'Attendance';

    /**
     * The Command's Name
     *
     * @var string
     */
    protected $name = 'biometric:sync';

    /**
     * The Command's Description
     *
     * @var string
     */
    protected $description = 'Synchronizes attendance records from active biometric devices via ZKTeco socket protocol.';

    /**
     * The Command's Usage
     *
     * @var string
     */
    protected $usage = 'biometric:sync [--company <company_id>] [--device <device_id>] [--fresh]';

    /**
     * The Command's Arguments
     *
     * @var array
     */
    protected $arguments = [];

    /**
     * The Command's Options
     *
     * @var array
     */
    protected $options = [
        '--company' => 'Optional Company ID (e.g. COMP-MERCURY) to filter devices.',
        '--device'  => 'Optional Biometric Device ID (e.g. DEV-12345678) to sync a single device.',
        '--fresh'   => 'Force full/fresh synchronization ignoring last_sync_at cutoff timestamp.',
    ];

    /**
     * Actually run the command.
     *
     * @param array $params
     * @return int
     */
    public function run(array $params)
    {
        $lockPath = defined('WRITEPATH')
            ? (rtrim(WRITEPATH, '/\\') . DIRECTORY_SEPARATOR . 'biometric_sync.lock')
            : (dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'writable' . DIRECTORY_SEPARATOR . 'biometric_sync.lock');

        $lockDir = dirname($lockPath);
        if (!is_dir($lockDir)) {
            @mkdir($lockDir, 0777, true);
        }

        $lockHandle = @fopen($lockPath, 'c+');
        if (!$lockHandle || !flock($lockHandle, LOCK_EX | LOCK_NB)) {
            CLI::write('Another biometric sync process is already running (locked by writable/biometric_sync.lock). Exiting.', 'yellow');
            if ($lockHandle) {
                fclose($lockHandle);
            }
            return 0;
        }

        ftruncate($lockHandle, 0);
        fwrite($lockHandle, (string) getmypid() . "\n" . date('Y-m-d H:i:s'));
        fflush($lockHandle);

        try {
            CLI::write("================================================================", 'cyan');
            CLI::write("           HRMS BIOMETRIC HARDWARE ATTENDANCE SYNC              ", 'white', 'blue');
            CLI::write("================================================================", 'cyan');

            $companyId = $params['company'] ?? CLI::getOption('company');
            $deviceId  = $params['device'] ?? CLI::getOption('device');

            $freshOption = $params['fresh'] ?? CLI::getOption('fresh');
            $fresh = ($freshOption !== null && $freshOption !== false && $freshOption !== '0' && $freshOption !== 'false');

            CLI::write('Company Filter : ' . ($companyId ?: 'ALL COMPANIES'));
            CLI::write('Device Filter  : ' . ($deviceId ?: 'ALL ACTIVE DEVICES'));
            CLI::write('Sync Mode      : ' . ($fresh ? 'FRESH / FULL PULL' : 'INCREMENTAL'));
            CLI::newLine();

            $deviceModel = new BiometricDeviceModel();
            $builder = $deviceModel->groupStart()
                ->where('is_active', 1)
                ->orWhere('is_active IS NULL')
                ->groupEnd();

            if (!empty($companyId)) {
                $builder->where('company_id', $companyId);
            }

            if (!empty($deviceId)) {
                $builder->where('id', $deviceId);
            }

            $devices = $builder->findAll();

            if (empty($devices)) {
                CLI::write('No active biometric devices found matching the specified criteria.', 'yellow');
                return 0;
            }

            $totalDevices = count($devices);
            $totalSynced  = 0;
            $successCount = 0;
            $failedCount  = 0;

            CLI::write("Found {$totalDevices} active biometric device(s) to synchronize.", 'cyan');
            CLI::newLine();

            $service = new ZKTecoService();

            foreach ($devices as $index => $dev) {
                $id           = $dev['id'];
                $devCompanyId = $dev['company_id'] ?: $companyId;
                $devName      = $dev['device_name'] ?? $id;
                $ip           = $dev['ip_address'] ?? 'unknown IP';
                $port         = (int) ($dev['port'] ?? 4370);

                CLI::write(sprintf('[%d/%d] Connecting to %s (%s:%d)...', $index + 1, $totalDevices, $devName, $ip, $port), 'white');

                try {
                    $res = $service->syncDevice($id, 'Scheduled CLI', $devCompanyId, $fresh);

                    if (!empty($res['success'])) {
                        $records = (int) ($res['synced_records'] ?? 0);
                        $totalSynced += $records;
                        $successCount++;
                        CLI::write("  ✔ [SUCCESS] {$records} records synced. " . ($res['message'] ?? ''), 'green');
                    } else {
                        $failedCount++;
                        CLI::write('  ✖ [FAILED] ' . ($res['message'] ?? 'Device sync returned false.'), 'red');
                    }
                } catch (\Throwable $e) {
                    $failedCount++;
                    CLI::write("  ✖ [EXCEPTION] Device '{$devName}' failed: " . $e->getMessage(), 'red');
                    log_message('error', "BiometricSync CLI exception for device {$id}: " . $e->getMessage());
                }
            }

            CLI::newLine();
            CLI::write("================================================================", 'cyan');
            CLI::write("                   SYNCHRONIZATION SUMMARY                      ", 'white', 'green');
            CLI::write("================================================================", 'cyan');
            CLI::write("Total Devices Processed : {$totalDevices}");
            CLI::write("Successful Devices      : {$successCount}", 'green');
            CLI::write("Failed Devices          : {$failedCount}", $failedCount > 0 ? 'red' : 'green');
            CLI::write("Total Records Synced    : {$totalSynced}", 'cyan');
            CLI::newLine();

            return $failedCount > 0 ? 1 : 0;
        } finally {
            flock($lockHandle, LOCK_UN);
            fclose($lockHandle);
            @unlink($lockPath);
        }
    }
}
