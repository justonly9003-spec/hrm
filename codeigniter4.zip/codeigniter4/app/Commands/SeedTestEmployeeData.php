<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Database\Seeds\EmployeeTestSeeder;

class SeedTestEmployeeData extends BaseCommand
{
    protected $group       = 'Database';
    protected $name        = 'seed:employee';
    protected $description = 'Seeds dedicated test company (TEST-PAYROLL-001) with exactly 9 employees for payroll/OT/PF/gratuity validation.';
    protected $usage       = 'seed:employee [--reset]';
    protected $options     = [
        '--reset' => 'Safely purge the test company dataset without affecting any other tenant data.',
    ];

    public function run(array $params)
    {
        $reset = CLI::getOption('reset');
        if ($reset) {
            $GLOBALS['argv'][] = '--reset';
        }

        $seeder = new EmployeeTestSeeder(new \Config\Database());
        $seeder->run();
    }
}
