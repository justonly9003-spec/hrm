<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Services\Automation\ScheduledJobsService;

class RunModule06Lifecycle extends BaseCommand
{
    protected $group       = 'Automation';
    protected $name        = 'cron:module06';
    protected $description = 'Executes Module 06 Lifecycle Automation Jobs (Job expiration, Training completion, Goal milestone tracking)';
    protected $usage       = 'cron:module06 [options]';
    protected $options     = [
        '--user' => 'User ID triggering the command',
        '--json' => 'Output results as pure JSON'
    ];

    public function run(array $params)
    {
        $userId = CLI::getOption('user') ?? 'CRON_SYSTEM';
        $service = new ScheduledJobsService();
        $result = $service->syncModule06LifecycleJobs($userId);

        CLI::write(json_encode($result));
    }
}
