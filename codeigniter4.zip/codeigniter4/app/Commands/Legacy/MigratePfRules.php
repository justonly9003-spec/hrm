<?php

/**
 * legacy one-time migration
 */

namespace App\Commands\Legacy;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use Config\Database;
use App\Models\CompanyModel;
use App\Services\Rules\RuleSchemaRegistry;

class MigratePfRules extends BaseCommand
{
    protected $group       = 'Rules';
    protected $name        = 'rules:migrate-pf';
    protected $description = 'Migrates Provident Fund policies and employee overrides to rule_definitions (PF domain).';
    protected $usage       = 'rules:migrate-pf [--dry-run] [--company=COMPANY_ID]';
    protected $options     = [
        '--dry-run' => 'Simulate migration without inserting or modifying rule_definitions.',
        '--company' => 'Limit migration to a specific company ID or code.',
    ];

    public function run(array $params)
    {
        CLI::write("================================================================", 'cyan');
        CLI::write("           PROVIDENT FUND TO RULE STORE MIGRATION              ", 'white', 'blue');
        CLI::write("================================================================", 'cyan');

        $dryRun = CLI::getOption('dry-run') !== null || in_array('--dry-run', $params, true);
        $companyFilter = CLI::getOption('company') ?? null;

        foreach ($params as $k => $v) {
            if (is_string($v) && str_starts_with($v, '--company=')) {
                $companyFilter = substr($v, 10);
            }
            if ($k === 'company' && empty($companyFilter)) {
                $companyFilter = $v;
            }
        }

        if ($dryRun) {
            CLI::write("MODE: DRY RUN (Zero database mutations)", 'yellow');
        } else {
            CLI::write("MODE: LIVE MIGRATION", 'green');
        }
        CLI::newLine();

        $db = Database::connect();
        RuleSchemaRegistry::init();

        $companyModel = new CompanyModel();
        $companies = [];
        if (!empty($companyFilter)) {
            $comp = $companyModel->find($companyFilter)
                ?: $companyModel->where('code', $companyFilter)->first()
                ?: $companyModel->where('id', $companyFilter)->first();
            if (!$comp) {
                CLI::error("Company not found: {$companyFilter}");
                return 1;
            }
            $companies = [$comp];
        } else {
            $companies = $companyModel->findAll();
        }

        $now = date('Y-m-d H:i:s');
        $migratedCompanyRules = 0;
        $migratedEmployeeOverrides = 0;
        $skippedRules = 0;

        foreach ($companies as $comp) {
            $cId = $comp['id'];
            $cName = $comp['company_name'] ?? $comp['name'] ?? $cId;
            CLI::write("Processing Company: [{$cId}] {$cName}...", 'white');

            // 1. Statutory Policies for PF
            if ($db->tableExists('statutory_policies') &&
                $db->tableExists('statutory_policy_versions') &&
                $db->tableExists('statutory_policy_rules')) {

                $policies = $db->table('statutory_policies')
                    ->where('company_id', $cId)
                    ->groupStart()
                        ->where('policy_type', 'PROVIDENT_FUND')
                        ->orLike('policy_name', 'Provident', 'both')
                    ->groupEnd()
                    ->get()
                    ->getResultArray();

                foreach ($policies as $policy) {
                    $versions = $db->table('statutory_policy_versions')
                        ->where('policy_id', $policy['id'])
                        ->orderBy('version_number', 'ASC')
                        ->get()
                        ->getResultArray();

                    foreach ($versions as $version) {
                        $rule = $db->table('statutory_policy_rules')
                            ->where('version_id', $version['id'])
                            ->get()
                            ->getRowArray();

                        if (!$rule) {
                            continue;
                        }

                        $existing = $db->table('rule_definitions')
                            ->where('company_id', $cId)
                            ->where('domain', 'PF')
                            ->where('scope_level', 'Company')
                            ->where('version_number', (int)$version['version_number'])
                            ->countAllResults();

                        if ($existing > 0) {
                            $skippedRules++;
                            CLI::write("  -> Company rule v{$version['version_number']} already exists. Skipping.", 'dark_gray');
                            continue;
                        }

                        $contribType     = !empty($rule['contribution_type']) ? (string)$rule['contribution_type'] : 'percentage';
                        $empRate         = isset($rule['employee_rate']) ? (float)$rule['employee_rate'] : 7.0;
                        $compRate        = isset($rule['employer_rate']) ? (float)$rule['employer_rate'] : 7.0;
                        $empFixed        = isset($rule['employee_fixed_amount']) ? (float)$rule['employee_fixed_amount'] : 0.0;
                        $compFixed       = isset($rule['employer_fixed_amount']) ? (float)$rule['employer_fixed_amount'] : 0.0;
                        $calcBasis       = !empty($rule['calculation_basis']) ? (string)$rule['calculation_basis'] : 'Basic';
                        $basisComponents = ['Basic'];
                        if (!empty($rule['basis_components_json'])) {
                            $basisComponents = is_array($rule['basis_components_json'])
                                ? $rule['basis_components_json']
                                : (json_decode($rule['basis_components_json'], true) ?: ['Basic']);
                        }

                        $params = [
                            'contribution_type'     => $contribType,
                            'employee_rate'         => $empRate,
                            'employer_rate'         => $compRate,
                            'employee_fixed_amount' => $empFixed,
                            'employer_fixed_amount' => $compFixed,
                            'calculation_basis'     => $calcBasis,
                            'basis_components'      => $basisComponents,
                            'custom_formula'        => !empty($rule['custom_formula']) ? (string)$rule['custom_formula'] : null,
                            'employer_formula'      => !empty($rule['employer_formula']) ? (string)$rule['employer_formula'] : null,
                            'min_salary_limit'      => isset($rule['min_salary_limit']) ? (float)$rule['min_salary_limit'] : 0.0,
                            'max_salary_limit'      => isset($rule['max_salary_limit']) ? (float)$rule['max_salary_limit'] : 0.0,
                            'min_deduction_limit'   => isset($rule['min_deduction_limit']) ? (float)$rule['min_deduction_limit'] : 0.0,
                            'max_deduction_limit'   => isset($rule['max_deduction_limit']) ? (float)$rule['max_deduction_limit'] : 0.0,
                        ];

                        if (!$dryRun) {
                            $db->table('rule_definitions')->insert([
                                'id'             => 'rd-' . bin2hex(random_bytes(8)),
                                'company_id'     => $cId,
                                'domain'         => 'PF',
                                'scope_level'    => 'Company',
                                'scope_id'       => null,
                                'version_number' => (int)$version['version_number'],
                                'effective_from' => $version['effective_from'] ?? '2020-01-01',
                                'effective_to'   => $version['effective_to'] ?? null,
                                'status'         => $version['status'] ?? 'Active',
                                'params_json'    => json_encode($params, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                                'schema_version' => 1,
                                'change_reason'  => 'Migrated from statutory_policies / statutory_policy_rules',
                                'created_by'     => 'system_migration',
                                'approved_by'    => $version['approved_by'] ?? 'system_migration',
                                'created_at'     => $version['created_at'] ?? $now,
                                'updated_at'     => $version['updated_at'] ?? $now,
                            ]);
                        }
                        $migratedCompanyRules++;
                        CLI::write("  + [MIGRATED] Company statutory PF rule v{$version['version_number']} (Rate: {$empRate}%/{$compRate}%, Basis: {$calcBasis})", 'green');
                    }
                }
            }

            // 1.5 Migrate from provident_fund_rules if table exists
            if ($db->tableExists('provident_fund_rules')) {
                $pfRules = $db->table('provident_fund_rules')
                    ->where('company_id', $cId)
                    ->get()
                    ->getResultArray();

                foreach ($pfRules as $pfr) {
                    $existing = $db->table('rule_definitions')
                        ->where('company_id', $cId)
                        ->where('domain', 'PF')
                        ->where('scope_level', 'Company')
                        ->countAllResults();

                    if ($existing === 0) {
                        $empRate = isset($pfr['employee_contribution_rate']) ? (float)$pfr['employee_contribution_rate'] : 7.0;
                        $compRate = isset($pfr['employer_contribution_rate']) ? (float)$pfr['employer_contribution_rate'] : 7.0;
                        $calcBasis = !empty($pfr['calculation_base']) ? (string)$pfr['calculation_base'] : 'Basic';

                        $params = [
                            'contribution_type'     => !empty($pfr['contribution_type']) ? $pfr['contribution_type'] : 'percentage',
                            'employee_rate'         => $empRate,
                            'employer_rate'         => $compRate,
                            'employee_fixed_amount' => (float)($pfr['employee_fixed_amount'] ?? 0.0),
                            'employer_fixed_amount' => (float)($pfr['employer_fixed_amount'] ?? 0.0),
                            'calculation_basis'     => $calcBasis,
                            'basis_components'      => ['Basic'],
                            'custom_formula'        => null,
                            'employer_formula'      => null,
                            'min_salary_limit'      => (float)($pfr['min_salary_limit'] ?? 0.0),
                            'max_salary_limit'      => (float)($pfr['max_salary_limit'] ?? 0.0),
                            'min_deduction_limit'   => (float)($pfr['min_deduction_limit'] ?? 0.0),
                            'max_deduction_limit'   => (float)($pfr['max_deduction_limit'] ?? 0.0),
                        ];

                        if (!$dryRun) {
                            $db->table('rule_definitions')->insert([
                                'id'             => 'rd-' . bin2hex(random_bytes(8)),
                                'company_id'     => $cId,
                                'domain'         => 'PF',
                                'scope_level'    => 'Company',
                                'scope_id'       => null,
                                'version_number' => 1,
                                'effective_from' => $pfr['effective_from'] ?? '2020-01-01',
                                'effective_to'   => $pfr['effective_to'] ?? null,
                                'status'         => 'Active',
                                'params_json'    => json_encode($params, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                                'schema_version' => 1,
                                'change_reason'  => 'Migrated from provident_fund_rules',
                                'created_by'     => 'system_migration',
                                'approved_by'    => 'system_migration',
                                'created_at'     => $now,
                                'updated_at'     => $now,
                            ]);
                        }
                        $migratedCompanyRules++;
                        CLI::write("  + [MIGRATED] Company PF rule from provident_fund_rules", 'green');
                    }
                }
            }

            // Ensure base rule exists from system_settings or schema defaults
            $hasAnyPfRule = $db->table('rule_definitions')
                ->where('company_id', $cId)
                ->where('domain', 'PF')
                ->where('scope_level', 'Company')
                ->countAllResults();

            if ($hasAnyPfRule === 0) {
                $seedDefaults = RuleSchemaRegistry::seedValues('PF');

                if ($db->tableExists('system_settings')) {
                    $empRateRow = $db->table('system_settings')->where('company_id', $cId)->where('setting_key', 'payroll_pf_emp_rate')->get()->getRowArray();
                    $compRateRow = $db->table('system_settings')->where('company_id', $cId)->where('setting_key', 'payroll_pf_comp_rate')->get()->getRowArray();
                    $typeRow = $db->table('system_settings')->where('company_id', $cId)->where('setting_key', 'payroll_pf_type')->get()->getRowArray();

                    if (!empty($empRateRow['setting_value'])) {
                        $r = (float)$empRateRow['setting_value'];
                        $seedDefaults['employee_rate'] = ($r <= 1.0 && $r > 0) ? ($r * 100.0) : $r;
                    }
                    if (!empty($compRateRow['setting_value'])) {
                        $r = (float)$compRateRow['setting_value'];
                        $seedDefaults['employer_rate'] = ($r <= 1.0 && $r > 0) ? ($r * 100.0) : $r;
                    }
                    if (!empty($typeRow['setting_value'])) {
                        $seedDefaults['contribution_type'] = (string)$typeRow['setting_value'];
                    }
                }

                if (!$dryRun) {
                    $db->table('rule_definitions')->insert([
                        'id'             => 'rd-' . bin2hex(random_bytes(8)),
                        'company_id'     => $cId,
                        'domain'         => 'PF',
                        'scope_level'    => 'Company',
                        'scope_id'       => null,
                        'version_number' => 1,
                        'effective_from' => '2020-01-01',
                        'effective_to'   => null,
                        'status'         => 'Active',
                        'params_json'    => json_encode($seedDefaults, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                        'schema_version' => 1,
                        'change_reason'  => 'Initial Company Provident Fund policy (Single Rule Store)',
                        'created_by'     => 'system_migration',
                        'approved_by'    => 'system_migration',
                        'created_at'     => $now,
                        'updated_at'     => $now,
                    ]);
                }
                $migratedCompanyRules++;
                CLI::write("  + [INITIALIZED] Base Company PF rule created from system_settings / schema definition", 'cyan');
            }

            // Read authoritative company employee rate for override comparison
            $activeCompanyRule = $db->table('rule_definitions')
                ->where('company_id', $cId)
                ->where('domain', 'PF')
                ->where('scope_level', 'Company')
                ->where('status', 'Active')
                ->orderBy('version_number', 'DESC')
                ->get()
                ->getRowArray();
            $compActiveParams = $activeCompanyRule ? (new \App\Models\RuleDefinitionModel())->paramsOf($activeCompanyRule) : [];
            $companyEmpRate = (float)($compActiveParams['employee_rate'] ?? 7.0);

            // 2. Migrate Employee Overrides from employee_salaries
            if ($db->tableExists('employee_salaries')) {
                $salaries = $db->table('employee_salaries')
                    ->select('id, employee_id, company_id, custom_components_json, effective_from, effective_to, status')
                    ->where('company_id', $cId)
                    ->get()
                    ->getResultArray();

                foreach ($salaries as $sal) {
                    $rawJson = $sal['custom_components_json'] ?? '';
                    if (empty($rawJson)) {
                        continue;
                    }
                    $data = is_array($rawJson) ? $rawJson : (is_object($rawJson) ? (array)$rawJson : (is_string($rawJson) ? json_decode($rawJson, true) : []));
                    if (!is_array($data) || empty($data['pf_settings']['is_override'])) {
                        continue;
                    }

                    $empId = $sal['employee_id'] ?? '';
                    if ($empId === '') {
                        continue;
                    }

                    $existing = $db->table('rule_definitions')
                        ->where('company_id', $cId)
                        ->where('domain', 'PF')
                        ->where('scope_level', 'Employee')
                        ->where('scope_id', $empId)
                        ->countAllResults();

                    if ($existing > 0) {
                        $skippedRules++;
                        continue;
                    }

                    $pfSettings = $data['pf_settings'];
                    $empRate = (float)($pfSettings['employee_rate'] ?? $companyEmpRate);
                    $compRate = (float)($pfSettings['employer_rate'] ?? $companyEmpRate);

                    $overrideParams = [
                        'employee_rate' => $empRate,
                        'employer_rate' => $compRate,
                    ];

                    if (!$dryRun) {
                        $db->table('rule_definitions')->insert([
                            'id'             => 'rd-' . bin2hex(random_bytes(8)),
                            'company_id'     => $cId,
                            'domain'         => 'PF',
                            'scope_level'    => 'Employee',
                            'scope_id'       => $empId,
                            'version_number' => 1,
                            'effective_from' => $sal['effective_from'] ?? '2020-01-01',
                            'effective_to'   => $sal['effective_to'] ?? null,
                            'status'         => ($sal['status'] ?? 'Active') === 'Active' ? 'Active' : 'Archived',
                            'params_json'    => json_encode($overrideParams, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                            'schema_version' => 1,
                            'change_reason'  => 'Migrated from employee PF override',
                            'created_by'     => 'system_migration',
                            'approved_by'    => 'system_migration',
                            'created_at'     => $now,
                            'updated_at'     => $now,
                        ]);
                    }
                    $migratedEmployeeOverrides++;
                    CLI::write("  + [MIGRATED OVERRIDE] Employee {$empId} override rule from salary assignment (Emp: {$empRate}%, Comp: {$compRate}%)", 'yellow');
                }
            }

            // 3. Migrate Employee Overrides from employees table if legacy rate field exists
            if ($db->tableExists('employees') && $db->fieldExists('pf_employee_rate', 'employees')) {
                $empRows = $db->table('employees')
                    ->where('company_id', $cId)
                    ->where('pf_employee_rate IS NOT NULL')
                    ->get()
                    ->getResultArray();

                foreach ($empRows as $er) {
                    $empId = $er['id'] ?? '';
                    if ($empId === '') {
                        continue;
                    }

                    $eRate = (float)$er['pf_employee_rate'];
                    if ($eRate <= 0.0 || abs($eRate - $companyEmpRate) < 0.001) {
                        continue;
                    }

                    $existing = $db->table('rule_definitions')
                        ->where('company_id', $cId)
                        ->where('domain', 'PF')
                        ->where('scope_level', 'Employee')
                        ->where('scope_id', $empId)
                        ->countAllResults();

                    if ($existing > 0) {
                        $skippedRules++;
                        continue;
                    }

                    $cRate = isset($er['pf_employer_rate']) ? (float)$er['pf_employer_rate'] : $eRate;
                    $overrideParams = [
                        'employee_rate' => $eRate,
                        'employer_rate' => $cRate,
                    ];

                    if (!$dryRun) {
                        $db->table('rule_definitions')->insert([
                            'id'             => 'rd-' . bin2hex(random_bytes(8)),
                            'company_id'     => $cId,
                            'domain'         => 'PF',
                            'scope_level'    => 'Employee',
                            'scope_id'       => $empId,
                            'version_number' => 1,
                            'effective_from' => $er['pf_effective_date'] ?? $er['joining_date'] ?? '2020-01-01',
                            'effective_to'   => null,
                            'status'         => 'Active',
                            'params_json'    => json_encode($overrideParams, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                            'schema_version' => 1,
                            'change_reason'  => 'Migrated from employee PF override',
                            'created_by'     => 'system_migration',
                            'approved_by'    => 'system_migration',
                            'created_at'     => $now,
                            'updated_at'     => $now,
                        ]);
                    }
                    $migratedEmployeeOverrides++;
                    CLI::write("  + [MIGRATED OVERRIDE] Employee {$empId} legacy employee table override (Emp: {$eRate}%, Comp: {$cRate}%)", 'yellow');
                }
            }
        }

        CLI::newLine();
        CLI::write("MIGRATION SUMMARY:", 'white', 'blue');
        CLI::write("  - Company PF Rules Migrated: {$migratedCompanyRules}");
        CLI::write("  - Employee Overrides Migrated: {$migratedEmployeeOverrides}");
        CLI::write("  - Existing Rules Skipped: {$skippedRules}");
        CLI::write("Completed successfully.", 'green');
        return 0;
    }
}
