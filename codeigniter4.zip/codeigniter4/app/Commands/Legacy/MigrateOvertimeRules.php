<?php

/**
 * legacy one-time migration
 */

namespace App\Commands\Legacy;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use Config\Database;
use App\Models\CompanyModel;
use App\Services\Rules\RuleSchemaRegistry;

class MigrateOvertimeRules extends BaseCommand
{
    protected $group       = 'Rules';
    protected $name        = 'rules:migrate-ot';
    protected $description = 'Migrates Overtime policies and rule profiles to rule_definitions (OVERTIME domain).';
    protected $usage       = 'rules:migrate-ot [--dry-run] [--company=COMPANY_ID]';
    protected $options     = [
        '--dry-run' => 'Simulate migration without inserting or modifying rule_definitions.',
        '--company' => 'Limit migration to a specific company ID or code.',
    ];

    public function run(array $params)
    {
        CLI::write("================================================================", 'cyan');
        CLI::write("             OVERTIME TO RULE STORE MIGRATION                  ", 'white', 'blue');
        CLI::write("================================================================", 'cyan');

        $dryRun = CLI::getOption('dry-run') !== null || in_array('--dry-run', $params, true);
        $companyFilter = CLI::getOption('company') ?? null;

        foreach ($params as $k => $v) {
            if (is_string($v) && str_starts_with($v, '--company=')) {
                $companyFilter = substr($v, 10);
            }
            if ($k === 'company' && empty($companyFilter)) {
                $companyFilter = $v;
            }
        }

        if ($dryRun) {
            CLI::write("MODE: DRY RUN (Zero database mutations)", 'yellow');
        } else {
            CLI::write("MODE: LIVE MIGRATION", 'green');
        }
        CLI::newLine();

        $db = Database::connect();
        RuleSchemaRegistry::init();

        $companyModel = new CompanyModel();
        $companies = [];
        if (!empty($companyFilter)) {
            $comp = $companyModel->find($companyFilter)
                ?: $companyModel->where('code', $companyFilter)->first()
                ?: $companyModel->where('id', $companyFilter)->first();
            if (!$comp) {
                CLI::error("Company not found: {$companyFilter}");
                return 1;
            }
            $companies = [$comp];
        } else {
            $companies = $companyModel->findAll();
        }

        $now = date('Y-m-d H:i:s');
        $migratedCompanyRules = 0;
        $migratedBranchRules = 0;
        $migratedDeptRules = 0;
        $seededBaselineRules = 0;
        $skippedRules = 0;

        foreach ($companies as $comp) {
            $companyId = $comp['id'];
            $companyName = $comp['name'] ?? $companyId;

            CLI::write("Processing Company: {$companyName} ({$companyId})", 'white', 'light_gray');

            // 1. Check overtime_policies
            $hasPolicies = false;
            if ($db->tableExists('overtime_policies')) {
                $policies = $db->table('overtime_policies')
                    ->where('company_id', $companyId)
                    ->get()
                    ->getResultArray();

                foreach ($policies as $row) {
                    $hasPolicies = true;
                    $scopeLevel = 'Company';
                    $scopeId    = null;

                    if (!empty($row['branch_id'])) {
                        $scopeLevel = 'Branch';
                        $scopeId    = $row['branch_id'];
                    } elseif (!empty($row['department_id'])) {
                        $scopeLevel = 'Department';
                        $scopeId    = $row['department_id'];
                    }

                    $divisorMode = in_array($row['divisor_mode'] ?? '', ['Fixed 30 Days', 'Fixed 26 Days', 'Calendar Days', 'Basics'])
                        ? $row['divisor_mode']
                        : 'Fixed 30 Days';

                    $roundingMode = in_array($row['rounding_mode'] ?? '', ["Exact", "Nearest 15 minutes", "Nearest 30 minutes", "Nearest 1 hour", "Round Down", "Round Up"])
                        ? $row['rounding_mode']
                        : 'Exact';

                    $salaryBasis = in_array($row['salary_basis'] ?? '', ['Basic Salary', 'Gross Salary'])
                        ? $row['salary_basis']
                        : 'Basic Salary';

                    $paramsPayload = [
                        'enabled'                             => ($row['status'] ?? 'Active') === 'Active',
                        'scope'                               => 'All Staff',
                        'salary_basis'                        => $salaryBasis,
                        'divisor_mode'                        => $divisorMode,
                        'divisor_hours'                       => !empty($row['standard_daily_hours']) ? (float)$row['standard_daily_hours'] : 8.0,
                        'normal_multiplier'                   => !empty($row['normal_ot_multiplier']) ? (float)$row['normal_ot_multiplier'] : 1.50,
                        'weekly_off_multiplier'               => !empty($row['weekly_off_ot_multiplier']) ? (float)$row['weekly_off_ot_multiplier'] : 2.00,
                        'holiday_multiplier'                  => !empty($row['holiday_ot_multiplier']) ? (float)$row['holiday_ot_multiplier'] : 2.00,
                        'special_multiplier'                  => !empty($row['special_ot_multiplier']) ? (float)$row['special_ot_multiplier'] : 2.00,
                        'night_multiplier'                    => !empty($row['special_ot_multiplier']) ? (float)$row['special_ot_multiplier'] : 1.50,
                        'min_ot_minutes_to_qualify'           => 0,
                        'min_ot_unit_minutes'                 => !empty($row['min_ot_unit_minutes']) ? (int)$row['min_ot_unit_minutes'] : 15,
                        'rounding_mode'                       => $roundingMode,
                        'daily_threshold_hours'               => 8.0,
                        'max_daily_ot_hours'                  => !empty($row['max_daily_ot_hours']) ? (float)$row['max_daily_ot_hours'] : 4.0,
                        'max_monthly_ot_hours'                => !empty($row['max_monthly_ot_hours']) ? (float)$row['max_monthly_ot_hours'] : 60.0,
                        'enable_daily_ot'                     => true,
                        'enable_early_arrival_ot'             => !empty($row['allow_early_arrival_ot']),
                        'early_arrival_grace_minutes'         => (int)($row['early_arrival_grace_minutes'] ?? 0),
                        'early_arrival_min_threshold_minutes' => (int)($row['early_arrival_min_threshold_minutes'] ?? 0),
                        'enable_post_shift_ot'                => true,
                        'post_shift_grace_minutes'            => (int)($row['post_shift_grace_minutes'] ?? 0),
                        'post_shift_min_threshold_minutes'    => (int)($row['post_shift_min_threshold_minutes'] ?? 0),
                        'requires_pre_approval'               => !empty($row['requires_pre_approval']),
                        'requires_post_approval'              => !empty($row['requires_post_approval']),
                        'calculation_method'                  => 'Daily Overtime',
                        'conflict_policy'                     => 'Anti-Double-Counting',
                    ];

                    $builder = $db->table('rule_definitions')
                        ->where('company_id', $companyId)
                        ->where('domain', 'OVERTIME')
                        ->where('scope_level', $scopeLevel);

                    if ($scopeId === null) {
                        $builder->where('scope_id IS NULL');
                    } else {
                        $builder->where('scope_id', $scopeId);
                    }

                    $existing = $builder->countAllResults();

                    if ($existing > 0) {
                        CLI::write("  [SKIP] {$scopeLevel} rule already exists", 'yellow');
                        $skippedRules++;
                        continue;
                    }

                    if (!$dryRun) {
                        $db->table('rule_definitions')->insert([
                            'id'             => 'rd-' . bin2hex(random_bytes(8)),
                            'company_id'     => $companyId,
                            'domain'         => 'OVERTIME',
                            'scope_level'    => $scopeLevel,
                            'scope_id'       => $scopeId,
                            'version_number' => 1,
                            'effective_from' => $row['effective_from'] ?? '2020-01-01',
                            'effective_to'   => $row['effective_to'] ?? null,
                            'status'         => $row['status'] ?? 'Active',
                            'params_json'    => json_encode($paramsPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                            'schema_version' => 1,
                            'change_reason'  => 'Migrated from overtime_policies',
                            'created_by'     => 'system_migration',
                            'approved_by'    => 'system_migration',
                            'created_at'     => $row['created_at'] ?? $now,
                            'updated_at'     => $row['updated_at'] ?? $now,
                        ]);
                    }

                    if ($scopeLevel === 'Branch') {
                        $migratedBranchRules++;
                    } elseif ($scopeLevel === 'Department') {
                        $migratedDeptRules++;
                    } else {
                        $migratedCompanyRules++;
                    }

                    CLI::write("  [MIGRATE] Migrated {$scopeLevel} overtime policy", 'green');
                }
            }

            // 2. Fallback to attendance_rule_profiles if no Company rule exists yet
            $activeCompanyCount = $db->table('rule_definitions')
                ->where('company_id', $companyId)
                ->where('domain', 'OVERTIME')
                ->where('scope_level', 'Company')
                ->countAllResults();

            if ($activeCompanyCount === 0 && $db->tableExists('attendance_rule_profiles')) {
                $builder = $db->table('attendance_rule_profiles');
                if ($db->fieldExists('company_id', 'attendance_rule_profiles')) {
                    $builder->where('company_id', $companyId);
                }
                if ($db->fieldExists('status', 'attendance_rule_profiles')) {
                    $builder->where('status', 'Active');
                }
                $profile = $builder->get()->getRowArray();

                $rawJson = $profile['rules_json'] ?? ($profile['configuration_json'] ?? '');
                if (!empty($rawJson)) {
                    $rules = is_array($rawJson) ? $rawJson : (json_decode($rawJson, true) ?: []);
                    $ot = $rules['overtimeRule'] ?? null;
                    if (is_array($ot)) {
                        $paramsPayload = [
                            'enabled'                             => !empty($ot['enableDailyOt']) || !empty($ot['enableWeeklyOt']),
                            'scope'                               => 'All Staff',
                            'salary_basis'                        => in_array($ot['salaryBasis'] ?? '', ['Basic Salary', 'Gross Salary']) ? $ot['salaryBasis'] : 'Basic Salary',
                            'divisor_mode'                        => 'Fixed 30 Days',
                            'divisor_hours'                       => !empty($ot['divisorHours']) ? (float)$ot['divisorHours'] : 8.0,
                            'normal_multiplier'                   => !empty($ot['normalDayMultiplier']) ? (float)$ot['normalDayMultiplier'] : 1.50,
                            'weekly_off_multiplier'               => !empty($ot['offDayMultiplier']) ? (float)$ot['offDayMultiplier'] : 2.00,
                            'holiday_multiplier'                  => !empty($ot['holidayMultiplier']) ? (float)$ot['holidayMultiplier'] : 2.00,
                            'special_multiplier'                  => !empty($ot['specialMultiplier']) ? (float)$ot['specialMultiplier'] : 2.00,
                            'night_multiplier'                    => !empty($ot['nightMultiplier']) ? (float)$ot['nightMultiplier'] : 1.50,
                            'min_ot_minutes_to_qualify'           => (int)($ot['minOtMinutesToQualify'] ?? 0),
                            'min_ot_unit_minutes'                 => 15,
                            'rounding_mode'                       => in_array($ot['roundingMethod'] ?? '', ["Exact", "Nearest 15 minutes", "Nearest 30 minutes", "Nearest 1 hour", "Round Down", "Round Up"]) ? $ot['roundingMethod'] : 'Exact',
                            'daily_threshold_hours'               => !empty($ot['dailyThresholdHours']) ? (float)$ot['dailyThresholdHours'] : 8.0,
                            'max_daily_ot_hours'                  => !empty($ot['dailyMaxHoursCap']) ? (float)$ot['dailyMaxHoursCap'] : 4.0,
                            'max_monthly_ot_hours'                => !empty($ot['weeklyMaxHoursCap']) ? (float)($ot['weeklyMaxHoursCap'] * 4.0) : 60.0,
                            'enable_daily_ot'                     => true,
                            'enable_early_arrival_ot'             => !empty($ot['enableEarlyArrivalOt']),
                            'early_arrival_grace_minutes'         => 0,
                            'early_arrival_min_threshold_minutes' => (int)($ot['earlyArrivalMinThresholdMinutes'] ?? 0),
                            'enable_post_shift_ot'                => true,
                            'post_shift_grace_minutes'            => 0,
                            'post_shift_min_threshold_minutes'    => 0,
                            'requires_pre_approval'               => !empty($ot['preApprovalRequired']),
                            'requires_post_approval'              => false,
                            'calculation_method'                  => in_array($ot['calculationMethod'] ?? '', ["Daily Overtime", "Weekly Overtime", "Daily + Weekly without double counting", "Higher-of-Daily-or-Weekly", "Standard Daily"]) ? $ot['calculationMethod'] : 'Daily Overtime',
                            'conflict_policy'                     => in_array($ot['conflictPolicy'] ?? '', ["Anti-Double-Counting", "Daily OT only", "Weekly OT only", "Daily + Weekly without double counting", "Higher-of-Daily-or-Weekly"]) ? $ot['conflictPolicy'] : 'Anti-Double-Counting',
                        ];

                        if (!$dryRun) {
                            $db->table('rule_definitions')->insert([
                                'id'             => 'rd-' . bin2hex(random_bytes(8)),
                                'company_id'     => $companyId,
                                'domain'         => 'OVERTIME',
                                'scope_level'    => 'Company',
                                'scope_id'       => null,
                                'version_number' => 1,
                                'effective_from' => '2020-01-01',
                                'effective_to'   => null,
                                'status'         => 'Active',
                                'params_json'    => json_encode($paramsPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                                'schema_version' => 1,
                                'change_reason'  => 'Migrated from attendance_rule_profiles.overtimeRule',
                                'created_by'     => 'system_migration',
                                'approved_by'    => 'system_migration',
                                'created_at'     => $now,
                                'updated_at'     => $now,
                            ]);
                        }
                        $migratedCompanyRules++;
                        CLI::write("  [MIGRATE] Migrated Company rule from attendance_rule_profiles", 'green');
                        $activeCompanyCount = 1;
                    }
                }
            }

            // 3. Ensure baseline Company rule exists
            if ($activeCompanyCount === 0) {
                $seedParams = RuleSchemaRegistry::seedValues('OVERTIME');
                if (!$dryRun) {
                    $db->table('rule_definitions')->insert([
                        'id'             => 'rd-' . bin2hex(random_bytes(8)),
                        'company_id'     => $companyId,
                        'domain'         => 'OVERTIME',
                        'scope_level'    => 'Company',
                        'scope_id'       => null,
                        'version_number' => 1,
                        'effective_from' => '2020-01-01',
                        'effective_to'   => null,
                        'status'         => 'Active',
                        'params_json'    => json_encode($seedParams, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                        'schema_version' => 1,
                        'change_reason'  => 'Default baseline OVERTIME rule seeded by migration',
                        'created_by'     => 'system_migration',
                        'approved_by'    => 'system_migration',
                        'created_at'     => $now,
                        'updated_at'     => $now,
                    ]);
                }
                $seededBaselineRules++;
                CLI::write("  [SEED] Seeded baseline Company OVERTIME rule", 'cyan');
            }
        }

        CLI::newLine();
        CLI::write("================================================================", 'cyan');
        CLI::write("MIGRATION SUMMARY:", 'yellow');
        CLI::write("  - Company Overtime Rules Migrated: {$migratedCompanyRules}");
        CLI::write("  - Branch Overtime Rules Migrated:  {$migratedBranchRules}");
        CLI::write("  - Dept Overtime Rules Migrated:    {$migratedDeptRules}");
        CLI::write("  - Baseline Rules Seeded:           {$seededBaselineRules}");
        CLI::write("  - Existing Rules Skipped:          {$skippedRules}");
        CLI::write("================================================================", 'cyan');

        return 0;
    }
}
