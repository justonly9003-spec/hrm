<?php

/**
 * legacy one-time migration
 */

namespace App\Commands\Legacy;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use Config\Database;
use App\Models\CompanyModel;
use App\Services\Rules\RuleSchemaRegistry;
use App\Services\Rules\RuleParamValidator;
use App\Database\Migrations\MigrateTaxRulesToRuleDefinitions;

class MigrateTaxRules extends BaseCommand
{
    protected $group       = 'Rules';
    protected $name        = 'rules:migrate-tax';
    protected $description = 'Migrates Income Tax policies and employee overrides to rule_definitions (TAX domain).';
    protected $usage       = 'rules:migrate-tax [--dry-run] [--company=COMPANY_ID]';
    protected $options     = [
        '--dry-run' => 'Simulate migration without inserting or modifying rule_definitions.',
        '--company' => 'Limit migration to a specific company ID or code.',
    ];

    public function run(array $params)
    {
        CLI::write("================================================================", 'cyan');
        CLI::write("           INCOME TAX TO RULE STORE MIGRATION                  ", 'white', 'blue');
        CLI::write("================================================================", 'cyan');

        $dryRun = CLI::getOption('dry-run') !== null || in_array('--dry-run', $params, true);
        $companyFilter = CLI::getOption('company') ?? null;

        foreach ($params as $k => $v) {
            if (is_string($v) && str_starts_with($v, '--company=')) {
                $companyFilter = substr($v, 10);
            }
            if ($k === 'company' && empty($companyFilter)) {
                $companyFilter = $v;
            }
        }

        if ($dryRun) {
            CLI::write("MODE: DRY RUN (Zero database mutations)", 'yellow');
        } else {
            CLI::write("MODE: LIVE MIGRATION", 'green');
        }
        CLI::newLine();

        $db = Database::connect();
        RuleSchemaRegistry::init();

        $migration = new MigrateTaxRulesToRuleDefinitions();
        if (!$dryRun) {
            $migration->up();
            CLI::write("Successfully executed tax rules migration into rule_definitions.", 'green');
        } else {
            CLI::write("Dry-run completed successfully.", 'green');
        }

        return 0;
    }
}
