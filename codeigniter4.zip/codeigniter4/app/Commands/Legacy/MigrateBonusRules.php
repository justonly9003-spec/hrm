<?php

/**
 * legacy one-time migration
 */

namespace App\Commands\Legacy;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use Config\Database;
use App\Models\CompanyModel;
use App\Services\Rules\RuleSchemaRegistry;

class MigrateBonusRules extends BaseCommand
{
    protected $group       = 'Rules';
    protected $name        = 'rules:migrate-bonus';
    protected $description = 'Migrates Bonus schemes and weekly bonus rules to rule_definitions (BONUS domain).';
    protected $usage       = 'rules:migrate-bonus [--dry-run] [--company=COMPANY_ID]';
    protected $options     = [
        '--dry-run' => 'Simulate migration without inserting or modifying rule_definitions.',
        '--company' => 'Limit migration to a specific company ID or code.',
    ];

    public function run(array $params)
    {
        CLI::write("================================================================", 'cyan');
        CLI::write("              BONUS TO RULE STORE MIGRATION                    ", 'white', 'blue');
        CLI::write("================================================================", 'cyan');

        $dryRun = CLI::getOption('dry-run') !== null || in_array('--dry-run', $params, true);
        $companyFilter = CLI::getOption('company') ?? null;

        foreach ($params as $k => $v) {
            if (is_string($v) && str_starts_with($v, '--company=')) {
                $companyFilter = substr($v, 10);
            }
            if ($k === 'company' && empty($companyFilter)) {
                $companyFilter = $v;
            }
        }

        if ($dryRun) {
            CLI::write("MODE: DRY RUN (Zero database mutations)", 'yellow');
        } else {
            CLI::write("MODE: LIVE MIGRATION", 'green');
        }
        CLI::newLine();

        $db = Database::connect();
        RuleSchemaRegistry::init();

        $companyModel = new CompanyModel();
        $companies = [];

        if (!empty($companyFilter)) {
            $comp = $companyModel->find($companyFilter)
                ?: $companyModel->where('code', $companyFilter)->first()
                ?: $companyModel->where('id', $companyFilter)->first();

            if (!$comp) {
                CLI::error("Error: Company not found with ID or code '{$companyFilter}'");
                return 1;
            }
            $companies = [$comp];
        } else {
            $companies = $companyModel->findAll();
        }

        if (empty($companies)) {
            CLI::write("No companies found in database to migrate bonus rules for.", 'yellow');
            return 0;
        }

        $now = date('Y-m-d H:i:s');
        $createdCount = 0;
        $skippedCount = 0;

        foreach ($companies as $comp) {
            $companyId = $comp['id'] ?? '';
            $companyName = $comp['name'] ?? $companyId;

            CLI::write("Checking company: {$companyName} ({$companyId})", 'white');

            // 1. Weekly bonus params
            $weeklyBonusParams = $this->extractWeeklyBonusProfile($db, $companyId);

            // 2. Extract schemes
            $scopeGroupedSchemes = $this->extractBonusSchemes($db, $companyId);

            $companySchemes = $scopeGroupedSchemes['Company'] ?? [];
            if (empty($companySchemes)) {
                $companySchemes = [
                    [
                        'code'                       => 'FESTIVAL',
                        'name'                       => 'Festival Bonus',
                        'category'                   => 'Festival',
                        'calculation_type'           => 'Percentage_Basic',
                        'value'                      => 100.0,
                        'salary_basis'               => 'Basic Salary',
                        'included_component_codes'   => [],
                        'min_service_days'           => 90,
                        'prorate_under_service_days' => true,
                        'prorate_threshold_months'   => 6,
                        'prorate_min_ratio'          => 0.1,
                        'include_probation'          => false,
                        'priority'                   => 1,
                        'custom_formula'             => null,
                        'status'                     => 'Active',
                    ],
                    [
                        'code'                       => 'ANNUAL',
                        'name'                       => 'Annual Corporate Incentive',
                        'category'                   => 'Annual',
                        'calculation_type'           => 'Percentage_Basic',
                        'value'                      => 50.0,
                        'salary_basis'               => 'Basic Salary',
                        'included_component_codes'   => [],
                        'min_service_days'           => 180,
                        'prorate_under_service_days' => true,
                        'prorate_threshold_months'   => 12,
                        'prorate_min_ratio'          => 0.1,
                        'include_probation'          => false,
                        'priority'                   => 2,
                        'custom_formula'             => null,
                        'status'                     => 'Active',
                    ]
                ];
            }

            $completeCompanyParams = array_merge([
                'schemes' => $companySchemes,
            ], $weeklyBonusParams);

            // Validate against RuleSchemaRegistry
            $validationErrors = RuleSchemaRegistry::validate('BONUS', $completeCompanyParams, true);
            if (!empty($validationErrors)) {
                CLI::error("  [Validation Error] Company scope: " . json_encode($validationErrors));
            }

            $existingCompanyRule = $db->table('rule_definitions')
                ->where('company_id', $companyId)
                ->where('domain', 'BONUS')
                ->where('scope_level', 'Company')
                ->where('version_number', 1)
                ->countAllResults();

            if ($existingCompanyRule > 0) {
                CLI::write("  -> Company scope: Already exists (skipping)", 'dark_gray');
                $skippedCount++;
            } else {
                CLI::write("  -> Company scope: Will insert version 1 (" . count($companySchemes) . " schemes)", 'green');
                if (!$dryRun) {
                    $db->table('rule_definitions')->insert([
                        'id'             => 'rd-' . bin2hex(random_bytes(8)),
                        'company_id'     => $companyId,
                        'domain'         => 'BONUS',
                        'scope_level'    => 'Company',
                        'scope_id'       => null,
                        'version_number' => 1,
                        'effective_from' => '2020-01-01',
                        'effective_to'   => null,
                        'status'         => 'Active',
                        'params_json'    => json_encode($completeCompanyParams, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                        'schema_version' => 1,
                        'change_reason'  => 'P16: Migration from bonus_schemes and attendance rule profiles',
                        'created_by'     => 'CLI-MIGRATION',
                        'approved_by'    => 'CLI-MIGRATION',
                        'created_at'     => $now,
                        'updated_at'     => $now,
                    ]);
                }
                $createdCount++;
            }

            // Child scopes
            $allowedChildScopes = ['Branch', 'Department', 'Designation', 'Employee'];
            foreach ($allowedChildScopes as $scopeLevel) {
                if (empty($scopeGroupedSchemes[$scopeLevel])) {
                    continue;
                }

                foreach ($scopeGroupedSchemes[$scopeLevel] as $scopeId => $childSchemes) {
                    $existingChild = $db->table('rule_definitions')
                        ->where('company_id', $companyId)
                        ->where('domain', 'BONUS')
                        ->where('scope_level', $scopeLevel)
                        ->where('scope_id', $scopeId)
                        ->where('version_number', 1)
                        ->countAllResults();

                    if ($existingChild > 0) {
                        CLI::write("  -> {$scopeLevel} [{$scopeId}]: Already exists (skipping)", 'dark_gray');
                        $skippedCount++;
                    } else {
                        CLI::write("  -> {$scopeLevel} [{$scopeId}]: Will insert (" . count($childSchemes) . " schemes)", 'yellow');
                        if (!$dryRun) {
                            $db->table('rule_definitions')->insert([
                                'id'             => 'rd-' . bin2hex(random_bytes(8)),
                                'company_id'     => $companyId,
                                'domain'         => 'BONUS',
                                'scope_level'    => $scopeLevel,
                                'scope_id'       => $scopeId,
                                'version_number' => 1,
                                'effective_from' => '2020-01-01',
                                'effective_to'   => null,
                                'status'         => 'Active',
                                'params_json'    => json_encode(['schemes' => $childSchemes], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                                'schema_version' => 1,
                                'change_reason'  => "P16: Migrated {$scopeLevel} {$scopeId} bonus scheme",
                                'created_by'     => 'CLI-MIGRATION',
                                'approved_by'    => 'CLI-MIGRATION',
                                'created_at'     => $now,
                                'updated_at'     => $now,
                            ]);
                        }
                        $createdCount++;
                    }
                }
            }
        }

        CLI::newLine();
        CLI::write("Summary: {$createdCount} inserted, {$skippedCount} skipped.", 'cyan');
        return 0;
    }

    protected function extractWeeklyBonusProfile($db, string $companyId): array
    {
        $wbr = null;

        if ($db->tableExists('attendance_rule_profiles')) {
            $builder = $db->table('attendance_rule_profiles');
            if ($db->fieldExists('company_id', 'attendance_rule_profiles')) {
                $builder->where('company_id', $companyId);
            }
            if ($db->fieldExists('status', 'attendance_rule_profiles')) {
                $builder->where('status', 'Active');
            }
            $profile = $builder->get()->getRowArray();

            $rawJson = $profile['rules_json'] ?? ($profile['configuration_json'] ?? '');
            if (!empty($rawJson)) {
                $rules = is_array($rawJson)
                    ? $rawJson
                    : (json_decode($rawJson, true) ?: []);
                $wbr = $rules['weeklyBonusRule'] ?? null;
            }
        }

        $method = in_array($wbr['bonusMethod'] ?? '', ['Fixed Amount', 'Percentage of Basic', 'Hour Based', 'Tier Based'], true)
            ? $wbr['bonusMethod']
            : 'Fixed Amount';

        $rawTiers = $wbr['tiers'] ?? [
            ['tierName' => 'Tier 1 (40 - 44 hrs)', 'minHours' => 40, 'maxHours' => 44, 'bonusAmount' => 300],
            ['tierName' => 'Tier 2 (45 - 48 hrs)', 'minHours' => 45, 'maxHours' => 48, 'bonusAmount' => 600],
            ['tierName' => 'Tier 3 (49+ hrs)', 'minHours' => 49, 'maxHours' => 99, 'bonusAmount' => 1000],
        ];

        $cleanedTiers = [];
        foreach ($rawTiers as $t) {
            $cleanedTiers[] = [
                'tier_name'    => (string)($t['tierName'] ?? $t['tier_name'] ?? 'Tier'),
                'min_hours'    => (float)($t['minHours'] ?? $t['min_hours'] ?? 0),
                'max_hours'    => (float)($t['maxHours'] ?? $t['max_hours'] ?? 0),
                'bonus_amount' => (float)($t['bonusAmount'] ?? $t['bonus_amount'] ?? 0),
            ];
        }

        return [
            'weekly_bonus_enabled'                  => isset($wbr['enabled']) ? (bool)$wbr['enabled'] : true,
            'weekly_bonus_method'                   => $method,
            'weekly_bonus_fixed_amount'             => isset($wbr['fixedAmount']) ? (float)$wbr['fixedAmount'] : 500.0,
            'weekly_bonus_percentage_of_basic'      => isset($wbr['percentageOfBasic']) ? (float)$wbr['percentageOfBasic'] : 5.0,
            'weekly_bonus_rate_per_hour'            => isset($wbr['ratePerHour']) ? (float)$wbr['ratePerHour'] : 100.0,
            'weekly_bonus_min_present_days'         => isset($wbr['minPresentDays']) ? (int)$wbr['minPresentDays'] : 5,
            'weekly_bonus_min_weekly_hours'          => isset($wbr['minWeeklyHours']) ? (float)$wbr['minWeeklyHours'] : 40.0,
            'weekly_bonus_full_attendance_required' => !empty($wbr['fullAttendanceRequired']),
            'weekly_bonus_late_allowed'             => isset($wbr['lateAllowed']) ? (bool)$wbr['lateAllowed'] : true,
            'weekly_bonus_max_allowed_lates'        => isset($wbr['maxAllowedLates']) ? (int)$wbr['maxAllowedLates'] : 2,
            'weekly_bonus_leave_allowed'            => isset($wbr['leaveAllowed']) ? (bool)$wbr['leaveAllowed'] : true,
            'weekly_bonus_tiers'                    => $cleanedTiers,
        ];
    }

    protected function extractBonusSchemes($db, string $companyId): array
    {
        $grouped = [
            'Company'     => [],
            'Branch'      => [],
            'Department'  => [],
            'Designation' => [],
            'Employee'    => [],
        ];

        if (!$db->tableExists('bonus_schemes')) {
            return $grouped;
        }

        $builder = $db->table('bonus_schemes');
        if ($db->fieldExists('company_id', 'bonus_schemes')) {
            $builder->groupStart()
                ->where('company_id', $companyId)
                ->orWhere('company_id IS NULL')
                ->orWhere('company_id', '')
                ->groupEnd();
        }

        $rows = $builder->get()->getResultArray();
        foreach ($rows as $row) {
            $scopeLevel = $row['scope_level'] ?? 'Global';
            $scopeId    = !empty($row['scope_id']) ? (string)$row['scope_id'] : null;

            $calcType = in_array($row['calculation_type'] ?? '', ['Percentage_Basic', 'Percentage_Gross', 'Flat', 'Formula'], true)
                ? $row['calculation_type']
                : 'Percentage_Basic';

            $salaryBasis = in_array($row['salary_basis'] ?? '', ['Basic Salary', 'Gross Salary'], true)
                ? $row['salary_basis']
                : 'Basic Salary';

            $schemeObj = [
                'code'                       => (string)($row['code'] ?? $row['id'] ?? 'SCHEME-DEFAULT'),
                'name'                       => (string)($row['name'] ?? $row['title'] ?? 'Bonus Scheme'),
                'category'                   => (string)($row['category'] ?? 'Festival'),
                'calculation_type'           => $calcType,
                'value'                      => (float)($row['value'] ?? 0.0),
                'salary_basis'               => $salaryBasis,
                'min_service_days'           => isset($row['min_service_days']) ? (int)$row['min_service_days'] : 90,
                'prorate_under_service_days' => !empty($row['prorate_under_service_days']),
                'prorate_threshold_months'   => isset($row['prorate_threshold_months']) ? (int)$row['prorate_threshold_months'] : 6,
                'prorate_min_ratio'          => isset($row['prorate_min_ratio']) ? (float)$row['prorate_min_ratio'] : 0.1,
                'include_probation'          => !empty($row['include_probation']),
                'priority'                   => isset($row['priority']) ? (int)$row['priority'] : 1,
                'custom_formula'             => !empty($row['custom_formula']) ? (string)$row['custom_formula'] : null,
                'status'                     => (!empty($row['status']) && strtolower((string)$row['status']) === 'inactive') ? 'Inactive' : 'Active',
            ];

            if ($scopeLevel === 'Global' || $scopeLevel === 'Company' || empty($scopeLevel)) {
                $grouped['Company'][] = $schemeObj;
            } elseif (in_array($scopeLevel, ['Branch', 'Department', 'Designation', 'Employee'], true) && $scopeId !== null) {
                if (!isset($grouped[$scopeLevel][$scopeId])) {
                    $grouped[$scopeLevel][$scopeId] = [];
                }
                $grouped[$scopeLevel][$scopeId][] = $schemeObj;
            }
        }

        return $grouped;
    }
}
