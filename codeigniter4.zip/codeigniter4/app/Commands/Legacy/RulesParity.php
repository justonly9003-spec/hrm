<?php

/**
 * legacy one-time migration
 */

namespace App\Commands\Legacy;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use Config\Database;
use App\Models\PayrollModel;
use App\Models\CompanyModel;
use App\Services\PayrollService;

/**
 * RulesParity
 *
 * Parity harness to prove business rule migrations do not alter payroll results.
 * Recomputes payroll in dry-run mode (zero writes, zero mutations) and compares
 * against stored payroll_items rows for past months.
 */
class RulesParity extends BaseCommand
{
    protected $group       = 'Rules';
    protected $name        = 'rules:parity';
    protected $description = 'Verifies calculation parity between current code and stored payroll items in dry-run mode.';
    protected $usage       = 'rules:parity --month=YYYY-MM [--company=ID] [--out=path.csv] [--all-rows]';
    protected $arguments   = [];
    protected $options     = [
        '--month'    => 'The payroll month to verify in YYYY-MM format (required).',
        '--company'  => 'Optional company ID or code to scope the parity check.',
        '--out'      => 'Optional file path to output CSV comparison report.',
        '--all-rows' => 'Include all comparison rows in the CSV (default: diffs only).',
    ];

    /**
     * The 10 canonical fields required for parity comparison
     */
    protected array $fieldsToCompare = [
        'basic_salary',
        'gross_salary',
        'overtime_amount',
        'bonus_amount',
        'pf_deduction',
        'employer_pf_contribution',
        'gratuity_provision',
        'tax_deduction',
        'total_deductions',
        'net_salary',
    ];

    public function run(array $params)
    {
        CLI::write("================================================================", 'cyan');
        CLI::write("           PAYROLL RULES PARITY VERIFICATION HARNESS            ", 'white', 'blue');
        CLI::write("================================================================", 'cyan');

        // 1. Parse CLI options and arguments flexibly
        $month = $params['month'] ?? CLI::getOption('month');
        $companyParam = $params['company'] ?? CLI::getOption('company');
        $outFile = $params['out'] ?? CLI::getOption('out');
        $allRows = CLI::getOption('all-rows') !== null || in_array('--all-rows', $params, true);

        foreach ($params as $k => $v) {
            if (is_string($v)) {
                if (str_starts_with($v, '--month=')) {
                    $month = substr($v, 8);
                } elseif (str_starts_with($v, '--company=')) {
                    $companyParam = substr($v, 10);
                } elseif (str_starts_with($v, '--out=')) {
                    $outFile = substr($v, 6);
                }
            }
            if (is_string($k)) {
                if ($k === 'month' && empty($month)) $month = $v;
                if ($k === 'company' && empty($companyParam)) $companyParam = $v;
                if ($k === 'out' && empty($outFile)) $outFile = $v;
            }
        }

        // Validate required month argument (YYYY-MM format)
        if (empty($month) || !preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $month)) {
            CLI::error("Error: Valid --month=YYYY-MM is required (e.g. php spark rules:parity --month=2025-01).");
            CLI::write("Usage: php spark {$this->usage}", 'yellow');
            return 1;
        }

        $db = Database::connect();
        $payrollModel = new PayrollModel();
        $companyModel = new CompanyModel();
        $payrollService = new PayrollService();

        // 2. Resolve company scope
        $companies = [];
        if (!empty($companyParam)) {
            $comp = $companyModel->find($companyParam) 
                ?: $companyModel->where('code', $companyParam)->first()
                ?: $companyModel->where('id', $companyParam)->first();

            if (!$comp) {
                CLI::error("Error: Company not found with ID or code: '{$companyParam}'");
                return 1;
            }
            $companies = [$comp];
        } else {
            // Find all companies that have batches in the target month
            $monthParts = explode('-', $month);
            $yearNum = (int)$monthParts[0];
            $monthNum = (int)$monthParts[1];

            $builder = $db->table('payrolls')
                ->select('DISTINCT(company_id) as comp_id')
                ->groupStart()
                    ->where('payroll_month', $month)
                    ->orGroupStart()
                        ->where('year', $yearNum)
                        ->where('month', $monthNum)
                    ->groupEnd()
                ->groupEnd();

            $compIds = array_filter(array_column($builder->get()->getResultArray(), 'comp_id'));

            if (empty($compIds)) {
                // If no batches, get all active companies to report clear absence of past payroll
                $companies = $companyModel->findAll();
            } else {
                $companies = $companyModel->whereIn('id', $compIds)->findAll();
            }
        }

        if (empty($companies)) {
            CLI::error("No companies found to evaluate.");
            return 1;
        }

        CLI::write("Month Scoped       : " . $month, 'yellow');
        CLI::write("Company Scope      : " . (!empty($companyParam) ? $companies[0]['name'] . " ({$companies[0]['id']})" : 'ALL COMPANIES (' . count($companies) . ' found)'), 'white');
        CLI::write("Output CSV Destination : " . ($outFile ?: 'STDOUT / Console Stream'), 'white');
        CLI::write("Tolerance Threshold: 0.01", 'white');
        CLI::write("Execution Mode     : Strict Dry-Run (Zero Database Writes)", 'cyan');
        CLI::newLine();

        $totalCompaniesEvaluated = 0;
        $totalBatchesEvaluated = 0;
        $totalEmployeesEvaluated = 0;
        $totalComparisons = 0;
        $totalMatches = 0;
        $totalDiffs = 0;

        $csvRows = []; // ['employee_id', 'field', 'stored', 'recomputed', 'diff']
        $diffsByField = array_fill_keys($this->fieldsToCompare, 0);

        foreach ($companies as $comp) {
            $companyId = $comp['id'];
            $companyName = $comp['name'] ?? $companyId;

            $batches = $payrollModel->getBatchesForMonth($month, $companyId);
            if (empty($batches)) {
                CLI::write("Company [{$companyName}]: No existing payroll batches found for {$month}. Skipping.", 'dark_gray');
                continue;
            }

            $totalCompaniesEvaluated++;

            foreach ($batches as $batch) {
                $batchId = $batch['id'];
                $branchId = $batch['branch_id'] ?? null;
                $totalBatchesEvaluated++;

                CLI::write("Evaluating Batch [{$batchId}] (Company: {$companyName}, Month: {$month}, Branch: " . ($branchId ?: 'All') . ")...", 'white');

                // A. Retrieve stored payroll_items for this batch (left join employees to preserve records even if employee row altered)
                $storedItems = $db->table('payroll_items')
                    ->select('payroll_items.*, CONCAT(COALESCE(employees.first_name, \'\'), \' \', COALESCE(employees.last_name, \'\')) as employee_name, employees.employee_code')
                    ->join('employees', 'employees.id = payroll_items.employee_id', 'left')
                    ->where('payroll_items.payroll_id', $batchId)
                    ->get()
                    ->getResultArray();

                if (empty($storedItems)) {
                    CLI::write("  -> Warning: Batch {$batchId} has 0 stored payroll_items.", 'yellow');
                    continue;
                }

                $storedItemsByEmp = [];
                foreach ($storedItems as $item) {
                    $empId = $item['employee_id'] ?? '';
                    if ($empId !== '') {
                        $storedItemsByEmp[$empId] = $item;
                    }
                }

                // B. Recompute in dry-run mode (guaranteed zero mutations)
                $dryRunResult = $payrollService->generatePayrollBatch($month, $companyId, $branchId, null, true);

                if (!$dryRunResult['success'] && empty($dryRunResult['items'])) {
                    CLI::error("  -> Dry-run recomputation failed for batch {$batchId}: " . ($dryRunResult['message'] ?? 'Unknown error'));
                    // Mark all stored items as diffs because current calculation failed
                    foreach ($storedItemsByEmp as $empId => $storedItem) {
                        $totalEmployeesEvaluated++;
                        foreach ($this->fieldsToCompare as $field) {
                            $totalComparisons++;
                            $storedVal = round((float)($storedItem[$field] ?? 0), 2);
                            $recomputedVal = 0.00;
                            $diff = round($recomputedVal - $storedVal, 2);

                            $totalDiffs++;
                            $diffsByField[$field]++;

                            $csvRows[] = [
                                'employee_id' => $empId,
                                'field'       => $field,
                                'stored'      => number_format($storedVal, 2, '.', ''),
                                'recomputed'  => number_format($recomputedVal, 2, '.', ''),
                                'diff'        => number_format($diff, 2, '.', ''),
                            ];
                        }
                    }
                    continue;
                }

                $recomputedItemsByEmp = [];
                foreach ($dryRunResult['items'] as $recomputedItem) {
                    $empId = $recomputedItem['employee_id'] ?? '';
                    if ($empId !== '') {
                        $recomputedItemsByEmp[$empId] = $recomputedItem;
                    }
                }

                // C. Union of employee IDs from stored and recomputed sets
                $allEmployeeIds = array_unique(array_merge(array_keys($storedItemsByEmp), array_keys($recomputedItemsByEmp)));
                $batchEmployeeCount = count($allEmployeeIds);
                $totalEmployeesEvaluated += $batchEmployeeCount;

                $batchDiffCount = 0;

                foreach ($allEmployeeIds as $empId) {
                    $stored = $storedItemsByEmp[$empId] ?? null;
                    $recomputed = $recomputedItemsByEmp[$empId] ?? null;

                    foreach ($this->fieldsToCompare as $field) {
                        $totalComparisons++;

                        // Handle potential employer_pf_contribution alias
                        $storedVal = 0.00;
                        if ($stored) {
                            if ($field === 'employer_pf_contribution') {
                                $storedVal = (float)($stored['employer_pf_contribution'] ?? $stored['pf_employer_contribution'] ?? 0.00);
                            } else {
                                $storedVal = (float)($stored[$field] ?? 0.00);
                            }
                        }
                        $storedVal = round($storedVal, 2);

                        $recomputedVal = 0.00;
                        if ($recomputed) {
                            if ($field === 'employer_pf_contribution') {
                                $recomputedVal = (float)($recomputed['employer_pf_contribution'] ?? $recomputed['pf_employer_contribution'] ?? 0.00);
                            } else {
                                $recomputedVal = (float)($recomputed[$field] ?? 0.00);
                            }
                        }
                        $recomputedVal = round($recomputedVal, 2);

                        $diff = round($recomputedVal - $storedVal, 2);
                        $hasDiff = abs($diff) > 0.01;

                        if ($hasDiff) {
                            $totalDiffs++;
                            $batchDiffCount++;
                            $diffsByField[$field]++;

                            $csvRows[] = [
                                'employee_id' => $empId,
                                'field'       => $field,
                                'stored'      => number_format($storedVal, 2, '.', ''),
                                'recomputed'  => number_format($recomputedVal, 2, '.', ''),
                                'diff'        => number_format($diff, 2, '.', ''),
                            ];
                        } else {
                            $totalMatches++;
                            if ($allRows) {
                                $csvRows[] = [
                                    'employee_id' => $empId,
                                    'field'       => $field,
                                    'stored'      => number_format($storedVal, 2, '.', ''),
                                    'recomputed'  => number_format($recomputedVal, 2, '.', ''),
                                    'diff'        => number_format($diff, 2, '.', ''),
                                ];
                            }
                        }
                    }
                }

                if ($batchDiffCount === 0) {
                    CLI::write("  -> Batch {$batchId}: {$batchEmployeeCount} employees verified. Parity MATCH (0 diffs).", 'green');
                } else {
                    CLI::write("  -> Batch {$batchId}: {$batchDiffCount} diff(s) detected across {$batchEmployeeCount} employees.", 'red');
                }
            }
        }

        CLI::newLine();
        CLI::write("----------------------------------------------------------------", 'cyan');
        CLI::write("                    PARITY SUMMARY REPORT                       ", 'white', 'blue');
        CLI::write("----------------------------------------------------------------", 'cyan');
        CLI::write("Companies Evaluated    : " . $totalCompaniesEvaluated);
        CLI::write("Batches Evaluated      : " . $totalBatchesEvaluated);
        CLI::write("Employees Evaluated    : " . $totalEmployeesEvaluated);
        CLI::write("Total Field Checks     : " . $totalComparisons);
        CLI::write("Parity Matches (<=0.01): " . $totalMatches, 'green');
        CLI::write("Discrepancies / Diffs  : " . $totalDiffs, $totalDiffs > 0 ? 'red' : 'green');

        if ($totalDiffs > 0) {
            CLI::newLine();
            CLI::write("Discrepancy Breakdown by Field:", 'yellow');
            foreach ($diffsByField as $f => $count) {
                if ($count > 0) {
                    CLI::write("  - " . str_pad($f, 26) . ": {$count} diff(s)", 'red');
                }
            }
        }

        // 3. Format and output CSV
        $csvHeader = "employee_id,field,stored,recomputed,diff";
        $csvLines = [$csvHeader];
        foreach ($csvRows as $row) {
            $csvLines[] = sprintf(
                "%s,%s,%s,%s,%s",
                $row['employee_id'],
                $row['field'],
                $row['stored'],
                $row['recomputed'],
                $row['diff']
            );
        }
        $csvContent = implode("\n", $csvLines) . "\n";

        if (!empty($outFile)) {
            $dir = dirname($outFile);
            if (!empty($dir) && $dir !== '.' && !is_dir($dir)) {
                mkdir($dir, 0777, true);
            }
            file_put_contents($outFile, $csvContent);
            CLI::newLine();
            CLI::write("CSV report written successfully to: {$outFile}", 'cyan');
        } else {
            // If no output file specified, stream the CSV directly to console output
            CLI::newLine();
            CLI::write("--- CSV REPORT (employee_id, field, stored, recomputed, diff) ---", 'yellow');
            foreach ($csvLines as $line) {
                CLI::write($line);
            }
            CLI::write("--- END OF CSV REPORT ---", 'yellow');
        }

        CLI::newLine();
        if ($totalDiffs === 0) {
            CLI::write("[PARITY VERIFIED] Calculation parity confirmed with zero discrepancies.", 'white', 'green');
            return 0;
        }

        CLI::error("[PARITY FAILED] Discrepancies detected between recomputed and stored values.");
        return 1;
    }
}
