<?php

/**
 * legacy one-time migration
 */

namespace App\Commands\Legacy;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use Config\Database;
use App\Models\CompanyModel;
use App\Services\Rules\RuleSchemaRegistry;
use App\Services\Rules\RuleParamValidator;

class MigrateLeaveRules extends BaseCommand
{
    protected $group       = 'Rules';
    protected $name        = 'rules:migrate-leave';
    protected $description = 'Migrates leave policies, types, eligibility rules, and quotas to rule_definitions (LEAVE domain).';
    protected $usage       = 'rules:migrate-leave [--dry-run] [--company=COMPANY_ID]';
    protected $options     = [
        '--dry-run' => 'Simulate migration without inserting or modifying rule_definitions.',
        '--company' => 'Limit migration to a specific company ID or code.',
    ];

    public function run(array $params)
    {
        CLI::write("================================================================", 'cyan');
        CLI::write("              LEAVE TO RULE STORE MIGRATION                     ", 'white', 'blue');
        CLI::write("================================================================", 'cyan');

        $dryRun = CLI::getOption('dry-run') !== null || in_array('--dry-run', $params, true);
        $companyFilter = CLI::getOption('company') ?? null;

        foreach ($params as $k => $v) {
            if (is_string($v) && str_starts_with($v, '--company=')) {
                $companyFilter = substr($v, 10);
            }
            if ($k === 'company' && empty($companyFilter)) {
                $companyFilter = $v;
            }
        }

        if ($dryRun) {
            CLI::write("MODE: DRY RUN (Zero database mutations)", 'yellow');
        } else {
            CLI::write("MODE: LIVE MIGRATION", 'green');
        }
        CLI::newLine();

        $db = Database::connect();
        RuleSchemaRegistry::init();

        $companyModel = new CompanyModel();
        $companies = [];

        if (!empty($companyFilter)) {
            $comp = $companyModel->find($companyFilter)
                ?: $companyModel->where('code', $companyFilter)->first()
                ?: $companyModel->where('id', $companyFilter)->first();

            if (!$comp) {
                CLI::error("Error: Company not found with ID or code '{$companyFilter}'");
                return 1;
            }
            $companies = [$comp];
        } else {
            $companies = $companyModel->findAll();
        }

        if (empty($companies)) {
            CLI::write("No companies found in database to migrate leave rules for.", 'yellow');
            return 0;
        }

        $now = date('Y-m-d H:i:s');
        $createdCount = 0;
        $skippedCount = 0;

        foreach ($companies as $comp) {
            $companyId = $comp['id'] ?? '';
            $companyName = $comp['name'] ?? $companyId;

            CLI::write("Processing company: {$companyName} ({$companyId})", 'white');

            // 1. Extract rules grouped by scope
            $extracted = $this->extractLeaveRulesForCompany($db, $companyId);

            // 2. Company Scope
            $companyParams = $extracted['Company'] ?? null;
            if (!$companyParams) {
                CLI::error("  [Error] Failed to build complete Company scope params for {$companyId}");
                continue;
            }

            $validation = RuleParamValidator::validate('LEAVE', 'Company', $companyParams, false);
            if (!$validation['valid']) {
                CLI::error("  [Validation Error] Company scope: " . json_encode($validation['errors']));
            }

            $existingCompanyRule = $db->table('rule_definitions')
                ->where('company_id', $companyId)
                ->where('domain', 'LEAVE')
                ->where('scope_level', 'Company')
                ->where('version_number', 1)
                ->countAllResults();

            if ($existingCompanyRule === 0) {
                CLI::write("  -> Creating Company scope rule (version 1)", 'green');
                if (!$dryRun) {
                    $db->table('rule_definitions')->insert([
                        'id'             => 'rd-' . bin2hex(random_bytes(8)),
                        'company_id'     => $companyId,
                        'domain'         => 'LEAVE',
                        'scope_level'    => 'Company',
                        'scope_id'       => null,
                        'version_number' => 1,
                        'effective_from' => '2020-01-01',
                        'effective_to'   => null,
                        'status'         => 'Active',
                        'params_json'    => json_encode($validation['clean'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                        'schema_version' => 1,
                        'change_reason'  => 'P17: Migration of leave policies, types, and eligibility to Single Rule Store',
                        'created_by'     => 'SYS-MIGRATION',
                        'approved_by'    => 'SYS-MIGRATION',
                        'created_at'     => $now,
                        'updated_at'     => $now,
                    ]);
                }
                $createdCount++;
            } else {
                CLI::write("  -> Company scope rule already exists. Skipped.", 'yellow');
                $skippedCount++;
            }

            // 3. Child scopes (Branch, Department, Designation, Employee)
            $allowedChildScopes = ['Branch', 'Department', 'Designation', 'Employee'];
            foreach ($allowedChildScopes as $childScope) {
                if (empty($extracted[$childScope])) {
                    continue;
                }

                foreach ($extracted[$childScope] as $scopeId => $scopeParams) {
                    $childValidation = RuleParamValidator::validate('LEAVE', $childScope, $scopeParams, true);
                    if (!$childValidation['valid']) {
                        CLI::error("  [Validation Error] {$childScope} ({$scopeId}): " . json_encode($childValidation['errors']));
                    }

                    $existingChild = $db->table('rule_definitions')
                        ->where('company_id', $companyId)
                        ->where('domain', 'LEAVE')
                        ->where('scope_level', $childScope)
                        ->where('scope_id', $scopeId)
                        ->where('version_number', 1)
                        ->countAllResults();

                    if ($existingChild === 0) {
                        CLI::write("  -> Creating {$childScope} rule for ID '{$scopeId}'", 'cyan');
                        if (!$dryRun) {
                            $db->table('rule_definitions')->insert([
                                'id'             => 'rd-' . bin2hex(random_bytes(8)),
                                'company_id'     => $companyId,
                                'domain'         => 'LEAVE',
                                'scope_level'    => $childScope,
                                'scope_id'       => $scopeId,
                                'version_number' => 1,
                                'effective_from' => '2020-01-01',
                                'effective_to'   => null,
                                'status'         => 'Active',
                                'params_json'    => json_encode($childValidation['clean'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                                'schema_version' => 1,
                                'change_reason'  => "P17: Migration of {$childScope}-scoped leave policy overrides",
                                'created_by'     => 'SYS-MIGRATION',
                                'approved_by'    => 'SYS-MIGRATION',
                                'created_at'     => $now,
                                'updated_at'     => $now,
                            ]);
                        }
                        $createdCount++;
                    } else {
                        $skippedCount++;
                    }
                }
            }
        }

        CLI::newLine();
        CLI::write("LEAVE MIGRATION SUMMARY:", 'white', 'blue');
        CLI::write("  Rules Created: {$createdCount}", 'green');
        CLI::write("  Rules Skipped: {$skippedCount}", 'yellow');
        CLI::write("================================================================", 'cyan');

        return 0;
    }

    /**
     * Extract and normalize leave rules from leave_policies, leave_types, and leave_type_eligibility_rules
     */
    public function extractLeaveRulesForCompany($db, string $companyId): array
    {
        $result = [
            'Company'     => null,
            'Branch'      => [],
            'Department'  => [],
            'Designation' => [],
            'Employee'    => [],
        ];

        // 1. Fetch leave types
        $leaveTypes = [];
        if ($db->tableExists('leave_types')) {
            $qb = $db->table('leave_types');
            if ($db->fieldExists('company_id', 'leave_types')) {
                $qb->where("(company_id = '{$companyId}' OR company_id IS NULL OR company_id = '')");
            }
            $leaveTypes = $qb->get()->getResultArray();
        }

        $typeMap = [];
        foreach ($leaveTypes as $lt) {
            $code = strtoupper($lt['code'] ?? 'LV');
            $id = $lt['id'] ?? $code;
            $typeMap[$id] = $code;
        }

        // 2. Fetch eligibility rules
        $eligibilityRules = [];
        if ($db->tableExists('leave_type_eligibility_rules')) {
            $eqb = $db->table('leave_type_eligibility_rules');
            if ($db->fieldExists('company_id', 'leave_type_eligibility_rules')) {
                $eqb->where("(company_id = '{$companyId}' OR company_id IS NULL OR company_id = '')");
            }
            $rawRules = $eqb->get()->getResultArray();
            foreach ($rawRules as $r) {
                $ltId = $r['leave_type_id'] ?? '';
                $ltCode = $typeMap[$ltId] ?? strtoupper($r['leave_type_name'] ?? 'LV');
                $eligibilityRules[] = [
                    'leave_type_id'        => $ltId,
                    'leave_type_code'      => $ltCode,
                    'employment_type_id'   => $r['employment_type_id'] ?? null,
                    'eligibility_mode'     => $r['eligibility_mode'] ?? 'after_probation',
                    'waiting_period_value' => (int)($r['waiting_period_value'] ?? 0),
                    'waiting_period_unit'  => $r['waiting_period_unit'] ?? 'Months',
                    'accrual_start_mode'   => $r['accrual_start_mode'] ?? 'from_joining',
                    'allow_advance_leave'  => !empty($r['allow_advance_leave']),
                    'blocked_message'      => $r['blocked_message'] ?? null,
                    'status'               => $r['status'] ?? 'active',
                ];
            }
        }

        // 3. Fetch policies
        $policies = [];
        if ($db->tableExists('leave_policies')) {
            $pqb = $db->table('leave_policies');
            if ($db->fieldExists('company_id', 'leave_policies')) {
                $pqb->where("(company_id = '{$companyId}' OR company_id IS NULL OR company_id = '')");
            }
            $policies = $pqb->get()->getResultArray();
        }

        // Sort policies: Global first, then Company, then specific scopes
        $companyPolicy = null;
        $childPolicies = [];

        foreach ($policies as $pol) {
            $scopeLevel = ucfirst(strtolower($pol['scope_level'] ?? 'Global'));
            if ($scopeLevel === 'Global' || $scopeLevel === 'Company') {
                if ($companyPolicy === null || ($pol['company_id'] ?? '') === $companyId) {
                    $companyPolicy = $pol;
                }
            } else {
                $childPolicies[] = $pol;
            }
        }

        // 4. Build Company Scope Rule
        $entitlements = [];
        $policyEntitlements = [];
        if ($companyPolicy && !empty($companyPolicy['entitlements_json'])) {
            $decoded = json_decode($companyPolicy['entitlements_json'], true);
            if (is_array($decoded)) {
                $policyEntitlements = $decoded;
            }
        }

        // Index policy entitlements by code or id
        $peMap = [];
        foreach ($policyEntitlements as $pe) {
            $tId = $pe['leaveTypeId'] ?? $pe['leave_type_id'] ?? '';
            $tCode = strtoupper($pe['leaveTypeCode'] ?? $pe['leave_type_code'] ?? ($typeMap[$tId] ?? ''));
            if ($tCode !== '') {
                $peMap[$tCode] = $pe;
            }
        }

        // Normalize each leave type into an entitlement
        if (!empty($leaveTypes)) {
            foreach ($leaveTypes as $lt) {
                $code = strtoupper($lt['code'] ?? 'LV');
                $pe = $peMap[$code] ?? [];
                $entitlements[] = $this->normalizeEntitlement($lt, $pe);
            }
        } else {
            // Seed fallback if leave_types table is completely empty
            $entitlements = [
                [
                    'leave_type_code'             => 'ANNUAL',
                    'days_per_year'               => 14.0,
                    'is_paid'                     => true,
                    'paid_percentage'             => 100,
                    'accrual_mode'                => 'Monthly accrual',
                    'accrual_rate_per_month'      => 1.17,
                    'accrual_timing'              => 'Beginning of month',
                    'carry_forward_allowed'       => false,
                    'carry_forward_max_days'      => 0.0,
                    'carry_forward_percentage'    => 100,
                    'carry_forward_expiry_months' => 12,
                    'max_consecutive_days'        => 14,
                    'min_notice_days'             => 3,
                    'allow_half_day'              => true,
                    'allow_negative_balance'      => false,
                    'max_negative_days'           => 0,
                    'allow_backdated_application' => true,
                    'max_backdate_days'           => 0,
                    'backdated_role_requirement'  => '',
                    'allow_future_application'    => true,
                    'max_future_days'             => 90,
                    'sandwich_rule'               => false,
                    'attachment_required'         => false,
                    'approval_required'           => true,
                    'is_auto_approved'            => false,
                    'counts_as_working_day'       => true,
                    'affects_payroll'             => true,
                    'encashment_allowed'          => true,
                    'encashment_max_days'         => 10.0,
                    'encashment_min_balance_days' => 5.0,
                    'encashment_frequency'        => 'Yearly',
                    'encashment_salary_basis'     => 'Basic Salary',
                    'encashment_divisor'          => null,
                    'encashment_formula'          => 'Basic Salary / 30 * Days',
                    'requires_reason'             => true,
                    'requires_medical_certificate'=> false,
                    'medical_certificate_threshold_days' => 0,
                    'allow_hourly_leave'          => false,
                    'min_hourly_hours'            => 2.0,
                    'max_hourly_hours'            => 4.0,
                    'allow_unpaid_split'          => true,
                    'allow_emergency_absence'     => false,
                ]
            ];
        }

        // Ensure both AL and ANNUAL are represented in Company entitlements
        $existingCodes = array_map(fn($e) => strtoupper($e['leave_type_code'] ?? ''), $entitlements);
        foreach ($entitlements as $entItem) {
            $eCode = strtoupper($entItem['leave_type_code'] ?? '');
            if ($eCode === 'ANNUAL' && !in_array('AL', $existingCodes, true)) {
                $aliasItem = $entItem;
                $aliasItem['leave_type_code'] = 'AL';
                $entitlements[] = $aliasItem;
                $existingCodes[] = 'AL';
            } elseif ($eCode === 'AL' && !in_array('ANNUAL', $existingCodes, true)) {
                $aliasItem = $entItem;
                $aliasItem['leave_type_code'] = 'ANNUAL';
                $entitlements[] = $aliasItem;
                $existingCodes[] = 'ANNUAL';
            }
        }

        // Ensure standard seed types (SL, CL, EL, ML, PL, UL, LWP) are represented in Company entitlements
        $seedValues = RuleSchemaRegistry::seedValues('LEAVE');
        $seedEnts = $seedValues['entitlements'] ?? [];
        foreach ($seedEnts as $se) {
            $sCode = strtoupper($se['leave_type_code'] ?? '');
            if ($sCode !== '' && !in_array($sCode, $existingCodes, true)) {
                $matchedEnt = null;
                foreach ($entitlements as $entItem) {
                    $ec = strtoupper($entItem['leave_type_code'] ?? '');
                    if ($ec !== '' && \App\Services\Leave\LeaveTypeMatcher::matchLeaveTypeCode($sCode, $ec)) {
                        $matchedEnt = $entItem;
                        break;
                    }
                }
                if ($matchedEnt !== null) {
                    $cloned = $matchedEnt;
                    $cloned['leave_type_code'] = $sCode;
                    $entitlements[] = $cloned;
                } else {
                    $entitlements[] = $se;
                }
                $existingCodes[] = $sCode;
            }
        }

        // Probation JSON
        $probJson = [];
        if ($companyPolicy && !empty($companyPolicy['probation_json'])) {
            $probJson = json_decode($companyPolicy['probation_json'], true) ?: [];
        }
        $probation = [
            'probation_duration_months'        => (int)($probJson['probationDurationMonths'] ?? $probJson['probation_duration_months'] ?? 6),
            'can_apply_during_probation'       => !empty($probJson['canApplyDuringProbation'] ?? $probJson['can_apply_during_probation'] ?? true),
            'accrue_during_probation'          => !empty($probJson['accrueDuringProbation'] ?? $probJson['accrue_during_probation'] ?? false),
            'allowed_leave_type_codes'         => $probJson['allowedLeaveTypeIds'] ?? $probJson['allowed_leave_type_codes'] ?? ['SL', 'UL'],
            'blocked_leave_type_codes'         => $probJson['blockedLeaveTypeIds'] ?? $probJson['blocked_leave_type_codes'] ?? ['AL', 'EL'],
            'allow_paid_leave'                 => !empty($probJson['allowPaidLeave'] ?? $probJson['allow_paid_leave'] ?? false),
            'allow_unpaid_leave'               => isset($probJson['allowUnpaidLeave']) ? !empty($probJson['allowUnpaidLeave']) : true,
            'auto_transition_on_confirmation' => isset($probJson['autoTransitionToConfirmedPolicy']) ? !empty($probJson['autoTransitionToConfirmedPolicy']) : true,
            'eligibility_rules'                => $eligibilityRules,
        ];

        // Sandwich JSON
        $sandJson = [];
        if ($companyPolicy && !empty($companyPolicy['sandwich_rules_json'])) {
            $sandJson = json_decode($companyPolicy['sandwich_rules_json'], true) ?: [];
        }
        $sandwich = [
            'enabled'                => isset($sandJson['enabled']) ? !empty($sandJson['enabled']) : true,
            'weekend_treatment'      => $sandJson['weekendTreatment'] ?? $sandJson['weekend_treatment'] ?? (!empty($sandJson['treatWeekendAsLeave']) ? 'Count weekly off as leave' : 'Include if sandwiched'),
            'holiday_treatment'      => $sandJson['holidayTreatment'] ?? $sandJson['holiday_treatment'] ?? (!empty($sandJson['treatHolidayAsLeave']) ? 'Count holidays as leave' : 'Include if sandwiched'),
            'treat_weekend_as_leave' => !empty($sandJson['treatWeekendAsLeave'] ?? $sandJson['treat_weekend_as_leave'] ?? false),
            'treat_holiday_as_leave' => !empty($sandJson['treatHolidayAsLeave'] ?? $sandJson['treat_holiday_as_leave'] ?? false),
            'bridge_leave_enabled'   => isset($sandJson['bridgeLeaveEnabled']) ? !empty($sandJson['bridgeLeaveEnabled']) : true,
            'bridge_leave_action'    => $sandJson['bridgeLeaveAction'] ?? $sandJson['bridge_leave_action'] ?? 'Count intervening days',
            'applies_to_paid_only'   => isset($sandJson['appliesToPaidLeavesOnly']) ? !empty($sandJson['appliesToPaidLeavesOnly']) : true,
        ];

        // Approval Workflow JSON
        $wfJson = [];
        if ($companyPolicy && !empty($companyPolicy['approval_workflow_json'])) {
            $wfJson = json_decode($companyPolicy['approval_workflow_json'], true) ?: [];
        }
        $approvalWorkflow = [
            'workflow_type'               => $wfJson['workflowType'] ?? $wfJson['workflow_type'] ?? 'Multi-Tier',
            'tiers'                       => $wfJson['tiers'] ?? [
                ['tier' => 1, 'name' => 'Department Manager Endorsement', 'required' => true, 'auto_approve_days_threshold' => 0],
                ['tier' => 2, 'name' => 'HR Operations Final Sanction', 'required' => true, 'auto_approve_days_threshold' => 0]
            ],
            'tier_conditions'             => $wfJson['tierConditions'] ?? $wfJson['tier_conditions'] ?? [
                ['min_days' => 1, 'max_days' => 2, 'required_approvers' => ['Department Manager Endorsement']],
                ['min_days' => 3, 'max_days' => 999, 'required_approvers' => ['Department Manager Endorsement', 'HR Operations Final Sanction']]
            ],
            'auto_approve_under_days'     => (int)($wfJson['autoApproveUnderDays'] ?? $wfJson['auto_approve_under_days'] ?? 0),
            'allow_employee_cancellation' => isset($wfJson['allowEmployeeCancellation']) ? !empty($wfJson['allowEmployeeCancellation']) : true,
            'cancellation_window'         => $wfJson['cancellationWindow'] ?? $wfJson['cancellation_window'] ?? 'Before leave start',
        ];

        // Unpaid Deductions JSON
        $unpaidJson = [];
        if ($companyPolicy && !empty($companyPolicy['unpaid_deductions_json'])) {
            $unpaidJson = json_decode($companyPolicy['unpaid_deductions_json'], true) ?: [];
        }
        $unpaidDeduction = [
            'formula'         => $unpaidJson['unpaidFormula'] ?? $unpaidJson['formula'] ?? 'Monthly Salary / 30',
            'salary_basis'    => $unpaidJson['salaryBasis'] ?? $unpaidJson['salary_basis'] ?? 'Basic Salary',
            'divisor'         => !empty($unpaidJson['divisor']) ? (int)$unpaidJson['divisor'] : 30,
            'affects_payroll' => isset($unpaidJson['affectsPayroll']) ? !empty($unpaidJson['affectsPayroll']) : true,
        ];

        $result['Company'] = [
            'entitlements'      => $entitlements,
            'probation'         => $probation,
            'sandwich'          => $sandwich,
            'approval_workflow' => $approvalWorkflow,
            'unpaid_deduction'  => $unpaidDeduction,
        ];

        // 5. Child Policies (Branch, Department, Designation, Employee)
        foreach ($childPolicies as $cp) {
            $sLevel = ucfirst(strtolower($cp['scope_level'] ?? ''));
            $sId = $cp['scope_id'] ?? null;
            if (!in_array($sLevel, ['Branch', 'Department', 'Designation', 'Employee'], true) || empty($sId)) {
                continue;
            }

            $cEntitlements = [];
            if (!empty($cp['entitlements_json'])) {
                $cDecoded = json_decode($cp['entitlements_json'], true);
                if (is_array($cDecoded)) {
                    foreach ($cDecoded as $ce) {
                        $tId = $ce['leaveTypeId'] ?? $ce['leave_type_id'] ?? '';
                        $tCode = strtoupper($ce['leaveTypeCode'] ?? $ce['leave_type_code'] ?? ($typeMap[$tId] ?? ''));
                        if ($tCode !== '') {
                            $cEntitlements[] = $this->normalizeEntitlement(['code' => $tCode], $ce);
                        }
                    }
                }
            }

            $cParams = [];
            if (!empty($cEntitlements)) {
                $cParams['entitlements'] = $cEntitlements;
            }
            if (!empty($cp['probation_json'])) {
                $cProb = json_decode($cp['probation_json'], true);
                if (is_array($cProb)) {
                    $cParams['probation'] = $cProb;
                }
            }
            if (!empty($cp['sandwich_rules_json'])) {
                $cSand = json_decode($cp['sandwich_rules_json'], true);
                if (is_array($cSand)) {
                    $cParams['sandwich'] = $cSand;
                }
            }
            if (!empty($cp['approval_workflow_json'])) {
                $cWf = json_decode($cp['approval_workflow_json'], true);
                if (is_array($cWf)) {
                    $cParams['approval_workflow'] = $cWf;
                }
            }
            if (!empty($cp['unpaid_deductions_json'])) {
                $cUnpaid = json_decode($cp['unpaid_deductions_json'], true);
                if (is_array($cUnpaid)) {
                    $cParams['unpaid_deduction'] = $cUnpaid;
                }
            }

            if (!empty($cParams)) {
                $result[$sLevel][$sId] = $cParams;
            }
        }

        return $result;
    }

    /**
     * Normalize entitlement array combining leave_types table row and policy entitlements_json item
     */
    private function normalizeEntitlement(array $lt, array $pe): array
    {
        $code = strtoupper($pe['leave_type_code'] ?? $pe['leaveTypeCode'] ?? $lt['code'] ?? 'LV');
        $days = (float)($pe['yearlyDays'] ?? $pe['days_per_year'] ?? $lt['days_per_year'] ?? $lt['annual_allocation'] ?? 0.0);
        $isPaid = isset($pe['is_paid']) ? !empty($pe['is_paid']) : (isset($lt['is_paid']) ? !empty($lt['is_paid']) : true);
        $paidPct = (int)($pe['paid_percentage'] ?? $lt['paid_percentage'] ?? 100);

        $accrualMode = $pe['entitlementMethod'] ?? $pe['accrual_mode'] ?? $lt['accrual_mode'] ?? 'Fixed yearly days';
        if (!in_array($accrualMode, ['Fixed yearly days', 'Monthly accrual', 'Pro-rata', 'Service-based', 'Calendar days'], true)) {
            $accrualMode = (stripos($accrualMode, 'monthly') !== false) ? 'Monthly accrual' : 'Fixed yearly days';
        }

        $earnEveryDays = isset($pe['earn_every_days']) ? (int)$pe['earn_every_days'] : (isset($lt['earn_every_days']) ? (int)$lt['earn_every_days'] : null);
        $earnLeavePerCycle = isset($pe['earn_leave_per_cycle']) ? (float)$pe['earn_leave_per_cycle'] : (isset($lt['earn_leave_per_cycle']) ? (float)$lt['earn_leave_per_cycle'] : 1.0);
        $accrualTimingMode = $pe['accrual_credit_timing'] ?? $lt['accrual_credit_timing'] ?? 'on_completion';
        $accrualStartFrom = $pe['accrual_start_from'] ?? $lt['accrual_start_from'] ?? 'joining_date';
        $accrualFixedStart = $pe['accrual_fixed_start_date'] ?? $lt['accrual_fixed_start_date'] ?? null;
        $maxCap = isset($pe['max_balance_cap']) && $pe['max_balance_cap'] !== null ? (float)$pe['max_balance_cap'] : (isset($lt['max_balance_cap']) && $lt['max_balance_cap'] !== null ? (float)$lt['max_balance_cap'] : null);

        $accrualRate = (float)($pe['accrualRatePerMonth'] ?? $pe['accrual_rate_per_month'] ?? $lt['accrual_rate_per_month'] ?? ($days > 0 ? round($days / 12, 2) : 0.0));
        $accrualTiming = $pe['accrualTiming'] ?? $pe['accrual_timing'] ?? $lt['accrual_timing'] ?? ($accrualMode === 'Monthly accrual' ? 'Beginning of month' : 'Beginning of year');

        $allowCf = isset($pe['allowCarryForward']) ? !empty($pe['allowCarryForward']) : (!empty($lt['allow_carry_forward'] ?? $lt['carry_forward']));
        $maxCf = (float)($pe['maxCarryForwardDays'] ?? $pe['carry_forward_max_days'] ?? $lt['max_carry_forward_days'] ?? $lt['carry_forward_days'] ?? 0.0);
        $cfPct = (int)($pe['carry_forward_percentage'] ?? $lt['carry_forward_percentage'] ?? 100);
        $cfExpiry = (int)($pe['carry_forward_expiry_months'] ?? $lt['carry_forward_expiry_months'] ?? 12);

        $maxConsec = (int)($pe['max_consecutive_days'] ?? $lt['max_consecutive_days'] ?? 14);
        $minNotice = (int)($pe['min_notice_days'] ?? $lt['min_notice_days'] ?? 3);
        $halfDay = isset($pe['allow_half_day']) ? !empty($pe['allow_half_day']) : (!empty($lt['allow_half_day'] ?? 1));

        $negBal = isset($pe['allow_negative_balance']) ? !empty($pe['allow_negative_balance']) : (!empty($lt['allow_negative_balance'] ?? 0));
        $maxNeg = (int)($pe['max_negative_days'] ?? $lt['max_negative_days'] ?? 0);

        $allowBackdate = isset($pe['allow_backdated_application']) ? !empty($pe['allow_backdated_application']) : (!empty($lt['allow_backdated_application'] ?? 1));
        $maxBackdate = (int)($pe['max_backdate_days'] ?? $lt['max_backdate_days'] ?? 0);
        $backdateRole = $pe['backdated_role_requirement'] ?? $lt['backdated_role_requirement'] ?? '';

        $allowFuture = isset($pe['allow_future_application']) ? !empty($pe['allow_future_application']) : (!empty($lt['allow_future_application'] ?? 1));
        $maxFuture = (int)($pe['max_future_days'] ?? $lt['max_future_days'] ?? 90);

        $sandwich = isset($pe['sandwich_rule']) ? !empty($pe['sandwich_rule']) : (!empty($lt['sandwich_rule'] ?? 0));
        $reqAttach = isset($pe['attachment_required']) ? !empty($pe['attachment_required']) : (!empty($lt['requires_attachment'] ?? $lt['attachment_required'] ?? 0));
        $reqAppr = isset($pe['approval_required']) ? !empty($pe['approval_required']) : (!empty($lt['requires_approval'] ?? $lt['approval_required'] ?? 1));
        $autoAppr = isset($pe['is_auto_approved']) ? !empty($pe['is_auto_approved']) : (!empty($lt['is_auto_approved'] ?? 0));
        $countsWork = isset($pe['counts_as_working_day']) ? !empty($pe['counts_as_working_day']) : (!empty($lt['counts_as_working_day'] ?? 1));
        $affectsPay = isset($pe['affects_payroll']) ? !empty($pe['affects_payroll']) : (!empty($lt['affects_payroll'] ?? 1));

        $encashAllowed = isset($pe['allowEncashment']) ? !empty($pe['allowEncashment']) : ($lt['encashment'] === 'Yes' || !empty($lt['encashment']) || !empty($lt['allow_encashment']));
        $encashMax = (float)($pe['encashmentMaxDays'] ?? $pe['encashment_max_days'] ?? $lt['max_encashment_days'] ?? 0.0);
        $encashMin = (float)($pe['encashmentMinBalanceDays'] ?? $pe['encashment_min_balance_days'] ?? $lt['min_balance_for_encashment'] ?? 0.0);
        $encashFreq = $pe['encashmentFrequency'] ?? $pe['encashment_frequency'] ?? $lt['encashment_frequency'] ?? 'Yearly';
        if (!in_array($encashFreq, ['Monthly', 'Quarterly', 'Bi-annually', 'Yearly', 'On Separation'], true)) {
            $encashFreq = 'Yearly';
        }
        $encashBasis = $pe['encashmentSalaryBasis'] ?? $pe['encashment_salary_basis'] ?? $lt['encashment_salary_basis'] ?? 'Basic Salary';
        if (!in_array($encashBasis, ['Basic Salary', 'Gross Salary', 'Daily Salary', 'Fixed Rate'], true)) {
            $encashBasis = 'Basic Salary';
        }
        $encashDiv = !empty($pe['encashmentDivisor']) ? (int)$pe['encashmentDivisor'] : (!empty($lt['encashment_divisor']) ? (int)$lt['encashment_divisor'] : null);
        $encashFormula = $pe['encashmentFormula'] ?? $pe['encashment_formula'] ?? $lt['encashment_formula'] ?? 'Basic Salary / 30 * Days';

        $reqReason = isset($pe['requires_reason']) ? !empty($pe['requires_reason']) : (isset($lt['requires_reason']) ? !empty($lt['requires_reason']) : true);
        $reqMedCert = isset($pe['requires_medical_certificate']) ? !empty($pe['requires_medical_certificate']) : (!empty($lt['requires_medical_certificate'] ?? 0));
        $medCertThresh = (int)($pe['medical_certificate_threshold_days'] ?? $lt['medical_certificate_threshold_days'] ?? 0);
        $allowHourly = isset($pe['allow_hourly_leave']) ? !empty($pe['allow_hourly_leave']) : (!empty($lt['allow_hourly_leave'] ?? 0));
        $minHourly = (float)($pe['min_hourly_hours'] ?? $lt['min_hourly_hours'] ?? 2.0);
        $maxHourly = (float)($pe['max_hourly_hours'] ?? $lt['max_hourly_hours'] ?? 4.0);
        $allowUnpaidSplit = isset($pe['allow_unpaid_split']) ? !empty($pe['allow_unpaid_split']) : (!empty($lt['allow_unpaid_split'] ?? 0));
        $allowEmergency = isset($pe['allow_emergency_absence'])
            ? !empty($pe['allow_emergency_absence'])
            : (isset($lt['allow_emergency_absence']) ? !empty($lt['allow_emergency_absence']) : in_array($code, ['SL', 'SICK', 'CL', 'CASUAL'], true));

        return [
            'leave_type_code'             => $code,
            'days_per_year'               => $days,
            'is_paid'                     => $isPaid,
            'paid_percentage'             => $paidPct,
            'accrual_mode'                => $accrualMode,
            'earn_every_days'             => $earnEveryDays,
            'earn_leave_per_cycle'        => $earnLeavePerCycle,
            'accrual_credit_timing'       => $accrualTimingMode,
            'accrual_start_from'          => $accrualStartFrom,
            'accrual_fixed_start_date'    => $accrualFixedStart,
            'max_balance_cap'             => $maxCap,
            'accrual_rate_per_month'      => $accrualRate,
            'accrual_timing'              => $accrualTiming,
            'carry_forward_allowed'       => $allowCf,
            'carry_forward_max_days'      => $maxCf,
            'carry_forward_percentage'    => $cfPct,
            'carry_forward_expiry_months' => $cfExpiry,
            'max_consecutive_days'        => $maxConsec,
            'min_notice_days'             => $minNotice,
            'allow_half_day'              => $halfDay,
            'allow_negative_balance'      => $negBal,
            'max_negative_days'           => $maxNeg,
            'allow_backdated_application' => $allowBackdate,
            'max_backdate_days'           => $maxBackdate,
            'backdated_role_requirement'  => $backdateRole,
            'allow_future_application'    => $allowFuture,
            'max_future_days'             => $maxFuture,
            'sandwich_rule'               => $sandwich,
            'attachment_required'         => $reqAttach,
            'approval_required'           => $reqAppr,
            'is_auto_approved'            => $autoAppr,
            'counts_as_working_day'       => $countsWork,
            'affects_payroll'             => $affectsPay,
            'encashment_allowed'          => $encashAllowed,
            'encashment_max_days'         => $encashMax,
            'encashment_min_balance_days' => $encashMin,
            'encashment_frequency'        => $encashFreq,
            'encashment_salary_basis'     => $encashBasis,
            'encashment_divisor'          => $encashDiv,
            'encashment_formula'          => $encashFormula,
            'requires_reason'             => $reqReason,
            'requires_medical_certificate'=> $reqMedCert,
            'medical_certificate_threshold_days' => $medCertThresh,
            'allow_hourly_leave'          => $allowHourly,
            'min_hourly_hours'            => $minHourly,
            'max_hourly_hours'            => $maxHourly,
            'allow_unpaid_split'          => $allowUnpaidSplit,
            'allow_emergency_absence'     => $allowEmergency,
        ];
    }
}
