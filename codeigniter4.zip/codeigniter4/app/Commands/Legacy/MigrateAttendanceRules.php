<?php

/**
 * legacy one-time migration
 */

namespace App\Commands\Legacy;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use Config\Database;
use App\Models\CompanyModel;
use App\Services\Rules\RuleSchemaRegistry;
use App\Services\Rules\RuleParamValidator;

class MigrateAttendanceRules extends BaseCommand
{
    protected $group       = 'Rules';
    protected $name        = 'rules:migrate-attendance';
    protected $description = 'Migrates attendance profiles, policies, and weekend settings to rule_definitions (ATTENDANCE domain).';
    protected $usage       = 'rules:migrate-attendance [--dry-run] [--company=COMPANY_ID]';
    protected $options     = [
        '--dry-run' => 'Simulate migration without inserting or modifying rule_definitions.',
        '--company' => 'Limit migration to a specific company ID or code.',
    ];

    public function run(array $params)
    {
        CLI::write("================================================================", 'cyan');
        CLI::write("           ATTENDANCE TO RULE STORE MIGRATION                   ", 'white', 'blue');
        CLI::write("================================================================", 'cyan');

        $dryRun = CLI::getOption('dry-run') !== null || in_array('--dry-run', $params, true);
        $companyFilter = CLI::getOption('company') ?? null;

        foreach ($params as $k => $v) {
            if (is_string($v) && str_starts_with($v, '--company=')) {
                $companyFilter = substr($v, 10);
            }
            if ($k === 'company' && empty($companyFilter)) {
                $companyFilter = $v;
            }
        }

        if ($dryRun) {
            CLI::write("MODE: DRY RUN (Zero database mutations)", 'yellow');
        } else {
            CLI::write("MODE: LIVE MIGRATION", 'green');
        }
        CLI::newLine();

        $db = Database::connect();
        RuleSchemaRegistry::init();

        $companyModel = new CompanyModel();
        $companies = [];

        if (!empty($companyFilter)) {
            $comp = $companyModel->find($companyFilter)
                ?: $companyModel->where('code', $companyFilter)->first()
                ?: $companyModel->where('id', $companyFilter)->first();

            if (!$comp) {
                CLI::error("Error: Company not found with ID or code '{$companyFilter}'");
                return 1;
            }
            $companies = [$comp];
        } else {
            $companies = $companyModel->findAll();
        }

        if (empty($companies)) {
            CLI::write("No companies found in database to migrate attendance rules for.", 'yellow');
            return 0;
        }

        $totalCompanies = count($companies);
        CLI::write("Processing {$totalCompanies} company(ies)...", 'white');
        CLI::newLine();

        $totalCreated = 0;
        $totalSkipped = 0;
        $now = date('Y-m-d H:i:s');

        foreach ($companies as $idx => $company) {
            $companyId = $company['id'];
            $companyName = $company['name'] ?? $companyId;
            CLI::write(sprintf("[%d/%d] Company: %s (%s)", $idx + 1, $totalCompanies, $companyName, $companyId), 'yellow');

            $extracted = $this->extractAttendanceRulesForCompany($db, $companyId);

            // 1. Company Scope
            $companyParams = $extracted['Company'] ?? [];
            $seedDefaults  = RuleSchemaRegistry::seedValues('ATTENDANCE');
            $mergedCompany = array_merge($seedDefaults, $companyParams);

            $val = RuleParamValidator::validate('ATTENDANCE', 'Company', $mergedCompany, false);
            if (!$val['valid']) {
                CLI::write("  [WARN] Company scope validation had errors, applying clean params: " . implode(', ', $val['errors']), 'red');
            }
            $cleanCompanyParams = $val['valid'] ? $val['clean'] : $mergedCompany;

            $existingCompanyRule = $db->table('rule_definitions')
                ->where('company_id', $companyId)
                ->where('domain', 'ATTENDANCE')
                ->where('scope_level', 'Company')
                ->where('version_number', 1)
                ->countAllResults();

            if ($existingCompanyRule === 0) {
                if (!$dryRun) {
                    $db->table('rule_definitions')->insert([
                        'id'             => 'rd-' . bin2hex(random_bytes(8)),
                        'company_id'     => $companyId,
                        'domain'         => 'ATTENDANCE',
                        'scope_level'    => 'Company',
                        'scope_id'       => null,
                        'version_number' => 1,
                        'effective_from' => '2020-01-01',
                        'effective_to'   => null,
                        'status'         => 'Active',
                        'params_json'    => json_encode($cleanCompanyParams, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                        'schema_version' => 1,
                        'change_reason'  => 'P18: Migration of attendance policies and profiles to Single Rule Store',
                        'created_by'     => 'SYS-MIGRATION',
                        'approved_by'    => 'SYS-MIGRATION',
                        'created_at'     => $now,
                        'updated_at'     => $now,
                    ]);
                }
                CLI::write("  [CREATED] Company-level rule definition inserted", 'green');
                $totalCreated++;
            } else {
                CLI::write("  [SKIP] Company-level rule definition already exists", 'light_gray');
                $totalSkipped++;
            }

            // 2. Child Scopes (Branch, Department, Designation, Shift, Employee)
            $allowedChildScopes = ['Branch', 'Department', 'Designation', 'Shift', 'Employee'];
            foreach ($allowedChildScopes as $childScope) {
                if (empty($extracted[$childScope])) {
                    continue;
                }

                foreach ($extracted[$childScope] as $scopeId => $scopeParams) {
                    if (empty($scopeParams) || empty($scopeId)) {
                        continue;
                    }

                    $childVal = RuleParamValidator::validate('ATTENDANCE', $childScope, $scopeParams, true);
                    $cleanChild = $childVal['valid'] ? $childVal['clean'] : $scopeParams;

                    $existingChild = $db->table('rule_definitions')
                        ->where('company_id', $companyId)
                        ->where('domain', 'ATTENDANCE')
                        ->where('scope_level', $childScope)
                        ->where('scope_id', $scopeId)
                        ->where('version_number', 1)
                        ->countAllResults();

                    if ($existingChild === 0) {
                        if (!$dryRun) {
                            $db->table('rule_definitions')->insert([
                                'id'             => 'rd-' . bin2hex(random_bytes(8)),
                                'company_id'     => $companyId,
                                'domain'         => 'ATTENDANCE',
                                'scope_level'    => $childScope,
                                'scope_id'       => $scopeId,
                                'version_number' => 1,
                                'effective_from' => '2020-01-01',
                                'effective_to'   => null,
                                'status'         => 'Active',
                                'params_json'    => json_encode($cleanChild, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                                'schema_version' => 1,
                                'change_reason'  => "P18: Scoped override migration for {$childScope} {$scopeId}",
                                'created_by'     => 'SYS-MIGRATION',
                                'approved_by'    => 'SYS-MIGRATION',
                                'created_at'     => $now,
                                'updated_at'     => $now,
                            ]);
                        }
                        CLI::write("  [CREATED] {$childScope} rule override inserted for ID: {$scopeId}", 'green');
                        $totalCreated++;
                    } else {
                        CLI::write("  [SKIP] {$childScope} rule override already exists for ID: {$scopeId}", 'light_gray');
                        $totalSkipped++;
                    }
                }
            }
        }

        CLI::newLine();
        CLI::write("================================================================", 'cyan');
        CLI::write("MIGRATION SUMMARY", 'white', 'blue');
        CLI::write("================================================================", 'cyan');
        CLI::write("  Created Rules : {$totalCreated}", 'green');
        CLI::write("  Skipped Rules : {$totalSkipped}", 'yellow');
        CLI::newLine();

        return 0;
    }

    /**
     * Extract attendance parameters from attendance_rule_profiles and system_settings
     */
    protected function extractAttendanceRulesForCompany($db, string $companyId): array
    {
        $result = [
            'Company'     => [],
            'Branch'      => [],
            'Department'  => [],
            'Designation' => [],
            'Shift'       => [],
            'Employee'    => [],
        ];

        // 1. Extract from attendance_rule_profiles
        if ($db->tableExists('attendance_rule_profiles')) {
            $builder = $db->table('attendance_rule_profiles');
            if ($db->fieldExists('company_id', 'attendance_rule_profiles')) {
                $builder->groupStart()
                    ->where('company_id', $companyId)
                    ->orWhere('company_id IS NULL')
                    ->orWhere('company_id', '')
                ->groupEnd();
            }
            if ($db->fieldExists('status', 'attendance_rule_profiles')) {
                $builder->where('status', 'Active');
            }
            if ($db->fieldExists('version', 'attendance_rule_profiles')) {
                $builder->orderBy('version', 'ASC');
            }
            $profiles = $builder->get()->getResultArray();

            foreach ($profiles as $prof) {
                $rawJson = $prof['configuration_json'] ?? ($prof['rules_json'] ?? '');
                $cfg = !empty($rawJson) ? json_decode($rawJson, true) : [];
                if (!is_array($cfg)) {
                    $cfg = [];
                }

                $params = $this->mapProfileConfigToParams($cfg);
                $scopeLevel = $prof['scope_level'] ?? 'Company';
                if ($scopeLevel === 'Global') {
                    $scopeLevel = 'Company';
                }

                $scopeId = $prof['scope_id'] ?? null;
                if ($scopeLevel === 'Company' || empty($scopeId)) {
                    $result['Company'] = array_merge($result['Company'], $params);
                } elseif (isset($result[$scopeLevel])) {
                    $result[$scopeLevel][$scopeId] = $params;
                }
            }
        }

        // 2. Extract from system_settings (hrms_attendance_settings)
        if ($db->tableExists('system_settings')) {
            $hasCompanyCol = $db->fieldExists('company_id', 'system_settings');
            $builder = $db->table('system_settings')->where('setting_key', 'hrms_attendance_settings');
            if ($hasCompanyCol) {
                $builder->groupStart()
                    ->where('company_id', $companyId)
                    ->orWhere('company_id IS NULL')
                    ->orWhere('company_id', '')
                ->groupEnd();
            }
            $settingRow = $builder->get()->getRowArray();

            if ($settingRow && !empty($settingRow['setting_value'])) {
                $parsed = json_decode($settingRow['setting_value'], true);
                if (is_array($parsed)) {
                    if (isset($parsed['standardDailyHours'])) {
                        $result['Company']['daily_required_hours'] = (float)$parsed['standardDailyHours'];
                    }
                    if (!empty($parsed['officeStartTime'])) {
                        $result['Company']['office_start_time'] = substr(trim((string)$parsed['officeStartTime']), 0, 5);
                    }
                    if (!empty($parsed['officeEndTime'])) {
                        $result['Company']['office_end_time'] = substr(trim((string)$parsed['officeEndTime']), 0, 5);
                    }
                    if (isset($parsed['graceTime'])) {
                        $result['Company']['late_grace_minutes'] = (int)$parsed['graceTime'];
                    }
                    if (!empty($parsed['halfDayTime'])) {
                        $result['Company']['half_day_time'] = substr(trim((string)$parsed['halfDayTime']), 0, 5);
                    }
                    if (!empty($parsed['weekendDays'])) {
                        $rawW = is_array($parsed['weekendDays']) ? $parsed['weekendDays'] : [$parsed['weekendDays']];
                        $validDays = ['Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
                        $cleanW = [];
                        foreach ($rawW as $wd) {
                            foreach ($validDays as $vd) {
                                if (strcasecmp(trim((string)$wd), $vd) === 0) {
                                    $cleanW[] = $vd;
                                    break;
                                }
                            }
                        }
                        if (!empty($cleanW)) {
                            $result['Company']['weekly_off_days'] = array_values(array_unique($cleanW));
                        }
                    }
                    if (!empty($parsed['lateDeductionRatio'])) {
                        $ratioStr = trim((string)$parsed['lateDeductionRatio']);
                        if (preg_match('/(\d+)\s*(?:late\s*days?|days?).*?=\s*(\d+(?:\.\d+)?)/i', $ratioStr, $m)) {
                            $result['Company']['late_consecutive_days_threshold'] = (int)$m[1];
                            $result['Company']['late_consecutive_penalty_leave_days'] = (float)$m[2];
                        }
                    }

                    // Security / geofence settings to hrms_attendance_security_settings
                    $secData = [
                        'geofenceRadius' => (int)($parsed['geofenceRadius'] ?? 200),
                        'strictGeofence' => !empty($parsed['strictGeofence']) ? 1 : 0,
                        'allowedIp'      => (string)($parsed['allowedIp'] ?? '103.112.54.9'),
                    ];
                    $secBuilder = $db->table('system_settings')->where('setting_key', 'hrms_attendance_security_settings');
                    if ($hasCompanyCol) {
                        $secBuilder->where('company_id', $companyId);
                    }
                    $existingSec = $secBuilder->get()->getRowArray();
                    if (!$existingSec) {
                        $secFields = $db->getFieldNames('system_settings');
                        $secInsert = [
                            'setting_key'   => 'hrms_attendance_security_settings',
                            'setting_value' => json_encode($secData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                        ];
                        if (in_array('id', $secFields)) {
                            $secInsert['id'] = 'set-' . bin2hex(random_bytes(8));
                        }
                        if (in_array('company_id', $secFields)) {
                            $secInsert['company_id'] = $companyId;
                        }
                        if (in_array('description', $secFields)) {
                            $secInsert['description'] = "Security and GPS geofence settings for company {$companyId}";
                        }
                        if (in_array('group_name', $secFields)) {
                            $secInsert['group_name'] = 'security';
                        }
                        if (in_array('created_at', $secFields)) {
                            $secInsert['created_at'] = date('Y-m-d H:i:s');
                        }
                        if (in_array('updated_at', $secFields)) {
                            $secInsert['updated_at'] = date('Y-m-d H:i:s');
                        }
                        $db->table('system_settings')->insert($secInsert);
                    }
                }
            }
        }

        return $result;
    }

    /**
     * Map configuration_json to ATTENDANCE schema params
     */
    protected function mapProfileConfigToParams(array $cfg): array
    {
        $p = [];

        if (!empty($cfg['workingWeek'])) {
            $ww = $cfg['workingWeek'];
            if (!empty($ww['weekStartDay']) && in_array($ww['weekStartDay'], ['Saturday', 'Sunday', 'Monday'], true)) {
                $p['week_start_day'] = $ww['weekStartDay'];
            }
            if (!empty($ww['weeklyOffDays'])) {
                $p['weekly_off_days'] = array_values((array)$ww['weeklyOffDays']);
            }
            if (isset($ww['standardDailyHours'])) {
                $p['daily_required_hours'] = (float)$ww['standardDailyHours'];
            }
        }

        if (!empty($cfg['dailyHours'])) {
            $dh = $cfg['dailyHours'];
            if (isset($dh['dailyRequiredHours'])) {
                $p['daily_required_hours'] = (float)$dh['dailyRequiredHours'];
            }
            if (isset($dh['halfDayThresholdHours'])) {
                $p['half_day_threshold_hours'] = (float)$dh['halfDayThresholdHours'];
            }
            if (isset($dh['minWorkHoursForPresent'])) {
                $p['min_work_hours_for_present'] = (float)$dh['minWorkHoursForPresent'];
            }
        }

        if (!empty($cfg['breakRule'])) {
            $br = $cfg['breakRule'];
            if (isset($br['enabled'])) {
                $p['break_enabled'] = !empty($br['enabled']);
            }
            if (isset($br['breakDurationMinutes'])) {
                $p['break_duration_minutes'] = (int)$br['breakDurationMinutes'];
            }
            if (isset($br['isPaid'])) {
                $p['break_is_paid'] = !empty($br['isPaid']);
            }
            if (isset($br['unpaidBreakTreatment'])) {
                $p['unpaid_break_treatment'] = (string)$br['unpaidBreakTreatment'];
            }
            if (isset($br['autoDeductBreak'])) {
                $p['break_auto_deduct'] = !empty($br['autoDeductBreak']);
            }
        }

        if (!empty($cfg['lateRule'])) {
            $lr = $cfg['lateRule'];
            if (isset($lr['enabled'])) {
                $p['late_enabled'] = !empty($lr['enabled']);
            }
            if (isset($lr['gracePeriodMinutes'])) {
                $p['late_grace_minutes'] = (int)$lr['gracePeriodMinutes'];
            }
            if (!empty($lr['penaltyMethod'])) {
                $validMethods = ["Warning", "Deduction", "Reduce working hours", "Leave deduction", "Ignore"];
                foreach ($validMethods as $vm) {
                    if (strcasecmp($vm, $lr['penaltyMethod']) === 0) {
                        $p['late_penalty_method'] = $vm;
                        break;
                    }
                }
            }
            if (isset($lr['penaltyDeductionAmountPerMinute'])) {
                $p['late_penalty_per_minute'] = (float)$lr['penaltyDeductionAmountPerMinute'];
            }
            if (isset($lr['consecutiveLateDaysThreshold'])) {
                $p['late_consecutive_days_threshold'] = (int)$lr['consecutiveLateDaysThreshold'];
            }
            if (isset($lr['consecutiveLatePenaltyLeaveDays'])) {
                $p['late_consecutive_penalty_leave_days'] = (float)$lr['consecutiveLatePenaltyLeaveDays'];
            }
        }

        if (!empty($cfg['earlyOutRule'])) {
            $eor = $cfg['earlyOutRule'];
            if (isset($eor['enabled'])) {
                $p['early_out_enabled'] = !empty($eor['enabled']);
            }
            if (isset($eor['earlyOutThresholdMinutes'])) {
                $p['early_out_threshold_minutes'] = (int)$eor['earlyOutThresholdMinutes'];
            }
            if (!empty($eor['penaltyMethod'])) {
                $validMethods = ["Warning", "Deduction", "Reduce working hours", "Leave deduction", "Ignore"];
                foreach ($validMethods as $vm) {
                    if (strcasecmp($vm, $eor['penaltyMethod']) === 0) {
                        $p['early_out_penalty_method'] = $vm;
                        break;
                    }
                }
            }
            if (isset($eor['penaltyDeductionAmountPerMinute'])) {
                $p['early_out_penalty_per_minute'] = (float)$eor['penaltyDeductionAmountPerMinute'];
            }
        }

        if (!empty($cfg['missingDayRule'])) {
            $mdr = $cfg['missingDayRule'];
            if (!empty($mdr['policy']) && in_array($mdr['policy'], ['Actual Hours Only', 'Pro-rated Target'], true)) {
                $p['missing_day_policy'] = $mdr['policy'];
            }
            if (isset($mdr['allowWeeklyBonusIfHoursMet'])) {
                $p['missing_day_allow_weekly_bonus_if_hours_met'] = !empty($mdr['allowWeeklyBonusIfHoursMet']);
            }
        }

        if (!empty($cfg['holidayTreatment'])) {
            $ht = $cfg['holidayTreatment'];
            if (isset($ht['countsAsWorkingHours'])) {
                $p['holiday_counts_as_working_hours'] = !empty($ht['countsAsWorkingHours']);
            }
            if (isset($ht['creditedWorkingHours'])) {
                $p['holiday_credited_hours'] = (float)$ht['creditedWorkingHours'];
            }
            if (isset($ht['countsTowardWeeklyRequirement'])) {
                $p['holiday_counts_toward_weekly_requirement'] = !empty($ht['countsTowardWeeklyRequirement']);
            }
        }

        if (!empty($cfg['leaveTreatments']) && is_array($cfg['leaveTreatments'])) {
            $cleanTreatments = [];
            foreach ($cfg['leaveTreatments'] as $lt) {
                if (!is_array($lt)) continue;
                $code = strtoupper(trim((string)($lt['leave_type_code'] ?? ($lt['leaveTypeId'] ?? ''))));
                if ($code === '') continue;
                $cleanTreatments[] = [
                    'leave_type_code'         => $code,
                    'counts_as_working_day'   => !empty($lt['counts_as_working_day'] ?? ($lt['countsAsWorkingDay'] ?? false)),
                    'counts_as_working_hours' => !empty($lt['counts_as_working_hours'] ?? ($lt['countsAsWorkingHours'] ?? false)),
                    'credited_hours_per_day'  => (float)($lt['credited_hours_per_day'] ?? ($lt['creditedWorkingHoursPerDay'] ?? 8.0)),
                    'affects_weekly_bonus'    => !empty($lt['affects_weekly_bonus'] ?? ($lt['affectsWeeklyBonus'] ?? true)),
                    'affects_attendance'      => !empty($lt['affects_attendance'] ?? ($lt['affectsAttendance'] ?? true)),
                ];
            }
            if (!empty($cleanTreatments)) {
                $p['leave_treatments'] = $cleanTreatments;
            }
        }

        return $p;
    }
}
