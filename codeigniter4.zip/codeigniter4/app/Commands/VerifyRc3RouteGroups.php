<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use Config\Services;

class VerifyRc3RouteGroups extends BaseCommand
{
    protected $group       = 'Verification';
    protected $name        = 'verify:rc3-route-groups';
    protected $description = 'Verifies the RC-3 route group split and permission filter disjunction.';

    public function run(array $params)
    {
        CLI::write("==================================================================", 'cyan');
        CLI::write("       VERIFY RC-3: ROUTE GROUPS & FILTER DISJUNCTION             ", 'yellow');
        CLI::write("==================================================================", 'cyan');

        $routes = Services::routes();
        $routesList = $routes->getRoutes();

        $passed = 0;
        $failed = 0;

        // 1. Verify payroll/bonuses does not have group-level permission:payroll.view
        CLI::write("[Check 1] Inspecting filters on /payroll/bonuses...", 'white');
        $bonusFilter = $routes->getFilterForRoute('payroll/bonuses');
        $hasGroupPayrollViewOnBonuses = str_contains($bonusFilter, 'permission:payroll.view');
        $hasBonusView = str_contains($bonusFilter, 'permission:bonus.view');

        if (!$hasGroupPayrollViewOnBonuses && $hasBonusView) {
            CLI::write("  -> PASSED: /payroll/bonuses has permission:bonus.view without outer permission:payroll.view.", 'green');
            $passed++;
        } else {
            CLI::write("  -> FAILED: /payroll/bonuses filter was: '{$bonusFilter}'", 'red');
            $failed++;
        }

        // 2. Verify payroll/loans does not have group-level permission:payroll.view
        CLI::write("[Check 2] Inspecting filters on /payroll/loans...", 'white');
        $loanFilter = $routes->getFilterForRoute('payroll/loans');
        $hasGroupPayrollViewOnLoans = str_contains($loanFilter, 'permission:payroll.view');
        $hasLoansView = str_contains($loanFilter, 'permission:loans.view');

        if (!$hasGroupPayrollViewOnLoans && $hasLoansView) {
            CLI::write("  -> PASSED: /payroll/loans has permission:loans.view without outer permission:payroll.view.", 'green');
            $passed++;
        } else {
            CLI::write("  -> FAILED: /payroll/loans filter was: '{$loanFilter}'", 'red');
            $failed++;
        }

        // 3. Verify payroll/pf/reports/summary has permission:pf.view|payroll.view without outer permission:payroll.view
        CLI::write("[Check 3] Inspecting filters on /payroll/pf/reports/summary...", 'white');
        $pfFilter = $routes->getFilterForRoute('payroll/pf/reports/summary');
        $hasOnlyPfDisjunction = str_contains($pfFilter, 'permission:pf.view|payroll.view');
        $hasSeparatePayrollView = (substr_count($pfFilter, 'permission:payroll.view') > 0 && !str_contains($pfFilter, 'permission:pf.view|payroll.view'));

        if ($hasOnlyPfDisjunction && !$hasSeparatePayrollView) {
            CLI::write("  -> PASSED: /payroll/pf/reports/summary uses route-level OR disjunction without group override.", 'green');
            $passed++;
        } else {
            CLI::write("  -> FAILED: /payroll/pf/reports/summary filter was: '{$pfFilter}'", 'red');
            $failed++;
        }

        // 4. Verify pf/reports/summary has route filter permission:pf.view|payroll.view
        CLI::write("[Check 4] Inspecting filters on /pf/reports/summary...", 'white');
        $pfStandaloneFilter = $routes->getFilterForRoute('pf/reports/summary');
        if (str_contains($pfStandaloneFilter, 'permission:pf.view|payroll.view')) {
            CLI::write("  -> PASSED: /pf/reports/summary now enforces permission:pf.view|payroll.view.", 'green');
            $passed++;
        } else {
            CLI::write("  -> FAILED: /pf/reports/summary filter was: '{$pfStandaloneFilter}'", 'red');
            $failed++;
        }

        // 5. Verify core payroll route retains permission:payroll.view
        CLI::write("[Check 5] Inspecting filters on core /payroll...", 'white');
        $payrollFilter = $routes->getFilterForRoute('payroll');
        if (str_contains($payrollFilter, 'permission:payroll.view')) {
            CLI::write("  -> PASSED: Core /payroll retains permission:payroll.view enforcement.", 'green');
            $passed++;
        } else {
            CLI::write("  -> FAILED: Core /payroll filter was: '{$payrollFilter}'", 'red');
            $failed++;
        }

        CLI::write("------------------------------------------------------------------", 'cyan');
        CLI::write("Summary: {$passed} passed, {$failed} failed.", $failed === 0 ? 'green' : 'red');
        return $failed === 0 ? 0 : 1;
    }
}
