<?php

namespace App\Commands;

use App\Services\CompanyWeekendService;
use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use Config\Database;

class WeekendReconcile extends BaseCommand
{
    protected $group       = 'Rules';
    protected $name        = 'weekend:reconcile';
    protected $description = 'Audit and reconcile Active ATTENDANCE Company rule weekly_off_days with companies.weekly_off mirror.';
    protected $usage       = 'weekend:reconcile [--company=ID] [--apply] [--prefer=rule|column]';
    protected $options     = [
        '--company' => 'Target a single company ID (or code). Omit to inspect all companies.',
        '--apply'   => 'Write reconciled values. Without this flag, runs in dry-run mode (no writes).',
        '--prefer'  => 'Source of truth when applying: "rule" (default, updates companies mirror) or "column" (publishes to rule via CompanyWeekendService::saveWeeklyOff).',
    ];

    public function run(array $params)
    {
        $targetCompany = $this->extractOption($params, 'company');
        $apply         = $this->extractFlag($params, 'apply');
        $preferRaw     = $this->extractOption($params, 'prefer');
        $prefer        = ($preferRaw !== null && trim((string)$preferRaw) !== '')
            ? strtolower(trim((string)$preferRaw))
            : 'rule';

        if (!in_array($prefer, ['rule', 'column'], true)) {
            CLI::error("Invalid --prefer value '{$prefer}'. Allowed values: rule, column.");
            return EXIT_ERROR;
        }

        $rows = $this->reconcile($targetCompany, $apply, $prefer);

        $thead = ['company', 'rule days', 'column days', 'status'];
        $tbody = array_map(static function (array $row): array {
            return [
                $row['company'],
                $row['rule_days_label'],
                $row['column_days_label'],
                $row['status'],
            ];
        }, $rows);

        CLI::table($tbody, $thead);

        $modeLabel = $apply ? "APPLY (--prefer={$prefer})" : 'DRY RUN (no writes)';
        CLI::write("Mode: {$modeLabel} | Companies checked: " . count($rows));

        return EXIT_SUCCESS;
    }

    /**
     * Core reconciliation logic (usable from CLI run() and unit tests).
     *
     * @return array<int, array{
     *     company: string,
     *     rule_days: array<int, string>,
     *     column_days: array<int, string>,
     *     rule_days_label: string,
     *     column_days_label: string,
     *     status: string,
     *     applied: bool
     * }>
     */
    public function reconcile(?string $targetCompany = null, bool $apply = false, string $prefer = 'rule'): array
    {
        $db = Database::connect();
        if (!$db->tableExists('companies')) {
            return [];
        }

        $builder = $db->table('companies')->select('id, code, name, weekly_off, working_days');
        if ($targetCompany !== null && trim($targetCompany) !== '') {
            $cleanTarget = trim($targetCompany);
            $builder->groupStart()
                ->where('id', $cleanTarget)
                ->orWhere('code', $cleanTarget)
                ->groupEnd();
        }

        $companies = $builder->orderBy('id', 'ASC')->get()->getResultArray();
        $results   = [];

        foreach ($companies as $comp) {
            $companyId = (string)($comp['id'] ?? '');
            if ($companyId === '') {
                continue;
            }

            $ruleDays = $this->readActiveAttendanceRuleDays($db, $companyId);
            $colDays  = CompanyWeekendService::parseWeeklyOffField($comp['weekly_off'] ?? null);

            $status = $this->determineStatus($ruleDays, $colDays);
            $applied = false;

            if ($apply && $status !== 'match') {
                if ($prefer === 'rule') {
                    // Never write an empty list
                    if (!empty($ruleDays)) {
                        $applied = CompanyWeekendService::syncCompanyMirror($companyId, $ruleDays);
                    }
                } elseif ($prefer === 'column') {
                    // Never write an empty list
                    if (!empty($colDays)) {
                        $res = CompanyWeekendService::saveWeeklyOff(
                            $companyId,
                            $colDays,
                            'system_reconcile',
                            'weekend:reconcile',
                            true
                        );
                        $applied = !empty($res['ok']);
                    }
                }
            }

            $results[] = [
                'company'           => $companyId,
                'rule_days'         => $ruleDays,
                'column_days'       => $colDays,
                'rule_days_label'   => !empty($ruleDays) ? implode(', ', $ruleDays) : '(empty)',
                'column_days_label' => !empty($colDays) ? implode(', ', $colDays) : '(empty)',
                'status'            => $status,
                'applied'           => $applied,
            ];
        }

        return $results;
    }

    /**
     * Read Active Company-scope ATTENDANCE rule weekly_off_days for a company.
     *
     * @return array<int, string>
     */
    protected function readActiveAttendanceRuleDays($db, string $companyId): array
    {
        if (!$db->tableExists('rule_definitions')) {
            return [];
        }

        $today = date('Y-m-d');
        $rows = $db->table('rule_definitions')
            ->where('company_id', $companyId)
            ->where('domain', 'ATTENDANCE')
            ->where('scope_level', 'Company')
            ->where('status', 'Active')
            ->orderBy('effective_from', 'DESC')
            ->orderBy('version_number', 'DESC')
            ->get()
            ->getResultArray();

        if (empty($rows)) {
            return [];
        }

        $selected = null;
        foreach ($rows as $r) {
            $from = substr((string)($r['effective_from'] ?? ''), 0, 10);
            $to   = !empty($r['effective_to']) ? substr((string)$r['effective_to'], 0, 10) : null;
            if ($from <= $today && ($to === null || $to >= $today)) {
                $selected = $r;
                break;
            }
        }
        if ($selected === null) {
            $selected = $rows[0];
        }

        $params = json_decode((string)($selected['params_json'] ?? '{}'), true);
        if (!is_array($params) || !isset($params['weekly_off_days'])) {
            return [];
        }

        return CompanyWeekendService::parseWeeklyOffField($params['weekly_off_days']);
    }

    /**
     * Determine reconciliation status between rule days and column days.
     */
    protected function determineStatus(array $ruleDays, array $colDays): string
    {
        if (empty($ruleDays)) {
            return 'rule missing';
        }
        if (empty($colDays)) {
            return 'column missing';
        }
        if ($ruleDays === $colDays) {
            return 'match';
        }
        return 'mismatch';
    }

    private function extractOption(array $params, string $name): ?string
    {
        $cliVal = CLI::getOption($name);
        if (is_string($cliVal) && $cliVal !== '') {
            return $cliVal;
        }
        if (isset($params[$name]) && is_string($params[$name]) && $params[$name] !== '') {
            return $params[$name];
        }
        foreach ($params as $k => $v) {
            if (is_string($k) && ltrim($k, '-') === $name && is_string($v) && $v !== '') {
                return $v;
            }
            if (is_string($v)) {
                if (str_starts_with($v, "--{$name}=")) {
                    return substr($v, strlen("--{$name}="));
                }
                if (str_starts_with($v, "{$name}=")) {
                    return substr($v, strlen("{$name}="));
                }
            }
        }
        return null;
    }

    private function extractFlag(array $params, string $name): bool
    {
        if (CLI::getOption($name) !== null) {
            return true;
        }
        if (array_key_exists($name, $params) || array_key_exists("--{$name}", $params)) {
            return true;
        }
        foreach ($params as $v) {
            if ($v === $name || $v === "--{$name}") {
                return true;
            }
        }
        return false;
    }
}
