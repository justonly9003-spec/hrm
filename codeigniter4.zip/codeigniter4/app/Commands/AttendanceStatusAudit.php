<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Models\AttendanceModel;
use App\Services\RuleEngineService;

class AttendanceStatusAudit extends BaseCommand
{
    protected $group       = 'Attendance';
    protected $name        = 'attendance:status-audit';
    protected $description = 'Audits attendance_logs status distribution, detects invalid/blank records, and optionally recomputes them using RuleEngineService.';
    protected $usage       = 'attendance:status-audit [--fix] [--company <company_id>] [--limit <number>]';
    protected $arguments   = [];
    protected $options     = [
        '--fix'     => 'Safely recompute and repair blank/invalid statuses using the Rule Engine.',
        '--company' => 'Optional Company ID filter.',
        '--limit'   => 'Optional maximum number of records to process with --fix (default: all).',
    ];

    /**
     * Canonical status set defined by enterprise business rules
     */
    protected array $canonicalStatuses = [
        'Present',
        'Present (Early Closure)',
        'Approved Early Closure',
        'Early Closure Covered',
        'Late',
        'Early Out',
        'Late & Early Out',
        'Half Day',
        'Absent',
        'On Leave',
        'Holiday',
        'Weekly Off',
        'Missing Punch'
    ];

    public function run(array $params)
    {
        CLI::write("================================================================", 'cyan');
        CLI::write("           ATTENDANCE LOGS STATUS AUDIT & RECOVERY              ", 'white', 'blue');
        CLI::write("================================================================", 'cyan');

        $db = \Config\Database::connect();
        if (!$db->tableExists('attendance_logs')) {
            CLI::error("Table `attendance_logs` does not exist in database.");
            return;
        }

        $companyId = $params['company'] ?? CLI::getOption('company');
        $isFix = CLI::getOption('fix') !== null || in_array('--fix', $params, true);
        $limit = CLI::getOption('limit') ? (int)CLI::getOption('limit') : 0;

        CLI::write("Company Scope : " . ($companyId ?: 'ALL COMPANIES'), 'white');
        CLI::write("Mode          : " . ($isFix ? 'AUDIT & REPAIR (--fix)' : 'AUDIT ONLY (Read-Only)'), $isFix ? 'yellow' : 'cyan');
        CLI::newLine();

        // 1. Column Type Inspection
        $colType = 'UNKNOWN';
        try {
            $fieldData = $db->getFieldData('attendance_logs');
            foreach ($fieldData as $col) {
                if ($col->name === 'status') {
                    $colType = $col->type . (!empty($col->max_length) ? "({$col->max_length})" : '');
                    break;
                }
            }
        } catch (\Throwable $e) {
            $colType = 'ERROR: ' . $e->getMessage();
        }
        CLI::write("Database Column Type: `attendance_logs.status` is {$colType}", 'white');
        CLI::newLine();

        // 2. Status Distribution Summary
        CLI::write("--- Current Status Distribution in `attendance_logs` ---", 'yellow');

        $distBuilder = $db->table('attendance_logs')
            ->select("COALESCE(NULLIF(status, ''), '(EMPTY STRING)') as status_val, COUNT(*) as cnt");

        if (!empty($companyId)) {
            $distBuilder->where('company_id', $companyId);
        }

        $distribution = $distBuilder->groupBy("status_val")
            ->orderBy("cnt", "DESC")
            ->get()
            ->getResultArray();

        $totalRecords = 0;
        $invalidCount = 0;
        $legacyCount = 0;

        $legacyMap = [
            'present'                => 'Present',
            'present_early_closure'  => 'Present (Early Closure)',
            'approved_early_closure' => 'Present (Early Closure)',
            'early_closure'          => 'Present (Early Closure)',
            'late'                   => 'Late',
            'absent'                 => 'Absent',
            'half_day'               => 'Half Day',
            'on_leave'               => 'On Leave',
            'holiday'                => 'Holiday',
            'weekend'                => 'Weekly Off'
        ];

        $cliTable = [];
        $cliTable[] = ['Status Value', 'Record Count', 'Category / Canonical Target'];

        foreach ($distribution as $row) {
            $val = (string)$row['status_val'];
            $cnt = (int)$row['cnt'];
            $totalRecords += $cnt;

            if (in_array($val, $this->canonicalStatuses, true)) {
                $category = 'Canonical Valid';
            } elseif (array_key_exists(strtolower($val), $legacyMap)) {
                $category = 'Legacy Lowercase -> ' . $legacyMap[strtolower($val)];
                $legacyCount += $cnt;
            } elseif ($val === '(EMPTY STRING)' || $val === '(NULL)' || $val === '') {
                $category = 'EMPTY / LOST REAL STATUS';
                $invalidCount += $cnt;
            } else {
                $category = 'Non-Standard Variant';
                $invalidCount += $cnt;
            }

            $cliTable[] = [$val, number_format($cnt), $category];
        }

        CLI::table($cliTable, ['Status Value', 'Record Count', 'Classification']);
        CLI::write("Total Attendance Records Audited: " . number_format($totalRecords), 'white');
        CLI::write("Invalid / Blank Status Records  : " . number_format($invalidCount), $invalidCount > 0 ? 'red' : 'green');
        CLI::write("Legacy Lowercase Status Records : " . number_format($legacyCount), $legacyCount > 0 ? 'yellow' : 'green');
        CLI::newLine();

        // 3. Query Rows with Empty, Null, or Non-Canonical Status
        $logFields = $db->getFieldNames('attendance_logs');
        $selectCols = ['id', 'employee_id', 'date', 'check_in', 'check_out', 'working_hours', 'late_minutes', 'status', 'is_late'];
        foreach (['company_id', 'is_company_closure', 'closure_credit_hours', 'actual_worked_hours', 'early_out_minutes', 'remarks'] as $optCol) {
            if (in_array($optCol, $logFields, true)) {
                $selectCols[] = $optCol;
            }
        }
        $invalidQuery = $db->table('attendance_logs')
            ->select(implode(', ', $selectCols))
            ->groupStart()
                ->where('status IS NULL', null, false)
                ->orWhere('status', '')
                ->orWhereNotIn('status', $this->canonicalStatuses)
            ->groupEnd();

        if (!empty($companyId)) {
            $invalidQuery->where('company_id', $companyId);
        }

        $invalidQuery->orderBy('date', 'DESC');
        if ($limit > 0) {
            $invalidQuery->limit($limit);
        }

        $invalidRows = $invalidQuery->get()->getResultArray();
        $abnormalTotal = count($invalidRows);

        if ($abnormalTotal === 0) {
            CLI::write("All attendance_logs records conform strictly to canonical status labels!", 'green');
            return;
        }

        CLI::write("Found {$abnormalTotal} records requiring normalization or recomputation.", 'yellow');

        // Show a preview table of up to 10 abnormal records
        CLI::write("Sample of records needing attention:", 'cyan');
        $previewTable = [];
        $previewTable[] = ['Date', 'Employee ID', 'In Time', 'Out Time', 'Hours', 'Current Status'];
        foreach (array_slice($invalidRows, 0, 10) as $row) {
            $previewTable[] = [
                $row['date'] ?? '-',
                $row['employee_id'] ?? '-',
                $row['check_in'] ?? '-',
                $row['check_out'] ?? '-',
                $row['working_hours'] ?? '0.00',
                $row['status'] === '' ? '(EMPTY)' : ($row['status'] ?? '(NULL)')
            ];
        }
        CLI::table($previewTable, ['Date', 'Employee ID', 'In', 'Out', 'Hours', 'Status']);

        // 4. If --fix is NOT passed, guide the user and stop
        if (!$isFix) {
            CLI::newLine();
            CLI::write("----------------------------------------------------------------", 'yellow');
            CLI::write("Notice: Run with `--fix` to repair legacy strings and recompute ", 'yellow');
            CLI::write("empty/invalid statuses using `RuleEngineService::calculateDailyAttendance`.", 'yellow');
            CLI::write("Example: php spark attendance:status-audit --fix", 'white');
            CLI::write("----------------------------------------------------------------", 'yellow');
            return;
        }

        // 5. Execution of --fix
        CLI::newLine();
        CLI::write("Starting safe recomputation with RuleEngineService...", 'green');

        $ruleEngine = new RuleEngineService();
        $attModel = new AttendanceModel();
        $repairedCount = 0;
        $legacyFixedCount = 0;
        $recomputedCount = 0;
        $errorsCount = 0;

        // Cache employee records to avoid N+1 queries during bulk recalculation
        $employeeCache = [];

        foreach ($invalidRows as $row) {
            $currentStatus = (string)($row['status'] ?? '');
            $empId = $row['employee_id'];
            $logDate = $row['date'];
            $logId = $row['id'];

            try {
                // If it is just a simple legacy string with existing valid punch data, normalize directly
                if (isset($legacyMap[strtolower($currentStatus)])) {
                    $newStatus = $legacyMap[strtolower($currentStatus)];
                    $db->table('attendance_logs')
                        ->where('id', $logId)
                        ->update([
                            'status'     => $newStatus,
                            'updated_at' => date('Y-m-d H:i:s')
                        ]);
                    $legacyFixedCount++;
                    $repairedCount++;
                    continue;
                }

                // For blank/null/invalid statuses, run rule engine recomputation
                $rowCompId = $row['company_id'] ?? null;
                $cacheKey = ($rowCompId ?? 'global') . ':' . $empId;
                if (!isset($employeeCache[$cacheKey])) {
                    $empBuilder = $db->table('employees');
                    if (!empty($rowCompId)) {
                        $empBuilder->where('company_id', $rowCompId)
                            ->groupStart()
                                ->where('id', $empId)
                                ->orWhere('employee_code', $empId)
                            ->groupEnd();
                        $empRecord = $empBuilder->get()->getFirstRow('array');
                    } else {
                        $empRecord = $empBuilder->where('id', $empId)->get()->getFirstRow('array');
                    }
                    $employeeCache[$cacheKey] = $empRecord ?: null;
                }

                $employee = $employeeCache[$cacheKey];
                $isRowClosure = AttendanceModel::isClosureLog($row);
                $origLateMins = (int)($row['late_minutes'] ?? 0);
                $origNormStatus = AttendanceModel::normalizeAttendanceStatus($currentStatus);
                $wasRowLate = $origLateMins > 0 || !empty($row['is_late']) || in_array($origNormStatus, ['Late', 'Late & Early Out'], true);

                if (!$employee) {
                    // Normalize to best guess without employee profile
                    $newStatus = $isRowClosure
                        ? ($wasRowLate ? 'Late' : 'Present (Early Closure)')
                        : AttendanceModel::normalizeAttendanceStatus($currentStatus);
                    $db->table('attendance_logs')
                        ->where('id', $logId)
                        ->update(['status' => $newStatus, 'updated_at' => date('Y-m-d H:i:s')]);
                    $repairedCount++;
                    continue;
                }

                // Recompute using RuleEngineService
                $calc = $ruleEngine->calculateDailyAttendance($logDate, $employee, $row);
                $calculatedStatus = AttendanceModel::normalizeAttendanceStatus($calc['status'] ?? 'Present');
                $calcHours = (float)($calc['net_hours'] ?? $row['working_hours'] ?? 0.00);
                $calcLateMins = (int)($calc['late_minutes'] ?? $row['late_minutes'] ?? 0);
                $calcIsLate = !empty($calc['is_late']) || $calcLateMins > 0;

                if ($isRowClosure) {
                    $isClosureLate = $wasRowLate || $calcIsLate || in_array($calculatedStatus, ['Late', 'Late & Early Out'], true);
                    $calculatedStatus = $isClosureLate ? 'Late' : 'Present (Early Closure)';
                    $calcLateMins = max($origLateMins, $calcLateMins);
                    $calcIsLate = $isClosureLate;
                    $calcHours = max($calcHours, (float)($row['working_hours'] ?? 0.0), (float)($row['closure_credit_hours'] ?? 8.0));
                    $calc['early_out_minutes'] = 0;
                }

                $updateData = [
                    'status'        => $calculatedStatus,
                    'working_hours' => $calcHours,
                    'late_minutes'  => $calcLateMins,
                    'is_late'       => $calcIsLate ? 1 : 0,
                    'updated_at'    => date('Y-m-d H:i:s')
                ];

                if (isset($calc['early_out_minutes'])) {
                    $updateData['early_out_minutes'] = $isRowClosure ? 0 : (int)$calc['early_out_minutes'];
                }

                $db->table('attendance_logs')
                    ->where('id', $logId)
                    ->update($updateData);

                $recomputedCount++;
                $repairedCount++;

            } catch (\Throwable $e) {
                log_message('error', "attendance:status-audit recompute error for log {$logId}: " . $e->getMessage());
                $errorsCount++;
            }
        }

        CLI::newLine();
        CLI::write("================================================================", 'cyan');
        CLI::write("                    REPAIR COMPLETE                             ", 'white', 'green');
        CLI::write("================================================================", 'cyan');
        CLI::write("Total Processed     : " . number_format($abnormalTotal));
        CLI::write("Legacy Labels Fixed : " . number_format($legacyFixedCount), 'green');
        CLI::write("Recomputed by Rules : " . number_format($recomputedCount), 'green');
        CLI::write("Errors Encountered  : " . number_format($errorsCount), $errorsCount > 0 ? 'red' : 'green');
        CLI::write("Total Repaired      : " . number_format($repairedCount), 'green');
        CLI::newLine();
    }
}
