<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Models\EmployeeModel;
use App\Models\EmployeeSalaryModel;
use Config\Database;

/**
 * CLI Command: payroll:salary-drift
 *
 * Scans employees and identifies drift where employees.basic_salary != active employee_salaries.basic_salary.
 * With --fix, re-syncs the cache on the employees table from the canonical employee_salaries record
 * (never the other way around).
 */
class PayrollSalaryDrift extends BaseCommand
{
    protected $group       = 'Payroll';
    protected $name        = 'payroll:salary-drift';
    protected $description = 'Lists employees where employees.basic_salary != active employee_salaries.basic_salary, with optional --fix to re-sync cache.';
    protected $usage       = 'payroll:salary-drift [options]';
    protected $arguments   = [];
    protected $options     = [
        '--fix'     => 'Re-sync cache on employees table from canonical active employee_salaries (never the other way).',
        '--company' => 'Filter audit by specific company ID.',
        '--json'    => 'Output results in JSON format.',
    ];

    public function run(array $params)
    {
        $shouldFix = array_key_exists('fix', $params) || CLI::getOption('fix') !== null;
        $companyFilter = $params['company'] ?? CLI::getOption('company');
        $jsonMode = array_key_exists('json', $params) || CLI::getOption('json') !== null;

        $db = Database::connect();
        $empModel = new EmployeeModel();
        $salaryModel = new EmployeeSalaryModel();

        $query = $empModel->select('employees.*');
        if (!empty($companyFilter)) {
            $query->where('employees.company_id', $companyFilter);
        }
        $employees = $query->orderBy('employees.company_id', 'ASC')
            ->orderBy('employees.employee_code', 'ASC')
            ->findAll();

        $totalChecked = count($employees);
        $driftDetected = [];
        $fixedCount = 0;
        $noSalaryRecord = [];

        $today = date('Y-m-d');

        foreach ($employees as $emp) {
            $empId = $emp['id'];

            // Find active salary from employee_salaries (as-of today)
            $activeSal = $salaryModel->where('employee_id', $empId)
                ->where('status', 'Active')
                ->where('effective_from <=', $today)
                ->orderBy('effective_from', 'DESC')
                ->first();

            if (!$activeSal) {
                // Fallback to any active record
                $activeSal = $salaryModel->where('employee_id', $empId)
                    ->where('status', 'Active')
                    ->orderBy('effective_from', 'DESC')
                    ->first();
            }

            if (!$activeSal) {
                // No active employee_salaries record
                $noSalaryRecord[] = [
                    'employee_id'   => $empId,
                    'employee_code' => $emp['employee_code'] ?? 'N/A',
                    'name'          => trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')),
                    'company_id'    => $emp['company_id'] ?? 'N/A',
                    'cached_basic'  => (float)($emp['basic_salary'] ?? 0.0),
                ];
                continue;
            }

            $cachedBasic = round((float)($emp['basic_salary'] ?? 0.0), 2);
            $activeBasic = round((float)($activeSal['basic_salary'] ?? 0.0), 2);

            // Check for basic salary drift
            if (abs($cachedBasic - $activeBasic) > 0.009) {
                $driftItem = [
                    'employee_id'    => $empId,
                    'employee_code'  => $emp['employee_code'] ?? 'N/A',
                    'name'           => trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')),
                    'company_id'     => $emp['company_id'] ?? 'N/A',
                    'cached_basic'   => $cachedBasic,
                    'active_basic'   => $activeBasic,
                    'difference'     => round($cachedBasic - $activeBasic, 2),
                    'salary_id'      => $activeSal['id'] ?? 'N/A',
                    'effective_from' => $activeSal['effective_from'] ?? 'N/A',
                    'fixed'          => false,
                ];

                if ($shouldFix) {
                    EmployeeModel::withSalarySync(function() use ($empModel, $empId, $activeSal) {
                        $empModel->update($empId, [
                            'basic_salary'  => (float)$activeSal['basic_salary'],
                            'gross_salary'  => (float)($activeSal['gross_salary'] ?? $activeSal['basic_salary']),
                            'salary_status' => 'CONFIGURED',
                            'updated_at'    => date('Y-m-d H:i:s'),
                        ]);
                    });
                    $driftItem['fixed'] = true;
                    $fixedCount++;
                }

                $driftDetected[] = $driftItem;
            }
        }

        $report = [
            'total_employees_checked' => $totalChecked,
            'drift_count'             => count($driftDetected),
            'fixed_count'             => $fixedCount,
            'no_active_salary_count'  => count($noSalaryRecord),
            'fix_mode_applied'        => $shouldFix,
            'drifts'                  => $driftDetected,
            'no_active_salary'        => $noSalaryRecord,
        ];

        if ($jsonMode) {
            CLI::write(json_encode($report, JSON_PRETTY_PRINT));
            return;
        }

        CLI::write("==================================================================", 'cyan');
        CLI::write("           PAYROLL SALARY DRIFT AUDIT & RE-SYNC TOOL             ", 'yellow');
        CLI::write("==================================================================", 'cyan');
        CLI::write("Checked: {$totalChecked} employees across system.", 'white');
        CLI::newLine();

        if (empty($driftDetected)) {
            CLI::write("[PASS] Zero salary drift detected! All cached employee basic salaries match their active salary structures.", 'green');
        } else {
            CLI::write(sprintf("[DRIFT DETECTED] Found %d employee(s) with mismatched basic salary:", count($driftDetected)), 'red');
            CLI::newLine();

            $headers = ['Emp Code', 'Employee Name', 'Cached Basic', 'Active Basic (Truth)', 'Difference', 'Status'];
            $rows = [];

            foreach ($driftDetected as $d) {
                $statusStr = $d['fixed'] ? 'FIXED (Re-synced)' : 'DRIFT';
                $rows[] = [
                    $d['employee_code'],
                    substr($d['name'], 0, 24),
                    number_format($d['cached_basic'], 2),
                    number_format($d['active_basic'], 2),
                    ($d['difference'] >= 0 ? '+' : '') . number_format($d['difference'], 2),
                    $statusStr,
                ];
            }

            // Print table manually for clean terminal rendering
            $mask = "%-12s %-25s %-15s %-22s %-12s %-16s\n";
            printf($mask, $headers[0], $headers[1], $headers[2], $headers[3], $headers[4], $headers[5]);
            printf($mask, '------------', '-------------------------', '---------------', '----------------------', '------------', '----------------');
            foreach ($rows as $r) {
                printf($mask, $r[0], $r[1], $r[2], $r[3], $r[4], $r[5]);
            }
            CLI::newLine();

            if ($shouldFix) {
                CLI::write("Successfully re-synced {$fixedCount} employee record(s) from employee_salaries.", 'green');
            } else {
                CLI::write("Tip: Run 'php spark payroll:salary-drift --fix' to re-sync employees cache from canonical active employee_salaries.", 'yellow');
            }
        }

        if (!empty($noSalaryRecord)) {
            CLI::newLine();
            CLI::write(sprintf("Notice: %d employee(s) have no active employee_salaries record (unconfigured salary).", count($noSalaryRecord)), 'light_gray');
        }

        CLI::write("------------------------------------------------------------------", 'dark_gray');
    }
}
