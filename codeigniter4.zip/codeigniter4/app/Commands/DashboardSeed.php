<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Services\DashboardService;

class DashboardSeed extends BaseCommand
{
    protected $group       = 'Dashboard';
    protected $name        = 'dashboard:seed';
    protected $description = 'Seeds baseline dashboard widgets and role configurations on deploy.';
    protected $usage       = 'dashboard:seed [--force]';
    protected $options     = [
        '--force' => 'Force re-seeding and updating existing widget definitions.',
    ];

    public function run(array $params)
    {
        CLI::write("================================================================", 'cyan');
        CLI::write("           DASHBOARD WIDGETS DEFAULT SEEDER UTILITY             ", 'white', 'blue');
        CLI::write("================================================================", 'cyan');

        $force = CLI::getOption('force') ? true : false;

        try {
            CLI::write("Starting dashboard widgets baseline synchronization (force: " . ($force ? 'yes' : 'no') . ")...", 'yellow');

            $dashboardService = new DashboardService();
            $stats = $dashboardService->seedDefaultWidgets($force);

            CLI::newLine();
            CLI::write("✓ Dashboard baseline seeding completed successfully.", 'green');
            if (is_array($stats)) {
                CLI::write("  • Baseline widgets inserted: " . ($stats['inserted'] ?? 0), 'white');
                CLI::write("  • Baseline widgets updated:  " . ($stats['updated'] ?? 0), 'white');
                CLI::write("  • Role configurations synced: " . ($stats['role_configs'] ?? 0), 'white');
            }
        } catch (\Throwable $e) {
            CLI::error("✗ Seeding failed: " . $e->getMessage());
        }

        CLI::newLine();
        CLI::write("================================================================", 'cyan');
        CLI::write("                  SEEDING FINISHED                              ", 'white', 'green');
        CLI::write("================================================================", 'cyan');
    }
}
