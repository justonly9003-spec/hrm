<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Models\CompanyModel;
use App\Services\CompanyInitializationService;

class InitializeCompanyMasterData extends BaseCommand
{
    protected $group       = 'Company Tenant';
    protected $name        = 'company:initialize';
    protected $description = 'Initializes company-specific default master data (Departments, Designations, Salary Grades, Security Policies, Shifts, Holidays, Employment Types, Leave Types & Policies).';
    protected $usage       = 'company:initialize [company_id] [--all]';
    protected $arguments   = [
        'company_id' => 'The ID or code of the company to initialize (e.g. COMP-APEX or comp-001).',
    ];
    protected $options     = [
        '--all' => 'Initialize default master data for all registered companies.',
    ];

    public function run(array $params)
    {
        CLI::write("================================================================", 'cyan');
        CLI::write("     COMPANY DEFAULT MASTER DATA PROVISIONING UTILITY           ", 'white', 'blue');
        CLI::write("================================================================", 'cyan');

        $companyModel = new CompanyModel();
        $initService  = new CompanyInitializationService();

        $targetId = $params[0] ?? null;
        $allFlag  = CLI::getOption('all');

        $companiesToProcess = [];

        if ($allFlag) {
            $companiesToProcess = $companyModel->findAll();
        } elseif (!empty($targetId)) {
            $comp = $companyModel->find($targetId) ?: $companyModel->where('code', $targetId)->first();
            if (!$comp) {
                CLI::error("Company not found with ID or code: '{$targetId}'");
                return;
            }
            $companiesToProcess[] = $comp;
        } else {
            CLI::error("Please specify a company_id or pass --all flag.");
            CLI::write("Usage: php spark {$this->usage}", 'yellow');
            return;
        }

        if (empty($companiesToProcess)) {
            CLI::write("No companies found to process.", 'yellow');
            return;
        }

        CLI::write("Found " . count($companiesToProcess) . " company tenant(s) to process.");
        CLI::newLine();

        foreach ($companiesToProcess as $comp) {
            $cId   = $comp['id'];
            $cName = $comp['name'] ?? 'N/A';
            $cCode = $comp['code'] ?? 'N/A';

            CLI::write("----------------------------------------------------------------", 'dark_gray');
            CLI::write("Processing: {$cName} [ID: {$cId}, Code: {$cCode}]", 'yellow');

            try {
                $result = $initService->initializeCompany($cId);

                CLI::write("✓ Initialized successfully!", 'green');
                
                $thead = ['Category', 'Created', 'Skipped (Existing)'];
                $tbody = [];

                foreach ($result['initialized'] as $cat => $createdItems) {
                    $skippedItems = $result['skipped'][$cat] ?? [];
                    $tbody[] = [
                        ucwords(str_replace('_', ' ', $cat)),
                        count($createdItems) . ' (' . implode(', ', array_slice($createdItems, 0, 4)) . (count($createdItems) > 4 ? '...' : '') . ')',
                        count($skippedItems) . ' (' . implode(', ', array_slice($skippedItems, 0, 4)) . (count($skippedItems) > 4 ? '...' : '') . ')',
                    ];
                }

                CLI::table($tbody, $thead);
            } catch (\Throwable $e) {
                CLI::error("✗ Failed for company '{$cName}': " . $e->getMessage());
            }
        }

        CLI::newLine();
        CLI::write("================================================================", 'cyan');
        CLI::write("                  PROVISIONING FINISHED                         ", 'white', 'green');
        CLI::write("================================================================", 'cyan');
    }
}
