<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Models\RuleDefinitionModel;
use App\Database\Seeds\EmployeeTestSeeder;

class ConfigureTestPolicy extends BaseCommand
{
    protected $group       = 'Database';
    protected $name        = 'test:policy';
    protected $description = 'Configures or toggles business rules (OT early arrival, Gratuity minimum duration) for TEST-PAYROLL-001.';
    protected $usage       = 'test:policy [--early-arrival=on|off] [--gratuity-years=1.0|0.0833] [--status]';
    protected $options     = [
        '--early-arrival'  => 'Enable or disable early arrival overtime (on|off, 1|0, true|false).',
        '--gratuity-years' => 'Set minimum service years for statutory gratuity (e.g. 1.0 for 1 year, 0.0833 for 1 month).',
        '--status'         => 'Display current active rule configuration for TEST-PAYROLL-001.',
    ];

    public function run(array $params)
    {
        $companyId = EmployeeTestSeeder::TEST_COMPANY_ID;
        $ruleModel = new RuleDefinitionModel();
        $now = date('Y-m-d H:i:s');

        $otRow = $ruleModel->where('company_id', $companyId)->where('domain', 'OVERTIME')->where('scope_level', 'Company')->first();
        $gratRow = $ruleModel->where('company_id', $companyId)->where('domain', 'GRATUITY')->where('scope_level', 'Company')->first();

        if (!$otRow || !$gratRow) {
            CLI::error("Rules for test company ('{$companyId}') not found. Please seed the test dataset first: php spark seed:employee");
            return;
        }

        $otParams = json_decode($otRow['params_json'], true) ?: [];
        $gratParams = json_decode($gratRow['params_json'], true) ?: [];

        $earlyArrivalOpt = CLI::getOption('early-arrival');
        if ($earlyArrivalOpt !== null) {
            $enable = in_array(strtolower((string)$earlyArrivalOpt), ['1', 'on', 'true', 'yes'], true);
            $otParams['enable_early_arrival_ot'] = $enable;
            $ruleModel->update($otRow['id'], [
                'params_json'   => json_encode($otParams, JSON_PRETTY_PRINT),
                'change_reason' => 'Test toggle: Early arrival OT set to ' . ($enable ? 'ENABLED' : 'DISABLED'),
                'updated_at'    => $now
            ]);
            CLI::write(" [SUCCESS] OVERTIME: enable_early_arrival_ot is now " . ($enable ? 'ENABLED (true)' : 'DISABLED (false)'), 'green');
        }

        $gratYearsOpt = CLI::getOption('gratuity-years');
        if ($gratYearsOpt !== null && is_numeric($gratYearsOpt)) {
            $years = (float)$gratYearsOpt;
            $gratParams['eligibility_min_years'] = $years;
            $ruleModel->update($gratRow['id'], [
                'params_json'   => json_encode($gratParams, JSON_PRETTY_PRINT),
                'change_reason' => "Test toggle: Gratuity eligibility_min_years set to {$years}",
                'updated_at'    => $now
            ]);
            CLI::write(" [SUCCESS] GRATUITY: eligibility_min_years is now {$years} " . ($years < 0.1 ? "(~1 Month)" : "({$years} Years)"), 'green');
        }

        // Print Status
        $otRow = $ruleModel->where('company_id', $companyId)->where('domain', 'OVERTIME')->where('scope_level', 'Company')->first();
        $gratRow = $ruleModel->where('company_id', $companyId)->where('domain', 'GRATUITY')->where('scope_level', 'Company')->first();
        $otParams = json_decode($otRow['params_json'], true) ?: [];
        $gratParams = json_decode($gratRow['params_json'], true) ?: [];

        CLI::write("============================================================", 'cyan');
        CLI::write(" CURRENT TEST POLICY STATUS (TEST-PAYROLL-001):", 'yellow');
        CLI::write("  - OVERTIME enable_early_arrival_ot : " . (!empty($otParams['enable_early_arrival_ot']) ? 'ENABLED (true)' : 'DISABLED (false)'));
        CLI::write("  - GRATUITY eligibility_min_years   : " . ($gratParams['eligibility_min_years'] ?? 'N/A') . " years");
        CLI::write("============================================================", 'cyan');
    }
}
