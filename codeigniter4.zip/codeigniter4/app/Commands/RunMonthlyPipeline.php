<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Services\Automation\ScheduledJobsService;

class RunMonthlyPipeline extends BaseCommand
{
    protected $group       = 'Automation';
    protected $name        = 'cron:monthly';
    protected $description = 'Executes the Sequential 12-Step Monthly Payroll Automation Pipeline: Attendance Close -> OT -> Leave Deduction -> Bonus -> Tax -> PF -> Loan/Advance -> Payroll Calc -> Review -> Approval -> Lock -> Disbursement';
    protected $usage       = 'cron:monthly [options]';
    protected $options     = [
        '--month'   => 'Month in YYYY-MM format (e.g. 2026-08)',
        '--company' => 'Company ID (e.g. COMP-01)',
        '--user'    => 'User ID triggering the manual command',
        '--json'    => 'Output results as pure JSON'
    ];

    public function run(array $params)
    {
        $jsonMode = array_key_exists('json', $params) || CLI::getOption('json');
        $month = CLI::getOption('month') ?? date('Y-m');
        $companyId = CLI::getOption('company') ?? 'COMP-01';
        $userId = CLI::getOption('user') ?? 'CLI_SCHEDULER';

        // Authorization check if run on behalf of a specific user ID
        if ($userId !== 'CLI_SCHEDULER' && $userId !== 'CRON_SYSTEM') {
            $db = \Config\Database::connect();
            $userRow = $db->table('users')
                ->select('users.id, users.status, roles.code as role_code, roles.name as role_name')
                ->join('roles', 'roles.id = users.role_id', 'left')
                ->where('users.id', $userId)
                ->get()
                ->getRowArray();

            if (!$userRow || strtolower($userRow['status'] ?? '') !== 'active') {
                CLI::error("Authorization Failure: User '{$userId}' not found or inactive.");
                return 1;
            }

            $role = strtolower($userRow['role_code'] ?? $userRow['role_name'] ?? '');
            if (!in_array($role, ['superadmin', 'platformadmin', 'admin', 'hrdirector', 'software_app_admin', 'super_admin'], true)) {
                CLI::error("Authorization Failure: User '{$userId}' lacks administrative authority to trigger monthly payroll pipeline.");
                return 1;
            }
        }

        $service = new ScheduledJobsService();

        if (!$jsonMode) {
            CLI::write("================================================================", 'cyan');
            CLI::write("    ENTERPRISE HRMS - MONTHLY AUTOMATION PIPELINE (P8)          ", 'yellow');
            CLI::write("================================================================", 'cyan');
            CLI::write("Target Month : " . $month . " | Company: " . $companyId, 'white');
            CLI::write("Triggered By : " . $userId . " | Start Time: " . date('Y-m-d H:i:s'), 'white');
            CLI::newLine();
            CLI::write("Executing 12-Step Sequential Monthly Pipeline...", 'cyan');
            CLI::newLine();
        }

        $result = $service->runMonthlyPipeline($month, $companyId, $userId);

        if ($jsonMode) {
            CLI::write(json_encode($result, JSON_PRETTY_PRINT));
            return !empty($result['success']) ? 0 : 1;
        }

        // Print actual status and details from real pipeline execution
        $stepIndex = 1;
        foreach (($result['steps'] ?? []) as $stepKey => $stepData) {
            $stepName = $stepData['step'] ?? $stepKey;
            $status = $stepData['status'] ?? 'UNKNOWN';
            $details = $stepData['details'] ?? '';

            $color = match ($status) {
                'COMPLETED' => 'green',
                'PENDING_HUMAN_APPROVAL', 'GATED_BY_APPROVAL' => 'yellow',
                'FAILED', 'BLOCKED' => 'red',
                'SKIPPED' => 'light_gray',
                default => 'white'
            };

            CLI::write(sprintf(" [%d/12] %s: %s", $stepIndex, $stepName, $status), $color);
            CLI::write("        -> " . $details, 'white');
            $stepIndex++;
        }

        CLI::newLine();
        CLI::write("================================================================", 'cyan');
        if (!empty($result['success'])) {
            CLI::write("PIPELINE STAGED TO PENDING_REVIEW IN " . ($result['duration_ms'] ?? 0) . " ms", 'green');
            CLI::write("Human Authorization Boundary Enforced: Dual approval required before lock/disbursement.", 'yellow');
        } else {
            $isBlocked = !empty($result['blocked']);
            $msg = $isBlocked ? 'PIPELINE BLOCKED: CONCURRENCY OR FINALIZED BATCH GUARD' : 'PIPELINE EXECUTION FAILED';
            CLI::write($msg, 'red');
        }
        CLI::write("================================================================", 'cyan');

        return !empty($result['success']) ? 0 : 1;
    }
}
