<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Models\RawBiometricEventModel;
use App\Models\UnmatchedBiometricModel;

class RepairBiometricEvents extends BaseCommand
{
    protected $group       = 'Biometric Hardware';
    protected $name        = 'biometric:repair';
    protected $description = 'Repairs corrupted raw_biometric_events where biometric_user_id is NULL or empty, extracts PIN from raw_payload, and rebuilds individual unmatched identities.';
    protected $usage       = 'biometric:repair [--company <company_id>]';
    protected $arguments   = [];
    protected $options     = [
        '--company' => 'Optional Company ID (e.g. COMP-TEST) to filter records.',
    ];

    public function run(array $params)
    {
        CLI::write("================================================================", 'cyan');
        CLI::write("   RAW BIOMETRIC BUFFER RECOVERY & IDENTITY REBUILD UTILITY     ", 'white', 'blue');
        CLI::write("================================================================", 'cyan');

        $companyId = $params['company'] ?? CLI::getOption('company');

        CLI::write("Company Scope  : " . ($companyId ?: 'ALL COMPANIES'));
        CLI::newLine();

        $rawModel = new RawBiometricEventModel();
        CLI::write("Scanning raw_biometric_events for corrupted NULL/blank PIN records...", 'yellow');

        $result = $rawModel->repairCorruptedEvents($companyId);

        CLI::newLine();
        CLI::write("================================================================", 'cyan');
        CLI::write("                    REPAIR SUMMARY                              ", 'white', 'green');
        CLI::write("================================================================", 'cyan');
        CLI::write("Corrupted Records Found : " . number_format($result['total_corrupted']));
        CLI::write("Successfully Repaired   : " . number_format($result['repaired']));
        CLI::write("Unrecoverable (Isolated): " . number_format($result['unrecoverable']));

        if (!empty($result['recovered_pins'])) {
            CLI::newLine();
            CLI::write("Recovered Biometric User PINs:", 'green');
            foreach ($result['recovered_pins'] as $pin => $count) {
                CLI::write("  - PIN [{$pin}]: {$count} punches recovered", 'white');
            }
        }

        if (!empty($result['identities'])) {
            CLI::newLine();
            CLI::write("Rebuilt Identities Summary:", 'yellow');
            CLI::write("  Total Distinct Badges: " . number_format($result['identities']['total_identities']));
            CLI::write("  Awaiting Resolution  : " . number_format($result['identities']['unmapped']));
            CLI::write("  Linked HRM Profiles  : " . number_format($result['identities']['mapped']));
        }

        CLI::newLine();
        CLI::write("Done! All raw biometric events are now clean and individually listed.", 'green');
    }
}
