<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Models\UserModel;
use App\Services\PermissionService;
use App\Filters\PermissionFilter;
use App\Filters\RoleFilter;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\URI;
use CodeIgniter\HTTP\UserAgent;

class VerifyRc7FailClosed extends BaseCommand
{
    protected $group       = 'Verification';
    protected $name        = 'verify:rc7-fail-closed';
    protected $description = 'Verifies RC-7: Fail-closed defaults across PermissionFilter, RoleFilter, PermissionService, and UserModel.';

    public function run(array $params)
    {
        CLI::write("==================================================================", 'cyan');
        CLI::write("        VERIFY RC-7: FAIL-CLOSED DEFAULTS & SAFE HANDLING         ", 'yellow');
        CLI::write("==================================================================", 'cyan');

        $passed = 0;
        $failed = 0;

        // -------------------------------------------------------------
        // Check 1: UserModel::normalizeStatus fails safe on invalid/unknown statuses
        // -------------------------------------------------------------
        CLI::write("\n[Check 1] UserModel::normalizeStatus fail-safe defaults...", 'white');

        $testCases = [
            'active'            => UserModel::STATUS_ACTIVE,
            'ACTIVE'            => UserModel::STATUS_ACTIVE,
            'suspended'         => UserModel::STATUS_SUSPENDED,
            'banned'            => UserModel::STATUS_SUSPENDED,
            'locked'            => UserModel::STATUS_LOCKED,
            'blocked'           => UserModel::STATUS_LOCKED,
            'inactive'          => UserModel::STATUS_INACTIVE,
            'disabled'          => UserModel::STATUS_INACTIVE,
            'deactivated'       => UserModel::STATUS_INACTIVE,
            'terminated'        => UserModel::STATUS_INACTIVE,
            'resigned'          => UserModel::STATUS_INACTIVE,
            'pending'           => UserModel::STATUS_INACTIVE,
            'pending_approval'  => UserModel::STATUS_INACTIVE,
            'typo_status'       => UserModel::STATUS_INACTIVE,
            'actve'             => UserModel::STATUS_INACTIVE,
            ''                  => UserModel::STATUS_INACTIVE,
            null                => UserModel::STATUS_INACTIVE,
        ];

        $statusOk = true;
        foreach ($testCases as $input => $expected) {
            $actual = UserModel::normalizeStatus($input);
            if ($actual !== $expected) {
                CLI::error("  ✖ Status input " . var_export($input, true) . " expected '{$expected}', got '{$actual}'");
                $statusOk = false;
            }
        }

        if ($statusOk) {
            CLI::write("  ✔ All known and unknown statuses fail closed to inactive/locked/suspended correctly.", 'green');
            $passed++;
        } else {
            $failed++;
        }

        // -------------------------------------------------------------
        // Check 2: PermissionService::hasAccess fails closed on empty module
        // -------------------------------------------------------------
        CLI::write("\n[Check 2] PermissionService::hasAccess fail-closed on empty module...", 'white');

        $db = \Config\Database::connect();
        $permService = new PermissionService($db);

        $emptyModAccess1 = $permService->hasAccess('test-user-id', null, 'view');
        $emptyModAccess2 = $permService->hasAccess('test-user-id', '', 'view');
        $emptyModAccess3 = $permService->hasAccess(null, null, 'view');

        if (!$emptyModAccess1 && !$emptyModAccess2 && !$emptyModAccess3) {
            CLI::write("  ✔ hasAccess returns false when module is null or empty (fail-closed).", 'green');
            $passed++;
        } else {
            CLI::error("  ✖ hasAccess returned true on empty module (fail-open bug).");
            $failed++;
        }

        // -------------------------------------------------------------
        // Check 3: PermissionService::hasAccess does not treat generic user IDs as roles
        // -------------------------------------------------------------
        CLI::write("\n[Check 3] PermissionService::hasAccess does not convert user IDs to roles...", 'white');

        // Target user ID 'manager' or 'admin' or 'user' should be treated as user identifier, not wiped to null
        $refMethod = new \ReflectionMethod(PermissionService::class, 'hasAccess');
        $code = file_get_contents(APPPATH . 'Services/PermissionService.php');
        
        $hasCleanSeparation = !str_contains($code, "in_array(\$cleaned, \$knownRoles") 
            && !str_contains($code, "'manager', 'team_leader', 'employee'")
            && str_contains($code, "\$strictSystemRoles = [");

        if ($hasCleanSeparation) {
            CLI::write("  ✔ PermissionService hasAccess strictly distinguishes user IDs from system roles.", 'green');
            $passed++;
        } else {
            CLI::error("  ✖ PermissionService still contains legacy knownRoles heuristic mapping user IDs to roles.");
            $failed++;
        }

        // -------------------------------------------------------------
        // Check 4: PermissionFilter fails closed on empty arguments
        // -------------------------------------------------------------
        CLI::write("\n[Check 4] PermissionFilter fails closed on empty arguments...", 'white');

        $permFilter = new PermissionFilter();
        $uri = new URI('http://example.com/api/test');
        $request = new IncomingRequest(new \Config\App(), $uri, 'php://input', new UserAgent());

        // Setup session
        $session = \Config\Services::session();
        $session->set('user_id', 'usr-test-rc7');
        $session->set('role', 'employee');

        $emptyFilterRes = $permFilter->before($request, []);
        $nullFilterRes = $permFilter->before($request, null);

        $emptyDenied = ($emptyFilterRes instanceof \CodeIgniter\HTTP\ResponseInterface) 
            && $emptyFilterRes->getStatusCode() === 403;
        $nullDenied = ($nullFilterRes instanceof \CodeIgniter\HTTP\ResponseInterface) 
            && $nullFilterRes->getStatusCode() === 403;

        if ($emptyDenied && $nullDenied) {
            CLI::write("  ✔ PermissionFilter returns HTTP 403 when filter arguments are empty or null.", 'green');
            $passed++;
        } else {
            CLI::error("  ✖ PermissionFilter failed to deny on empty arguments (emptyDenied={$emptyDenied}, nullDenied={$nullDenied}).");
            $failed++;
        }

        // -------------------------------------------------------------
        // Check 5: PermissionFilter disambiguates two dotless arguments
        // -------------------------------------------------------------
        CLI::write("\n[Check 5] PermissionFilter disambiguates two dotless args...", 'white');

        $filterCode = file_get_contents(APPPATH . 'Filters/PermissionFilter.php');
        $hasActionCheck = str_contains($filterCode, 'in_array($arg1, $knownActions, true)')
            && str_contains($filterCode, '!in_array($arg1, $knownModules, true)');

        if ($hasActionCheck) {
            CLI::write("  ✔ PermissionFilter disambiguates two dotless args via knownActions vs knownModules.", 'green');
            $passed++;
        } else {
            CLI::error("  ✖ PermissionFilter does not disambiguate two dotless arguments.");
            $failed++;
        }

        // -------------------------------------------------------------
        // Check 6: RoleFilter requires login, fails closed on empty args, returns 403
        // -------------------------------------------------------------
        CLI::write("\n[Check 6] RoleFilter login check, fail-closed empty args, and 403 response...", 'white');

        $roleFilter = new RoleFilter();

        // 6a: Test without login
        $session->remove('user_id');
        $noLoginRes = $roleFilter->before($request, ['admin']);
        $loginEnforced = ($noLoginRes instanceof \CodeIgniter\HTTP\ResponseInterface || $noLoginRes instanceof \CodeIgniter\HTTP\RedirectResponse);

        // 6b: Test with login but empty arguments
        $session->set('user_id', 'usr-test-rc7');
        $session->set('role', 'employee');
        $emptyRoleRes = $roleFilter->before($request, []);
        $emptyRoleDenied = ($emptyRoleRes instanceof \CodeIgniter\HTTP\ResponseInterface)
            && $emptyRoleRes->getStatusCode() === 403;

        // 6c: Test unauthorized role
        $unauthRes = $roleFilter->before($request, ['company_admin']);
        $unauthDenied = ($unauthRes instanceof \CodeIgniter\HTTP\ResponseInterface)
            && $unauthRes->getStatusCode() === 403;

        if ($loginEnforced && $emptyRoleDenied && $unauthDenied) {
            CLI::write("  ✔ RoleFilter enforces authentication, fails closed on empty args, and returns 403.", 'green');
            $passed++;
        } else {
            CLI::error("  ✖ RoleFilter check failed (loginEnforced={$loginEnforced}, emptyDenied={$emptyRoleDenied}, unauthDenied={$unauthDenied}).");
            $failed++;
        }

        // -------------------------------------------------------------
        // Summary
        // -------------------------------------------------------------
        CLI::write("\n------------------------------------------------------------------", 'cyan');
        CLI::write("RC-7 Verification Results: {$passed} Passed, {$failed} Failed", $failed === 0 ? 'green' : 'red');
        CLI::write("------------------------------------------------------------------\n", 'cyan');

        return $failed === 0 ? 0 : 1;
    }
}
