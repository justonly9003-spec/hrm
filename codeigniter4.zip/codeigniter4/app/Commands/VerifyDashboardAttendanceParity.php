<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use Config\Database;
use App\Services\AttendanceRuleEngine;
use App\Services\DashboardWidgetDataProvider;
use App\Models\EmployeeModel;

/**
 * Class VerifyDashboardAttendanceParity
 *
 * Verifies that:
 * 1. For today's date, dashboard Present/Late/Absent/OnLeave/Missing Punch strictly equals
 *    the Attendance module "today" tab for the same scope.
 * 2. The last point of the 7-day trend strictly equals today's dashboard card numbers.
 * 3. Probation employees (eligible in AttendanceRuleEngine) are included so last day equals today's card.
 * 4. Trend calculation functions independently when total_employees is 0 (workforce widget OFF).
 * 5. Per-request cache inside AttendanceRuleEngine prevents duplicate recomputation.
 *
 * Usage: php spark attendance:verify-dashboard-parity
 */
class VerifyDashboardAttendanceParity extends BaseCommand
{
    protected $group       = 'Attendance';
    protected $name        = 'attendance:verify-dashboard-parity';
    protected $description = 'Verifies strict parity between Dashboard attendance cards, 7-day trend, and Attendance module today tab.';
    protected $usage       = 'attendance:verify-dashboard-parity';

    public function run(array $params)
    {
        CLI::write("==================================================================", 'cyan');
        CLI::write("   DASHBOARD & ATTENDANCE MODULE PARITY VERIFICATION SUITE       ", 'yellow');
        CLI::write("==================================================================", 'cyan');

        $db = Database::connect();
        $engine = new AttendanceRuleEngine();
        $provider = new DashboardWidgetDataProvider();

        $passed = 0;
        $failed = 0;

        $suffix    = bin2hex(random_bytes(3));
        $companyId = 'comp-par-' . $suffix;
        $deptId    = 'dept-par-' . $suffix;
        $branchId  = 'br-par-' . $suffix;
        $shiftId   = 'sh-par-' . $suffix;

        $today = date('Y-m-d');

        try {
            // Setup isolated test fixtures
            if ($db->tableExists('companies')) {
                $db->table('companies')->insert([
                    'id'         => $companyId,
                    'name'       => 'Parity Test Corp ' . $suffix,
                    'currency'   => 'BDT',
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            }
            if ($db->tableExists('departments')) {
                $db->table('departments')->insert([
                    'id'         => $deptId,
                    'company_id' => $companyId,
                    'name'       => 'Operations',
                    'status'     => 'Active',
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            }
            if ($db->tableExists('branches')) {
                $db->table('branches')->insert([
                    'id'         => $branchId,
                    'company_id' => $companyId,
                    'name'       => 'Main Branch',
                    'status'     => 'Active',
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            }
            if ($db->tableExists('shifts')) {
                $db->table('shifts')->insert([
                    'id'         => $shiftId,
                    'company_id' => $companyId,
                    'name'       => 'Morning Shift',
                    'start_time' => '08:00:00',
                    'end_time'   => '16:00:00',
                    'grace_time' => 15,
                    'weekly_off' => 'Friday',
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            }

            // Create test employees across all primary buckets (including Probation):
            // 1. Present on time (Active)
            // 2. Late employee (Active)
            // 3. Approved leave today (Active)
            // 4. Probation employee absent (Probation)
            // 5. Missing punch employee (Active)
            $emp1 = 'emp-p1-' . $suffix;
            $emp2 = 'emp-p2-' . $suffix;
            $emp3 = 'emp-p3-' . $suffix;
            $emp4 = 'emp-p4-' . $suffix; // Probation
            $emp5 = 'emp-p5-' . $suffix;

            $testEmployees = [
                ['id' => $emp1, 'code' => 'EMP-1-' . $suffix, 'status' => 'Active',    'name' => 'Present Staff'],
                ['id' => $emp2, 'code' => 'EMP-2-' . $suffix, 'status' => 'Active',    'name' => 'Late Staff'],
                ['id' => $emp3, 'code' => 'EMP-3-' . $suffix, 'status' => 'Active',    'name' => 'Leave Staff'],
                ['id' => $emp4, 'code' => 'EMP-4-' . $suffix, 'status' => 'Probation', 'name' => 'Probation Absent Staff'],
                ['id' => $emp5, 'code' => 'EMP-5-' . $suffix, 'status' => 'Active',    'name' => 'Missing Punch Staff'],
            ];

            if ($db->tableExists('employees')) {
                foreach ($testEmployees as $te) {
                    $db->table('employees')->insert([
                        'id'             => $te['id'],
                        'company_id'     => $companyId,
                        'department_id'  => $deptId,
                        'branch_id'      => $branchId,
                        'shift_id'       => $shiftId,
                        'employee_code'  => $te['code'],
                        'first_name'     => $te['name'],
                        'last_name'      => '',
                        'status'         => $te['status'],
                        'joining_date'   => '2025-01-01',
                        'employment_start_date' => '2025-01-01',
                        'created_at'     => date('Y-m-d H:i:s'),
                    ]);
                }
            }

            // Punch logs for today:
            // Emp1: Present on time
            // Emp2: Late (check-in at 09:30)
            if ($db->tableExists('attendance_logs')) {
                $db->table('attendance_logs')->insert([
                    'id'            => 'att-log1-' . $suffix,
                    'company_id'    => $companyId,
                    'employee_id'   => $emp1,
                    'employee_code' => 'EMP-1-' . $suffix,
                    'date'          => $today,
                    'check_in'      => '08:00:00',
                    'check_out'     => '16:00:00',
                    'status'        => 'Present',
                    'created_at'    => date('Y-m-d H:i:s'),
                ]);

                $db->table('attendance_logs')->insert([
                    'id'            => 'att-log2-' . $suffix,
                    'company_id'    => $companyId,
                    'employee_id'   => $emp2,
                    'employee_code' => 'EMP-2-' . $suffix,
                    'date'          => $today,
                    'check_in'      => '09:30:00',
                    'check_out'     => '16:00:00',
                    'status'        => 'Late',
                    'late_minutes'  => 75,
                    'created_at'    => date('Y-m-d H:i:s'),
                ]);
            }

            // Approved Leave for Emp3:
            if ($db->tableExists('leave_applications')) {
                $db->table('leave_applications')->insert([
                    'id'            => 'lv-app-' . $suffix,
                    'company_id'    => $companyId,
                    'employee_id'   => $emp3,
                    'start_date'    => $today,
                    'end_date'      => $today,
                    'status'        => 'Approved',
                    'reason'        => 'Personal Leave',
                    'created_at'    => date('Y-m-d H:i:s'),
                ]);
            }

            $scope = [
                'type'          => 'company',
                'branch_id'     => $branchId,
                'department_id' => $deptId,
                'company_id'    => $companyId,
            ];

            // -------------------------------------------------------------
            // Test 1: Attendance Module "today" tab calculation
            // -------------------------------------------------------------
            CLI::write("Test 1: Query Attendance Module 'today' tab calculation...", 'white');
            AttendanceRuleEngine::clearEngineCaches();
            $moduleData = $engine->calculateAttendanceForDate($today, $branchId, $deptId, $companyId, null, null, null, false, false);
            $moduleStats = $moduleData['stats'] ?? [];

            $mPresent = (int)($moduleStats['present'] ?? 0);
            $mLate    = (int)($moduleStats['late'] ?? 0);
            $mAbsent  = (int)($moduleStats['absent'] ?? 0);
            $mLeave   = (int)($moduleStats['onLeave'] ?? ($moduleStats['on_leave'] ?? 0));
            $mTotal   = (int)($moduleStats['totalActive'] ?? 0);

            CLI::write("  -> Module Stats: TotalActive={$mTotal}, Present={$mPresent}, Late={$mLate}, Absent={$mAbsent}, OnLeave={$mLeave}", 'cyan');

            if ($mTotal === 5 && $mPresent >= 2 && $mLate >= 1 && $mLeave >= 1) {
                CLI::write("  -> PASSED: Attendance module calculated expected baseline metrics (includes Probation).", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: Attendance module baseline calculation mismatch.", 'red');
                $failed++;
            }

            // -------------------------------------------------------------
            // Test 2: Dashboard provideAttendanceStats parity
            // -------------------------------------------------------------
            CLI::write("\nTest 2: Dashboard provideAttendanceStats parity check...", 'white');
            $dashStats = $provider->provideAttendanceStats($today, $scope, $companyId, 0, true);

            $dPresent = (int)($dashStats['present'] ?? 0);
            $dLate    = (int)($dashStats['late'] ?? 0);
            $dAbsent  = (int)($dashStats['absent'] ?? 0);
            $dLeave   = (int)($dashStats['on_leave'] ?? 0);
            $dMissing = (int)($dashStats['missing_punch'] ?? 0);
            $dTotal   = (int)($dashStats['total_active'] ?? 0);

            CLI::write("  -> Dashboard Stats: TotalActive={$dTotal}, Present={$dPresent}, Late={$dLate}, Absent={$dAbsent}, OnLeave={$dLeave}, MissingPunch={$dMissing}", 'cyan');

            $mMissing = (int)($moduleStats['missingPunch'] ?? ($moduleStats['missing_punch'] ?? 0));

            $dashMismatches = [];
            if ($dPresent !== $mPresent) {
                $dashMismatches[] = "Present: dash={$dPresent} vs mod={$mPresent}";
            }
            if ($dLate !== $mLate) {
                $dashMismatches[] = "Late: dash={$dLate} vs mod={$mLate}";
            }
            if ($dAbsent !== $mAbsent) {
                $dashMismatches[] = "Absent: dash={$dAbsent} vs mod={$mAbsent}";
            }
            if ($dLeave !== $mLeave) {
                $dashMismatches[] = "OnLeave: dash={$dLeave} vs mod={$mLeave}";
            }
            if ($dMissing !== $mMissing) {
                $dashMismatches[] = "MissingPunch: dash={$dMissing} vs mod={$mMissing}";
            }
            if ($dTotal !== $mTotal) {
                $dashMismatches[] = "TotalActive: dash={$dTotal} vs mod={$mTotal}";
            }

            if (empty($dashMismatches)) {
                CLI::write("  -> PASSED: Dashboard attendance cards strictly equal Attendance module 'today' tab.", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: Parity mismatch between Dashboard and Attendance Module: " . implode(', ', $dashMismatches), 'red');
                $failed++;
            }

            // -------------------------------------------------------------
            // Test 3: Rolling 7-Day Trend Parity (Last Day === Today's Card)
            // -------------------------------------------------------------
            CLI::write("\nTest 3: 7-Day Rolling Trend last point vs today's card parity...", 'white');
            // Test with total_employees = 0 to verify independence from workforce widget
            $trend = $provider->provideRollingAttendanceTrend($today, $scope, $companyId, 0);

            if (empty($trend) || count($trend) !== 7) {
                CLI::write("  -> FAILED: Trend does not contain exactly 7 days.", 'red');
                $failed++;
            } else {
                $lastDay = end($trend);
                CLI::write("  -> Trend Last Day ({$lastDay['date']}): Present={$lastDay['present']}, Late={$lastDay['late']}, Absent={$lastDay['absent']}, Leave={$lastDay['on_leave']}, MissingPunch={$lastDay['missing_punch']}", 'cyan');

                $trendMismatches = [];
                if (($lastDay['date'] ?? '') !== $today) {
                    $trendMismatches[] = "Date mismatch: trend last date '{$lastDay['date']}' is not today '{$today}'";
                }
                if ($lastDay['present'] !== $dPresent) {
                    $trendMismatches[] = "Present: trend={$lastDay['present']} vs dash={$dPresent}";
                }
                if ($lastDay['late'] !== $dLate) {
                    $trendMismatches[] = "Late: trend={$lastDay['late']} vs dash={$dLate}";
                }
                if ($lastDay['absent'] !== $dAbsent) {
                    $trendMismatches[] = "Absent: trend={$lastDay['absent']} vs dash={$dAbsent}";
                }
                if ($lastDay['on_leave'] !== $dLeave) {
                    $trendMismatches[] = "OnLeave: trend={$lastDay['on_leave']} vs dash={$dLeave}";
                }
                if ($lastDay['missing_punch'] !== $dMissing) {
                    $trendMismatches[] = "MissingPunch: trend={$lastDay['missing_punch']} vs dash={$dMissing}";
                }
                if ($lastDay['total_active'] !== $dTotal) {
                    $trendMismatches[] = "TotalActive: trend={$lastDay['total_active']} vs dash={$dTotal}";
                }

                if (empty($trendMismatches)) {
                    CLI::write("  -> PASSED: Last point of 7-day trend strictly equals today's card.", 'green');
                    $passed++;
                } else {
                    CLI::write("  -> FAILED: Trend last point mismatch with today's card: " . implode(', ', $trendMismatches), 'red');
                    $failed++;
                }
            }

            // -------------------------------------------------------------
            // Test 4: Engine Per-Request Cache Check
            // -------------------------------------------------------------
            CLI::write("\nTest 4: Verify AttendanceRuleEngine per-request cache hit...", 'white');
            $secondRun = $engine->calculateAttendanceForDate($today, $branchId, $deptId, $companyId, null, null, null, false, false);
            if ($secondRun === $moduleData) {
                CLI::write("  -> PASSED: Subsequent call for the same day, scope, and parameters served strictly from calculationCache.", 'green');
                $passed++;
            } else {
                CLI::write("  -> FAILED: Cache did not return identical reference result.", 'red');
                $failed++;
            }

        } finally {
            // Clean up all fixtures
            try {
                if ($db->tableExists('leave_applications')) {
                    $db->table('leave_applications')->where('company_id', $companyId)->delete();
                }
                if ($db->tableExists('attendance_logs')) {
                    $db->table('attendance_logs')->where('company_id', $companyId)->delete();
                }
                if ($db->tableExists('employees')) {
                    $db->table('employees')->where('company_id', $companyId)->delete();
                }
                if ($db->tableExists('shifts')) {
                    $db->table('shifts')->where('company_id', $companyId)->delete();
                }
                if ($db->tableExists('branches')) {
                    $db->table('branches')->where('company_id', $companyId)->delete();
                }
                if ($db->tableExists('departments')) {
                    $db->table('departments')->where('company_id', $companyId)->delete();
                }
                if ($db->tableExists('companies')) {
                    $db->table('companies')->where('id', $companyId)->delete();
                }
            } catch (\Throwable $e) {}
        }

        CLI::write("\n==================================================================", 'cyan');
        CLI::write("    PARITY SUITE FINISHED: Passed: {$passed}, Failed: {$failed}    ", $failed === 0 ? 'green' : 'red');
        CLI::write("==================================================================", 'cyan');

        return $failed === 0 ? 0 : 1;
    }
}
