<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application Error</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0f172a; color: #f8fafc; padding: 40px 20px; }
        .container { max-width: 900px; margin: 0 auto; background: #1e293b; border: 1px solid #334155; border-radius: 12px; padding: 30px; }
        h1 { color: #f43f5e; font-size: 22px; margin-top: 0; }
        pre { background: #0f172a; border: 1px solid #334155; padding: 15px; border-radius: 8px; overflow-x: auto; color: #38bdf8; font-size: 13px; }
        p { color: #94a3b8; font-size: 14px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>An Error Occurred</h1>
        <p><?= esc($message ?? 'An uncaught error was encountered.') ?></p>
        <?php if (ENVIRONMENT !== 'production' && isset($exception)): ?>
            <pre><?= esc($exception->getMessage()) . "\n\n" . esc($exception->getTraceAsString()) ?></pre>
        <?php endif; ?>
    </div>
</body>
</html>
