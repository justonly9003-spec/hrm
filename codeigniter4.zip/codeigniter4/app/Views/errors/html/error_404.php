<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Page Not Found</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0f172a; color: #f8fafc; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
        .box { background: #1e293b; border: 1px solid #334155; border-radius: 12px; padding: 40px; text-align: center; max-width: 480px; }
        h1 { font-size: 32px; color: #f43f5e; margin: 0 0 10px 0; }
        p { color: #94a3b8; font-size: 14px; margin-bottom: 24px; }
        a { background: #4f46e5; color: white; padding: 10px 20px; border-radius: 8px; text-decoration: none; font-size: 13px; font-weight: 600; }
    </style>
</head>
<body>
    <div class="box">
        <h1>404</h1>
        <p><?= esc($message ?? 'Sorry! Cannot seem to find the page you were looking for.') ?></p>
        <a href="<?= base_url() ?>">Back to Dashboard</a>
    </div>
</body>
</html>
