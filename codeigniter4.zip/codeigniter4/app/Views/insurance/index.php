<!-- Medical Insurance Management Hub View -->
<?php
$menuVis = new \App\Services\MenuVisibilityService();
$currentUserId = (string)(session()->get('user_id') ?? '');
if (!empty($activeTab) && !$menuVis->isVisible($currentUserId, 'insurance.' . $activeTab)) {
    $firstTab = $menuVis->getFirstVisibleTab('insurance', $currentUserId) ?? 'dashboard';
    $activeTab = $firstTab;
}
?>
<div x-data="insuranceManager()" class="space-y-6">

    <!-- Flash Notifications -->
    <?php if (session()->getFlashdata('success')): ?>
        <div class="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs font-semibold flex items-center justify-between shadow-xs">
            <div class="flex items-center gap-2">
                <i data-lucide="check-circle" class="w-4 h-4 text-emerald-600 dark:text-emerald-400"></i>
                <span><?= esc(session()->getFlashdata('success')) ?></span>
            </div>
            <button @click="$el.parentElement.remove()" class="text-emerald-600 hover:text-emerald-800"><i data-lucide="x" class="w-4 h-4"></i></button>
        </div>
    <?php endif; ?>

    <?php if (session()->getFlashdata('error')): ?>
        <div class="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200 text-xs font-semibold flex items-center justify-between shadow-xs">
            <div class="flex items-center gap-2">
                <i data-lucide="alert-triangle" class="w-4 h-4 text-rose-600 dark:text-rose-400"></i>
                <span><?= esc(session()->getFlashdata('error')) ?></span>
            </div>
            <button @click="$el.parentElement.remove()" class="text-rose-600 hover:text-rose-800"><i data-lucide="x" class="w-4 h-4"></i></button>
        </div>
    <?php endif; ?>

    <!-- Main Navigation Header -->
    <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm">
        <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
                <div class="flex items-center gap-2.5">
                    <div class="w-10 h-10 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shadow-xs">
                        <i data-lucide="shield-plus" class="w-5 h-5"></i>
                    </div>
                    <div>
                        <h1 class="text-xl font-black text-slate-900 dark:text-white tracking-tight">Medical Insurance Management</h1>
                        <p class="text-xs text-slate-400 mt-0.5">Underwriters, healthcare packages, employee policy enrollments, dependents, and claims</p>
                    </div>
                </div>
            </div>

            <!-- Tab Navigation Pills -->
            <div class="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-100 dark:bg-slate-800/80 rounded-2xl border border-slate-200/60 dark:border-slate-700/60">
                <?php if ($menuVis->isVisible($currentUserId, 'insurance.dashboard')): ?>
                <button @click="switchTab('dashboard')" :class="activeTab === 'dashboard' ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 font-bold shadow-xs' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'" class="px-3.5 py-1.5 rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5">
                    <i data-lucide="layout-dashboard" class="w-3.5 h-3.5"></i>
                    <span>Dashboard</span>
                </button>
                <?php endif; ?>

                <?php if ($menuVis->isVisible($currentUserId, 'insurance.providers')): ?>
                <button @click="switchTab('providers')" :class="activeTab === 'providers' ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 font-bold shadow-xs' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'" class="px-3.5 py-1.5 rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5">
                    <i data-lucide="building-2" class="w-3.5 h-3.5"></i>
                    <span>Providers</span>
                </button>
                <?php endif; ?>

                <?php if ($menuVis->isVisible($currentUserId, 'insurance.plans')): ?>
                <button @click="switchTab('plans')" :class="activeTab === 'plans' ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 font-bold shadow-xs' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'" class="px-3.5 py-1.5 rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5">
                    <i data-lucide="layers" class="w-3.5 h-3.5"></i>
                    <span>Plans</span>
                </button>
                <?php endif; ?>

                <?php if ($menuVis->isVisible($currentUserId, 'insurance.enrollments')): ?>
                <button @click="switchTab('enrollments')" :class="activeTab === 'enrollments' ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 font-bold shadow-xs' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'" class="px-3.5 py-1.5 rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5">
                    <i data-lucide="users" class="w-3.5 h-3.5"></i>
                    <span>Enrollments</span>
                </button>
                <?php endif; ?>

                <?php if ($menuVis->isVisible($currentUserId, 'insurance.dependents')): ?>
                <button @click="switchTab('dependents')" :class="activeTab === 'dependents' ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 font-bold shadow-xs' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'" class="px-3.5 py-1.5 rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5">
                    <i data-lucide="heart-handshake" class="w-3.5 h-3.5"></i>
                    <span>Dependents</span>
                </button>
                <?php endif; ?>

                <?php if ($menuVis->isVisible($currentUserId, 'insurance.claims')): ?>
                <button @click="switchTab('claims')" :class="activeTab === 'claims' ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 font-bold shadow-xs' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'" class="px-3.5 py-1.5 rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5">
                    <i data-lucide="receipt" class="w-3.5 h-3.5"></i>
                    <span>Claims</span>
                </button>
                <?php endif; ?>

                <?php if ($menuVis->isVisible($currentUserId, 'insurance.reports')): ?>
                <button @click="switchTab('reports')" :class="activeTab === 'reports' ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 font-bold shadow-xs' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'" class="px-3.5 py-1.5 rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5">
                    <i data-lucide="bar-chart-3" class="w-3.5 h-3.5"></i>
                    <span>Reports</span>
                </button>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Active Tab Modules -->
    <?php if ($menuVis->isVisible($currentUserId, 'insurance.dashboard')): ?>
        <?= $this->include('insurance/tab_dashboard') ?>
    <?php endif; ?>
    <?php if ($menuVis->isVisible($currentUserId, 'insurance.providers')): ?>
        <?= $this->include('insurance/tab_providers') ?>
    <?php endif; ?>
    <?php if ($menuVis->isVisible($currentUserId, 'insurance.plans')): ?>
        <?= $this->include('insurance/tab_plans') ?>
    <?php endif; ?>
    <?php if ($menuVis->isVisible($currentUserId, 'insurance.enrollments')): ?>
        <?= $this->include('insurance/tab_enrollments') ?>
    <?php endif; ?>
    <?php if ($menuVis->isVisible($currentUserId, 'insurance.dependents')): ?>
        <?= $this->include('insurance/tab_dependents') ?>
    <?php endif; ?>
    <?php if ($menuVis->isVisible($currentUserId, 'insurance.claims')): ?>
        <?= $this->include('insurance/tab_claims') ?>
    <?php endif; ?>
    <?php if ($menuVis->isVisible($currentUserId, 'insurance.reports')): ?>
        <?= $this->include('insurance/tab_reports') ?>
    <?php endif; ?>

    <!-- ========================================================================= -->
    <!-- MODAL 1: PROVIDER MODAL (Create / Edit)                                    -->
    <!-- ========================================================================= -->
    <div x-show="showProviderModal" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" x-cloak>
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 w-full max-w-lg overflow-hidden shadow-2xl">
            <form method="POST" action="<?= base_url('insurance/providers/save') ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="id" x-model="providerForm.id">
                
                <div class="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <h3 class="text-base font-bold text-slate-900 dark:text-white" x-text="providerForm.id ? 'Edit Insurance Underwriter' : 'Register New Insurance Underwriter'"></h3>
                    <button type="button" @click="showProviderModal = false" class="text-slate-400 hover:text-slate-600"><i data-lucide="x" class="w-5 h-5"></i></button>
                </div>

                <div class="p-6 space-y-4 text-xs">
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Company / Underwriter Name *</label>
                        <input type="text" name="name" x-model="providerForm.name" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Contact Person</label>
                            <input type="text" name="contact_person" x-model="providerForm.contact_person" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                        </div>
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Phone</label>
                            <input type="text" name="phone" x-model="providerForm.phone" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Email</label>
                            <input type="email" name="email" x-model="providerForm.email" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                        </div>
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Policy / Master Contract #</label>
                            <input type="text" name="policy_number" x-model="providerForm.policy_number" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono">
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Contract Start Date</label>
                            <input type="date" name="contract_start_date" x-model="providerForm.contract_start_date" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                        </div>
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Contract End Date</label>
                            <input type="date" name="contract_end_date" x-model="providerForm.contract_end_date" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                        </div>
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Status</label>
                        <select name="status" x-model="providerForm.status" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                            <option value="Terminated">Terminated</option>
                        </select>
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Office Address</label>
                        <textarea name="address" x-model="providerForm.address" rows="2" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"></textarea>
                    </div>
                </div>

                <div class="p-6 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                    <button type="button" @click="showProviderModal = false" class="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200/50 transition cursor-pointer">Cancel</button>
                    <button type="submit" class="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-sm transition cursor-pointer">Save Provider</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ========================================================================= -->
    <!-- MODAL 2: PLAN MODAL (Create / Edit)                                        -->
    <!-- ========================================================================= -->
    <div x-show="showPlanModal" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" x-cloak>
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 w-full max-w-2xl overflow-hidden shadow-2xl">
            <form method="POST" action="<?= base_url('insurance/plans/save') ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="id" x-model="planForm.id">
                
                <div class="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <h3 class="text-base font-bold text-slate-900 dark:text-white" x-text="planForm.id ? 'Edit Insurance Benefit Plan' : 'Create Insurance Benefit Plan'"></h3>
                    <button type="button" @click="showPlanModal = false" class="text-slate-400 hover:text-slate-600"><i data-lucide="x" class="w-5 h-5"></i></button>
                </div>

                <div class="p-6 space-y-4 text-xs max-h-[75vh] overflow-y-auto">
                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Underwriter / Provider *</label>
                            <select name="provider_id" x-model="planForm.provider_id" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                                <option value="">Select Insurance Provider</option>
                                <?php foreach ($providers as $prov): ?>
                                    <option value="<?= esc($prov['id']) ?>"><?= esc($prov['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Plan Code *</label>
                            <input type="text" name="plan_code" x-model="planForm.plan_code" placeholder="e.g. MED-GOLD" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono uppercase">
                        </div>
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Plan Name *</label>
                        <input type="text" name="name" x-model="planForm.name" placeholder="e.g. Comprehensive Corporate Gold Plan" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Annual Coverage Limit (<?= esc($currencyCode) ?>) *</label>
                        <input type="number" step="0.01" name="annual_coverage_limit" x-model="planForm.annual_coverage_limit" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono font-bold">
                    </div>

                    <!-- Coverage Checkboxes -->
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-2">Covered Healthcare Benefits</label>
                        <div class="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                            <label class="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 cursor-pointer">
                                <input type="checkbox" name="hospitalization_coverage" value="1" x-model="planForm.hospitalization_coverage" class="rounded text-indigo-600">
                                <span>Hospitalization</span>
                            </label>
                            <label class="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 cursor-pointer">
                                <input type="checkbox" name="opd_coverage" value="1" x-model="planForm.opd_coverage" class="rounded text-indigo-600">
                                <span>Outpatient (OPD)</span>
                            </label>
                            <label class="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 cursor-pointer">
                                <input type="checkbox" name="emergency_coverage" value="1" x-model="planForm.emergency_coverage" class="rounded text-indigo-600">
                                <span>Emergency Care</span>
                            </label>
                            <label class="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 cursor-pointer">
                                <input type="checkbox" name="maternity_coverage" value="1" x-model="planForm.maternity_coverage" class="rounded text-indigo-600">
                                <span>Maternity</span>
                            </label>
                            <label class="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 cursor-pointer">
                                <input type="checkbox" name="dental_coverage" value="1" x-model="planForm.dental_coverage" class="rounded text-indigo-600">
                                <span>Dental Care</span>
                            </label>
                            <label class="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 cursor-pointer">
                                <input type="checkbox" name="vision_coverage" value="1" x-model="planForm.vision_coverage" class="rounded text-indigo-600">
                                <span>Vision Care</span>
                            </label>
                        </div>
                    </div>

                    <!-- Contribution Split -->
                    <div class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 space-y-3">
                        <div class="font-bold text-slate-800 dark:text-slate-200">Premium Contribution Split Configuration</div>
                        <div class="grid grid-cols-2 gap-3">
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Employer Contribution</label>
                                <div class="flex gap-2">
                                    <select name="employer_contribution_type" x-model="planForm.employer_contribution_type" class="w-1/2 px-2.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
                                        <option value="percentage">% Share</option>
                                        <option value="fixed">Fixed <?= esc($currencyCode) ?></option>
                                    </select>
                                    <input type="number" step="0.01" name="employer_contribution_value" x-model="planForm.employer_contribution_value" class="w-1/2 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono">
                                </div>
                            </div>
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Employee Deduction</label>
                                <div class="flex gap-2">
                                    <select name="employee_contribution_type" x-model="planForm.employee_contribution_type" class="w-1/2 px-2.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
                                        <option value="percentage">% Share</option>
                                        <option value="fixed">Fixed <?= esc($currencyCode) ?></option>
                                    </select>
                                    <input type="number" step="0.01" name="employee_contribution_value" x-model="planForm.employee_contribution_value" class="w-1/2 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="grid grid-cols-3 gap-3">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Effective Date</label>
                            <input type="date" name="effective_date" x-model="planForm.effective_date" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
                        </div>
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Expiry Date</label>
                            <input type="date" name="expiry_date" x-model="planForm.expiry_date" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
                        </div>
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Status</label>
                            <select name="status" x-model="planForm.status" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                                <option value="Draft">Draft</option>
                                <option value="Archived">Archived</option>
                            </select>
                        </div>
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Plan Description & Exclusions</label>
                        <textarea name="description" x-model="planForm.description" rows="2" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"></textarea>
                    </div>
                </div>

                <div class="p-6 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                    <button type="button" @click="showPlanModal = false" class="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200/50 transition cursor-pointer">Cancel</button>
                    <button type="submit" class="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-sm transition cursor-pointer">Save Plan</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ========================================================================= -->
    <!-- MODAL 3: ENROLL INDIVIDUAL EMPLOYEE                                       -->
    <!-- ========================================================================= -->
    <div x-show="showEnrollModal" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" x-cloak>
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 w-full max-w-lg overflow-hidden shadow-2xl">
            <form method="POST" action="<?= base_url('insurance/enroll') ?>">
                <?= csrf_field() ?>
                
                <div class="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <h3 class="text-base font-bold text-slate-900 dark:text-white">Enroll Individual Staff Member</h3>
                    <button type="button" @click="showEnrollModal = false" class="text-slate-400 hover:text-slate-600"><i data-lucide="x" class="w-5 h-5"></i></button>
                </div>

                <div class="p-6 space-y-4 text-xs">
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Select Employee *</label>
                        <select name="employee_id" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                            <option value="">Select Employee</option>
                            <?php foreach ($employees as $emp): ?>
                                <option value="<?= esc($emp['id']) ?>"><?= esc(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')) ?> (<?= esc($emp['employee_code'] ?? '—') ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Insurance Benefit Plan *</label>
                        <select name="plan_id" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                            <option value="">Select Plan</option>
                            <?php foreach ($plans as $pl): ?>
                                <option value="<?= esc($pl['id']) ?>"><?= esc($pl['name']) ?> (<?= esc($pl['plan_code']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Policy Number</label>
                            <input type="text" name="policy_number" placeholder="Optional / Auto-generated" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono">
                        </div>
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Member / Insurance Card ID</label>
                            <input type="text" name="member_id" placeholder="Optional / Auto-generated" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono">
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Effective Date *</label>
                            <input type="date" name="effective_date" value="<?= date('Y-m-d') ?>" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
                        </div>
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Expiry Date</label>
                            <input type="date" name="expiry_date" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Employer Contribution (<?= esc($currencyCode) ?>)</label>
                            <input type="number" step="0.01" name="employer_contribution" placeholder="Plan default" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono">
                        </div>
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Employee Deduction (<?= esc($currencyCode) ?>)</label>
                            <input type="number" step="0.01" name="employee_contribution" placeholder="Plan default" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono">
                        </div>
                    </div>
                </div>

                <div class="p-6 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                    <button type="button" @click="showEnrollModal = false" class="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200/50 transition cursor-pointer">Cancel</button>
                    <button type="submit" class="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-sm transition cursor-pointer">Enroll Staff</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ========================================================================= -->
    <!-- MODAL 4: BULK ENROLLMENT                                                  -->
    <!-- ========================================================================= -->
    <div x-show="showBulkEnrollModal" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" x-cloak>
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 w-full max-w-lg overflow-hidden shadow-2xl">
            <form method="POST" action="<?= base_url('insurance/enroll/bulk') ?>">
                <?= csrf_field() ?>
                
                <div class="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <h3 class="text-base font-bold text-slate-900 dark:text-white">Bulk Staff Insurance Enrollment</h3>
                    <button type="button" @click="showBulkEnrollModal = false" class="text-slate-400 hover:text-slate-600"><i data-lucide="x" class="w-5 h-5"></i></button>
                </div>

                <div class="p-6 space-y-4 text-xs">
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Target Benefit Plan *</label>
                        <select name="plan_id" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                            <option value="">Select Plan</option>
                            <?php foreach ($plans as $pl): ?>
                                <option value="<?= esc($pl['id']) ?>"><?= esc($pl['name']) ?> (<?= esc($pl['plan_code']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Effective Date *</label>
                        <input type="date" name="effective_date" value="<?= date('Y-m-d') ?>" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Select Employees (Hold Ctrl/Cmd to select multiple) *</label>
                        <select name="employee_ids[]" multiple required size="6" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs">
                            <?php foreach ($employees as $emp): ?>
                                <option value="<?= esc($emp['id']) ?>"><?= esc(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')) ?> (<?= esc($emp['employee_code'] ?? '—') ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="p-6 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                    <button type="button" @click="showBulkEnrollModal = false" class="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200/50 transition cursor-pointer">Cancel</button>
                    <button type="submit" class="px-5 py-2.5 bg-slate-900 dark:bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold shadow-sm transition cursor-pointer">Execute Bulk Onboarding</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ========================================================================= -->
    <!-- MODAL 5: ALL-ACTIVE COMPANY ENROLLMENT                                    -->
    <!-- ========================================================================= -->
    <div x-show="showAllActiveModal" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" x-cloak>
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 w-full max-w-lg overflow-hidden shadow-2xl">
            <form method="POST" action="<?= base_url('insurance/enroll/all-active') ?>">
                <?= csrf_field() ?>
                
                <div class="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <h3 class="text-base font-bold text-slate-900 dark:text-white">Assign Plan to All Active Employees</h3>
                    <button type="button" @click="showAllActiveModal = false" class="text-slate-400 hover:text-slate-600"><i data-lucide="x" class="w-5 h-5"></i></button>
                </div>

                <div class="p-6 space-y-4 text-xs">
                    <div class="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200/60 text-emerald-800 dark:text-emerald-200">
                        <i data-lucide="sparkles" class="w-4 h-4 inline mr-1"></i>
                        This operation automatically enrolls every currently active staff member in your organization who does not already have an active policy in this benefit tier.
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Target Benefit Plan *</label>
                        <select name="plan_id" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                            <option value="">Select Plan</option>
                            <?php foreach ($plans as $pl): ?>
                                <option value="<?= esc($pl['id']) ?>"><?= esc($pl['name']) ?> (<?= esc($pl['plan_code']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Effective Date *</label>
                            <input type="date" name="effective_date" value="<?= date('Y-m-d') ?>" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
                        </div>
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Expiry Date</label>
                            <input type="date" name="expiry_date" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
                        </div>
                    </div>
                </div>

                <div class="p-6 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                    <button type="button" @click="showAllActiveModal = false" class="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200/50 transition cursor-pointer">Cancel</button>
                    <button type="submit" class="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-sm transition cursor-pointer">Execute All-Active Enrollment</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ========================================================================= -->
    <!-- MODAL 6: UPDATE ENROLLMENT STATUS                                         -->
    <!-- ========================================================================= -->
    <div x-show="showStatusModal" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" x-cloak>
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 w-full max-w-md overflow-hidden shadow-2xl">
            <form method="POST" :action="'<?= base_url('insurance/enrollments/status/') ?>' + statusForm.id">
                <?= csrf_field() ?>
                
                <div class="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <h3 class="text-base font-bold text-slate-900 dark:text-white">Change Policy Status</h3>
                    <button type="button" @click="showStatusModal = false" class="text-slate-400 hover:text-slate-600"><i data-lucide="x" class="w-5 h-5"></i></button>
                </div>

                <div class="p-6 space-y-4 text-xs">
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">New Coverage Status *</label>
                        <select name="status" x-model="statusForm.status" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                            <option value="Active">Active</option>
                            <option value="Pending">Pending</option>
                            <option value="Suspended">Suspended</option>
                            <option value="Expired">Expired</option>
                            <option value="Cancelled">Cancelled</option>
                        </select>
                    </div>

                    <div x-show="statusForm.status === 'Cancelled'">
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Cancellation Reason</label>
                        <textarea name="reason" x-model="statusForm.reason" rows="2" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"></textarea>
                    </div>
                </div>

                <div class="p-6 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                    <button type="button" @click="showStatusModal = false" class="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200/50 transition cursor-pointer">Cancel</button>
                    <button type="submit" class="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-sm transition cursor-pointer">Update Status</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ========================================================================= -->
    <!-- MODAL 7: DEPENDENT MODAL (Create / Edit)                                  -->
    <!-- ========================================================================= -->
    <div x-show="showDependentModal" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" x-cloak>
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 w-full max-w-lg overflow-hidden shadow-2xl">
            <form method="POST" action="<?= base_url('insurance/dependents/save') ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="id" x-model="dependentForm.id">
                
                <div class="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <h3 class="text-base font-bold text-slate-900 dark:text-white" x-text="dependentForm.id ? 'Edit Insured Dependent' : 'Register Insured Dependent'"></h3>
                    <button type="button" @click="showDependentModal = false" class="text-slate-400 hover:text-slate-600"><i data-lucide="x" class="w-5 h-5"></i></button>
                </div>

                <div class="p-6 space-y-4 text-xs">
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Primary Staff Member *</label>
                        <select name="employee_id" x-model="dependentForm.employee_id" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                            <option value="">Select Employee</option>
                            <?php foreach ($employees as $emp): ?>
                                <option value="<?= esc($emp['id']) ?>"><?= esc(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')) ?> (<?= esc($emp['employee_code'] ?? '—') ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Dependent Full Name *</label>
                        <input type="text" name="full_name" x-model="dependentForm.full_name" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Relationship *</label>
                            <select name="relationship" x-model="dependentForm.relationship" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                                <option value="Spouse">Spouse</option>
                                <option value="Child">Child</option>
                                <option value="Parent">Parent</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Gender</label>
                            <select name="gender" x-model="dependentForm.gender" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Date of Birth</label>
                            <input type="date" name="date_of_birth" x-model="dependentForm.date_of_birth" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
                        </div>
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">National ID / Passport #</label>
                            <input type="text" name="national_id" x-model="dependentForm.national_id" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono">
                        </div>
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Coverage Status</label>
                        <select name="status" x-model="dependentForm.status" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Medical Notes / Chronic Conditions</label>
                        <textarea name="notes" x-model="dependentForm.notes" rows="2" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"></textarea>
                    </div>
                </div>

                <div class="p-6 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                    <button type="button" @click="showDependentModal = false" class="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200/50 transition cursor-pointer">Cancel</button>
                    <button type="submit" class="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-sm transition cursor-pointer">Save Dependent</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ========================================================================= -->
    <!-- MODAL 8: SUBMIT CLAIM MODAL                                               -->
    <!-- ========================================================================= -->
    <div x-show="showClaimModal" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" x-cloak>
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 w-full max-w-lg overflow-hidden shadow-2xl">
            <form method="POST" action="<?= base_url('insurance/claims/create') ?>">
                <?= csrf_field() ?>
                
                <div class="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <h3 class="text-base font-bold text-slate-900 dark:text-white">Submit Healthcare Claim</h3>
                    <button type="button" @click="showClaimModal = false" class="text-slate-400 hover:text-slate-600"><i data-lucide="x" class="w-5 h-5"></i></button>
                </div>

                <div class="p-6 space-y-4 text-xs">
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Claimant Employee *</label>
                        <select name="employee_id" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                            <option value="">Select Employee</option>
                            <?php foreach ($employees as $emp): ?>
                                <option value="<?= esc($emp['id']) ?>"><?= esc(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')) ?> (<?= esc($emp['employee_code'] ?? '—') ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Patient Type</label>
                            <select name="claimant_type" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
                                <option value="Employee">Employee (Self)</option>
                                <option value="Dependent">Family Dependent</option>
                            </select>
                        </div>
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Patient Name</label>
                            <input type="text" name="claimant_name" placeholder="Leave blank if Self" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Benefit Category *</label>
                            <select name="claim_type" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
                                <option value="Hospitalization">Hospitalization</option>
                                <option value="OPD">Outpatient (OPD)</option>
                                <option value="Emergency">Emergency Care</option>
                                <option value="Maternity">Maternity</option>
                                <option value="Dental">Dental Care</option>
                                <option value="Vision">Vision Care</option>
                                <option value="Prescription">Prescription Meds</option>
                            </select>
                        </div>
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Claimed Amount (<?= esc($currencyCode) ?>) *</label>
                            <input type="number" step="0.01" name="claimed_amount" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono font-bold">
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Treatment / Incident Date *</label>
                            <input type="date" name="incident_date" value="<?= date('Y-m-d') ?>" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
                        </div>
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Hospital / Clinic / Provider</label>
                            <input type="text" name="hospital_name" placeholder="e.g. City General Hospital" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
                        </div>
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Diagnosis & Medical Reason</label>
                        <textarea name="diagnosis" rows="2" placeholder="Brief diagnostic description..." class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"></textarea>
                    </div>
                </div>

                <div class="p-6 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                    <button type="button" @click="showClaimModal = false" class="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200/50 transition cursor-pointer">Cancel</button>
                    <button type="submit" class="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-sm transition cursor-pointer">Submit Claim</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ========================================================================= -->
    <!-- MODAL 9: CLAIM TRANSITION (Review / Approve / Reject / Pay)               -->
    <!-- ========================================================================= -->
    <div x-show="showTransitionModal" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" x-cloak>
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 w-full max-w-md overflow-hidden shadow-2xl">
            <form method="POST" :action="'<?= base_url('insurance/claims/transition/') ?>' + transitionForm.claim_id">
                <?= csrf_field() ?>
                <input type="hidden" name="action" x-model="transitionForm.action">
                
                <div class="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <h3 class="text-base font-bold text-slate-900 dark:text-white" x-text="getTransitionTitle()"></h3>
                    <button type="button" @click="showTransitionModal = false" class="text-slate-400 hover:text-slate-600"><i data-lucide="x" class="w-5 h-5"></i></button>
                </div>

                <div class="p-6 space-y-4 text-xs">
                    <div class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 font-mono">
                        <div>Claim: <span class="font-bold text-slate-900 dark:text-white" x-text="transitionForm.claim_number"></span></div>
                        <div>Claimed: <span class="font-bold text-indigo-600" x-text="'<?= esc($currencyCode) ?> ' + Number(transitionForm.claimed_amount || 0).toFixed(2)"></span></div>
                    </div>

                    <!-- Approve: approved amount -->
                    <div x-show="transitionForm.action === 'approve'">
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Approved Amount (<?= esc($currencyCode) ?>) *</label>
                        <input type="number" step="0.01" name="approved_amount" x-model="transitionForm.approved_amount" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono font-bold text-emerald-600">
                    </div>

                    <!-- Pay: paid amount & payment ref -->
                    <div x-show="transitionForm.action === 'pay'" class="space-y-3">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Disbursed Amount (<?= esc($currencyCode) ?>) *</label>
                            <input type="number" step="0.01" name="paid_amount" x-model="transitionForm.paid_amount" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono font-bold text-purple-600">
                        </div>
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Payment Reference / Bank Trx ID</label>
                            <input type="text" name="payment_reference" x-model="transitionForm.payment_reference" placeholder="e.g. TRX-998822" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono">
                        </div>
                    </div>

                    <!-- Reject / Review notes -->
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1" x-text="transitionForm.action === 'reject' ? 'Rejection Reason *' : 'Adjudication Remarks'"></label>
                        <textarea name="remarks" x-model="transitionForm.remarks" rows="2" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"></textarea>
                    </div>
                </div>

                <div class="p-6 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                    <button type="button" @click="showTransitionModal = false" class="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200/50 transition cursor-pointer">Cancel</button>
                    <button type="submit" class="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-sm transition cursor-pointer" x-text="getSubmitBtnText()"></button>
                </div>
            </form>
        </div>
    </div>

    <!-- ========================================================================= -->
    <!-- MODAL 10: UPLOAD CLAIM DOCUMENT / RECEIPT                                  -->
    <!-- ========================================================================= -->
    <div x-show="showUploadDocModal" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" x-cloak>
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 w-full max-w-md overflow-hidden shadow-2xl">
            <form method="POST" :action="'<?= base_url('insurance/claims/') ?>' + uploadDocForm.claim_id + '/documents'" enctype="multipart/form-data">
                <?= csrf_field() ?>
                
                <div class="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <div>
                        <h3 class="text-base font-bold text-slate-900 dark:text-white">Upload Claim Document</h3>
                        <p class="text-[11px] text-slate-400 font-mono" x-text="'Claim #' + uploadDocForm.claim_number"></p>
                    </div>
                    <button type="button" @click="showUploadDocModal = false" class="text-slate-400 hover:text-slate-600"><i data-lucide="x" class="w-5 h-5"></i></button>
                </div>

                <div class="p-6 space-y-4 text-xs">
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Document Category *</label>
                        <select name="document_type" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                            <option value="Invoice">Hospital / Pharmacy Invoice</option>
                            <option value="Prescription">Doctor Prescription</option>
                            <option value="Discharge_Summary">Discharge Summary</option>
                            <option value="Lab_Report">Diagnostic / Lab Report</option>
                            <option value="Receipt">Payment Receipt</option>
                            <option value="Other">Other Supporting Document</option>
                        </select>
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Document Title</label>
                        <input type="text" name="document_name" placeholder="e.g. Inpatient Admission Bill" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">File Attachment (PDF, JPG, PNG) *</label>
                        <input type="file" name="file" required class="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                    </div>
                </div>

                <div class="p-6 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                    <button type="button" @click="showUploadDocModal = false" class="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200/50 transition cursor-pointer">Cancel</button>
                    <button type="submit" class="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-sm transition cursor-pointer">Upload Document</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ========================================================================= -->
    <!-- DRAWER / MODAL 11: 360 COVERAGE PROFILE VIEW                              -->
    <!-- ========================================================================= -->
    <div x-show="showCoverageModal" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" x-cloak>
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 w-full max-w-xl overflow-hidden shadow-2xl">
            <div class="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                        <i data-lucide="shield-check" class="w-5 h-5"></i>
                    </div>
                    <div>
                        <h3 class="text-base font-bold text-slate-900 dark:text-white" x-text="coverageData.employee ? (coverageData.employee.first_name + ' ' + coverageData.employee.last_name) : 'Coverage Profile'"></h3>
                        <p class="text-xs text-slate-400 font-mono" x-text="coverageData.employee ? coverageData.employee.employee_code : ''"></p>
                    </div>
                </div>
                <button type="button" @click="showCoverageModal = false" class="text-slate-400 hover:text-slate-600"><i data-lucide="x" class="w-5 h-5"></i></button>
            </div>

            <div class="p-6 space-y-5 text-xs max-h-[70vh] overflow-y-auto" x-show="coverageData.employee">
                <!-- Active Policy Card -->
                <template x-if="coverageData.active_coverage">
                    <div class="p-4 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50">
                        <div class="flex items-center justify-between mb-2">
                            <span class="text-[10px] uppercase font-bold tracking-wider text-indigo-600 dark:text-indigo-400">Current Health Benefit Plan</span>
                            <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700" x-text="coverageData.active_coverage.coverage_status"></span>
                        </div>
                        <h4 class="text-base font-black text-slate-900 dark:text-white" x-text="coverageData.active_coverage.plan_name"></h4>
                        <div class="grid grid-cols-2 gap-3 mt-3">
                            <div>Policy: <strong class="font-mono text-slate-800 dark:text-slate-200" x-text="coverageData.active_coverage.policy_number || '—'"></strong></div>
                            <div>Member ID: <strong class="font-mono text-indigo-600" x-text="coverageData.active_coverage.member_id || '—'"></strong></div>
                            <div>Effective: <span x-text="coverageData.active_coverage.effective_date"></span></div>
                            <div>Expires: <span x-text="coverageData.active_coverage.expiry_date || 'Open Renewal'"></span></div>
                        </div>
                    </div>
                </template>

                <template x-if="!coverageData.active_coverage">
                    <div class="py-6 text-center text-slate-400 bg-slate-50 dark:bg-slate-800/40 rounded-2xl">
                        No active medical policy recorded for this employee.
                    </div>
                </template>

                <!-- Dependents List -->
                <div>
                    <h4 class="font-bold text-slate-900 dark:text-white mb-2">Registered Family Dependents (<span x-text="(coverageData.dependents || []).length"></span>)</h4>
                    <div class="space-y-2">
                        <template x-for="d in (coverageData.dependents || [])" :key="d.id">
                            <div class="flex items-center justify-between p-3 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30">
                                <div>
                                    <div class="font-bold text-slate-900 dark:text-white" x-text="d.full_name"></div>
                                    <div class="text-[10px] text-slate-400" x-text="d.relationship + (d.date_of_birth ? (' • Born ' + d.date_of_birth) : '')"></div>
                                </div>
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold" :class="d.status === 'Active' ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'" x-text="d.status"></span>
                            </div>
                        </template>
                        <div x-show="!(coverageData.dependents && coverageData.dependents.length)" class="text-slate-400 italic text-center py-2">
                            No dependents registered.
                        </div>
                    </div>
                </div>

                <!-- Claims History -->
                <div>
                    <h4 class="font-bold text-slate-900 dark:text-white mb-2">Claims & Settlements History</h4>
                    <div class="space-y-2">
                        <template x-for="c in (coverageData.claims || [])" :key="c.id">
                            <div class="flex items-center justify-between p-3 rounded-xl border border-slate-100 dark:border-slate-800">
                                <div>
                                    <div class="font-bold font-mono text-slate-900 dark:text-white" x-text="c.claim_number"></div>
                                    <div class="text-[10px] text-slate-400" x-text="c.claim_type + ' • ' + c.claim_date"></div>
                                </div>
                                <div class="text-right">
                                    <div class="font-mono font-bold text-slate-900 dark:text-white" x-text="'<?= esc($currencyCode) ?> ' + Number(c.claimed_amount || 0).toFixed(2)"></div>
                                    <span class="text-[10px] font-bold" x-text="c.status"></span>
                                </div>
                            </div>
                        </template>
                        <div x-show="!(coverageData.claims && coverageData.claims.length)" class="text-slate-400 italic text-center py-2">
                            No medical claims submitted.
                        </div>
                    </div>
                </div>
            </div>

            <div class="p-6 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end">
                <button type="button" @click="showCoverageModal = false" class="px-4 py-2.5 bg-slate-900 dark:bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold cursor-pointer">Close</button>
            </div>
        </div>
    </div>

</div>

<!-- Alpine.js Insurance Manager Script -->
<script>
function insuranceManager() {
    return {
        activeTab: '<?= esc($activeTab) ?>',
        
        // Modals visibility
        showProviderModal: false,
        showPlanModal: false,
        showEnrollModal: false,
        showBulkEnrollModal: false,
        showAllActiveModal: false,
        showStatusModal: false,
        showDependentModal: false,
        showClaimModal: false,
        showTransitionModal: false,
        showUploadDocModal: false,
        showCoverageModal: false,

        // Forms state
        providerForm: {
            id: '',
            name: '',
            contact_person: '',
            phone: '',
            email: '',
            policy_number: '',
            contract_start_date: '',
            contract_end_date: '',
            status: 'Active',
            address: ''
        },
        planForm: {
            id: '',
            provider_id: '',
            plan_code: '',
            name: '',
            annual_coverage_limit: 100000,
            hospitalization_coverage: true,
            opd_coverage: true,
            emergency_coverage: true,
            maternity_coverage: false,
            dental_coverage: false,
            vision_coverage: false,
            employer_contribution_type: 'percentage',
            employer_contribution_value: 80,
            employee_contribution_type: 'percentage',
            employee_contribution_value: 20,
            effective_date: '<?= date('Y-m-d') ?>',
            expiry_date: '',
            status: 'Active',
            description: ''
        },
        statusForm: {
            id: '',
            status: 'Active',
            reason: ''
        },
        dependentForm: {
            id: '',
            employee_id: '',
            full_name: '',
            relationship: 'Spouse',
            gender: 'Female',
            date_of_birth: '',
            national_id: '',
            status: 'Active',
            notes: ''
        },
        transitionForm: {
            claim_id: '',
            claim_number: '',
            action: '',
            claimed_amount: 0,
            approved_amount: 0,
            paid_amount: 0,
            payment_reference: '',
            remarks: ''
        },
        uploadDocForm: {
            claim_id: '',
            claim_number: ''
        },
        coverageData: {},

        // Tab switcher
        switchTab(tab) {
            this.activeTab = tab;
            const url = new URL(window.location);
            url.searchParams.set('tab', tab);
            window.history.pushState({}, '', url);
            this.$nextTick(() => {
                if (window.lucide) {
                    window.lucide.createIcons();
                }
            });
        },

        // Provider Actions
        openProviderModal() {
            this.providerForm = {
                id: '',
                name: '',
                contact_person: '',
                phone: '',
                email: '',
                policy_number: '',
                contract_start_date: '',
                contract_end_date: '',
                status: 'Active',
                address: ''
            };
            this.showProviderModal = true;
        },
        editProvider(p) {
            this.providerForm = {
                id: p.id,
                name: p.name || '',
                contact_person: p.contact_person || '',
                phone: p.phone || '',
                email: p.email || '',
                policy_number: p.policy_number || '',
                contract_start_date: p.contract_start_date || '',
                contract_end_date: p.contract_end_date || '',
                status: p.status || 'Active',
                address: p.address || ''
            };
            this.showProviderModal = true;
        },

        // Plan Actions
        openPlanModal() {
            this.planForm = {
                id: '',
                provider_id: '',
                plan_code: '',
                name: '',
                annual_coverage_limit: 100000,
                hospitalization_coverage: true,
                opd_coverage: true,
                emergency_coverage: true,
                maternity_coverage: false,
                dental_coverage: false,
                vision_coverage: false,
                employer_contribution_type: 'percentage',
                employer_contribution_value: 80,
                employee_contribution_type: 'percentage',
                employee_contribution_value: 20,
                effective_date: '<?= date('Y-m-d') ?>',
                expiry_date: '',
                status: 'Active',
                description: ''
            };
            this.showPlanModal = true;
        },
        editPlan(pl) {
            this.planForm = {
                id: pl.id,
                provider_id: pl.provider_id || '',
                plan_code: pl.plan_code || '',
                name: pl.name || '',
                annual_coverage_limit: pl.annual_coverage_limit || 0,
                hospitalization_coverage: Boolean(Number(pl.hospitalization_coverage)),
                opd_coverage: Boolean(Number(pl.opd_coverage)),
                emergency_coverage: Boolean(Number(pl.emergency_coverage)),
                maternity_coverage: Boolean(Number(pl.maternity_coverage)),
                dental_coverage: Boolean(Number(pl.dental_coverage)),
                vision_coverage: Boolean(Number(pl.vision_coverage)),
                employer_contribution_type: pl.employer_contribution_type || 'percentage',
                employer_contribution_value: pl.employer_contribution_value || 0,
                employee_contribution_type: pl.employee_contribution_type || 'percentage',
                employee_contribution_value: pl.employee_contribution_value || 0,
                effective_date: pl.effective_date || '',
                expiry_date: pl.expiry_date || '',
                status: pl.status || 'Active',
                description: pl.description || ''
            };
            this.showPlanModal = true;
        },

        // Enrollment Actions
        openEnrollModal() {
            this.showEnrollModal = true;
        },
        openBulkEnrollModal() {
            this.showBulkEnrollModal = true;
        },
        openAllActiveModal() {
            this.showAllActiveModal = true;
        },
        openStatusModal(en) {
            this.statusForm = {
                id: en.id,
                status: en.coverage_status || 'Active',
                reason: en.cancellation_reason || ''
            };
            this.showStatusModal = true;
        },
        async viewCoverage(employeeId) {
            this.coverageData = {};
            this.showCoverageModal = true;
            try {
                const res = await fetch('<?= base_url('insurance/coverage/') ?>' + employeeId, {
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                });
                const json = await res.json();
                if (json.success && json.data) {
                    this.coverageData = json.data;
                }
            } catch (err) {
                console.error('Failed to load coverage profile:', err);
            }
        },

        // Dependent Actions
        openDependentModal() {
            this.dependentForm = {
                id: '',
                employee_id: '',
                full_name: '',
                relationship: 'Spouse',
                gender: 'Female',
                date_of_birth: '',
                national_id: '',
                status: 'Active',
                notes: ''
            };
            this.showDependentModal = true;
        },
        editDependent(dep) {
            this.dependentForm = {
                id: dep.id,
                employee_id: dep.employee_id || '',
                full_name: dep.full_name || '',
                relationship: dep.relationship || 'Spouse',
                gender: dep.gender || 'Female',
                date_of_birth: dep.date_of_birth || '',
                national_id: dep.national_id || '',
                status: dep.status || 'Active',
                notes: dep.notes || ''
            };
            this.showDependentModal = true;
        },

        // Claim Actions
        openClaimModal() {
            this.showClaimModal = true;
        },
        openTransitionModal(claim, action) {
            this.transitionForm = {
                claim_id: claim.id,
                claim_number: claim.claim_number,
                action: action,
                claimed_amount: claim.claimed_amount || 0,
                approved_amount: claim.claimed_amount || 0,
                paid_amount: claim.approved_amount || claim.claimed_amount || 0,
                payment_reference: '',
                remarks: ''
            };
            this.showTransitionModal = true;
        },
        openUploadDocModal(claimId, claimNumber) {
            this.uploadDocForm = {
                claim_id: claimId,
                claim_number: claimNumber
            };
            this.showUploadDocModal = true;
        },
        getTransitionTitle() {
            switch(this.transitionForm.action) {
                case 'review': return 'Place Claim Under Review';
                case 'approve': return 'Approve Claim Settlement';
                case 'reject': return 'Reject Claim';
                case 'pay': return 'Disburse Claim Payment';
                default: return 'Adjudicate Claim';
            }
        },
        getSubmitBtnText() {
            switch(this.transitionForm.action) {
                case 'review': return 'Confirm Review';
                case 'approve': return 'Approve Settlement';
                case 'reject': return 'Confirm Rejection';
                case 'pay': return 'Record Disbursement';
                default: return 'Submit';
            }
        }
    };
}
</script>
