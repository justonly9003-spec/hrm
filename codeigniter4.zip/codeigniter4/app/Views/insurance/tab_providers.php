<!-- Tab: Insurance Providers Management -->
<div x-show="activeTab === 'providers'" class="space-y-6">
    <!-- Header with Search & Add Provider -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h3 class="text-lg font-bold text-slate-900 dark:text-white">Insurance Providers</h3>
            <p class="text-xs text-slate-400 mt-0.5">Manage partner insurance underwriters, contact points, and master corporate policies</p>
        </div>
        <div class="flex items-center gap-2">
            <button @click="openProviderModal()" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer shadow-sm shadow-indigo-600/20">
                <i data-lucide="plus" class="w-4 h-4"></i>
                <span>Add Provider</span>
            </button>
        </div>
    </div>

    <!-- Provider Cards / Table -->
    <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-sm">
        <?php if (empty($providers)): ?>
            <div class="py-16 text-center text-slate-400">
                <i data-lucide="building" class="w-10 h-10 mx-auto mb-2 opacity-40"></i>
                <p class="text-sm font-semibold">No insurance providers registered yet.</p>
                <p class="text-xs mt-1">Click "Add Provider" above to add your company's insurance underwriter.</p>
            </div>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead class="bg-slate-50 dark:bg-slate-800/50 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-100 dark:border-slate-800">
                        <tr>
                            <th class="px-5 py-3.5">Provider Name</th>
                            <th class="px-5 py-3.5">Contact Person</th>
                            <th class="px-5 py-3.5">Contact Info</th>
                            <th class="px-5 py-3.5">Policy / Contract Ref</th>
                            <th class="px-5 py-3.5">Contract Period</th>
                            <th class="px-5 py-3.5 text-center">Status</th>
                            <th class="px-5 py-3.5 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                        <?php foreach ($providers as $p): ?>
                        <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition">
                            <td class="px-5 py-3.5">
                                <div class="font-bold text-slate-900 dark:text-white"><?= esc($p['name']) ?></div>
                                <?php if (!empty($p['plan_count'])): ?>
                                    <span class="text-[10px] text-slate-400 font-medium"><?= (int)$p['plan_count'] ?> active plan(s)</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-5 py-3.5 text-slate-600 dark:text-slate-300">
                                <?= esc($p['contact_person'] ?: '—') ?>
                            </td>
                            <td class="px-5 py-3.5 text-slate-500">
                                <div><?= esc($p['email'] ?: '—') ?></div>
                                <div class="text-[11px] text-slate-400"><?= esc($p['phone'] ?: '') ?></div>
                            </td>
                            <td class="px-5 py-3.5 font-mono text-slate-600 dark:text-slate-300">
                                <?= esc($p['policy_number'] ?: '—') ?>
                            </td>
                            <td class="px-5 py-3.5 text-[11px] text-slate-500">
                                <?php if (!empty($p['contract_start_date'])): ?>
                                    <?= esc($p['contract_start_date']) ?> to <?= esc($p['contract_end_date'] ?: 'Open') ?>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                            <td class="px-5 py-3.5 text-center">
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold <?= $p['status'] === 'Active' ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 border border-emerald-200/50 dark:border-emerald-800/50' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400' ?>">
                                    <?= esc($p['status']) ?>
                                </span>
                            </td>
                            <td class="px-5 py-3.5 text-right space-x-1">
                                <button @click="editProvider(<?= htmlspecialchars(json_encode($p), ENT_QUOTES, 'UTF-8') ?>)" class="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition cursor-pointer" title="Edit Provider">
                                    <i data-lucide="pencil" class="w-3.5 h-3.5"></i>
                                </button>
                                <form method="POST" action="<?= base_url('insurance/providers/delete/' . $p['id']) ?>" class="inline" onsubmit="return confirm('Are you sure you want to delete or deactivate this provider?');">
                                    <?= csrf_field() ?>
                                    <button type="submit" class="p-1.5 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/40 text-rose-600 dark:text-rose-400 transition cursor-pointer" title="Delete Provider">
                                        <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
