<!-- Tab: Dashboard Statistics & Executive KPI Metrics -->
<div x-show="activeTab === 'dashboard'" class="space-y-6">
    <!-- Top KPI Grid -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <!-- Insured Employees -->
        <div class="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm relative overflow-hidden">
            <div class="flex items-center justify-between">
                <div>
                    <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Insured Staff</span>
                    <h3 class="text-2xl font-black text-slate-900 dark:text-white mt-1">
                        <?= number_format($stats['insured_employees'] ?? 0) ?>
                    </h3>
                    <p class="text-[11px] text-slate-500 mt-1">
                        Out of <?= number_format($stats['total_employees'] ?? 0) ?> active staff
                    </p>
                </div>
                <div class="w-12 h-12 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                    <i data-lucide="shield-check" class="w-6 h-6"></i>
                </div>
            </div>
            <div class="mt-3 w-full bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden">
                <?php 
                    $coveragePercent = !empty($stats['total_employees']) ? min(100, round(($stats['insured_employees'] / $stats['total_employees']) * 100, 1)) : 0;
                ?>
                <div class="bg-emerald-500 h-1.5 rounded-full" style="width: <?= $coveragePercent ?>%"></div>
            </div>
            <span class="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold mt-1 inline-block"><?= $coveragePercent ?>% Workforce Covered</span>
        </div>

        <!-- Active Policies -->
        <div class="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm">
            <div class="flex items-center justify-between">
                <div>
                    <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Active Policies</span>
                    <h3 class="text-2xl font-black text-slate-900 dark:text-white mt-1">
                        <?= number_format($stats['active_coverage'] ?? 0) ?>
                    </h3>
                    <p class="text-[11px] text-slate-500 mt-1">
                        <?= number_format($stats['total_dependents'] ?? 0) ?> dependents covered
                    </p>
                </div>
                <div class="w-12 h-12 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
                    <i data-lucide="users" class="w-6 h-6"></i>
                </div>
            </div>
            <div class="mt-3 flex items-center gap-2 text-[11px] text-slate-500">
                <span class="font-medium text-amber-600 dark:text-amber-400 flex items-center gap-1">
                    <i data-lucide="clock" class="w-3.5 h-3.5"></i>
                    <?= number_format($stats['expiring_coverage'] ?? 0) ?> expiring in 30 days
                </span>
            </div>
        </div>

        <!-- Claims Summary -->
        <div class="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm">
            <div class="flex items-center justify-between">
                <div>
                    <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Claims Disbursed</span>
                    <h3 class="text-2xl font-black text-slate-900 dark:text-white mt-1">
                        <?= esc($currencyCode) ?> <?= number_format($stats['total_paid_amount'] ?? 0, 2) ?>
                    </h3>
                    <p class="text-[11px] text-slate-500 mt-1">
                        <?= number_format($stats['paid_claims'] ?? 0) ?> claims settled
                    </p>
                </div>
                <div class="w-12 h-12 rounded-xl bg-sky-50 dark:bg-sky-950/50 flex items-center justify-center text-sky-600 dark:text-sky-400">
                    <i data-lucide="badge-dollar-sign" class="w-6 h-6"></i>
                </div>
            </div>
            <div class="mt-3 flex items-center justify-between text-[11px] text-slate-500">
                <span>Pending Adjudication:</span>
                <span class="font-bold text-amber-600 dark:text-amber-400"><?= number_format($stats['pending_claims'] ?? 0) ?></span>
            </div>
        </div>

        <!-- Plans & Providers -->
        <div class="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm">
            <div class="flex items-center justify-between">
                <div>
                    <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Active Plans</span>
                    <h3 class="text-2xl font-black text-slate-900 dark:text-white mt-1">
                        <?= number_format($stats['active_plans'] ?? 0) ?>
                    </h3>
                    <p class="text-[11px] text-slate-500 mt-1">
                        Across <?= number_format($stats['active_providers'] ?? 0) ?> underwriters
                    </p>
                </div>
                <div class="w-12 h-12 rounded-xl bg-purple-50 dark:bg-purple-950/50 flex items-center justify-center text-purple-600 dark:text-purple-400">
                    <i data-lucide="layers" class="w-6 h-6"></i>
                </div>
            </div>
            <div class="mt-3 flex items-center gap-1.5 text-[11px] text-slate-500">
                <span class="font-medium text-slate-600 dark:text-slate-300">Total Claimed:</span>
                <span class="font-bold"><?= esc($currencyCode) ?> <?= number_format($stats['total_claimed_amount'] ?? 0, 2) ?></span>
            </div>
        </div>
    </div>

    <!-- Middle: Plan Breakdown & Quick Actions -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Plan Breakdown Table -->
        <div class="lg:col-span-2 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm">
            <div class="flex items-center justify-between mb-4">
                <div>
                    <h4 class="text-sm font-bold text-slate-900 dark:text-white">Insurance Plan Distribution</h4>
                    <p class="text-xs text-slate-400 mt-0.5">Enrollment and monthly contribution volume per plan</p>
                </div>
                <button @click="activeTab = 'plans'" class="text-xs text-indigo-600 dark:text-indigo-400 hover:underline font-semibold cursor-pointer">
                    Manage Plans &rarr;
                </button>
            </div>

            <?php if (empty($stats['plan_breakdown'])): ?>
                <div class="py-12 text-center text-slate-400 text-xs">
                    <i data-lucide="inbox" class="w-8 h-8 mx-auto mb-2 opacity-50"></i>
                    No active insurance enrollments found yet.
                </div>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-xs">
                        <thead>
                            <tr class="text-[11px] text-slate-400 uppercase tracking-wider border-b border-slate-100 dark:border-slate-800 pb-2">
                                <th class="pb-2">Plan Name</th>
                                <th class="pb-2 text-center">Enrolled Staff</th>
                                <th class="pb-2 text-right">Total Premium Volume</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                            <?php foreach ($stats['plan_breakdown'] as $pb): ?>
                            <tr>
                                <td class="py-3 font-semibold text-slate-800 dark:text-slate-200">
                                    <?= esc($pb['plan_name'] ?? 'Unnamed Plan') ?>
                                </td>
                                <td class="py-3 text-center">
                                    <span class="px-2 py-0.5 rounded-full text-[11px] font-bold bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400">
                                        <?= number_format($pb['enrolled_count'] ?? 0) ?>
                                    </span>
                                </td>
                                <td class="py-3 text-right font-mono font-semibold text-slate-700 dark:text-slate-300">
                                    <?= esc($currencyCode) ?> <?= number_format($pb['total_premium'] ?? 0, 2) ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <!-- Quick Operations Panel -->
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm flex flex-col justify-between">
            <div>
                <h4 class="text-sm font-bold text-slate-900 dark:text-white mb-1">Quick Actions</h4>
                <p class="text-xs text-slate-400 mb-4">Execute policy operations and management workflows</p>
                
                <div class="space-y-2.5">
                    <button @click="openEnrollModal()" class="w-full px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold flex items-center justify-between transition cursor-pointer shadow-sm shadow-indigo-600/20">
                        <span class="flex items-center gap-2">
                            <i data-lucide="user-plus" class="w-4 h-4"></i>
                            Enroll Individual Employee
                        </span>
                        <i data-lucide="chevron-right" class="w-4 h-4 opacity-70"></i>
                    </button>

                    <button @click="openBulkEnrollModal()" class="w-full px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center justify-between transition cursor-pointer">
                        <span class="flex items-center gap-2">
                            <i data-lucide="users-round" class="w-4 h-4"></i>
                            Bulk Employee Enrollment
                        </span>
                        <i data-lucide="chevron-right" class="w-4 h-4 opacity-70"></i>
                    </button>

                    <button @click="openClaimModal()" class="w-full px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center justify-between transition cursor-pointer shadow-sm shadow-emerald-600/20">
                        <span class="flex items-center gap-2">
                            <i data-lucide="file-plus-2" class="w-4 h-4"></i>
                            Submit New Medical Claim
                        </span>
                        <i data-lucide="chevron-right" class="w-4 h-4 opacity-70"></i>
                    </button>

                    <button @click="activeTab = 'reports'" class="w-full px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold flex items-center justify-between transition cursor-pointer">
                        <span class="flex items-center gap-2">
                            <i data-lucide="download" class="w-4 h-4"></i>
                            Export Statutory Reports (CSV)
                        </span>
                        <i data-lucide="chevron-right" class="w-4 h-4 opacity-70"></i>
                    </button>
                </div>
            </div>

            <div class="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
                <i data-lucide="shield" class="w-4 h-4 text-emerald-500 shrink-0"></i>
                <span>Tenant isolation strictly verified on all insurance policies.</span>
            </div>
        </div>
    </div>
</div>
