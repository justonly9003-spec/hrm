<!-- Tab: Insurance Claims & Adjudication -->
<div x-show="activeTab === 'claims'" class="space-y-6">
    <!-- Header with Search, Filter & New Claim -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h3 class="text-lg font-bold text-slate-900 dark:text-white">Medical Claims & Reimbursement Requests</h3>
            <p class="text-xs text-slate-400 mt-0.5">Track employee hospitalization, OPD, prescription, and emergency claims from filing to settlement</p>
        </div>
        <div class="flex items-center gap-2">
            <button @click="openClaimModal()" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer shadow-sm shadow-indigo-600/20">
                <i data-lucide="file-plus" class="w-4 h-4"></i>
                <span>Submit Claim</span>
            </button>
        </div>
    </div>

    <!-- Claims Register Table -->
    <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-sm">
        <?php if (empty($claims)): ?>
            <div class="py-16 text-center text-slate-400">
                <i data-lucide="receipt" class="w-10 h-10 mx-auto mb-2 opacity-40"></i>
                <p class="text-sm font-semibold">No medical insurance claims recorded.</p>
                <p class="text-xs mt-1">Submit employee healthcare reimbursement claims or record underwriter settlements.</p>
            </div>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead class="bg-slate-50 dark:bg-slate-800/50 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-100 dark:border-slate-800">
                        <tr>
                            <th class="px-5 py-3.5">Claim # / Date</th>
                            <th class="px-5 py-3.5">Employee / Patient</th>
                            <th class="px-5 py-3.5">Benefit Plan</th>
                            <th class="px-5 py-3.5">Category & Diagnosis</th>
                            <th class="px-5 py-3.5 text-right">Claimed</th>
                            <th class="px-5 py-3.5 text-right">Approved / Paid</th>
                            <th class="px-5 py-3.5 text-center">Status</th>
                            <th class="px-5 py-3.5 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                        <?php foreach ($claims as $cl): ?>
                        <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition">
                            <td class="px-5 py-3.5">
                                <div class="font-mono font-bold text-slate-900 dark:text-white">
                                    <?= esc($cl['claim_number']) ?>
                                </div>
                                <div class="text-[11px] text-slate-400">
                                    Filed: <?= esc($cl['claim_date']) ?>
                                </div>
                            </td>
                            <td class="px-5 py-3.5">
                                <div class="font-bold text-slate-800 dark:text-slate-200">
                                    <?= esc(($cl['first_name'] ?? '') . ' ' . ($cl['last_name'] ?? '')) ?>
                                </div>
                                <div class="text-[10px] text-slate-400">
                                    Patient: <span class="font-medium text-slate-600 dark:text-slate-300"><?= esc($cl['claimant_name'] ?? 'Self') ?></span> (<?= esc($cl['claimant_type'] ?? 'Employee') ?>)
                                </div>
                            </td>
                            <td class="px-5 py-3.5">
                                <div class="font-semibold text-slate-800 dark:text-slate-200"><?= esc($cl['plan_name'] ?? '—') ?></div>
                                <div class="text-[10px] text-slate-400"><?= esc($cl['provider_name'] ?? '') ?></div>
                            </td>
                            <td class="px-5 py-3.5">
                                <span class="inline-block px-2 py-0.5 rounded-md font-semibold text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 mb-0.5">
                                    <?= esc($cl['claim_type'] ?? 'General') ?>
                                </span>
                                <?php if (!empty($cl['diagnosis'])): ?>
                                    <div class="text-[11px] text-slate-500 truncate max-w-xs"><?= esc($cl['diagnosis']) ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="px-5 py-3.5 text-right font-mono text-[11px] font-bold text-slate-900 dark:text-white">
                                <?= esc($currencyCode) ?> <?= number_format($cl['claimed_amount'] ?? 0, 2) ?>
                            </td>
                            <td class="px-5 py-3.5 text-right font-mono text-[11px]">
                                <?php if (($cl['approved_amount'] ?? 0) > 0): ?>
                                    <div class="text-emerald-600 dark:text-emerald-400 font-bold">Appr: <?= esc($currencyCode) ?> <?= number_format($cl['approved_amount'], 2) ?></div>
                                <?php endif; ?>
                                <?php if (($cl['paid_amount'] ?? 0) > 0): ?>
                                    <div class="text-indigo-600 dark:text-indigo-400 font-medium">Paid: <?= esc($currencyCode) ?> <?= number_format($cl['paid_amount'], 2) ?></div>
                                <?php endif; ?>
                                <?php if (empty($cl['approved_amount']) && empty($cl['paid_amount'])): ?>
                                    <span class="text-slate-400">—</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-5 py-3.5 text-center">
                                <?php 
                                    $st = $cl['status'] ?? 'Draft';
                                    $badgeClass = match($st) {
                                        'Draft'        => 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400',
                                        'Submitted'    => 'bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 border border-blue-200/50 dark:border-blue-800/50',
                                        'Under Review' => 'bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400 border border-amber-200/50 dark:border-amber-800/50',
                                        'Approved'     => 'bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 border border-emerald-200/50 dark:border-emerald-800/50',
                                        'Rejected'     => 'bg-rose-50 dark:bg-rose-950 text-rose-600 dark:text-rose-400 border border-rose-200/50 dark:border-rose-800/50',
                                        'Paid'         => 'bg-purple-50 dark:bg-purple-950 text-purple-600 dark:text-purple-400 border border-purple-200/50 dark:border-purple-800/50',
                                        'Cancelled'    => 'bg-slate-100 dark:bg-slate-800 text-slate-500',
                                        default        => 'bg-slate-100 text-slate-600'
                                    };
                                ?>
                                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold <?= $badgeClass ?>">
                                    <?= esc($st) ?>
                                </span>
                            </td>
                            <td class="px-5 py-3.5 text-right space-x-1">
                                <!-- Upload Doc -->
                                <button @click="openUploadDocModal('<?= esc($cl['id']) ?>', '<?= esc($cl['claim_number']) ?>')" class="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition cursor-pointer" title="Upload Supporting Document/Invoice">
                                    <i data-lucide="paperclip" class="w-3.5 h-3.5"></i>
                                </button>
                                
                                <!-- Adjudication transitions -->
                                <?php if ($st === 'Submitted'): ?>
                                    <button @click="openTransitionModal(<?= htmlspecialchars(json_encode($cl), ENT_QUOTES, 'UTF-8') ?>, 'review')" class="px-2 py-1 rounded-lg bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-200/50 text-[10px] font-bold hover:bg-amber-100 transition cursor-pointer">
                                        Review
                                    </button>
                                <?php elseif ($st === 'Under Review'): ?>
                                    <button @click="openTransitionModal(<?= htmlspecialchars(json_encode($cl), ENT_QUOTES, 'UTF-8') ?>, 'approve')" class="px-2 py-1 rounded-lg bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200/50 text-[10px] font-bold hover:bg-emerald-100 transition cursor-pointer">
                                        Approve
                                    </button>
                                    <button @click="openTransitionModal(<?= htmlspecialchars(json_encode($cl), ENT_QUOTES, 'UTF-8') ?>, 'reject')" class="px-2 py-1 rounded-lg bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-200/50 text-[10px] font-bold hover:bg-rose-100 transition cursor-pointer">
                                        Reject
                                    </button>
                                <?php elseif ($st === 'Approved'): ?>
                                    <button @click="openTransitionModal(<?= htmlspecialchars(json_encode($cl), ENT_QUOTES, 'UTF-8') ?>, 'pay')" class="px-2 py-1 rounded-lg bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 border border-purple-200/50 text-[10px] font-bold hover:bg-purple-100 transition cursor-pointer">
                                        Disburse / Pay
                                    </button>
                                <?php endif; ?>

                                <!-- Delete -->
                                <?php if (in_array($st, ['Draft', 'Cancelled', 'Rejected'])): ?>
                                <form method="POST" action="<?= base_url('insurance/claims/delete/' . $cl['id']) ?>" class="inline" onsubmit="return confirm('Delete this claim record?');">
                                    <?= csrf_field() ?>
                                    <button type="submit" class="p-1.5 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/40 text-rose-600 dark:text-rose-400 transition cursor-pointer" title="Delete Claim">
                                        <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                                    </button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
