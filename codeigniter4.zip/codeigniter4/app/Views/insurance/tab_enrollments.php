<!-- Tab: Employee Policy Enrollments -->
<div x-show="activeTab === 'enrollments'" class="space-y-6">
    <!-- Header with Search, Filter & Actions -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h3 class="text-lg font-bold text-slate-900 dark:text-white">Employee Medical Insurance Enrollments</h3>
            <p class="text-xs text-slate-400 mt-0.5">Manage staff policy numbers, member cards, effective coverage dates, and status changes</p>
        </div>
        <div class="flex flex-wrap items-center gap-2">
            <button @click="openEnrollModal()" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer shadow-sm shadow-indigo-600/20">
                <i data-lucide="user-plus" class="w-4 h-4"></i>
                <span>Enroll Staff</span>
            </button>
            <button @click="openBulkEnrollModal()" class="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer">
                <i data-lucide="users-round" class="w-4 h-4"></i>
                <span>Bulk Enroll</span>
            </button>
            <button @click="openAllActiveModal()" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer shadow-sm shadow-emerald-600/20">
                <i data-lucide="sparkles" class="w-4 h-4"></i>
                <span>Assign All Active</span>
            </button>
        </div>
    </div>

    <!-- Enrollments Table -->
    <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-sm">
        <?php if (empty($enrollments)): ?>
            <div class="py-16 text-center text-slate-400">
                <i data-lucide="users" class="w-10 h-10 mx-auto mb-2 opacity-40"></i>
                <p class="text-sm font-semibold">No employee insurance enrollments recorded.</p>
                <p class="text-xs mt-1">Enroll employees individually or execute bulk corporate policy onboarding.</p>
            </div>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead class="bg-slate-50 dark:bg-slate-800/50 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-100 dark:border-slate-800">
                        <tr>
                            <th class="px-5 py-3.5">Employee</th>
                            <th class="px-5 py-3.5">Department</th>
                            <th class="px-5 py-3.5">Plan / Underwriter</th>
                            <th class="px-5 py-3.5">Policy & Member ID</th>
                            <th class="px-5 py-3.5">Effective Period</th>
                            <th class="px-5 py-3.5 text-right">Contribution Split</th>
                            <th class="px-5 py-3.5 text-center">Status</th>
                            <th class="px-5 py-3.5 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                        <?php foreach ($enrollments as $en): ?>
                        <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition">
                            <td class="px-5 py-3.5">
                                <div class="font-bold text-slate-900 dark:text-white">
                                    <?= esc(($en['first_name'] ?? '') . ' ' . ($en['last_name'] ?? '')) ?>
                                </div>
                                <div class="text-[11px] text-slate-400 font-mono">
                                    <?= esc($en['employee_code'] ?? '—') ?>
                                </div>
                            </td>
                            <td class="px-5 py-3.5 text-slate-600 dark:text-slate-300">
                                <?= esc($en['department_name'] ?? '—') ?>
                            </td>
                            <td class="px-5 py-3.5">
                                <div class="font-semibold text-slate-800 dark:text-slate-200"><?= esc($en['plan_name'] ?? '—') ?></div>
                                <div class="text-[10px] text-slate-400"><?= esc($en['provider_name'] ?? '') ?></div>
                            </td>
                            <td class="px-5 py-3.5 font-mono">
                                <div class="text-slate-900 dark:text-white font-medium"><?= esc($en['policy_number'] ?? '—') ?></div>
                                <div class="text-[11px] text-indigo-600 dark:text-indigo-400"><?= esc($en['member_id'] ?? '—') ?></div>
                            </td>
                            <td class="px-5 py-3.5 text-[11px] text-slate-500">
                                <div><?= esc($en['effective_date'] ?? '—') ?></div>
                                <div class="text-slate-400">to <?= esc($en['expiry_date'] ?: 'Open') ?></div>
                            </td>
                            <td class="px-5 py-3.5 text-right font-mono text-[11px]">
                                <div class="text-slate-700 dark:text-slate-300">ER: <?= esc($currencyCode) ?> <?= number_format($en['employer_contribution'] ?? 0, 2) ?></div>
                                <div class="text-slate-500">EE: <?= esc($currencyCode) ?> <?= number_format($en['employee_contribution'] ?? 0, 2) ?></div>
                            </td>
                            <td class="px-5 py-3.5 text-center">
                                <?php 
                                    $st = $en['coverage_status'] ?? 'Active';
                                    $badgeClass = match($st) {
                                        'Active'    => 'bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 border border-emerald-200/50 dark:border-emerald-800/50',
                                        'Pending'   => 'bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400 border border-amber-200/50 dark:border-amber-800/50',
                                        'Suspended' => 'bg-orange-50 dark:bg-orange-950 text-orange-600 dark:text-orange-400 border border-orange-200/50 dark:border-orange-800/50',
                                        'Expired'   => 'bg-slate-100 dark:bg-slate-800 text-slate-500 border border-slate-200/50 dark:border-slate-700/50',
                                        'Cancelled' => 'bg-rose-50 dark:bg-rose-950 text-rose-600 dark:text-rose-400 border border-rose-200/50 dark:border-rose-800/50',
                                        default     => 'bg-slate-100 dark:bg-slate-800 text-slate-600'
                                    };
                                ?>
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold <?= $badgeClass ?>">
                                    <?= esc($st) ?>
                                </span>
                            </td>
                            <td class="px-5 py-3.5 text-right space-x-1">
                                <button @click="viewCoverage('<?= esc($en['employee_id']) ?>')" class="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-indigo-600 dark:text-indigo-400 transition cursor-pointer" title="View 360° Coverage Profile">
                                    <i data-lucide="eye" class="w-3.5 h-3.5"></i>
                                </button>
                                <button @click="openStatusModal(<?= htmlspecialchars(json_encode($en), ENT_QUOTES, 'UTF-8') ?>)" class="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition cursor-pointer" title="Change Coverage Status">
                                    <i data-lucide="sliders" class="w-3.5 h-3.5"></i>
                                </button>
                                <form method="POST" action="<?= base_url('insurance/enrollments/delete/' . $en['id']) ?>" class="inline" onsubmit="return confirm('Are you sure you want to remove this enrollment record?');">
                                    <?= csrf_field() ?>
                                    <button type="submit" class="p-1.5 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/40 text-rose-600 dark:text-rose-400 transition cursor-pointer" title="Delete Enrollment">
                                        <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
