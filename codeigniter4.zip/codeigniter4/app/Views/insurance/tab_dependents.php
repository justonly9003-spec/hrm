<!-- Tab: Covered Dependents & Beneficiaries -->
<div x-show="activeTab === 'dependents'" class="space-y-6">
    <!-- Header with Search, Filter & Add Dependent -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h3 class="text-lg font-bold text-slate-900 dark:text-white">Covered Dependents & Family Members</h3>
            <p class="text-xs text-slate-400 mt-0.5">Manage employee spouses, children, parents, and secondary beneficiaries entitled to healthcare coverage</p>
        </div>
        <div class="flex items-center gap-2">
            <button @click="openDependentModal()" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer shadow-sm shadow-indigo-600/20">
                <i data-lucide="user-plus" class="w-4 h-4"></i>
                <span>Add Dependent</span>
            </button>
        </div>
    </div>

    <!-- Dependents Table -->
    <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-sm">
        <?php if (empty($dependents)): ?>
            <div class="py-16 text-center text-slate-400">
                <i data-lucide="users" class="w-10 h-10 mx-auto mb-2 opacity-40"></i>
                <p class="text-sm font-semibold">No insured family dependents registered.</p>
                <p class="text-xs mt-1">Register spouses, children, or dependents under active employee health policies.</p>
            </div>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead class="bg-slate-50 dark:bg-slate-800/50 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-100 dark:border-slate-800">
                        <tr>
                            <th class="px-5 py-3.5">Dependent Name</th>
                            <th class="px-5 py-3.5">Primary Staff / Member</th>
                            <th class="px-5 py-3.5">Relationship</th>
                            <th class="px-5 py-3.5">Date of Birth & Gender</th>
                            <th class="px-5 py-3.5">National ID / Passport</th>
                            <th class="px-5 py-3.5 text-center">Status</th>
                            <th class="px-5 py-3.5 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                        <?php foreach ($dependents as $dep): ?>
                        <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition">
                            <td class="px-5 py-3.5">
                                <div class="font-bold text-slate-900 dark:text-white">
                                    <?= esc($dep['full_name']) ?>
                                </div>
                                <?php if (!empty($dep['notes'])): ?>
                                    <div class="text-[11px] text-slate-400 truncate max-w-xs"><?= esc($dep['notes']) ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="px-5 py-3.5">
                                <div class="font-semibold text-slate-800 dark:text-slate-200">
                                    <?= esc(($dep['first_name'] ?? '') . ' ' . ($dep['last_name'] ?? '')) ?>
                                </div>
                                <div class="text-[11px] text-slate-400 font-mono">
                                    <?= esc($dep['employee_code'] ?? '—') ?>
                                </div>
                            </td>
                            <td class="px-5 py-3.5">
                                <?php 
                                    $rel = $dep['relationship'] ?? 'Spouse';
                                    $relBadge = match($rel) {
                                        'Spouse' => 'bg-pink-50 text-pink-700 dark:bg-pink-950/60 dark:text-pink-300 border border-pink-200/50 dark:border-pink-800/50',
                                        'Child'  => 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200/50 dark:border-blue-800/50',
                                        'Parent' => 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-200/50 dark:border-amber-800/50',
                                        default  => 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                                    };
                                ?>
                                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold <?= $relBadge ?>">
                                    <?= esc($rel) ?>
                                </span>
                            </td>
                            <td class="px-5 py-3.5 text-slate-600 dark:text-slate-300">
                                <div><?= esc($dep['date_of_birth'] ?? '—') ?></div>
                                <div class="text-[10px] text-slate-400"><?= esc($dep['gender'] ?? '—') ?></div>
                            </td>
                            <td class="px-5 py-3.5 font-mono text-slate-700 dark:text-slate-300">
                                <?= esc($dep['national_id'] ?: '—') ?>
                            </td>
                            <td class="px-5 py-3.5 text-center">
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold <?= ($dep['status'] ?? 'Active') === 'Active' ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 border border-emerald-200/50 dark:border-emerald-800/50' : 'bg-slate-100 dark:bg-slate-800 text-slate-500' ?>">
                                    <?= esc($dep['status'] ?? 'Active') ?>
                                </span>
                            </td>
                            <td class="px-5 py-3.5 text-right space-x-1">
                                <button @click="editDependent(<?= htmlspecialchars(json_encode($dep), ENT_QUOTES, 'UTF-8') ?>)" class="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition cursor-pointer" title="Edit Dependent">
                                    <i data-lucide="pencil" class="w-3.5 h-3.5"></i>
                                </button>
                                <form method="POST" action="<?= base_url('insurance/dependents/delete/' . $dep['id']) ?>" class="inline" onsubmit="return confirm('Remove this dependent from insurance coverage?');">
                                    <?= csrf_field() ?>
                                    <button type="submit" class="p-1.5 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/40 text-rose-600 dark:text-rose-400 transition cursor-pointer" title="Delete Dependent">
                                        <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
