<!-- Tab: Insurance Reports & Statutory Intelligence -->
<div x-show="activeTab === 'reports'" class="space-y-6">
    <!-- Reports Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h3 class="text-lg font-bold text-slate-900 dark:text-white">Insurance Analytics & Operational Reports</h3>
            <p class="text-xs text-slate-400 mt-0.5">Export policy coverage rosters, impending renewal expirations, claims loss ratio analysis, and payroll contribution summaries</p>
        </div>
    </div>

    <!-- Quick Report Tiles -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        <!-- 1. Employee Coverage Roster -->
        <div class="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between hover:border-indigo-500/50 transition">
            <div>
                <div class="w-10 h-10 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mb-3">
                    <i data-lucide="file-spreadsheet" class="w-5 h-5"></i>
                </div>
                <h4 class="text-sm font-bold text-slate-900 dark:text-white">Staff Coverage Roster</h4>
                <p class="text-xs text-slate-400 mt-1">Full registry of active employee policies, member codes, benefit tiers, and effective dates.</p>
            </div>
            <div class="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span class="text-[11px] text-slate-400 font-medium"><?= number_format($stats['active_coverage'] ?? 0) ?> active records</span>
                <a href="<?= base_url('insurance/reports/employees') ?>" target="_blank" class="px-3 py-1.5 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 rounded-xl text-xs font-bold transition flex items-center gap-1">
                    <span>Export</span>
                    <i data-lucide="external-link" class="w-3.5 h-3.5"></i>
                </a>
            </div>
        </div>

        <!-- 2. Expiring Policies -->
        <div class="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between hover:border-amber-500/50 transition">
            <div>
                <div class="w-10 h-10 rounded-2xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center mb-3">
                    <i data-lucide="clock-alert" class="w-5 h-5"></i>
                </div>
                <h4 class="text-sm font-bold text-slate-900 dark:text-white">Expiring Policies (30-90 Days)</h4>
                <p class="text-xs text-slate-400 mt-1">Impending coverage expirations requiring underwriter contract renewal or plan migration.</p>
            </div>
            <div class="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span class="text-[11px] text-amber-600 font-bold"><?= number_format($stats['expiring_coverage'] ?? 0) ?> expiring</span>
                <a href="<?= base_url('insurance/reports/expiring?days=60') ?>" target="_blank" class="px-3 py-1.5 bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 hover:bg-amber-100 rounded-xl text-xs font-bold transition flex items-center gap-1">
                    <span>Export</span>
                    <i data-lucide="external-link" class="w-3.5 h-3.5"></i>
                </a>
            </div>
        </div>

        <!-- 3. Claims Utilization -->
        <div class="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between hover:border-emerald-500/50 transition">
            <div>
                <div class="w-10 h-10 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-3">
                    <i data-lucide="activity" class="w-5 h-5"></i>
                </div>
                <h4 class="text-sm font-bold text-slate-900 dark:text-white">Claims Adjudication Loss Ratio</h4>
                <p class="text-xs text-slate-400 mt-1">Detailed utilization analysis: filed claims, approved amounts, rejected rates, and total payouts.</p>
            </div>
            <div class="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span class="text-[11px] text-emerald-600 font-bold"><?= esc($currencyCode) ?> <?= number_format($stats['total_paid_amount'] ?? 0, 0) ?> paid</span>
                <a href="<?= base_url('insurance/reports/claims') ?>" target="_blank" class="px-3 py-1.5 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100 rounded-xl text-xs font-bold transition flex items-center gap-1">
                    <span>Export</span>
                    <i data-lucide="external-link" class="w-3.5 h-3.5"></i>
                </a>
            </div>
        </div>

        <!-- 4. Contributions Summary -->
        <div class="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between hover:border-purple-500/50 transition">
            <div>
                <div class="w-10 h-10 rounded-2xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center mb-3">
                    <i data-lucide="circle-dollar-sign" class="w-5 h-5"></i>
                </div>
                <h4 class="text-sm font-bold text-slate-900 dark:text-white">Premium Contributions Statement</h4>
                <p class="text-xs text-slate-400 mt-1">Monthly breakdown of employer subsidies versus employee payroll deductions per plan.</p>
            </div>
            <div class="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span class="text-[11px] text-purple-600 font-bold"><?= esc($currencyCode) ?> <?= number_format($stats['total_employer_monthly_premium'] ?? 0, 0) ?>/mo ER</span>
                <a href="<?= base_url('insurance/reports/contributions') ?>" target="_blank" class="px-3 py-1.5 bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 hover:bg-purple-100 rounded-xl text-xs font-bold transition flex items-center gap-1">
                    <span>Export</span>
                    <i data-lucide="external-link" class="w-3.5 h-3.5"></i>
                </a>
            </div>
        </div>
    </div>
</div>
