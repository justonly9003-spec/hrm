<!-- Tab: Insurance Plans Management -->
<div x-show="activeTab === 'plans'" class="space-y-6">
    <!-- Header with Search & Add Plan -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h3 class="text-lg font-bold text-slate-900 dark:text-white">Insurance Plans & Benefit Packages</h3>
            <p class="text-xs text-slate-400 mt-0.5">Manage policy tiers, annual limits, coverage options, and employer/employee premium split ratios</p>
        </div>
        <div class="flex items-center gap-2">
            <button @click="openPlanModal()" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer shadow-sm shadow-indigo-600/20">
                <i data-lucide="plus" class="w-4 h-4"></i>
                <span>Create Plan</span>
            </button>
        </div>
    </div>

    <!-- Plans Cards / Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        <?php if (empty($plans)): ?>
            <div class="col-span-full py-16 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 text-center text-slate-400">
                <i data-lucide="layers" class="w-10 h-10 mx-auto mb-2 opacity-40"></i>
                <p class="text-sm font-semibold">No medical insurance plans configured.</p>
                <p class="text-xs mt-1">Click "Create Plan" above to create standard or executive healthcare benefit tiers.</p>
            </div>
        <?php else: ?>
            <?php foreach ($plans as $pl): ?>
            <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-5 shadow-sm flex flex-col justify-between hover:border-indigo-500/50 transition">
                <div>
                    <!-- Plan Header -->
                    <div class="flex items-start justify-between gap-3 mb-3">
                        <div>
                            <div class="flex items-center gap-2">
                                <span class="px-2 py-0.5 rounded-md font-mono text-[10px] font-bold bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-400 border border-indigo-200/50 dark:border-indigo-800/50">
                                    <?= esc($pl['plan_code']) ?>
                                </span>
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold <?= $pl['status'] === 'Active' ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400' : 'bg-slate-100 dark:bg-slate-800 text-slate-500' ?>">
                                    <?= esc($pl['status']) ?>
                                </span>
                            </div>
                            <h4 class="text-base font-black text-slate-900 dark:text-white mt-1.5"><?= esc($pl['name']) ?></h4>
                            <p class="text-xs text-slate-400">Underwriter: <span class="font-medium text-slate-700 dark:text-slate-300"><?= esc($pl['provider_name'] ?? '—') ?></span></p>
                        </div>
                    </div>

                    <!-- Coverage Limit & Description -->
                    <div class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 mb-4">
                        <div class="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">Annual Coverage Limit</div>
                        <div class="text-lg font-black text-slate-900 dark:text-white font-mono mt-0.5">
                            <?= esc($currencyCode) ?> <?= number_format($pl['annual_coverage_limit'] ?? 0, 2) ?>
                        </div>
                        <?php if (!empty($pl['description'])): ?>
                            <p class="text-[11px] text-slate-500 mt-1 line-clamp-2"><?= esc($pl['description']) ?></p>
                        <?php endif; ?>
                    </div>

                    <!-- Coverage Tags -->
                    <div class="mb-4">
                        <div class="text-[10px] uppercase font-bold text-slate-400 mb-1.5 tracking-wider">Benefits Included</div>
                        <div class="flex flex-wrap gap-1.5">
                            <?php if (!empty($pl['hospitalization_coverage'])): ?>
                                <span class="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200/50 dark:border-emerald-800/50 flex items-center gap-1">
                                    <i data-lucide="check" class="w-3 h-3"></i> Hospitalization
                                </span>
                            <?php endif; ?>
                            <?php if (!empty($pl['opd_coverage'])): ?>
                                <span class="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200/50 dark:border-emerald-800/50 flex items-center gap-1">
                                    <i data-lucide="check" class="w-3 h-3"></i> OPD
                                </span>
                            <?php endif; ?>
                            <?php if (!empty($pl['emergency_coverage'])): ?>
                                <span class="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200/50 dark:border-emerald-800/50 flex items-center gap-1">
                                    <i data-lucide="check" class="w-3 h-3"></i> Emergency
                                </span>
                            <?php endif; ?>
                            <?php if (!empty($pl['maternity_coverage'])): ?>
                                <span class="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border border-purple-200/50 dark:border-purple-800/50 flex items-center gap-1">
                                    <i data-lucide="check" class="w-3 h-3"></i> Maternity
                                </span>
                            <?php endif; ?>
                            <?php if (!empty($pl['dental_coverage'])): ?>
                                <span class="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 border border-sky-200/50 dark:border-sky-800/50 flex items-center gap-1">
                                    <i data-lucide="check" class="w-3 h-3"></i> Dental
                                </span>
                            <?php endif; ?>
                            <?php if (!empty($pl['vision_coverage'])): ?>
                                <span class="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200/50 dark:border-amber-800/50 flex items-center gap-1">
                                    <i data-lucide="check" class="w-3 h-3"></i> Vision
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Contribution Split -->
                    <div class="grid grid-cols-2 gap-2 text-xs mb-3 py-2 px-3 rounded-xl bg-slate-50 dark:bg-slate-800/30">
                        <div>
                            <span class="text-[10px] text-slate-400">Employer Share</span>
                            <div class="font-bold text-slate-800 dark:text-slate-200">
                                <?= $pl['employer_contribution_type'] === 'percentage' ? esc($pl['employer_contribution_value']) . '%' : esc($currencyCode) . ' ' . number_format($pl['employer_contribution_value'], 2) ?>
                            </div>
                        </div>
                        <div>
                            <span class="text-[10px] text-slate-400">Employee Share</span>
                            <div class="font-bold text-slate-800 dark:text-slate-200">
                                <?= $pl['employee_contribution_type'] === 'percentage' ? esc($pl['employee_contribution_value']) . '%' : esc($currencyCode) . ' ' . number_format($pl['employee_contribution_value'], 2) ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Footer & Actions -->
                <div class="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <span class="text-[11px] text-slate-400">
                        <?= (int)($pl['enrolled_count'] ?? 0) ?> enrolled
                    </span>
                    <div class="flex items-center gap-1">
                        <button @click="editPlan(<?= htmlspecialchars(json_encode($pl), ENT_QUOTES, 'UTF-8') ?>)" class="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition cursor-pointer" title="Edit Plan">
                            <i data-lucide="pencil" class="w-3.5 h-3.5"></i>
                        </button>
                        <form method="POST" action="<?= base_url('insurance/plans/delete/' . $pl['id']) ?>" class="inline" onsubmit="return confirm('Are you sure you want to delete this plan?');">
                            <?= csrf_field() ?>
                            <button type="submit" class="p-1.5 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/40 text-rose-600 dark:text-rose-400 transition cursor-pointer" title="Delete Plan">
                                <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
