<div class="space-y-6">
    <!-- Header & Breadcrumbs -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
        <div>
            <div class="flex items-center gap-2.5">
                <div class="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60 flex items-center justify-center shadow-xs">
                    <i data-lucide="palette" class="w-5 h-5"></i>
                </div>
                <div>
                    <h1 class="text-xl font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
                        System Administration & Branding Configuration
                    </h1>
                    <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                        Three completely independent branding configurations: Application Logo, Report Header, and Report Footer.
                    </p>
                </div>
            </div>
        </div>

        <div class="flex items-center gap-3 flex-wrap">
            <?php if (!empty($isAppAdmin) && !empty($allCompanies) && count($allCompanies) > 1): ?>
                <div class="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1.5 rounded-xl border border-slate-200 dark:border-slate-700">
                    <i data-lucide="building-2" class="w-4 h-4 text-slate-500 ml-1"></i>
                    <select onchange="window.location.href='<?= base_url('company/branding') ?>?company_id=' + this.value" class="text-xs font-bold bg-transparent text-slate-800 dark:text-slate-200 focus:outline-hidden pr-2 cursor-pointer">
                        <?php foreach ($allCompanies as $comp): ?>
                            <option value="<?= esc($comp['id']) ?>" <?= ($comp['id'] === ($currentCompId ?? $company['id'])) ? 'selected' : '' ?> class="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200">
                                <?= esc($comp['name']) ?> (<?= esc($comp['code']) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            <?php endif; ?>

            <a href="<?= base_url('reports/upload') ?>" class="px-3.5 py-2 text-xs font-semibold rounded-xl bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900 text-indigo-700 dark:text-indigo-300 transition flex items-center gap-1.5 cursor-pointer border border-indigo-200/60 dark:border-indigo-800/60">
                <i data-lucide="upload-cloud" class="w-4 h-4 text-indigo-600"></i>
                <span>Report & Document Center</span>
            </a>
            <a href="<?= base_url('reports') ?>" class="px-3.5 py-2 text-xs font-semibold rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition flex items-center gap-1.5 cursor-pointer">
                <i data-lucide="file-spreadsheet" class="w-4 h-4"></i>
                <span>Report Generator</span>
            </a>
        </div>
    </div>

    <!-- Feedback Alerts -->
    <?php if (!empty($success)): ?>
        <div class="p-4 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 rounded-2xl text-xs flex items-center gap-3">
            <i data-lucide="check-circle-2" class="w-4 h-4 text-emerald-600 shrink-0"></i>
            <span><?= esc($success) ?></span>
        </div>
    <?php endif; ?>

    <?php if (!empty($error)): ?>
        <div class="p-4 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200 rounded-2xl text-xs flex items-center gap-3">
            <i data-lucide="alert-circle" class="w-4 h-4 text-rose-600 shrink-0"></i>
            <span><?= esc($error) ?></span>
        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Configuration Columns (5 cols) -->
        <div class="lg:col-span-5 space-y-6">

            <!-- 1. APPLICATION LOGO CONFIGURATION BLOCK -->
            <div class="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
                <div class="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                    <div class="flex items-center gap-2">
                        <div class="w-7 h-7 rounded-lg bg-indigo-50 dark:bg-indigo-950/80 text-indigo-600 flex items-center justify-center font-bold text-xs">
                            1
                        </div>
                        <div>
                            <h2 class="text-sm font-bold text-slate-900 dark:text-white">
                                Application / Company Logo
                            </h2>
                            <p class="text-[10px] text-slate-400">
                                Sidebar, navbar, dashboard header, and login screen
                            </p>
                        </div>
                    </div>
                    <span class="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                        UI Scope
                    </span>
                </div>

                <form action="<?= base_url('company/branding') ?>" method="post" enctype="multipart/form-data" class="space-y-4">
                    <?= csrf_field() ?>
                    <input type="hidden" name="company_id" value="<?= esc($company['id'] ?? '') ?>" />
                    <input type="hidden" name="section_action" value="logo" />

                    <!-- Current Logo Preview Card -->
                    <div class="flex items-center gap-4 p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700/60">
                        <div class="w-14 h-14 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-1 flex items-center justify-center shrink-0 overflow-hidden relative">
                            <?php 
                                $rawLogo = $company['logo'] ?? '';
                                $hasLogo = !empty($rawLogo) && strlen($rawLogo) > 5; 
                                $resolvedFormLogo = $rawLogo;
                                if ($hasLogo && !str_starts_with($rawLogo, 'http://') && !str_starts_with($rawLogo, 'https://') && !str_starts_with($rawLogo, 'data:')) {
                                    $resolvedFormLogo = base_url(ltrim($rawLogo, '/'));
                                }
                            ?>
                            <img id="formLogoThumbnail" 
                                 src="<?= esc($resolvedFormLogo) ?>" 
                                 alt="Company Logo" 
                                 class="max-h-full max-w-full object-contain <?= $hasLogo ? '' : 'hidden' ?>" 
                                 onerror="this.classList.add('hidden'); document.getElementById('formLogoFallbackIcon')?.classList.remove('hidden');" 
                                 onload="this.classList.remove('hidden'); document.getElementById('formLogoFallbackIcon')?.classList.add('hidden');" />
                            <i id="formLogoFallbackIcon" data-lucide="building-2" class="w-5 h-5 text-slate-400 <?= $hasLogo ? 'hidden' : '' ?>"></i>
                        </div>

                        <div class="flex-1 space-y-1">
                            <p class="text-xs font-bold text-slate-800 dark:text-slate-200">
                                <?= $hasLogo ? 'Custom Application Logo' : 'Standard Icon Emblem' ?>
                            </p>
                            <p class="text-[10px] text-slate-400 leading-tight">
                                Independent branding. This logo is NOT used as Report Header image or Footer image.
                            </p>
                        </div>
                    </div>

                    <!-- Upload and URL inputs -->
                    <div class="space-y-2">
                        <input type="text" id="brandingLogoInput" name="logo" value="<?= esc($company['logo'] ?? '') ?>" oninput="updateBrandPreview()" placeholder="Direct Logo URL (https://...)" class="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2 text-slate-900 dark:text-white placeholder-slate-400 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden" />

                        <div class="flex items-center gap-2 flex-wrap pt-1">
                            <label class="px-3 py-1.5 text-xs font-bold text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/80 hover:bg-indigo-100 rounded-xl transition inline-flex items-center gap-1.5 cursor-pointer border border-indigo-200 dark:border-indigo-800">
                                <i data-lucide="upload-cloud" class="w-3.5 h-3.5"></i>
                                <span>Upload Logo</span>
                                <input type="file" id="logoFileInput" name="logo_file" accept="image/*" class="hidden" />
                            </label>

                            <button type="button" onclick="loadPresetLogo('https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=240&auto=format&fit=crop&q=80')" class="text-[11px] font-semibold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 cursor-pointer">
                                Load Sample
                            </button>

                            <button type="button" onclick="loadPresetLogo('')" class="text-[11px] font-semibold text-rose-500 hover:underline ml-auto cursor-pointer flex items-center gap-1">
                                <i data-lucide="trash-2" class="w-3 h-3"></i>
                                <span>Remove Logo</span>
                            </button>
                        </div>
                    </div>

                    <button type="submit" class="w-full py-2 text-xs font-bold text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/50 hover:bg-indigo-100 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer border border-indigo-200/80 dark:border-indigo-800">
                        <i data-lucide="check" class="w-3.5 h-3.5"></i>
                        <span>Save Logo Settings</span>
                    </button>
                </form>
            </div>

            <!-- 1B. COMPANY THEME & NAVIGATION LAYOUT BLOCK -->
            <div class="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
                <div class="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                    <div class="flex items-center gap-2">
                        <div class="w-7 h-7 rounded-lg bg-purple-50 dark:bg-purple-950/80 text-purple-600 flex items-center justify-center font-bold text-xs">
                            <i data-lucide="palette" class="w-4 h-4"></i>
                        </div>
                        <div>
                            <h2 class="text-sm font-bold text-slate-900 dark:text-white">
                                Company Theme & Navigation Layout
                            </h2>
                            <p class="text-[10px] text-slate-400">
                                Corporate color identity, brand accents, and workspace navigation mode
                            </p>
                        </div>
                    </div>
                    <span class="text-[10px] font-mono px-2 py-0.5 rounded-full bg-purple-50 dark:bg-purple-950/80 text-purple-700 dark:text-purple-300">
                        Theme & Layout
                    </span>
                </div>

                <form action="<?= base_url('company/branding') ?>" method="post" class="space-y-4">
                    <?= csrf_field() ?>
                    <input type="hidden" name="company_id" value="<?= esc($company['id'] ?? '') ?>" />
                    <input type="hidden" name="section_action" value="theme_layout" />

                    <!-- Theme Archetype Selector -->
                    <div>
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                            Corporate Theme Palette (Preset Archetypes)
                        </label>
                        <?php 
                            $currentThemeCode = strtolower($company['theme_code'] ?? 'indigo');
                            $themeOptions = [
                                'indigo'   => ['name' => 'Indigo', 'hex' => '#4338ca'],
                                'emerald'  => ['name' => 'Emerald', 'hex' => '#059669'],
                                'sapphire' => ['name' => 'Sapphire', 'hex' => '#0284c7'],
                                'purple'   => ['name' => 'Purple', 'hex' => '#7c3aed'],
                                'amber'    => ['name' => 'Amber', 'hex' => '#d97706'],
                                'rose'     => ['name' => 'Rose', 'hex' => '#e11d48'],
                                'teal'     => ['name' => 'Teal', 'hex' => '#0d9488'],
                                'crimson'  => ['name' => 'Crimson', 'hex' => '#dc2626'],
                                'cyan'     => ['name' => 'Cyan', 'hex' => '#0891b2'],
                                'slate'    => ['name' => 'Slate', 'hex' => '#334155'],
                            ];
                        ?>
                        <input type="hidden" name="theme_code" id="companyThemeInput" value="<?= esc($currentThemeCode) ?>" />
                        
                        <div class="grid grid-cols-5 gap-2">
                            <?php foreach ($themeOptions as $tId => $tData): ?>
                                <button type="button" 
                                        onclick="selectCompanyTheme('<?= $tId ?>', '<?= $tData['hex'] ?>')" 
                                        id="theme-choice-<?= $tId ?>"
                                        class="p-2 rounded-xl border flex flex-col items-center gap-1.5 transition text-center cursor-pointer <?= ($currentThemeCode === $tId) ? 'border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/40 ring-2 ring-indigo-500/20' : 'border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800' ?>">
                                    <span class="w-6 h-6 rounded-lg shadow-xs" style="background-color: <?= $tData['hex'] ?>;"></span>
                                    <span class="text-[10px] font-bold text-slate-700 dark:text-slate-300 truncate max-w-full"><?= esc($tData['name']) ?></span>
                                </button>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Custom Primary Color Hex -->
                    <div>
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                            Brand Primary Hex Color
                        </label>
                        <div class="flex items-center gap-3">
                            <input type="color" 
                                   id="companyColorPicker" 
                                   value="<?= esc($company['primary_color'] ?? '#4f46e5') ?>" 
                                   onchange="document.getElementById('companyPrimaryColorInput').value = this.value; if(window.applyTheme) window.applyTheme(document.getElementById('companyThemeInput').value);" 
                                   class="w-10 h-10 rounded-xl cursor-pointer border border-slate-200 dark:border-slate-700 bg-transparent p-0.5" />
                            <input type="text" 
                                   name="primary_color" 
                                   id="companyPrimaryColorInput" 
                                   value="<?= esc($company['primary_color'] ?? '#4f46e5') ?>" 
                                   oninput="document.getElementById('companyColorPicker').value = this.value;" 
                                   placeholder="#4f46e5" 
                                   class="flex-1 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2 text-slate-900 dark:text-white font-mono focus:ring-2 focus:ring-indigo-500 focus:outline-hidden" />
                        </div>
                    </div>

                    <!-- Navigation Layout Preference -->
                    <div>
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                            Workspace Navigation Layout
                        </label>
                        <?php $currentLayout = strtolower($company['nav_layout'] ?? 'sidebar'); ?>
                        <div class="grid grid-cols-2 gap-3">
                            <label class="p-3 rounded-xl border flex items-center gap-3 cursor-pointer transition <?= ($currentLayout === 'sidebar') ? 'border-indigo-600 bg-indigo-50/40 dark:bg-indigo-950/30' : 'border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800' ?>">
                                <input type="radio" name="nav_layout" value="sidebar" <?= ($currentLayout === 'sidebar') ? 'checked' : '' ?> onchange="if(window.setNavLayout) window.setNavLayout('sidebar')" class="text-indigo-600 focus:ring-indigo-500" />
                                <div>
                                    <p class="text-xs font-bold text-slate-800 dark:text-slate-200">Classic Sidebar</p>
                                    <p class="text-[10px] text-slate-400">Vertical left column</p>
                                </div>
                            </label>
                            <label class="p-3 rounded-xl border flex items-center gap-3 cursor-pointer transition <?= ($currentLayout === 'topbar') ? 'border-indigo-600 bg-indigo-50/40 dark:bg-indigo-950/30' : 'border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800' ?>">
                                <input type="radio" name="nav_layout" value="topbar" <?= ($currentLayout === 'topbar') ? 'checked' : '' ?> onchange="if(window.setNavLayout) window.setNavLayout('topbar')" class="text-indigo-600 focus:ring-indigo-500" />
                                <div>
                                    <p class="text-xs font-bold text-slate-800 dark:text-slate-200">Modern Topbar</p>
                                    <p class="text-[10px] text-slate-400">Horizontal tabs bar</p>
                                </div>
                            </label>
                        </div>
                    </div>

                    <button type="submit" class="w-full py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition flex items-center justify-center gap-2 cursor-pointer shadow-sm shadow-indigo-500/20">
                        <i data-lucide="check" class="w-4 h-4"></i>
                        <span>Save Theme & Layout Settings</span>
                    </button>
                </form>
            </div>

            <!-- 2. REPORT HEADER CONFIGURATION BLOCK -->
            <div class="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
                <div class="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                    <div class="flex items-center gap-2">
                        <div class="w-7 h-7 rounded-lg bg-emerald-50 dark:bg-emerald-950/80 text-emerald-600 flex items-center justify-center font-bold text-xs">
                            2
                        </div>
                        <div>
                            <h2 class="text-sm font-bold text-slate-900 dark:text-white">
                                Report Header Configuration
                            </h2>
                            <p class="text-[10px] text-slate-400">
                                Printable reports, PDF exports, and data statements
                            </p>
                        </div>
                    </div>
                    <span class="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300">
                        Report Scope
                    </span>
                </div>

                <form action="<?= base_url('company/branding') ?>" method="post" enctype="multipart/form-data" class="space-y-4">
                    <?= csrf_field() ?>
                    <input type="hidden" name="company_id" value="<?= esc($company['id'] ?? '') ?>" />
                    <input type="hidden" name="section_action" value="header" />

                    <!-- Current Header Image Preview Card -->
                    <div class="flex items-center gap-4 p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700/60">
                        <div class="w-20 h-14 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-1 flex items-center justify-center shrink-0 overflow-hidden relative">
                            <?php $hasHeaderImg = !empty($company['report_header_image']) && strlen($company['report_header_image']) > 15; ?>
                            <img id="formHeaderThumbnail" 
                                 src="<?= esc($company['report_header_image'] ?? '') ?>" 
                                 alt="Header Image" 
                                 class="max-h-full max-w-full object-contain <?= $hasHeaderImg ? '' : 'hidden' ?>" 
                                 onerror="this.classList.add('hidden'); document.getElementById('formHeaderFallbackIcon')?.classList.remove('hidden');" 
                                 onload="this.classList.remove('hidden'); document.getElementById('formHeaderFallbackIcon')?.classList.add('hidden');" />
                            <i id="formHeaderFallbackIcon" data-lucide="file-text" class="w-5 h-5 text-slate-400 <?= $hasHeaderImg ? 'hidden' : '' ?>"></i>
                        </div>

                        <div class="flex-1 space-y-1">
                            <p class="text-xs font-bold text-slate-800 dark:text-slate-200">
                                <?= $hasHeaderImg ? 'Custom Header Image Active' : 'Text-Only Layout (0px Space)' ?>
                            </p>
                            <p class="text-[10px] text-slate-400 leading-tight">
                                Optional Image Rule: If missing, text starts immediately at the top with zero empty space.
                            </p>
                        </div>
                    </div>

                    <!-- Upload and URL inputs -->
                    <div class="space-y-2">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">
                            Header Image / Custom Emblem
                        </label>
                        <input type="text" id="reportHeaderImageInput" name="report_header_image" value="<?= esc($company['report_header_image'] ?? '') ?>" oninput="updateBrandPreview()" placeholder="Custom header image URL (or leave blank for text-only)..." class="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2 text-slate-900 dark:text-white placeholder-slate-400 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden" />

                        <div class="flex items-center gap-2 flex-wrap pt-1">
                            <label class="px-3 py-1.5 text-xs font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/80 hover:bg-emerald-100 rounded-xl transition inline-flex items-center gap-1.5 cursor-pointer border border-emerald-200 dark:border-emerald-800">
                                <i data-lucide="upload-cloud" class="w-3.5 h-3.5"></i>
                                <span>Upload Header Img</span>
                                <input type="file" id="headerFileInput" name="report_header_file" accept="image/*" class="hidden" />
                            </label>

                            <button type="button" onclick="loadPresetHeaderImg('https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=240&auto=format&fit=crop&q=80')" class="text-[11px] font-semibold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 cursor-pointer">
                                Load Sample
                            </button>

                            <button type="button" onclick="loadPresetHeaderImg('')" class="text-[11px] font-semibold text-rose-500 hover:underline ml-auto cursor-pointer flex items-center gap-1">
                                <i data-lucide="trash-2" class="w-3 h-3"></i>
                                <span>Remove Image</span>
                            </button>
                        </div>
                    </div>

                    <!-- Header Text -->
                    <div>
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                            Report Header Text / Subtitle (Optional)
                        </label>
                        <input type="text" name="report_header_text" id="reportHeaderTextInput" value="<?= esc($company['report_header_text'] ?? '') ?>" oninput="updateBrandPreview()" placeholder="E.g. Government Approved Statutory Register / ISO 9001:2015" class="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden" />
                    </div>

                    <button type="submit" class="w-full py-2 text-xs font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/50 hover:bg-emerald-100 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer border border-emerald-200/80 dark:border-emerald-800">
                        <i data-lucide="check" class="w-3.5 h-3.5"></i>
                        <span>Save Header Settings</span>
                    </button>
                </form>
            </div>

            <!-- 3. REPORT FOOTER CONFIGURATION BLOCK -->
            <div class="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
                <div class="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                    <div class="flex items-center gap-2">
                        <div class="w-7 h-7 rounded-lg bg-amber-50 dark:bg-amber-950/80 text-amber-600 flex items-center justify-center font-bold text-xs">
                            3
                        </div>
                        <div>
                            <h2 class="text-sm font-bold text-slate-900 dark:text-white">
                                Report Footer Configuration
                            </h2>
                            <p class="text-[10px] text-slate-400">
                                Footer graphic banner, legal disclaimer, and pagination
                            </p>
                        </div>
                    </div>
                    <span class="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-50 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300">
                        Footer Scope
                    </span>
                </div>

                <form action="<?= base_url('company/branding') ?>" method="post" enctype="multipart/form-data" class="space-y-4">
                    <?= csrf_field() ?>
                    <input type="hidden" name="company_id" value="<?= esc($company['id'] ?? '') ?>" />
                    <input type="hidden" name="section_action" value="footer" />

                    <!-- Current Footer Image Preview Card -->
                    <div class="flex items-center gap-4 p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700/60">
                        <div class="w-24 h-10 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-1 flex items-center justify-center shrink-0 overflow-hidden relative">
                            <?php $hasFooterImg = !empty($company['report_footer_image']) && strlen($company['report_footer_image']) > 15; ?>
                            <img id="formFooterThumbnail" 
                                 src="<?= esc($company['report_footer_image'] ?? '') ?>" 
                                 alt="Footer Image" 
                                 class="max-h-full max-w-full object-contain <?= $hasFooterImg ? '' : 'hidden' ?>" 
                                 onerror="this.classList.add('hidden'); document.getElementById('formFooterFallbackIcon')?.classList.remove('hidden');" 
                                 onload="this.classList.remove('hidden'); document.getElementById('formFooterFallbackIcon')?.classList.add('hidden');" />
                            <i id="formFooterFallbackIcon" data-lucide="image" class="w-5 h-5 text-slate-400 <?= $hasFooterImg ? 'hidden' : '' ?>"></i>
                        </div>

                        <div class="flex-1 space-y-1">
                            <p class="text-xs font-bold text-slate-800 dark:text-slate-200">
                                <?= $hasFooterImg ? 'Custom Footer Banner Active' : 'Text-Only Footer (0px Space)' ?>
                            </p>
                            <p class="text-[10px] text-slate-400 leading-tight">
                                Optional Image Rule: If missing, disclaimer and pagination render with zero blank space.
                            </p>
                        </div>
                    </div>

                    <!-- Upload and URL inputs -->
                    <div class="space-y-2">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">
                            Footer Banner Graphic (Optional)
                        </label>
                        <input type="text" id="reportFooterImageInput" name="report_footer_image" value="<?= esc($company['report_footer_image'] ?? '') ?>" oninput="updateBrandPreview()" placeholder="Footer Graphic URL (https://...)" class="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2 text-slate-900 dark:text-white placeholder-slate-400 focus:ring-2 focus:ring-amber-500 focus:outline-hidden" />

                        <div class="flex items-center gap-2 flex-wrap pt-1">
                            <label class="px-3 py-1.5 text-xs font-bold text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/80 hover:bg-amber-100 rounded-xl transition inline-flex items-center gap-1.5 cursor-pointer border border-amber-200 dark:border-amber-800">
                                <i data-lucide="upload-cloud" class="w-3.5 h-3.5"></i>
                                <span>Upload Footer Img</span>
                                <input type="file" id="footerFileInput" name="report_footer_file" accept="image/*" class="hidden" />
                            </label>

                            <button type="button" onclick="loadPresetFooterImg('https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=600&auto=format&fit=crop&q=80')" class="text-[11px] font-semibold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 cursor-pointer">
                                Load Sample
                            </button>

                            <button type="button" onclick="loadPresetFooterImg('')" class="text-[11px] font-semibold text-rose-500 hover:underline ml-auto cursor-pointer flex items-center gap-1">
                                <i data-lucide="trash-2" class="w-3 h-3"></i>
                                <span>Remove Image</span>
                            </button>
                        </div>
                    </div>

                    <!-- Footer Disclaimer Text -->
                    <div>
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                            Footer Disclaimer / Legal Notice
                        </label>
                        <textarea name="report_footer_text" id="reportFooterTextInput" oninput="updateBrandPreview()" rows="2" class="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500 focus:outline-hidden"><?= esc($company['report_footer_text'] ?? 'This is an official system-generated document from Enterprise HRMS Analytics Hub. Confidential.') ?></textarea>
                    </div>

                    <button type="submit" class="w-full py-2 text-xs font-bold text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/50 hover:bg-amber-100 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer border border-amber-200/80 dark:border-amber-800">
                        <i data-lucide="check" class="w-3.5 h-3.5"></i>
                        <span>Save Footer Settings</span>
                    </button>
                </form>
            </div>

            <!-- COMPANY METADATA & GLOBAL SAVE -->
            <form action="<?= base_url('company/branding') ?>" method="post" class="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
                <?= csrf_field() ?>
                <input type="hidden" name="company_id" value="<?= esc($company['id'] ?? '') ?>" />
                <input type="hidden" name="section_action" value="metadata" />

                <h3 class="text-sm font-bold text-slate-900 dark:text-white pb-2 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2">
                    <i data-lucide="building-2" class="w-4 h-4 text-indigo-600"></i>
                    <span>Company Profile & Contact Information</span>
                </h3>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Company Name</label>
                        <input type="text" name="name" id="companyNameInput" oninput="updateBrandPreview()" required value="<?= esc($company['name'] ?? 'Apex Global Technologies Ltd.') ?>" class="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden" />
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Company Code</label>
                        <input type="text" name="code" required value="<?= esc($company['code'] ?? 'APEX') ?>" class="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-white uppercase focus:ring-2 focus:ring-indigo-500 focus:outline-hidden" />
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Official Email</label>
                        <input type="email" name="email" id="companyEmailInput" oninput="updateBrandPreview()" value="<?= esc($company['email'] ?? 'contact@apex-corp.internal') ?>" class="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden" />
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Official Phone</label>
                        <input type="text" name="phone" id="companyPhoneInput" oninput="updateBrandPreview()" value="<?= esc($company['phone'] ?? '+1 (555) 019-2834') ?>" class="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden" />
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Headquarters Address</label>
                    <input type="text" name="address" id="companyAddressInput" oninput="updateBrandPreview()" value="<?= esc($company['address'] ?? '100 Wall Street, Financial District, New York, NY 10005') ?>" class="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden" />
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Website URL</label>
                    <input type="text" name="website" id="companyWebsiteInput" oninput="updateBrandPreview()" value="<?= esc($company['website'] ?? 'www.apex-corp.internal') ?>" class="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden" />
                </div>

                <button type="submit" class="w-full py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs shadow-indigo-600/20 flex items-center justify-center gap-2 transition cursor-pointer">
                    <i data-lucide="check" class="w-4 h-4"></i>
                    <span>Save Company Information</span>
                </button>
            </form>

        </div>

        <!-- Live Printable A4 Page Preview (7 cols) -->
        <div class="lg:col-span-7 space-y-6">

            <!-- 1. Sidebar Brand Header Simulation -->
            <div class="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
                <h3 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3 flex items-center gap-2">
                    <i data-lucide="layout" class="w-4 h-4 text-indigo-600"></i>
                    <span>Application Logo Live Simulation (Sidebar & UI)</span>
                </h3>

                <div class="p-4 bg-slate-100 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between flex-wrap gap-3">
                    <div class="w-64 bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center gap-3 shadow-xs">
                        <div class="w-9 h-9 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-0.5 flex items-center justify-center shrink-0 overflow-hidden">
                            <img id="sidebarLogoImg" 
                                 src="<?= esc($resolvedFormLogo) ?>" 
                                 alt="Logo" 
                                 class="max-h-full max-w-full object-contain <?= $hasLogo ? '' : 'hidden' ?>" 
                                 onerror="this.classList.add('hidden'); document.getElementById('sidebarLogoFallbackIcon')?.classList.remove('hidden');" 
                                 onload="this.classList.remove('hidden'); document.getElementById('sidebarLogoFallbackIcon')?.classList.add('hidden');" />
                            <i id="sidebarLogoFallbackIcon" data-lucide="building-2" class="w-5 h-5 text-indigo-600 <?= $hasLogo ? 'hidden' : '' ?>"></i>
                        </div>

                        <div class="flex flex-col min-w-0">
                            <span id="sidebarCompanyName" class="font-sans font-extrabold tracking-tight text-xs leading-tight truncate text-slate-900 dark:text-white">
                                <?= esc($company['name'] ?? 'Enterprise HRMS') ?>
                            </span>
                            <span class="text-[10px] text-indigo-600 dark:text-indigo-400 font-bold uppercase tracking-wider mt-0.5 flex items-center gap-1">
                                <i data-lucide="sparkles" class="w-2.5 h-2.5"></i> Pro Workspace
                            </span>
                        </div>
                    </div>

                    <div class="text-right">
                        <span id="sidebarLogoStatusText" class="text-xs font-semibold text-slate-600 dark:text-slate-300 block">
                            <?= !empty($company['logo']) ? '✓ Custom Logo Active' : '✓ Default Icon Active' ?>
                        </span>
                        <span class="text-[10px] text-slate-400">
                            App navbar & login screen
                        </span>
                    </div>
                </div>
            </div>

            <!-- 2. Live Printable A4 Page Preview (Optional Image Rule) -->
            <div class="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
                <div class="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 mb-4 flex-wrap gap-2">
                    <div>
                        <h3 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
                            <i data-lucide="eye" class="w-4 h-4 text-indigo-600"></i>
                            <span>Printable Report Simulation (Optional Image Rule)</span>
                        </h3>
                        <p class="text-[10px] text-slate-400 mt-0.5">
                            Zero blank space when images are absent. Report Header ≠ Logo.
                        </p>
                    </div>

                    <div class="flex items-center gap-2">
                        <span id="previewHeaderStatus" class="text-[10px] font-bold px-2 py-0.5 rounded-full <?= !empty($company['report_header_image']) ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400' ?> font-mono">
                            HEADER: <?= !empty($company['report_header_image']) ? 'IMAGE' : 'TEXT-ONLY (0px)' ?>
                        </span>
                        <span id="previewFooterStatus" class="text-[10px] font-bold px-2 py-0.5 rounded-full <?= !empty($company['report_footer_image']) ? 'bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300' : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400' ?> font-mono">
                            FOOTER: <?= !empty($company['report_footer_image']) ? 'IMAGE' : 'TEXT-ONLY (0px)' ?>
                        </span>
                    </div>
                </div>

                <!-- A4 Simulated Canvas -->
                <div class="bg-slate-100 dark:bg-slate-950 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-inner">
                    <div class="bg-white dark:bg-slate-900 p-8 rounded-lg shadow-sm border border-slate-200 dark:border-slate-800 max-w-2xl mx-auto space-y-6" id="simulatedA4Sheet">
                        
                        <!-- Dynamic Report Header: strictly uses report_header_image (NOT logo) -->
                        <?= view('reports/partials/report_header', [
                            'company'           => $company,
                            'reportHeaderImage' => $company['report_header_image'] ?? null,
                            'reportHeaderText'  => $company['report_header_text'] ?? null,
                            'reportTitle'       => 'OFFICIAL HRMS EXECUTIVE SALARY & ATTENDANCE AUDIT REGISTER',
                            'reportPeriod'      => 'July 01, 2026 to July 31, 2026'
                        ]) ?>

                        <!-- Mock Report Register Table -->
                        <div class="border border-slate-200 dark:border-slate-800 rounded-md overflow-hidden text-[10px]">
                            <table class="w-full text-left">
                                <thead class="bg-slate-100 dark:bg-slate-800 font-bold">
                                    <tr>
                                        <th class="p-1.5">EMP ID</th>
                                        <th class="p-1.5">NAME</th>
                                        <th class="p-1.5">DEPT</th>
                                        <th class="p-1.5">PRESENT</th>
                                        <th class="p-1.5">NET SALARY</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                                    <tr>
                                        <td class="p-1.5 font-mono">EMP-001</td>
                                        <td class="p-1.5 font-bold">Rahim Ahmed</td>
                                        <td class="p-1.5">Engineering</td>
                                        <td class="p-1.5">26 Days</td>
                                        <td class="p-1.5 font-mono font-bold"><?= esc($company['currency_symbol'] ?? '$') ?> 65,000</td>
                                    </tr>
                                    <tr>
                                        <td class="p-1.5 font-mono">EMP-002</td>
                                        <td class="p-1.5 font-bold">Sadia Islam</td>
                                        <td class="p-1.5">HR & Operations</td>
                                        <td class="p-1.5">25 Days</td>
                                        <td class="p-1.5 font-mono font-bold"><?= esc($company['currency_symbol'] ?? '$') ?> 48,000</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <!-- Dynamic Report Footer: strictly uses report_footer_image -->
                        <?= view('reports/partials/report_footer', [
                            'company'           => $company,
                            'reportFooterImage' => $company['report_footer_image'] ?? null,
                            'reportFooterText'  => $company['report_footer_text'] ?? 'This is an official system-generated document from Enterprise HRMS Analytics Hub. Confidential.',
                            'generatedDate'     => date('Y-m-d H:i:s'),
                            'pageNumberText'    => 'Page 1 of 1'
                        ]) ?>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }

    // Logo upload listener
    setupImageFileInput('logoFileInput', 'brandingLogoInput', 'formLogoThumbnail', 'formLogoFallbackIcon');
    // Header image upload listener
    setupImageFileInput('headerFileInput', 'reportHeaderImageInput', 'formHeaderThumbnail', 'formHeaderFallbackIcon');
    // Footer image upload listener
    setupImageFileInput('footerFileInput', 'reportFooterImageInput', 'formFooterThumbnail', 'formFooterFallbackIcon');

    updateBrandPreview();
});

function setupImageFileInput(fileInputId, textInputId, thumbId, fallbackIconId) {
    const fileInput = document.getElementById(fileInputId);
    const textInput = document.getElementById(textInputId);
    const thumb = document.getElementById(thumbId);
    const fallbackIcon = document.getElementById(fallbackIconId);

    if (fileInput) {
        fileInput.addEventListener('change', function(e) {
            if (e.target.files && e.target.files[0]) {
                const reader = new FileReader();
                reader.onload = function(evt) {
                    if (textInput) textInput.value = evt.target.result;
                    if (thumb) {
                        thumb.src = evt.target.result;
                        thumb.classList.remove('hidden');
                    }
                    if (fallbackIcon) fallbackIcon.classList.add('hidden');
                    updateBrandPreview();
                };
                reader.readAsDataURL(e.target.files[0]);
            }
        });
    }
}

function loadPresetLogo(url) {
    const input = document.getElementById('brandingLogoInput');
    const fileInput = document.getElementById('logoFileInput');
    if (fileInput) fileInput.value = '';
    if (input) {
        input.value = url;
        updateBrandPreview();
    }
}

function loadPresetHeaderImg(url) {
    const input = document.getElementById('reportHeaderImageInput');
    const fileInput = document.getElementById('headerFileInput');
    if (fileInput) fileInput.value = '';
    if (input) {
        input.value = url;
        updateBrandPreview();
    }
}

function loadPresetFooterImg(url) {
    const input = document.getElementById('reportFooterImageInput');
    const fileInput = document.getElementById('footerFileInput');
    if (fileInput) fileInput.value = '';
    if (input) {
        input.value = url;
        updateBrandPreview();
    }
}

function selectCompanyTheme(themeId, hex) {
    const themeInput = document.getElementById('companyThemeInput');
    const colorInput = document.getElementById('companyPrimaryColorInput');
    const picker = document.getElementById('companyColorPicker');
    if (themeInput) themeInput.value = themeId;
    if (colorInput) colorInput.value = hex;
    if (picker) picker.value = hex;

    // Highlight selected button
    document.querySelectorAll('[id^="theme-choice-"]').forEach(el => {
        el.classList.remove('border-indigo-600', 'bg-indigo-50/50', 'dark:bg-indigo-950/40', 'ring-2', 'ring-indigo-500/20');
        el.classList.add('border-slate-200', 'dark:border-slate-700');
    });
    const selectedBtn = document.getElementById('theme-choice-' + themeId);
    if (selectedBtn) {
        selectedBtn.classList.remove('border-slate-200', 'dark:border-slate-700');
        selectedBtn.classList.add('border-indigo-600', 'bg-indigo-50/50', 'dark:bg-indigo-950/40', 'ring-2', 'ring-indigo-500/20');
    }

    if (window.applyTheme) {
        window.applyTheme(themeId, null, true);
    }
}

window.addEventListener('ci4-theme-changed', (e) => {
    if (e.detail && e.detail.theme) {
        const themeId = e.detail.theme;
        const themeInput = document.getElementById('companyThemeInput');
        if (themeInput) themeInput.value = themeId;
        document.querySelectorAll('[id^="theme-choice-"]').forEach(el => {
            el.classList.remove('border-indigo-600', 'bg-indigo-50/50', 'dark:bg-indigo-950/40', 'ring-2', 'ring-indigo-500/20');
            el.classList.add('border-slate-200', 'dark:border-slate-700');
        });
        const selectedBtn = document.getElementById('theme-choice-' + themeId);
        if (selectedBtn) {
            selectedBtn.classList.remove('border-slate-200', 'dark:border-slate-700');
            selectedBtn.classList.add('border-indigo-600', 'bg-indigo-50/50', 'dark:bg-indigo-950/40', 'ring-2', 'ring-indigo-500/20');
        }
        if (window.THEME_DEFINITIONS && window.THEME_DEFINITIONS[themeId]) {
            const hex = window.THEME_DEFINITIONS[themeId].primaryHex || window.THEME_DEFINITIONS[themeId].p600;
            const colorInput = document.getElementById('companyPrimaryColorInput');
            const picker = document.getElementById('companyColorPicker');
            if (colorInput) colorInput.value = hex;
            if (picker) picker.value = hex;
        }
    }
});

function updateBrandPreview() {
    const logoInput = document.getElementById('brandingLogoInput');
    const headerInput = document.getElementById('reportHeaderImageInput');
    const headerTextInput = document.getElementById('reportHeaderTextInput');
    const footerInput = document.getElementById('reportFooterImageInput');
    const footerTextInput = document.getElementById('reportFooterTextInput');
    const companyNameInput = document.getElementById('companyNameInput');

    const logoVal = logoInput ? logoInput.value.trim() : '';
    const headerVal = headerInput ? headerInput.value.trim() : '';
    const headerTextVal = headerTextInput ? headerTextInput.value.trim() : '';
    const footerVal = footerInput ? footerInput.value.trim() : '';
    const footerTextVal = footerTextInput ? footerTextInput.value.trim() : '';
    const compNameVal = companyNameInput ? companyNameInput.value.trim() : 'Enterprise HRMS';

    // 1. Sidebar Brand Simulation (uses Application Logo only)
    const sidebarLogo = document.getElementById('sidebarLogoImg');
    const sidebarFallback = document.getElementById('sidebarLogoFallbackIcon');
    const sidebarCompName = document.getElementById('sidebarCompanyName');
    const sidebarStatus = document.getElementById('sidebarLogoStatusText');

    if (sidebarCompName && compNameVal) {
        sidebarCompName.textContent = compNameVal;
    }

    if (logoVal.length > 5) {
        if (sidebarLogo) {
            sidebarLogo.src = logoVal;
            sidebarLogo.classList.remove('hidden');
        }
        if (sidebarFallback) sidebarFallback.classList.add('hidden');
        if (sidebarStatus) sidebarStatus.textContent = '✓ Custom Logo Active';
    } else {
        if (sidebarLogo) {
            sidebarLogo.src = '';
            sidebarLogo.classList.add('hidden');
        }
        if (sidebarFallback) sidebarFallback.classList.remove('hidden');
        if (sidebarStatus) sidebarStatus.textContent = '✓ Default Icon Active';
    }

    // Form thumbnail cards
    const logoThumb = document.getElementById('formLogoThumbnail');
    const logoFallback = document.getElementById('formLogoFallbackIcon');
    if (logoVal.length > 5) {
        if (logoThumb) { logoThumb.src = logoVal; logoThumb.classList.remove('hidden'); }
        if (logoFallback) logoFallback.classList.add('hidden');
    } else {
        if (logoThumb) { logoThumb.src = ''; logoThumb.classList.add('hidden'); }
        if (logoFallback) logoFallback.classList.remove('hidden');
    }

    const headerThumb = document.getElementById('formHeaderThumbnail');
    const headerFallback = document.getElementById('formHeaderFallbackIcon');
    if (headerVal.length > 5) {
        if (headerThumb) { headerThumb.src = headerVal; headerThumb.classList.remove('hidden'); }
        if (headerFallback) headerFallback.classList.add('hidden');
    } else {
        if (headerThumb) { headerThumb.src = ''; headerThumb.classList.add('hidden'); }
        if (headerFallback) headerFallback.classList.remove('hidden');
    }

    const footerThumb = document.getElementById('formFooterThumbnail');
    const footerFallback = document.getElementById('formFooterFallbackIcon');
    if (footerVal.length > 5) {
        if (footerThumb) { footerThumb.src = footerVal; footerThumb.classList.remove('hidden'); }
        if (footerFallback) footerFallback.classList.add('hidden');
    } else {
        if (footerThumb) { footerThumb.src = ''; footerThumb.classList.add('hidden'); }
        if (footerFallback) footerFallback.classList.remove('hidden');
    }

    // 2. Synchronize Report Header (Optional Image Rule: independent from logo!)
    const previewHeader = document.querySelector('.report-header-wrapper');
    const headerStatus = document.getElementById('previewHeaderStatus');

    if (previewHeader) {
        let headerImgBox = previewHeader.querySelector('.report-header-image-box');
        if (headerVal.length > 5) {
            if (!headerImgBox) {
                headerImgBox = document.createElement('div');
                headerImgBox.className = 'report-header-image-box mb-2.5 flex justify-center';
                const img = document.createElement('img');
                img.className = 'max-h-16 max-w-[240px] object-contain';
                img.alt = 'Report Header';
                img.onerror = function() { headerImgBox.remove(); };
                headerImgBox.appendChild(img);
                previewHeader.insertBefore(headerImgBox, previewHeader.firstChild);
            }
            const img = headerImgBox.querySelector('img');
            if (img) img.src = headerVal;
            headerImgBox.style.display = 'flex';
            if (headerStatus) {
                headerStatus.textContent = 'HEADER: IMAGE';
                headerStatus.className = 'text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 font-mono';
            }
        } else {
            if (headerImgBox) {
                headerImgBox.remove();
            }
            if (headerStatus) {
                headerStatus.textContent = 'HEADER: TEXT-ONLY (0px)';
                headerStatus.className = 'text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400 font-mono';
            }
        }

        // Update custom header text
        let customTextEl = previewHeader.querySelector('.report-custom-header-text');
        const companyInfoDiv = previewHeader.querySelector('.company-text-info');
        if (headerTextVal.length > 0) {
            if (!customTextEl && companyInfoDiv) {
                customTextEl = document.createElement('div');
                customTextEl.className = 'report-custom-header-text text-sm font-semibold text-slate-700 mb-1';
                companyInfoDiv.insertBefore(customTextEl, companyInfoDiv.firstChild);
            }
            if (customTextEl) customTextEl.textContent = headerTextVal;
        } else if (customTextEl) {
            customTextEl.remove();
        }
    }

    // 3. Synchronize Report Footer (Optional Image Rule: independent from logo & header!)
    const previewFooter = document.querySelector('.report-footer-wrapper');
    const footerStatus = document.getElementById('previewFooterStatus');

    if (previewFooter) {
        let footerImgBox = previewFooter.querySelector('.report-footer-image-box');
        if (footerVal.length > 5) {
            if (!footerImgBox) {
                footerImgBox = document.createElement('div');
                footerImgBox.className = 'report-footer-image-box mb-2.5 flex justify-center';
                const img = document.createElement('img');
                img.className = 'max-h-8 max-w-full object-contain';
                img.alt = 'Footer Banner';
                img.onerror = function() { footerImgBox.remove(); };
                footerImgBox.appendChild(img);
                previewFooter.insertBefore(footerImgBox, previewFooter.firstChild);
            }
            const img = footerImgBox.querySelector('img');
            if (img) img.src = footerVal;
            footerImgBox.style.display = 'flex';
            if (footerStatus) {
                footerStatus.textContent = 'FOOTER: IMAGE';
                footerStatus.className = 'text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300 font-mono';
            }
        } else {
            if (footerImgBox) {
                footerImgBox.remove();
            }
            if (footerStatus) {
                footerStatus.textContent = 'FOOTER: TEXT-ONLY (0px)';
                footerStatus.className = 'text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400 font-mono';
            }
        }

        const footerMsg = previewFooter.querySelector('.footer-msg');
        if (footerMsg && footerTextVal.length > 0) {
            footerMsg.textContent = footerTextVal;
        }
    }
}
</script>
