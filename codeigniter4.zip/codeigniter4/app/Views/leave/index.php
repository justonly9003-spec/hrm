<div id="leave-manager-page" class="space-y-6">

    <!-- Top Header & Action Bar -->
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div>
            <div class="flex items-center gap-3">
                <div class="w-11 h-11 rounded-2xl bg-indigo-50 border border-indigo-100 text-indigo-600 flex items-center justify-center font-bold shadow-xs">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                </div>
                <div>
                    <h1 class="text-xl font-extrabold text-slate-900 tracking-tight">Leave Management</h1>
                    <p class="text-xs text-slate-500 mt-0.5">Leave applications, approvals, balances, and audit ledger. All leave rules and policies are governed in the Rule Engine.</p>
                </div>
            </div>
        </div>

        <div class="flex flex-wrap items-center gap-2.5">
            <?php if (!empty($canExportLeave)): ?>
            <a href="<?= base_url('leave/export') ?>" class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 shadow-xs transition">
                <svg class="w-3.5 h-3.5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                Export Data
            </a>
            <?php endif; ?>
            <?php if (!empty($canCreateLeaveType)): ?>
            <button type="button" onclick="openLeaveTypeModal()" class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-600 text-white shadow-sm shadow-amber-500/20 transition">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                + Create Leave Type
            </button>
            <?php endif; ?>
            <?php if (!empty($canApplyLeave)): ?>
            <button type="button" onclick="openModal('applyLeaveModal')" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm shadow-indigo-600/20 transition">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                + Apply for Leave
            </button>
            <?php endif; ?>
        </div>
    </div>

    <!-- Navigation Tabs -->
    <div class="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto">
        <button onclick="switchTab('applications')" id="tab-btn-applications" class="tab-btn flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-xl transition whitespace-nowrap bg-indigo-600 text-white shadow-md shadow-indigo-500/20">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
            Applications & Approvals
            <?php if (!empty($metrics['total_pending']) && (int)$metrics['total_pending'] > 0): ?>
                <span class="px-2 py-0.5 bg-amber-500 text-white text-[10px] rounded-full font-bold">
                    <?= esc($metrics['total_pending']) ?>
                </span>
            <?php endif; ?>
        </button>

        <?php if (!empty($canCreateLeaveType)): ?>
        <button onclick="switchTab('leaveTypes')" id="tab-btn-leaveTypes" class="tab-btn flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-xl transition whitespace-nowrap text-slate-600 hover:bg-slate-100">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"/></svg>
            Leave Categories (<?= count($leaveTypes ?? []) ?>)
        </button>
        <?php endif; ?>

        <?php if (!empty($canViewRules)): ?>
        <a href="<?= base_url('rules?domain=LEAVE') ?>" class="flex items-center gap-1.5 px-3 py-2 text-xs font-bold rounded-xl transition whitespace-nowrap text-purple-700 bg-purple-50 hover:bg-purple-100 border border-purple-200 shadow-2xs" title="Centrally govern leave rules, quotas, sandwich rules, and approval tiers in the Rule Engine">
            <svg class="w-4 h-4 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
            Leave Rules (Rule Engine) &rarr;
        </a>
        <?php endif; ?>

        <button onclick="switchTab('ledger')" id="tab-btn-ledger" class="tab-btn flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-xl transition whitespace-nowrap text-slate-600 hover:bg-slate-100">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
            Leave Balances & Audit Ledger
        </button>

        <?php if (!empty($canManageAccrual)): ?>
        <button onclick="switchTab('accrualRollover')" id="tab-btn-accrualRollover" class="tab-btn flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-xl transition whitespace-nowrap text-slate-600 hover:bg-slate-100">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
            Accrual & Year-End Rollover
        </button>
        <?php endif; ?>

        <button onclick="switchTab('calendar')" id="tab-btn-calendar" class="tab-btn flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-xl transition whitespace-nowrap text-slate-600 hover:bg-slate-100">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
            Absence & Holiday Calendar
        </button>

        <button onclick="switchTab('simulator')" id="tab-btn-simulator" class="tab-btn flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-xl transition whitespace-nowrap text-slate-600 hover:bg-slate-100">
            <svg class="w-4 h-4 text-teal-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
            Eligibility Sandbox
        </button>

        <?php if (!empty($canViewReconciliation)): ?>
        <button onclick="switchTab('reconciliation')" id="tab-btn-reconciliation" class="tab-btn flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-xl transition whitespace-nowrap text-slate-600 hover:bg-slate-100">
            <svg class="w-4 h-4 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
            Reconciliation Matrix
        </button>
        <?php endif; ?>
    </div>

    <!-- ==================== TAB 1: APPLICATIONS & APPROVALS ==================== -->
    <div id="tab-content-applications" class="tab-content space-y-6">
        
        <!-- Summary Metric Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
                <div>
                    <span class="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Total Applications</span>
                    <h3 class="text-2xl font-black text-slate-800 font-mono mt-1"><?= esc($metrics['total_applied']) ?></h3>
                    <span class="text-[10px] text-slate-400">All registered requests</span>
                </div>
                <div class="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600 font-bold text-lg">
                    📝
                </div>
            </div>

            <div class="bg-white p-5 rounded-2xl border border-amber-200/80 bg-amber-50/20 shadow-sm flex items-center justify-between">
                <div>
                    <span class="text-[11px] font-bold text-amber-700 uppercase tracking-wider">Pending Review</span>
                    <h3 class="text-2xl font-black text-amber-600 font-mono mt-1"><?= esc($metrics['total_pending']) ?></h3>
                    <span class="text-[10px] text-amber-600/80 font-medium">In approval pipeline</span>
                </div>
                <div class="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center text-amber-700 font-bold text-lg">
                    ⏳
                </div>
            </div>

            <div class="bg-white p-5 rounded-2xl border border-emerald-200/80 bg-emerald-50/20 shadow-sm flex items-center justify-between">
                <div>
                    <span class="text-[11px] font-bold text-emerald-700 uppercase tracking-wider">Approved Requests</span>
                    <h3 class="text-2xl font-black text-emerald-600 font-mono mt-1"><?= esc($metrics['total_approved']) ?></h3>
                    <span class="text-[10px] text-emerald-600/80 font-medium">Sanctioned & logged</span>
                </div>
                <div class="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-700 font-bold text-lg">
                    ✅
                </div>
            </div>

            <div class="bg-white p-5 rounded-2xl border border-rose-200/80 bg-rose-50/20 shadow-sm flex items-center justify-between">
                <div>
                    <span class="text-[11px] font-bold text-rose-700 uppercase tracking-wider">Rejected Requests</span>
                    <h3 class="text-2xl font-black text-rose-600 font-mono mt-1"><?= esc($metrics['total_rejected']) ?></h3>
                    <span class="text-[10px] text-rose-600/80 font-medium">Declined / quota restored</span>
                </div>
                <div class="w-10 h-10 rounded-xl bg-rose-100 flex items-center justify-center text-rose-700 font-bold text-lg">
                    ❌
                </div>
            </div>
        </div>

        <!-- Pending Approval Queue (Quick Managerial Action Desk) -->
        <?php if (!empty($canApproveLeave) || !empty($canEndorseLeave) || !empty($canHrApproveLeave)): ?>
        <div class="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
            <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                <div class="flex items-center gap-2">
                    <h3 class="font-bold text-slate-800 text-sm">Quick Managerial Action Desk</h3>
                    <span class="px-2 py-0.5 bg-amber-100 text-amber-800 font-bold text-[10px] rounded-full">
                        <?= esc($metrics['total_pending'] ?? count($managerialApplications ?? [])) ?> Pending Requests
                    </span>
                </div>
            </div>

            <?php 
                $pendingList = !empty($managerialApplications) ? $managerialApplications : [];
            ?>

            <?php if (empty($pendingList)): ?>
                <div class="py-10 text-center text-slate-400 italic text-xs">
                    ✨ No pending leave applications requiring approval at this time.
                </div>
            <?php else: ?>
                <div class="divide-y divide-slate-100">
                    <?php foreach ($pendingList as $app): ?>
                        <div class="py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
                            <div class="flex items-center gap-3">
                                <div class="w-9 h-9 rounded-full bg-indigo-50 border border-indigo-100 flex items-center justify-center font-bold text-indigo-700 flex-shrink-0">
                                    <?= esc(substr($app['employee_name'] ?? 'E', 0, 1)) ?>
                                </div>
                                <div>
                                    <span class="font-bold text-slate-900 block"><?= esc($app['employee_name']) ?> <span class="text-slate-400 font-mono text-[10px] font-normal">(<?= esc($app['employee_code'] ?? $app['employee_id']) ?>)</span></span>
                                    <span class="text-[10px] text-slate-500">
                                        <?= esc($app['department_name'] ?? 'General') ?> • <strong class="text-indigo-600"><?= esc($app['leave_type_name'] ?? $app['type_name'] ?? 'Leave') ?></strong>
                                    </span>
                                </div>
                            </div>

                            <div class="bg-slate-50 p-2.5 rounded-xl border border-slate-200 max-w-sm flex-1">
                                <div class="flex justify-between items-center text-[10px] font-bold text-slate-700">
                                    <span>📅 <?= esc($app['from_date'] ?? $app['start_date']) ?> to <?= esc($app['to_date'] ?? $app['end_date']) ?></span>
                                    <span class="text-indigo-600 font-mono"><?= esc($app['total_days']) ?> Working Day(s)</span>
                                </div>
                                <p class="text-slate-500 text-[10px] italic mt-1 truncate" title="<?= esc($app['reason']) ?>">"<?= esc($app['reason']) ?>"</p>
                            </div>

                            <div class="flex items-center gap-1.5 flex-shrink-0">
                                <a href="<?= base_url('leave/slip/' . esc($app['id'])) ?>" target="_blank" class="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1" title="View & Print Official Slip">
                                    <svg class="w-3.5 h-3.5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
                                    <span>Slip</span>
                                </a>
                                <?php 
                                    $isMgrEndorsed = in_array(strtolower((string)($app['manager_status'] ?? '')), ['approved', 'endorsed'], true);
                                    $isDhEndorsed  = in_array(strtolower((string)($app['dept_head_status'] ?? '')), ['approved', 'endorsed'], true);
                                    $appTotalDays  = (float)($app['total_days'] ?? 1.0);
                                    $appReqDh      = ($appTotalDays >= 8.0) || !empty($app['dept_head_id']) || !empty($app['dept_head_status']);
                                    $isEndorsedApp = in_array(strtolower((string)($app['status'] ?? '')), ['endorsed'], true) || $isMgrEndorsed;
                                ?>
                                <?php if (!$isMgrEndorsed && !empty($canEndorseLeave)): ?>
                                    <button type="button" onclick="openEndorseModal('<?= esc($app['id']) ?>', '<?= esc(addslashes($app['employee_name'])) ?>', false)" class="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-xs font-bold transition">
                                        Endorse (Mgr)
                                    </button>
                                <?php endif; ?>
                                <?php if ($appReqDh && !$isDhEndorsed && !empty($canEndorseLeave)): ?>
                                    <button type="button" onclick="openEndorseModal('<?= esc($app['id']) ?>', '<?= esc(addslashes($app['employee_name'])) ?>', true)" class="px-3 py-1.5 bg-purple-50 hover:bg-purple-100 text-purple-700 rounded-xl text-xs font-bold transition">
                                        Endorse (Dept Head)
                                    </button>
                                <?php endif; ?>
                                <button type="button" onclick="openRejectModal('<?= esc($app['id']) ?>', '<?= esc(addslashes($app['employee_name'])) ?>')" class="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl text-xs font-bold transition">
                                    Reject
                                </button>
                                <?php if (($isEndorsedApp && !empty($canHrApproveLeave)) || (!$isEndorsedApp && !empty($canApproveLeave))): ?>
                                    <button type="button" onclick="openApproveModal('<?= esc($app['id']) ?>', '<?= esc(addslashes($app['employee_name'])) ?>', '<?= esc($app['total_days']) ?>')" class="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition shadow-sm">
                                        <?= $isEndorsedApp ? 'HR Approve' : 'Approve' ?>
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <!-- Filters Form -->
        <div class="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm flex flex-col md:flex-row gap-3 items-center justify-between">
            <form method="GET" action="<?= base_url('leave') ?>" class="flex flex-wrap items-center gap-2 w-full md:w-auto flex-1">
                <input type="hidden" name="tab" value="applications">

                <div class="relative flex-1 min-w-[200px]">
                    <svg class="w-4 h-4 absolute left-3 top-3 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                    <input type="text" name="search" value="<?= esc($searchFilter ?? '') ?>" placeholder="Search employee name, code, reason..." class="w-full text-xs pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-1 focus:ring-indigo-500">
                </div>

                <select name="type" onchange="this.form.submit()" class="text-xs border border-slate-200 rounded-xl px-3 py-2.5 bg-slate-50 font-bold focus:outline-none">
                    <option value="all">All Leave Types</option>
                    <?php foreach ($leaveTypes as $t): ?>
                        <option value="<?= esc($t['id']) ?>" <?= ($typeFilter ?? '') === $t['id'] ? 'selected' : '' ?>><?= esc($t['name'] ?? 'Leave') ?> (<?= esc($t['code'] ?? 'LV') ?>)</option>
                    <?php endforeach; ?>
                </select>

                <select name="status" onchange="this.form.submit()" class="text-xs border border-slate-200 rounded-xl px-3 py-2.5 bg-slate-50 font-bold focus:outline-none">
                    <option value="all" <?= ($statusFilter ?? '') === 'all' ? 'selected' : '' ?>>All Statuses</option>
                    <option value="Pending" <?= ($statusFilter ?? '') === 'Pending' ? 'selected' : '' ?>>⏳ Pending</option>
                    <option value="Endorsed" <?= ($statusFilter ?? '') === 'Endorsed' ? 'selected' : '' ?>>✍️ Endorsed</option>
                    <option value="Approved" <?= ($statusFilter ?? '') === 'Approved' ? 'selected' : '' ?>>✅ Approved</option>
                    <option value="Rejected" <?= ($statusFilter ?? '') === 'Rejected' ? 'selected' : '' ?>>❌ Rejected</option>
                    <option value="Cancelled" <?= ($statusFilter ?? '') === 'Cancelled' ? 'selected' : '' ?>>🚫 Cancelled</option>
                </select>

                <button type="submit" class="px-3.5 py-2.5 bg-slate-800 text-white rounded-xl text-xs font-bold">Filter</button>
            </form>

            <div class="flex items-center gap-2">
                <a href="<?= base_url('leave/export?status=' . urlencode($statusFilter ?? 'all') . '&type=' . urlencode($typeFilter ?? 'all')) ?>" class="px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition whitespace-nowrap">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                    Export CSV
                </a>
            </div>
        </div>

        <!-- Batch Action Toolbar -->
        <?php if (!empty($canApproveLeave) || !empty($canHrApproveLeave)): ?>
        <div id="batchActionToolbar" class="bg-indigo-50 border border-indigo-200 rounded-2xl p-3 shadow-sm hidden items-center justify-between text-xs">
            <div class="flex items-center gap-2 font-bold text-indigo-900">
                <span id="selectedCountText">0 selected</span>
            </div>
            <div class="flex items-center gap-2">
                <button type="button" onclick="submitBatchReject()" class="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold transition">
                    Batch Reject
                </button>
                <button type="button" onclick="submitBatchApprove()" class="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold transition shadow-sm">
                    Batch Approve
                </button>
            </div>
        </div>
        <?php endif; ?>

        <!-- Registry Table -->
        <div class="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs text-slate-600">
                    <thead class="bg-slate-50 text-slate-700 font-bold border-b border-slate-200 uppercase text-[10px]">
                        <tr>
                            <th class="p-3.5 w-8">
                                <input type="checkbox" id="selectAllCheckbox" onchange="toggleSelectAll(this)" class="rounded text-indigo-600 w-4 h-4">
                            </th>
                            <th class="p-3.5">Employee</th>
                            <th class="p-3.5">Category & Duration</th>
                            <th class="p-3.5">Days & Rules</th>
                            <th class="p-3.5">Reason & Attachment</th>
                            <th class="p-3.5">Tier 1: Manager</th>
                            <th class="p-3.5">Tier 2: HR Final</th>
                            <th class="p-3.5 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php if (empty($applications)): ?>
                            <tr><td colspan="8" class="p-10 text-center text-slate-400 italic">No leave applications found matching your criteria.</td></tr>
                        <?php else: ?>
                            <?php foreach ($applications as $app): ?>
                                <?php 
                                    $isOwnApp = !empty($currentEmp['id']) && (string)$app['employee_id'] === (string)$currentEmp['id'];
                                    $canCheckApprove = ($app['status'] === 'Endorsed' && !empty($canHrApproveLeave)) || ($app['status'] === 'Pending' && !empty($canApproveLeave));
                                ?>
                                <tr class="hover:bg-slate-50/60 transition">
                                    <td class="p-3.5">
                                        <?php if (in_array($app['status'], ['Pending', 'Endorsed'], true) && $canCheckApprove && !$isOwnApp): ?>
                                            <input type="checkbox" class="app-checkbox rounded text-indigo-600 w-4 h-4" value="<?= esc($app['id']) ?>" onchange="updateBatchState()">
                                        <?php else: ?>
                                            <span class="text-slate-300">-</span>
                                        <?php endif; ?>
                                    </td>

                                    <td class="p-3.5">
                                        <div class="flex items-center gap-2.5">
                                            <div class="w-8 h-8 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center font-bold text-slate-600">
                                                <?= esc(substr($app['employee_name'] ?? 'E', 0, 1)) ?>
                                            </div>
                                            <div>
                                                <span class="font-bold text-slate-900 block"><?= esc($app['employee_name']) ?></span>
                                                <span class="text-[10px] text-slate-400 font-mono"><?= esc($app['employee_code'] ?? $app['employee_id']) ?> • <?= esc($app['department_name'] ?? 'General') ?></span>
                                            </div>
                                        </div>
                                    </td>

                                    <td class="p-3.5">
                                        <span class="font-bold text-slate-800 block"><?= esc($app['leave_type_name'] ?? $app['type_name'] ?? 'Leave') ?></span>
                                        <span class="text-slate-500 text-[10px] block">
                                            📅 <?= esc($app['from_date'] ?? $app['start_date']) ?> &rarr; <?= esc($app['to_date'] ?? $app['end_date']) ?>
                                        </span>
                                    </td>

                                    <td class="p-3.5">
                                        <div class="flex flex-wrap items-center gap-1">
                                            <span class="font-bold text-indigo-700 font-mono text-xs bg-indigo-50 px-2 py-0.5 rounded-md">
                                                <?= esc($app['total_days']) ?> d
                                            </span>
                                            <?php if (!empty($app['sandwich_rule_applies'])): ?>
                                                <span class="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-100 text-amber-800" title="Sandwich weekend rule applied (+2 days)">
                                                    🥪 +2d Sandwich
                                                </span>
                                            <?php endif; ?>
                                            <?php if (!empty($app['is_emergency'])): ?>
                                                <span class="px-1.5 py-0.5 rounded text-[9px] font-bold bg-rose-100 text-rose-800">
                                                    🚨 Emergency
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </td>

                                    <td class="p-3.5 max-w-xs">
                                        <p class="text-slate-600 italic truncate text-[11px]" title="<?= esc($app['reason'] ?? '') ?>"><?= !empty($app['reason']) ? '"' . esc($app['reason']) . '"' : '<span class="text-slate-400 not-italic">Confidential</span>' ?></p>
                                        <?php if (!empty($app['attachment_path'])): ?>
                                            <a href="<?= base_url('leave/attachment/' . esc($app['id'])) ?>" target="_blank" class="inline-flex items-center gap-1 text-[10px] font-bold text-indigo-600 hover:underline mt-0.5">
                                                📎 Document
                                            </a>
                                        <?php endif; ?>
                                    </td>

                                    <!-- Tier 1 Manager & Dept Head Status -->
                                    <td class="p-3.5">
                                        <?php 
                                            $rowDays = (float)($app['total_days'] ?? 0);
                                            $rowReqDh = $rowDays >= 8;
                                            $isMgrDone = ($app['manager_status'] ?? '') === 'Approved';
                                            $isDhDone = ($app['dept_head_status'] ?? '') === 'Approved';
                                        ?>
                                        <?php if ($rowReqDh): ?>
                                            <div class="flex flex-col gap-1">
                                                <?php if ($isMgrDone): ?>
                                                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200" title="Manager Endorsement">
                                                        ✓ Mgr: <?= esc($app['manager_name'] ?? 'Mgr') ?>
                                                    </span>
                                                <?php else: ?>
                                                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-bold bg-slate-100 text-slate-600 border border-slate-200">
                                                        ⏳ Pending Mgr
                                                    </span>
                                                <?php endif; ?>

                                                <?php if ($isDhDone): ?>
                                                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-bold bg-purple-50 text-purple-700 border border-purple-200" title="Dept Head Endorsement">
                                                        ✓ DH: <?= esc($app['dept_head_name'] ?? 'Dept Head') ?>
                                                    </span>
                                                <?php else: ?>
                                                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-bold bg-purple-50/60 text-purple-600 border border-purple-100">
                                                        ⏳ Pending DH
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        <?php else: ?>
                                            <?php if ($isMgrDone): ?>
                                                <span class="px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                                                    ✓ Endorsed (<?= esc($app['manager_name'] ?? 'Mgr') ?>)
                                                </span>
                                            <?php else: ?>
                                                <span class="px-2 py-0.5 rounded-full text-[9px] font-bold bg-slate-100 text-slate-600 border border-slate-200">
                                                    Pending Endorsement
                                                </span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>

                                    <!-- Tier 2 HR Final Status -->
                                    <td class="p-3.5">
                                        <span class="px-2.5 py-1 rounded-full text-[10px] font-bold border <?= 
                                            $app['status'] === 'Approved' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 
                                            ($app['status'] === 'Pending' ? 'bg-amber-50 text-amber-700 border-amber-200' : 
                                            ($app['status'] === 'Endorsed' ? 'bg-indigo-50 text-indigo-700 border-indigo-200' : 
                                            ($app['status'] === 'Cancelled' ? 'bg-slate-100 text-slate-600 border-slate-200' : 'bg-rose-50 text-rose-700 border-rose-200'))) 
                                        ?>">
                                            <?= esc($app['status']) ?>
                                        </span>
                                    </td>

                                    <td class="p-3.5 text-right">
                                        <div class="flex items-center justify-end gap-1">
                                            <a href="<?= base_url('leave/slip/' . esc($app['id'])) ?>" target="_blank" class="px-2 py-1 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 text-slate-700 rounded-lg text-[10px] font-bold transition flex items-center gap-1" title="View & Print Official Leave Slip (PDF)">
                                                <svg class="w-3 h-3 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
                                                <span>Slip</span>
                                            </a>
                                            <?php 
                                                $isPendingOrEndorsed = in_array($app['status'], ['Pending', 'Endorsed'], true);
                                            ?>
                                            <?php 
                                                $isEndorsedRow = ($app['status'] === 'Endorsed') || ($isMgrDone && (!$rowReqDh || $isDhDone));
                                            ?>
                                            <?php if (!$isOwnApp && (!empty($canApproveLeave) || !empty($canEndorseLeave) || !empty($canHrApproveLeave)) && $isPendingOrEndorsed): ?>
                                                <?php if (!$isMgrDone && !empty($canEndorseLeave)): ?>
                                                    <button type="button" onclick="openEndorseModal('<?= esc($app['id']) ?>', '<?= esc(addslashes($app['employee_name'])) ?>', false)" class="px-2 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-[10px] font-bold transition">Endorse (Mgr)</button>
                                                <?php endif; ?>
                                                <?php if ($rowReqDh && !$isDhDone && (!empty($canEndorseLeave) || !empty($canApproveLeave))): ?>
                                                    <button type="button" onclick="openEndorseModal('<?= esc($app['id']) ?>', '<?= esc(addslashes($app['employee_name'])) ?>', true)" class="px-2 py-1 bg-purple-50 hover:bg-purple-100 text-purple-700 rounded-lg text-[10px] font-bold transition">Endorse (DH)</button>
                                                <?php endif; ?>
                                                <button type="button" onclick="openRejectModal('<?= esc($app['id']) ?>', '<?= esc(addslashes($app['employee_name'])) ?>')" class="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg text-[10px] font-bold transition">Reject</button>
                                                <?php if (($isEndorsedRow && !empty($canHrApproveLeave)) || (!$isEndorsedRow && !empty($canApproveLeave))): ?>
                                                    <button type="button" onclick="openApproveModal('<?= esc($app['id']) ?>', '<?= esc(addslashes($app['employee_name'])) ?>', '<?= esc($app['total_days']) ?>')" class="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[10px] font-bold transition"><?= $isEndorsedRow ? 'HR Approve' : 'Approve' ?></button>
                                                <?php endif; ?>
                                            <?php elseif ($isOwnApp && $isPendingOrEndorsed): ?>
                                                <button type="button" onclick="openCancelModal('<?= esc($app['id']) ?>', '<?= esc(addslashes($app['employee_name'])) ?>', false)" class="px-2 py-1 bg-slate-100 hover:bg-rose-50 hover:text-rose-600 text-slate-700 rounded-lg text-[10px] font-bold transition">Withdraw</button>
                                            <?php elseif ($app['status'] === 'Approved' && (!empty($canApproveLeave) || $isOwnApp)): ?>
                                                <button type="button" onclick="openCancelModal('<?= esc($app['id']) ?>', '<?= esc(addslashes($app['employee_name'])) ?>', true)" class="px-2 py-1 bg-slate-100 hover:bg-rose-50 hover:text-rose-600 text-slate-700 rounded-lg text-[10px] font-bold">Cancel</button>
                                            <?php elseif ($app['status'] === 'Approved'): ?>
                                                <span class="text-[10px] text-emerald-600 font-bold">Approved</span>
                                            <?php elseif ($isPendingOrEndorsed): ?>
                                                <span class="text-[10px] text-amber-600 font-bold">Under Review</span>
                                            <?php else: ?>
                                                <span class="text-[10px] text-slate-400 font-semibold">Archived</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <!-- ==================== TAB 3: ROSTER & HOLIDAY CALENDAR ==================== -->
    <div id="tab-content-calendar" class="tab-content hidden space-y-4">
        <?= view('dashboard/widgets/staff_leave_calendar', [
            'calendarMatrix'        => $calendarMatrix ?? [],
            'allLeaveApplications'  => $calendarApplications ?? $allApplications ?? $applications ?? [],
            'employees'             => $calendarEmployees ?? $employees ?? [],
            'holidays'              => $holidays ?? [],
            'departments'           => $calendarDepartments ?? $departments ?? [],
            'branches'              => $branches ?? [],
            'leaveTypes'            => $leaveTypes ?? [],
            'companyId'             => $companyId ?? null,
            'currentEmp'            => $currentEmp ?? null,
            'currentEmpId'          => $currentEmp['id'] ?? null,
            'currentDeptId'         => $currentEmp['department_id'] ?? null,
            'isHRAdmin'             => $isHRAdmin ?? false,
            'canApproveLeave'       => $canApproveLeave ?? false,
            'calYear'               => $calendarMatrix['year'] ?? date('Y'),
            'calMonth'              => $calendarMatrix['month'] ?? date('n')
        ]) ?>
    </div>

    <!-- ==================== TAB 5: ACCRUAL & ROLLOVER ENGINE ==================== -->
    <div id="tab-content-accrualRollover" class="tab-content hidden space-y-6">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            <!-- Monthly Accrual Engine Card -->
            <div class="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-5">
                <div class="flex items-center justify-between border-b border-slate-100 pb-4">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center font-bold text-indigo-600 text-lg">
                            ⚡
                        </div>
                        <div>
                            <h3 class="font-bold text-slate-900 text-sm">Leave Accrual Batch Engine</h3>
                            <p class="text-[11px] text-slate-500">Calculates dynamic leave accruals (Calendar days & Monthly) driven by the Centralized Rule Engine.</p>
                        </div>
                    </div>
                    <span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-100">
                        Rule Engine Driven
                    </span>
                </div>

                <div class="p-4 bg-slate-50 rounded-2xl border border-slate-100 text-xs text-slate-600 space-y-2">
                    <p><strong>Accrual Engine:</strong> <code class="bg-white px-1.5 py-0.5 rounded font-mono text-[11px] text-indigo-700 border border-slate-200">Calendar Days (N days = X leave) &amp; Monthly Accrual via Single Rule Store</code></p>
                    <p class="text-[11px] text-slate-500">Accruals are idempotent via deterministic cycle identifiers (<code class="font-mono text-[10px]">cycle_no</code>). Running multiple times for the same cycle will not duplicate credits.</p>
                </div>

                <form id="accrualBatchForm" method="POST" action="<?= base_url('leave/accrue-monthly') ?>" class="space-y-4">
                    <?= csrf_field() ?>
                    <div>
                        <label class="block text-xs font-bold text-slate-700 mb-1">Effective Accrual Date</label>
                        <input type="date" name="effective_date" id="accrual_effective_date" value="<?= date('Y-m-d') ?>" required class="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-indigo-500">
                    </div>

                    <div class="flex items-center gap-3 p-3 bg-indigo-50/50 border border-indigo-100 rounded-xl">
                        <input type="checkbox" name="is_dry_run" id="accrual_dry_run" value="1" checked class="w-4 h-4 text-indigo-600 rounded">
                        <label for="accrual_dry_run" class="text-xs font-bold text-indigo-900 cursor-pointer">
                            Dry Run / Simulation Mode (Test calculations without updating balances)
                        </label>
                    </div>

                    <div class="flex items-center gap-3 pt-2">
                        <button type="button" onclick="runAccrualSimulation()" class="flex-1 px-4 py-2.5 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition shadow-sm flex items-center justify-center gap-2">
                            <span>🔍 Simulate Accrual</span>
                        </button>
                        <button type="submit" onclick="return confirm('Execute monthly accrual for all eligible employees?')" class="flex-1 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-sm flex items-center justify-center gap-2">
                            <span>⚡ Commit Live Accrual</span>
                        </button>
                    </div>
                </form>

                <!-- Accrual Simulation Results Output -->
                <div id="accrualSimulationResult" class="hidden border border-indigo-100 rounded-2xl p-4 bg-indigo-50/30 text-xs space-y-3">
                    <div class="flex items-center justify-between font-bold text-indigo-900">
                        <span>Simulation Summary</span>
                        <span id="accrualResultCount" class="text-[11px] bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded-full">0 Records</span>
                    </div>
                    <div id="accrualResultSummary" class="text-slate-700 font-medium text-xs"></div>
                    <div class="max-h-48 overflow-y-auto border border-slate-200 rounded-xl bg-white">
                        <table class="w-full text-left text-[11px]">
                            <thead class="bg-slate-50 text-slate-500 font-bold border-b border-slate-100 sticky top-0">
                                <tr>
                                    <th class="p-2">Employee</th>
                                    <th class="p-2">Category</th>
                                    <th class="p-2 text-right">Credit</th>
                                    <th class="p-2 text-right">New Balance</th>
                                </tr>
                            </thead>
                            <tbody id="accrualResultTableBody" class="divide-y divide-slate-100 font-mono"></tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Year-End Rollover & Expiry Card -->
            <div class="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-5">
                <div class="flex items-center justify-between border-b border-slate-100 pb-4">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-2xl bg-amber-50 border border-amber-100 flex items-center justify-center font-bold text-amber-600 text-lg">
                            🔄
                        </div>
                        <div>
                            <h3 class="font-bold text-slate-900 text-sm">Year-End Carry Forward & Expiry Wizard</h3>
                            <p class="text-[11px] text-slate-500">Roll unused balances into the new fiscal year within statutory policy caps.</p>
                        </div>
                    </div>
                    <span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-100">
                        Annual Rollover
                    </span>
                </div>

                <div class="p-4 bg-slate-50 rounded-2xl border border-slate-100 text-xs text-slate-600 space-y-2">
                    <p><strong>Rollover Formula:</strong> <code class="bg-white px-1.5 py-0.5 rounded font-mono text-[11px] text-amber-700 border border-slate-200">Carried Forward = min(Available Balance, Max Carry Cap)</code></p>
                    <p class="text-[11px] text-slate-500">Any unused balance beyond the maximum cap is automatically logged as expired.</p>
                </div>

                <form id="rolloverForm" method="POST" action="<?= base_url('leave/rollover-year-end') ?>" class="space-y-4">
                    <?= csrf_field() ?>
                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block text-xs font-bold text-slate-700 mb-1">From Fiscal Year</label>
                            <input type="number" name="from_year" id="rollover_from_year" value="<?= (int)date('Y') - 1 ?>" required class="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500">
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-slate-700 mb-1">To Fiscal Year</label>
                            <input type="number" name="to_year" id="rollover_to_year" value="<?= (int)date('Y') ?>" required class="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500">
                        </div>
                    </div>

                    <div class="flex items-center gap-3 p-3 bg-amber-50/50 border border-amber-100 rounded-xl">
                        <input type="checkbox" name="is_dry_run" id="rollover_dry_run" value="1" checked class="w-4 h-4 text-amber-600 rounded">
                        <label for="rollover_dry_run" class="text-xs font-bold text-amber-900 cursor-pointer">
                            Dry Run / Simulation Mode (Test carry-forward & expiry without modifying records)
                        </label>
                    </div>

                    <div class="flex items-center gap-3 pt-2">
                        <button type="button" onclick="runRolloverSimulation()" class="flex-1 px-4 py-2.5 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition shadow-sm flex items-center justify-center gap-2">
                            <span>🔍 Simulate Rollover</span>
                        </button>
                        <button type="submit" onclick="return confirm('Commit year-end rollover? This will create new fiscal year opening balances.')" class="flex-1 px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition shadow-sm flex items-center justify-center gap-2">
                            <span>🔄 Commit Rollover</span>
                        </button>
                    </div>
                </form>

                <!-- Rollover Simulation Results Output -->
                <div id="rolloverSimulationResult" class="hidden border border-amber-100 rounded-2xl p-4 bg-amber-50/30 text-xs space-y-3">
                    <div class="flex items-center justify-between font-bold text-amber-900">
                        <span>Rollover Simulation Summary</span>
                        <span id="rolloverResultCount" class="text-[11px] bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full">0 Records</span>
                    </div>
                    <div id="rolloverResultSummary" class="text-slate-700 font-medium text-xs"></div>
                    <div class="max-h-48 overflow-y-auto border border-slate-200 rounded-xl bg-white">
                        <table class="w-full text-left text-[11px]">
                            <thead class="bg-slate-50 text-slate-500 font-bold border-b border-slate-100 sticky top-0">
                                <tr>
                                    <th class="p-2">Employee</th>
                                    <th class="p-2">Category</th>
                                    <th class="p-2 text-right">Carry Fwd</th>
                                    <th class="p-2 text-right">Expired</th>
                                </tr>
                            </thead>
                            <tbody id="rolloverResultTableBody" class="divide-y divide-slate-100 font-mono"></tbody>
                        </table>
                    </div>
                </div>

                <!-- Reopen Closed Fiscal Year Card -->
                <?php if (!empty($canReopenYear)): ?>
                <div class="pt-4 border-t border-slate-100 space-y-3">
                    <div class="flex items-center justify-between">
                        <h5 class="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                            <span>🔓 Reopen Finalized / Closed Leave Year</span>
                        </h5>
                        <span class="text-[10px] text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded font-mono font-bold">Audit Protected</span>
                    </div>
                    <p class="text-[11px] text-slate-500">
                        Reopen a closed leave year to apply late adjustments. Requires mandatory audit reason.
                    </p>
                    <form id="reopenYearForm" method="POST" action="<?= base_url('leave/reopen-year') ?>" class="space-y-3">
                        <?= csrf_field() ?>
                        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            <div>
                                <label class="block text-[11px] font-bold text-slate-700 mb-1">Fiscal Year</label>
                                <input type="number" name="year" id="reopen_year_input" value="<?= (int)date('Y') - 1 ?>" required class="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-rose-500">
                            </div>
                            <div class="sm:col-span-2">
                                <label class="block text-[11px] font-bold text-slate-700 mb-1">Reason for Reopening <span class="text-rose-500">*</span></label>
                                <input type="text" name="reason" id="reopen_reason_input" placeholder="e.g. Audit correction for medical leave adjustments" required class="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-1 focus:ring-rose-500">
                            </div>
                        </div>
                        <div class="flex justify-end">
                            <button type="submit" onclick="return confirm('Reopen closed leave year? This action is logged permanently in the audit trail.')" class="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm">
                                <span>🔓 Reopen Closed Year</span>
                            </button>
                        </div>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- ==================== TAB 4: LEAVE BALANCES & AUDIT LEDGER ==================== -->
    <div id="tab-content-ledger" class="tab-content hidden space-y-6">
        
        <!-- Live Balance Quota Checker Section -->
        <div class="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 pb-4 gap-3">
                <div>
                    <h3 class="font-bold text-slate-900 text-sm">Employee Leave Balances & Entitlement Overview</h3>
                    <p class="text-[11px] text-slate-500">Formula: <code class="bg-slate-100 px-1.5 py-0.5 rounded font-mono text-[10px] text-slate-700">Available = Opening + Allocation + Accrual + Carry Forward - Approved - Pending - Unpaid - Encashed</code></p>
                </div>

                <div class="flex items-center gap-3">
                    <!-- Employee switcher -->
                    <form method="GET" action="<?= base_url('leave') ?>" class="flex items-center gap-2">
                        <input type="hidden" name="tab" value="ledger">
                        <label class="text-xs font-bold text-slate-500 whitespace-nowrap">View Employee:</label>
                        <select name="emp_id" onchange="this.form.submit()" class="text-xs font-bold p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500 min-w-[220px]">
                            <?php if (empty($employees)): ?>
                                <option value="">No company employees found</option>
                            <?php else: ?>
                                <?php foreach ($employees as $e): ?>
                                    <?php 
                                        $empDisplayName = trim(($e['first_name'] ?? '') . ' ' . ($e['last_name'] ?? '')) ?: ($e['name'] ?? $e['id']);
                                        $empCode = $e['employee_code'] ?? $e['id'];
                                        $empDept = !empty($e['department_name']) ? ' • ' . $e['department_name'] : '';
                                        $isSel = (isset($selectedBalanceEmpId) && $selectedBalanceEmpId === $e['id']);
                                    ?>
                                    <option value="<?= esc($e['id']) ?>" <?= $isSel ? 'selected' : '' ?>>
                                        <?= esc($empDisplayName) ?> (<?= esc($empCode) ?><?= esc($empDept) ?>)
                                    </option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </form>

                    <?php if (!empty($canAdjustBalance)): ?>
                    <button type="button" onclick="openAdjustModal('<?= esc($selectedBalanceEmpId ?? '') ?>')" class="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm whitespace-nowrap">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                        Adjust Balance
                    </button>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Balances Grid -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-5">
                <?php foreach ($employeeBalances as $bal): ?>
                    <?php 
                        $open = (float)($bal['opening_balance'] ?? 0);
                        $alloc = (float)($bal['allocated_days'] ?? 0);
                        $acc = (float)($bal['accrued_days'] ?? 0);
                        $cf = (float)($bal['carry_forward_days'] ?? 0);
                        $appr = (float)($bal['approved_leave_days'] ?? 0);
                        $pend = (float)($bal['pending_leave_days'] ?? 0);
                        $unpaid = (float)($bal['unpaid_adjustment_days'] ?? 0);
                        $encash = (float)($bal['encashed_days'] ?? 0);

                        $totalEnt = isset($bal['total_entitlement']) ? (float)$bal['total_entitlement'] : ($open + $alloc + $cf);
                        $totalDeductions = $appr + $pend + $unpaid + $encash;
                        $available = (float)($bal['available_balance'] ?? max(0.0, $totalEnt - $totalDeductions));
                        $usedPercent = $totalEnt > 0 ? min(100, round((($appr + $pend + $encash) / $totalEnt) * 100)) : 0;
                        $isPaid = !empty($bal['is_paid']);
                    ?>
                    <div class="bg-white border border-slate-200/90 hover:border-indigo-200 rounded-2xl p-5 shadow-xs transition space-y-4 relative overflow-hidden">
                        <!-- Top Header -->
                        <div class="flex justify-between items-start">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center font-black text-indigo-700 font-mono text-sm shadow-2xs">
                                    <?= esc($bal['type_code'] ?? 'LV') ?>
                                </div>
                                <div>
                                    <h4 class="font-bold text-slate-900 text-sm leading-snug"><?= esc($bal['type_name'] ?? 'Leave') ?></h4>
                                    <span class="text-[10px] text-slate-400 font-medium">Annual Quota & Entitlement</span>
                                </div>
                            </div>
                            <span class="px-2.5 py-1 rounded-full text-[10px] font-bold <?= $isPaid ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/60' : 'bg-amber-50 text-amber-700 border border-amber-200/60' ?>">
                                <?= $isPaid ? 'Paid' : 'Loss of Pay' ?>
                            </span>
                        </div>

                        <!-- Available Summary Callout -->
                        <div class="p-3.5 bg-slate-50 border border-slate-100 rounded-xl flex items-baseline justify-between">
                            <div>
                                <span class="text-xs text-slate-500 font-bold uppercase tracking-wider block">Available Balance</span>
                                <div class="flex items-baseline gap-1 mt-0.5">
                                    <span class="text-2xl font-black text-slate-900 font-mono"><?= esc($available) ?></span>
                                    <span class="text-slate-400 text-xs font-semibold"> / <?= esc($totalEnt) ?> days</span>
                                </div>
                            </div>
                            <span class="text-[11px] font-bold text-indigo-600 bg-indigo-50/80 border border-indigo-100 px-2.5 py-1 rounded-lg">
                                <?= esc($available) ?> Net Free
                            </span>
                        </div>

                        <!-- Progress Bar -->
                        <div class="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                            <div class="bg-indigo-600 h-1.5 rounded-full transition-all" style="width: <?= $usedPercent ?>%"></div>
                        </div>

                        <!-- 3-Column Deductions / Status Row -->
                        <div class="grid grid-cols-3 gap-2 pt-2 text-center border-t border-slate-100">
                            <div class="bg-slate-50/80 p-2 rounded-xl border border-slate-100">
                                <span class="text-slate-400 block text-[10px] font-semibold">Approved</span>
                                <span class="font-bold text-slate-800 font-mono text-xs"><?= esc($appr) ?>d</span>
                            </div>
                            <div class="bg-amber-50/50 p-2 rounded-xl border border-amber-100">
                                <span class="text-amber-600/80 block text-[10px] font-semibold">Pending</span>
                                <span class="font-bold text-amber-700 font-mono text-xs"><?= esc($pend) ?>d</span>
                            </div>
                            <div class="bg-slate-50/80 p-2 rounded-xl border border-slate-100">
                                <span class="text-slate-400 block text-[10px] font-semibold">Encashed</span>
                                <span class="font-bold text-slate-800 font-mono text-xs"><?= esc($encash) ?>d</span>
                            </div>
                        </div>

                        <!-- Formula Component Breakdown Accordion / Pills -->
                        <div class="pt-1 text-[10px] text-slate-500 border-t border-slate-100 flex flex-wrap items-center justify-between gap-1">
                            <span title="Opening: <?= $open ?>d | Alloc: <?= $alloc ?>d | Accrual: <?= $acc ?>d | CF: <?= $cf ?>d" class="text-slate-400">
                                Entitlement: <strong class="text-slate-700 font-mono"><?= $totalEnt ?>d</strong>
                            </span>
                            <span title="Approved: <?= $appr ?>d + Pending: <?= $pend ?>d + Unpaid: <?= $unpaid ?>d + Encashed: <?= $encash ?>d" class="text-slate-400">
                                Deductions: <strong class="text-rose-600 font-mono"><?= $totalDeductions ?>d</strong>
                            </span>
                        </div>

                        <?php if (!empty($canAdjustBalance)): ?>
                            <div class="pt-2">
                                <button type="button" onclick="openAdjustModal('<?= esc($selectedBalanceEmpId ?? '') ?>', '<?= esc($bal['leave_type_id'] ?? '') ?>')" class="w-full py-1.5 px-3 bg-slate-50 hover:bg-indigo-50 hover:text-indigo-600 border border-slate-200 hover:border-indigo-200 rounded-xl text-xs font-bold text-slate-600 transition text-center flex items-center justify-center gap-1.5">
                                    <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                                    Adjust Quota
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-5">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 pb-4 gap-4">
                <div>
                    <h3 class="font-bold text-slate-900 text-sm">Leave Transaction & Balance Movement Ledger</h3>
                    <p class="text-[11px] text-slate-500">Immutable audit log of all accruals, carry forwards, debits, adjustments, and reversions.</p>
                </div>

                <!-- Ledger Filters -->
                <div class="flex flex-wrap items-center gap-2">
                    <select id="ledger_employee_filter" onchange="filterLedgerAjax()" class="text-xs font-bold p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500">
                        <option value="">All Employees</option>
                        <?php foreach ($employees as $e): ?>
                            <option value="<?= esc($e['id']) ?>"><?= esc(trim(($e['first_name'] ?? '') . ' ' . ($e['last_name'] ?? '')) ?: ($e['name'] ?? $e['id'])) ?></option>
                        <?php endforeach; ?>
                    </select>

                    <select id="ledger_type_filter" onchange="filterLedgerAjax()" class="text-xs font-bold p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500">
                        <option value="">All Categories</option>
                        <?php foreach ($leaveTypes as $lt): ?>
                            <option value="<?= esc($lt['id']) ?>"><?= esc($lt['name']) ?></option>
                        <?php endforeach; ?>
                    </select>

                    <button type="button" onclick="filterLedgerAjax()" class="px-3 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-xs font-bold transition">
                        🔄 Refresh
                    </button>
                </div>
            </div>

            <!-- Ledger Table -->
            <div class="border border-slate-100 rounded-2xl overflow-hidden text-xs">
                <div class="overflow-x-auto">
                    <table class="w-full text-left">
                        <thead class="bg-slate-50 text-[10px] text-slate-500 font-bold uppercase border-b border-slate-100">
                            <tr>
                                <th class="p-3">Date</th>
                                <th class="p-3">Employee</th>
                                <th class="p-3">Leave Category</th>
                                <th class="p-3">Transaction Type</th>
                                <th class="p-3 text-right">Delta (Days)</th>
                                <th class="p-3 text-right">Balance After</th>
                                <th class="p-3">Reference / Remarks</th>
                                <th class="p-3">Performed By</th>
                            </tr>
                        </thead>
                        <tbody id="ledgerTableBody" class="divide-y divide-slate-100">
                            <?php if (empty($recentLedger)): ?>
                                <tr>
                                    <td colspan="8" class="p-8 text-center text-slate-400 italic">No transaction records found in the current audit period.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($recentLedger as $tx): ?>
                                    <?php 
                                        $type = $tx['transaction_type'] ?? 'Adjustment';
                                        $isCredit = in_array($type, ['Accrual', 'Carry_Forward', 'Credit', 'Reversal']);
                                        $days = (float)($tx['days'] ?? 0);
                                    ?>
                                    <tr class="hover:bg-slate-50/50">
                                        <td class="p-3 font-mono text-slate-600 whitespace-nowrap"><?= esc(substr($tx['transaction_date'] ?? $tx['created_at'] ?? '', 0, 10)) ?></td>
                                        <td class="p-3 font-bold text-slate-800 whitespace-nowrap">
                                            <?= esc(trim(($tx['first_name'] ?? '') . ' ' . ($tx['last_name'] ?? '')) ?: ($tx['employee_name'] ?? $tx['employee_id'] ?? 'Staff')) ?>
                                            <span class="text-[10px] text-slate-400 font-mono block"><?= esc($tx['employee_code'] ?? '') ?></span>
                                        </td>
                                        <td class="p-3 font-medium text-slate-700 whitespace-nowrap"><?= esc($tx['leave_type_name'] ?? 'Leave') ?></td>
                                        <td class="p-3 whitespace-nowrap">
                                            <span class="px-2.5 py-1 rounded-full text-[10px] font-bold <?= $isCredit ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/60' : 'bg-rose-50 text-rose-700 border border-rose-200/60' ?>">
                                                <?= esc($type) ?>
                                            </span>
                                        </td>
                                        <td class="p-3 text-right font-mono font-bold whitespace-nowrap <?= $isCredit ? 'text-emerald-600' : 'text-rose-600' ?>">
                                            <?= $isCredit ? '+' : '-' ?><?= esc(abs($days)) ?>d
                                        </td>
                                        <td class="p-3 text-right font-mono font-bold text-slate-900 whitespace-nowrap">
                                            <?= esc($tx['balance_after'] ?? '—') ?>d
                                        </td>
                                        <td class="p-3 text-slate-500 max-w-xs truncate" title="<?= esc($tx['remarks'] ?? '') ?>">
                                            <?= esc($tx['remarks'] ?? '—') ?>
                                        </td>
                                        <td class="p-3 text-slate-400 text-[11px] whitespace-nowrap"><?= esc($tx['created_by'] ?? 'System') ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- ==================== TAB 2: DYNAMIC LEAVE TYPES ==================== -->
    <div id="tab-content-leaveTypes" class="tab-content hidden space-y-6">
        <div class="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 pb-4 gap-4">
                <div>
                    <h3 class="font-extrabold text-slate-900 text-base">Leave Categories (Master Identity)</h3>
                    <p class="text-xs text-slate-500 mt-0.5">Statutory leave categories. Quotas, accruals, carry-forward, sandwich rules, and approval tiers are governed in the Rule Engine.</p>
                </div>

                <button type="button" onclick="openLeaveTypeModal()" class="inline-flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold shadow-sm shadow-amber-500/20 transition">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                    + Create Leave Type
                </button>
            </div>

            <!-- Leave Types Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <?php if (empty($leaveTypes)): ?>
                    <div class="col-span-full bg-slate-50 border border-dashed border-slate-200 p-8 rounded-2xl text-center space-y-2">
                        <span class="text-2xl block">📁</span>
                        <h4 class="font-bold text-slate-700 text-sm">No Leave Types Configured</h4>
                        <p class="text-xs text-slate-500 max-w-md mx-auto">Click "+ Create Leave Type" above to add statutory leave categories.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($leaveTypes as $lt): ?>
                        <?php 
                            $status = $lt['status'] ?? 'active';
                        ?>
                        <div class="bg-white border border-slate-200/90 hover:border-amber-300 rounded-2xl p-5 shadow-xs transition space-y-4 flex flex-col justify-between">
                            <div>
                                <div class="flex items-start justify-between">
                                    <div class="flex items-center gap-2.5">
                                        <div class="w-9 h-9 rounded-xl bg-amber-50 border border-amber-200/60 text-amber-700 font-bold flex items-center justify-center text-xs font-mono">
                                            <?= esc($lt['code'] ?? 'LV') ?>
                                        </div>
                                        <div>
                                            <h4 class="font-bold text-slate-900 text-sm"><?= esc($lt['name']) ?></h4>
                                            <div class="flex items-center gap-1.5 mt-0.5 flex-wrap">
                                                <span class="text-[10px] text-slate-400 font-mono"><?= esc($lt['code'] ?? 'LV') ?></span>
                                                <?php 
                                                    $appGender = $lt['applicable_gender'] ?? 'All';
                                                    if (strcasecmp($appGender, 'Female') === 0):
                                                ?>
                                                    <span class="px-1.5 py-0.2 rounded text-[9px] font-bold bg-pink-50 text-pink-700 border border-pink-200">Female Only</span>
                                                <?php elseif (strcasecmp($appGender, 'Male') === 0): ?>
                                                    <span class="px-1.5 py-0.2 rounded text-[9px] font-bold bg-blue-50 text-blue-700 border border-blue-200">Male Only</span>
                                                <?php else: ?>
                                                    <span class="px-1.5 py-0.2 rounded text-[9px] font-bold bg-slate-100 text-slate-600 border border-slate-200">All Genders</span>
                                                <?php endif; ?>
                                                <?php 
                                                    $isPaid = !empty($lt['is_paid']);
                                                ?>
                                                <span class="px-1.5 py-0.2 rounded text-[9px] font-bold <?= $isPaid ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-slate-100 text-slate-600 border border-slate-200' ?>">
                                                    <?= $isPaid ? 'Paid' : 'Unpaid (LOP)' ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold <?= strtolower($status) === 'active' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-slate-100 text-slate-600 border border-slate-200' ?>">
                                        <?= esc(ucfirst($status)) ?>
                                    </span>
                                </div>

                                <p class="text-xs text-slate-600 mt-2.5 min-h-[32px] line-clamp-2">
                                    <?= esc($lt['description'] ?? 'Standard statutory leave category.') ?>
                                </p>

                                <!-- Configured Policy Chips Grid -->
                                <div class="grid grid-cols-2 gap-2 my-2 text-[11px]">
                                    <div class="p-2 rounded-xl bg-slate-50 border border-slate-100 space-y-0.5">
                                        <span class="text-[10px] font-bold text-slate-400 block uppercase">Allocation</span>
                                        <span class="font-bold text-slate-800"><?= esc($lt['days_per_year'] ?? 0) ?> days/year</span>
                                    </div>
                                    <div class="p-2 rounded-xl bg-slate-50 border border-slate-100 space-y-0.5">
                                        <span class="text-[10px] font-bold text-slate-400 block uppercase">Accrual Mode</span>
                                        <span class="font-bold text-slate-800 truncate block" title="<?= esc($lt['accrual_mode'] ?? 'Fixed yearly days') ?>"><?= esc($lt['accrual_mode'] ?? 'Fixed yearly days') ?></span>
                                    </div>
                                    <div class="p-2 rounded-xl bg-slate-50 border border-slate-100 space-y-0.5">
                                        <span class="text-[10px] font-bold text-slate-400 block uppercase">Carry-Forward</span>
                                        <span class="font-bold text-slate-800">
                                            <?= !empty($lt['carry_forward_allowed']) ? ('Max ' . esc($lt['carry_forward_max_days'] ?? 0) . 'd (' . esc($lt['carry_forward_percentage'] ?? 100) . '%)') : 'None (Expires)' ?>
                                        </span>
                                    </div>
                                    <div class="p-2 rounded-xl bg-slate-50 border border-slate-100 space-y-0.5">
                                        <span class="text-[10px] font-bold text-slate-400 block uppercase">Approval Flow</span>
                                        <span class="font-bold <?= !empty($lt['is_auto_approved']) ? 'text-indigo-600' : 'text-slate-800' ?>">
                                            <?= !empty($lt['is_auto_approved']) ? 'Auto-Approved' : (!empty($lt['approval_required']) ? 'Multi-Tier Approval' : 'Direct Approval') ?>
                                        </span>
                                    </div>
                                </div>

                                <div class="p-2.5 rounded-xl bg-purple-50/70 border border-purple-200/60 text-xs flex items-center justify-between gap-2">
                                    <div class="flex items-center gap-1.5">
                                        <i data-lucide="shield" class="w-3.5 h-3.5 text-purple-600 shrink-0"></i>
                                        <span class="text-purple-900 font-semibold text-[11px]">
                                            Probation: <?= !empty($lt['probation_eligible']) ? '<strong class="text-emerald-700">Eligible</strong>' : '<strong class="text-slate-500">Blocked</strong>' ?>
                                        </span>
                                    </div>
                                    <?php if (!empty($canViewRules)): ?>
                                    <a href="<?= base_url('rules?domain=LEAVE') ?>" class="text-indigo-600 font-bold hover:underline flex items-center gap-1 text-[11px]">
                                        Configure &rarr;
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="flex items-center justify-between pt-3 border-t border-slate-100 text-xs">
                                <span class="text-[10px] text-slate-400">Status: <strong class="text-slate-700 capitalize"><?= esc($status) ?></strong></span>
                                <div class="flex items-center gap-2">
                                    <button type="button" onclick='editLeaveType(<?= json_encode($lt, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>)' class="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg font-bold text-xs transition">
                                        Edit
                                    </button>
                                    <form method="POST" action="<?= base_url('leave/type/delete/' . $lt['id']) ?>" onsubmit="return confirm('Delete this leave category?')" class="inline">
                                        <?= csrf_field() ?>
                                        <button type="submit" class="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg font-bold text-xs transition">
                                            Delete
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- ==================== TAB 5: REPORTS & EXPORT ==================== -->
    <div id="tab-content-reports" class="tab-content hidden space-y-6">
        <div class="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 pb-4 gap-4">
                <div>
                    <h3 class="font-bold text-slate-800 text-sm">Leave Analytics & Department Utilization Report</h3>
                    <p class="text-[11px] text-slate-500">Department-wise absence utilization, approved day counts, and export tools.</p>
                </div>

                <div class="flex items-center gap-2">
                    <button onclick="window.print()" class="px-3.5 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5">
                        <svg class="w-3.5 h-3.5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
                        Print Report
                    </button>
                    <a href="<?= base_url('leave/export') ?>" class="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                        Download Full CSV
                    </a>
                </div>
            </div>

            <!-- Department Utilization Table -->
            <div class="border border-slate-100 rounded-xl overflow-hidden text-xs">
                <table class="w-full text-left">
                    <thead class="bg-slate-50 text-[10px] text-slate-500 font-bold uppercase border-b border-slate-100">
                        <tr>
                            <th class="p-3">Department</th>
                            <th class="p-3">Total Requests</th>
                            <th class="p-3">Approved Days</th>
                            <th class="p-3">Pending Days</th>
                            <th class="p-3">Utilization Rate</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php foreach ($departments as $dept): ?>
                            <?php 
                                $deptApps = array_filter($applications, fn($a) => ($a['department_name'] ?? '') === $dept['name']);
                                $apprDays = 0;
                                $pendDays = 0;
                                foreach ($deptApps as $da) {
                                    if (($da['status'] ?? '') === 'Approved') $apprDays += (float)($da['total_days'] ?? 1);
                                    if (($da['status'] ?? '') === 'Pending') $pendDays += (float)($da['total_days'] ?? 1);
                                }
                            ?>
                            <tr class="hover:bg-slate-50/50">
                                <td class="p-3 font-bold text-slate-800"><?= esc($dept['name']) ?></td>
                                <td class="p-3 font-mono"><?= count($deptApps) ?></td>
                                <td class="p-3 font-mono font-bold text-emerald-700"><?= $apprDays ?> days</td>
                                <td class="p-3 font-mono text-amber-600"><?= $pendDays ?> days</td>
                                <td class="p-3">
                                    <div class="w-24 bg-slate-100 rounded-full h-1.5 overflow-hidden">
                                        <div class="bg-indigo-600 h-1.5 rounded-full" style="width: <?= min(100, $apprDays * 5) ?>%"></div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Comprehensive 18 Leave Management Reports Grid (#23 to #40) -->
            <div class="pt-6 border-t border-slate-100">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <h4 class="font-bold text-slate-800 text-sm flex items-center gap-2">
                            <span class="w-2.5 h-2.5 rounded-full bg-indigo-600"></span>
                            Leave Management Reports Catalog (#23 - #40)
                        </h4>
                        <p class="text-[11px] text-slate-500">Official statutory registers, balance statements, encashment, accruals, and compliance audits with instant PDF and CSV exports.</p>
                    </div>
                    <a href="<?= base_url('reports?type=leave_application_register') ?>" class="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1">
                        Go to Reports Hub &rarr;
                    </a>
                </div>

                <?php
                $leaveReportsGrid = [
                    ['num' => 23, 'code' => 'leave_application_register', 'title' => 'Leave Application Register', 'desc' => 'Master register of all leave applications, dates, durations, and statuses.'],
                    ['num' => 24, 'code' => 'pending_leave_approval', 'title' => 'Pending Leave Approval', 'desc' => 'Applications awaiting managerial review, aging days, and designated approvers.'],
                    ['num' => 25, 'code' => 'approved_leave_report', 'title' => 'Approved Leave Report', 'desc' => 'All authorized leaves with duration, approver details, and approval timestamps.'],
                    ['num' => 26, 'code' => 'rejected_leave_report', 'title' => 'Rejected Leave Report', 'desc' => 'Audit log of rejected leave requests with formal rejection justifications.'],
                    ['num' => 27, 'code' => 'cancelled_leave_report', 'title' => 'Cancelled Leave Report', 'desc' => 'Withdrawn or cancelled leaves with timestamps, cancelled by, and reasons.'],
                    ['num' => 28, 'code' => 'employee_leave_balance', 'title' => 'Employee Leave Balance', 'desc' => 'Opening, earned, utilized, pending, and net available balances per employee.'],
                    ['num' => 29, 'code' => 'leave_ledger', 'title' => 'Leave Ledger', 'desc' => 'Granular chronological debit/credit transactions with balance tracking.'],
                    ['num' => 30, 'code' => 'leave_type_summary', 'title' => 'Leave Type Summary', 'desc' => 'Company-wide quota utilization across Paid and Unpaid leave classifications.'],
                    ['num' => 31, 'code' => 'department_leave_calendar', 'title' => 'Department Leave Calendar', 'desc' => 'Departmental leave schedules, staffing coverage, and daily presence.'],
                    ['num' => 32, 'code' => 'branch_leave_calendar', 'title' => 'Branch Leave Calendar', 'desc' => 'Branch-wise workforce leave schedules, headcount, and availability ratios.'],
                    ['num' => 33, 'code' => 'leave_encashment_report', 'title' => 'Leave Encashment Report', 'desc' => 'Monetary calculations of encashable balances, daily basic rates, and payouts.'],
                    ['num' => 34, 'code' => 'leave_accrual_report', 'title' => 'Leave Accrual Report', 'desc' => 'Periodic monthly/annual leave accrual schedule, caps, and service progression.'],
                    ['num' => 35, 'code' => 'carry_forward_report', 'title' => 'Carry-forward Report', 'desc' => 'Annual year-end carry-over audit, statutory limits, and lapsed balance log.'],
                    ['num' => 36, 'code' => 'loss_of_pay_report', 'title' => 'Loss of Pay (LOP) Report', 'desc' => 'Unpaid leaves, unexcused absence days, daily rate, and salary deductions.'],
                    ['num' => 37, 'code' => 'probation_leave_eligibility', 'title' => 'Probation Leave Eligibility', 'desc' => 'Probationary employee leave entitlement, waiting restrictions, and policy rules.'],
                    ['num' => 38, 'code' => 'leave_policy_compliance', 'title' => 'Leave Policy Compliance', 'desc' => 'Advance notice checks, sandwich rule impact, and consecutive day limits.'],
                    ['num' => 39, 'code' => 'leave_overlap_conflict', 'title' => 'Leave Overlap / Conflict Report', 'desc' => 'Simultaneous leave conflicts within teams, shift shortages, and risk scoring.'],
                    ['num' => 40, 'code' => 'leave_approval_history', 'title' => 'Leave Approval History', 'desc' => 'Complete approval workflow audit log, timestamps, and turnaround hours.'],
                ];
                ?>

                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
                    <?php foreach ($leaveReportsGrid as $lr): ?>
                        <div class="border border-slate-200/80 rounded-xl p-3.5 bg-slate-50/50 hover:bg-white hover:border-indigo-300 hover:shadow-xs transition flex flex-col justify-between">
                            <div>
                                <div class="flex items-center justify-between gap-2 mb-1.5">
                                    <span class="px-2 py-0.5 rounded-md text-[10px] font-bold bg-indigo-100 text-indigo-700">
                                        #<?= $lr['num'] ?>
                                    </span>
                                    <span class="text-[10px] text-slate-400 font-medium">Certified Audit</span>
                                </div>
                                <h5 class="font-bold text-slate-900 text-xs leading-snug"><?= esc($lr['title']) ?></h5>
                                <p class="text-[11px] text-slate-500 mt-1 line-clamp-2 leading-relaxed"><?= esc($lr['desc']) ?></p>
                            </div>
                            <div class="flex items-center gap-1.5 mt-3 pt-2.5 border-t border-slate-200/60">
                                <a href="<?= base_url('reports?type=' . $lr['code']) ?>" class="flex-1 text-center py-1.5 px-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-semibold rounded-lg text-[11px] transition">
                                    View
                                </a>
                                <a href="<?= base_url('reports/print-view?type=' . $lr['code'] . '&download=pdf') ?>" target="_blank" class="py-1.5 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg text-[11px] transition flex items-center gap-1" title="Export PDF">
                                    <svg class="w-3 h-3 text-red-500" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z" clip-rule="evenodd"/></svg>
                                    PDF
                                </a>
                                <a href="<?= base_url('reports?type=' . $lr['code'] . '&export=csv') ?>" class="py-1.5 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg text-[11px] transition flex items-center gap-1" title="Download CSV">
                                    <svg class="w-3 h-3 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                                    CSV
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- ==================== TAB 7: ELIGIBILITY & QUOTA SANDBOX SIMULATOR ==================== -->
    <div id="tab-content-simulator" class="tab-content space-y-6 hidden">
        <!-- Top Banner -->
        <div class="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
                <div class="flex items-center gap-2">
                    <h2 class="text-lg font-bold text-slate-900">
                        Interactive Leave Eligibility & Quota Sandbox
                    </h2>
                    <span class="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-teal-100 text-teal-800">
                        Real-Time Simulation
                    </span>
                </div>
                <p class="text-xs text-slate-500 mt-1 max-w-2xl">
                    Simulate leave applications across any employee profile. Test date spans, sandwich rules, probation criteria, multi-tier approvals, overdraft caps, and payroll impact before submission.
                </p>
            </div>
        </div>

        <?php if (empty($employees) || empty($leaveTypes)): ?>
            <div class="p-12 text-center text-slate-500 bg-white rounded-2xl border border-slate-200">
                <svg class="w-8 h-8 text-teal-500 mx-auto mb-2 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                <p class="text-sm">Please create at least one employee and leave type to activate the sandbox simulator.</p>
            </div>
        <?php else: ?>
            <!-- Simulator Inputs & Result Layout -->
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
                <!-- Left Config Panel (5 Cols) -->
                <div class="lg:col-span-5 space-y-4">
                    <div class="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
                        <h3 class="text-sm font-bold text-slate-900 flex items-center gap-2">
                            <svg class="w-4 h-4 text-teal-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                            Employee & Leave Selection
                        </h3>

                        <!-- Employee Selector -->
                        <div>
                            <label class="block text-xs font-medium text-slate-700 mb-1">
                                Target Employee
                            </label>
                            <select
                                id="sim-select-emp"
                                onchange="onSimulatorInputChanged()"
                                class="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 focus:ring-2 focus:ring-teal-500 focus:outline-none font-medium"
                            >
                                <?php foreach ($employees as $emp): ?>
                                    <?php
                                        $empName = trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')) ?: ($emp['name'] ?? $emp['id']);
                                        $empCode = $emp['employee_code'] ?? $emp['id'];
                                        $empStatus = $emp['status'] ?? 'Active';
                                        $empDept = $emp['department_name'] ?? 'General';
                                        $empDesg = $emp['designation_title'] ?? $emp['designation_name'] ?? 'Staff';
                                        $empJoin = employee_joining_date($emp) ?? 'N/A';
                                        $empConfirm = $emp['confirm_date'] ?? $emp['confirmation_date'] ?? 'On Probation';
                                        $empBasic = isset($emp['basic_salary']) && $emp['basic_salary'] !== null ? (float)$emp['basic_salary'] : 0.0;
                                        $empGross = isset($emp['gross_salary']) && $emp['gross_salary'] !== null ? (float)$emp['gross_salary'] : 0.0;
                                    ?>
                                    <option
                                        value="<?= esc($emp['id']) ?>"
                                        data-dept="<?= esc($empDept) ?>"
                                        data-desg="<?= esc($empDesg) ?>"
                                        data-join="<?= esc($empJoin) ?>"
                                        data-confirm="<?= esc($empConfirm) ?>"
                                        data-basic="<?= esc($empBasic) ?>"
                                        data-gross="<?= esc($empGross) ?>"
                                    >
                                        <?= esc($empName) ?> (<?= esc($empCode) ?>) - <?= esc($empStatus) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Employee Profile Preview Badge -->
                        <div class="bg-slate-50 p-3 rounded-xl text-xs space-y-1.5 border border-slate-100">
                            <div class="flex justify-between">
                                <span class="text-slate-500">Department / Designation:</span>
                                <span id="sim-preview-dept-desg" class="font-semibold text-slate-800">General • Staff</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-slate-500">Joining / Confirmation:</span>
                                <span id="sim-preview-join-conf" class="font-semibold text-slate-800">N/A • On Probation</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-slate-500">Basic / Gross Salary:</span>
                                <span id="sim-preview-salary" class="font-semibold text-slate-800">30,000 / 45,000</span>
                            </div>
                        </div>

                        <!-- Leave Type Selector -->
                        <div>
                            <label class="block text-xs font-medium text-slate-700 mb-1">
                                Leave Type
                            </label>
                            <select
                                id="sim-select-leave-type"
                                onchange="onSimulatorInputChanged()"
                                class="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 focus:ring-2 focus:ring-teal-500 focus:outline-none font-medium"
                            >
                                <?php foreach ($leaveTypes as $lt): ?>
                                    <?php $isLtPaid = !empty($lt['is_paid']); ?>
                                    <option value="<?= esc($lt['id']) ?>" data-paid="<?= $isLtPaid ? '1' : '0' ?>" data-days="<?= esc($lt['days_per_year'] ?? 10) ?>">
                                        <?= esc($lt['name']) ?> (<?= esc($lt['code'] ?? 'LV') ?>) - <?= $isLtPaid ? 'Paid' : 'Unpaid (LOP)' ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Current Balance Card -->
                        <div class="bg-teal-50 p-3 rounded-xl border border-teal-100 flex items-center justify-between">
                            <div>
                                <div class="text-[11px] text-teal-700 font-medium">Available Quota Balance</div>
                                <div id="sim-current-balance" class="text-lg font-extrabold text-teal-900">-- Days</div>
                            </div>
                            <div id="sim-annual-allocation" class="text-right text-[11px] text-teal-600">
                                Annual Allocation: --d
                            </div>
                        </div>
                    </div>

                    <!-- Date & Options Configuration -->
                    <div class="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
                        <h3 class="text-sm font-bold text-slate-900 flex items-center gap-2">
                            <svg class="w-4 h-4 text-teal-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                            Date Range & Options
                        </h3>

                        <div class="grid grid-cols-2 gap-3">
                            <div>
                                <label class="block text-xs font-medium text-slate-700 mb-1">From Date</label>
                                <input
                                    id="sim-input-start-date"
                                    type="date"
                                    value="<?= date('Y-m-d') ?>"
                                    onchange="onSimulatorStartDateChanged()"
                                    class="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 focus:ring-2 focus:ring-teal-500 focus:outline-none font-mono"
                                />
                            </div>
                            <div>
                                <label class="block text-xs font-medium text-slate-700 mb-1">To Date</label>
                                <input
                                    id="sim-input-end-date"
                                    type="date"
                                    value="<?= date('Y-m-d') ?>"
                                    onchange="onSimulatorInputChanged()"
                                    class="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 focus:ring-2 focus:ring-teal-500 focus:outline-none font-mono"
                                />
                            </div>
                        </div>

                        <!-- Half-Day & Hourly Toggles -->
                        <div class="grid grid-cols-2 gap-3 pt-2">
                            <label class="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer text-xs">
                                <input
                                    id="sim-toggle-half-day"
                                    type="checkbox"
                                    onchange="onSimulatorHalfDayToggled(this.checked)"
                                    class="rounded text-teal-600 focus:ring-teal-500 w-4 h-4"
                                />
                                <span class="font-medium text-slate-800">Half-Day (0.5d)</span>
                            </label>

                            <label class="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer text-xs">
                                <input
                                    id="sim-toggle-hourly"
                                    type="checkbox"
                                    onchange="onSimulatorHourlyToggled(this.checked)"
                                    class="rounded text-teal-600 focus:ring-teal-500 w-4 h-4"
                                />
                                <span class="font-medium text-slate-800">Hourly Leave</span>
                            </label>
                        </div>

                        <div id="sim-hourly-slider-container" class="hidden p-3 bg-slate-50 rounded-xl space-y-1">
                            <div class="flex justify-between text-xs">
                                <span class="text-slate-500">Duration in Hours:</span>
                                <span id="sim-hours-label" class="font-bold text-teal-600">4 Hours (0.50d)</span>
                            </div>
                            <input
                                id="sim-slider-hours"
                                type="range"
                                min="1"
                                max="8"
                                value="4"
                                oninput="onSimulatorHoursChanged(this.value)"
                                class="w-full accent-teal-600 cursor-pointer"
                            />
                        </div>

                        <!-- Medical & Attachment Toggles -->
                        <div class="space-y-2 pt-1">
                            <label class="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                                <input
                                    id="sim-toggle-med-cert"
                                    type="checkbox"
                                    onchange="onSimulatorInputChanged()"
                                    class="rounded text-teal-600 focus:ring-teal-500 w-4 h-4"
                                />
                                <span>Attached Medical Certificate / Doctor Prescription</span>
                            </label>
                            <label class="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                                <input
                                    id="sim-toggle-attachment"
                                    type="checkbox"
                                    onchange="onSimulatorInputChanged()"
                                    class="rounded text-teal-600 focus:ring-teal-500 w-4 h-4"
                                />
                                <span>Attached General Supporting Document</span>
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Right Simulation Analytics Output (7 Cols) -->
                <div class="lg:col-span-7 space-y-4">
                    <!-- Validation Status Banner -->
                    <div id="sim-validation-banner" class="p-4 rounded-2xl border flex items-start gap-3 bg-slate-50 border-slate-200 text-slate-700 transition-all duration-200">
                        <div id="sim-validation-icon" class="mt-0.5 flex-shrink-0">
                            <svg class="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                        </div>
                        <div class="space-y-1 text-xs flex-1">
                            <div id="sim-validation-title" class="font-bold text-sm">
                                Ready to Simulate
                            </div>
                            <div id="sim-validation-errors" class="space-y-1"></div>
                            <div id="sim-validation-warnings" class="space-y-1"></div>
                        </div>
                    </div>

                    <!-- Metric Cards Grid -->
                    <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
                        <div class="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
                            <div class="text-[11px] text-slate-500 font-medium">Chargeable Days</div>
                            <div id="sim-metric-chargeable-days" class="text-2xl font-extrabold text-teal-600 mt-1">
                                -- Days
                            </div>
                            <div id="sim-metric-working-days" class="text-[10px] text-slate-400 mt-1">-- working days</div>
                        </div>

                        <div class="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
                            <div class="text-[11px] text-slate-500 font-medium">Projected Balance</div>
                            <div id="sim-metric-projected-balance" class="text-2xl font-extrabold text-slate-900 mt-1">
                                -- Days
                            </div>
                            <div id="sim-metric-initial-balance" class="text-[10px] text-slate-400 mt-1">From --d initial</div>
                        </div>

                        <div class="bg-white rounded-xl p-4 border border-slate-200 shadow-sm col-span-2 sm:col-span-1">
                            <div class="text-[11px] text-slate-500 font-medium">Sandwich Rule</div>
                            <div id="sim-metric-sandwich-badge" class="text-lg font-bold text-slate-900 mt-1 flex items-center gap-1.5">
                                <span class="text-slate-400 font-normal">Standard (0d)</span>
                            </div>
                            <div class="text-[10px] text-slate-400 mt-1">Intervening weekend span</div>
                        </div>
                    </div>

                    <!-- Breakdown & Scope Resolution Details -->
                    <div class="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4 text-xs">
                        <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                            <div class="font-bold text-slate-900 flex items-center gap-2">
                                <svg class="w-4 h-4 text-teal-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
                                Policy Resolution Engine
                            </div>
                            <span id="sim-policy-scope-badge" class="px-2 py-0.5 rounded text-[11px] font-semibold bg-teal-50 text-teal-700">
                                Scope: Global
                            </span>
                        </div>

                        <div class="space-y-2">
                            <div class="flex justify-between">
                                <span class="text-slate-500">Active Policy Matched:</span>
                                <span id="sim-policy-name" class="font-semibold text-slate-800">Standard Company Policy (POL-STD)</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-slate-500">Day Breakdown:</span>
                                <span id="sim-span-breakdown" class="text-slate-700 font-mono text-[11px]">--</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-slate-500">Weekend & Holiday Treatment:</span>
                                <span id="sim-calendar-treatment" class="text-slate-700">Count weekly off as leave • Exclude public holidays</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-slate-500">Approval Workflow Tiers:</span>
                                <span id="sim-workflow-tiers" class="font-semibold text-teal-600">Manager &rarr; HR Admin</span>
                            </div>
                        </div>

                        <!-- Financial & Payroll Impact Box -->
                        <div class="bg-slate-50 p-4 rounded-xl space-y-2 border border-slate-100">
                            <div class="font-bold text-slate-800 flex items-center gap-2">
                                <svg class="w-4 h-4 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                                Financial & Payroll Impact Estimation
                            </div>
                            <div id="sim-financial-lop-row" class="text-xs">
                                <div class="flex items-center justify-between text-emerald-600 font-medium">
                                    <span>Paid Leave Status:</span>
                                    <span>100% Fully Paid (No Payroll Deductions)</span>
                                </div>
                            </div>
                            <div id="sim-financial-encash-row" class="hidden text-xs text-slate-600 pt-1 border-t border-slate-200 flex items-center justify-between">
                                <span>Equivalent Encashment Payout:</span>
                                <span id="sim-encash-amount" class="font-semibold text-slate-800">0 (Basic)</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- ==================== TAB 8: LEAVE LEDGER AUDIT & RECONCILIATION MATRIX ==================== -->
    <div id="tab-content-reconciliation" class="tab-content space-y-6 hidden">
        <!-- Top Control Banner -->
        <div class="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
                <div class="flex items-center gap-2">
                    <h2 class="text-lg font-bold text-slate-900">
                        Leave Ledger Audit &amp; Reconciliation Matrix
                    </h2>
                    <span class="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-teal-100 text-teal-800">
                        Deterministic Audit
                    </span>
                </div>
                <p class="text-xs text-slate-500 mt-1 max-w-xl">
                    Live mathematical verification comparing immutable transaction logs against quota allocations. Detects overdraws, missing openings, and ledger gaps.
                </p>
            </div>

            <div class="flex items-center gap-3">
                <button
                    type="button"
                    id="btn-leave-audit-repair-all"
                    onclick="triggerAutoReconcile()"
                    class="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-sm transition-all flex items-center gap-2"
                >
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                    <span id="recon-repair-btn-text">Audit &amp; Reconcile Ledgers</span>
                </button>
            </div>
        </div>

        <!-- Success/Alert Notice Banner -->
        <div id="recon-feedback-banner" class="hidden p-4 rounded-xl text-xs font-semibold flex items-center gap-2">
            <span id="recon-feedback-icon"></span>
            <span id="recon-feedback-message"></span>
        </div>

        <!-- Summary KPI Cards -->
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div class="bg-white rounded-xl p-4 border border-slate-200 shadow-xs">
                <div class="text-xs text-slate-500 font-medium">Total Quotas Audited</div>
                <div id="kpi-recon-total" class="text-xl font-bold text-slate-900 mt-0.5 font-mono">0</div>
            </div>
            <div class="bg-emerald-50 rounded-xl p-4 border border-emerald-200">
                <div class="text-xs text-emerald-600 font-medium">Optimal &amp; Balanced</div>
                <div id="kpi-recon-optimal" class="text-xl font-bold text-emerald-700 mt-0.5 font-mono">0</div>
            </div>
            <div class="bg-amber-50 rounded-xl p-4 border border-amber-200">
                <div class="text-xs text-amber-600 font-medium">Attention Required</div>
                <div id="kpi-recon-flagged" class="text-xl font-bold text-amber-700 mt-0.5 font-mono">0</div>
            </div>
            <div class="bg-rose-50 rounded-xl p-4 border border-rose-200">
                <div class="text-xs text-rose-600 font-medium">Overdrawn Quotas</div>
                <div id="kpi-recon-overdrawn" class="text-xl font-bold text-rose-700 mt-0.5 font-mono">0</div>
            </div>
        </div>

        <!-- Filter & Search Bar -->
        <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div class="flex flex-1 flex-col sm:flex-row sm:items-center gap-2">
                <div class="relative flex-1 max-w-xs">
                    <svg class="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                    <input
                        id="recon-search-input"
                        type="text"
                        placeholder="Search by staff name, ID, or leave type..."
                        oninput="filterReconciliationTable()"
                        class="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                    >
                </div>
                <select id="recon-dept-filter" onchange="loadReconciliationMatrix(1)" class="text-xs py-2 px-2.5 rounded-xl border border-slate-200 bg-white text-slate-700 focus:ring-2 focus:ring-teal-500 focus:outline-none">
                    <option value="all">All Departments</option>
                    <?php if (!empty($departments)): ?>
                        <?php foreach ($departments as $d): ?>
                            <option value="<?= esc($d['id']) ?>"><?= esc($d['name']) ?></option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
                <select id="recon-branch-filter" onchange="loadReconciliationMatrix(1)" class="text-xs py-2 px-2.5 rounded-xl border border-slate-200 bg-white text-slate-700 focus:ring-2 focus:ring-teal-500 focus:outline-none">
                    <option value="all">All Branches</option>
                    <?php if (!empty($branches)): ?>
                        <?php foreach ($branches as $b): ?>
                            <option value="<?= esc($b['id']) ?>"><?= esc($b['name']) ?></option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>

            <div class="flex items-center gap-1.5 overflow-x-auto">
                <button
                    type="button"
                    id="btn-recon-filter-all"
                    onclick="setReconFilter('all')"
                    class="px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all bg-teal-600 text-white"
                >
                    all
                </button>
                <button
                    type="button"
                    id="btn-recon-filter-flagged"
                    onclick="setReconFilter('flagged')"
                    class="px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all bg-slate-100 text-slate-600 hover:bg-slate-200"
                >
                    flagged
                </button>
                <button
                    type="button"
                    id="btn-recon-filter-overdrawn"
                    onclick="setReconFilter('overdrawn')"
                    class="px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all bg-slate-100 text-slate-600 hover:bg-slate-200"
                >
                    overdrawn
                </button>
                <button
                    type="button"
                    id="btn-recon-filter-optimal"
                    onclick="setReconFilter('optimal')"
                    class="px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all bg-slate-100 text-slate-600 hover:bg-slate-200"
                >
                    optimal
                </button>
            </div>
        </div>

        <!-- Reconciliation Table -->
        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs border-collapse">
                    <thead>
                        <tr class="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                            <th class="py-3 px-4">Employee</th>
                            <th class="py-3 px-4">Leave Type</th>
                            <th class="py-3 px-3 text-right">Opening</th>
                            <th class="py-3 px-3 text-right">Accrued</th>
                            <th class="py-3 px-3 text-right">Carry Fwd</th>
                            <th class="py-3 px-3 text-right">Used</th>
                            <th class="py-3 px-3 text-right">Encashed</th>
                            <th class="py-3 px-3 text-right font-bold text-teal-700">Balance</th>
                            <th class="py-3 px-4">Audit Status</th>
                        </tr>
                    </thead>
                    <tbody id="recon-table-body" class="divide-y divide-slate-100">
                        <tr>
                            <td colspan="9" class="text-center py-12 text-slate-400">
                                <div class="flex items-center justify-center gap-2">
                                    <svg class="w-4 h-4 animate-spin text-teal-600" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path></svg>
                                    Loading live ledger reconciliation matrix...
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <!-- Pagination Footer -->
            <div id="recon-pagination-bar" class="px-4 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-600">
                <div id="recon-pagination-info">Showing 0 of 0 records</div>
                <div class="flex items-center gap-1.5" id="recon-pagination-controls"></div>
            </div>
        </div>
    </div>

    <!-- ==================== MODAL: APPLY FOR LEAVE ==================== -->
    <div id="applyLeaveModal" class="modal-backdrop fixed inset-0 bg-slate-900/60 backdrop-blur-sm hidden items-center justify-center z-50 p-4">
        <div class="bg-white rounded-3xl p-6 max-w-lg w-full shadow-2xl border border-slate-200 space-y-4 max-h-[90vh] overflow-y-auto">
            <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 class="text-base font-bold text-slate-900">Submit Leave Application</h3>
                <button type="button" onclick="closeModal('applyLeaveModal')" class="text-slate-400 hover:text-slate-600 font-bold text-lg">&times;</button>
            </div>

            <form id="applyLeaveForm" method="POST" action="<?= base_url('leave/apply') ?>" enctype="multipart/form-data" class="space-y-4 text-xs">
                <?= csrf_field() ?>
                
                <!-- Employee select -->
                <div>
                    <label class="block font-bold text-slate-700 mb-1">Applicant Employee <span class="text-rose-500">*</span></label>
                    <select name="employee_id" id="apply_employee_id" onchange="filterLeaveCategoriesByGender(); updateApplicantBalance();" required class="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500 font-bold">
                        <?php if (empty($employees)): ?>
                            <option value="">No company employees found</option>
                        <?php else: ?>
                            <?php foreach ($employees as $e): ?>
                                <?php 
                                    $empDisplayName = trim(($e['first_name'] ?? '') . ' ' . ($e['last_name'] ?? '')) ?: ($e['name'] ?? $e['id']);
                                    $empCode = $e['employee_code'] ?? $e['id'];
                                    $empDept = !empty($e['department_name']) ? ' • ' . $e['department_name'] : '';
                                    $empGender = strtolower($e['gender'] ?? 'all');
                                    $isSel = (isset($selectedEmpId) && $selectedEmpId === $e['id']);
                                ?>
                                <option value="<?= esc($e['id']) ?>" data-gender="<?= esc($empGender) ?>" <?= $isSel ? 'selected' : '' ?>>
                                    <?= esc($empDisplayName) ?> (<?= esc($empCode) ?><?= esc($empDept) ?><?= !empty($e['gender']) ? ' • ' . ucfirst($e['gender']) : '' ?>)
                                </option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>

                <!-- Leave Type -->
                <div>
                    <div class="flex items-center justify-between mb-1">
                        <label class="block font-bold text-slate-700">Leave Category <span class="text-rose-500">*</span></label>
                        <span id="genderEligibilityNotice" class="hidden text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-200"></span>
                    </div>
                    <select name="leave_type_id" id="apply_leave_type_id" onchange="calculateLiveWorkingDays(); updateEmergencyCheckboxState();" required class="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500 font-bold">
                        <?php foreach ($leaveTypes as $lt): ?>
                            <?php 
                                $isLtPaid = !empty($lt['is_paid']); 
                                $appGen = $lt['applicable_gender'] ?? 'All';
                                $genBadge = '';
                                if (strcasecmp($appGen, 'Female') === 0) {
                                    $genBadge = ' [Female Only]';
                                } elseif (strcasecmp($appGen, 'Male') === 0) {
                                    $genBadge = ' [Male Only]';
                                }
                            ?>
                            <option value="<?= esc($lt['id']) ?>" data-gender="<?= esc($appGen) ?>" data-paid="<?= $isLtPaid ? '1' : '0' ?>" data-sandwich="<?= !empty($lt['sandwich_rule']) ? '1' : '0' ?>" data-allow-emergency="<?= !empty($lt['allow_emergency_absence']) ? '1' : '0' ?>">
                                <?= esc($lt['name']) ?> (<?= esc($lt['code'] ?? 'LV') ?>) - <?= $isLtPaid ? 'Paid' : 'Unpaid' ?><?= $genBadge ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Date Range -->
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">Start Date <span class="text-rose-500">*</span></label>
                        <input type="date" name="from_date" id="apply_from_date" value="<?= date('Y-m-d') ?>" onchange="calculateLiveWorkingDays()" required class="w-full p-2.5 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono">
                    </div>
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">End Date <span class="text-rose-500">*</span></label>
                        <input type="date" name="to_date" id="apply_to_date" value="<?= date('Y-m-d') ?>" onchange="calculateLiveWorkingDays()" required class="w-full p-2.5 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono">
                    </div>
                </div>

                <!-- Sandwich Warning Banner -->
                <div id="sandwichWarningBanner" class="p-3 bg-amber-50 border border-amber-200 rounded-xl hidden flex-col gap-1 text-amber-900">
                    <span class="font-bold text-xs flex items-center gap-1.5">🥪 Sandwich Weekend Rule Triggered</span>
                    <span class="text-[11px] text-amber-800">Leave spans Thursday to Sunday/Monday across the weekend. 2 weekend days will be added to the chargeable deduction count.</span>
                </div>

                <!-- Live working days preview banner -->
                <div id="workingDaysBanner" class="p-3 bg-indigo-50/70 border border-indigo-100 rounded-xl flex items-center justify-between text-indigo-900 font-bold">
                    <span class="text-[11px]">Total Chargeable Days:</span>
                    <span id="chargeableDaysCount" class="font-mono text-sm font-black text-indigo-700">1.0 Day</span>
                </div>

                <!-- Half day & Options -->
                <div class="flex flex-wrap items-center gap-4 pt-1">
                    <div class="flex items-center gap-2">
                        <label class="flex items-center gap-1.5 font-bold text-slate-700 cursor-pointer">
                            <input type="checkbox" name="is_half_day" id="apply_is_half_day" onchange="toggleHalfDaySelect(); calculateLiveWorkingDays()" value="1" class="rounded text-indigo-600 w-4 h-4">
                            Half-Day Leave (0.5d)
                        </label>
                        <select name="half_day" id="apply_half_day" class="hidden text-xs py-1 px-2 border border-slate-300 rounded-lg font-medium text-slate-700 bg-white">
                            <option value="First Half">First Half</option>
                            <option value="Second Half">Second Half</option>
                        </select>
                    </div>

                    <div class="flex items-center gap-2">
                        <label id="emergency_checkbox_wrapper" class="flex items-center gap-1.5 font-bold text-rose-700 cursor-pointer">
                            <input type="checkbox" name="is_emergency" id="apply_is_emergency" value="1" onchange="onEmergencyCheckboxChanged()" class="rounded text-rose-600 w-4 h-4">
                            <span id="emergency_checkbox_label">Emergency Absence</span>
                        </label>
                        <span id="emergency_disabled_notice" class="hidden text-[11px] text-slate-400 italic font-medium">(Restricted to HR/Managers for this category)</span>
                    </div>

                    <label class="flex items-center gap-1.5 font-bold text-amber-700 cursor-pointer">
                        <input type="checkbox" name="confirm_unpaid_split" id="apply_confirm_unpaid_split" value="1" class="rounded text-amber-600 w-4 h-4">
                        Split Shortage as Unpaid Leave (LOP)
                    </label>
                </div>

                <!-- Emergency Contact -->
                <div>
                    <label class="block font-bold text-slate-700 mb-1">Emergency Contact Phone / Details (Optional)</label>
                    <input type="text" name="emergency_contact" placeholder="+880 1700-000000" class="w-full p-2.5 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono">
                </div>

                <!-- Attachment Upload -->
                <div>
                    <label class="block font-bold text-slate-700 mb-1">Supporting Medical / Formal Attachment (Optional)</label>
                    <input type="file" name="attachment" accept=".pdf,.png,.jpg,.jpeg" class="w-full text-xs text-slate-500 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-slate-100 file:text-slate-700 hover:file:bg-slate-200">
                </div>

                <!-- Reason -->
                <div>
                    <label class="block font-bold text-slate-700 mb-1">Reason for Leave <span class="text-rose-500">*</span></label>
                    <textarea name="reason" rows="2" required placeholder="State official reason for leave request..." class="w-full p-2.5 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500"></textarea>
                </div>

                <div class="flex justify-end gap-2 pt-3 border-t border-slate-100">
                    <button type="button" onclick="closeModal('applyLeaveModal')" class="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold">Cancel</button>
                    <button type="submit" class="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold shadow-sm shadow-indigo-600/20">Submit Application</button>
                </div>

            </form>
        </div>
    </div>

    <!-- ==================== MODAL: TIER 1 ENDORSE ==================== -->
    <div id="endorseModal" class="modal-backdrop fixed inset-0 bg-slate-900/60 backdrop-blur-sm hidden items-center justify-center z-50 p-4">
        <div class="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4">
            <h3 id="endorse_modal_title" class="text-base font-bold text-slate-900">Tier 1: Manager Endorsement</h3>
            <p id="endorse_modal_desc" class="text-xs text-slate-500">Endorse this time-off request to forward it to HR for final sanction and balance debiting.</p>

            <form id="endorseForm" method="POST" action="" class="space-y-4 text-xs">
                <?= csrf_field() ?>
                <div class="p-3 bg-indigo-50 rounded-xl border border-indigo-100 text-indigo-900 font-bold">
                    Applicant: <span id="endorse_emp_name"></span>
                </div>

                <div>
                    <label id="endorse_remarks_label" class="block font-bold text-slate-700 mb-1">Manager Remarks / Coverage Notes</label>
                    <input type="text" name="remarks" placeholder="e.g. Work coverage arranged with team lead" class="w-full p-2.5 border border-slate-200 rounded-xl">
                </div>

                <div class="flex justify-end gap-2 pt-3 border-t border-slate-100">
                    <button type="button" onclick="closeModal('endorseModal')" class="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold">Cancel</button>
                    <button id="endorse_submit_btn" type="submit" class="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold shadow-sm">Confirm Endorsement</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ==================== MODAL: TIER 2 APPROVE ==================== -->
    <div id="approveModal" class="modal-backdrop fixed inset-0 bg-slate-900/60 backdrop-blur-sm hidden items-center justify-center z-50 p-4">
        <div class="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4">
            <h3 class="text-base font-bold text-slate-900">Tier 2: HR Final Approval</h3>
            <p class="text-xs text-slate-500">Approving will debit the quota balance ledger and automatically mark attendance logs as 'On Leave'.</p>

            <form id="approveForm" method="POST" action="" class="space-y-4 text-xs">
                <?= csrf_field() ?>
                <div class="p-3 bg-emerald-50 rounded-xl border border-emerald-100 text-emerald-900 font-bold">
                    Applicant: <span id="approve_emp_name"></span> (<span id="approve_days"></span> Days)
                </div>

                <div>
                    <label class="block font-bold text-slate-700 mb-1">HR Sanction Notes (Optional)</label>
                    <input type="text" name="remarks" placeholder="e.g., Approved as per annual quota policy" class="w-full p-2.5 border border-slate-200 rounded-xl">
                </div>

                <div class="flex justify-end gap-2 pt-3 border-t border-slate-100">
                    <button type="button" onclick="closeModal('approveModal')" class="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold">Cancel</button>
                    <button type="submit" class="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold shadow-sm">Confirm Final Approval</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ==================== MODAL: REJECT LEAVE ==================== -->
    <div id="rejectModal" class="modal-backdrop fixed inset-0 bg-slate-900/60 backdrop-blur-sm hidden items-center justify-center z-50 p-4">
        <div class="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4">
            <h3 class="text-base font-bold text-slate-900">Reject Leave Request</h3>
            <p class="text-xs text-slate-500">Specify the reason for rejecting this leave application.</p>

            <form id="rejectForm" method="POST" action="" class="space-y-4 text-xs">
                <?= csrf_field() ?>
                <div class="p-3 bg-rose-50 rounded-xl border border-rose-100 text-rose-900 font-bold">
                    Applicant: <span id="reject_emp_name"></span>
                </div>

                <div>
                    <label class="block font-bold text-slate-700 mb-1">Rejection Reason <span class="text-rose-500">*</span></label>
                    <textarea name="rejection_reason" rows="3" required placeholder="State operational justification for rejection..." class="w-full p-2.5 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-rose-500"></textarea>
                </div>

                <div class="flex justify-end gap-2 pt-3 border-t border-slate-100">
                    <button type="button" onclick="closeModal('rejectModal')" class="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold">Cancel</button>
                    <button type="submit" class="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold shadow-sm">Reject Application</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ==================== MODAL: CANCEL LEAVE ==================== -->
    <div id="cancelModal" class="modal-backdrop fixed inset-0 bg-slate-900/60 backdrop-blur-sm hidden items-center justify-center z-50 p-4">
        <div class="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4">
            <h3 class="text-base font-bold text-slate-900" id="cancel_modal_title">Cancel Leave Request</h3>
            <p class="text-xs text-slate-500" id="cancel_modal_desc">Provide mandatory cancellation reason to proceed.</p>

            <form id="cancelForm" method="POST" action="" class="space-y-4 text-xs">
                <?= csrf_field() ?>
                <div class="p-3 bg-amber-50 rounded-xl border border-amber-100 text-amber-900 font-bold">
                    Applicant: <span id="cancel_emp_name"></span>
                </div>

                <div>
                    <label class="block font-bold text-slate-700 mb-1">Cancellation Reason <span class="text-rose-500">*</span></label>
                    <textarea id="cancel_reason_input" name="reason" rows="3" required placeholder="State mandatory reason for withdrawal or cancellation..." class="w-full p-2.5 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-rose-500"></textarea>
                </div>

                <div class="flex justify-end gap-2 pt-3 border-t border-slate-100">
                    <button type="button" onclick="closeModal('cancelModal')" class="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold">Close</button>
                    <button type="submit" class="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold shadow-sm">Confirm Cancellation</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ==================== MODAL: ENCASHMENT ==================== -->
    <div id="encashModal" class="modal-backdrop fixed inset-0 bg-slate-900/60 backdrop-blur-sm hidden items-center justify-center z-50 p-4">
        <div class="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4">
            <h3 class="text-base font-bold text-slate-900">Process Leave Encashment</h3>
            <p class="text-xs text-slate-500">Encash accrued Earned Leave (AL) balance into monetary compensation: <code class="bg-slate-100 px-1 py-0.5 rounded font-mono text-[10px] text-slate-700">(Basic / 30) * Days</code>.</p>

            <form method="POST" action="<?= base_url('leave/encash') ?>" class="space-y-3.5 text-xs">
                <?= csrf_field() ?>
                <div>
                    <label class="block font-bold text-slate-700 mb-1">Employee</label>
                    <select name="employee_id" required class="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold">
                        <?php if (empty($employees)): ?>
                            <option value="">No company employees found</option>
                        <?php else: ?>
                            <?php foreach ($employees as $e): ?>
                                <?php 
                                    $empDisplayName = trim(($e['first_name'] ?? '') . ' ' . ($e['last_name'] ?? '')) ?: ($e['name'] ?? $e['id']);
                                    $empCode = $e['employee_code'] ?? $e['id'];
                                    $empDept = !empty($e['department_name']) ? ' • ' . $e['department_name'] : '';
                                    $isSel = (isset($selectedEmpId) && $selectedEmpId === $e['id']);
                                ?>
                                <option value="<?= esc($e['id']) ?>" <?= $isSel ? 'selected' : '' ?>>
                                    <?= esc($empDisplayName) ?> (<?= esc($empCode) ?><?= esc($empDept) ?>)
                                </option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>

                <div>
                    <label class="block font-bold text-slate-700 mb-1">Leave Category</label>
                    <select name="leave_type_id" required class="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold">
                        <?php foreach ($leaveTypes as $lt): ?>
                            <?php if (str_contains(strtolower($lt['name']), 'annual') || str_contains(strtolower($lt['name']), 'earned') || !empty($lt['encashment'])): ?>
                                <option value="<?= esc($lt['id']) ?>" selected><?= esc($lt['name'] ?? 'Earned Leave') ?> (<?= esc($lt['code'] ?? 'AL') ?>)</option>
                            <?php else: ?>
                                <option value="<?= esc($lt['id']) ?>"><?= esc($lt['name'] ?? 'Leave') ?> (<?= esc($lt['code'] ?? 'LV') ?>)</option>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block font-bold text-slate-700 mb-1">Encashment Days Count</label>
                    <input type="number" step="0.5" min="0.5" name="days" value="5.0" required class="w-full p-2.5 border border-slate-200 rounded-xl font-mono">
                </div>

                <div class="flex justify-end gap-2 pt-3 border-t border-slate-100">
                    <button type="button" onclick="closeModal('encashModal')" class="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold">Cancel</button>
                    <button type="submit" class="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold">Process Encashment</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ==================== MODAL: ADJUST QUOTA ==================== -->
    <div id="adjustQuotaModal" class="modal-backdrop fixed inset-0 bg-slate-900/60 backdrop-blur-sm hidden items-center justify-center z-50 p-4">
        <div class="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4">
            <h3 class="text-base font-bold text-slate-900">Manual Quota Balance Adjustment</h3>
            <p class="text-xs text-slate-500">Directly credit or debit leave days with an audited transaction record.</p>

            <!-- Inline Alert for clear Payroll-Lock (422) and Duplicate Error messaging -->
            <div id="adjustQuotaModalAlert" class="hidden p-3 rounded-xl text-xs font-semibold"></div>

            <form id="adjustQuotaForm" method="POST" action="<?= base_url('leave/balance-adjust') ?>" class="space-y-3.5 text-xs">
                <?= csrf_field() ?>
                <input type="hidden" name="year" id="adjust_year" value="<?= esc($selectedYear ?? date('Y')) ?>">
                <input type="hidden" name="idempotency_key" id="adjust_idempotency_key" value="">
                
                <div>
                    <label class="block font-bold text-slate-700 mb-1">Target Employee</label>
                    <select name="employee_id" id="adjust_employee_id" required class="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold">
                        <?php if (empty($employees)): ?>
                            <option value="">No company employees found</option>
                        <?php else: ?>
                            <?php foreach ($employees as $e): ?>
                                <?php 
                                    $empDisplayName = trim(($e['first_name'] ?? '') . ' ' . ($e['last_name'] ?? '')) ?: ($e['name'] ?? $e['id']);
                                    $empCode = $e['employee_code'] ?? $e['id'];
                                    $empDept = !empty($e['department_name']) ? ' • ' . $e['department_name'] : '';
                                    $isSel = (isset($selectedEmpId) && $selectedEmpId === $e['id']);
                                ?>
                                <option value="<?= esc($e['id']) ?>" <?= $isSel ? 'selected' : '' ?>>
                                    <?= esc($empDisplayName) ?> (<?= esc($empCode) ?><?= esc($empDept) ?>)
                                </option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>

                <div>
                    <label class="block font-bold text-slate-700 mb-1">Leave Category</label>
                    <select name="leave_type_id" id="adjust_leave_type_id" required class="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold">
                        <?php foreach ($leaveTypes as $lt): ?>
                            <option value="<?= esc($lt['id']) ?>"><?= esc($lt['name'] ?? 'Leave') ?> (<?= esc($lt['code'] ?? 'LV') ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">Adjustment Type</label>
                        <select name="type" id="adjust_type" class="w-full p-2.5 border border-slate-200 rounded-xl font-bold">
                            <option value="Credit">➕ Credit (Add Days)</option>
                            <option value="Debit">➖ Debit (Deduct Days)</option>
                        </select>
                    </div>
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">Days Count</label>
                        <input type="number" step="0.5" min="0.5" name="days" id="adjust_days" value="1.0" required class="w-full p-2.5 border border-slate-200 rounded-xl font-mono">
                    </div>
                </div>

                <div>
                    <label class="block font-bold text-slate-700 mb-1">Adjustment Audit Remarks</label>
                    <input type="text" name="remarks" id="adjust_remarks" required placeholder="e.g., Annual bonus days grant / Policy correction" class="w-full p-2.5 border border-slate-200 rounded-xl">
                </div>

                <div class="flex justify-end gap-2 pt-3 border-t border-slate-100">
                    <button type="button" onclick="closeModal('adjustQuotaModal')" class="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold">Cancel</button>
                    <button type="submit" id="adjust_submit_btn" class="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold shadow-sm">Save Adjustment</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ==================== MODAL: CONFIGURE LEAVE RULES ==================== -->
    <?php if (!empty($canViewRules)): ?>
    <div id="policyModal" class="modal-backdrop fixed inset-0 bg-slate-900/60 backdrop-blur-sm hidden items-center justify-center z-50 p-4">
        <div class="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4 max-h-[90vh] overflow-y-auto text-center">
            <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 class="text-base font-bold text-slate-900">Leave Rules Single Store</h3>
                <button type="button" onclick="closeModal('policyModal')" class="text-slate-400 hover:text-slate-600 font-bold text-lg">&times;</button>
            </div>
            <div class="p-4 space-y-3">
                <p class="text-xs text-slate-600">Leave policies, quotas, carry-forward, probation, sandwich, and approval rules are now managed centrally in the <strong>Rule Engine</strong> (domain: LEAVE).</p>
                <a href="<?= base_url('rules?domain=LEAVE') ?>" class="inline-flex items-center gap-2 px-5 py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition shadow-sm">
                    Go to Rule Engine (Leave Rules) &rarr;
                </a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- ==================== MODAL: CREATE / EDIT LEAVE CATEGORY ==================== -->
    <div id="leaveTypeModal" class="modal-backdrop fixed inset-0 bg-slate-900/60 backdrop-blur-sm hidden items-center justify-center z-50 p-4">
        <div class="bg-white rounded-3xl p-6 max-w-xl w-full shadow-2xl border border-slate-200 space-y-4 max-h-[92vh] overflow-y-auto">
            <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                    <h3 id="leaveTypeModalTitle" class="text-base font-bold text-slate-900">Configure Leave Category</h3>
                    <p class="text-[11px] text-slate-500">Statutory leave category, annual quota, carry-forward and encashment terms.</p>
                </div>
                <button type="button" onclick="closeModal('leaveTypeModal')" class="text-slate-400 hover:text-slate-600 font-bold text-lg">&times;</button>
            </div>

            <!-- Modal Tab Navigation -->
            <div class="flex border-b border-slate-200 gap-2 text-xs">
                <button type="button" onclick="switchLtModalTab('general')" id="lt-modal-tab-general" class="lt-modal-tab-btn pb-2 font-bold text-indigo-600 border-b-2 border-indigo-600">General Info</button>
                <button type="button" onclick="switchLtModalTab('quota')" id="lt-modal-tab-quota" class="lt-modal-tab-btn pb-2 font-bold text-slate-500 border-b-2 border-transparent hover:text-slate-800">Quota & Rules</button>
                <button type="button" onclick="switchLtModalTab('carry')" id="lt-modal-tab-carry" class="lt-modal-tab-btn pb-2 font-bold text-slate-500 border-b-2 border-transparent hover:text-slate-800">Carry Forward & Encash</button>
            </div>

            <form id="leaveTypeForm" method="POST" action="<?= base_url('leave/type/save') ?>" class="space-y-4 text-xs">
                <?= csrf_field() ?>
                <input type="hidden" name="id" id="lt_form_id" value="">

                <!-- Tab 1: General Info -->
                <div id="lt-modal-content-general" class="lt-modal-tab-content space-y-3">
                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-bold text-slate-700 mb-1">Category Name <span class="text-rose-500">*</span></label>
                            <input type="text" name="name" id="lt_form_name" required placeholder="e.g. Annual Vacation" class="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold">
                        </div>
                        <div>
                            <label class="block font-bold text-slate-700 mb-1">Category Code <span class="text-rose-500">*</span></label>
                            <input type="text" name="code" id="lt_form_code" required placeholder="e.g. AL, SL, CL" class="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono uppercase">
                        </div>
                    </div>

                    <div class="grid grid-cols-3 gap-3">
                        <div>
                            <label class="block font-bold text-slate-700 mb-1">Paid Status <span class="text-rose-500">*</span></label>
                            <select name="is_paid" id="lt_form_is_paid" class="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold">
                                <option value="1">Paid Leave (100% Salary Credit)</option>
                                <option value="0">Unpaid / Loss of Pay (LOP)</option>
                            </select>
                        </div>
                        <div>
                            <label class="block font-bold text-slate-700 mb-1">Applicable Gender <span class="text-rose-500">*</span></label>
                            <select name="applicable_gender" id="lt_form_applicable_gender" class="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold">
                                <option value="All">All Genders</option>
                                <option value="Female">Female Only</option>
                                <option value="Male">Male Only</option>
                            </select>
                        </div>
                        <div>
                            <label class="block font-bold text-slate-700 mb-1">Status</label>
                            <select name="status" id="lt_form_status" class="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                    </div>

                    <div>
                        <label class="block font-bold text-slate-700 mb-1">Description & Scope</label>
                        <textarea name="description" id="lt_form_desc" rows="2" placeholder="Policy terms, documentation needed, eligibility..." class="w-full p-2.5 border border-slate-200 rounded-xl"></textarea>
                    </div>
                </div>

                <!-- Tab 2: Quota & Rules -->
                <div id="lt-modal-content-quota" class="lt-modal-tab-content hidden space-y-3">
                    <div class="p-3 bg-purple-50 rounded-xl border border-purple-200 text-purple-900 flex items-start gap-2 text-xs">
                        <i data-lucide="info" class="w-4 h-4 text-purple-600 shrink-0 mt-0.5"></i>
                        <div>
                            <span class="font-bold">Managed centrally in Rule Engine:</span>
                            <span>Annual quotas, max consecutive days, notice period, and half-day restrictions are configured authoritatively under <a href="<?= base_url('rules?domain=LEAVE') ?>" class="underline font-bold text-purple-700">Rules &gt; Leave Domain</a>.</span>
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-3 opacity-60 pointer-events-none">
                        <div>
                            <label class="block font-bold text-slate-700 mb-1">Annual Allocation (Days/Year)</label>
                            <input type="number" step="0.5" min="0" name="days_per_year" id="lt_form_days_per_year" value="14" disabled class="w-full p-2.5 bg-slate-100 border border-slate-200 rounded-xl font-mono font-bold">
                        </div>
                        <div>
                            <label class="block font-bold text-slate-700 mb-1">Max Consecutive Days Limit</label>
                            <input type="number" min="1" name="max_consecutive_days" id="lt_form_max_consecutive" value="14" disabled class="w-full p-2.5 bg-slate-100 border border-slate-200 rounded-xl font-mono">
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-3 opacity-60 pointer-events-none">
                        <div class="flex items-center gap-2 p-3 bg-slate-100 border border-slate-200 rounded-xl">
                            <input type="checkbox" name="allow_half_day" id="lt_form_allow_half_day" value="1" checked disabled class="w-4 h-4 text-indigo-600 rounded">
                            <label for="lt_form_allow_half_day" class="font-bold text-slate-800">Allow Half-Day Applications</label>
                        </div>
                        <div class="flex items-center gap-2 p-3 bg-slate-100 border border-slate-200 rounded-xl">
                            <input type="checkbox" name="requires_medical_cert" id="lt_form_req_med" value="1" disabled class="w-4 h-4 text-indigo-600 rounded">
                            <label for="lt_form_req_med" class="font-bold text-slate-800">Mandatory Medical Certificate (&gt;2d)</label>
                        </div>
                    </div>
                </div>

                <!-- Tab 3: Carry Forward & Encashment -->
                <div id="lt-modal-content-carry" class="lt-modal-tab-content hidden space-y-3">
                    <div class="p-3 bg-purple-50 rounded-xl border border-purple-200 text-purple-900 flex items-start gap-2 text-xs">
                        <i data-lucide="info" class="w-4 h-4 text-purple-600 shrink-0 mt-0.5"></i>
                        <div>
                            <span class="font-bold">Managed centrally in Rule Engine:</span>
                            <span>Carry-forward rollover caps, expiry, and encashment terms are configured under <a href="<?= base_url('rules?domain=LEAVE') ?>" class="underline font-bold text-purple-700">Rules &gt; Leave Domain</a>.</span>
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-3 opacity-60 pointer-events-none">
                        <div class="p-3 bg-slate-100 border border-slate-200 rounded-xl space-y-2">
                            <div class="flex items-center gap-2">
                                <input type="checkbox" name="allow_carry_forward" id="lt_form_allow_cf" value="1" disabled onchange="toggleCfField(this.checked)" class="w-4 h-4 text-indigo-600 rounded">
                                <label for="lt_form_allow_cf" class="font-bold text-slate-800">Allow Year-End Carry Forward</label>
                            </div>
                            <div id="cf_days_wrapper" class="hidden">
                                <label class="block text-[11px] font-bold text-slate-600 mb-1">Max Carry Forward Cap (Days)</label>
                                <input type="number" step="0.5" min="0" name="carry_forward_days" id="lt_form_cf_days" value="0" disabled class="w-full p-2 bg-white border border-slate-200 rounded-lg font-mono">
                            </div>
                        </div>

                        <div class="p-3 bg-slate-100 border border-slate-200 rounded-xl space-y-2">
                            <div class="flex items-center gap-2">
                                <input type="checkbox" name="encashment" id="lt_form_encash" value="1" disabled onchange="toggleEncashField(this.checked)" class="w-4 h-4 text-emerald-600 rounded">
                                <label for="lt_form_encash" class="font-bold text-slate-800">Allow Leave Encashment</label>
                            </div>
                            <div id="encash_days_wrapper" class="hidden">
                                <label class="block text-[11px] font-bold text-slate-600 mb-1">Max Encashable Days / Year</label>
                                <input type="number" step="0.5" min="0" name="max_encash_days" id="lt_form_max_encash" value="10" disabled class="w-full p-2 bg-white border border-slate-200 rounded-lg font-mono">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="flex justify-end gap-2 pt-3 border-t border-slate-100">
                    <button type="button" onclick="closeModal('leaveTypeModal')" class="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold">Cancel</button>
                    <button type="submit" class="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold shadow-sm">Save Category</button>
                </div>
            </form>
        </div>
    </div>

</div>

<!-- Client-side Interactive Scripts -->
<script>
    function switchTab(tabId) {
        document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('bg-indigo-600', 'text-white', 'shadow-sm', 'shadow-indigo-600/10');
            btn.classList.add('text-slate-600', 'hover:bg-slate-100');
        });

        const targetContent = document.getElementById('tab-content-' + tabId);
        const targetBtn = document.getElementById('tab-btn-' + tabId);
        if (targetContent) targetContent.classList.remove('hidden');
        if (targetBtn) {
            targetBtn.classList.remove('text-slate-600', 'hover:bg-slate-100');
            targetBtn.classList.add('bg-indigo-600', 'text-white', 'shadow-sm', 'shadow-indigo-600/10');
        }

        const url = new URL(window.location);
        url.searchParams.set('tab', tabId);
        window.history.pushState({}, '', url);

        if (tabId === 'simulator') {
            runLeaveSimulation();
        }
        if (tabId === 'reconciliation') {
            loadReconciliationMatrix();
        }
    }

    const isLeavePrivilegedUser = <?= (!empty($isHRAdmin) || !empty($canApproveLeave) || !empty($canEndorseLeave)) ? 'true' : 'false' ?>;

    function updateEmergencyCheckboxState() {
        const typeSelect = document.getElementById('apply_leave_type_id');
        const emgCheckbox = document.getElementById('apply_is_emergency');
        const emgLabel = document.getElementById('emergency_checkbox_label');
        const emgNotice = document.getElementById('emergency_disabled_notice');
        const emgWrapper = document.getElementById('emergency_checkbox_wrapper');

        if (!typeSelect || !emgCheckbox) return;

        const selectedOption = typeSelect.options[typeSelect.selectedIndex];
        const allowsEmergency = selectedOption ? (selectedOption.getAttribute('data-allow-emergency') === '1') : false;

        if (isLeavePrivilegedUser) {
            emgCheckbox.disabled = false;
            if (emgWrapper) {
                emgWrapper.classList.remove('opacity-50', 'cursor-not-allowed');
                emgWrapper.classList.add('cursor-pointer');
            }
            if (emgLabel) emgLabel.textContent = 'Emergency Absence (HR/Manager)';
            if (emgNotice) emgNotice.classList.add('hidden');
        } else if (allowsEmergency) {
            emgCheckbox.disabled = false;
            if (emgWrapper) {
                emgWrapper.classList.remove('opacity-50', 'cursor-not-allowed');
                emgWrapper.classList.add('cursor-pointer');
            }
            if (emgLabel) emgLabel.textContent = 'Emergency Absence';
            if (emgNotice) emgNotice.classList.add('hidden');
        } else {
            emgCheckbox.checked = false;
            emgCheckbox.disabled = true;
            if (emgWrapper) {
                emgWrapper.classList.add('opacity-50', 'cursor-not-allowed');
                emgWrapper.classList.remove('cursor-pointer');
            }
            if (emgLabel) emgLabel.textContent = 'Emergency Absence';
            if (emgNotice) emgNotice.classList.remove('hidden');
        }
        onEmergencyCheckboxChanged();
    }

    function onEmergencyCheckboxChanged() {
        const emgCheckbox = document.getElementById('apply_is_emergency');
        const reasonTextarea = document.querySelector('#applyLeaveModal textarea[name="reason"]');
        const reasonLabel = document.querySelector('#applyLeaveModal textarea[name="reason"]')?.parentElement?.querySelector('label');

        if (!reasonTextarea) return;

        if (emgCheckbox && emgCheckbox.checked) {
            reasonTextarea.required = true;
            reasonTextarea.placeholder = 'Please explain the emergency circumstances and absence reason in detail (mandatory)...';
            if (reasonLabel) {
                reasonLabel.innerHTML = 'Emergency Justification & Reason <span class="text-rose-500">*</span>';
            }
        } else {
            reasonTextarea.placeholder = 'State official reason for leave request...';
            if (reasonLabel) {
                reasonLabel.innerHTML = 'Reason for Leave <span class="text-rose-500">*</span>';
            }
        }
    }

    function filterLeaveCategoriesByGender() {
        const empSelect = document.getElementById('apply_employee_id');
        const typeSelect = document.getElementById('apply_leave_type_id');
        const noticeEl = document.getElementById('genderEligibilityNotice');
        if (!empSelect || !typeSelect) return;

        const selectedEmpOpt = empSelect.options[empSelect.selectedIndex];
        const rawGender = (selectedEmpOpt ? (selectedEmpOpt.getAttribute('data-gender') || 'all') : 'all').toLowerCase();

        let normalizedGender = 'All';
        if (rawGender.includes('fem') || rawGender === 'f' || rawGender.includes('woman')) {
            normalizedGender = 'Female';
        } else if (rawGender.includes('male') || rawGender === 'm' || rawGender.includes('man')) {
            normalizedGender = 'Male';
        }

        let firstEligibleIndex = -1;
        let hiddenCount = 0;

        for (let i = 0; i < typeSelect.options.length; i++) {
            const opt = typeSelect.options[i];
            const appGender = opt.getAttribute('data-gender') || 'All';

            let isEligible = true;
            if (appGender === 'Female' && normalizedGender !== 'Female' && normalizedGender !== 'All') {
                isEligible = false;
            } else if (appGender === 'Male' && normalizedGender !== 'Male' && normalizedGender !== 'All') {
                isEligible = false;
            }

            if (isEligible) {
                opt.hidden = false;
                opt.disabled = false;
                opt.style.display = '';
                if (firstEligibleIndex === -1) {
                    firstEligibleIndex = i;
                }
            } else {
                opt.hidden = true;
                opt.disabled = true;
                opt.style.display = 'none';
                hiddenCount++;
            }
        }

        const currentOpt = typeSelect.options[typeSelect.selectedIndex];
        if (!currentOpt || currentOpt.disabled || currentOpt.hidden) {
            if (firstEligibleIndex !== -1) {
                typeSelect.selectedIndex = firstEligibleIndex;
            }
        }

        if (noticeEl) {
            if (hiddenCount > 0 && normalizedGender !== 'All') {
                noticeEl.classList.remove('hidden');
                noticeEl.textContent = 'Filtered for ' + normalizedGender;
            } else {
                noticeEl.classList.add('hidden');
            }
        }

        calculateLiveWorkingDays();
        updateEmergencyCheckboxState();

        // Dynamically enforce Single Rule Store probation & eligibility policies from backend
        const empId = empSelect.value;
        if (empId) {
            fetch('<?= base_url('leave/eligible-types') ?>?employee_id=' + encodeURIComponent(empId) + '&filter_probation=1', {
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
            .then(function(r) { return r.json(); })
            .then(function(res) {
                if (res && res.success && Array.isArray(res.data)) {
                    var allowedTypeIds = res.data.map(function(d) { return String(d.id); });
                    var hasProbationBlocked = false;
                    for (var j = 0; j < typeSelect.options.length; j++) {
                        var opt = typeSelect.options[j];
                        if (!opt.value) continue;
                        if (!allowedTypeIds.includes(String(opt.value))) {
                            opt.hidden = true;
                            opt.disabled = true;
                            opt.style.display = 'none';
                            hasProbationBlocked = true;
                        }
                    }
                    var curr = typeSelect.options[typeSelect.selectedIndex];
                    if (!curr || curr.disabled || curr.hidden) {
                        for (var k = 0; k < typeSelect.options.length; k++) {
                            if (!typeSelect.options[k].disabled && !typeSelect.options[k].hidden) {
                                typeSelect.selectedIndex = k;
                                break;
                            }
                        }
                    }
                    if (noticeEl && hasProbationBlocked) {
                        noticeEl.classList.remove('hidden');
                        noticeEl.textContent = 'Filtered for ' + normalizedGender + ' & Probation Policy';
                    }
                    calculateLiveWorkingDays();
                }
            })
            .catch(function() {
                // Client-side filtering remains in effect
            });
        }
    }

    function updateApplicantBalance() {
        filterLeaveCategoriesByGender();
    }

    function openModal(modalId) {
        const m = document.getElementById(modalId);
        if (m) {
            m.classList.remove('hidden');
            m.classList.add('flex');
            if (modalId === 'applyLeaveModal') {
                filterLeaveCategoriesByGender();
                updateEmergencyCheckboxState();
            }
        }
    }

    function closeModal(modalId) {
        const m = document.getElementById(modalId);
        if (m) {
            m.classList.remove('flex');
            m.classList.add('hidden');
        }
    }

    function generateUUID() {
        if (typeof crypto !== 'undefined' && crypto.randomUUID) {
            return crypto.randomUUID();
        }
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            const r = Math.random() * 16 | 0;
            const v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    function openAdjustModal(empId, leaveTypeId) {
        const modal = document.getElementById('adjustQuotaModal');
        if (!modal) return;

        // Reset days count to 1.0 and clear remarks
        const daysInput = document.getElementById('adjust_days') || modal.querySelector('[name="days"]');
        if (daysInput) daysInput.value = '1.0';

        const remarksInput = document.getElementById('adjust_remarks') || modal.querySelector('[name="remarks"]');
        if (remarksInput) remarksInput.value = '';

        const typeSelect = document.getElementById('adjust_type') || modal.querySelector('[name="type"]');
        if (typeSelect) typeSelect.value = 'Credit';

        // Preselect employee if provided and exists
        const empSelect = document.getElementById('adjust_employee_id') || modal.querySelector('[name="employee_id"]');
        if (empSelect && empId) {
            for (let i = 0; i < empSelect.options.length; i++) {
                if (empSelect.options[i].value === empId) {
                    empSelect.selectedIndex = i;
                    break;
                }
            }
        }

        // Preselect leave category if provided and exists
        const ltSelect = document.getElementById('adjust_leave_type_id') || modal.querySelector('[name="leave_type_id"]');
        if (ltSelect && leaveTypeId) {
            for (let i = 0; i < ltSelect.options.length; i++) {
                if (ltSelect.options[i].value === leaveTypeId) {
                    ltSelect.selectedIndex = i;
                    break;
                }
            }
        }

        // Fresh idempotency key per modal open/submit
        const idemInput = document.getElementById('adjust_idempotency_key') || modal.querySelector('[name="idempotency_key"]');
        if (idemInput) {
            idemInput.value = 'adj_' + generateUUID();
        }

        // Hidden year input defaulting to current year if unset
        const yearInput = document.getElementById('adjust_year') || modal.querySelector('[name="year"]');
        if (yearInput && !yearInput.value) {
            yearInput.value = new Date().getFullYear();
        }

        // Clear previous alert messages and re-enable button
        const alertBox = document.getElementById('adjustQuotaModalAlert');
        if (alertBox) {
            alertBox.classList.add('hidden');
            alertBox.innerHTML = '';
        }

        const submitBtn = document.getElementById('adjust_submit_btn');
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerText = 'Save Adjustment';
        }

        openModal('adjustQuotaModal');
    }

    document.addEventListener('DOMContentLoaded', () => {
        const adjustForm = document.getElementById('adjustQuotaForm');
        if (adjustForm) {
            adjustForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const form = this;
                const submitBtn = document.getElementById('adjust_submit_btn');
                const alertBox = document.getElementById('adjustQuotaModalAlert');

                if (submitBtn) {
                    submitBtn.disabled = true;
                    submitBtn.innerText = 'Saving...';
                }
                if (alertBox) alertBox.classList.add('hidden');

                const formData = new FormData(form);

                fetch(form.action, {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(async response => {
                    const data = await response.json().catch(() => ({}));
                    if (response.ok && data.success) {
                        const targetEmpId = formData.get('employee_id');
                        window.location.href = '<?= base_url('leave?tab=ledger') ?>' + (targetEmpId ? '&emp_id=' + encodeURIComponent(targetEmpId) : '');
                    } else {
                        if (submitBtn) {
                            submitBtn.disabled = false;
                            submitBtn.innerText = 'Save Adjustment';
                        }
                        if (alertBox) {
                            alertBox.classList.remove('hidden');
                            const msg = data.message || 'Failed to adjust balance.';
                            const is422 = response.status === 422 || msg.includes('422') || msg.toLowerCase().includes('payroll');
                            const isDup = msg.toLowerCase().includes('duplicate');

                            if (is422) {
                                alertBox.className = 'p-3.5 bg-amber-50 border border-amber-300 text-amber-900 rounded-xl text-xs font-semibold flex items-start gap-2 shadow-xs';
                                alertBox.innerHTML = '<svg class="w-4 h-4 text-amber-600 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg><div><span class="block font-bold text-amber-950">Payroll Locked (422)</span> ' + msg + '</div>';
                            } else if (isDup) {
                                alertBox.className = 'p-3.5 bg-orange-50 border border-orange-300 text-orange-900 rounded-xl text-xs font-semibold flex items-start gap-2 shadow-xs';
                                alertBox.innerHTML = '<svg class="w-4 h-4 text-orange-600 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg><div><span class="block font-bold text-orange-950">Duplicate Adjustment</span> ' + msg + '</div>';
                            } else {
                                alertBox.className = 'p-3.5 bg-rose-50 border border-rose-300 text-rose-900 rounded-xl text-xs font-semibold flex items-start gap-2 shadow-xs';
                                alertBox.innerHTML = '<svg class="w-4 h-4 text-rose-600 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg><div><span class="block font-bold text-rose-950">Adjustment Error</span> ' + msg + '</div>';
                            }
                        }
                    }
                })
                .catch(err => {
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.innerText = 'Save Adjustment';
                    }
                    if (alertBox) {
                        alertBox.className = 'p-3.5 bg-rose-50 border border-rose-300 text-rose-900 rounded-xl text-xs font-semibold';
                        alertBox.classList.remove('hidden');
                        alertBox.innerText = 'Network error: ' + err.message;
                    }
                });
            });
        }
    });

    function openEndorseModal(id, empName, isDeptHead = false) {
        document.getElementById('endorse_emp_name').innerText = empName;
        const titleEl = document.getElementById('endorse_modal_title');
        const descEl = document.getElementById('endorse_modal_desc');
        const labelEl = document.getElementById('endorse_remarks_label');
        const btn = document.getElementById('endorse_submit_btn') || document.querySelector('#endorseForm button[type="submit"]');

        if (isDeptHead) {
            document.getElementById('endorseForm').action = '<?= base_url('leave/endorse-dept-head/') ?>' + id;
            if (titleEl) titleEl.innerText = 'Department Head Endorsement';
            if (descEl) descEl.innerText = 'Endorse this 8+ day extended leave request as Department Head prior to HR final approval.';
            if (labelEl) labelEl.innerText = 'Department Head Remarks / Strategic Impact';
            if (btn) {
                btn.dataset.submitting = '0';
                btn.style.opacity = '1';
                btn.style.pointerEvents = 'auto';
                btn.innerText = 'Confirm Dept Head Endorsement';
                btn.className = 'px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-bold shadow-sm';
            }
        } else {
            document.getElementById('endorseForm').action = '<?= base_url('leave/endorse/') ?>' + id;
            if (titleEl) titleEl.innerText = 'Tier 1: Manager Endorsement';
            if (descEl) descEl.innerText = 'Endorse this time-off request to forward it to HR or Department Head for subsequent review.';
            if (labelEl) labelEl.innerText = 'Manager Remarks / Coverage Notes';
            if (btn) {
                btn.dataset.submitting = '0';
                btn.style.opacity = '1';
                btn.style.pointerEvents = 'auto';
                btn.innerText = 'Confirm Endorsement';
                btn.className = 'px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold shadow-sm';
            }
        }
        openModal('endorseModal');
    }

    function openApproveModal(id, empName, days) {
        document.getElementById('approve_emp_name').innerText = empName;
        document.getElementById('approve_days').innerText = days;
        document.getElementById('approveForm').action = '<?= base_url('leave/approve/') ?>' + id;
        const btn = document.querySelector('#approveForm button[type="submit"]');
        if (btn) { btn.dataset.submitting = '0'; btn.style.opacity = '1'; btn.style.pointerEvents = 'auto'; btn.innerText = 'Confirm Final Approval'; }
        openModal('approveModal');
    }

    function openRejectModal(id, empName) {
        document.getElementById('reject_emp_name').innerText = empName;
        document.getElementById('rejectForm').action = '<?= base_url('leave/reject/') ?>' + id;
        const btn = document.querySelector('#rejectForm button[type="submit"]');
        if (btn) { btn.dataset.submitting = '0'; btn.style.opacity = '1'; btn.style.pointerEvents = 'auto'; btn.innerText = 'Confirm Rejection'; }
        openModal('rejectModal');
    }

    function openCancelModal(id, empName, isApproved) {
        const titleEl = document.getElementById('cancel_modal_title');
        const descEl = document.getElementById('cancel_modal_desc');
        const empEl = document.getElementById('cancel_emp_name');
        const formEl = document.getElementById('cancelForm');
        const reasonInput = document.getElementById('cancel_reason_input');

        if (titleEl) {
            titleEl.innerText = isApproved ? 'Cancel Approved Leave' : 'Withdraw Leave Application';
        }
        if (descEl) {
            descEl.innerText = isApproved 
                ? 'Specify mandatory cancellation reason. Cancelling will restore quota balance to the employee.' 
                : 'Specify mandatory reason for withdrawing this pending application.';
        }
        if (empEl) {
            empEl.innerText = empName;
        }
        if (formEl) {
            formEl.action = '<?= base_url('leave/cancel/') ?>' + id;
        }
        if (reasonInput) {
            reasonInput.value = '';
        }
        const btn = document.querySelector('#cancelForm button[type="submit"]');
        if (btn) { btn.dataset.submitting = '0'; btn.style.opacity = '1'; btn.style.pointerEvents = 'auto'; btn.innerText = isApproved ? 'Confirm Cancellation' : 'Confirm Withdrawal'; }
        openModal('cancelModal');
    }

    function toggleHalfDaySelect() {
        const isHalf = document.getElementById('apply_is_half_day')?.checked;
        const sel = document.getElementById('apply_half_day');
        if (sel) {
            if (isHalf) {
                sel.classList.remove('hidden');
            } else {
                sel.classList.add('hidden');
            }
        }
    }

    function calculateLiveWorkingDays() {
        const empId = document.getElementById('apply_employee_id')?.value;
        const typeId = document.getElementById('apply_leave_type_id')?.value;
        const fromDate = document.getElementById('apply_from_date')?.value;
        const toDate = document.getElementById('apply_to_date')?.value;
        const isHalfDay = document.getElementById('apply_is_half_day')?.checked ? 1 : 0;

        if (!fromDate || !toDate) return;

        const formData = new FormData();
        formData.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');
        formData.append('employee_id', empId);
        formData.append('leave_type_id', typeId);
        formData.append('from_date', fromDate);
        formData.append('to_date', toDate);
        formData.append('is_half_day', isHalfDay);

        fetch('<?= base_url('leave/calculate-days') ?>', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
            }
        })
        .then(res => res.json())
        .then(data => {
            if (data && data.chargeable_days !== undefined) {
                const days = data.chargeable_days;
                const chargeElem = document.getElementById('chargeableDaysCount');
                if (chargeElem) {
                    chargeElem.innerText = days + ' Working Day' + (days > 1 ? 's' : '');
                }

                // Dynamic authoritative sandwich rule resolution from CompanyWeekendService
                const sandwichWarn = document.getElementById('sandwichWarningBanner');
                if (sandwichWarn) {
                    if (data.sandwich_applies && !isHalfDay) {
                        sandwichWarn.classList.remove('hidden');
                        sandwichWarn.classList.add('flex');
                    } else {
                        sandwichWarn.classList.remove('flex');
                        sandwichWarn.classList.add('hidden');
                    }
                }
            }
        })
        .catch(err => {
            console.error('Calculation error', err);
        });
    }

    function runAccrualSimulation() {
        const date = document.getElementById('accrual_effective_date').value;
        const formData = new FormData();
        formData.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');
        formData.append('effective_date', date);
        formData.append('is_dry_run', 1);

        fetch('<?= base_url('leave/accrue-monthly') ?>', {
            method: 'POST',
            body: formData,
            headers: { 
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
            }
        })
        .then(res => res.json())
        .then(data => {
            const container = document.getElementById('accrualSimulationResult');
            const summary = document.getElementById('accrualResultSummary');
            const count = document.getElementById('accrualResultCount');
            const tbody = document.getElementById('accrualResultTableBody');

            container.classList.remove('hidden');
            summary.innerText = data.summary || 'Simulation completed.';
            count.innerText = (data.processed_count || 0) + ' Records';

            tbody.innerHTML = '';
            if (data.details && data.details.length > 0) {
                data.details.forEach(item => {
                    const tr = document.createElement('tr');
                    tr.className = 'hover:bg-slate-50';
                    tr.innerHTML = `
                        <td class="p-2 font-bold">${item.employee_name || item.employee_id}</td>
                        <td class="p-2">${item.type_name || item.leave_type_id}</td>
                        <td class="p-2 text-right text-emerald-600 font-bold">+${item.credit_days || item.accrual_rate}d</td>
                        <td class="p-2 text-right font-bold text-slate-800">${item.new_balance || item.after_balance || '—'}d</td>
                    `;
                    tbody.appendChild(tr);
                });
            } else {
                tbody.innerHTML = '<tr><td colspan="4" class="p-3 text-center text-slate-400">No pending accruals for this date (already processed).</td></tr>';
            }
        })
        .catch(err => {
            console.error(err);
            alert('Accrual simulation failed.');
        });
    }

    function runRolloverSimulation() {
        const fromYear = document.getElementById('rollover_from_year').value;
        const toYear = document.getElementById('rollover_to_year').value;
        const formData = new FormData();
        formData.append('from_year', fromYear);
        formData.append('to_year', toYear);
        formData.append('is_dry_run', 1);

        fetch('<?= base_url('leave/rollover-year-end') ?>', {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
        .then(res => res.json())
        .then(data => {
            const container = document.getElementById('rolloverSimulationResult');
            const summary = document.getElementById('rolloverResultSummary');
            const count = document.getElementById('rolloverResultCount');
            const tbody = document.getElementById('rolloverResultTableBody');

            container.classList.remove('hidden');
            summary.innerText = data.summary || 'Rollover simulation completed.';
            count.innerText = (data.processed_count || 0) + ' Records';

            tbody.innerHTML = '';
            if (data.details && data.details.length > 0) {
                data.details.forEach(item => {
                    const tr = document.createElement('tr');
                    tr.className = 'hover:bg-slate-50';
                    tr.innerHTML = `
                        <td class="p-2 font-bold">${item.employee_name || item.employee_id}</td>
                        <td class="p-2">${item.type_name || item.leave_type_id}</td>
                        <td class="p-2 text-right text-emerald-600 font-bold">+${item.carried_forward || 0}d</td>
                        <td class="p-2 text-right text-rose-600 font-bold">-${item.expired_days || 0}d</td>
                    `;
                    tbody.appendChild(tr);
                });
            } else {
                tbody.innerHTML = '<tr><td colspan="4" class="p-3 text-center text-slate-400">No eligible balances found for rollover between these years.</td></tr>';
            }
        })
        .catch(err => {
            console.error(err);
            alert('Rollover simulation failed.');
        });
    }

    function filterLedgerAjax() {
        const empId = document.getElementById('ledger_employee_filter').value;
        const typeId = document.getElementById('ledger_type_filter').value;

        const url = new URL('<?= base_url('leave/ledger') ?>');
        if (empId) url.searchParams.set('employee_id', empId);
        if (typeId) url.searchParams.set('leave_type_id', typeId);

        fetch(url.toString(), {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
        .then(res => res.json())
        .then(data => {
            const tbody = document.getElementById('ledgerTableBody');
            tbody.innerHTML = '';
            if (!data.ledger || data.ledger.length === 0) {
                tbody.innerHTML = '<tr><td colspan="8" class="p-8 text-center text-slate-400 italic">No transaction records found matching filters.</td></tr>';
                return;
            }

            data.ledger.forEach(tx => {
                const isCredit = ['Accrual', 'Carry_Forward', 'Credit', 'Reversal'].includes(tx.transaction_type);
                const tr = document.createElement('tr');
                tr.className = 'hover:bg-slate-50/50';
                tr.innerHTML = `
                    <td class="p-3 font-mono text-slate-600 whitespace-nowrap">${(tx.transaction_date || tx.created_at || '').substring(0, 10)}</td>
                    <td class="p-3 font-bold text-slate-800 whitespace-nowrap">
                        ${tx.first_name ? (tx.first_name + ' ' + (tx.last_name || '')) : (tx.employee_name || tx.employee_id || 'Staff')}
                        <span class="text-[10px] text-slate-400 font-mono block">${tx.employee_code || ''}</span>
                    </td>
                    <td class="p-3 font-medium text-slate-700 whitespace-nowrap">${tx.leave_type_name || 'Leave'}</td>
                    <td class="p-3 whitespace-nowrap">
                        <span class="px-2.5 py-1 rounded-full text-[10px] font-bold ${isCredit ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/60' : 'bg-rose-50 text-rose-700 border border-rose-200/60'}">
                            ${tx.transaction_type || 'Adjustment'}
                        </span>
                    </td>
                    <td class="p-3 text-right font-mono font-bold whitespace-nowrap ${isCredit ? 'text-emerald-600' : 'text-rose-600'}">
                        ${isCredit ? '+' : '-'}${Math.abs(parseFloat(tx.days || 0))}d
                    </td>
                    <td class="p-3 text-right font-mono font-bold text-slate-900 whitespace-nowrap">
                        ${tx.balance_after !== null && tx.balance_after !== undefined ? tx.balance_after + 'd' : '—'}
                    </td>
                    <td class="p-3 text-slate-500 max-w-xs truncate" title="${tx.remarks || ''}">
                        ${tx.remarks || '—'}
                    </td>
                    <td class="p-3 text-slate-400 text-[11px] whitespace-nowrap">${tx.created_by || 'System'}</td>
                `;
                tbody.appendChild(tr);
            });
        })
        .catch(err => {
            console.error('Ledger fetch failed', err);
        });
    }

    function toggleSelectAll(master) {
        const checkboxes = document.querySelectorAll('.app-checkbox');
        checkboxes.forEach(cb => cb.checked = master.checked);
        updateBatchState();
    }

    function getSelectedIds() {
        const checkboxes = document.querySelectorAll('.app-checkbox:checked');
        return Array.from(checkboxes).map(cb => cb.value);
    }

    function updateBatchState() {
        const selected = getSelectedIds();
        const toolbar = document.getElementById('batchActionToolbar');
        const text = document.getElementById('selectedCountText');

        if (selected.length > 0) {
            toolbar.classList.remove('hidden');
            toolbar.classList.add('flex');
            text.innerText = selected.length + ' application' + (selected.length > 1 ? 's' : '') + ' selected';
        } else {
            toolbar.classList.remove('flex');
            toolbar.classList.add('hidden');
        }
    }

    function submitBatchApprove() {
        const ids = getSelectedIds();
        if (ids.length === 0) return;
        if (!confirm('Approve ' + ids.length + ' selected leave application(s)?')) return;

        const formData = new FormData();
        formData.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');
        formData.append('ids', JSON.stringify(ids));

        fetch('<?= base_url('leave/batch-approve') ?>', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
            }
        })
        .then(res => res.json())
        .then(data => {
            alert(data.message);
            window.location.reload();
        })
        .catch(err => {
            console.error(err);
            window.location.reload();
        });
    }

    function submitBatchReject() {
        const ids = getSelectedIds();
        if (ids.length === 0) return;
        const reason = prompt('Enter rejection reason for selected applications:');
        if (!reason) return;

        const formData = new FormData();
        formData.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');
        formData.append('ids', JSON.stringify(ids));
        formData.append('reason', reason);

        fetch('<?= base_url('leave/batch-reject') ?>', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
            }
        })
        .then(res => res.json())
        .then(data => {
            alert(data.message);
            window.location.reload();
        })
        .catch(err => {
            console.error(err);
            window.location.reload();
        });
    }

    function openLeaveTypeModal() {
        document.getElementById('leaveTypeModalTitle').innerText = 'Add Leave Category';
        document.getElementById('lt_form_id').value = '';
        document.getElementById('lt_form_name').value = '';
        document.getElementById('lt_form_code').value = '';
        document.getElementById('lt_form_desc').value = '';
        document.getElementById('lt_form_days_per_year').value = '14';
        document.getElementById('lt_form_is_paid').value = '1';
        if (document.getElementById('lt_form_applicable_gender')) {
            document.getElementById('lt_form_applicable_gender').value = 'All';
        }
        document.getElementById('lt_form_status').value = 'active';
        document.getElementById('lt_form_allow_cf').checked = false;
        document.getElementById('lt_form_cf_days').value = '0';
        toggleCfField(false);
        document.getElementById('lt_form_encash').checked = false;
        document.getElementById('lt_form_max_encash').value = '10';
        toggleEncashField(false);
        switchLtModalTab('general');
        openModal('leaveTypeModal');
    }

    function editLeaveType(type) {
        if (!type) return;
        document.getElementById('leaveTypeModalTitle').innerText = 'Edit Leave Category (' + (type.code || 'LV') + ')';
        document.getElementById('lt_form_id').value = type.id || '';
        document.getElementById('lt_form_name').value = type.name || '';
        document.getElementById('lt_form_code').value = type.code || '';
        document.getElementById('lt_form_desc').value = type.description || '';
        document.getElementById('lt_form_days_per_year').value = type.days_per_year || type.annual_allocation || 14;
        document.getElementById('lt_form_is_paid').value = (type.is_paid == 1 || type.paid == 1) ? '1' : '0';
        if (document.getElementById('lt_form_applicable_gender')) {
            document.getElementById('lt_form_applicable_gender').value = type.applicable_gender || 'All';
        }
        document.getElementById('lt_form_status').value = type.status || 'active';

        const isCf = (type.allow_carry_forward == 1 || (type.carry_forward_days && type.carry_forward_days > 0));
        document.getElementById('lt_form_allow_cf').checked = isCf;
        document.getElementById('lt_form_cf_days').value = type.carry_forward_days || type.max_carry_forward_days || 0;
        toggleCfField(isCf);

        const isEncash = !!type.encashment;
        document.getElementById('lt_form_encash').checked = isEncash;
        document.getElementById('lt_form_max_encash').value = type.max_encashment_days || type.max_encash_days || 10;
        toggleEncashField(isEncash);

        switchLtModalTab('general');
        openModal('leaveTypeModal');
    }

    function switchLtModalTab(tabKey) {
        document.querySelectorAll('.lt-modal-tab-content').forEach(el => el.classList.add('hidden'));
        document.querySelectorAll('.lt-modal-tab-btn').forEach(btn => {
            btn.classList.remove('text-indigo-600', 'border-indigo-600');
            btn.classList.add('text-slate-500', 'border-transparent');
        });

        const target = document.getElementById('lt-modal-content-' + tabKey);
        const btn = document.getElementById('lt-modal-tab-' + tabKey);
        if (target) target.classList.remove('hidden');
        if (btn) {
            btn.classList.remove('text-slate-500', 'border-transparent');
            btn.classList.add('text-indigo-600', 'border-indigo-600');
        }
    }

    function toggleCfField(checked) {
        const wrapper = document.getElementById('cf_days_wrapper');
        if (wrapper) {
            if (checked) wrapper.classList.remove('hidden');
            else wrapper.classList.add('hidden');
        }
    }

    function toggleEncashField(checked) {
        const wrapper = document.getElementById('encash_days_wrapper');
        if (wrapper) {
            if (checked) wrapper.classList.remove('hidden');
            else wrapper.classList.add('hidden');
        }
    }

    // ==================== TAB 7: LEAVE SIMULATOR LOGIC ====================
    let simDebounceTimer = null;

    function onSimulatorInputChanged() {
        clearTimeout(simDebounceTimer);
        simDebounceTimer = setTimeout(runLeaveSimulation, 150);
    }

    function onSimulatorStartDateChanged() {
        const startInput = document.getElementById('sim-input-start-date');
        const endInput = document.getElementById('sim-input-end-date');
        if (startInput && endInput) {
            if (endInput.value < startInput.value) {
                endInput.value = startInput.value;
            }
        }
        onSimulatorInputChanged();
    }

    function onSimulatorHalfDayToggled(checked) {
        if (checked) {
            const hourlyCb = document.getElementById('sim-toggle-hourly');
            if (hourlyCb) hourlyCb.checked = false;
            const sliderCont = document.getElementById('sim-hourly-slider-container');
            if (sliderCont) sliderCont.classList.add('hidden');
        }
        onSimulatorInputChanged();
    }

    function onSimulatorHourlyToggled(checked) {
        const sliderCont = document.getElementById('sim-hourly-slider-container');
        if (checked) {
            const halfDayCb = document.getElementById('sim-toggle-half-day');
            if (halfDayCb) halfDayCb.checked = false;
            if (sliderCont) sliderCont.classList.remove('hidden');
        } else {
            if (sliderCont) sliderCont.classList.add('hidden');
        }
        onSimulatorInputChanged();
    }

    function onSimulatorHoursChanged(val) {
        const hours = parseFloat(val) || 4;
        const days = (hours / 8).toFixed(2);
        const label = document.getElementById('sim-hours-label');
        if (label) {
            label.innerText = `${hours} Hours (${days}d)`;
        }
        onSimulatorInputChanged();
    }

    function runLeaveSimulation() {
        const empSelect = document.getElementById('sim-select-emp');
        const typeSelect = document.getElementById('sim-select-leave-type');
        if (!empSelect || !typeSelect) return;

        const empId = empSelect.value;
        const typeId = typeSelect.value;
        const startDate = document.getElementById('sim-input-start-date')?.value || '';
        const endDate = document.getElementById('sim-input-end-date')?.value || startDate;
        const isHalfDay = document.getElementById('sim-toggle-half-day')?.checked ? 1 : 0;
        const isHourly = document.getElementById('sim-toggle-hourly')?.checked ? 1 : 0;
        const hourlyHours = parseFloat(document.getElementById('sim-slider-hours')?.value || '4');
        const hasMedCert = document.getElementById('sim-toggle-med-cert')?.checked ? 1 : 0;
        const hasAttachment = document.getElementById('sim-toggle-attachment')?.checked ? 1 : 0;

        // Immediately update employee profile badge preview
        const selectedOpt = empSelect.selectedOptions[0];
        if (selectedOpt) {
            const dept = selectedOpt.getAttribute('data-dept') || 'General';
            const desg = selectedOpt.getAttribute('data-desg') || 'Staff';
            const join = selectedOpt.getAttribute('data-join') || 'N/A';
            const confirm = selectedOpt.getAttribute('data-confirm') || 'On Probation';
            const basic = parseFloat(selectedOpt.getAttribute('data-basic') || '0');
            const gross = parseFloat(selectedOpt.getAttribute('data-gross') || '0');

            const deptDesg = document.getElementById('sim-preview-dept-desg');
            if (deptDesg) deptDesg.innerText = `${dept} • ${desg}`;
            const joinConf = document.getElementById('sim-preview-join-conf');
            if (joinConf) joinConf.innerText = `${join} • ${confirm}`;
            const salary = document.getElementById('sim-preview-salary');
            if (salary) salary.innerText = (basic > 0) ? `${basic.toLocaleString()} / ${gross.toLocaleString()}` : 'Confidential';
        }

        // Show spinner / calculating state on validation banner
        const banner = document.getElementById('sim-validation-banner');
        const iconContainer = document.getElementById('sim-validation-icon');
        const titleContainer = document.getElementById('sim-validation-title');
        const errorsContainer = document.getElementById('sim-validation-errors');
        const warningsContainer = document.getElementById('sim-validation-warnings');

        if (titleContainer) titleContainer.innerText = 'Calculating Live Simulation...';
        if (iconContainer) {
            iconContainer.innerHTML = '<svg class="w-5 h-5 text-slate-500 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>';
        }

        const formData = new FormData();
        formData.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');
        formData.append('employee_id', empId);
        formData.append('leave_type_id', typeId);
        formData.append('from_date', startDate);
        formData.append('to_date', endDate);
        formData.append('is_half_day', isHalfDay);
        formData.append('is_hourly', isHourly);
        formData.append('hourly_hours', hourlyHours);
        formData.append('has_medical_cert', hasMedCert);
        formData.append('has_attachment', hasAttachment);
        formData.append('reason', 'Interactive sandbox simulation');

        fetch('<?= base_url('leave/simulate') ?>', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
            }
        })
        .then(res => res.json())
        .then(data => {
            if (!data || !data.success) {
                if (titleContainer) titleContainer.innerText = data?.message || 'Simulation encountered an issue';
                if (banner) {
                    banner.className = 'p-4 rounded-2xl border flex items-start gap-3 bg-rose-50 border-rose-200 text-rose-800 transition-all duration-200';
                }
                return;
            }
            renderSimulatorResults(data);
        })
        .catch(err => {
            console.error('Leave simulation request failed:', err);
            if (titleContainer) titleContainer.innerText = 'Failed to connect to simulation engine';
            if (banner) {
                banner.className = 'p-4 rounded-2xl border flex items-start gap-3 bg-rose-50 border-rose-200 text-rose-800 transition-all duration-200';
            }
        });
    }

    function renderSimulatorResults(data) {
        // 1. Quota & Balances
        const curBalEl = document.getElementById('sim-current-balance');
        if (curBalEl) curBalEl.innerText = `${data.currentBalance} Days`;
        const annAllocEl = document.getElementById('sim-annual-allocation');
        if (annAllocEl) annAllocEl.innerText = `Annual Allocation: ${data.leaveType?.days_per_year ?? 0}d`;

        // 2. Validation Status Banner
        const banner = document.getElementById('sim-validation-banner');
        const icon = document.getElementById('sim-validation-icon');
        const title = document.getElementById('sim-validation-title');
        const errorsEl = document.getElementById('sim-validation-errors');
        const warningsEl = document.getElementById('sim-validation-warnings');

        if (errorsEl) errorsEl.innerHTML = '';
        if (warningsEl) warningsEl.innerHTML = '';

        const isValid = !!data.validation?.isValid;
        const errors = data.validation?.errors || [];
        const warnings = data.validation?.warnings || [];

        if (isValid) {
            if (warnings.length > 0) {
                if (banner) banner.className = 'p-4 rounded-2xl border flex items-start gap-3 bg-amber-50 border-amber-200 text-amber-900 transition-all duration-200';
                if (icon) icon.innerHTML = '<svg class="w-5 h-5 text-amber-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>';
                if (title) title.innerText = 'Application Eligible With Advisories';
            } else {
                if (banner) banner.className = 'p-4 rounded-2xl border flex items-start gap-3 bg-emerald-50 border-emerald-200 text-emerald-900 transition-all duration-200';
                if (icon) icon.innerHTML = '<svg class="w-5 h-5 text-emerald-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>';
                if (title) title.innerText = 'Application Fully Eligible';
            }
        } else {
            if (banner) banner.className = 'p-4 rounded-2xl border flex items-start gap-3 bg-rose-50 border-rose-200 text-rose-900 transition-all duration-200';
            if (icon) icon.innerHTML = '<svg class="w-5 h-5 text-rose-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>';
            if (title) title.innerText = 'Application Blocked by Policy';
        }

        if (errors.length > 0 && errorsEl) {
            errors.forEach(err => {
                const p = document.createElement('p');
                p.className = 'font-semibold text-rose-700 flex items-center gap-1.5';
                p.innerHTML = `<span class="inline-block w-1.5 h-1.5 rounded-full bg-rose-600"></span> ${escapeHtml(err)}`;
                errorsEl.appendChild(p);
            });
        }

        if (warnings.length > 0 && warningsEl) {
            warnings.forEach(warn => {
                const p = document.createElement('p');
                p.className = 'text-amber-700 flex items-center gap-1.5';
                p.innerHTML = `<span class="inline-block w-1.5 h-1.5 rounded-full bg-amber-500"></span> ${escapeHtml(warn)}`;
                warningsEl.appendChild(p);
            });
        }

        // 3. Metric Cards
        const totalDays = data.span?.totalDays ?? 0;
        const workingDays = data.span?.workingDays ?? 0;
        const chgDaysEl = document.getElementById('sim-metric-chargeable-days');
        if (chgDaysEl) chgDaysEl.innerText = `${totalDays} Days`;
        const wrkDaysEl = document.getElementById('sim-metric-working-days');
        if (wrkDaysEl) wrkDaysEl.innerText = `${workingDays} working days`;

        const projBal = data.projectedBalance ?? 0;
        const projBalEl = document.getElementById('sim-metric-projected-balance');
        if (projBalEl) {
            projBalEl.innerText = `${projBal} Days`;
            if (projBal < 0) {
                projBalEl.className = 'text-2xl font-extrabold text-rose-600 mt-1';
            } else {
                projBalEl.className = 'text-2xl font-extrabold text-slate-900 mt-1';
            }
        }
        const initBalEl = document.getElementById('sim-metric-initial-balance');
        if (initBalEl) initBalEl.innerText = `From ${data.currentBalance}d initial`;

        const sndBadge = document.getElementById('sim-metric-sandwich-badge');
        if (sndBadge) {
            if (data.span?.sandwichRuleApplies) {
                sndBadge.innerHTML = `<span class="text-amber-600">Active</span> <span class="text-xs text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded font-mono font-bold">+${data.span.bridgeDaysCount || 0}d</span>`;
            } else {
                sndBadge.innerHTML = '<span class="text-slate-400 font-normal">Standard (0d)</span>';
            }
        }

        // 4. Policy Resolution Engine Details
        const scopeBadge = document.getElementById('sim-policy-scope-badge');
        if (scopeBadge) scopeBadge.innerText = `Scope: ${data.resolvedPolicy?.scopeLevel || 'Global'}`;
        const polName = document.getElementById('sim-policy-name');
        if (polName) polName.innerText = `${data.resolvedPolicy?.name || 'Standard Company Policy'} (${data.resolvedPolicy?.code || 'POL-STD'})`;
        const breakdown = document.getElementById('sim-span-breakdown');
        if (breakdown) breakdown.innerText = data.span?.breakdownText || '--';
        const calTreat = document.getElementById('sim-calendar-treatment');
        if (calTreat) calTreat.innerText = `${data.resolvedPolicy?.weekendTreatment || 'Exclude weekly off'} • ${data.resolvedPolicy?.holidayTreatment || 'Exclude holidays'}`;
        const wfTiers = document.getElementById('sim-workflow-tiers');
        if (wfTiers) {
            const approvers = data.validation?.requiredApprovers || (Array.isArray(data.approvalWorkflow?.tiers) && data.approvalWorkflow.tiers.length ? data.approvalWorkflow.tiers.map(t => t.name || 'Tier ' + t.tier) : ['Supervisor Endorsement', 'Final Approval']);
            wfTiers.innerHTML = approvers.map(a => escapeHtml(a)).join(' &rarr; ');
        }

        // 5. Financial & Payroll Impact Box
        const lopRow = document.getElementById('sim-financial-lop-row');
        if (lopRow) {
            const isPaid = (data.leaveType?.is_paid === 'Yes' || data.leaveType?.is_paid == 1);
            if (!isPaid) {
                const formulaDisplay = data.unpaidFormula || data.leaveType?.unpaid_deduction_formula || 'Monthly / 30';
                lopRow.innerHTML = `<div class="flex items-center justify-between text-rose-600 font-medium"><span>Unpaid Leave (LOP) Deduction:</span><span class="font-bold text-sm font-mono">-${Number(data.unpaidLOP || 0).toLocaleString()} (${escapeHtml(formulaDisplay)} * ${totalDays}d)</span></div>`;
            } else {
                lopRow.innerHTML = '<div class="flex items-center justify-between text-emerald-600 font-medium"><span>Paid Leave Status:</span><span>100% Fully Paid (No Payroll Deductions)</span></div>';
            }
        }

        const encashRow = document.getElementById('sim-financial-encash-row');
        const encashAmt = document.getElementById('sim-encash-amount');
        if (encashRow && encashAmt) {
            const allowEncash = (data.leaveType?.encashment === 'Yes' || data.leaveType?.encashment == 1);
            if (allowEncash) {
                encashRow.classList.remove('hidden');
                const encashBasisDisplay = data.encashSalaryBasis || data.leaveType?.encashment_salary_basis || 'Basic Salary';
                encashAmt.innerText = `${Number(data.encashmentSample || 0).toLocaleString()} (${escapeHtml(encashBasisDisplay)})`;
            } else {
                encashRow.classList.add('hidden');
            }
        }
    }

    function escapeHtml(text) {
        if (!text) return '';
        const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
        return text.replace(/[&<>"']/g, m => map[m]);
    }

    // ==========================================
    // GAP-02: Live Reconciliation Matrix Scripts
    // ==========================================
    let reconData = [];
    let reconFilter = 'all';
    let isReconciling = false;
    let reconCurrentPage = 1;
    let reconTotalPages = 1;
    let reconPerPage = 100;

    async function loadReconciliationMatrix(page = 1) {
        const tbody = document.getElementById('recon-table-body');
        if (!tbody) return;

        reconCurrentPage = page;
        tbody.innerHTML = `<tr><td colspan="9" class="text-center py-12 text-slate-400">
            <div class="flex items-center justify-center gap-2">
                <svg class="w-4 h-4 animate-spin text-teal-600" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path></svg>
                Loading live ledger reconciliation matrix...
            </div>
        </td></tr>`;

        const deptSelect = document.getElementById('recon-dept-filter');
        const branchSelect = document.getElementById('recon-branch-filter');
        const deptId = deptSelect ? deptSelect.value : '';
        const branchId = branchSelect ? branchSelect.value : '';

        let url = '<?= base_url('leave/reconciliation/data') ?>?page=' + encodeURIComponent(page) + '&per_page=' + reconPerPage;
        if (deptId && deptId !== 'all') url += '&department_id=' + encodeURIComponent(deptId);
        if (branchId && branchId !== 'all') url += '&branch_id=' + encodeURIComponent(branchId);

        try {
            const res = await fetch(url, {
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            });
            const data = await res.json();

            if (data && data.success) {
                reconData = data.rows || [];
                updateReconciliationKPIs(data.metrics || {});
                updateReconciliationPagination(data.pagination || {});
                renderReconciliationRows();
            } else {
                tbody.innerHTML = `<tr><td colspan="9" class="text-center py-12 text-rose-500 font-semibold">${escapeHtml(data?.message || 'Failed to load reconciliation matrix.')}</td></tr>`;
            }
        } catch (err) {
            console.error('loadReconciliationMatrix error:', err);
            tbody.innerHTML = '<tr><td colspan="9" class="text-center py-12 text-rose-500 font-semibold">Network error while fetching reconciliation data.</td></tr>';
        }
    }

    function updateReconciliationPagination(pagination) {
        reconCurrentPage = pagination.page || 1;
        reconTotalPages = pagination.total_pages || 1;
        const totalRows = pagination.total_rows || reconData.length || 0;
        const perPage = pagination.per_page || reconPerPage;
        const startRow = totalRows === 0 ? 0 : (reconCurrentPage - 1) * perPage + 1;
        const endRow = Math.min(totalRows, reconCurrentPage * perPage);

        const infoEl = document.getElementById('recon-pagination-info');
        if (infoEl) {
            infoEl.innerText = `Showing ${startRow.toLocaleString()}–${endRow.toLocaleString()} of ${totalRows.toLocaleString()} quota records`;
        }

        const controlsEl = document.getElementById('recon-pagination-controls');
        if (!controlsEl) return;

        let html = '';
        html += `<button type="button" onclick="loadReconciliationMatrix(${reconCurrentPage - 1})" ${reconCurrentPage <= 1 ? 'disabled' : ''} class="px-2.5 py-1 rounded-lg border border-slate-200 text-xs font-semibold ${reconCurrentPage <= 1 ? 'opacity-40 cursor-not-allowed bg-slate-100 text-slate-400' : 'bg-white hover:bg-slate-50 text-slate-700'}">Previous</button>`;
        html += `<span class="px-2 py-1 text-xs font-mono font-bold text-slate-600">Page ${reconCurrentPage} of ${reconTotalPages}</span>`;
        html += `<button type="button" onclick="loadReconciliationMatrix(${reconCurrentPage + 1})" ${reconCurrentPage >= reconTotalPages ? 'disabled' : ''} class="px-2.5 py-1 rounded-lg border border-slate-200 text-xs font-semibold ${reconCurrentPage >= reconTotalPages ? 'opacity-40 cursor-not-allowed bg-slate-100 text-slate-400' : 'bg-white hover:bg-slate-50 text-slate-700'}">Next</button>`;
        controlsEl.innerHTML = html;
    }

    function updateReconciliationKPIs(metrics) {
        const total = document.getElementById('kpi-recon-total');
        const optimal = document.getElementById('kpi-recon-optimal');
        const flagged = document.getElementById('kpi-recon-flagged');
        const overdrawn = document.getElementById('kpi-recon-overdrawn');

        if (total) total.innerText = Number(metrics.total_quotas || reconData.length || 0).toLocaleString();
        if (optimal) optimal.innerText = Number(metrics.optimal_count || 0).toLocaleString();
        if (flagged) flagged.innerText = Number(metrics.flagged_count || 0).toLocaleString();
        if (overdrawn) overdrawn.innerText = Number(metrics.overdrawn_count || 0).toLocaleString();
    }

    function setReconFilter(filter) {
        reconFilter = filter;
        ['all', 'flagged', 'overdrawn', 'optimal'].forEach(tab => {
            const btn = document.getElementById('btn-recon-filter-' + tab);
            if (btn) {
                if (tab === filter) {
                    btn.className = 'px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all bg-teal-600 text-white';
                } else {
                    btn.className = 'px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all bg-slate-100 text-slate-600 hover:bg-slate-200';
                }
            }
        });
        renderReconciliationRows();
    }

    function filterReconciliationTable() {
        renderReconciliationRows();
    }

    function renderReconciliationRows() {
        const tbody = document.getElementById('recon-table-body');
        if (!tbody) return;

        const searchInput = document.getElementById('recon-search-input');
        const searchTerm = (searchInput ? searchInput.value : '').trim().toLowerCase();

        const filtered = reconData.filter(item => {
            const nameMatch = (item.employeeName || '').toLowerCase().includes(searchTerm) ||
                              (item.employeeCode || '').toLowerCase().includes(searchTerm) ||
                              (item.employeeId || '').toLowerCase().includes(searchTerm) ||
                              (item.leaveTypeName || '').toLowerCase().includes(searchTerm);

            if (!nameMatch) return false;

            if (reconFilter === 'flagged') return !item.isBalanced;
            if (reconFilter === 'overdrawn') return item.isOverdrawn;
            if (reconFilter === 'optimal') return item.isBalanced;
            return true;
        });

        if (filtered.length === 0) {
            tbody.innerHTML = '<tr><td colspan="9" class="text-center py-12 text-slate-400 font-medium">No quota records found matching the current filter.</td></tr>';
            return;
        }

        tbody.innerHTML = filtered.map(item => {
            const balClass = item.ledgerBalance < 0 ? 'bg-rose-100 text-rose-800' : 'bg-teal-50 text-teal-800';
            
            let statusIcon = '';
            if (item.isBalanced) {
                statusIcon = '<svg class="w-4 h-4 text-emerald-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>';
            } else if (item.isOverdrawn) {
                statusIcon = '<svg class="w-4 h-4 text-rose-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>';
            } else {
                statusIcon = '<svg class="w-4 h-4 text-amber-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>';
            }

            return `
                <tr class="hover:bg-slate-50/50 transition-colors">
                    <td class="py-3 px-4">
                        <div class="font-semibold text-slate-900">${escapeHtml(item.employeeName)}</div>
                        <div class="text-[11px] text-slate-400 font-mono">${escapeHtml(item.employeeCode || item.employeeId)}</div>
                    </td>
                    <td class="py-3 px-4 font-medium text-slate-800">
                        ${escapeHtml(item.leaveTypeName)}
                    </td>
                    <td class="py-3 px-3 text-right text-slate-600 font-mono">${Number(item.opening || 0).toFixed(1)}d</td>
                    <td class="py-3 px-3 text-right text-slate-600 font-mono">+${Number(item.accrued || 0).toFixed(1)}d</td>
                    <td class="py-3 px-3 text-right text-slate-600 font-mono">+${Number(item.carryForward || 0).toFixed(1)}d</td>
                    <td class="py-3 px-3 text-right text-rose-600 font-mono">-${Number(item.used || 0).toFixed(1)}d</td>
                    <td class="py-3 px-3 text-right text-amber-600 font-mono">-${Number(item.encashed || 0).toFixed(1)}d</td>
                    <td class="py-3 px-3 text-right font-bold">
                        <span class="px-2 py-0.5 rounded font-mono ${balClass}">
                            ${Number(item.ledgerBalance || 0).toFixed(1)}d
                        </span>
                    </td>
                    <td class="py-3 px-4">
                        <div class="flex items-center gap-1.5">
                            ${statusIcon}
                            <span class="text-[11px] text-slate-600 font-medium">${escapeHtml(item.statusNote)}</span>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');
    }

    async function triggerAutoReconcile() {
        if (isReconciling) return;

        const btn = document.getElementById('btn-leave-audit-repair-all');
        const btnText = document.getElementById('recon-repair-btn-text');

        isReconciling = true;
        if (btn) btn.disabled = true;
        if (btnText) btnText.innerText = 'Auditing & Repairing...';

        try {
            // Find all missing opening items
            const missingOpenings = reconData.filter(i => i.discrepancyType === 'MISSING_OPENING');

            const res = await fetch('<?= base_url('leave/reconciliation/auto-reconcile') ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
                },
                body: JSON.stringify({ items: missingOpenings })
            });

            const data = await res.json();

            if (res.ok && data.success) {
                showReconNotice('success', data.message || `Audit completed: Repaired ${data.repaired_count || 0} missing quota allocations.`);
                // Refresh table immediately
                await loadReconciliationMatrix();
            } else {
                showReconNotice('error', data.message || 'Auto-reconciliation failed.');
            }
        } catch (err) {
            console.error('triggerAutoReconcile error:', err);
            showReconNotice('error', 'Network error while attempting auto-reconciliation.');
        } finally {
            isReconciling = false;
            if (btn) btn.disabled = false;
            if (btnText) btnText.innerText = 'Audit & Reconcile Ledgers';
        }
    }

    function showReconNotice(type, message) {
        const banner = document.getElementById('recon-feedback-banner');
        const icon = document.getElementById('recon-feedback-icon');
        const msg = document.getElementById('recon-feedback-message');
        if (!banner || !msg) return;

        msg.innerText = message;

        if (type === 'success') {
            banner.className = 'p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-semibold text-emerald-800 flex items-center gap-2';
            icon.innerHTML = '<svg class="w-4 h-4 text-emerald-600 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>';
        } else {
            banner.className = 'p-4 bg-rose-50 border border-rose-200 rounded-xl text-xs font-semibold text-rose-800 flex items-center gap-2';
            icon.innerHTML = '<svg class="w-4 h-4 text-rose-600 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>';
        }

        banner.classList.remove('hidden');
        setTimeout(() => {
            if (banner) banner.classList.add('hidden');
        }, 6000);
    }

    document.addEventListener('DOMContentLoaded', () => {
        let initialTab = '<?= esc($activeTab ?? 'applications') ?>';
        if (initialTab === 'dashboard') initialTab = 'applications';
        if (initialTab === 'wizard') initialTab = 'accrualRollover';
        switchTab(initialTab);
        calculateLiveWorkingDays();

        if (initialTab === 'simulator') {
            runLeaveSimulation();
        }
        if (initialTab === 'reconciliation') {
            loadReconciliationMatrix();
        }

        // Check if query parameter requests opening apply modal directly
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('action') === 'apply' || urlParams.get('apply') === '1') {
            openModal('applyLeaveModal');
        }

        // Anti-double-click / duplicate submission guard on leave action forms
        ['approveForm', 'endorseForm', 'rejectForm', 'cancelForm'].forEach(formId => {
            const form = document.getElementById(formId);
            if (!form) return;
            form.addEventListener('submit', function(e) {
                const btn = this.querySelector('button[type="submit"]');
                if (btn) {
                    if (btn.dataset.submitting === '1') {
                        e.preventDefault();
                        return false;
                    }
                    btn.dataset.submitting = '1';
                    btn.style.opacity = '0.6';
                    btn.style.pointerEvents = 'none';
                    btn.innerText = 'Processing...';
                }
            });
        });
    });
</script>
