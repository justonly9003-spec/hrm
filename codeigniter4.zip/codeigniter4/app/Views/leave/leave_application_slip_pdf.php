<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'Official Leave Application Slip') ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    <script>
        (function() {
            const origWarn = console.warn;
            console.warn = function(...args) {
                if (typeof args[0] === 'string' && args[0].includes('cdn.tailwindcss.com should not be used in production')) {
                    return;
                }
                origWarn.apply(console, args);
            };
        })();
    </script>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        @media print {
            @page {
                size: A4 portrait;
                margin: 6mm 8mm !important;
            }
            html, body {
                background: #ffffff !important;
                padding: 0 !important;
                margin: 0 !important;
                color: #0f172a !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }
            .no-print { display: none !important; }
            .leave-sheet {
                box-shadow: none !important;
                border: none !important;
                padding: 4mm 6mm !important;
                max-width: 100% !important;
                width: 100% !important;
                margin: 0 auto !important;
            }
            .signature-box {
                break-inside: avoid !important;
                page-break-inside: avoid !important;
            }
            .leave-sheet,
            .report-header-component,
            .report-footer-component {
                break-inside: avoid !important;
                page-break-inside: avoid !important;
            }
        }
    </style>
</head>
<body class="bg-slate-900 min-h-screen p-4 sm:p-6 flex flex-col items-center justify-start text-slate-800">

    <!-- Top Action Bar (Hidden during Print) -->
    <div class="no-print max-w-4xl w-full flex items-center justify-between mb-4">
        <a href="<?= base_url('leave') ?>" class="text-xs font-semibold text-slate-300 hover:text-white flex items-center gap-1.5 transition">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
            <span>Back to Leave Register</span>
        </a>
        <div class="flex items-center gap-2">
            <button type="button" onclick="downloadLeaveSlipPdf()" class="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs rounded-xl shadow transition-all flex items-center gap-1.5 cursor-pointer border border-slate-700">
                <svg class="w-4 h-4 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                <span>Download PDF</span>
            </button>
            <button type="button" onclick="printLeaveSlipPdf()" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl shadow transition-all flex items-center gap-1.5 cursor-pointer">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
                <span>Print Leave Slip</span>
            </button>
        </div>
    </div>

    <!-- Official Leave Application Sheet -->
    <div class="leave-sheet max-w-4xl w-full bg-white p-6 sm:p-10 rounded-2xl shadow-2xl border border-slate-200">
        
        <!-- Official Dynamic Report Header Partial -->
        <?= view('reports/partials/report_header', [
            'company'            => $company,
            'reportTitle'        => 'EMPLOYEE LEAVE APPLICATION & SANCTION RECORD',
            'reportPeriod'       => 'Application Date: ' . date('d F Y', strtotime($app['applied_at'] ?? $app['created_at'] ?? 'now')),
            'reportHeaderImage'  => $company['report_header_image'] ?? null,
            'reportHeaderLayout' => $company['report_header_layout'] ?? 'center',
            'reportHeaderText'   => $company['report_header_text'] ?? null,
        ]) ?>

        <?php
            $rawStatus = ucfirst(strtolower($app['status'] ?? 'Pending'));
            $isApproved = ($rawStatus === 'Approved');
            $isPending = ($rawStatus === 'Pending');
            $isRejected = ($rawStatus === 'Rejected');
            $isCancelled = ($rawStatus === 'Cancelled');
        ?>

        <!-- Section 1: Employee Official Profile -->
        <div class="mb-5">
            <h4 class="text-xs font-bold text-slate-900 uppercase tracking-wider border-b border-slate-200 pb-1.5 mb-3 flex items-center gap-2">
                <span class="w-2 h-2 rounded-full bg-indigo-600"></span>
                <span>1. Applicant Identification & Deployment</span>
            </h4>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-3.5 bg-white p-3.5 rounded-xl border border-slate-200 text-xs">
                <div>
                    <span class="text-slate-400 block text-[10px] uppercase font-semibold">Employee Name</span>
                    <strong class="text-slate-900 text-sm font-bold block"><?= esc($app['employee_name'] ?? 'N/A') ?></strong>
                    <span class="text-slate-500 text-[11px] font-mono">ID: <?= esc($app['employee_code'] ?? $app['employee_id']) ?></span>
                </div>
                <div>
                    <span class="text-slate-400 block text-[10px] uppercase font-semibold">Department & Designation</span>
                    <strong class="text-slate-800 block font-semibold"><?= esc($app['department_name'] ?? 'General') ?></strong>
                    <span class="text-slate-600 text-[11px]"><?= esc($app['employee_designation'] ?? 'Staff Member') ?></span>
                </div>
                <div>
                    <span class="text-slate-400 block text-[10px] uppercase font-semibold">Branch & Joining Date</span>
                    <strong class="text-slate-800 block font-semibold"><?= esc($app['branch_name'] ?? 'Main Headquarters') ?></strong>
                    <span class="text-slate-500 text-[11px]">Joined: <?= !empty($app['employee_join_date']) ? esc(date('d M Y', strtotime($app['employee_join_date']))) : 'Recorded' ?></span>
                </div>
                <div class="md:col-span-2">
                    <span class="text-slate-400 block text-[10px] uppercase font-semibold">Contact & Residential Address</span>
                    <span class="text-slate-700 text-[11px] block"><?= esc($app['employee_address'] ?? 'Official company residential address on file') ?></span>
                    <span class="text-slate-500 text-[10px]">Phone: <?= esc($app['employee_phone'] ?? 'N/A') ?> • Email: <?= esc($app['employee_email'] ?? 'N/A') ?></span>
                </div>
                <div>
                    <span class="text-slate-400 block text-[10px] uppercase font-semibold">Employment Status</span>
                    <span class="inline-block mt-0.5 px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-100 text-slate-700">
                        <?= esc($app['employee_status'] ?? 'Active') ?>
                    </span>
                </div>
            </div>
        </div>

        <!-- Section 2: Leave Application Particulars -->
        <div class="mb-5">
            <h4 class="text-xs font-bold text-slate-900 uppercase tracking-wider border-b border-slate-200 pb-1.5 mb-3 flex items-center gap-2">
                <span class="w-2 h-2 rounded-full bg-indigo-600"></span>
                <span>2. Leave Request Details</span>
            </h4>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 bg-white p-3.5 rounded-xl border border-slate-200 text-xs mb-3">
                <div>
                    <span class="text-slate-400 block text-[10px] uppercase font-semibold">Leave Type</span>
                    <strong class="text-indigo-700 text-sm font-bold block"><?= esc($app['leave_type_name'] ?? 'Leave') ?> (<?= esc($app['leave_type_code'] ?? 'LV') ?>)</strong>
                    <span class="text-[10px] font-semibold text-slate-500"><?= !empty($app['leave_is_paid']) ? 'Paid Category' : 'Unpaid (LWP)' ?></span>
                </div>
                <div>
                    <span class="text-slate-400 block text-[10px] uppercase font-semibold">Schedule / Duration</span>
                    <strong class="text-slate-900 block font-bold">
                        <?= esc(date('d M Y', strtotime($app['from_date'] ?? $app['start_date']))) ?> &rarr; <?= esc(date('d M Y', strtotime($app['to_date'] ?? $app['end_date']))) ?>
                    </strong>
                    <span class="text-[10px] text-slate-500 font-mono">
                        <?php if (!empty($app['is_half_day'])): ?>
                            Half Day (0.50 d)
                        <?php elseif (!empty($app['is_hourly'])): ?>
                            Hourly (<?= esc($app['hourly_hours'] ?? 0) ?> hrs)
                        <?php else: ?>
                            Full Day Regular
                        <?php endif; ?>
                    </span>
                </div>
                <div>
                    <span class="text-slate-400 block text-[10px] uppercase font-semibold">Total Working Days</span>
                    <div class="flex items-baseline gap-1 mt-0.5">
                        <span class="text-xl font-black font-mono text-slate-900"><?= esc(number_format((float)($app['total_days'] ?? 1), 2)) ?></span>
                        <span class="text-xs font-bold text-slate-500">Days</span>
                    </div>
                </div>
                <div>
                    <span class="text-slate-400 block text-[10px] uppercase font-semibold">Work Reliever / Handover</span>
                    <strong class="text-slate-800 block font-semibold truncate"><?= esc($app['covering_employee_name'] ?? 'Designated Colleague / Dept') ?></strong>
                    <span class="text-[10px] text-slate-500 font-mono"><?= !empty($app['covering_employee_code']) ? 'Code: ' . esc($app['covering_employee_code']) : 'Responsibility delegated' ?></span>
                </div>
            </div>



            <!-- Reason and Emergency Contact Box -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs">
                <div class="md:col-span-2">
                    <span class="text-slate-400 block text-[10px] uppercase font-semibold">Purpose & Stated Reason for Leave</span>
                    <p class="text-slate-800 mt-1 italic text-xs leading-relaxed bg-white p-2.5 rounded-lg border border-slate-200">
                        "<?= esc($app['reason'] ?? 'Not specified in self-service submission.') ?>"
                    </p>
                </div>
                <div>
                    <span class="text-slate-400 block text-[10px] uppercase font-semibold">Emergency Contact During Leave</span>
                    <div class="mt-1 bg-white p-2.5 rounded-lg border border-slate-200 text-xs text-slate-700">
                        <strong class="block text-slate-900"><?= esc($app['emergency_contact'] ?? $app['employee_phone'] ?? 'Contact via official email') ?></strong>
                        <span class="text-[10px] text-slate-400 block mt-1">Available for emergency contact</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section 3: Full Employee Leave Balance Status -->
        <div class="mb-5">
            <div class="flex items-center justify-between border-b border-slate-200 pb-1.5 mb-2.5">
                <h4 class="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                    <span class="w-2 h-2 rounded-full bg-indigo-600"></span>
                    <span>3. Leave Account Summary (Year: <?= esc($year ?? date('Y')) ?>)</span>
                </h4>
                <span class="text-[10px] text-slate-400 font-mono">Live Audited Ledger</span>
            </div>

            <div class="overflow-x-auto border border-slate-200 rounded-xl">
                <table class="w-full text-left text-xs text-slate-600">
                    <thead class="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 text-[10px] uppercase">
                        <tr>
                            <th class="p-2.5">Leave Category</th>
                            <th class="p-2.5 text-center">Nature</th>
                            <th class="p-2.5 text-right">Entitlement</th>
                            <th class="p-2.5 text-right">Brought Forward</th>
                            <th class="p-2.5 text-right">Total Quota</th>
                            <th class="p-2.5 text-right">Taken / Used</th>
                            <th class="p-2.5 text-right">Pending</th>
                            <th class="p-2.5 text-right font-black text-indigo-900">Remaining Balance</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 bg-white">
                        <?php if (empty($balances)): ?>
                            <tr>
                                <td colspan="8" class="p-4 text-center text-slate-400 italic text-xs">No active leave quota definitions found for this organization.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($balances as $b): ?>
                                <?php
                                    $isCurrentLeaveType = ((string)($b['type_id'] ?? '') === (string)($app['leave_type_id'] ?? ''));
                                    $rowBg = $isCurrentLeaveType ? 'bg-indigo-50/70 font-semibold' : 'hover:bg-slate-50/50';
                                    $open = (float)($b['opening_balance'] ?? 0);
                                    $alloc = (float)($b['allocated_days'] ?? 0);
                                    $cf = (float)($b['carry_forward_days'] ?? 0);
                                    $tot = isset($b['total_entitlement']) ? (float)$b['total_entitlement'] : ($open + $alloc + $cf);
                                    $appr = (float)($b['approved_leave_days'] ?? 0);
                                    $pend = (float)($b['pending_leave_days'] ?? 0);
                                    $rem = (float)($b['available_balance'] ?? ($tot - $appr));
                                ?>
                                <tr class="<?= $rowBg ?>">
                                    <td class="p-2.5">
                                        <div class="flex items-center gap-1.5">
                                            <span class="font-bold text-slate-900"><?= esc($b['type_name'] ?? 'Leave') ?></span>
                                            <span class="text-[10px] font-mono text-slate-400">(<?= esc($b['type_code'] ?? 'LV') ?>)</span>
                                            <?php if ($isCurrentLeaveType): ?>
                                                <span class="text-[9px] uppercase px-1.5 py-0.2 bg-indigo-600 text-white rounded font-bold">Applied</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td class="p-2.5 text-center text-[10px]">
                                        <span class="px-2 py-0.5 rounded-full font-bold <?= !empty($b['is_paid']) ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-600' ?>">
                                            <?= !empty($b['is_paid']) ? 'Paid' : 'Unpaid' ?>
                                        </span>
                                    </td>
                                    <td class="p-2.5 text-right font-mono"><?= number_format($alloc, 1) ?></td>
                                    <td class="p-2.5 text-right font-mono"><?= number_format($cf, 1) ?></td>
                                    <td class="p-2.5 text-right font-mono font-bold text-slate-800"><?= number_format($tot, 1) ?></td>
                                    <td class="p-2.5 text-right font-mono text-rose-600"><?= number_format($appr, 1) ?></td>
                                    <td class="p-2.5 text-right font-mono text-amber-600"><?= number_format($pend, 1) ?></td>
                                    <td class="p-2.5 text-right font-mono font-black text-indigo-700 text-sm"><?= number_format($rem, 1) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Official Physical Signatures for Hard Copy Maintenance -->
        <div class="signature-box pt-5 mt-6 border-t-2 border-slate-300">
            <div class="text-center mb-5">
                <span class="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Official Physical Signatures & Approvals (Hard Copy Record Retention)</span>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-8 text-center text-xs max-w-3xl mx-auto">
                <!-- 1. Employee Signature -->
                <div class="space-y-1 bg-slate-50/50 p-4 rounded-xl border border-dashed border-slate-300 flex flex-col justify-between">
                    <div class="text-[10px] text-slate-400 text-left mb-6 italic">
                        "I certify that the requested leave dates are correct and undertake to resume duties on the scheduled date."
                    </div>
                    <div>
                        <div class="h-12 border-b border-slate-400 mb-1.5"></div>
                        <div class="text-[11px] font-bold text-slate-900 uppercase">Employee Signature</div>
                        <div class="text-[10px] text-slate-500 font-mono"><?= esc($app['employee_name'] ?? 'Applicant') ?></div>
                        <div class="text-[9px] text-slate-400 mt-0.5">Date: _____/_____/20___</div>
                    </div>
                </div>

                <!-- 2. HR Director / Authorizing Official -->
                <div class="space-y-1 bg-slate-50/50 p-4 rounded-xl border border-dashed border-slate-300 flex flex-col justify-between">
                    <div class="text-[10px] text-slate-600 text-left mb-3 flex flex-col gap-1">
                        <span class="font-bold text-slate-700">Sanction Authority:</span>
                        <div class="flex items-center gap-3 text-[9.5px]">
                            <span>[ <?= $isApproved ? '✓' : '&nbsp;&nbsp;' ?> ] Paid</span>
                            <span>[ &nbsp;&nbsp; ] Unpaid</span>
                            <span>[ <?= $isRejected ? '✓' : '&nbsp;&nbsp;' ?> ] Rej.</span>
                        </div>
                    </div>
                    <div>
                        <div class="h-12 border-b border-slate-400 mb-1.5"></div>
                        <div class="text-[11px] font-bold text-slate-900 uppercase">HR / Managing Authority</div>
                        <div class="text-[10px] text-slate-500 font-mono">Seal & Signature</div>
                        <div class="text-[9px] text-slate-400 mt-0.5">Date: _____/_____/20___</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Official Report Footer Partial -->
        <div class="mt-4">
            <?= view('reports/partials/report_footer', [
                'company'            => $company,
                'reportFooterImage'  => $company['report_footer_image'] ?? null,
                'reportFooterText'   => $company['report_footer_text'] ?? 'Official document issued under Enterprise HR & Payroll Policy. Original hard copy with physical signatures must be retained in employee dossier.',
                'reportFooterLayout' => $company['report_footer_layout'] ?? 'center',
                'generatedDate'      => date('Y-m-d H:i:s'),
                'pageNumberText'     => 'Form HR-LA-01'
            ]) ?>
        </div>

    </div>

    <!-- Client-side PDF Generation Engine -->
    <script src="https://cdn.jsdelivr.net/npm/html2canvas-pro@1.5.8/dist/html2canvas-pro.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script>
        async function printLeaveSlipPdf() {
            const element = document.querySelector('.leave-sheet');
            if (!element) {
                window.print();
                return;
            }

            try {
                if (window.html2canvas && (window.jspdf || window.jsPDF)) {
                    const canvas = await window.html2canvas(element, {
                        scale: 2,
                        useCORS: true,
                        logging: false,
                        backgroundColor: '#ffffff',
                        windowWidth: 794,
                        onclone: (clonedDoc) => {
                            const clonedElement = clonedDoc.querySelector('.leave-sheet');
                            if (clonedElement) {
                                const hiddenEls = clonedElement.querySelectorAll('[style*="display: none"], [style*="display:none"]');
                                hiddenEls.forEach(el => el.remove());

                                clonedElement.style.padding = '20px 24px';
                                clonedElement.style.maxWidth = '794px';
                                clonedElement.style.width = '794px';
                                clonedElement.style.boxSizing = 'border-box';
                                clonedElement.style.backgroundColor = '#ffffff';
                                clonedElement.style.height = 'auto';
                                clonedElement.style.minHeight = 'auto';
                                clonedElement.style.position = 'static';
                                clonedElement.style.margin = '0 auto';
                            }
                        }
                    });
                    const imgData = canvas.toDataURL('image/jpeg', 0.98);
                    const { jsPDF } = window.jspdf || window;
                    const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
                    const pdfWidth = 210;
                    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
                    pdf.addImage(imgData, 'JPEG', 0, 0, pdfWidth, pdfHeight);

                    const pdfBlob = pdf.output('blob');
                    const blobUrl = URL.createObjectURL(pdfBlob);
                    const printTab = window.open(blobUrl, '_blank');
                    if (printTab) {
                        printTab.focus();
                    } else {
                        const printIframe = document.createElement('iframe');
                        printIframe.style.position = 'fixed';
                        printIframe.style.right = '0';
                        printIframe.style.bottom = '0';
                        printIframe.style.width = '0';
                        printIframe.style.height = '0';
                        printIframe.style.border = '0';
                        printIframe.src = blobUrl;
                        document.body.appendChild(printIframe);
                        printIframe.onload = () => {
                            setTimeout(() => {
                                printIframe.contentWindow.focus();
                                printIframe.contentWindow.print();
                            }, 500);
                        };
                    }
                } else {
                    window.print();
                }
            } catch (err) {
                console.error('Print Generation error:', err);
                window.print();
            }
        }

        async function downloadLeaveSlipPdf() {
            const element = document.querySelector('.leave-sheet');
            if (!element) return;
            const code = '<?= esc($app['employee_code'] ?? 'EMP') ?>';
            const id = '<?= esc($app['id'] ?? 'LEAVE') ?>';
            const filename = `LeaveSlip-${code}-${id}.pdf`;

            try {
                if (window.html2canvas && (window.jspdf || window.jsPDF)) {
                    const canvas = await window.html2canvas(element, {
                        scale: 2,
                        useCORS: true,
                        logging: false,
                        backgroundColor: '#ffffff',
                        windowWidth: 794,
                        onclone: (clonedDoc) => {
                            const clonedElement = clonedDoc.querySelector('.leave-sheet');
                            if (clonedElement) {
                                const hiddenEls = clonedElement.querySelectorAll('[style*="display: none"], [style*="display:none"]');
                                hiddenEls.forEach(el => el.remove());

                                clonedElement.style.padding = '20px 24px';
                                clonedElement.style.maxWidth = '794px';
                                clonedElement.style.width = '794px';
                                clonedElement.style.boxSizing = 'border-box';
                                clonedElement.style.backgroundColor = '#ffffff';
                                clonedElement.style.height = 'auto';
                                clonedElement.style.minHeight = 'auto';
                                clonedElement.style.position = 'static';
                                clonedElement.style.margin = '0 auto';
                            }
                        }
                    });
                    const imgData = canvas.toDataURL('image/jpeg', 0.98);
                    const { jsPDF } = window.jspdf || window;
                    const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
                    const pdfWidth = 210;
                    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
                    pdf.addImage(imgData, 'JPEG', 0, 0, pdfWidth, pdfHeight);
                    pdf.save(filename);
                } else {
                    window.print();
                }
            } catch (err) {
                console.error('PDF Generation error:', err);
                window.print();
            }
        }
    </script>
</body>
</html>
