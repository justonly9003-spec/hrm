<!-- TAB: Group / Team / Department Attendance Matrix -->
<script>
window.groupAttendanceModule = function() {
    return {
        selectedDate: <?= json_encode($date ?? date('Y-m-d')) ?>,
        deptFilter: 'all',
        branchFilter: 'all',
        desgFilter: 'all',
        shiftFilter: 'all',
        statusFilter: 'all',
        searchQuery: '',
        isLoadingGroup: false,
        isApplying: false,
        groupTabInitialized: false,
        _abortController: null,

        allEmployees: <?= json_encode($employees ?? []) ?>,
        allShifts: <?= json_encode($shifts ?? []) ?>,
        allDepartments: <?= json_encode($departments ?? []) ?>,
        allBranches: <?= json_encode($branches ?? []) ?>,
        allDesignations: <?= json_encode($designations ?? []) ?>,
        allHolidays: <?= json_encode($holidays ?? []) ?>,
        allLeaves: <?= json_encode($leaves ?? []) ?>,
        allGroupLogs: <?= json_encode($empHistoryLogs ?? $logs ?? []) ?>,
        policySettings: <?= json_encode($settings ?? []) ?>,
        serverCalculations: <?= json_encode($serverCalculations ?? (object)[]) ?>,

        initGroupTab() {
            if (this.groupTabInitialized) return;
            this.groupTabInitialized = true;

            if (!this.selectedDate) {
                this.selectedDate = <?= json_encode($date ?? date('Y-m-d')) ?>;
            }
            this.isLoadingGroup = false;
            this.isApplying = false;

            const isGroupActive = () => (window.attendanceApp ? window.attendanceApp.activeTab === 'group' : (window.location.search.includes('tab=group')));

            if (isGroupActive() && (!this.allGroupLogs || !this.allGroupLogs.length)) {
                this.fetchGroupLogsForDate(this.selectedDate);
            }

            window.addEventListener('tab-changed', (e) => {
                if (e.detail?.tab === 'group' && (!this.allGroupLogs || !this.allGroupLogs.length)) {
                    this.fetchGroupLogsForDate(this.selectedDate);
                }
            });

            this.$watch('selectedDate', (newDate, oldDate) => {
                if (newDate && oldDate && newDate !== oldDate) {
                    this.fetchGroupLogsForDate(newDate);
                }
            });

            this.$nextTick(() => {
                if (window.lucide) window.lucide.createIcons();
            });
        },

    async applyFilters() {
        if (this.isApplying || this.isLoadingGroup) return;
        this.isApplying = true;
        try {
            await this.fetchGroupLogsForDate(this.selectedDate);
        } catch (err) {
            console.error('Apply filter error:', err);
        } finally {
            this.isApplying = false;
            this.isLoadingGroup = false;
        }
    },

    fetchGroupLogsForDate(targetDate) {
        if (!targetDate) {
            this.isLoadingGroup = false;
            this.isApplying = false;
            return Promise.resolve();
        }

        if (this._abortController) {
            this._abortController.abort();
        }
        this._abortController = new AbortController();
        const currentSignal = this._abortController.signal;

        this.isLoadingGroup = true;
        const params = new URLSearchParams();
        params.append('date', targetDate);

        return fetch('<?= base_url('attendance/group-ajax') ?>?' + params.toString(), {
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
            signal: currentSignal
        })
        .then(res => {
            if (!res.ok) throw new Error(`HTTP error: ${res.status}`);
            return res.json();
        })
        .then(data => {
            if (data && (data.status === 'success' || data.success) && data.data) {
                if (Array.isArray(data.data.logs)) {
                    const freshLogs = data.data.logs;
                    const otherLogs = (this.allGroupLogs || []).filter(l => (l.date || l.attendance_date) !== targetDate);
                    this.allGroupLogs = [...otherLogs, ...freshLogs];
                }
                if (data.data.leaves) {
                    this.allLeaves = data.data.leaves;
                }
                if (data.data.holidays) {
                    this.allHolidays = data.data.holidays;
                }
                if (data.data.calculated_results && Array.isArray(data.data.calculated_results)) {
                    const calcMap = {};
                    data.data.calculated_results.forEach(cr => {
                        if (cr.employee && cr.employee.id) {
                            calcMap[String(cr.employee.id).toLowerCase()] = cr.calculation;
                        }
                        if (cr.employee && cr.employee.employee_code) {
                            calcMap[String(cr.employee.employee_code).toLowerCase()] = cr.calculation;
                        }
                    });
                    this.serverCalculations = calcMap;
                }
            }
        })
        .catch(err => {
            if (err.name !== 'AbortError') {
                console.warn('Group attendance remote fetch fallback:', err);
            }
        })
        .finally(() => {
            this.isLoadingGroup = false;
            this.isApplying = false;
            this._abortController = null;
            this.$nextTick(() => {
                if (window.lucide) window.lucide.createIcons();
            });
        });
    },

    get calculatedRows() {
        const selDate = this.selectedDate || '<?= esc($date ?? date('Y-m-d')) ?>';
        const [yr, mo, da] = selDate.split('-').map(Number);
        const dateObj = new Date(yr, (mo || 1) - 1, da || 1, 12, 0, 0);
        const dayOfWeek = dateObj.toLocaleDateString('en-US', { weekday: 'short' });
        const dayFull = dateObj.toLocaleDateString('en-US', { weekday: 'long' });

        // Check if holiday - computed once for the selected date
        const holiday = (this.allHolidays || []).find(h => {
            if (h.date === selDate) return true;
            if (h.from_date && h.to_date && selDate >= h.from_date && selDate <= h.to_date) return true;
            return false;
        });
        const isHoliday = !!holiday;
        const holidayName = holiday ? (holiday.name || 'Company Holiday') : null;

        // Build Map lookups for O(1) indexed access
        const shiftsMap = new Map();
        (this.allShifts || []).forEach(s => {
            if (s && s.id !== undefined) shiftsMap.set(String(s.id), s);
        });
        const defaultShift = (this.allShifts && this.allShifts[0]) || {
            id: 'shift-001',
            name: 'General Shift (8 AM - 4 PM)',
            start_time: '08:00',
            end_time: '16:00',
            grace_time: 15
        };

        const deptMap = new Map();
        (this.allDepartments || []).forEach(d => {
            if (d && d.id !== undefined) deptMap.set(String(d.id), d);
        });

        const branchMap = new Map();
        (this.allBranches || []).forEach(b => {
            if (b && b.id !== undefined) branchMap.set(String(b.id), b);
        });

        const desgMap = new Map();
        (this.allDesignations || []).forEach(d => {
            if (d && d.id !== undefined) desgMap.set(String(d.id), d);
        });

        // Index logs for selDate by employee id and employee code
        const logsByEmp = new Map();
        (this.allGroupLogs || []).forEach(l => {
            const lDate = l.date || l.attendance_date || l.log_date;
            if (lDate === selDate) {
                const lEmpId = String(l.employee_id || l.employeeId || '').toLowerCase().trim();
                if (lEmpId) logsByEmp.set(lEmpId, l);
            }
        });

        // Index approved leaves covering selDate by employee id and employee code
        const leavesByEmp = new Map();
        (this.allLeaves || []).forEach(la => {
            if (String(la.status).toLowerCase() === 'approved') {
                const s = la.start_date || la.from_date;
                const e = la.end_date || la.to_date;
                if (s && e && selDate >= s && selDate <= e) {
                    const laEmpId = String(la.employee_id || la.employeeId || '').toLowerCase().trim();
                    if (laEmpId) leavesByEmp.set(laEmpId, la);
                }
            }
        });

        const defaultGrace = parseInt(this.policySettings?.graceTime || 15);

        return (this.allEmployees || []).map(emp => {
            const empId = String(emp.id || '').toLowerCase().trim();
            const empCode = String(emp.employee_code || '').toLowerCase().trim();

            // Check if server-side RuleEngineService evaluation exists
            const serverCalc = this.serverCalculations[empId] || this.serverCalculations[empCode] || null;

            // O(1) matching log for this employee on selDate
            const log = (empId && logsByEmp.get(empId)) || (empCode && logsByEmp.get(empCode)) || null;

            // O(1) Shift lookup
            const shiftId = String(emp.shift_id || emp.shiftId || '');
            const shift = (shiftId && shiftsMap.get(shiftId)) || defaultShift;

            const shiftStart = shift.start_time || emp.start_time || '08:00';
            const shiftEnd = shift.end_time || emp.end_time || '16:00';
            const graceMinutes = parseInt(shift.grace_time || shift.late_grace_period_mins || defaultGrace);

            // O(1) Dept, Branch, Desg lookups
            const empDeptId = String(emp.department_id || emp.departmentId || '');
            const dept = (empDeptId && deptMap.get(empDeptId)) || { name: emp.department_name || emp.department || 'General' };

            const empBranchId = String(emp.branch_id || emp.branchId || '');
            const branch = (empBranchId && branchMap.get(empBranchId)) || { name: emp.branch_name || emp.branch || 'Main HQ' };

            const empDesgId = String(emp.designation_id || emp.designationId || '');
            const desg = (empDesgId && desgMap.get(empDesgId)) || { name: emp.designation_name || emp.role || 'Staff' };

            // Check if Weekly Off
            let groupOffDays = emp.weekly_off_days || emp.weekly_off || (window.attendanceSettings && window.attendanceSettings.weekendDays) || [];
            if (typeof groupOffDays === 'string') {
                try { groupOffDays = JSON.parse(groupOffDays); } catch(e) { groupOffDays = groupOffDays.split(',').map(s => s.trim()); }
            }
            const isWeeklyOff = serverCalc ? (serverCalc.is_weekly_off ?? false) : (Array.isArray(groupOffDays) ? groupOffDays.includes(dayFull) : false);

            // O(1) Leave lookup
            const leave = (empId && leavesByEmp.get(empId)) || (empCode && leavesByEmp.get(empCode)) || null;
            const isOnLeave = serverCalc ? (serverCalc.is_on_leave ?? !!leave) : !!leave;

            // Compute Punch Times & Metrics (Using server-side authoritative engine if present, else client evaluation)
            let checkIn = serverCalc ? (serverCalc.check_in || '') : (log ? (log.check_in || '') : '');
            let checkOut = serverCalc ? (serverCalc.check_out || '') : (log ? (log.check_out || '') : '');
            let workingHours = serverCalc ? parseFloat(serverCalc.net_hours || 0) : (log ? parseFloat(log.working_hours || 0) : 0);
            let overtimeHours = serverCalc ? (parseFloat(serverCalc.daily_overtime_hours || 0) + parseFloat(serverCalc.off_day_overtime_hours || 0) + parseFloat(serverCalc.holiday_overtime_hours || 0)) : (log ? parseFloat(log.overtime_hours || 0) : 0);
            let lateMinutes = serverCalc ? parseInt(serverCalc.late_minutes || 0) : (log ? parseInt(log.late_minutes || 0) : 0);
            let earlyOutMinutes = serverCalc ? parseInt(serverCalc.early_out_minutes || 0) : (log ? parseInt(log.early_out_minutes || 0) : 0);
            let source = log ? (log.verification_method || log.source || 'Biometric') : 'Web';
            let status = serverCalc ? serverCalc.status : 'Absent';

            const isClosureLog = !!(
                (serverCalc && serverCalc.is_company_closure) ||
                (log && (
                    parseInt(log.is_company_closure || 0) === 1 ||
                    parseFloat(log.closure_credit_hours || 0) > 0 ||
                    ['present (early closure)', 'early closure covered', 'approved early closure'].includes(String(log.status || '').trim().toLowerCase()) ||
                    String(log.verification_method || '').toLowerCase().includes('early closure')
                ))
            );

            // Real-time recalculation if log exists and no serverCalc was injected
            if (!serverCalc && log && checkIn && checkIn !== '--:--:--' && checkIn !== '---') {
                const inParts = checkIn.split(':').map(Number);
                const shiftInParts = shiftStart.split(':').map(Number);
                const inTotalMins = (inParts[0] * 60) + (inParts[1] || 0);
                const shiftInTotalMins = (shiftInParts[0] * 60) + (shiftInParts[1] || 0);

                if (inTotalMins > (shiftInTotalMins + graceMinutes)) {
                    lateMinutes = inTotalMins - shiftInTotalMins;
                } else if (!isClosureLog) {
                    lateMinutes = 0;
                }

                if (checkOut && checkOut !== '--:--:--' && checkOut !== '---') {
                    const outParts = checkOut.split(':').map(Number);
                    const shiftOutParts = shiftEnd.split(':').map(Number);
                    const outTotalMins = (outParts[0] * 60) + (outParts[1] || 0);
                    const shiftOutTotalMins = (shiftOutParts[0] * 60) + (shiftOutParts[1] || 0);

                    if (!isClosureLog && outTotalMins < shiftOutTotalMins) {
                        earlyOutMinutes = shiftOutTotalMins - outTotalMins;
                    } else {
                        earlyOutMinutes = 0;
                    }

                    const breakEnabled = this.policySettings?.breakEnabled ?? false;
                    const breakIsPaid = this.policySettings?.breakIsPaid ?? false;
                    const breakHours = (breakEnabled && !breakIsPaid) ? ((parseInt(this.policySettings?.breakDurationMinutes || 60)) / 60) : 0;

                    if (!workingHours || workingHours <= 0) {
                        let duration = (outTotalMins - inTotalMins) / 60;
                        if (breakHours > 0 && duration > breakHours && duration >= 4.0) {
                            duration -= breakHours;
                        }
                        workingHours = Math.max(0, duration) + (isClosureLog ? parseFloat(log.closure_credit_hours || 0) : 0);
                    }

                    const standardShiftHours = Math.max(0, ((shiftOutTotalMins - shiftInTotalMins) / 60) - breakHours);
                    if (!isClosureLog && !overtimeHours && workingHours > standardShiftHours) {
                        overtimeHours = workingHours - standardShiftHours;
                    }
                } else if (isClosureLog) {
                    earlyOutMinutes = 0;
                }

                const hasCheckOut = checkOut && checkOut !== '--:--:--' && checkOut !== '---';
                if (isClosureLog) {
                    const rawLogSt = String(log.status || '').trim();
                    status = (lateMinutes > 0 || rawLogSt === 'Late' || rawLogSt === 'Late & Early Out') ? 'Late' : 'Present (Early Closure)';
                } else if (hasCheckOut && workingHours > 0 && workingHours < 4) {
                    status = 'Half Day';
                } else if (lateMinutes > 0 && earlyOutMinutes > 0) {
                    status = 'Late & Early Out';
                } else if (lateMinutes > 0) {
                    status = 'Late';
                } else if (earlyOutMinutes > 0) {
                    status = 'Early Out';
                } else {
                    status = log.status || 'Present';
                }
            } else if (!serverCalc) {
                if (isOnLeave) {
                    status = leave.leave_type_name || leave.leave_type || 'On Leave';
                } else if (isHoliday) {
                    status = 'Holiday';
                } else if (isWeeklyOff) {
                    status = 'Weekly Off';
                } else {
                    status = 'Absent';
                }
            }

            const isLate = serverCalc ? (serverCalc.is_late ?? lateMinutes > 0) : (lateMinutes > 0 || status === 'Late' || status === 'Late & Early Out');
            const isEarlyOut = isClosureLog ? false : (serverCalc ? (serverCalc.is_early_out ?? earlyOutMinutes > 0) : (earlyOutMinutes > 0 || status === 'Early Out' || status === 'Late & Early Out'));

            const logPayload = {
                id: log ? (log.id || ('SYN-' + emp.id + '-' + selDate)) : ('SYN-' + emp.id + '-' + selDate),
                employee_id: emp.id,
                employee_name: emp.name || `${emp.first_name || ''} ${emp.last_name || ''}`,
                employee_code: emp.employee_code || emp.id,
                date: selDate,
                attendance_date: selDate,
                department_name: dept.name,
                branch_name: branch.name,
                designation_name: desg.name || desg.title,
                shift_name: shift.name,
                shift_start: shiftStart,
                shift_end: shiftEnd,
                check_in: checkIn || '--:--:--',
                check_out: checkOut || '--:--:--',
                late_minutes: lateMinutes,
                early_out_minutes: earlyOutMinutes,
                working_hours: workingHours,
                overtime_hours: overtimeHours,
                status: status,
                verification_method: source,
                notes: log ? log.notes : '',
                gps_lat: log ? log.gps_lat : null,
                gps_lon: log ? log.gps_lon : null,
                rule_profile_applied: serverCalc ? serverCalc.rule_profile_applied : null,
                ot_amount: serverCalc ? serverCalc.ot_amount : 0
            };

            return {
                employee: emp,
                shift: shift,
                dept: dept,
                branch: branch,
                desg: desg,
                date: selDate,
                shiftStart: shiftStart,
                shiftEnd: shiftEnd,
                checkIn: checkIn || '--:--:--',
                checkOut: checkOut || '--:--:--',
                lateMinutes: lateMinutes,
                earlyOutMinutes: earlyOutMinutes,
                workingHours: workingHours,
                overtimeHours: overtimeHours,
                status: status,
                source: source,
                isLate: isLate,
                isEarlyOut: isEarlyOut,
                isHoliday: isHoliday,
                isWeeklyOff: isWeeklyOff,
                isOnLeave: isOnLeave,
                holidayName: holidayName,
                leaveType: leave ? (leave.leave_type_name || leave.leave_type || 'Approved Leave') : null,
                logObj: logPayload,
                serverCalculation: serverCalc
            };
        });
    },

    get filteredRows() {
        return this.calculatedRows.filter(row => {
            const emp = row.employee;
            const deptId = String(emp.department_id || emp.departmentId || '');
            const branchId = String(emp.branch_id || emp.branchId || '');
            const desgId = String(emp.designation_id || emp.designationId || '');
            const shiftId = String(emp.shift_id || emp.shiftId || '');

            if (this.deptFilter !== 'all' && deptId !== this.deptFilter) return false;
            if (this.branchFilter !== 'all' && branchId !== this.branchFilter) return false;
            if (this.desgFilter !== 'all' && desgId !== this.desgFilter) return false;
            if (this.shiftFilter !== 'all' && shiftId !== this.shiftFilter) return false;

            if (this.statusFilter !== 'all') {
                const stLower = String(row.status || '').trim().toLowerCase();
                const isPresentRow = ['present', 'present (early closure)', 'early closure covered', 'approved early closure', 'late', 'early out', 'late & early out', 'half day', 'on time', 'grace', 'wfh', 'remote', 'off-day work', 'weekend duty present', 'holiday duty present'].includes(stLower);
                if (this.statusFilter === 'Present') {
                    if (!isPresentRow) return false;
                } else if (this.statusFilter === 'Late') {
                    if (!row.isLate) return false;
                } else if (this.statusFilter === 'Early Out') {
                    if (!row.isEarlyOut) return false;
                } else if (this.statusFilter === 'Absent') {
                    if (row.status !== 'Absent') return false;
                } else if (this.statusFilter === 'On Leave') {
                    if (!row.isOnLeave && !stLower.includes('leave')) return false;
                } else if (this.statusFilter === 'Half Day') {
                    if (row.status !== 'Half Day') return false;
                } else if (this.statusFilter === 'Holiday') {
                    if (!row.isHoliday && row.status !== 'Holiday') return false;
                } else if (this.statusFilter === 'Weekly Off') {
                    if (!row.isWeeklyOff && row.status !== 'Weekly Off') return false;
                } else if (row.status !== this.statusFilter) {
                    return false;
                }
            }

            if (this.searchQuery) {
                const q = this.searchQuery.toLowerCase().trim();
                const name = (emp.name || `${emp.first_name || ''} ${emp.last_name || ''}`).toLowerCase();
                const code = (emp.employee_code || emp.id || '').toLowerCase();
                const deptName = (row.dept?.name || '').toLowerCase();
                const branchName = (row.branch?.name || '').toLowerCase();
                const desgName = (row.desg?.name || row.desg?.title || '').toLowerCase();
                if (!name.includes(q) && !code.includes(q) && !deptName.includes(q) && !branchName.includes(q) && !desgName.includes(q)) {
                    return false;
                }
            }

            return true;
        });
    },

    get groupStats() {
        const rows = this.filteredRows;
        let present = 0;
        let late = 0;
        let earlyOut = 0;
        let absent = 0;
        let onLeave = 0;
        let halfDay = 0;
        let totalWorkedHours = 0;
        let totalOvertimeHours = 0;

        rows.forEach(r => {
            totalWorkedHours += (parseFloat(r.workingHours) || 0);
            totalOvertimeHours += (parseFloat(r.overtimeHours) || 0);

            const stLower = String(r.status || '').trim().toLowerCase();
            const isPres = [
                'present',
                'present (early closure)',
                'early closure covered',
                'approved early closure',
                'late',
                'early out',
                'late & early out',
                'half day',
                'on time',
                'grace',
                'wfh',
                'remote',
                'off-day work',
                'weekend duty present',
                'holiday duty present'
            ].includes(stLower);
            if (isPres) {
                present++;
            }

            if (r.status === 'Half Day') {
                halfDay++;
            }

            const isLate = r.isLate || r.status === 'Late' || r.status === 'Late & Early Out' || (parseInt(r.lateMinutes) > 0);
            if (isLate) {
                late++;
            }

            const isEarlyOut = r.isEarlyOut || r.status === 'Early Out' || r.status === 'Late & Early Out' || (parseInt(r.earlyOutMinutes) > 0);
            if (isEarlyOut) {
                earlyOut++;
            }

            if (r.isOnLeave || (r.status && r.status.toLowerCase().includes('leave'))) {
                onLeave++;
            } else if (r.status === 'Holiday' || r.status === 'Weekly Off') {
                // Not counted as absent
            } else if (!isPres && r.status !== 'Missing Punch') {
                absent++;
            }
        });

        const total = rows.length || 1;
        const presenceRate = Math.round((present / total) * 100);
        const punctualityRate = present > 0 ? Math.round(((present - late) / present) * 100) : 100;

        return {
            totalInGroup: rows.length,
            present,
            late,
            earlyOut,
            absent,
            onLeave,
            halfDay,
            totalWorkedHours: totalWorkedHours.toFixed(1),
            totalOvertimeHours: totalOvertimeHours.toFixed(1),
            presenceRate,
            punctualityRate
        };
    },

    exportGroupCsv() {
        const rows = this.filteredRows;
        if (!rows || rows.length === 0) {
            alert('No employee records to export for the selected filters.');
            return;
        }

        const headers = [
            'Employee ID', 'Name', 'Department', 'Branch', 'Designation', 'Shift', 
            'Date', 'Scheduled In', 'Actual In', 'Late (Min)', 'Scheduled Out', 'Actual Out', 
            'Early Out (Min)', 'Worked (Hours)', 'Daily OT (Hours)', 'Status', 'Leave', 'Holiday', 'Source'
        ];

        const escapeCell = (val) => {
            const str = String(val ?? '');
            if (str.includes(',') || str.includes('\"') || str.includes('\n')) {
                return '\"' + str.replace(/\"/g, '\"\"') + '\"';
            }
            return str;
        };

        const csvLines = [headers.join(',')];

        rows.forEach(r => {
            const emp = r.employee;
            const empName = emp.name || `${emp.first_name || ''} ${emp.last_name || ''}`;
            const row = [
                escapeCell(emp.employee_code || emp.id),
                escapeCell(empName),
                escapeCell(r.dept?.name || ''),
                escapeCell(r.branch?.name || ''),
                escapeCell(r.desg?.name || r.desg?.title || ''),
                escapeCell(r.shift?.name || ''),
                escapeCell(r.date),
                escapeCell(r.shiftStart),
                escapeCell(r.checkIn),
                escapeCell(r.lateMinutes),
                escapeCell(r.shiftEnd),
                escapeCell(r.checkOut),
                escapeCell(r.earlyOutMinutes),
                escapeCell(parseFloat(r.workingHours || 0).toFixed(2)),
                escapeCell(parseFloat(r.overtimeHours || 0).toFixed(2)),
                escapeCell(r.status),
                escapeCell(r.leaveType || '-'),
                escapeCell(r.holidayName || '-'),
                escapeCell(r.source || 'Web')
            ];
            csvLines.push(row.join(','));
        });

        const csvContent = csvLines.join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.setAttribute('href', url);
        link.setAttribute('download', `Group_Attendance_${this.selectedDate}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    },

    stepDay(days) {
        const [yr, mo, da] = this.selectedDate.split('-').map(Number);
        const cur = new Date(yr, mo - 1, da, 12, 0, 0);
        cur.setDate(cur.getDate() + days);
        const y = cur.getFullYear();
        const m = String(cur.getMonth() + 1).padStart(2, '0');
        const d = String(cur.getDate()).padStart(2, '0');
        this.selectedDate = `${y}-${m}-${d}`;
    },

    setToday() {
        const today = new Date();
        const y = today.getFullYear();
        const m = String(today.getMonth() + 1).padStart(2, '0');
        const d = String(today.getDate()).padStart(2, '0');
        this.selectedDate = `${y}-${m}-${d}`;
    }
};
};
</script>

<div x-show="activeTab === 'group'" class="space-y-6 animate-in fade-in duration-200" x-data="groupAttendanceModule()" x-init="initGroupTab()">

    <!-- Top Multi-Filter Header Box -->
    <div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
            <div>
                <span class="text-[10px] font-bold uppercase tracking-widest text-indigo-600 dark:text-indigo-400 font-mono">Team &amp; Department Matrix</span>
                <h2 class="text-lg font-black text-slate-900 dark:text-white tracking-tight">Group Attendance &amp; Multi-Unit Roster</h2>
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Filter cross-functional teams by branch, shift, department, or presence state with real-time rule engine evaluation.</p>
            </div>

            <div class="flex items-center gap-2 flex-wrap">
                <!-- Date Step Controls -->
                <div class="flex items-center bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-1 shadow-2xs">
                    <button @click="stepDay(-1)" type="button" class="p-1.5 hover:bg-white dark:hover:bg-slate-700 text-slate-500 dark:text-slate-300 rounded-lg transition cursor-pointer" title="Previous Day">
                        <i data-lucide="chevron-left" class="w-3.5 h-3.5"></i>
                    </button>
                    <div class="flex items-center gap-1.5 px-2">
                        <i data-lucide="calendar" class="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400"></i>
                        <input
                            type="date"
                            x-model="selectedDate"
                            class="bg-transparent text-xs font-bold text-slate-900 dark:text-white focus:outline-hidden cursor-pointer"
                        />
                    </div>
                    <button @click="stepDay(1)" type="button" class="p-1.5 hover:bg-white dark:hover:bg-slate-700 text-slate-500 dark:text-slate-300 rounded-lg transition cursor-pointer" title="Next Day">
                        <i data-lucide="chevron-right" class="w-3.5 h-3.5"></i>
                    </button>
                </div>

                <button
                    @click="setToday()"
                    type="button"
                    class="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                    Today
                </button>

                <!-- Dedicated Apply Filter Button -->
                <button
                    @click="applyFilters()"
                    :disabled="isApplying || isLoadingGroup"
                    type="button"
                    class="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                    title="Apply selected date and filter combination"
                >
                    <svg x-show="isApplying || isLoadingGroup" class="w-3.5 h-3.5 animate-spin" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
                    </svg>
                    <svg x-show="!isApplying && !isLoadingGroup" class="w-3.5 h-3.5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"></polygon>
                    </svg>
                    <span x-text="(isApplying || isLoadingGroup) ? 'Applying...' : 'Apply'">Apply</span>
                </button>

                <button
                    @click="exportGroupCsv()"
                    type="button"
                    class="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900 text-indigo-700 dark:text-indigo-300 rounded-xl text-xs font-bold transition border border-indigo-200/80 dark:border-indigo-800 cursor-pointer shadow-2xs"
                >
                    <i data-lucide="download" class="w-3.5 h-3.5"></i>
                    <span>Export Group CSV</span>
                </button>
            </div>
        </div>

        <!-- Filter Controls Row (6 columns responsive grid) -->
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2.5">
            
            <!-- Search -->
            <div class="sm:col-span-2 relative">
                <i data-lucide="search" class="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400"></i>
                <input
                    type="text"
                    placeholder="Search name, ID, department..."
                    x-model="searchQuery"
                    class="w-full text-xs pl-8.5 pr-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden focus:bg-white dark:focus:bg-slate-900 focus:ring-2 focus:ring-indigo-500 font-medium"
                />
            </div>

            <!-- Department Filter -->
            <div>
                <select
                    x-model="deptFilter"
                    class="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-white font-medium focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                >
                    <option value="all">All Departments</option>
                    <template x-for="d in allDepartments" :key="d.id">
                        <option :value="d.id" x-text="d.name"></option>
                    </template>
                </select>
            </div>

            <!-- Branch Filter -->
            <div>
                <select
                    x-model="branchFilter"
                    class="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-white font-medium focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                >
                    <option value="all">All Branches</option>
                    <template x-for="b in allBranches" :key="b.id">
                        <option :value="b.id" x-text="b.name"></option>
                    </template>
                </select>
            </div>

            <!-- Designation Filter -->
            <div>
                <select
                    x-model="desgFilter"
                    class="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-white font-medium focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                >
                    <option value="all">All Designations</option>
                    <template x-for="dg in allDesignations" :key="dg.id">
                        <option :value="dg.id" x-text="dg.name || dg.title"></option>
                    </template>
                </select>
            </div>

            <!-- Shift Filter -->
            <div>
                <select
                    x-model="shiftFilter"
                    class="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-white font-medium focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                >
                    <option value="all">All Shifts</option>
                    <template x-for="s in allShifts" :key="s.id">
                        <option :value="s.id" x-text="s.name"></option>
                    </template>
                </select>
            </div>

        </div>

        <!-- Secondary Filter Status Chips -->
        <div class="flex items-center gap-1.5 pt-1 overflow-x-auto text-xs pb-1">
            <span class="text-[11px] font-bold text-slate-400 shrink-0 mr-1">Status:</span>
            
            <button 
                type="button"
                @click="statusFilter = 'all'" 
                :class="statusFilter === 'all' ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-2xs font-bold' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'"
                class="px-2.5 py-1 rounded-lg text-[11px] transition cursor-pointer shrink-0 font-medium"
            >
                All Statuses
            </button>

            <button 
                type="button"
                @click="statusFilter = 'Present'" 
                :class="statusFilter === 'Present' ? 'bg-emerald-600 text-white shadow-2xs font-bold' : 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100'"
                class="px-2.5 py-1 rounded-lg text-[11px] transition cursor-pointer shrink-0 font-medium"
            >
                Present
            </button>

            <button 
                type="button"
                @click="statusFilter = 'Late'" 
                :class="statusFilter === 'Late' ? 'bg-amber-600 text-white shadow-2xs font-bold' : 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 hover:bg-amber-100'"
                class="px-2.5 py-1 rounded-lg text-[11px] transition cursor-pointer shrink-0 font-medium"
            >
                Late Arrivals
            </button>

            <button 
                type="button"
                @click="statusFilter = 'Early Out'" 
                :class="statusFilter === 'Early Out' ? 'bg-orange-600 text-white shadow-2xs font-bold' : 'bg-orange-50 dark:bg-orange-950/40 text-orange-700 dark:text-orange-300 hover:bg-orange-100'"
                class="px-2.5 py-1 rounded-lg text-[11px] transition cursor-pointer shrink-0 font-medium"
            >
                Early Out
            </button>

            <button 
                type="button"
                @click="statusFilter = 'Absent'" 
                :class="statusFilter === 'Absent' ? 'bg-rose-600 text-white shadow-2xs font-bold' : 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 hover:bg-rose-100'"
                class="px-2.5 py-1 rounded-lg text-[11px] transition cursor-pointer shrink-0 font-medium"
            >
                Absent
            </button>

            <button 
                type="button"
                @click="statusFilter = 'On Leave'" 
                :class="statusFilter === 'On Leave' ? 'bg-purple-600 text-white shadow-2xs font-bold' : 'bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 hover:bg-purple-100'"
                class="px-2.5 py-1 rounded-lg text-[11px] transition cursor-pointer shrink-0 font-medium"
            >
                On Leave
            </button>

            <button 
                type="button"
                @click="statusFilter = 'Half Day'" 
                :class="statusFilter === 'Half Day' ? 'bg-indigo-600 text-white shadow-2xs font-bold' : 'bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100'"
                class="px-2.5 py-1 rounded-lg text-[11px] transition cursor-pointer shrink-0 font-medium"
            >
                Half Day
            </button>

            <button 
                type="button"
                @click="statusFilter = 'Holiday'" 
                :class="statusFilter === 'Holiday' ? 'bg-teal-600 text-white shadow-2xs font-bold' : 'bg-teal-50 dark:bg-teal-950/40 text-teal-700 dark:text-teal-300 hover:bg-teal-100'"
                class="px-2.5 py-1 rounded-lg text-[11px] transition cursor-pointer shrink-0 font-medium"
            >
                Holiday
            </button>

            <button 
                type="button"
                @click="statusFilter = 'Weekly Off'" 
                :class="statusFilter === 'Weekly Off' ? 'bg-slate-600 text-white shadow-2xs font-bold' : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'"
                class="px-2.5 py-1 rounded-lg text-[11px] transition cursor-pointer shrink-0 font-medium"
            >
                Weekly Off
            </button>
        </div>
    </div>

    <!-- Filtered Group KPI Strip (8 Metrics Cards) -->
    <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        
        <!-- Total -->
        <div class="bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs text-center">
            <span class="text-[10px] font-bold text-slate-400 uppercase block tracking-wider">Filtered Total</span>
            <span class="text-xl font-black font-mono text-slate-800 dark:text-white my-1 block" x-text="groupStats.totalInGroup + ' staff'"></span>
            <span class="text-[10px] text-slate-400 font-medium block">Headcount</span>
        </div>

        <!-- Present -->
        <div class="bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-emerald-100 dark:border-emerald-950/60 shadow-2xs text-center">
            <span class="text-[10px] font-bold text-emerald-600 uppercase block tracking-wider">Present</span>
            <span class="text-xl font-black font-mono text-emerald-600 dark:text-emerald-400 my-1 block" x-text="groupStats.present"></span>
            <span class="text-[10px] text-emerald-600 font-bold block" x-text="groupStats.presenceRate + '% rate'"></span>
        </div>

        <!-- Late -->
        <div class="bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-amber-100 dark:border-amber-950/60 shadow-2xs text-center">
            <span class="text-[10px] font-bold text-amber-600 uppercase block tracking-wider">Late</span>
            <span class="text-xl font-black font-mono text-amber-600 dark:text-amber-400 my-1 block" x-text="groupStats.late"></span>
            <span class="text-[10px] text-amber-600 font-medium block">&gt; Grace Buffer</span>
        </div>

        <!-- Early Out -->
        <div class="bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-orange-100 dark:border-orange-950/60 shadow-2xs text-center">
            <span class="text-[10px] font-bold text-orange-600 uppercase block tracking-wider">Early Out</span>
            <span class="text-xl font-black font-mono text-orange-600 dark:text-orange-400 my-1 block" x-text="groupStats.earlyOut"></span>
            <span class="text-[10px] text-orange-600 font-medium block">Early Departures</span>
        </div>

        <!-- Absent -->
        <div class="bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-rose-100 dark:border-rose-950/60 shadow-2xs text-center">
            <span class="text-[10px] font-bold text-rose-600 uppercase block tracking-wider">Absent</span>
            <span class="text-xl font-black font-mono text-rose-600 dark:text-rose-400 my-1 block" x-text="groupStats.absent"></span>
            <span class="text-[10px] text-rose-600 font-medium block">Unexcused</span>
        </div>

        <!-- On Leave -->
        <div class="bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-purple-100 dark:border-purple-950/60 shadow-2xs text-center">
            <span class="text-[10px] font-bold text-purple-600 uppercase block tracking-wider">On Leave</span>
            <span class="text-xl font-black font-mono text-purple-600 dark:text-purple-400 my-1 block" x-text="groupStats.onLeave"></span>
            <span class="text-[10px] text-purple-600 font-medium block">Approved</span>
        </div>

        <!-- Worked Hours -->
        <div class="bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-indigo-100 dark:border-indigo-950/60 shadow-2xs text-center">
            <span class="text-[10px] font-bold text-indigo-600 uppercase block tracking-wider">Worked Hours</span>
            <span class="text-xl font-black font-mono text-indigo-600 dark:text-indigo-400 my-1 block" x-text="groupStats.totalWorkedHours + 'h'"></span>
            <span class="text-[10px] text-indigo-600 font-medium block">Group Net</span>
        </div>

        <!-- Overtime -->
        <div class="bg-emerald-600 text-white p-3.5 rounded-2xl shadow-2xs text-center">
            <span class="text-[10px] font-bold text-emerald-100 uppercase block tracking-wider">Total OT</span>
            <span class="text-xl font-black font-mono text-white my-1 block" x-text="'+' + groupStats.totalOvertimeHours + 'h'"></span>
            <span class="text-[10px] text-emerald-200 font-medium block">1.5x Premium</span>
        </div>

    </div>

    <!-- Group Matrix Table Container -->
    <div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-xs">
                <thead>
                    <tr class="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200/80 dark:border-slate-800 text-[11px] font-bold text-slate-500 dark:text-slate-400 whitespace-nowrap">
                        <th class="p-3.5">Employee ID &amp; Name</th>
                        <th class="p-3.5">Department &amp; Branch</th>
                        <th class="p-3.5">Assigned Shift</th>
                        <th class="p-3.5">Sched In</th>
                        <th class="p-3.5">Actual In</th>
                        <th class="p-3.5">Late (m)</th>
                        <th class="p-3.5">Sched Out</th>
                        <th class="p-3.5">Actual Out</th>
                        <th class="p-3.5">Early Out (m)</th>
                        <th class="p-3.5 text-center">Worked (h)</th>
                        <th class="p-3.5 text-center">OT (h)</th>
                        <th class="p-3.5 text-center">Status</th>
                        <th class="p-3.5">Source</th>
                        <th class="p-3.5 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-800 whitespace-nowrap">
                    
                    <!-- Loading state -->
                    <template x-if="isLoadingGroup">
                        <tr>
                            <td colspan="14" class="p-12 text-center text-slate-400 dark:text-slate-500">
                                <div class="flex items-center justify-center gap-2">
                                    <svg class="w-4 h-4 animate-spin text-indigo-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
                                    </svg>
                                    <span class="text-xs font-semibold">Evaluating team matrix roster...</span>
                                </div>
                            </td>
                        </tr>
                    </template>

                    <!-- Empty State -->
                    <template x-if="!isLoadingGroup && filteredRows.length === 0">
                        <tr>
                            <td colspan="14" class="p-12 text-center text-slate-400 dark:text-slate-500 text-xs italic">
                                No employees found matching the specified group filter combination.
                            </td>
                        </tr>
                    </template>

                    <!-- Row Loop -->
                    <template x-if="!isLoadingGroup">
                        <template x-for="row in filteredRows" :key="row.employee.id">
                            <tr 
                                @click="openDiagnosticLog(row.logObj)"
                                class="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition cursor-pointer"
                            >
                                
                                <!-- Employee ID & Name -->
                                <td class="p-3.5">
                                    <div class="flex items-center gap-2.5">
                                        <div class="w-8 h-8 rounded-full overflow-hidden bg-indigo-50 dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 font-bold flex items-center justify-center shrink-0 border border-indigo-200/50 dark:border-slate-700">
                                            <template x-if="row.employee.photo || row.employee.avatar">
                                                <img :src="row.employee.photo || row.employee.avatar" :alt="row.employee.name" class="w-full h-full object-cover" />
                                            </template>
                                            <template x-if="!row.employee.photo && !row.employee.avatar">
                                                <span x-text="(row.employee.name || row.employee.first_name || 'E').substr(0, 2).toUpperCase()"></span>
                                            </template>
                                        </div>
                                        <div>
                                            <span class="font-bold text-slate-900 dark:text-white block leading-tight" x-text="row.employee.name || `${row.employee.first_name || ''} ${row.employee.last_name || ''}`"></span>
                                            <span class="text-[10px] text-slate-400 font-mono" x-text="row.employee.employee_code || row.employee.id"></span>
                                        </div>
                                    </div>
                                </td>

                                <!-- Department & Branch -->
                                <td class="p-3.5">
                                    <span class="font-semibold text-slate-800 dark:text-slate-200 block" x-text="row.dept?.name || 'General'"></span>
                                    <span class="text-[10px] text-slate-400 font-mono" x-text="row.branch?.name || 'Main HQ'"></span>
                                </td>

                                <!-- Shift -->
                                <td class="p-3.5">
                                    <span class="font-semibold text-slate-800 dark:text-slate-200 block" x-text="row.shift?.name || 'Day Shift'"></span>
                                    <span class="text-[10px] text-slate-400 font-mono" x-text="row.shiftStart + ' - ' + row.shiftEnd"></span>
                                </td>

                                <!-- Sched In -->
                                <td class="p-3.5 font-mono text-slate-500 dark:text-slate-400" x-text="row.shiftStart"></td>

                                <!-- Actual In -->
                                <td class="p-3.5 font-mono font-bold text-slate-900 dark:text-white" x-text="row.checkIn"></td>

                                <!-- Late (m) -->
                                <td class="p-3.5 font-mono font-bold" :class="row.lateMinutes > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-slate-400 dark:text-slate-600'">
                                    <span x-text="row.lateMinutes > 0 ? '+' + row.lateMinutes + 'm' : '0m'"></span>
                                </td>

                                <!-- Sched Out -->
                                <td class="p-3.5 font-mono text-slate-500 dark:text-slate-400" x-text="row.shiftEnd"></td>

                                <!-- Actual Out -->
                                <td class="p-3.5 font-mono font-bold text-slate-900 dark:text-white" x-text="row.checkOut"></td>

                                <!-- Early Out (m) -->
                                <td class="p-3.5 font-mono font-bold" :class="row.earlyOutMinutes > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-slate-400 dark:text-slate-600'">
                                    <span x-text="row.earlyOutMinutes > 0 ? '-' + row.earlyOutMinutes + 'm' : '0m'"></span>
                                </td>

                                <!-- Worked (h) -->
                                <td class="p-3.5 font-mono font-black text-center text-indigo-700 dark:text-indigo-400" x-text="(parseFloat(row.workingHours || 0)).toFixed(2) + 'h'"></td>

                                <!-- OT (h) -->
                                <td class="p-3.5 font-mono font-bold text-center">
                                    <template x-if="parseFloat(row.overtimeHours || 0) > 0">
                                        <span class="px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 text-[10px]" x-text="'+' + (parseFloat(row.overtimeHours)).toFixed(2) + 'h (' + Math.round(parseFloat(row.overtimeHours) * 60) + 'm)'"></span>
                                    </template>
                                    <template x-if="!parseFloat(row.overtimeHours || 0)">
                                        <span class="text-slate-400 dark:text-slate-600">0h</span>
                                    </template>
                                </td>

                                <!-- Status -->
                                <td class="p-3.5 text-center">
                                    <span :class="{
                                        'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300 dark:border-emerald-800': ['Present', 'Present (Early Closure)', 'Early Closure Covered', 'Approved Early Closure', 'Off-Day Work', 'Weekend Duty Present', 'Holiday Duty Present'].includes(row.status),
                                        'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/50 dark:text-amber-300 dark:border-amber-800': row.status === 'Late' || row.status === 'Late & Early Out',
                                        'bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-950/50 dark:text-orange-300 dark:border-orange-800': row.status === 'Early Out',
                                        'bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950/50 dark:text-purple-300 dark:border-purple-800': row.isOnLeave || row.status.toLowerCase().includes('leave'),
                                        'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-950/50 dark:text-indigo-300 dark:border-indigo-800': row.status === 'Half Day',
                                        'bg-teal-50 text-teal-700 border-teal-200 dark:bg-teal-950/50 dark:text-teal-300 dark:border-teal-800': row.status === 'Holiday',
                                        'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700': row.status === 'Weekly Off',
                                        'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/50 dark:text-rose-300 dark:border-rose-800': row.status === 'Absent'
                                    }" class="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold border inline-block" x-text="row.status"></span>
                                </td>

                                <!-- Source -->
                                <td class="p-3.5">
                                    <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200/60 dark:border-slate-700" x-text="row.source || 'Web'"></span>
                                </td>

                                <!-- Actions -->
                                <td class="p-3.5 text-right" @click.stop="">
                                    <div class="flex items-center justify-end gap-1.5">
                                        <button
                                            @click="openDiagnosticLog(row.logObj)"
                                            type="button"
                                            class="p-1.5 hover:bg-indigo-50 dark:hover:bg-slate-800 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 rounded-lg transition cursor-pointer"
                                            title="View Diagnostic Breakdown"
                                        >
                                            <i data-lucide="eye" class="w-3.5 h-3.5"></i>
                                        </button>
                                        <button
                                            @click="viewEmployee(row.employee.id)"
                                            type="button"
                                            class="p-1.5 hover:bg-indigo-50 dark:hover:bg-slate-800 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 rounded-lg transition cursor-pointer"
                                            title="View Individual Ledger"
                                        >
                                            <i data-lucide="user" class="w-3.5 h-3.5"></i>
                                        </button>
                                        <button
                                            @click="openCorrectionFor(row.employee.id, selectedDate, row.checkIn, row.checkOut)"
                                            type="button"
                                            class="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg text-[11px] font-bold transition cursor-pointer"
                                        >
                                            Regularize
                                        </button>
                                    </div>
                                </td>

                            </tr>
                        </template>
                    </template>

                </tbody>
            </table>
        </div>
    </div>

</div>
