<!-- TAB: Individual Employee Attendance Hub (8 Full Sub-Tabs & 19-Column Daily Ledger) -->
<script>
window.employeeAttendanceModule = function() {
    return {
        currentEmpId: <?= json_encode((string)($selectedEmpId ?? '')) ?>,
        allEmployees: <?= json_encode($employees ?? []) ?>,
        empLogs: <?= json_encode($empHistoryLogs ?? []) ?>,
        allLeaves: <?= json_encode($leaves ?? []) ?>,
        allHolidays: <?= json_encode($holidays ?? []) ?>,
        allCorrectionsList: <?= json_encode($allCorrections ?? []) ?>,
        activeSubTab: 'history',
        activeQuickRange: 'this_month',
        filterFrom: '',
        filterTo: '<?= date('Y-m-d') ?>',
        statusFilter: 'all',
        isLoadingEmp: false,
        isApplying: false,
        isReprocessing: false,
        empTabInitialized: false,
        _abortController: null,
        selectedDayDiagnostic: null,
        
        // Biometric pending & status audit
        pendingBiometricPunches: 0,
        topReprocessNotes: [],
        biometricBannerDismissed: false,

        // Server min/max dates & stale punch detection
        serverMinDate: '',
        serverMaxDate: '',
        hasStalePunches: false,
        latestPunchDate: null,
        showClampedNotice: false,
        
        // Evaluation results
        dailyRows: [],
        empSummary: {
            calendarDays: 0,
            workingDays: 0,
            present: 0,
            late: 0,
            earlyOut: 0,
            halfDay: 0,
            absent: 0,
            onLeave: 0,
            holidayDays: 0,
            weeklyOffDays: 0,
            totalHours: '0.0',
            totalRequired: '0.0',
            totalOt: '0.0',
            punctualityRate: 100,
            attendanceRate: 100
        },

        parseDateTuple(str) {
            if (!str) return null;
            str = String(str).trim();
            if (/^(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})$/.test(str)) {
                const m = str.match(/^(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})$/);
                return [parseInt(m[1], 10), parseInt(m[2], 10), parseInt(m[3], 10)];
            }
            if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(str)) {
                const m = str.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
                return [parseInt(m[3], 10), parseInt(m[1], 10), parseInt(m[2], 10)];
            }
            if (/^(\d{1,2})-(\d{1,2})-(\d{4})$/.test(str)) {
                const m = str.match(/^(\d{1,2})-(\d{1,2})-(\d{4})$/);
                return [parseInt(m[3], 10), parseInt(m[2], 10), parseInt(m[1], 10)];
            }
            const d = new Date(str);
            if (!isNaN(d.getTime())) {
                return [d.getFullYear(), d.getMonth() + 1, d.getDate()];
            }
            return null;
        },

        normalizeIsoDate(str) {
            const t = this.parseDateTuple(str);
            if (!t) return '';
            return `${t[0]}-${String(t[1]).padStart(2, '0')}-${String(t[2]).padStart(2, '0')}`;
        },

        normalizeStatus(st) {
            if (!st) return 'Absent';
            const s = String(st).trim();
            const l = s.toLowerCase().replace(/[\s\-_]+/g, '');
            if (l === 'present' || l === 'present(earlyclosure)' || l === 'earlyclosurecovered' || l === 'approvedearlyclosure' || l === 'offdaywork' || l === 'weekenddutypresent' || l === 'holidaydutypresent') return 'Present';
            if (l === 'late') return 'Late';
            if (l === 'earlyout') return 'Early Out';
            if (l === 'lateearlyout' || l === 'lateandearlyout') return 'Late & Early Out';
            if (l === 'halfday') return 'Half Day';
            if (l === 'absent') return 'Absent';
            if (l === 'onleave' || l === 'leave' || l === 'paidleave') return 'On Leave';
            if (l === 'holiday') return 'Holiday';
            if (l === 'weeklyoff' || l === 'weekend' || l === 'offday') return 'Weekly Off';
            if (l === 'missingpunch' || l === 'missing') return 'Missing Punch';
            if (l === 'beforejoining') return 'Before Joining';
            return s;
        },

        getStatusBadgeClass(status) {
            const st = this.normalizeStatus(status);
            switch (st) {
                case 'Present':
                    return 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300';
                case 'Late':
                    return 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300';
                case 'Early Out':
                    return 'bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-950/60 dark:text-orange-300';
                case 'Late & Early Out':
                    return 'bg-amber-500/10 text-amber-800 border-amber-300 dark:bg-amber-950/70 dark:text-amber-200 font-black';
                case 'Half Day':
                    return 'bg-sky-50 text-sky-700 border-sky-200 dark:bg-sky-950/60 dark:text-sky-300';
                case 'On Leave':
                case 'Paid Leave':
                    return 'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-950/60 dark:text-indigo-300';
                case 'Holiday':
                    return 'bg-teal-50 text-teal-700 border-teal-200 dark:bg-teal-950/60 dark:text-teal-300';
                case 'Weekly Off':
                    return 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300';
                case 'Missing Punch':
                    return 'bg-pink-50 text-pink-700 border-pink-200 dark:bg-pink-950/60 dark:text-pink-300';
                case 'Before Joining':
                    return 'bg-slate-50 text-slate-400 border-slate-200 dark:bg-slate-900 dark:text-slate-500';
                case 'Absent':
                default:
                    return 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/60 dark:text-rose-300';
            }
        },

        get currentEmployee() {
            if (!this.allEmployees || this.allEmployees.length === 0) return {};
            const cur = String(this.currentEmpId || '').toLowerCase().trim();
            const found = this.allEmployees.find(e => 
                String(e.id || '').toLowerCase().trim() === cur || 
                String(e.employee_code || '').toLowerCase().trim() === cur
            );
            return found || this.allEmployees[0] || {};
        },

        get currentEmployeeJoinDate() {
            const emp = this.currentEmployee;
            if (!emp) return '';
            const raw = emp.joining_date || emp.join_date || emp.employment_start_date || this.serverMinDate || '';
            return this.normalizeIsoDate(raw);
        },

        initEmpTab() {
            if (this.empTabInitialized) return;
            this.empTabInitialized = true;

            if ((!this.currentEmpId || this.currentEmpId === 'undefined' || this.currentEmpId === '') && this.allEmployees && this.allEmployees.length > 0) {
                this.currentEmpId = String(this.allEmployees[0].id);
            }

            const today = new Date();
            const y = today.getFullYear();
            const m = String(today.getMonth() + 1).padStart(2, '0');
            const d = String(today.getDate()).padStart(2, '0');
            const todayStr = `${y}-${m}-${d}`;
            const firstOfThisMonth = `${y}-${m}-01`;

            const empJoinIso = this.currentEmployeeJoinDate;

            // B5 default selection: "This Month", clamped to joining date if joined this month
            if (!this.filterFrom || this.filterFrom === '2025-01-01' || this.filterFrom === '2026-07-27') {
                if (empJoinIso && empJoinIso > firstOfThisMonth && empJoinIso <= todayStr) {
                    this.filterFrom = empJoinIso;
                    this.activeQuickRange = 'since_joining';
                } else {
                    this.filterFrom = firstOfThisMonth;
                    this.activeQuickRange = 'this_month';
                }
            }
            if (!this.filterTo) {
                this.filterTo = todayStr;
            }

            this.isLoadingEmp = false;
            this.isApplying = false;

            const isEmpActive = () => (window.attendanceApp ? window.attendanceApp.activeTab === 'employee' : (window.location.search.includes('tab=employee')));

            // Fetch live attendance data from server only if active tab is employee
            if (isEmpActive()) {
                this.fetchOrRecalculate(true);
            }

            window.addEventListener('tab-changed', (e) => {
                if (e.detail?.tab === 'employee') {
                    if (e.detail?.employee_id) {
                        this.currentEmpId = String(e.detail.employee_id);
                    }
                    this.fetchOrRecalculate(true);
                }
            });

            this.$nextTick(() => {
                if (window.lucide) window.lucide.createIcons();
            });
        },

        onFromDateChange(newVal) {
            const empJoinIso = this.currentEmployeeJoinDate;
            if (empJoinIso && newVal && newVal < empJoinIso) {
                this.filterFrom = empJoinIso;
                this.showClampedNotice = true;
                setTimeout(() => { this.showClampedNotice = false; }, 4500);
            } else {
                this.filterFrom = newVal;
            }
        },

        async applyFilters() {
            if (this.isApplying || this.isLoadingEmp) return;
            this.isApplying = true;
            this.activeQuickRange = 'custom';
            try {
                await this.fetchOrRecalculate(true);
            } catch (err) {
                console.error('Apply filter error:', err);
            } finally {
                this.isApplying = false;
                this.isLoadingEmp = false;
            }
        },

        get employeeLeaves() {
            const emp = this.currentEmployee;
            const empId = String(emp.id || '').toLowerCase().trim();
            const empCode = String(emp.employee_code || '').toLowerCase().trim();
            const curId = String(this.currentEmpId || '').toLowerCase().trim();
            return (this.allLeaves || []).filter(l => {
                const lEmpId = String(l.employee_id || l.employeeId || '').toLowerCase().trim();
                return (empId && lEmpId === empId) || (empCode && lEmpId === empCode) || (curId && lEmpId === curId);
            });
        },

        get employeeCorrections() {
            const emp = this.currentEmployee;
            const empId = String(emp.id || '').toLowerCase().trim();
            const empCode = String(emp.employee_code || '').toLowerCase().trim();
            const curId = String(this.currentEmpId || '').toLowerCase().trim();
            return (this.allCorrectionsList || []).filter(c => {
                const cEmpId = String(c.employee_id || c.employeeId || '').toLowerCase().trim();
                return (empId && cEmpId === empId) || (empCode && cEmpId === empCode) || (curId && cEmpId === curId);
            });
        },

        setQuickRange(type) {
            const today = new Date();
            const y = today.getFullYear();
            const m = String(today.getMonth() + 1).padStart(2, '0');
            const d = String(today.getDate()).padStart(2, '0');
            const todayStr = `${y}-${m}-${d}`;
            const firstOfThisMonth = `${y}-${m}-01`;

            const empJoinIso = this.currentEmployeeJoinDate;

            this.activeQuickRange = type;

            if (type === 'this_month') {
                this.filterFrom = (empJoinIso && empJoinIso > firstOfThisMonth) ? empJoinIso : firstOfThisMonth;
                this.filterTo = todayStr;
            } else if (type === 'last_month') {
                const lastMonthStart = new Date(y, today.getMonth() - 1, 1, 12, 0, 0);
                const lastMonthEnd = new Date(y, today.getMonth(), 0, 12, 0, 0);
                const ly = lastMonthStart.getFullYear();
                const lm = String(lastMonthStart.getMonth() + 1).padStart(2, '0');
                const ld = String(lastMonthEnd.getDate()).padStart(2, '0');
                const lmStart = `${ly}-${lm}-01`;
                this.filterFrom = (empJoinIso && empJoinIso > lmStart) ? empJoinIso : lmStart;
                this.filterTo = `${ly}-${lm}-${ld}`;
            } else if (type === 'last_30') {
                const past30 = new Date(today.getTime() - (30 * 86400000));
                const py = past30.getFullYear();
                const pm = String(past30.getMonth() + 1).padStart(2, '0');
                const pd = String(past30.getDate()).padStart(2, '0');
                const p30Str = `${py}-${pm}-${pd}`;
                this.filterFrom = (empJoinIso && empJoinIso > p30Str) ? empJoinIso : p30Str;
                this.filterTo = todayStr;
            } else if (type === 'since_joining') {
                this.filterFrom = empJoinIso || `${y}-01-01`;
                this.filterTo = todayStr;
            } else if (type === 'year') {
                const yearStart = `${y}-01-01`;
                this.filterFrom = (empJoinIso && empJoinIso > yearStart) ? empJoinIso : yearStart;
                this.filterTo = todayStr;
            }
            this.fetchOrRecalculate(true);
        },

        changeEmployee(empId) {
            this.currentEmpId = String(empId);
            this.fetchOrRecalculate(true);
        },

        jumpToLastActivity() {
            if (!this.latestPunchDate) return;
            const rowEl = document.getElementById('ledger-row-' + this.latestPunchDate);
            if (rowEl) {
                rowEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
                rowEl.classList.add('bg-indigo-100', 'dark:bg-indigo-900/60');
                setTimeout(() => {
                    rowEl.classList.remove('bg-indigo-100', 'dark:bg-indigo-900/60');
                }, 2500);
            }
        },

        reprocessBiometric() {
            if (this.isReprocessing) return;
            this.isReprocessing = true;
            fetch('<?= base_url('attendance/sync/reprocess') ?>', {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })
            .then(res => res.json())
            .then(data => {
                this.fetchOrRecalculate(true);
            })
            .catch(err => {
                console.error('Biometric reprocess failed:', err);
                this.fetchOrRecalculate(true);
            })
            .finally(() => {
                this.isReprocessing = false;
            });
        },

        fetchOrRecalculate(triggerLoading = true) {
            if (!this.currentEmpId) {
                this.isLoadingEmp = false;
                this.isApplying = false;
                return Promise.resolve();
            }

            // Date validation check: clamp From date if before joining date
            const empJoinIso = this.currentEmployeeJoinDate;
            if (empJoinIso && this.filterFrom && this.filterFrom < empJoinIso) {
                this.filterFrom = empJoinIso;
            }

            // Prevent inverted range
            if (this.filterFrom && this.filterTo && this.filterFrom > this.filterTo) {
                console.warn('Invalid date range: From date is after To date');
                this.filterTo = this.filterFrom;
            }

            if (this._abortController) {
                this._abortController.abort();
            }
            this._abortController = new AbortController();
            const currentSignal = this._abortController.signal;

            if (triggerLoading) {
                this.isLoadingEmp = true;
            }

            const fromIso = this.normalizeIsoDate(this.filterFrom) || this.filterFrom;
            const toIso = this.normalizeIsoDate(this.filterTo) || this.filterTo;
            const url = `<?= base_url('attendance/getEmployeeAttendanceAjax') ?>?employee_id=${encodeURIComponent(this.currentEmpId)}&from=${encodeURIComponent(fromIso)}&to=${encodeURIComponent(toIso)}`;
            
            return fetch(url, {
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                signal: currentSignal
            })
            .then(res => {
                if (!res.ok) {
                    throw new Error(`HTTP error! status: ${res.status}`);
                }
                return res.json();
            })
            .then(data => {
                if (data && data.status === 'success' && data.data) {
                    if (data.data.logs) {
                        const curId = String(this.currentEmpId).toLowerCase().trim();
                        const curCode = String(this.currentEmployee?.employee_code || '').toLowerCase().trim();
                        const otherEmpLogs = this.empLogs.filter(l => {
                            const lId = String(l.employee_id || l.employeeId || '').toLowerCase().trim();
                            return lId !== curId && lId !== curCode;
                        });
                        const freshLogs = data.data.logs.map(l => ({
                            ...l,
                            employee_id: String(l.employee_id || this.currentEmpId),
                            employeeId: String(l.employee_id || this.currentEmpId),
                            date: l.date || l.log_date || l.attendance_date,
                            attendance_date: l.date || l.log_date || l.attendance_date
                        }));
                        this.empLogs = [...otherEmpLogs, ...freshLogs];
                    }
                    if (data.data.employee) {
                        const returnedEmp = data.data.employee;
                        const idx = (this.allEmployees || []).findIndex(e => String(e.id) === String(returnedEmp.id) || (e.employee_code && String(e.employee_code) === String(returnedEmp.employee_code)));
                        if (idx !== -1) {
                            // B9: Never overwrite existing non-empty weekly_off_days with an empty value
                            const existingWeeklyOff = this.allEmployees[idx].weekly_off_days;
                            const hasNewWeeklyOff = Array.isArray(returnedEmp.weekly_off_days) && returnedEmp.weekly_off_days.length > 0;
                            const safeWeeklyOff = hasNewWeeklyOff ? returnedEmp.weekly_off_days : (existingWeeklyOff || []);
                            this.allEmployees[idx] = {
                                ...this.allEmployees[idx],
                                ...returnedEmp,
                                weekly_off_days: safeWeeklyOff
                            };
                        }
                    }
                    if (data.data.leaves) {
                        this.allLeaves = data.data.leaves;
                    }
                    if (data.data.holidays) {
                        this.allHolidays = data.data.holidays;
                    }
                    if (data.data.pending_biometric_punches !== undefined) {
                        this.pendingBiometricPunches = data.data.pending_biometric_punches;
                    }
                    if (data.data.top_reprocess_notes) {
                        this.topReprocessNotes = data.data.top_reprocess_notes;
                    }
                    if (data.data.min_date || data.data.joining_date) {
                        this.serverMinDate = data.data.min_date || data.data.joining_date;
                    }
                    if (data.data.max_date) {
                        this.serverMaxDate = data.data.max_date;
                    }
                }
                this.recalculateDailyEvaluation();
            })
            .catch((err) => {
                if (err.name !== 'AbortError') {
                    console.warn('Fetch employee attendance fallback to local:', err);
                }
                this.recalculateDailyEvaluation();
            })
            .finally(() => {
                this.isLoadingEmp = false;
                this.isApplying = false;
                this._abortController = null;
                this.$nextTick(() => {
                    if (window.lucide) window.lucide.createIcons();
                });
            });
        },

        recalculateDailyEvaluation() {
            const emp = this.currentEmployee;
            if (!emp || !emp.id || !this.filterFrom || !this.filterTo) {
                this.dailyRows = [];
                return;
            }

            const shiftStart = emp.start_time || '08:00';
            const shiftEnd = emp.end_time || '16:00';
            const shiftName = emp.shift_name || 'Standard Day Shift';

            const empId = String(emp.id || '').toLowerCase().trim();
            const empCode = String(emp.employee_code || '').toLowerCase().trim();
            const curId = String(this.currentEmpId || '').toLowerCase().trim();
            
            // Map logs by date for O(1) indexed lookup
            const logsByDate = new Map();
            (this.empLogs || []).forEach(l => {
                const lEmpId = String(l.employee_id || l.employeeId || '').toLowerCase().trim();
                if ((empId && lEmpId === empId) || (empCode && lEmpId === empCode) || (curId && lEmpId === curId)) {
                    const rawDate = l.date || l.attendance_date || l.log_date;
                    const lDate = this.normalizeIsoDate(rawDate);
                    if (lDate) logsByDate.set(lDate, l);
                }
            });

            const empLeaves = this.employeeLeaves.filter(la => String(la.status).toLowerCase() === 'approved');

            // B8: Clamp generated dates to employee's joining date
            const empJoinIso = this.currentEmployeeJoinDate;
            let startIso = this.normalizeIsoDate(this.filterFrom) || this.filterFrom;
            let endIso = this.normalizeIsoDate(this.filterTo) || this.filterTo;

            if (empJoinIso && startIso < empJoinIso) {
                startIso = empJoinIso;
            }
            if (startIso > endIso) {
                endIso = startIso;
            }

            // Robust timezone-safe date list generation
            const dates = [];
            const startTuple = this.parseDateTuple(startIso);
            const endTuple = this.parseDateTuple(endIso);

            if (startTuple && endTuple) {
                const curr = new Date(startTuple[0], startTuple[1] - 1, startTuple[2], 12, 0, 0);
                const target = new Date(endTuple[0], endTuple[1] - 1, endTuple[2], 12, 0, 0);

                let count = 0;
                while (curr <= target && count < 5000) {
                    const yr = curr.getFullYear();
                    const mo = String(curr.getMonth() + 1).padStart(2, '0');
                    const da = String(curr.getDate()).padStart(2, '0');
                    const dtStr = `${yr}-${mo}-${da}`;
                    // Days before joining must not be generated at all
                    if (!empJoinIso || dtStr >= empJoinIso) {
                        dates.push(dtStr);
                    }
                    curr.setDate(curr.getDate() + 1);
                    count++;
                }
            }

            // Reverse so newest date is at the top
            dates.reverse();

            const todayStr = new Date().toISOString().slice(0, 10);

            // B10: Detect latest punch date to show "No punches since <date>" banner if older than today
            let latestLogDate = null;
            logsByDate.forEach((logVal, dt) => {
                if (logVal && logVal.check_in && logVal.check_in !== '--:--:--' && logVal.check_in !== '---') {
                    if (!latestLogDate || dt > latestLogDate) {
                        latestLogDate = dt;
                    }
                }
            });
            this.latestPunchDate = latestLogDate;
            this.hasStalePunches = !!(latestLogDate && latestLogDate < todayStr);

            let calendarDays = dates.length;
            let workingDays = 0;
            let present = 0;
            let late = 0;
            let earlyOut = 0;
            let halfDay = 0;
            let absent = 0;
            let onLeave = 0;
            let holidayDays = 0;
            let weeklyOffDays = 0;
            let totalHours = 0;
            let totalRequired = 0;
            let totalOt = 0;

            const rows = dates.map(dateStr => {
                const [yr, mo, da] = dateStr.split('-').map(Number);
                const dateObj = new Date(yr, mo - 1, da, 12, 0, 0);
                const dayOfWeek = dateObj.toLocaleDateString('en-US', { weekday: 'short' });
                const dayFull = dateObj.toLocaleDateString('en-US', { weekday: 'long' });
                
                // Weekly off lookup based on employee/company settings
                let defaultOffDays = (window.attendanceSettings && window.attendanceSettings.weekendDays) || [];
                if (typeof defaultOffDays === 'string') {
                    try { defaultOffDays = JSON.parse(defaultOffDays); } catch(e) { defaultOffDays = defaultOffDays.split(',').map(s => s.trim()); }
                }
                let empOffDays = emp.weekly_off_days || emp.weekly_off || defaultOffDays;
                if (typeof empOffDays === 'string') {
                    try { empOffDays = JSON.parse(empOffDays); } catch(e) { empOffDays = empOffDays.split(',').map(s => s.trim()); }
                }
                if (!Array.isArray(empOffDays)) {
                    empOffDays = [];
                }
                const empOffDaysNormalized = empOffDays.map(d => String(d).trim().toLowerCase());
                const isWeeklyOff = empOffDaysNormalized.includes(dayFull.toLowerCase()) || empOffDaysNormalized.includes(dayOfWeek.toLowerCase());

                // Holiday check
                const holiday = (this.allHolidays || []).find(h => {
                    if (h.date === dateStr) return true;
                    if (h.from_date && h.to_date && dateStr >= h.from_date && dateStr <= h.to_date) return true;
                    return false;
                });
                const isHoliday = !!holiday;

                // Leave check
                const leave = empLeaves.find(la => {
                    const s = la.start_date || la.from_date;
                    const e = la.end_date || la.to_date;
                    return dateStr >= s && dateStr <= e;
                });
                const isOnLeave = !!leave;

                // O(1) Log check
                const log = logsByDate.get(dateStr) || null;

                let status = 'Absent';
                let checkIn = log ? (log.check_in || '') : '';
                let checkOut = log ? (log.check_out || '') : '';
                let workedHours = log ? parseFloat(log.working_hours || 0) : 0;
                let otHours = log ? parseFloat(log.overtime_hours || 0) : 0;
                let lateMinutes = log ? parseInt(log.late_minutes || 0) : 0;
                let earlyOutMinutes = log ? parseInt(log.early_out_minutes || 0) : 0;
                let method = log ? (log.verification_method || 'Biometric') : '--';
                let reqHours = 8.0;

                if (isHoliday) {
                    holidayDays++;
                    status = 'Holiday';
                    reqHours = 0;
                } else if (isWeeklyOff) {
                    weeklyOffDays++;
                    status = 'Weekly Off';
                    reqHours = 0;
                } else {
                    if (dateStr <= todayStr) {
                        workingDays++;
                        totalRequired += reqHours;
                    }
                }

                if (isOnLeave) {
                    status = 'On Leave';
                    if (dateStr <= todayStr) onLeave++;
                } else if (log && ((log.check_in && log.check_in !== '--:--:--' && log.check_in !== '---') || parseInt(log.is_company_closure || 0) === 1 || parseFloat(log.closure_credit_hours || 0) > 0)) {
                    const rawStatus = String(log.status || 'Present').trim();
                    const isClosureRow = parseInt(log.is_company_closure || 0) === 1
                        || parseFloat(log.closure_credit_hours || 0) > 0
                        || ['present (early closure)', 'early closure covered', 'approved early closure'].includes(rawStatus.toLowerCase())
                        || String(log.verification_method || '').toLowerCase().includes('early closure');
                    const normStatus = this.normalizeStatus(rawStatus);
                    if (isClosureRow) {
                        earlyOutMinutes = 0;
                        status = (lateMinutes > 0 || normStatus === 'Late' || normStatus === 'Late & Early Out') ? 'Late' : 'Present (Early Closure)';
                    } else {
                        status = normStatus;
                    }
                    const effectiveNorm = this.normalizeStatus(status);
                    if (effectiveNorm === 'Present') {
                        present++;
                        if (lateMinutes > 0) late++;
                    } else if (effectiveNorm === 'Late') {
                        present++;
                        late++;
                    } else if (effectiveNorm === 'Early Out') {
                        present++;
                        earlyOut++;
                    } else if (effectiveNorm === 'Late & Early Out') {
                        present++;
                        late++;
                        earlyOut++;
                    } else if (effectiveNorm === 'Half Day') {
                        halfDay++;
                    } else if (effectiveNorm === 'Absent') {
                        absent++;
                    } else if (effectiveNorm === 'On Leave' || effectiveNorm === 'Paid Leave') {
                        onLeave++;
                    }

                    if (!isClosureRow && earlyOutMinutes > 0 && effectiveNorm !== 'Early Out' && effectiveNorm !== 'Late & Early Out') {
                        earlyOut++;
                    }

                    totalHours += workedHours;
                    totalOt += otHours;
                } else if (!isHoliday && !isWeeklyOff && !isOnLeave) {
                    if (dateStr <= todayStr) {
                        status = 'Absent';
                        absent++;
                    } else {
                        status = 'Upcoming';
                    }
                }

                const logPayload = {
                    id: log ? (log.id || ('ATT-' + dateStr)) : ('ATT-' + dateStr),
                    date: dateStr,
                    attendance_date: dateStr,
                    employee_id: emp.id,
                    employee_name: `${emp.first_name || ''} ${emp.last_name || ''}`,
                    employee_code: emp.employee_code || 'EMP',
                    department_name: emp.department_name || 'General',
                    branch_name: emp.branch_name || 'Main Office',
                    shift_name: shiftName,
                    shift_start: shiftStart,
                    shift_end: shiftEnd,
                    check_in: checkIn || '--:--:--',
                    check_out: checkOut || '--:--:--',
                    working_hours: workedHours,
                    overtime_hours: otHours,
                    late_minutes: lateMinutes,
                    early_out_minutes: earlyOutMinutes,
                    status: status,
                    verification_method: method,
                    gps_lat: log ? log.gps_lat : null,
                    gps_lon: log ? log.gps_lon : null,
                    is_within_geofence: log ? log.is_within_geofence : 1
                };

                return {
                    date: dateStr,
                    dayOfWeek,
                    dayFull,
                    isHoliday,
                    isWeeklyOff,
                    isOnLeave,
                    holidayName: holiday ? (holiday.name || 'Company Holiday') : null,
                    leaveType: leave ? (leave.leave_type_name || leave.leave_type || 'Approved Leave') : null,
                    shiftName,
                    shiftStart,
                    shiftEnd,
                    checkIn: checkIn || '--:--:--',
                    checkOut: checkOut || '--:--:--',
                    lateMinutes,
                    earlyOutMinutes,
                    breakHours: log && log.break_hours !== undefined && log.break_hours !== null ? (parseFloat(log.break_hours || 0)).toFixed(2) : '0.00',
                    workedHours: workedHours.toFixed(2),
                    reqHours: reqHours.toFixed(1),
                    otHours: otHours.toFixed(2),
                    status,
                    method,
                    logObj: logPayload
                };
            });

            this.dailyRows = rows;

            const punctuality = present > 0 ? Math.round(((present - late) / present) * 100) : 100;
            const attRate = workingDays > 0 ? Math.round((present / workingDays) * 100) : 100;

            this.empSummary = {
                calendarDays,
                workingDays,
                present,
                late,
                earlyOut,
                halfDay,
                absent,
                onLeave,
                holidayDays,
                weeklyOffDays,
                totalHours: totalHours.toFixed(1),
                totalRequired: totalRequired.toFixed(1),
                totalOt: totalOt.toFixed(1),
                punctualityRate: Math.max(0, punctuality),
                attendanceRate: Math.max(0, attRate)
            };

            this.$nextTick(() => {
                if (window.lucide) window.lucide.createIcons();
            });
        },

        get filteredDailyRows() {
            if (this.statusFilter === 'all') return this.dailyRows;
            const filterNorm = this.normalizeStatus(this.statusFilter);
            return this.dailyRows.filter(r => this.normalizeStatus(r.status) === filterNorm);
        },

        exportLedgerCsv() {
            const emp = this.currentEmployee;
            const headers = ['Date', 'Day', 'Shift', 'Scheduled In', 'Actual In', 'Late (min)', 'Scheduled Out', 'Actual Out', 'Early Out (min)', 'Break (h)', 'Worked (h)', 'Req (h)', 'Overtime (h)', 'Attendance Status', 'Method'];
            const csvRows = [headers.join(',')];

            this.dailyRows.forEach(r => {
                const row = [
                    r.date,
                    r.dayOfWeek,
                    `"${r.shiftName}"`,
                    r.shiftStart,
                    r.checkIn,
                    r.lateMinutes,
                    r.shiftEnd,
                    r.checkOut,
                    r.earlyOutMinutes,
                    r.breakHours,
                    r.workedHours,
                    r.reqHours,
                    r.otHours,
                    `"${r.status}"`,
                    `"${r.method}"`
                ];
                csvRows.push(row.join(','));
            });

            const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', `Attendance_Ledger_${emp.employee_code || emp.id}_${this.filterFrom}_to_${this.filterTo}.csv`);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    };
};
</script>

<div x-show="activeTab === 'employee'" x-data="employeeAttendanceModule()" x-init="initEmpTab()" class="space-y-6 animate-in fade-in duration-200">

    <!-- Top Employee Selection & Period Controls -->
    <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        
        <!-- Employee Selector Dropdown / Self Profile -->
        <div class="flex-1 w-full md:max-w-md space-y-1">
            <label class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block font-mono">
                <?= (!empty($attendanceScope) && $attendanceScope === 'self') ? 'Employee Profile' : 'Select Employee to Track' ?>
            </label>
            <?php if (!empty($attendanceScope) && $attendanceScope === 'self' && !empty($employees)): ?>
                <?php $me = $employees[0]; ?>
                <div class="flex items-center gap-3 px-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl">
                    <div class="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-900/50 flex items-center justify-center text-indigo-700 dark:text-indigo-300 font-bold text-xs shrink-0">
                        <?= esc(strtoupper(substr($me['first_name'] ?? 'E', 0, 1) . substr($me['last_name'] ?? 'M', 0, 1))) ?>
                    </div>
                    <div class="min-w-0">
                        <div class="text-xs font-bold text-slate-900 dark:text-white truncate">
                            <?= esc(($me['first_name'] ?? '') . ' ' . ($me['last_name'] ?? '')) ?> (<?= esc($me['employee_code'] ?? 'EMP-' . $me['id']) ?>)
                        </div>
                        <div class="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                            <?= esc($me['department_name'] ?? 'General') ?> • <?= esc($me['designation_name'] ?? 'Staff') ?>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="relative">
                    <select
                        x-model="currentEmpId"
                        @change="changeEmployee($event.target.value)"
                        class="w-full text-xs font-bold px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl focus:outline-none focus:bg-white dark:focus:bg-slate-900 text-slate-900 dark:text-white cursor-pointer"
                    >
                        <?php if (!empty($employees)): ?>
                            <?php foreach ($employees as $e): ?>
                                <option value="<?= esc($e['id']) ?>" :selected="String(currentEmpId) === '<?= esc($e['id']) ?>'">
                                    <?= esc(($e['first_name'] ?? '') . ' ' . ($e['last_name'] ?? '')) ?> (<?= esc($e['employee_code'] ?? 'EMP-' . $e['id']) ?>) • <?= esc($e['department_name'] ?? 'General') ?>
                                </option>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <option value="1">Imran Hasan (EMP-101) • Technology & Engineering</option>
                        <?php endif; ?>
                    </select>
                </div>
            <?php endif; ?>
        </div>

        <!-- Date Range Selector -->
        <div class="flex flex-wrap items-center gap-2">
            <div>
                <span class="text-[9px] font-bold text-slate-400 uppercase tracking-wider block font-mono">From</span>
                <input
                    type="date"
                    :value="filterFrom"
                    :min="currentEmployeeJoinDate"
                    @change="onFromDateChange($event.target.value)"
                    class="text-xs font-bold px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none text-slate-900 dark:text-white"
                />
            </div>
            <div>
                <span class="text-[9px] font-bold text-slate-400 uppercase tracking-wider block font-mono">To</span>
                <input
                    type="date"
                    x-model="filterTo"
                    class="text-xs font-bold px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none text-slate-900 dark:text-white"
                />
            </div>
            <div class="pt-3.5 flex items-center gap-2">
                <button
                    @click="applyFilters()"
                    :disabled="isApplying || isLoadingEmp"
                    type="button"
                    class="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                    title="Apply selected employee date range"
                >
                    <svg x-show="isApplying || isLoadingEmp" class="w-3.5 h-3.5 animate-spin" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
                    </svg>
                    <svg x-show="!isApplying && !isLoadingEmp" class="w-3.5 h-3.5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"></polygon>
                    </svg>
                    <span x-text="(isApplying || isLoadingEmp) ? 'Applying...' : 'Apply'">Apply</span>
                </button>
                <button
                    @click="exportLedgerCsv()"
                    class="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-50 dark:bg-indigo-950 hover:bg-indigo-100 text-indigo-700 dark:text-indigo-300 rounded-xl text-xs font-bold transition border border-indigo-200 dark:border-indigo-800 cursor-pointer"
                >
                    <i data-lucide="download" class="w-3.5 h-3.5"></i>
                    <span>Export CSV</span>
                </button>
            </div>
        </div>

    </div>

    <!-- Clamped Date Notice Alert -->
    <div x-show="showClampedNotice" x-transition class="text-xs text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 px-4 py-2.5 rounded-2xl flex items-center gap-2 font-medium">
        <i data-lucide="info" class="w-4 h-4 shrink-0 text-amber-500"></i>
        <span>Start date was automatically clamped to the employee's joining date (<strong class="font-mono" x-text="currentEmployeeJoinDate"></strong>).</span>
    </div>

    <!-- Quick Range Presets Toolbar -->
    <div class="flex flex-wrap items-center gap-2 p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 text-xs">
        <span class="text-slate-400 font-bold uppercase text-[10px] tracking-wider mr-1">Quick Ranges:</span>
        <button 
            @click="setQuickRange('this_month')" 
            :class="activeQuickRange === 'this_month' ? 'bg-indigo-600 text-white font-bold' : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium hover:bg-slate-200'"
            class="px-2.5 py-1 rounded-lg transition cursor-pointer">
            This Month
        </button>
        <button 
            @click="setQuickRange('last_month')" 
            :class="activeQuickRange === 'last_month' ? 'bg-indigo-600 text-white font-bold' : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium hover:bg-slate-200'"
            class="px-2.5 py-1 rounded-lg transition cursor-pointer">
            Last Month
        </button>
        <button 
            @click="setQuickRange('last_30')" 
            :class="activeQuickRange === 'last_30' ? 'bg-indigo-600 text-white font-bold' : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium hover:bg-slate-200'"
            class="px-2.5 py-1 rounded-lg transition cursor-pointer">
            Past 30 Days
        </button>
        <button 
            x-show="currentEmployeeJoinDate"
            @click="setQuickRange('since_joining')" 
            :class="activeQuickRange === 'since_joining' ? 'bg-indigo-600 text-white font-bold' : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium hover:bg-slate-200'"
            class="px-2.5 py-1 rounded-lg transition cursor-pointer">
            <span>Since Joining</span>
            <span class="text-[10px] opacity-80 font-mono" x-text="`(${currentEmployeeJoinDate})`"></span>
        </button>
        <button 
            @click="setQuickRange('year')" 
            :class="activeQuickRange === 'year' ? 'bg-indigo-600 text-white font-bold' : 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-400 font-bold hover:bg-indigo-100'"
            class="px-2.5 py-1 rounded-lg transition cursor-pointer">
            📅 Full Year
        </button>
    </div>

    <!-- Employee Profile Header Card (Exact React Cool Design) -->
    <div class="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 text-white rounded-3xl p-6 shadow-xl border border-slate-800 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        
        <div class="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div class="w-16 h-16 rounded-2xl overflow-hidden bg-indigo-950/80 border-2 border-indigo-500/40 shrink-0 flex items-center justify-center relative shadow-inner">
                <img 
                    :src="currentEmployee.photo || currentEmployee.avatar || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150'" 
                    :alt="currentEmployee.name || 'Employee Avatar'" 
                    class="w-full h-full object-cover" 
                    @error="$el.style.display='none'; $el.nextElementSibling.classList.remove('hidden'); $el.nextElementSibling.classList.add('flex');"
                />
                <div class="w-full h-full hidden items-center justify-center bg-indigo-900/80 text-indigo-200 font-black text-lg">
                    <span x-text="(((currentEmployee.first_name || currentEmployee.name || 'E')[0] || '') + ((currentEmployee.last_name || '')[0] || '')).toUpperCase()"></span>
                </div>
            </div>
            <div class="space-y-1">
                <div class="flex flex-wrap items-center gap-2">
                    <h2 class="text-xl font-black text-white tracking-tight" x-text="currentEmployee.name || `${currentEmployee.first_name || ''} ${currentEmployee.last_name || ''}`.trim() || 'Alexander Wright'"></h2>
                    <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-indigo-900/60 text-indigo-300 border border-indigo-700/50" x-text="currentEmployee.employee_code || ('EMP-' + (currentEmployee.id || '1001'))"></span>
                    <span :class="(currentEmployee.status === 'Inactive' || currentEmployee.status === 'inactive') ? 'bg-rose-500/20 text-rose-300 border-rose-500/30' : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'" class="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold border" x-text="currentEmployee.status || 'Active'"></span>
                </div>

                <div class="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-300">
                    <span class="flex items-center gap-1"><i data-lucide="briefcase" class="w-3.5 h-3.5 text-indigo-400"></i> <span x-text="currentEmployee.designation_name || currentEmployee.role || currentEmployee.designation || 'Staff'"></span></span>
                    <span class="flex items-center gap-1"><i data-lucide="building" class="w-3.5 h-3.5 text-indigo-400"></i> <span x-text="currentEmployee.department_name || currentEmployee.department || 'General'"></span></span>
                    <span class="flex items-center gap-1"><i data-lucide="map-pin" class="w-3.5 h-3.5 text-indigo-400"></i> <span x-text="currentEmployee.branch_name || currentEmployee.branch || 'Dhaka Head Office'"></span></span>
                    <span class="flex items-center gap-1 font-mono text-indigo-200"><i data-lucide="clock" class="w-3.5 h-3.5 text-indigo-400"></i> <span x-text="`${currentEmployee.shift_name || 'General Shift (8 AM - 4 PM)'} (${currentEmployee.start_time || '08:00'}-${currentEmployee.end_time || '16:00'})`"></span></span>
                </div>
            </div>
        </div>

        <div class="bg-white/10 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 flex items-center gap-4 text-xs font-mono shrink-0">
            <div>
                <span class="text-[9px] text-slate-400 block uppercase">Attendance Rate</span>
                <span class="text-lg font-black text-emerald-400" x-text="empSummary.attendanceRate + '%'"></span>
            </div>
            <div class="h-8 w-px bg-white/20"></div>
            <div>
                <span class="text-[9px] text-slate-400 block uppercase">Punctuality</span>
                <span class="text-lg font-black text-indigo-300" x-text="empSummary.punctualityRate + '%'"></span>
            </div>
            <div class="h-8 w-px bg-white/20"></div>
            <div>
                <span class="text-[9px] text-slate-400 block uppercase">Total Overtime</span>
                <span class="text-lg font-black text-amber-300" x-text="empSummary.totalOt + 'h'"></span>
            </div>
        </div>

    </div>

    <!-- Summary KPI Strip for the Filtered Period (12 Mini Metrics) -->
    <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
        <div class="bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 text-center">
            <span class="text-[10px] font-bold text-slate-400 uppercase block">Calendar Days</span>
            <span class="text-lg font-black font-mono text-slate-800 dark:text-white" x-text="empSummary.calendarDays"></span>
        </div>
        <div class="bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 text-center">
            <span class="text-[10px] font-bold text-slate-400 uppercase block">Working Days</span>
            <span class="text-lg font-black font-mono text-slate-800 dark:text-white" x-text="empSummary.workingDays"></span>
        </div>
        <div class="bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 text-center">
            <span class="text-[10px] font-bold text-emerald-600 uppercase block">Present Days</span>
            <span class="text-lg font-black font-mono text-emerald-700 dark:text-emerald-400" x-text="empSummary.present"></span>
        </div>
        <div class="bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 text-center">
            <span class="text-[10px] font-bold text-amber-600 uppercase block">Late Days</span>
            <span class="text-lg font-black font-mono text-amber-700 dark:text-amber-400" x-text="empSummary.late"></span>
        </div>
        <div class="bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 text-center">
            <span class="text-[10px] font-bold text-indigo-600 uppercase block">Early Out Days</span>
            <span class="text-lg font-black font-mono text-indigo-700 dark:text-indigo-400" x-text="empSummary.earlyOut"></span>
        </div>
        <div class="bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 text-center">
            <span class="text-[10px] font-bold text-rose-600 uppercase block">Absent Days</span>
            <span class="text-lg font-black font-mono text-rose-700 dark:text-rose-400" x-text="empSummary.absent"></span>
        </div>
        <div class="bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 text-center">
            <span class="text-[10px] font-bold text-purple-600 uppercase block">Leave Days</span>
            <span class="text-lg font-black font-mono text-purple-700 dark:text-purple-400" x-text="empSummary.onLeave"></span>
        </div>
        <div class="bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 text-center">
            <span class="text-[10px] font-bold text-blue-600 uppercase block">Holidays</span>
            <span class="text-lg font-black font-mono text-blue-700 dark:text-blue-400" x-text="empSummary.holidayDays"></span>
        </div>
        <div class="bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 text-center">
            <span class="text-[10px] font-bold text-slate-500 uppercase block">Weekly Off</span>
            <span class="text-lg font-black font-mono text-slate-700 dark:text-slate-300" x-text="empSummary.weeklyOffDays"></span>
        </div>
        <div class="bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 text-center">
            <span class="text-[10px] font-bold text-orange-600 uppercase block">Half Days</span>
            <span class="text-lg font-black font-mono text-orange-700 dark:text-orange-400" x-text="empSummary.halfDay"></span>
        </div>
        <div class="bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 text-center">
            <span class="text-[10px] font-bold text-indigo-600 uppercase block">Worked Hours</span>
            <span class="text-lg font-black font-mono text-indigo-700 dark:text-indigo-400" x-text="empSummary.totalHours + 'h'"></span>
        </div>
        <div class="bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 text-center">
            <span class="text-[10px] font-bold text-emerald-600 uppercase block">Total OT Hours</span>
            <span class="text-lg font-black font-mono text-emerald-700 dark:text-emerald-400" x-text="empSummary.totalOt + 'h'"></span>
        </div>
    </div>

    <!-- 8 Interactive Sub-Tabs Switcher -->
    <div class="flex items-center gap-1.5 p-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-x-auto text-xs shadow-xs">
        
        <button @click="activeSubTab = 'history'" :class="activeSubTab === 'history' ? 'bg-indigo-600 text-white font-bold shadow-xs shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900'" class="px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer shrink-0">
            <i data-lucide="history" class="w-3.5 h-3.5"></i>
            <span>Attendance History (<span x-text="dailyRows.length"></span>)</span>
        </button>

        <button @click="activeSubTab = 'profile'" :class="activeSubTab === 'profile' ? 'bg-indigo-600 text-white font-bold shadow-xs shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900'" class="px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer shrink-0">
            <i data-lucide="user" class="w-3.5 h-3.5"></i>
            <span>Profile</span>
        </button>

        <button @click="activeSubTab = 'daily-details'" :class="activeSubTab === 'daily-details' ? 'bg-indigo-600 text-white font-bold shadow-xs shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900'" class="px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer shrink-0">
            <i data-lucide="clock" class="w-3.5 h-3.5"></i>
            <span>Daily Details</span>
        </button>

        <button @click="activeSubTab = 'punch-history'" :class="activeSubTab === 'punch-history' ? 'bg-indigo-600 text-white font-bold shadow-xs shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900'" class="px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer shrink-0">
            <i data-lucide="file-text" class="w-3.5 h-3.5"></i>
            <span>Punch History</span>
        </button>

        <button @click="activeSubTab = 'leave'" :class="activeSubTab === 'leave' ? 'bg-indigo-600 text-white font-bold shadow-xs shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900'" class="px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer shrink-0">
            <i data-lucide="calendar" class="w-3.5 h-3.5"></i>
            <span>Leave (<span x-text="employeeLeaves.length"></span>)</span>
        </button>

        <button @click="activeSubTab = 'overtime'" :class="activeSubTab === 'overtime' ? 'bg-indigo-600 text-white font-bold shadow-xs shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900'" class="px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer shrink-0">
            <i data-lucide="trending-up" class="w-3.5 h-3.5"></i>
            <span>Overtime</span>
        </button>

        <button @click="activeSubTab = 'corrections'" :class="activeSubTab === 'corrections' ? 'bg-indigo-600 text-white font-bold shadow-xs shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900'" class="px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer shrink-0">
            <i data-lucide="alert-circle" class="w-3.5 h-3.5"></i>
            <span>Corrections (<span x-text="employeeCorrections.length"></span>)</span>
        </button>

        <button @click="activeSubTab = 'monthly-summary'" :class="activeSubTab === 'monthly-summary' ? 'bg-indigo-600 text-white font-bold shadow-xs shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900'" class="px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer shrink-0">
            <i data-lucide="award" class="w-3.5 h-3.5"></i>
            <span>Monthly Summary</span>
        </button>

    </div>

    <!-- ========================================================================= -->
    <!-- SUB-TAB 1: 📅 COMPREHENSIVE 19-COLUMN DAILY ATTENDANCE LEDGER HISTORY === -->
    <!-- ========================================================================= -->
    <div x-show="activeSubTab === 'history'" class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm overflow-hidden space-y-4 p-4 animate-in fade-in">
        
        <!-- B10: Stale Punches Warning Banner -->
        <template x-if="hasStalePunches && latestPunchDate">
            <div class="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-in fade-in">
                <div class="flex items-center gap-3">
                    <div class="w-9 h-9 rounded-xl bg-amber-100 dark:bg-amber-900/50 text-amber-700 dark:text-amber-300 flex items-center justify-center shrink-0">
                        <i data-lucide="clock" class="w-5 h-5"></i>
                    </div>
                    <div>
                        <h5 class="text-xs font-bold text-amber-900 dark:text-amber-200">
                            No punches since <span class="font-mono underline" x-text="latestPunchDate"></span>
                        </h5>
                        <p class="text-[11px] text-amber-700/80 dark:text-amber-300/80">
                            The latest attendance activity recorded for this employee was on <span class="font-mono font-semibold" x-text="latestPunchDate"></span>.
                        </p>
                    </div>
                </div>
                <button 
                    @click="jumpToLastActivity()"
                    class="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer shrink-0 flex items-center gap-1.5">
                    <i data-lucide="arrow-down" class="w-3.5 h-3.5"></i>
                    <span>Jump to last activity</span>
                </button>
            </div>
        </template>

        <!-- B4: Pending Biometric Punches Notice -->
        <template x-if="pendingBiometricPunches > 0 && !biometricBannerDismissed">
            <div class="bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-200 dark:border-indigo-800 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-in fade-in">
                <div class="flex items-start gap-3">
                    <div class="w-9 h-9 rounded-xl bg-indigo-100 dark:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0 mt-0.5">
                        <i data-lucide="fingerprint" class="w-5 h-5"></i>
                    </div>
                    <div class="space-y-1">
                        <div class="flex items-center gap-2">
                            <h5 class="text-xs font-bold text-indigo-950 dark:text-indigo-200">
                                <span x-text="pendingBiometricPunches"></span> raw punches pending evaluation for this employee
                            </h5>
                        </div>
                        <p class="text-[11px] text-indigo-700/80 dark:text-indigo-300/80">
                            Biometric devices captured raw events that have not yet been evaluated against shift and grace window rules.
                        </p>
                        <template x-if="topReprocessNotes && topReprocessNotes.length > 0">
                            <div class="flex flex-wrap items-center gap-1.5 pt-1">
                                <span class="text-[10px] text-indigo-500 font-semibold">Reprocess notes:</span>
                                <template x-for="(note, nIdx) in topReprocessNotes" :key="nIdx">
                                    <span class="px-2 py-0.5 rounded-md bg-indigo-100/70 dark:bg-indigo-900/40 text-[10px] font-mono text-indigo-800 dark:text-indigo-300" x-text="note"></span>
                                </template>
                            </div>
                        </template>
                    </div>
                </div>
                <div class="flex items-center gap-2 shrink-0">
                    <button 
                        @click="reprocessBiometric()"
                        :disabled="isReprocessing"
                        class="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer flex items-center gap-1.5 disabled:opacity-50">
                        <span x-show="!isReprocessing">Reprocess Now</span>
                        <span x-show="isReprocessing">Reprocessing...</span>
                    </button>
                    <button 
                        @click="biometricBannerDismissed = true"
                        class="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg cursor-pointer transition"
                        title="Dismiss notice">
                        <i data-lucide="x" class="w-4 h-4"></i>
                    </button>
                </div>
            </div>
        </template>

        <div class="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
            <div>
                <h4 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                    <i data-lucide="history" class="w-4 h-4 text-indigo-600"></i>
                    Comprehensive Daily Attendance Ledger
                </h4>
                <p class="text-xs text-slate-500">Every single date evaluated against shifts, grace window, and overtime rules</p>
            </div>

            <div class="flex items-center gap-2 text-xs">
                <label class="font-bold text-slate-500">Filter Status:</label>
                <select x-model="statusFilter" class="px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-slate-700 dark:text-slate-200 focus:outline-none">
                    <option value="all">All Statuses (<span x-text="dailyRows.length"></span>)</option>
                    <option value="Present">Present</option>
                    <option value="Late">Late</option>
                    <option value="Early Out">Early Out</option>
                    <option value="Late & Early Out">Late & Early Out</option>
                    <option value="Half Day">Half Day</option>
                    <option value="Absent">Absent</option>
                    <option value="On Leave">On Leave</option>
                    <option value="Holiday">Holiday</option>
                    <option value="Weekly Off">Weekly Off</option>
                    <option value="Missing Punch">Missing Punch</option>
                </select>
                <span class="text-xs text-slate-400 font-mono ml-2" x-text="`${filteredDailyRows.length} records shown`"></span>
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-xs">
                <thead>
                    <tr class="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200/80 dark:border-slate-800 text-[11px] font-bold text-slate-500 uppercase tracking-wider whitespace-nowrap">
                        <th class="py-3 px-3">Date</th>
                        <th class="py-3 px-2">Day</th>
                        <th class="py-3 px-2">Shift</th>
                        <th class="py-3 px-2">Sched In</th>
                        <th class="py-3 px-3">Actual In</th>
                        <th class="py-3 px-2 text-center">Late (m)</th>
                        <th class="py-3 px-2">Sched Out</th>
                        <th class="py-3 px-3">Actual Out</th>
                        <th class="py-3 px-2 text-center">Early Out (m)</th>
                        <th class="py-3 px-2 text-center">Break (h)</th>
                        <th class="py-3 px-3 text-center">Worked (h)</th>
                        <th class="py-3 px-2 text-center">Req (h)</th>
                        <th class="py-3 px-2 text-center">OT (h)</th>
                        <th class="py-3 px-3 text-center">Attendance Status</th>
                        <th class="py-3 px-2">Leave</th>
                        <th class="py-3 px-2">Holiday</th>
                        <th class="py-3 px-2 text-center">Off-Day</th>
                        <th class="py-3 px-2 text-center">Correction</th>
                        <th class="py-3 px-2 text-center">Source</th>
                        <th class="py-3 px-3 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-800 whitespace-nowrap">
                    <!-- B6: Empty State -->
                    <template x-if="filteredDailyRows.length === 0">
                        <tr>
                            <td colspan="20" class="p-8 text-center text-slate-500">
                                <div class="max-w-md mx-auto space-y-3 py-4">
                                    <div class="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 flex items-center justify-center mx-auto">
                                        <i data-lucide="calendar-x" class="w-6 h-6"></i>
                                    </div>
                                    <h5 class="font-bold text-slate-800 dark:text-slate-200 text-sm">No attendance records found</h5>
                                    <p class="text-xs text-slate-500 dark:text-slate-400">
                                        Date range searched: <span class="font-mono font-bold" x-text="`${filterFrom} to ${filterTo}`"></span>
                                    </p>
                                    <template x-if="pendingBiometricPunches > 0">
                                        <div class="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 text-xs text-amber-800 dark:text-amber-300 font-medium">
                                            <span class="font-bold" x-text="pendingBiometricPunches"></span> raw biometric punches are waiting to be processed.
                                        </div>
                                    </template>
                                    <div class="text-[11px] text-slate-400">
                                        <span>Employee Joining Date: <strong class="font-mono" x-text="currentEmployeeJoinDate || 'N/A'"></strong></span> • 
                                        <span>Status: <strong x-text="currentEmployee.status || 'Active'"></strong></span>
                                    </div>
                                    <div class="pt-2 flex items-center justify-center gap-2">
                                        <button 
                                            @click="openCorrectionFor(currentEmpId, filterTo, '09:00', '18:00')"
                                            class="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer">
                                            Record Manual Attendance
                                        </button>
                                        <button 
                                            @click="activeTab = 'biometric'"
                                            class="px-3.5 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold transition cursor-pointer">
                                            Import Punches
                                        </button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </template>
                    <template x-for="r in filteredDailyRows" :key="r.date">
                        <tr :id="'ledger-row-' + r.date" class="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition">
                            
                            <!-- 1. Date -->
                            <td class="py-3 px-3">
                                <span class="font-mono font-bold text-slate-900 dark:text-white" x-text="r.date"></span>
                            </td>

                            <!-- 2. Day of week -->
                            <td class="py-3 px-2 text-slate-600 dark:text-slate-400 font-medium" x-text="r.dayOfWeek"></td>

                            <!-- 3. Shift -->
                            <td class="py-3 px-2">
                                <span class="font-mono text-[11px] text-slate-700 dark:text-slate-300" x-text="r.shiftName"></span>
                            </td>

                            <!-- 4. Sched In -->
                            <td class="py-3 px-2 font-mono text-slate-500" x-text="r.shiftStart"></td>

                            <!-- 5. Actual In -->
                            <td class="py-3 px-3">
                                <span class="font-mono font-bold text-slate-900 dark:text-white" x-text="r.checkIn"></span>
                            </td>

                            <!-- 6. Late Minutes -->
                            <td class="py-3 px-2 text-center font-mono">
                                <template x-if="r.lateMinutes > 0">
                                    <span class="text-amber-600 font-bold" x-text="'+' + r.lateMinutes + 'm'"></span>
                                </template>
                                <template x-if="!r.lateMinutes || r.lateMinutes <= 0">
                                    <span class="text-slate-300">0m</span>
                                </template>
                            </td>

                            <!-- 7. Sched Out -->
                            <td class="py-3 px-2 font-mono text-slate-500" x-text="r.shiftEnd"></td>

                            <!-- 8. Actual Out -->
                            <td class="py-3 px-3">
                                <span class="font-mono font-bold text-slate-900 dark:text-white" x-text="r.checkOut"></span>
                            </td>

                            <!-- 9. Early Out Minutes -->
                            <td class="py-3 px-2 text-center font-mono">
                                <template x-if="r.earlyOutMinutes > 0">
                                    <span class="text-rose-600 font-bold" x-text="'-' + r.earlyOutMinutes + 'm'"></span>
                                </template>
                                <template x-if="!r.earlyOutMinutes || r.earlyOutMinutes <= 0">
                                    <span class="text-slate-300">0m</span>
                                </template>
                            </td>

                            <!-- 10. Break Hours -->
                            <td class="py-3 px-2 text-center font-mono text-slate-500" x-text="r.breakHours + 'h'"></td>

                            <!-- 11. Worked Hours -->
                            <td class="py-3 px-3 text-center">
                                <span class="font-mono font-black text-indigo-700 dark:text-indigo-400" x-text="r.workedHours + 'h'"></span>
                            </td>

                            <!-- 12. Req Hours -->
                            <td class="py-3 px-2 text-center font-mono text-slate-400" x-text="r.reqHours + 'h'"></td>

                            <!-- 13. OT Hours -->
                            <td class="py-3 px-2 text-center font-mono">
                                <template x-if="parseFloat(r.otHours) > 0">
                                    <span class="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-bold text-[10px] border border-emerald-200" x-text="'+' + r.otHours + 'h'"></span>
                                </template>
                                <template x-if="!parseFloat(r.otHours) || parseFloat(r.otHours) <= 0">
                                    <span class="text-slate-300">0h</span>
                                </template>
                            </td>

                            <!-- 14. Attendance Status -->
                            <td class="py-3 px-3 text-center">
                                <span :class="getStatusBadgeClass(r.status)" class="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold border inline-block" x-text="normalizeStatus(r.status)"></span>
                            </td>

                            <!-- 15. Leave -->
                            <td class="py-3 px-2 text-slate-600 dark:text-slate-400" x-text="r.leaveType || '-'"></td>

                            <!-- 16. Holiday -->
                            <td class="py-3 px-2 text-slate-600 dark:text-slate-400" x-text="r.holidayName || '-'"></td>

                            <!-- 17. Off-Day -->
                            <td class="py-3 px-2 text-center font-mono text-slate-600 dark:text-slate-400" x-text="r.isWeeklyOff ? 'Yes' : 'No'"></td>

                            <!-- 18. Correction -->
                            <td class="py-3 px-2 text-center">
                                <span class="text-slate-400">-</span>
                            </td>

                            <!-- 19. Source -->
                            <td class="py-3 px-2 text-center text-slate-600 dark:text-slate-400" x-text="r.method || 'Web'"></td>

                            <!-- 20. Actions -->
                            <td class="py-3 px-3 text-right">
                                <div class="flex items-center justify-end gap-1.5">
                                    <button @click="openDiagnosticLog(r.logObj)" title="View Day Diagnostic Breakdown" class="p-1.5 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-950 text-slate-400 hover:text-indigo-600 transition cursor-pointer">
                                        <i data-lucide="scan" class="w-3.5 h-3.5"></i>
                                    </button>
                                    <button @click="openCorrectionFor(currentEmpId, r.date, r.checkIn, r.checkOut)" title="Regularize Attendance" class="px-2 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-[11px] font-bold transition cursor-pointer">
                                        Regularize
                                    </button>
                                </div>
                            </td>

                        </tr>
                    </template>
                </tbody>
            </table>
        </div>

    </div>

    <!-- ========================================================================= -->
    <!-- SUB-TAB 2: 👤 EMPLOYEE PROFILE & SHIFT POLICIES ========================= -->
    <!-- ========================================================================= -->
    <div x-show="activeSubTab === 'profile'" class="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in">
        
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm space-y-4">
            <h4 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                <i data-lucide="user" class="w-4 h-4 text-indigo-600"></i>
                Organizational Assignment
            </h4>
            <div class="divide-y divide-slate-100 dark:divide-slate-800 text-xs space-y-2.5 pt-2">
                <div class="flex justify-between py-1.5">
                    <span class="text-slate-400">Employee ID:</span>
                    <span class="font-mono font-bold text-slate-900 dark:text-white" x-text="currentEmployee.employee_code || currentEmployee.id || 'EMP-101'"></span>
                </div>
                <div class="flex justify-between py-1.5">
                    <span class="text-slate-400">Full Name:</span>
                    <span class="font-bold text-slate-800 dark:text-white" x-text="`${currentEmployee.first_name || ''} ${currentEmployee.last_name || ''}`"></span>
                </div>
                <div class="flex justify-between py-1.5">
                    <span class="text-slate-400">Email:</span>
                    <span class="font-mono text-slate-800 dark:text-white" x-text="currentEmployee.email || '—'"></span>
                </div>
                <div class="flex justify-between py-1.5">
                    <span class="text-slate-400">Phone:</span>
                    <span class="font-mono text-slate-800 dark:text-white" x-text="currentEmployee.phone || '+880 1711-000000'"></span>
                </div>
                <div class="flex justify-between py-1.5">
                    <span class="text-slate-400">Department:</span>
                    <span class="font-bold text-slate-800 dark:text-white" x-text="currentEmployee.department_name || 'General'"></span>
                </div>
                <div class="flex justify-between py-1.5">
                    <span class="text-slate-400">Designation:</span>
                    <span class="font-bold text-slate-800 dark:text-white" x-text="currentEmployee.designation_name || 'Staff'"></span>
                </div>
                <div class="flex justify-between py-1.5">
                    <span class="text-slate-400">Branch Office:</span>
                    <span class="font-bold text-slate-800 dark:text-white" x-text="currentEmployee.branch_name || 'Main Office'"></span>
                </div>
                <div class="flex justify-between py-1.5">
                    <span class="text-slate-400">Basic Salary Basis:</span>
                    <span class="font-mono font-bold text-indigo-700 dark:text-indigo-400" x-text="(parseFloat(currentEmployee.basic_salary || currentEmployee.salary || 0)).toLocaleString()"></span>
                </div>
            </div>
        </div>

        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm space-y-4">
            <h4 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                <i data-lucide="clock" class="w-4 h-4 text-indigo-600"></i>
                Shift & Work Week Roster
            </h4>
            <div class="divide-y divide-slate-100 dark:divide-slate-800 text-xs space-y-2.5 pt-2">
                <div class="flex justify-between py-1.5">
                    <span class="text-slate-400">Assigned Shift:</span>
                    <span class="font-bold text-indigo-600" x-text="currentEmployee.shift_name || 'Standard Shift'"></span>
                </div>
                <div class="flex justify-between py-1.5">
                    <span class="text-slate-400">Standard Timings:</span>
                    <span class="font-mono font-bold text-slate-800 dark:text-white" x-text="`${currentEmployee.start_time || '08:00'} - ${currentEmployee.end_time || '16:00'}`"></span>
                </div>
                <div class="flex justify-between py-1.5">
                    <span class="text-slate-400">Late Grace Window:</span>
                    <span class="font-mono font-bold text-amber-600">15 Minutes</span>
                </div>
                <div class="flex justify-between py-1.5">
                    <span class="text-slate-400">Weekly Off Day:</span>
                    <span class="font-bold text-slate-800 dark:text-white">Friday (Off-Day OT applies)</span>
                </div>
                <div class="flex justify-between py-1.5">
                    <span class="text-slate-400">Working Days:</span>
                    <span class="font-bold text-slate-800 dark:text-white">Saturday to Thursday (6 Days / 48 hrs)</span>
                </div>
                <div class="flex justify-between py-1.5">
                    <span class="text-slate-400">Overtime Policy:</span>
                    <span class="font-bold text-emerald-600">1.5x Normal / 2.0x Off-Day</span>
                </div>
            </div>
        </div>

    </div>

    <!-- ========================================================================= -->
    <!-- SUB-TAB 3: ⏰ DAILY DETAILS (DIAGNOSTIC CARDS INSPECTOR) ================= -->
    <!-- ========================================================================= -->
    <div x-show="activeSubTab === 'daily-details'" class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm space-y-4 animate-in fade-in">
        <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <div>
                <h4 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                    <i data-lucide="clock" class="w-4 h-4 text-indigo-600"></i>
                    Detailed Daily Diagnostic Inspector
                </h4>
                <p class="text-xs text-slate-500">Select any day card to inspect full telemetry, shift grace compliance, and math</p>
            </div>
            <span class="text-xs text-slate-400 font-mono" x-text="`${dailyRows.length} Days Evaluated`"></span>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
            <template x-for="r in dailyRows.slice(0, 12)" :key="r.date">
                <div @click="openDiagnosticLog(r.logObj)" class="p-4 bg-slate-50 dark:bg-slate-800/60 hover:bg-indigo-50/50 dark:hover:bg-indigo-950/40 border border-slate-200/80 dark:border-slate-700/80 hover:border-indigo-300 rounded-2xl transition cursor-pointer space-y-2.5 shadow-xs">
                    <div class="flex items-center justify-between">
                        <span class="font-mono font-bold text-slate-900 dark:text-white text-xs" x-text="`${r.date} (${r.dayOfWeek})`"></span>
                        <span :class="{
                            'bg-emerald-50 text-emerald-700 border-emerald-200': r.status === 'Present',
                            'bg-amber-50 text-amber-700 border-amber-200': r.status === 'Late',
                            'bg-orange-50 text-orange-700 border-orange-200': r.status === 'Early Out',
                            'bg-purple-50 text-purple-700 border-purple-200': r.status === 'Half Day',
                            'bg-blue-50 text-blue-700 border-blue-200': r.status === 'On Leave' || r.status === 'Holiday',
                            'bg-slate-100 text-slate-700 border-slate-200': r.status === 'Weekly Off',
                            'bg-rose-50 text-rose-700 border-rose-200': r.status === 'Absent'
                        }" class="px-2 py-0.5 rounded-full text-[10px] font-bold border" x-text="r.status"></span>
                    </div>
                    <div class="text-xs text-slate-600 dark:text-slate-400 font-mono flex items-center justify-between">
                        <span>IN: <strong class="text-slate-800 dark:text-slate-200" x-text="r.checkIn"></strong></span>
                        <span>OUT: <strong class="text-slate-800 dark:text-slate-200" x-text="r.checkOut"></strong></span>
                    </div>
                    <div class="flex items-center justify-between text-[11px] pt-1.5 border-t border-slate-200/60 dark:border-slate-700/60">
                        <span class="text-slate-500">Worked: <strong class="text-slate-900 dark:text-white" x-text="r.workedHours + 'h'"></strong></span>
                        <span class="text-indigo-600 dark:text-indigo-400 font-bold" x-text="'OT: +' + r.otHours + 'h'"></span>
                    </div>
                </div>
            </template>
        </div>
    </div>

    <!-- ========================================================================= -->
    <!-- SUB-TAB 4: 📜 RAW PUNCH STREAM LOG ====================================== -->
    <!-- ========================================================================= -->
    <div x-show="activeSubTab === 'punch-history'" class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm space-y-4 animate-in fade-in">
        <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <div>
                <h4 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                    <i data-lucide="file-text" class="w-4 h-4 text-indigo-600"></i>
                    Biometric Terminal & Web Raw Punch Stream
                </h4>
                <p class="text-xs text-slate-500">Immutable device punch logs recorded at biometric turnstiles and web checkpoints</p>
            </div>
            <span class="text-xs font-mono text-slate-400" x-text="`${empLogs.filter(l => (l.employee_id === currentEmpId || l.employeeId === currentEmpId)).length} Punches Recorded`"></span>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs border-collapse">
                <thead>
                    <tr class="bg-slate-50 dark:bg-slate-800/60 text-slate-400 font-bold border-b border-slate-100 dark:border-slate-800 text-[11px] uppercase tracking-wider">
                        <th class="p-3">Log Date</th>
                        <th class="p-3">Check-In Time</th>
                        <th class="p-3">Check-Out Time</th>
                        <th class="p-3 text-center">Duration</th>
                        <th class="p-3 text-center">Status</th>
                        <th class="p-3 text-center">Device / Terminal</th>
                        <th class="p-3 text-center">Audit Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-800 whitespace-nowrap">
                    <template x-if="empLogs.filter(l => (l.employee_id === currentEmpId || l.employeeId === currentEmpId)).length === 0">
                        <tr>
                            <td colspan="7" class="p-8 text-center text-slate-400 italic">No raw biometric device punches recorded for this employee.</td>
                        </tr>
                    </template>
                    <template x-for="l in empLogs.filter(l => (l.employee_id === currentEmpId || l.employeeId === currentEmpId))" :key="l.id || l.date">
                        <tr class="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition">
                            <td class="p-3 font-mono font-bold text-slate-900 dark:text-white" x-text="l.date || l.log_date || l.attendance_date"></td>
                            <td class="p-3 font-mono font-bold text-indigo-600 dark:text-indigo-400" x-text="l.check_in || '---'"></td>
                            <td class="p-3 font-mono font-bold text-indigo-600 dark:text-indigo-400" x-text="l.check_out || '---'"></td>
                            <td class="p-3 font-mono font-bold text-center text-slate-800 dark:text-white" x-text="(parseFloat(l.working_hours || 0)).toFixed(2) + 'h'"></td>
                            <td class="p-3 text-center">
                                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300" x-text="l.status || 'Present'"></span>
                            </td>
                            <td class="p-3 text-center font-mono text-slate-600 dark:text-slate-400" x-text="l.verification_method || 'ZKTeco SilkBio-101 (HQ)'"></td>
                            <td class="p-3 text-center">
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200">Verified ✓</span>
                            </td>
                        </tr>
                    </template>
                </tbody>
            </table>
        </div>
    </div>

    <!-- ========================================================================= -->
    <!-- SUB-TAB 5: 🏖️ LEAVE APPLICATIONS & ENTITLEMENTS ========================= -->
    <!-- ========================================================================= -->
    <div x-show="activeSubTab === 'leave'" class="space-y-6 animate-in fade-in">
        
        <!-- Leave Balance Cards -->
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div class="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-1">
                <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Annual Leave</div>
                <div class="text-2xl font-black text-indigo-600 font-mono">15.0 <span class="text-xs font-normal text-slate-400">/ 15 Days</span></div>
                <div class="text-[10px] text-emerald-600 font-medium">100% Available</div>
            </div>
            <div class="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-1">
                <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Sick Leave</div>
                <div class="text-2xl font-black text-amber-600 font-mono">10.0 <span class="text-xs font-normal text-slate-400">/ 10 Days</span></div>
                <div class="text-[10px] text-emerald-600 font-medium">100% Available</div>
            </div>
            <div class="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-1">
                <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Casual Leave</div>
                <div class="text-2xl font-black text-emerald-600 font-mono">8.0 <span class="text-xs font-normal text-slate-400">/ 8 Days</span></div>
                <div class="text-[10px] text-emerald-600 font-medium">100% Available</div>
            </div>
            <div class="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-1">
                <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Emergency Leave</div>
                <div class="text-2xl font-black text-rose-600 font-mono">3.0 <span class="text-xs font-normal text-slate-400">/ 3 Days</span></div>
                <div class="text-[10px] text-emerald-600 font-medium">100% Available</div>
            </div>
        </div>

        <!-- Leave History Table -->
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm space-y-4">
            <h4 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                <i data-lucide="calendar" class="w-4 h-4 text-indigo-600"></i>
                Leave Applications & Approvals
            </h4>
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs border-collapse">
                    <thead>
                        <tr class="bg-slate-50 dark:bg-slate-800/60 text-slate-400 font-bold border-b border-slate-100 dark:border-slate-800 text-[11px] uppercase tracking-wider">
                            <th class="p-3">Leave Category</th>
                            <th class="p-3">From Date</th>
                            <th class="p-3">To Date</th>
                            <th class="p-3 text-center">Days</th>
                            <th class="p-3">Reason</th>
                            <th class="p-3 text-center">Approval Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-800 whitespace-nowrap">
                        <template x-if="employeeLeaves.length === 0">
                            <tr>
                                <td colspan="6" class="p-8 text-center text-slate-400 italic">No leave applications recorded for this employee in the current fiscal period.</td>
                            </tr>
                        </template>
                        <template x-for="la in employeeLeaves" :key="la.id">
                            <tr class="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition">
                                <td class="p-3 font-bold text-slate-800 dark:text-white" x-text="la.leave_type_name || la.leave_type || 'Casual Leave'"></td>
                                <td class="p-3 font-mono text-slate-700 dark:text-slate-300" x-text="la.start_date || la.from_date"></td>
                                <td class="p-3 font-mono text-slate-700 dark:text-slate-300" x-text="la.end_date || la.to_date"></td>
                                <td class="p-3 text-center font-bold font-mono text-slate-900 dark:text-white" x-text="la.total_days || '1'"></td>
                                <td class="p-3 text-slate-600 dark:text-slate-300" x-text="la.reason || 'Personal leave'"></td>
                                <td class="p-3 text-center">
                                    <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300" x-text="la.status || 'Approved'"></span>
                                </td>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- ========================================================================= -->
    <!-- SUB-TAB 6: 📈 OVERTIME & PREMIUM PAYROLL LEDGER ========================= -->
    <!-- ========================================================================= -->
    <div x-show="activeSubTab === 'overtime'" class="space-y-6 animate-in fade-in">
        
        <!-- Overtime Calculation Banner & Multipliers -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div class="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-1">
                <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Base Hourly Rate</div>
                <div class="text-2xl font-black text-slate-900 dark:text-white font-mono" x-text="((parseFloat(currentEmployee.basic_salary || currentEmployee.salary || 0)) > 0 ? (((parseFloat(currentEmployee.basic_salary || currentEmployee.salary)) / 208).toFixed(2) + '/hr') : '--')"></div>
                <div class="text-[10px] text-slate-400">Calculated from configured employee salary basis</div>
            </div>
            <div class="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-1">
                <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Regular OT Multiplier</div>
                <div class="text-2xl font-black text-emerald-600 font-mono">1.50x <span class="text-xs font-normal text-slate-400">Rate</span></div>
                <div class="text-[10px] text-emerald-600 font-medium">Applied for shift extensions &gt; 8h</div>
            </div>
            <div class="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-1">
                <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Holiday / Off-Day Multiplier</div>
                <div class="text-2xl font-black text-indigo-600 font-mono">2.00x <span class="text-xs font-normal text-slate-400">Rate</span></div>
                <div class="text-[10px] text-indigo-600 font-medium">Applied on Friday &amp; Public Holidays</div>
            </div>
        </div>

        <!-- Overtime Ledger Table -->
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm space-y-4">
            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <div>
                    <h4 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                        <i data-lucide="trending-up" class="w-4 h-4 text-emerald-600"></i>
                        Overtime & Premium Payroll Ledger
                    </h4>
                    <p class="text-xs text-slate-500">Detailed breakdown of overtime hours, rate multipliers, and estimated payable amount</p>
                </div>
                <div class="text-right">
                    <div class="text-xs text-slate-400 font-bold">Total Overtime Accrued</div>
                    <div class="text-base font-black text-emerald-600 font-mono" x-text="empSummary.totalOt + ' Hours'"></div>
                </div>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs border-collapse">
                    <thead>
                        <tr class="bg-slate-50 dark:bg-slate-800/60 text-slate-400 font-bold border-b border-slate-100 dark:border-slate-800 text-[11px] uppercase tracking-wider whitespace-nowrap">
                            <th class="p-3">Date</th>
                            <th class="p-3">Day Type</th>
                            <th class="p-3 text-center">Worked (h)</th>
                            <th class="p-3 text-center">Daily OT (h)</th>
                            <th class="p-3 text-center">Off-Day / Hol OT</th>
                            <th class="p-3 text-center">Rate Multiplier</th>
                            <th class="p-3 text-right">Est. Payable Amount</th>
                            <th class="p-3 text-center">Audit Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-800 whitespace-nowrap">
                        <template x-if="dailyRows.filter(r => parseFloat(r.otHours) > 0).length === 0">
                            <tr>
                                <td colspan="8" class="p-8 text-center text-slate-400 italic">No overtime hours logged in this selected range.</td>
                            </tr>
                        </template>
                        <template x-for="r in dailyRows.filter(r => parseFloat(r.otHours) > 0)" :key="r.date">
                            <tr class="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition">
                                <td class="p-3 font-mono font-bold text-slate-900 dark:text-white" x-text="`${r.date} (${r.dayOfWeek})`"></td>
                                <td class="p-3">
                                    <span :class="r.isHoliday ? 'text-purple-600 font-bold' : (r.isWeeklyOff ? 'text-indigo-600 font-bold' : 'text-slate-600 dark:text-slate-400')" x-text="r.isHoliday ? 'Public Holiday' : (r.isWeeklyOff ? 'Weekly Off (Friday)' : 'Regular Shift Extension')"></span>
                                </td>
                                <td class="p-3 font-mono text-center font-bold text-slate-700 dark:text-slate-300" x-text="r.workedHours + 'h'"></td>
                                <td class="p-3 font-mono font-black text-center text-emerald-600" x-text="(!r.isHoliday && !r.isWeeklyOff) ? ('+' + r.otHours + 'h') : '0.00h'"></td>
                                <td class="p-3 font-mono font-black text-center text-indigo-600" x-text="(r.isHoliday || r.isWeeklyOff) ? ('+' + r.otHours + 'h') : '0.00h'"></td>
                                <td class="p-3 text-center font-mono font-bold text-slate-800 dark:text-slate-200" x-text="r.isHoliday || r.isWeeklyOff ? '2.0x (Holiday Rate)' : '1.5x (Standard)'"></td>
                                <td class="p-3 text-right font-mono font-black text-emerald-600" x-text="parseFloat(currentEmployee.basic_salary || currentEmployee.salary || 0) > 0 ? (parseFloat(r.otHours) * ((parseFloat(currentEmployee.basic_salary || currentEmployee.salary)) / 208) * (r.isHoliday || r.isWeeklyOff ? 2.0 : 1.5)).toFixed(2) : '--'"></td>
                                <td class="p-3 text-center">
                                    <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200">Pre-Approved</span>
                                </td>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <!-- ========================================================================= -->
    <!-- SUB-TAB 7: ✏️ REGULARIZATION & CORRECTIONS =============================== -->
    <!-- ========================================================================= -->
    <div x-show="activeSubTab === 'corrections'" class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm space-y-4 animate-in fade-in">
        <div class="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
            <div>
                <h4 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                    <i data-lucide="edit-3" class="w-4 h-4 text-amber-600"></i>
                    Attendance Regularization & Correction History
                </h4>
                <p class="text-xs text-slate-500">Track and submit manual punch modifications and exception justifications</p>
            </div>
            <button @click="openCorrectionFor(currentEmpId, '<?= date('Y-m-d') ?>', '08:00', '16:00')" class="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 transition cursor-pointer flex items-center gap-1.5 shadow-sm">
                <i data-lucide="plus" class="w-3.5 h-3.5"></i>
                <span>Request Regularization</span>
            </button>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs border-collapse">
                <thead>
                    <tr class="bg-slate-50 dark:bg-slate-800/60 text-slate-400 font-bold border-b border-slate-100 dark:border-slate-800 text-[11px] uppercase tracking-wider whitespace-nowrap">
                        <th class="p-3">Attendance Date</th>
                        <th class="p-3">Correction Type</th>
                        <th class="p-3">Proposed In</th>
                        <th class="p-3">Proposed Out</th>
                        <th class="p-3">Reason / Justification</th>
                        <th class="p-3 text-center">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-800 whitespace-nowrap">
                    <template x-if="employeeCorrections.length === 0">
                        <tr>
                            <td colspan="6" class="p-8 text-center text-slate-400 italic">No attendance regularization requests found for this employee.</td>
                        </tr>
                    </template>
                    <template x-for="c in employeeCorrections" :key="c.id">
                        <tr class="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition">
                            <td class="p-3 font-mono font-bold text-slate-900 dark:text-white" x-text="c.attendance_date"></td>
                            <td class="p-3 font-bold text-slate-800 dark:text-white" x-text="c.request_type || 'Missing Check-In'"></td>
                            <td class="p-3 font-mono text-indigo-600 dark:text-indigo-400 font-bold" x-text="c.proposed_check_in || '---'"></td>
                            <td class="p-3 font-mono text-indigo-600 dark:text-indigo-400 font-bold" x-text="c.proposed_check_out || '---'"></td>
                            <td class="p-3 text-slate-600 dark:text-slate-300" x-text="c.reason || 'Regularization'"></td>
                            <td class="p-3 text-center">
                                <span :class="{
                                    'bg-emerald-50 text-emerald-700 border-emerald-200': c.status === 'Approved',
                                    'bg-amber-50 text-amber-700 border-amber-200': c.status === 'Pending',
                                    'bg-rose-50 text-rose-700 border-rose-200': c.status === 'Rejected'
                                }" class="px-2.5 py-0.5 rounded-full text-[10px] font-bold border" x-text="c.status"></span>
                            </td>
                        </tr>
                    </template>
                </tbody>
            </table>
        </div>
    </div>

    <!-- ========================================================================= -->
    <!-- SUB-TAB 8: 📊 MONTHLY SUMMARY ROLLUP ==================================== -->
    <!-- ========================================================================= -->
    <div x-show="activeSubTab === 'monthly-summary'" class="space-y-6 animate-in fade-in">
        
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
            <div class="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-1">
                <div class="text-slate-400 text-xs font-bold uppercase tracking-wider">Total Calendar Days</div>
                <div class="text-2xl font-black text-slate-900 dark:text-white font-mono" x-text="empSummary.calendarDays"></div>
                <div class="text-[10px] text-slate-400">Evaluated in Selected Range</div>
            </div>
            <div class="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-1">
                <div class="text-slate-400 text-xs font-bold uppercase tracking-wider">Days Present</div>
                <div class="text-2xl font-black text-emerald-600 font-mono" x-text="empSummary.present"></div>
                <div class="text-[10px] text-emerald-600 font-medium">On-Duty Attendance</div>
            </div>
            <div class="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-1">
                <div class="text-slate-400 text-xs font-bold uppercase tracking-wider">Total Hours Worked</div>
                <div class="text-2xl font-black text-indigo-600 font-mono" x-text="empSummary.totalHours + 'h'"></div>
                <div class="text-[10px] text-indigo-600 font-medium">Standard + Overtime</div>
            </div>
            <div class="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-1">
                <div class="text-slate-400 text-xs font-bold uppercase tracking-wider">Cumulative OT</div>
                <div class="text-2xl font-black text-emerald-600 font-mono" x-text="empSummary.totalOt + 'h'"></div>
                <div class="text-[10px] text-emerald-600 font-medium">Payable Overtime</div>
            </div>
        </div>

        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm space-y-4">
            <h4 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                <i data-lucide="layers" class="w-4 h-4 text-indigo-600"></i>
                Performance & Attendance Percentage Rollup
            </h4>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
                <div class="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-700/60 space-y-1">
                    <span class="text-slate-400">Late Arrivals</span>
                    <div class="text-xl font-bold text-amber-600 font-mono" x-text="empSummary.late + ' Days'"></div>
                </div>
                <div class="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-700/60 space-y-1">
                    <span class="text-slate-400">Early Departures</span>
                    <div class="text-xl font-bold text-rose-600 font-mono" x-text="empSummary.earlyOut + ' Days'"></div>
                </div>
                <div class="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-700/60 space-y-1">
                    <span class="text-slate-400">Attendance Rate</span>
                    <div class="text-xl font-bold text-emerald-600 font-mono" x-text="empSummary.attendanceRate + '%'"></div>
                </div>
                <div class="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-700/60 space-y-1">
                    <span class="text-slate-400">Punctuality Score</span>
                    <div class="text-xl font-bold text-indigo-600 font-mono" x-text="empSummary.punctualityRate + '%'"></div>
                </div>
            </div>
        </div>

    </div>

</div>
