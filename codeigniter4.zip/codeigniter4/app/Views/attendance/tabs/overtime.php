<?php
    $perm = $permissionService ?? new \App\Services\PermissionService();
    $currentUser = $currentUser ?? (function_exists('session') ? session()->get('user') : null);
    $userRole = (string)($currentUser['role_name'] ?? $currentUser['role_code'] ?? $currentUser['role'] ?? (function_exists('session') && session()->has('role') ? session()->get('role') : ''));

    // Permission-first flags (controller passes them; fallback resolves for the logged-in user via the single resolver)
    $canManageOvertime  = $canManageOvertime  ?? ($perm->hasAccess(null, 'overtime', 'manage') || $perm->hasAccess(null, 'attendance', 'manage'));
    $canCreateOvertime  = $canCreateOvertime  ?? ($perm->hasAccess(null, 'overtime', 'create') || $canManageOvertime);
    $canApproveOvertime = $canApproveOvertime ?? $perm->hasAccess(null, 'overtime', 'approve');
    $canEditOvertime    = $canEditOvertime    ?? ($perm->hasAccess(null, 'overtime', 'edit') || $canManageOvertime);

    $filters            = (isset($filters) && is_array($filters)) ? $filters : [];
    $activeStatus       = $filters['status'] ?? 'all';
    $curTab             = $activeTab ?? 'requests';

    $rulesData          = $rules ?? [
        'salaryBasis'            => 'Basic Salary',
        'divisorDays'            => 30,
        'divisorHours'           => 8,
        'captureMode'            => 'hybrid',
        'preApprovalRequired'    => false,
        'autoApproveThreshold'   => 2.0,
        'claimExpiryDays'        => 14,
        'mandatoryJustification' => true,
        'normalDayMultiplier'    => 1.5,
        'offDayMultiplier'       => 2.0,
        'holidayMultiplier'      => 2.0,
        'nightMultiplier'        => 1.5,
        'mealAllowanceThreshold' => 2.5,
        'lateNightTransportHour' => 4.0,
        'weeklyMaxHoursCap'      => 16.0,
        'dailyMaxHoursCap'       => 4.0,
    ];

    $simDays = !empty($simParams['sim_days']) ? (float)$simParams['sim_days'] : (float)($rulesData['divisorDays'] ?? 30);
    $simHours = !empty($simParams['sim_hours']) ? (float)$simParams['sim_hours'] : (float)($rulesData['divisorHours'] ?? 8);
    $simBasis = !empty($simParams['sim_salary_basis']) ? $simParams['sim_salary_basis'] : ($rulesData['salaryBasis'] ?? 'Basic Salary');

    // Safe collections initialization
    $requests            = (isset($requests) && is_array($requests)) ? $requests : [];
    $employeeRatesMatrix = (isset($employeeRatesMatrix) && is_array($employeeRatesMatrix)) ? $employeeRatesMatrix : [];
    $settlementLocks     = (isset($settlementLocks) && is_array($settlementLocks)) ? $settlementLocks : [];
    $attendanceSummary   = (isset($attendanceSummary) && is_array($attendanceSummary)) ? $attendanceSummary : [];
    $departments         = (isset($departments) && is_array($departments)) ? $departments : [];
    $employees           = (isset($employees) && is_array($employees)) ? $employees : [];
    $designations        = (isset($designations) && is_array($designations)) ? $designations : [];

    $stats               = array_merge([
        'total_hours'           => 0.0,
        'approved_count'        => 0,
        'total_approved_amount' => 0.0,
        'total_pending_amount'  => 0.0,
        'pending_count'         => 0,
        'rejected_count'        => 0,
    ], (isset($stats) && is_array($stats)) ? $stats : []);

    $analytics           = array_merge([
        'fatigue_alerts'        => [],
        'approval_ratio'        => 0,
        'avg_duration'          => 0,
        'labor_law_compliance'  => ['status' => 'Compliant', 'standard_hours_cap' => 48],
        'total_approved_amount' => 0.0,
        'total_approved_hours'  => 0.0,
        'department_breakdown'  => [],
    ], (isset($analytics) && is_array($analytics)) ? $analytics : []);

    // Gracefully load overtime claims from database if empty
    if (empty($requests) && class_exists('\App\Models\OvertimeClaimModel')) {
        try {
            $companyId = $company['id'] ?? (function_exists('session') && session()->has('company_id') ? session()->get('company_id') : null);
            $claimModel = new \App\Models\OvertimeClaimModel();
            $claimQuery = $claimModel->orderBy('date', 'DESC');
            if ($companyId) {
                $claimQuery->where('company_id', $companyId);
            }
            if (!empty($filters['status']) && $filters['status'] !== 'all') {
                $claimQuery->where('status', $filters['status']);
            }
            $loadedRequests = $claimQuery->findAll(100);
            if (!empty($loadedRequests)) {
                $requests = $loadedRequests;
                $approvedHours = 0.0;
                $approvedCount = 0;
                $pendingCount  = 0;
                $rejectedCount = 0;
                foreach ($requests as $r) {
                    $st = $r['status'] ?? 'Pending';
                    if ($st === 'Approved') {
                        $approvedCount++;
                        $approvedHours += (float)($r['approved_hours'] ?? $r['requested_hours'] ?? 0);
                    } elseif ($st === 'Pending') {
                        $pendingCount++;
                    } elseif ($st === 'Rejected') {
                        $rejectedCount++;
                    }
                }
                $stats['total_hours']    = $approvedHours;
                $stats['approved_count'] = $approvedCount;
                $stats['pending_count']  = $pendingCount;
                $stats['rejected_count'] = $rejectedCount;
            }
        } catch (\Throwable $e) {
            // graceful fallback
        }
    }

    if (empty($settlementLocks) && class_exists('\App\Models\OvertimeSettlementLockModel')) {
        try {
            $companyId = $company['id'] ?? (function_exists('session') && session()->has('company_id') ? session()->get('company_id') : null);
            $lockModel = new \App\Models\OvertimeSettlementLockModel();
            $lockQuery = $lockModel;
            $db = \Config\Database::connect();
            if ($db->fieldExists('payroll_month', 'overtime_settlement_locks')) {
                $lockQuery = $lockQuery->orderBy('payroll_month', 'DESC');
            } elseif ($db->fieldExists('created_at', 'overtime_settlement_locks')) {
                $lockQuery = $lockQuery->orderBy('created_at', 'DESC');
            }
            if ($companyId && $db->fieldExists('company_id', 'overtime_settlement_locks')) {
                $lockQuery->where('company_id', $companyId);
            }
            $settlementLocks = $lockQuery->findAll(50) ?: [];
        } catch (\Throwable $e) {
            $settlementLocks = [];
        }
    }
?>

<div class="space-y-6">
    <?= view('attendance/attendance_nav', ['activeTab' => 'overtime']) ?>

    <!-- Top Header & Primary Navigation -->
    <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
            <div class="flex items-center gap-2">
                <span class="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400">
                    <i data-lucide="clock" class="w-6 h-6"></i>
                </span>
                <div>
                    <div class="flex items-center gap-2.5">
                        <h1 class="text-xl lg:text-2xl font-black text-slate-900 dark:text-white tracking-tight">Overtime Tracking & Approval</h1>
                        <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800/60 font-mono">
                            <i data-lucide="cpu" class="w-3 h-3"></i>
                            <?= esc($rulesData['salaryBasis']) ?> &divide; <?= esc($rulesData['divisorDays']) ?>d &divide; <?= esc($rulesData['divisorHours']) ?>h
                        </span>
                    </div>
                    <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Dynamic formula-based overtime calculations, multi-tier claims approval workflow, biometric hardware cross-referencing, and labor fatigue monitoring.</p>
                </div>
            </div>
        </div>

        <div class="flex flex-wrap items-center gap-2.5">
            <!-- Export Claims CSV -->
            <a href="<?= base_url('attendance/overtime/export?' . http_build_query($filters ?? [])) ?>" 
               class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/60 shadow-xs transition">
                <i data-lucide="download" class="w-3.5 h-3.5"></i>
                <span>Export CSV</span>
            </a>

            <!-- Set OT Designation Override -->
            <?php if ($canManageOvertime): ?>
            <button onclick="openModal('rateModal')" 
                    class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/60 text-xs font-semibold shadow-xs transition">
                <i data-lucide="coins" class="w-3.5 h-3.5 text-amber-500"></i>
                <span>Designation Rates</span>
            </button>
            <?php endif; ?>

            <!-- Submit OT Request -->
            <?php if ($canCreateOvertime): ?>
            <button onclick="openModal('requestModal')" 
                    class="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs shadow-indigo-500/20 transition">
                <i data-lucide="plus" class="w-3.5 h-3.5"></i>
                <span>Submit OT Claim</span>
            </button>
            <?php endif; ?>
        </div>
    </div>

    <!-- 4-TAB NAVIGATION BAR -->
    <div class="flex items-center gap-2 border-b border-slate-200 dark:border-slate-700/80 pb-3 overflow-x-auto">
        <a href="<?= base_url('attendance/overtime?tab=requests') ?>" 
           class="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap <?= ($curTab === 'requests') ? 'bg-indigo-600 text-white shadow-xs' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700' ?>">
            <i data-lucide="clipboard-list" class="w-4 h-4"></i>
            <span>Overtime Claims & Approvals</span>
            <span class="px-1.5 py-0.2 rounded-full text-[10px] <?= ($curTab === 'requests') ? 'bg-indigo-700 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300' ?>">
                <?= count($requests) ?>
            </span>
        </a>

        <?php if ($canManageOvertime): ?>
        <a href="<?= base_url('rules?domain=OVERTIME') ?>" 
           class="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 hover:bg-purple-100 dark:hover:bg-purple-900/60 border border-purple-200 dark:border-purple-800">
            <i data-lucide="scale" class="w-4 h-4 text-purple-600"></i>
            <span>Policy Rules (Rule Engine)</span>
            <span class="px-1.5 py-0.2 rounded-full text-[10px] bg-purple-200/60 dark:bg-purple-800 text-purple-700 dark:text-purple-200 font-mono">SSOT</span>
        </a>
        <?php endif; ?>

        <a href="<?= base_url('attendance/overtime?tab=employee-rates') ?>" 
           class="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap <?= ($curTab === 'employee-rates') ? 'bg-indigo-600 text-white shadow-xs' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700' ?>">
            <i data-lucide="users" class="w-4 h-4"></i>
            <span>Employee Rates & Simulator</span>
            <span class="px-1.5 py-0.2 rounded-full text-[10px] <?= ($curTab === 'employee-rates') ? 'bg-indigo-700 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300' ?>">
                <?= count($employeeRatesMatrix ?? []) ?>
            </span>
        </a>

        <a href="<?= base_url('attendance/overtime?tab=analytics') ?>" 
           class="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap <?= ($curTab === 'analytics') ? 'bg-indigo-600 text-white shadow-xs' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700' ?>">
            <i data-lucide="bar-chart-3" class="w-4 h-4"></i>
            <span>Analytics & Fatigue Intelligence</span>
            <?php if (!empty($analytics['fatigue_alerts'])): ?>
            <span class="px-1.5 py-0.2 rounded-full text-[10px] bg-rose-600 text-white font-bold animate-pulse">
                <?= count($analytics['fatigue_alerts']) ?> Alert
            </span>
            <?php endif; ?>
        </a>

        <?php if ($canManageOvertime): ?>
        <a href="<?= base_url('attendance/overtime?tab=settlement-locks') ?>" 
           class="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap <?= ($curTab === 'settlement-locks') ? 'bg-indigo-600 text-white shadow-xs' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700' ?>">
            <i data-lucide="shield-check" class="w-4 h-4"></i>
            <span>Settlement Locks & Idempotency</span>
            <span class="px-1.5 py-0.2 rounded-full text-[10px] <?= ($curTab === 'settlement-locks') ? 'bg-indigo-700 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300' ?>">
                <?= count($settlementLocks ?? []) ?>
            </span>
        </a>
        <?php endif; ?>
    </div>

    <!-- TAB CONTENT 1: OVERTIME CLAIMS & APPROVALS -->
    <?php if ($curTab === 'requests'): ?>
        <!-- KPI Metrics Grid -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <!-- 1. Total Approved OT Hours -->
            <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-100 dark:border-slate-700/80 shadow-xs flex items-center gap-3.5">
                <div class="w-11 h-11 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
                    <i data-lucide="clock" class="w-5 h-5"></i>
                </div>
                <div>
                    <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Approved OT</div>
                    <div class="text-xl font-black text-slate-900 dark:text-white font-mono"><?= number_format((float)$stats['total_hours'], 1) ?> hrs</div>
                    <div class="text-[10px] text-indigo-500 font-semibold mt-0.5"><?= $stats['approved_count'] ?> claims approved</div>
                </div>
            </div>

            <!-- 2. Estimated Payout -->
            <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-100 dark:border-slate-700/80 shadow-xs flex items-center gap-3.5">
                <div class="w-11 h-11 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                    <i data-lucide="banknote" class="w-5 h-5"></i>
                </div>
                <div>
                    <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Approved OT Payout</div>
                    <div class="text-xl font-black text-emerald-600 dark:text-emerald-400 font-mono">BDT <?= number_format((float)$stats['total_approved_amount'], 2) ?></div>
                    <div class="text-[10px] text-slate-400 mt-0.5">Pending: BDT <?= number_format((float)$stats['total_pending_amount'], 2) ?></div>
                </div>
            </div>

            <!-- 3. Pending Approvals -->
            <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-100 dark:border-slate-700/80 shadow-xs flex items-center gap-3.5">
                <div class="w-11 h-11 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                    <i data-lucide="clock-4" class="w-5 h-5"></i>
                </div>
                <div>
                    <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Pending Approvals</div>
                    <div class="text-xl font-black text-amber-600 dark:text-amber-400 font-mono"><?= $stats['pending_count'] ?></div>
                    <div class="text-[10px] text-slate-400 mt-0.5"><?= $stats['rejected_count'] ?> claims rejected</div>
                </div>
            </div>

            <!-- 4. Active Formulation & Capture -->
            <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-100 dark:border-slate-700/80 shadow-xs flex items-center gap-3.5">
                <div class="w-11 h-11 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0">
                    <i data-lucide="shield-check" class="w-5 h-5"></i>
                </div>
                <div>
                    <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Capture & Policy Mode</div>
                    <div class="text-xs font-black text-purple-700 dark:text-purple-300 capitalize"><?= str_replace('_', ' ', $rulesData['captureMode']) ?></div>
                    <div class="text-[10px] text-slate-400 mt-0.5 font-mono">1.5x Normal &bull; 2.0x Off-Day</div>
                </div>
            </div>
        </div>

        <!-- Overtime Requests List & Controls Card -->
        <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700/80 shadow-xs overflow-hidden">
            <!-- Filter & Search Bar -->
            <div class="p-4 border-b border-slate-100 dark:border-slate-700/60 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                <!-- Status Tabs -->
                <div class="flex items-center gap-1 overflow-x-auto pb-1 md:pb-0">
                    <a href="<?= base_url('attendance/overtime?' . http_build_query(array_merge($filters, ['tab' => 'requests', 'status' => 'all']))) ?>"
                       class="px-3 py-1.5 rounded-lg text-xs font-semibold transition shrink-0 <?= ($activeStatus === 'all' || $activeStatus === '') ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700' ?>">
                        All Claims
                        <span class="ml-1 px-1.5 py-0.2 rounded-full text-[10px] <?= ($activeStatus === 'all' || $activeStatus === '') ? 'bg-indigo-700 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300' ?>"><?= count($requests) ?></span>
                    </a>
                    <a href="<?= base_url('attendance/overtime?' . http_build_query(array_merge($filters, ['tab' => 'requests', 'status' => 'Pending']))) ?>"
                       class="px-3 py-1.5 rounded-lg text-xs font-semibold transition shrink-0 <?= ($activeStatus === 'Pending') ? 'bg-amber-500 text-white shadow-xs' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700' ?>">
                        Pending
                        <?php if (($stats['pending_count'] ?? 0) > 0): ?>
                        <span class="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-amber-600 text-white"><?= $stats['pending_count'] ?></span>
                        <?php endif; ?>
                    </a>
                    <a href="<?= base_url('attendance/overtime?' . http_build_query(array_merge($filters, ['tab' => 'requests', 'status' => 'Approved']))) ?>"
                       class="px-3 py-1.5 rounded-lg text-xs font-semibold transition shrink-0 <?= ($activeStatus === 'Approved') ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700' ?>">
                        Approved
                    </a>
                    <a href="<?= base_url('attendance/overtime?' . http_build_query(array_merge($filters, ['tab' => 'requests', 'status' => 'Rejected']))) ?>"
                       class="px-3 py-1.5 rounded-lg text-xs font-semibold transition shrink-0 <?= ($activeStatus === 'Rejected') ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700' ?>">
                        Rejected
                    </a>
                </div>

                <!-- Search and Department Filter -->
                <form method="GET" action="<?= base_url('attendance/overtime') ?>" class="flex flex-wrap items-center gap-2">
                    <input type="hidden" name="tab" value="requests">
                    <input type="hidden" name="status" value="<?= esc($activeStatus) ?>">

                    <div class="relative min-w-[200px]">
                        <i data-lucide="search" class="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400"></i>
                        <input type="text" 
                               name="search" 
                               value="<?= esc($filters['search'] ?? '') ?>" 
                               placeholder="Search employee, ID, task..." 
                               class="w-full pl-8 pr-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500">
                    </div>

                    <select name="department_id" onchange="this.form.submit()" class="px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:outline-none">
                        <option value="">All Departments</option>
                        <?php foreach ($departments ?? [] as $dept): ?>
                            <option value="<?= esc($dept['id']) ?>" <?= ($filters['department_id'] ?? '') === $dept['id'] ? 'selected' : '' ?>>
                                <?= esc($dept['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <button type="submit" class="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-semibold transition">
                        Filter
                    </button>

                    <?php if (!empty($filters['search']) || !empty($filters['department_id']) || $activeStatus !== 'all'): ?>
                    <a href="<?= base_url('attendance/overtime?tab=requests') ?>" class="px-2.5 py-1.5 text-xs text-rose-500 hover:underline">
                        Clear
                    </a>
                    <?php endif; ?>
                </form>
            </div>

            <!-- Batch Action Bar (Shown when items selected) -->
            <?php if ($canApproveOvertime): ?>
            <div id="batchActionBar" class="hidden px-4 py-2.5 bg-indigo-50 dark:bg-indigo-950/40 border-b border-indigo-100 dark:border-indigo-900/50 flex items-center justify-between transition-all">
                <div class="flex items-center gap-2">
                    <span class="text-xs font-bold text-indigo-900 dark:text-indigo-200">
                        <span id="selectedCount">0</span> claims selected
                    </span>
                </div>
                <div class="flex items-center gap-2">
                    <button type="button" onclick="executeBatchApprove()" class="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-xs transition">
                        <i data-lucide="check" class="w-3.5 h-3.5"></i> Approve Selected
                    </button>
                    <button type="button" onclick="openBatchRejectModal()" class="inline-flex items-center gap-1.5 px-3 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold shadow-xs transition">
                        <i data-lucide="x" class="w-3.5 h-3.5"></i> Reject Selected
                    </button>
                </div>
            </div>
            <?php endif; ?>

            <!-- Overtime Claims Table -->
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse text-xs">
                    <thead>
                        <tr class="bg-slate-50/75 dark:bg-slate-900/50 border-b border-slate-100 dark:border-slate-700/60 text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider">
                            <?php if ($canApproveOvertime): ?>
                            <th class="px-4 py-3.5 w-8">
                                <input type="checkbox" id="selectAllCheckbox" onchange="toggleSelectAll(this)" class="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500">
                            </th>
                            <?php endif; ?>
                            <th class="px-5 py-3.5">OT ID & Date</th>
                            <th class="px-5 py-3.5">Employee</th>
                            <th class="px-5 py-3.5 text-center">Hours</th>
                            <th class="px-5 py-3.5">Rate / Multiplier</th>
                            <th class="px-5 py-3.5 text-right">Est. Total Amount</th>
                            <th class="px-5 py-3.5">Task Description / Purpose</th>
                            <th class="px-5 py-3.5 text-center">Status</th>
                            <?php if ($canApproveOvertime): ?>
                            <th class="px-5 py-3.5 text-right">Actions</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-700/50">
                        <?php if (empty($requests)): ?>
                            <tr>
                                <td colspan="<?= ($canApproveOvertime) ? 9 : 8 ?>" class="px-6 py-12 text-center text-slate-400">
                                    <div class="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center mx-auto mb-2">
                                        <i data-lucide="clock" class="w-6 h-6"></i>
                                    </div>
                                    <p class="font-bold text-slate-700 dark:text-slate-300 text-sm">No overtime records found</p>
                                    <p class="text-xs text-slate-400 mt-0.5">There are no overtime claims matching your current filter criteria.</p>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($requests as $req): 
                                $avatarUrl = !empty($req['employee_avatar']) ? $req['employee_avatar'] : 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&auto=format&fit=crop&q=80';
                                $hasMeal = ((float)$req['hours'] >= ($rulesData['mealAllowanceThreshold'] ?? 2.5));
                            ?>
                                <tr class="hover:bg-slate-50/60 dark:hover:bg-slate-750/30 transition">
                                    <!-- Checkbox for batch actions -->
                                    <?php if ($canApproveOvertime): ?>
                                    <td class="px-4 py-3.5">
                                        <?php if ($req['status'] === 'Pending'): ?>
                                        <input type="checkbox" value="<?= esc($req['id']) ?>" class="claim-checkbox rounded border-slate-300 text-indigo-600 focus:ring-indigo-500" onchange="updateSelectedCount()">
                                        <?php endif; ?>
                                    </td>
                                    <?php endif; ?>

                                    <!-- ID & Date -->
                                    <td class="px-5 py-3.5">
                                        <span class="font-mono font-bold text-indigo-600 dark:text-indigo-400">#<?= esc($req['id']) ?></span>
                                        <div class="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 flex items-center gap-1">
                                            <i data-lucide="calendar" class="w-3 h-3 text-slate-400"></i>
                                            <?= date('M d, Y', strtotime($req['overtime_date'])) ?>
                                        </div>
                                    </td>

                                    <!-- Employee -->
                                    <td class="px-5 py-3.5">
                                        <div class="flex items-center gap-2.5">
                                            <img src="<?= esc($avatarUrl) ?>" 
                                                 alt="<?= esc($req['employee_name'] ?? 'Staff') ?>" 
                                                 class="w-8 h-8 rounded-full object-cover shrink-0 border border-slate-200 dark:border-slate-700" 
                                                 referrerpolicy="no-referrer"
                                                 onerror="this.src='https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&auto=format&fit=crop&q=80'">
                                            <div class="min-w-0">
                                                <div class="font-bold text-slate-800 dark:text-slate-100 truncate"><?= esc($req['employee_name'] ?? 'Employee') ?></div>
                                                <div class="text-[11px] text-slate-400 truncate">
                                                    <?= esc($req['employee_code'] ?? '') ?> &bull; <?= esc($req['designation_name'] ?? $req['department_name'] ?? 'General') ?>
                                                </div>
                                            </div>
                                        </div>
                                    </td>

                                    <!-- Hours & Allowance Indicators -->
                                    <td class="px-5 py-3.5 text-center">
                                        <div class="inline-flex flex-col items-center">
                                            <?php 
                                                $reqHrs = (float)($req['hours'] ?? 0);
                                                $reqMins = !empty($req['payable_total_minutes']) ? (int)$req['payable_total_minutes'] : (int)round($reqHrs * 60);
                                            ?>
                                            <span class="font-mono text-xs font-black text-slate-800 dark:text-slate-100 px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700/60">
                                                <?= number_format($reqHrs, 2) ?> hrs
                                            </span>
                                            <span class="text-[10px] text-slate-500 dark:text-slate-400 font-mono mt-0.5"><?= $reqMins ?> mins</span>
                                            <?php if ($hasMeal): ?>
                                            <span class="text-[9px] font-bold text-amber-600 dark:text-amber-400 mt-0.5 flex items-center gap-0.5">
                                                <i data-lucide="utensils" class="w-2.5 h-2.5"></i> +Meal
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </td>

                                    <!-- Rate / Multiplier -->
                                    <td class="px-5 py-3.5">
                                        <div class="flex flex-col gap-0.5">
                                            <span class="inline-flex items-center gap-1 text-[11px] font-bold text-slate-700 dark:text-slate-300">
                                                <?= esc($req['overtime_type'] ?? 'Normal') ?> 
                                                <span class="text-indigo-600 font-mono">(<?= esc($req['rate_multiplier'] ?? '1.5') ?>x)</span>
                                            </span>
                                        </div>
                                    </td>

                                    <!-- Total Amount -->
                                    <td class="px-5 py-3.5 text-right">
                                        <span class="font-mono text-xs font-black text-emerald-600 dark:text-emerald-400">
                                            BDT <?= number_format((float)($req['calculated_amount'] ?? 0), 2) ?>
                                        </span>
                                    </td>

                                    <!-- Purpose / Reason -->
                                    <td class="px-5 py-3.5 max-w-xs">
                                        <p class="truncate text-slate-600 dark:text-slate-300 text-xs" title="<?= esc($req['reason']) ?>">
                                            <?= esc($req['reason'] ?: 'Shift extension / Post-release verification') ?>
                                        </p>
                                        <?php if (!empty($req['rejection_reason'])): ?>
                                            <p class="text-[10px] text-rose-500 font-semibold mt-0.5 truncate" title="Rejection Reason: <?= esc($req['rejection_reason']) ?>">
                                                Reason: <?= esc($req['rejection_reason']) ?>
                                            </p>
                                        <?php endif; ?>
                                    </td>

                                    <!-- Status Badge -->
                                    <td class="px-5 py-3.5 text-center">
                                        <?php if ($req['status'] === 'Approved'): ?>
                                            <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/40">
                                                <i data-lucide="check" class="w-3 h-3"></i> Approved
                                            </span>
                                            <?php if (!empty($req['approver_name'])): ?>
                                                <div class="text-[9px] text-slate-400 mt-0.5">by <?= esc($req['approver_name']) ?></div>
                                            <?php endif; ?>
                                        <?php elseif ($req['status'] === 'Rejected'): ?>
                                            <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800/40">
                                                <i data-lucide="x" class="w-3 h-3"></i> Rejected
                                            </span>
                                        <?php else: ?>
                                            <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800/40">
                                                <i data-lucide="clock" class="w-3 h-3"></i> Pending
                                            </span>
                                        <?php endif; ?>
                                    </td>

                                    <!-- Actions -->
                                    <?php if ($canApproveOvertime): ?>
                                    <td class="px-5 py-3.5 text-right">
                                        <?php if ($req['status'] === 'Pending' && $canApproveOvertime): ?>
                                            <div class="flex items-center justify-end gap-1.5">
                                                <form method="POST" action="<?= base_url('attendance/overtime/approve/' . $req['id']) ?>" onsubmit="return confirm('Approve overtime claim #<?= esc($req['id']) ?> for <?= esc($req['employee_name']) ?>?');">
                                                    <?= csrf_field() ?>
                                                    <button type="submit" 
                                                            class="p-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 dark:bg-emerald-950/50 dark:hover:bg-emerald-900/60 dark:text-emerald-300 transition" 
                                                            title="Approve Claim">
                                                        <i data-lucide="check" class="w-4 h-4"></i>
                                                    </button>
                                                </form>
                                                
                                                <button type="button" 
                                                        onclick="openRejectModal('<?= esc($req['id']) ?>', '<?= esc(addslashes($req['employee_name'] ?? 'Employee')) ?>')" 
                                                        class="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 dark:bg-rose-950/50 dark:hover:bg-rose-900/60 dark:text-rose-300 transition" 
                                                        title="Reject Claim">
                                                    <i data-lucide="x" class="w-4 h-4"></i>
                                                </button>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-[10px] text-slate-400 font-semibold">Processed</span>
                                        <?php endif; ?>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Attendance Hardware Auto-Calculated Overtime Cross-Reference -->
        <?php if (!empty($attendanceSummary)): ?>
        <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700/80 p-5 shadow-xs space-y-4">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                <div>
                    <h3 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                        <i data-lucide="fingerprint" class="w-4 h-4 text-teal-600"></i>
                        Biometric & Geofence Shift Overtime Summary
                    </h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Aggregated overtime hours registered directly through biometric time-clock punches and muster logs.</p>
                </div>
                <span class="text-xs text-teal-600 dark:text-teal-400 font-semibold bg-teal-50 dark:bg-teal-950/40 px-2.5 py-1 rounded-lg">
                    <?= count($attendanceSummary) ?> Staff with Registered OT
                </span>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                <?php foreach ($attendanceSummary as $att): 
                    $attAvatar = !empty($att['employee_avatar']) ? $att['employee_avatar'] : 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&auto=format&fit=crop&q=80';
                ?>
                    <div class="p-3 rounded-xl border border-slate-100 dark:border-slate-700/70 bg-slate-50/50 dark:bg-slate-900/30 flex items-center justify-between">
                        <div class="flex items-center gap-2.5 min-w-0">
                            <img src="<?= esc($attAvatar) ?>" 
                                 alt="<?= esc($att['employee_name'] ?? 'Staff') ?>" 
                                 class="w-7 h-7 rounded-full object-cover shrink-0" 
                                 referrerpolicy="no-referrer"
                                 onerror="this.src='https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&auto=format&fit=crop&q=80'">
                            <div class="min-w-0">
                                <p class="text-xs font-bold text-slate-800 dark:text-slate-100 truncate"><?= esc($att['employee_name'] ?? 'Staff') ?></p>
                                <p class="text-[10px] text-slate-400 truncate"><?= esc($att['employee_code']) ?> &bull; <?= esc($att['days_with_ot']) ?> shift days</p>
                            </div>
                        </div>
                        <div class="text-right shrink-0">
                            <span class="font-mono text-xs font-black text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/50 px-2 py-0.5 rounded-md">
                                <?= number_format((float)$att['total_ot_hours'], 1) ?> hrs
                            </span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

    <!-- TAB CONTENT 2: EMPLOYEE SALARY OT RATES & LIVE SIMULATOR -->
    <?php elseif ($curTab === 'employee-rates'): ?>
        <div class="space-y-6">
            <!-- Simulator Control Bar -->
            <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700/80 p-5 shadow-xs space-y-4">
                <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
                    <div>
                        <h3 class="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                            <i data-lucide="sliders" class="w-4 h-4 text-indigo-600"></i>
                            Dynamic Rate Divisor Simulator
                        </h3>
                        <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Test how adjusting divisor parameters affects base hourly rates across all active personnel in real-time.</p>
                    </div>
                    
                    <form method="GET" action="<?= base_url('attendance/overtime') ?>" class="flex flex-wrap items-center gap-2.5">
                        <input type="hidden" name="tab" value="employee-rates">

                        <div class="flex items-center gap-1.5 bg-slate-50 dark:bg-slate-900 px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700">
                            <span class="text-[11px] font-bold text-slate-400">Basis:</span>
                            <select name="sim_salary_basis" onchange="this.form.submit()" class="bg-transparent text-xs font-bold text-slate-800 dark:text-slate-200 focus:outline-none">
                                <option value="Basic Salary" <?= ($simBasis === 'Basic Salary') ? 'selected' : '' ?>>Basic</option>
                                <option value="Gross Salary" <?= ($simBasis === 'Gross Salary') ? 'selected' : '' ?>>Gross</option>
                            </select>
                        </div>

                        <div class="flex items-center gap-1.5 bg-slate-50 dark:bg-slate-900 px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700">
                            <span class="text-[11px] font-bold text-slate-400">Days:</span>
                            <input type="number" name="sim_days" value="<?= esc($simDays) ?>" class="w-12 bg-transparent text-xs font-mono font-bold text-slate-800 dark:text-slate-200 focus:outline-none" onchange="this.form.submit()">
                        </div>

                        <div class="flex items-center gap-1.5 bg-slate-50 dark:bg-slate-900 px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700">
                            <span class="text-[11px] font-bold text-slate-400">Hours:</span>
                            <input type="number" name="sim_hours" value="<?= esc($simHours) ?>" class="w-10 bg-transparent text-xs font-mono font-bold text-slate-800 dark:text-slate-200 focus:outline-none" onchange="this.form.submit()">
                        </div>

                        <button type="submit" class="px-3 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-bold shadow-xs hover:bg-indigo-700 transition">
                            Apply Simulator
                        </button>
                    </form>
                </div>
            </div>

            <!-- Employee Rates Matrix Table -->
            <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700/80 shadow-xs overflow-hidden">
                <div class="p-4 border-b border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
                    <div>
                        <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Employee Overtime Rate Matrix</h4>
                        <p class="text-[11px] text-slate-400 mt-0.5">Computed dynamically using <code class="font-mono font-bold text-indigo-600"><?= esc($simBasis) ?> &divide; <?= esc($simDays) ?>d &divide; <?= esc($simHours) ?>h (= <?= esc($simDays * $simHours) ?> hrs divisor)</code></p>
                    </div>
                    <span class="text-xs font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40 px-2.5 py-1 rounded-lg">
                        <?= count($employeeRatesMatrix) ?> Active Personnel
                    </span>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse text-xs">
                        <thead>
                            <tr class="bg-slate-50/75 dark:bg-slate-900/50 border-b border-slate-100 dark:border-slate-700/60 text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider">
                                <th class="px-5 py-3.5">Employee</th>
                                <th class="px-5 py-3.5">Designation & Dept</th>
                                <th class="px-5 py-3.5 text-right">Salary Basis</th>
                                <th class="px-5 py-3.5 text-right">Base Rate (1.0x)</th>
                                <th class="px-5 py-3.5 text-right">Normal OT (1.5x)</th>
                                <th class="px-5 py-3.5 text-right">Off-Day OT (2.0x)</th>
                                <th class="px-5 py-3.5 text-right">Holiday OT (2.0x)</th>
                                <th class="px-5 py-3.5 text-center">Quick Action</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-slate-700/50">
                            <?php if (empty($employeeRatesMatrix)): ?>
                                <tr>
                                    <td colspan="8" class="px-6 py-8 text-center text-slate-400">No active employees found.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($employeeRatesMatrix as $row): 
                                    $empAvatar = !empty($row['photo']) ? $row['photo'] : 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&auto=format&fit=crop&q=80';
                                ?>
                                    <tr class="hover:bg-slate-50/60 dark:hover:bg-slate-750/30 transition">
                                        <td class="px-5 py-3.5">
                                            <div class="flex items-center gap-2.5">
                                                <img src="<?= esc($empAvatar) ?>" 
                                                     alt="<?= esc($row['name']) ?>" 
                                                     class="w-8 h-8 rounded-full object-cover shrink-0 border border-slate-200 dark:border-slate-700" 
                                                     referrerpolicy="no-referrer"
                                                     onerror="this.src='https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&auto=format&fit=crop&q=80'">
                                                <div>
                                                    <div class="font-bold text-slate-800 dark:text-slate-100"><?= esc($row['name']) ?></div>
                                                    <div class="text-[10px] text-slate-400 font-mono"><?= esc($row['employee_code']) ?></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-5 py-3.5">
                                            <div class="font-semibold text-slate-700 dark:text-slate-300"><?= esc($row['designation_name'] ?? 'Staff') ?></div>
                                            <div class="text-[10px] text-slate-400"><?= esc($row['department_name'] ?? 'General') ?></div>
                                        </td>
                                        <td class="px-5 py-3.5 text-right font-mono font-bold text-slate-700 dark:text-slate-300">
                                            BDT <?= number_format((float)($row['salary_used'] ?? $row['formula_base'] ?? 0), 2) ?>
                                        </td>
                                        <td class="px-5 py-3.5 text-right font-mono font-bold text-slate-800 dark:text-slate-100">
                                            BDT <?= number_format((float)($row['base_rate'] ?? $row['hourly_rate'] ?? 0), 2) ?> /hr
                                        </td>
                                        <td class="px-5 py-3.5 text-right font-mono font-bold text-indigo-600 dark:text-indigo-400">
                                            BDT <?= number_format((float)($row['normal_rate'] ?? $row['normal_ot_rate'] ?? 0), 2) ?> /hr
                                        </td>
                                        <td class="px-5 py-3.5 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400">
                                            BDT <?= number_format((float)($row['off_day_rate'] ?? $row['weekend_ot_rate'] ?? 0), 2) ?> /hr
                                        </td>
                                        <td class="px-5 py-3.5 text-right font-mono font-bold text-purple-600 dark:text-purple-400">
                                            BDT <?= number_format((float)($row['holiday_rate'] ?? $row['holiday_ot_rate'] ?? 0), 2) ?> /hr
                                        </td>
                                        <td class="px-5 py-3.5 text-center">
                                            <button type="button" 
                                                    onclick="quickClaimForEmp('<?= esc($row['id'] ?? $row['employee_id'] ?? '') ?>')" 
                                                    class="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/50 dark:hover:bg-indigo-900/60 text-indigo-600 dark:text-indigo-300 font-bold text-[11px] transition">
                                                Claim OT
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    <!-- TAB CONTENT 4: ANALYTICS & FATIGUE INTELLIGENCE -->
    <?php elseif ($curTab === 'analytics'): ?>
        <div class="space-y-6">
            <!-- Analytics Top Metrics -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-100 dark:border-slate-700/80 shadow-xs">
                    <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Approval Conversion Ratio</div>
                    <div class="text-2xl font-black text-indigo-600 dark:text-indigo-400 font-mono mt-1"><?= esc($analytics['approval_ratio'] ?? 0) ?>%</div>
                    <div class="w-full bg-slate-100 dark:bg-slate-700 h-1.5 rounded-full mt-2 overflow-hidden">
                        <div class="bg-indigo-600 h-full rounded-full" style="width: <?= esc($analytics['approval_ratio'] ?? 0) ?>%"></div>
                    </div>
                </div>

                <div class="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-100 dark:border-slate-700/80 shadow-xs">
                    <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Average OT Shift Duration</div>
                    <div class="text-2xl font-black text-slate-800 dark:text-slate-100 font-mono mt-1"><?= esc($analytics['avg_duration'] ?? 0) ?> hrs</div>
                    <div class="text-[10px] text-emerald-500 font-semibold mt-1">Within daily 4.0h safety cap</div>
                </div>

                <div class="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-100 dark:border-slate-700/80 shadow-xs">
                    <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Labor Law Compliance</div>
                    <div class="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1"><?= esc($analytics['labor_law_compliance']['status'] ?? 'Compliant') ?></div>
                    <div class="text-[10px] text-slate-400 mt-1">Weekly Cap: <?= esc($analytics['labor_law_compliance']['standard_hours_cap'] ?? 16) ?>h</div>
                </div>

                <div class="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-100 dark:border-slate-700/80 shadow-xs">
                    <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Disbursable OT</div>
                    <div class="text-2xl font-black text-slate-900 dark:text-white font-mono mt-1">BDT <?= number_format((float)($analytics['total_approved_amount'] ?? 0), 2) ?></div>
                    <div class="text-[10px] text-indigo-500 font-semibold mt-1"><?= number_format((float)($analytics['total_approved_hours'] ?? 0), 1) ?> verified extra hours</div>
                </div>
            </div>

            <!-- Department Breakdown & Top Claimants -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <!-- Department Distribution -->
                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700/80 p-5 shadow-xs space-y-4">
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                        <i data-lucide="pie-chart" class="w-4 h-4 text-indigo-600"></i> Department Overtime Expenditure
                    </h3>
                    <div class="space-y-3">
                        <?php if (empty($analytics['department_breakdown'])): ?>
                            <p class="text-xs text-slate-400 text-center py-6">No overtime records logged yet.</p>
                        <?php else: ?>
                            <?php foreach ($analytics['department_breakdown'] as $deptRow): ?>
                                <div class="p-3 rounded-xl border border-slate-100 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-900/30">
                                    <div class="flex items-center justify-between text-xs mb-1.5">
                                        <span class="font-bold text-slate-800 dark:text-slate-100"><?= esc($deptRow['department']) ?></span>
                                        <span class="font-mono font-bold text-indigo-600 dark:text-indigo-400">BDT <?= number_format((float)$deptRow['amount'], 2) ?></span>
                                    </div>
                                    <div class="flex items-center justify-between text-[10px] text-slate-400">
                                        <span><?= number_format((float)$deptRow['hours'], 1) ?> hours</span>
                                        <span><?= esc($deptRow['claims_count']) ?> claims submitted</span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Top Overtime Claimants -->
                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700/80 p-5 shadow-xs space-y-4">
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                        <i data-lucide="award" class="w-4 h-4 text-amber-500"></i> Top Overtime Claimants
                    </h3>
                    <div class="space-y-3">
                        <?php if (empty($analytics['top_claimants'])): ?>
                            <p class="text-xs text-slate-400 text-center py-6">No approved claimant data.</p>
                        <?php else: ?>
                            <?php foreach ($analytics['top_claimants'] as $c): ?>
                                <div class="flex items-center justify-between p-3 rounded-xl border border-slate-100 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-900/30">
                                    <div class="min-w-0">
                                        <div class="font-bold text-xs text-slate-800 dark:text-slate-100 truncate"><?= esc($c['name']) ?></div>
                                        <div class="text-[10px] text-slate-400"><?= esc($c['code']) ?> &bull; <?= esc($c['department']) ?></div>
                                    </div>
                                    <div class="text-right shrink-0">
                                        <div class="font-mono text-xs font-black text-emerald-600 dark:text-emerald-400">BDT <?= number_format((float)$c['amount'], 2) ?></div>
                                        <div class="text-[10px] text-slate-400 font-mono"><?= number_format((float)$c['hours'], 1) ?> hrs &bull; <?= $c['approved_claims'] ?> claims</div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Fatigue Alert Log -->
            <?php if (!empty($analytics['fatigue_alerts'])): ?>
            <div class="bg-rose-50 dark:bg-rose-950/30 rounded-2xl border border-rose-200 dark:border-rose-900/50 p-5 shadow-xs space-y-3">
                <h3 class="text-sm font-bold text-rose-800 dark:text-rose-300 flex items-center gap-2">
                    <i data-lucide="alert-triangle" class="w-4 h-4 text-rose-600"></i>
                    Fatigue Safety Threshold Alerts
                </h3>
                <p class="text-xs text-rose-700 dark:text-rose-400">The following overtime shifts exceed statutory or policy safety guidelines for daily extra work:</p>
                
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-1">
                    <?php foreach ($analytics['fatigue_alerts'] as $alert): ?>
                        <div class="p-3 rounded-xl bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-800/60 shadow-xs">
                            <div class="flex items-center justify-between text-xs font-bold text-slate-800 dark:text-slate-100 mb-1">
                                <span><?= esc($alert['employee_name']) ?></span>
                                <span class="font-mono text-rose-600 font-black"><?= esc($alert['hours']) ?> hrs</span>
                            </div>
                            <p class="text-[11px] text-rose-500 font-semibold"><?= esc($alert['reason']) ?></p>
                            <p class="text-[10px] text-slate-400 mt-1">Claim #<?= esc($alert['claim_id']) ?> &bull; Date: <?= esc($alert['date']) ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <!-- TAB CONTENT 5: SETTLEMENT LOCKS & IDEMPOTENCY -->
    <?php if ($curTab === 'settlement-locks'): ?>
        <div class="space-y-6">
            <!-- Header Card -->
            <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700/80 p-5 shadow-xs">
                <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div class="space-y-1">
                        <div class="flex items-center gap-2">
                            <span class="p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
                                <i data-lucide="shield-check" class="w-4 h-4"></i>
                            </span>
                            <h3 class="text-sm font-bold text-slate-800 dark:text-slate-100">Deterministic Overtime Hash-Locks (Idempotency Ledger)</h3>
                            <span class="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300">
                                OT-HASH Engine Active
                            </span>
                        </div>
                        <p class="text-xs text-slate-500 dark:text-slate-400 max-w-2xl">
                            Prevents double-counting between daily and weekly overtime thresholds. Each overtime settlement generates a deterministic hash (<code class="font-mono text-indigo-600 dark:text-indigo-400">OT-HASH-{emp}-{range}-{hash}</code>) immutably locking the pay item against future payroll cycles.
                        </p>
                    </div>
                </div>

                <!-- Metric Cards -->
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-5 pt-5 border-t border-slate-100 dark:border-slate-700/60">
                    <?php
                        $totalLockHours = array_sum(array_column($settlementLocks ?? [], 'ot_hours'));
                        $totalLockAmount = array_sum(array_column($settlementLocks ?? [], 'ot_amount'));
                    ?>
                    <div class="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-700/50">
                        <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Active Locks</span>
                        <span class="text-xl font-black text-slate-800 dark:text-white font-mono"><?= count($settlementLocks ?? []) ?></span>
                        <span class="text-[10px] text-emerald-600 font-medium block mt-0.5">Idempotency Enforced</span>
                    </div>
                    <div class="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-700/50">
                        <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Settled Overtime Hours</span>
                        <span class="text-xl font-black text-indigo-600 dark:text-indigo-400 font-mono"><?= number_format($totalLockHours, 2) ?> hrs</span>
                        <span class="text-[10px] text-slate-500 font-medium block mt-0.5">Locked against duplicate pay</span>
                    </div>
                    <div class="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-700/50">
                        <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Disbursed OT Value</span>
                        <span class="text-xl font-black text-emerald-600 dark:text-emerald-400 font-mono">BDT <?= number_format($totalLockAmount, 2) ?></span>
                        <span class="text-[10px] text-slate-500 font-medium block mt-0.5">Protected by deterministic key</span>
                    </div>
                </div>
            </div>

            <!-- Settlement Locks Table -->
            <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700/80 overflow-hidden shadow-xs">
                <div class="p-4 border-b border-slate-100 dark:border-slate-700/80 flex items-center justify-between">
                    <h4 class="text-xs font-bold text-slate-800 dark:text-slate-100">Active Idempotency Hash Locks</h4>
                    <span class="text-[11px] text-slate-400 font-mono"><?= count($settlementLocks ?? []) ?> Records</span>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse text-xs">
                        <thead>
                            <tr class="border-b border-slate-100 dark:border-slate-700/80 bg-slate-50/50 dark:bg-slate-900/30 text-slate-500 dark:text-slate-400">
                                <th class="py-3 px-4 font-semibold">Employee</th>
                                <th class="py-3 px-4 font-semibold">Period / Week</th>
                                <th class="py-3 px-4 font-semibold">OT Type</th>
                                <th class="py-3 px-4 font-semibold text-right">Settled Hours</th>
                                <th class="py-3 px-4 font-semibold text-right">Rate & Multiplier</th>
                                <th class="py-3 px-4 font-semibold text-right">Amount</th>
                                <th class="py-3 px-4 font-semibold">Deterministic Hash Lock</th>
                                <th class="py-3 px-4 font-semibold text-center">Status</th>
                                <th class="py-3 px-4 font-semibold text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-slate-700/60">
                            <?php if (empty($settlementLocks)): ?>
                            <tr>
                                <td colspan="9" class="py-8 text-center text-slate-400">
                                    <div class="flex flex-col items-center justify-center gap-2">
                                        <i data-lucide="shield-check" class="w-8 h-8 text-slate-300 dark:text-slate-600"></i>
                                        <p>No active settlement locks recorded yet.</p>
                                        <span class="text-[11px] text-slate-400">Locks are created automatically when payroll batches containing weekly excess OT are generated.</span>
                                    </div>
                                </td>
                            </tr>
                            <?php else: ?>
                                <?php foreach ($settlementLocks as $lock): ?>
                                <tr class="hover:bg-slate-50/60 dark:hover:bg-slate-900/30 transition">
                                    <td class="py-3 px-4">
                                        <div class="font-bold text-slate-900 dark:text-white">
                                            <?= esc(($lock['first_name'] ?? '') . ' ' . ($lock['last_name'] ?? '')) ?: (!empty($lock['employee_id']) ? esc($lock['employee_id']) : (!empty($lock['company_id']) ? 'Company Wide Lock' : 'Settlement Lock')) ?>
                                        </div>
                                        <div class="text-[10px] text-slate-400 font-mono"><?= esc($lock['emp_code'] ?? $lock['employee_id'] ?? $lock['id'] ?? '-') ?></div>
                                    </td>
                                    <td class="py-3 px-4 font-mono text-[11px]">
                                        <div class="text-slate-800 dark:text-slate-200 font-semibold"><?= esc($lock['period_month'] ?? $lock['payroll_month'] ?? '-') ?></div>
                                        <div class="text-slate-400 text-[10px]">
                                            <?= esc($lock['week_identifier'] ?? (!empty($lock['payroll_id']) ? 'Payroll: ' . substr($lock['payroll_id'], 0, 10) : '')) ?> 
                                            <?php if (!empty($lock['week_start'])): ?>
                                                (<?= esc($lock['week_start']) ?> to <?= esc($lock['week_end']) ?>)
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td class="py-3 px-4">
                                        <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300 font-mono">
                                            <?= esc($lock['ot_type'] ?? 'Monthly Settlement') ?>
                                        </span>
                                    </td>
                                    <td class="py-3 px-4 text-right font-mono font-bold text-indigo-600 dark:text-indigo-400">
                                        <?= number_format((float)($lock['ot_hours'] ?? $lock['total_hours'] ?? 0), 2) ?> hrs
                                    </td>
                                    <td class="py-3 px-4 text-right font-mono text-[11px] text-slate-600 dark:text-slate-300">
                                        <?= number_format((float)($lock['hourly_rate'] ?? 0), 2) ?> &times; <?= number_format((float)($lock['multiplier'] ?? 1), 2) ?>x
                                    </td>
                                    <td class="py-3 px-4 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400">
                                        BDT <?= number_format((float)($lock['ot_amount'] ?? $lock['total_amount'] ?? 0), 2) ?>
                                    </td>
                                    <td class="py-3 px-4">
                                        <code class="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono text-[10px] text-slate-700 dark:text-slate-300 select-all" title="<?= esc($lock['lock_hash'] ?? '') ?>">
                                            <?= esc(substr($lock['lock_hash'] ?? '', 0, 32)) ?>...
                                        </code>
                                    </td>
                                    <td class="py-3 px-4 text-center">
                                        <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400">
                                            <?= esc($lock['status'] ?? 'SETTLED') ?>
                                        </span>
                                    </td>
                                    <td class="py-3 px-4 text-center">
                                        <?php if ($canManageOvertime): ?>
                                        <form method="POST" action="<?= base_url('attendance/overtime/release-lock/' . $lock['id']) ?>" onsubmit="return confirm('Release this overtime settlement lock? The hours will be re-eligible for settlement in future payroll runs.');" class="inline">
                                            <?= csrf_field() ?>
                                            <button type="submit" class="px-2 py-1 rounded-lg text-[10px] font-bold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition">
                                                Release
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- MODAL 1: Submit New Overtime Request -->
<div id="requestModal" class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 hidden">
    <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-700 transition-all">
        <div class="px-6 py-4 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between bg-slate-50/60 dark:bg-slate-900/50">
            <h3 class="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <i data-lucide="clock" class="w-4 h-4 text-indigo-600"></i> Submit Overtime Claim
            </h3>
            <button onclick="closeModal('requestModal')" class="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                <i data-lucide="x" class="w-4 h-4"></i>
            </button>
        </div>

        <form method="POST" action="<?= base_url('attendance/overtime/request') ?>" class="p-6 space-y-4" id="otRequestForm">
            <?= csrf_field() ?>

            <!-- Select Employee -->
            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Select Employee</label>
                <select name="employee_id" id="req_employee_id" required onchange="calculateLiveEstimate()" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-semibold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500">
                    <?php foreach ($employees ?? [] as $emp): ?>
                        <option value="<?= esc($emp['id']) ?>">
                            <?= esc($emp['first_name'] . ' ' . $emp['last_name']) ?> (<?= esc($emp['employee_code']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Date & Hours -->
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Overtime Date</label>
                    <input type="date" 
                           name="overtime_date" 
                           required 
                           value="<?= date('Y-m-d') ?>" 
                           class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500">
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Hours Worked</label>
                    <input type="number" 
                           step="0.5" 
                           min="0.5" 
                           max="24" 
                           name="hours" 
                           id="req_hours" 
                           value="2.0" 
                           required 
                           oninput="calculateLiveEstimate()" 
                           class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-mono font-bold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500">
                </div>
            </div>

            <!-- Overtime Type -->
            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Overtime Policy / Multiplier</label>
                <select name="overtime_type" id="req_type" onchange="calculateLiveEstimate()" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-semibold text-slate-800 dark:text-slate-200 focus:outline-none">
                    <option value="Normal">Normal Working Day (1.5x Hourly Rate)</option>
                    <option value="Weekend">Weekend Shift (2.0x Double Rate)</option>
                    <option value="Holiday">Public Holiday (2.0x Premium Rate)</option>
                    <option value="Night Shift">Night Shift Differential (1.5x Rate)</option>
                </select>
            </div>

            <!-- Live Calculation Preview Card -->
            <div class="p-3.5 rounded-xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 flex items-center justify-between">
                <div>
                    <span class="text-[10px] font-bold text-indigo-500 uppercase tracking-wider block">Estimated Payout</span>
                    <span class="text-base font-black text-indigo-700 dark:text-indigo-300 font-mono" id="preview_total_amount">BDT 0.00</span>
                    <div id="preview_allowance_badge" class="hidden text-[10px] font-bold text-amber-600 mt-0.5">
                        <i data-lucide="utensils" class="w-3 h-3 inline"></i> Meal Allowance Triggered (&ge;2.5h)
                    </div>
                </div>
                <div class="text-right">
                    <span class="text-[10px] font-bold text-indigo-500 uppercase tracking-wider block">Hourly Rate Used</span>
                    <span class="text-xs font-bold text-indigo-700 dark:text-indigo-300 font-mono" id="preview_hourly_rate">BDT 0.00 / hr</span>
                    <span class="text-[10px] text-slate-400 block font-mono" id="preview_base_calc"></span>
                </div>
            </div>

            <!-- Reason & Work Description -->
            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Work Description & Justification</label>
                <textarea name="reason" 
                          rows="3" 
                          required 
                          placeholder="e.g. Production Server Deployment & Post-Release Verification" 
                          class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500 resize-none"></textarea>
            </div>

            <!-- Auto-Approve Checkbox (for Admins) -->
            <?php if ($canManageOvertime): ?>
            <div class="flex items-center gap-2 pt-1">
                <input type="checkbox" name="auto_approve" id="auto_approve" value="1" class="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500">
                <label for="auto_approve" class="text-xs text-slate-600 dark:text-slate-300">Immediately mark this claim as Approved (Auto-Approve)</label>
            </div>
            <?php endif; ?>

            <div class="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-700">
                <button type="button" onclick="closeModal('requestModal')" class="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-700 transition">Cancel</button>
                <button type="submit" class="px-4 py-2 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm shadow-indigo-500/20 transition">Submit Overtime</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL 2: Set Designation Overtime Rate -->
<div id="rateModal" class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 hidden">
    <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-700">
        <div class="px-6 py-4 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between bg-slate-50/60 dark:bg-slate-900/50">
            <h3 class="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <i data-lucide="coins" class="w-4 h-4 text-amber-500"></i> Set Designation Rate
            </h3>
            <button onclick="closeModal('rateModal')" class="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                <i data-lucide="x" class="w-4 h-4"></i>
            </button>
        </div>

        <form method="POST" action="<?= base_url('attendance/overtime/rate/save') ?>" class="p-6 space-y-4">
            <?= csrf_field() ?>

            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Designation</label>
                <input type="text" 
                       name="designation_title" 
                       required 
                       placeholder="e.g. Senior Software Engineer" 
                       list="designation_list"
                       class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500">
                
                <datalist id="designation_list">
                    <?php foreach ($designations ?? [] as $dsg): ?>
                        <option value="<?= esc($dsg['name']) ?>"><?= esc($dsg['name']) ?></option>
                    <?php endforeach; ?>
                </datalist>
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Fixed Hourly Rate (BDT)</label>
                <div class="relative">
                    <span class="absolute left-3.5 top-2.5 text-xs font-bold text-slate-400">BDT</span>
                    <input type="number" 
                           step="1" 
                           min="1" 
                           name="hourly_rate" 
                           required 
                           placeholder="350" 
                           class="w-full pl-12 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-mono font-bold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500">
                </div>
                <p class="text-[10px] text-slate-400 mt-1">If set, overrides dynamic basic salary calculation for this role.</p>
            </div>

            <div class="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-700">
                <button type="button" onclick="closeModal('rateModal')" class="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-700 transition">Cancel</button>
                <button type="submit" class="px-4 py-2 rounded-xl text-xs font-bold text-white bg-slate-800 hover:bg-slate-700 dark:bg-slate-700 dark:hover:bg-slate-600 shadow-sm transition">Save Rate</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL 3: Reject Overtime Request -->
<div id="rejectModal" class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 hidden">
    <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-700">
        <div class="px-6 py-4 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between bg-rose-50/60 dark:bg-rose-950/40">
            <h3 class="text-sm font-bold text-rose-800 dark:text-rose-300 flex items-center gap-2">
                <i data-lucide="alert-triangle" class="w-4 h-4 text-rose-600"></i> Reject Overtime Claim
            </h3>
            <button onclick="closeModal('rejectModal')" class="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                <i data-lucide="x" class="w-4 h-4"></i>
            </button>
        </div>

        <form id="rejectForm" method="POST" action="" class="p-6 space-y-4">
            <?= csrf_field() ?>

            <div>
                <p class="text-xs text-slate-600 dark:text-slate-300 mb-2">
                    Please provide the reason for rejecting the overtime claim for <span id="rejectEmpName" class="font-bold text-slate-900 dark:text-white"></span>.
                </p>
                <textarea name="rejection_reason" 
                          id="rejection_reason_input"
                          rows="3" 
                          required 
                          placeholder="e.g. Prior approval was not obtained from department manager before working extra hours." 
                          class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-rose-500 resize-none"></textarea>
            </div>

            <!-- Quick Reason Tags -->
            <div class="flex flex-wrap gap-1.5">
                <button type="button" onclick="setQuickReason('Prior approval was not obtained for extra hours.')" class="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200">Unapproved overtime</button>
                <button type="button" onclick="setQuickReason('Discrepancy with biometric clock-in/out records.')" class="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200">Clock mismatch</button>
                <button type="button" onclick="setQuickReason('Duplicate overtime claim submission.')" class="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200">Duplicate claim</button>
            </div>

            <div class="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-700">
                <button type="button" onclick="closeModal('rejectModal')" class="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-700 transition">Cancel</button>
                <button type="submit" class="px-4 py-2 rounded-xl text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 shadow-sm shadow-rose-500/20 transition">Confirm Rejection</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL 4: Batch Reject Modal -->
<div id="batchRejectModal" class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 hidden">
    <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-700">
        <div class="px-6 py-4 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between bg-rose-50/60 dark:bg-rose-950/40">
            <h3 class="text-sm font-bold text-rose-800 dark:text-rose-300 flex items-center gap-2">
                <i data-lucide="alert-triangle" class="w-4 h-4 text-rose-600"></i> Batch Reject Selected Claims
            </h3>
            <button onclick="closeModal('batchRejectModal')" class="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                <i data-lucide="x" class="w-4 h-4"></i>
            </button>
        </div>

        <form id="batchRejectForm" method="POST" action="<?= base_url('attendance/overtime/batch-reject') ?>" class="p-6 space-y-4">
            <?= csrf_field() ?>
            <input type="hidden" name="claim_ids" id="batch_reject_ids" value="">

            <div>
                <p class="text-xs text-slate-600 dark:text-slate-300 mb-2">
                    Enter the rejection reason for all selected overtime claims:
                </p>
                <textarea name="batch_rejection_reason" 
                          rows="3" 
                          required 
                          placeholder="e.g. Budget ceiling reached / Unapproved extra hours." 
                          class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-rose-500 resize-none"></textarea>
            </div>

            <div class="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-700">
                <button type="button" onclick="closeModal('batchRejectModal')" class="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-700 transition">Cancel</button>
                <button type="submit" class="px-4 py-2 rounded-xl text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 shadow-sm transition">Reject Selected</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal(id) {
    const el = document.getElementById(id);
    if (el) {
        el.classList.remove('hidden');
        if (id === 'requestModal') {
            calculateLiveEstimate();
        }
    }
}

function closeModal(id) {
    const el = document.getElementById(id);
    if (el) {
        el.classList.add('hidden');
    }
}

function openRejectModal(id, empName) {
    const modal = document.getElementById('rejectModal');
    const form = document.getElementById('rejectForm');
    const nameEl = document.getElementById('rejectEmpName');
    
    if (modal && form) {
        form.action = '<?= base_url('attendance/overtime/reject/') ?>/' + id;
        if (nameEl) nameEl.textContent = empName;
        modal.classList.remove('hidden');
    }
}

function setQuickReason(reason) {
    const input = document.getElementById('rejection_reason_input');
    if (input) {
        input.value = reason;
    }
}

function quickClaimForEmp(empId) {
    const select = document.getElementById('req_employee_id');
    if (select) {
        select.value = empId;
    }
    openModal('requestModal');
}

function calculateLiveEstimate() {
    const empId = document.getElementById('req_employee_id')?.value;
    const hours = document.getElementById('req_hours')?.value || 0;
    const type = document.getElementById('req_type')?.value || 'Normal';

    if (!empId) return;

    fetch('<?= base_url('attendance/overtime/calculate') ?>', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({
            employee_id: empId,
            hours: hours,
            overtime_type: type
        })
    })
        .then(res => res.json())
        .then(data => {
            if (data.success && data.data) {
                const totalEl = document.getElementById('preview_total_amount');
                const rateEl = document.getElementById('preview_hourly_rate');
                const baseEl = document.getElementById('preview_base_calc');
                const mealEl = document.getElementById('preview_allowance_badge');

                if (totalEl) totalEl.textContent = `BDT ${Number(data.data.total_amount).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
                if (rateEl) rateEl.textContent = `BDT ${Number(data.data.hourly_rate).toFixed(2)} / hr`;
                if (baseEl) baseEl.textContent = `Base: BDT ${Number(data.data.base_hourly_rate).toFixed(2)} (${data.data.multiplier}x)`;
                
                if (mealEl) {
                    if (data.data.meal_allowance) {
                        mealEl.classList.remove('hidden');
                    } else {
                        mealEl.classList.add('hidden');
                    }
                }
            }
        })
        .catch(err => console.log('Live estimate error:', err));
}

// Rule Engine Live Preview
function setPresetDays(days) {
    const el = document.getElementById('rule_divisor_days');
    if (el) {
        el.value = days;
        updateRulePreview();
    }
}

function setPresetHours(hours) {
    const el = document.getElementById('rule_divisor_hours');
    if (el) {
        el.value = hours;
        updateRulePreview();
    }
}

function updateRulePreview() {
    const days = parseFloat(document.getElementById('rule_divisor_days')?.value) || 30;
    const hours = parseFloat(document.getElementById('rule_divisor_hours')?.value) || 8;
    const totalDivisor = days * hours;
    
    const summaryEl = document.getElementById('sample_divisor_summary');
    if (summaryEl) summaryEl.textContent = `Divisor = ${totalDivisor} Total Monthly Hours`;

    const sampleSalary = 30000;
    const baseRate = sampleSalary / totalDivisor;
    const normalRate = baseRate * 1.5;
    const offdayRate = baseRate * 2.0;

    const baseEl = document.getElementById('sample_base_rate');
    const normEl = document.getElementById('sample_normal_rate');
    const offEl = document.getElementById('sample_offday_rate');

    if (baseEl) baseEl.textContent = `BDT ${baseRate.toFixed(2)} / hr`;
    if (normEl) normEl.textContent = `BDT ${normalRate.toFixed(2)} / hr`;
    if (offEl) offEl.textContent = `BDT ${offdayRate.toFixed(2)} / hr`;
}

// Batch Actions
function toggleSelectAll(master) {
    const checkboxes = document.querySelectorAll('.claim-checkbox');
    checkboxes.forEach(cb => cb.checked = master.checked);
    updateSelectedCount();
}

function updateSelectedCount() {
    const checked = document.querySelectorAll('.claim-checkbox:checked');
    const count = checked.length;
    const bar = document.getElementById('batchActionBar');
    const countEl = document.getElementById('selectedCount');
    
    if (countEl) countEl.textContent = count;
    if (bar) {
        if (count > 0) {
            bar.classList.remove('hidden');
        } else {
            bar.classList.add('hidden');
        }
    }
}

function getSelectedIds() {
    const checked = document.querySelectorAll('.claim-checkbox:checked');
    return Array.from(checked).map(cb => cb.value);
}

function executeBatchApprove() {
    const ids = getSelectedIds();
    if (ids.length === 0) return;

    if (!confirm(`Are you sure you want to approve ${ids.length} selected overtime claim(s)?`)) {
        return;
    }

    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '<?= base_url('attendance/overtime/batch-approve') ?>';

    const csrfInput = document.createElement('input');
    csrfInput.type = 'hidden';
    csrfInput.name = '<?= csrf_token() ?>';
    csrfInput.value = '<?= csrf_hash() ?>';
    form.appendChild(csrfInput);

    const idsInput = document.createElement('input');
    idsInput.type = 'hidden';
    idsInput.name = 'claim_ids';
    idsInput.value = ids.join(',');
    form.appendChild(idsInput);

    document.body.appendChild(form);
    form.submit();
}

function openBatchRejectModal() {
    const ids = getSelectedIds();
    if (ids.length === 0) return;

    const input = document.getElementById('batch_reject_ids');
    if (input) input.value = ids.join(',');
    openModal('batchRejectModal');
}

// Initial calculation on page load
document.addEventListener('DOMContentLoaded', () => {
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    updateRulePreview();
});
</script>
