<!-- TAB: Self Clocking & Biometric Verification Kiosk Simulator -->
<div x-show="activeTab === 'clock'" class="space-y-6 animate-in fade-in duration-200">

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

        <!-- Column 1: ESS Self Clock & Live GPS Haversine Geofence -->
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm space-y-6">
            
            <div class="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
                <div class="flex items-center gap-2">
                    <i data-lucide="clock" class="w-5 h-5 text-indigo-600"></i>
                    <h3 class="font-bold text-slate-800 dark:text-white text-base">Personal ESS Web Clock</h3>
                </div>
                <span class="text-xs font-mono text-slate-400" x-text="liveDateString"></span>
            </div>

            <!-- Digital Clock Display -->
            <div class="text-center py-6 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border border-slate-100 dark:border-slate-800 space-y-2">
                <div class="text-4xl sm:text-5xl font-black font-mono text-slate-900 dark:text-white tracking-tight" x-text="liveDigitalClock"></div>
                <div class="text-xs text-slate-400 font-medium">Standard Bangladesh Standard Time (UTC+6)</div>
            </div>

            <!-- Live GPS Geofence Radar Status -->
            <div class="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-700/60 space-y-3 text-xs">
                <div class="flex items-center justify-between">
                    <span class="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                        <i data-lucide="map-pin" class="w-4 h-4 text-rose-500"></i>
                        GPS Geofence Perimeter Verification
                    </span>
                    <span class="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-bold border border-emerald-200 flex items-center gap-1">
                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                        Within Zone (45m / 200m)
                    </span>
                </div>

                <div class="grid grid-cols-2 gap-2 text-[11px] font-mono text-slate-500">
                    <div>Latitude: <strong class="text-slate-800 dark:text-white" x-text="geoStatus.lat"></strong></div>
                    <div>Longitude: <strong class="text-slate-800 dark:text-white" x-text="geoStatus.lon"></strong></div>
                </div>
            </div>

            <!-- Primary Large Action Button -->
            <div class="space-y-3">
                <template x-if="!isClockedIn">
                    <button @click="doQuickCheckIn()" :disabled="clockLoading" class="w-full py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-sm shadow-lg transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50">
                        <i data-lucide="log-in" class="w-5 h-5"></i>
                        <span x-text="clockLoading ? 'Acquiring GPS Fix & Registering...' : 'Punch In Now (Web Check-In)'"></span>
                    </button>
                </template>

                <template x-if="isClockedIn">
                    <div class="space-y-3">
                        <div class="p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200 dark:border-emerald-800 text-center space-y-1">
                            <span class="text-xs font-bold text-emerald-700 dark:text-emerald-400">Currently Clocked In</span>
                            <div class="text-2xl font-black text-emerald-700 font-mono" x-text="elapsedFormatted"></div>
                            <span class="text-[11px] text-slate-400" x-text="'Checked in at ' + checkInTime"></span>
                        </div>

                        <div class="grid grid-cols-2 gap-3">
                            <button @click="toggleBreak(!isOnBreak)" class="py-3 rounded-2xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-2 cursor-pointer">
                                <i data-lucide="coffee" class="w-4 h-4"></i>
                                <span x-text="isOnBreak ? 'Resume Work' : 'Start Lunch/Break'"></span>
                            </button>

                            <button @click="doQuickCheckOut()" :disabled="clockLoading" class="py-3 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50">
                                <i data-lucide="log-out" class="w-4 h-4"></i>
                                <span>Register Check-Out</span>
                            </button>
                        </div>
                    </div>
                </template>
            </div>

        </div>

        <!-- Column 2: Hardware Biometric Kiosk Simulation Hub -->
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm space-y-6">
            
            <div class="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
                <div class="flex items-center gap-2">
                    <i data-lucide="shield-check" class="w-5 h-5 text-indigo-600"></i>
                    <h3 class="font-bold text-slate-800 dark:text-white text-base">Biometric & RFID Kiosk Terminal</h3>
                </div>
                <span class="px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 text-xs font-bold font-mono">
                    DEV-ZK-01 Online
                </span>
            </div>

            <!-- Employee Selection for Terminal -->
            <div class="space-y-1.5 text-xs">
                <label class="block font-bold text-slate-700 dark:text-slate-300">Simulate Employee Swipe / Scan</label>
                <select x-model="selectedKioskEmp" class="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white font-bold focus:ring-2 focus:ring-indigo-500 outline-hidden">
                    <?php foreach ($employees as $emp): ?>
                        <option value="<?= $emp['id'] ?>">
                            <?= esc($emp['first_name'] . ' ' . $emp['last_name']) ?> (<?= esc($emp['employee_code'] ?? 'EMP') ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- 4 Physical Terminal Interaction Modes -->
            <div class="grid grid-cols-2 gap-3 text-xs">
                
                <!-- 1. Face AI -->
                <button @click="triggerHardwarePunch('face')" class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 hover:bg-indigo-50 hover:border-indigo-200 border border-slate-200 dark:border-slate-700 text-left transition space-y-2 group cursor-pointer">
                    <div class="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition">
                        <i data-lucide="scan-face" class="w-4 h-4"></i>
                    </div>
                    <div class="font-bold text-slate-800 dark:text-white">Facial Recognition</div>
                    <p class="text-[10px] text-slate-400">Simulate AI 3D Mesh & Liveness verify</p>
                </button>

                <!-- 2. Fingerprint -->
                <button @click="triggerHardwarePunch('fingerprint')" class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 hover:bg-indigo-50 hover:border-indigo-200 border border-slate-200 dark:border-slate-700 text-left transition space-y-2 group cursor-pointer">
                    <div class="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition">
                        <i data-lucide="fingerprint" class="w-4 h-4"></i>
                    </div>
                    <div class="font-bold text-slate-800 dark:text-white">Optical Fingerprint</div>
                    <p class="text-[10px] text-slate-400">Simulate 500 DPI 1:N match</p>
                </button>

                <!-- 3. RFID Card -->
                <button @click="triggerHardwarePunch('rfid')" class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 hover:bg-indigo-50 hover:border-indigo-200 border border-slate-200 dark:border-slate-700 text-left transition space-y-2 group cursor-pointer">
                    <div class="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition">
                        <i data-lucide="credit-card" class="w-4 h-4"></i>
                    </div>
                    <div class="font-bold text-slate-800 dark:text-white">RFID NFC Badge</div>
                    <p class="text-[10px] text-slate-400">Simulate 13.56 MHz Mifare tap</p>
                </button>

                <!-- 4. Dynamic QR Code -->
                <button @click="triggerHardwarePunch('qr')" class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 hover:bg-indigo-50 hover:border-indigo-200 border border-slate-200 dark:border-slate-700 text-left transition space-y-2 group cursor-pointer">
                    <div class="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition">
                        <i data-lucide="qr-code" class="w-4 h-4"></i>
                    </div>
                    <div class="font-bold text-slate-800 dark:text-white">Dynamic Rotating QR</div>
                    <p class="text-[10px] text-slate-400">Token rotates in <span class="font-bold text-indigo-600" x-text="qrCountdown + 's'"></span></p>
                </button>

            </div>

            <!-- Terminal Response Alert -->
            <template x-if="kioskResponse">
                <div class="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-semibold space-y-1 animate-in fade-in">
                    <div class="flex items-center justify-between">
                        <span class="flex items-center gap-2 text-emerald-700 font-bold">
                            <i data-lucide="check-circle" class="w-4 h-4"></i>
                            Hardware Punch Ingested!
                        </span>
                        <span class="text-[10px] text-slate-400 font-mono" x-text="new Date().toLocaleTimeString()"></span>
                    </div>
                    <div class="text-[11px] text-emerald-800" x-text="kioskResponse.message || 'Biometric punch verified and recorded in muster.'"></div>
                </div>
            </template>

        </div>

    </div>

</div>
