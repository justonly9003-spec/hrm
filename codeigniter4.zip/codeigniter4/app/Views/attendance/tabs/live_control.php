<!-- TAB: Live Attendance Ecosystem Control & Engine Performance Simulator -->
<script>
window.liveAttendanceControlTabModule = function() {
    return {
        csrfToken: '<?= csrf_token() ?>',
        csrfHash: '<?= csrf_hash() ?>',
        selectedDate: <?= json_encode($date ?? date('Y-m-d')) ?>,
        fromDate: <?= json_encode($fromDate ?? $from ?? $date ?? date('Y-m-d')) ?>,
        toDate: <?= json_encode($toDate ?? $to ?? $date ?? date('Y-m-d')) ?>,
        dateMode: <?= json_encode(!empty($fromDate) && !empty($toDate) && $fromDate !== $toDate ? 'range' : 'single') ?>,
        skipHolidays: true,
        skipWeekends: true,
        companyWeeklyOff: <?= json_encode($companyWeeklyOff ?? []) ?>,
        holidays: <?= json_encode($holidays ?? []) ?>,
        useCurrentTime: true,
        currentTime: '<?= date('H:i:s') ?>',
        customTime: '09:00:00',
        selectedEmpIds: [],
        searchQuery: '',
        departmentFilter: 'all',
        shiftFilter: 'all',
        statusFilter: 'all',
        bulkEventType: 'CHECK_IN',
        isProcessingBulk: false,
        isLoading: false,
        
        // Simulation parameters
        isSimulating: false,
        simulationPattern: 'morning_rush',
        simulationSpeedMs: 100,
        simulationProgress: 0,
        simulationAbort: false,

        // Live Event Stream and Telemetry
        eventStream: [],
        streamFilter: 'all',
        telemetry: {
            lastEventCount: 0,
            lastSuccessCount: 0,
            lastFailedCount: 0,
            lastTotalDurationMs: 0,
            lastAvgLatencyMs: 0,
            minLatencyMs: 0,
            maxLatencyMs: 0,
            totalSimulatedEver: 0
        },

        // Dataset passed from CI4 backend or fetched
        employees: <?= json_encode($employees ?? []) ?>,
        departments: <?= json_encode($departments ?? []) ?>,
        shifts: <?= json_encode($shifts ?? []) ?>,
        branches: <?= json_encode($branches ?? []) ?>,
        summary: {
            total_employees: <?= (int)($stats['totalActive'] ?? count($employees ?? [])) ?>,
            present: <?= (int)($stats['present'] ?? 0) ?>,
            late: <?= (int)($stats['late'] ?? 0) ?>,
            absent: <?= (int)($stats['absent'] ?? 0) ?>,
            on_leave: <?= (int)($stats['onLeave'] ?? 0) ?>,
            checked_in: <?= (int)($stats['present'] ?? 0) ?>,
            checked_out: 0,
            early_out: <?= (int)($stats['earlyOut'] ?? 0) ?>,
            overtime_employees: 0,
            overtime_hours: 0,
            test_records_count: 0,
            presence_rate: <?= (int)($stats['presenceRate'] ?? 0) ?>,
            punctuality_rate: 100
        },

        _clockInterval: null,

        currentCsrfHash() {
            return window.CSRF_HASH || this.csrfHash || '';
        },

        syncCsrf(res, data) {
            const headerHash = (res && res.headers && typeof res.headers.get === 'function') ? res.headers.get('X-CSRF-TOKEN') : '';
            const nextHash = (data && data.csrf_hash) ? data.csrf_hash : (headerHash || window.CSRF_HASH || '');
            if (nextHash) {
                this.csrfHash = nextHash;
                window.CSRF_HASH = nextHash;
            }
        },

        initLiveTab() {
            this.updateClock();
            if (this._clockInterval) clearInterval(this._clockInterval);
            this._clockInterval = setInterval(() => {
                if (document.hidden) return;
                const now = new Date();
                const hrs = String(now.getHours()).padStart(2, '0');
                const mins = String(now.getMinutes()).padStart(2, '0');
                const secs = String(now.getSeconds()).padStart(2, '0');
                this.currentTime = `${hrs}:${mins}:${secs}`;
            }, 1000);

            const isLiveActive = () => (window.attendanceApp ? window.attendanceApp.activeTab === 'live-control' : (window.location.search.includes('tab=live-control')));

            if (isLiveActive()) {
                this.fetchRealtimeData();
            }

            window.addEventListener('tab-changed', (e) => {
                if (e.detail?.tab === 'live-control') {
                    this.fetchRealtimeData();
                }
            });

            this.$nextTick(() => {
                if (window.lucide) window.lucide.createIcons();
            });
        },

        isWeekend(dateStr) {
            if (!dateStr) return false;
            const d = new Date(dateStr + 'T00:00:00');
            if (isNaN(d.getTime())) return false;
            const dayName = d.toLocaleDateString('en-US', { weekday: 'long' });
            const offDays = (Array.isArray(this.companyWeeklyOff) && this.companyWeeklyOff.length > 0)
                ? this.companyWeeklyOff
                : [];
            return offDays.some(day => day.toLowerCase() === dayName.toLowerCase());
        },

        getHoliday(dateStr) {
            if (!dateStr || !Array.isArray(this.holidays)) return null;
            return this.holidays.find(h => {
                const start = h.from_date || h.date || h.start_date || '';
                const end = h.to_date || h.end_date || h.date || start;
                return dateStr >= start && dateStr <= end;
            }) || null;
        },

        getDateRangeDays() {
            if (this.dateMode === 'single') {
                return [this.selectedDate || '<?= date('Y-m-d') ?>'];
            }
            const startStr = this.fromDate <= this.toDate ? this.fromDate : this.toDate;
            const endStr = this.fromDate <= this.toDate ? this.toDate : this.fromDate;
            const dates = [];
            const current = new Date(startStr + 'T00:00:00');
            const end = new Date(endStr + 'T00:00:00');
            let count = 0;
            // Support long ranges up to 3 years (1095 days) without silent 62-day truncation
            while (current <= end && count < 1095) {
                const y = current.getFullYear();
                const m = String(current.getMonth() + 1).padStart(2, '0');
                const d = String(current.getDate()).padStart(2, '0');
                dates.push(`${y}-${m}-${d}`);
                current.setDate(current.getDate() + 1);
                count++;
            }
            return dates.length > 0 ? dates : [this.selectedDate];
        },

        getActiveWorkingDates() {
            const allDays = this.getDateRangeDays();
            return allDays.filter(d => {
                if (this.skipWeekends && this.isWeekend(d)) return false;
                if (this.skipHolidays && this.getHoliday(d)) return false;
                return true;
            });
        },

        get dateRangeSummary() {
            const days = this.getDateRangeDays();
            let weekends = 0;
            let holidaysCount = 0;
            let working = 0;
            const holidayNames = [];

            days.forEach(d => {
                const isWk = this.isWeekend(d);
                const hol = this.getHoliday(d);
                if (isWk) weekends++;
                if (hol) {
                    holidaysCount++;
                    const name = hol.name || hol.title || 'Company Holiday';
                    if (!holidayNames.includes(name)) holidayNames.push(name);
                }
                if ((!this.skipWeekends || !isWk) && (!this.skipHolidays || !hol)) {
                    working++;
                }
            });

            return {
                totalDays: days.length,
                workingDays: working,
                weekendDays: weekends,
                holidayDays: holidaysCount,
                holidayNames: holidayNames,
                weeklyOffNames: (this.companyWeeklyOff && this.companyWeeklyOff.length > 0) ? this.companyWeeklyOff.join(', ') : 'None'
            };
        },

        onDateRangeChange() {
            if (this.fromDate > this.toDate) {
                this.toDate = this.fromDate;
            }
            this.selectedDate = this.fromDate;
            this.fetchRealtimeData();
        },

        setDatePreset(preset) {
            const today = new Date();
            const fmt = d => d.toISOString().split('T')[0];
            if (preset === 'today') {
                this.selectedDate = fmt(today);
                this.fromDate = fmt(today);
                this.toDate = fmt(today);
                this.dateMode = 'single';
            } else if (preset === 'yesterday') {
                const y = new Date(today);
                y.setDate(y.getDate() - 1);
                this.selectedDate = fmt(y);
                this.fromDate = fmt(y);
                this.toDate = fmt(y);
                this.dateMode = 'single';
            } else if (preset === 'this_week') {
                const start = new Date(today);
                start.setDate(today.getDate() - today.getDay());
                const end = new Date(start);
                end.setDate(start.getDate() + 6);
                this.fromDate = fmt(start);
                this.toDate = fmt(end);
                this.selectedDate = fmt(today);
                this.dateMode = 'range';
            } else if (preset === 'last_7_days') {
                const start = new Date(today);
                start.setDate(today.getDate() - 6);
                this.fromDate = fmt(start);
                this.toDate = fmt(today);
                this.selectedDate = fmt(today);
                this.dateMode = 'range';
            } else if (preset === 'this_month') {
                const start = new Date(today.getFullYear(), today.getMonth(), 1);
                const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
                this.fromDate = fmt(start);
                this.toDate = fmt(end);
                this.selectedDate = fmt(today);
                this.dateMode = 'range';
            }
            this.fetchRealtimeData();
        },

        updateClock() {
            const now = new Date();
            this.currentTime = now.toTimeString().split(' ')[0];
        },

        get activeTimestamp() {
            return this.useCurrentTime ? this.currentTime : this.customTime;
        },

        setTimePreset(timeStr) {
            this.customTime = timeStr;
            this.useCurrentTime = false;
        },

        async fetchRealtimeData() {
            this.isLoading = true;
            try {
                const params = new URLSearchParams();
                params.append('date', this.selectedDate);
                params.append('from_date', this.fromDate);
                params.append('to_date', this.dateMode === 'range' ? this.toDate : this.selectedDate);
                params.append('date_mode', this.dateMode);
                params.append('skip_weekends', this.skipWeekends ? '1' : '0');
                params.append('skip_holidays', this.skipHolidays ? '1' : '0');
                if (this.departmentFilter !== 'all') params.append('department_id', this.departmentFilter);
                if (this.shiftFilter !== 'all') params.append('shift_id', this.shiftFilter);
                if (this.searchQuery) params.append('search', this.searchQuery);

                const res = await fetch('<?= base_url('attendance/live-employees') ?>?' + params.toString(), {
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                });
                const data = await res.json();
                this.syncCsrf(res, data);
                if (data.success && data.employees) {
                    this.employees = data.employees;
                }

                // Also fetch fresh summary
                const sumRes = await fetch('<?= base_url('attendance/live-summary') ?>?' + params.toString(), {
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                });
                const sumData = await sumRes.json();
                this.syncCsrf(sumRes, sumData);
                if (sumData.success && sumData.summary) {
                    this.summary = sumData.summary;
                }
            } catch (err) {
                console.error('Error fetching live data:', err);
            } finally {
                this.isLoading = false;
                this.$nextTick(() => {
                    if (window.lucide) window.lucide.createIcons();
                });
            }
        },

        get filteredEmployees() {
            return this.employees.filter(emp => {
                if (this.departmentFilter !== 'all' && emp.department_id !== this.departmentFilter && emp.department !== this.departmentFilter) return false;
                if (this.shiftFilter !== 'all' && String(emp.shift_id || '') !== String(this.shiftFilter)) return false;

                const status = (emp.live_status || emp.status || '').toLowerCase();
                if (this.statusFilter !== 'all') {
                    if (this.statusFilter === 'present' && !['present', 'late', 'early out', 'late & early out'].includes(status)) return false;
                    if (this.statusFilter === 'absent' && status !== 'absent') return false;
                    if (this.statusFilter === 'late' && status !== 'late' && status !== 'late & early out') return false;
                    if (this.statusFilter === 'leave' && !status.includes('leave')) return false;
                    if (this.statusFilter === 'overtime' && !(parseFloat(emp.overtime_hours || 0) > 0)) return false;
                    if (this.statusFilter === 'test_records' && !(emp.is_test_record || emp.source === 'live_test' || emp.verification_source === 'live_test')) return false;
                }

                if (this.searchQuery.trim()) {
                    const q = this.searchQuery.toLowerCase();
                    const name = (emp.name || emp.full_name || emp.first_name || '').toLowerCase();
                    const code = (emp.employee_code || emp.id || '').toLowerCase();
                    const dept = (emp.department_name || emp.department || '').toLowerCase();
                    return name.includes(q) || code.includes(q) || dept.includes(q);
                }

                return true;
            });
        },

        toggleSelectAll() {
            const currentFiltered = this.filteredEmployees;
            if (this.selectedEmpIds.length === currentFiltered.length && currentFiltered.length > 0) {
                this.selectedEmpIds = [];
            } else {
                this.selectedEmpIds = currentFiltered.map(e => e.id);
            }
        },

        selectByDepartment(deptId) {
            this.selectedEmpIds = this.employees.filter(e => String(e.department_id || '') === String(deptId) || String(e.department || '') === String(deptId)).map(e => e.id);
        },

        selectByShift(shiftId) {
            this.selectedEmpIds = this.employees.filter(e => String(e.shift_id || '') === String(shiftId)).map(e => e.id);
        },

        // Trigger Single Employee Action
        async triggerSingle(empId, eventType, customTimeVal = null) {
            const targetTime = customTimeVal || this.activeTimestamp;
            const emp = this.employees.find(e => e.id === empId) || {};
            const startTime = performance.now();
            const activeHash = this.currentCsrfHash();

            const formData = new URLSearchParams();
            formData.append('employee_id', empId);
            formData.append('event_type', eventType);
            formData.append('date', this.selectedDate);
            formData.append('time', targetTime);
            formData.append('custom_time', (customTimeVal || !this.useCurrentTime) ? '1' : '0');
            formData.append('force_update', '1');
            formData.append('override_weekend_holiday', '1');
            if (this.csrfToken && activeHash) {
                formData.append(this.csrfToken, activeHash);
            }

            try {
                const headers = { 
                    'Content-Type': 'application/x-www-form-urlencoded', 
                    'X-Requested-With': 'XMLHttpRequest' 
                };
                if (activeHash) headers['X-CSRF-TOKEN'] = activeHash;

                const res = await fetch('<?= base_url('attendance/live-trigger-single') ?>', {
                    method: 'POST',
                    headers: headers,
                    body: formData.toString()
                });
                const data = await res.json();
                this.syncCsrf(res, data);
                const durationMs = Math.round(performance.now() - startTime);

                this.addStreamItem({
                    id: 'EVT-' + Math.floor(100000 + Math.random() * 900000),
                    timestamp: new Date().toLocaleTimeString(),
                    time: targetTime,
                    employeeId: empId,
                    employeeCode: emp.employee_code || empId,
                    employeeName: emp.name || emp.first_name || 'Staff',
                    department: emp.department_name || emp.department || 'General',
                    shiftName: emp.shift_name || 'Standard Shift',
                    eventType: eventType,
                    status: data.success ? 'SUCCESS' : 'FAILED',
                    message: data.message || (data.success ? `Event [${eventType}] processed.` : (data.error || 'Action rejected.')),
                    lateMinutes: data.late_minutes,
                    earlyMinutes: data.early_out_minutes || data.early_out_mins,
                    workingHours: data.working_hours,
                    overtimeHours: data.overtime_hours,
                    durationMs: data.duration_ms || durationMs
                });

                this.updateTelemetry(1, data.success ? 1 : 0, data.success ? 0 : 1, durationMs);
                this.fetchRealtimeData();
            } catch (err) {
                console.error('Trigger single error:', err);
                const durationMs = Math.round(performance.now() - startTime);
                this.addStreamItem({
                    id: 'EVT-' + Math.floor(100000 + Math.random() * 900000),
                    timestamp: new Date().toLocaleTimeString(),
                    time: targetTime,
                    employeeId: empId,
                    employeeCode: emp.employee_code || empId,
                    employeeName: emp.name || emp.first_name || 'Staff',
                    department: emp.department_name || emp.department || 'General',
                    shiftName: emp.shift_name || 'Standard Shift',
                    eventType: eventType,
                    status: 'FAILED',
                    message: 'Network or execution error.',
                    durationMs: durationMs
                });
                this.updateTelemetry(1, 0, 1, durationMs);
            }
        },

        // Bulk Dispatcher
        async triggerBulkAction() {
            if (this.selectedEmpIds.length === 0) {
                alert('Please select at least one employee from the table or use the quick scope selectors.');
                return;
            }

            this.isProcessingBulk = true;
            const startTime = performance.now();
            const targetTime = this.activeTimestamp;

            const isRange = this.dateMode === 'range' && (this.fromDate !== this.toDate);
            const allDays = this.getDateRangeDays();
            const workingDays = this.getActiveWorkingDates();

            if (isRange && workingDays.length === 0) {
                alert('No active working days found in the selected range (' + this.fromDate + ' to ' + this.toDate + '). All dates are company holidays or weekends.');
                this.isProcessingBulk = false;
                return;
            }

            // Stream skipped entries for transparency
            allDays.forEach(d => {
                if (this.skipWeekends && this.isWeekend(d)) {
                    this.addStreamItem({
                        id: 'SKP-' + Math.floor(100000 + Math.random() * 900000),
                        timestamp: new Date().toLocaleTimeString(),
                        time: targetTime,
                        employeeId: 'ALL',
                        employeeCode: 'POLICY',
                        employeeName: 'All Selected Employees',
                        department: 'Company-Wide',
                        shiftName: 'Weekly Off',
                        eventType: 'SKIPPED_WEEKEND',
                        status: 'SKIPPED',
                        message: `Date ${d} is a Company Weekend (${this.companyWeeklyOff.join(', ') || 'Weekly Off'}) — Dispatches skipped per weekend policy.`,
                        durationMs: 0
                    });
                } else if (this.skipHolidays && this.getHoliday(d)) {
                    const hol = this.getHoliday(d);
                    const hName = hol.name || hol.title || 'Official Holiday';
                    this.addStreamItem({
                        id: 'SKP-' + Math.floor(100000 + Math.random() * 900000),
                        timestamp: new Date().toLocaleTimeString(),
                        time: targetTime,
                        employeeId: 'ALL',
                        employeeCode: 'HOLIDAY',
                        employeeName: 'All Selected Employees',
                        department: 'Company-Wide',
                        shiftName: 'Holiday',
                        eventType: 'SKIPPED_HOLIDAY',
                        status: 'SKIPPED',
                        message: `Date ${d} is a Company Holiday (${hName}) — Dispatches skipped per holiday policy.`,
                        durationMs: 0
                    });
                }
            });

            // If single date mode, check if single date is weekend/holiday
            let overrideWeekendHoliday = false;
            if (!isRange) {
                if (this.skipWeekends && this.isWeekend(this.selectedDate)) {
                    const offNames = (Array.isArray(this.companyWeeklyOff) && this.companyWeeklyOff.length > 0) ? this.companyWeeklyOff.join(', ') : 'Weekly Off';
                    if (!confirm(`Date ${this.selectedDate} is a configured Company Weekend (${offNames}). Do you still want to force dispatch events?`)) {
                        this.isProcessingBulk = false;
                        return;
                    }
                    overrideWeekendHoliday = true;
                }
                if (this.skipHolidays && this.getHoliday(this.selectedDate)) {
                    const hol = this.getHoliday(this.selectedDate);
                    const hName = hol.name || hol.title || 'Company Holiday';
                    if (!confirm(`Date ${this.selectedDate} is a Company Holiday (${hName}). Do you still want to force dispatch events?`)) {
                        this.isProcessingBulk = false;
                        return;
                    }
                    overrideWeekendHoliday = true;
                }
            } else {
                // Range mode preview confirmation before dispatch
                const pMsg = `Dispatch ${this.bulkEventType} for ${this.selectedEmpIds.length} employee(s) across ${this.dateRangeSummary.workingDays} working days?\n(${this.dateRangeSummary.weekendDays} weekends skipped, ${this.dateRangeSummary.holidayDays} holidays skipped${this.dateRangeSummary.holidayNames.length > 0 ? ': ' + this.dateRangeSummary.holidayNames.join(', ') : ''})`;
                if (!confirm(pMsg)) {
                    this.isProcessingBulk = false;
                    return;
                }
            }

            const activeHash = this.currentCsrfHash();
            const formData = new URLSearchParams();
            formData.append('employee_ids', JSON.stringify(this.selectedEmpIds));
            formData.append('event_type', this.bulkEventType);
            formData.append('date', this.selectedDate);
            formData.append('from_date', this.fromDate);
            formData.append('to_date', isRange ? this.toDate : this.selectedDate);
            formData.append('skip_holidays', this.skipHolidays ? '1' : '0');
            formData.append('skip_weekends', this.skipWeekends ? '1' : '0');
            formData.append('override_weekend_holiday', overrideWeekendHoliday ? '1' : '0');
            formData.append('time', targetTime);
            formData.append('custom_time', !this.useCurrentTime ? '1' : '0');
            formData.append('force_update', '1');
            if (this.csrfToken && activeHash) {
                formData.append(this.csrfToken, activeHash);
            }

            try {
                const headers = { 
                    'Content-Type': 'application/x-www-form-urlencoded', 
                    'X-Requested-With': 'XMLHttpRequest' 
                };
                if (activeHash) headers['X-CSRF-TOKEN'] = activeHash;

                const res = await fetch('<?= base_url('attendance/live-trigger-bulk') ?>', {
                    method: 'POST',
                    headers: headers,
                    body: formData.toString()
                });
                const data = await res.json();
                this.syncCsrf(res, data);
                const totalDuration = Math.round(performance.now() - startTime);
                const eventList = data.events || data.results || [];

                if (Array.isArray(eventList) && eventList.length > 0) {
                    eventList.forEach(r => {
                        this.addStreamItem({
                            id: 'EVT-' + Math.floor(100000 + Math.random() * 900000),
                            timestamp: new Date().toLocaleTimeString(),
                            time: targetTime,
                            employeeId: r.employee_id,
                            employeeCode: r.employee_code || r.employee_id,
                            employeeName: r.employee_name || 'Staff',
                            department: r.department || 'General',
                            shiftName: r.shift || 'Shift',
                            eventType: this.bulkEventType,
                            status: r.success ? 'SUCCESS' : (r.skipped ? 'SKIPPED' : 'FAILED'),
                            message: r.message || (r.success ? 'Bulk event processed' : (r.error || r.reason || 'Event failed')),
                            error: r.error || r.reason || null,
                            lateMinutes: r.late_minutes,
                            earlyMinutes: r.early_out_minutes || r.early_out_mins,
                            workingHours: r.working_hours,
                            overtimeHours: r.overtime_hours,
                            durationMs: r.duration_ms || 10
                        });
                    });
                } else if (!data.success && !data.skipped) {
                    this.selectedEmpIds.forEach(id => {
                        const emp = this.employees.find(e => e.id === id) || {};
                        this.addStreamItem({
                            id: 'EVT-' + Math.floor(100000 + Math.random() * 900000),
                            timestamp: new Date().toLocaleTimeString(),
                            time: targetTime,
                            employeeId: id,
                            employeeCode: emp.employee_code || id,
                            employeeName: emp.name || emp.first_name || 'Staff',
                            department: emp.department_name || emp.department || 'General',
                            shiftName: emp.shift_name || 'Shift',
                            eventType: this.bulkEventType,
                            status: 'FAILED',
                            message: data.message || data.error || 'Bulk dispatch rejected',
                            durationMs: 10
                        });
                    });
                }

                const processedTotal = isRange ? (workingDays.length * this.selectedEmpIds.length) : this.selectedEmpIds.length;
                this.updateTelemetry(
                    processedTotal, 
                    data.success_count !== undefined ? data.success_count : (data.success ? processedTotal : 0), 
                    data.failed_count !== undefined ? data.failed_count : (data.success ? 0 : processedTotal), 
                    totalDuration
                );

                this.fetchRealtimeData();
            } catch (err) {
                console.error('Bulk trigger error:', err);
                const totalDuration = Math.round(performance.now() - startTime);
                this.updateTelemetry(this.selectedEmpIds.length, 0, this.selectedEmpIds.length, totalDuration);
            } finally {
                this.isProcessingBulk = false;
            }
        },

        // Stress & Load Simulator
        async startSimulation() {
            if (this.isSimulating) return;
            this.isSimulating = true;
            this.simulationAbort = false;
            this.simulationProgress = 0;

            const pool = this.filteredEmployees.length > 0 ? this.filteredEmployees : this.employees;
            if (pool.length === 0) {
                alert('No employees available for simulation.');
                this.isSimulating = false;
                return;
            }

            const isRange = this.dateMode === 'range' && (this.fromDate !== this.toDate);
            const allDays = this.getDateRangeDays();
            const targetDates = this.getActiveWorkingDates();

            if (isRange && targetDates.length === 0) {
                alert('No active working dates in range (' + this.fromDate + ' to ' + this.toDate + '). All dates are company holidays or weekends.');
                this.isSimulating = false;
                return;
            }

            // Stream skipped entries for transparency
            allDays.forEach(d => {
                if (this.skipWeekends && this.isWeekend(d)) {
                    this.addStreamItem({
                        id: 'SKP-' + Math.floor(100000 + Math.random() * 900000),
                        timestamp: new Date().toLocaleTimeString(),
                        time: '00:00:00',
                        employeeId: 'ALL',
                        employeeCode: 'POLICY',
                        employeeName: 'Workforce',
                        department: 'Company-Wide',
                        shiftName: 'Weekly Off',
                        eventType: 'SKIPPED_WEEKEND',
                        status: 'SKIPPED',
                        message: `Simulation skipped date ${d} — Company Weekend (${this.companyWeeklyOff.join(', ') || 'Weekly Off'}).`,
                        durationMs: 0
                    });
                } else if (this.skipHolidays && this.getHoliday(d)) {
                    const hol = this.getHoliday(d);
                    const hName = hol.name || hol.title || 'Official Holiday';
                    this.addStreamItem({
                        id: 'SKP-' + Math.floor(100000 + Math.random() * 900000),
                        timestamp: new Date().toLocaleTimeString(),
                        time: '00:00:00',
                        employeeId: 'ALL',
                        employeeCode: 'HOLIDAY',
                        employeeName: 'Workforce',
                        department: 'Company-Wide',
                        shiftName: 'Holiday',
                        eventType: 'SKIPPED_HOLIDAY',
                        status: 'SKIPPED',
                        message: `Simulation skipped date ${d} — Company Holiday (${hName}).`,
                        durationMs: 0
                    });
                }
            });

            const datesToRun = isRange ? targetDates : [this.selectedDate];
            const totalSteps = datesToRun.length * pool.length;
            let currentStep = 0;
            let successCount = 0;
            let failedCount = 0;
            const simStart = performance.now();

            for (const simDate of datesToRun) {
                if (this.simulationAbort) break;

                for (let i = 0; i < pool.length; i++) {
                    if (this.simulationAbort) break;

                    const emp = pool[i];
                    let simEvent = 'CHECK_IN';
                    let simTime = '08:50:00';

                    // Determine simulation pattern logic
                    if (this.simulationPattern === 'morning_rush') {
                        const rand = Math.random();
                        if (rand < 0.80) {
                            simEvent = 'CHECK_IN';
                            const offset = Math.floor(Math.random() * 15) - 10;
                            const mins = Math.max(0, 540 + offset);
                            simTime = `${String(Math.floor(mins / 60)).padStart(2, '0')}:${String(mins % 60).padStart(2, '0')}:${String(Math.floor(Math.random() * 59)).padStart(2, '0')}`;
                        } else {
                            simEvent = 'LATE_CHECK_IN';
                            const lateOffset = 16 + Math.floor(Math.random() * 45);
                            const mins = 540 + lateOffset;
                            simTime = `${String(Math.floor(mins / 60)).padStart(2, '0')}:${String(mins % 60).padStart(2, '0')}:${String(Math.floor(Math.random() * 59)).padStart(2, '0')}`;
                        }
                    } else if (this.simulationPattern === 'evening_rush') {
                        const rand = Math.random();
                        if (rand < 0.85) {
                            simEvent = 'CHECK_OUT';
                            const offset = Math.floor(Math.random() * 25);
                            const mins = 1080 + offset;
                            simTime = `${String(Math.floor(mins / 60)).padStart(2, '0')}:${String(mins % 60).padStart(2, '0')}:${String(Math.floor(Math.random() * 59)).padStart(2, '0')}`;
                        } else {
                            simEvent = 'EARLY_CHECK_OUT';
                            const earlyOffset = Math.floor(Math.random() * 60) + 15;
                            const mins = 1080 - earlyOffset;
                            simTime = `${String(Math.floor(mins / 60)).padStart(2, '0')}:${String(mins % 60).padStart(2, '0')}:${String(Math.floor(Math.random() * 59)).padStart(2, '0')}`;
                        }
                    } else if (this.simulationPattern === 'concurrency_burst') {
                        simEvent = 'CHECK_IN';
                        simTime = this.activeTimestamp;
                    } else {
                        // Mixed Realistic
                        const rand = Math.random();
                        if (rand < 0.80) {
                            simEvent = 'MARK_PRESENT';
                        } else if (rand < 0.90) {
                            simEvent = 'LATE_CHECK_IN';
                        } else {
                            simEvent = 'CHECK_IN';
                        }
                        simTime = this.activeTimestamp;
                    }

                    const empStart = performance.now();
                    try {
                        const activeHash = this.currentCsrfHash();
                        const formData = new URLSearchParams();
                        formData.append('employee_id', emp.id);
                        formData.append('event_type', simEvent);
                        formData.append('date', simDate);
                        formData.append('time', simTime);
                        formData.append('custom_time', '1');
                        formData.append('force_update', '1');
                        formData.append('override_weekend_holiday', '1');
                        if (this.csrfToken && activeHash) {
                            formData.append(this.csrfToken, activeHash);
                        }

                        const headers = { 
                            'Content-Type': 'application/x-www-form-urlencoded', 
                            'X-Requested-With': 'XMLHttpRequest' 
                        };
                        if (activeHash) headers['X-CSRF-TOKEN'] = activeHash;

                        const res = await fetch('<?= base_url('attendance/live-trigger-single') ?>', {
                            method: 'POST',
                            headers: headers,
                            body: formData.toString()
                        });
                        const resData = await res.json();
                        this.syncCsrf(res, resData);
                        const durationMs = Math.round(performance.now() - empStart);

                        if (resData.success) successCount++;
                        else failedCount++;

                        this.addStreamItem({
                            id: 'SIM-' + Math.floor(100000 + Math.random() * 900000),
                            timestamp: new Date().toLocaleTimeString(),
                            time: simTime,
                            employeeId: emp.id,
                            employeeCode: emp.employee_code || emp.id,
                            employeeName: emp.name || emp.first_name || 'Staff',
                            department: emp.department_name || emp.department || 'General',
                            shiftName: emp.shift_name || 'Standard Shift',
                            eventType: simEvent,
                            status: resData.success ? 'SUCCESS' : 'FAILED',
                            message: `[${simDate}] ` + (resData.message || (resData.success ? `Simulation event registered.` : 'Rejected')),
                            lateMinutes: resData.late_minutes,
                            earlyMinutes: resData.early_out_minutes || resData.early_out_mins,
                            workingHours: resData.working_hours,
                            overtimeHours: resData.overtime_hours,
                            durationMs: resData.duration_ms || durationMs
                        });
                    } catch (e) {
                        failedCount++;
                    }

                    currentStep++;
                    this.simulationProgress = Math.round((currentStep / totalSteps) * 100);

                    if (this.simulationSpeedMs > 0) {
                        await new Promise(r => setTimeout(r, this.simulationSpeedMs));
                    }
                }
            }

            const totalDuration = Math.round(performance.now() - simStart);
            this.updateTelemetry(currentStep, successCount, failedCount, totalDuration);
            this.isSimulating = false;
            this.fetchRealtimeData();
        },

        abortSimulation() {
            this.simulationAbort = true;
            this.isSimulating = false;
        },

        // Safe Cleanups & Test Purging
        async resetTestData(scope = 'date') {
            const confirmMsg = scope === 'all' 
                ? 'Are you sure you want to PURGE ALL live test attendance records across the entire database? (Production records remain untouched).'
                : (scope === 'range' 
                    ? `Are you sure you want to reset all live test records between ${this.fromDate} and ${this.toDate}?`
                    : `Are you sure you want to reset all live test records for ${this.selectedDate}?`);

            if (!confirm(confirmMsg)) return;

            this.isLoading = true;
            const activeHash = this.currentCsrfHash();
            const formData = new URLSearchParams();
            formData.append('scope', scope);
            formData.append('date', this.selectedDate);
            formData.append('from_date', this.fromDate);
            formData.append('to_date', this.toDate);
            formData.append('confirm', 'RESET_TEST_ATTENDANCE');
            if (this.csrfToken && activeHash) {
                formData.append(this.csrfToken, activeHash);
            }

            try {
                const headers = { 
                    'Content-Type': 'application/x-www-form-urlencoded', 
                    'X-Requested-With': 'XMLHttpRequest' 
                };
                if (activeHash) headers['X-CSRF-TOKEN'] = activeHash;

                const res = await fetch('<?= base_url('attendance/live-reset') ?>', {
                    method: 'POST',
                    headers: headers,
                    body: formData.toString()
                });
                const data = await res.json();
                this.syncCsrf(res, data);
                alert(data.message || 'Test data reset completed.');
                this.eventStream = [];
                this.fetchRealtimeData();
            } catch (err) {
                console.error('Reset error:', err);
            } finally {
                this.isLoading = false;
            }
        },

        addStreamItem(item) {
            this.eventStream = [item, ...this.eventStream.slice(0, 49)];
        },

        updateTelemetry(count, success, failed, durationMs) {
            const avg = count > 0 ? Math.round((durationMs / count) * 100) / 100 : 0;
            this.telemetry = {
                lastEventCount: count,
                lastSuccessCount: success,
                lastFailedCount: failed,
                lastTotalDurationMs: durationMs,
                lastAvgLatencyMs: avg,
                minLatencyMs: Math.min(this.telemetry.minLatencyMs || 999, avg),
                maxLatencyMs: Math.max(this.telemetry.maxLatencyMs, avg),
                totalSimulatedEver: this.telemetry.totalSimulatedEver + count
            };
        },

        get filteredStream() {
            if (this.streamFilter === 'all') return this.eventStream;
            return this.eventStream.filter(e => e.status.toLowerCase() === this.streamFilter.toLowerCase());
        }
    };
};
</script>

<template x-if="isTabLoaded('live-control')">
<div 
    x-show="activeTab === 'live-control' || activeTab === 'live'" 
    x-data="liveAttendanceControlTabModule()" 
    x-init="initLiveTab()"
    class="space-y-6 animate-in fade-in duration-200"
>

    <!-- TOP SAFETY BANNER: LIVE SIMULATION TEST MODE -->
    <div class="relative overflow-hidden rounded-3xl bg-gradient-to-r from-amber-600 via-orange-600 to-rose-600 p-6 text-white shadow-xl shadow-orange-500/10">
        <div class="absolute -right-10 -bottom-10 w-64 h-64 rounded-full bg-white/10 blur-2xl pointer-events-none"></div>
        <div class="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div class="flex items-start gap-4">
                <div class="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center flex-shrink-0 shadow-inner">
                    <i data-lucide="shield-alert" class="w-7 h-7 text-white"></i>
                </div>
                <div>
                    <div class="flex items-center gap-2">
                        <span class="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-white/20 text-white border border-white/30 backdrop-blur-xs flex items-center gap-1.5">
                            <span class="w-2 h-2 rounded-full bg-amber-300 animate-ping"></span>
                            Live Engine Simulation & Performance Testing Console
                        </span>
                        <span class="text-xs font-mono bg-black/20 px-2 py-0.5 rounded-md text-amber-200">DB SOURCE: live_test</span>
                    </div>
                    <h2 class="text-2xl font-black tracking-tight mt-1">Live Attendance Ecosystem Control</h2>
                    <p class="text-xs text-amber-100/90 max-w-3xl mt-0.5">
                        Events triggered here pass directly through the authoritative <strong>Attendance Engine, Rule Hierarchy, Shift Engine, Leave & Holiday Validators, and Database Models</strong>. Use this console to test system performance, inspect rule behavior in real-time, and run bulk workforce simulations.
                    </p>
                </div>
            </div>

            <!-- Quick Safe Reset Actions in Top Banner -->
            <div class="flex items-center gap-2.5 flex-wrap">
                <button @click="resetTestData('date')" :disabled="isLoading" class="px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-white font-bold text-xs backdrop-blur-xs transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50">
                    <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i>
                    <span>Reset Today's Test Data</span>
                </button>
                <button @click="resetTestData('all')" :disabled="isLoading" class="px-3.5 py-2 rounded-xl bg-black/30 hover:bg-black/40 text-amber-200 font-bold text-xs border border-white/20 transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50">
                    <i data-lucide="trash-2" class="w-3.5 h-3.5 text-rose-300"></i>
                    <span>Purge All Test Records</span>
                </button>
            </div>
        </div>
    </div>

    <!-- REAL-TIME KPI SUMMARY METRIC CARDS -->
    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
        <!-- 1. Total Active Workforce -->
        <div class="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm">
            <div class="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-bold mb-1">
                <span>Active Employees</span>
                <i data-lucide="users" class="w-4 h-4 text-indigo-500"></i>
            </div>
            <div class="text-2xl font-black text-slate-900 dark:text-white" x-text="summary.total_employees">0</div>
            <div class="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
                <span>Filter scope</span>
                <span class="font-mono text-indigo-600 dark:text-indigo-400" x-text="'(' + filteredEmployees.length + ' shown)'"></span>
            </div>
        </div>

        <!-- 2. Present / Presence Rate -->
        <div class="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm">
            <div class="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-bold mb-1">
                <span>Present Today</span>
                <i data-lucide="user-check" class="w-4 h-4 text-emerald-500"></i>
            </div>
            <div class="text-2xl font-black text-emerald-600 dark:text-emerald-400" x-text="summary.present">0</div>
            <div class="text-[10px] text-emerald-600 font-bold mt-1 flex items-center gap-1">
                <span x-text="summary.presence_rate + '% Presence'">0%</span>
                <span class="text-slate-400 font-normal">| <span x-text="summary.checked_in">0</span> in-office</span>
            </div>
        </div>

        <!-- 3. Late Check-Ins -->
        <div class="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm">
            <div class="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-bold mb-1">
                <span>Late Punches</span>
                <i data-lucide="alert-triangle" class="w-4 h-4 text-amber-500"></i>
            </div>
            <div class="text-2xl font-black text-amber-600 dark:text-amber-400" x-text="summary.late">0</div>
            <div class="text-[10px] text-amber-600 font-bold mt-1">
                <span x-text="summary.punctuality_rate + '% Punctuality'">100%</span>
            </div>
        </div>

        <!-- 4. Absent & On Leave -->
        <div class="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm">
            <div class="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-bold mb-1">
                <span>Absent / Leave</span>
                <i data-lucide="user-x" class="w-4 h-4 text-rose-500"></i>
            </div>
            <div class="text-2xl font-black text-rose-600 dark:text-rose-400">
                <span x-text="summary.absent">0</span>
                <span class="text-xs text-blue-500 font-bold" x-text="' / ' + summary.on_leave + ' L'"></span>
            </div>
            <div class="text-[10px] text-slate-400 mt-1">
                <span x-text="summary.early_out + ' early exits'"></span>
            </div>
        </div>

        <!-- 5. Overtime Generated -->
        <div class="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm">
            <div class="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-bold mb-1">
                <span>Overtime Logged</span>
                <i data-lucide="trending-up" class="w-4 h-4 text-purple-500"></i>
            </div>
            <div class="text-2xl font-black text-purple-600 dark:text-purple-400 font-mono" x-text="summary.overtime_hours + 'h'">0h</div>
            <div class="text-[10px] text-purple-600 font-bold mt-1">
                <span x-text="summary.overtime_employees + ' staff members'">0 staff</span>
            </div>
        </div>

        <!-- 6. Test Data Isolation Status -->
        <div class="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm">
            <div class="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-bold mb-1">
                <span>Test Records</span>
                <i data-lucide="cpu" class="w-4 h-4 text-orange-500"></i>
            </div>
            <div class="text-2xl font-black text-orange-600 dark:text-orange-400 font-mono" x-text="summary.test_records_count">0</div>
            <div class="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
                <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                <span>Isolated DB Scope</span>
            </div>
        </div>
    </div>

    <!-- MAIN CONTROL HUB: TIME SYNCHRONIZER, BULK DISPATCHER & STRESS SIMULATOR -->
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">

        <!-- Left Column: Clock Controls & Bulk Event Dispatcher (7 Cols) -->
        <div class="lg:col-span-7 space-y-6">

            <!-- 1. Date Scope & Calendar Policy Console (From Date, To Date & Policy Exceptions) -->
            <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm space-y-4">
                <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
                    <div class="flex items-center gap-2.5">
                        <div class="p-2 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 font-bold">
                            <i data-lucide="calendar-range" class="w-4 h-4"></i>
                        </div>
                        <div>
                            <h3 class="font-extrabold text-slate-900 dark:text-white text-sm">Date Scope & Policy Exceptions</h3>
                            <p class="text-[11px] text-slate-400">Target a single date or date range. Automatically exclude company holidays and weekly off days (e.g. Every Friday is Weekend).</p>
                        </div>
                    </div>

                    <!-- Mode Toggle: Single Date vs Date Range -->
                    <div class="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl shrink-0">
                        <button 
                            type="button"
                            @click="dateMode = 'single'; selectedDate = fromDate; fetchRealtimeData()" 
                            :class="dateMode === 'single' ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs font-black' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'" 
                            class="px-3 py-1.5 rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5"
                        >
                            <i data-lucide="calendar" class="w-3.5 h-3.5"></i>
                            <span>Single Date</span>
                        </button>
                        <button 
                            type="button"
                            @click="dateMode = 'range'; onDateRangeChange()" 
                            :class="dateMode === 'range' ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs font-black' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'" 
                            class="px-3 py-1.5 rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5"
                        >
                            <i data-lucide="calendar-range" class="w-3.5 h-3.5"></i>
                            <span>Date Range</span>
                        </button>
                    </div>
                </div>

                <!-- SINGLE DATE MODE CONTROLS -->
                <div x-show="dateMode === 'single'" class="space-y-3">
                    <div class="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                        <div class="flex-1 bg-slate-50 dark:bg-slate-800/80 px-4 py-2.5 rounded-2xl border border-slate-200/80 dark:border-slate-700 flex items-center justify-between">
                            <span class="text-xs font-bold text-slate-600 dark:text-slate-300">Target Attendance Date:</span>
                            <div class="flex items-center gap-2">
                                <i data-lucide="calendar" class="w-4 h-4 text-indigo-500"></i>
                                <input 
                                    type="date" 
                                    x-model="selectedDate" 
                                    @change="fromDate = selectedDate; toDate = selectedDate; fetchRealtimeData()" 
                                    class="bg-transparent text-xs font-black text-slate-800 dark:text-white focus:outline-none cursor-pointer"
                                />
                            </div>
                        </div>

                        <!-- Quick Single Day Presets -->
                        <div class="flex items-center gap-2 shrink-0">
                            <button type="button" @click="setDatePreset('today')" class="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold transition">
                                Today
                            </button>
                            <button type="button" @click="setDatePreset('yesterday')" class="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold transition">
                                Yesterday
                            </button>
                        </div>
                    </div>

                    <!-- Single Date Policy Notice -->
                    <template x-if="isWeekend(selectedDate)">
                        <div class="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 rounded-2xl flex items-center justify-between text-xs text-amber-900 dark:text-amber-200">
                            <div class="flex items-center gap-2">
                                <i data-lucide="alert-triangle" class="w-4 h-4 text-amber-500 shrink-0"></i>
                                <span><strong>Company Weekend:</strong> <span x-text="selectedDate"></span> is a weekly off (<strong x-text="companyWeeklyOff.join(', ') || 'Weekly Off'"></strong>).</span>
                            </div>
                            <span class="text-[10px] font-mono uppercase bg-amber-200 dark:bg-amber-900 px-2 py-0.5 rounded-full font-bold">Weekend Policy Active</span>
                        </div>
                    </template>
                    <template x-if="getHoliday(selectedDate)">
                        <div class="p-3 bg-purple-50 dark:bg-purple-950/40 border border-purple-300 dark:border-purple-800 rounded-2xl flex items-center justify-between text-xs text-purple-900 dark:text-purple-200">
                            <div class="flex items-center gap-2">
                                <i data-lucide="sparkles" class="w-4 h-4 text-purple-500 shrink-0"></i>
                                <span><strong>Company Holiday:</strong> <span x-text="getHoliday(selectedDate)?.name || 'Official Holiday'"></span>.</span>
                            </div>
                            <span class="text-[10px] font-mono uppercase bg-purple-200 dark:bg-purple-900 px-2 py-0.5 rounded-full font-bold">Holiday Policy Active</span>
                        </div>
                    </template>
                </div>

                <!-- DATE RANGE MODE CONTROLS -->
                <div x-show="dateMode === 'range'" class="space-y-4">
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <!-- From Date Input -->
                        <div class="bg-slate-50 dark:bg-slate-800/80 p-3.5 rounded-2xl border border-slate-200/80 dark:border-slate-700 space-y-1">
                            <label class="block text-[10px] font-mono uppercase font-bold text-slate-400">From Date (Start)</label>
                            <div class="flex items-center gap-2">
                                <i data-lucide="calendar" class="w-4 h-4 text-indigo-500 shrink-0"></i>
                                <input 
                                    type="date" 
                                    x-model="fromDate" 
                                    @change="onDateRangeChange()" 
                                    class="w-full bg-transparent text-sm font-black text-slate-800 dark:text-white focus:outline-none cursor-pointer"
                                />
                            </div>
                        </div>

                        <!-- To Date Input -->
                        <div class="bg-slate-50 dark:bg-slate-800/80 p-3.5 rounded-2xl border border-slate-200/80 dark:border-slate-700 space-y-1">
                            <label class="block text-[10px] font-mono uppercase font-bold text-slate-400">To Date (End)</label>
                            <div class="flex items-center gap-2">
                                <i data-lucide="calendar" class="w-4 h-4 text-indigo-500 shrink-0"></i>
                                <input 
                                    type="date" 
                                    x-model="toDate" 
                                    @change="onDateRangeChange()" 
                                    class="w-full bg-transparent text-sm font-black text-slate-800 dark:text-white focus:outline-none cursor-pointer"
                                />
                            </div>
                        </div>
                    </div>

                    <!-- Quick Range Presets -->
                    <div class="flex items-center gap-2 flex-wrap">
                        <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">Range Presets:</span>
                        <button type="button" @click="setDatePreset('this_week')" class="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-indigo-950/60 text-slate-700 dark:text-slate-300 text-[11px] font-bold transition">
                            This Week
                        </button>
                        <button type="button" @click="setDatePreset('last_7_days')" class="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-indigo-950/60 text-slate-700 dark:text-slate-300 text-[11px] font-bold transition">
                            Last 7 Days
                        </button>
                        <button type="button" @click="setDatePreset('this_month')" class="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-indigo-950/60 text-slate-700 dark:text-slate-300 text-[11px] font-bold transition">
                            This Month
                        </button>
                        <button type="button" @click="setDatePreset('today')" class="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-indigo-950/60 text-slate-700 dark:text-slate-300 text-[11px] font-bold transition">
                            Today Only
                        </button>
                    </div>
                </div>

                <!-- POLICY EXCEPTION TOGGLES (Company Holidays & Weekends e.g. Friday) -->
                <div class="p-4 rounded-2xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/80 space-y-3">
                    <span class="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider block font-mono">Automated Calendar Policy Enforcement:</span>
                    
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <!-- 1. Except Company Holidays -->
                        <label class="flex items-start gap-3 p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 cursor-pointer hover:border-purple-300 dark:hover:border-purple-700 transition">
                            <input 
                                type="checkbox" 
                                x-model="skipHolidays" 
                                class="mt-0.5 rounded text-purple-600 focus:ring-purple-500 w-4 h-4 cursor-pointer"
                            />
                            <div class="space-y-0.5">
                                <div class="flex items-center gap-2">
                                    <span class="text-xs font-black text-slate-900 dark:text-white">Except Company Holidays</span>
                                    <span class="px-1.5 py-0.2 rounded-full text-[9px] bg-purple-100 text-purple-800 dark:bg-purple-900/60 dark:text-purple-300 font-bold" x-text="dateRangeSummary.holidayDays + ' in range'"></span>
                                </div>
                                <p class="text-[11px] text-slate-500 dark:text-slate-400">Exclude official public & company holidays from automated punches.</p>
                            </div>
                        </label>

                        <!-- 2. Except Company Weekends (e.g. Every Friday is Weekend) -->
                        <label class="flex items-start gap-3 p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 cursor-pointer hover:border-amber-300 dark:hover:border-amber-700 transition">
                            <input 
                                type="checkbox" 
                                x-model="skipWeekends" 
                                class="mt-0.5 rounded text-amber-600 focus:ring-amber-500 w-4 h-4 cursor-pointer"
                            />
                            <div class="space-y-0.5">
                                <div class="flex items-center gap-2">
                                    <span class="text-xs font-black text-slate-900 dark:text-white">Except Company Weekends</span>
                                    <span class="px-1.5 py-0.2 rounded-full text-[9px] bg-amber-100 text-amber-800 dark:bg-amber-900/60 dark:text-amber-300 font-bold font-mono">
                                        Off: <span x-text="dateRangeSummary.weeklyOffNames">Friday</span>
                                    </span>
                                </div>
                                <p class="text-[11px] text-slate-500 dark:text-slate-400">Configured rule: <strong>every <span x-text="dateRangeSummary.weeklyOffNames">Friday</span> is weekend</strong>. Events are skipped.</p>
                            </div>
                        </label>
                    </div>

                    <!-- Live Scope Metrics Badge Bar -->
                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-center font-mono">
                        <div class="bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-slate-200/60 dark:border-slate-800">
                            <span class="text-[10px] text-slate-400 block font-sans">Calendar Days</span>
                            <span class="text-base font-black text-slate-900 dark:text-white" x-text="dateRangeSummary.totalDays">1</span>
                        </div>
                        <div class="bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-emerald-200 dark:border-emerald-900/40">
                            <span class="text-[10px] text-emerald-600 dark:text-emerald-400 block font-sans font-bold">Active Working Days</span>
                            <span class="text-base font-black text-emerald-600 dark:text-emerald-400" x-text="dateRangeSummary.workingDays">1</span>
                        </div>
                        <div class="bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-amber-200 dark:border-amber-900/40">
                            <span class="text-[10px] text-amber-600 dark:text-amber-400 block font-sans font-bold">Weekends Skipped</span>
                            <span class="text-base font-black text-amber-600 dark:text-amber-400" x-text="dateRangeSummary.weekendDays">0</span>
                        </div>
                        <div class="bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-purple-200 dark:border-purple-900/40">
                            <span class="text-[10px] text-purple-600 dark:text-purple-400 block font-sans font-bold">Holidays Skipped</span>
                            <span class="text-base font-black text-purple-600 dark:text-purple-400" x-text="dateRangeSummary.holidayDays">0</span>
                        </div>
                    </div>

                    <template x-if="dateRangeSummary.holidayNames.length > 0">
                        <div class="text-[11px] text-purple-700 dark:text-purple-300 bg-purple-50 dark:bg-purple-950/40 px-3 py-1.5 rounded-xl border border-purple-200 dark:border-purple-800 flex items-center gap-1.5">
                            <i data-lucide="info" class="w-3.5 h-3.5 shrink-0"></i>
                            <span>Holidays in range: <strong x-text="dateRangeSummary.holidayNames.join(', ')"></strong></span>
                        </div>
                    </template>
                </div>
            </div>

            <!-- 2. Live Time & Manual Override Console -->
            <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm space-y-4">
                <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                    <div class="flex items-center gap-2">
                        <div class="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 font-bold">
                            <i data-lucide="clock" class="w-4 h-4"></i>
                        </div>
                        <div>
                            <h3 class="font-extrabold text-slate-900 dark:text-white text-sm">Engine Time Synchronizer & Presets</h3>
                            <p class="text-[11px] text-slate-400">Lock timestamps to exact minutes or use live synchronized system clock.</p>
                        </div>
                    </div>

                    <div class="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-mono font-bold text-slate-600 dark:text-slate-300">
                        <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                        <span x-text="selectedDate"></span>
                    </div>
                </div>

                <!-- Clock Mode Toggle & Inputs -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <!-- Live System Clock -->
                    <div 
                        @click="useCurrentTime = true"
                        :class="useCurrentTime ? 'border-indigo-500 bg-indigo-50/40 dark:bg-indigo-950/30' : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40'"
                        class="p-4 rounded-2xl border-2 cursor-pointer transition flex items-center justify-between"
                    >
                        <div>
                            <div class="flex items-center gap-1.5">
                                <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                                <span class="text-xs font-bold text-slate-800 dark:text-white">Live System Clock</span>
                            </div>
                            <div class="text-2xl font-black font-mono text-slate-900 dark:text-white mt-1" x-text="currentTime">00:00:00</div>
                            <span class="text-[10px] text-slate-400">NTP Real-Time Ticker</span>
                        </div>
                        <i data-lucide="radio" :class="useCurrentTime ? 'text-indigo-600' : 'text-slate-300'" class="w-5 h-5"></i>
                    </div>

                    <!-- Manual Timestamp Override -->
                    <div 
                        @click="useCurrentTime = false"
                        :class="!useCurrentTime ? 'border-amber-500 bg-amber-50/40 dark:bg-amber-950/30' : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40'"
                        class="p-4 rounded-2xl border-2 cursor-pointer transition space-y-1.5"
                    >
                        <div class="flex items-center justify-between">
                            <span class="text-xs font-bold text-slate-800 dark:text-white">Manual Timestamp</span>
                            <span class="text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-300 font-bold">Custom</span>
                        </div>
                        <input 
                            type="time" 
                            step="1"
                            x-model="customTime" 
                            @input="useCurrentTime = false"
                            class="w-full text-xl font-black font-mono bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-1 text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500 outline-none"
                        />
                        <span class="text-[10px] text-slate-400 block">Punches will use this exact time</span>
                    </div>
                </div>

                <!-- Quick Simulation Time Presets -->
                <div class="space-y-1.5 pt-1">
                    <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block font-mono">Instant Timing Quick-Presets:</span>
                    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
                        <button @click="setTimePreset('08:50:00')" class="px-2.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-emerald-50 hover:text-emerald-700 dark:hover:bg-emerald-950/60 text-slate-700 dark:text-slate-300 text-[11px] font-bold transition flex flex-col items-center">
                            <span class="font-mono">08:50 AM</span>
                            <span class="text-[9px] text-emerald-600 font-normal">On-Time</span>
                        </button>
                        <button @click="setTimePreset('09:12:00')" class="px-2.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-amber-50 hover:text-amber-700 dark:hover:bg-amber-950/60 text-slate-700 dark:text-slate-300 text-[11px] font-bold transition flex flex-col items-center">
                            <span class="font-mono">09:12 AM</span>
                            <span class="text-[9px] text-amber-600 font-normal">Grace Period</span>
                        </button>
                        <button @click="setTimePreset('09:45:00')" class="px-2.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-rose-50 hover:text-rose-700 dark:hover:bg-rose-950/60 text-slate-700 dark:text-slate-300 text-[11px] font-bold transition flex flex-col items-center">
                            <span class="font-mono">09:45 AM</span>
                            <span class="text-[9px] text-rose-600 font-normal">Late Arrival</span>
                        </button>
                        <button @click="setTimePreset('15:30:00')" class="px-2.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-orange-50 hover:text-orange-700 dark:hover:bg-orange-950/60 text-slate-700 dark:text-slate-300 text-[11px] font-bold transition flex flex-col items-center">
                            <span class="font-mono">03:30 PM</span>
                            <span class="text-[9px] text-orange-600 font-normal">Early Out</span>
                        </button>
                        <button @click="setTimePreset('18:05:00')" class="px-2.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 hover:text-indigo-700 dark:hover:bg-indigo-950/60 text-slate-700 dark:text-slate-300 text-[11px] font-bold transition flex flex-col items-center">
                            <span class="font-mono">06:05 PM</span>
                            <span class="text-[9px] text-indigo-600 font-normal">Shift End</span>
                        </button>
                        <button @click="setTimePreset('19:45:00')" class="px-2.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-purple-50 hover:text-purple-700 dark:hover:bg-purple-950/60 text-slate-700 dark:text-slate-300 text-[11px] font-bold transition flex flex-col items-center">
                            <span class="font-mono">07:45 PM</span>
                            <span class="text-[9px] text-purple-600 font-normal">Overtime</span>
                        </button>
                    </div>
                </div>
            </div>

            <!-- 2. Multi-Employee Bulk Dispatcher -->
            <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm space-y-4">
                <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                    <div class="flex items-center gap-2">
                        <div class="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 font-bold">
                            <i data-lucide="layers" class="w-4 h-4"></i>
                        </div>
                        <div>
                            <h3 class="font-extrabold text-slate-900 dark:text-white text-sm">Bulk Event Dispatcher</h3>
                            <p class="text-[11px] text-slate-400">Trigger simultaneous punches for checked employees or departments.</p>
                        </div>
                    </div>

                    <span class="px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold font-mono text-xs">
                        <span x-text="selectedEmpIds.length">0</span> Selected
                    </span>
                </div>

                <!-- Scope Shortcuts -->
                <div class="flex items-center gap-2 flex-wrap text-xs">
                    <span class="font-bold text-slate-400 text-[11px]">Quick Scopes:</span>
                    <button @click="toggleSelectAll()" class="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-bold text-[11px] transition">
                        <span x-text="selectedEmpIds.length === filteredEmployees.length ? 'Deselect All' : 'Select All Filtered (' + filteredEmployees.length + ')'"></span>
                    </button>
                    <template x-for="dept in departments.slice(0, 3)" :key="dept.id">
                        <button @click="selectByDepartment(dept.id)" class="px-2.5 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-400 font-bold text-[11px] hover:bg-indigo-100 transition" x-text="dept.name"></button>
                    </template>
                    <template x-for="sh in shifts.slice(0, 3)" :key="sh.id">
                        <button @click="selectByShift(sh.id)" class="px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 font-bold text-[11px] hover:bg-emerald-100 transition" x-text="sh.name"></button>
                    </template>
                </div>

                <!-- Bulk Action Trigger Form -->
                <div class="grid grid-cols-1 sm:grid-cols-12 gap-3 pt-2">
                    <div class="sm:col-span-8">
                        <label class="block font-bold text-slate-700 dark:text-slate-300 text-xs mb-1">Select Event Type</label>
                        <select x-model="bulkEventType" class="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white font-bold text-xs focus:ring-2 focus:ring-indigo-500 outline-none">
                            <option value="CHECK_IN">1. Standard Check-In (Evaluates Shift & Grace)</option>
                            <option value="LATE_CHECK_IN">2. Late Check-In (+45m after shift start)</option>
                            <option value="CHECK_OUT">3. Standard Check-Out (Shift End Time)</option>
                            <option value="EARLY_CHECK_OUT">4. Early Departure (-60m before shift end)</option>
                            <option value="MARK_PRESENT">5. Full Work Day (Employee Shift Schedule)</option>
                            <option value="MARK_ABSENT">6. Mark Day Absent</option>
                            <option value="RESET_ATTENDANCE">7. Reset / Clear Day Attendance</option>
                        </select>
                    </div>

                    <div class="sm:col-span-4 flex items-end">
                        <button 
                            @click="triggerBulkAction()" 
                            :disabled="isProcessingBulk || selectedEmpIds.length === 0"
                            class="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-md transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            <i data-lucide="zap" class="w-4 h-4"></i>
                            <span x-text="isProcessingBulk ? 'Dispatching...' : (dateMode === 'range' && fromDate !== toDate ? 'Dispatch across ' + dateRangeSummary.workingDays + ' Working Days' : 'Dispatch Events')"></span>
                        </button>
                    </div>
                </div>

                <!-- Dispatch Preview Badge -->
                <div class="text-[11px] text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-xl border border-slate-200/80 dark:border-slate-700 flex flex-wrap items-center justify-between gap-2">
                    <div class="flex items-center gap-2">
                        <i data-lucide="calendar-check-2" class="w-4 h-4 text-emerald-500 shrink-0"></i>
                        <span>
                            Preview: <strong class="text-emerald-600 dark:text-emerald-400 font-extrabold" x-text="dateRangeSummary.workingDays + ' working days'"></strong>,
                            <span class="text-amber-600 dark:text-amber-400 font-bold" x-text="dateRangeSummary.weekendDays + ' weekends skipped'"></span>,
                            <span class="text-rose-600 dark:text-rose-400 font-bold" x-text="dateRangeSummary.holidayDays + ' holidays skipped' + (dateRangeSummary.holidayNames.length > 0 ? ' (' + dateRangeSummary.holidayNames.join(', ') + ')' : '')"></span>
                        </span>
                    </div>
                    <span class="text-[10px] font-mono text-slate-400 shrink-0" x-text="dateMode === 'range' && fromDate !== toDate ? fromDate + ' → ' + toDate : selectedDate"></span>
                </div>
            </div>

        </div>

        <!-- Right Column: Stress & Load Testing Simulator + Telemetry (5 Cols) -->
        <div class="lg:col-span-5 space-y-6">

            <!-- 1. Wave Simulator -->
            <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm space-y-4">
                <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                    <div class="flex items-center gap-2">
                        <div class="p-2 rounded-xl bg-orange-50 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400 font-bold">
                            <i data-lucide="sparkles" class="w-4 h-4"></i>
                        </div>
                        <div>
                            <h3 class="font-extrabold text-slate-900 dark:text-white text-sm">Stress & Arrival Wave Simulator</h3>
                            <p class="text-[11px] text-slate-400">Generate realistic arrival distributions and concurrency bursts.</p>
                        </div>
                    </div>
                </div>

                <div class="space-y-3 text-xs">
                    <div>
                        <label class="block font-bold text-slate-700 dark:text-slate-300 mb-1">Simulation Wave Pattern</label>
                        <select x-model="simulationPattern" :disabled="isSimulating" class="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white font-bold text-xs focus:ring-2 focus:ring-orange-500 outline-none">
                            <option value="morning_rush">Morning Rush Hour (80% on-time, 20% late arrival)</option>
                            <option value="evening_rush">Evening Departure Wave (85% on-time, 15% early exit)</option>
                            <option value="concurrency_burst">Concurrency Burst (High-throughput simultaneous punches)</option>
                            <option value="mixed_realistic">Mixed Workforce Day (Realistic presence & leave distributions)</option>
                        </select>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-bold text-slate-700 dark:text-slate-300 mb-1">Latency Throttle (ms)</label>
                            <select x-model="simulationSpeedMs" :disabled="isSimulating" class="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white font-bold text-xs focus:ring-2 focus:ring-orange-500 outline-none">
                                <option value="0">0ms (Instant Burst)</option>
                                <option value="50">50ms (Rapid Wave)</option>
                                <option value="100">100ms (Standard Live)</option>
                                <option value="250">250ms (Slow-Motion)</option>
                            </select>
                        </div>

                        <div>
                            <label class="block font-bold text-slate-700 dark:text-slate-300 mb-1">Target Pool Size</label>
                            <div class="px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold font-mono text-slate-800 dark:text-white" x-text="filteredEmployees.length + ' Employees'"></div>
                        </div>
                    </div>

                    <!-- Progress Bar during simulation -->
                    <template x-if="isSimulating">
                        <div class="space-y-1.5 pt-2">
                            <div class="flex justify-between text-[11px] font-bold text-slate-600 dark:text-slate-400">
                                <span>Running Simulation...</span>
                                <span class="font-mono" x-text="simulationProgress + '%'"></span>
                            </div>
                            <div class="w-full h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                                <div class="h-full bg-gradient-to-r from-orange-500 to-rose-600 transition-all duration-150" :style="'width: ' + simulationProgress + '%'"></div>
                            </div>
                        </div>
                    </template>

                    <!-- Simulation Buttons -->
                    <div class="pt-2 flex items-center gap-3">
                        <template x-if="!isSimulating">
                            <button @click="startSimulation()" class="w-full py-2.5 rounded-xl bg-gradient-to-r from-orange-500 to-rose-600 hover:from-orange-600 hover:to-rose-700 text-white font-black text-xs shadow-md transition flex items-center justify-center gap-2 cursor-pointer">
                                <i data-lucide="play" class="w-4 h-4"></i>
                                <span>Launch Simulation Wave</span>
                            </button>
                        </template>
                        <template x-if="isSimulating">
                            <button @click="abortSimulation()" class="w-full py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-black text-xs shadow-md transition flex items-center justify-center gap-2 cursor-pointer">
                                <i data-lucide="pause" class="w-4 h-4"></i>
                                <span>Abort Simulation</span>
                            </button>
                        </template>
                    </div>
                </div>
            </div>

            <!-- 2. Performance Telemetry Metrics -->
            <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm space-y-3">
                <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                    <div class="flex items-center gap-2">
                        <i data-lucide="activity" class="w-4 h-4 text-indigo-600"></i>
                        <h4 class="font-extrabold text-slate-800 dark:text-white text-xs">Engine Telemetry & Latency</h4>
                    </div>
                    <span class="text-[10px] font-mono text-slate-400">Authoritative Rule Engine</span>
                </div>

                <div class="grid grid-cols-2 gap-3 text-xs">
                    <div class="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl space-y-1">
                        <span class="text-[10px] text-slate-400 font-bold uppercase">Avg Latency</span>
                        <div class="text-lg font-black font-mono text-slate-900 dark:text-white" x-text="telemetry.lastAvgLatencyMs + ' ms'">0 ms</div>
                    </div>
                    <div class="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl space-y-1">
                        <span class="text-[10px] text-slate-400 font-bold uppercase">Success Rate</span>
                        <div class="text-lg font-black font-mono text-emerald-600" x-text="(telemetry.lastEventCount > 0 ? Math.round((telemetry.lastSuccessCount / telemetry.lastEventCount) * 100) : 100) + '%'">100%</div>
                    </div>
                    <div class="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl space-y-1">
                        <span class="text-[10px] text-slate-400 font-bold uppercase">Last Batch Size</span>
                        <div class="text-lg font-black font-mono text-indigo-600" x-text="telemetry.lastEventCount + ' events'">0 events</div>
                    </div>
                    <div class="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl space-y-1">
                        <span class="text-[10px] text-slate-400 font-bold uppercase">Total Simulated</span>
                        <div class="text-lg font-black font-mono text-orange-600" x-text="telemetry.totalSimulatedEver">0</div>
                    </div>
                </div>
            </div>

        </div>

    </div>

    <!-- MAIN EMPLOYEE WORKFORCE MATRIX TABLE -->
    <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm overflow-hidden space-y-4">
        
        <!-- Table Filter Header -->
        <div class="p-6 border-b border-slate-100 dark:border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h3 class="font-black text-slate-900 dark:text-white text-base flex items-center gap-2">
                    <i data-lucide="users" class="w-5 h-5 text-indigo-600"></i>
                    Workforce Attendance Matrix & Quick Triggers
                </h3>
                <p class="text-xs text-slate-400">Trigger individual punch events, simulate late arrival penalties, early exits, or inspect live calculations.</p>
            </div>

            <!-- Filter Controls -->
            <div class="flex items-center gap-2.5 flex-wrap">
                <!-- Search Input -->
                <div class="relative w-44 sm:w-56">
                    <i data-lucide="search" class="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"></i>
                    <input 
                        type="text" 
                        x-model="searchQuery" 
                        placeholder="Search employee..." 
                        class="w-full pl-8 pr-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-medium focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                </div>

                <!-- Department Filter -->
                <select x-model="departmentFilter" class="px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold focus:ring-2 focus:ring-indigo-500 outline-none">
                    <option value="all">All Departments</option>
                    <template x-for="dept in departments" :key="dept.id">
                        <option :value="dept.id" x-text="dept.name"></option>
                    </template>
                </select>

                <!-- Shift Filter -->
                <select x-model="shiftFilter" class="px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold focus:ring-2 focus:ring-indigo-500 outline-none">
                    <option value="all">All Shifts</option>
                    <template x-for="sh in shifts" :key="sh.id">
                        <option :value="sh.id" x-text="sh.name"></option>
                    </template>
                </select>

                <!-- Status Filter -->
                <select x-model="statusFilter" class="px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold focus:ring-2 focus:ring-indigo-500 outline-none">
                    <option value="all">All Statuses</option>
                    <option value="present">Present Only</option>
                    <option value="late">Late Arrival Only</option>
                    <option value="absent">Absent Only</option>
                    <option value="leave">On Leave</option>
                    <option value="overtime">With Overtime</option>
                    <option value="test_records">Live Test Data Only</option>
                </select>

                <!-- Refresh -->
                <button @click="fetchRealtimeData()" :disabled="isLoading" class="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 transition cursor-pointer">
                    <i data-lucide="refresh-cw" :class="isLoading ? 'animate-spin' : ''" class="w-4 h-4"></i>
                </button>
            </div>
        </div>

        <!-- Matrix Table -->
        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs border-collapse">
                <thead>
                    <tr class="bg-slate-50/80 dark:bg-slate-800/60 border-y border-slate-100 dark:border-slate-800 font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-[10px]">
                        <th class="p-4 w-10 text-center">
                            <input type="checkbox" @change="toggleSelectAll()" :checked="selectedEmpIds.length === filteredEmployees.length && filteredEmployees.length > 0" class="rounded text-indigo-600 focus:ring-indigo-500" />
                        </th>
                        <th class="p-4">Employee Profile</th>
                        <th class="p-4">Assigned Shift</th>
                        <th class="p-4">Live Status</th>
                        <th class="p-4">Today Punches</th>
                        <th class="p-4">Calculated Metrics</th>
                        <th class="p-4">Source</th>
                        <th class="p-4 text-right">Quick Event Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                    <template x-for="emp in filteredEmployees" :key="emp.id">
                        <tr class="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
                            <!-- Checkbox -->
                            <td class="p-4 text-center">
                                <input type="checkbox" :value="emp.id" x-model="selectedEmpIds" class="rounded text-indigo-600 focus:ring-indigo-500" />
                            </td>

                            <!-- Employee Profile -->
                            <td class="p-4">
                                <div class="flex items-center gap-3">
                                    <img :src="emp.photo || emp.avatar || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150'" class="w-9 h-9 rounded-xl object-cover border border-slate-200 dark:border-slate-700" />
                                    <div>
                                        <div class="font-extrabold text-slate-900 dark:text-white" x-text="emp.name || emp.full_name || emp.first_name"></div>
                                        <div class="text-[10px] text-slate-400 font-mono" x-text="(emp.employee_code || emp.id) + ' • ' + (emp.department_name || emp.department || 'General')"></div>
                                    </div>
                                </div>
                            </td>

                            <!-- Shift -->
                            <td class="p-4">
                                <div class="font-bold text-slate-800 dark:text-white text-[11px]" x-text="emp.shift_name || 'Standard Shift'"></div>
                                <div class="text-[10px] text-slate-400 font-mono" x-text="(emp.shift_start_time || emp.start_time || '09:00') + ' - ' + (emp.shift_end_time || emp.end_time || '18:00')"></div>
                            </td>

                            <!-- Live Status -->
                            <td class="p-4">
                                <span 
                                    :class="{
                                        'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-950/60 dark:text-indigo-300': (emp.live_status || emp.status) && (emp.live_status || emp.status).startsWith('P:'),
                                        'bg-slate-100 text-slate-500 border-slate-300 dark:bg-slate-800 dark:text-slate-400': (emp.live_status || emp.status) && (emp.live_status || emp.status).includes('Before join'),
                                        'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300': ['Present', 'Present (Early Closure)', 'Early Closure Covered', 'Approved Early Closure'].includes(emp.live_status || emp.status),
                                        'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300': (emp.live_status || emp.status) === 'Late',
                                        'bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-950/60 dark:text-orange-300': (emp.live_status || emp.status) === 'Early Out' || (emp.live_status || emp.status) === 'Late & Early Out',
                                        'bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950/60 dark:text-purple-300': (emp.live_status || emp.status) === 'Half Day',
                                        'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/60 dark:text-blue-300': (emp.live_status || emp.status) && (emp.live_status || emp.status).includes('Leave'),
                                        'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/60 dark:text-rose-300': (emp.live_status || emp.status) === 'Absent',
                                        'bg-slate-100 text-slate-600 border-slate-200 dark:bg-slate-800 dark:text-slate-400': !(emp.live_status || emp.status) || (emp.live_status || emp.status) === 'Not Checked In'
                                    }" 
                                    class="px-2.5 py-1 rounded-full text-[10px] font-extrabold border inline-flex items-center gap-1"
                                    x-text="emp.live_status || emp.status || 'Not Checked In'"
                                ></span>
                            </td>

                            <!-- Punches -->
                            <td class="p-4 font-mono text-[11px]">
                                <div class="flex items-center gap-2">
                                    <span class="text-slate-400">In:</span>
                                    <strong :class="emp.check_in ? 'text-indigo-600' : 'text-slate-400'" x-text="emp.check_in || '--:--:--'"></strong>
                                </div>
                                <div class="flex items-center gap-2">
                                    <span class="text-slate-400">Out:</span>
                                    <strong :class="emp.check_out ? 'text-indigo-600' : 'text-slate-400'" x-text="emp.check_out || '--:--:--'"></strong>
                                </div>
                            </td>

                            <!-- Metrics -->
                            <td class="p-4 font-mono text-[11px]">
                                <div class="text-slate-700 dark:text-slate-300">
                                    <span class="text-slate-400">Worked:</span> 
                                    <strong class="text-emerald-600" x-text="(parseFloat(emp.working_hours || 0)).toFixed(1) + 'h'"></strong>
                                </div>
                                <template x-if="parseInt(emp.late_minutes || 0) > 0">
                                    <div class="text-amber-600 font-bold" x-text="'+' + emp.late_minutes + 'm Late'"></div>
                                </template>
                                <template x-if="parseFloat(emp.overtime_hours || 0) > 0">
                                    <div class="text-purple-600 font-bold" x-text="'+' + emp.overtime_hours + 'h OT'"></div>
                                </template>
                            </td>

                            <!-- Source -->
                            <td class="p-4">
                                <template x-if="emp.is_test_record || emp.source === 'live_test' || emp.verification_source === 'live_test'">
                                    <span class="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-orange-100 text-orange-800 border border-orange-200">live_test</span>
                                </template>
                                <template x-if="!(emp.is_test_record || emp.source === 'live_test' || emp.verification_source === 'live_test') && (emp.source || (emp.verification_source && emp.verification_source !== 'None'))">
                                    <span class="px-2 py-0.5 rounded text-[9px] font-mono text-slate-500 bg-slate-100" x-text="emp.source || emp.verification_source"></span>
                                </template>
                                <template x-if="!(emp.is_test_record || emp.source === 'live_test' || emp.verification_source === 'live_test') && !(emp.source || (emp.verification_source && emp.verification_source !== 'None'))">
                                    <span class="text-[10px] text-slate-400 font-mono">--</span>
                                </template>
                            </td>

                            <!-- Actions -->
                            <td class="p-4 text-right">
                                <div class="flex items-center justify-end gap-1.5 flex-wrap">
                                    <!-- In -->
                                    <button @click="triggerSingle(emp.id, 'CHECK_IN')" title="Instant Check-In" class="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-600 text-emerald-700 hover:text-white font-bold text-[10px] transition cursor-pointer">
                                        In
                                    </button>
                                    <!-- Out -->
                                    <button @click="triggerSingle(emp.id, 'CHECK_OUT')" title="Instant Check-Out" class="px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-600 text-rose-700 hover:text-white font-bold text-[10px] transition cursor-pointer">
                                        Out
                                    </button>
                                    <!-- Sim Late -->
                                    <button @click="triggerSingle(emp.id, 'LATE_CHECK_IN', '09:45:00')" title="Simulate Late Arrival (+45m)" class="px-2.5 py-1 rounded-lg bg-amber-50 hover:bg-amber-600 text-amber-700 hover:text-white font-bold text-[10px] transition cursor-pointer">
                                        Late
                                    </button>
                                    <!-- Full Day -->
                                    <button @click="triggerSingle(emp.id, 'MARK_PRESENT', '09:00:00')" title="Simulate Full 9-5 Day" class="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-600 text-indigo-700 hover:text-white font-bold text-[10px] transition cursor-pointer">
                                        Full
                                    </button>
                                    <!-- Reset -->
                                    <button @click="triggerSingle(emp.id, 'RESET_ATTENDANCE')" title="Reset / Clear Attendance" class="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-rose-600 transition cursor-pointer">
                                        <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    </template>
                </tbody>
            </table>
        </div>
    </div>

    <!-- REAL-TIME LIVE EVENT STREAM & CONSOLE FEED -->
    <div class="bg-slate-950 text-white rounded-3xl border border-slate-800 shadow-2xl overflow-hidden space-y-3 p-6">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2.5">
                <div class="w-3 h-3 rounded-full bg-emerald-500 animate-ping"></div>
                <div class="font-black text-sm font-mono tracking-tight flex items-center gap-2">
                    <i data-lucide="terminal" class="w-4 h-4 text-emerald-400"></i>
                    Live Engine Event Stream & Telemetry Feed
                </div>
            </div>

            <!-- Filter Stream -->
            <div class="flex items-center gap-2 text-xs">
                <button @click="streamFilter = 'all'" :class="streamFilter === 'all' ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400'" class="px-2.5 py-1 rounded-lg font-bold transition">All</button>
                <button @click="streamFilter = 'success'" :class="streamFilter === 'success' ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400'" class="px-2.5 py-1 rounded-lg font-bold transition">Success</button>
                <button @click="streamFilter = 'failed'" :class="streamFilter === 'failed' ? 'bg-rose-600 text-white' : 'bg-slate-800 text-slate-400'" class="px-2.5 py-1 rounded-lg font-bold transition">Failed</button>
                <button @click="eventStream = []" class="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-400 hover:text-white font-bold transition">Clear Feed</button>
            </div>
        </div>

        <!-- Terminal Log Box -->
        <div class="max-h-72 overflow-y-auto font-mono text-[11px] space-y-2 pr-2">
            <template x-if="filteredStream.length === 0">
                <div class="text-slate-500 text-center py-6">No live events captured yet. Trigger a single action or launch a simulation wave above to stream telemetry.</div>
            </template>

            <template x-for="item in filteredStream" :key="item.id">
                <div class="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800/80 flex items-start justify-between gap-3">
                    <div class="flex items-start gap-2.5">
                        <span :class="item.status === 'SUCCESS' ? 'text-emerald-400' : 'text-rose-400'" class="font-bold shrink-0">[<span x-text="item.status"></span>]</span>
                        <span class="text-slate-400 shrink-0" x-text="item.timestamp"></span>
                        <span class="text-indigo-400 font-bold shrink-0" x-text="'[' + item.eventType + ']'"></span>
                        <span class="text-amber-200 font-bold shrink-0" x-text="item.employeeCode + ' - ' + item.employeeName"></span>
                        <span class="text-slate-300" x-text="item.message"></span>
                        <template x-if="item.error && item.error !== item.message">
                            <span class="text-rose-400 font-semibold text-[10px] bg-rose-950/80 px-1.5 py-0.5 rounded border border-rose-800/50" x-text="'Reason: ' + item.error"></span>
                        </template>
                    </div>
                    <div class="text-right shrink-0">
                        <span class="text-emerald-400 font-bold" x-text="item.durationMs + 'ms'"></span>
                    </div>
                </div>
            </template>
        </div>
    </div>

</div>
</template>
