<!-- TAB: Staff Leave & Absence Calendar + Individual Attendance Calendar Grid -->
<?php
$calIsAdminHR      = !empty($calendarIsAdminHR);
$calUserDeptId     = (string)($calendarUserDeptId ?? '');
$calUserDeptName   = (string)($calendarUserDeptName ?? 'My Department');
$calSelectedDeptId = (string)($calendarSelectedDeptId ?? ($calIsAdminHR ? 'all' : $calUserDeptId));
$calDepts          = $calendarDepartments ?? $departments ?? [];
$calEmps           = !empty($calendarEmployees) ? $calendarEmployees : ($employees ?? []);
$calLeavesList     = $calendarLeaves ?? $leaves ?? [];
$calLeaveTypes     = $leaveTypes ?? [];
$calCompanyOff     = $companyWeeklyOff ?? \App\Services\CompanyWeekendService::getCompanyWeeklyOff($companyId ?? $userCompanyId ?? (function_exists('session') && session()->has('company_id') ? session()->get('company_id') : null));
?>
<script>
window.calendarAttendanceModule = function() {
    return {
        // Primary View Mode: 'leave_calendar' (Staff Leave & Absence Calendar Grid) | 'leave_list' (Leave Schedule Table) | 'individual' (Single Employee Attendance Grid)
        calendarMode: 'leave_calendar',

        calYear: <?= (int)$year ?>,
        calMonth: <?= (int)$month ?>,
        calEmpId: '<?= esc($selectedEmpId) ?>',

        // Role & Department Access Control Context
        isAdminHR: <?= $calIsAdminHR ? 'true' : 'false' ?>,
        userDeptId: <?= json_encode($calUserDeptId) ?>,
        userDeptName: <?= json_encode($calUserDeptName) ?>,
        selectedDeptId: <?= json_encode($calIsAdminHR ? ($calSelectedDeptId ?: 'all') : ($calUserDeptId ?: 'all')) ?>,
        selectedLeaveEmpId: 'all',
        selectedLeaveStatus: 'all', // 'all' | 'Approved' | 'Pending'
        selectedLeaveType: 'all',
        leaveSearchQuery: '',
        isLoadingLeaves: false,
        apiErrorMessage: <?= json_encode($calendarAccessNotice ?? '') ?>,

        // Datasets
        allDepartments: <?= json_encode(array_values($calDepts)) ?>,
        allCalendarEmployees: <?= json_encode(array_values($calEmps)) ?>,
        allEmployees: <?= json_encode(array_values($employees ?? [])) ?>,
        allShifts: <?= json_encode(array_values($shifts ?? [])) ?>,
        allRuleProfiles: <?= json_encode(array_values($ruleProfiles ?? [])) ?>,
        allLogs: <?= json_encode(array_values($empHistoryLogs ?? [])) ?>,
        holidays: <?= json_encode(array_values($holidays ?? [])) ?>,
        leaves: <?= json_encode(array_values($calLeavesList)) ?>,
        leaveTypes: <?= json_encode(array_values($calLeaveTypes)) ?>,

        defaultCompanyOff: <?= json_encode($calCompanyOff) ?>,
        // Designated weekly off resolution mode for Individual Attendance Grid
        offDayMode: 'auto', // 'auto' | 'friday' | 'fri_sat' | 'sat_sun' | 'sunday' | 'custom'
        customOffDays: <?= json_encode($calCompanyOff) ?>,
        viewFilter: 'all', // 'all' | 'off_days' | 'work_days' | 'discrepancies'
        selectedDayModal: null,
        selectedLeaveDayModal: null,

        weekDaysList: [
            { dayIndex: 0, shortName: 'Sun', fullName: 'Sunday' },
            { dayIndex: 1, shortName: 'Mon', fullName: 'Monday' },
            { dayIndex: 2, shortName: 'Tue', fullName: 'Tuesday' },
            { dayIndex: 3, shortName: 'Wed', fullName: 'Wednesday' },
            { dayIndex: 4, shortName: 'Thu', fullName: 'Thursday' },
            { dayIndex: 5, shortName: 'Fri', fullName: 'Friday' },
            { dayIndex: 6, shortName: 'Sat', fullName: 'Saturday' }
        ],

        /**
         * Normalize leave status strictly to 'Approved' or 'Pending'.
         * Returns null for 'Rejected', 'Cancelled', 'Withdrawn'.
         */
        normalizeLeaveStatus(rawStatus) {
            const st = String(rawStatus || '').trim().toLowerCase();
            if (['rejected', 'cancelled', 'withdrawn'].includes(st)) {
                return null;
            }
            if (st === 'approved') {
                return 'Approved';
            }
            if (st === 'pending' || st === 'endorsed') {
                return 'Pending';
            }
            return null;
        },

        /**
         * Employees visible in the Staff Leave & Absence Calendar dropdown,
         * strictly scoped by role and selected department.
         */
        get scopedLeaveEmployees() {
            const list = this.allCalendarEmployees || [];
            if (!this.isAdminHR) {
                if (!this.userDeptId) return list;
                return list.filter(e => String(e.department_id || '') === String(this.userDeptId));
            }
            if (this.selectedDeptId && this.selectedDeptId !== 'all') {
                return list.filter(e => String(e.department_id || '') === String(this.selectedDeptId));
            }
            return list;
        },

        /**
         * Authorized and filtered leave records for the active month.
         * Strictly excludes Rejected, Cancelled, and Withdrawn leaves, and enforces department scope.
         */
        get filteredStaffLeaves() {
            const mStr = String(this.calMonth).padStart(2, '0');
            const monthStart = `${this.calYear}-${mStr}-01`;
            const daysInMonth = new Date(this.calYear, this.calMonth, 0).getDate();
            const monthEnd = `${this.calYear}-${mStr}-${String(daysInMonth).padStart(2, '0')}`;
            const q = String(this.leaveSearchQuery || '').trim().toLowerCase();

            return (this.leaves || []).filter(rawLeave => {
                const normStatus = this.normalizeLeaveStatus(rawLeave.status || rawLeave.approval_status);
                if (!normStatus) {
                    return false; // Exclude Rejected, Cancelled, Withdrawn
                }

                const startDate = String(rawLeave.start_date || rawLeave.from_date || '');
                const endDate = String(rawLeave.end_date || rawLeave.to_date || startDate);
                if (!startDate || startDate > monthEnd || endDate < monthStart) {
                    return false;
                }

                const leaveDeptId = String(rawLeave.department_id || rawLeave.employee_department_id || '');

                // Strict Department Isolation for Department Manager & Employee
                if (!this.isAdminHR) {
                    if (this.userDeptId && leaveDeptId !== String(this.userDeptId)) {
                        return false;
                    }
                } else if (this.selectedDeptId && this.selectedDeptId !== 'all') {
                    if (leaveDeptId !== String(this.selectedDeptId)) {
                        return false;
                    }
                }

                if (this.selectedLeaveEmpId && this.selectedLeaveEmpId !== 'all') {
                    if (String(rawLeave.employee_id || '') !== String(this.selectedLeaveEmpId)) {
                        return false;
                    }
                }

                if (this.selectedLeaveStatus && this.selectedLeaveStatus !== 'all') {
                    if (normStatus !== this.selectedLeaveStatus) {
                        return false;
                    }
                }

                if (this.selectedLeaveType && this.selectedLeaveType !== 'all') {
                    const ltName = String(rawLeave.leave_type_name || rawLeave.leave_type || '').toLowerCase();
                    const ltCode = String(rawLeave.leave_type_code || '').toLowerCase();
                    const ltId = String(rawLeave.leave_type_id || '');
                    const targetType = String(this.selectedLeaveType).toLowerCase();
                    if (ltId !== String(this.selectedLeaveType) && !ltName.includes(targetType) && ltCode !== targetType) {
                        return false;
                    }
                }

                if (q) {
                    const empName = String(rawLeave.employee_name || `${rawLeave.first_name || ''} ${rawLeave.last_name || ''}`).toLowerCase();
                    const empCode = String(rawLeave.employee_code || rawLeave.employee_id || '').toLowerCase();
                    const deptName = String(rawLeave.department_name || '').toLowerCase();
                    const typeName = String(rawLeave.leave_type_name || rawLeave.leave_type || '').toLowerCase();
                    if (!empName.includes(q) && !empCode.includes(q) && !deptName.includes(q) && !typeName.includes(q)) {
                        return false;
                    }
                }

                return true;
            }).map(l => {
                const normStatus = this.normalizeLeaveStatus(l.status || l.approval_status) || 'Pending';
                const startDate = String(l.start_date || l.from_date || '');
                const endDate = String(l.end_date || l.to_date || startDate);
                const empName = String(l.employee_name || `${l.first_name || ''} ${l.last_name || ''}`).trim() || String(l.employee_code || l.employee_id || 'Employee');
                const deptName = String(l.department_name || this.getDepartmentNameById(l.department_id) || 'General');
                const leaveType = String(l.leave_type_name || l.leave_type || l.leave_type_code || 'Leave');
                return {
                    ...l,
                    employee_name: empName,
                    department_name: deptName,
                    leave_type: leaveType,
                    leave_type_name: leaveType,
                    start_date: startDate,
                    end_date: endDate,
                    from_date: startDate,
                    to_date: endDate,
                    status: normStatus,
                    approval_status: normStatus
                };
            });
        },

        getDepartmentNameById(deptId) {
            if (!deptId) return '';
            const found = (this.allDepartments || []).find(d => String(d.id) === String(deptId));
            return found ? found.name : '';
        },

        /**
         * 7-column Monthly Grid for Staff Leave & Absence Calendar
         */
        get staffLeaveCalendarDays() {
            const daysInMonth = new Date(this.calYear, this.calMonth, 0).getDate();
            const firstDayIndexCol = new Date(this.calYear, this.calMonth - 1, 1).getDay();
            const days = [];
            const designatedOffs = this.defaultCompanyOff && this.defaultCompanyOff.length > 0 ? this.defaultCompanyOff : ['Friday'];
            const todayStr = new Date().toISOString().slice(0, 10);
            const activeLeaves = this.filteredStaffLeaves;

            for (let i = 0; i < firstDayIndexCol; i++) {
                days.push({ day: '', dateStr: '', isBlank: true, leaves: [] });
            }

            for (let d = 1; d <= daysInMonth; d++) {
                const dateStr = `${this.calYear}-${String(this.calMonth).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
                const dateObj = new Date(this.calYear, this.calMonth - 1, d, 12, 0, 0);
                const dowIndex = dateObj.getDay();
                const dayNameFull = this.weekDaysList[dowIndex].fullName;
                const dayNameShort = this.weekDaysList[dowIndex].shortName;
                const isDesignatedWeeklyOff = designatedOffs.includes(dayNameFull);

                const holiday = (this.holidays || []).find(h => {
                    if (h.date === dateStr) return true;
                    if (h.from_date && h.to_date && dateStr >= h.from_date && dateStr <= h.to_date) return true;
                    return false;
                });

                const dayLeaves = activeLeaves.filter(lv => dateStr >= lv.start_date && dateStr <= lv.end_date);
                const approvedDayCount = dayLeaves.filter(lv => lv.status === 'Approved').length;
                const pendingDayCount = dayLeaves.filter(lv => lv.status === 'Pending').length;

                days.push({
                    day: d,
                    dateStr,
                    dayOfWeek: dayNameShort,
                    dayFullName: dayNameFull,
                    isBlank: false,
                    isDesignatedWeeklyOff,
                    isToday: dateStr === todayStr,
                    holiday: holiday ? (holiday.name || 'Public Holiday') : null,
                    leaves: dayLeaves,
                    leaveCount: dayLeaves.length,
                    approvedCount: approvedDayCount,
                    pendingCount: pendingDayCount
                });
            }

            return days;
        },

        /**
         * Summary metrics for Staff Leave & Absence Calendar
         */
        get staffLeaveSummary() {
            const list = this.filteredStaffLeaves;
            const todayStr = new Date().toISOString().slice(0, 10);
            const approved = list.filter(l => l.status === 'Approved').length;
            const pending = list.filter(l => l.status === 'Pending').length;
            const onLeaveToday = list.filter(l => todayStr >= l.start_date && todayStr <= l.end_date);
            const uniqueEmployeesOnLeave = new Set(list.map(l => String(l.employee_id))).size;

            return {
                totalApplications: list.length,
                approvedCount: approved,
                pendingCount: pending,
                onLeaveTodayCount: onLeaveToday.length,
                onLeaveTodayList: onLeaveToday,
                uniqueEmployeesOnLeave,
                authorizedStaffCount: this.scopedLeaveEmployees.length
            };
        },

        /**
         * Fetch live Role & Department scoped calendar leaves from backend API
         */
        async fetchStaffCalendarLeaves() {
            this.isLoadingLeaves = true;
            this.apiErrorMessage = '';
            try {
                const params = new URLSearchParams({
                    year: String(this.calYear),
                    month: String(this.calMonth)
                });
                if (this.isAdminHR) {
                    if (this.selectedDeptId && this.selectedDeptId !== 'all') {
                        params.set('department_id', String(this.selectedDeptId));
                    }
                } else if (this.userDeptId) {
                    params.set('department_id', String(this.userDeptId));
                }

                const res = await fetch(`<?= base_url('attendance/calendar-leaves-ajax') ?>?${params.toString()}`, {
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });
                const json = await res.json();
                if (!res.ok || !json || json.success !== true) {
                    this.apiErrorMessage = (json && json.message) ? json.message : 'Unable to load leave calendar data for the requested scope.';
                    if (!this.isAdminHR && this.userDeptId) {
                        this.selectedDeptId = this.userDeptId;
                    }
                    return;
                }
                if (json.data) {
                    if (Array.isArray(json.data.leaves)) {
                        this.leaves = json.data.leaves;
                    }
                    if (Array.isArray(json.data.employees)) {
                        this.allCalendarEmployees = json.data.employees;
                    }
                    if (Array.isArray(json.data.departments)) {
                        this.allDepartments = json.data.departments;
                    }
                    if (Array.isArray(json.data.weekly_off_days) && json.data.weekly_off_days.length > 0) {
                        this.defaultCompanyOff = json.data.weekly_off_days;
                    }
                }
            } catch (err) {
                console.error('Staff Leave Calendar fetch error:', err);
            } finally {
                this.isLoadingLeaves = false;
            }
        },

        onDepartmentChange() {
            if (!this.isAdminHR && this.userDeptId) {
                this.selectedDeptId = this.userDeptId;
            }
            this.selectedLeaveEmpId = 'all';
            this.fetchStaffCalendarLeaves();
        },

        resetLeaveFilters() {
            this.leaveSearchQuery = '';
            this.selectedLeaveStatus = 'all';
            this.selectedLeaveType = 'all';
            this.selectedLeaveEmpId = 'all';
            if (this.isAdminHR) {
                this.selectedDeptId = 'all';
                this.fetchStaffCalendarLeaves();
            } else if (this.userDeptId) {
                this.selectedDeptId = this.userDeptId;
            }
        },

        openLeaveDayModal(cell) {
            if (!cell || cell.isBlank) return;
            this.selectedLeaveDayModal = cell;
        },

        closeLeaveDayModal() {
            this.selectedLeaveDayModal = null;
        },

        // =========================================================================
        // INDIVIDUAL EMPLOYEE ATTENDANCE CALENDAR COMPUTED PROPERTIES
        // =========================================================================
        get currentEmployee() {
            if (!this.allEmployees || this.allEmployees.length === 0) return null;
            return this.allEmployees.find(e => String(e.id) === String(this.calEmpId)) || this.allEmployees[0];
        },

        get currentShift() {
            const emp = this.currentEmployee;
            if (!emp || !this.allShifts || this.allShifts.length === 0) return null;
            const shiftId = emp.shift_id || emp.shiftId;
            return this.allShifts.find(s => String(s.id) === String(shiftId)) || this.allShifts[0];
        },

        get designatedOffDays() {
            if (this.offDayMode === 'friday') return ['Friday'];
            if (this.offDayMode === 'fri_sat') return ['Friday', 'Saturday'];
            if (this.offDayMode === 'sat_sun') return ['Saturday', 'Sunday'];
            if (this.offDayMode === 'sunday') return ['Sunday'];
            if (this.offDayMode === 'custom') return this.customOffDays;

            const emp = this.currentEmployee;
            if (emp) {
                if (emp.weekly_off_days && Array.isArray(emp.weekly_off_days) && emp.weekly_off_days.length > 0) {
                    return emp.weekly_off_days;
                }
                const shift = this.currentShift;
                if (shift && shift.weekly_off_array && Array.isArray(shift.weekly_off_array) && shift.weekly_off_array.length > 0) {
                    return shift.weekly_off_array;
                }
                if (this.allRuleProfiles && this.allRuleProfiles.length > 0) {
                    const matchedProfile = this.allRuleProfiles.find(p => {
                        if (p.scopeLevel === 'Employee' && String(p.scopeId) === String(emp.id)) return true;
                        if (p.scopeLevel === 'Shift' && String(p.scopeId) === String(emp.shift_id)) return true;
                        if (p.scopeLevel === 'Department' && String(p.scopeId) === String(emp.department_id)) return true;
                        if (p.scopeLevel === 'Company' || p.scopeLevel === 'Global') return true;
                        return false;
                    });
                    if (matchedProfile && matchedProfile.workingWeek && matchedProfile.workingWeek.weeklyOffDays) {
                        return matchedProfile.workingWeek.weeklyOffDays;
                    }
                }
            }
            return this.defaultCompanyOff && this.defaultCompanyOff.length > 0 ? this.defaultCompanyOff : [];
        },

        get monthName() {
            return new Date(this.calYear, this.calMonth - 1, 1).toLocaleString('en-US', { month: 'long', year: 'numeric' });
        },

        get weekHeaderList() {
            const offs = this.designatedOffDays;
            return this.weekDaysList.map(d => ({
                ...d,
                isOff: offs.includes(d.fullName)
            }));
        },

        get calendarDays() {
            const daysInMonth = new Date(this.calYear, this.calMonth, 0).getDate();
            const firstDayIndexCol = new Date(this.calYear, this.calMonth - 1, 1).getDay();
            const days = [];
            const designatedOffs = this.designatedOffDays;
            const todayStr = new Date().toISOString().slice(0, 10);

            for (let i = 0; i < firstDayIndexCol; i++) {
                days.push({ day: '', dateStr: '', isBlank: true });
            }

            for (let d = 1; d <= daysInMonth; d++) {
                const dateStr = `${this.calYear}-${String(this.calMonth).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
                const dateObj = new Date(this.calYear, this.calMonth - 1, d, 12, 0, 0);
                const dowIndex = dateObj.getDay();
                const dayNameFull = this.weekDaysList[dowIndex].fullName;
                const dayNameShort = this.weekDaysList[dowIndex].shortName;
                const isDesignatedWeeklyOff = designatedOffs.includes(dayNameFull);

                const holiday = (this.holidays || []).find(h => {
                    if (h.date === dateStr) return true;
                    if (h.from_date && h.to_date && dateStr >= h.from_date && dateStr <= h.to_date) return true;
                    return false;
                });

                const leave = (this.leaves || []).find(l => {
                    if (String(l.employee_id) !== String(this.calEmpId)) return false;
                    const normSt = this.normalizeLeaveStatus(l.status || l.approval_status);
                    if (!normSt) return false;
                    const s = l.start_date || l.from_date;
                    const e = l.end_date || l.to_date || s;
                    return dateStr >= s && dateStr <= e;
                });

                const log = (this.allLogs || []).find(l =>
                    (String(l.employee_id) === String(this.calEmpId) || String(l.employee_code) === String(this.calEmpId)) &&
                    l.date === dateStr
                );

                const hasPunchedIn = !!(log && log.check_in && log.check_in !== '--:--:--' && log.check_in !== '---');
                const isPast = dateStr < todayStr;
                const isToday = dateStr === todayStr;

                let status = 'Scheduled';
                let statusLabel = 'Scheduled Work Day';
                let isOffDayDuty = false;

                if (hasPunchedIn) {
                    if (isDesignatedWeeklyOff) {
                        status = 'Weekly Off (Worked)';
                        statusLabel = 'Off-Day Duty';
                        isOffDayDuty = true;
                    } else if (holiday) {
                        status = 'Holiday (Worked)';
                        statusLabel = 'Holiday Duty';
                    } else {
                        status = log.status || 'Present';
                        statusLabel = status;
                    }
                } else {
                    if (holiday) {
                        status = 'Holiday';
                        statusLabel = holiday.name || 'Public Holiday';
                    } else if (leave) {
                        const leaveSt = this.normalizeLeaveStatus(leave.status || leave.approval_status) || 'Approved';
                        status = leaveSt === 'Pending' ? 'Leave Pending' : 'On Leave';
                        statusLabel = `${leave.leave_type_name || leave.leave_type || 'Leave'} (${leaveSt})`;
                    } else if (isDesignatedWeeklyOff) {
                        status = 'Weekly Off';
                        statusLabel = 'Designated Off Day';
                    } else if (isPast) {
                        status = 'Absent';
                        statusLabel = 'Absent';
                    } else if (isToday) {
                        status = 'Not Recorded';
                        statusLabel = 'Not Clocked In';
                    } else {
                        status = 'Scheduled';
                        statusLabel = 'Upcoming Work Day';
                    }
                }

                days.push({
                    day: d,
                    dateStr,
                    dayOfWeek: dayNameShort,
                    dayFullName: dayNameFull,
                    isBlank: false,
                    isDesignatedWeeklyOff,
                    isOffDayDuty,
                    isToday,
                    isPast,
                    holiday: holiday ? (holiday.name || 'Public Holiday') : null,
                    leave: leave ? (leave.leave_type_name || leave.leave_type || 'Leave') : null,
                    leaveStatus: leave ? (this.normalizeLeaveStatus(leave.status || leave.approval_status) || 'Approved') : null,
                    log: log || null,
                    status,
                    statusLabel
                });
            }

            return days;
        },

        get monthSummary() {
            const days = this.calendarDays.filter(d => !d.isBlank);
            const totalCalendarDays = days.length;
            let designatedOffsCount = 0;
            let holidaysCount = 0;
            let leavesCount = 0;
            let presentCount = 0;
            let offDayWorkedCount = 0;
            let lateCount = 0;
            let absentCount = 0;
            let totalHoursWorked = 0;
            let totalOvertimeHours = 0;

            days.forEach(d => {
                if (d.isDesignatedWeeklyOff) designatedOffsCount++;
                if (d.holiday && !d.isDesignatedWeeklyOff) holidaysCount++;
                if (d.leave) leavesCount++;
                if (d.isOffDayDuty) offDayWorkedCount++;

                if (d.log && d.log.check_in && d.log.check_in !== '--:--:--') {
                    if (['Present', 'Present (Early Closure)', 'Early Closure Covered', 'Approved Early Closure', 'Late', 'Half Day', 'Early Out', 'Weekly Off (Worked)', 'Holiday (Worked)'].includes(d.status)) {
                        presentCount++;
                    }
                    if (d.status === 'Late' || (d.log.late_minutes && parseInt(d.log.late_minutes) > 0)) {
                        lateCount++;
                    }
                    totalHoursWorked += parseFloat(d.log.working_hours || 0);
                    totalOvertimeHours += parseFloat(d.log.overtime_hours || 0);
                } else if (d.status === 'Absent') {
                    absentCount++;
                }
            });

            const scheduledWorkDays = Math.max(0, totalCalendarDays - designatedOffsCount - holidaysCount);

            return {
                totalCalendarDays,
                designatedOffsCount,
                holidaysCount,
                leavesCount,
                scheduledWorkDays,
                presentCount,
                offDayWorkedCount,
                lateCount,
                absentCount,
                totalHoursWorked: totalHoursWorked.toFixed(1),
                totalOvertimeHours: totalOvertimeHours.toFixed(1)
            };
        },

        get filteredCalendarDays() {
            if (this.viewFilter === 'all') return this.calendarDays;
            if (this.viewFilter === 'off_days') {
                return this.calendarDays.map(d => d.isBlank ? d : (d.isDesignatedWeeklyOff ? d : { ...d, isDimmed: true }));
            }
            if (this.viewFilter === 'work_days') {
                return this.calendarDays.map(d => d.isBlank ? d : (!d.isDesignatedWeeklyOff ? d : { ...d, isDimmed: true }));
            }
            if (this.viewFilter === 'discrepancies') {
                return this.calendarDays.map(d => d.isBlank ? d : ((d.status === 'Absent' || d.isOffDayDuty || d.status === 'Late') ? d : { ...d, isDimmed: true }));
            }
            return this.calendarDays;
        },

        prevMonth() {
            if (this.calMonth === 1) {
                this.calMonth = 12;
                this.calYear--;
            } else {
                this.calMonth--;
            }
            this.fetchStaffCalendarLeaves();
        },

        nextMonth() {
            if (this.calMonth === 12) {
                this.calMonth = 1;
                this.calYear++;
            } else {
                this.calMonth++;
            }
            this.fetchStaffCalendarLeaves();
        },

        goToCurrentMonth() {
            const now = new Date();
            this.calYear = now.getFullYear();
            this.calMonth = now.getMonth() + 1;
            this.fetchStaffCalendarLeaves();
        },

        openDayModal(cell) {
            if (!cell || cell.isBlank) return;
            this.selectedDayModal = cell;
        },

        closeDayModal() {
            this.selectedDayModal = null;
        }
    };
};
</script>

<div x-show="activeTab === 'calendar'" class="space-y-6 animate-in fade-in duration-200" x-data="calendarAttendanceModule()">

    <!-- ACCESS CONTROL / SECURITY ALERT BANNER -->
    <template x-if="apiErrorMessage">
        <div class="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 flex items-center justify-between gap-3 text-xs text-rose-800 dark:text-rose-200">
            <div class="flex items-center gap-2.5">
                <i data-lucide="shield-alert" class="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0"></i>
                <span class="font-bold" x-text="apiErrorMessage"></span>
            </div>
            <button @click="apiErrorMessage = ''" class="text-rose-500 hover:text-rose-700 font-bold cursor-pointer">Dismiss</button>
        </div>
    </template>

    <!-- HEADER & MODE SWITCHER BAR -->
    <div class="bg-white dark:bg-slate-900 p-5 sm:p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-5">
        <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
            <div class="flex items-start sm:items-center gap-3.5">
                <div class="w-12 h-12 rounded-2xl bg-indigo-600/10 dark:bg-indigo-500/20 border border-indigo-200/60 dark:border-indigo-800/60 flex items-center justify-center text-indigo-600 dark:text-indigo-400 shrink-0">
                    <i data-lucide="calendar-days" class="w-6 h-6"></i>
                </div>
                <div class="space-y-1">
                    <div class="flex items-center gap-2 flex-wrap">
                        <h2 class="text-lg font-black text-slate-900 dark:text-white tracking-tight">Staff Leave & Absence Calendar</h2>
                        <template x-if="isAdminHR">
                            <span class="px-2.5 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 text-[11px] font-extrabold">
                                Company-Wide Authorized Access (Admin / HR)
                            </span>
                        </template>
                        <template x-if="!isAdminHR">
                            <span class="px-2.5 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 text-[11px] font-extrabold">
                                Department Access Only: <span x-text="userDeptName || 'Own Department'"></span>
                            </span>
                        </template>
                    </div>
                    <p class="text-xs text-slate-500 dark:text-slate-400">
                        <span x-show="isAdminHR">View company-wide employee leave schedules, filter by department, and inspect Leave Date, Employee Name, Department, Leave Type, and Approval Status (Approved / Pending).</span>
                        <span x-show="!isAdminHR">View leave schedule and approval status (Approved / Pending) strictly for staff members within your own department (<strong class="text-slate-700 dark:text-slate-200" x-text="userDeptName || 'Own Department'"></strong>).</span>
                    </p>
                </div>
            </div>

            <!-- Mode Switcher + Month Navigation -->
            <div class="flex flex-wrap items-center gap-2.5">
                <div class="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl border border-slate-200 dark:border-slate-700">
                    <button
                        type="button"
                        @click="calendarMode = 'leave_calendar'"
                        :class="calendarMode === 'leave_calendar' ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs font-extrabold' : 'text-slate-600 dark:text-slate-400 font-semibold'"
                        class="px-3 py-1.5 rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5"
                    >
                        <i data-lucide="calendar" class="w-3.5 h-3.5"></i>
                        <span>Leave Calendar</span>
                    </button>
                    <button
                        type="button"
                        @click="calendarMode = 'leave_list'"
                        :class="calendarMode === 'leave_list' ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs font-extrabold' : 'text-slate-600 dark:text-slate-400 font-semibold'"
                        class="px-3 py-1.5 rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5"
                    >
                        <i data-lucide="table" class="w-3.5 h-3.5"></i>
                        <span>Leave Schedule (<span x-text="filteredStaffLeaves.length"></span>)</span>
                    </button>
                    <button
                        type="button"
                        @click="calendarMode = 'individual'"
                        :class="calendarMode === 'individual' ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs font-extrabold' : 'text-slate-600 dark:text-slate-400 font-semibold'"
                        class="px-3 py-1.5 rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5"
                    >
                        <i data-lucide="user-check" class="w-3.5 h-3.5"></i>
                        <span>Attendance Grid</span>
                    </button>
                </div>

                <!-- Month Navigator -->
                <div class="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl border border-slate-200 dark:border-slate-700">
                    <button type="button" @click="prevMonth()" class="p-2 rounded-xl hover:bg-white dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition cursor-pointer" title="Previous Month">
                        <i data-lucide="chevron-left" class="w-4 h-4"></i>
                    </button>
                    <span class="text-xs sm:text-sm font-black text-slate-900 dark:text-white font-mono min-w-32 text-center" x-text="monthName"></span>
                    <button type="button" @click="nextMonth()" class="p-2 rounded-xl hover:bg-white dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition cursor-pointer" title="Next Month">
                        <i data-lucide="chevron-right" class="w-4 h-4"></i>
                    </button>
                </div>

                <button type="button" @click="goToCurrentMonth()" class="px-3 py-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 font-bold text-xs transition cursor-pointer flex items-center gap-1.5 border border-indigo-200 dark:border-indigo-800">
                    <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i>
                    <span>Current Month</span>
                </button>
            </div>
        </div>

        <!-- =================================================================== -->
        <!-- STAFF LEAVE & ABSENCE CALENDAR FILTERS (leave_calendar / leave_list) -->
        <!-- =================================================================== -->
        <div x-show="calendarMode === 'leave_calendar' || calendarMode === 'leave_list'" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            <!-- 1. Department Filter (Enabled for Admin/HR, Locked to Own Department for Manager/Employee) -->
            <div>
                <label class="block font-bold text-slate-600 dark:text-slate-400 text-[11px] uppercase tracking-wider mb-1">
                    Department
                    <span x-show="!isAdminHR" class="text-emerald-600 dark:text-emerald-400 font-extrabold">(Own Dept Locked)</span>
                </label>
                <template x-if="isAdminHR">
                    <select
                        x-model="selectedDeptId"
                        @change="onDepartmentChange()"
                        class="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white font-bold text-xs focus:ring-2 focus:ring-indigo-500 outline-hidden cursor-pointer"
                    >
                        <option value="all">All Departments (Company-Wide)</option>
                        <template x-for="d in allDepartments" :key="d.id">
                            <option :value="d.id" x-text="d.name"></option>
                        </template>
                    </select>
                </template>
                <template x-if="!isAdminHR">
                    <div class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs flex items-center justify-between">
                        <span class="truncate" x-text="userDeptName || 'My Department'"></span>
                        <span class="px-1.5 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-[10px] font-extrabold uppercase">Scoped</span>
                    </div>
                </template>
            </div>

            <!-- 2. Employee Filter (Scoped to Authorized Department) -->
            <div>
                <label class="block font-bold text-slate-600 dark:text-slate-400 text-[11px] uppercase tracking-wider mb-1">Employee</label>
                <select
                    x-model="selectedLeaveEmpId"
                    class="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white font-bold text-xs focus:ring-2 focus:ring-indigo-500 outline-hidden cursor-pointer"
                >
                    <option value="all" x-text="isAdminHR ? 'All Authorized Employees' : 'All Staff in My Department'"></option>
                    <template x-for="emp in scopedLeaveEmployees" :key="emp.id">
                        <option :value="emp.id" x-text="(emp.name || (emp.first_name + ' ' + emp.last_name)) + ' (' + (emp.employee_code || emp.id) + ')'"></option>
                    </template>
                </select>
            </div>

            <!-- 3. Leave Type Filter -->
            <div>
                <label class="block font-bold text-slate-600 dark:text-slate-400 text-[11px] uppercase tracking-wider mb-1">Leave Type</label>
                <select
                    x-model="selectedLeaveType"
                    class="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white font-bold text-xs focus:ring-2 focus:ring-indigo-500 outline-hidden cursor-pointer"
                >
                    <option value="all">All Leave Types</option>
                    <template x-for="lt in leaveTypes" :key="lt.id || lt.code || lt.name">
                        <option :value="lt.name || lt.code" x-text="lt.name || lt.code"></option>
                    </template>
                </select>
            </div>

            <!-- 4. Approval Status Filter (Strictly Approved / Pending) -->
            <div>
                <label class="block font-bold text-slate-600 dark:text-slate-400 text-[11px] uppercase tracking-wider mb-1">Approval Status</label>
                <select
                    x-model="selectedLeaveStatus"
                    class="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white font-bold text-xs focus:ring-2 focus:ring-indigo-500 outline-hidden cursor-pointer"
                >
                    <option value="all">All (Approved & Pending)</option>
                    <option value="Approved">Approved Only</option>
                    <option value="Pending">Pending Only</option>
                </select>
            </div>

            <!-- 5. Search & Reset -->
            <div>
                <label class="block font-bold text-slate-600 dark:text-slate-400 text-[11px] uppercase tracking-wider mb-1">Search Staff / Leave</label>
                <div class="flex items-center gap-1.5">
                    <input
                        type="text"
                        x-model="leaveSearchQuery"
                        placeholder="Name, ID, Dept, Type..."
                        class="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white font-semibold text-xs focus:ring-2 focus:ring-indigo-500 outline-hidden"
                    >
                    <button
                        type="button"
                        @click="resetLeaveFilters()"
                        class="px-2.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-slate-600 hover:text-rose-600 text-xs font-bold transition cursor-pointer shrink-0"
                        title="Reset Filters"
                    >
                        Reset
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- ======================================================================= -->
    <!-- MODE 1 & 2: STAFF LEAVE & ABSENCE CALENDAR (GRID & SCHEDULE TABLE)      -->
    <!-- ======================================================================= -->
    <div x-show="calendarMode === 'leave_calendar' || calendarMode === 'leave_list'" class="space-y-6">

        <!-- KPI SUMMARY CARDS -->
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            <div class="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
                <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Total Leave Records</span>
                <div class="text-xl font-black font-mono text-slate-900 dark:text-white" x-text="staffLeaveSummary.totalApplications"></div>
                <span class="text-[10px] text-slate-500 font-medium" x-text="monthName"></span>
            </div>

            <div class="bg-emerald-50/50 dark:bg-emerald-950/20 p-4 rounded-2xl border border-emerald-200/80 dark:border-emerald-900/60 shadow-xs">
                <span class="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider block mb-1">Approved Leaves</span>
                <div class="text-xl font-black font-mono text-emerald-700 dark:text-emerald-300" x-text="staffLeaveSummary.approvedCount"></div>
                <span class="text-[10px] text-emerald-600/80 dark:text-emerald-400/80 font-medium">Confirmed Absences</span>
            </div>

            <div class="bg-amber-50/50 dark:bg-amber-950/20 p-4 rounded-2xl border border-amber-200/80 dark:border-amber-900/60 shadow-xs">
                <span class="text-[10px] font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider block mb-1">Pending Leaves</span>
                <div class="text-xl font-black font-mono text-amber-700 dark:text-amber-300" x-text="staffLeaveSummary.pendingCount"></div>
                <span class="text-[10px] text-amber-600/80 dark:text-amber-400/80 font-medium">Awaiting Approval</span>
            </div>

            <div class="bg-rose-50/50 dark:bg-rose-950/20 p-4 rounded-2xl border border-rose-200/80 dark:border-rose-900/60 shadow-xs">
                <span class="text-[10px] font-bold text-rose-600 dark:text-rose-400 uppercase tracking-wider block mb-1">On Leave Today</span>
                <div class="text-xl font-black font-mono text-rose-700 dark:text-rose-300" x-text="staffLeaveSummary.onLeaveTodayCount"></div>
                <span class="text-[10px] text-rose-600/80 dark:text-rose-400/80 font-medium">Active Date Overlap</span>
            </div>

            <div class="bg-indigo-50/50 dark:bg-indigo-950/20 p-4 rounded-2xl border border-indigo-200/80 dark:border-indigo-900/60 shadow-xs">
                <span class="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider block mb-1" x-text="isAdminHR ? 'Scoped Staff' : 'Department Staff'"></span>
                <div class="text-xl font-black font-mono text-indigo-700 dark:text-indigo-300" x-text="staffLeaveSummary.authorizedStaffCount"></div>
                <span class="text-[10px] text-indigo-600/80 dark:text-indigo-400/80 font-medium" x-text="staffLeaveSummary.uniqueEmployeesOnLeave + ' staff with leave'"></span>
            </div>
        </div>

        <!-- VIEW A: STAFF LEAVE & ABSENCE CALENDAR 7-COLUMN GRID -->
        <div x-show="calendarMode === 'leave_calendar'" class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm p-4 sm:p-6 overflow-hidden space-y-4">
            <div class="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-100 dark:border-slate-800 text-[11px]">
                <div class="flex items-center gap-3 flex-wrap text-slate-600 dark:text-slate-400">
                    <span class="font-bold text-slate-400 uppercase tracking-wider text-[10px]">Status Legend:</span>
                    <span class="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 font-bold">
                        <span class="w-2 h-2 rounded-full bg-emerald-500"></span> Approved Leave
                    </span>
                    <span class="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 font-bold">
                        <span class="w-2 h-2 rounded-full bg-amber-500"></span> Pending Leave
                    </span>
                    <span class="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 border border-sky-200 dark:border-sky-800 font-bold">
                        <span class="w-2 h-2 rounded-full bg-sky-500"></span> Public Holiday
                    </span>
                    <span class="text-slate-400 dark:text-slate-500 italic">
                        * Rejected, Cancelled, and Withdrawn leaves are hidden.
                    </span>
                </div>
                <span x-show="isLoadingLeaves" class="text-xs font-bold text-indigo-600 dark:text-indigo-400 animate-pulse">Refreshing calendar...</span>
            </div>

            <!-- Day Names Header -->
            <div class="grid grid-cols-7 gap-2 text-center">
                <template x-for="head in weekDaysList" :key="head.fullName">
                    <div
                        :class="(defaultCompanyOff || []).includes(head.fullName)
                            ? 'bg-indigo-50/80 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 border-b-2 border-indigo-500'
                            : 'bg-slate-50/80 dark:bg-slate-800/50 text-slate-600 dark:text-slate-300'"
                        class="py-2.5 rounded-xl text-xs font-black uppercase tracking-wider"
                    >
                        <span x-text="head.shortName"></span>
                    </div>
                </template>
            </div>

            <!-- Calendar Cells -->
            <div class="grid grid-cols-7 gap-2">
                <template x-for="(cell, idx) in staffLeaveCalendarDays" :key="idx">
                    <div>
                        <template x-if="cell.isBlank">
                            <div class="min-h-36 rounded-2xl bg-slate-50/40 dark:bg-slate-800/20 border border-dashed border-slate-200/40 dark:border-slate-800/40"></div>
                        </template>

                        <template x-if="!cell.isBlank">
                            <div
                                @click="openLeaveDayModal(cell)"
                                :class="{
                                    'border-indigo-500 ring-2 ring-indigo-500/30': cell.isToday,
                                    'border-sky-200 dark:border-sky-900/60 bg-sky-50/30 dark:bg-sky-950/15': cell.holiday,
                                    'border-slate-200/80 dark:border-slate-800 bg-slate-50/40 dark:bg-slate-800/20': cell.isDesignatedWeeklyOff && !cell.holiday,
                                    'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900': !cell.isDesignatedWeeklyOff && !cell.holiday
                                }"
                                class="min-h-36 p-2.5 rounded-2xl border flex flex-col justify-between cursor-pointer hover:shadow-md transition relative overflow-hidden"
                            >
                                <!-- Top Row: Date number + count badge -->
                                <div class="flex items-center justify-between gap-1 mb-1.5">
                                    <div class="flex items-center gap-1">
                                        <span
                                            :class="cell.isToday ? 'bg-indigo-600 text-white' : (cell.isDesignatedWeeklyOff ? 'text-indigo-600 dark:text-indigo-400 font-black' : 'text-slate-800 dark:text-white font-bold')"
                                            class="text-xs font-mono px-1.5 py-0.5 rounded-md"
                                            x-text="cell.day"
                                        ></span>
                                        <span x-show="cell.isDesignatedWeeklyOff" class="text-[9px] font-bold text-indigo-500">Off</span>
                                    </div>
                                    <template x-if="cell.leaveCount > 0">
                                        <span class="px-1.5 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 text-[9px] font-extrabold" x-text="cell.leaveCount + ' on leave'"></span>
                                    </template>
                                </div>

                                <!-- Holiday Banner if applicable -->
                                <template x-if="cell.holiday">
                                    <div class="mb-1 px-1.5 py-0.5 rounded bg-sky-100/80 dark:bg-sky-900/50 text-sky-800 dark:text-sky-200 text-[9px] font-bold truncate" :title="cell.holiday" x-text="cell.holiday"></div>
                                </template>

                                <!-- Staff Leave Entries on this Date -->
                                <div class="space-y-1 flex-1 overflow-hidden">
                                    <template x-for="lv in cell.leaves.slice(0, 3)" :key="lv.id + '-' + cell.dateStr">
                                        <div
                                            :class="lv.status === 'Approved'
                                                ? 'bg-emerald-50/90 dark:bg-emerald-950/50 border-emerald-200 dark:border-emerald-800/80 text-emerald-900 dark:text-emerald-200'
                                                : 'bg-amber-50/90 dark:bg-amber-950/50 border-amber-200 dark:border-amber-800/80 text-amber-900 dark:text-amber-200'"
                                            class="p-1.5 rounded-xl border text-[10px] leading-tight space-y-0.5"
                                        >
                                            <div class="flex items-center justify-between gap-1">
                                                <span class="font-extrabold truncate" x-text="lv.employee_name"></span>
                                                <span
                                                    :class="lv.status === 'Approved'
                                                        ? 'bg-emerald-600 text-white'
                                                        : 'bg-amber-500 text-white'"
                                                    class="px-1 py-0.2 rounded text-[8px] font-black uppercase shrink-0"
                                                    x-text="lv.status"
                                                ></span>
                                            </div>
                                            <div class="text-[9px] opacity-85 truncate">
                                                <span class="font-semibold" x-text="lv.department_name"></span> • <span x-text="lv.leave_type_name"></span>
                                            </div>
                                            <div class="text-[8px] font-mono opacity-75 truncate" x-text="lv.start_date + ' → ' + lv.end_date"></div>
                                        </div>
                                    </template>

                                    <template x-if="cell.leaves.length > 3">
                                        <div class="text-[10px] font-extrabold text-indigo-600 dark:text-indigo-400 text-center pt-0.5">
                                            +<span x-text="cell.leaves.length - 3"></span> more staff...
                                        </div>
                                    </template>

                                    <template x-if="cell.leaves.length === 0 && !cell.holiday">
                                        <div class="text-[10px] text-slate-300 dark:text-slate-600 pt-4 text-center">No Leave</div>
                                    </template>
                                </div>
                            </div>
                        </template>
                    </div>
                </template>
            </div>
        </div>

        <!-- VIEW B: STAFF LEAVE SCHEDULE TABLE (Complete List of Approved & Pending Leaves) -->
        <div x-show="calendarMode === 'leave_list'" class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm overflow-hidden">
            <div class="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <div>
                    <h3 class="text-sm font-black text-slate-900 dark:text-white">
                        Authorized Leave Schedule — <span x-text="monthName"></span>
                    </h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">
                        Showing Employee Name, Department, Leave Type, Start Date & End Date, and Leave Status (Approved / Pending).
                    </p>
                </div>
                <span class="px-3 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold" x-text="filteredStaffLeaves.length + ' Records'"></span>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="bg-slate-50/80 dark:bg-slate-800/50 border-b border-slate-100 dark:border-slate-800 text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                            <th class="py-3.5 px-4">Employee Name</th>
                            <th class="py-3.5 px-4">Department</th>
                            <th class="py-3.5 px-4">Leave Type</th>
                            <th class="py-3.5 px-4">Leave Start Date</th>
                            <th class="py-3.5 px-4">Leave End Date</th>
                            <th class="py-3.5 px-4 text-center">Days</th>
                            <th class="py-3.5 px-4 text-right">Approval Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                        <template x-for="lv in filteredStaffLeaves" :key="lv.id">
                            <tr class="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition">
                                <td class="py-3.5 px-4">
                                    <div class="font-bold text-slate-900 dark:text-white" x-text="lv.employee_name"></div>
                                    <div class="text-[11px] text-slate-400 font-mono" x-text="lv.employee_code || lv.employee_id"></div>
                                </td>
                                <td class="py-3.5 px-4 font-semibold text-slate-700 dark:text-slate-300" x-text="lv.department_name"></td>
                                <td class="py-3.5 px-4">
                                    <span class="px-2.5 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-bold text-[11px]" x-text="lv.leave_type_name"></span>
                                </td>
                                <td class="py-3.5 px-4 font-mono font-bold text-slate-800 dark:text-slate-200" x-text="lv.start_date"></td>
                                <td class="py-3.5 px-4 font-mono font-bold text-slate-800 dark:text-slate-200" x-text="lv.end_date"></td>
                                <td class="py-3.5 px-4 text-center font-mono font-bold text-slate-700 dark:text-slate-300" x-text="lv.total_days || 1"></td>
                                <td class="py-3.5 px-4 text-right">
                                    <span
                                        :class="lv.status === 'Approved'
                                            ? 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                                            : 'bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800'"
                                        class="px-2.5 py-1 rounded-full text-[11px] font-extrabold inline-flex items-center gap-1"
                                    >
                                        <span :class="lv.status === 'Approved' ? 'bg-emerald-500' : 'bg-amber-500'" class="w-1.5 h-1.5 rounded-full"></span>
                                        <span x-text="lv.status"></span>
                                    </span>
                                </td>
                            </tr>
                        </template>
                        <template x-if="filteredStaffLeaves.length === 0">
                            <tr>
                                <td colspan="7" class="py-10 text-center text-slate-400 dark:text-slate-500 font-semibold">
                                    No Approved or Pending leave applications found for the selected scope and month.
                                </td>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- ======================================================================= -->
    <!-- MODE 3: INDIVIDUAL EMPLOYEE ATTENDANCE CALENDAR GRID                    -->
    <!-- ======================================================================= -->
    <div x-show="calendarMode === 'individual'" class="space-y-6">
        <div class="bg-white dark:bg-slate-900 p-5 sm:p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-5">
            <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-5 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div class="flex items-center gap-4">
                    <template x-if="currentEmployee">
                        <img
                            :src="currentEmployee.photo || currentEmployee.avatar || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150'"
                            :alt="currentEmployee.name"
                            class="w-14 h-14 rounded-2xl object-cover ring-2 ring-indigo-500/20 shadow-xs"
                        >
                    </template>
                    <div class="space-y-1">
                        <div class="flex items-center gap-2 flex-wrap">
                            <h2 class="text-lg font-black text-slate-900 dark:text-white" x-text="currentEmployee ? currentEmployee.name : 'Select Employee'"></h2>
                            <span class="px-2 py-0.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 font-mono text-[11px] font-bold" x-text="currentEmployee ? (currentEmployee.employee_code || 'EMP') : ''"></span>
                            <span class="px-2 py-0.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 text-[10px] font-extrabold uppercase" x-text="currentEmployee ? (currentEmployee.status || 'Active') : 'Active'"></span>
                        </div>
                        <p class="text-xs text-slate-500 dark:text-slate-400 font-medium">
                            <span x-text="currentEmployee ? (currentEmployee.designation_name || currentEmployee.role || 'Staff') : ''"></span> •
                            <span x-text="currentEmployee ? (currentEmployee.department_name || currentEmployee.department || 'General') : ''"></span> •
                            <span x-text="currentEmployee ? (currentEmployee.branch_name || currentEmployee.branch || 'Main HQ') : ''"></span>
                        </p>
                    </div>
                </div>

                <div class="flex items-center gap-3 bg-slate-50/80 dark:bg-slate-800/60 p-3.5 rounded-2xl border border-slate-200/60 dark:border-slate-700/60">
                    <div class="w-10 h-10 rounded-xl bg-indigo-500/10 dark:bg-indigo-500/20 flex items-center justify-center text-indigo-600 dark:text-indigo-400 shrink-0">
                        <i data-lucide="calendar-heart" class="w-5 h-5"></i>
                    </div>
                    <div class="text-xs space-y-0.5">
                        <div class="flex items-center gap-2">
                            <span class="font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider text-[10px]">Designated Weekly Off:</span>
                            <template x-for="day in designatedOffDays" :key="day">
                                <span class="px-2 py-0.5 rounded-md bg-indigo-600 text-white font-black text-[11px] shadow-xs" x-text="day"></span>
                            </template>
                        </div>
                        <div class="text-slate-600 dark:text-slate-300 font-medium text-[11px]">
                            Shift: <span class="font-bold text-slate-800 dark:text-white" x-text="currentShift ? (currentShift.name || 'General Shift') : (currentEmployee ? currentEmployee.shift_name : 'General Shift')"></span>
                            (<span x-text="currentShift ? ((currentShift.start_time || '08:00').substr(0, 5) + ' - ' + (currentShift.end_time || '16:00').substr(0, 5)) : '08:00 - 16:00'"></span>)
                        </div>
                    </div>
                </div>
            </div>

            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div class="w-full md:w-80">
                    <label class="block font-bold text-slate-600 dark:text-slate-400 text-xs mb-1">Select Employee</label>
                    <select x-model="calEmpId" class="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white font-bold text-xs focus:ring-2 focus:ring-indigo-500 outline-hidden cursor-pointer">
                        <?php foreach ($employees as $e): ?>
                            <option value="<?= esc($e['id']) ?>" <?= $e['id'] === $selectedEmpId ? 'selected' : '' ?>>
                                <?= esc(($e['first_name'] ?? '') . ' ' . ($e['last_name'] ?? '')) ?> (<?= esc($e['employee_code'] ?? 'EMP') ?>) — <?= esc($e['designation_name'] ?? 'Staff') ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="w-full md:w-72">
                    <label class="block font-bold text-slate-600 dark:text-slate-400 text-xs mb-1">Designated Off Schedule Profile</label>
                    <select x-model="offDayMode" class="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white font-bold text-xs focus:ring-2 focus:ring-indigo-500 outline-hidden cursor-pointer">
                        <option value="auto">Auto (Employee Shift & Rule Policy)</option>
                        <option value="friday">Standard 6-Day (Friday Off)</option>
                        <option value="fri_sat">Corporate 5-Day (Friday & Saturday Off)</option>
                        <option value="sat_sun">Standard 5-Day (Saturday & Sunday Off)</option>
                        <option value="sunday">Single Off (Sunday Only)</option>
                    </select>
                </div>

                <div class="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl shrink-0 self-start md:self-end">
                    <button type="button" @click="viewFilter = 'all'" :class="viewFilter === 'all' ? 'bg-white dark:bg-slate-900 text-indigo-600 shadow-xs' : 'text-slate-600 dark:text-slate-400'" class="px-2.5 py-1.5 rounded-lg font-bold text-[10px] transition cursor-pointer">All Days</button>
                    <button type="button" @click="viewFilter = 'off_days'" :class="viewFilter === 'off_days' ? 'bg-white dark:bg-slate-900 text-indigo-600 shadow-xs' : 'text-slate-600 dark:text-slate-400'" class="px-2.5 py-1.5 rounded-lg font-bold text-[10px] transition cursor-pointer">Off Days</button>
                    <button type="button" @click="viewFilter = 'work_days'" :class="viewFilter === 'work_days' ? 'bg-white dark:bg-slate-900 text-indigo-600 shadow-xs' : 'text-slate-600 dark:text-slate-400'" class="px-2.5 py-1.5 rounded-lg font-bold text-[10px] transition cursor-pointer">Work Days</button>
                    <button type="button" @click="viewFilter = 'discrepancies'" :class="viewFilter === 'discrepancies' ? 'bg-white dark:bg-slate-900 text-indigo-600 shadow-xs' : 'text-slate-600 dark:text-slate-400'" class="px-2.5 py-1.5 rounded-lg font-bold text-[10px] transition cursor-pointer">Exceptions</button>
                </div>
            </div>
        </div>

        <!-- Individual Calendar Grid -->
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm p-4 sm:p-6 overflow-hidden">
            <div class="grid grid-cols-7 gap-2 text-center pb-3 border-b border-slate-100 dark:border-slate-800">
                <template x-for="head in weekHeaderList" :key="head.fullName">
                    <div
                        :class="head.isOff
                            ? 'bg-indigo-50/80 dark:bg-indigo-950/40 border-b-2 border-indigo-600 dark:border-indigo-400 text-indigo-700 dark:text-indigo-300'
                            : 'bg-slate-50/60 dark:bg-slate-800/40 text-slate-600 dark:text-slate-400'"
                        class="py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition flex flex-col items-center justify-center gap-0.5"
                    >
                        <span x-text="head.shortName"></span>
                        <span x-show="head.isOff" class="text-[9px] font-extrabold text-indigo-600 dark:text-indigo-400 tracking-normal">(Weekly Off)</span>
                        <span x-show="!head.isOff" class="text-[9px] font-medium text-slate-400 dark:text-slate-500 tracking-normal">(Work)</span>
                    </div>
                </template>
            </div>

            <div class="grid grid-cols-7 gap-2 pt-3">
                <template x-for="(cell, idx) in filteredCalendarDays" :key="idx">
                    <div>
                        <template x-if="cell.isBlank">
                            <div class="h-28 sm:h-32 rounded-2xl bg-slate-50/40 dark:bg-slate-800/20 border border-dashed border-slate-200/40 dark:border-slate-800/40"></div>
                        </template>

                        <template x-if="!cell.isBlank">
                            <div
                                @click="openDayModal(cell)"
                                :class="{
                                    'opacity-30 pointer-events-none': cell.isDimmed,
                                    'border-indigo-200 dark:border-indigo-900/60 bg-indigo-50/20 dark:bg-indigo-950/15': cell.status === 'Weekly Off',
                                    'border-amber-300 dark:border-amber-700 bg-amber-50/40 dark:bg-amber-950/20': cell.status === 'Weekly Off (Worked)' || cell.isOffDayDuty,
                                    'border-sky-200 dark:border-sky-900/60 bg-sky-50/40 dark:bg-sky-950/20': cell.status === 'Holiday' || cell.status === 'Holiday (Worked)',
                                    'border-blue-200 dark:border-blue-900/60 bg-blue-50/40 dark:bg-blue-950/20': cell.status === 'On Leave' || cell.status === 'Leave Pending',
                                    'border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/40 dark:bg-emerald-950/20': ['Present', 'Present (Early Closure)', 'Early Closure Covered', 'Approved Early Closure'].includes(cell.status),
                                    'border-amber-200 dark:border-amber-900/60 bg-amber-50/30 dark:bg-amber-950/20': cell.status === 'Late',
                                    'border-rose-200 dark:border-rose-900/60 bg-rose-50/40 dark:bg-rose-950/20': cell.status === 'Absent',
                                    'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900': cell.status === 'Scheduled' || cell.status === 'Not Recorded',
                                    'ring-2 ring-indigo-500 shadow-sm': cell.isToday
                                }"
                                class="h-28 sm:h-32 p-2.5 rounded-2xl border flex flex-col justify-between cursor-pointer hover:shadow-md transition-all relative overflow-hidden"
                            >
                                <div class="flex items-center justify-between gap-1">
                                    <span
                                        :class="cell.isToday ? 'bg-indigo-600 text-white shadow-xs' : (cell.isDesignatedWeeklyOff ? 'text-indigo-700 dark:text-indigo-400 font-black' : 'text-slate-800 dark:text-white font-bold')"
                                        class="text-xs font-mono px-1.5 py-0.5 rounded-md"
                                        x-text="cell.day"
                                    ></span>
                                    <span x-show="cell.isDesignatedWeeklyOff && !cell.isOffDayDuty" class="px-1.5 py-0.2 text-[9px] font-bold rounded bg-indigo-100/70 dark:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300">Off</span>
                                </div>

                                <div class="text-[10px] space-y-0.5 my-auto">
                                    <template x-if="cell.holiday">
                                        <div class="font-bold text-sky-700 dark:text-sky-300 truncate" x-text="cell.holiday"></div>
                                    </template>
                                    <template x-if="cell.leave">
                                        <div class="font-bold text-blue-700 dark:text-blue-300 truncate" x-text="cell.leave + ' (' + cell.leaveStatus + ')'"></div>
                                    </template>
                                    <template x-if="cell.log && cell.log.check_in && cell.log.check_in !== '--:--:--'">
                                        <div class="font-mono text-slate-800 dark:text-slate-200 font-bold truncate" x-text="cell.log.check_in.substr(0, 5) + ' - ' + (cell.log.check_out ? cell.log.check_out.substr(0, 5) : '--:--')"></div>
                                    </template>
                                </div>

                                <div>
                                    <span class="px-1.5 py-0.5 rounded-md text-[9px] font-bold block text-center truncate bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300" x-text="cell.statusLabel"></span>
                                </div>
                            </div>
                        </template>
                    </div>
                </template>
            </div>
        </div>
    </div>

    <!-- ======================================================================= -->
    <!-- MODAL 1: STAFF LEAVE DAY DETAILS MODAL                                  -->
    <!-- ======================================================================= -->
    <template x-if="selectedLeaveDayModal">
        <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150" @click.self="closeLeaveDayModal()">
            <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-xl w-full overflow-hidden">
                <div class="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <div>
                        <h3 class="text-base font-black text-slate-900 dark:text-white" x-text="selectedLeaveDayModal.dayFullName + ', ' + selectedLeaveDayModal.dateStr"></h3>
                        <p class="text-xs text-slate-500 dark:text-slate-400">
                            <span x-text="selectedLeaveDayModal.leaveCount"></span> employee(s) on leave in authorized scope
                        </p>
                    </div>
                    <button type="button" @click="closeLeaveDayModal()" class="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 cursor-pointer">
                        <i data-lucide="x" class="w-5 h-5"></i>
                    </button>
                </div>

                <div class="p-5 space-y-3 max-h-[70vh] overflow-y-auto">
                    <template x-if="selectedLeaveDayModal.holiday">
                        <div class="p-3 rounded-2xl bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 text-xs text-sky-800 dark:text-sky-200 font-bold">
                            Public Holiday: <span x-text="selectedLeaveDayModal.holiday"></span>
                        </div>
                    </template>

                    <template x-for="lv in selectedLeaveDayModal.leaves" :key="lv.id">
                        <div class="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 flex items-start justify-between gap-3">
                            <div class="space-y-1">
                                <div class="flex items-center gap-2">
                                    <span class="text-sm font-black text-slate-900 dark:text-white" x-text="lv.employee_name"></span>
                                    <span class="text-[11px] font-mono text-slate-400" x-text="lv.employee_code || lv.employee_id"></span>
                                </div>
                                <div class="text-xs text-slate-600 dark:text-slate-300 font-semibold">
                                    Department: <span class="font-bold text-slate-800 dark:text-white" x-text="lv.department_name"></span>
                                </div>
                                <div class="text-xs text-slate-600 dark:text-slate-300">
                                    Leave Type: <span class="font-bold text-indigo-600 dark:text-indigo-400" x-text="lv.leave_type_name"></span>
                                </div>
                                <div class="text-xs font-mono text-slate-500 dark:text-slate-400">
                                    Period: <strong x-text="lv.start_date"></strong> to <strong x-text="lv.end_date"></strong>
                                    (<span x-text="(lv.total_days || 1) + ' day(s)'"></span>)
                                </div>
                            </div>
                            <span
                                :class="lv.status === 'Approved'
                                    ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                                    : 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800'"
                                class="px-2.5 py-1 rounded-full text-xs font-black uppercase shrink-0"
                                x-text="lv.status"
                            ></span>
                        </div>
                    </template>

                    <template x-if="selectedLeaveDayModal.leaves.length === 0">
                        <div class="py-8 text-center text-xs text-slate-400 font-semibold">
                            No Approved or Pending leaves scheduled on this date.
                        </div>
                    </template>
                </div>

                <div class="p-4 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-100 dark:border-slate-800 flex justify-end">
                    <button type="button" @click="closeLeaveDayModal()" class="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-white font-bold text-xs cursor-pointer">
                        Close
                    </button>
                </div>
            </div>
        </div>
    </template>

    <!-- ======================================================================= -->
    <!-- MODAL 2: INDIVIDUAL DAY PUNCH DETAILS MODAL                             -->
    <!-- ======================================================================= -->
    <template x-if="selectedDayModal">
        <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150" @click.self="closeDayModal()">
            <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-lg w-full overflow-hidden">
                <div class="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <div class="space-y-0.5">
                        <h3 class="text-base font-black text-slate-900 dark:text-white" x-text="selectedDayModal.dayFullName + ', ' + selectedDayModal.dateStr"></h3>
                        <p class="text-xs text-slate-500 dark:text-slate-400">
                            Employee: <strong class="text-slate-800 dark:text-slate-200" x-text="currentEmployee ? currentEmployee.name : ''"></strong>
                        </p>
                    </div>
                    <button type="button" @click="closeDayModal()" class="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 transition cursor-pointer">
                        <i data-lucide="x" class="w-5 h-5"></i>
                    </button>
                </div>

                <div class="p-6 space-y-4">
                    <div class="grid grid-cols-2 gap-3">
                        <div class="bg-slate-50 dark:bg-slate-800/40 p-3.5 rounded-2xl border border-slate-200/60 dark:border-slate-700/60">
                            <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">First Check-In</span>
                            <div class="text-sm font-black font-mono text-slate-900 dark:text-white mt-1" x-text="selectedDayModal.log && selectedDayModal.log.check_in ? selectedDayModal.log.check_in : '--:--:--'"></div>
                        </div>
                        <div class="bg-slate-50 dark:bg-slate-800/40 p-3.5 rounded-2xl border border-slate-200/60 dark:border-slate-700/60">
                            <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Last Check-Out</span>
                            <div class="text-sm font-black font-mono text-slate-900 dark:text-white mt-1" x-text="selectedDayModal.log && selectedDayModal.log.check_out ? selectedDayModal.log.check_out : '--:--:--'"></div>
                        </div>
                    </div>
                </div>

                <div class="p-4 bg-slate-50/80 dark:bg-slate-800/80 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end">
                    <button type="button" @click="closeDayModal()" class="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-white font-bold text-xs cursor-pointer">
                        Close
                    </button>
                </div>
            </div>
        </div>
    </template>

</div>
