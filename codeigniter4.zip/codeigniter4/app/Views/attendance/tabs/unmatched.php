<!-- Sub-View: Unmatched Biometric Staff & Raw Hardware Device Ingestion -->
<div x-show="activeTab === 'unmatched' || activeTab === 'unmatched-biometrics'" class="space-y-6 animate-in fade-in duration-200">
    
    <!-- Top Banner & Company Scope Header -->
    <div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-5 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
            <div class="flex items-center gap-2 flex-wrap">
                <span class="text-[10px] font-bold uppercase tracking-widest text-amber-600 dark:text-amber-400 font-mono">Biometric Hardware Gateway</span>
                <span class="px-2 py-0.5 text-[10px] font-bold rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300">Identity Resolution Engine</span>
                <?php if (!empty($currentCompany)): ?>
                    <span class="px-2.5 py-0.5 text-[10px] font-bold rounded-full bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300 border border-indigo-200/60 dark:border-indigo-800/60 flex items-center gap-1">
                        <i data-lucide="building" class="w-3 h-3"></i>
                        <span><?= esc($currentCompany['name']) ?> (ID: <?= esc($currentCompany['id']) ?>)</span>
                    </span>
                <?php endif; ?>
            </div>
            <h2 class="text-base font-extrabold text-slate-900 dark:text-white mt-1">Unmatched Biometric Staff & Hardware Terminal Ingestion</h2>
            <p class="text-xs text-slate-500 dark:text-slate-400">Punches received from company biometric devices without existing employee profiles are safely held. Map them to existing employees or onboard new staff to reprocess all historical punches.</p>
        </div>

        <div class="flex items-center gap-2.5 flex-wrap">
            <?php if ((!empty($isSoftwareAdmin) || !empty($isSoftwareAppAdmin)) && !empty($allCompanies) && count($allCompanies) > 1): ?>
                <div class="flex items-center gap-1.5 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs">
                    <span class="text-slate-400 font-medium text-[11px]">Company:</span>
                    <select onchange="window.location.href='<?= base_url('attendance?tab=unmatched&company_id=') ?>' + this.value" class="bg-transparent font-bold text-slate-800 dark:text-slate-200 outline-none text-xs cursor-pointer">
                        <option value="">All Companies</option>
                        <?php foreach ($allCompanies as $comp): ?>
                            <option value="<?= esc($comp['id']) ?>" <?= ($comp['id'] === ($userCompanyId ?? '')) ? 'selected' : '' ?>>
                                <?= esc($comp['name']) ?> (ID: <?= esc(substr($comp['id'], 0, 8)) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            <?php endif; ?>

            <a href="<?= base_url('employees/create') ?>" class="flex items-center gap-2 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm transition">
                <i data-lucide="user-plus" class="w-3.5 h-3.5"></i>
                <span>Onboard New Staff</span>
            </a>

            <button @click="triggerBiometricRepair()" class="flex items-center gap-2 px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold shadow-sm transition cursor-pointer" title="Auto-recovers missing biometric user IDs from raw payloads and rebuilds distinct terminal identities">
                <i data-lucide="wrench" class="w-3.5 h-3.5" :class="isRepairingBuffer ? 'animate-spin' : ''"></i>
                <span x-text="isRepairingBuffer ? 'Repairing Buffer...' : 'Repair PIN Buffer'"></span>
            </button>

            <button @click="triggerBiometricSync()" class="flex items-center gap-2 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition cursor-pointer">
                <i data-lucide="refresh-cw" class="w-3.5 h-3.5" :class="isSyncingZKT ? 'animate-spin' : ''"></i>
                <span>Fetch Terminal Data</span>
            </button>
        </div>
    </div>

    <!-- KPI Metric Cards for Unmatched Engine -->
    <div class="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <!-- 1. Total Ingested Hardware Badges -->
        <div onclick="setQuickStatus('ALL')" class="p-4 rounded-2xl border bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 shadow-xs cursor-pointer hover:border-indigo-400 dark:hover:border-indigo-600 transition group">
            <div class="flex items-center justify-between text-indigo-600 dark:text-indigo-400 mb-1">
                <span class="text-[10px] font-bold uppercase tracking-wider">Total Terminal Users</span>
                <i data-lucide="fingerprint" class="w-4 h-4 group-hover:scale-110 transition-transform"></i>
            </div>
            <span class="text-2xl font-black font-mono text-slate-900 dark:text-white" id="cardTotalCount"><?= (int)($totalTotal ?? ($totalUnmatched + $totalMapped + $totalIgnored)) ?></span>
            <span class="text-[11px] text-slate-400 block mt-0.5">Ingested Badges</span>
        </div>

        <!-- 2. Successfully Mapped -->
        <div onclick="setQuickStatus('MAPPED')" class="p-4 rounded-2xl border bg-white dark:bg-slate-900 border-emerald-200/80 dark:border-emerald-900/40 shadow-xs cursor-pointer hover:border-emerald-500 transition group">
            <div class="flex items-center justify-between text-emerald-600 dark:text-emerald-400 mb-1">
                <span class="text-[10px] font-bold uppercase tracking-wider">Mapped to Employees</span>
                <i data-lucide="check-check" class="w-4 h-4 group-hover:scale-110 transition-transform"></i>
            </div>
            <span class="text-2xl font-black font-mono text-emerald-700 dark:text-emerald-400" id="cardMappedCount"><?= (int)($totalMapped ?? 0) ?></span>
            <span class="text-[11px] text-slate-400 block mt-0.5">Linked HRM Profiles</span>
        </div>

        <!-- 3. Awaiting Resolution / Unmapped -->
        <div onclick="setQuickStatus('UNMATCHED')" class="p-4 rounded-2xl border bg-white dark:bg-slate-900 border-amber-200/80 dark:border-amber-900/40 shadow-xs cursor-pointer hover:border-amber-500 transition group">
            <div class="flex items-center justify-between text-amber-600 dark:text-amber-400 mb-1">
                <span class="text-[10px] font-bold uppercase tracking-wider">Awaiting Resolution</span>
                <i data-lucide="alert-circle" class="w-4 h-4 group-hover:scale-110 transition-transform"></i>
            </div>
            <span class="text-2xl font-black font-mono text-amber-700 dark:text-amber-400" id="cardUnmatchedCount"><?= (int)($totalUnmatched ?? 0) ?></span>
            <span class="text-[11px] text-slate-400 block mt-0.5">Unlinked Machine PINs</span>
        </div>

        <!-- 4. Preserved Raw Punches -->
        <div class="p-4 rounded-2xl border bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 shadow-xs">
            <div class="flex items-center justify-between text-blue-600 dark:text-blue-400 mb-1">
                <span class="text-[10px] font-bold uppercase tracking-wider">Raw Buffer Punches</span>
                <i data-lucide="cpu" class="w-4 h-4"></i>
            </div>
            <span class="text-2xl font-black font-mono text-slate-900 dark:text-white"><?= (int)($unprocessedRawCount ?? 0) ?></span>
            <span class="text-[11px] text-slate-400 block mt-0.5">Preserved in Buffer</span>
        </div>

        <!-- 5. Ignored / Archived -->
        <div onclick="setQuickStatus('IGNORED')" class="p-4 rounded-2xl border bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 shadow-xs cursor-pointer hover:border-slate-400 transition group">
            <div class="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1">
                <span class="text-[10px] font-bold uppercase tracking-wider">Archived / Tags</span>
                <i data-lucide="archive" class="w-4 h-4 group-hover:scale-110 transition-transform"></i>
            </div>
            <span class="text-2xl font-black font-mono text-slate-700 dark:text-slate-300" id="cardIgnoredCount"><?= (int)($totalIgnored ?? 0) ?></span>
            <span class="text-[11px] text-slate-400 block mt-0.5">Skipped Hardware Tags</span>
        </div>
    </div>

    <!-- Main Unmatched Biometric Data List -->
    <div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
        
        <!-- Search, Filter & Quick Filter Bar -->
        <div class="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div class="flex items-center gap-2 w-full sm:w-auto">
                <div class="relative w-full sm:w-72">
                    <i data-lucide="search" class="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
                    <input 
                        type="text" 
                        id="unmatchedSearchInput"
                        placeholder="Search biometric PIN, card, name, employee..." 
                        class="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500 outline-none"
                    >
                </div>

                <select id="unmatchedStatusFilter" class="text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-slate-800 dark:text-slate-200 font-medium">
                    <option value="ALL">All Statuses (<?= (int)($totalTotal ?? ($totalUnmatched + $totalMapped + $totalIgnored)) ?>)</option>
                    <option value="UNMATCHED">Unmapped Only (<?= (int)($totalUnmatched ?? 0) ?>)</option>
                    <option value="MAPPED">Mapped Only (<?= (int)($totalMapped ?? 0) ?>)</option>
                    <option value="IGNORED">Archived / Ignored (<?= (int)($totalIgnored ?? 0) ?>)</option>
                </select>
            </div>

            <div class="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5 self-end sm:self-center">
                <span>Displaying:</span>
                <span class="font-bold text-slate-900 dark:text-white font-mono" id="unmatchedCountBadge"><?= count($unmatchedStaff ?? []) ?> records</span>
            </div>
        </div>

        <!-- Table Container -->
        <div class="overflow-x-auto rounded-2xl border border-slate-100 dark:border-slate-800">
            <table class="w-full text-left text-xs text-slate-600 dark:text-slate-300">
                <thead class="bg-slate-50/80 dark:bg-slate-800/60 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider border-b border-slate-200/80 dark:border-slate-800">
                    <tr>
                        <th class="py-3 px-4">Biometric User PIN</th>
                        <th class="py-3 px-4">Origin Terminal Device & Company</th>
                        <th class="py-3 px-4">Device Display Name</th>
                        <th class="py-3 px-4">Preserved Punches</th>
                        <th class="py-3 px-4">Last Punch Time</th>
                        <th class="py-3 px-4">Mapped HRM Employee</th>
                        <th class="py-3 px-4">Mapping Status</th>
                        <th class="py-3 px-4 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-800/60 font-medium" id="unmatchedTableBody">
                    <?php if (empty($unmatchedStaff)): ?>
                        <tr>
                            <td colspan="8" class="py-12 text-center text-slate-400">
                                <div class="flex flex-col items-center justify-center gap-2">
                                    <div class="w-12 h-12 rounded-full bg-amber-50 dark:bg-amber-950/40 text-amber-500 flex items-center justify-center">
                                        <i data-lucide="check-circle-2" class="w-6 h-6"></i>
                                    </div>
                                    <p class="font-bold text-sm text-slate-700 dark:text-slate-300">No Biometric Ingestion Records Found</p>
                                    <p class="text-xs text-slate-400 max-w-sm">No biometric user IDs currently detected for this filter. Punches will automatically populate here as terminal events arrive.</p>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($unmatchedStaff as $row): 
                            $status = $row['computed_status'] ?? $row['status'] ?? 'UNMATCHED';
                            $isMapped = ($status === 'MAPPED');
                            $hasEmployee = !empty($row['employee_id']) || !empty($row['employee_code']);
                            $empName = trim(($row['employee_first_name'] ?? '') . ' ' . ($row['employee_last_name'] ?? ''));
                            $searchText = strtolower(implode(' ', [
                                $row['biometric_user_id'] ?? '',
                                $row['device_user_name'] ?? '',
                                $row['card_number'] ?? '',
                                $row['device_name'] ?? '',
                                $row['device_serial'] ?? '',
                                $empName,
                                $row['employee_code'] ?? '',
                                $row['employee_department'] ?? '',
                                $row['employee_designation'] ?? '',
                                $status
                            ]));
                        ?>
                            <tr class="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition unmatched-row" data-status="<?= esc($status) ?>" data-text="<?= esc($searchText) ?>">
                                <td class="py-3 px-4">
                                    <div class="flex items-center gap-2">
                                        <div class="w-8 h-8 rounded-xl <?= $isMapped ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300' : 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300' ?> flex items-center justify-center font-mono font-bold text-xs">
                                            <i data-lucide="fingerprint" class="w-4 h-4"></i>
                                        </div>
                                        <div>
                                            <span class="font-black font-mono text-slate-900 dark:text-white"><?= esc($row['biometric_user_id']) ?></span>
                                            <?php if (!empty($row['card_number'])): ?>
                                                <span class="block text-[10px] text-slate-400 font-mono">RFID: <?= esc($row['card_number']) ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-3 px-4">
                                    <div>
                                        <span class="font-bold text-slate-800 dark:text-slate-200"><?= esc($row['device_name'] ?? $row['device_id'] ?? 'Terminal') ?></span>
                                        <span class="block text-[10px] text-indigo-600 dark:text-indigo-400 font-mono">
                                            <?= esc($row['company_name'] ?? ($currentCompany['name'] ?? 'Company #' . substr($row['company_id'] ?? '', 0, 8))) ?>
                                        </span>
                                    </div>
                                </td>
                                <td class="py-3 px-4">
                                    <span class="text-slate-700 dark:text-slate-300 font-medium"><?= esc($row['device_user_name'] ?: 'No Name on Device') ?></span>
                                </td>
                                <td class="py-3 px-4">
                                    <span class="px-2 py-0.5 rounded-full text-xs font-mono font-bold bg-blue-50 text-blue-700 dark:bg-blue-950/50 dark:text-blue-300 border border-blue-200/50">
                                        <?= (int)($row['punch_count'] ?? $row['event_count'] ?? 1) ?> punches
                                    </span>
                                </td>
                                <td class="py-3 px-4 text-xs font-mono text-slate-500">
                                    <?= !empty($row['last_punch_at']) ? date('M d, Y H:i:s', strtotime($row['last_punch_at'])) : 'N/A' ?>
                                </td>
                                <td class="py-3 px-4">
                                    <?php if ($isMapped && $hasEmployee): ?>
                                        <div class="flex items-center gap-2">
                                            <div class="w-7 h-7 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold flex items-center justify-center text-[11px]">
                                                <?= strtoupper(substr($empName ?: 'E', 0, 1)) ?>
                                            </div>
                                            <div>
                                                <div class="flex items-center gap-1.5">
                                                    <span class="font-bold text-slate-900 dark:text-white"><?= esc($empName) ?></span>
                                                    <span class="px-1.5 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-mono text-[10px]"><?= esc($row['employee_code']) ?></span>
                                                </div>
                                                <span class="text-[10px] text-slate-400 block"><?= esc($row['employee_department'] ?? 'General') ?><?= !empty($row['employee_designation']) ? ' • ' . esc($row['employee_designation']) : '' ?></span>
                                            </div>
                                        </div>
                                    <?php elseif ($status === 'IGNORED'): ?>
                                        <span class="text-slate-400 italic text-[11px]">Archived / Visitor Tag</span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400 font-semibold text-[11px]">
                                            <i data-lucide="alert-circle" class="w-3 h-3"></i>
                                            <span>Unlinked (Awaiting Mapping)</span>
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3 px-4">
                                    <?php if ($isMapped): ?>
                                        <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200/60">Mapped</span>
                                    <?php elseif ($status === 'IGNORED'): ?>
                                        <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-400">Archived</span>
                                    <?php else: ?>
                                        <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 animate-pulse border border-amber-200/60">Unmatched</span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3 px-4 text-right">
                                    <div class="flex items-center justify-end gap-1.5">
                                        <?php if ($isMapped): ?>
                                            <!-- Unmap Action -->
                                            <?php if (!empty($row['mapping_id'])): ?>
                                                <button 
                                                    onclick="unmapBiometric('<?= esc($row['mapping_id']) ?>', '<?= esc($row['biometric_user_id']) ?>', '<?= esc($empName) ?>')"
                                                    class="px-2.5 py-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 hover:bg-rose-100 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                                                    title="Disconnect this employee and return punches to unmatched pool"
                                                >
                                                    <i data-lucide="unlink" class="w-3.5 h-3.5"></i>
                                                    <span>Unmap</span>
                                                </button>
                                            <?php endif; ?>

                                            <!-- View Employee Profile Link -->
                                            <?php if (!empty($row['employee_id'])): ?>
                                                <a 
                                                    href="<?= base_url('employees/' . esc($row['employee_id'])) ?>"
                                                    class="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                                                    title="View Employee Profile"
                                                >
                                                    <i data-lucide="external-link" class="w-3.5 h-3.5"></i>
                                                </a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <!-- Map to Employee Modal Trigger -->
                                            <button 
                                                onclick="openMapModal('<?= esc($row['id']) ?>', '<?= esc($row['biometric_user_id']) ?>', '<?= esc($row['device_user_name'] ?? '') ?>', '<?= esc($row['device_id'] ?? '') ?>', '<?= esc($row['company_id'] ?? '') ?>')"
                                                class="px-2.5 py-1.5 rounded-xl bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 hover:bg-amber-100 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                                                title="Map to an existing Employee"
                                            >
                                                <i data-lucide="link-2" class="w-3.5 h-3.5"></i>
                                                <span>Map Staff</span>
                                            </button>

                                            <!-- Quick Onboard -->
                                            <a 
                                                href="<?= base_url('employees/create?biometric_user_id=' . urlencode($row['biometric_user_id']) . '&name=' . urlencode($row['device_user_name'] ?? '') . '&company_id=' . urlencode($row['company_id'] ?? '')) ?>"
                                                class="px-2.5 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 text-xs font-bold transition flex items-center gap-1"
                                                title="Create new Employee with this Biometric ID"
                                            >
                                                <i data-lucide="user-plus" class="w-3.5 h-3.5"></i>
                                                <span>Onboard</span>
                                            </a>

                                            <!-- Ignore / Archive Button -->
                                            <button 
                                                onclick="ignoreUnmatchedBiometric('<?= esc($row['id']) ?>')"
                                                class="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
                                                title="Ignore / Archive this badge"
                                            >
                                                <i data-lucide="archive" class="w-3.5 h-3.5"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Mapping Modal Form -->
    <div id="biometricMappingModal" class="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs hidden p-4">
        <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-5 animate-in zoom-in-95 duration-150">
            <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <div class="flex items-center gap-2.5">
                    <div class="w-9 h-9 rounded-2xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold">
                        <i data-lucide="link-2" class="w-5 h-5"></i>
                    </div>
                    <div>
                        <h3 class="text-sm font-black text-slate-900 dark:text-white">Map Biometric ID to Employee</h3>
                        <p class="text-xs text-slate-400">All historical punch records will immediately recalculate</p>
                    </div>
                </div>
                <button onclick="closeMapModal()" class="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition">
                    <i data-lucide="x" class="w-4 h-4"></i>
                </button>
            </div>

            <form id="biometricMappingForm" method="POST" action="<?= base_url('attendance/unmatched/map') ?>" class="space-y-4">
                <?= csrf_field() ?>
                <input type="hidden" name="unmatched_id" id="modalUnmatchedId">
                <input type="hidden" name="company_id" id="modalCompanyId">

                <div class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 text-xs space-y-1.5">
                    <div class="flex justify-between">
                        <span class="text-slate-400">Biometric User PIN:</span>
                        <span class="font-mono font-bold text-slate-900 dark:text-white" id="modalBiometricId"></span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-slate-400">Terminal Label:</span>
                        <span class="text-slate-700 dark:text-slate-300 font-medium" id="modalDeviceUserName"></span>
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                        Select Target Employee <span class="text-rose-500">*</span>
                    </label>
                    <select name="employee_id" id="modalEmployeeSelect" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500 outline-none">
                        <option value="">-- Choose Employee to Link --</option>
                        <?php foreach ($employees as $emp): ?>
                            <?php $unmatchedEmpName = trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')) ?: ($emp['name'] ?? 'Staff'); ?>
                            <option value="<?= esc($emp['id']) ?>">
                                <?= esc($emp['employee_code']) ?> - <?= esc($unmatchedEmpName) ?> (<?= esc($emp['department'] ?? 'Staff') ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="flex items-center gap-2 p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200/60 dark:border-amber-900/40 text-xs text-amber-800 dark:text-amber-300">
                    <i data-lucide="info" class="w-4 h-4 shrink-0"></i>
                    <span>Connecting will reprocess attendance logs from all raw punches automatically.</span>
                </div>

                <div class="flex items-center justify-end gap-2.5 pt-2">
                    <button type="button" onclick="closeMapModal()" class="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition">
                        Cancel
                    </button>
                    <button type="submit" class="px-4 py-2 rounded-xl text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 shadow-sm transition flex items-center gap-1.5">
                        <i data-lucide="check" class="w-4 h-4"></i>
                        <span>Confirm & Reprocess Punches</span>
                    </button>
                </div>
            </form>
        </div>
    </div>

</div>

<!-- Client-side Script for Unmatched Tab filtering and modals -->
<script>
function openMapModal(unmatchedId, biometricId, deviceUserName, deviceId, companyId) {
    document.getElementById('modalUnmatchedId').value = unmatchedId;
    document.getElementById('modalBiometricId').textContent = biometricId;
    document.getElementById('modalDeviceUserName').textContent = deviceUserName || 'None';
    document.getElementById('modalCompanyId').value = companyId || '';
    document.getElementById('biometricMappingModal').classList.remove('hidden');
}

function closeMapModal() {
    document.getElementById('biometricMappingModal').classList.add('hidden');
}

function ignoreUnmatchedBiometric(id) {
    if (!confirm('Are you sure you want to archive this biometric badge? Its punches will be ignored for now.')) return;
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '<?= base_url('attendance/unmatched/ignore') ?>';
    
    const csrfInput = document.createElement('input');
    csrfInput.type = 'hidden';
    csrfInput.name = '<?= csrf_token() ?>';
    csrfInput.value = '<?= csrf_hash() ?>';
    form.appendChild(csrfInput);

    const idInput = document.createElement('input');
    idInput.type = 'hidden';
    idInput.name = 'id';
    idInput.value = id;
    form.appendChild(idInput);

    document.body.appendChild(form);
    form.submit();
}

function unmapBiometric(mappingId, pin, employeeName) {
    if (!confirm('Are you sure you want to unmap Biometric PIN ' + pin + (employeeName ? ' from ' + employeeName : '') + '? Punches from this terminal identity will return to the unmatched pool.')) return;
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '<?= base_url('attendance/unmatched/unmap') ?>';
    
    const csrfInput = document.createElement('input');
    csrfInput.type = 'hidden';
    csrfInput.name = '<?= csrf_token() ?>';
    csrfInput.value = '<?= csrf_hash() ?>';
    form.appendChild(csrfInput);

    const idInput = document.createElement('input');
    idInput.type = 'hidden';
    idInput.name = 'mapping_id';
    idInput.value = mappingId;
    form.appendChild(idInput);

    document.body.appendChild(form);
    form.submit();
}

function setQuickStatus(status) {
    const statusFilter = document.getElementById('unmatchedStatusFilter');
    if (statusFilter) {
        statusFilter.value = status;
        if (typeof window.applyUnmatchedFilter === 'function') {
            window.applyUnmatchedFilter();
        }
    }
}

// Client filtering for unmatched rows
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('unmatchedSearchInput');
    const statusFilter = document.getElementById('unmatchedStatusFilter');
    const rows = document.querySelectorAll('.unmatched-row');
    const badge = document.getElementById('unmatchedCountBadge');

    window.applyUnmatchedFilter = function() {
        const query = (searchInput ? searchInput.value : '').toLowerCase().trim();
        const status = statusFilter ? statusFilter.value : 'ALL';
        let visible = 0;
        let visibleMapped = 0;
        let visibleUnmatched = 0;

        rows.forEach(r => {
            const rowStatus = r.getAttribute('data-status');
            const rowText = r.getAttribute('data-text') || '';
            const matchesSearch = !query || rowText.includes(query);
            const matchesStatus = (status === 'ALL') || (rowStatus === status);

            if (matchesSearch && matchesStatus) {
                r.style.display = '';
                visible++;
                if (rowStatus === 'MAPPED') visibleMapped++;
                if (rowStatus === 'UNMATCHED') visibleUnmatched++;
            } else {
                r.style.display = 'none';
            }
        });

        if (badge) {
            if (status === 'MAPPED') {
                badge.textContent = visible + ' mapped records';
            } else if (status === 'UNMATCHED') {
                badge.textContent = visible + ' unmapped records';
            } else if (status === 'IGNORED') {
                badge.textContent = visible + ' archived records';
            } else {
                badge.textContent = visible + ' records (' + visibleMapped + ' mapped, ' + visibleUnmatched + ' unmapped)';
            }
        }
    };

    if (searchInput) searchInput.addEventListener('input', window.applyUnmatchedFilter);
    if (statusFilter) statusFilter.addEventListener('change', window.applyUnmatchedFilter);

    // Initial filter run (defaults to ALL to match total count card)
    window.applyUnmatchedFilter();
});
</script>
