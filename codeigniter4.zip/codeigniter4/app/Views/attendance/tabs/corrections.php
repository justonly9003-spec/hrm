<!-- TAB: Attendance Corrections & Regularization Workflow -->
<script>
window.correctionsAttendanceModule = function() {
    return {
        subTab: <?= json_encode(($activeTab ?? ($_GET['tab'] ?? '')) === 'early-closures' ? 'early_closures' : 'individual') ?>,
        filterStatus: 'Pending',
        searchQuery: '',
        allCorrections: <?= json_encode($allCorrections ?? $pendingCorrections ?? []) ?>,
        showSubmitModal: false,
        selectedEmpId: <?= json_encode($currentUser['employee_id'] ?? (!empty($employees[0]['id']) ? $employees[0]['id'] : 'emp-001')) ?>,
        selectedDate: <?= json_encode(date('Y-m-d')) ?>,
        reqCheckIn: '09:00:00',
        reqCheckOut: '18:00:00',
        reason: '',
        requestType: 'Missing Check-In',
        isSubmitting: false,
        actionLoadingId: null,
        showRemarksModal: false,
        activeActionId: null,
        activeActionType: null,
        remarksText: '',

        init() {
            const params = new URLSearchParams(window.location.search);
            if (this.subTab === 'early_closures' || params.get('tab') === 'early-closures' || window.location.href.includes('early-closures') || window.attendanceConfig?.activeTab === 'early-closures') {
                this.subTab = 'early_closures';
                this.loadEarlyClosures();
            }
            window.addEventListener('tab-changed', (e) => {
                if (e.detail?.tab === 'early-closures') {
                    this.subTab = 'early_closures';
                    this.loadEarlyClosures();
                } else if (e.detail?.tab === 'corrections') {
                    this.subTab = 'individual';
                }
                this.refreshIcons();
            });
            this.refreshIcons();
        },

        refreshIcons() {
            this.$nextTick(() => {
                if (window.lucide) {
                    window.lucide.createIcons();
                }
            });
        },

        get filteredCorrections() {
            return this.allCorrections.filter(c => {
                const st = (c.status || '').toLowerCase();
                const targetSt = this.filterStatus.toLowerCase();

                if (targetSt !== 'all' && st !== targetSt) {
                    return false;
                }

                if (this.searchQuery) {
                    const q = this.searchQuery.toLowerCase();
                    const name = (c.employee_name || c.name || '').toLowerCase();
                    const code = (c.employee_code || c.employee_id || c.employeeId || '').toLowerCase();
                    const rsn = (c.reason || '').toLowerCase();
                    const dt = (c.attendance_date || c.date || '').toLowerCase();
                    const type = (c.request_type || '').toLowerCase();
                    if (!name.includes(q) && !code.includes(q) && !rsn.includes(q) && !dt.includes(q) && !type.includes(q)) {
                        return false;
                    }
                }

                return true;
            });
        },

        get stats() {
            let pending = 0;
            let approved = 0;
            let rejected = 0;
            this.allCorrections.forEach(c => {
                const st = (c.status || '').toLowerCase();
                if (st === 'pending') pending++;
                else if (st === 'approved') approved++;
                else if (st === 'rejected') rejected++;
            });
            return { pending, approved, rejected, total: this.allCorrections.length };
        },

        openSubmitModal() {
            this.showSubmitModal = true;
            this.reason = '';
            this.refreshIcons();
        },

        closeSubmitModal() {
            this.showSubmitModal = false;
            this.reason = '';
        },

        async submitRegularization() {
            if (!this.reason.trim()) {
                alert('Please provide a detailed reason or business justification.');
                return;
            }

            this.isSubmitting = true;
            try {
                const payload = {
                    employee_id: this.selectedEmpId,
                    attendance_date: this.selectedDate,
                    request_type: this.requestType,
                    proposed_check_in: this.reqCheckIn,
                    proposed_check_out: this.reqCheckOut,
                    reason: this.reason
                };

                const res = await fetch('<?= base_url('attendance/correction/submit') ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
                    },
                    body: JSON.stringify(payload)
                });

                const data = await res.json();
                if (data.status === 'success') {
                    if (data.corrections) {
                        this.allCorrections = data.corrections;
                    } else {
                        // Reload list
                        await this.loadCorrections();
                    }
                    this.closeSubmitModal();
                    this.refreshIcons();
                } else {
                    alert(data.message || 'Failed to submit regularization request.');
                }
            } catch (err) {
                console.error('Submit correction error:', err);
                // Fallback submit form
                document.getElementById('fallbackCorrectionForm').submit();
            } finally {
                this.isSubmitting = false;
            }
        },

        openActionModal(id, type) {
            this.activeActionId = id;
            this.activeActionType = type;
            this.remarksText = type === 'approve' ? 'Verified by HR Manager' : 'Insufficient justification';
            this.showRemarksModal = true;
            this.refreshIcons();
        },

        async confirmAction() {
            if (!this.activeActionId || !this.activeActionType) return;
            const id = this.activeActionId;
            const type = this.activeActionType;
            const remarks = this.remarksText;

            this.actionLoadingId = id;
            this.showRemarksModal = false;

            try {
                const url = type === 'approve' 
                    ? '<?= base_url('attendance/correction/approve/') ?>' + id
                    : '<?= base_url('attendance/correction/reject/') ?>' + id;

                const res = await fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
                    },
                    body: JSON.stringify({ remarks: remarks })
                });

                const data = await res.json();
                if (data.status === 'success') {
                    if (data.corrections) {
                        this.allCorrections = data.corrections;
                    } else {
                        await this.loadCorrections();
                    }
                    this.refreshIcons();
                } else {
                    alert(data.message || 'Operation failed.');
                }
            } catch (e) {
                console.error('Action error:', e);
                // Fallback to standard form post
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = type === 'approve' 
                    ? '<?= base_url('attendance/correction/approve/') ?>' + id
                    : '<?= base_url('attendance/correction/reject/') ?>' + id;
                
                const csrfInput = document.createElement('input');
                csrfInput.type = 'hidden';
                csrfInput.name = '<?= csrf_token() ?>';
                csrfInput.value = '<?= csrf_hash() ?>';
                form.appendChild(csrfInput);

                const remarkInput = document.createElement('input');
                remarkInput.type = 'hidden';
                remarkInput.name = 'remarks';
                remarkInput.value = remarks;
                form.appendChild(remarkInput);

                document.body.appendChild(form);
                form.submit();
            } finally {
                this.actionLoadingId = null;
            }
        },

        async loadCorrections() {
            try {
                const res = await fetch('<?= base_url('attendance/corrections-ajax') ?>', {
                    headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
                });
                const data = await res.json();
                if (data.status === 'success' && data.corrections) {
                    this.allCorrections = data.corrections;
                    this.refreshIcons();
                }
            } catch (e) {
                console.error('Failed to load corrections:', e);
            }
        },

        // Early Closure Sub-Module
        earlyClosures: <?= json_encode($earlyClosures ?? []) ?>,
        showEarlyClosureModal: false,
        showApprovalModal: false,
        showDetailsModal: false,
        approvalClosureId: null,
        approvalNoteText: '',
        activeClosureDetails: null,
        closurePreviewLoading: false,
        closureSubmitting: false,
        closurePreviewData: null,
        closureForm: {
            closure_date: '<?= date('Y-m-d') ?>',
            closure_time: '12:00',
            scope_type: 'company',
            branch_id: '',
            department_id: '',
            shift_id: '',
            reason: '',
            admin_notes: ''
        },

        formatHoursToHHMM(hours) {
            if (hours === null || hours === undefined || isNaN(hours)) return '00:00';
            const totalMinutes = Math.round(parseFloat(hours) * 60);
            const h = Math.floor(Math.max(0, totalMinutes) / 60);
            const m = Math.max(0, totalMinutes) % 60;
            return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
        },

        formatMinutesToHHMM(minutes) {
            if (minutes === null || minutes === undefined || isNaN(minutes)) return '00:00';
            const mins = Math.max(0, parseInt(minutes, 10));
            const h = Math.floor(mins / 60);
            const m = mins % 60;
            return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
        },

        get closureStats() {
            let approved = 0;
            let pending = 0;
            let totalHours = 0;
            let totalMinutes = 0;
            this.earlyClosures.forEach(c => {
                if (c.status === 'Approved') approved++;
                if (c.status === 'Draft' || c.status === 'Submitted') pending++;
                const hrs = parseFloat(c.total_credited_hours || 0);
                totalHours += hrs;
                totalMinutes += parseInt(c.total_credited_minutes || Math.round(hrs * 60), 10);
            });
            const h = Math.floor(totalMinutes / 60);
            const m = totalMinutes % 60;
            const totalTimeDisplay = String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
            return {
                total: this.earlyClosures.length,
                approved,
                pending,
                totalHours: totalHours.toFixed(1),
                totalTimeDisplay
            };
        },

        openEarlyClosureModal() {
            this.showEarlyClosureModal = true;
            this.closurePreviewData = null;
            this.closureForm.reason = '';
            this.closureForm.admin_notes = '';
            this.refreshIcons();
        },

        getScopeBadgeClass(scope) {
            const s = (scope || '').toLowerCase();
            if (s === 'company') return 'bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300';
            if (s === 'branch') return 'bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-300';
            if (s === 'department') return 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300';
            if (s === 'shift') return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300';
            return 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300';
        },

        getClosureStatusBadgeClass(status) {
            const st = (status || '').toLowerCase();
            if (st === 'approved') return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300';
            if (st === 'draft' || st === 'submitted') return 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300';
            return 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300';
        },

        getCreditStatusBadgeClass(status) {
            const st = (status || '').toLowerCase();
            if (st === 'approved') return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300';
            if (st === 'draft' || st === 'submitted') return 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300';
            return 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300';
        },

        getCorrectionStatusBadgeClass(status) {
            const st = (status || '').toLowerCase();
            if (st === 'approved') return 'bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800';
            if (st === 'rejected') return 'bg-rose-50 dark:bg-rose-950 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800';
            return 'bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800';
        },

        async loadEarlyClosures() {
            try {
                const res = await fetch('<?= base_url('attendance/early-closures?format=json') ?>', {
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });
                const data = await res.json();
                if ((data.success || data.status === 'success') && data.data) {
                    this.earlyClosures = data.data;
                    this.refreshIcons();
                }
            } catch (e) {
                console.error('Failed to load early closures:', e);
            }
        },

        async previewEarlyClosure() {
            if (!this.closureForm.closure_date || !this.closureForm.closure_time) {
                alert('Please select both a closure date and closure time.');
                return;
            }
            this.closurePreviewLoading = true;
            try {
                const res = await fetch('<?= base_url('attendance/early-closures/preview') ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
                    },
                    body: JSON.stringify(this.closureForm)
                });
                const data = await res.json();
                if ((data.success || data.status === 'success') && (data.preview || data.data)) {
                    this.closurePreviewData = data.preview || data.data;
                } else {
                    alert(data.message || 'Failed to evaluate preview.');
                }
            } catch (e) {
                console.error(e);
                alert('Error evaluating early closure preview.');
            } finally {
                this.closurePreviewLoading = false;
                this.refreshIcons();
            }
        },

        async saveClosureDraft() {
            if (!this.closureForm.reason.trim()) {
                alert('Corporate justification reason is mandatory.');
                return;
            }
            this.closureSubmitting = true;
            try {
                const res = await fetch('<?= base_url('attendance/early-closures/create') ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
                    },
                    body: JSON.stringify(this.closureForm)
                });
                const data = await res.json();
                if (data.success || data.status === 'success') {
                    alert('Early closure event created in Draft status.');
                    this.showEarlyClosureModal = false;
                    await this.loadEarlyClosures();
                } else {
                    alert(data.message || 'Failed to save draft.');
                }
            } catch (e) {
                console.error(e);
                alert('Failed to create early closure draft.');
            } finally {
                this.closureSubmitting = false;
            }
        },

        async createAndApproveClosure() {
            if (!this.closureForm.reason.trim()) {
                alert('Corporate justification reason is mandatory.');
                return;
            }
            if (!this.closureForm.admin_notes.trim()) {
                alert('Mandatory Admin Note / Approval remarks cannot be empty.');
                return;
            }

            if (!confirm('Are you sure you want to approve this company early closure? All eligible employees will be credited for full-day duty without OT.')) {
                return;
            }

            this.closureSubmitting = true;
            try {
                const createRes = await fetch('<?= base_url('attendance/early-closures/create') ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
                    },
                    body: JSON.stringify(this.closureForm)
                });
                const createData = await createRes.json();
                if (!(createData.success || createData.status === 'success') || !createData.data?.id) {
                    alert(createData.message || 'Failed to initialize event.');
                    this.closureSubmitting = false;
                    return;
                }

                const eventId = createData.data.id;

                const approveRes = await fetch('<?= base_url('attendance/early-closures/approve') ?>/' + eventId, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
                    },
                    body: JSON.stringify({ admin_notes: this.closureForm.admin_notes.trim() })
                });
                const approveData = await approveRes.json();
                if (approveData.success || approveData.status === 'success') {
                    alert(approveData.message || 'Early closure approved and attendance credited successfully!');
                    this.showEarlyClosureModal = false;
                    await this.loadEarlyClosures();
                } else {
                    alert(approveData.message || 'Failed to approve early closure.');
                }
            } catch (e) {
                console.error(e);
                alert('An error occurred during approval.');
            } finally {
                this.closureSubmitting = false;
            }
        },

        openApprovalModal(id) {
            this.approvalClosureId = id;
            this.approvalNoteText = '';
            this.showApprovalModal = true;
        },

        async confirmApproveClosure() {
            if (!this.approvalNoteText.trim()) {
                alert('Mandatory Admin Approval Note cannot be empty.');
                return;
            }
            try {
                const res = await fetch('<?= base_url('attendance/early-closures/approve') ?>/' + this.approvalClosureId, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
                    },
                    body: JSON.stringify({ admin_notes: this.approvalNoteText.trim() })
                });
                const data = await res.json();
                if (data.success || data.status === 'success') {
                    alert(data.message || 'Closure approved successfully!');
                    this.showApprovalModal = false;
                    await this.loadEarlyClosures();
                } else {
                    alert(data.message || 'Failed to approve.');
                }
            } catch (e) {
                console.error(e);
                alert('Error approving early closure.');
            }
        },

        async cancelClosure(id) {
            const reason = prompt('Please enter a cancellation reason:');
            if (!reason || !reason.trim()) return;

            try {
                const res = await fetch('<?= base_url('attendance/early-closures/cancel') ?>/' + id, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
                    },
                    body: JSON.stringify({ reason: reason.trim() })
                });
                const data = await res.json();
                if (data.success || data.status === 'success') {
                    alert(data.message || 'Closure event cancelled and credits revoked.');
                    await this.loadEarlyClosures();
                } else {
                    alert(data.message || 'Failed to cancel.');
                }
            } catch (e) {
                console.error(e);
                alert('Error cancelling closure.');
            }
        },

        async viewClosureDetails(id) {
            try {
                const res = await fetch('<?= base_url('attendance/early-closures/details') ?>/' + id, {
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });
                const data = await res.json();
                if (data.success || data.status === 'success') {
                    this.activeClosureDetails = data.data || data;
                    this.showDetailsModal = true;
                    this.refreshIcons();
                } else {
                    alert(data.message || 'Could not load details.');
                }
            } catch (e) {
                console.error(e);
                alert('Error loading closure details.');
            }
        }
    };
};
</script>

<div x-show="activeTab === 'corrections' || activeTab === 'early-closures'" class="space-y-6 animate-in fade-in duration-200" x-data="correctionsAttendanceModule()" x-init="init()">
    
    <!-- Sub-Navigation: Individual Regularizations vs Company Early Closure -->
    <div class="flex items-center gap-2 p-1.5 bg-slate-100 dark:bg-slate-800/80 rounded-2xl w-fit border border-slate-200/80 dark:border-slate-700/80">
        <button 
            type="button"
            @click="subTab = 'individual'; refreshIcons(); window.history.replaceState({}, '', '?tab=corrections')"
            :class="subTab === 'individual' ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm font-black' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 font-bold'"
            class="px-4 py-2 rounded-xl text-xs flex items-center gap-2 transition cursor-pointer"
        >
            <i data-lucide="user-check" class="w-4 h-4"></i>
            <span>Individual Regularizations</span>
            <span class="px-1.5 py-0.5 text-[10px] rounded-full bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 font-mono" x-text="stats.pending"></span>
        </button>

        <button 
            type="button"
            @click="subTab = 'early_closures'; loadEarlyClosures(); refreshIcons(); window.history.replaceState({}, '', '?tab=early-closures')"
            :class="subTab === 'early_closures' ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-sm font-black' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 font-bold'"
            class="px-4 py-2 rounded-xl text-xs flex items-center gap-2 transition cursor-pointer"
        >
            <i data-lucide="building-2" class="w-4 h-4"></i>
            <span>Company Early Closure & Credits</span>
            <span class="px-1.5 py-0.5 text-[10px] rounded-full bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 font-mono" x-text="closureStats.total"></span>
        </button>
    </div>

    <!-- Sub-View 1: Individual Regularizations -->
    <div x-show="subTab === 'individual'" class="space-y-6">

    <!-- Top Banner & Submit Button -->
    <div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-5 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
            <span class="text-[10px] font-bold uppercase tracking-widest text-indigo-600 dark:text-indigo-400 font-mono">Regularization Workflow</span>
            <h2 class="text-base font-extrabold text-slate-900 dark:text-white">Attendance Correction & Regularization Center</h2>
            <p class="text-xs text-slate-500 dark:text-slate-400">Submit, audit, and approve adjustments for missed punches and device sync anomalies.</p>
        </div>

        <button
            @click="openSubmitModal()"
            class="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl text-xs font-bold shadow-md shadow-indigo-600/20 transition cursor-pointer shrink-0"
        >
            <i data-lucide="plus" class="w-4 h-4"></i>
            <span>Request Regularization</span>
        </button>
    </div>

    <!-- 4 KPI Quick-Filter Cards -->
    <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
        
        <!-- Pending Approval -->
        <div 
            @click="filterStatus = 'Pending'; refreshIcons()"
            :class="filterStatus === 'Pending' ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-300 dark:border-amber-700 ring-2 ring-amber-400/20' : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800'"
            class="p-4 rounded-2xl border transition cursor-pointer shadow-xs hover:border-amber-300"
        >
            <span class="text-[10px] font-bold text-amber-700 dark:text-amber-400 uppercase block tracking-wider">Pending Approval</span>
            <span class="text-2xl font-black font-mono text-amber-800 dark:text-amber-300" x-text="stats.pending"></span>
        </div>

        <!-- Approved -->
        <div 
            @click="filterStatus = 'Approved'; refreshIcons()"
            :class="filterStatus === 'Approved' ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-700 ring-2 ring-emerald-400/20' : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800'"
            class="p-4 rounded-2xl border transition cursor-pointer shadow-xs hover:border-emerald-300"
        >
            <span class="text-[10px] font-bold text-emerald-700 dark:text-emerald-400 uppercase block tracking-wider">Approved</span>
            <span class="text-2xl font-black font-mono text-emerald-800 dark:text-emerald-300" x-text="stats.approved"></span>
        </div>

        <!-- Rejected -->
        <div 
            @click="filterStatus = 'Rejected'; refreshIcons()"
            :class="filterStatus === 'Rejected' ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-300 dark:border-rose-700 ring-2 ring-rose-400/20' : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800'"
            class="p-4 rounded-2xl border transition cursor-pointer shadow-xs hover:border-rose-300"
        >
            <span class="text-[10px] font-bold text-rose-700 dark:text-rose-400 uppercase block tracking-wider">Rejected</span>
            <span class="text-2xl font-black font-mono text-rose-800 dark:text-rose-300" x-text="stats.rejected"></span>
        </div>

        <!-- Total Requests -->
        <div 
            @click="filterStatus = 'All'; refreshIcons()"
            :class="filterStatus === 'All' ? 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-300 dark:border-indigo-700 ring-2 ring-indigo-400/20' : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800'"
            class="p-4 rounded-2xl border transition cursor-pointer shadow-xs hover:border-indigo-300"
        >
            <span class="text-[10px] font-bold text-indigo-700 dark:text-indigo-400 uppercase block tracking-wider">Total Requests</span>
            <span class="text-2xl font-black font-mono text-indigo-900 dark:text-indigo-300" x-text="stats.total"></span>
        </div>

    </div>

    <!-- Regularization Queue List -->
    <div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
        
        <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
            <div class="flex items-center gap-2">
                <i data-lucide="shield-check" class="w-4 h-4 text-indigo-600 dark:text-indigo-400"></i>
                <span class="font-bold text-slate-900 dark:text-white text-sm">Regularization Queue (<span x-text="filteredCorrections.length"></span>)</span>
            </div>

            <div class="flex items-center gap-2 w-full sm:w-auto">
                <div class="relative w-full sm:w-64">
                    <i data-lucide="search" class="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400"></i>
                    <input
                        type="text"
                        placeholder="Search staff, code, reason..."
                        x-model="searchQuery"
                        @input="refreshIcons()"
                        class="w-full text-xs pl-8 pr-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                </div>
            </div>
        </div>

        <div class="divide-y divide-slate-100 dark:divide-slate-800">
            <template x-if="filteredCorrections.length === 0">
                <div class="py-12 text-center text-slate-400 text-xs italic">
                    <i data-lucide="inbox" class="w-10 h-10 mx-auto mb-2 text-slate-300 dark:text-slate-600"></i>
                    No regularization requests found for status "<span x-text="filterStatus"></span>".
                </div>
            </template>

            <template x-for="c in filteredCorrections" :key="c.id">
                <div class="py-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 hover:bg-slate-50/60 dark:hover:bg-slate-800/40 p-3.5 rounded-2xl transition border border-transparent hover:border-slate-200/50 dark:hover:border-slate-700/50">
                    
                    <div class="space-y-2 flex-1 min-w-0">
                        <!-- Employee Header & Date -->
                        <div class="flex flex-wrap items-center gap-2">
                            <div class="w-7 h-7 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 font-bold flex items-center justify-center text-xs shrink-0 border border-indigo-200/40">
                                <span x-text="(c.employee_name || c.name || 'E').substr(0, 2).toUpperCase()"></span>
                            </div>
                            <span class="font-bold text-slate-900 dark:text-white text-xs" x-text="c.employee_name || c.name || 'Employee'"></span>
                            <span class="text-[10px] text-slate-400 font-mono" x-text="'(' + (c.employee_code || c.employee_id || 'EMP') + ' &bull; ' + (c.department_name || c.department || 'General') + ')'"></span>
                            <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                                Date: <span x-text="c.attendance_date || c.date"></span>
                            </span>
                            <template x-if="c.request_type">
                                <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300" x-text="c.request_type"></span>
                            </template>
                        </div>

                        <!-- Comparison Timings -->
                        <div class="flex flex-wrap items-center gap-3 text-xs font-mono">
                            <span class="text-slate-500 dark:text-slate-400">
                                Original: <strong class="text-slate-700 dark:text-slate-200" x-text="c.original_check_in || c.checkIn || '--:--'"></strong> to <strong class="text-slate-700 dark:text-slate-200" x-text="c.original_check_out || c.checkOut || '--:--'"></strong>
                            </span>
                            <i data-lucide="arrow-right" class="w-3.5 h-3.5 text-slate-300 dark:text-slate-600"></i>
                            <span class="text-indigo-700 dark:text-indigo-400 font-bold">
                                Requested: <span x-text="c.proposed_check_in || c.requestedCheckIn || '--:--'"></span> to <span x-text="c.proposed_check_out || c.requestedCheckOut || '--:--'"></span>
                            </span>
                        </div>

                        <!-- Detailed Reason Quote Box -->
                        <p class="text-xs text-slate-600 dark:text-slate-300 italic bg-slate-50 dark:bg-slate-800/80 p-2.5 rounded-xl border border-slate-200/80 dark:border-slate-700 leading-relaxed" x-text="'&ldquo;' + (c.reason || 'No specific explanation provided') + '&rdquo;'"></p>

                        <!-- Reviewer & Timestamp Metadata -->
                        <div class="text-[10px] text-slate-400 flex flex-wrap items-center gap-3 pt-0.5">
                            <span>Submitted: <strong class="text-slate-600 dark:text-slate-300" x-text="c.created_at || c.requestedAt || 'Just now'"></strong></span>
                            <template x-if="c.reviewed_by || c.approvedBy">
                                <span>Reviewed by: <strong class="text-slate-700 dark:text-slate-200" x-text="c.reviewed_by || c.approvedBy"></strong></span>
                            </template>
                            <template x-if="c.remarks">
                                <span class="text-indigo-600 dark:text-indigo-400 font-medium">Remarks: <span x-text="c.remarks"></span></span>
                            </template>
                        </div>
                    </div>

                    <!-- Status Pill & Action Buttons -->
                    <div class="flex items-center gap-3 shrink-0 self-end md:self-center">
                        <span :class="getCorrectionStatusBadgeClass(c.status)" class="px-3 py-1 rounded-full text-xs font-extrabold border capitalize" x-text="c.status || 'Pending'"></span>

                        <template x-if="(c.status || '').toLowerCase() === 'pending'">
                            <div class="flex items-center gap-1.5">
                                <button
                                    @click="openActionModal(c.id, 'approve')"
                                    :disabled="actionLoadingId === c.id"
                                    class="flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition cursor-pointer shadow-xs disabled:opacity-50"
                                >
                                    <i data-lucide="check" class="w-3.5 h-3.5"></i>
                                    <span>Approve</span>
                                </button>
                                <button
                                    @click="openActionModal(c.id, 'reject')"
                                    :disabled="actionLoadingId === c.id"
                                    class="flex items-center gap-1 px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition cursor-pointer shadow-xs disabled:opacity-50"
                                >
                                    <i data-lucide="x" class="w-3.5 h-3.5"></i>
                                    <span>Reject</span>
                                </button>
                            </div>
                        </template>
                    </div>

                </div>
            </template>
        </div>

    </div>

    <!-- MODAL: Request Attendance Regularization -->
    <div x-show="showSubmitModal" x-cloak class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
        <div @click.away="closeSubmitModal()" class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 w-full max-w-lg shadow-2xl p-6 space-y-4 text-xs">
            
            <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <div class="flex items-center gap-2">
                    <div class="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                        <i data-lucide="clock" class="w-4 h-4"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-slate-900 dark:text-white text-base">Request Attendance Regularization</h3>
                        <p class="text-[11px] text-slate-400">Submit punch correction for manager review and approval</p>
                    </div>
                </div>
                <button @click="closeSubmitModal()" class="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg cursor-pointer">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>

            <form @submit.prevent="submitRegularization()" class="space-y-4 text-xs">
                
                <!-- Employee Selection -->
                <div class="space-y-1">
                    <label class="font-bold text-slate-700 dark:text-slate-300">Employee *</label>
                    <select
                        x-model="selectedEmpId"
                        class="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-slate-800 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-hidden"
                    >
                        <?php foreach ($employees as $e): ?>
                            <option value="<?= $e['id'] ?>"><?= esc(trim(($e['first_name'] ?? '') . ' ' . ($e['last_name'] ?? '')) ?: ($e['name'] ?? $e['employee_code'] ?? 'EMP')) ?> (<?= esc($e['employee_code'] ?? 'EMP') ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Regularization Category / Type -->
                <div class="space-y-1">
                    <label class="font-bold text-slate-700 dark:text-slate-300">Adjustment Type *</label>
                    <select
                        x-model="requestType"
                        class="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-slate-800 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-hidden"
                    >
                        <option value="Missing Check-In">Missing Check-In (Forgot Morning Punch)</option>
                        <option value="Missed Check-Out">Missed Check-Out (Left without Evening Punch)</option>
                        <option value="Time Adjustment">Time Adjustment (Biometric Delay / Traffic)</option>
                        <option value="Device Anomaly">Device Anomaly / Terminal Hardware Offline</option>
                        <option value="Out on Duty">Out on Duty / Client On-Site Deployment</option>
                    </select>
                </div>

                <!-- Attendance Date -->
                <div class="space-y-1">
                    <label class="font-bold text-slate-700 dark:text-slate-300">Attendance Date *</label>
                    <input
                        type="date"
                        x-model="selectedDate"
                        required
                        class="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-slate-800 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-hidden"
                    />
                </div>

                <!-- Timings -->
                <div class="grid grid-cols-2 gap-3">
                    <div class="space-y-1">
                        <label class="font-bold text-slate-700 dark:text-slate-300">Adjusted Check-In</label>
                        <input
                            type="time"
                            step="1"
                            x-model="reqCheckIn"
                            required
                            class="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold font-mono text-slate-800 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-hidden"
                        />
                    </div>
                    <div class="space-y-1">
                        <label class="font-bold text-slate-700 dark:text-slate-300">Adjusted Check-Out</label>
                        <input
                            type="time"
                            step="1"
                            x-model="reqCheckOut"
                            required
                            class="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold font-mono text-slate-800 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-hidden"
                        />
                    </div>
                </div>

                <!-- Detailed Reason / Business Justification -->
                <div class="space-y-1">
                    <label class="font-bold text-slate-700 dark:text-slate-300">Detailed Reason / Business Justification *</label>
                    <textarea
                        rows="3"
                        required
                        placeholder="e.g. Biometric terminal offline at gate; client meeting on site; power outage..."
                        x-model="reason"
                        class="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-white placeholder-slate-400 focus:ring-2 focus:ring-indigo-500 outline-hidden"
                    ></textarea>
                </div>

                <!-- Modal Actions -->
                <div class="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                    <button
                        type="button"
                        @click="closeSubmitModal()"
                        class="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl font-bold transition cursor-pointer"
                    >
                        Cancel
                    </button>
                    <button
                        type="submit"
                        :disabled="isSubmitting"
                        class="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold shadow-md shadow-indigo-600/20 transition cursor-pointer flex items-center gap-1.5 disabled:opacity-50"
                    >
                        <span x-show="!isSubmitting">Submit Regularization</span>
                        <span x-show="isSubmitting" class="flex items-center gap-1">
                            <i data-lucide="loader" class="w-3.5 h-3.5 animate-spin"></i> Processing...
                        </span>
                    </button>
                </div>

            </form>
        </div>
    </div>

    <!-- MODAL: Reviewer Remarks (Approve / Reject) -->
    <div x-show="showRemarksModal" x-cloak class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
        <div @click.away="showRemarksModal = false" class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 w-full max-w-md shadow-2xl p-6 space-y-4 text-xs">
            
            <div class="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                <h3 class="font-bold text-slate-900 dark:text-white text-sm capitalize" x-text="activeActionType === 'approve' ? 'Approve Regularization Request' : 'Reject Regularization Request'"></h3>
                <button @click="showRemarksModal = false" class="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                    <i data-lucide="x" class="w-4 h-4"></i>
                </button>
            </div>

            <div class="space-y-2">
                <label class="font-bold text-slate-700 dark:text-slate-300">Manager / Auditor Remarks</label>
                <textarea
                    rows="3"
                    x-model="remarksText"
                    placeholder="Enter audit remarks or reason for decision..."
                    class="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-white placeholder-slate-400 focus:ring-2 focus:ring-indigo-500 outline-hidden text-xs"
                ></textarea>
            </div>

            <div class="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                    type="button"
                    @click="showRemarksModal = false"
                    class="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold hover:bg-slate-200"
                >
                    Cancel
                </button>
                <button
                    type="button"
                    @click="confirmAction()"
                    :class="activeActionType === 'approve' ? 'bg-emerald-600 hover:bg-emerald-700 text-white' : 'bg-rose-600 hover:bg-rose-700 text-white'"
                    class="px-4 py-2 rounded-xl font-bold shadow-xs transition"
                >
                    <span x-text="activeActionType === 'approve' ? 'Confirm Approval' : 'Confirm Rejection'"></span>
                </button>
            </div>

        </div>
    </div>

    <!-- Hidden fallback form for standard non-AJAX submissions -->
    <form id="fallbackCorrectionForm" action="<?= base_url('attendance/correction/submit') ?>" method="POST" class="hidden">
        <?= csrf_field() ?>
        <input type="hidden" name="employee_id" :value="selectedEmpId">
        <input type="hidden" name="attendance_date" :value="selectedDate">
        <input type="hidden" name="request_type" :value="requestType">
        <input type="hidden" name="proposed_check_in" :value="reqCheckIn">
        <input type="hidden" name="proposed_check_out" :value="reqCheckOut">
        <input type="hidden" name="reason" :value="reason">
    </form>

    </div><!-- End of subTab === 'individual' -->

    <!-- Sub-View 2: Company Early Closure & Full-Day Credits -->
    <?= view('attendance/tabs/early_closures') ?>

</div>
