<!-- TAB: Monthly Muster Roll & Timesheet Ledger -->
<script>
window.monthlyAttendanceModule = function() {
    return {
        musterList: <?= json_encode($monthlyMuster ?? []) ?>,
        departments: <?= json_encode($departments ?? []) ?>,
        branches: <?= json_encode($branches ?? []) ?>,
        selectedYear: <?= (int)($year ?? date('Y')) ?>,
        selectedMonth: <?= (int)($month ?? date('n')) ?>,
        deptFilter: 'all',
        branchFilter: 'all',
        searchQuery: '',
        isLoading: false,

        monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],

        get monthName() {
            return this.monthNames[this.selectedMonth - 1] || 'Month';
        },

        async fetchMuster() {
            this.isLoading = true;
            try {
                const params = new URLSearchParams({
                    year: this.selectedYear,
                    month: this.selectedMonth
                });
                if (this.deptFilter !== 'all') params.append('department_id', this.deptFilter);
                if (this.branchFilter !== 'all') params.append('branch_id', this.branchFilter);

                const res = await fetch(`<?= base_url('attendance/muster-ajax') ?>?${params.toString()}`);
                const data = await res.json();
                if (data.status === 'success' && data.data && data.data.muster) {
                    this.musterList = data.data.muster;
                }
            } catch (err) {
                console.error('Error loading monthly muster:', err);
            } finally {
                this.isLoading = false;
            }
        },

        onMonthChange(newMonth) {
            this.selectedMonth = parseInt(newMonth);
            this.fetchMuster();
        },

        onYearChange(newYear) {
            this.selectedYear = parseInt(newYear);
            this.fetchMuster();
        },

        get filteredMuster() {
            return (this.musterList || []).filter(m => {
                if (this.deptFilter !== 'all' && (m.department_id !== this.deptFilter && m.department_name !== this.deptFilter)) return false;
                if (this.branchFilter !== 'all' && (m.branch_id !== this.branchFilter && m.branch_name !== this.branchFilter)) return false;
                if (this.searchQuery) {
                    const q = this.searchQuery.toLowerCase();
                    const name = (m.employee_name || '').toLowerCase();
                    const code = (m.employee_code || m.employee_id || '').toLowerCase();
                    if (!name.includes(q) && !code.includes(q)) return false;
                }
                return true;
            });
        },

        get orgTotals() {
            const list = this.filteredMuster;
            let totalWorked = 0;
            let totalOT = 0;
            let totalLate = 0;
            let totalPresent = 0;
            let totalAbsent = 0;
            let totalLop = 0;

            list.forEach(m => {
                totalWorked += parseFloat(m.total_worked_hours || m.worked_hours || 0);
                totalOT += parseFloat(m.total_ot_hours || m.overtime_hours || 0);
                totalLate += parseInt(m.late_days || 0);
                totalPresent += parseInt(m.present_days || 0);
                totalAbsent += parseInt(m.absent_days || 0);
                totalLop += parseFloat(m.lop_days || 0);
            });

            return {
                totalStaff: list.length,
                totalWorked: (Math.round(totalWorked * 10) / 10).toFixed(1),
                totalOT: (Math.round(totalOT * 10) / 10).toFixed(1),
                totalLate: totalLate,
                totalPresent: totalPresent,
                totalAbsent: totalAbsent,
                totalLop: (Math.round(totalLop * 10) / 10).toFixed(1)
            };
        },

        exportMusterCSV() {
            let csv = "Employee ID,Name,Department,Branch,Calendar Days,Working Days,Weekly Off,Holidays,Present,Absent,Paid Leave,Unpaid Leave,Half Days,Late,Early Out,Missing Punch,Req Hours,Worked Hours,Daily OT,OffDay OT,Total OT,Attendance %,Punctuality %\n";
            this.filteredMuster.forEach(r => {
                const empId = r.employee_code || r.employee_id || '';
                const empName = (r.employee_name || '').replace(/"/g, '""');
                const dept = (r.department_name || '').replace(/"/g, '""');
                const branch = (r.branch_name || '').replace(/"/g, '""');
                const calDays = r.calendar_days || r.total_days || 30;
                const workDays = r.working_days || 0;
                const offDays = r.weekly_off_days || 0;
                const holidays = r.holiday_days || 0;
                const present = r.present_days || 0;
                const absent = r.absent_days || 0;
                const paidLeave = r.paid_leave_days || 0;
                const unpaidLeave = r.unpaid_leave_days || 0;
                const halfDays = r.half_days || 0;
                const late = r.late_days || 0;
                const earlyOut = r.early_out_days || 0;
                const missing = r.missing_punch_days || 0;
                const reqHours = r.required_hours || 0;
                const workedHours = r.total_worked_hours || r.worked_hours || 0;
                const dailyOT = r.daily_ot_hours || 0;
                const offDayOT = r.off_day_ot_hours || 0;
                const totalOT = r.total_ot_hours || r.overtime_hours || 0;
                const attPct = r.attendance_rate || 100;
                const punctPct = r.punctuality_rate || 100;

                csv += `${empId},"${empName}","${dept}","${branch}",${calDays},${workDays},${offDays},${holidays},${present},${absent},${paidLeave},${unpaidLeave},${halfDays},${late},${earlyOut},${missing},${reqHours},${workedHours},${dailyOT},${offDayOT},${totalOT},${attPct},${punctPct}\n`;
            });

            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = `Monthly_Muster_Roll_${this.monthName}_${this.selectedYear}.csv`;
            link.click();
        },

        printMuster() {
            window.print();
        },

        inspectEmployee(empId) {
            if (window.attendanceApp && typeof window.attendanceApp.selectEmployee === 'function') {
                window.attendanceApp.selectEmployee(empId);
            } else {
                window.location = `<?= base_url('attendance') ?>?tab=individual&emp_id=${encodeURIComponent(empId)}&year=${this.selectedYear}&month=${this.selectedMonth}`;
            }
        }
    };
};
</script>

<div x-show="activeTab === 'monthly'" class="space-y-6 animate-in fade-in duration-200" x-data="monthlyAttendanceModule()" x-init="
    if (activeTab === 'monthly' && (!musterList || !musterList.length)) fetchMuster();
    window.addEventListener('tab-changed', (e) => {
        if (e.detail?.tab === 'monthly' && (!musterList || !musterList.length)) fetchMuster();
    });
">

    <!-- Monthly Header & Filter Controls -->
    <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
        
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
            <div>
                <span class="text-[10px] font-bold uppercase tracking-widest text-indigo-600 dark:text-indigo-400 font-mono">HR Muster Master</span>
                <h2 class="text-base font-extrabold text-slate-900 dark:text-white">
                    Monthly Attendance & Overtime Ledger (<span x-text="monthName + ' ' + selectedYear"></span>)
                </h2>
                <p class="text-xs text-slate-500 dark:text-slate-400">Authoritative aggregation of calendar days, shift credit, working hours, and payable overtime.</p>
            </div>

            <div class="flex items-center gap-2">
                <button
                    type="button"
                    @click="exportMusterCSV()"
                    class="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/50 dark:hover:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300 rounded-xl text-xs font-bold transition border border-indigo-200 dark:border-indigo-800 cursor-pointer"
                >
                    <i data-lucide="download" class="w-3.5 h-3.5"></i>
                    Export Muster Roll CSV
                </button>
                <button
                    type="button"
                    @click="printMuster()"
                    class="flex items-center gap-1.5 px-3.5 py-2 bg-slate-900 hover:bg-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition cursor-pointer"
                >
                    <i data-lucide="printer" class="w-3.5 h-3.5"></i>
                    Print Muster
                </button>
            </div>
        </div>

        <!-- Filters Grid -->
        <div class="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
            
            <!-- Search -->
            <div class="relative col-span-2 sm:col-span-1">
                <i data-lucide="search" class="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400"></i>
                <input
                    type="text"
                    placeholder="Search employee..."
                    x-model="searchQuery"
                    class="w-full text-xs pl-8 pr-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:bg-white dark:focus:bg-slate-900"
                />
            </div>

            <!-- Department Filter -->
            <div>
                <select
                    x-model="deptFilter"
                    @change="fetchMuster()"
                    class="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-white focus:outline-none font-medium"
                >
                    <option value="all">All Departments</option>
                    <template x-for="d in departments" :key="d.id">
                        <option :value="d.id" x-text="d.name"></option>
                    </template>
                </select>
            </div>

            <!-- Branch Filter -->
            <div>
                <select
                    x-model="branchFilter"
                    @change="fetchMuster()"
                    class="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-white focus:outline-none font-medium"
                >
                    <option value="all">All Branches</option>
                    <template x-for="b in branches" :key="b.id">
                        <option :value="b.id" x-text="b.name"></option>
                    </template>
                </select>
            </div>

            <!-- Month Filter -->
            <div>
                <select
                    x-model="selectedMonth"
                    @change="onMonthChange($event.target.value)"
                    class="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-white focus:outline-none font-bold"
                >
                    <template x-for="(m, idx) in monthNames" :key="idx">
                        <option :value="idx + 1" :selected="selectedMonth === (idx + 1)" x-text="m"></option>
                    </template>
                </select>
            </div>

            <!-- Year Filter -->
            <div>
                <select
                    x-model="selectedYear"
                    @change="onYearChange($event.target.value)"
                    class="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-white focus:outline-none font-bold"
                >
                    <option value="2024">Year 2024</option>
                    <option value="2025">Year 2025</option>
                    <option value="2026">Year 2026</option>
                    <option value="2027">Year 2027</option>
                </select>
            </div>

        </div>

    </div>

    <!-- KPI Highlights Strip (4 Cards) -->
    <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div class="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <span class="text-[10px] font-bold text-slate-400 uppercase block">Total Workforce</span>
            <div class="flex items-baseline gap-1.5 my-1">
                <span class="text-2xl font-black font-mono text-slate-900 dark:text-white" x-text="orgTotals.totalStaff"></span>
                <span class="text-xs text-slate-500 font-bold">Staff</span>
            </div>
            <span class="text-[11px] text-slate-400">Active roster in ledger</span>
        </div>

        <div class="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <span class="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase block">Total Productive Hours</span>
            <div class="flex items-baseline gap-1.5 my-1">
                <span class="text-2xl font-black font-mono text-emerald-700 dark:text-emerald-400" x-text="orgTotals.totalWorked"></span>
                <span class="text-xs text-emerald-600 font-bold">hrs</span>
            </div>
            <span class="text-[11px] text-emerald-600">Company actual worked</span>
        </div>

        <div class="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <span class="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase block">Payable Overtime Hours</span>
            <div class="flex items-baseline gap-1.5 my-1">
                <span class="text-2xl font-black font-mono text-indigo-700 dark:text-indigo-400" x-text="orgTotals.totalOT"></span>
                <span class="text-xs text-indigo-600 font-bold">hrs</span>
            </div>
            <span class="text-[11px] text-indigo-600">Daily + Weekend + Holiday OT</span>
        </div>

        <div class="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <span class="text-[10px] font-bold text-amber-600 dark:text-amber-400 uppercase block">Total Late Incidents</span>
            <div class="flex items-baseline gap-1.5 my-1">
                <span class="text-2xl font-black font-mono text-amber-700 dark:text-amber-400" x-text="orgTotals.totalLate"></span>
                <span class="text-xs text-amber-600 font-bold">Times</span>
            </div>
            <span class="text-[11px] text-amber-600">Arrivals after grace window</span>
        </div>
    </div>

    <!-- Complete Monthly Muster Table (20 Columns) -->
    <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-sm overflow-hidden relative">
        
        <!-- Loading Overlay -->
        <div x-show="isLoading" class="absolute inset-0 bg-white/70 dark:bg-slate-900/70 backdrop-blur-xs flex items-center justify-center z-20">
            <div class="flex items-center gap-2 px-4 py-2 rounded-xl bg-white dark:bg-slate-800 shadow-md border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-300">
                <i data-lucide="loader-2" class="w-4 h-4 animate-spin text-indigo-600"></i>
                Calculating Muster Roll...
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-xs">
                <thead>
                    <tr class="bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-400 font-bold border-b border-slate-100 dark:border-slate-800 whitespace-nowrap">
                        <th class="p-3.5 sticky left-0 bg-slate-50 dark:bg-slate-800 z-10">Employee ID & Name</th>
                        <th class="p-3.5">Department</th>
                        <th class="p-3.5 text-center">Cal. Days</th>
                        <th class="p-3.5 text-center">Work Days</th>
                        <th class="p-3.5 text-center">Off Days</th>
                        <th class="p-3.5 text-center">Holidays</th>
                        <th class="p-3.5 text-center text-emerald-700 dark:text-emerald-400">Present</th>
                        <th class="p-3.5 text-center text-rose-700 dark:text-rose-400">Absent</th>
                        <th class="p-3.5 text-center text-purple-700 dark:text-purple-400">Paid Leave</th>
                        <th class="p-3.5 text-center text-slate-600 dark:text-slate-400">Unpaid Leave</th>
                        <th class="p-3.5 text-center text-indigo-700 dark:text-indigo-400">Half Day</th>
                        <th class="p-3.5 text-center text-amber-700 dark:text-amber-400">Late</th>
                        <th class="p-3.5 text-center text-indigo-700 dark:text-indigo-400">Early Out</th>
                        <th class="p-3.5 text-center text-orange-700 dark:text-orange-400">Missing</th>
                        <th class="p-3.5 text-center bg-indigo-50/50 dark:bg-indigo-950/30 text-indigo-700 dark:text-indigo-300 font-bold">Payable Days</th>
                        <th class="p-3.5 text-center bg-rose-50/50 dark:bg-rose-950/30 text-rose-700 dark:text-rose-300 font-bold">LOP Days</th>
                        <th class="p-3.5 text-right font-bold">Worked (h)</th>
                        <th class="p-3.5 text-right font-bold text-emerald-700 dark:text-emerald-400">Total OT (h)</th>
                        <th class="p-3.5 text-center font-bold text-indigo-700 dark:text-indigo-400">Att %</th>
                        <th class="p-3.5 text-center font-bold text-slate-700 dark:text-slate-400">Punct %</th>
                        <th class="p-3.5 text-right">Action</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-800 font-mono text-[11px] whitespace-nowrap">
                    <template x-if="filteredMuster.length === 0">
                        <tr>
                            <td colspan="21" class="py-12 text-center text-slate-400 text-xs font-sans">
                                No monthly muster records match the selected filters.
                            </td>
                        </tr>
                    </template>
                    <template x-for="r in filteredMuster" :key="r.employee_id">
                        <tr class="hover:bg-slate-50/70 dark:hover:bg-slate-800/50 transition">
                            
                            <!-- Employee Sticky Column -->
                            <td class="p-3.5 font-sans sticky left-0 bg-white dark:bg-slate-900 z-10">
                                <div class="flex items-center gap-2.5">
                                    <div class="w-7 h-7 rounded-lg bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 font-bold text-xs flex items-center justify-center shrink-0">
                                        <span x-text="(r.employee_name || 'E').substr(0, 2).toUpperCase()"></span>
                                    </div>
                                    <div>
                                        <div class="font-bold text-slate-900 dark:text-white leading-tight truncate max-w-40" x-text="r.employee_name"></div>
                                        <div class="text-[10px] text-slate-400 font-mono" x-text="r.employee_code || r.employee_id"></div>
                                    </div>
                                </div>
                            </td>

                            <!-- Department -->
                            <td class="p-3.5 font-sans text-slate-700 dark:text-slate-300" x-text="r.department_name || 'General'"></td>

                            <!-- Cal Days -->
                            <td class="p-3.5 text-center text-slate-600 dark:text-slate-400" x-text="r.calendar_days || r.total_days || 30"></td>

                            <!-- Work Days -->
                            <td class="p-3.5 text-center font-bold text-slate-800 dark:text-slate-200" x-text="r.working_days || 0"></td>

                            <!-- Off Days -->
                            <td class="p-3.5 text-center text-slate-600 dark:text-slate-400" x-text="r.weekly_off_days || 0"></td>

                            <!-- Holidays -->
                            <td class="p-3.5 text-center text-blue-700 dark:text-blue-400" x-text="r.holiday_days || 0"></td>

                            <!-- Present -->
                            <td class="p-3.5 text-center font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-50/40 dark:bg-emerald-950/20" x-text="r.present_days || 0"></td>

                            <!-- Absent -->
                            <td class="p-3.5 text-center font-bold text-rose-700 dark:text-rose-400 bg-rose-50/40 dark:bg-rose-950/20" x-text="r.absent_days || 0"></td>

                            <!-- Paid Leave -->
                            <td class="p-3.5 text-center text-purple-700 dark:text-purple-400" x-text="r.paid_leave_days || 0"></td>

                            <!-- Unpaid Leave -->
                            <td class="p-3.5 text-center text-slate-600 dark:text-slate-400" x-text="r.unpaid_leave_days || 0"></td>

                            <!-- Half Day -->
                            <td class="p-3.5 text-center text-indigo-700 dark:text-indigo-400" x-text="r.half_days || 0"></td>

                            <!-- Late -->
                            <td class="p-3.5 text-center font-bold text-amber-700 dark:text-amber-400" x-text="r.late_days || 0"></td>

                            <!-- Early Out -->
                            <td class="p-3.5 text-center text-indigo-700 dark:text-indigo-400" x-text="r.early_out_days || 0"></td>

                            <!-- Missing -->
                            <td class="p-3.5 text-center text-orange-700 dark:text-orange-400" x-text="r.missing_punch_days || 0"></td>

                            <!-- Payable Days -->
                            <td class="p-3.5 text-center font-black text-indigo-700 dark:text-indigo-400 bg-indigo-50/60 dark:bg-indigo-950/40" x-text="r.payable_days || 0"></td>

                            <!-- LOP Days -->
                            <td class="p-3.5 text-center font-bold text-rose-700 dark:text-rose-400 bg-rose-50/60 dark:bg-rose-950/40" x-text="r.lop_days || 0"></td>

                            <!-- Worked Hours -->
                            <td class="p-3.5 text-right font-bold text-slate-900 dark:text-white" x-text="(parseFloat(r.total_worked_hours || r.worked_hours || 0)).toFixed(1) + 'h'"></td>

                            <!-- Total OT -->
                            <td class="p-3.5 text-right font-black text-emerald-700 dark:text-emerald-400 bg-emerald-50/50 dark:bg-emerald-950/30">
                                <div x-text="'+' + (parseFloat(r.total_ot_hours || r.overtime_hours || 0)).toFixed(1) + 'h'"></div>
                                <div class="text-[10px] font-normal text-slate-500 dark:text-slate-400" x-text="'(' + Math.round(parseFloat(r.total_ot_hours || r.overtime_hours || 0) * 60) + 'm)'"></div>
                            </td>

                            <!-- Att % -->
                            <td class="p-3.5 text-center font-bold text-indigo-700 dark:text-indigo-400" x-text="(r.attendance_rate || 0) + '%'"></td>

                            <!-- Punct % -->
                            <td class="p-3.5 text-center font-bold text-slate-700 dark:text-slate-400" x-text="(r.punctuality_rate || 0) + '%'"></td>

                            <!-- Action -->
                            <td class="p-3.5 text-right font-sans">
                                <button
                                    type="button"
                                    @click="inspectEmployee(r.employee_id)"
                                    class="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-[11px] font-bold transition cursor-pointer"
                                >
                                    Inspect
                                </button>
                            </td>

                        </tr>
                    </template>
                </tbody>
            </table>
        </div>

    </div>

</div>
