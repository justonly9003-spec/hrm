<!-- TAB: Attendance Reports & Data Export Center -->
<div x-show="activeTab === 'reports'" class="space-y-6 animate-in fade-in duration-200">

    <?php
    $attCatalog = \App\Services\AttendanceReportService::getReportCatalog();
    $repDescriptions = [
        'daily_summary'         => 'Total Employees, Present, Absent, Late, Leave, Holiday, Weekly Off',
        'monthly_summary'       => 'Employee-wise monthly attendance, absence, and payable days summary',
        'employee_details'      => 'Daily Check-in, Check-out, Regular Hours, Worked Hours, Overtime',
        'attendance_register'   => 'Date-wise comprehensive attendance register for all employees',
        'department_summary'    => 'Department-level attendance percentage, late arrival rate, and work hours',
        'branch_summary'        => 'Branch/Office workforce presence, punctuality, and work hours summary',
        'shift_wise'            => 'Shift-wise assigned staff, presence, late arrivals, and adherence rates',
        'late_attendance'       => 'Late arrival dates, shift start times, delay minutes, and monthly late frequency',
        'early_checkout'        => 'Early departure records before scheduled shift conclusion and duration lost',
        'absenteeism'           => 'Unexcused absence days, absenteeism percentage, and streak monitoring',
        'missing_punch'         => 'Incomplete attendance records missing either check-in or check-out punch',
        'attendance_correction' => 'Regularization requests, adjustment approval audit trail, and original vs proposed times',
        'manual_attendance'     => 'Manually entered or overridden attendance records with operator justification',
        'gps_geofence'          => 'Mobile/remote punches, GPS coordinates, distance, and geofence perimeter violations',
        'qr_kiosk'              => 'Attendance captured via stationary tablet kiosks and dynamic QR scanners',
        'zkteco_sync'           => 'Biometric hardware synchronization history, imported punches, and duplicate audit',
        'worked_hours'          => 'Daily, weekly, and monthly worked hours, scheduled duty, overtime, and shortfalls',
        'attendance_percentage' => 'Multi-level attendance rate percentages across employee, department, and branch',
        'muster_roll'           => 'Statutory labor law muster roll grid of daily attendance status codes (days 1-31)',
        'attendance_exception'  => 'Wrong shifts, duplicate punches within 5 mins, excessive shift hours, and anomalies',
        'joining_boundary'      => 'Pre-joining date boundary audit verifying zero false absent deductions before joining',
        'lock_reopen'           => 'Monthly attendance lock and administrative reopen audit trail with justification notes',
        'roster_vs_actual'      => 'Comparison between scheduled roster shifts and actual punch times, variances, and adherence rates',
    ];
    ?>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

        <!-- Report Generation Configurator Card -->
        <div class="lg:col-span-1 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-xs space-y-4">
            <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <div class="flex items-center gap-2">
                    <i data-lucide="file-spreadsheet" class="w-5 h-5 text-indigo-600"></i>
                    <h3 class="font-black text-slate-800 dark:text-white text-base">23 Standard Reports</h3>
                </div>
                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300">
                    Full Catalog
                </span>
            </div>

            <form id="attendanceReportForm" action="<?= base_url('attendance/export') ?>" method="GET" class="space-y-4 text-xs">
                
                <!-- Report Type -->
                <div>
                    <label class="block font-bold text-slate-700 dark:text-slate-300 mb-1">Select Attendance Report</label>
                    <select name="report_type" id="reportTypeSelector" class="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white font-medium focus:ring-2 focus:ring-indigo-500 outline-hidden">
                        <optgroup label="Summary & Analytics">
                            <option value="daily_summary">1. Daily Attendance Summary</option>
                            <option value="monthly_summary">2. Monthly Attendance Summary</option>
                            <option value="department_summary">5. Department Attendance Summary</option>
                            <option value="branch_summary">6. Branch Attendance Summary</option>
                            <option value="shift_wise">7. Shift-wise Attendance</option>
                            <option value="worked_hours">17. Worked Hours Report</option>
                            <option value="attendance_percentage">18. Attendance Percentage Report</option>
                        </optgroup>
                        <optgroup label="Registers & Details">
                            <option value="employee_details">3. Employee Attendance Details</option>
                            <option value="attendance_register">4. Attendance Register</option>
                            <option value="muster_roll">19. Muster Roll / Register</option>
                        </optgroup>
                        <optgroup label="Punctuality & Discipline">
                            <option value="late_attendance">8. Late Attendance Report</option>
                            <option value="early_checkout">9. Early Checkout Report</option>
                            <option value="absenteeism">10. Absenteeism Report</option>
                        </optgroup>
                        <optgroup label="Exceptions & Anomalies">
                            <option value="missing_punch">11. Missing Punch Report</option>
                            <option value="attendance_exception">20. Attendance Exception Report</option>
                            <option value="roster_vs_actual">23. Roster vs Actual Comparison</option>
                        </optgroup>
                        <optgroup label="Audit & Hardware Tracking">
                            <option value="attendance_correction">12. Attendance Correction Report</option>
                            <option value="manual_attendance">13. Manual Attendance Report</option>
                            <option value="gps_geofence">14. GPS / Geofence Attendance Report</option>
                            <option value="qr_kiosk">15. QR / Kiosk Attendance Report</option>
                            <option value="zkteco_sync">16. ZKTeco Device Sync Report</option>
                            <option value="joining_boundary">21. Joining-date Boundary Report</option>
                            <option value="lock_reopen">22. Attendance Lock / Reopen Report</option>
                        </optgroup>
                    </select>
                </div>

                <!-- Date Range -->
                <div class="grid grid-cols-2 gap-2">
                    <div>
                        <label class="block font-bold text-slate-700 dark:text-slate-300 mb-1">From Date</label>
                        <input type="date" name="from_date" id="repFromDate" value="<?= esc($from) ?>" class="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white font-medium focus:ring-2 focus:ring-indigo-500 outline-hidden">
                    </div>
                    <div>
                        <label class="block font-bold text-slate-700 dark:text-slate-300 mb-1">To Date</label>
                        <input type="date" name="to_date" id="repToDate" value="<?= esc($to) ?>" class="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white font-medium focus:ring-2 focus:ring-indigo-500 outline-hidden">
                    </div>
                </div>

                <!-- Department -->
                <div>
                    <label class="block font-bold text-slate-700 dark:text-slate-300 mb-1">Department</label>
                    <select name="department_id" id="repDeptId" class="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white font-medium focus:ring-2 focus:ring-indigo-500 outline-hidden">
                        <option value="">All Departments</option>
                        <?php foreach ($departments as $d): ?>
                            <option value="<?= $d['id'] ?>"><?= esc($d['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Branch -->
                <div>
                    <label class="block font-bold text-slate-700 dark:text-slate-300 mb-1">Branch / Office</label>
                    <select name="branch_id" id="repBranchId" class="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white font-medium focus:ring-2 focus:ring-indigo-500 outline-hidden">
                        <option value="">All Branches</option>
                        <?php foreach ($branches as $b): ?>
                            <option value="<?= $b['id'] ?>"><?= esc($b['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Action Download & Print Buttons -->
                <div class="grid grid-cols-2 gap-2 mt-4">
                    <button type="submit" class="w-full py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-xs transition flex items-center justify-center gap-1.5 cursor-pointer">
                        <i data-lucide="download-cloud" class="w-4 h-4"></i>
                        <span>Export CSV</span>
                    </button>
                    <button type="button" onclick="openPrintPdfView(true)" class="w-full py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-900 text-white dark:bg-slate-700 dark:hover:bg-slate-600 font-bold text-xs shadow-xs transition flex items-center justify-center gap-1.5 cursor-pointer">
                        <i data-lucide="file-text" class="w-4 h-4"></i>
                        <span>Export PDF / Print</span>
                    </button>
                </div>

                <div class="pt-2 text-center">
                    <a href="<?= base_url('reports') ?>" class="text-[11px] text-indigo-600 hover:underline inline-flex items-center gap-1 font-semibold">
                        <span>Open in Enterprise Analytics Hub</span>
                        <i data-lucide="external-link" class="w-3 h-3"></i>
                    </a>
                </div>

            </form>
        </div>

        <!-- Pre-Packaged Quick Export & Category Grid -->
        <div class="lg:col-span-2 space-y-4">
            
            <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-xs space-y-4">
                <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                    <h3 class="font-bold text-slate-800 dark:text-white text-sm flex items-center gap-2">
                        <i data-lucide="zap" class="w-4 h-4 text-amber-500"></i>
                        Popular Quick Exports & PDF Reports
                    </h3>
                    <span class="text-xs text-slate-400">Direct CSV & PDF</span>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    
                    <!-- 1. Daily Export -->
                    <div class="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-700/60 flex flex-col justify-between space-y-3">
                        <div>
                            <div class="flex items-center gap-2">
                                <span class="p-2 rounded-xl bg-emerald-50 text-emerald-600 font-bold"><i data-lucide="calendar" class="w-4 h-4"></i></span>
                                <div>
                                    <h4 class="font-bold text-slate-900 dark:text-white text-xs">1. Daily Attendance Summary</h4>
                                    <span class="text-[11px] text-slate-500 dark:text-slate-400">Total Staff, Present, Absent, Late, Leave, Holiday, Weekly Off</span>
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-2 gap-2">
                            <a href="<?= base_url('attendance/export?report_type=daily_summary&date=' . $date) ?>" class="py-1.5 px-3 rounded-xl bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-[11px] border border-slate-200 dark:border-slate-700 text-center block transition">
                                CSV
                            </a>
                            <a href="<?= base_url('attendance/print-report?type=daily_summary&from_date=' . $from . '&to_date=' . $to . '&download=pdf') ?>" target="_blank" onclick="safeOpenReport(this.href, event)" class="py-1.5 px-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 text-indigo-700 dark:text-indigo-300 font-bold text-[11px] border border-indigo-200 dark:border-indigo-800 text-center block transition">
                                PDF / Print
                            </a>
                        </div>
                    </div>

                    <!-- 2. Monthly Summary -->
                    <div class="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-700/60 flex flex-col justify-between space-y-3">
                        <div>
                            <div class="flex items-center gap-2">
                                <span class="p-2 rounded-xl bg-indigo-50 text-indigo-600 font-bold"><i data-lucide="layers" class="w-4 h-4"></i></span>
                                <div>
                                    <h4 class="font-bold text-slate-900 dark:text-white text-xs">2. Monthly Attendance Summary</h4>
                                    <span class="text-[11px] text-slate-500 dark:text-slate-400">Employee-level monthly presence, absence, and payable days</span>
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-2 gap-2">
                            <a href="<?= base_url('attendance/export?report_type=monthly_summary&year=' . $year . '&month=' . $month) ?>" class="py-1.5 px-3 rounded-xl bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-[11px] border border-slate-200 dark:border-slate-700 text-center block transition">
                                CSV
                            </a>
                            <a href="<?= base_url('attendance/print-report?type=monthly_summary&year=' . $year . '&month=' . $month . '&download=pdf') ?>" target="_blank" onclick="safeOpenReport(this.href, event)" class="py-1.5 px-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 text-indigo-700 dark:text-indigo-300 font-bold text-[11px] border border-indigo-200 dark:border-indigo-800 text-center block transition">
                                PDF / Print
                            </a>
                        </div>
                    </div>

                    <!-- 3. Employee Details -->
                    <div class="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-700/60 flex flex-col justify-between space-y-3">
                        <div>
                            <div class="flex items-center gap-2">
                                <span class="p-2 rounded-xl bg-blue-50 text-blue-600 font-bold"><i data-lucide="clock" class="w-4 h-4"></i></span>
                                <div>
                                    <h4 class="font-bold text-slate-900 dark:text-white text-xs">3. Employee Punch Details</h4>
                                    <span class="text-[11px] text-slate-500 dark:text-slate-400">Daily check-in, check-out, and worked hours</span>
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-2 gap-2">
                            <a href="<?= base_url('attendance/export?report_type=employee_details&from_date=' . $from . '&to_date=' . $to) ?>" class="py-1.5 px-3 rounded-xl bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-[11px] border border-slate-200 dark:border-slate-700 text-center block transition">
                                CSV
                            </a>
                            <a href="<?= base_url('attendance/print-report?type=employee_details&from_date=' . $from . '&to_date=' . $to . '&download=pdf') ?>" target="_blank" onclick="safeOpenReport(this.href, event)" class="py-1.5 px-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 text-indigo-700 dark:text-indigo-300 font-bold text-[11px] border border-indigo-200 dark:border-indigo-800 text-center block transition">
                                PDF / Print
                            </a>
                        </div>
                    </div>

                    <!-- 19. Statutory Muster Roll -->
                    <div class="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-700/60 flex flex-col justify-between space-y-3">
                        <div>
                            <div class="flex items-center gap-2">
                                <span class="p-2 rounded-xl bg-purple-50 text-purple-600 font-bold"><i data-lucide="table" class="w-4 h-4"></i></span>
                                <div>
                                    <h4 class="font-bold text-slate-900 dark:text-white text-xs">19. Statutory Muster Roll</h4>
                                    <span class="text-[11px] text-slate-500 dark:text-slate-400">31-day presence register and payable days</span>
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-2 gap-2">
                            <a href="<?= base_url('attendance/export?report_type=muster_roll&year=' . $year . '&month=' . $month) ?>" class="py-1.5 px-3 rounded-xl bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-[11px] border border-slate-200 dark:border-slate-700 text-center block transition">
                                CSV
                            </a>
                            <a href="<?= base_url('attendance/print-report?type=muster_roll&year=' . $year . '&month=' . $month . '&download=pdf') ?>" target="_blank" onclick="safeOpenReport(this.href, event)" class="py-1.5 px-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 text-indigo-700 dark:text-indigo-300 font-bold text-[11px] border border-indigo-200 dark:border-indigo-800 text-center block transition">
                                PDF / Print
                            </a>
                        </div>
                    </div>

                </div>

                <!-- 22 Reports Directory -->
                <div class="pt-4 border-t border-slate-100 dark:border-slate-800">
                    <h4 class="font-bold text-slate-700 dark:text-slate-300 text-xs mb-3 flex items-center justify-between">
                        <span class="flex items-center gap-2">
                            <i data-lucide="list-checks" class="w-4 h-4 text-indigo-500"></i>
                            Complete 22-Report Reference Directory
                        </span>
                        <span class="text-[10px] text-slate-400">Click to Export CSV or PDF</span>
                    </h4>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-2.5 text-[11px]">
                        <?php foreach ($attCatalog as $code => $item): ?>
                            <div class="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-700/60 flex flex-col justify-between gap-2 hover:border-indigo-300 dark:hover:border-indigo-700 transition">
                                <div>
                                    <div class="flex items-center justify-between">
                                        <span class="font-bold text-slate-800 dark:text-slate-200">
                                            <span class="text-indigo-600 dark:text-indigo-400 font-black">#<?= $item['number'] ?></span> <?= esc($item['title']) ?>
                                        </span>
                                        <span class="text-[9px] font-semibold px-1.5 py-0.5 rounded-md bg-slate-200/70 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                                            <?= esc($item['category']) ?>
                                        </span>
                                    </div>
                                    <div class="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5 leading-snug">
                                        <strong>Included Fields:</strong> <?= esc($repDescriptions[$code] ?? $item['description']) ?>
                                    </div>
                                </div>
                                
                                <div class="flex items-center justify-end gap-1.5 pt-1 border-t border-slate-200/40 dark:border-slate-700/40">
                                    <a href="<?= base_url('attendance/export?report_type=' . $code . '&from_date=' . $from . '&to_date=' . $to) ?>" class="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 text-[10px] font-bold">
                                        CSV
                                    </a>
                                    <a href="<?= base_url('attendance/print-report?type=' . $code . '&from_date=' . $from . '&to_date=' . $to . '&download=pdf') ?>" target="_blank" onclick="safeOpenReport(this.href, event)" class="px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300 hover:bg-indigo-100 border border-indigo-200 dark:border-indigo-800 text-[10px] font-bold flex items-center gap-1">
                                        <i data-lucide="printer" class="w-3 h-3"></i>
                                        <span>PDF / Print</span>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

            </div>

        </div>

    </div>

</div>

<script>
function safeOpenReport(url, event) {
    if (event) {
        return true;
    }
    window.location.href = url;
}

function openPrintPdfView(autoDownload = true) {
    const selector = document.getElementById('reportTypeSelector');
    const fromInput = document.getElementById('repFromDate');
    const toInput = document.getElementById('repToDate');
    const deptInput = document.getElementById('repDeptId');
    const branchInput = document.getElementById('repBranchId');

    const repType = selector ? selector.value : 'daily_summary';
    const fromVal = fromInput ? fromInput.value : '';
    const toVal = toInput ? toInput.value : '';
    const deptVal = deptInput ? deptInput.value : '';
    const branchVal = branchInput ? branchInput.value : '';

    let url = '<?= base_url('attendance/print-report') ?>'
        + '?type=' + encodeURIComponent(repType)
        + '&from_date=' + encodeURIComponent(fromVal)
        + '&to_date=' + encodeURIComponent(toVal)
        + '&department_id=' + encodeURIComponent(deptVal)
        + '&branch_id=' + encodeURIComponent(branchVal);

    if (autoDownload) {
        url += '&download=pdf';
    }

    safeOpenReport(url);
}
</script>
