<!-- TAB: Tracker Overview (12 KPI Cards, Department Breakdown, Key Employee Roster, Policies & Regularizations) -->
<div x-show="activeTab === 'overview' || activeTab === 'dashboard'" class="space-y-6 animate-in fade-in duration-200">

    <!-- Top Banner with Dynamic Date Selector -->
    <div class="bg-slate-900 text-white p-6 rounded-3xl shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div class="space-y-1">
            <div class="flex items-center gap-2">
                <span class="text-[10px] uppercase font-mono font-bold px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center gap-1.5">
                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    Authoritative Rule Engine Calculated
                </span>
                <?php if (!empty($isDateRange)): ?>
                    <span class="text-xs text-slate-400 font-mono">Range: <?= esc($from) ?> &rarr; <?= esc($to) ?></span>
                    <?php if (!empty($exceptHolidayWeekend)): ?>
                        <span class="text-[10px] text-emerald-400 font-bold font-mono">(Fridays & Holidays Excepted)</span>
                    <?php endif; ?>
                <?php else: ?>
                    <span class="text-xs text-slate-400 font-mono">Date: <?= esc($date) ?></span>
                    <?php if (!empty($exceptHolidayWeekend)): ?>
                        <span class="text-[10px] text-emerald-400 font-bold font-mono">(Excepted)</span>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <h2 class="text-xl md:text-2xl font-black text-white tracking-tight">Organization Attendance Master Overview</h2>
            <p class="text-xs text-slate-400 max-w-xl">
                Live workforce presence tracking, automated grace period validation, overtime engine calculations, and department muster analytics.
            </p>
        </div>

        <div class="bg-slate-800/80 border border-slate-700 p-3.5 rounded-2xl flex items-center gap-3">
            <div class="text-right">
                <span class="text-[9px] uppercase font-bold text-slate-400 block font-mono">
                    <?= !empty($isDateRange) ? 'Active Date Range' : 'Selected Date' ?>
                </span>
                <?php if (!empty($isDateRange)): ?>
                    <span class="text-xs font-bold text-white font-mono"><?= esc($from) ?> to <?= esc($to) ?></span>
                <?php else: ?>
                    <input 
                        type="date"
                        value="<?= esc($date) ?>"
                        @change="changeDate($event.target.value)"
                        class="bg-transparent text-xs font-bold text-white focus:outline-hidden cursor-pointer"
                    />
                <?php endif; ?>
            </div>
            <i data-lucide="calendar" class="w-5 h-5 text-indigo-400 shrink-0"></i>
        </div>
    </div>

    <!-- Primary KPI Grid (12 High-Impact Rule Engine Cards) -->
    <?= view('dashboard/widgets/attendance_overview_kpis', [
        'stats'     => $stats,
        'settings'  => $settings,
        'employees' => $employees,
        'date'      => $date,
    ]) ?>

    <!-- Today's Live Attendance Activity Highlights (Compact Executive Preview) -->
    <?= view('dashboard/widgets/attendance_live_activity', [
        'logs' => $logs,
        'date' => $date,
    ]) ?>

    <!-- Middle Section: Department-Wise Attendance Cards & Quick Employee Muster Stream -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Department Attendance Cards (2 cols on lg) -->
        <div class="lg:col-span-2">
            <?= view('dashboard/widgets/attendance_department_breakdown', [
                'deptBreakdown' => $deptBreakdown,
                'date'          => $date,
            ]) ?>
        </div>

        <!-- Quick Key Employee Roster / Live Muster Stream (1 col on lg) -->
        <div class="lg:col-span-1">
            <?= view('dashboard/widgets/attendance_key_roster', [
                'employees' => $employees,
                'logs'      => $logs,
                'date'      => $date,
            ]) ?>
        </div>
    </div>

    <!-- Bottom 2-Column: Attendance Regularization Queue & Active Policy Engine Summary -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Attendance Correction & Regularization Action Queue (2 cols on lg) -->
        <div class="lg:col-span-2">
            <?= view('dashboard/widgets/attendance_regularization_queue', [
                'pendingCorrections' => $pendingCorrections,
                'date'               => $date,
            ]) ?>
        </div>

        <!-- Active Shift, Policy & Today's Late List (1 col on lg) -->
        <div class="lg:col-span-1 space-y-6">
            <?= view('dashboard/widgets/attendance_policy_summary', [
                'settings' => $settings,
            ]) ?>
            <?= view('dashboard/widgets/attendance_late_arrivals', [
                'logs'  => $logs,
                'stats' => $stats,
                'date'  => $date,
            ]) ?>
        </div>
    </div>

</div>

