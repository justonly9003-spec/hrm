<!-- Sub-View: Company Early Closure & Full-Day Credits Workflow -->
<div x-show="typeof subTab !== 'undefined' && subTab === 'early_closures'" class="space-y-6 animate-in fade-in duration-200">
    
    <!-- Top Banner & Action Buttons -->
    <div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-5 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
            <div class="flex items-center gap-2">
                <span class="text-[10px] font-bold uppercase tracking-widest text-emerald-600 dark:text-emerald-400 font-mono">Controlled Attendance Adjustment</span>
                <span class="px-2 py-0.5 text-[10px] font-bold rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">Non-Destructive Credit</span>
            </div>
            <h2 class="text-base font-extrabold text-slate-900 dark:text-white mt-1">Company Early Closure & Full-Day Attendance Credits</h2>
            <p class="text-xs text-slate-500 dark:text-slate-400">Authorize official early release with full-day credit. Original punch records remain preserved, Daily OT is protected from fake inflation, and full credit is counted toward Weekly Bonus eligibility.</p>
        </div>

        <button
            @click="openEarlyClosureModal()"
            class="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl text-xs font-bold shadow-md shadow-emerald-600/20 transition cursor-pointer shrink-0"
        >
            <i data-lucide="calendar-check" class="w-4 h-4"></i>
            <span>Declare Early Closure</span>
        </button>
    </div>

    <!-- KPI Metric Cards for Early Closures -->
    <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <!-- Total Events -->
        <div class="p-4 rounded-2xl border bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 shadow-xs">
            <span class="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase block tracking-wider">Total Closure Events</span>
            <span class="text-2xl font-black font-mono text-slate-900 dark:text-white" x-text="closureStats.total"></span>
        </div>

        <!-- Approved & Active -->
        <div class="p-4 rounded-2xl border bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-700 shadow-xs">
            <span class="text-[10px] font-bold text-emerald-700 dark:text-emerald-400 uppercase block tracking-wider">Approved & Credited</span>
            <span class="text-2xl font-black font-mono text-emerald-800 dark:text-emerald-300" x-text="closureStats.approved"></span>
        </div>

        <!-- Total Credited Time -->
        <div class="p-4 rounded-2xl border bg-indigo-50 dark:bg-indigo-950/40 border-indigo-300 dark:border-indigo-700 shadow-xs">
            <span class="text-[10px] font-bold text-indigo-700 dark:text-indigo-400 uppercase block tracking-wider">Total Credited Time</span>
            <span class="text-2xl font-black font-mono text-indigo-900 dark:text-indigo-300" x-text="closureStats.totalTimeDisplay || (closureStats.totalHours + 'h')"></span>
        </div>

        <!-- Pending / Draft -->
        <div class="p-4 rounded-2xl border bg-amber-50 dark:bg-amber-950/40 border-amber-300 dark:border-amber-700 shadow-xs">
            <span class="text-[10px] font-bold text-amber-700 dark:text-amber-400 uppercase block tracking-wider">Pending / Draft</span>
            <span class="text-2xl font-black font-mono text-amber-800 dark:text-amber-300" x-text="closureStats.pending"></span>
        </div>
    </div>

    <!-- Closure Events Table -->
    <div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl shadow-sm overflow-hidden">
        <div class="p-4 border-b border-slate-200/80 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-800/30">
            <h3 class="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-300">Corporate Early Closure Events & Audit Trail</h3>
            <button @click="loadEarlyClosures()" class="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1">
                <i data-lucide="refresh-cw" class="w-3.5 h-3.5"></i>
                <span>Refresh</span>
            </button>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs text-slate-600 dark:text-slate-400">
                <thead class="bg-slate-50 dark:bg-slate-800/50 text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400 border-b border-slate-200/80 dark:border-slate-800">
                    <tr>
                        <th class="px-4 py-3">Closure Date & Time</th>
                        <th class="px-4 py-3">Scope</th>
                        <th class="px-4 py-3">Affected Employees</th>
                        <th class="px-4 py-3">Credited Time</th>
                        <th class="px-4 py-3">Status</th>
                        <th class="px-4 py-3">Admin Reason & Notes</th>
                        <th class="px-4 py-3">Authorized By</th>
                        <th class="px-4 py-3 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-800/60">
                    <template x-for="item in earlyClosures" :key="item.id">
                        <tr class="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition">
                            <td class="px-4 py-3 font-semibold text-slate-900 dark:text-white">
                                <div class="flex items-center gap-1.5">
                                    <i data-lucide="calendar" class="w-3.5 h-3.5 text-slate-400"></i>
                                    <span x-text="item.closure_date"></span>
                                </div>
                                <span class="text-[10px] text-slate-400 font-mono" x-text="'Release: ' + item.closure_time"></span>
                            </td>
                            <td class="px-4 py-3">
                                <span class="px-2 py-0.5 text-[10px] font-bold rounded-md uppercase"
                                      :class="getScopeBadgeClass(item.scope_type)"
                                      x-text="(item.scope_type || '').replace('_', ' ')">
                                </span>
                            </td>
                            <td class="px-4 py-3">
                                <span class="font-bold text-slate-800 dark:text-slate-200" x-text="item.affected_employee_count"></span>
                                <span class="text-[10px] text-slate-400 ml-1">staff</span>
                            </td>
                            <td class="px-4 py-3 font-mono font-bold text-emerald-600 dark:text-emerald-400">
                                <span x-text="'+' + (item.total_credited_display || formatHoursToHHMM(item.total_credited_hours))"></span>
                            </td>
                            <td class="px-4 py-3">
                                <span class="px-2.5 py-1 text-[10px] font-extrabold rounded-full inline-block uppercase tracking-wider"
                                      :class="getClosureStatusBadgeClass(item.status)"
                                      x-text="item.status">
                                </span>
                            </td>
                            <td class="px-4 py-3 max-w-xs truncate">
                                <div class="text-xs font-medium text-slate-800 dark:text-slate-200" x-text="item.reason"></div>
                                <div x-show="item.admin_notes" class="text-[10px] text-slate-400 italic mt-0.5" x-text="'Notes: ' + item.admin_notes"></div>
                            </td>
                            <td class="px-4 py-3 text-[11px]">
                                <div class="font-semibold text-slate-800 dark:text-slate-200" x-text="item.approved_by_name || item.created_by_name || 'System'"></div>
                                <div class="text-[10px] text-slate-400" x-text="item.approved_at || item.created_at"></div>
                            </td>
                            <td class="px-4 py-3 text-right">
                                <div class="flex items-center justify-end gap-1.5">
                                    <button
                                        @click="viewClosureDetails(item.id)"
                                        class="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition"
                                        title="View detailed employee credits audit"
                                    >
                                        Details
                                    </button>

                                    <template x-if="item.status === 'Draft' || item.status === 'Submitted'">
                                        <button
                                            @click="openApprovalModal(item.id)"
                                            class="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white transition shadow-xs"
                                            title="Approve early closure and apply attendance credits"
                                        >
                                            Approve
                                        </button>
                                    </template>

                                    <template x-if="item.status === 'Approved'">
                                        <button
                                            @click="cancelClosure(item.id)"
                                            class="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-900/60 text-rose-600 dark:text-rose-400 transition"
                                            title="Cancel and revoke credited duty"
                                        >
                                            Revoke
                                        </button>
                                    </template>
                                </div>
                            </td>
                        </tr>
                    </template>

                    <tr x-show="earlyClosures.length === 0">
                        <td colspan="8" class="text-center py-8 text-slate-400">
                            <div class="flex flex-col items-center justify-center gap-2">
                                <i data-lucide="clock-alert" class="w-8 h-8 text-slate-300 dark:text-slate-600"></i>
                                <span class="text-xs font-semibold">No company early closure events recorded yet.</span>
                                <button @click="openEarlyClosureModal()" class="text-xs font-bold text-emerald-600 hover:underline">Declare First Early Closure</button>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- MODAL 1: Declare Early Closure & Real-time Preview -->
    <div x-show="showEarlyClosureModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in" style="display: none;">
        <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto space-y-5" @click.away="showEarlyClosureModal = false">
            
            <div class="flex justify-between items-start border-b border-slate-100 dark:border-slate-800 pb-3">
                <div>
                    <span class="text-[10px] font-bold uppercase tracking-widest text-emerald-600 dark:text-emerald-400 font-mono">Controlled Attendance Adjustment</span>
                    <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Declare Official Company Early Closure</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Authorize early dismissal with full configured working day credit without falsifying raw punches.</p>
                </div>
                <button @click="showEarlyClosureModal = false" class="p-1 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                    <label class="block text-[11px] font-bold uppercase text-slate-500 mb-1">Closure Date</label>
                    <input type="date" x-model="closureForm.closure_date" class="w-full text-xs font-semibold px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-white">
                </div>

                <div>
                    <label class="block text-[11px] font-bold uppercase text-slate-500 mb-1">Authorized Closure Time</label>
                    <input type="time" x-model="closureForm.closure_time" class="w-full text-xs font-semibold px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-white">
                </div>

                <div>
                    <label class="block text-[11px] font-bold uppercase text-slate-500 mb-1">Scope Level</label>
                    <select x-model="closureForm.scope_type" class="w-full text-xs font-semibold px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-white">
                        <option value="company">Entire Company (All Active)</option>
                        <option value="branch">Specific Branch</option>
                        <option value="department">Specific Department</option>
                        <option value="shift">Specific Shift</option>
                    </select>
                </div>
            </div>

            <!-- Conditional Scope Targets -->
            <div x-show="closureForm.scope_type === 'branch'" class="grid grid-cols-1 gap-2">
                <label class="block text-[11px] font-bold uppercase text-slate-500">Select Target Branch</label>
                <select x-model="closureForm.branch_id" class="w-full text-xs font-semibold px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-white">
                    <option value="">-- Choose Branch --</option>
                    <?php foreach ($branches ?? [] as $b): ?>
                        <option value="<?= $b['id'] ?>"><?= esc($b['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div x-show="closureForm.scope_type === 'department'" class="grid grid-cols-1 gap-2">
                <label class="block text-[11px] font-bold uppercase text-slate-500">Select Target Department</label>
                <select x-model="closureForm.department_id" class="w-full text-xs font-semibold px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-white">
                    <option value="">-- Choose Department --</option>
                    <?php foreach ($departments ?? [] as $d): ?>
                        <option value="<?= $d['id'] ?>"><?= esc($d['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div x-show="closureForm.scope_type === 'shift'" class="grid grid-cols-1 gap-2">
                <label class="block text-[11px] font-bold uppercase text-slate-500">Select Target Shift</label>
                <select x-model="closureForm.shift_id" class="w-full text-xs font-semibold px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-white">
                    <option value="">-- Choose Shift --</option>
                    <?php foreach ($shifts ?? [] as $s): ?>
                        <option value="<?= $s['id'] ?>"><?= esc($s['name']) ?> (<?= esc($s['start_time']) ?> - <?= esc($s['end_time']) ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label class="block text-[11px] font-bold uppercase text-slate-500 mb-1">Corporate Justification / Reason <span class="text-rose-500">*</span></label>
                <textarea x-model="closureForm.reason" rows="2" placeholder="e.g., Extreme Weather Warning / Severe Snowfall / Corporate Townhall Event" class="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-white"></textarea>
            </div>

            <!-- Preview Calculation Trigger -->
            <div class="flex items-center justify-between p-3 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200/80 dark:border-indigo-800">
                <div class="flex items-center gap-2">
                    <i data-lucide="calculator" class="w-4 h-4 text-indigo-600 dark:text-indigo-400"></i>
                    <span class="text-xs font-bold text-indigo-900 dark:text-indigo-300">Evaluate Shift Durations, Punches & Credit Hours</span>
                </div>
                <button
                    type="button"
                    @click="previewEarlyClosure()"
                    :disabled="closurePreviewLoading"
                    class="px-3 py-1.5 text-xs font-bold rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white transition flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                    <span x-show="!closurePreviewLoading">Calculate & Preview Impact</span>
                    <span x-show="closurePreviewLoading">Evaluating Roster...</span>
                </button>
            </div>

            <!-- Real-Time Evaluation Result Preview Table -->
            <div x-show="closurePreviewData" class="space-y-3 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 bg-slate-50/50 dark:bg-slate-800/30">
                <div class="flex justify-between items-center text-xs">
                    <span class="font-extrabold text-slate-800 dark:text-slate-200">
                        Affected Employees Preview (<span x-text="closurePreviewData?.summary?.eligible_count || 0"></span> eligible of <span x-text="closurePreviewData?.summary?.total_candidates || 0"></span>)
                    </span>
                    <span class="font-mono font-bold text-emerald-600 dark:text-emerald-400" x-text="'Total Closure Credit: ' + (closurePreviewData?.summary?.total_credited_display || formatMinutesToHHMM(closurePreviewData?.summary?.total_credited_minutes))"></span>
                </div>

                <div class="max-h-56 overflow-y-auto border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900">
                    <table class="w-full text-left text-xs">
                        <thead class="bg-slate-50 dark:bg-slate-800 text-[10px] uppercase font-bold text-slate-500 border-b border-slate-200 dark:border-slate-700 sticky top-0">
                            <tr>
                                <th class="px-3 py-2">Employee</th>
                                <th class="px-3 py-2">Configured Shift</th>
                                <th class="px-3 py-2">Preserved Clock In/Out</th>
                                <th class="px-3 py-2">Required Duty</th>
                                <th class="px-3 py-2">Actual Worked</th>
                                <th class="px-3 py-2 font-bold text-emerald-600">Credited Time</th>
                                <th class="px-3 py-2">Final Duty</th>
                                <th class="px-3 py-2">Daily OT</th>
                                <th class="px-3 py-2">Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-slate-800 text-[11px]">
                            <template x-for="emp in closurePreviewData?.employees" :key="emp.employee_id">
                                <tr :class="emp.is_eligible ? 'hover:bg-slate-50 dark:hover:bg-slate-800/50' : 'bg-slate-50/60 dark:bg-slate-900/60 text-slate-400'">
                                    <td class="px-3 py-2">
                                        <div class="font-bold text-slate-800 dark:text-slate-200" x-text="emp.name"></div>
                                        <div class="text-[9px] text-slate-400 font-mono" x-text="emp.employee_code + ' • ' + emp.department"></div>
                                    </td>
                                    <td class="px-3 py-2 font-mono">
                                        <span x-text="(emp.scheduled_start || '').substring(0,5) + '–' + (emp.scheduled_end || '').substring(0,5)"></span>
                                    </td>
                                    <td class="px-3 py-2 font-mono">
                                        <span x-text="emp.actual_check_in ? (emp.actual_check_in.substring(0,5) + ' – ' + (emp.actual_check_out ? emp.actual_check_out.substring(0,5) : closureForm.closure_time)) : 'No In Punch'"></span>
                                    </td>
                                    <td class="px-3 py-2 font-mono font-semibold" x-text="emp.required_duty_display || formatMinutesToHHMM(emp.required_duty_minutes)"></td>
                                    <td class="px-3 py-2 font-mono font-semibold" x-text="emp.actual_worked_display || formatMinutesToHHMM(emp.actual_worked_minutes)"></td>
                                    <td class="px-3 py-2 font-mono font-black text-emerald-600 dark:text-emerald-400" x-text="emp.credited_time_display || formatMinutesToHHMM(emp.credited_minutes)"></td>
                                    <td class="px-3 py-2 font-mono font-bold text-slate-900 dark:text-white" x-text="emp.final_duty_display || formatMinutesToHHMM(emp.final_duty_minutes)"></td>
                                    <td class="px-3 py-2 font-mono font-bold text-slate-500" x-text="emp.daily_ot_display || formatMinutesToHHMM(emp.daily_ot_minutes)"></td>
                                    <td class="px-3 py-2">
                                        <span class="px-2 py-0.5 text-[9px] font-bold rounded-full uppercase"
                                              :class="emp.is_eligible ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'"
                                              x-text="emp.is_eligible ? 'Eligible' : (emp.ineligibility_reason || 'Ineligible')">
                                        </span>
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Mandatory Admin Note on Creation/Approval -->
            <div>
                <label class="block text-[11px] font-bold uppercase text-slate-500 mb-1">
                    Mandatory Admin Approval Remarks / Audit Authorization Note <span class="text-rose-500">*</span>
                </label>
                <textarea x-model="closureForm.admin_notes" rows="2" placeholder="Mandatory administrative notes explaining management approval, safety instructions, and payroll credit justification..." class="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-white"></textarea>
                <span class="text-[10px] text-slate-400">Required: At least one non-whitespace character must be provided.</span>
            </div>

            <div class="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                    type="button"
                    @click="showEarlyClosureModal = false"
                    class="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold hover:bg-slate-200 text-xs"
                >
                    Cancel
                </button>
                <button
                    type="button"
                    @click="saveClosureDraft()"
                    :disabled="closureSubmitting"
                    class="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 font-bold text-xs"
                >
                    Save as Draft
                </button>
                <button
                    type="button"
                    @click="createAndApproveClosure()"
                    :disabled="closureSubmitting"
                    class="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-600/20"
                >
                    <span x-show="!closureSubmitting">Approve & Credit Employees</span>
                    <span x-show="closureSubmitting">Applying Credits...</span>
                </button>
            </div>

        </div>
    </div>

    <!-- MODAL 2: Mandatory Admin Approval Note Modal for existing Drafts -->
    <div x-show="showApprovalModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in" style="display: none;">
        <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl max-w-md w-full space-y-4" @click.away="showApprovalModal = false">
            <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Authoritative Approval Note</h3>
            <p class="text-xs text-slate-500">Provide mandatory administrative justification to credit employees for the early release.</p>

            <div>
                <label class="block text-[11px] font-bold uppercase text-slate-500 mb-1">Admin Approval Note <span class="text-rose-500">*</span></label>
                <textarea x-model="approvalNoteText" rows="3" placeholder="Approval reason (cannot be blank)..." class="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-white"></textarea>
            </div>

            <div class="flex justify-end gap-2 pt-2">
                <button @click="showApprovalModal = false" class="px-4 py-2 rounded-xl bg-slate-100 text-xs font-bold text-slate-700">Cancel</button>
                <button @click="confirmApproveClosure()" class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-xs font-bold text-white shadow-xs">Authorize & Credit</button>
            </div>
        </div>
    </div>

    <!-- MODAL 3: View Details & Credit Audit -->
    <div x-show="showDetailsModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in" style="display: none;">
        <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto space-y-4" @click.away="showDetailsModal = false">
            <div class="flex justify-between items-start border-b border-slate-100 dark:border-slate-800 pb-3">
                <div>
                    <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Early Closure Audit & Credit Records</h3>
                    <p class="text-xs text-slate-500" x-text="'Event: ' + (activeClosureDetails?.closure?.closure_date || '') + ' at ' + (activeClosureDetails?.closure?.closure_time || '')"></p>
                </div>
                <button @click="showDetailsModal = false" class="p-1 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>

            <div class="overflow-x-auto border border-slate-200 dark:border-slate-700 rounded-2xl">
                <table class="w-full text-left text-xs">
                    <thead class="bg-slate-50 dark:bg-slate-800 text-[10px] uppercase font-bold text-slate-500 border-b border-slate-200 dark:border-slate-700">
                        <tr>
                            <th class="px-3 py-2">Employee</th>
                            <th class="px-3 py-2">Configured Shift</th>
                            <th class="px-3 py-2">Preserved Clock In/Out</th>
                            <th class="px-3 py-2">Required Duty</th>
                            <th class="px-3 py-2">Actual Worked</th>
                            <th class="px-3 py-2 font-bold text-emerald-600">Credited Time</th>
                            <th class="px-3 py-2">Final Duty</th>
                            <th class="px-3 py-2">Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-800 text-[11px]">
                        <template x-for="c in activeClosureDetails?.credits" :key="c.id">
                            <tr>
                                <td class="px-3 py-2 font-semibold">
                                    <span x-text="c.first_name + ' ' + c.last_name"></span>
                                    <span class="text-[9px] text-slate-400 block font-mono" x-text="c.employee_code + ' • ' + (c.department_name || '')"></span>
                                </td>
                                <td class="px-3 py-2 font-mono" x-text="(c.scheduled_start || '').substring(0,5) + '–' + (c.scheduled_end || '').substring(0,5)"></td>
                                <td class="px-3 py-2 font-mono" x-text="c.actual_check_in ? ((c.actual_check_in.substring(0,5)) + ' – ' + (c.actual_check_out ? c.actual_check_out.substring(0,5) : '--:--')) : 'No In Punch'"></td>
                                <td class="px-3 py-2 font-mono font-semibold" x-text="c.required_duty_display || formatMinutesToHHMM(c.required_duty_minutes)"></td>
                                <td class="px-3 py-2 font-mono font-semibold" x-text="c.actual_worked_display || formatMinutesToHHMM(c.actual_worked_minutes)"></td>
                                <td class="px-3 py-2 font-mono font-bold text-emerald-600" x-text="c.credited_time_display || formatMinutesToHHMM(c.credited_minutes)"></td>
                                <td class="px-3 py-2 font-mono font-bold text-slate-900 dark:text-white" x-text="c.final_duty_display || formatMinutesToHHMM(c.final_duty_minutes)"></td>
                                <td class="px-3 py-2">
                                    <span class="px-2 py-0.5 text-[9px] font-bold rounded-full uppercase"
                                          :class="getCreditStatusBadgeClass(c.status)"
                                          x-text="c.status"></span>
                                </td>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>

            <div class="flex justify-end pt-2">
                <button @click="showDetailsModal = false" class="px-4 py-2 rounded-xl bg-slate-100 text-xs font-bold text-slate-700">Close</button>
            </div>
        </div>
    </div>

</div>
