<!-- TAB: Hardware Terminal & Biometric Push Sync Hub -->
<div x-show="activeTab === 'sync' || activeTab === 'zkteco'" class="space-y-6 animate-in fade-in duration-200">

    <!-- Top Action Banner -->
    <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <div class="flex items-center gap-2 mb-1 flex-wrap">
                <span class="p-1.5 rounded-lg bg-indigo-50 text-indigo-600 font-bold"><i data-lucide="server" class="w-4 h-4"></i></span>
                <h3 class="font-bold text-slate-800 dark:text-white text-base">ZKTeco Biometric Terminal Sync & Ingestion Engine</h3>
                <?php if (!empty($currentCompany)): ?>
                    <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 text-indigo-800 dark:bg-indigo-950/60 dark:text-indigo-300 border border-indigo-200">
                        Company: <?= esc($currentCompany['name']) ?> (ID: <?= esc($currentCompany['id']) ?>)
                    </span>
                <?php endif; ?>
            </div>
            <p class="text-xs text-slate-500">Scoped company-wise biometric devices, standalone TCP/IP port 4370 socket communication, real-time push punch queue ingestion, and device health monitoring.</p>
        </div>

        <div class="flex items-center gap-2 shrink-0">
            <a href="<?= base_url('attendance/sync') ?>" class="px-3.5 py-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 font-bold text-xs inline-flex items-center gap-2 transition">
                <i data-lucide="sliders" class="w-4 h-4 text-indigo-500"></i>
                <span>Device Registry</span>
            </a>

            <button @click="handleTestZKDevice()" :disabled="isSyncingZKT" class="px-4 py-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 font-bold text-xs inline-flex items-center gap-2 cursor-pointer transition">
                <i data-lucide="activity" class="w-4 h-4 text-emerald-500"></i>
                <span>Test Ping Handshake</span>
            </button>

            <button @click="handleSyncZKTecoPushLogs()" :disabled="isSyncingZKT" type="button" class="px-4 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs inline-flex items-center gap-2 shadow-sm cursor-pointer transition disabled:opacity-50 disabled:cursor-not-allowed">
                <svg x-show="isSyncingZKT" class="w-4 h-4 animate-spin" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
                </svg>
                <svg x-show="!isSyncingZKT" class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"></path>
                    <path d="M21 3v5h-5"></path>
                    <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"></path>
                    <path d="M3 21v-5h5"></path>
                </svg>
                <span x-text="isSyncingZKT ? 'Ingesting Punch Queue...' : 'Sync Hardware Queue'">Sync Hardware Queue</span>
            </button>
        </div>
    </div>

    <!-- Status Message Alert -->
    <template x-if="syncStatusMessage">
        <div class="p-4 rounded-2xl bg-indigo-50 border border-indigo-200 text-indigo-900 text-xs font-semibold flex items-center justify-between shadow-xs">
            <div class="flex items-center gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600"></i>
                <span x-text="syncStatusMessage"></span>
            </div>
            <button @click="syncStatusMessage = ''" class="text-indigo-400 hover:text-indigo-700">&times;</button>
        </div>
    </template>

    <!-- Empty State if No Devices Configured -->
    <template x-if="!zkDevices || zkDevices.length === 0">
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-8 text-center">
            <div class="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 mx-auto flex items-center justify-center mb-3">
                <i data-lucide="server" class="w-6 h-6"></i>
            </div>
            <h4 class="text-sm font-bold text-slate-800 dark:text-white">No Biometric Devices Registered for this Company</h4>
            <p class="text-xs text-slate-400 max-w-md mx-auto mt-1 mb-4">Register terminals and bind them directly to this organization to enable real-time clocking.</p>
            <a href="<?= base_url('attendance/sync') ?>" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition inline-flex items-center gap-1.5">
                <i data-lucide="plus" class="w-4 h-4"></i>
                <span>Add Biometric Device</span>
            </a>
        </div>
    </template>

    <!-- Device List Grid -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4" x-show="zkDevices && zkDevices.length > 0">
        <template x-for="device in zkDevices" :key="device.id">
            <div class="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
                <div class="flex items-center justify-between">
                    <span class="font-mono font-bold text-slate-900 dark:text-white text-xs" x-text="device.id"></span>
                    <span class="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-bold text-[10px] flex items-center gap-1 border border-emerald-200">
                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                        <span x-text="device.status"></span>
                    </span>
                </div>

                <div>
                    <h4 class="font-bold text-slate-800 dark:text-white text-xs" x-text="device.name"></h4>
                    <p class="text-[11px] text-slate-400" x-text="device.model"></p>
                </div>

                <div class="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl space-y-1.5 text-[11px] font-mono">
                    <div class="flex justify-between text-slate-500">
                        <span>Company:</span>
                        <strong class="text-indigo-600 dark:text-indigo-400 font-bold" x-text="(device.companyName || 'Corporate Entity') + (device.companyId ? ' (' + (device.companyId.length > 8 ? device.companyId.substring(0, 8) + '...' : device.companyId) + ')' : '')"></strong>
                    </div>
                    <div class="flex justify-between text-slate-500">
                        <span>IP Address:</span>
                        <strong class="text-slate-800 dark:text-white" x-text="device.ipAddress + ':' + device.port"></strong>
                    </div>
                    <div class="flex justify-between text-slate-500">
                        <span>Serial:</span>
                        <span class="text-slate-700 dark:text-slate-300" x-text="device.serialNumber"></span>
                    </div>
                    <div class="flex justify-between text-slate-500">
                        <span>Branch:</span>
                        <span class="text-slate-700 dark:text-slate-300" x-text="device.branch"></span>
                    </div>
                </div>

                <div class="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                    <span>Heartbeat: <strong class="text-emerald-600" x-text="device.lastHeartbeat"></strong></span>
                    <span class="text-indigo-600 font-bold cursor-pointer hover:underline" @click="handleTestZKDevice()">Diagnostics</span>
                </div>
            </div>
        </template>
    </div>

    <!-- Raw Push Punch Stream Table -->
    <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm overflow-hidden space-y-2">
        <div class="p-5 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
            <div>
                <h4 class="font-bold text-slate-800 dark:text-white text-sm flex items-center gap-2">
                    <i data-lucide="radio" class="w-4 h-4 text-rose-500"></i>
                    Ingested Raw Biometric Push Queue
                </h4>
                <p class="text-slate-400 text-xs">Real-time un-aggregated punch captures from remote hardware terminals.</p>
            </div>
            <span class="px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700 font-bold text-xs" x-text="rawPushLogs.length + ' Logs In Memory'"></span>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-xs">
                <thead>
                    <tr class="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200/80 dark:border-slate-800 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                        <th class="py-3 px-4">Log ID</th>
                        <th class="py-3 px-3">Device ID</th>
                        <th class="py-3 px-3">User PIN / Code</th>
                        <th class="py-3 px-3">Employee Name</th>
                        <th class="py-3 px-3">Punch Timestamp</th>
                        <th class="py-3 px-3">Verification Mode</th>
                        <th class="py-3 px-4 text-right">Muster Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                    <template x-for="log in rawPushLogs" :key="log.id">
                        <tr class="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition">
                            <td class="py-3 px-4 font-mono font-bold text-slate-700 dark:text-slate-300" x-text="log.id"></td>
                            <td class="py-3 px-3 font-mono text-slate-500" x-text="log.deviceId"></td>
                            <td class="py-3 px-3 font-mono font-bold text-indigo-600" x-text="log.userPin"></td>
                            <td class="py-3 px-3 font-bold text-slate-800 dark:text-white" x-text="log.userName"></td>
                            <td class="py-3 px-3 font-mono text-slate-700 dark:text-slate-200 font-bold" x-text="log.punchTime"></td>
                            <td class="py-3 px-3">
                                <span class="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-medium text-[10px]" x-text="log.verifyType"></span>
                            </td>
                            <td class="py-3 px-4 text-right">
                                <span class="px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-[11px] font-bold" x-text="log.state"></span>
                            </td>
                        </tr>
                    </template>
                </tbody>
            </table>
        </div>
    </div>

</div>
