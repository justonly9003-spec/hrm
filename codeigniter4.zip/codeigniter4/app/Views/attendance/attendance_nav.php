<?php
/**
 * Shared Attendance & Workforce Time Navigation Bar
 * 
 * Supports switching across:
 * - Overview
 * - Today's Muster
 * - Roster / Shift Scheduling
 * - Overtime Tracking & Approval
 * - Biometric Hardware & Sync
 * - Unmatched Staff
 * - Individual Ledger
 * - Group Matrix
 * - Calendar
 * - Monthly Timesheet
 * - Corrections
 * 
 * @var string $activeTab Current active attendance tab
 */

$currentActiveTab = $activeTab ?? 'overview';

$perm = $permissionService ?? new \App\Services\PermissionService();
$menuVis = new \App\Services\MenuVisibilityService();
$currentUserId = (string)(session()->get('user_id') ?? '');

$attendanceNavItems = [
    [
        'id'         => 'overview',
        'label'      => 'Overview',
        'url'        => base_url('attendance?tab=overview'),
        'icon'       => 'layout-dashboard',
        'permission' => 'attendance.overview',
    ],
    [
        'id'         => 'today',
        'label'      => "Today's Muster",
        'url'        => base_url('attendance?tab=today'),
        'icon'       => 'calendar-check',
        'permission' => 'attendance.today',
    ],
    [
        'id'         => 'roster',
        'label'      => 'Roster & Shifts',
        'url'        => base_url('attendance/roster'),
        'icon'       => 'calendar-range',
        'permission' => 'rostering.view',
    ],
    [
        'id'         => 'duty-assignments',
        'label'      => 'Duty Assignments',
        'url'        => base_url('duty-assignments'),
        'icon'       => 'shield-check',
        'permission' => 'attendance.view',
    ],
    [
        'id'         => 'overtime',
        'label'      => 'Overtime Hub',
        'url'        => base_url('attendance/overtime'),
        'icon'       => 'clock',
        'permission' => 'attendance.view',
    ],
    [
        'id'         => 'sync',
        'label'      => 'Biometric Hardware & Sync',
        'url'        => base_url('attendance/sync'),
        'icon'       => 'server',
        'permission' => 'attendance.sync',
    ],
    [
        'id'         => 'unmatched',
        'label'      => 'Unmatched Biometric Staff',
        'url'        => base_url('attendance/unmatched'),
        'icon'       => 'fingerprint',
        'permission' => 'attendance.view',
    ],
];
?>

<div class="flex items-center gap-2 p-1.5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-x-auto scrollbar-none mb-6">
    <?php foreach ($attendanceNavItems as $item): ?>
        <?php
        $permKey = $item['permission'];
        if (!empty($permKey) && !$perm->hasAccess(null, explode('.', $permKey)[0], explode('.', $permKey)[1] ?? 'view') && !can($permKey)) {
            continue;
        }
        $isActive = ($currentActiveTab === $item['id']);
        ?>
        <a href="<?= esc($item['url']) ?>" 
           class="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all shrink-0 <?= $isActive 
                ? 'bg-indigo-600 text-white shadow-sm' 
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800' ?>">
            <i data-lucide="<?= esc($item['icon']) ?>" class="w-4 h-4 <?= $isActive ? 'text-white' : 'text-slate-400' ?>"></i>
            <span><?= esc($item['label']) ?></span>
        </a>
    <?php endforeach; ?>
</div>
