<?php
/**
 * Canonical Unmatched Biometric Staff & Identity Resolution View
 * Rendered both as a tab inside /attendance and as the dedicated /attendance/unmatched view.
 */
$unmatchedList = $unmatchedStaff ?? [];
$mappingsList = $activeMappings ?? $establishedMappings ?? [];
$deviceList = $devices ?? $zkDevices ?? [];
$companyList = $allCompanies ?? [];
$currComp = $currentCompany ?? null;
?>

<div x-data="{ activeTab: 'unmatched', unmatchedSubTab: 'unmatched' }" class="space-y-6 animate-in fade-in duration-200">
    <?= view('attendance/attendance_nav', ['activeTab' => 'unmatched']) ?>
    
    <!-- Top Sub-Banner & Company Scope Header -->
    <div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-5 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
            <div class="flex items-center gap-2 flex-wrap">
                <span class="text-[10px] font-bold uppercase tracking-widest text-amber-600 dark:text-amber-400 font-mono">Biometric Hardware Gateway</span>
                <span class="px-2 py-0.5 text-[10px] font-bold rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300">Identity Resolution Engine</span>
                <?php if (!empty($currComp)): ?>
                    <span class="px-2.5 py-0.5 text-[10px] font-bold rounded-full bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300 border border-indigo-200/60 dark:border-indigo-800/60 flex items-center gap-1">
                        <i data-lucide="building" class="w-3 h-3"></i>
                        <span><?= esc($currComp['name']) ?></span>
                    </span>
                <?php endif; ?>
            </div>
            <h2 class="text-base font-extrabold text-slate-900 dark:text-white mt-1">Unmatched Biometric Staff & Hardware Terminal Ingestion</h2>
            <p class="text-xs text-slate-500 dark:text-slate-400">Punches received from biometric terminals without registered employee profiles are safely preserved. Map identities or onboard staff to reprocess all historical punches.</p>
        </div>

        <div class="flex items-center gap-2.5 flex-wrap">
            <?php if ((!empty($isSoftwareAdmin) || !empty($isSoftwareAppAdmin)) && !empty($companyList) && count($companyList) > 1): ?>
                <div class="flex items-center gap-1.5 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs">
                    <span class="text-slate-400 font-medium text-[11px]">Company:</span>
                    <select onchange="window.location.href='<?= base_url('attendance/unmatched?company_id=') ?>' + this.value" class="bg-transparent font-bold text-slate-800 dark:text-slate-200 outline-none text-xs cursor-pointer">
                        <option value="">All Companies</option>
                        <?php foreach ($companyList as $comp): ?>
                            <option value="<?= esc($comp['id']) ?>" <?= ($comp['id'] === ($userCompanyId ?? '')) ? 'selected' : '' ?>>
                                <?= esc($comp['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            <?php endif; ?>

            <a href="<?= base_url('employees/create') ?>" class="flex items-center gap-2 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs transition">
                <i data-lucide="user-plus" class="w-3.5 h-3.5"></i>
                <span>Onboard New Staff</span>
            </a>

            <button type="button" onclick="triggerBiometricRepair()" class="flex items-center gap-2 px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold shadow-xs transition cursor-pointer" title="Auto-recovers missing biometric user IDs from raw payloads and rebuilds distinct terminal identities">
                <i data-lucide="wrench" class="w-3.5 h-3.5"></i>
                <span>Repair PIN Buffer</span>
            </button>

            <a href="<?= base_url('attendance/sync') ?>" class="flex items-center gap-2 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs transition cursor-pointer">
                <i data-lucide="refresh-cw" class="w-3.5 h-3.5"></i>
                <span>Fetch Terminal Data</span>
            </a>
        </div>
    </div>

    <!-- KPI Metric Cards for Unmatched Engine -->
    <div class="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <!-- 1. Total Ingested Hardware Badges -->
        <div onclick="setQuickStatus('ALL')" class="p-4 rounded-2xl border bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 shadow-xs cursor-pointer hover:border-indigo-400 dark:hover:border-indigo-600 transition group">
            <div class="flex items-center justify-between text-indigo-600 dark:text-indigo-400 mb-1">
                <span class="text-[10px] font-bold uppercase tracking-wider">Total Terminal Users</span>
                <i data-lucide="fingerprint" class="w-4 h-4 group-hover:scale-110 transition-transform"></i>
            </div>
            <span class="text-2xl font-black font-mono text-slate-900 dark:text-white" id="cardTotalCount"><?= (int)($totalTotal ?? ($totalUnmatched + $totalMapped + $totalIgnored)) ?></span>
            <span class="text-[11px] text-slate-400 block mt-0.5">Ingested Badges</span>
        </div>

        <!-- 2. Successfully Mapped -->
        <div onclick="setQuickStatus('MAPPED')" class="p-4 rounded-2xl border bg-white dark:bg-slate-900 border-emerald-200/80 dark:border-emerald-900/40 shadow-xs cursor-pointer hover:border-emerald-500 transition group">
            <div class="flex items-center justify-between text-emerald-600 dark:text-emerald-400 mb-1">
                <span class="text-[10px] font-bold uppercase tracking-wider">Mapped to Employees</span>
                <i data-lucide="check-check" class="w-4 h-4 group-hover:scale-110 transition-transform"></i>
            </div>
            <span class="text-2xl font-black font-mono text-emerald-700 dark:text-emerald-400" id="cardMappedCount"><?= (int)($totalMapped ?? 0) ?></span>
            <span class="text-[11px] text-slate-400 block mt-0.5">Linked HRM Profiles</span>
        </div>

        <!-- 3. Awaiting Resolution / Unmapped -->
        <div onclick="setQuickStatus('UNMATCHED')" class="p-4 rounded-2xl border bg-white dark:bg-slate-900 border-amber-200/80 dark:border-amber-900/40 shadow-xs cursor-pointer hover:border-amber-500 transition group">
            <div class="flex items-center justify-between text-amber-600 dark:text-amber-400 mb-1">
                <span class="text-[10px] font-bold uppercase tracking-wider">Awaiting Resolution</span>
                <i data-lucide="alert-circle" class="w-4 h-4 group-hover:scale-110 transition-transform"></i>
            </div>
            <span class="text-2xl font-black font-mono text-amber-700 dark:text-amber-400" id="cardUnmatchedCount"><?= (int)($totalUnmatched ?? 0) ?></span>
            <span class="text-[11px] text-slate-400 block mt-0.5">Unlinked Machine PINs</span>
        </div>

        <!-- 4. Preserved Raw Punches -->
        <div class="p-4 rounded-2xl border bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 shadow-xs">
            <div class="flex items-center justify-between text-blue-600 dark:text-blue-400 mb-1">
                <span class="text-[10px] font-bold uppercase tracking-wider">Raw Buffer Punches</span>
                <i data-lucide="cpu" class="w-4 h-4"></i>
            </div>
            <span class="text-2xl font-black font-mono text-slate-900 dark:text-white"><?= (int)($unprocessedRawCount ?? 0) ?></span>
            <span class="text-[11px] text-slate-400 block mt-0.5">Preserved in Buffer</span>
        </div>

        <!-- 5. Ignored / Archived -->
        <div onclick="setQuickStatus('IGNORED')" class="p-4 rounded-2xl border bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 shadow-xs cursor-pointer hover:border-slate-400 transition group">
            <div class="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1">
                <span class="text-[10px] font-bold uppercase tracking-wider">Archived / Tags</span>
                <i data-lucide="archive" class="w-4 h-4 group-hover:scale-110 transition-transform"></i>
            </div>
            <span class="text-2xl font-black font-mono text-slate-700 dark:text-slate-300" id="cardIgnoredCount"><?= (int)($totalIgnored ?? 0) ?></span>
            <span class="text-[11px] text-slate-400 block mt-0.5">Skipped Hardware Tags</span>
        </div>
    </div>

    <!-- Sub-View Navigation Switcher -->
    <div class="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
        <button 
            type="button" 
            @click="unmatchedSubTab = 'unmatched'" 
            :class="unmatchedSubTab === 'unmatched' ? 'border-amber-600 text-amber-600 dark:text-amber-400 font-bold bg-amber-50/50 dark:bg-amber-950/30' : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'"
            class="px-4 py-2.5 rounded-xl border-b-2 text-xs transition flex items-center gap-2 cursor-pointer"
        >
            <i data-lucide="fingerprint" class="w-4 h-4"></i>
            <span>Unmatched Biometric Staff</span>
            <span class="px-2 py-0.5 rounded-full text-[10px] font-mono bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-200">
                <?= (int)($totalUnmatched ?? count($unmatchedList)) ?>
            </span>
        </button>

        <button 
            type="button" 
            @click="unmatchedSubTab = 'mappings'" 
            :class="unmatchedSubTab === 'mappings' ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 font-bold bg-indigo-50/50 dark:bg-indigo-950/30' : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'"
            class="px-4 py-2.5 rounded-xl border-b-2 text-xs transition flex items-center gap-2 cursor-pointer"
        >
            <i data-lucide="check-check" class="w-4 h-4"></i>
            <span>Active Biometric Mappings</span>
            <span class="px-2 py-0.5 rounded-full text-[10px] font-mono bg-indigo-100 dark:bg-indigo-900/60 text-indigo-800 dark:text-indigo-200">
                <?= count($mappingsList) ?>
            </span>
        </button>
    </div>

    <!-- SUB-VIEW 1: Unmatched Biometric Staff Data List -->
    <div x-show="unmatchedSubTab === 'unmatched'" class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-5 shadow-xs space-y-4">
        
        <!-- Search, Filter & Quick Filter Bar -->
        <div class="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
            <div class="flex flex-wrap items-center gap-2 flex-1">
                <!-- Search Input -->
                <div class="relative w-full sm:w-64">
                    <i data-lucide="search" class="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
                    <input 
                        type="text" 
                        id="unmatchedSearchInput"
                        placeholder="Search PIN, name, employee, card..." 
                        class="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500 outline-none"
                    >
                </div>

                <!-- Status Filter -->
                <select id="unmatchedStatusFilter" class="text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-slate-800 dark:text-slate-200 font-medium">
                    <option value="ALL">All Statuses (<?= (int)($totalTotal ?? ($totalUnmatched + $totalMapped + $totalIgnored)) ?>)</option>
                    <option value="UNMATCHED">Unmapped Only (<?= (int)($totalUnmatched ?? 0) ?>)</option>
                    <option value="MAPPED">Mapped Only (<?= (int)($totalMapped ?? 0) ?>)</option>
                    <option value="IGNORED">Archived / Ignored (<?= (int)($totalIgnored ?? 0) ?>)</option>
                </select>

                <!-- Device Filter -->
                <?php if (!empty($deviceList)): ?>
                    <select id="unmatchedDeviceFilter" onchange="window.applyUnmatchedFilter ? window.applyUnmatchedFilter() : null" class="text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-slate-800 dark:text-slate-200 font-medium">
                        <option value="">All Devices</option>
                        <?php foreach ($deviceList as $dev): ?>
                            <?php
                            $deviceId = $dev['id'] ?? $dev['device_id'] ?? '';
                            $deviceName = $dev['name'] ?? $dev['device_name'] ?? 'Unnamed device';
                            ?>
                            <option value="<?= esc($deviceId) ?>"><?= esc($deviceName) ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php endif; ?>

                <button type="button" onclick="resetUnmatchedFilters()" class="px-3 py-2 rounded-xl text-xs font-semibold text-slate-500 hover:text-slate-800 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition">
                    Reset
                </button>
            </div>

            <div class="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5 self-end lg:self-center">
                <span>Displaying:</span>
                <span class="font-bold text-slate-900 dark:text-white font-mono" id="unmatchedCountBadge"><?= count($unmatchedList) ?> records</span>
            </div>
        </div>

        <!-- Table Container -->
        <div class="overflow-x-auto rounded-2xl border border-slate-100 dark:border-slate-800">
            <table class="w-full text-left text-xs text-slate-600 dark:text-slate-300">
                <thead class="bg-slate-50/80 dark:bg-slate-800/60 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider border-b border-slate-200/80 dark:border-slate-800">
                    <tr>
                        <th class="py-3.5 px-4">Biometric User PIN</th>
                        <th class="py-3.5 px-4">Origin Terminal Device</th>
                        <th class="py-3.5 px-4">Device Display Name</th>
                        <th class="py-3.5 px-4 text-center">Punches</th>
                        <th class="py-3.5 px-4">Last Punch Time</th>
                        <th class="py-3.5 px-4">Mapped HRM Employee</th>
                        <th class="py-3.5 px-4">Status</th>
                        <th class="py-3.5 px-4 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-800/60 font-medium" id="unmatchedTableBody">
                    <?php if (empty($unmatchedList)): ?>
                        <tr>
                            <td colspan="8" class="py-12 text-center text-slate-400">
                                <div class="flex flex-col items-center justify-center gap-2">
                                    <div class="w-12 h-12 rounded-full bg-amber-50 dark:bg-amber-950/40 text-amber-500 flex items-center justify-center">
                                        <i data-lucide="check-circle-2" class="w-6 h-6"></i>
                                    </div>
                                    <p class="font-bold text-sm text-slate-700 dark:text-slate-300">No Biometric Ingestion Records Found</p>
                                    <p class="text-xs text-slate-400 max-w-sm">No biometric identities currently pending resolution. Punches will automatically populate here as terminal events arrive.</p>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($unmatchedList as $row): 
                            $status = $row['computed_status'] ?? $row['status'] ?? 'UNMATCHED';
                            $isMapped = ($status === 'MAPPED');
                            $hasEmployee = !empty($row['employee_id']) || !empty($row['employee_code']);
                            $empName = trim(($row['employee_first_name'] ?? '') . ' ' . ($row['employee_last_name'] ?? ''));
                            $punchCount = (int)($row['punch_count'] ?? $row['event_count'] ?? 1);
                            $deviceId = $row['device_id'] ?? '';
                            $searchText = strtolower(implode(' ', [
                                $row['biometric_user_id'] ?? '',
                                $row['device_user_name'] ?? '',
                                $row['card_number'] ?? '',
                                $row['device_name'] ?? '',
                                $row['device_serial'] ?? '',
                                $empName,
                                $row['employee_code'] ?? '',
                                $row['employee_department'] ?? '',
                                $row['employee_designation'] ?? '',
                                $status
                            ]));
                        ?>
                            <tr class="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition unmatched-row" data-status="<?= esc($status) ?>" data-device="<?= esc($deviceId) ?>" data-text="<?= esc($searchText) ?>">
                                <td class="py-3.5 px-4">
                                    <div class="flex items-center gap-2">
                                        <div class="w-8 h-8 rounded-xl <?= $isMapped ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300' : 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300' ?> flex items-center justify-center font-mono font-bold text-xs">
                                            <i data-lucide="fingerprint" class="w-4 h-4"></i>
                                        </div>
                                        <div>
                                            <span class="font-black font-mono text-slate-900 dark:text-white"><?= esc($row['biometric_user_id']) ?></span>
                                            <?php if (!empty($row['card_number'])): ?>
                                                <span class="block text-[10px] text-slate-400 font-mono">RFID: <?= esc($row['card_number']) ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-3.5 px-4">
                                    <div>
                                        <span class="font-bold text-slate-800 dark:text-slate-200"><?= esc($row['device_name'] ?? $row['device_id'] ?? 'Terminal') ?></span>
                                        <?php if (!empty($row['device_serial'])): ?>
                                            <span class="block text-[10px] text-slate-400 font-mono">S/N: <?= esc($row['device_serial']) ?></span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td class="py-3.5 px-4">
                                    <span class="text-slate-700 dark:text-slate-300 font-medium"><?= esc($row['device_user_name'] ?: 'Not set in machine') ?></span>
                                </td>
                                <td class="py-3.5 px-4 text-center">
                                    <button 
                                        type="button" 
                                        onclick="viewRawEvents('<?= esc($row['id']) ?>', '<?= esc($row['biometric_user_id']) ?>')" 
                                        class="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-mono font-bold bg-blue-50 text-blue-700 dark:bg-blue-950/50 dark:text-blue-300 border border-blue-200/50 hover:bg-blue-100 transition cursor-pointer" 
                                        title="View preserved raw punches stream"
                                    >
                                        <i data-lucide="layers" class="w-3.5 h-3.5"></i>
                                        <span><?= $punchCount ?></span>
                                    </button>
                                </td>
                                <td class="py-3.5 px-4 text-xs font-mono text-slate-500">
                                    <?= !empty($row['last_punch_at']) ? date('M d, Y H:i', strtotime($row['last_punch_at'])) : (!empty($row['last_seen_at']) ? date('M d, Y H:i', strtotime($row['last_seen_at'])) : 'N/A') ?>
                                </td>
                                <td class="py-3.5 px-4">
                                    <?php if ($isMapped && $hasEmployee): ?>
                                        <div class="flex items-center gap-2">
                                            <div class="w-7 h-7 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold flex items-center justify-center text-[11px]">
                                                <?= strtoupper(substr($empName ?: 'E', 0, 1)) ?>
                                            </div>
                                            <div>
                                                <div class="flex items-center gap-1.5">
                                                    <span class="font-bold text-slate-900 dark:text-white"><?= esc($empName) ?></span>
                                                    <span class="px-1.5 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-mono text-[10px]"><?= esc($row['employee_code']) ?></span>
                                                </div>
                                                <span class="text-[10px] text-slate-400 block"><?= esc($row['employee_department'] ?? 'General') ?><?= !empty($row['employee_designation']) ? ' • ' . esc($row['employee_designation']) : '' ?></span>
                                            </div>
                                        </div>
                                    <?php elseif ($status === 'IGNORED'): ?>
                                        <span class="text-slate-400 italic text-[11px]">Archived / Visitor Tag</span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400 font-semibold text-[11px]">
                                            <i data-lucide="alert-circle" class="w-3 h-3"></i>
                                            <span>Unlinked (Awaiting Mapping)</span>
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3.5 px-4">
                                    <?php if ($isMapped): ?>
                                        <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200/60">Mapped</span>
                                    <?php elseif ($status === 'IGNORED'): ?>
                                        <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-400">Archived</span>
                                    <?php else: ?>
                                        <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 animate-pulse border border-amber-200/60">Unmatched</span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3.5 px-4 text-right">
                                    <div class="flex items-center justify-end gap-1.5">
                                        <?php if ($isMapped): ?>
                                            <!-- Unmap Action -->
                                            <?php $mappingId = $row['mapping_id'] ?? null; ?>
                                            <?php if (!empty($mappingId)): ?>
                                                <button 
                                                    type="button"
                                                    onclick="unmapBiometric('<?= esc($mappingId) ?>', '<?= esc($row['biometric_user_id']) ?>', '<?= esc($empName) ?>')"
                                                    class="px-2.5 py-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 hover:bg-rose-100 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                                                    title="Disconnect this employee and return punches to unmatched pool"
                                                >
                                                    <i data-lucide="unlink" class="w-3.5 h-3.5"></i>
                                                    <span>Unmap</span>
                                                </button>
                                            <?php endif; ?>

                                            <!-- View Employee Profile Link -->
                                            <?php if (!empty($row['employee_id'])): ?>
                                                <a 
                                                    href="<?= base_url('employees/' . esc($row['employee_id'])) ?>"
                                                    class="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                                                    title="View Employee Profile"
                                                >
                                                    <i data-lucide="external-link" class="w-3.5 h-3.5"></i>
                                                </a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <!-- Map to Employee Modal Trigger -->
                                            <button 
                                                type="button"
                                                onclick="openLinkModal('<?= esc($row['id']) ?>', '<?= esc($row['biometric_user_id']) ?>', '<?= esc($row['device_user_name'] ?? '') ?>', '<?= $punchCount ?>')"
                                                class="px-2.5 py-1.5 rounded-xl bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 hover:bg-amber-100 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                                                title="Link to existing Employee"
                                            >
                                                <i data-lucide="link" class="w-3.5 h-3.5"></i>
                                                <span>Link Staff</span>
                                            </button>

                                            <!-- Quick Onboard -->
                                            <a 
                                                href="<?= base_url('employees/create?biometric_user_id=' . urlencode($row['biometric_user_id']) . '&name=' . urlencode($row['device_user_name'] ?? '') . '&company_id=' . urlencode($row['company_id'] ?? '')) ?>"
                                                class="px-2.5 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 text-xs font-bold transition flex items-center gap-1"
                                                title="Create new Employee with this Biometric ID"
                                            >
                                                <i data-lucide="user-plus" class="w-3.5 h-3.5"></i>
                                                <span>Onboard</span>
                                            </a>

                                            <!-- Ignore / Archive Button -->
                                            <?php if ($status !== 'IGNORED'): ?>
                                                <button 
                                                    type="button"
                                                    onclick="openIgnoreModal('<?= esc($row['id']) ?>', '<?= esc($row['biometric_user_id']) ?>')"
                                                    class="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
                                                    title="Ignore / Archive this badge"
                                                >
                                                    <i data-lucide="archive" class="w-3.5 h-3.5"></i>
                                                </button>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- SUB-VIEW 2: Active Biometric Mappings Table -->
    <div x-show="unmatchedSubTab === 'mappings'" class="space-y-4">
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-5 shadow-xs overflow-hidden">
            <div class="pb-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Active Biometric Identity Mappings</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Authoritative mapping rules linking Biometric Machine User IDs directly to Employee Master records.</p>
                </div>
                <span class="text-xs font-mono font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 px-2.5 py-1 rounded-xl">
                    Total: <?= count($mappingsList) ?> Active Rules
                </span>
            </div>

            <div class="overflow-x-auto mt-4 rounded-2xl border border-slate-100 dark:border-slate-800">
                <table class="w-full text-left text-xs text-slate-600 dark:text-slate-300">
                    <thead class="bg-slate-50/80 dark:bg-slate-800/60 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider border-b border-slate-200/80 dark:border-slate-800">
                        <tr>
                            <th class="py-3.5 px-4">Biometric User ID</th>
                            <th class="py-3.5 px-4">Device Name/Alias</th>
                            <th class="py-3.5 px-4">Employee Code</th>
                            <th class="py-3.5 px-4">Employee Master Record</th>
                            <th class="py-3.5 px-4">Department</th>
                            <th class="py-3.5 px-4">Mapped Date & Author</th>
                            <th class="py-3.5 px-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-800/60 font-medium">
                        <?php if (empty($mappingsList)): ?>
                            <tr>
                                <td colspan="7" class="py-12 text-center text-slate-400">
                                    No active mappings found. Onboard or link staff to establish permanent biometric mapping rules.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($mappingsList as $map): ?>
                                <tr class="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
                                    <td class="py-3.5 px-4 font-mono font-bold text-slate-900 dark:text-white">
                                        <div class="flex items-center gap-2">
                                            <span class="w-2 h-2 rounded-full bg-emerald-500"></span>
                                            <span><?= esc($map['biometric_user_id']) ?></span>
                                        </div>
                                    </td>
                                    <td class="py-3.5 px-4 text-slate-600 dark:text-slate-300">
                                        <?= esc($map['device_user_name'] ?? 'Direct Biometric Match') ?>
                                    </td>
                                    <td class="py-3.5 px-4 font-mono font-bold text-indigo-600 dark:text-indigo-400">
                                        <?= esc($map['employee_code'] ?? '—') ?>
                                    </td>
                                    <td class="py-3.5 px-4 text-slate-800 dark:text-slate-200 font-semibold">
                                        <?= esc(trim(($map['first_name'] ?? '') . ' ' . ($map['last_name'] ?? ''))) ?: 'Employee' ?>
                                    </td>
                                    <td class="py-3.5 px-4 text-slate-600 dark:text-slate-400">
                                        <?= esc($map['department'] ?? 'General') ?>
                                    </td>
                                    <td class="py-3.5 px-4 text-[11px] text-slate-500">
                                        <div><?= !empty($map['mapped_at']) ? date('M d, Y H:i', strtotime($map['mapped_at'])) : '—' ?></div>
                                        <div class="text-[10px] text-slate-400 font-mono"><?= esc($map['mapped_by'] ?? 'System') ?></div>
                                    </td>
                                    <td class="py-3.5 px-4 text-right">
                                        <form method="POST" action="<?= base_url('attendance/unmatched/unmap') ?>" onsubmit="return confirm('Disable this biometric mapping? New punches will revert to unmatched pool.');" class="inline">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="mapping_id" value="<?= esc($map['id']) ?>">
                                            <button type="submit" class="px-2.5 py-1.5 rounded-xl text-xs font-bold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition flex items-center gap-1 ml-auto cursor-pointer">
                                                <i data-lucide="unlink" class="w-3.5 h-3.5"></i>
                                                <span>Unlink</span>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- MODAL 1: Link Existing Staff Modal -->
    <div id="linkModal" class="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 hidden">
        <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-2xl max-w-lg w-full p-6 space-y-5">
            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-4">
                <div class="flex items-center gap-2.5">
                    <div class="w-9 h-9 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
                        <i data-lucide="link" class="w-5 h-5"></i>
                    </div>
                    <div>
                        <h3 class="text-sm font-black text-slate-900 dark:text-white">Link Biometric Identity to Existing Staff</h3>
                        <p class="text-xs text-slate-400">Map device biometric User ID to an Employee Master profile</p>
                    </div>
                </div>
                <button type="button" onclick="closeLinkModal()" class="text-slate-400 hover:text-slate-600 dark:hover:text-white p-1 rounded-xl">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>

            <form method="POST" action="<?= base_url('attendance/unmatched/link') ?>" class="space-y-4">
                <?= csrf_field() ?>
                <input type="hidden" name="unmatched_id" id="modal_unmatched_id">

                <div class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 space-y-1 text-xs">
                    <div class="flex items-center justify-between">
                        <span class="text-slate-400">Biometric Machine ID:</span>
                        <span class="font-mono font-bold text-slate-900 dark:text-white" id="modal_bio_user_id">—</span>
                    </div>
                    <div class="flex items-center justify-between">
                        <span class="text-slate-400">Detected Machine Name:</span>
                        <span class="font-semibold text-slate-800 dark:text-slate-200" id="modal_bio_user_name">—</span>
                    </div>
                    <div class="flex items-center justify-between">
                        <span class="text-slate-400">Preserved Raw Punches:</span>
                        <span class="font-bold text-indigo-600 dark:text-indigo-400" id="modal_bio_punch_count">—</span>
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                        Select Target Employee Master Record <span class="text-rose-500">*</span>
                    </label>
                    <select name="employee_id" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none">
                        <option value="">-- Choose Employee to Link --</option>
                        <?php foreach (($employees ?? []) as $emp): ?>
                            <option value="<?= esc($emp['id']) ?>">
                                <?= esc($emp['employee_code']) ?> — <?= esc(trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? ''))) ?: esc($emp['name'] ?? 'Staff') ?> (<?= esc($emp['department'] ?? 'General') ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p class="text-[11px] text-slate-400 mt-1">Future biometric punches with this ID will credit this employee's ledger directly.</p>
                </div>

                <div class="p-3 rounded-xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 flex items-start gap-2.5">
                    <input type="checkbox" name="reprocess" id="reprocess_punches_cb" value="1" checked class="mt-0.5 rounded text-indigo-600 focus:ring-indigo-500">
                    <label for="reprocess_punches_cb" class="text-xs text-indigo-900 dark:text-indigo-200 cursor-pointer">
                        <strong>Reprocess historical raw punches immediately</strong>
                        <span class="block text-[11px] text-indigo-700/80 dark:text-indigo-300/80">Convert all preserved punches into official attendance logs and evaluate shift work hours.</span>
                    </label>
                </div>

                <div class="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-100 dark:border-slate-700">
                    <button type="button" onclick="closeLinkModal()" class="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition">
                        Cancel
                    </button>
                    <button type="submit" class="px-4 py-2 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm transition flex items-center gap-1.5">
                        <i data-lucide="check" class="w-4 h-4"></i>
                        <span>Confirm Link & Reprocess</span>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL 2: View Raw Punches Modal -->
    <div id="eventsModal" class="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 hidden">
        <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-2xl max-w-2xl w-full p-6 space-y-4 max-h-[85vh] flex flex-col">
            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3 shrink-0">
                <div class="flex items-center gap-2.5">
                    <div class="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                        <i data-lucide="history" class="w-4 h-4"></i>
                    </div>
                    <div>
                        <h3 class="text-sm font-bold text-slate-900 dark:text-white">Raw Biometric Events Stream</h3>
                        <p class="text-xs text-slate-500 font-mono">User ID: <span id="events_modal_user_id">—</span></p>
                    </div>
                </div>
                <button type="button" onclick="closeEventsModal()" class="text-slate-400 hover:text-slate-600 dark:hover:text-white p-1 rounded-xl">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>

            <div class="overflow-y-auto flex-1 border border-slate-100 dark:border-slate-700 rounded-2xl" id="events_container">
                <div class="p-8 text-center text-slate-400">Loading raw events...</div>
            </div>

            <div class="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-700 shrink-0">
                <span class="text-[11px] text-slate-400">All raw hardware events are preserved in the system buffer.</span>
                <button type="button" onclick="closeEventsModal()" class="px-4 py-1.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition">
                    Close
                </button>
            </div>
        </div>
    </div>

    <!-- MODAL 3: Ignore Identity Modal -->
    <div id="ignoreModal" class="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 hidden">
        <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-2xl max-w-md w-full p-6 space-y-4">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-2xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 flex items-center justify-center shrink-0">
                    <i data-lucide="archive" class="w-5 h-5"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Ignore Unmatched Biometric Identity</h3>
                    <p class="text-xs text-slate-500 font-mono">Biometric ID: <span id="ignore_modal_user_id">—</span></p>
                </div>
            </div>

            <form method="POST" action="<?= base_url('attendance/unmatched/ignore') ?>" class="space-y-4">
                <?= csrf_field() ?>
                <input type="hidden" name="unmatched_id" id="ignore_unmatched_id">

                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Reason for Archiving / Ignoring *</label>
                    <textarea name="reason" rows="3" required placeholder="e.g. Visitor card, contractor badge, or device test punch." class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-rose-500 outline-none"></textarea>
                </div>

                <div class="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-700">
                    <button type="button" onclick="closeIgnoreModal()" class="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition">
                        Cancel
                    </button>
                    <button type="submit" class="px-4 py-2 rounded-xl text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 transition">
                        Confirm Ignore
                    </button>
                </div>
            </form>
        </div>
    </div>

</div>

<!-- Client-side Script for Unmatched Tab & Sub-tabs -->
<script>
function openLinkModal(unmatchedId, bioUserId, bioUserName, punchCount) {
    document.getElementById('modal_unmatched_id').value = unmatchedId;
    document.getElementById('modal_bio_user_id').textContent = bioUserId;
    document.getElementById('modal_bio_user_name').textContent = bioUserName || 'Not set in machine';
    document.getElementById('modal_bio_punch_count').textContent = punchCount + ' records preserved';
    document.getElementById('linkModal').classList.remove('hidden');
}

function closeLinkModal() {
    document.getElementById('linkModal').classList.add('hidden');
}

function openIgnoreModal(unmatchedId, bioUserId) {
    document.getElementById('ignore_unmatched_id').value = unmatchedId;
    document.getElementById('ignore_modal_user_id').textContent = bioUserId;
    document.getElementById('ignoreModal').classList.remove('hidden');
}

function closeIgnoreModal() {
    document.getElementById('ignoreModal').classList.add('hidden');
}

function viewRawEvents(unmatchedId, bioUserId) {
    document.getElementById('events_modal_user_id').textContent = bioUserId;
    const container = document.getElementById('events_container');
    container.innerHTML = '<div class="p-8 text-center text-slate-400">Loading raw punch events...</div>';
    document.getElementById('eventsModal').classList.remove('hidden');

    fetch('<?= base_url('attendance/unmatched/events') ?>/' + encodeURIComponent(unmatchedId))
        .then(res => res.json())
        .then(data => {
            if (!data.success || !data.events || data.events.length === 0) {
                container.innerHTML = '<div class="p-8 text-center text-slate-400">No raw events found for this identity in the buffer.</div>';
                return;
            }

            let html = `
                <table class="w-full text-left text-xs">
                    <thead>
                        <tr class="bg-slate-50 dark:bg-slate-900 text-slate-500 font-semibold border-b border-slate-100 dark:border-slate-700">
                            <th class="py-2.5 px-3">Punch Timestamp</th>
                            <th class="py-2.5 px-3">Device / Terminal</th>
                            <th class="py-2.5 px-3">State</th>
                            <th class="py-2.5 px-3">Matching Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-700/60">`;
            
            data.events.forEach(ev => {
                const statusBadge = ev.matching_status === 'UNMATCHED' 
                    ? '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-200/60">UNMATCHED</span>'
                    : '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200/60">REPROCESSED</span>';

                html += `
                    <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                        <td class="py-2.5 px-3 font-mono font-semibold text-slate-800 dark:text-slate-200">${ev.punch_time}</td>
                        <td class="py-2.5 px-3 text-slate-600 dark:text-slate-400">${ev.device_name || 'Terminal'}</td>
                        <td class="py-2.5 px-3 font-semibold text-slate-700 dark:text-slate-300">${ev.punch_state || 'CheckIn'}</td>
                        <td class="py-2.5 px-3">${statusBadge}</td>
                    </tr>`;
            });

            html += `</tbody></table>`;
            container.innerHTML = html;
        })
        .catch(err => {
            container.innerHTML = `<div class="p-8 text-center text-rose-500">Failed to load events: ${err.message}</div>`;
        });
}

function closeEventsModal() {
    document.getElementById('eventsModal').classList.add('hidden');
}

function triggerBiometricRepair() {
    if (!confirm('Run automatic PIN buffer repair? This will scan raw biometric payloads, extract missing user IDs, and rebuild distinct identities.')) return;
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '<?= base_url('attendance/unmatched/repair') ?>';
    const csrfInput = document.createElement('input');
    csrfInput.type = 'hidden';
    csrfInput.name = '<?= csrf_token() ?>';
    csrfInput.value = '<?= csrf_hash() ?>';
    form.appendChild(csrfInput);
    document.body.appendChild(form);
    form.submit();
}

function unmapBiometric(mappingId, pin, employeeName) {
    if (!confirm('Are you sure you want to unmap Biometric PIN ' + pin + (employeeName ? ' from ' + employeeName : '') + '? Punches from this terminal identity will return to the unmatched pool.')) return;
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '<?= base_url('attendance/unmatched/unmap') ?>';
    
    const csrfInput = document.createElement('input');
    csrfInput.type = 'hidden';
    csrfInput.name = '<?= csrf_token() ?>';
    csrfInput.value = '<?= csrf_hash() ?>';
    form.appendChild(csrfInput);

    const idInput = document.createElement('input');
    idInput.type = 'hidden';
    idInput.name = 'mapping_id';
    idInput.value = mappingId;
    form.appendChild(idInput);

    document.body.appendChild(form);
    form.submit();
}

function setQuickStatus(status) {
    const statusFilter = document.getElementById('unmatchedStatusFilter');
    if (statusFilter) {
        statusFilter.value = status;
        if (typeof window.applyUnmatchedFilter === 'function') {
            window.applyUnmatchedFilter();
        }
    }
}

function resetUnmatchedFilters() {
    const searchInput = document.getElementById('unmatchedSearchInput');
    const statusFilter = document.getElementById('unmatchedStatusFilter');
    const deviceFilter = document.getElementById('unmatchedDeviceFilter');
    if (searchInput) searchInput.value = '';
    if (statusFilter) statusFilter.value = 'ALL';
    if (deviceFilter) deviceFilter.value = '';
    if (typeof window.applyUnmatchedFilter === 'function') {
        window.applyUnmatchedFilter();
    }
}

// Client-side filtering for unmatched rows
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('unmatchedSearchInput');
    const statusFilter = document.getElementById('unmatchedStatusFilter');
    const deviceFilter = document.getElementById('unmatchedDeviceFilter');
    const rows = document.querySelectorAll('.unmatched-row');
    const badge = document.getElementById('unmatchedCountBadge');

    window.applyUnmatchedFilter = function() {
        const query = (searchInput ? searchInput.value : '').toLowerCase().trim();
        const status = statusFilter ? statusFilter.value : 'ALL';
        const device = deviceFilter ? deviceFilter.value : '';
        let visible = 0;
        let visibleMapped = 0;
        let visibleUnmatched = 0;

        rows.forEach(r => {
            const rowStatus = r.getAttribute('data-status');
            const rowDevice = r.getAttribute('data-device') || '';
            const rowText = r.getAttribute('data-text') || '';
            const matchesSearch = !query || rowText.includes(query);
            const matchesStatus = (status === 'ALL') || (rowStatus === status);
            const matchesDevice = !device || (rowDevice === device);

            if (matchesSearch && matchesStatus && matchesDevice) {
                r.style.display = '';
                visible++;
                if (rowStatus === 'MAPPED') visibleMapped++;
                if (rowStatus === 'UNMATCHED') visibleUnmatched++;
            } else {
                r.style.display = 'none';
            }
        });

        if (badge) {
            if (status === 'MAPPED') {
                badge.textContent = visible + ' mapped records';
            } else if (status === 'UNMATCHED') {
                badge.textContent = visible + ' unmapped records';
            } else if (status === 'IGNORED') {
                badge.textContent = visible + ' archived records';
            } else {
                badge.textContent = visible + ' records (' + visibleMapped + ' mapped, ' + visibleUnmatched + ' unmapped)';
            }
        }
    };

    if (searchInput) searchInput.addEventListener('input', window.applyUnmatchedFilter);
    if (statusFilter) statusFilter.addEventListener('change', window.applyUnmatchedFilter);
    if (deviceFilter) deviceFilter.addEventListener('change', window.applyUnmatchedFilter);

    window.applyUnmatchedFilter();
});
</script>
