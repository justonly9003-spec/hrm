<?= view('attendance/attendance_nav', ['activeTab' => 'roster']) ?>
<?= view('roster/index', get_defined_vars()) ?>
