<?php
use App\Services\Auth\PasswordPolicyService;
$passwordPolicy = $passwordPolicy ?? PasswordPolicyService::forCompany(null);
?>
<div class="w-full max-w-md mx-auto" x-data="resetPasswordFlow()" x-init="init()">
    <div class="bg-slate-900/90 backdrop-blur-xl border border-slate-800/90 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-black/70">
        
        <!-- Header -->
        <div class="text-center mb-6">
            <div class="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 to-indigo-400 flex items-center justify-center text-white mx-auto mb-3 shadow-lg shadow-indigo-600/30 border border-indigo-400/30">
                <i data-lucide="shield-check" class="w-6 h-6"></i>
            </div>
            <h2 class="text-xl sm:text-2xl font-bold text-white tracking-tight">Create New Password</h2>
            <p class="text-xs sm:text-sm text-slate-400 mt-1" x-text="codeVerified ? 'Verification confirmed. Enter your new password below.' : 'Enter the reset token sent to your email to verify identity'">
                Enter the reset token sent to your email to verify identity
            </p>
        </div>

        <!-- Session Flash Error -->
        <?php if (session()->getFlashdata('error')): ?>
            <div role="alert" class="mb-5 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2.5">
                <i data-lucide="alert-circle" class="w-4 h-4 text-rose-400 shrink-0 mt-0.5"></i>
                <div class="flex-1 leading-relaxed break-words break-all"><?= esc(session()->getFlashdata('error')) ?></div>
            </div>
        <?php endif; ?>

        <!-- Session Flash Success -->
        <?php if (session()->getFlashdata('success')): ?>
            <div role="status" class="mb-5 p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-start gap-2.5">
                <i data-lucide="check-circle" class="w-4 h-4 text-emerald-400 shrink-0 mt-0.5"></i>
                <div class="flex-1 leading-relaxed break-words break-all"><?= esc(session()->getFlashdata('success')) ?></div>
            </div>
        <?php endif; ?>

        <!-- Live Code Verification Error -->
        <div x-show="verifyError" x-cloak class="mb-5 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2.5">
            <i data-lucide="alert-circle" class="w-4 h-4 text-rose-400 shrink-0 mt-0.5"></i>
            <div class="flex-1 leading-relaxed" x-text="verifyError"></div>
        </div>

        <!-- Live Code Verification Success -->
        <div x-show="verifySuccess" x-cloak class="mb-5 p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-start gap-2.5">
            <i data-lucide="check-circle" class="w-4 h-4 text-emerald-400 shrink-0 mt-0.5"></i>
            <div class="flex-1 leading-relaxed" x-text="verifySuccess"></div>
        </div>

        <!-- Reset Password Form -->
        <form action="<?= base_url('auth/reset-password') ?>" method="POST" @submit="handleSubmit($event)" class="space-y-4">
            <?= csrf_field() ?>

            <!-- Step 1: Registered Work Email -->
            <div>
                <label class="block text-xs font-semibold text-slate-300 mb-1.5">Registered Work Email</label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <i data-lucide="mail" class="w-4 h-4"></i>
                    </div>
                    <input 
                        type="email" 
                        name="email" 
                        x-model="email"
                        :readonly="codeVerified"
                        placeholder="user@enterprise.local" 
                        required 
                        class="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition shadow-inner"
                        :class="codeVerified ? 'bg-slate-900/60 text-slate-400 border-slate-800 cursor-not-allowed' : ''"
                    >
                </div>
            </div>

            <!-- Step 1: Reset Token -->
            <div>
                <div class="flex items-center justify-between mb-1.5">
                    <label class="block text-xs font-semibold text-slate-300">Password Reset Token</label>
                    <span class="text-[11px]" :class="codeVerified ? 'text-emerald-400 font-semibold' : 'text-slate-400'">
                        <span x-show="!codeVerified">Check email link / token</span>
                        <span x-show="codeVerified" x-cloak class="inline-flex items-center gap-1">
                            <i data-lucide="shield-check" class="w-3 h-3 text-emerald-400"></i> Token Confirmed
                        </span>
                    </span>
                </div>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <i data-lucide="key-round" class="w-4 h-4" :class="codeVerified ? 'text-emerald-400' : ''"></i>
                    </div>
                    <input 
                        type="text" 
                        name="token" 
                        id="verificationTokenInput"
                        x-model="token"
                        @keydown.enter.prevent="if(!codeVerified) verifyToken()"
                        :readonly="codeVerified"
                        placeholder="Paste reset token from email" 
                        autocomplete="off"
                        required 
                        class="w-full pl-10 pr-10 py-2.5 rounded-xl bg-slate-800/80 border text-white placeholder-slate-600 text-sm font-mono focus:outline-none focus:ring-2 transition shadow-inner"
                        :class="codeVerified ? 'border-emerald-500/60 bg-emerald-950/20 text-emerald-300 ring-1 ring-emerald-500/40 cursor-not-allowed' : 'border-slate-700 focus:ring-indigo-500 focus:border-indigo-500'"
                    >
                    <input type="hidden" name="code" :value="token">
                    <div x-show="codeVerified" x-cloak class="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-emerald-400">
                        <i data-lucide="check" class="w-5 h-5 text-emerald-400"></i>
                    </div>
                </div>
                <div class="flex items-center justify-between mt-1 text-[11px]">
                    <span class="text-slate-400">Valid for 15 minutes</span>
                    <a href="<?= base_url('auth/forgot-password') ?>" class="text-indigo-400 hover:text-indigo-300 transition" x-show="!codeVerified">
                        Request New Link
                    </a>
                </div>
            </div>

            <!-- "Verify Token" Trigger Button (Shown ONLY before verification) -->
            <div x-show="!codeVerified" class="pt-1">
                <button 
                    type="button" 
                    @click="verifyToken()"
                    :disabled="verifying || !token || token.length < 16"
                    class="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.99] text-white font-semibold text-xs transition-all duration-200 shadow-md shadow-indigo-600/30 flex items-center justify-center gap-2 cursor-pointer"
                >
                    <template x-if="verifying">
                        <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
                        </svg>
                    </template>
                    <template x-if="!verifying">
                        <i data-lucide="shield-check" class="w-4 h-4"></i>
                    </template>
                    <span x-text="verifying ? 'Verifying Token...' : 'Verify Token'">Verify Token</span>
                </button>
            </div>

            <!-- Step 2: Password Fields (HIDDEN UNTIL TOKEN IS VERIFIED) -->
            <div x-show="codeVerified" x-cloak class="space-y-4 pt-3 border-t border-slate-800/80">
                
                <div class="p-2.5 rounded-xl bg-indigo-950/40 border border-indigo-800/50 flex items-center gap-2 text-indigo-300 text-xs">
                    <i data-lucide="unlock" class="w-4 h-4 text-indigo-400 shrink-0"></i>
                    <span>Identity confirmed! Create your new password below.</span>
                </div>

                <!-- New Password -->
                <div>
                    <label class="block text-xs font-semibold text-slate-300 mb-1.5">New Password</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                            <i data-lucide="lock" class="w-4 h-4"></i>
                        </div>
                        <input 
                            type="password" 
                            name="new_password" 
                            id="newPasswordInput" 
                            x-model="newPassword" 
                            placeholder="••••••••••••" 
                            minlength="<?= (int)$passwordPolicy['min_length'] ?>" 
                            :required="codeVerified" 
                            class="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition shadow-inner font-mono"
                        >
                    </div>
                    <p class="text-[11px] text-slate-500 mt-1">Must be at least 12 characters long</p>
                </div>

                <!-- Confirm New Password -->
                <div>
                    <label class="block text-xs font-semibold text-slate-300 mb-1.5">Confirm New Password</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                            <i data-lucide="check-check" class="w-4 h-4"></i>
                        </div>
                        <input 
                            type="password" 
                            name="confirm_password" 
                            x-model="confirmPassword"
                            placeholder="••••••••••••" 
                            minlength="<?= (int)$passwordPolicy['min_length'] ?>"
                            :required="codeVerified"
                            class="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition shadow-inner font-mono"
                        >
                    </div>
                    <p x-show="newPassword && confirmPassword && newPassword !== confirmPassword" class="text-[11px] text-rose-400 mt-1">
                        Passwords do not match
                    </p>
                </div>

                <!-- Submit New Password Button -->
                <button 
                    type="submit" 
                    :disabled="submitting || !newPassword || newPassword.length < 12 || newPassword !== confirmPassword"
                    class="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-indigo-600 hover:from-emerald-500 hover:to-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.99] text-white font-semibold text-sm transition-all duration-200 shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 cursor-pointer mt-4"
                >
                    <template x-if="submitting">
                        <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
                        </svg>
                    </template>
                    <template x-if="!submitting">
                        <i data-lucide="check" class="w-4 h-4"></i>
                    </template>
                    <span x-text="submitting ? 'Saving Password...' : 'Save New Password'">Save New Password</span>
                </button>
            </div>
        </form>

        <div class="mt-6 pt-5 border-t border-slate-800/80 text-center">
            <a href="<?= base_url('auth/login') ?>" class="text-xs text-slate-400 hover:text-indigo-400 font-medium transition inline-flex items-center gap-1.5">
                <i data-lucide="arrow-left" class="w-3.5 h-3.5"></i>
                <span>Back to Sign In</span>
            </a>
        </div>
    </div>
</div>

<script>
function resetPasswordFlow() {
    return {
        email: <?= json_encode($email ?? old('email') ?? '') ?>,
        token: <?= json_encode($token ?? old('token') ?? old('code') ?? '') ?>,
        codeVerified: false,
        verifying: false,
        submitting: false,
        verifyError: '',
        verifySuccess: '',
        newPassword: '',
        confirmPassword: '',

        init() {
            if (this.email && this.token && this.token.length >= 16) {
                this.verifyToken();
            }
        },

        async verifyToken() {
            this.verifyError = '';
            this.verifySuccess = '';
            const cleanEmail = (this.email || '').trim();
            const cleanToken = (this.token || '').trim();

            if (!cleanEmail) {
                this.verifyError = 'Please enter your registered work email.';
                return;
            }

            if (!cleanToken) {
                this.verifyError = 'Please enter or paste the reset token from your email.';
                return;
            }

            this.verifying = true;

            try {
                const csrfMetaName = document.querySelector('meta[name="csrf-token-name"]');
                const csrfMetaHash = document.querySelector('meta[name="csrf-hash"]');
                const csrfName = csrfMetaName ? csrfMetaName.getAttribute('content') : 'csrf_test_name';
                const csrfHash = csrfMetaHash ? csrfMetaHash.getAttribute('content') : (document.querySelector('input[name="' + csrfName + '"]')?.value || '');

                const formData = new FormData();
                formData.append('email', cleanEmail);
                formData.append('token', cleanToken);
                formData.append('code', cleanToken);
                if (csrfName && csrfHash) {
                    formData.append(csrfName, csrfHash);
                }

                const response = await fetch('<?= base_url('auth/verify-reset-code') ?>', {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: formData
                });

                const data = await response.json();

                // Keep CSRF token in sync
                if (data.csrf_hash) {
                    if (csrfMetaHash) csrfMetaHash.setAttribute('content', data.csrf_hash);
                    const csrfInput = document.querySelector('input[name="' + csrfName + '"]');
                    if (csrfInput) csrfInput.value = data.csrf_hash;
                }

                if (data.success) {
                    this.codeVerified = true;
                    this.verifySuccess = data.message || 'Token verified successfully! Please enter your new password.';
                    setTimeout(() => {
                        const passInput = document.getElementById('newPasswordInput');
                        if (passInput) passInput.focus();
                        if (typeof lucide !== 'undefined') lucide.createIcons();
                    }, 100);
                } else {
                    this.verifyError = data.message || 'Invalid or expired reset token.';
                }
            } catch (err) {
                this.verifyError = 'Error verifying token. Please check your network connection and try again.';
            } finally {
                this.verifying = false;
                if (typeof lucide !== 'undefined') {
                    setTimeout(() => lucide.createIcons(), 50);
                }
            }
        },

        handleSubmit(event) {
            if (!this.codeVerified) {
                event.preventDefault();
                this.verifyToken();
                return;
            }

            if (!this.newPassword || this.newPassword.length < 12) {
                event.preventDefault();
                this.verifyError = 'New password must be at least 12 characters long.';
                return;
            }

            if (this.newPassword !== this.confirmPassword) {
                event.preventDefault();
                this.verifyError = 'Passwords do not match.';
                return;
            }

            this.submitting = true;
        }
    };
}
</script>
