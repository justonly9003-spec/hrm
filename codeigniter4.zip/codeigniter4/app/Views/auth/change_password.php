<?php
use App\Services\Auth\PasswordPolicyService;
$passwordPolicy = $passwordPolicy ?? PasswordPolicyService::forCompany(session()->get('company_id'));
?>
<div class="w-full max-w-md mx-auto">
    <div class="bg-slate-900/90 backdrop-blur-xl border border-slate-800/90 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-black/70">
        
        <!-- Header -->
        <div class="text-center mb-6">
            <div class="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-indigo-600 flex items-center justify-center text-white mx-auto mb-3 shadow-lg shadow-indigo-600/30 border border-indigo-400/30">
                <i data-lucide="shield-alert" class="w-6 h-6"></i>
            </div>
            <h2 class="text-xl sm:text-2xl font-bold text-white tracking-tight">Change Your Password</h2>
            <p class="text-xs sm:text-sm text-slate-400 mt-1">Please set a secure, personalized password before continuing</p>
        </div>

        <!-- Flash Warning (Mandatory Change) -->
        <?php if (session()->getFlashdata('warning')): ?>
            <div role="alert" class="mb-5 p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-start gap-2.5">
                <i data-lucide="alert-triangle" class="w-4 h-4 text-amber-400 shrink-0 mt-0.5"></i>
                <div class="flex-1 leading-relaxed"><?= esc(session()->getFlashdata('warning')) ?></div>
            </div>
        <?php endif; ?>

        <!-- Flash Error -->
        <?php if (session()->getFlashdata('error')): ?>
            <div role="alert" class="mb-5 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2.5">
                <i data-lucide="alert-circle" class="w-4 h-4 text-rose-400 shrink-0 mt-0.5"></i>
                <div class="flex-1 leading-relaxed"><?= esc(session()->getFlashdata('error')) ?></div>
            </div>
        <?php endif; ?>

        <!-- Flash Success -->
        <?php if (session()->getFlashdata('success')): ?>
            <div role="status" class="mb-5 p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-start gap-2.5">
                <i data-lucide="check-circle" class="w-4 h-4 text-emerald-400 shrink-0 mt-0.5"></i>
                <div class="flex-1 leading-relaxed"><?= esc(session()->getFlashdata('success')) ?></div>
            </div>
        <?php endif; ?>

        <!-- Change Password Form -->
        <form action="<?= base_url('change-password') ?>" method="POST" class="space-y-4">
            <?= csrf_field() ?>

            <!-- Current Password -->
            <div>
                <label class="block text-xs font-semibold text-slate-300 mb-1.5">Current / Temporary Password</label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <i data-lucide="lock" class="w-4 h-4"></i>
                    </div>
                    <input 
                        type="password" 
                        name="current_password" 
                        required 
                        placeholder="Enter current password"
                        class="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition shadow-inner font-mono"
                    >
                </div>
            </div>

            <!-- New Password -->
            <div>
                <label class="block text-xs font-semibold text-slate-300 mb-1.5">New Password <span class="text-slate-400 font-normal">(<?= esc(PasswordPolicyService::describe($passwordPolicy)) ?>)</span></label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <i data-lucide="key" class="w-4 h-4"></i>
                    </div>
                    <input 
                        type="password" 
                        name="new_password" 
                        required 
                        minlength="<?= (int)$passwordPolicy['min_length'] ?>"
                        placeholder="Enter new secure password"
                        class="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition shadow-inner font-mono"
                    >
                </div>
            </div>

            <!-- Confirm Password -->
            <div>
                <label class="block text-xs font-semibold text-slate-300 mb-1.5">Confirm New Password</label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <i data-lucide="check" class="w-4 h-4"></i>
                    </div>
                    <input 
                        type="password" 
                        name="confirm_password" 
                        required 
                        minlength="<?= (int)$passwordPolicy['min_length'] ?>"
                        placeholder="Re-enter new password"
                        class="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition shadow-inner font-mono"
                    >
                </div>
            </div>

            <button 
                type="submit" 
                class="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 active:scale-[0.99] text-white font-semibold text-sm transition-all duration-200 shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 cursor-pointer mt-2"
            >
                <i data-lucide="save" class="w-4 h-4"></i>
                <span>Update Password & Continue</span>
            </button>
        </form>

        <div class="mt-6 pt-5 border-t border-slate-800/80 text-center">
            <form method="POST" action="<?= base_url('logout') ?>" class="inline m-0 p-0">
                <?= csrf_field() ?>
                <button type="submit" class="text-xs text-slate-400 hover:text-rose-400 font-medium transition inline-flex items-center gap-1.5 bg-transparent border-0 cursor-pointer">
                    <i data-lucide="log-out" class="w-3.5 h-3.5"></i>
                    <span>Sign Out Instead</span>
                </button>
            </form>
        </div>

    </div>
</div>
