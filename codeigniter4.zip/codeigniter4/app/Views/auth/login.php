<div class="w-full grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
    
    <!-- Left Column: Enterprise Security & Platform Topology (Desktop) -->
    <div class="lg:col-span-6 space-y-6 text-left hidden lg:block">
        
        <div class="space-y-3">
            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-semibold">
                <i data-lucide="sparkles" class="w-3.5 h-3.5 text-indigo-400"></i>
                <span>Next-Gen Enterprise Authentication</span>
            </div>
            <h1 class="text-3xl sm:text-4xl font-extrabold text-white tracking-tight leading-tight">
                Secure Workforce <span class="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-300 to-indigo-200">Management Platform</span>
            </h1>
            <p class="text-sm text-slate-300 leading-relaxed max-w-lg">
                Sign in to manage human capital intelligence, dynamic shift rostering, biometric attendance reconciliation, payroll governance, and auditable enterprise compliance.
            </p>
        </div>

        <!-- Abstract Topology & Security Architecture Matrix -->
        <div class="bg-slate-900/70 border border-slate-800 rounded-2xl p-6 backdrop-blur-md space-y-5 shadow-xl relative overflow-hidden">
            <div class="absolute -right-8 -top-8 w-40 h-40 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none"></div>

            <div class="flex items-center justify-between pb-3 border-b border-slate-800 text-xs">
                <div class="flex items-center gap-2 text-slate-300 font-semibold">
                    <i data-lucide="network" class="w-4 h-4 text-indigo-400"></i>
                    <span>Enterprise Architecture Matrix</span>
                </div>
                <span class="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-800/60 flex items-center gap-1">
                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span> Active Sync
                </span>
            </div>

            <!-- Connected Security Nodes -->
            <div class="space-y-3 text-xs">
                <div class="flex items-center gap-3 p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60">
                    <div class="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shrink-0">
                        <i data-lucide="shield-check" class="w-4 h-4"></i>
                    </div>
                    <div class="flex-1">
                        <div class="font-semibold text-slate-200">Role-Based Security Layer</div>
                        <div class="text-[11px] text-slate-400">Strict permission matrix across operational tiers</div>
                    </div>
                    <i data-lucide="check" class="w-4 h-4 text-indigo-400"></i>
                </div>

                <div class="flex items-center gap-3 p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60">
                    <div class="w-8 h-8 rounded-lg bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 shrink-0">
                        <i data-lucide="activity" class="w-4 h-4"></i>
                    </div>
                    <div class="flex-1">
                        <div class="font-semibold text-slate-200">Continuous Audit & Integrity</div>
                        <div class="text-[11px] text-slate-400">Tamper-evident activity logs & payroll ledgers</div>
                    </div>
                    <i data-lucide="check" class="w-4 h-4 text-purple-400"></i>
                </div>

                <div class="flex items-center gap-3 p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60">
                    <div class="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
                        <i data-lucide="cpu" class="w-4 h-4"></i>
                    </div>
                    <div class="flex-1">
                        <div class="font-semibold text-slate-200">Dynamic Rule & Roster Engine</div>
                        <div class="text-[11px] text-slate-400">Automated shift policies, attendance & leave reconciliation</div>
                    </div>
                    <i data-lucide="check" class="w-4 h-4 text-emerald-400"></i>
                </div>
            </div>

            <!-- Metrics Row -->
            <div class="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800 text-center">
                <div class="p-2 rounded-lg bg-slate-800/40 border border-slate-800">
                    <div class="text-sm font-extrabold text-white">99.99%</div>
                    <div class="text-[10px] text-slate-400 uppercase tracking-wider">Uptime SLA</div>
                </div>
                <div class="p-2 rounded-lg bg-slate-800/40 border border-slate-800">
                    <div class="text-sm font-extrabold text-indigo-300">Zero Trust</div>
                    <div class="text-[10px] text-slate-400 uppercase tracking-wider">IAM Enforced</div>
                </div>
                <div class="p-2 rounded-lg bg-slate-800/40 border border-slate-800">
                    <div class="text-sm font-extrabold text-emerald-400">AES-256</div>
                    <div class="text-[10px] text-slate-400 uppercase tracking-wider">Encrypted</div>
                </div>
            </div>

        </div>

        <!-- Capability Chips -->
        <div class="flex flex-wrap gap-2 text-[11px] text-slate-400">
            <span class="px-2.5 py-1 rounded-md bg-slate-800/60 border border-slate-700/60">Time & Attendance</span>
            <span class="px-2.5 py-1 rounded-md bg-slate-800/60 border border-slate-700/60">Shift Rostering</span>
            <span class="px-2.5 py-1 rounded-md bg-slate-800/60 border border-slate-700/60">Automated Payroll</span>
            <span class="px-2.5 py-1 rounded-md bg-slate-800/60 border border-slate-700/60">Employee Self-Service</span>
            <span class="px-2.5 py-1 rounded-md bg-slate-800/60 border border-slate-700/60">Compliance & Audit</span>
        </div>

    </div>

    <!-- Right Column: Premium Enterprise Authentication Card -->
    <div class="lg:col-span-6 flex justify-center w-full">
        <div id="enterprise-login-card" class="w-full max-w-md bg-slate-900/90 backdrop-blur-xl border border-slate-800/90 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-black/70 relative">
            
            <!-- Card Header -->
            <div class="text-center mb-6">
                <div class="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 to-indigo-400 flex items-center justify-center text-white mx-auto mb-3 shadow-lg shadow-indigo-600/30 border border-indigo-400/30">
                    <i data-lucide="key-round" class="w-6 h-6"></i>
                </div>
                <h2 class="text-xl sm:text-2xl font-bold text-white tracking-tight">Welcome back</h2>
                <p class="text-xs sm:text-sm text-slate-400 mt-1">Sign in to securely access your workspace.</p>
            </div>

            <!-- Flash Error Message -->
            <?php if (session()->getFlashdata('error')): ?>
                <div id="login-error-alert" role="alert" class="mb-5 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2.5">
                    <i data-lucide="alert-circle" class="w-4 h-4 text-rose-400 shrink-0 mt-0.5"></i>
                    <div class="flex-1 leading-relaxed break-words break-all"><?= esc(session()->getFlashdata('error')) ?></div>
                </div>
            <?php endif; ?>

            <!-- Flash Success Message -->
            <?php if (session()->getFlashdata('success')): ?>
                <div id="login-success-alert" role="status" class="mb-5 p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-start gap-2.5">
                    <i data-lucide="check-circle" class="w-4 h-4 text-emerald-400 shrink-0 mt-0.5"></i>
                    <div class="flex-1 leading-relaxed break-words break-all">
                        <div><?= esc(session()->getFlashdata('success')) ?></div>
                        <?php if (session()->getFlashdata('reset_url')): ?>
                            <div class="mt-2.5 pt-2 border-t border-emerald-500/30">
                                <a href="<?= esc(session()->getFlashdata('reset_url')) ?>" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400/40 text-emerald-200 font-semibold text-xs transition">
                                    <span>Enter 6-Digit Code & Reset Password</span>
                                    <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Login Form -->
            <form id="loginForm" action="<?= base_url('auth/login') ?>" method="POST" class="space-y-4" novalidate>
                <?= csrf_field() ?>

                <!-- Username or Email Field -->
                <div>
                    <label for="loginUsername" class="block text-xs font-semibold text-slate-300 mb-1.5">
                        Username, Email or Staff ID
                    </label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                            <i data-lucide="user" class="w-4 h-4"></i>
                        </div>
                        <input
                            type="text"
                            id="loginUsername"
                            name="username"
                            required
                            autocomplete="username"
                            placeholder="Enter your username or email"
                            class="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition shadow-inner"
                        >
                    </div>
                </div>

                <!-- Password Field -->
                <div>
                    <div class="flex items-center justify-between mb-1.5">
                        <label for="loginPassword" class="block text-xs font-semibold text-slate-300">
                            Password
                        </label>
                        <div class="flex items-center gap-2">
                            <span id="capsLockAlert" class="hidden text-[11px] font-semibold text-amber-400 flex items-center gap-1">
                                Caps Lock is ON
                            </span>
                            <a href="<?= base_url('auth/forgot-password') ?>" class="text-[11px] font-semibold text-indigo-400 hover:text-indigo-300 transition">
                                Forgot?
                            </a>
                        </div>
                    </div>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                            <i data-lucide="lock" class="w-4 h-4"></i>
                        </div>
                        <input
                            type="password"
                            id="loginPassword"
                            name="password"
                            required
                            autocomplete="current-password"
                            placeholder="••••••••"
                            class="w-full pl-10 pr-10 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition shadow-inner"
                        >
                        <button
                            type="button"
                            id="togglePasswordBtn"
                            aria-label="Toggle password visibility"
                            class="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-200 transition cursor-pointer"
                        >
                            <i data-lucide="eye" id="togglePasswordIcon" class="w-4 h-4"></i>
                        </button>
                    </div>
                </div>

                <!-- Remember Device Option -->
                <div class="flex items-center justify-between pt-1">
                    <label class="flex items-center gap-2 cursor-pointer select-none">
                        <input
                            type="checkbox"
                            id="rememberMe"
                            name="remember_me"
                            checked
                            class="w-4 h-4 rounded bg-slate-800 border-slate-700 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                        >
                        <span class="text-xs text-slate-300 hover:text-white transition">
                            Remember this device
                        </span>
                    </label>
                </div>

                <!-- Submit Button -->
                <button
                    type="submit"
                    id="loginSubmitBtn"
                    class="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 active:scale-[0.99] text-white font-semibold text-sm transition-all duration-200 shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed mt-2"
                >
                    <span id="btnText">Sign In to Dashboard</span>
                    <i data-lucide="arrow-right" id="btnIcon" class="w-4 h-4"></i>
                </button>
            </form>

            <!-- Subtle Security Indicators -->
            <div class="mt-6 pt-5 border-t border-slate-800/80">
                <div class="grid grid-cols-2 gap-2 text-[11px] text-slate-400">
                    <div class="flex items-center gap-1.5">
                        <i data-lucide="shield-check" class="w-3.5 h-3.5 text-indigo-400 shrink-0"></i>
                        <span class="truncate">Encrypted Access</span>
                    </div>
                    <div class="flex items-center gap-1.5">
                        <i data-lucide="lock" class="w-3.5 h-3.5 text-indigo-400 shrink-0"></i>
                        <span class="truncate">Role-Based Security</span>
                    </div>
                    <div class="flex items-center gap-1.5">
                        <i data-lucide="file-check" class="w-3.5 h-3.5 text-indigo-400 shrink-0"></i>
                        <span class="truncate">Audit Protected</span>
                    </div>
                    <div class="flex items-center gap-1.5">
                        <i data-lucide="check-circle-2" class="w-3.5 h-3.5 text-indigo-400 shrink-0"></i>
                        <span class="truncate">Secure Session</span>
                    </div>
                </div>
            </div>

        </div>
    </div>

</div>

<!-- Client-side Security & UX Enhancement Script -->
<script>
    (function() {
        const passwordInput = document.getElementById('loginPassword');
        const toggleBtn = document.getElementById('togglePasswordBtn');
        const toggleIcon = document.getElementById('togglePasswordIcon');
        const capsLockAlert = document.getElementById('capsLockAlert');
        const loginForm = document.getElementById('loginForm');
        const submitBtn = document.getElementById('loginSubmitBtn');
        const btnText = document.getElementById('btnText');
        const btnIcon = document.getElementById('btnIcon');

        // Password visibility toggle
        if (toggleBtn && passwordInput) {
            toggleBtn.addEventListener('click', function() {
                const isPassword = passwordInput.getAttribute('type') === 'password';
                passwordInput.setAttribute('type', isPassword ? 'text' : 'password');
                
                if (toggleIcon) {
                    toggleIcon.setAttribute('data-lucide', isPassword ? 'eye-off' : 'eye');
                    if (typeof lucide !== 'undefined') {
                        lucide.createIcons();
                    }
                }
            });
        }

        // Caps Lock detection
        if (passwordInput && capsLockAlert) {
            const checkCapsLock = function(e) {
                if (e.getModifierState && e.getModifierState('CapsLock')) {
                    capsLockAlert.classList.remove('hidden');
                } else {
                    capsLockAlert.classList.add('hidden');
                }
            };
            passwordInput.addEventListener('keydown', checkCapsLock);
            passwordInput.addEventListener('keyup', checkCapsLock);
        }

        // Form submission loading state
        if (loginForm && submitBtn) {
            loginForm.addEventListener('submit', function() {
                submitBtn.disabled = true;
                if (btnText) btnText.textContent = 'Authenticating...';
                if (btnIcon) {
                    btnIcon.setAttribute('data-lucide', 'loader-2');
                    btnIcon.classList.add('animate-spin');
                    if (typeof lucide !== 'undefined') {
                        lucide.createIcons();
                    }
                }
            });
        }
    })();
</script>
