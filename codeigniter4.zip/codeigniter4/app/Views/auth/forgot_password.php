<div class="w-full max-w-md mx-auto">
    <div class="bg-slate-900/90 backdrop-blur-xl border border-slate-800/90 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-black/70">
        
        <!-- Header -->
        <div class="text-center mb-6">
            <div class="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 to-indigo-400 flex items-center justify-center text-white mx-auto mb-3 shadow-lg shadow-indigo-600/30 border border-indigo-400/30">
                <i data-lucide="key-round" class="w-6 h-6"></i>
            </div>
            <h2 class="text-xl sm:text-2xl font-bold text-white tracking-tight">Reset Password</h2>
            <p class="text-xs sm:text-sm text-slate-400 mt-1">Enter your registered work email to receive a secure password reset link</p>
        </div>

        <!-- Flash Error -->
        <?php if (session()->getFlashdata('error')): ?>
            <div role="alert" class="mb-5 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2.5">
                <i data-lucide="alert-circle" class="w-4 h-4 text-rose-400 shrink-0 mt-0.5"></i>
                <div class="flex-1 leading-relaxed break-words break-all"><?= esc(session()->getFlashdata('error')) ?></div>
            </div>
        <?php endif; ?>

        <!-- Flash Success -->
        <?php if (session()->getFlashdata('success')): ?>
            <div role="status" class="mb-5 p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-start gap-2.5">
                <i data-lucide="check-circle" class="w-4 h-4 text-emerald-400 shrink-0 mt-0.5"></i>
                <div class="flex-1 leading-relaxed break-words break-all">
                    <div><?= esc(session()->getFlashdata('success')) ?></div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Reset Request Form -->
        <form action="<?= base_url('auth/forgot-password') ?>" method="POST" class="space-y-4">
            <?= csrf_field() ?>
            <div>
                <label class="block text-xs font-semibold text-slate-300 mb-1.5">Registered Work Email</label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <i data-lucide="mail" class="w-4 h-4"></i>
                    </div>
                    <input 
                        type="email" 
                        name="email" 
                        placeholder="user@enterprise.local" 
                        required 
                        class="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition shadow-inner"
                    >
                </div>
            </div>

            <button 
                type="submit" 
                class="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 active:scale-[0.99] text-white font-semibold text-sm transition-all duration-200 shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 cursor-pointer mt-2"
            >
                <i data-lucide="send" class="w-4 h-4"></i>
                <span>Send Password Reset Link</span>
            </button>
        </form>

        <div class="mt-6 pt-5 border-t border-slate-800/80 text-center">
            <a href="<?= base_url('auth/login') ?>" class="text-xs text-slate-400 hover:text-indigo-400 font-medium transition inline-flex items-center gap-1.5">
                <i data-lucide="arrow-left" class="w-3.5 h-3.5"></i>
                <span>Back to Sign In</span>
            </a>
        </div>

    </div>
</div>
