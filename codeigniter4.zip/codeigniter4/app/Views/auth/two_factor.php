<div class="w-full max-w-md mx-auto">
    <div class="bg-slate-900/90 backdrop-blur-xl border border-slate-800/90 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-black/70">
        
        <!-- Header -->
        <div class="text-center mb-6">
            <div class="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 to-indigo-400 flex items-center justify-center text-white mx-auto mb-3 shadow-lg shadow-indigo-600/30 border border-indigo-400/30">
                <i data-lucide="shield-check" class="w-6 h-6"></i>
            </div>
            <h2 class="text-xl sm:text-2xl font-bold text-white tracking-tight">Two-Factor Verification</h2>
            <p class="text-xs sm:text-sm text-slate-400 mt-1">Enter the 6-digit security code dispatched to your registered email</p>
        </div>

        <!-- Flash Info -->
        <?php if (session()->getFlashdata('info')): ?>
            <div role="status" class="mb-5 p-3.5 rounded-xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs flex items-start gap-2.5">
                <i data-lucide="info" class="w-4 h-4 text-indigo-400 shrink-0 mt-0.5"></i>
                <div class="flex-1 leading-relaxed"><?= esc(session()->getFlashdata('info')) ?></div>
            </div>
        <?php endif; ?>

        <!-- Flash Error -->
        <?php if (session()->getFlashdata('error')): ?>
            <div role="alert" class="mb-5 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2.5">
                <i data-lucide="alert-circle" class="w-4 h-4 text-rose-400 shrink-0 mt-0.5"></i>
                <div class="flex-1 leading-relaxed"><?= esc(session()->getFlashdata('error')) ?></div>
            </div>
        <?php endif; ?>

        <!-- Flash Success -->
        <?php if (session()->getFlashdata('success')): ?>
            <div role="status" class="mb-5 p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-start gap-2.5">
                <i data-lucide="check-circle" class="w-4 h-4 text-emerald-400 shrink-0 mt-0.5"></i>
                <div class="flex-1 leading-relaxed"><?= esc(session()->getFlashdata('success')) ?></div>
            </div>
        <?php endif; ?>

        <!-- Verification Form -->
        <form action="<?= base_url('auth/verify-2fa') ?>" method="POST" class="space-y-4">
            <?= csrf_field() ?>
            <div>
                <label for="otpCode" class="block text-xs font-semibold text-slate-300 mb-1.5 text-center">
                    6-Digit Security Code (OTP)
                </label>
                <div class="relative">
                    <input 
                        type="text" 
                        id="otpCode" 
                        name="otp_code" 
                        maxlength="6" 
                        pattern="[0-9]{6}" 
                        inputmode="numeric"
                        required 
                        autofocus 
                        placeholder="••••••" 
                        class="w-full py-3 px-4 rounded-xl bg-slate-800/80 border border-slate-700 text-center font-mono text-2xl font-bold tracking-[0.4em] text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition shadow-inner"
                    >
                </div>
            </div>
            
            <button 
                type="submit" 
                class="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 active:scale-[0.99] text-white font-semibold text-sm transition-all duration-200 shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 cursor-pointer mt-2"
            >
                <i data-lucide="shield" class="w-4 h-4"></i>
                <span>Verify & Access Dashboard</span>
            </button>
        </form>

        <div class="mt-6 pt-5 border-t border-slate-800/80 text-center">
            <a href="<?= base_url('auth/login') ?>" class="text-xs text-slate-400 hover:text-indigo-400 font-medium transition inline-flex items-center gap-1.5">
                <i data-lucide="arrow-left" class="w-3.5 h-3.5"></i>
                <span>Back to Sign In</span>
            </a>
        </div>

    </div>
</div>
