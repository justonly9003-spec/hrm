<div class="space-y-6">
    <!-- Breadcrumb & Top Bar -->
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
            <div class="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                <a href="<?= base_url() ?>" class="hover:text-indigo-600 dark:hover:text-indigo-400 font-medium">Home</a>
                <i data-lucide="chevron-right" class="w-3.5 h-3.5"></i>
                <span class="text-slate-700 dark:text-slate-200 font-semibold">Employee Self-Service (ESS)</span>
            </div>
            <h1 class="text-2xl font-black text-slate-900 dark:text-white mt-1">Employee Self-Service (ESS) Portal</h1>
        </div>

        <div class="flex items-center gap-3">
            <span class="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 rounded-xl text-xs font-bold font-mono">
                <span class="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                Live Self-Service Active
            </span>
            <?php if (in_array(session()->get('role') ?? '', ['Super Admin', 'Admin', 'HR', 'Manager'])): ?>
                <a href="<?= base_url('dashboard') ?>" class="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs">
                    <i data-lucide="layout-dashboard" class="w-4 h-4"></i>
                    <span>Switch to Executive Admin View</span>
                </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Render ESS Full Interactive Panel -->
    <?= view('dashboard/ess_panel', get_defined_vars()) ?>
</div>
