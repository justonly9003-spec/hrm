<?php
/**
 * Master Enterprise Unified Dashboard View (Single Dashboard View)
 * 
 * PHASES 16 & 17 COMPLIANT:
 * - Strictly ONE single dashboard view across all roles, branches, and scopes.
 * - Zero business calculations in the view.
 * - Receives:
 *   1. $authorized_widgets: fully authorized, non-suppressed widgets
 *   2. $widget_configurations: resolved configurations (precedence: User -> Role -> Branch -> Dept -> Company -> Global)
 *   3. $widget_data: real data payloads from individual data providers (OFF widgets were not queried)
 *   4. $layout: dynamic layout engine specs (order, position, width, height, size, visibility, responsive 12-column classes)
 * - Dynamically renders widgets based on the Layout Engine.
 */
$currentRole            = $currentRole ?? ($role_code ?? 'employee');
$scope                  = $scope ?? ['type' => 'company'];
$authorized_widgets     = $authorized_widgets ?? ($active_widgets ?? []);
$widget_configurations  = $widget_configurations ?? [];
$widget_data            = $widget_data ?? ($metrics['data'] ?? []);
$layout                 = $layout ?? [
    'container_class' => 'grid grid-cols-12 gap-6 w-full',
    'ordered_widgets' => $authorized_widgets,
    'widget_classes'  => [],
    'total_visible'   => count($authorized_widgets),
];

$enabled_modules        = $enabled_modules ?? ($widget_data['enabled_modules'] ?? []);
$isPayrollOn            = !empty($enabled_modules['payroll']);
$isAttendanceOn         = !empty($enabled_modules['attendance']);
$isLeavesOn             = !empty($enabled_modules['leaves']);

// Phase 2 & Phase 3 Category Navigation & Lazy-Loading Scoping
$active_category        = $active_category ?? 'overview';
$category_groups        = $category_groups ?? \App\Services\DashboardWidgetRegistry::getCategoryGroups();
$category_counts        = $category_counts ?? [
    'overview'   => count($category_widgets['overview'] ?? []),
    'attendance' => count($category_widgets['attendance'] ?? []),
    'leaves'     => count($category_widgets['leaves'] ?? []),
    'payroll'    => count($category_widgets['payroll'] ?? []),
];
$category_widgets       = $category_widgets ?? [
    'overview'   => $authorized_widgets,
    'attendance' => [],
    'leaves'     => [],
    'payroll'    => [],
];
?>

<div class="space-y-2.5">
    <!-- 
      CATEGORY NAVIGATION & DASHBOARD CONTROLS DECK (ULTRA-COMPACT SINGLE TOOLBAR)
      Tabs on the left, Scope Filters & Customization Actions in the Top-Right Corner
    -->
    <div class="bg-white dark:bg-slate-900/90 border border-slate-200/80 dark:border-slate-800 rounded-lg px-2 py-1 shadow-2xs backdrop-blur-sm">
        <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-1.5">
            <!-- Left: Category Tabs (Compact & Single-row) -->
            <div class="flex items-center gap-0.5 p-0.5 bg-slate-100 dark:bg-slate-800/80 rounded-md overflow-x-auto" role="tablist" aria-label="Dashboard Categories">
                <?php foreach ($category_groups as $catKey => $catDef): ?>
                    <?php 
                        $isActive = ($active_category === $catKey);
                        $count = $category_counts[$catKey] ?? 0;
                    ?>
                    <button type="button"
                            role="tab"
                            id="tab-btn-<?= esc($catKey) ?>"
                            data-category="<?= esc($catKey) ?>"
                            aria-selected="<?= $isActive ? 'true' : 'false' ?>"
                            aria-controls="category-panel-<?= esc($catKey) ?>"
                            onclick="switchDashboardCategory('<?= esc($catKey) ?>')"
                            class="dashboard-cat-tab group relative flex items-center gap-1 px-2 py-0.5 h-6 rounded text-[11px] font-medium whitespace-nowrap transition-all duration-150 leading-none <?= $isActive ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-2xs border border-slate-200/80 dark:border-slate-700 font-bold' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 border border-transparent' ?>">
                        <i data-lucide="<?= esc($catDef['icon'] ?? 'layout-dashboard') ?>" class="w-3 h-3 <?= $isActive ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-300' ?>"></i>
                        <span><?= esc($catDef['title']) ?></span>
                        <span class="inline-flex items-center justify-center px-1 py-0 text-[9px] font-bold rounded-full <?= $isActive ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-300 border border-indigo-200/50 dark:border-indigo-800/50' : 'bg-slate-200/80 dark:bg-slate-700 text-slate-600 dark:text-slate-300' ?>">
                            <?= (int)$count ?>
                        </span>
                    </button>
                <?php endforeach; ?>
            </div>

            <!-- Right: Scope Filters & Customization Controls (Ultra-Compact Inline Deck) -->
            <div class="flex items-center gap-1 shrink-0 flex-wrap sm:flex-nowrap">
                <?php if (in_array($currentRole, ['company_admin', 'hr_admin', 'hr_officer', 'software_app_admin'], true)): ?>
                    <div class="flex items-center gap-1">
                        <?php if (!empty($branches)): ?>
                            <!-- Branch Scope Filter -->
                            <div class="relative">
                                <select id="dashboard-scope-branch" onchange="applyDashboardScopeFilters()"
                                        class="h-6 text-[11px] font-medium pl-5 pr-4 py-0.5 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-750 transition cursor-pointer appearance-none shadow-2xs leading-none">
                                    <option value="" class="text-slate-900 dark:text-slate-100">All Branches</option>
                                    <?php foreach ($branches as $b): ?>
                                        <option value="<?= esc($b['id']) ?>" <?= (($scope['branch_id'] ?? '') === $b['id']) ? 'selected' : '' ?> class="text-slate-900 dark:text-slate-100">
                                            Branch: <?= esc($b['name']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <i data-lucide="map-pin" class="w-3 h-3 text-slate-400 dark:text-slate-500 absolute left-1.5 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                                <i data-lucide="chevron-down" class="w-2.5 h-2.5 text-slate-400 dark:text-slate-500 absolute right-1 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($departments)): ?>
                            <!-- Department Scope Filter -->
                            <div class="relative">
                                <select id="dashboard-scope-dept" onchange="applyDashboardScopeFilters()"
                                        class="h-6 text-[11px] font-medium pl-5 pr-4 py-0.5 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-750 transition cursor-pointer appearance-none shadow-2xs leading-none">
                                    <option value="" class="text-slate-900 dark:text-slate-100">All Departments</option>
                                    <?php foreach ($departments as $d): ?>
                                        <option value="<?= esc($d['id']) ?>" <?= (($scope['department_id'] ?? '') === $d['id']) ? 'selected' : '' ?> class="text-slate-900 dark:text-slate-100">
                                            Dept: <?= esc($d['name']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <i data-lucide="layers" class="w-3 h-3 text-slate-400 dark:text-slate-500 absolute left-1.5 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                                <i data-lucide="chevron-down" class="w-2.5 h-2.5 text-slate-400 dark:text-slate-500 absolute right-1 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php elseif (in_array($currentRole, ['manager', 'team_leader'], true)): ?>
                    <!-- Locked Managerial Scope: Assigned Department Only -->
                    <div class="inline-flex items-center gap-1 px-2 py-0.5 h-6 rounded bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 text-emerald-700 dark:text-emerald-300 text-[11px] font-medium shadow-2xs leading-none" title="Scope locked to your authorized department">
                        <i data-lucide="lock" class="w-3 h-3 text-emerald-600 dark:text-emerald-400"></i>
                        <span>Dept: <?= esc($scope['department_name'] ?? 'Authorized Department') ?></span>
                    </div>
                <?php endif; ?>

                <div class="flex items-center gap-1">
                    <!-- Interactive User Customization Button -->
                    <button type="button" onclick="openCustomizationModal()" id="btn-customize-dashboard" class="inline-flex items-center gap-1 px-2 py-0.5 h-6 rounded bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-[11px] font-medium transition border border-slate-200 dark:border-slate-700 cursor-pointer shadow-2xs leading-none">
                        <i data-lucide="sliders" class="w-3 h-3 text-indigo-600 dark:text-indigo-400"></i>
                        <span>Customize Layout</span>
                    </button>

                    <?php if (in_array($currentRole, ['software_app_admin', 'company_admin', 'hr_admin'], true)): ?>
                        <a href="<?= base_url('dashboard/widgets') ?>" class="inline-flex items-center gap-1 px-1.5 py-0.5 h-6 rounded bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 text-[11px] font-medium transition border border-slate-200 dark:border-slate-700 shadow-2xs leading-none" title="System Widget Administration">
                            <i data-lucide="shield-check" class="w-3 h-3 text-indigo-500"></i>
                            <span>Admin Rules</span>
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Hidden indicator for JS category switch -->
                <span id="category-description-text" class="hidden"><?= esc($category_groups[$active_category]['description'] ?? '') ?></span>
            </div>
        </div>
    </div>

    <?php
        $company = $company ?? null;
        $user = $user ?? [];
        $companyId = $companyId ?? ($scope['company_id'] ?? ($company['id'] ?? null));

        // Helper closure to render a list of widgets within a category container
        $renderCategoryWidgetList = function(array $widgets) use ($layout, $widget_configurations, $widget_data, $metrics, $currentRole, $scope, $company, $companyId, $user) {
            $widgetClasses = $layout['widget_classes'] ?? [];
            $hasExecutiveKpis          = false;
            $hasLateArrivalsWidget     = false;
            $hasAttendanceOverviewKpis = false;
            foreach ($widgets as $w) {
                $code = $w['code'] ?? '';
                if ($code === 'company_executive_kpis' || $code === 'executive_kpis') {
                    $hasExecutiveKpis = true;
                }
                if ($code === 'attendance_late_arrivals') {
                    $hasLateArrivalsWidget = true;
                }
                if ($code === 'attendance_overview_kpis') {
                    $hasAttendanceOverviewKpis = true;
                }
            }

            if (empty($widgets)) {
                ?>
                <div class="col-span-12 p-10 text-center bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-xs">
                    <i data-lucide="inbox" class="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto mb-2"></i>
                    <h4 class="text-sm font-bold text-slate-700 dark:text-slate-300">No active widgets in this category</h4>
                    <p class="text-xs text-slate-400 mt-1 max-w-sm mx-auto">There are no enabled widgets matching your current role and organizational scope for this category.</p>
                </div>
                <?php
                return;
            }

            foreach ($widgets as $widget) {
                $wId   = $widget['id'] ?? '';
                $wCode = $widget['code'] ?? '';
                $gridClass = $widgetClasses[$wId] ?? $widgetClasses[$wCode] ?? ($widget['layout_class'] ?? 'col-span-12 md:col-span-6');
                ?>
                <div id="widget-card-<?= esc($wCode ?: $wId) ?>" class="<?= esc($gridClass) ?> flex">
                    <div class="h-full w-full">
                    <?php 
                        try {
                            $targetViewPath = \App\Services\DashboardService::normalizeWidgetViewPath($widget['view_path'] ?? '');
                            echo view($targetViewPath, [
                                'widget'                    => $widget,
                                'configuration'             => $widget_configurations[$wId] ?? $widget_configurations[$wCode] ?? [],
                                'data'                      => $widget_data,
                                'metrics'                   => $metrics ?? ['data' => $widget_data, 'workforce' => $widget_data],
                                'role'                      => $currentRole,
                                'scope'                     => $scope,
                                'company'                   => $company ?? null,
                                'companyId'                 => $companyId ?? ($scope['company_id'] ?? ($company['id'] ?? null)),
                                'user'                      => $user ?? [],
                                'hasExecutiveKpis'          => $hasExecutiveKpis,
                                'hasLateArrivalsWidget'     => $hasLateArrivalsWidget,
                                'hasAttendanceOverviewKpis' => $hasAttendanceOverviewKpis,
                            ]);
                        } catch (\Throwable $e) {
                            log_message('error', 'Dashboard widget render exception [' . ($widget['code'] ?? '') . ']: ' . $e->getMessage());
                            ?>
                            <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 text-xs flex items-center gap-3 shadow-2xs h-full w-full">
                                <div class="w-8 h-8 rounded-lg bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 flex items-center justify-center text-amber-600 shrink-0">
                                    <i data-lucide="alert-circle" class="w-4 h-4"></i>
                                </div>
                                <div class="min-w-0 flex-1">
                                    <div class="font-bold text-slate-800 dark:text-slate-100 truncate"><?= esc($widget['title'] ?? 'Widget') ?></div>
                                    <div class="text-[11px] text-slate-400 mt-0.5">Widget data is temporarily unavailable. Please refresh or contact support.</div>
                                </div>
                            </div>
                            <?php
                        }
                    ?>
                    </div>
                </div>
                <?php
            }
        };
    ?>

    <!-- CATEGORY PANEL 1: OVERVIEW (Default, Pre-rendered server-side) -->
    <div id="category-panel-overview" class="dashboard-cat-panel <?= ($active_category === 'overview') ? '' : 'hidden' ?>" role="tabpanel" aria-labelledby="tab-btn-overview">
        <div id="category-grid-overview" class="<?= esc($layout['container_class'] ?? 'grid grid-cols-12 gap-6 w-full') ?>">
            <?php 
                if ($active_category === 'overview') {
                    $renderCategoryWidgetList($category_widgets['overview'] ?? []);
                }
            ?>
        </div>
    </div>

    <!-- CATEGORY PANEL 2: ATTENDANCE & SHIFTS (Asynchronously Lazy-Loaded) -->
    <div id="category-panel-attendance" class="dashboard-cat-panel <?= ($active_category === 'attendance') ? '' : 'hidden' ?>" role="tabpanel" aria-labelledby="tab-btn-attendance">
        <div id="category-grid-attendance" class="<?= esc($layout['container_class'] ?? 'grid grid-cols-12 gap-6 w-full') ?>">
            <?php 
                if ($active_category === 'attendance') {
                    $renderCategoryWidgetList($category_widgets['attendance'] ?? []);
                } else {
                    ?>
                    <div class="col-span-12 py-12 flex flex-col items-center justify-center text-center">
                        <div class="w-8 h-8 border-3 border-indigo-600/30 border-t-indigo-600 rounded-full animate-spin mb-3"></div>
                        <p class="text-xs font-semibold text-slate-600 dark:text-slate-300">Loading Attendance & Shifts widgets...</p>
                        <p class="text-[11px] text-slate-400 mt-0.5">Fetching live shift rosters and attendance logs</p>
                    </div>
                    <?php
                }
            ?>
        </div>
    </div>

    <!-- CATEGORY PANEL 3: LEAVES & ROSTER (Asynchronously Lazy-Loaded) -->
    <div id="category-panel-leaves" class="dashboard-cat-panel <?= ($active_category === 'leaves') ? '' : 'hidden' ?>" role="tabpanel" aria-labelledby="tab-btn-leaves">
        <div id="category-grid-leaves" class="<?= esc($layout['container_class'] ?? 'grid grid-cols-12 gap-6 w-full') ?>">
            <?php 
                if ($active_category === 'leaves') {
                    $renderCategoryWidgetList($category_widgets['leaves'] ?? []);
                } else {
                    ?>
                    <div class="col-span-12 py-12 flex flex-col items-center justify-center text-center">
                        <div class="w-8 h-8 border-3 border-indigo-600/30 border-t-indigo-600 rounded-full animate-spin mb-3"></div>
                        <p class="text-xs font-semibold text-slate-600 dark:text-slate-300">Loading Leaves & Roster widgets...</p>
                        <p class="text-[11px] text-slate-400 mt-0.5">Fetching leave entitlements and department calendar</p>
                    </div>
                    <?php
                }
            ?>
        </div>
    </div>

    <!-- CATEGORY PANEL 4: PAYROLL & COMPLIANCE (Asynchronously Lazy-Loaded) -->
    <div id="category-panel-payroll" class="dashboard-cat-panel <?= ($active_category === 'payroll') ? '' : 'hidden' ?>" role="tabpanel" aria-labelledby="tab-btn-payroll">
        <div id="category-grid-payroll" class="<?= esc($layout['container_class'] ?? 'grid grid-cols-12 gap-6 w-full') ?>">
            <?php 
                if ($active_category === 'payroll') {
                    $renderCategoryWidgetList($category_widgets['payroll'] ?? []);
                } else {
                    ?>
                    <div class="col-span-12 py-12 flex flex-col items-center justify-center text-center">
                        <div class="w-8 h-8 border-3 border-indigo-600/30 border-t-indigo-600 rounded-full animate-spin mb-3"></div>
                        <p class="text-xs font-semibold text-slate-600 dark:text-slate-300">Loading Payroll & Compliance widgets...</p>
                        <p class="text-[11px] text-slate-400 mt-0.5">Fetching payroll cost breakdown and compliance records</p>
                    </div>
                    <?php
                }
            ?>
        </div>
    </div>

    <?php if (empty($authorized_widgets)): ?>
        <div class="p-12 text-center bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl">
            <i data-lucide="layout-grid" class="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto mb-3"></i>
            <h3 class="text-base font-bold text-slate-800 dark:text-slate-200">No Active Widgets Authorized for Current Scope</h3>
            <p class="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                Your account has access to this workspace, but no widgets match the active role, scope filters, or enabled modules.
            </p>
            <div class="mt-4">
                <button type="button" onclick="openCustomizationModal()" class="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-500 transition">
                    <i data-lucide="sliders" class="w-4 h-4"></i> Customize My Dashboard
                </button>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- =========================================================================
     PHASE 18 — USER CUSTOMIZATION MODAL & DRAWER
     Supports: show/hide, reorder, resize, reset, save preferences.
     INVARIANT: "Users cannot enable unauthorized widgets."
     ========================================================================= -->
<div id="customizationModal" class="fixed inset-0 z-50 hidden overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
    <!-- Backdrop -->
    <div class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity" onclick="closeCustomizationModal()"></div>

    <div class="flex min-h-screen items-center justify-center p-4 text-center sm:p-0">
        <div class="relative transform overflow-hidden rounded-2xl bg-white dark:bg-slate-900 text-left shadow-2xl transition-all sm:my-8 sm:w-full sm:max-w-3xl border border-slate-200 dark:border-slate-800">
            <!-- Modal Header -->
            <div class="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50">
                <div class="flex items-center gap-3">
                    <div class="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400">
                        <i data-lucide="sliders" class="w-5 h-5"></i>
                    </div>
                    <div>
                        <h3 class="text-base font-bold text-slate-800 dark:text-slate-100" id="modal-title">Customize Dashboard Layout</h3>
                        <p class="text-xs text-slate-500 dark:text-slate-400">Personalize tab-by-tab widget display, width, and order</p>
                    </div>
                </div>
                <button type="button" onclick="closeCustomizationModal()" class="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>

            <!-- Notice Banner & Target User Switcher -->
            <?php if (in_array($currentRole, ['software_app_admin', 'company_admin', 'hr_admin'], true) && !empty($companyUsers)): ?>
                <div class="px-6 py-2.5 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200/80 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                    <label for="customizationTargetUser" class="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 shrink-0">
                        <i data-lucide="user-cog" class="w-4 h-4 text-indigo-500"></i>
                        <span>Target Account:</span>
                    </label>
                    <select id="customizationTargetUser" onchange="onCustomizationUserChange(this.value)" class="text-xs font-semibold py-1.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 w-full sm:w-auto">
                        <option value="">Myself (<?= esc($user['name'] ?? 'My Dashboard') ?> - <?= esc(ucwords(str_replace('_', ' ', $currentRole))) ?>)</option>
                        <optgroup label="Manage Company Staff & Roles">
                            <?php foreach ($companyUsers as $cu): ?>
                                <?php if (($cu['id'] ?? '') !== ($user_id ?? '')): ?>
                                    <option value="<?= esc($cu['id']) ?>" data-role="<?= esc($cu['role_name'] ?: $cu['role_code'] ?: 'Staff') ?>" data-name="<?= esc($cu['name'] ?: $cu['username']) ?>">
                                        <?= esc($cu['name'] ?: $cu['username']) ?> (<?= esc($cu['role_name'] ?: $cu['role_code'] ?: 'Staff') ?><?= !empty($cu['employee_code']) ? ' - ' . esc($cu['employee_code']) : '' ?>)
                                    </option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </optgroup>
                    </select>
                </div>
            <?php endif; ?>

            <div class="px-6 py-2.5 bg-indigo-50/70 dark:bg-indigo-950/30 border-b border-indigo-200/50 dark:border-indigo-800/40 flex items-center justify-between text-xs text-indigo-800 dark:text-indigo-300">
                <div class="flex items-center gap-2">
                    <i data-lucide="check-shield" class="w-4 h-4 shrink-0 text-indigo-600"></i>
                    <span id="customizationModalBannerText">Authorized Widgets for <?= esc(ucwords(str_replace('_', ' ', $currentRole))) ?>: Customize widget display, layout width, and order.</span>
                </div>
            </div>

            <!-- Modal Category Tabs Bar (Tabs-Wise Configuration Deck) -->
            <div class="px-6 py-2 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200/80 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <!-- Tab Buttons (All, Overview, Attendance, Leaves, Payroll) -->
                <div class="flex items-center gap-1 p-0.5 bg-slate-200/70 dark:bg-slate-900/60 rounded-xl overflow-x-auto no-scrollbar" id="modalCategoryTabs" role="tablist" aria-label="Widget Categories">
                    <button type="button" onclick="switchCustomizationModalTab('all')" data-modal-tab="all" class="modal-cat-tab flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold transition bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-2xs border border-slate-200/80 dark:border-slate-700">
                        <span>All</span>
                        <span class="inline-flex items-center justify-center px-1.5 py-0.2 text-[10px] font-bold rounded-full bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-300" id="modal-cat-count-all">0</span>
                    </button>
                    <button type="button" onclick="switchCustomizationModalTab('overview')" data-modal-tab="overview" class="modal-cat-tab flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 border border-transparent transition">
                        <i data-lucide="layout-dashboard" class="w-3.5 h-3.5"></i>
                        <span>Overview</span>
                        <span class="inline-flex items-center justify-center px-1.5 py-0.2 text-[10px] font-bold rounded-full bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300" id="modal-cat-count-overview">0</span>
                    </button>
                    <button type="button" onclick="switchCustomizationModalTab('attendance')" data-modal-tab="attendance" class="modal-cat-tab flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 border border-transparent transition">
                        <i data-lucide="clock" class="w-3.5 h-3.5"></i>
                        <span>Attendance</span>
                        <span class="inline-flex items-center justify-center px-1.5 py-0.2 text-[10px] font-bold rounded-full bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300" id="modal-cat-count-attendance">0</span>
                    </button>
                    <button type="button" onclick="switchCustomizationModalTab('leaves')" data-modal-tab="leaves" class="modal-cat-tab flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 border border-transparent transition">
                        <i data-lucide="calendar-days" class="w-3.5 h-3.5"></i>
                        <span>Leaves</span>
                        <span class="inline-flex items-center justify-center px-1.5 py-0.2 text-[10px] font-bold rounded-full bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300" id="modal-cat-count-leaves">0</span>
                    </button>
                    <button type="button" onclick="switchCustomizationModalTab('payroll')" data-modal-tab="payroll" class="modal-cat-tab flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 border border-transparent transition">
                        <i data-lucide="receipt" class="w-3.5 h-3.5"></i>
                        <span>Payroll</span>
                        <span class="inline-flex items-center justify-center px-1.5 py-0.2 text-[10px] font-bold rounded-full bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300" id="modal-cat-count-payroll">0</span>
                    </button>
                </div>

                <!-- Live Search Box inside Modal -->
                <div class="relative w-full sm:w-48 shrink-0">
                    <i data-lucide="search" class="w-3 h-3 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                    <input type="text"
                           id="customizationModalSearch"
                           oninput="filterCustomizationWidgets()"
                           placeholder="Filter in tab..."
                           class="w-full pl-7 pr-2.5 py-1 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 focus:outline-hidden focus:ring-1 focus:ring-indigo-500">
                </div>
            </div>

            <!-- Modal Body / Widget Items List (Lazy Loaded via AJAX) -->
            <div class="p-6 max-h-[55vh] overflow-y-auto space-y-2.5" id="widgetPreferenceList">
                <div class="py-12 text-center text-slate-400 text-xs">
                    <span class="inline-block animate-spin mr-1.5 text-indigo-600">⟳</span>
                    Loading customizable widgets...
                </div>
            </div>

            <!-- Modal Footer -->
            <div class="flex items-center justify-between px-6 py-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50">
                <button type="button" onclick="resetUserPreferences()" id="btn-reset-preferences" class="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition">
                    <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i>
                    <span>Reset to Defaults</span>
                </button>
                <div class="flex items-center gap-2">
                    <button type="button" onclick="closeCustomizationModal()" class="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition">
                        Cancel
                    </button>
                    <button type="button" onclick="saveUserPreferences()" id="btn-save-preferences" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition shadow-xs shadow-indigo-600/30">
                        <i data-lucide="check" class="w-4 h-4"></i>
                        <span>Save & Apply</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Customization JavaScript Engine (Phase 18) -->
<script>
let customizableWidgetsLoaded = false;
let currentCustomizationTargetId = '';

function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

async function openCustomizationModal() {
    const modal = document.getElementById('customizationModal');
    if (modal) {
        modal.classList.remove('hidden');
        if (window.lucide) { lucide.createIcons(); }
    }
    const userSelector = document.getElementById('customizationTargetUser');
    currentCustomizationTargetId = userSelector ? (userSelector.value || '') : '';
    await loadCustomizableWidgets(true, currentCustomizationTargetId);
}

function onCustomizationUserChange(userId) {
    currentCustomizationTargetId = userId || '';
    const bannerText = document.getElementById('customizationModalBannerText');
    const selector = document.getElementById('customizationTargetUser');

    if (bannerText) {
        if (!userId) {
            bannerText.textContent = 'Authorized Widgets for <?= esc(ucwords(str_replace('_', ' ', $currentRole))) ?>: Customize widget display, layout width, and order.';
        } else {
            const selectedOpt = selector ? selector.options[selector.selectedIndex] : null;
            const targetName = selectedOpt ? selectedOpt.getAttribute('data-name') : 'Selected User';
            const targetRole = selectedOpt ? selectedOpt.getAttribute('data-role') : 'Staff';
            bannerText.textContent = 'Configuring Personalized Dashboard for ' + targetName + ' (' + targetRole + ').';
        }
    }

    loadCustomizableWidgets(true, currentCustomizationTargetId);
}

async function loadCustomizableWidgets(forceReload = false, targetUserId = null) {
    const listEl = document.getElementById('widgetPreferenceList');
    if (!listEl) return;

    if (customizableWidgetsLoaded && !forceReload && !targetUserId) {
        return;
    }

    listEl.innerHTML = `
        <div class="py-12 text-center text-slate-400 text-xs">
            <span class="inline-block animate-spin mr-1.5 text-indigo-600">⟳</span>
            Loading customizable widgets...
        </div>
    `;

    try {
        const params = new URLSearchParams(window.location.search);
        if (targetUserId) {
            params.set('target_user_id', targetUserId);
        } else {
            params.delete('target_user_id');
        }
        const query = params.toString() ? '?' + params.toString() : '';
        const res = await fetch('<?= base_url('api/dashboard/customizable-widgets') ?>' + query, {
            method: 'GET',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        });

        const data = await res.json();
        const widgetArray = Array.isArray(data.data) ? data.data : ((data.data && Array.isArray(data.data.widgets)) ? data.data.widgets : (data.widgets || []));
        // Check success per Global Rule 8
        if (res.ok && (data.success || data.status === 'success') && Array.isArray(widgetArray)) {
            customizableWidgetsLoaded = true;
            renderCustomizableWidgets(widgetArray);
        } else {
            listEl.innerHTML = `
                <div class="py-12 text-center text-rose-500 text-xs">
                    <i data-lucide="alert-circle" class="w-8 h-8 mx-auto mb-2 opacity-75"></i>
                    ${escapeHtml(data.message || 'Failed to load customizable widgets.')}
                </div>
            `;
            if (window.lucide) { lucide.createIcons(); }
        }
    } catch (e) {
        listEl.innerHTML = `
            <div class="py-12 text-center text-rose-500 text-xs">
                <i data-lucide="alert-circle" class="w-8 h-8 mx-auto mb-2 opacity-75"></i>
                Network error loading customizable widgets. Please try again.
            </div>
        `;
        if (window.lucide) { lucide.createIcons(); }
    }
}

const categoryGroupTitles = {
    'all': 'All Widgets',
    'overview': 'Overview',
    'attendance': 'Attendance & Shifts',
    'leaves': 'Leaves & Roster',
    'payroll': 'Payroll & Compliance'
};

let currentModalCategoryTab = 'all';

function resolveWidgetCategoryGroup(widget) {
    if (widget.category_group) {
        return widget.category_group;
    }
    const idOrCode = (widget.code || widget.id || '').toLowerCase();
    if (idOrCode.includes('department_breakdown') || idOrCode === 'wdg-att-17' || idOrCode.includes('dept_breakdown')) {
        return 'overview';
    }
    if (idOrCode.includes('att') || idOrCode.includes('clock') || idOrCode.includes('shift') || idOrCode.includes('roster')) {
        return 'attendance';
    }
    if (idOrCode.includes('leave') || idOrCode.includes('cal') || idOrCode.includes('holiday')) {
        return 'leaves';
    }
    if (idOrCode.includes('pay') || idOrCode.includes('compliance') || idOrCode.includes('tax') || idOrCode.includes('audit') || idOrCode.includes('health')) {
        return 'payroll';
    }
    return 'overview';
}

function switchCustomizationModalTab(tabKey) {
    currentModalCategoryTab = tabKey || 'all';

    // Update tab button visual state
    document.querySelectorAll('.modal-cat-tab').forEach(btn => {
        const tab = btn.getAttribute('data-modal-tab');
        const isTarget = (tab === currentModalCategoryTab);
        if (isTarget) {
            btn.className = 'modal-cat-tab flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold transition bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-2xs border border-slate-200/80 dark:border-slate-700';
            const badge = btn.querySelector('span:last-child');
            if (badge) {
                badge.className = 'inline-flex items-center justify-center px-1.5 py-0.2 text-[10px] font-bold rounded-full bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-300';
            }
        } else {
            btn.className = 'modal-cat-tab flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 border border-transparent transition';
            const badge = btn.querySelector('span:last-child');
            if (badge) {
                badge.className = 'inline-flex items-center justify-center px-1.5 py-0.2 text-[10px] font-bold rounded-full bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300';
            }
        }
    });

    filterCustomizationWidgets();
}

function filterCustomizationWidgets() {
    const searchInput = document.getElementById('customizationModalSearch');
    const q = searchInput ? searchInput.value.toLowerCase().trim() : '';
    const items = document.querySelectorAll('#widgetPreferenceList .widget-pref-item');
    let visibleCount = 0;

    items.forEach(row => {
        const rowCat = row.getAttribute('data-category-group') || 'overview';
        const matchesCategory = (currentModalCategoryTab === 'all' || rowCat === currentModalCategoryTab);
        const searchText = (row.getAttribute('data-search-text') || '').toLowerCase();
        const matchesSearch = !q || searchText.includes(q);

        if (matchesCategory && matchesSearch) {
            row.classList.remove('hidden');
            visibleCount++;
        } else {
            row.classList.add('hidden');
        }
    });

    const emptyMsg = document.getElementById('customizationEmptyMessage');
    if (emptyMsg) {
        if (visibleCount === 0) {
            emptyMsg.classList.remove('hidden');
            const label = categoryGroupTitles[currentModalCategoryTab] || 'selected category';
            const labelEl = document.getElementById('customizationEmptyLabel');
            if (labelEl) {
                labelEl.textContent = q ? `No widgets found matching "${q}" in ${label}.` : `No authorized widgets in ${label}.`;
            }
        } else {
            emptyMsg.classList.add('hidden');
        }
    }
}

function renderCustomizableWidgets(widgets) {
    const listEl = document.getElementById('widgetPreferenceList');
    if (!listEl) return;

    // Filter to only authorized widgets
    const authorized = widgets.filter(w => !w.hasOwnProperty('is_authorized') || w.is_authorized);

    // Compute category counts
    const counts = { all: authorized.length, overview: 0, attendance: 0, leaves: 0, payroll: 0 };
    authorized.forEach(w => {
        const catGroup = resolveWidgetCategoryGroup(w);
        if (counts[catGroup] !== undefined) {
            counts[catGroup]++;
        } else {
            counts.overview++;
        }
    });

    // Update tab count badges in UI
    for (const [key, cnt] of Object.entries(counts)) {
        const countBadge = document.getElementById('modal-cat-count-' + key);
        if (countBadge) {
            countBadge.textContent = cnt;
        }
    }

    if (authorized.length === 0) {
        listEl.innerHTML = `
            <div class="py-12 text-center text-slate-400 text-xs">
                <i data-lucide="shield-check" class="w-8 h-8 mx-auto mb-2 opacity-50"></i>
                No customizable widgets authorized for this role or user.
            </div>
        `;
        if (window.lucide) { lucide.createIcons(); }
        return;
    }

    let html = '';
    authorized.forEach(cw => {
        const status = Number(cw.status) === 1 ? 1 : 0;
        const gridW = cw.grid_width || 'half';
        const wId = cw.id || '';
        const wCode = cw.code || '';
        const title = escapeHtml(cw.title || wCode || 'Widget');
        const desc = escapeHtml(cw.description || 'Dashboard analytic widget');
        const catGroup = resolveWidgetCategoryGroup(cw);
        const groupTitle = escapeHtml(categoryGroupTitles[catGroup] || catGroup);
        const icon = escapeHtml(cw.icon || 'layout-grid');
        const searchText = `${title} ${desc} ${wCode} ${groupTitle}`.toLowerCase();

        // Color coding for category group pill
        let badgeColors = 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700';
        if (catGroup === 'attendance') {
            badgeColors = 'bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 border-sky-200 dark:border-sky-800';
        } else if (catGroup === 'leaves') {
            badgeColors = 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800';
        } else if (catGroup === 'payroll') {
            badgeColors = 'bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border-purple-200 dark:border-purple-800';
        } else if (catGroup === 'overview') {
            badgeColors = 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800';
        }

        html += `
            <div class="widget-pref-item flex flex-col sm:flex-row sm:items-center justify-between p-3 rounded-xl border transition-all bg-white dark:bg-slate-900/90 border-slate-200/80 dark:border-slate-800 hover:border-indigo-300 shadow-2xs"
                 data-widget-id="${escapeHtml(wId)}"
                 data-widget-code="${escapeHtml(wCode)}"
                 data-category-group="${escapeHtml(catGroup)}"
                 data-search-text="${escapeHtml(searchText)}"
                 data-authorized="1"
                 id="pref-row-${escapeHtml(wCode || wId)}">
                
                <!-- Left: Icon & Info -->
                <div class="flex items-start sm:items-center gap-3 mb-2 sm:mb-0 min-w-0">
                    <div class="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 shrink-0">
                        <i data-lucide="${icon}" class="w-4 h-4"></i>
                    </div>
                    <div class="min-w-0">
                        <div class="flex items-center gap-2 flex-wrap">
                            <span class="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-200 truncate">${title}</span>
                            <span class="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider border ${badgeColors}">
                                ${groupTitle}
                            </span>
                        </div>
                        <p class="text-xs text-slate-400 mt-0.5 line-clamp-1">
                            ${desc}
                        </p>
                    </div>
                </div>

                <!-- Right: Controls (Show/Hide, Width, Reorder) -->
                <div class="flex items-center gap-2 self-end sm:self-center shrink-0">
                    <!-- Width Selector (Half vs Full) -->
                    <select class="widget-width-select text-xs font-medium py-1 px-2 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 cursor-pointer">
                        <option value="half" ${gridW === 'half' ? 'selected' : ''}>1/2 Width</option>
                        <option value="full" ${gridW === 'full' ? 'selected' : ''}>Full Width</option>
                    </select>

                    <!-- Reorder Up/Down Buttons -->
                    <div class="flex items-center border border-slate-200 dark:border-slate-700 rounded-lg overflow-hidden bg-slate-100 dark:bg-slate-800">
                        <button type="button" onclick="moveWidgetRow(this, -1)" title="Move Up" class="p-1 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition cursor-pointer">
                            <i data-lucide="chevron-up" class="w-3.5 h-3.5"></i>
                        </button>
                        <button type="button" onclick="moveWidgetRow(this, 1)" title="Move Down" class="p-1 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition cursor-pointer">
                            <i data-lucide="chevron-down" class="w-3.5 h-3.5"></i>
                        </button>
                    </div>

                    <!-- Show/Hide Switch -->
                    <label class="relative inline-flex items-center cursor-pointer" title="Toggle visibility on dashboard">
                        <input type="checkbox" class="sr-only peer widget-status-toggle" ${status === 1 ? 'checked' : ''}>
                        <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
                    </label>
                </div>
            </div>
        `;
    });

    html += `
        <div id="customizationEmptyMessage" class="hidden py-12 text-center text-slate-400 text-xs">
            <i data-lucide="filter" class="w-8 h-8 mx-auto mb-2 opacity-40"></i>
            <p id="customizationEmptyLabel">No widgets found in this category.</p>
        </div>
    `;

    listEl.innerHTML = html;
    if (window.lucide) { lucide.createIcons(); }

    // When modal opens, auto-switch to active dashboard category if valid
    const targetTab = (activeDashboardCategory && ['overview', 'attendance', 'leaves', 'payroll'].includes(activeDashboardCategory))
        ? activeDashboardCategory
        : 'all';
    switchCustomizationModalTab(targetTab);
}

function closeCustomizationModal() {
    const modal = document.getElementById('customizationModal');
    if (modal) {
        modal.classList.add('hidden');
    }
}

function moveWidgetRow(btn, direction) {
    const row = btn.closest('.widget-pref-item');
    if (!row) return;

    const list = Array.from(document.querySelectorAll('#widgetPreferenceList .widget-pref-item'));
    const visibleItems = list.filter(item => !item.classList.contains('hidden'));
    const currentIndex = visibleItems.indexOf(row);
    if (currentIndex === -1) return;

    if (direction === -1 && currentIndex > 0) {
        const prev = visibleItems[currentIndex - 1];
        row.parentNode.insertBefore(row, prev);
    } else if (direction === 1 && currentIndex < visibleItems.length - 1) {
        const next = visibleItems[currentIndex + 1];
        row.parentNode.insertBefore(next, row);
    }
}

async function saveUserPreferences() {
    const saveBtn = document.getElementById('btn-save-preferences');
    if (saveBtn) {
        saveBtn.disabled = true;
        saveBtn.innerHTML = '<span class="inline-block animate-spin mr-1.5">⟳</span> Saving...';
    }

    const items = document.querySelectorAll('#widgetPreferenceList .widget-pref-item');
    const preferences = [];

    items.forEach((item, index) => {
        const widgetId = item.getAttribute('data-widget-id');
        const isAuth = item.getAttribute('data-authorized') === '1';
        const toggle = item.querySelector('.widget-status-toggle');
        const widthSelect = item.querySelector('.widget-width-select');

        // Only process authorized widgets; unauthorized widgets cannot be enabled
        const status = (isAuth && toggle && toggle.checked) ? 1 : 0;
        const gridWidth = (widthSelect) ? widthSelect.value : 'half';

        preferences.push({
            widget_id: widgetId,
            status: status,
            grid_width: gridWidth,
            sort_order: index + 1
        });
    });

    try {
        const formData = new FormData();
        formData.append('preferences', JSON.stringify(preferences));
        if (currentCustomizationTargetId) {
            formData.append('target_user_id', currentCustomizationTargetId);
        }
        formData.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');

        const res = await fetch('<?= base_url('api/dashboard/preferences/save') ?>', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
            }
        });

        const data = await res.json();
        // Check success per Global Rule 8
        if (res.ok && (data.success || data.status === 'success')) {
            closeCustomizationModal();
            window.location.reload();
        } else {
            alert(data.message || 'Failed to save dashboard preferences.');
        }
    } catch (e) {
        alert('An unexpected network error occurred while saving preferences.');
    } finally {
        if (saveBtn) {
            saveBtn.disabled = false;
            saveBtn.innerHTML = '<i data-lucide="check" class="w-4 h-4"></i><span>Save & Apply</span>';
            if (window.lucide) { lucide.createIcons(); }
        }
    }
}

async function resetUserPreferences() {
    const isTargetUser = !!currentCustomizationTargetId;
    const confirmMsg = isTargetUser
        ? 'Are you sure you want to reset this user\'s customized widgets and layout back to their role defaults?'
        : 'Are you sure you want to reset your customized widgets and layout back to your role defaults?';

    if (!confirm(confirmMsg)) {
        return;
    }

    const resetBtn = document.getElementById('btn-reset-preferences');
    if (resetBtn) {
        resetBtn.disabled = true;
        resetBtn.innerHTML = '<span class="inline-block animate-spin mr-1">⟳</span> Resetting...';
    }

    try {
        const formData = new FormData();
        if (currentCustomizationTargetId) {
            formData.append('target_user_id', currentCustomizationTargetId);
        }
        formData.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');

        const res = await fetch('<?= base_url('api/dashboard/preferences/reset') ?>', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
            }
        });

        const data = await res.json();
        // Check success per Global Rule 8
        if (res.ok && (data.success || data.status === 'success')) {
            closeCustomizationModal();
            window.location.reload();
        } else {
            alert(data.message || 'Failed to reset preferences.');
        }
    } catch (e) {
        alert('An unexpected error occurred while resetting preferences.');
    } finally {
        if (resetBtn) {
            resetBtn.disabled = false;
            resetBtn.innerHTML = '<i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i><span>Reset to Defaults</span>';
            if (window.lucide) { lucide.createIcons(); }
        }
    }
}

function applyDashboardScopeFilters() {
    const branchEl = document.getElementById('dashboard-scope-branch');
    const deptEl = document.getElementById('dashboard-scope-dept');
    const params = new URLSearchParams(window.location.search);

    if (branchEl && branchEl.value) {
        params.set('branch_id', branchEl.value);
    } else {
        params.delete('branch_id');
    }

    if (deptEl && deptEl.value) {
        params.set('department_id', deptEl.value);
    } else {
        params.delete('department_id');
    }

    if (activeDashboardCategory && activeDashboardCategory !== 'overview') {
        params.set('category', activeDashboardCategory);
    } else {
        params.delete('category');
    }

    const query = params.toString();
    window.location.href = '<?= base_url('dashboard') ?>' + (query ? '?' + query : '');
}

// =========================================================================
// PHASES 2 & 3: CATEGORY NAVIGATION & ASYNCHRONOUS LAZY LOADING ENGINE
// =========================================================================
const categoryDescriptions = <?= json_encode(array_map(fn($g) => $g['description'] ?? '', $category_groups)) ?>;
let activeDashboardCategory = '<?= esc($active_category) ?>';
const loadedCategories = {
    '<?= esc($active_category) ?>': true
};
const loadingCategories = {};

/**
 * Switch Dashboard Category Tab
 * - Toggles active tab styling and ARIA attributes
 * - Swaps category panels with zero UI flash
 * - Lazily fetches remote widget payload on demand (first access only)
 * - Cached locally in loadedCategories to avoid duplicate API requests
 */
function switchDashboardCategory(category) {
    if (!category || category === activeDashboardCategory) {
        return;
    }

    // 1. Update Tab button styles & accessibility
    document.querySelectorAll('.dashboard-cat-tab').forEach(btn => {
        const cat = btn.getAttribute('data-category');
        const isTarget = (cat === category);
        btn.setAttribute('aria-selected', isTarget ? 'true' : 'false');
        if (isTarget) {
            btn.className = 'dashboard-cat-tab group relative flex items-center gap-1 px-2 py-0.5 h-6 rounded text-[11px] font-medium whitespace-nowrap transition-all duration-150 leading-none bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-2xs border border-slate-200/80 dark:border-slate-700 font-bold';
            const icon = btn.querySelector('i');
            if (icon) {
                icon.className = 'w-3 h-3 text-indigo-600 dark:text-indigo-400';
            }
            const badge = btn.querySelector('span:last-child');
            if (badge) {
                badge.className = 'inline-flex items-center justify-center px-1 py-0 text-[9px] font-bold rounded-full bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-300 border border-indigo-200/50 dark:border-indigo-800/50';
            }
        } else {
            btn.className = 'dashboard-cat-tab group relative flex items-center gap-1 px-2 py-0.5 h-6 rounded text-[11px] font-medium whitespace-nowrap transition-all duration-150 leading-none text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 border border-transparent';
            const icon = btn.querySelector('i');
            if (icon) {
                icon.className = 'w-3 h-3 text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-300';
            }
            const badge = btn.querySelector('span:last-child');
            if (badge) {
                badge.className = 'inline-flex items-center justify-center px-1 py-0 text-[9px] font-bold rounded-full bg-slate-200/80 dark:bg-slate-700 text-slate-600 dark:text-slate-300';
            }
        }
    });

    // 2. Update category description tooltip text
    const descEl = document.getElementById('category-description-text');
    if (descEl && categoryDescriptions[category]) {
        descEl.textContent = categoryDescriptions[category];
    }

    // 3. Switch visible panels
    document.querySelectorAll('.dashboard-cat-panel').forEach(panel => {
        panel.classList.add('hidden');
    });
    const targetPanel = document.getElementById('category-panel-' + category);
    if (targetPanel) {
        targetPanel.classList.remove('hidden');
    }

    activeDashboardCategory = category;

    // 4. Update browser URL history state silently without reloading page
    try {
        const url = new URL(window.location.href);
        if (category === 'overview') {
            url.searchParams.delete('category');
            url.searchParams.delete('tab');
        } else {
            url.searchParams.set('category', category);
        }
        window.history.replaceState({ category }, '', url.toString());
    } catch (e) {
        // Fallback for older browsers
    }

    // 5. Asynchronously fetch category widgets if not already loaded
    if (!loadedCategories[category]) {
        loadCategoryWidgetsAsync(category);
    }
}

/**
 * Fetch and Render Category Widgets via AJAX
 * - Skeleton placeholder during fetch
 * - Duplicate request prevention (loadingCategories lock)
 * - Strict error recovery with Retry button
 * - Re-initializes Lucide icons upon DOM insertion
 */
async function loadCategoryWidgetsAsync(category, forceRetry = false) {
    if (loadingCategories[category] && !forceRetry) {
        return; // Prevent duplicate concurrent requests
    }

    loadingCategories[category] = true;
    const gridEl = document.getElementById('category-grid-' + category);
    if (!gridEl) {
        loadingCategories[category] = false;
        return;
    }

    // Render skeleton placeholders while fetching
    gridEl.innerHTML = `
        <div class="col-span-12 md:col-span-6 p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 animate-pulse space-y-4">
            <div class="flex items-center justify-between">
                <div class="h-4 bg-slate-200 dark:bg-slate-800 rounded w-1/3"></div>
                <div class="w-8 h-8 bg-slate-200 dark:bg-slate-800 rounded-lg"></div>
            </div>
            <div class="space-y-2">
                <div class="h-8 bg-slate-200 dark:bg-slate-800 rounded w-1/2"></div>
                <div class="h-3 bg-slate-200 dark:bg-slate-800 rounded w-3/4"></div>
            </div>
        </div>
        <div class="col-span-12 md:col-span-6 p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 animate-pulse space-y-4">
            <div class="flex items-center justify-between">
                <div class="h-4 bg-slate-200 dark:bg-slate-800 rounded w-1/3"></div>
                <div class="w-8 h-8 bg-slate-200 dark:bg-slate-800 rounded-lg"></div>
            </div>
            <div class="space-y-2">
                <div class="h-8 bg-slate-200 dark:bg-slate-800 rounded w-1/2"></div>
                <div class="h-3 bg-slate-200 dark:bg-slate-800 rounded w-3/4"></div>
            </div>
        </div>
    `;

    try {
        const branchEl = document.getElementById('dashboard-scope-branch');
        const deptEl = document.getElementById('dashboard-scope-dept');
        const params = new URLSearchParams();
        params.set('category', category);
        if (branchEl && branchEl.value) params.set('branch_id', branchEl.value);
        if (deptEl && deptEl.value) params.set('department_id', deptEl.value);

        const url = '<?= base_url('api/dashboard/category-widgets') ?>?' + params.toString();
        const res = await fetch(url, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        });

        const json = await res.json();
        // Check success per Global Rule 8
        if (res.ok && json.success) {
            gridEl.innerHTML = json.data.html;
            loadedCategories[category] = true;
            if (window.lucide) {
                lucide.createIcons();
            }
        } else {
            throw new Error(json.message || 'Failed to load category widgets.');
        }
    } catch (err) {
        gridEl.innerHTML = `
            <div class="col-span-12 p-8 text-center bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-900/50 rounded-2xl shadow-xs">
                <div class="w-10 h-10 rounded-full bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 flex items-center justify-center text-rose-500 mx-auto mb-3">
                    <i data-lucide="alert-triangle" class="w-5 h-5"></i>
                </div>
                <h4 class="text-sm font-bold text-slate-800 dark:text-slate-100">Unable to load category widgets</h4>
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto">${err.message || 'Network error occurred while fetching category widgets.'}</p>
                <button type="button" onclick="loadCategoryWidgetsAsync('${category}', true)" class="mt-4 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition shadow-xs">
                    <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i> Try Again
                </button>
            </div>
        `;
        if (window.lucide) {
            lucide.createIcons();
        }
    } finally {
        loadingCategories[category] = false;
    }
}
</script>

