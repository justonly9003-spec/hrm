<?php
/**
 * Master Dashboard & Widget Management Hub
 * 
 * Interactive drag-and-drop ordering, role widget toggles,
 * layout width switches, catalog assignments, and multi-tenant organization overrides.
 */
$currentRole = $currentRole ?? 'company_admin';
$isAppAdmin = $isAppAdmin ?? false;
$selectedCompanyId = $selectedCompanyId ?? null;
$companies = $companies ?? [];
$companyUsers = $companyUsers ?? [];
$allWidgets = $allWidgets ?? [];
$roles = $roles ?? [];
$roleConfigs = $roleConfigs ?? [];
$companyOverrides = $companyOverrides ?? [];

// Resolve default active role
$firstRoleCode = array_key_first($roles) ?? 'company_admin';
$defaultActiveRole = $isAppAdmin ? 'software_app_admin' : (isset($roles[$currentRole]) ? $currentRole : $firstRoleCode);

// Helper map for preview URLs
$rolePreviewRoutes = [
    'software_app_admin' => 'dashboard/appadmin',
    'company_admin'      => 'dashboard/company-admin',
    'hr_admin'           => 'dashboard/hr',
    'hr_officer'         => 'dashboard/hr',
    'manager'            => 'dashboard/manager',
    'branch_manager'     => 'dashboard/manager',
    'team_leader'        => 'dashboard/manager',
    'employee'           => 'dashboard/employee',
    'finance'            => 'dashboard',
    'auditor'            => 'dashboard',
];

// Helper map for role icons
$roleIcons = [
    'software_app_admin' => 'shield-alert',
    'company_admin'      => 'building',
    'hr_admin'           => 'users',
    'hr_officer'         => 'user-check',
    'branch_manager'     => 'git-branch',
    'manager'            => 'briefcase',
    'team_leader'        => 'users-round',
    'employee'           => 'user',
    'auditor'            => 'shield-check',
    'finance'            => 'calculator',
];
?>
<div class="space-y-6">
    <!-- Header Banner -->
    <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-xs border border-slate-200/80 dark:border-slate-800">
        <div class="space-y-1">
            <div class="flex items-center gap-2">
                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800">
                    Control Center
                </span>
                <span class="text-xs text-slate-400">• Drag-and-Drop RBAC Widget Engine</span>
                <?php if ($isAppAdmin): ?>
                    <span class="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-800">
                        Global Superadmin Scope
                    </span>
                <?php else: ?>
                    <span class="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-400 border border-sky-200 dark:border-sky-800">
                        Tenant Organization Scope (<?= esc($roles[$currentRole] ?? $currentRole) ?>)
                    </span>
                <?php endif; ?>
            </div>
            <h1 class="text-2xl font-black tracking-tight text-slate-900 dark:text-white">Dashboard & Widget Management Hub</h1>
            <p class="text-xs text-slate-500 dark:text-slate-400 max-w-3xl">
                Rearrange widgets via drag-and-drop handles, configure 1/2 vs full column span, toggle status per role, assign catalog components, and manage organization-level tenant and staff user overrides.
            </p>
        </div>
        <div class="flex flex-wrap items-center gap-2.5">
            <a id="preview-dashboard-btn" href="<?= base_url($rolePreviewRoutes[$defaultActiveRole] ?? 'dashboard') ?>" target="_blank" class="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold transition border border-slate-200/80 dark:border-slate-700">
                <i data-lucide="external-link" class="w-4 h-4 text-indigo-600 dark:text-indigo-400"></i>
                <span id="preview-btn-label">Live Preview (<?= esc($roles[$defaultActiveRole] ?? 'Dashboard') ?>)</span>
            </a>
            <a href="<?= base_url('dashboard') ?>" class="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition shadow-xs shadow-indigo-600/30">
                <i data-lucide="arrow-left" class="w-4 h-4"></i>
                <span>Return to Dashboard</span>
            </a>
        </div>
    </div>

    <!-- Main Configuration Card -->
    <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-xs">
        
        <!-- Top Toolbar: Role Switcher & Live Search -->
        <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-5">
            <!-- Role Tabs Bar -->
            <div class="flex flex-wrap items-center gap-2">
                <?php foreach ($roles as $rCode => $rName): ?>
                    <?php 
                        $isActiveTab = ($rCode === $defaultActiveRole);
                        $rCount = count($roleConfigs[$rCode] ?? []);
                        $iconName = $roleIcons[$rCode] ?? 'shield';
                    ?>
                    <button type="button" 
                            onclick="switchRoleTab('<?= $rCode ?>')" 
                            id="tab-btn-<?= $rCode ?>"
                            data-preview-url="<?= base_url($rolePreviewRoutes[$rCode] ?? 'dashboard') ?>"
                            data-role-label="<?= esc($rName) ?>"
                            class="role-tab-btn px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 <?= $isActiveTab ? 'bg-indigo-600 text-white shadow-xs' : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700' ?>">
                        <i data-lucide="<?= $iconName ?>" class="w-3.5 h-3.5"></i>
                        <span><?= esc($rName) ?></span>
                        <span class="role-badge-count text-[10px] px-1.5 py-0.2 rounded-md font-mono <?= $isActiveTab ? 'bg-indigo-700 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300' ?>">
                            <?= $rCount ?>
                        </span>
                    </button>
                <?php endforeach; ?>

                <?php if (!empty($companyUsers)): ?>
                    <button type="button" 
                            onclick="switchRoleTab('company_users')" 
                            id="tab-btn-company_users"
                            data-preview-url="<?= base_url('dashboard') ?>"
                            data-role-label="Company Users"
                            class="role-tab-btn px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700">
                        <i data-lucide="user-cog" class="w-3.5 h-3.5 text-indigo-500"></i>
                        <span>Company Users</span>
                        <span class="role-badge-count text-[10px] px-1.5 py-0.2 rounded-md font-mono bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                            <?= count($companyUsers) ?>
                        </span>
                    </button>
                <?php endif; ?>
            </div>

            <!-- Instant Search Input & Catalog Add -->
            <div class="flex items-center gap-2.5">
                <div class="relative">
                    <i data-lucide="search" class="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"></i>
                    <input type="text" 
                           id="widget-search-input" 
                           placeholder="Filter role widgets..." 
                           onkeyup="filterWidgetCards(this.value)"
                           class="pl-9 pr-3.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 w-48 sm:w-60">
                </div>

                <?php if ($isAppAdmin || in_array($currentRole, ['company_admin', 'hr_admin'], true)): ?>
                    <button type="button" 
                            onclick="openCatalogModal()" 
                            class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 text-xs font-bold border border-indigo-200 dark:border-indigo-800 transition">
                        <i data-lucide="plus" class="w-3.5 h-3.5"></i>
                        <span>Add from Catalog</span>
                    </button>
                <?php endif; ?>
            </div>
        </div>

        <!-- Instructions Banner -->
        <div class="mt-4 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <div class="flex items-center gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-500 shrink-0"></i>
                <span>
                    <strong>Drag and Drop:</strong> Grab any card's handle <span class="font-mono px-1 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300">:::</span> to re-sequence widgets, or use the nudge buttons. Changes persist automatically.
                </span>
            </div>
            <span class="hidden sm:inline-block text-[11px] font-mono text-slate-400">Auto-saves via AJAX</span>
        </div>

        <!-- Role Widget Panels -->
        <?php foreach ($roles as $rCode => $rName): ?>
            <?php 
                $rWidgets = $roleConfigs[$rCode] ?? [];
                $isHidden = ($rCode !== $defaultActiveRole);
            ?>
            <div id="role-panel-<?= $rCode ?>" class="role-panel mt-6 <?= $isHidden ? 'hidden' : '' ?>" data-role-code="<?= $rCode ?>">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
                    <div>
                        <h3 class="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                            <span><?= esc($rName) ?> Workspace Widgets</span>
                            <span class="text-xs font-normal text-slate-400 font-mono">(<?= count($rWidgets) ?> total)</span>
                        </h3>
                        <p class="text-xs text-slate-500">Live operational view sequence for accounts assigned the <?= esc($rName) ?> role.</p>
                    </div>
                    <div class="flex items-center gap-2 text-xs">
                        <span class="text-slate-400">Quick view:</span>
                        <a href="<?= base_url($rolePreviewRoutes[$rCode] ?? 'dashboard') ?>" target="_blank" class="text-indigo-600 dark:text-indigo-400 font-bold hover:underline inline-flex items-center gap-1">
                            Launch <?= esc($rName) ?> Dashboard <i data-lucide="arrow-up-right" class="w-3 h-3"></i>
                        </a>
                    </div>
                </div>

                <?php if (empty($rWidgets)): ?>
                    <div class="p-12 text-center bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700 text-xs text-slate-400 space-y-2">
                        <i data-lucide="layout-grid" class="w-8 h-8 text-slate-300 dark:text-slate-600 mx-auto"></i>
                        <p class="font-bold text-slate-600 dark:text-slate-300">No widgets configured for this role.</p>
                        <?php if ($isAppAdmin || in_array($currentRole, ['company_admin', 'hr_admin'], true)): ?>
                            <button type="button" onclick="openCatalogModal('<?= $rCode ?>')" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-500 transition">
                                <i data-lucide="plus" class="w-3.5 h-3.5"></i> Add First Widget
                            </button>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <!-- Sortable Container -->
                    <div class="space-y-3 sortable-widget-list" id="widget-list-<?= $rCode ?>" data-role="<?= $rCode ?>">
                        <?php foreach ($rWidgets as $idx => $rw): ?>
                            <?php
                                $gridWidth = $rw['grid_width'] ?? 'half';
                                $isActive = ($rw['status'] == 1);
                                $category = $rw['category'] ?? 'general';
                            ?>
                            <div class="widget-drag-card p-4 rounded-xl bg-slate-50/70 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 transition hover:border-slate-300 dark:hover:border-slate-700 hover:shadow-xs group"
                                 id="widget-card-<?= esc($rw['widget_id']) ?>"
                                 data-widget-id="<?= esc($rw['widget_id']) ?>"
                                 data-role="<?= $rCode ?>"
                                 data-title="<?= strtolower(esc($rw['title'])) ?>"
                                 data-code="<?= strtolower(esc($rw['widget_code'])) ?>"
                                 data-module="<?= strtolower(esc($rw['module_code'] ?? '')) ?>"
                                 draggable="true">
                                
                                <div class="flex items-start md:items-center gap-3">
                                    <!-- Drag Handle -->
                                    <div class="drag-handle cursor-grab active:cursor-grabbing p-1.5 rounded-lg text-slate-300 hover:text-slate-600 dark:text-slate-600 dark:hover:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-700 transition" title="Drag to reorder">
                                        <i data-lucide="grip-vertical" class="w-4 h-4"></i>
                                    </div>

                                    <!-- Index Badge -->
                                    <span class="order-idx text-[11px] font-mono font-bold w-6 text-center text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-300">
                                        #<?= $idx + 1 ?>
                                    </span>

                                    <!-- Widget Icon -->
                                    <div class="p-2.5 rounded-xl bg-white dark:bg-slate-700 border border-slate-200/80 dark:border-slate-600 text-indigo-600 dark:text-indigo-400 shrink-0 shadow-2xs">
                                        <i data-lucide="<?= esc($rw['icon'] ?? 'layout-grid') ?>" class="w-5 h-5"></i>
                                    </div>

                                    <!-- Widget Titles & Meta -->
                                    <div>
                                        <div class="flex flex-wrap items-center gap-2">
                                            <span class="text-sm font-bold text-slate-900 dark:text-white"><?= esc($rw['title']) ?></span>
                                            <span class="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-200/70 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold">
                                                <?= esc($rw['widget_code']) ?>
                                            </span>
                                            <?php if (!empty($rw['module_code'])): ?>
                                                <span class="text-[10px] font-bold px-2 py-0.5 rounded-md bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800">
                                                    Module: <?= esc($rw['module_code']) ?>
                                                </span>
                                            <?php endif; ?>
                                            <span class="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-500 uppercase tracking-wider">
                                                <?= esc($category) ?>
                                            </span>
                                        </div>
                                        <p class="text-xs text-slate-500 mt-0.5 line-clamp-1 max-w-xl"><?= esc($rw['description'] ?? 'Standard Dashboard Widget') ?></p>
                                    </div>
                                </div>

                                <!-- Action Controls Deck -->
                                <div class="flex flex-wrap items-center gap-3 self-end md:self-center">
                                    
                                    <!-- Grid Width Switcher (Half vs Full) -->
                                    <div class="flex items-center rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-0.5 text-[11px] font-bold">
                                        <button type="button" 
                                                onclick="updateWidgetGridWidth('<?= esc($rw['widget_id']) ?>', 'role', '<?= $rCode ?>', 'half', this)"
                                                title="Half column width (1/2 row on desktop)"
                                                class="grid-btn-half px-2 py-1 rounded-md transition <?= ($gridWidth === 'half') ? 'bg-indigo-600 text-white shadow-2xs' : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200' ?>">
                                            1/2 Width
                                        </button>
                                        <button type="button" 
                                                onclick="updateWidgetGridWidth('<?= esc($rw['widget_id']) ?>', 'role', '<?= $rCode ?>', 'full', this)"
                                                title="Full row width"
                                                class="grid-btn-full px-2 py-1 rounded-md transition <?= ($gridWidth === 'full') ? 'bg-indigo-600 text-white shadow-2xs' : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200' ?>">
                                            Full Width
                                        </button>
                                    </div>

                                    <!-- Nudge Up / Down Ordering Buttons -->
                                    <div class="flex items-center gap-0.5 bg-white dark:bg-slate-800 p-0.5 rounded-lg border border-slate-200 dark:border-slate-700">
                                        <button type="button" 
                                                onclick="nudgeWidget('<?= $rCode ?>', '<?= esc($rw['widget_id']) ?>', 'up')" 
                                                class="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-white rounded hover:bg-slate-100 dark:hover:bg-slate-700 transition"
                                                title="Move up one position">
                                            <i data-lucide="chevron-up" class="w-4 h-4"></i>
                                        </button>
                                        <button type="button" 
                                                onclick="nudgeWidget('<?= $rCode ?>', '<?= esc($rw['widget_id']) ?>', 'down')" 
                                                class="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-white rounded hover:bg-slate-100 dark:hover:bg-slate-700 transition"
                                                title="Move down one position">
                                            <i data-lucide="chevron-down" class="w-4 h-4"></i>
                                        </button>
                                    </div>

                                    <!-- Status Toggle Button -->
                                    <button type="button" 
                                            onclick="toggleRoleWidgetStatus('<?= esc($rw['widget_id']) ?>', '<?= $rCode ?>', this)"
                                            data-status="<?= $isActive ? '1' : '0' ?>"
                                            class="status-toggle-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition <?= $isActive ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 border border-slate-200 dark:border-slate-700' ?>">
                                        <span class="status-indicator-dot w-2 h-2 rounded-full <?= $isActive ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400' ?>"></span>
                                        <span class="status-label-text"><?= $isActive ? 'Active' : 'Disabled' ?></span>
                                    </button>

                                    <?php if ($isAppAdmin || in_array($currentRole, ['company_admin', 'hr_admin'], true)): ?>
                                        <!-- Remove from role button -->
                                        <button type="button" 
                                                onclick="removeWidgetFromRole('<?= esc($rw['widget_id']) ?>', '<?= $rCode ?>', '<?= esc(addslashes($rw['title'])) ?>')"
                                                title="Remove widget from this role"
                                                class="p-1.5 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition">
                                            <i data-lucide="trash-2" class="w-4 h-4"></i>
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>

        <!-- Company Users Layout Management Panel -->
        <?php if (!empty($companyUsers)): ?>
            <div id="role-panel-company_users" class="role-panel mt-6 hidden" data-role-code="company_users">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 bg-slate-50 dark:bg-slate-800/40 p-4 rounded-xl border border-slate-200/80 dark:border-slate-800">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
                            <i data-lucide="user-cog" class="w-5 h-5"></i>
                        </div>
                        <div>
                            <h3 class="text-sm font-extrabold text-slate-900 dark:text-white">Personalized Staff Dashboard Layouts</h3>
                            <p class="text-xs text-slate-500">Configure, customize, reorder, or reset widget layouts for company staff accounts (finance, HR, employees, managers).</p>
                        </div>
                    </div>

                    <div class="flex items-center gap-2">
                        <label for="mgmt-company-user-select" class="text-xs font-bold text-slate-500 whitespace-nowrap">Select User:</label>
                        <select id="mgmt-company-user-select" onchange="loadMgmtUserWidgets(this.value)" class="text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 max-w-xs">
                            <?php foreach ($companyUsers as $cu): ?>
                                <option value="<?= esc($cu['id']) ?>" data-role="<?= esc($cu['role_name'] ?: $cu['role_code'] ?: 'Staff') ?>" data-name="<?= esc($cu['name'] ?: $cu['username']) ?>">
                                    <?= esc($cu['name'] ?: $cu['username']) ?> (<?= esc($cu['role_name'] ?: $cu['role_code'] ?: 'Staff') ?><?= !empty($cu['employee_code']) ? ' - ' . esc($cu['employee_code']) : '' ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div id="mgmt-user-widgets-container" class="space-y-3 min-h-[160px]">
                    <div class="py-12 text-center text-slate-400 text-xs">
                        <span class="inline-block animate-spin mr-1.5 text-indigo-600">⟳</span> Loading staff widgets...
                    </div>
                </div>

                <div class="flex items-center justify-between mt-4 pt-4 border-t border-slate-100 dark:border-slate-800">
                    <button type="button" onclick="resetMgmtUserPreferences()" id="btn-mgmt-reset-user" class="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition">
                        <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i>
                        <span>Reset User to Role Defaults</span>
                    </button>
                    <button type="button" onclick="saveMgmtUserPreferences()" id="btn-mgmt-save-user" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition shadow-xs shadow-indigo-600/30">
                        <i data-lucide="check" class="w-4 h-4"></i>
                        <span>Save User Layout</span>
                    </button>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Tenant Organization Overrides Section -->
    <?php if ($isAppAdmin || !empty($selectedCompanyId)): ?>
        <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-xs">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-950/60 border border-purple-100 dark:border-purple-800 flex items-center justify-center text-purple-600 dark:text-purple-400">
                        <i data-lucide="building-2" class="w-5 h-5"></i>
                    </div>
                    <div>
                        <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Tenant Organization Overrides</h3>
                        <p class="text-xs text-slate-500">Allow specific enterprise tenants to force-enable or force-disable specific widgets across their workforce workspace.</p>
                    </div>
                </div>

                <div class="flex flex-wrap items-center gap-3">
                    <?php if ($isAppAdmin && !empty($companies)): ?>
                        <form method="GET" action="<?= base_url('dashboard/widgets') ?>" class="flex items-center gap-2">
                            <label for="company-selector" class="text-xs font-bold text-slate-500 whitespace-nowrap">Select Tenant:</label>
                            <select id="company-selector" name="company_id" onchange="this.form.submit()" class="text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200">
                                <?php foreach ($companies as $c): ?>
                                    <option value="<?= esc($c['id']) ?>" <?= ($selectedCompanyId === $c['id']) ? 'selected' : '' ?>>
                                        <?= esc($c['name']) ?> (<?= esc($c['code'] ?? 'ORG') ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </form>
                    <?php endif; ?>

                    <div class="relative">
                        <i data-lucide="search" class="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2"></i>
                        <input type="text" 
                               id="tenant-filter-input" 
                               placeholder="Filter tenant widgets..." 
                               onkeyup="filterTenantCards(this.value)"
                               class="pl-8 pr-3 py-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 w-44">
                    </div>
                </div>
            </div>

            <div class="mt-4">
                <div class="flex items-center justify-between mb-3 text-xs">
                    <span class="text-slate-500">
                        Managing tenant overrides for: <strong class="text-slate-800 dark:text-slate-200">
                            <?php 
                                $currCompanyObj = null;
                                foreach ($companies as $comp) {
                                    if ($comp['id'] === $selectedCompanyId) {
                                        $currCompanyObj = $comp;
                                        break;
                                    }
                                }
                                echo esc($currCompanyObj['name'] ?? 'Active Company Workspace');
                            ?>
                        </strong>
                    </span>
                    <span class="text-slate-400 font-mono text-[11px]"><?= count($companyOverrides) ?> Active Overrides Recorded</span>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5" id="tenant-cards-container">
                    <?php foreach ($allWidgets as $w): ?>
                        <?php 
                            $isOverridden = false;
                            $overrideStatus = 1;
                            foreach ($companyOverrides as $co) {
                                if ($co['widget_id'] === $w['id']) {
                                    $isOverridden = true;
                                    $overrideStatus = (int)$co['status'];
                                    break;
                                }
                            }
                        ?>
                        <div class="tenant-widget-card p-3.5 rounded-xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/70 dark:border-slate-800 flex flex-col justify-between gap-3 transition hover:border-slate-300 dark:hover:border-slate-700"
                             data-title="<?= strtolower(esc($w['title'])) ?>"
                             data-code="<?= strtolower(esc($w['code'])) ?>">
                            <div class="flex items-start gap-2.5">
                                <div class="p-2 rounded-lg bg-white dark:bg-slate-700 text-slate-600 dark:text-slate-300 shrink-0 border border-slate-200/60 dark:border-slate-600">
                                    <i data-lucide="<?= esc($w['icon'] ?? 'box') ?>" class="w-4 h-4"></i>
                                </div>
                                <div class="min-w-0">
                                    <div class="text-xs font-bold text-slate-900 dark:text-white truncate"><?= esc($w['title']) ?></div>
                                    <div class="text-[10px] text-slate-400 font-mono"><?= esc($w['code']) ?></div>
                                    <?php if (!empty($w['module_code'])): ?>
                                        <span class="text-[9px] font-bold text-purple-600 dark:text-purple-400">Mod: <?= esc($w['module_code']) ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800/60 text-[11px]">
                                <?php if ($isOverridden): ?>
                                    <span class="inline-flex items-center gap-1 font-bold <?= ($overrideStatus === 1) ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400' ?>">
                                        <span class="w-1.5 h-1.5 rounded-full <?= ($overrideStatus === 1) ? 'bg-emerald-500' : 'bg-rose-500' ?>"></span>
                                        <?= ($overrideStatus === 1) ? 'Forced Active' : 'Forced Disabled' ?>
                                    </span>
                                <?php else: ?>
                                    <span class="text-slate-400 italic">Inherited Default</span>
                                <?php endif; ?>

                                <div class="flex items-center gap-1.5">
                                    <?php if ($isOverridden): ?>
                                        <button type="button"
                                                onclick="resetCompanyOverride('<?= esc($w['id']) ?>', '<?= esc($selectedCompanyId) ?>', this)"
                                                title="Clear override and restore role default"
                                                class="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-200/70 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300 transition">
                                            Reset
                                        </button>
                                    <?php endif; ?>

                                    <button type="button"
                                            onclick="toggleCompanyOverride('<?= esc($w['id']) ?>', '<?= esc($selectedCompanyId) ?>', <?= ($isOverridden && $overrideStatus === 1) ? 0 : 1 ?>, this)"
                                            class="px-2.5 py-1 rounded-lg text-[10px] font-bold transition <?= ($isOverridden && $overrideStatus === 1) ? 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400 border border-rose-200' : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200' ?>">
                                        <?= ($isOverridden && $overrideStatus === 1) ? 'Disable' : 'Force Enable' ?>
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- Modal: Add Widget from Catalog -->
<?php if ($isAppAdmin || in_array($currentRole, ['company_admin', 'hr_admin'], true)): ?>
<div id="catalog-modal" class="fixed inset-0 z-50 hidden bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
    <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-2xl w-full p-6 shadow-2xl max-h-[85vh] flex flex-col">
        <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
            <div>
                <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Add Widget to Role Workspace</h3>
                <p class="text-xs text-slate-500">Target Role: <strong id="catalog-modal-role-label" class="text-indigo-600 dark:text-indigo-400">Software App Admin</strong></p>
            </div>
            <button type="button" onclick="closeCatalogModal()" class="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>

        <div class="py-3">
            <input type="text" 
                   id="catalog-search" 
                   placeholder="Search all 28 catalog widgets..." 
                   onkeyup="filterCatalogModal(this.value)"
                   class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20">
        </div>

        <div class="overflow-y-auto space-y-2.5 pr-1 flex-1 my-2" id="catalog-list">
            <?php foreach ($allWidgets as $w): ?>
                <div class="catalog-item p-3 rounded-xl border border-slate-200/80 dark:border-slate-800 hover:border-indigo-200 dark:hover:border-indigo-800 flex items-center justify-between gap-3 bg-slate-50/50 dark:bg-slate-800/30"
                     data-widget-id="<?= esc($w['id']) ?>"
                     data-title="<?= strtolower(esc($w['title'])) ?>"
                     data-code="<?= strtolower(esc($w['code'])) ?>">
                    <div class="flex items-center gap-2.5">
                        <div class="p-2 rounded-lg bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 border border-slate-200 dark:border-slate-600">
                            <i data-lucide="<?= esc($w['icon'] ?? 'layout-grid') ?>" class="w-4 h-4"></i>
                        </div>
                        <div>
                            <span class="text-xs font-bold text-slate-900 dark:text-white block"><?= esc($w['title']) ?></span>
                            <span class="text-[10px] text-slate-400 font-mono"><?= esc($w['code']) ?> • <?= esc($w['view_path']) ?></span>
                        </div>
                    </div>
                    <button type="button" 
                            onclick="assignCatalogWidget('<?= esc($w['id']) ?>', this)"
                            class="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition">
                        Add to Role
                    </button>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="border-t border-slate-100 dark:border-slate-800 pt-3 flex justify-end">
            <button type="button" onclick="closeCatalogModal()" class="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-200">
                Close
            </button>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Floating Toast Container -->
<div id="toast-container" class="fixed bottom-5 right-5 z-50 space-y-2 pointer-events-none"></div>

<script>
let currentActiveRole = '<?= esc($defaultActiveRole) ?>';
const csrfTokenName = '<?= csrf_token() ?>';
let csrfTokenHash = '<?= csrf_hash() ?>';
let mgmtUserWidgets = [];
let mgmtUserWidgetsLoaded = false;

function getCsrfHeaders() {
    return {
        'X-Requested-With': 'XMLHttpRequest',
        'X-CSRF-TOKEN': csrfTokenHash
    };
}

// Toast Notification System
function showToast(message, type = 'success') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `pointer-events-auto flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-lg border text-xs font-bold transition-all duration-300 transform translate-y-2 opacity-0 ${
        type === 'success' 
            ? 'bg-emerald-900/90 border-emerald-700 text-emerald-100 backdrop-blur-xs' 
            : type === 'error'
            ? 'bg-rose-900/90 border-rose-700 text-rose-100 backdrop-blur-xs'
            : 'bg-slate-900/90 border-slate-700 text-slate-100 backdrop-blur-xs'
    }`;
    
    const icon = type === 'success' ? '✓' : (type === 'error' ? '✕' : 'ℹ');
    toast.innerHTML = `<span class="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center font-black">${icon}</span> <span>${message}</span>`;

    container.appendChild(toast);

    requestAnimationFrame(() => {
        toast.classList.remove('translate-y-2', 'opacity-0');
        toast.classList.add('translate-y-0', 'opacity-100');
    });

    setTimeout(() => {
        toast.classList.add('opacity-0', 'translate-y-2');
        setTimeout(() => toast.remove(), 300);
    }, 3200);
}

// Switch Role Tab
function switchRoleTab(roleCode, persist = true) {
    currentActiveRole = roleCode;

    if (persist) {
        localStorage.setItem('ci4_mgmt_active_role_tab', roleCode);
        if (window.location.hash !== '#' + roleCode) {
            history.replaceState(null, null, '#' + roleCode);
        }
    }

    document.querySelectorAll('.role-tab-btn').forEach(btn => {
        btn.classList.remove('bg-indigo-600', 'text-white', 'shadow-xs');
        btn.classList.add('bg-slate-50', 'dark:bg-slate-800', 'text-slate-600', 'dark:text-slate-300');
        const badge = btn.querySelector('.role-badge-count');
        if (badge) {
            badge.classList.remove('bg-indigo-700', 'text-white');
            badge.classList.add('bg-slate-200', 'dark:bg-slate-700', 'text-slate-600', 'dark:text-slate-300');
        }
    });
    
    const activeBtn = document.getElementById('tab-btn-' + roleCode);
    if (activeBtn) {
        activeBtn.classList.remove('bg-slate-50', 'dark:bg-slate-800', 'text-slate-600', 'dark:text-slate-300');
        activeBtn.classList.add('bg-indigo-600', 'text-white', 'shadow-xs');
        const badge = activeBtn.querySelector('.role-badge-count');
        if (badge) {
            badge.classList.remove('bg-slate-200', 'dark:bg-slate-700', 'text-slate-600', 'dark:text-slate-300');
            badge.classList.add('bg-indigo-700', 'text-white');
        }

        // Update preview button in banner
        const previewUrl = activeBtn.getAttribute('data-preview-url');
        const roleLabel = activeBtn.getAttribute('data-role-label');
        const previewBtn = document.getElementById('preview-dashboard-btn');
        const previewLabel = document.getElementById('preview-btn-label');
        if (previewBtn && previewUrl) {
            previewBtn.href = previewUrl;
        }
        if (previewLabel && roleLabel) {
            previewLabel.textContent = 'Live Preview (' + roleLabel + ')';
        }
    }

    document.querySelectorAll('.role-panel').forEach(panel => {
        panel.classList.add('hidden');
    });

    const activePanel = document.getElementById('role-panel-' + roleCode);
    if (activePanel) {
        activePanel.classList.remove('hidden');
    }

    // Clear search filter when switching tabs
    const searchInput = document.getElementById('widget-search-input');
    if (searchInput) {
        searchInput.value = '';
        filterWidgetCards('');
    }

    if (roleCode === 'company_users' && !mgmtUserWidgetsLoaded) {
        const select = document.getElementById('mgmt-company-user-select');
        if (select && select.value) {
            loadMgmtUserWidgets(select.value);
        }
    }
}

// Filter Widget Cards by Name/Code/Module
function filterWidgetCards(query) {
    const q = query.trim().toLowerCase();
    const activePanel = document.getElementById('role-panel-' + currentActiveRole);
    if (!activePanel) return;

    const cards = activePanel.querySelectorAll('.widget-drag-card');
    cards.forEach(card => {
        const title = card.getAttribute('data-title') || '';
        const code = card.getAttribute('data-code') || '';
        const mod = card.getAttribute('data-module') || '';
        if (title.includes(q) || code.includes(q) || mod.includes(q)) {
            card.classList.remove('hidden');
        } else {
            card.classList.add('hidden');
        }
    });
}

// Filter Tenant Cards
function filterTenantCards(query) {
    const q = query.trim().toLowerCase();
    const cards = document.querySelectorAll('.tenant-widget-card');
    cards.forEach(card => {
        const title = card.getAttribute('data-title') || '';
        const code = card.getAttribute('data-code') || '';
        if (title.includes(q) || code.includes(q)) {
            card.classList.remove('hidden');
        } else {
            card.classList.add('hidden');
        }
    });
}

// Toggle Role Widget Status (Optimistic UI + AJAX)
function toggleRoleWidgetStatus(widgetId, roleCode, buttonEl) {
    const currentStatus = parseInt(buttonEl.getAttribute('data-status') || '0', 10);
    const nextStatus = currentStatus === 1 ? 0 : 1;

    // Optimistic UI update
    buttonEl.setAttribute('data-status', nextStatus.toString());
    const dot = buttonEl.querySelector('.status-indicator-dot');
    const label = buttonEl.querySelector('.status-label-text');

    if (nextStatus === 1) {
        buttonEl.className = 'status-toggle-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800';
        if (dot) dot.className = 'status-indicator-dot w-2 h-2 rounded-full bg-emerald-500 animate-pulse';
        if (label) label.textContent = 'Active';
    } else {
        buttonEl.className = 'status-toggle-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition bg-slate-100 dark:bg-slate-800 text-slate-500 border border-slate-200 dark:border-slate-700';
        if (dot) dot.className = 'status-indicator-dot w-2 h-2 rounded-full bg-slate-400';
        if (label) label.textContent = 'Disabled';
    }

    const formData = new FormData();
    formData.append('widget_id', widgetId);
    formData.append('target_type', 'role');
    formData.append('target_id', roleCode);
    formData.append('status', nextStatus);
    formData.append(csrfTokenName, csrfTokenHash);

    fetch('<?= base_url('api/dashboard/widgets/toggle') ?>', {
        method: 'POST',
        headers: getCsrfHeaders(),
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.success || data.status === 'success') {
            showToast(data.message || 'Status updated successfully.');
        } else {
            showToast(data.message || 'Failed to update status.', 'error');
            // Revert state
            toggleRoleWidgetStatus(widgetId, roleCode, buttonEl);
        }
    })
    .catch(err => {
        console.error(err);
        showToast('Network error updating widget status.', 'error');
    });
}

// Update Widget Grid Width (1/2 vs Full)
function updateWidgetGridWidth(widgetId, targetType, targetId, gridWidth, buttonEl) {
    const parentContainer = buttonEl.parentElement;
    const btnHalf = parentContainer.querySelector('.grid-btn-half');
    const btnFull = parentContainer.querySelector('.grid-btn-full');

    if (gridWidth === 'half') {
        btnHalf.className = 'grid-btn-half px-2 py-1 rounded-md transition bg-indigo-600 text-white shadow-2xs';
        btnFull.className = 'grid-btn-full px-2 py-1 rounded-md transition text-slate-500 hover:text-slate-800 dark:hover:text-slate-200';
    } else {
        btnFull.className = 'grid-btn-full px-2 py-1 rounded-md transition bg-indigo-600 text-white shadow-2xs';
        btnHalf.className = 'grid-btn-half px-2 py-1 rounded-md transition text-slate-500 hover:text-slate-800 dark:hover:text-slate-200';
    }

    const formData = new FormData();
    formData.append('widget_id', widgetId);
    formData.append('target_type', targetType);
    formData.append('target_id', targetId);
    formData.append('grid_width', gridWidth);
    formData.append(csrfTokenName, csrfTokenHash);

    fetch('<?= base_url('api/dashboard/widgets/update-width') ?>', {
        method: 'POST',
        headers: getCsrfHeaders(),
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.success || data.status === 'success') {
            showToast(data.message || 'Column layout updated.');
        } else {
            showToast(data.message || 'Error updating layout.', 'error');
        }
    })
    .catch(err => {
        console.error(err);
        showToast('Network error updating width.', 'error');
    });
}

// Nudge widget position (up/down)
function nudgeWidget(roleCode, widgetId, direction) {
    const container = document.getElementById('widget-list-' + roleCode);
    if (!container) return;

    const cards = Array.from(container.children).filter(c => c.classList.contains('widget-drag-card'));
    const index = cards.findIndex(c => c.getAttribute('data-widget-id') === widgetId);
    if (index === -1) return;

    if (direction === 'up' && index > 0) {
        container.insertBefore(cards[index], cards[index - 1]);
    } else if (direction === 'down' && index < cards.length - 1) {
        container.insertBefore(cards[index + 1], cards[index]);
    } else {
        return;
    }

    recalculateIndexPills(container);
    persistWidgetOrder(roleCode, container);
}

// Recalculate #1, #2 pills after reordering
function recalculateIndexPills(container) {
    const cards = Array.from(container.children).filter(c => c.classList.contains('widget-drag-card'));
    cards.forEach((card, idx) => {
        const pill = card.querySelector('.order-idx');
        if (pill) {
            pill.textContent = '#' + (idx + 1);
        }
    });
}

// Persist Widget Order via AJAX
function persistWidgetOrder(roleCode, container) {
    const cards = Array.from(container.children).filter(c => c.classList.contains('widget-drag-card'));
    const newOrderIds = cards.map(c => c.getAttribute('data-widget-id'));

    const formData = new FormData();
    formData.append('target_type', 'role');
    formData.append('target_id', roleCode);
    formData.append('widget_ids', JSON.stringify(newOrderIds));
    formData.append(csrfTokenName, csrfTokenHash);

    fetch('<?= base_url('api/dashboard/widgets/reorder') ?>', {
        method: 'POST',
        headers: getCsrfHeaders(),
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.success || data.status === 'success') {
            showToast('Widget display sequence saved.');
        } else {
            showToast(data.message || 'Error reordering widgets.', 'error');
        }
    })
    .catch(err => {
        console.error(err);
        showToast('Network error saving widget order.', 'error');
    });
}

// HTML5 Drag and Drop Handlers
function initializeDragAndDrop() {
    document.querySelectorAll('.sortable-widget-list').forEach(container => {
        let draggedCard = null;

        container.addEventListener('dragstart', function(e) {
            const card = e.target.closest('.widget-drag-card');
            if (!card) return;
            draggedCard = card;
            e.dataTransfer.effectAllowed = 'move';
            e.dataTransfer.setData('text/plain', card.getAttribute('data-widget-id'));
            card.classList.add('opacity-40', 'border-indigo-500', 'dark:border-indigo-500');
        });

        container.addEventListener('dragend', function(e) {
            if (draggedCard) {
                draggedCard.classList.remove('opacity-40', 'border-indigo-500', 'dark:border-indigo-500');
                draggedCard = null;
            }
            container.querySelectorAll('.drag-over-indicator').forEach(el => el.remove());
        });

        container.addEventListener('dragover', function(e) {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            const targetCard = e.target.closest('.widget-drag-card');
            if (!targetCard || targetCard === draggedCard) return;

            const rect = targetCard.getBoundingClientRect();
            const next = (e.clientY - rect.top) / (rect.bottom - rect.top) > 0.5;
            container.insertBefore(draggedCard, next ? targetCard.nextSibling : targetCard);
        });

        container.addEventListener('drop', function(e) {
            e.preventDefault();
            const roleCode = container.getAttribute('data-role');
            recalculateIndexPills(container);
            persistWidgetOrder(roleCode, container);
        });
    });
}

// Remove widget from role
function removeWidgetFromRole(widgetId, roleCode, title) {
    if (!confirm(`Are you sure you want to remove '${title}' from the ${roleCode} dashboard?`)) {
        return;
    }

    const formData = new FormData();
    formData.append('widget_id', widgetId);
    formData.append('role_code', roleCode);
    formData.append(csrfTokenName, csrfTokenHash);

    fetch('<?= base_url('api/dashboard/widgets/remove-role') ?>', {
        method: 'POST',
        headers: getCsrfHeaders(),
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.success || data.status === 'success') {
            showToast(data.message || 'Widget removed.');
            const card = document.getElementById('widget-card-' + widgetId);
            if (card) {
                const container = card.parentElement;
                card.remove();
                if (container) recalculateIndexPills(container);
            }
        } else {
            showToast(data.message || 'Error removing widget.', 'error');
        }
    })
    .catch(err => {
        console.error(err);
        showToast('Network error removing widget.', 'error');
    });
}

// Catalog Modal Management
function openCatalogModal(roleCode) {
    const modal = document.getElementById('catalog-modal');
    if (!modal) return;
    const targetRole = roleCode || currentActiveRole;
    const label = document.getElementById('catalog-modal-role-label');
    if (label) {
        label.textContent = targetRole;
    }
    modal.classList.remove('hidden');
}

function closeCatalogModal() {
    const modal = document.getElementById('catalog-modal');
    if (modal) modal.classList.add('hidden');
}

function filterCatalogModal(query) {
    const q = query.trim().toLowerCase();
    const items = document.querySelectorAll('.catalog-item');
    items.forEach(item => {
        const title = item.getAttribute('data-title') || '';
        const code = item.getAttribute('data-code') || '';
        if (title.includes(q) || code.includes(q)) {
            item.classList.remove('hidden');
        } else {
            item.classList.add('hidden');
        }
    });
}

function assignCatalogWidget(widgetId, buttonEl) {
    buttonEl.disabled = true;
    buttonEl.textContent = 'Adding...';

    const formData = new FormData();
    formData.append('widget_id', widgetId);
    formData.append('role_code', currentActiveRole);
    formData.append(csrfTokenName, csrfTokenHash);

    fetch('<?= base_url('api/dashboard/widgets/assign-role') ?>', {
        method: 'POST',
        headers: getCsrfHeaders(),
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.success || data.status === 'success') {
            showToast(data.message || 'Widget added to role.');
            buttonEl.textContent = 'Added ✓';
            buttonEl.className = 'px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold';
            setTimeout(() => {
                window.location.reload();
            }, 800);
        } else {
            showToast(data.message || 'Error adding widget.', 'error');
            buttonEl.disabled = false;
            buttonEl.textContent = 'Add to Role';
        }
    })
    .catch(err => {
        console.error(err);
        buttonEl.disabled = false;
        buttonEl.textContent = 'Add to Role';
        showToast('Network error assigning widget.', 'error');
    });
}

// Toggle Company Override (Tenant)
function toggleCompanyOverride(widgetId, companyId, newStatus, buttonEl) {
    buttonEl.disabled = true;
    const formData = new FormData();
    formData.append('widget_id', widgetId);
    formData.append('target_type', 'company');
    formData.append('target_id', companyId);
    formData.append('status', newStatus);
    formData.append(csrfTokenName, csrfTokenHash);

    fetch('<?= base_url('api/dashboard/widgets/toggle') ?>', {
        method: 'POST',
        headers: getCsrfHeaders(),
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.success || data.status === 'success') {
            showToast(data.message || 'Organization override saved.');
            setTimeout(() => window.location.reload(), 600);
        } else {
            showToast(data.message || 'Error updating override.', 'error');
            buttonEl.disabled = false;
        }
    })
    .catch(err => {
        console.error(err);
        buttonEl.disabled = false;
        showToast('Network error saving override.', 'error');
    });
}

// Reset Company Override
function resetCompanyOverride(widgetId, companyId, buttonEl) {
    buttonEl.disabled = true;
    const formData = new FormData();
    formData.append('widget_id', widgetId);
    formData.append('company_id', companyId);
    formData.append(csrfTokenName, csrfTokenHash);

    fetch('<?= base_url('api/dashboard/widgets/reset-override') ?>', {
        method: 'POST',
        headers: getCsrfHeaders(),
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.success || data.status === 'success') {
            showToast(data.message || 'Override cleared.');
            setTimeout(() => window.location.reload(), 600);
        } else {
            showToast(data.message || 'Error resetting override.', 'error');
            buttonEl.disabled = false;
        }
    })
    .catch(err => {
        console.error(err);
        buttonEl.disabled = false;
        showToast('Network error resetting override.', 'error');
    });
}

// Staff User Layout Management (for tenant admins & software admin)
function loadMgmtUserWidgets(userId) {
    if (!userId) {
        const select = document.getElementById('mgmt-company-user-select');
        userId = select ? select.value : '';
    }
    if (!userId) return;

    const container = document.getElementById('mgmt-user-widgets-container');
    if (container) {
        container.innerHTML = `
            <div class="py-12 text-center text-slate-400 text-xs">
                <span class="inline-block animate-spin mr-1.5 text-indigo-600">⟳</span> Loading staff widgets...
            </div>
        `;
    }

    fetch('<?= base_url('api/dashboard/customizable-widgets') ?>?target_user_id=' + encodeURIComponent(userId), {
        headers: getCsrfHeaders()
    })
    .then(r => r.json())
    .then(data => {
        if (data.success || data.status === 'success') {
            const raw = Array.isArray(data.data) ? data.data : ((data.data && data.data.widgets) ? data.data.widgets : (data.widgets || []));
            mgmtUserWidgets = raw.map(w => ({
                ...w,
                widget_id: w.id || w.widget_id,
                title: w.title || w.code || 'Widget',
                is_visible: (w.status == 1 || w.is_visible == 1 || w.status === true || w.is_visible === true) ? 1 : 0,
                grid_width: w.grid_width || 'half',
                icon: w.icon || 'layout-grid',
                widget_code: w.code || w.widget_code || w.id || w.widget_id
            }));
            mgmtUserWidgetsLoaded = true;
            renderMgmtUserWidgets(mgmtUserWidgets);
        } else {
            if (container) {
                container.innerHTML = `
                    <div class="p-8 text-center bg-rose-50/50 dark:bg-rose-950/20 rounded-xl border border-rose-200 dark:border-rose-900 text-xs text-rose-600 dark:text-rose-400">
                        ${data.message || 'Failed to load user widgets.'}
                    </div>
                `;
            }
        }
    })
    .catch(err => {
        console.error(err);
        if (container) {
            container.innerHTML = `
                <div class="p-8 text-center bg-rose-50/50 dark:bg-rose-950/20 rounded-xl border border-rose-200 dark:border-rose-900 text-xs text-rose-600 dark:text-rose-400">
                    Network error loading staff layout.
                </div>
            `;
        }
    });
}

function renderMgmtUserWidgets(widgets) {
    const container = document.getElementById('mgmt-user-widgets-container');
    if (!container) return;

    if (!widgets || widgets.length === 0) {
        container.innerHTML = `
            <div class="p-8 text-center bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700 text-xs text-slate-400">
                No customizable widgets assigned to this user's role.
            </div>
        `;
        return;
    }

    container.innerHTML = widgets.map((w, idx) => {
        const wid = w.widget_id || w.id;
        const isVisible = (w.is_visible == 1 || w.is_visible === true || w.status == 1);
        const width = w.grid_width || 'half';
        const isHalf = width === 'half';
        const isFull = width === 'full';

        return `
            <div class="mgmt-user-widget-card p-3.5 rounded-xl bg-slate-50/70 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-3 transition hover:border-slate-300 dark:hover:border-slate-700" data-widget-id="${wid}">
                <div class="flex items-center gap-3">
                    <span class="text-xs font-mono font-bold text-slate-400 w-6">#${idx + 1}</span>
                    <div class="p-2 rounded-lg bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 border border-slate-200 dark:border-slate-600">
                        <i data-lucide="${w.icon || 'layout-grid'}" class="w-4 h-4"></i>
                    </div>
                    <div>
                        <div class="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                            <span>${w.title || 'Widget'}</span>
                            ${w.module_code ? `<span class="text-[9px] font-bold text-purple-600 dark:text-purple-400 font-mono">Mod: ${w.module_code}</span>` : ''}
                        </div>
                        <div class="text-[10px] text-slate-400 font-mono">${w.widget_code || wid}</div>
                    </div>
                </div>

                <div class="flex flex-wrap items-center gap-3 justify-end">
                    <!-- Column width switch -->
                    <div class="inline-flex rounded-lg border border-slate-200 dark:border-slate-700 p-0.5 bg-white dark:bg-slate-800 text-[11px] font-bold">
                        <button type="button" 
                                onclick="setMgmtUserWidgetWidth('${wid}', 'half')" 
                                class="px-2 py-1 rounded-md transition ${isHalf ? 'bg-indigo-600 text-white shadow-2xs' : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'}">
                            1/2
                        </button>
                        <button type="button" 
                                onclick="setMgmtUserWidgetWidth('${wid}', 'full')" 
                                class="px-2 py-1 rounded-md transition ${isFull ? 'bg-indigo-600 text-white shadow-2xs' : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'}">
                            Full
                        </button>
                    </div>

                    <!-- Nudge Up / Down Ordering Buttons -->
                    <div class="flex items-center gap-0.5 bg-white dark:bg-slate-800 p-0.5 rounded-lg border border-slate-200 dark:border-slate-700">
                        <button type="button" 
                                onclick="nudgeMgmtUserWidget('${wid}', 'up')" 
                                class="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-white rounded hover:bg-slate-100 dark:hover:bg-slate-700 transition"
                                title="Move up">
                            <i data-lucide="chevron-up" class="w-4 h-4"></i>
                        </button>
                        <button type="button" 
                                onclick="nudgeMgmtUserWidget('${wid}', 'down')" 
                                class="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-white rounded hover:bg-slate-100 dark:hover:bg-slate-700 transition"
                                title="Move down">
                            <i data-lucide="chevron-down" class="w-4 h-4"></i>
                        </button>
                    </div>

                    <!-- Visibility Toggle Button -->
                    <button type="button" 
                            onclick="toggleMgmtUserWidgetStatus('${wid}')"
                            class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${isVisible ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 border border-slate-200 dark:border-slate-700'}">
                        <span class="w-2 h-2 rounded-full ${isVisible ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'}"></span>
                        <span>${isVisible ? 'Visible' : 'Hidden'}</span>
                    </button>
                </div>
            </div>
        `;
    }).join('');

    if (window.lucide) {
        window.lucide.createIcons();
    }
}

function setMgmtUserWidgetWidth(widgetId, width) {
    const item = mgmtUserWidgets.find(w => (w.widget_id === widgetId || w.id === widgetId));
    if (item) {
        item.grid_width = width;
        renderMgmtUserWidgets(mgmtUserWidgets);
    }
}

function toggleMgmtUserWidgetStatus(widgetId) {
    const item = mgmtUserWidgets.find(w => (w.widget_id === widgetId || w.id === widgetId));
    if (item) {
        const cur = (item.is_visible == 1 || item.status == 1 || item.is_visible === true);
        item.is_visible = cur ? 0 : 1;
        item.status = cur ? 0 : 1;
        renderMgmtUserWidgets(mgmtUserWidgets);
    }
}

function nudgeMgmtUserWidget(widgetId, direction) {
    const idx = mgmtUserWidgets.findIndex(w => (w.widget_id === widgetId || w.id === widgetId));
    if (idx === -1) return;

    if (direction === 'up' && idx > 0) {
        const temp = mgmtUserWidgets[idx];
        mgmtUserWidgets[idx] = mgmtUserWidgets[idx - 1];
        mgmtUserWidgets[idx - 1] = temp;
    } else if (direction === 'down' && idx < mgmtUserWidgets.length - 1) {
        const temp = mgmtUserWidgets[idx];
        mgmtUserWidgets[idx] = mgmtUserWidgets[idx + 1];
        mgmtUserWidgets[idx + 1] = temp;
    }
    renderMgmtUserWidgets(mgmtUserWidgets);
}

function saveMgmtUserPreferences() {
    const select = document.getElementById('mgmt-company-user-select');
    const userId = select ? select.value : '';
    if (!userId) {
        showToast('Please select a staff user first.', 'error');
        return;
    }

    const saveBtn = document.getElementById('btn-mgmt-save-user');
    if (saveBtn) {
        saveBtn.disabled = true;
        saveBtn.innerHTML = '<span class="inline-block animate-spin mr-1">⟳</span> Saving...';
    }

    const prefs = {};
    mgmtUserWidgets.forEach((w, idx) => {
        const wid = w.widget_id || w.id;
        const isVisible = (w.is_visible == 1 || w.status == 1 || w.is_visible === true) ? 1 : 0;
        prefs[wid] = {
            status: isVisible,
            is_visible: isVisible,
            grid_width: w.grid_width || 'half',
            sort_order: idx + 1
        };
    });

    const formData = new FormData();
    formData.append('target_user_id', userId);
    formData.append('preferences', JSON.stringify(prefs));
    formData.append(csrfTokenName, csrfTokenHash);

    fetch('<?= base_url('api/dashboard/preferences/save') ?>', {
        method: 'POST',
        headers: getCsrfHeaders(),
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (saveBtn) {
            saveBtn.disabled = false;
            saveBtn.innerHTML = '<i data-lucide="check" class="w-4 h-4"></i><span>Save User Layout</span>';
            if (window.lucide) window.lucide.createIcons();
        }

        if (data.success || data.status === 'success') {
            showToast(data.message || 'Staff layout saved successfully.');
        } else {
            showToast(data.message || 'Failed to save staff layout.', 'error');
        }
    })
    .catch(err => {
        console.error(err);
        if (saveBtn) {
            saveBtn.disabled = false;
            saveBtn.innerHTML = '<i data-lucide="check" class="w-4 h-4"></i><span>Save User Layout</span>';
            if (window.lucide) window.lucide.createIcons();
        }
        showToast('Network error saving staff layout.', 'error');
    });
}

function resetMgmtUserPreferences() {
    const select = document.getElementById('mgmt-company-user-select');
    const userId = select ? select.value : '';
    const userName = select ? (select.options[select.selectedIndex]?.text || 'this user') : 'this user';

    if (!userId) {
        showToast('Please select a staff user first.', 'error');
        return;
    }

    if (!confirm(`Reset layout preferences for ${userName} back to role defaults?`)) {
        return;
    }

    const resetBtn = document.getElementById('btn-mgmt-reset-user');
    if (resetBtn) {
        resetBtn.disabled = true;
    }

    const formData = new FormData();
    formData.append('target_user_id', userId);
    formData.append(csrfTokenName, csrfTokenHash);

    fetch('<?= base_url('api/dashboard/preferences/reset') ?>', {
        method: 'POST',
        headers: getCsrfHeaders(),
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (resetBtn) {
            resetBtn.disabled = false;
        }

        if (data.success || data.status === 'success') {
            showToast(data.message || 'User layout reset to role defaults.');
            loadMgmtUserWidgets(userId);
        } else {
            showToast(data.message || 'Failed to reset user layout.', 'error');
        }
    })
    .catch(err => {
        console.error(err);
        if (resetBtn) {
            resetBtn.disabled = false;
        }
        showToast('Network error resetting user layout.', 'error');
    });
}

// Initialize on DOM load
document.addEventListener('DOMContentLoaded', function() {
    const defaultRole = '<?= esc($defaultActiveRole) ?>';
    const hash = window.location.hash.replace('#', '').trim();
    const saved = localStorage.getItem('ci4_mgmt_active_role_tab');
    const targetRole = hash || saved || defaultRole;
    if (document.getElementById('tab-btn-' + targetRole)) {
        switchRoleTab(targetRole, false);
    } else {
        switchRoleTab(defaultRole, false);
    }

    initializeDragAndDrop();
    if (window.lucide) {
        window.lucide.createIcons();
    }
});
</script>
