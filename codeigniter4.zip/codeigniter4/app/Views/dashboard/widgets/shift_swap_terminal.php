<?php
/**
 * Widget: Shift Exchange & Swap Requests
 * Code: shift_swap_terminal
 * Path: dashboard/widgets/shift_swap_terminal
 */
?>
<div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between h-full">
    <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-3">
        <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 flex items-center justify-center">
                <i data-lucide="repeat" class="w-4 h-4"></i>
            </div>
            <div>
                <h3 class="text-sm font-bold text-slate-900 dark:text-white"><?= esc($widget['title']) ?></h3>
                <p class="text-[11px] text-slate-500 dark:text-slate-400">Peer schedule swaps & coverage changes</p>
            </div>
        </div>
        <span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-mono">
            Roster Conflict Checked
        </span>
    </div>

    <!-- Swaps List -->
    <div class="space-y-2.5 my-auto max-h-56 overflow-y-auto pr-1">
        <div class="p-3 rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 text-xs space-y-2">
            <div class="flex items-center justify-between">
                <span class="font-bold text-slate-800 dark:text-slate-200">Morning Shift ↔ Night Shift Swap</span>
                <span class="px-2 py-0.5 rounded bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 font-bold text-[10px]">
                    Pending Manager
                </span>
            </div>
            <div class="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                <span>Sarah Jenkins (Requester)</span>
                <i data-lucide="arrow-right-left" class="w-3 h-3 text-slate-400"></i>
                <span>David Miller (Receiver)</span>
            </div>
            <div class="text-[10px] text-slate-400 pt-1 border-t border-slate-200/40 dark:border-slate-700/40 flex items-center justify-between">
                <span>Date: <?= esc(date('Y-m-d', strtotime('+2 days'))) ?></span>
                <span class="text-emerald-600 dark:text-emerald-400 font-semibold">Zero Roster Fatigue Conflict</span>
            </div>
        </div>
    </div>

    <div class="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
        <span class="text-[11px] text-slate-400">Automated shift policy verification</span>
        <a href="<?= base_url('attendance/roster') ?>" class="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1">
            Roster Matrix <i data-lucide="arrow-right" class="w-3 h-3"></i>
        </a>
    </div>
</div>
