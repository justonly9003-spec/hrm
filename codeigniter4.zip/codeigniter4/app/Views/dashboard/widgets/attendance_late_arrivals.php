<?php
/**
 * Widget: Today's Late Arrivals List
 */
$logs = $logs ?? ($data['attendance_today_logs'] ?? []);
$stats = $stats ?? ($data['attendance_overview_stats'] ?? []);
$lateCount = (int)($stats['late'] ?? 0);

$lateLogs = array_filter($logs, fn($l) => ($l['status'] ?? '') === 'Late' || (!empty($l['late_minutes']) && (int)$l['late_minutes'] > 0));
if ($lateCount === 0 && !empty($lateLogs)) {
    $lateCount = count($lateLogs);
}
$canViewAllAttendance = (new \App\Services\PermissionService())->hasAccess(session()->get('user_id'), 'attendance', 'view', $role ?? null) && !in_array($role ?? '', ['employee'], true);
?>

<div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-xs space-y-3 w-full h-full flex flex-col justify-between">
    <div>
        <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <h3 class="font-bold text-slate-800 dark:text-white text-sm flex items-center gap-2">
                <i data-lucide="user-x" class="w-4 h-4 text-amber-500"></i>
                <span>Today's Late Arrivals</span>
            </h3>
            <span class="font-mono text-xs text-amber-600 font-bold px-2 py-0.5 rounded-full bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800">
                <?= esc($lateCount) ?> Late
            </span>
        </div>

        <div class="divide-y divide-slate-100 dark:divide-slate-800 max-h-60 overflow-y-auto pr-1">
            <?php if (empty($lateLogs)): ?>
                <div class="py-6 text-center text-slate-400 text-xs">
                    <i data-lucide="smile" class="w-7 h-7 mx-auto mb-1 text-emerald-500 opacity-80"></i>
                    No late arrivals recorded today. High punctuality!
                </div>
            <?php else: ?>
                <?php foreach (array_slice($lateLogs, 0, 5) as $ll): ?>
                    <div class="py-2.5 flex items-center justify-between text-xs">
                        <div>
                            <div class="font-bold text-slate-800 dark:text-white"><?= esc($ll['employee_name'] ?? 'Employee') ?></div>
                            <div class="text-[10px] text-slate-400"><?= esc($ll['department_name'] ?? 'General') ?> &bull; <?= esc($ll['employee_code'] ?? '') ?></div>
                        </div>
                        <div class="text-right">
                            <span class="px-2 py-0.5 rounded bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-400 font-mono text-[10px] font-bold">
                                <?= esc($ll['check_in'] ?? '--:--') ?>
                            </span>
                            <div class="text-[10px] text-amber-600 font-bold">+<?= (int)($ll['late_minutes'] ?? 0) ?>m</div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 flex items-center justify-between mt-2">
        <span>Showing top latest arrivals</span>
        <?php if (!empty($canViewAllAttendance)): ?>
            <a href="<?= base_url('attendance?tab=today&status=Late') ?>" class="text-amber-600 dark:text-amber-400 font-bold hover:underline">
                View All Late &rarr;
            </a>
        <?php endif; ?>
    </div>
</div>
