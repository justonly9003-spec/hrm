<?php
/**
 * Widget: 7-Day Rolling Attendance Trend
 * Code: attendance_trend
 * Path: dashboard/widgets/attendance_trend
 */
$trend = $trend ?? ($data['rolling_attendance_trend'] ?? ($metrics['data']['rolling_attendance_trend'] ?? ($metrics['workforce']['rolling_attendance_trend'] ?? [])));
$totalWorkforce = $metrics['workforce']['total_employees'] ?? 0;
?>
<div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between h-full">
    <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
        <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                <i data-lucide="trending-up" class="w-4 h-4"></i>
            </div>
            <div>
                <h3 class="text-sm font-bold text-slate-900 dark:text-white"><?= esc($widget['title'] ?? '7-Day Attendance Trend') ?></h3>
                <p class="text-[11px] text-slate-500 dark:text-slate-400">Rolling presence, lates & absences</p>
            </div>
        </div>
        <span class="text-[10px] font-bold font-mono px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
            Last 7 Days
        </span>
    </div>

    <!-- Trend Visualizer Bars -->
    <div class="space-y-3 my-auto py-2">
        <?php if (!empty($trend)): ?>
            <div class="grid grid-cols-7 gap-2 items-end h-28 pt-2">
                <?php foreach ($trend as $day): ?>
                    <?php 
                        $pres = (int)($day['present'] ?? 0);
                        $late = (int)($day['late'] ?? 0);
                        $abs  = (int)($day['absent'] ?? 0);
                        $dayTotal = (int)($day['total_active'] ?? ($totalWorkforce > 0 ? $totalWorkforce : 0));
                        $pct  = $dayTotal > 0 ? min(100, round(($pres / $dayTotal) * 100)) : (float)($day['attendance_rate'] ?? 0);
                    ?>
                    <div class="flex flex-col items-center gap-1.5 h-full justify-end group" title="<?= esc($day['date'] ?? '') ?>: Present <?= $pres ?>, Late <?= $late ?>, Absent <?= $abs ?>, Leave <?= (int)($day['on_leave'] ?? 0) ?> (<?= $pct ?>%)">
                        <div class="text-[9px] font-mono text-slate-400 group-hover:text-slate-700 dark:group-hover:text-slate-200 transition">
                            <?= esc($pres) ?>
                        </div>
                        <div class="w-full bg-slate-100 dark:bg-slate-800 rounded-md overflow-hidden flex flex-col justify-end h-20 relative">
                            <div class="w-full bg-emerald-500 rounded-t-sm transition-all duration-500 group-hover:bg-emerald-400" style="height: <?= $pct ?>%;"></div>
                        </div>
                        <span class="text-[10px] font-semibold text-slate-600 dark:text-slate-400"><?= esc($day['label']) ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-6 text-xs text-slate-400">No trend data available for current range</div>
        <?php endif; ?>
    </div>

    <div class="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
        <div class="flex items-center gap-4 text-[11px] text-slate-500">
            <span class="flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-emerald-500"></span> Present</span>
            <span class="flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-amber-500"></span> Late</span>
            <span class="flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-rose-500"></span> Absent</span>
        </div>
        <a href="<?= base_url('attendance') ?>" class="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1">
            Logs <i data-lucide="arrow-right" class="w-3 h-3"></i>
        </a>
    </div>
</div>
