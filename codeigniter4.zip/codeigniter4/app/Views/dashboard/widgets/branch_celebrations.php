<?php
/**
 * Widget: Branch Celebrations & Milestones
 * Code: branch_celebrations
 * Path: dashboard/widgets/branch_celebrations
 */
$todayBirthdays = $metrics['data']['today_birthdays'] ?? [];
$upcomingBirthdays = $metrics['data']['upcoming_birthdays'] ?? [];
$todayAnniversaries = $metrics['data']['today_anniversaries'] ?? [];
$upcomingAnniversaries = $metrics['data']['upcoming_anniversaries'] ?? [];

$hasToday = !empty($todayBirthdays) || !empty($todayAnniversaries);
?>
<div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between h-full"
     x-data="{ tab: 'birthdays' }">
    <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-3">
        <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-pink-50 dark:bg-pink-950/60 text-pink-600 dark:text-pink-400 flex items-center justify-center">
                <i data-lucide="party-popper" class="w-4 h-4"></i>
            </div>
            <div>
                <h3 class="text-sm font-bold text-slate-900 dark:text-white"><?= esc($widget['title']) ?></h3>
                <p class="text-[11px] text-slate-500 dark:text-slate-400">Team birthdays & work milestones</p>
            </div>
        </div>
        
        <!-- Tab selector -->
        <div class="flex p-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-[11px] font-bold">
            <button type="button" @click="tab = 'birthdays'" :class="tab === 'birthdays' ? 'bg-white dark:bg-slate-700 text-pink-600 dark:text-pink-400 shadow-2xs' : 'text-slate-500'" class="px-2.5 py-1 rounded-md transition">
                Birthdays (<?= count($todayBirthdays) + count($upcomingBirthdays) ?>)
            </button>
            <button type="button" @click="tab = 'anniversaries'" :class="tab === 'anniversaries' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-2xs' : 'text-slate-500'" class="px-2.5 py-1 rounded-md transition">
                Anniversaries (<?= count($todayAnniversaries) + count($upcomingAnniversaries) ?>)
            </button>
        </div>
    </div>

    <!-- Tab 1: Birthdays -->
    <div x-show="tab === 'birthdays'" class="space-y-2.5 my-auto max-h-56 overflow-y-auto pr-1">
        <?php if (!empty($todayBirthdays)): ?>
            <div class="p-3 rounded-xl bg-pink-50/70 dark:bg-pink-950/40 border border-pink-200/80 dark:border-pink-900/60 mb-2">
                <div class="flex items-center gap-2 text-pink-700 dark:text-pink-300 font-extrabold text-xs mb-2">
                    <i data-lucide="cake" class="w-3.5 h-3.5"></i>
                    <span>TODAY'S CELEBRATION!</span>
                </div>
                <?php foreach ($todayBirthdays as $b): ?>
                    <div class="flex items-center justify-between text-xs py-1">
                        <span class="font-bold text-slate-900 dark:text-white"><?= esc(trim(($b['first_name'] ?? '') . ' ' . ($b['last_name'] ?? ''))) ?></span>
                        <span class="text-[10px] font-bold text-pink-600 dark:text-pink-400 font-mono">Happy Birthday! 🎉</span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($upcomingBirthdays)): ?>
            <div class="divide-y divide-slate-100 dark:divide-slate-800/60 text-xs">
                <?php foreach ($upcomingBirthdays as $b): ?>
                    <div class="py-2 first:pt-0 flex items-center justify-between">
                        <div class="flex items-center gap-2">
                            <div class="w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-bold text-[9px] text-slate-600 dark:text-slate-300">
                                <?= esc(strtoupper(substr($b['first_name'] ?? 'U', 0, 1))) ?>
                            </div>
                            <span class="font-semibold text-slate-700 dark:text-slate-300"><?= esc(trim(($b['first_name'] ?? '') . ' ' . ($b['last_name'] ?? ''))) ?></span>
                        </div>
                        <span class="text-[10px] font-mono text-slate-400"><?= esc($b['bday_month_day'] ?? '') ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php elseif (empty($todayBirthdays)): ?>
            <div class="text-center py-6 text-xs text-slate-400">
                <i data-lucide="calendar-heart" class="w-6 h-6 mx-auto mb-1 text-slate-300 dark:text-slate-600"></i>
                No upcoming birthdays in next 30 days
            </div>
        <?php endif; ?>
    </div>

    <!-- Tab 2: Anniversaries -->
    <div x-show="tab === 'anniversaries'" class="space-y-2.5 my-auto max-h-56 overflow-y-auto pr-1" style="display: none;">
        <?php if (!empty($todayAnniversaries)): ?>
            <div class="p-3 rounded-xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200/80 dark:border-indigo-900/60 mb-2">
                <div class="flex items-center gap-2 text-indigo-700 dark:text-indigo-300 font-extrabold text-xs mb-2">
                    <i data-lucide="award" class="w-3.5 h-3.5"></i>
                    <span>WORK ANNIVERSARY TODAY!</span>
                </div>
                <?php foreach ($todayAnniversaries as $a): ?>
                    <div class="flex items-center justify-between text-xs py-1">
                        <span class="font-bold text-slate-900 dark:text-white"><?= esc(trim(($a['first_name'] ?? '') . ' ' . ($a['last_name'] ?? ''))) ?></span>
                        <span class="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 font-mono">Cheers to milestones! 🏆</span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($upcomingAnniversaries)): ?>
            <div class="divide-y divide-slate-100 dark:divide-slate-800/60 text-xs">
                <?php foreach ($upcomingAnniversaries as $a): ?>
                    <div class="py-2 first:pt-0 flex items-center justify-between">
                        <div class="flex items-center gap-2">
                            <div class="w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-bold text-[9px] text-slate-600 dark:text-slate-300">
                                <?= esc(strtoupper(substr($a['first_name'] ?? 'U', 0, 1))) ?>
                            </div>
                            <span class="font-semibold text-slate-700 dark:text-slate-300"><?= esc(trim(($a['first_name'] ?? '') . ' ' . ($a['last_name'] ?? ''))) ?></span>
                        </div>
                        <span class="text-[10px] font-mono text-slate-400"><?= esc($a['anniv_month_day'] ?? '') ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php elseif (empty($todayAnniversaries)): ?>
            <div class="text-center py-6 text-xs text-slate-400">
                <i data-lucide="award" class="w-6 h-6 mx-auto mb-1 text-slate-300 dark:text-slate-600"></i>
                No work anniversaries in next 30 days
            </div>
        <?php endif; ?>
    </div>

    <div class="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
        <span class="text-[11px] text-slate-400">Branch milestone tracker</span>
        <a href="<?= base_url('employees') ?>" class="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1">
            Directory <i data-lucide="arrow-right" class="w-3 h-3"></i>
        </a>
    </div>
</div>
