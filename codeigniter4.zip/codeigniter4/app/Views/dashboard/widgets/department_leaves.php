<?php
/**
 * Widget: Department Colleagues on Leave
 * Code: department_leaves
 * Path: dashboard/widgets/department_leaves
 */
$deptLeaves = $metrics['data']['dept_leaves_today'] ?? [];
$myDeptName = $metrics['employee_profile']['department_name'] ?? 'Your Department';
?>
<div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between h-full">
    <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-3">
        <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                <i data-lucide="user-minus" class="w-4 h-4"></i>
            </div>
            <div>
                <h3 class="text-sm font-bold text-slate-900 dark:text-white"><?= esc($widget['title']) ?></h3>
                <p class="text-[11px] text-slate-500 dark:text-slate-400">Teammates away in <?= esc($myDeptName) ?></p>
            </div>
        </div>
        <span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-mono">
            <?= count($deptLeaves) ?> Away Today
        </span>
    </div>

    <!-- Leaves list with privacy masking -->
    <div class="space-y-2.5 my-auto max-h-56 overflow-y-auto pr-1">
        <?php if (!empty($deptLeaves)): ?>
            <div class="divide-y divide-slate-100 dark:divide-slate-800/60 text-xs">
                <?php foreach ($deptLeaves as $leave): ?>
                    <?php 
                        $fullName = trim(($leave['first_name'] ?? '') . ' ' . ($leave['last_name'] ?? '')) ?: 'Colleague';
                    ?>
                    <div class="py-2.5 first:pt-0 flex items-center justify-between">
                        <div class="flex items-center gap-2.5">
                            <div class="w-7 h-7 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold text-[10px]">
                                <?= esc(strtoupper(substr($fullName, 0, 1))) ?>
                            </div>
                            <div>
                                <span class="font-bold text-slate-800 dark:text-slate-200 block"><?= esc($fullName) ?></span>
                                <span class="text-[10px] text-slate-400 block"><?= esc($leave['designation'] ?? 'Team Member') ?></span>
                            </div>
                        </div>
                        <div class="text-right">
                            <span class="px-2 py-0.5 rounded-md bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 text-[10px] font-bold uppercase tracking-wider">
                                On Leave
                            </span>
                            <span class="block text-[10px] font-mono text-slate-400 mt-0.5">Returns <?= esc($leave['return_date'] ?? 'Tomorrow') ?></span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-8 text-xs text-slate-400">
                <i data-lucide="users" class="w-6 h-6 mx-auto mb-2 text-slate-300 dark:text-slate-600"></i>
                All department team members are available today
            </div>
        <?php endif; ?>
    </div>

    <div class="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
        <span class="text-[11px] text-slate-400">Privacy protected view</span>
        <a href="<?= base_url('leave') ?>" class="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1">
            Leave Hub <i data-lucide="arrow-right" class="w-3 h-3"></i>
        </a>
    </div>
</div>
