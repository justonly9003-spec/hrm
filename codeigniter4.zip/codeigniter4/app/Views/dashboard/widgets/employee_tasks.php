<?php
/**
 * Widget: Personal Tasks & To-Do Checklist
 * Code: employee_tasks
 * Path: dashboard/widgets/employee_tasks
 */
$tasks = [
    ['id' => 1, 'text' => 'Review and submit end-of-month timesheet', 'priority' => 'high', 'due' => 'Today', 'done' => false],
    ['id' => 2, 'text' => 'Complete quarterly safety compliance module', 'priority' => 'medium', 'due' => 'In 2 days', 'done' => false],
    ['id' => 3, 'text' => 'Verify emergency contact details on employee profile', 'priority' => 'low', 'due' => 'This week', 'done' => true],
    ['id' => 4, 'text' => 'Acknowledge company updated Code of Conduct', 'priority' => 'medium', 'due' => 'Friday', 'done' => false],
];
?>
<div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between h-full"
     x-data="{ 
         tasks: <?= htmlspecialchars(json_encode($tasks), ENT_QUOTES, 'UTF-8') ?>,
         toggleTask(id) {
             const t = this.tasks.find(item => item.id === id);
             if (t) t.done = !t.done;
         }
     }">
    <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-3">
        <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 flex items-center justify-center">
                <i data-lucide="check-square" class="w-4 h-4"></i>
            </div>
            <div>
                <h3 class="text-sm font-bold text-slate-900 dark:text-white"><?= esc($widget['title']) ?></h3>
                <p class="text-[11px] text-slate-500 dark:text-slate-400">Workplace action items & reminders</p>
            </div>
        </div>
        <span class="text-[10px] font-bold font-mono px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
            <span x-text="tasks.filter(t => !t.done).length"></span> Pending
        </span>
    </div>

    <!-- Task list -->
    <div class="space-y-2 my-auto max-h-56 overflow-y-auto pr-1 divide-y divide-slate-100 dark:divide-slate-800/60">
        <template x-for="task in tasks" :key="task.id">
            <div class="pt-2 first:pt-0 flex items-center justify-between gap-3 text-xs group">
                <label class="flex items-center gap-2.5 cursor-pointer select-none min-w-0">
                    <input type="checkbox" :checked="task.done" @change="toggleTask(task.id)" class="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 dark:border-slate-700 dark:bg-slate-800">
                    <span :class="task.done ? 'line-through text-slate-400 dark:text-slate-500' : 'text-slate-800 dark:text-slate-200 font-semibold'" class="text-xs truncate" x-text="task.text"></span>
                </label>
                <div class="flex items-center gap-2 shrink-0">
                    <span :class="{
                        'bg-rose-50 text-rose-600 dark:bg-rose-950/60 dark:text-rose-400': task.priority === 'high',
                        'bg-amber-50 text-amber-600 dark:bg-amber-950/60 dark:text-amber-400': task.priority === 'medium',
                        'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400': task.priority === 'low'
                    }" class="px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider font-mono" x-text="task.priority"></span>
                    <span class="text-[10px] font-mono text-slate-400" x-text="task.due"></span>
                </div>
            </div>
        </template>
    </div>

    <div class="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
        <span class="text-[11px] text-slate-400">Synced to user profile</span>
        <button type="button" @click="tasks.push({ id: Date.now(), text: 'New assigned priority item', priority: 'medium', due: 'Pending', done: false })" class="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1">
            <i data-lucide="plus" class="w-3 h-3"></i> Add Quick Task
        </button>
    </div>
</div>
