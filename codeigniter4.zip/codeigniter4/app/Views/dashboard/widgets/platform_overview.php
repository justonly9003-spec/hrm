<div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-xs flex flex-col justify-between h-full">
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100 dark:border-slate-800">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-100 dark:border-indigo-800 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
                <i data-lucide="building-2" class="w-5 h-5"></i>
            </div>
            <div>
                <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Multi-Tenant Platform KPIs</h3>
                <p class="text-xs text-slate-500 dark:text-slate-400">Global tenant accounts, subscription metrics & platform health</p>
            </div>
        </div>
        <div class="flex items-center gap-2">
            <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200/60 dark:border-emerald-800/60">
                <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                Platform Operational
            </span>
        </div>
    </div>

    <!-- Metric Cards Grid -->
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 pt-5">
        <!-- Active Companies -->
        <div class="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 border border-slate-100 dark:border-slate-800">
            <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Tenant Fleets</span>
                <div class="p-1.5 rounded-lg bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400">
                    <i data-lucide="building" class="w-4 h-4"></i>
                </div>
            </div>
            <div class="mt-2 flex items-baseline gap-2">
                <span class="text-2xl font-black text-slate-900 dark:text-white"><?= esc($metrics['platform']['total_companies'] ?? 0) ?></span>
                <span class="text-xs font-semibold text-emerald-600 dark:text-emerald-400"><?= esc($metrics['platform']['active_companies'] ?? 0) ?> active</span>
            </div>
            <div class="mt-1 text-[11px] text-slate-400">100% Tenant Isolation</div>
        </div>

        <!-- Total Platform Workforce -->
        <div class="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 border border-slate-100 dark:border-slate-800">
            <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Total Workforce</span>
                <div class="p-1.5 rounded-lg bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400">
                    <i data-lucide="users" class="w-4 h-4"></i>
                </div>
            </div>
            <div class="mt-2 flex items-baseline gap-2">
                <span class="text-2xl font-black text-slate-900 dark:text-white"><?= esc($metrics['platform']['total_workforce'] ?? 0) ?></span>
                <span class="text-xs font-medium text-slate-500">employees</span>
            </div>
            <div class="mt-1 text-[11px] text-slate-400">Across all organizations</div>
        </div>

        <!-- User Accounts & Roles -->
        <div class="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 border border-slate-100 dark:border-slate-800">
            <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">RBAC Accounts</span>
                <div class="p-1.5 rounded-lg bg-purple-100 dark:bg-purple-900/50 text-purple-600 dark:text-purple-400">
                    <i data-lucide="shield-check" class="w-4 h-4"></i>
                </div>
            </div>
            <div class="mt-2 flex items-baseline gap-2">
                <span class="text-2xl font-black text-slate-900 dark:text-white"><?= esc($metrics['platform']['total_user_accounts'] ?? 0) ?></span>
                <span class="text-xs font-semibold text-purple-600 dark:text-purple-400">9 System Roles</span>
            </div>
            <div class="mt-1 text-[11px] text-slate-400">Granular role permissions</div>
        </div>

        <!-- Estimated Platform MRR -->
        <div class="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 border border-slate-100 dark:border-slate-800">
            <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Estimated MRR</span>
                <div class="p-1.5 rounded-lg bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400">
                    <i data-lucide="dollar-sign" class="w-4 h-4"></i>
                </div>
            </div>
            <div class="mt-2 flex items-baseline gap-2">
                <span class="text-2xl font-black text-slate-900 dark:text-white">$<?= number_format((float)($metrics['platform']['monthly_mrr'] ?? 0), 2) ?></span>
            </div>
            <div class="mt-1 text-[11px] text-emerald-600 dark:text-emerald-400 font-medium">Enterprise & Pro tiers</div>
        </div>
    </div>
</div>
