<div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-xs flex flex-col justify-between h-full">
    <div>
        <div class="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-950/60 border border-purple-100 dark:border-purple-800 flex items-center justify-center text-purple-600 dark:text-purple-400">
                    <i data-lucide="pie-chart" class="w-5 h-5"></i>
                </div>
                <div>
                    <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Departmental Distribution</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Business units, active staff, and organizational structure</p>
                </div>
            </div>
            <a href="<?= base_url('master/departments') ?>" class="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1">
                <span>Manage</span>
                <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
            </a>
        </div>

        <div class="mt-4 space-y-3">
            <?php 
                $depts = $metrics['workforce']['departments'] ?? [];
                if (empty($depts)):
            ?>
                <div class="py-6 text-center text-xs text-slate-400">No departments configured yet.</div>
            <?php else: ?>
                <?php foreach (array_slice($depts, 0, 4) as $d): ?>
                    <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <div class="w-8 h-8 rounded-lg bg-purple-100 dark:bg-purple-900/50 text-purple-700 dark:text-purple-300 font-bold text-xs flex items-center justify-center">
                                <?= strtoupper(substr($d['name'] ?? 'D', 0, 2)) ?>
                            </div>
                            <div>
                                <div class="text-xs font-bold text-slate-900 dark:text-white"><?= esc($d['name'] ?? 'Department') ?></div>
                                <div class="text-[11px] text-slate-400">Code: <?= esc($d['code'] ?? 'N/A') ?></div>
                            </div>
                        </div>
                        <span class="text-xs font-bold text-slate-700 dark:text-slate-300 px-2 py-1 bg-white dark:bg-slate-700 rounded-lg border border-slate-200/60 dark:border-slate-600">
                            Active
                        </span>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="pt-4 border-t border-slate-100 dark:border-slate-800 mt-4 flex items-center justify-between text-xs">
        <span class="text-slate-500">Total Units: <strong class="text-slate-800 dark:text-white"><?= count($depts) ?></strong></span>
        <a href="<?= base_url('employees') ?>" class="text-indigo-600 dark:text-indigo-400 font-bold hover:underline">
            View Staff Directory →
        </a>
    </div>
</div>
