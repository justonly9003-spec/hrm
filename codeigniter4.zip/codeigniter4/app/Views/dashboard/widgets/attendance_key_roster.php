<?php
/**
 * Widget: Key Employee Attendance Roster / Live Muster Stream
 */
$employees = $employees ?? ($data['attendance_employees'] ?? ($data['all_employees'] ?? []));
$logs = $logs ?? ($data['attendance_today_logs'] ?? []);
$canViewProfiles = (new \App\Services\PermissionService())->hasAccess(session()->get('user_id'), 'employees', 'view', $role ?? null);
?>

<div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-6 shadow-xs space-y-4 flex flex-col justify-between h-full w-full">
    <div class="space-y-3">
        <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <div>
                <h3 class="font-bold text-slate-900 dark:text-white text-sm">Key Employee Roster</h3>
                <p class="text-[11px] text-slate-400">Real-time punch arrivals and status</p>
            </div>
            <span class="text-xs text-slate-400 font-mono"><?= count($employees) ?> staff</span>
        </div>

        <div class="space-y-2 max-h-[380px] overflow-y-auto pr-1">
            <?php 
            $previewEmps = array_slice($employees, 0, 8);
            foreach ($previewEmps as $emp):
                // Find matching log
                $matchingLog = null;
                foreach ($logs as $l) {
                    if (($l['employee_id'] ?? '') === ($emp['id'] ?? '') || ($l['employee_code'] ?? '') === ($emp['employee_code'] ?? '')) {
                        $matchingLog = $l;
                        break;
                    }
                }
                $statusText = $matchingLog['status'] ?? 'Absent';
                $checkInDisplay = !empty($matchingLog['check_in']) ? substr($matchingLog['check_in'], 0, 5) : '--:--';
                $empName = trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')) ?: ($emp['name'] ?? $emp['employee_code'] ?? 'Staff');
            ?>
                <div 
                    <?php if (!empty($canViewProfiles)): ?>
                        @click="typeof viewEmployee === 'function' ? viewEmployee('<?= esc($emp['id'] ?? '') ?>') : window.location.href='<?= base_url('employee/profile/' . esc($emp['id'] ?? '')) ?>'"
                        class="flex items-center justify-between p-2.5 hover:bg-slate-50 dark:hover:bg-slate-800/80 rounded-2xl border border-transparent hover:border-slate-200 dark:hover:border-slate-700 transition cursor-pointer"
                    <?php else: ?>
                        class="flex items-center justify-between p-2.5 rounded-2xl border border-transparent"
                    <?php endif; ?>
                >
                    <div class="flex items-center gap-2.5">
                        <div class="w-8 h-8 rounded-full overflow-hidden bg-slate-100 dark:bg-slate-800 shrink-0">
                            <img src="<?= esc(!empty($emp['photo']) ? $emp['photo'] : (!empty($emp['avatar']) ? $emp['avatar'] : base_url('assets/images/avatar-placeholder.svg'))) ?>" alt="<?= esc($empName) ?>" class="w-full h-full object-cover" />
                        </div>
                        <div>
                            <div class="font-bold text-slate-900 dark:text-white text-xs leading-tight"><?= esc($empName) ?></div>
                            <div class="text-[10px] text-slate-400 font-mono"><?= esc($emp['employee_code'] ?? $emp['id'] ?? '') ?> &bull; <?= esc($checkInDisplay) ?></div>
                        </div>
                    </div>

                    <span class="px-2 py-0.5 rounded-full text-[10px] font-bold <?= 
                        in_array($statusText, ['Present', 'Present (Early Closure)', 'Early Closure Covered', 'Approved Early Closure', 'Off-Day Work', 'Weekend Duty Present', 'Holiday Duty Present'], true) ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400' :
                        ($statusText === 'Late' ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400' :
                        ($statusText === 'On Leave' || $statusText === 'Paid Leave' ? 'bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-400' :
                        'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400'))
                    ?>">
                        <?= esc($statusText) ?>
                    </span>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <?php if (!empty($canViewProfiles)): ?>
        <button
            type="button"
            @click="typeof setTab === 'function' ? setTab('employee') : window.location.href='<?= base_url('attendance?tab=employee') ?>'"
            class="w-full py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-2xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer mt-3"
        >
            <span>Open Individual Employee Tracker</span>
            <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
        </button>
    <?php endif; ?>
</div>
