<?php
/**
 * Widget: Department-Wise Attendance Breakdown
 */
$deptBreakdown = $deptBreakdown ?? ($data['attendance_dept_breakdown'] ?? []);
$date = $date ?? ($data['today'] ?? date('Y-m-d'));
$canViewGroupTab = (new \App\Services\PermissionService())->hasAccess(session()->get('user_id'), 'attendance', 'view', $role ?? null) && !in_array($role ?? '', ['employee'], true);
?>

<div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-6 shadow-xs space-y-4 w-full h-full flex flex-col justify-between">
    <div class="space-y-4">
        <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <div>
                <h3 class="font-bold text-slate-900 dark:text-white text-sm">Department-Wise Attendance Breakdown</h3>
                <p class="text-xs text-slate-500 dark:text-slate-400">Live attendance rate and punctuality by organizational unit</p>
            </div>
            <?php if (!empty($canViewGroupTab)): ?>
                <button
                    type="button"
                    @click="typeof setTab === 'function' ? setTab('group') : window.location.href='<?= base_url('attendance?tab=group') ?>'"
                    class="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 flex items-center gap-1 cursor-pointer"
                >
                    <span>View Full Group Table</span>
                    <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
                </button>
            <?php endif; ?>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 max-h-[420px] overflow-y-auto pr-1">
            <?php if (empty($deptBreakdown)): ?>
                <div class="col-span-2 py-8 text-center text-slate-400 text-xs">
                    No department attendance records found for this date.
                </div>
            <?php else: ?>
                <?php foreach ($deptBreakdown as $db): ?>
                    <div class="bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 rounded-2xl p-4 space-y-3">
                        <div class="flex items-center justify-between">
                            <span class="font-bold text-slate-900 dark:text-white text-xs"><?= esc($db['name'] ?? 'Department') ?></span>
                            <span class="text-[10px] font-mono font-bold bg-white dark:bg-slate-900 px-2 py-0.5 rounded-full border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300">
                                <?= (int)($db['total'] ?? 0) ?> staff
                            </span>
                        </div>

                        <div class="space-y-1.5">
                            <div class="flex items-center justify-between text-xs">
                                <span class="text-slate-500 dark:text-slate-400">Presence Rate</span>
                                <span class="font-bold font-mono text-indigo-600 dark:text-indigo-400"><?= (int)($db['rate'] ?? 0) ?>%</span>
                            </div>
                            <div class="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                                <div class="bg-indigo-600 h-full rounded-full transition-all duration-500" style="width: <?= min(100, max(0, (float)($db['rate'] ?? 0))) ?>%"></div>
                            </div>
                        </div>

                        <div class="grid grid-cols-4 gap-1 text-center pt-2 border-t border-slate-200/70 dark:border-slate-700/70 text-[10px]">
                            <div class="bg-white dark:bg-slate-900 p-1.5 rounded-lg border border-slate-200/60 dark:border-slate-800">
                                <span class="text-slate-400 block font-semibold">Present</span>
                                <span class="font-bold font-mono text-emerald-600"><?= (int)($db['present'] ?? 0) ?></span>
                            </div>
                            <div class="bg-white dark:bg-slate-900 p-1.5 rounded-lg border border-slate-200/60 dark:border-slate-800">
                                <span class="text-slate-400 block font-semibold">Late</span>
                                <span class="font-bold font-mono text-amber-600"><?= (int)($db['late'] ?? 0) ?></span>
                            </div>
                            <div class="bg-white dark:bg-slate-900 p-1.5 rounded-lg border border-slate-200/60 dark:border-slate-800">
                                <span class="text-slate-400 block font-semibold">Leave</span>
                                <span class="font-bold font-mono text-purple-600"><?= (int)($db['leave'] ?? 0) ?></span>
                            </div>
                            <div class="bg-white dark:bg-slate-900 p-1.5 rounded-lg border border-slate-200/60 dark:border-slate-800">
                                <span class="text-slate-400 block font-semibold">Absent</span>
                                <span class="font-bold font-mono text-rose-600"><?= (int)($db['absent'] ?? 0) ?></span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
        <span>Total Units: <strong><?= count($deptBreakdown) ?> Departments</strong></span>
        <?php if (!empty($canViewGroupTab)): ?>
            <a href="<?= base_url('attendance?tab=group') ?>" class="text-indigo-600 dark:text-indigo-400 font-bold hover:underline">
                View Analytics &rarr;
            </a>
        <?php endif; ?>
    </div>
</div>
