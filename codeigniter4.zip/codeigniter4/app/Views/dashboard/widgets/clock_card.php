<div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-xs flex flex-col justify-between h-full">
    <div>
        <div class="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-100 dark:border-emerald-800 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                    <i data-lucide="clock" class="w-5 h-5"></i>
                </div>
                <div>
                    <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Live Attendance & Punch Card</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Record daily clock in/out and view working hours</p>
                </div>
            </div>
            <span class="text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2.5 py-1 rounded-full border border-emerald-200 dark:border-emerald-800">
                <?= date('D, M d, Y') ?>
            </span>
        </div>

        <?php 
            $myAtt = $data['my_attendance_today'] ?? ($metrics['workforce']['my_attendance_today'] ?? null);
            $hasClockedIn = !empty($myAtt['in_time']) || (!empty($myAtt['status']) && in_array($myAtt['status'], ['Present', 'Late', 'Half Day']));
            $inTime = !empty($myAtt['in_time']) ? $myAtt['in_time'] : ($hasClockedIn ? 'Clocked In' : '--:--');
            $outTime = !empty($myAtt['out_time']) ? $myAtt['out_time'] : '--:--';
        ?>

        <div class="mt-4 grid grid-cols-2 gap-3">
            <div class="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Clock In</div>
                <div class="text-lg font-black text-slate-900 dark:text-white mt-1"><?= esc($inTime) ?></div>
                <?php if ($hasClockedIn): ?>
                    <div class="text-[11px] text-emerald-600 font-semibold mt-0.5">Biometric Verified</div>
                <?php else: ?>
                    <div class="text-[11px] text-amber-500 font-semibold mt-0.5">Not Clocked In Yet</div>
                <?php endif; ?>
            </div>
            <div class="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Clock Out</div>
                <div class="text-lg font-black text-slate-900 dark:text-white mt-1"><?= esc($outTime) ?></div>
                <div class="text-[11px] text-slate-400 mt-0.5"><?= !empty($myAtt['shift_name']) ? esc($myAtt['shift_name']) : 'Shift: Scheduled' ?></div>
            </div>
        </div>
    </div>

    <div class="pt-4 border-t border-slate-100 dark:border-slate-800 mt-4 flex items-center justify-between">
        <a href="<?= base_url('attendance') ?>" class="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline">
            View Monthly Attendance History →
        </a>
        <a href="<?= base_url('attendance') ?>" class="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition inline-flex items-center gap-1">
            <i data-lucide="fingerprint" class="w-3.5 h-3.5"></i>
            <span>Punch Clock</span>
        </a>
    </div>
</div>
