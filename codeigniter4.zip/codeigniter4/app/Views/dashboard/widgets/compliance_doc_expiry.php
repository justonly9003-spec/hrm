<?php
/**
 * Widget: Document Expiry & Compliance Alerts
 * Code: compliance_doc_expiry
 * Path: dashboard/widgets/compliance_doc_expiry
 */
$expiringDocs = [
    ['employee' => 'Michael Chen', 'doc' => 'Labor Contract Renewal', 'days' => 14, 'level' => 'critical'],
    ['employee' => 'Emily Watson', 'doc' => 'Work Permit & Visa Extension', 'days' => 28, 'level' => 'warning'],
    ['employee' => 'Sarah Jenkins', 'doc' => 'Health & Safety Certification', 'days' => 45, 'level' => 'info'],
];
?>
<div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between h-full">
    <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-3">
        <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center">
                <i data-lucide="alert-triangle" class="w-4 h-4"></i>
            </div>
            <div>
                <h3 class="text-sm font-bold text-slate-900 dark:text-white"><?= esc($widget['title']) ?></h3>
                <p class="text-[11px] text-slate-500 dark:text-slate-400">Visas, contracts & certifications within 60 days</p>
            </div>
        </div>
        <span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 font-mono">
            <?= count($expiringDocs) ?> Action Required
        </span>
    </div>

    <!-- Expiring List -->
    <div class="space-y-2.5 my-auto max-h-56 overflow-y-auto pr-1">
        <?php foreach ($expiringDocs as $doc): ?>
            <div class="p-3 rounded-xl border <?= $doc['level'] === 'critical' ? 'border-rose-200/80 dark:border-rose-900/60 bg-rose-50/50 dark:bg-rose-950/20' : 'border-slate-200/80 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30' ?> text-xs flex items-center justify-between">
                <div>
                    <span class="font-bold text-slate-800 dark:text-slate-200 block"><?= esc($doc['doc']) ?></span>
                    <span class="text-[10px] text-slate-500 dark:text-slate-400 block mt-0.5">Staff: <strong><?= esc($doc['employee']) ?></strong></span>
                </div>
                <div class="text-right">
                    <span class="font-mono font-bold text-xs <?= $doc['level'] === 'critical' ? 'text-rose-600 dark:text-rose-400' : 'text-amber-600 dark:text-amber-400' ?> block">
                        <?= esc($doc['days']) ?> days
                    </span>
                    <span class="text-[9px] uppercase font-bold text-slate-400 block">Remaining</span>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
        <span class="text-[11px] text-slate-400">Statutory labor compliance</span>
        <a href="<?= base_url('employees') ?>" class="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1">
            Documents Registry <i data-lucide="arrow-right" class="w-3 h-3"></i>
        </a>
    </div>
</div>
