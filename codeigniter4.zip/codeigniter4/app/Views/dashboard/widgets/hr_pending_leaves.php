<div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-xs flex flex-col justify-between h-full">
    <div>
        <div class="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/60 border border-amber-100 dark:border-amber-800 flex items-center justify-center text-amber-600 dark:text-amber-400">
                    <i data-lucide="inbox" class="w-5 h-5"></i>
                </div>
                <div>
                    <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Leave Applications Queue</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Applications submitted by staff requiring HR verification</p>
                </div>
            </div>
            <a href="<?= base_url('leave') ?>" class="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1">
                <span>View Full Queue</span>
                <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
            </a>
        </div>

        <div class="mt-4 space-y-3">
            <?php 
                $pending = $metrics['workforce']['pending_leaves'] ?? [];
                if (empty($pending)):
            ?>
                <div class="p-6 text-center text-xs text-slate-400 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-dashed border-slate-200 dark:border-slate-700">
                    <i data-lucide="check-check" class="w-6 h-6 text-emerald-500 mx-auto mb-1.5"></i>
                    No pending leave applications at this time!
                </div>
            <?php else: ?>
                <?php foreach (array_slice($pending, 0, 4) as $req): ?>
                    <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <div class="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300 font-bold text-xs flex items-center justify-center">
                                <?= strtoupper(substr($req['employee_name'] ?? 'S', 0, 2)) ?>
                            </div>
                            <div>
                                <div class="text-xs font-bold text-slate-900 dark:text-white"><?= esc($req['employee_name'] ?? 'Employee') ?></div>
                                <div class="text-[11px] text-slate-500">
                                    <?= esc($req['from_date']) ?> → <?= esc($req['to_date']) ?> • <span class="text-amber-600 font-semibold"><?= esc($req['days'] ?? 1) ?> days</span>
                                </div>
                            </div>
                        </div>
                        <a href="<?= base_url('leave') ?>" class="px-3 py-1.5 text-xs font-bold rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition">
                            Action
                        </a>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="pt-4 border-t border-slate-100 dark:border-slate-800 mt-4 flex items-center justify-between text-xs">
        <span class="text-slate-500">Total Pending: <strong class="text-amber-600"><?= count($pending) ?></strong></span>
        <a href="<?= base_url('leave?action=apply') ?>" class="text-indigo-600 dark:text-indigo-400 font-bold hover:underline">
            + Log Manual Leave
        </a>
    </div>
</div>
