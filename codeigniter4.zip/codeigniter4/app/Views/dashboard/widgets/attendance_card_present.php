<?php
/**
 * Widget: Today's Workforce Presence (Single Metric Card)
 */
$stats = $stats ?? ($data['attendance_overview_stats'] ?? []);
$employees = $employees ?? ($data['attendance_employees'] ?? ($data['all_employees'] ?? []));

$totalActive = (int)($stats['totalActive'] ?? $stats['totalEmployees'] ?? count($employees));
$present = (int)($stats['present'] ?? 0);
$presenceRate = $stats['presenceRate'] ?? ($totalActive > 0 ? round(($present / $totalActive) * 100) : 0);
?>

<div class="bg-white dark:bg-slate-900 border border-emerald-100 dark:border-emerald-950/60 rounded-2xl p-5 shadow-xs flex flex-col justify-between h-full">
    <div>
        <div class="flex items-center justify-between text-emerald-600 mb-2">
            <span class="text-[11px] font-bold uppercase tracking-wider">Today's Presence</span>
            <div class="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 flex items-center justify-center">
                <i data-lucide="check-circle-2" class="w-4 h-4 text-emerald-500"></i>
            </div>
        </div>
        <div class="flex items-baseline gap-2">
            <span class="text-3xl font-black text-emerald-600 font-mono"><?= esc($present) ?></span>
            <span class="text-xs text-slate-400 font-medium">/ <?= esc($totalActive) ?> Staff</span>
        </div>
        <div class="mt-3 space-y-1">
            <div class="flex justify-between text-[11px] text-slate-500 dark:text-slate-400">
                <span>Presence Rate</span>
                <span class="font-bold text-emerald-600"><?= esc($presenceRate) ?>%</span>
            </div>
            <div class="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div class="bg-emerald-500 h-full rounded-full transition-all duration-500" style="width: <?= min(100, max(0, (float)$presenceRate)) ?>%"></div>
            </div>
        </div>
    </div>
    <div class="pt-3 border-t border-slate-100 dark:border-slate-800 mt-3 flex items-center justify-between text-[11px]">
        <span class="text-slate-400">Active Presence</span>
        <a href="<?= base_url('attendance?tab=today') ?>" class="text-emerald-600 dark:text-emerald-400 font-bold hover:underline flex items-center gap-1">
            <span>View Muster</span>
            <i data-lucide="arrow-right" class="w-3 h-3"></i>
        </a>
    </div>
</div>
