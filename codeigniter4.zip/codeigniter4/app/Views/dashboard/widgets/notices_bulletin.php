<div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-xs flex flex-col justify-between h-full">
    <div>
        <div class="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-950/60 border border-purple-100 dark:border-purple-800 flex items-center justify-center text-purple-600 dark:text-purple-400">
                    <i data-lucide="megaphone" class="w-5 h-5"></i>
                </div>
                <div>
                    <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Organization Bulletins & Notices</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Official memos, company policies, and workplace announcements</p>
                </div>
            </div>
            <a href="<?= base_url('notices') ?>" class="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1">
                <span>All Notices</span>
                <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
            </a>
        </div>

        <div class="mt-4 space-y-3">
            <?php 
                $notices = $metrics['workforce']['notices'] ?? [];
                if (empty($notices)):
            ?>
                <div class="p-6 text-center text-xs text-slate-400 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-dashed border-slate-200 dark:border-slate-700">
                    <i data-lucide="bell-off" class="w-6 h-6 text-slate-400 mx-auto mb-1.5"></i>
                    No new organization announcements at this time.
                </div>
            <?php else: ?>
                <?php foreach (array_slice($notices, 0, 3) as $n): ?>
                    <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-start justify-between gap-4">
                        <div class="flex items-start gap-3">
                            <div class="p-2 rounded-lg bg-purple-100 dark:bg-purple-900/50 text-purple-600 dark:text-purple-400 mt-0.5">
                                <i data-lucide="file-text" class="w-4 h-4"></i>
                            </div>
                            <div>
                                <div class="text-xs font-bold text-slate-900 dark:text-white"><?= esc($n['title'] ?? 'Notice') ?></div>
                                <div class="text-[11px] text-slate-500 mt-0.5 line-clamp-2"><?= esc(strip_tags($n['description'] ?? 'No details')) ?></div>
                            </div>
                        </div>
                        <span class="text-[10px] text-slate-400 whitespace-nowrap">
                            <?= esc(date('M d', strtotime($n['created_at'] ?? 'now'))) ?>
                        </span>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="pt-4 border-t border-slate-100 dark:border-slate-800 mt-4 flex items-center justify-between text-xs">
        <span class="text-slate-500">Stay updated on company policies</span>
        <a href="<?= base_url('notices') ?>" class="text-purple-600 dark:text-purple-400 font-bold hover:underline">
            Read Policy Library →
        </a>
    </div>
</div>
