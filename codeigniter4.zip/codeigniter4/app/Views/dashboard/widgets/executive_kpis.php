<?php
/**
 * Widget: Executive Operations Summary & PiHR Workforce Command Center
 * 
 * PHASES 3 & 4 COMPLIANT:
 * - PiHR-aligned visual structure with clean white cards, subtle borders, and micro-shadows.
 * - 10 Authoritative Top Summary Cards (Clickable with interactive slide-over drilldown).
 * - 10-State Today's Attendance Overview (Present, Absent, Late, Half Day, Early Out, Not Checked In, Weekly Off, Holiday, On Approved Leave, Unscheduled).
 * - Full backward compatibility with VerifyExecutiveKpiPayroll (preserves currency formatting and RBAC).
 */

$dataPayload = $data ?? ($metrics['data'] ?? []);
$workforcePayload = $metrics['workforce'] ?? $dataPayload;

// 1. Top Summary Cards Data
$cards = $dataPayload['top_summary_cards'] ?? [];
$attOverview = $dataPayload['today_attendance_overview'] ?? [];

$totalActiveEmployees = (int)($cards['total_employees']['count'] ?? ($workforcePayload['active_employees'] ?? ($workforcePayload['total_employees'] ?? count($dataPayload['all_employees'] ?? []))));
$presentTodayCount    = (int)($cards['present_today']['count'] ?? ($workforcePayload['present_today'] ?? ($dataPayload['attendance_stats']['present'] ?? 0)));
$absentTodayCount     = (int)($cards['absent_today']['count'] ?? ($workforcePayload['absent_today'] ?? ($dataPayload['attendance_stats']['absent'] ?? 0)));
$lateTodayCount       = (int)($cards['late_today']['count'] ?? ($workforcePayload['late_today'] ?? ($dataPayload['attendance_stats']['late'] ?? 0)));
$onLeaveTodayCount    = (int)($cards['on_leave_today']['count'] ?? ($workforcePayload['on_leave_today'] ?? ($dataPayload['on_leave_today_count'] ?? count($dataPayload['on_leave_today'] ?? []))));
$onLeaveTomorrowCount = (int)($cards['on_leave_tomorrow']['count'] ?? ($dataPayload['on_leave_tomorrow_count'] ?? count($dataPayload['on_leave_tomorrow'] ?? [])));
$pendingLeavesCount   = (int)($cards['pending_leaves']['count'] ?? ($workforcePayload['pending_leave_count'] ?? ($dataPayload['pending_leave_count'] ?? count($dataPayload['pending_leaves'] ?? []))));
$onDutyCount          = (int)($cards['on_duty']['count'] ?? ($dataPayload['on_duty_count'] ?? count($dataPayload['on_duty_today'] ?? [])));
$onBreakCount         = (int)($cards['on_break']['count'] ?? ($dataPayload['on_break_count'] ?? count($dataPayload['on_break_now'] ?? [])));
$upcomingBirthdaysCount = (int)($cards['upcoming_birthdays']['count'] ?? count($dataPayload['upcoming_birthdays'] ?? []));

// 2. Attendance Overview States (10 states)
$presentState      = (int)($attOverview['present'] ?? $presentTodayCount);
$absentState       = (int)($attOverview['absent'] ?? $absentTodayCount);
$lateState         = (int)($attOverview['late'] ?? $lateTodayCount);
$halfDayState      = (int)($attOverview['half_day'] ?? ($dataPayload['attendance_overview_stats']['halfDay'] ?? ($dataPayload['attendance_overview_stats']['half_day'] ?? 0)));
$earlyOutState     = (int)($attOverview['early_out'] ?? ($dataPayload['attendance_overview_stats']['earlyOut'] ?? ($dataPayload['attendance_overview_stats']['early_out'] ?? 0)));
$notCheckedInState = (int)($attOverview['not_checked_in'] ?? max(0, $totalActiveEmployees - $presentState - $onLeaveTodayCount));
$weeklyOffState    = (int)($attOverview['weekly_off'] ?? ($dataPayload['attendance_overview_stats']['weeklyOff'] ?? ($dataPayload['attendance_overview_stats']['weekly_off_count'] ?? 0)));
$holidayState      = (int)($attOverview['holiday'] ?? ($dataPayload['attendance_overview_stats']['holiday'] ?? ($dataPayload['attendance_overview_stats']['holiday_count'] ?? 0)));
$onLeaveState      = (int)($attOverview['on_leave'] ?? $onLeaveTodayCount);
$unscheduledState  = (int)($attOverview['unscheduled'] ?? 0);
$presenceRate      = (float)($attOverview['presence_rate'] ?? ($workforcePayload['attendance_rate'] ?? ($totalActiveEmployees > 0 ? round(($presentTodayCount / $totalActiveEmployees) * 100, 1) : 0.0)));

// 3. Payroll & Financial Summary (Strictly preserved for RBAC & Parity)
$isPayrollEnabled  = !empty($dataPayload['is_payroll_enabled'] ?? $dataPayload['enabled_modules']['payroll'] ?? true);
$monthlyPayrollVal = $workforcePayload['monthly_payroll'] ?? $dataPayload['monthly_payroll'] ?? $metrics['monthly_payroll'] ?? null;
$canViewPayroll    = !empty($dataPayload['can_view_payroll'] ?? $workforcePayload['can_view_payroll'] ?? false);
if (!isset($dataPayload['can_view_payroll']) && !isset($workforcePayload['can_view_payroll'])) {
    $canViewPayroll = ($monthlyPayrollVal !== null);
}
$companyCurrency = !empty($company['currency']) ? $company['currency'] : (!empty($company['currency_symbol']) && $company['currency_symbol'] !== '$' ? $company['currency_symbol'] : '');

$cardsJson = [
    'total_employees'    => $cards['total_employees']['employees'] ?? ($dataPayload['all_employees'] ?? []),
    'present_today'      => $cards['present_today']['employees'] ?? [],
    'absent_today'       => $cards['absent_today']['employees'] ?? [],
    'late_today'         => $cards['late_today']['employees'] ?? [],
    'on_leave_today'     => $cards['on_leave_today']['employees'] ?? ($dataPayload['on_leave_today'] ?? []),
    'on_leave_tomorrow'  => $cards['on_leave_tomorrow']['employees'] ?? ($dataPayload['on_leave_tomorrow'] ?? []),
    'pending_leaves'     => $cards['pending_leaves']['employees'] ?? ($dataPayload['pending_leaves'] ?? []),
    'on_duty'            => $cards['on_duty']['employees'] ?? ($dataPayload['on_duty_today'] ?? []),
    'on_break'           => $cards['on_break']['employees'] ?? ($dataPayload['on_break_now'] ?? []),
    'upcoming_birthdays' => $cards['upcoming_birthdays']['employees'] ?? ($dataPayload['upcoming_birthdays'] ?? []),
];
?>

<div x-data="{
    activeModal: null,
    modalTitle: '',
    modalColor: 'indigo',
    modalCount: 0,
    searchQuery: '',
    modalDataset: <?= htmlspecialchars(json_encode($cardsJson), ENT_QUOTES, 'UTF-8') ?>,
    topOffset: '4rem',
    updateTopOffset() {
        const topbar = document.getElementById('topbar-navigation-strip');
        const navbar = document.getElementById('main-navbar');
        if (topbar && window.getComputedStyle(topbar).display !== 'none') {
            const rect = topbar.getBoundingClientRect();
            this.topOffset = (rect.bottom > 0 ? rect.bottom : 112) + 'px';
        } else if (navbar) {
            const rect = navbar.getBoundingClientRect();
            this.topOffset = (rect.bottom > 0 ? rect.bottom : 64) + 'px';
        } else {
            this.topOffset = '4rem';
        }
    },
    openDrilldown(key, title, color, count) {
        this.updateTopOffset();
        this.activeModal = key;
        this.modalTitle = title;
        this.modalColor = color;
        this.modalCount = count;
        this.searchQuery = '';
        this.$nextTick(() => {
            if (window.lucide) { lucide.createIcons(); }
        });
    },
    closeModal() {
        this.activeModal = null;
    },
    get currentList() {
        if (!this.activeModal || !this.modalDataset[this.activeModal]) {
            return [];
        }
        const list = this.modalDataset[this.activeModal];
        if (!this.searchQuery) return list;
        const q = this.searchQuery.toLowerCase().trim();
        return list.filter(item => {
            const name = (item.name || item.employee_name || ((item.first_name || '') + ' ' + (item.last_name || ''))).toLowerCase();
            const code = (item.employee_code || item.code || item.employee_id || '').toLowerCase();
            const dept = (item.department_name || item.departmentId || '').toLowerCase();
            const desig = (item.designation_name || item.designation || '').toLowerCase();
            return name.includes(q) || code.includes(q) || dept.includes(q) || desig.includes(q);
        });
    }
}" @keydown.escape.window="closeModal()" @resize.window="if (activeModal !== null) updateTopOffset()" class="space-y-4 w-full">

    <!-- 1. Executive Operations Header & Preserved Financial Metric (Compact Row, No Oversized Card Container) -->
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pb-1">
        <div class="flex items-center gap-2">
            <h2 class="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Executive Operations Summary</h2>
        </div>

        <!-- Preserved Financial / Department Metric (VerifyExecutiveKpiPayroll Compliant) -->
        <div class="flex items-center gap-2 shrink-0">
            <?php if ($isPayrollEnabled): ?>
                <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-2xs text-xs">
                    <i data-lucide="banknote" class="w-3.5 h-3.5 text-purple-600 dark:text-purple-400 shrink-0"></i>
                    <span class="text-[11px] font-medium text-slate-500 dark:text-slate-400">Payroll Est.:</span>
                    <div class="text-xs font-bold text-slate-900 dark:text-white font-mono inline-block">
                        <?php if ($canViewPayroll && $monthlyPayrollVal !== null): ?>
                            <span><?= !empty($companyCurrency) ? esc($companyCurrency) . ' ' : '' ?><?= number_format((float)$monthlyPayrollVal, 2) ?></span>
                        <?php else: ?>
                            <span class="text-slate-400">—</span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-2xs text-xs">
                    <i data-lucide="building-2" class="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 shrink-0"></i>
                    <span class="text-[11px] font-medium text-slate-500 dark:text-slate-400">Active Departments:</span>
                    <div class="text-xs font-bold text-slate-900 dark:text-white font-mono inline-block">
                        <?= count($dataPayload['departments'] ?? []) ?> <span class="text-[10px] font-normal text-slate-400">Depts</span>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- 2. Section 4: Top Dashboard Summary Cards (10 Clickable Cards Grid) -->
    <div>
        <div class="flex items-center justify-between pb-3">
            <div class="flex items-center gap-2">
                <span class="w-2 h-2 rounded-full bg-indigo-500"></span>
                <h3 class="text-sm font-extrabold text-slate-900 dark:text-white uppercase tracking-wider">Workforce & Attendance Summary</h3>
            </div>
            <span class="text-[11px] font-medium text-slate-400">Click any card to view detailed staff roster</span>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
            
            <!-- 1. Total Employees -->
            <div @click="openDrilldown('total_employees', 'Total Workforce Staff', 'indigo', <?= $totalActiveEmployees ?>)"
                 class="group bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-700 rounded-2xl p-4 shadow-xs hover:shadow-md transition-all cursor-pointer relative overflow-hidden">
                <div class="flex items-center justify-between text-slate-500 dark:text-slate-400">
                    <span class="text-[11px] font-bold uppercase tracking-wider">Total Staff</span>
                    <div class="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 group-hover:scale-110 transition-transform">
                        <i data-lucide="users" class="w-4 h-4"></i>
                    </div>
                </div>
                <div class="mt-2 flex items-baseline gap-2">
                    <span class="text-2xl font-black text-slate-900 dark:text-white font-mono"><?= esc($totalActiveEmployees) ?></span>
                </div>
                <div class="mt-1 flex items-center justify-between text-[11px]">
                    <span class="text-emerald-600 dark:text-emerald-400 font-semibold">Active Authorized</span>
                    <i data-lucide="arrow-up-right" class="w-3.5 h-3.5 text-slate-400 group-hover:text-indigo-600 transition"></i>
                </div>
            </div>

            <!-- 2. Present Today -->
            <div @click="openDrilldown('present_today', 'Present Staff Today', 'emerald', <?= $presentTodayCount ?>)"
                 class="group bg-white dark:bg-slate-900 border border-emerald-100 dark:border-emerald-950/60 hover:border-emerald-400 dark:hover:border-emerald-600 rounded-2xl p-4 shadow-xs hover:shadow-md transition-all cursor-pointer relative overflow-hidden">
                <div class="flex items-center justify-between text-emerald-600 dark:text-emerald-400">
                    <span class="text-[11px] font-bold uppercase tracking-wider">Present Today</span>
                    <div class="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 group-hover:scale-110 transition-transform">
                        <i data-lucide="check-circle-2" class="w-4 h-4"></i>
                    </div>
                </div>
                <div class="mt-2 flex items-baseline gap-2">
                    <span class="text-2xl font-black text-emerald-600 dark:text-emerald-400 font-mono"><?= esc($presentTodayCount) ?></span>
                    <span class="text-xs font-bold text-emerald-600/80"><?= esc($presenceRate) ?>%</span>
                </div>
                <div class="mt-1 flex items-center justify-between text-[11px]">
                    <span class="text-slate-500 dark:text-slate-400">Confirmed Present</span>
                    <i data-lucide="arrow-up-right" class="w-3.5 h-3.5 text-slate-400 group-hover:text-emerald-600 transition"></i>
                </div>
            </div>

            <!-- 3. Absent Today -->
            <div @click="openDrilldown('absent_today', 'Absent Staff Today', 'rose', <?= $absentTodayCount ?>)"
                 class="group bg-white dark:bg-slate-900 border border-rose-100 dark:border-rose-950/60 hover:border-rose-400 dark:hover:border-rose-600 rounded-2xl p-4 shadow-xs hover:shadow-md transition-all cursor-pointer relative overflow-hidden">
                <div class="flex items-center justify-between text-rose-600 dark:text-rose-400">
                    <span class="text-[11px] font-bold uppercase tracking-wider">Absent Today</span>
                    <div class="p-2 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 group-hover:scale-110 transition-transform">
                        <i data-lucide="x-circle" class="w-4 h-4"></i>
                    </div>
                </div>
                <div class="mt-2 flex items-baseline gap-2">
                    <span class="text-2xl font-black text-rose-600 dark:text-rose-400 font-mono"><?= esc($absentTodayCount) ?></span>
                </div>
                <div class="mt-1 flex items-center justify-between text-[11px]">
                    <span class="text-rose-600/90 font-medium">Unexcused</span>
                    <i data-lucide="arrow-up-right" class="w-3.5 h-3.5 text-slate-400 group-hover:text-rose-600 transition"></i>
                </div>
            </div>

            <!-- 4. Late Today -->
            <div @click="openDrilldown('late_today', 'Late Arrivals Today', 'amber', <?= $lateTodayCount ?>)"
                 class="group bg-white dark:bg-slate-900 border border-amber-100 dark:border-amber-950/60 hover:border-amber-400 dark:hover:border-amber-600 rounded-2xl p-4 shadow-xs hover:shadow-md transition-all cursor-pointer relative overflow-hidden">
                <div class="flex items-center justify-between text-amber-600 dark:text-amber-400">
                    <span class="text-[11px] font-bold uppercase tracking-wider">Late Today</span>
                    <div class="p-2 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 group-hover:scale-110 transition-transform">
                        <i data-lucide="clock" class="w-4 h-4"></i>
                    </div>
                </div>
                <div class="mt-2 flex items-baseline gap-2">
                    <span class="text-2xl font-black text-amber-600 dark:text-amber-400 font-mono"><?= esc($lateTodayCount) ?></span>
                </div>
                <div class="mt-1 flex items-center justify-between text-[11px]">
                    <span class="text-amber-600/90 font-medium">Exceeded Grace</span>
                    <i data-lucide="arrow-up-right" class="w-3.5 h-3.5 text-slate-400 group-hover:text-amber-600 transition"></i>
                </div>
            </div>

            <!-- 5. On Leave Today -->
            <div @click="openDrilldown('on_leave_today', 'Staff on Approved Leave Today', 'sky', <?= $onLeaveTodayCount ?>)"
                 class="group bg-white dark:bg-slate-900 border border-sky-100 dark:border-sky-950/60 hover:border-sky-400 dark:hover:border-sky-600 rounded-2xl p-4 shadow-xs hover:shadow-md transition-all cursor-pointer relative overflow-hidden">
                <div class="flex items-center justify-between text-sky-600 dark:text-sky-400">
                    <span class="text-[11px] font-bold uppercase tracking-wider">On Leave Today</span>
                    <div class="p-2 rounded-xl bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 group-hover:scale-110 transition-transform">
                        <i data-lucide="calendar-check" class="w-4 h-4"></i>
                    </div>
                </div>
                <div class="mt-2 flex items-baseline gap-2">
                    <span class="text-2xl font-black text-slate-900 dark:text-white font-mono"><?= esc($onLeaveTodayCount) ?></span>
                </div>
                <div class="mt-1 flex items-center justify-between text-[11px]">
                    <span class="text-sky-600 dark:text-sky-400 font-semibold">Approved Leave</span>
                    <i data-lucide="arrow-up-right" class="w-3.5 h-3.5 text-slate-400 group-hover:text-sky-600 transition"></i>
                </div>
            </div>

            <!-- 6. On Leave Tomorrow -->
            <div @click="openDrilldown('on_leave_tomorrow', 'Staff on Approved Leave Tomorrow', 'blue', <?= $onLeaveTomorrowCount ?>)"
                 class="group bg-white dark:bg-slate-900 border border-blue-100 dark:border-blue-950/60 hover:border-blue-400 dark:hover:border-blue-600 rounded-2xl p-4 shadow-xs hover:shadow-md transition-all cursor-pointer relative overflow-hidden">
                <div class="flex items-center justify-between text-blue-600 dark:text-blue-400">
                    <span class="text-[11px] font-bold uppercase tracking-wider">Leave Tomorrow</span>
                    <div class="p-2 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 group-hover:scale-110 transition-transform">
                        <i data-lucide="calendar-days" class="w-4 h-4"></i>
                    </div>
                </div>
                <div class="mt-2 flex items-baseline gap-2">
                    <span class="text-2xl font-black text-slate-900 dark:text-white font-mono"><?= esc($onLeaveTomorrowCount) ?></span>
                </div>
                <div class="mt-1 flex items-center justify-between text-[11px]">
                    <span class="text-blue-600 dark:text-blue-400 font-semibold">Scheduled Leave</span>
                    <i data-lucide="arrow-up-right" class="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-600 transition"></i>
                </div>
            </div>

            <!-- 7. Pending Leave Applications -->
            <div @click="openDrilldown('pending_leaves', 'Pending Leave Applications', 'purple', <?= $pendingLeavesCount ?>)"
                 class="group bg-white dark:bg-slate-900 border border-purple-100 dark:border-purple-950/60 hover:border-purple-400 dark:hover:border-purple-600 rounded-2xl p-4 shadow-xs hover:shadow-md transition-all cursor-pointer relative overflow-hidden">
                <div class="flex items-center justify-between text-purple-600 dark:text-purple-400">
                    <span class="text-[11px] font-bold uppercase tracking-wider">Pending Leaves</span>
                    <div class="p-2 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 group-hover:scale-110 transition-transform">
                        <i data-lucide="alert-circle" class="w-4 h-4"></i>
                    </div>
                </div>
                <div class="mt-2 flex items-baseline gap-2">
                    <span class="text-2xl font-black text-slate-900 dark:text-white font-mono"><?= esc($pendingLeavesCount) ?></span>
                </div>
                <div class="mt-1 flex items-center justify-between text-[11px]">
                    <span class="text-purple-600 dark:text-purple-400 font-semibold">Needs Approval</span>
                    <i data-lucide="arrow-up-right" class="w-3.5 h-3.5 text-slate-400 group-hover:text-purple-600 transition"></i>
                </div>
            </div>

            <!-- 8. On Duty / Field Visit -->
            <div @click="openDrilldown('on_duty', 'Approved On-Duty / Field Visits Today', 'teal', <?= $onDutyCount ?>)"
                 class="group bg-white dark:bg-slate-900 border border-teal-100 dark:border-teal-950/60 hover:border-teal-400 dark:hover:border-teal-600 rounded-2xl p-4 shadow-xs hover:shadow-md transition-all cursor-pointer relative overflow-hidden">
                <div class="flex items-center justify-between text-teal-600 dark:text-teal-400">
                    <span class="text-[11px] font-bold uppercase tracking-wider">On Duty / Visit</span>
                    <div class="p-2 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 group-hover:scale-110 transition-transform">
                        <i data-lucide="map-pin" class="w-4 h-4"></i>
                    </div>
                </div>
                <div class="mt-2 flex items-baseline gap-2">
                    <span class="text-2xl font-black text-slate-900 dark:text-white font-mono"><?= esc($onDutyCount) ?></span>
                </div>
                <div class="mt-1 flex items-center justify-between text-[11px]">
                    <span class="text-teal-600 dark:text-teal-400 font-semibold">External Duty</span>
                    <i data-lucide="arrow-up-right" class="w-3.5 h-3.5 text-slate-400 group-hover:text-teal-600 transition"></i>
                </div>
            </div>

            <!-- 9. On Break Now -->
            <div @click="openDrilldown('on_break', 'Employees Currently On Break', 'orange', <?= $onBreakCount ?>)"
                 class="group bg-white dark:bg-slate-900 border border-orange-100 dark:border-orange-950/60 hover:border-orange-400 dark:hover:border-orange-600 rounded-2xl p-4 shadow-xs hover:shadow-md transition-all cursor-pointer relative overflow-hidden">
                <div class="flex items-center justify-between text-orange-600 dark:text-orange-400">
                    <span class="text-[11px] font-bold uppercase tracking-wider">On Break Now</span>
                    <div class="p-2 rounded-xl bg-orange-50 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400 group-hover:scale-110 transition-transform">
                        <i data-lucide="coffee" class="w-4 h-4"></i>
                    </div>
                </div>
                <div class="mt-2 flex items-baseline gap-2">
                    <span class="text-2xl font-black text-slate-900 dark:text-white font-mono"><?= esc($onBreakCount) ?></span>
                </div>
                <div class="mt-1 flex items-center justify-between text-[11px]">
                    <span class="text-orange-600 dark:text-orange-400 font-semibold">Live Interval</span>
                    <i data-lucide="arrow-up-right" class="w-3.5 h-3.5 text-slate-400 group-hover:text-orange-600 transition"></i>
                </div>
            </div>

            <!-- 10. Upcoming Birthdays -->
            <div @click="openDrilldown('upcoming_birthdays', 'Upcoming Employee Birthdays', 'pink', <?= $upcomingBirthdaysCount ?>)"
                 class="group bg-white dark:bg-slate-900 border border-pink-100 dark:border-pink-950/60 hover:border-pink-400 dark:hover:border-pink-600 rounded-2xl p-4 shadow-xs hover:shadow-md transition-all cursor-pointer relative overflow-hidden">
                <div class="flex items-center justify-between text-pink-600 dark:text-pink-400">
                    <span class="text-[11px] font-bold uppercase tracking-wider">Birthdays</span>
                    <div class="p-2 rounded-xl bg-pink-50 dark:bg-pink-950/60 text-pink-600 dark:text-pink-400 group-hover:scale-110 transition-transform">
                        <i data-lucide="cake" class="w-4 h-4"></i>
                    </div>
                </div>
                <div class="mt-2 flex items-baseline gap-2">
                    <span class="text-2xl font-black text-slate-900 dark:text-white font-mono"><?= esc($upcomingBirthdaysCount) ?></span>
                </div>
                <div class="mt-1 flex items-center justify-between text-[11px]">
                    <span class="text-pink-600 dark:text-pink-400 font-semibold">This Month</span>
                    <i data-lucide="arrow-up-right" class="w-3.5 h-3.5 text-slate-400 group-hover:text-pink-600 transition"></i>
                </div>
            </div>

        </div>
    </div>

    <!-- 3. Section 5: Today's Attendance Overview (10-State Comprehensive Breakdown) -->
    <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-xs space-y-4">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
            <div class="flex items-center gap-2.5">
                <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <div>
                    <h3 class="text-sm font-extrabold text-slate-900 dark:text-white">Today's Attendance Overview</h3>
                    <p class="text-xs text-slate-400">Operational shift status breakdown (half day, early departures, rest days & pending punches)</p>
                </div>
            </div>
            <div class="flex items-center gap-2">
                <span class="text-xs font-semibold text-slate-500">Presence Rate:</span>
                <span class="px-2.5 py-0.5 rounded-full text-xs font-black bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                    <?= esc($presenceRate) ?>%
                </span>
            </div>
        </div>

        <!-- Proportional Segmented Progress Bar -->
        <?php
            $pctPresent = $totalActiveEmployees > 0 ? round(($presentState / $totalActiveEmployees) * 100, 1) : 0;
            $pctLeave   = $totalActiveEmployees > 0 ? round(($onLeaveState / $totalActiveEmployees) * 100, 1) : 0;
            $pctOff     = $totalActiveEmployees > 0 ? round((($weeklyOffState + $holidayState) / $totalActiveEmployees) * 100, 1) : 0;
            $pctAbsent  = $totalActiveEmployees > 0 ? round(($absentState / $totalActiveEmployees) * 100, 1) : 0;
            $pctOther   = max(0, 100 - ($pctPresent + $pctLeave + $pctOff + $pctAbsent));
        ?>
        <div class="w-full h-3 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden flex shadow-inner">
            <div style="width: <?= $pctPresent ?>%" class="bg-emerald-500 transition-all duration-500" title="Present: <?= $presentState ?>"></div>
            <div style="width: <?= $pctLeave ?>%" class="bg-sky-500 transition-all duration-500" title="On Leave: <?= $onLeaveState ?>"></div>
            <div style="width: <?= $pctOff ?>%" class="bg-slate-400 transition-all duration-500" title="Off / Holiday: <?= $weeklyOffState + $holidayState ?>"></div>
            <div style="width: <?= $pctAbsent ?>%" class="bg-rose-500 transition-all duration-500" title="Absent: <?= $absentState ?>"></div>
            <div style="width: <?= $pctOther ?>%" class="bg-amber-400 transition-all duration-500" title="Other: <?= $totalActiveEmployees - $presentState - $onLeaveState - $weeklyOffState - $holidayState - $absentState ?>"></div>
        </div>

        <!-- 6 Status Grid Items (Mutual exclusives non-duplicated with Top Summary Cards) -->
        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 pt-1">
            
            <!-- 1. Half Day -->
            <div class="p-3 rounded-xl border border-purple-100 dark:border-purple-950/60 bg-purple-50/50 dark:bg-purple-950/20">
                <div class="flex items-center justify-between text-purple-700 dark:text-purple-400">
                    <span class="text-[11px] font-bold">Half Day</span>
                    <i data-lucide="pie-chart" class="w-3.5 h-3.5"></i>
                </div>
                <div class="text-xl font-black text-purple-700 dark:text-purple-300 font-mono mt-1"><?= esc($halfDayState) ?></div>
                <span class="text-[10px] text-purple-600/80 block mt-0.5">&lt; 4.0 hrs</span>
            </div>

            <!-- 2. Early Out -->
            <div class="p-3 rounded-xl border border-indigo-100 dark:border-indigo-950/60 bg-indigo-50/50 dark:bg-indigo-950/20">
                <div class="flex items-center justify-between text-indigo-700 dark:text-indigo-400">
                    <span class="text-[11px] font-bold">Early Out</span>
                    <i data-lucide="log-out" class="w-3.5 h-3.5"></i>
                </div>
                <div class="text-xl font-black text-indigo-700 dark:text-indigo-300 font-mono mt-1"><?= esc($earlyOutState) ?></div>
                <span class="text-[10px] text-indigo-600/80 block mt-0.5">Before shift end</span>
            </div>

            <!-- 3. Not Checked In -->
            <div class="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
                <div class="flex items-center justify-between text-slate-600 dark:text-slate-400">
                    <span class="text-[11px] font-bold">Not Checked In</span>
                    <i data-lucide="user-x" class="w-3.5 h-3.5"></i>
                </div>
                <div class="text-xl font-black text-slate-700 dark:text-slate-200 font-mono mt-1"><?= esc($notCheckedInState) ?></div>
                <span class="text-[10px] text-slate-400 block mt-0.5">Pending check-in</span>
            </div>

            <!-- 4. Weekly Off -->
            <div class="p-3 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-800/40">
                <div class="flex items-center justify-between text-zinc-600 dark:text-zinc-400">
                    <span class="text-[11px] font-bold">Weekly Off</span>
                    <i data-lucide="calendar" class="w-3.5 h-3.5"></i>
                </div>
                <div class="text-xl font-black text-zinc-700 dark:text-zinc-200 font-mono mt-1"><?= esc($weeklyOffState) ?></div>
                <span class="text-[10px] text-zinc-400 block mt-0.5">Rest day</span>
            </div>

            <!-- 5. Holiday -->
            <div class="p-3 rounded-xl border border-sky-100 dark:border-sky-950/60 bg-sky-50/50 dark:bg-sky-950/20">
                <div class="flex items-center justify-between text-sky-700 dark:text-sky-400">
                    <span class="text-[11px] font-bold">Holiday</span>
                    <i data-lucide="sparkles" class="w-3.5 h-3.5"></i>
                </div>
                <div class="text-xl font-black text-sky-700 dark:text-sky-300 font-mono mt-1"><?= esc($holidayState) ?></div>
                <span class="text-[10px] text-sky-600/80 block mt-0.5">Public / Company</span>
            </div>

            <!-- 6. Unassigned / Unscheduled -->
            <div class="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
                <div class="flex items-center justify-between text-slate-600 dark:text-slate-400">
                    <span class="text-[11px] font-bold">Unscheduled</span>
                    <i data-lucide="help-circle" class="w-3.5 h-3.5"></i>
                </div>
                <div class="text-xl font-black text-slate-700 dark:text-slate-200 font-mono mt-1"><?= esc($unscheduledState) ?></div>
                <span class="text-[10px] text-slate-400 block mt-0.5">No shift assigned</span>
            </div>

        </div>
    </div>

    <!-- 4. Interactive Slide-Over Drawer / Modal for Summary Card Drilldowns -->
    <div x-show="activeModal !== null" 
         x-transition:enter="transition ease-out duration-300"
         x-transition:enter-start="opacity-0"
         x-transition:enter-end="opacity-100"
         x-transition:leave="transition ease-in duration-200"
         x-transition:leave-start="opacity-100"
         x-transition:leave-end="opacity-0"
         class="fixed top-16 right-0 bottom-0 left-0 z-50 overflow-hidden bg-slate-900/60 backdrop-blur-xs flex justify-end"
         :style="'top: ' + topOffset + '; height: calc(100vh - ' + topOffset + ');'"
         style="display: none;">
        
        <div @click.away="closeModal()" 
             x-show="activeModal !== null"
             x-transition:enter="transition ease-out duration-300 transform"
             x-transition:enter-start="translate-x-full"
             x-transition:enter-end="translate-x-0"
             x-transition:leave="transition ease-in duration-200 transform"
             x-transition:leave-start="translate-x-0"
             x-transition:leave-end="translate-x-full"
             class="w-full max-w-xl bg-white dark:bg-slate-900 h-full shadow-2xl flex flex-col border-l border-slate-200 dark:border-slate-800">
            
            <!-- Drawer Header -->
            <div class="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/50">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
                        <i data-lucide="users" class="w-5 h-5"></i>
                    </div>
                    <div>
                        <h3 class="text-base font-extrabold text-slate-900 dark:text-white" x-text="modalTitle"></h3>
                        <p class="text-xs text-slate-400">
                            Showing <span class="font-bold text-slate-700 dark:text-slate-200" x-text="currentList.length"></span> of <span x-text="modalCount"></span> staff members
                        </p>
                    </div>
                </div>
                <button type="button" @click="closeModal()" class="w-8 h-8 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 flex items-center justify-center hover:bg-slate-300 transition cursor-pointer">
                    <i data-lucide="x" class="w-4 h-4"></i>
                </button>
            </div>

            <!-- Search Filter Bar -->
            <div class="p-4 border-b border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900">
                <div class="relative">
                    <i data-lucide="search" class="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"></i>
                    <input type="text" 
                           x-model="searchQuery" 
                           placeholder="Filter by employee name, ID, or department..." 
                           class="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/50">
                </div>
            </div>

            <!-- Employee List Body -->
            <div class="flex-1 overflow-y-auto p-5 space-y-3 divide-y divide-slate-100 dark:divide-slate-800/60">
                <template x-for="(emp, idx) in currentList" :key="emp.id || emp.employee_id || idx">
                    <div class="pt-3 first:pt-0 flex items-center justify-between gap-3">
                        <div class="flex items-center gap-3 min-w-0">
                            <div class="w-9 h-9 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-xs font-bold text-slate-600 dark:text-slate-300 shrink-0 overflow-hidden border border-slate-200 dark:border-slate-700">
                                <template x-if="emp.avatar || emp.photo">
                                    <img :src="emp.avatar || emp.photo" class="w-full h-full object-cover" alt="avatar">
                                </template>
                                <template x-if="!emp.avatar && !emp.photo">
                                    <span x-text="(emp.name || emp.employee_name || 'E').substring(0, 2).toUpperCase()"></span>
                                </template>
                            </div>
                            <div class="min-w-0">
                                <div class="text-xs font-bold text-slate-900 dark:text-white truncate" x-text="emp.name || emp.employee_name || ((emp.first_name || '') + ' ' + (emp.last_name || ''))"></div>
                                <div class="text-[11px] text-slate-400 flex items-center gap-1.5 flex-wrap">
                                    <span class="font-mono" x-text="emp.employee_code || emp.code || emp.employee_id || ''"></span>
                                    <span>•</span>
                                    <span x-text="emp.department_name || emp.department || 'General'"></span>
                                    <template x-if="emp.designation_name || emp.designation">
                                        <span>• <span x-text="emp.designation_name || emp.designation"></span></span>
                                    </template>
                                </div>
                            </div>
                        </div>

                        <!-- Contextual Badge -->
                        <div class="shrink-0 text-right">
                            <template x-if="emp.check_in">
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                                    In: <span x-text="emp.check_in"></span>
                                </span>
                            </template>
                            <template x-if="emp.leave_type_name || emp.type_name">
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-50 text-sky-700 dark:bg-sky-950/60 dark:text-sky-300 border border-sky-200 dark:border-sky-800" x-text="emp.leave_type_name || emp.type_name"></span>
                            </template>
                            <template x-if="emp.duty_type">
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-50 text-teal-700 dark:bg-teal-950/60 dark:text-teal-300 border border-teal-200 dark:border-teal-800" x-text="emp.duty_type"></span>
                            </template>
                            <template x-if="emp.dob">
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-pink-50 text-pink-700 dark:bg-pink-950/60 dark:text-pink-300 border border-pink-200 dark:border-pink-800" x-text="emp.dob"></span>
                            </template>
                            <template x-if="emp.status && !emp.check_in && !emp.leave_type_name && !emp.duty_type && !emp.dob">
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300" x-text="emp.status"></span>
                            </template>
                        </div>
                    </div>
                </template>

                <!-- Empty State -->
                <template x-if="currentList.length === 0">
                    <div class="py-12 text-center text-slate-400">
                        <i data-lucide="inbox" class="w-8 h-8 mx-auto mb-2 opacity-50"></i>
                        <p class="text-xs">No employees found matching the criteria</p>
                    </div>
                </template>
            </div>

            <!-- Drawer Footer -->
            <div class="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 flex items-center justify-between">
                <span class="text-[11px] text-slate-400">HCM Executive Intelligence</span>
                <button type="button" @click="closeModal()" class="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold hover:bg-slate-300 transition cursor-pointer">
                    Close Drawer
                </button>
            </div>

        </div>
    </div>

</div>

