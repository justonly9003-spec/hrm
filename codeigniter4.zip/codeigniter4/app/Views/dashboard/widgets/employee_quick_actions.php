<?php
/**
 * Widget: Employee Quick Action Deck
 * Code: employee_quick_actions
 * Path: dashboard/widgets/employee_quick_actions
 */
$actions = [
    [
        'title'  => 'Apply for Leave',
        'desc'   => 'Submit casual, annual, or medical leave request',
        'icon'   => 'calendar-plus',
        'color'  => 'indigo',
        'url'    => base_url('leave?action=apply'),
        'module' => 'leaves',
    ],
    [
        'title'  => 'Clock-In / Punch',
        'desc'   => 'Terminal attendance check-in / check-out',
        'icon'   => 'clock',
        'color'  => 'emerald',
        'url'    => base_url('attendance'),
        'module' => 'attendance',
    ],
    [
        'title'  => 'Request Overtime',
        'desc'   => 'Pre-authorization for extended shift hours',
        'icon'   => 'clock-4',
        'color'  => 'teal',
        'url'    => base_url('overtime/create'),
        'module' => 'overtime',
    ],
    [
        'title'  => 'My Payslips',
        'desc'   => 'Download salary vouchers and statements',
        'icon'   => 'file-text',
        'color'  => 'violet',
        'url'    => base_url('payroll'),
        'module' => 'payroll',
    ],
    [
        'title'  => 'Shift Roster',
        'desc'   => 'View assigned shift schedules & weekends',
        'icon'   => 'calendar-range',
        'color'  => 'sky',
        'url'    => base_url('attendance/roster'),
        'module' => 'rostering',
    ],
    [
        'title'  => 'Staff Directory',
        'desc'   => 'Search teammates & organization hierarchy',
        'icon'   => 'users',
        'color'  => 'amber',
        'url'    => base_url('employees'),
        'module' => 'directory',
    ],
];

// Module-Based Server-Side Control: Suppress quick actions for disabled modules
$enabledModules = $metrics['data']['enabled_modules'] ?? [];
$actions = array_values(array_filter($actions, function ($action) use ($enabledModules) {
    if (empty($action['module'])) {
        return true;
    }
    $m = $action['module'];
    return !isset($enabledModules[$m]) || (bool)$enabledModules[$m];
}));
?>
<div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between h-full">
    <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
        <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                <i data-lucide="zap" class="w-4 h-4"></i>
            </div>
            <div>
                <h3 class="text-sm font-bold text-slate-900 dark:text-white"><?= esc($widget['title']) ?></h3>
                <p class="text-[11px] text-slate-500 dark:text-slate-400">High-frequency workflows & quick portals</p>
            </div>
        </div>
        <span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
            ESS Self-Service
        </span>
    </div>

    <!-- 6 Actions Grid -->
    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <?php foreach ($actions as $act): ?>
            <a href="<?= esc($act['url']) ?>" class="group p-3.5 rounded-xl border border-slate-200/80 dark:border-slate-800 hover:border-indigo-500/50 dark:hover:border-indigo-500/50 bg-slate-50/50 dark:bg-slate-800/30 hover:bg-white dark:hover:bg-slate-800/80 transition-all flex flex-col items-start gap-2.5 shadow-2xs">
                <div class="w-8 h-8 rounded-lg bg-white dark:bg-slate-800 border border-slate-200/60 dark:border-slate-700 flex items-center justify-center text-indigo-600 dark:text-indigo-400 group-hover:scale-105 transition">
                    <i data-lucide="<?= esc($act['icon']) ?>" class="w-4 h-4"></i>
                </div>
                <div>
                    <h4 class="text-xs font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition leading-tight">
                        <?= esc($act['title']) ?>
                    </h4>
                    <p class="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-1 leading-snug">
                        <?= esc($act['desc']) ?>
                    </p>
                </div>
            </a>
        <?php endforeach; ?>
    </div>
</div>
