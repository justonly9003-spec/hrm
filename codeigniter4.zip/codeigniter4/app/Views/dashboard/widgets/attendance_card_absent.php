<?php
/**
 * Widget: Today's Unaccounted Absences (Single Metric Card)
 */
$stats = $stats ?? ($data['attendance_overview_stats'] ?? []);
$absent = (int)($stats['absent'] ?? 0);
?>

<div class="bg-white dark:bg-slate-900 border border-rose-100 dark:border-rose-950/60 rounded-2xl p-5 shadow-xs flex flex-col justify-between h-full">
    <div>
        <div class="flex items-center justify-between text-rose-600 mb-2">
            <span class="text-[11px] font-bold uppercase tracking-wider">Unaccounted Absence</span>
            <div class="w-8 h-8 rounded-lg bg-rose-50 dark:bg-rose-950/60 flex items-center justify-center">
                <i data-lucide="x-circle" class="w-4 h-4 text-rose-500"></i>
            </div>
        </div>
        <div class="flex items-baseline gap-2">
            <span class="text-3xl font-black text-rose-600 font-mono"><?= esc($absent) ?></span>
            <span class="text-xs text-slate-400 font-medium">Staff Unaccounted</span>
        </div>
        <p class="text-[11px] text-slate-500 dark:text-slate-400 mt-2">
            No punch recorded today and no approved leave application on file.
        </p>
    </div>
    <div class="pt-3 border-t border-slate-100 dark:border-slate-800 mt-3 flex items-center justify-between text-[11px]">
        <span class="text-rose-600 font-bold">Requires Attention</span>
        <a href="<?= base_url('attendance?tab=today&status=Absent') ?>" class="text-rose-600 dark:text-rose-400 font-bold hover:underline flex items-center gap-1">
            <span>Review Absent</span>
            <i data-lucide="arrow-right" class="w-3 h-3"></i>
        </a>
    </div>
</div>
