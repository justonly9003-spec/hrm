<div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-xs flex flex-col justify-between h-full">
    <div>
        <div class="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-100 dark:border-indigo-800 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
                    <i data-lucide="wallet-cards" class="w-5 h-5"></i>
                </div>
                <div>
                    <h3 class="text-base font-extrabold text-slate-900 dark:text-white">My Leave Entitlements</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Annual quotas, used days & remaining balance</p>
                </div>
            </div>
            <a href="<?= base_url('leave?action=apply') ?>" class="px-2.5 py-1 text-xs font-bold rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition">
                + Request
            </a>
        </div>

        <?php 
            $balances = $data['my_leave_balances'] ?? ($metrics['data']['my_leave_balances'] ?? ($metrics['workforce']['my_leave_balances'] ?? []));
            $colors = [
                ['text' => 'text-indigo-600 dark:text-indigo-400', 'bg' => 'bg-indigo-50 dark:bg-indigo-950/40'],
                ['text' => 'text-emerald-600 dark:text-emerald-400', 'bg' => 'bg-emerald-50 dark:bg-emerald-950/40'],
                ['text' => 'text-amber-600 dark:text-amber-400', 'bg' => 'bg-amber-50 dark:bg-amber-950/40'],
                ['text' => 'text-sky-600 dark:text-sky-400', 'bg' => 'bg-sky-50 dark:bg-sky-950/40'],
            ];
        ?>

        <?php if (!empty($balances)): ?>
            <div class="mt-4 grid grid-cols-3 gap-3">
                <?php foreach (array_slice($balances, 0, 3) as $idx => $bal): ?>
                    <?php 
                        $color = $colors[$idx % count($colors)];
                        $allocated = (float)($bal['entitled_days'] ?? $bal['allocated_days'] ?? 0);
                        $carried = (float)($bal['carried_forward_days'] ?? $bal['carried_over'] ?? 0);
                        $used = (float)($bal['used_days'] ?? $bal['taken_days'] ?? 0);
                        $pending = (float)($bal['pending_days'] ?? 0);
                        $remaining = isset($bal['balance']) ? (float)$bal['balance'] : max(0, ($allocated + $carried - $used - $pending));
                        $typeName = $bal['leave_type_name'] ?? ($bal['leave_type_code'] ?? 'Leave');
                    ?>
                    <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-center">
                        <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider truncate" title="<?= esc($typeName) ?>"><?= esc($typeName) ?></div>
                        <div class="text-xl font-black <?= $color['text'] ?> mt-1"><?= (int)$remaining == $remaining ? (int)$remaining : number_format($remaining, 1) ?></div>
                        <div class="text-[10px] text-slate-500">Days Left</div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="mt-4 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-center">
                <p class="text-xs text-slate-500 dark:text-slate-400">No leave quotas allocated for current year</p>
            </div>
        <?php endif; ?>
    </div>

    <div class="pt-4 border-t border-slate-100 dark:border-slate-800 mt-4 flex items-center justify-between text-xs">
        <span class="text-slate-500">Leave Year: <strong><?= date('Y') ?></strong></span>
        <a href="<?= base_url('leave') ?>" class="text-indigo-600 dark:text-indigo-400 font-bold hover:underline">
            Leave History & Status →
        </a>
    </div>
</div>
