<?php
/**
 * Widget: Active Attendance Policy Engine Summary
 */
$settings = $settings ?? ($data['attendance_policy_settings'] ?? []);
$companyWeeklyOff = \App\Services\CompanyWeekendService::getCompanyWeeklyOff($data['company_id'] ?? null);
$weekendDays = (array)($settings['weekendDays'] ?? $companyWeeklyOff);
$perm = new \App\Services\PermissionService();
$userId = session()->get('user_id');
$canManageAttendance = $perm->hasAccess($userId, 'attendance', 'manage', $role ?? null);
$canViewRules = $perm->hasAccess($userId, 'rules', 'view', $role ?? null);
?>

<div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-xs space-y-4 w-full h-full flex flex-col justify-between">
    <div class="space-y-4">
        <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div class="flex items-center gap-2">
                <i data-lucide="sliders" class="w-4 h-4 text-indigo-600"></i>
                <h3 class="font-bold text-slate-800 dark:text-white text-sm">Active Attendance Policy</h3>
            </div>
            <?php if (!empty($canManageAttendance)): ?>
                <button 
                    type="button"
                    @click="typeof setTab === 'function' ? setTab('settings') : window.location.href='<?= base_url('attendance?tab=settings') ?>'" 
                    class="text-xs text-indigo-600 dark:text-indigo-400 font-bold hover:underline cursor-pointer"
                >
                    Edit
                </button>
            <?php endif; ?>
        </div>

        <div class="space-y-2.5 text-xs">
            <div class="flex justify-between items-center py-1.5 border-b border-slate-50 dark:border-slate-800">
                <span class="text-slate-500 dark:text-slate-400">Standard Work Shift:</span>
                <span class="font-bold font-mono text-slate-800 dark:text-white"><?= esc($settings['officeStartTime'] ?? '09:00') ?> - <?= esc($settings['officeEndTime'] ?? '18:00') ?></span>
            </div>
            <div class="flex justify-between items-center py-1.5 border-b border-slate-50 dark:border-slate-800">
                <span class="text-slate-500 dark:text-slate-400">Arrival Grace Buffer:</span>
                <span class="font-bold text-amber-600"><?= esc($settings['graceTime'] ?? '15') ?> Minutes</span>
            </div>
            <div class="flex justify-between items-center py-1.5 border-b border-slate-50 dark:border-slate-800">
                <span class="text-slate-500 dark:text-slate-400">Half-Day Threshold:</span>
                <span class="font-bold font-mono text-purple-600"><?= esc($settings['halfDayTime'] ?? '13:00') ?></span>
            </div>
            <div class="flex justify-between items-center py-1.5 border-b border-slate-50 dark:border-slate-800">
                <span class="text-slate-500 dark:text-slate-400">Overtime Rate:</span>
                <span class="font-bold text-emerald-600"><?= esc($settings['overtimeRate'] ?? '1.5') ?>x Base Hourly</span>
            </div>
            <div class="flex justify-between items-center py-1.5 border-b border-slate-50 dark:border-slate-800">
                <span class="text-slate-500 dark:text-slate-400">Geofence Radius:</span>
                <span class="font-bold text-slate-800 dark:text-white"><?= esc($settings['geofenceRadius'] ?? '200') ?> Meters</span>
            </div>
            <div class="flex justify-between items-center py-1.5">
                <span class="text-slate-500 dark:text-slate-400">Weekend Days:</span>
                <span class="font-bold text-indigo-600 dark:text-indigo-400"><?= implode(', ', $weekendDays) ?></span>
            </div>
        </div>

        <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl text-[11px] text-indigo-700 dark:text-indigo-300">
            <i data-lucide="info" class="w-3.5 h-3.5 inline mr-1"></i>
            Punctuality penalty: 3 late arrivals in a month automatically trigger a half-day casual leave deduction.
        </div>
    </div>

    <div class="pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
        <span>Authoritative RuleResolver Governed</span>
        <?php if (!empty($canViewRules)): ?>
            <a href="<?= base_url('rules?domain=ATTENDANCE') ?>" class="text-indigo-600 dark:text-indigo-400 font-bold hover:underline">
                View Rule Details &rarr;
            </a>
        <?php endif; ?>
    </div>
</div>
