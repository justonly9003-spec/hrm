<?php
/**
 * Widget: Today's Live Workforce Activity Highlights (Compact Executive Preview)
 */
$logs = $logs ?? ($data['attendance_today_logs'] ?? []);
$date = $date ?? ($data['today'] ?? date('Y-m-d'));
$perm = new \App\Services\PermissionService();
$userId = session()->get('user_id');
$canExportAtt = $perm->hasAccess($userId, 'attendance', 'export', $role ?? null);
$canManageAtt = $perm->hasAccess($userId, 'attendance', 'manage', $role ?? null)
    || $perm->hasAccess($userId, 'attendance', 'regularize_approve', $role ?? null);
?>

<div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-5 shadow-xs space-y-4 w-full">
    
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
        <div>
            <div class="flex items-center gap-2 mb-0.5">
                <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <h3 class="font-bold text-slate-900 dark:text-white text-sm">Today's Live Workforce Activity (<?= esc($date) ?>)</h3>
            </div>
            <p class="text-xs text-slate-500 dark:text-slate-400">Executive attendance snapshot and real-time punch arrivals</p>
        </div>

        <div class="flex items-center gap-2 flex-wrap">
            <button 
                type="button"
                @click="typeof setTab === 'function' ? setTab('today') : window.location.href='<?= base_url('attendance?tab=today') ?>'" 
                class="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs inline-flex items-center gap-2 transition shadow-xs cursor-pointer"
            >
                <i data-lucide="calendar-check" class="w-4 h-4"></i>
                <span>Open Full Today's Muster (<?= count($logs) ?> Staff)</span>
                <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
            </button>
            <?php if (!empty($canExportAtt)): ?>
                <a href="<?= base_url('attendance/export?date=' . $date) ?>" class="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs inline-flex items-center gap-1.5 transition">
                    <i data-lucide="download" class="w-3.5 h-3.5"></i>
                    Export CSV
                </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Compact Recent Activity Table -->
    <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse text-xs">
            <thead>
                <tr class="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 font-bold border-b border-slate-100 dark:border-slate-800">
                    <th class="p-3">Employee</th>
                    <th class="p-3">Department & Shift</th>
                    <th class="p-3">Check-In</th>
                    <th class="p-3">Check-Out</th>
                    <th class="p-3">Worked Hours</th>
                    <th class="p-3">Status</th>
                    <th class="p-3 text-right">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                <?php if (empty($logs)): ?>
                    <tr>
                        <td colspan="7" class="py-10 text-center text-slate-400 text-xs">
                            <i data-lucide="calendar-x" class="w-8 h-8 mx-auto mb-2 opacity-50"></i>
                            No attendance records recorded for today yet.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php 
                        $previewLogs = array_slice($logs, 0, 6);
                        foreach ($previewLogs as $l): 
                            $status = $l['status'] ?? 'Present';
                            $isLate = ($status === 'Late') || (!empty($l['late_minutes']) && (int)$l['late_minutes'] > 0);
                            $lateMins = (int)($l['late_minutes'] ?? 0);
                            $workHrs = (float)($l['working_hours'] ?? 0);

                            $statusBadgeClass = match($status) {
                                'Present', 'Present (Early Closure)', 'Early Closure Covered', 'Approved Early Closure', 'Off-Day Work', 'Weekend Duty Present', 'Holiday Duty Present' => 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800',
                                'Late'      => 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400 border-amber-200 dark:border-amber-800',
                                'Early Out' => 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400 border-amber-200 dark:border-amber-800',
                                'Half Day'  => 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-400 border-indigo-200 dark:border-indigo-800',
                                'On Leave', 'Paid Leave', 'Unpaid Leave' => 'bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-400 border-purple-200 dark:border-purple-800',
                                'Absent'    => 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400 border-rose-200 dark:border-rose-800',
                                default     => 'bg-slate-50 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-slate-200'
                            };
                    ?>
                        <tr class="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition">
                            <td class="p-3">
                                <div class="flex items-center gap-2">
                                    <div class="w-7 h-7 rounded-full overflow-hidden bg-slate-100 dark:bg-slate-800 shrink-0">
                                        <?php if (!empty($l['photo'])): ?>
                                            <img src="<?= esc($l['photo']) ?>" alt="<?= esc($l['employee_name'] ?? 'Staff') ?>" class="w-full h-full object-cover" />
                                        <?php else: ?>
                                            <div class="w-full h-full flex items-center justify-center bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 font-bold text-[10px]">
                                                <?= strtoupper(substr($l['employee_name'] ?? 'E', 0, 2)) ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div>
                                        <span class="font-bold text-slate-900 dark:text-white block leading-tight"><?= esc($l['employee_name'] ?? 'Staff') ?></span>
                                        <span class="text-[10px] text-slate-400 font-mono"><?= esc($l['employee_code'] ?? $l['employee_id'] ?? '') ?></span>
                                    </div>
                                </div>
                            </td>
                            <td class="p-3">
                                <span class="font-semibold text-slate-800 dark:text-slate-200 block"><?= esc($l['department_name'] ?? 'General') ?></span>
                                <span class="text-[10px] text-slate-400 font-mono"><?= esc($l['shift_name'] ?? 'Standard') ?></span>
                            </td>
                            <td class="p-3 font-mono font-bold text-slate-900 dark:text-white">
                                <?= !empty($l['check_in']) ? esc($l['check_in']) : '--:--:--' ?>
                                <?php if ($lateMins > 0): ?>
                                    <span class="text-[10px] font-normal text-amber-600 dark:text-amber-400 block">+<?= $lateMins ?>m late</span>
                                <?php endif; ?>
                            </td>
                            <td class="p-3 font-mono font-bold text-slate-900 dark:text-white">
                                <?= !empty($l['check_out']) ? esc($l['check_out']) : '--:--:--' ?>
                            </td>
                            <td class="p-3 font-mono font-bold text-indigo-700 dark:text-indigo-400">
                                <?= $workHrs > 0 ? number_format($workHrs, 2) . 'h' : '0.00h' ?>
                            </td>
                            <td class="p-3">
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-extrabold border <?= $statusBadgeClass ?>">
                                    <?= esc($status) ?>
                                </span>
                            </td>
                            <td class="p-3 text-right">
                                <div class="flex items-center justify-end gap-1">
                                    <button
                                        type="button"
                                        @click="typeof openDiagnosticLog === 'function' ? openDiagnosticLog(<?= htmlspecialchars(json_encode($l), ENT_QUOTES, 'UTF-8') ?>) : window.location.href='<?= base_url('attendance?tab=today') ?>'"
                                        class="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-lg transition cursor-pointer"
                                        title="View Full Day Diagnostics"
                                    >
                                        <i data-lucide="eye" class="w-3.5 h-3.5"></i>
                                    </button>
                                    <?php if (!empty($canManageAtt)): ?>
                                        <button
                                            type="button"
                                            @click="typeof openCorrectionFor === 'function' ? openCorrectionFor('<?= esc($l['employee_id'] ?? '') ?>', '<?= esc($l['date'] ?? $date) ?>', '<?= esc($l['check_in'] ?? '09:00') ?>', '<?= esc($l['check_out'] ?? '18:00') ?>') : window.location.href='<?= base_url('attendance?tab=corrections') ?>'"
                                            class="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-md text-[10px] font-bold transition cursor-pointer"
                                        >
                                            Regularize
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
        <span class="text-slate-400">
            Showing <?= min(6, count($logs)) ?> of <?= count($logs) ?> attendance records today.
        </span>
        <button 
            type="button"
            @click="typeof setTab === 'function' ? setTab('today') : window.location.href='<?= base_url('attendance?tab=today') ?>'" 
            class="font-bold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 flex items-center gap-1 cursor-pointer"
        >
            <span>View Full Muster Roll with all filters</span>
            <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
        </button>
    </div>
</div>
