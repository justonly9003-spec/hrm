<?php
    /**
     * Staff Leave & Absence Calendar Component / Widget
     * CodeIgniter 4 View with High-Fidelity Reactive Alpine.js Architecture
     * Dynamic Company-Scoped Workforce Roster & Absence Matrix
     */

    $metrics = $metrics ?? [];
    $calendarMatrix = $calendarMatrix ?? $metrics['calendar_matrix'] ?? $metrics['workforce']['calendar_matrix'] ?? null;
    $departments = $departments ?? $metrics['workforce']['departments'] ?? $metrics['departments'] ?? [];
    $branches = $branches ?? $metrics['workforce']['branches'] ?? $metrics['branches'] ?? [];
    $dbEmployees = !empty($employees) ? $employees : ($metrics['workforce']['all_employees'] ?? $metrics['workforce']['employees'] ?? $metrics['all_employees'] ?? []);
    $dbLeaves = !empty($allLeaveApplications) ? $allLeaveApplications : ($metrics['workforce']['all_leave_applications'] ?? $metrics['workforce']['pending_leaves'] ?? $metrics['all_leave_applications'] ?? []);
    $dbHolidays = !empty($holidays) ? $holidays : ($metrics['workforce']['holidays'] ?? $metrics['holidays'] ?? []);
    // Multi-tenant & Role-aware Company Resolution
    $session = function_exists('session') ? session() : null;
    $userRole = $session ? (string)($session->get('role') ?? $session->get('role_code') ?? '') : '';
    $canonicalRole = strtolower(trim($userRole));
    $isAppAdmin = in_array($canonicalRole, ['software_app_admin', 'superadmin'], true);

    // Multi-tenant isolation:
    // If App Admin: ONLY use explicitly selected company ID ($companyId or session selected_company_id).
    // If no company selected, DO NOT fallback to any random company.
    // If Tenant user: use provided $companyId, metrics company_id, or session company_id.
    $companyId = $companyId ?? ($company['id'] ?? null);
    if ($isAppAdmin) {
        $companyId = $companyId ?: ($session ? $session->get('selected_company_id') : null);
    } else {
        $companyId = $companyId ?: ($metrics['workforce']['company_id'] ?? ($session ? $session->get('company_id') : null));
    }

    $companyName = $company['name'] ?? $company['company_name'] ?? null;
    if ($companyId && empty($companyName)) {
        try {
            $compModel = new \App\Models\CompanyModel();
            $compRow = $compModel->find($companyId);
            $companyName = $compRow['name'] ?? $compRow['company_name'] ?? null;
        } catch (\Throwable $e) {}
    }
    $todayStr = date('Y-m-d');
    $currentYear = (int)($calYear ?? date('Y'));
    $currentMonthNum = (int)($calMonth ?? date('n')); // 1-12
    $currentMonthIdx = max(0, $currentMonthNum - 1); // 0-11

    // Fallback seed employees if table is completely empty
    $defaultEmployees = [
        [
            'id' => 'EMP-101',
            'employee_code' => 'EMP-101',
            'name' => 'Tariqul Islam',
            'email' => 'tariqul.islam@company.com',
            'phone' => '+880 1711-223344',
            'role' => 'Managing Director',
            'departmentId' => 'DEPT-EXEC',
            'departmentName' => 'Executive Management',
            'designationId' => 'DESG-MD',
            'designationName' => 'Managing Director',
            'branchId' => 'BR-01',
            'branchName' => 'Corporate HQ (Dhaka)',
            'companyId' => $companyId ?? 'COMP-001',
            'avatar' => 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
            'emergencyContact' => '+880 1711-001122'
        ],
        [
            'id' => 'EMP-102',
            'employee_code' => 'EMP-102',
            'name' => 'Tasnim Ahmed',
            'email' => 'tasnim.hr@company.com',
            'phone' => '+880 1812-334455',
            'role' => 'HR Manager',
            'departmentId' => 'DEPT-HR',
            'departmentName' => 'Human Resources',
            'designationId' => 'DESG-HR-MGR',
            'designationName' => 'HR Manager',
            'branchId' => 'BR-01',
            'branchName' => 'Corporate HQ (Dhaka)',
            'companyId' => $companyId ?? 'COMP-001',
            'avatar' => 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150',
            'emergencyContact' => '+880 1812-998877'
        ],
        [
            'id' => 'EMP-103',
            'employee_code' => 'EMP-103',
            'name' => 'Mahmudul Hasan',
            'email' => 'mahmud.ops@company.com',
            'phone' => '+880 1915-667788',
            'role' => 'Operations Specialist',
            'departmentId' => 'DEPT-OPS',
            'departmentName' => 'Operations & Logistics',
            'designationId' => 'DESG-OPS-SPEC',
            'designationName' => 'Operations Lead',
            'branchId' => 'BR-01',
            'branchName' => 'Corporate HQ (Dhaka)',
            'companyId' => $companyId ?? 'COMP-001',
            'avatar' => 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
            'emergencyContact' => '+880 1911-778899'
        ],
        [
            'id' => 'EMP-104',
            'employee_code' => 'EMP-104',
            'name' => 'Rafiqul Islam',
            'email' => 'rafiq.dev@company.com',
            'phone' => '+880 1515-556677',
            'role' => 'Junior Developer',
            'departmentId' => 'DEPT-ENG',
            'departmentName' => 'Software Engineering',
            'designationId' => 'DESG-ENG-JR',
            'designationName' => 'Software Engineer',
            'branchId' => 'BR-02',
            'branchName' => 'Innovation Hub (Chittagong)',
            'companyId' => $companyId ?? 'COMP-001',
            'avatar' => 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150',
            'emergencyContact' => '+880 1511-223344'
        ],
        [
            'id' => 'EMP-105',
            'employee_code' => 'EMP-105',
            'name' => 'Mehedi Hasan',
            'email' => 'mehedi.qa@company.com',
            'phone' => '+880 1616-667788',
            'role' => 'QA Engineer',
            'departmentId' => 'DEPT-ENG',
            'departmentName' => 'Software Engineering',
            'designationId' => 'DESG-ENG-QA',
            'designationName' => 'Senior QA Engineer',
            'branchId' => 'BR-02',
            'branchName' => 'Innovation Hub (Chittagong)',
            'companyId' => $companyId ?? 'COMP-001',
            'avatar' => 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
            'emergencyContact' => '+880 1611-332211'
        ],
        [
            'id' => 'EMP-106',
            'employee_code' => 'EMP-106',
            'name' => 'Nusrat Jahan',
            'email' => 'nusrat.tech@company.com',
            'phone' => '+880 1718-889900',
            'role' => 'Lead Architect',
            'departmentId' => 'DEPT-ENG',
            'departmentName' => 'Software Engineering',
            'designationId' => 'DESG-ENG-SR',
            'designationName' => 'Principal Software Architect',
            'branchId' => 'BR-01',
            'branchName' => 'Corporate HQ (Dhaka)',
            'companyId' => $companyId ?? 'COMP-001',
            'avatar' => 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=150',
            'emergencyContact' => '+880 1719-776655'
        ],
        [
            'id' => 'EMP-107',
            'employee_code' => 'EMP-107',
            'name' => 'Farhana Yeasmin',
            'email' => 'farhana.eng@company.com',
            'phone' => '+880 1819-990011',
            'role' => 'Head of Engineering',
            'departmentId' => 'DEPT-ENG',
            'departmentName' => 'Software Engineering',
            'designationId' => 'DESG-ENG-DIR',
            'designationName' => 'Director of Engineering',
            'branchId' => 'BR-01',
            'branchName' => 'Corporate HQ (Dhaka)',
            'companyId' => $companyId ?? 'COMP-001',
            'avatar' => 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150',
            'emergencyContact' => '+880 1811-334455'
        ],
        [
            'id' => 'EMP-108',
            'employee_code' => 'EMP-108',
            'name' => 'Sadia Khan',
            'email' => 'sadia.hro@company.com',
            'phone' => '+880 1714-556677',
            'role' => 'HR Officer',
            'departmentId' => 'DEPT-HR',
            'departmentName' => 'Human Resources',
            'designationId' => 'DESG-HR-EXEC',
            'designationName' => 'HR Officer',
            'branchId' => 'BR-01',
            'branchName' => 'Corporate HQ (Dhaka)',
            'companyId' => $companyId ?? 'COMP-001',
            'avatar' => 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150',
            'emergencyContact' => '+880 1711-889900'
        ],
        [
            'id' => 'EMP-109',
            'employee_code' => 'EMP-109',
            'name' => 'Kazi Nazrul Islam',
            'email' => 'kazi.finance@company.com',
            'phone' => '+880 1911-223344',
            'role' => 'Finance Manager',
            'departmentId' => 'DEPT-FIN',
            'departmentName' => 'Finance & Accounts',
            'designationId' => 'DESG-MGR-FIN',
            'designationName' => 'Head of Accounts & Finance',
            'branchId' => 'BR-01',
            'branchName' => 'Corporate HQ (Dhaka)',
            'companyId' => $companyId ?? 'COMP-001',
            'avatar' => 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150',
            'emergencyContact' => '+880 1912-998877'
        ]
    ];

    // Format employees for JS injection
    $defaultAvatarUrl = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150';
    $isHRAdmin = !empty($isHRAdmin) || $isAppAdmin;
    $canViewSensitiveContact = $isHRAdmin || in_array($canonicalRole, ['software_app_admin', 'superadmin', 'company_admin', 'hr_admin', 'hr_officer', 'manager', 'branch_manager'], true);
    $currentEmpId = (string)($currentEmpId ?? ($session ? ($session->get('employee_id') ?? '') : ''));
    $allowContact = $canViewSensitiveContact;

    $formattedEmployees = [];
    if (!empty($dbEmployees)) {
        foreach ($dbEmployees as $emp) {
            $empIdVal = (string)($emp['id'] ?? $emp['employee_code'] ?? '');
            $isSelf = !empty($currentEmpId) && ($empIdVal === $currentEmpId);
            $allowContact = $canViewSensitiveContact || $isSelf;

            $empName = trim((string)($emp['name'] ?? ''));
            if ($empName === '') {
                $empName = trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? ''));
            }
            if ($empName === '') {
                $empName = (string)($emp['employee_code'] ?? $empIdVal);
            }

            $photoVal = $emp['avatar'] ?? $emp['photo'] ?? $emp['employee_avatar'] ?? null;
            if (!empty($photoVal) && is_string($photoVal) && trim($photoVal) !== '') {
                $avatarVal = (str_starts_with($photoVal, 'http') || str_starts_with($photoVal, 'data:'))
                    ? $photoVal
                    : base_url(ltrim($photoVal, '/'));
            } else {
                $avatarVal = $defaultAvatarUrl;
            }

            $formattedEmployees[] = [
                'id'               => $empIdVal,
                'employee_code'    => (string)($emp['employee_code'] ?? $emp['id'] ?? ''),
                'name'             => $empName,
                'email'            => (string)($emp['email'] ?? ''),
                'phone'            => $allowContact ? (string)($emp['phone'] ?? '') : '',
                'role'             => (string)($emp['role'] ?? $emp['designation_name'] ?? 'Staff'),
                'departmentId'     => (string)($emp['departmentId'] ?? $emp['department_id'] ?? ''),
                'departmentName'   => (string)($emp['department_name'] ?? ''),
                'designationId'    => (string)($emp['designationId'] ?? $emp['designation_id'] ?? ''),
                'designationName'  => (string)($emp['designation_name'] ?? ''),
                'branchId'         => (string)($emp['branchId'] ?? $emp['branch_id'] ?? ''),
                'branchName'       => (string)($emp['branch_name'] ?? ''),
                'companyId'        => (string)($emp['companyId'] ?? $emp['company_id'] ?? $companyId ?? ''),
                'avatar'           => $avatarVal,
                'photo'            => $avatarVal,
                'emergencyContact' => $allowContact ? (string)($emp['emergencyContact'] ?? $emp['emergency_contact'] ?? '') : ''
            ];
        }
    } elseif (empty($companyId)) {
        $formattedEmployees = array_map(function($emp) use ($canViewSensitiveContact, $defaultAvatarUrl) {
            if (!$canViewSensitiveContact) {
                $emp['phone'] = '';
                $emp['emergencyContact'] = '';
            }
            if (empty($emp['avatar'])) {
                $emp['avatar'] = $defaultAvatarUrl;
                $emp['photo'] = $defaultAvatarUrl;
            }
            return $emp;
        }, $defaultEmployees);
    }

    // Ensure any employee present in $dbLeaves is also registered in $formattedEmployees
    if (!empty($dbLeaves)) {
        $registeredIds = array_column($formattedEmployees, 'id');
        $registeredCodes = array_filter(array_column($formattedEmployees, 'employee_code'));
        foreach ($dbLeaves as $lv) {
            $lEmpId = (string)($lv['employee_id'] ?? $lv['employeeId'] ?? '');
            $lEmpCode = (string)($lv['employee_code'] ?? '');
            if ($lEmpId === '' && $lEmpCode === '') {
                continue;
            }
            if (in_array($lEmpId, $registeredIds, true) || ($lEmpCode !== '' && in_array($lEmpCode, $registeredCodes, true))) {
                continue;
            }

            $lEmpName = trim(($lv['first_name'] ?? '') . ' ' . ($lv['last_name'] ?? ''));
            if ($lEmpName === '') {
                $lEmpName = trim((string)($lv['employee_name'] ?? $lv['name'] ?? ''));
            }
            if ($lEmpName === '') {
                $lEmpName = $lEmpCode ?: $lEmpId;
            }

            $lPhoto = $lv['photo'] ?? $lv['avatar'] ?? $lv['employee_avatar'] ?? null;
            if (!empty($lPhoto) && is_string($lPhoto) && trim($lPhoto) !== '') {
                $lAvatar = (str_starts_with($lPhoto, 'http') || str_starts_with($lPhoto, 'data:'))
                    ? $lPhoto
                    : base_url(ltrim($lPhoto, '/'));
            } else {
                $lAvatar = $defaultAvatarUrl;
            }

            $formattedEmployees[] = [
                'id'               => $lEmpId ?: $lEmpCode,
                'employee_code'    => $lEmpCode ?: $lEmpId,
                'name'             => $lEmpName,
                'email'            => '',
                'phone'            => '',
                'role'             => (string)($lv['employee_designation'] ?? $lv['designation_name'] ?? 'Staff'),
                'departmentId'     => (string)($lv['department_id'] ?? $lv['employee_department_id'] ?? ''),
                'departmentName'   => (string)($lv['department_name'] ?? ''),
                'designationId'    => '',
                'designationName'  => (string)($lv['employee_designation'] ?? $lv['designation_name'] ?? ''),
                'branchId'         => (string)($lv['branch_id'] ?? $lv['employee_branch_id'] ?? ''),
                'branchName'       => (string)($lv['branch_name'] ?? ''),
                'companyId'        => (string)($lv['company_id'] ?? $companyId ?? ''),
                'avatar'           => $lAvatar,
                'photo'            => $lAvatar,
                'emergencyContact' => ''
            ];
            $registeredIds[] = $lEmpId ?: $lEmpCode;
            if ($lEmpCode !== '') {
                $registeredCodes[] = $lEmpCode;
            }
        }
    }

    // Fallback seed leaves if table empty
    $defaultLeaves = [
        [
            'id' => 'LV-201',
            'employeeId' => 'EMP-104',
            'leaveType' => 'sick',
            'leaveTypeName' => 'Sick Leave',
            'startDate' => '2026-07-01',
            'endDate' => '2026-07-02',
            'totalDays' => 2,
            'reason' => 'Suffering from viral fever and severe headache.',
            'status' => 'Approved',
            'appliedOn' => '2026-06-30'
        ],
        [
            'id' => 'LV-206',
            'employeeId' => 'EMP-106',
            'leaveType' => 'annual',
            'leaveTypeName' => 'Annual Leave',
            'startDate' => '2026-07-08',
            'endDate' => '2026-07-10',
            'totalDays' => 3,
            'reason' => 'Outstation technology conference and family meetup.',
            'status' => 'Approved',
            'appliedOn' => '2026-07-01'
        ],
        [
            'id' => 'LV-204',
            'employeeId' => 'EMP-108',
            'leaveType' => 'casual',
            'leaveTypeName' => 'Casual Leave',
            'startDate' => '2026-07-12',
            'endDate' => '2026-07-13',
            'totalDays' => 2,
            'reason' => 'Attending family wedding ceremony.',
            'status' => 'Approved',
            'appliedOn' => '2026-07-08'
        ],
        [
            'id' => 'LV-205',
            'employeeId' => 'EMP-109',
            'leaveType' => 'sick',
            'leaveTypeName' => 'Sick Leave',
            'startDate' => '2026-07-12',
            'endDate' => '2026-07-12',
            'totalDays' => 1,
            'isHalfDay' => true,
            'halfDaySession' => 'Second Half',
            'reason' => 'Routine dental checkup and prescription renewal.',
            'status' => 'Approved',
            'appliedOn' => '2026-07-11'
        ],
        [
            'id' => 'LV-207',
            'employeeId' => 'EMP-103',
            'leaveType' => 'emergency',
            'leaveTypeName' => 'Emergency Leave',
            'startDate' => '2026-07-22',
            'endDate' => '2026-07-23',
            'totalDays' => 2,
            'reason' => 'Urgent home maintenance and repair following heavy rain.',
            'status' => 'Approved',
            'appliedOn' => '2026-07-21'
        ],
        [
            'id' => 'LV-203',
            'employeeId' => 'EMP-104',
            'leaveType' => 'casual',
            'leaveTypeName' => 'Casual Leave',
            'startDate' => '2026-07-25',
            'endDate' => '2026-07-25',
            'totalDays' => 1,
            'reason' => 'Urgent personal work and banking formalities at home.',
            'status' => 'Pending',
            'appliedOn' => '2026-07-12'
        ],
        [
            'id' => 'LV-208',
            'employeeId' => 'EMP-102',
            'leaveType' => 'casual',
            'leaveTypeName' => 'Casual Leave',
            'startDate' => '2026-07-28',
            'endDate' => '2026-07-29',
            'totalDays' => 2,
            'reason' => 'Family anniversary celebration and personal time off.',
            'status' => 'Pending',
            'appliedOn' => '2026-07-15'
        ]
    ];

    // Format leaves for JS injection (Strictly Approved & Pending; exclude Rejected, Cancelled, Withdrawn)
    $formattedLeaves = [];
    if (!empty($dbLeaves)) {
        foreach ($dbLeaves as $lv) {
            $rawLeaveSt = strtolower(trim((string)($lv['status'] ?? 'Approved')));
            if (in_array($rawLeaveSt, ['rejected', 'cancelled', 'withdrawn'], true)) {
                continue;
            }
            $normLeaveSt = ($rawLeaveSt === 'approved') ? 'Approved' : 'Pending';

            $lPhoto = $lv['photo'] ?? $lv['avatar'] ?? $lv['employee_avatar'] ?? null;
            $lAvatar = (!empty($lPhoto) && is_string($lPhoto) && trim($lPhoto) !== '')
                ? ((str_starts_with($lPhoto, 'http') || str_starts_with($lPhoto, 'data:')) ? $lPhoto : base_url(ltrim($lPhoto, '/')))
                : $defaultAvatarUrl;

            $lEmpName = trim(($lv['first_name'] ?? '') . ' ' . ($lv['last_name'] ?? ''));
            if ($lEmpName === '') {
                $lEmpName = trim((string)($lv['employee_name'] ?? $lv['name'] ?? ''));
            }

            $formattedLeaves[] = [
                'id'             => (string)($lv['id'] ?? ''),
                'employeeId'     => (string)($lv['employeeId'] ?? $lv['employee_id'] ?? ''),
                'employee_code'  => (string)($lv['employee_code'] ?? ''),
                'employee_name'  => $lEmpName,
                'avatar'         => $lAvatar,
                'photo'          => $lAvatar,
                'departmentId'   => (string)($lv['departmentId'] ?? $lv['department_id'] ?? $lv['employee_department_id'] ?? ''),
                'departmentName' => (string)($lv['departmentName'] ?? $lv['department_name'] ?? ''),
                'branchId'       => (string)($lv['branchId'] ?? $lv['branch_id'] ?? $lv['employee_branch_id'] ?? ''),
                'branchName'     => (string)($lv['branchName'] ?? $lv['branch_name'] ?? ''),
                'leaveType'      => (string)strtolower($lv['leave_type_code'] ?? $lv['leave_type_name'] ?? $lv['leaveType'] ?? 'casual'),
                'leaveTypeName'  => (string)($lv['leave_type_name'] ?? $lv['leaveTypeName'] ?? 'Leave'),
                'startDate'      => (string)($lv['startDate'] ?? $lv['from_date'] ?? $lv['start_date'] ?? ''),
                'endDate'        => (string)($lv['endDate'] ?? $lv['to_date'] ?? $lv['end_date'] ?? $lv['from_date'] ?? $lv['startDate'] ?? $lv['start_date'] ?? ''),
                'totalDays'      => (float)($lv['totalDays'] ?? $lv['total_days'] ?? 1),
                'isHalfDay'      => (bool)($lv['isHalfDay'] ?? $lv['is_half_day'] ?? false),
                'halfDaySession' => (string)($lv['halfDaySession'] ?? $lv['half_day_session'] ?? 'Second Half'),
                'reason'         => (string)($lv['reason'] ?? ''),
                'status'         => $normLeaveSt,
                'appliedOn'      => (string)($lv['appliedOn'] ?? $lv['applied_at'] ?? $lv['created_at'] ?? '')
            ];
        }
    } elseif (empty($companyId)) {
        $formattedLeaves = $defaultLeaves;
    }

    // Default branches if empty
    $defaultBranches = [
        ['id' => 'BR-01', 'name' => 'Corporate HQ (Dhaka)'],
        ['id' => 'BR-02', 'name' => 'Innovation Hub (Chittagong)']
    ];

    $formattedBranches = [];
    if (!empty($branches)) {
        foreach ($branches as $b) {
            $formattedBranches[] = [
                'id'   => (string)($b['id'] ?? ''),
                'name' => (string)($b['name'] ?? ''),
                'code' => (string)($b['code'] ?? '')
            ];
        }
    } else {
        $formattedBranches = $defaultBranches;
    }

    // Default departments if empty
    $defaultDepartments = [
        ['id' => 'DEPT-HR', 'name' => 'Human Resources'],
        ['id' => 'DEPT-ENG', 'name' => 'Software Engineering'],
        ['id' => 'DEPT-FIN', 'name' => 'Finance & Accounts'],
        ['id' => 'DEPT-OPS', 'name' => 'Operations & Logistics'],
        ['id' => 'DEPT-EXEC', 'name' => 'Executive Management']
    ];

    $formattedDepartments = [];
    if (!empty($departments)) {
        foreach ($departments as $d) {
            $formattedDepartments[] = [
                'id'   => (string)($d['id'] ?? ''),
                'name' => (string)($d['name'] ?? ''),
                'code' => (string)($d['code'] ?? '')
            ];
        }
    } else {
        $formattedDepartments = $defaultDepartments;
    }

    // Default holidays if empty
    $defaultHolidays = [
        ['id' => 'H-01', 'name' => 'Eid-ul-Fitr Day 1', 'date' => '2026-04-10', 'description' => 'National Religious Holiday'],
        ['id' => 'H-02', 'name' => 'Eid-ul-Fitr Day 2', 'date' => '2026-04-11', 'description' => 'National Religious Holiday'],
        ['id' => 'H-03', 'name' => 'May Day', 'date' => '2026-05-01', 'description' => 'International Workers Day'],
        ['id' => 'H-04', 'name' => 'Buddha Purnima', 'date' => '2026-05-23', 'description' => 'Official Holiday'],
        ['id' => 'H-05', 'name' => 'Eid-ul-Adha Day 1', 'date' => '2026-06-16', 'description' => 'National Holiday'],
        ['id' => 'H-06', 'name' => 'Eid-ul-Adha Day 2', 'date' => '2026-06-17', 'description' => 'National Holiday'],
        ['id' => 'H-07', 'name' => 'National Mourning Day', 'date' => '2026-08-15', 'description' => 'Official Public Holiday'],
        ['id' => 'H-08', 'name' => 'Janmashtami', 'date' => '2026-09-04', 'description' => 'Religious Public Holiday'],
        ['id' => 'H-09', 'name' => 'Durga Puja (Bijoya Dashami)', 'date' => '2026-10-21', 'description' => 'Official Holiday'],
        ['id' => 'H-10', 'name' => 'Victory Day', 'date' => '2026-12-16', 'description' => 'National Victory Celebration']
    ];

    $formattedHolidays = [];
    if (!empty($dbHolidays)) {
        foreach ($dbHolidays as $h) {
            $formattedHolidays[] = [
                'id'          => (string)($h['id'] ?? ''),
                'name'        => (string)($h['name'] ?? $h['description'] ?? 'Public Holiday'),
                'date'        => (string)($h['date'] ?? $h['from_date'] ?? ''),
                'toDate'      => (string)($h['toDate'] ?? $h['to_date'] ?? ''),
                'description' => (string)($h['description'] ?? $h['type'] ?? 'Official Public Holiday')
            ];
        }
    } else {
        $formattedHolidays = $defaultHolidays;
    }

    // Resolve Dynamic Weekly Off Days & Required Working Days from CompanyWeekendService
    $configuredWeeklyOff = \App\Services\CompanyWeekendService::getCompanyWeeklyOff($companyId);
    $requiredWorkingDays = max(1, 7 - count($configuredWeeklyOff));
    try {
        $activeRuleProfile = \App\Services\Rules\RuleResolver::attendanceProfile(['company_id' => $companyId]);
        if (!empty($activeRuleProfile['workingWeek']['requiredWorkingDays'])) {
            $requiredWorkingDays = (int)$activeRuleProfile['workingWeek']['requiredWorkingDays'];
        }
    } catch (\Throwable $e) {}
    $configuredWeeklyOff = array_values(array_filter(array_map(static function($d) {
        $clean = trim((string)$d);
        return !empty($clean) ? ucfirst(strtolower($clean)) : null;
    }, (array)$configuredWeeklyOff)));

    // Index backend calendar matrix days by date if available
    $backendDaysMap = [];
    if (!empty($calendarMatrix['days']) && is_array($calendarMatrix['days'])) {
        foreach ($calendarMatrix['days'] as $mDay) {
            if (!empty($mDay['date'])) {
                $backendDaysMap[$mDay['date']] = [
                    'is_weekend'   => !empty($mDay['is_weekend']),
                    'is_holiday'   => !empty($mDay['is_holiday']),
                    'holiday_name' => $mDay['holiday_name'] ?? null,
                ];
            }
        }
    }
?>

<script>
    function staffLeaveCalendarComponent() {
        return {
            viewMode: 'calendar',
            currentMonth: <?= $currentMonthIdx ?>,
            currentYear: <?= $currentYear ?>,
            systemTodayStr: '<?= $todayStr ?>',
            companyId: <?= json_encode((string)($companyId ?? '')) ?>,
            companyName: <?= json_encode((string)($companyName ?? '')) ?>,
            isAppAdmin: <?= $isAppAdmin ? 'true' : 'false' ?>,
            weeklyOffDays: <?= json_encode($configuredWeeklyOff, JSON_UNESCAPED_UNICODE) ?>,
            requiredWorkingDays: <?= $requiredWorkingDays ?>,
            backendDaysMap: <?= json_encode(!empty($backendDaysMap) ? $backendDaysMap : (object)[], JSON_UNESCAPED_UNICODE) ?>,
            
            searchQuery: '',
            selectedDept: 'all',
            selectedBranch: 'all',
            selectedStatus: 'all',
            selectedLeaveType: 'all',

            selectedLeaveDetail: null,
            selectedDayDetail: null,

            monthNames: [
                'January', 'February', 'March', 'April', 'May', 'June',
                'July', 'August', 'September', 'October', 'November', 'December'
            ],

            daysOfWeek: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
            fullDayNames: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],

            isWeeklyOffDay(dayName) {
                if (!Array.isArray(this.weeklyOffDays) || !dayName) {
                    return false;
                }
                const abbrToFull = {
                    'Sun': 'Sunday', 'Mon': 'Monday', 'Tue': 'Tuesday',
                    'Wed': 'Wednesday', 'Thu': 'Thursday', 'Fri': 'Friday', 'Sat': 'Saturday'
                };
                const normalized = abbrToFull[dayName] || dayName;
                return this.weeklyOffDays.includes(normalized);
            },

            // Dynamic Company Workforce Directory
            employees: <?= json_encode($formattedEmployees, JSON_UNESCAPED_UNICODE) ?>,

            // Dynamic Departments
            departments: <?= json_encode($formattedDepartments, JSON_UNESCAPED_UNICODE) ?>,

            // Dynamic Branches
            branches: <?= json_encode($formattedBranches, JSON_UNESCAPED_UNICODE) ?>,

            // Designations
            designations: [
                { id: 'DESG-MD', title: 'Managing Director' },
                { id: 'DESG-HR-MGR', title: 'HR Manager' },
                { id: 'DESG-HR-EXEC', title: 'HR Officer' },
                { id: 'DESG-ENG-DIR', title: 'Director of Engineering' },
                { id: 'DESG-ENG-SR', title: 'Principal Software Architect' },
                { id: 'DESG-ENG-JR', title: 'Software Engineer' },
                { id: 'DESG-ENG-QA', title: 'Senior QA Engineer' },
                { id: 'DESG-MGR-FIN', title: 'Head of Accounts & Finance' },
                { id: 'DESG-OPS-SPEC', title: 'Operations Lead' }
            ],

            // Dynamic Public Holidays
            holidays: <?= json_encode($formattedHolidays, JSON_UNESCAPED_UNICODE) ?>,

            // Dynamic Leave Applications
            leaveApplications: <?= json_encode($formattedLeaves, JSON_UNESCAPED_UNICODE) ?>,

            // Date Calculations
            daysInMonth(month, year) {
                return new Date(year, month + 1, 0).getDate();
            },

            startDayOfMonth(month, year) {
                return new Date(year, month, 1).getDay();
            },

            handlePrevMonth() {
                if (this.currentMonth === 0) {
                    this.currentMonth = 11;
                    this.currentYear--;
                } else {
                    this.currentMonth--;
                }
                this.fetchCalendarMatrix();
            },

            handleNextMonth() {
                if (this.currentMonth === 11) {
                    this.currentMonth = 0;
                    this.currentYear++;
                } else {
                    this.currentMonth++;
                }
                this.fetchCalendarMatrix();
            },

            handleJumpToToday() {
                this.currentMonth = <?= $currentMonthIdx ?>;
                this.currentYear = <?= $currentYear ?>;
                this.fetchCalendarMatrix();
            },

            defaultAvatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',

            async fetchCalendarMatrix() {
                try {
                    let url = `<?= base_url('leave/calendar-matrix') ?>?year=${this.currentYear}&month=${this.currentMonth + 1}`;
                    if (this.companyId) {
                        url += `&company_id=${encodeURIComponent(this.companyId)}`;
                    }
                    const res = await fetch(url, {
                        headers: { 'X-Requested-With': 'XMLHttpRequest' }
                    });
                    if (res.ok) {
                        const data = await res.json();
                        if (data && Array.isArray(data.weekly_off_days)) {
                            this.weeklyOffDays = data.weekly_off_days;
                        }
                        if (data && Array.isArray(data.days)) {
                            const newMap = {};
                            const newLeaves = [];
                            data.days.forEach(d => {
                                if (d.date) {
                                    newMap[d.date] = {
                                        is_weekend: !!d.is_weekend,
                                        is_holiday: !!d.is_holiday,
                                        holiday_name: d.holiday_name || null
                                    };
                                }
                                if (Array.isArray(d.leaves)) {
                                    d.leaves.forEach(lv => {
                                        const av = lv.avatar || lv.photo || lv.employee_avatar || this.defaultAvatarUrl;
                                        if (lv && lv.id && !newLeaves.some(x => x.id === lv.id)) {
                                            newLeaves.push({
                                                id: String(lv.id),
                                                employeeId: String(lv.employee_id || lv.employeeId || ''),
                                                employee_code: String(lv.employee_code || ''),
                                                employee_name: String(lv.employee_name || 'Staff Member'),
                                                avatar: String(av),
                                                photo: String(av),
                                                departmentId: String(lv.department_id || ''),
                                                departmentName: String(lv.department_name || ''),
                                                branchId: String(lv.branch_id || ''),
                                                branchName: String(lv.branch_name || ''),
                                                leaveType: String(lv.type_code || lv.leave_type || 'casual').toLowerCase(),
                                                leaveTypeName: String(lv.leave_type || 'Leave'),
                                                startDate: String(lv.from_date || lv.startDate || ''),
                                                endDate: String(lv.to_date || lv.endDate || lv.from_date || ''),
                                                totalDays: parseFloat(lv.total_days || 1),
                                                isHalfDay: !!lv.is_half_day,
                                                halfDaySession: String(lv.half_day_session || 'Second Half'),
                                                reason: String(lv.reason || ''),
                                                status: String(lv.status || 'Approved'),
                                                appliedOn: String(lv.applied_at || lv.appliedOn || '')
                                            });
                                        }
                                        if (lv && lv.employee_id && !this.employees.some(e => String(e.id) === String(lv.employee_id) || (lv.employee_code && String(e.employee_code) === String(lv.employee_code)))) {
                                            this.employees.push({
                                                id: String(lv.employee_id),
                                                employee_code: String(lv.employee_code || ''),
                                                name: String(lv.employee_name || 'Staff Member'),
                                                email: '',
                                                phone: '',
                                                role: String(lv.employee_designation || lv.designation_name || 'Staff'),
                                                departmentId: String(lv.department_id || ''),
                                                departmentName: String(lv.department_name || ''),
                                                branchId: String(lv.branch_id || ''),
                                                branchName: String(lv.branch_name || ''),
                                                companyId: String(this.companyId || ''),
                                                avatar: String(av),
                                                photo: String(av),
                                                emergencyContact: ''
                                            });
                                        }
                                    });
                                }
                            });
                            this.backendDaysMap = newMap;
                            if (newLeaves.length > 0) {
                                newLeaves.forEach(nl => {
                                    const existingIdx = this.leaveApplications.findIndex(x => x.id === nl.id);
                                    if (existingIdx >= 0) {
                                        this.leaveApplications[existingIdx] = nl;
                                    } else {
                                        this.leaveApplications.push(nl);
                                    }
                                });
                            }
                        }
                    }
                } catch (e) {
                    // Graceful fallback to client calculation
                }
            },

            getEmployee(id) {
                if (!id) return undefined;
                let emp = this.employees.find(e => String(e.id) === String(id) || (e.employee_code && String(e.employee_code) === String(id)));
                if (!emp) {
                    const lv = this.leaveApplications.find(l => String(l.employeeId) === String(id) || (l.employee_code && String(l.employee_code) === String(id)));
                    if (lv) {
                        const av = lv.avatar || lv.photo || lv.employee_avatar || this.defaultAvatarUrl;
                        emp = {
                            id: String(lv.employeeId || id),
                            employee_code: String(lv.employee_code || ''),
                            name: String(lv.employee_name || lv.employeeName || lv.name || 'Staff Member'),
                            avatar: String(av),
                            photo: String(av),
                            departmentId: String(lv.departmentId || lv.department_id || ''),
                            departmentName: String(lv.departmentName || lv.department_name || ''),
                            branchId: String(lv.branchId || lv.branch_id || ''),
                            branchName: String(lv.branch_name || ''),
                            role: String(lv.employee_designation || lv.designation_name || 'Staff')
                        };
                        this.employees.push(emp);
                    }
                }
                return emp;
            },

            getAvatar(emp) {
                if (emp && emp.avatar && typeof emp.avatar === 'string' && emp.avatar.trim() !== '' && !emp.avatar.includes('undefined')) {
                    return emp.avatar;
                }
                if (emp && emp.photo && typeof emp.photo === 'string' && emp.photo.trim() !== '' && !emp.photo.includes('undefined')) {
                    return emp.photo;
                }
                return this.defaultAvatarUrl;
            },

            getDepartment(id) {
                return this.departments.find(d => d.id === id);
            },

            getBranch(id) {
                return this.branches.find(b => b.id === id);
            },

            getDesignation(id) {
                return this.designations.find(d => d.id === id);
            },

            getLeaveTypeColor(type) {
                const t = (type || '').toLowerCase();
                if (t.includes('sick') || t.includes('med')) {
                    return {
                        bg: 'bg-rose-50/90 dark:bg-rose-950/40',
                        border: 'border-rose-200 dark:border-rose-900',
                        text: 'text-rose-700 dark:text-rose-300',
                        dot: 'bg-rose-500',
                        badge: 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                    };
                }
                if (t.includes('casual')) {
                    return {
                        bg: 'bg-emerald-50/90 dark:bg-emerald-950/40',
                        border: 'border-emerald-200 dark:border-emerald-900',
                        text: 'text-emerald-700 dark:text-emerald-300',
                        dot: 'bg-emerald-500',
                        badge: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                    };
                }
                if (t.includes('annual') || t.includes('earned') || t.includes('vacation')) {
                    return {
                        bg: 'bg-blue-50/90 dark:bg-blue-950/40',
                        border: 'border-blue-200 dark:border-blue-900',
                        text: 'text-blue-700 dark:text-blue-300',
                        dot: 'bg-blue-500',
                        badge: 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                    };
                }
                if (t.includes('matern') || t.includes('patern') || t.includes('parental')) {
                    return {
                        bg: 'bg-purple-50/90 dark:bg-purple-950/40',
                        border: 'border-purple-200 dark:border-purple-900',
                        text: 'text-purple-700 dark:text-purple-300',
                        dot: 'bg-purple-500',
                        badge: 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300'
                    };
                }
                if (t.includes('emergency')) {
                    return {
                        bg: 'bg-amber-50/90 dark:bg-amber-950/40',
                        border: 'border-amber-200 dark:border-amber-900',
                        text: 'text-amber-700 dark:text-amber-300',
                        dot: 'bg-amber-500',
                        badge: 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                    };
                }
                return {
                    bg: 'bg-slate-100/90 dark:bg-slate-800/60',
                    border: 'border-slate-200 dark:border-slate-700',
                    text: 'text-slate-700 dark:text-slate-300',
                    dot: 'bg-slate-500',
                    badge: 'bg-slate-200 text-slate-800 dark:bg-slate-800 dark:text-slate-300'
                };
            },

            get filteredLeaveApplications() {
                const query = this.searchQuery.toLowerCase().trim();
                return this.leaveApplications.filter(l => {
                    const st = String(l.status || '').toLowerCase();
                    if (['rejected', 'cancelled', 'withdrawn'].includes(st)) {
                        return false;
                    }
                    const emp = this.getEmployee(l.employeeId);
                    if (!emp) return false;

                    if (query) {
                        const matchName = emp.name.toLowerCase().includes(query);
                        const matchId = emp.id.toLowerCase().includes(query);
                        if (!matchName && !matchId) return false;
                    }

                    if (this.selectedDept !== 'all' && emp.departmentId !== this.selectedDept) {
                        return false;
                    }

                    if (this.selectedBranch !== 'all' && emp.branchId !== this.selectedBranch) {
                        return false;
                    }

                    if (this.selectedStatus !== 'all' && l.status !== this.selectedStatus) {
                        return false;
                    }

                    if (this.selectedLeaveType !== 'all') {
                        const typeKey = (l.leaveType || '').toLowerCase();
                        if (!typeKey.includes(this.selectedLeaveType.toLowerCase())) {
                            return false;
                        }
                    }

                    return true;
                });
            },

            get staffOnLeaveToday() {
                const today = this.systemTodayStr;
                return this.filteredLeaveApplications
                    .filter(l => today >= l.startDate && today <= l.endDate && !['Rejected', 'Cancelled', 'Withdrawn'].includes(l.status))
                    .map(l => ({ leave: l, employee: this.getEmployee(l.employeeId) }))
                    .filter(item => item.employee !== undefined);
            },

            get staffOnLeaveThisMonth() {
                const m = this.currentMonth + 1;
                const mStr = String(m).padStart(2, '0');
                const monthStart = `${this.currentYear}-${mStr}-01`;
                const numDays = this.daysInMonth(this.currentMonth, this.currentYear);
                const monthEnd = `${this.currentYear}-${mStr}-${String(numDays).padStart(2, '0')}`;

                return this.filteredLeaveApplications.filter(l => {
                    return l.startDate <= monthEnd && l.endDate >= monthStart && !['Rejected', 'Cancelled', 'Withdrawn'].includes(l.status);
                });
            },

            get holidaysInThisMonth() {
                const m = this.currentMonth + 1;
                const mStr = String(m).padStart(2, '0');
                const prefix = `${this.currentYear}-${mStr}`;
                return this.holidays.filter(h => h.date.startsWith(prefix));
            },

            getLeavesOnDay(dateStr) {
                return this.filteredLeaveApplications
                    .filter(l => dateStr >= l.startDate && dateStr <= l.endDate && !['Rejected', 'Cancelled', 'Withdrawn'].includes(l.status))
                    .map(l => {
                        let emp = this.getEmployee(l.employeeId);
                        if (!emp) {
                            const av = l.avatar || l.photo || l.employee_avatar || this.defaultAvatarUrl;
                            emp = {
                                id: String(l.employeeId || ''),
                                employee_code: String(l.employee_code || ''),
                                name: String(l.employee_name || l.employeeName || l.name || 'Staff Member'),
                                avatar: String(av),
                                photo: String(av),
                                departmentId: String(l.departmentId || l.department_id || ''),
                                departmentName: String(l.departmentName || l.department_name || ''),
                                branchId: String(l.branchId || l.branch_id || ''),
                                branchName: String(l.branch_name || ''),
                                role: 'Staff'
                            };
                        }
                        return { leave: l, employee: emp };
                    });
            },

            getHolidayOnDay(dateStr) {
                return this.holidays.find(h => h.date === dateStr);
            },

            approveLeave(leaveId) {
                const leave = this.leaveApplications.find(l => l.id === leaveId);
                if (leave) {
                    leave.status = 'Approved';
                }
                if (this.selectedLeaveDetail && this.selectedLeaveDetail.leave.id === leaveId) {
                    this.selectedLeaveDetail.leave.status = 'Approved';
                }
                // Trigger server background sync if real CI4 session is live
                try {
                    fetch('<?= base_url('leave/approve/') ?>/' + leaveId, {
                        method: 'POST',
                        headers: { 'X-Requested-With': 'XMLHttpRequest' }
                    });
                } catch(e) {}
            },

            rejectLeave(leaveId) {
                const leave = this.leaveApplications.find(l => l.id === leaveId);
                if (leave) {
                    leave.status = 'Rejected';
                }
                if (this.selectedLeaveDetail && this.selectedLeaveDetail.leave.id === leaveId) {
                    this.selectedLeaveDetail.leave.status = 'Rejected';
                }
                try {
                    fetch('<?= base_url('leave/reject/') ?>/' + leaveId, {
                        method: 'POST',
                        headers: { 'X-Requested-With': 'XMLHttpRequest' }
                    });
                } catch(e) {}
            }
        };
    }
</script>

<div id="staff-leave-calendar-root"
     x-data="staffLeaveCalendarComponent()"
     class="space-y-6 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-6 shadow-xs flex flex-col h-full">

    <!-- 1. TOP HEADER: TITLE & VIEW TOGGLES -->
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-5">
        <div>
            <div class="flex items-center gap-2">
                <span class="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-800">
                    <i data-lucide="calendar" class="w-5 h-5"></i>
                </span>
                <div>
                    <h2 class="text-lg font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
                        Staff Leave & Absence Calendar
                        <span class="text-xs font-mono font-bold px-2.5 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                            Live Roster
                        </span>
                    </h2>
                    <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                        Live schedule of staff on leave, planned team absences, and public holidays across departments.
                    </p>
                </div>
            </div>
        </div>

        <!-- View Mode Switcher -->
        <div class="flex items-center bg-slate-100/80 dark:bg-slate-800/80 p-1 rounded-2xl border border-slate-200/60 dark:border-slate-700/60 self-start md:self-auto shadow-2xs">
            <button
                id="view-calendar-grid-btn"
                @click="viewMode = 'calendar'"
                :class="viewMode === 'calendar' ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs font-bold' : 'text-slate-600 dark:text-slate-400 font-semibold hover:text-slate-900 dark:hover:text-slate-200'"
                class="px-3.5 py-1.5 rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5"
            >
                <i data-lucide="grid" class="w-3.5 h-3.5"></i>
                <span>Calendar Grid</span>
            </button>

            <button
                id="view-schedule-list-btn"
                @click="viewMode = 'list'"
                :class="viewMode === 'list' ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs font-bold' : 'text-slate-600 dark:text-slate-400 font-semibold hover:text-slate-900 dark:hover:text-slate-200'"
                class="px-3.5 py-1.5 rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5"
            >
                <i data-lucide="list" class="w-3.5 h-3.5"></i>
                <span>Schedule List</span>
            </button>

            <button
                id="view-today-roster-btn"
                @click="viewMode = 'today'"
                :class="viewMode === 'today' ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs font-bold' : 'text-slate-600 dark:text-slate-400 font-semibold hover:text-slate-900 dark:hover:text-slate-200'"
                class="px-3.5 py-1.5 rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5"
            >
                <i data-lucide="users" class="w-3.5 h-3.5"></i>
                <span>On Leave Today (<span x-text="staffOnLeaveToday.length"></span>)</span>
            </button>
        </div>
    </div>

    <!-- App Admin Notice: When no specific company is selected -->
    <div x-show="isAppAdmin && !companyId" class="p-3.5 bg-amber-50/90 dark:bg-amber-950/40 border border-amber-200/80 dark:border-amber-800/80 rounded-2xl flex items-center justify-between gap-3 text-xs text-amber-800 dark:text-amber-200">
        <div class="flex items-center gap-2.5">
            <i data-lucide="alert-circle" class="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0"></i>
            <div>
                <strong>Company Not Selected:</strong> Viewing calendar in platform overview mode. No company-specific weekly off is applied (all days active). Select a company from the switcher to view company-specific working week configuration and scheduled staff roster.
            </div>
        </div>
        <span class="px-2 py-0.5 bg-amber-200/70 dark:bg-amber-900/60 text-amber-900 dark:text-amber-200 rounded-md font-bold text-[10px] uppercase tracking-wider shrink-0">
            Platform Global
        </span>
    </div>

    <?php
        // When executive_kpis or attendance_overview_kpis is active in the same dashboard render, hide Staff On Leave Today card
        // Default is show (e.g. in leave/index.php or for employee dashboards without an attendance KPI deck)
        $hideStaffOnLeaveToday = !empty($hasExecutiveKpis) || !empty($hasAttendanceOverviewKpis) || !empty($hideLeaveTodayCard);
        $ribbonGridClass = $hideStaffOnLeaveToday ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3' : 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4';
    ?>
    <!-- 2. KPI METRICS RIBBON (<?= $hideStaffOnLeaveToday ? '3' : '4' ?> INTERACTIVE CARDS) -->
    <div class="grid <?= $ribbonGridClass ?> gap-4">
        
        <?php if (!$hideStaffOnLeaveToday): ?>
        <!-- Metric 1: Staff on Leave Today -->
        <div 
            @click="viewMode = 'today'"
            class="bg-rose-50/70 dark:bg-rose-950/20 border border-rose-100 dark:border-rose-900/40 rounded-2xl p-4 shadow-xs cursor-pointer hover:shadow-md transition group"
        >
            <div class="flex items-center justify-between">
                <span class="text-[11px] font-bold text-rose-700 dark:text-rose-400 uppercase tracking-wider">Staff On Leave Today</span>
                <span class="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
            </div>
            <div class="mt-2 flex items-baseline justify-between">
                <div class="text-2xl font-black text-rose-950 dark:text-rose-200">
                    <span x-text="staffOnLeaveToday.length"></span> <span class="text-xs font-semibold text-rose-600 dark:text-rose-400">staff</span>
                </div>
                
                <!-- Avatar Stack Preview -->
                <div class="flex -space-x-1.5 overflow-hidden">
                    <template x-for="(item, idx) in staffOnLeaveToday.slice(0, 4)" :key="idx">
                        <img
                            :src="getAvatar(item.employee)"
                            :alt="item.employee.name"
                            :title="item.employee.name + ' - ' + (item.leave.leaveTypeName || item.leave.leaveType || 'Leave')"
                            class="w-6 h-6 rounded-full border-2 border-white dark:border-slate-800 object-cover"
                            referrerpolicy="no-referrer"
                            @error="$event.target.src = defaultAvatarUrl"
                        />
                    </template>
                </div>
            </div>
            <p class="text-[10px] text-rose-700/80 dark:text-rose-400/80 mt-1 truncate"
               x-text="staffOnLeaveToday.length > 0 ? staffOnLeaveToday.map(s => s.employee.name).join(', ') : 'All staff present and on duty today'">
            </p>
        </div>
        <?php endif; ?>

        <!-- Metric 2: Month Scheduled Absences -->
        <div class="bg-indigo-50/70 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/40 rounded-2xl p-4 shadow-xs">
            <div class="flex items-center justify-between">
                <span class="text-[11px] font-bold text-indigo-700 dark:text-indigo-400 uppercase tracking-wider">
                    Leaves In <span x-text="monthNames[currentMonth]"></span>
                </span>
                <i data-lucide="calendar-days" class="w-4 h-4 text-indigo-500"></i>
            </div>
            <div class="mt-2 flex items-baseline gap-1">
                <div class="text-2xl font-black text-indigo-950 dark:text-indigo-200" x-text="staffOnLeaveThisMonth.length">
                </div>
                <span class="text-xs font-semibold text-indigo-600 dark:text-indigo-400">applications</span>
            </div>
            <p class="text-[10px] text-indigo-700/80 dark:text-indigo-400/80 mt-1">
                <span x-text="staffOnLeaveThisMonth.filter(l => l.status === 'Approved').length"></span> Approved · 
                <span x-text="staffOnLeaveThisMonth.filter(l => l.status === 'Pending').length"></span> Pending
            </p>
        </div>

        <!-- Metric 3: Holidays this month -->
        <div class="bg-emerald-50/70 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/40 rounded-2xl p-4 shadow-xs">
            <div class="flex items-center justify-between">
                <span class="text-[11px] font-bold text-emerald-700 dark:text-emerald-400 uppercase tracking-wider">Public Holidays</span>
                <span class="text-base">🌴</span>
            </div>
            <div class="mt-2 flex items-baseline gap-1">
                <div class="text-2xl font-black text-emerald-950 dark:text-emerald-200" x-text="holidaysInThisMonth.length">
                </div>
                <span class="text-xs font-semibold text-emerald-600 dark:text-emerald-400">days</span>
            </div>
            <p class="text-[10px] text-emerald-700/80 dark:text-emerald-400/80 mt-1 truncate"
               x-text="holidaysInThisMonth.length > 0 ? holidaysInThisMonth.map(h => h.name).join(', ') : 'No official public holidays in this month'">
            </p>
        </div>

        <!-- Metric 4: Total Workforce Coverage -->
        <div class="bg-amber-50/70 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900/40 rounded-2xl p-4 shadow-xs">
            <div class="flex items-center justify-between">
                <span class="text-[11px] font-bold text-amber-700 dark:text-amber-400 uppercase tracking-wider">Workforce Availability</span>
                <i data-lucide="users" class="w-4 h-4 text-amber-500"></i>
            </div>
            <div class="mt-2 flex items-baseline gap-1">
                <div class="text-2xl font-black text-amber-950 dark:text-amber-200">
                    <span x-text="Math.max(0, employees.length - staffOnLeaveToday.length)"></span> 
                    <span class="text-xs font-normal text-amber-600" x-text="'/ ' + employees.length"></span>
                </div>
                <span class="text-xs font-bold text-emerald-600 ml-auto"
                      x-text="employees.length > 0 ? Math.round(((employees.length - staffOnLeaveToday.length) / employees.length) * 100) + '%' : '100%'">
                </span>
            </div>
            <p class="text-[10px] text-amber-700/80 dark:text-amber-400/80 mt-1">
                Active staff on-premises & duty today
            </p>
        </div>
    </div>

    <!-- 3. CONTROLS BAR: MONTH NAVIGATION & SEARCH FILTERS -->
    <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 p-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 rounded-2xl">
        
        <!-- Month & Year Navigator -->
        <div class="flex items-center gap-2">
            <div class="flex items-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl shadow-2xs overflow-hidden">
                <button
                    id="prev-month-btn"
                    @click="handlePrevMonth()"
                    class="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition cursor-pointer"
                    title="Previous Month"
                >
                    <i data-lucide="chevron-left" class="w-4 h-4"></i>
                </button>
                <div class="px-4 py-1.5 text-center min-w-[140px]">
                    <span class="text-sm font-black text-slate-800 dark:text-slate-100 font-mono">
                        <span x-text="monthNames[currentMonth]"></span> <span x-text="currentYear"></span>
                    </span>
                </div>
                <button
                    id="next-month-btn"
                    @click="handleNextMonth()"
                    class="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition cursor-pointer"
                    title="Next Month"
                >
                    <i data-lucide="chevron-right" class="w-4 h-4"></i>
                </button>
            </div>

            <button
                id="jump-today-btn"
                @click="handleJumpToToday()"
                class="px-3 py-1.5 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-300 shadow-2xs transition cursor-pointer"
            >
                Today (<span x-text="(monthNames[<?= $currentMonthIdx ?>] || '').substring(0, 3) + ' \'' + String(<?= $currentYear ?>).slice(-2)"></span>)
            </button>

            <!-- Dynamic Weekly Off Day(s) Status Tag -->
            <div class="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs shadow-2xs">
                <span class="text-[11px] font-semibold text-slate-500 dark:text-slate-400">Weekly Off:</span>
                <template x-if="weeklyOffDays.length > 0">
                    <span class="font-bold text-indigo-700 dark:text-indigo-400 font-mono text-[11px]" x-text="weeklyOffDays.join(', ')"></span>
                </template>
                <template x-if="weeklyOffDays.length === 0">
                    <span class="font-bold text-slate-500 text-[11px]">None (7-Day Working)</span>
                </template>
            </div>
        </div>

        <!-- Search & Select Filters -->
        <div class="flex flex-wrap items-center gap-2">
            
            <!-- Search Box -->
            <div class="relative min-w-[180px] flex-1 sm:flex-initial">
                <i data-lucide="search" class="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"></i>
                <input
                    id="calendar-search-input"
                    type="text"
                    x-model="searchQuery"
                    placeholder="Search staff name or ID..."
                    class="w-full pl-8 pr-7 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 shadow-2xs"
                />
                <button
                    x-show="searchQuery"
                    @click="searchQuery = ''"
                    class="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                    <i data-lucide="x" class="w-3 h-3"></i>
                </button>
            </div>

            <!-- Department Filter -->
            <select
                id="calendar-dept-filter"
                x-model="selectedDept"
                class="px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 shadow-2xs cursor-pointer"
            >
                <option value="all">All Departments</option>
                <template x-for="d in departments" :key="d.id">
                    <option :value="d.id" x-text="d.name"></option>
                </template>
            </select>

            <!-- Branch Filter -->
            <select
                id="calendar-branch-filter"
                x-model="selectedBranch"
                class="px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 shadow-2xs cursor-pointer"
            >
                <option value="all">All Branches</option>
                <template x-for="b in branches" :key="b.id">
                    <option :value="b.id" x-text="b.name"></option>
                </template>
            </select>

            <!-- Status Filter -->
            <select
                id="calendar-status-filter"
                x-model="selectedStatus"
                class="px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 shadow-2xs cursor-pointer"
            >
                <option value="all">All Status</option>
                <option value="Approved">Approved Only</option>
                <option value="Pending">Pending Approvals</option>
            </select>

            <!-- Reset Filters -->
            <button
                x-show="searchQuery || selectedDept !== 'all' || selectedBranch !== 'all' || selectedStatus !== 'all' || selectedLeaveType !== 'all'"
                @click="searchQuery = ''; selectedDept = 'all'; selectedBranch = 'all'; selectedStatus = 'all'; selectedLeaveType = 'all';"
                class="px-2.5 py-1.5 text-xs text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl font-bold transition cursor-pointer"
                title="Clear all filters"
            >
                Reset
            </button>
        </div>
    </div>

    <!-- 4. CALENDAR GRID VIEW -->
    <div x-show="viewMode === 'calendar'" class="space-y-4">
        
        <!-- Day of week headers -->
        <div class="grid grid-cols-7 gap-2">
            <template x-for="(day, idx) in daysOfWeek" :key="day">
                <div 
                    :class="isWeeklyOffDay(fullDayNames[idx])
                        ? 'bg-slate-100/70 dark:bg-slate-800/40 text-slate-400 dark:text-slate-500' 
                        : 'bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300'"
                    class="py-2 text-center text-xs font-extrabold uppercase tracking-wider rounded-xl transition-colors"
                    x-text="day"
                >
                </div>
            </template>
        </div>

        <!-- Month Days Grid -->
        <div class="grid grid-cols-7 gap-2">
            
            <!-- Leading padding empty cells -->
            <template x-for="i in startDayOfMonth(currentMonth, currentYear)" :key="'empty-start-' + i">
                <div class="min-h-[115px] p-2 bg-slate-50/40 dark:bg-slate-900/20 rounded-2xl border border-dashed border-slate-200/50 dark:border-slate-800/50 opacity-30">
                </div>
            </template>

            <!-- Actual Month Days -->
            <template x-for="day in daysInMonth(currentMonth, currentYear)" :key="'day-' + day">
                <?php /* Alpine computed day block */ ?>
                <div 
                    x-data="{
                        get dateStr() {
                            const mStr = String(currentMonth + 1).padStart(2, '0');
                            const dStr = String(day).padStart(2, '0');
                            return `${currentYear}-${mStr}-${dStr}`;
                        },
                        get leavesOnDay() {
                            return getLeavesOnDay(this.dateStr);
                        },
                        get holidayOnDay() {
                            return getHolidayOnDay(this.dateStr);
                        },
                        get isToday() {
                            return this.dateStr === systemTodayStr;
                        },
                        get isWeekend() {
                            if (backendDaysMap && backendDaysMap[this.dateStr] !== undefined) {
                                const bDay = backendDaysMap[this.dateStr];
                                if (typeof bDay.is_weekend === 'boolean') {
                                    return bDay.is_weekend;
                                }
                            }
                            const dateObj = new Date(currentYear, currentMonth, day);
                            const dayName = fullDayNames[dateObj.getDay()];
                            return isWeeklyOffDay(dayName);
                        }
                    }"
                    @click="
                        if (leavesOnDay.length > 0 || holidayOnDay) {
                            selectedDayDetail = {
                                dateStr: dateStr,
                                holiday: holidayOnDay,
                                leaves: leavesOnDay
                            };
                        }
                    "
                    :class="[
                        isToday ? 'bg-indigo-50/40 dark:bg-indigo-950/30 border-indigo-400 dark:border-indigo-600 ring-2 ring-indigo-400/30 dark:ring-indigo-600/30 shadow-xs' :
                        holidayOnDay ? 'bg-rose-50/30 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900/60' :
                        isWeekend ? 'bg-slate-50/70 dark:bg-slate-900/40 border-slate-200 dark:border-slate-800' :
                        'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700',
                        (leavesOnDay.length > 0 || holidayOnDay) ? 'cursor-pointer hover:shadow-md' : ''
                    ]"
                    class="min-h-[115px] p-2.5 rounded-2xl border transition-all flex flex-col justify-between"
                >
                    <!-- Top Bar of Day: Number & Badges -->
                    <div class="flex items-center justify-between gap-1 mb-1.5">
                        <span 
                            :class="[
                                isToday ? 'bg-indigo-600 text-white shadow-xs' :
                                isWeekend ? 'text-slate-400 dark:text-slate-500' :
                                'text-slate-800 dark:text-slate-200'
                            ]"
                            class="text-xs font-black font-mono px-2 py-0.5 rounded-lg"
                            x-text="day"
                        >
                        </span>

                        <!-- Today Badge -->
                        <span x-show="isToday" class="text-[9px] font-extrabold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
                            Today
                        </span>

                        <!-- Holiday Tag -->
                        <span 
                            x-show="holidayOnDay" 
                            class="text-[9px] font-bold text-rose-700 dark:text-rose-400 bg-rose-100 dark:bg-rose-900/60 px-1.5 py-0.5 rounded-md truncate max-w-[85px]"
                            :title="holidayOnDay?.name"
                        >
                            🌴 Holiday
                        </span>
                    </div>

                    <!-- Holiday Title Banner if Present -->
                    <div 
                        x-show="holidayOnDay" 
                        class="mb-1 p-1 bg-rose-100/70 dark:bg-rose-900/40 rounded-lg text-[9px] font-bold text-rose-800 dark:text-rose-200 truncate"
                        :title="holidayOnDay?.description || holidayOnDay?.name"
                        x-text="holidayOnDay?.name"
                    >
                    </div>

                    <!-- Staff on Leave on this date - PROMINENTLY DISPLAYING NAMES -->
                    <div class="flex-1 space-y-1 overflow-hidden">
                        <template x-for="item in leavesOnDay.slice(0, 3)" :key="item.leave.id">
                            <div
                                x-data="{ colorStyle: getLeaveTypeColor(item.leave.leaveType || item.leave.leaveTypeId) }"
                                @click.stop="selectedLeaveDetail = { leave: item.leave, employee: item.employee }"
                                :class="[
                                    colorStyle.bg,
                                    colorStyle.border,
                                    item.leave.status === 'Pending' ? 'border-dashed opacity-85' : ''
                                ]"
                                :title="item.employee.name + ' (' + item.employee.id + ') on ' + (item.leave.leaveTypeName || item.leave.leaveType || 'Leave') + ': ' + (item.leave.reason || 'No reason provided')"
                                class="p-1.5 rounded-xl border text-[10px] transition-all hover:scale-[1.02] cursor-pointer flex items-center justify-between gap-1"
                            >
                                <div class="flex items-center gap-1.5 min-w-0">
                                    <!-- Employee Avatar / Profile Photo -->
                                    <div class="w-4 h-4 rounded-full overflow-hidden shrink-0 bg-slate-200">
                                        <img
                                            :src="getAvatar(item.employee)"
                                            :alt="item.employee?.name || 'Staff'"
                                            class="w-full h-full object-cover"
                                            referrerpolicy="no-referrer"
                                            @error="$event.target.src = defaultAvatarUrl"
                                        />
                                    </div>

                                    <!-- Staff Full Name Prominently Shown -->
                                    <span :class="colorStyle.text" class="font-bold truncate"
                                          x-text="item.employee?.name">
                                    </span>
                                </div>

                                <!-- Leave Type / Status Indicator -->
                                <div class="flex items-center gap-0.5 shrink-0">
                                    <span x-show="item.leave.isHalfDay" class="text-[8px] font-bold px-1 py-0.25 bg-amber-200 text-amber-900 rounded">
                                        1/2
                                    </span>
                                    <span 
                                        :class="item.leave.status === 'Pending' ? 'bg-amber-400 ring-1 ring-amber-500' : colorStyle.dot"
                                        class="w-1.5 h-1.5 rounded-full"
                                    >
                                    </span>
                                </div>
                            </div>
                        </template>

                        <!-- Overflow More Indicator -->
                        <button
                            x-show="leavesOnDay.length > 3"
                            @click.stop="selectedDayDetail = { dateStr: dateStr, holiday: holidayOnDay, leaves: leavesOnDay }"
                            class="w-full py-0.5 text-[9px] font-extrabold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 rounded-lg hover:bg-indigo-100 transition text-center cursor-pointer"
                            x-text="'+' + (leavesOnDay.length - 3) + ' more staff'"
                        >
                        </button>
                    </div>

                    <!-- Empty state for weekly off-days without leaves -->
                    <div x-show="isWeekend && !holidayOnDay && leavesOnDay.length === 0" class="text-[9px] font-bold text-slate-400 dark:text-slate-500 text-right mt-auto">
                        Weekly Off
                    </div>
                </div>
            </template>
        </div>
    </div>

    <!-- 5. SCHEDULE LIST VIEW -->
    <div x-show="viewMode === 'list'" class="border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden bg-white dark:bg-slate-900">
        <div class="p-4 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center">
            <div>
                <h3 class="text-sm font-black text-slate-800 dark:text-slate-100">
                    Absence Roster & Schedule (<span x-text="monthNames[currentMonth]"></span> <span x-text="currentYear"></span>)
                </h3>
                <p class="text-xs text-slate-500">
                    Detailed chronological view of all employee leaves for the selected time period.
                </p>
            </div>
            <span class="text-xs font-bold font-mono px-2.5 py-1 bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 rounded-xl border border-indigo-200 dark:border-indigo-800"
                  x-text="staffOnLeaveThisMonth.length + ' Records Found'">
            </span>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
                <thead class="bg-slate-50/80 dark:bg-slate-800/40 text-slate-500 font-bold uppercase text-[9px] tracking-wider border-b border-slate-200 dark:border-slate-700">
                    <tr>
                        <th class="p-3.5">Staff Name & ID</th>
                        <th class="p-3.5">Department & Branch</th>
                        <th class="p-3.5">Leave Type</th>
                        <th class="p-3.5">Duration</th>
                        <th class="p-3.5">Date Range</th>
                        <th class="p-3.5">Reason</th>
                        <th class="p-3.5 text-center">Status</th>
                        <th class="p-3.5 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                    <template x-for="leave in staffOnLeaveThisMonth" :key="leave.id">
                        <tr 
                            x-data="{
                                emp: getEmployee(leave.employeeId),
                                dept: getDepartment(getEmployee(leave.employeeId)?.departmentId),
                                br: getBranch(getEmployee(leave.employeeId)?.branchId),
                                colorStyle: getLeaveTypeColor(leave.leaveType || leave.leaveTypeId)
                            }"
                            class="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition"
                        >
                            <td class="p-3.5 font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2.5">
                                <div class="w-8 h-8 rounded-full overflow-hidden bg-slate-100 shrink-0">
                                    <img :src="getAvatar(emp)" :alt="emp ? emp.name : 'Staff'" class="w-full h-full object-cover" referrerpolicy="no-referrer" @error="$event.target.src = defaultAvatarUrl" />
                                </div>
                                <div>
                                    <span class="block font-bold text-slate-900 dark:text-slate-100" x-text="emp ? emp.name : 'Unknown'"></span>
                                    <span class="font-mono text-[10px] text-indigo-600 dark:text-indigo-400" x-text="emp ? emp.id : leave.employeeId"></span>
                                </div>
                            </td>

                            <td class="p-3.5 text-slate-600 dark:text-slate-400">
                                <span class="block font-semibold text-slate-800 dark:text-slate-200" x-text="dept ? dept.name : (emp?.departmentId || 'General')"></span>
                                <span class="text-[10px] text-slate-400" x-text="br ? br.name : (emp?.branchId || 'HQ')"></span>
                            </td>

                            <td class="p-3.5">
                                <span :class="colorStyle.badge" class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] font-bold">
                                    <span :class="colorStyle.dot" class="w-1.5 h-1.5 rounded-full"></span>
                                    <span x-text="leave.leaveTypeName || leave.leaveType || 'General Leave'"></span>
                                </span>
                            </td>

                            <td class="p-3.5 font-mono font-bold text-slate-700 dark:text-slate-300">
                                <span x-text="leave.totalDays + (leave.totalDays === 1 ? ' Day' : ' Days')"></span>
                                <span x-show="leave.isHalfDay" class="block text-[9px] font-normal text-amber-600">Half Day Session</span>
                            </td>

                            <td class="p-3.5 font-mono text-[11px] text-slate-600 dark:text-slate-400">
                                <div class="font-bold text-slate-800 dark:text-slate-200" x-text="leave.startDate"></div>
                                <div class="text-slate-400 text-[10px]" x-text="'to ' + leave.endDate"></div>
                            </td>

                            <td class="p-3.5 max-w-[200px] truncate text-slate-600 dark:text-slate-400" :title="leave.reason" x-text="leave.reason || 'No description provided'">
                            </td>

                            <td class="p-3.5 text-center">
                                <span 
                                    :class="[
                                        leave.status === 'Approved' ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300' :
                                        leave.status === 'Pending' ? 'bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300' :
                                        'bg-rose-50 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                                    ]"
                                    class="px-2.5 py-1 rounded-full text-[10px] font-black uppercase font-mono"
                                    x-text="leave.status"
                                >
                                </span>
                            </td>

                            <td class="p-3.5 text-right">
                                <button
                                    @click="selectedLeaveDetail = { leave: leave, employee: emp }"
                                    class="px-3 py-1 bg-slate-100 hover:bg-indigo-50 dark:bg-slate-800 dark:hover:bg-indigo-950/60 text-slate-700 hover:text-indigo-600 dark:text-slate-300 dark:hover:text-indigo-400 rounded-lg font-bold text-[11px] transition cursor-pointer"
                                >
                                    View Details
                                </button>
                            </td>
                        </tr>
                    </template>

                    <tr x-show="staffOnLeaveThisMonth.length === 0">
                        <td colspan="8" class="p-8 text-center text-slate-400 italic">
                            No staff leave records found matching your filters for <span x-text="monthNames[currentMonth]"></span> <span x-text="currentYear"></span>.
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- 6. TODAY'S ON-LEAVE ROSTER VIEW -->
    <div x-show="viewMode === 'today'" class="space-y-4">
        <div class="p-4 bg-rose-50/50 dark:bg-rose-950/20 border border-rose-100 dark:border-rose-900/40 rounded-2xl flex items-center justify-between">
            <div class="flex items-center gap-3">
                <div class="w-3 h-3 rounded-full bg-rose-500 animate-ping"></div>
                <div>
                    <h3 class="text-sm font-black text-rose-950 dark:text-rose-200">
                        Live Absence Roster for Today (<span x-text="systemTodayStr"></span>)
                    </h3>
                    <p class="text-xs text-rose-700/80 dark:text-rose-400">
                        Real-time list of employees with active approved leave covering today's operational schedule.
                    </p>
                </div>
            </div>
            <span class="text-xs font-black font-mono px-3 py-1 bg-rose-600 text-white rounded-xl shadow-xs"
                  x-text="staffOnLeaveToday.length + ' Staff Absent'">
            </span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <template x-for="item in staffOnLeaveToday" :key="item.leave.id">
                <div
                    x-data="{
                        dept: getDepartment(item.employee?.departmentId),
                        desg: getDesignation(item.employee?.designationId),
                        colorStyle: getLeaveTypeColor(item.leave.leaveType || item.leave.leaveTypeId)
                    }"
                    @click="selectedLeaveDetail = { leave: item.leave, employee: item.employee }"
                    class="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-700 rounded-2xl shadow-xs hover:shadow-md transition-all cursor-pointer space-y-3 group"
                >
                    <div class="flex items-center gap-3">
                        <div class="w-12 h-12 rounded-2xl overflow-hidden bg-slate-100 shrink-0 border border-slate-200 dark:border-slate-700">
                            <img :src="getAvatar(item.employee)" :alt="item.employee?.name || 'Staff'" class="w-full h-full object-cover" referrerpolicy="no-referrer" @error="$event.target.src = defaultAvatarUrl" />
                        </div>
                        <div class="min-w-0 flex-1">
                            <div class="flex items-center justify-between">
                                <h4 class="font-black text-slate-900 dark:text-slate-100 text-sm truncate group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition"
                                    x-text="item.employee?.name">
                                </h4>
                                <span class="text-[10px] font-mono font-bold text-slate-400" x-text="item.employee?.id"></span>
                            </div>
                            <p class="text-xs text-slate-500 truncate" x-text="desg ? desg.title : (item.employee?.role || 'Staff')"></p>
                            <p class="text-[11px] font-semibold text-slate-400 truncate" x-text="dept ? dept.name : (item.employee?.departmentId || 'General')"></p>
                        </div>
                    </div>

                    <div class="p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl space-y-1.5 text-xs">
                        <div class="flex justify-between items-center">
                            <span class="text-[10px] font-bold text-slate-400 uppercase">Leave Category</span>
                            <span :class="colorStyle.badge" class="px-2 py-0.5 rounded-md text-[10px] font-bold"
                                  x-text="item.leave.leaveTypeName || item.leave.leaveType || 'Leave'">
                            </span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-[10px] font-bold text-slate-400 uppercase">Absence Span</span>
                            <span class="font-mono font-bold text-slate-700 dark:text-slate-300 text-[11px]"
                                  x-text="item.leave.startDate + ' → ' + item.leave.endDate + ' (' + item.leave.totalDays + 'd)'">
                            </span>
                        </div>
                        <div x-show="item.leave.reason">
                            <p class="text-[11px] text-slate-600 dark:text-slate-400 italic pt-1 border-t border-slate-200/60 dark:border-slate-700/60 truncate"
                               x-text="'\x22' + item.leave.reason + '\x22'">
                            </p>
                        </div>
                    </div>
                </div>
            </template>

            <div x-show="staffOnLeaveToday.length === 0" class="col-span-full p-8 text-center bg-emerald-50/40 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/40 rounded-2xl">
                <i data-lucide="check-circle-2" class="w-8 h-8 text-emerald-500 mx-auto mb-2"></i>
                <h4 class="font-black text-emerald-950 dark:text-emerald-200 text-sm">Full Team Present Today</h4>
                <p class="text-xs text-emerald-700/80 dark:text-emerald-400 mt-0.5">
                    There are no registered staff absences or approved leaves scheduled for today.
                </p>
            </div>
        </div>
    </div>

    <!-- 7. CALENDAR LEGEND & COLOR GUIDE -->
    <div class="pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs">
        <div class="flex flex-wrap items-center gap-4">
            <span class="font-extrabold text-slate-500 dark:text-slate-400 text-[10px] uppercase tracking-wider">
                Color Legend:
            </span>
            <div class="flex items-center gap-1.5">
                <span class="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
                <span class="font-semibold text-slate-600 dark:text-slate-400 text-[11px]">Annual / Earned</span>
            </div>
            <div class="flex items-center gap-1.5">
                <span class="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                <span class="font-semibold text-slate-600 dark:text-slate-400 text-[11px]">Sick Leave</span>
            </div>
            <div class="flex items-center gap-1.5">
                <span class="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                <span class="font-semibold text-slate-600 dark:text-slate-400 text-[11px]">Casual Leave</span>
            </div>
            <div class="flex items-center gap-1.5">
                <span class="w-2.5 h-2.5 rounded-full bg-purple-500"></span>
                <span class="font-semibold text-slate-600 dark:text-slate-400 text-[11px]">Parental / Maternity</span>
            </div>
            <div class="flex items-center gap-1.5">
                <span class="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
                <span class="font-semibold text-slate-600 dark:text-slate-400 text-[11px]">Emergency</span>
            </div>
            <div class="flex items-center gap-1.5">
                <span class="w-2.5 h-2.5 rounded-full bg-slate-500"></span>
                <span class="font-semibold text-slate-600 dark:text-slate-400 text-[11px]">Unpaid Leave</span>
            </div>
            <div class="flex items-center gap-1.5">
                <span class="text-xs">🌴</span>
                <span class="font-semibold text-slate-600 dark:text-slate-400 text-[11px]">Public Holiday</span>
            </div>
        </div>

        <div class="text-[11px] text-slate-400">
            Click any staff entry or date box to inspect full absence information.
        </div>
    </div>

    <!-- 8. SINGLE LEAVE DETAIL MODAL -->
    <div x-show="selectedLeaveDetail !== null" x-cloak class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
        <div 
            @click.away="selectedLeaveDetail = null"
            class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl max-w-lg w-full overflow-hidden space-y-5"
        >
            <!-- Header -->
            <div class="flex items-start justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
                <div class="flex items-center gap-3">
                    <div class="w-12 h-12 rounded-2xl overflow-hidden bg-slate-100 shrink-0 border border-slate-200 dark:border-slate-700">
                        <img :src="getAvatar(selectedLeaveDetail?.employee)" :alt="selectedLeaveDetail?.employee?.name || 'Staff'" class="w-full h-full object-cover" referrerpolicy="no-referrer" @error="$event.target.src = defaultAvatarUrl" />
                    </div>
                    <div>
                        <h3 class="font-black text-slate-900 dark:text-slate-100 text-base" x-text="selectedLeaveDetail?.employee?.name"></h3>
                        <div class="flex items-center gap-2 text-xs text-slate-500">
                            <span class="font-mono font-bold text-indigo-600 dark:text-indigo-400" x-text="selectedLeaveDetail?.employee?.id"></span>
                            <span>·</span>
                            <span x-text="selectedLeaveDetail?.employee?.role"></span>
                        </div>
                    </div>
                </div>

                <button
                    @click="selectedLeaveDetail = null"
                    class="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition cursor-pointer"
                >
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>

            <!-- Leave Metadata Grid -->
            <div class="grid grid-cols-2 gap-3 text-xs">
                <div class="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl">
                    <span class="text-[10px] font-bold text-slate-400 uppercase block">Leave Category</span>
                    <span class="font-bold text-slate-800 dark:text-slate-200 mt-0.5 block capitalize"
                          x-text="selectedLeaveDetail?.leave?.leaveTypeName || selectedLeaveDetail?.leave?.leaveType || 'General Leave'">
                    </span>
                </div>

                <div class="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl">
                    <span class="text-[10px] font-bold text-slate-400 uppercase block">Status</span>
                    <span 
                        :class="[
                            selectedLeaveDetail?.leave?.status === 'Approved' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' :
                            selectedLeaveDetail?.leave?.status === 'Pending' ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300' :
                            'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                        ]"
                        class="inline-block px-2 py-0.5 rounded text-[10px] font-black uppercase font-mono mt-0.5"
                        x-text="selectedLeaveDetail?.leave?.status"
                    >
                    </span>
                </div>

                <div class="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl">
                    <span class="text-[10px] font-bold text-slate-400 uppercase block">Date Range</span>
                    <span class="font-mono font-bold text-slate-800 dark:text-slate-200 mt-0.5 block"
                          x-text="(selectedLeaveDetail?.leave?.startDate || selectedLeaveDetail?.leave?.from_date) + ' → ' + (selectedLeaveDetail?.leave?.endDate || selectedLeaveDetail?.leave?.to_date)">
                    </span>
                </div>

                <div class="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl">
                    <span class="text-[10px] font-bold text-slate-400 uppercase block">Total Duration</span>
                    <span class="font-mono font-bold text-slate-800 dark:text-slate-200 mt-0.5 block"
                          x-text="(selectedLeaveDetail?.leave?.totalDays || selectedLeaveDetail?.leave?.total_days || 1) + ' Day(s)' + (selectedLeaveDetail?.leave?.isHalfDay ? ' (Half Day)' : '')">
                    </span>
                </div>
            </div>

            <!-- Reason (Protected: only shown if present and authorized) -->
            <div x-show="selectedLeaveDetail?.leave?.reason && selectedLeaveDetail.leave.reason.trim() !== ''" class="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl text-xs space-y-1">
                <span class="text-[10px] font-bold text-slate-400 uppercase block">Employee Stated Reason</span>
                <p class="text-slate-700 dark:text-slate-300 italic font-sans leading-relaxed"
                   x-text="'\x22' + selectedLeaveDetail?.leave?.reason + '\x22'">
                </p>
            </div>

            <!-- Department & Contact Info -->
            <div class="text-xs text-slate-500 space-y-1.5 border-t border-slate-100 dark:border-slate-800 pt-3">
                <div class="flex items-center gap-2">
                    <i data-lucide="building-2" class="w-3.5 h-3.5 text-slate-400"></i>
                    <span>Department: <strong class="text-slate-700 dark:text-slate-300" x-text="getDepartment(selectedLeaveDetail?.employee?.departmentId)?.name || selectedLeaveDetail?.employee?.departmentId"></strong></span>
                </div>
                <div class="flex items-center gap-2">
                    <i data-lucide="map-pin" class="w-3.5 h-3.5 text-slate-400"></i>
                    <span>Branch Location: <strong class="text-slate-700 dark:text-slate-300" x-text="getBranch(selectedLeaveDetail?.employee?.branchId)?.name || selectedLeaveDetail?.employee?.branchId"></strong></span>
                </div>
                <div class="flex items-center gap-2">
                    <i data-lucide="mail" class="w-3.5 h-3.5 text-slate-400"></i>
                    <span>Email: <strong class="text-slate-700 dark:text-slate-300" x-text="selectedLeaveDetail?.employee?.email"></strong></span>
                </div>
                <div class="flex items-center gap-2" x-show="selectedLeaveDetail?.employee?.emergencyContact || selectedLeaveDetail?.employee?.phone">
                    <i data-lucide="phone" class="w-3.5 h-3.5 text-slate-400"></i>
                    <span>Emergency Phone: <strong class="text-slate-700 dark:text-slate-300" x-text="selectedLeaveDetail?.employee?.emergencyContact || selectedLeaveDetail?.employee?.phone"></strong></span>
                </div>
            </div>

            <!-- Actions for Pending Leave -->
            <div x-show="selectedLeaveDetail?.leave?.status === 'Pending'" class="flex items-center justify-end gap-2 border-t border-slate-100 dark:border-slate-800 pt-4">
                <button
                    @click="rejectLeave(selectedLeaveDetail.leave.id); selectedLeaveDetail = null;"
                    class="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 dark:bg-rose-950 dark:hover:bg-rose-900 text-xs font-bold rounded-xl transition cursor-pointer"
                >
                    Reject Leave
                </button>
                <button
                    @click="approveLeave(selectedLeaveDetail.leave.id); selectedLeaveDetail = null;"
                    class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer"
                >
                    Approve Leave
                </button>
            </div>
        </div>
    </div>

    <!-- 9. DAY ROSTER MODAL (WHEN MULTIPLE STAFF ARE ON LEAVE ON A DAY) -->
    <div x-show="selectedDayDetail !== null" x-cloak class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
        <div 
            @click.away="selectedDayDetail = null"
            class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl max-w-2xl w-full max-h-[85vh] overflow-hidden flex flex-col space-y-4"
        >
            <!-- Modal Header -->
            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
                <div>
                    <h3 class="font-black text-slate-900 dark:text-slate-100 text-lg flex items-center gap-2">
                        <i data-lucide="calendar-days" class="w-5 h-5 text-indigo-600 dark:text-indigo-400"></i>
                        <span>Staff Absences: <span x-text="selectedDayDetail?.dateStr"></span></span>
                    </h3>
                    <p class="text-slate-500 text-xs mt-0.5">
                        <span x-text="selectedDayDetail?.leaves?.length || 0"></span> staff member(s) scheduled on leave on this date.
                    </p>
                </div>

                <button
                    @click="selectedDayDetail = null"
                    class="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full text-slate-400 hover:text-slate-600 transition cursor-pointer"
                >
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>

            <!-- Holiday Notice if present on this date -->
            <div x-show="selectedDayDetail?.holiday" class="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 rounded-2xl flex items-center gap-3">
                <span class="text-2xl">🌴</span>
                <div>
                    <h4 class="font-black text-rose-900 dark:text-rose-200 text-xs uppercase"
                        x-text="'Public Holiday: ' + (selectedDayDetail?.holiday?.name || 'Company Holiday')">
                    </h4>
                    <p class="text-[11px] text-rose-700 dark:text-rose-400"
                       x-text="selectedDayDetail?.holiday?.description || 'Official company holiday'">
                    </p>
                </div>
            </div>

            <!-- List of staff on leave -->
            <div class="flex-1 overflow-y-auto space-y-3 pr-1">
                <template x-for="item in (selectedDayDetail?.leaves || [])" :key="item.leave.id">
                    <div 
                        x-data="{
                            dept: getDepartment(item.employee?.departmentId),
                            colorStyle: getLeaveTypeColor(item.leave.leaveType || item.leave.leaveTypeId)
                        }"
                        class="p-3.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full overflow-hidden bg-slate-200 shrink-0">
                                <img :src="getAvatar(item.employee)" :alt="item.employee?.name || 'Staff'" class="w-full h-full object-cover" referrerpolicy="no-referrer" @error="$event.target.src = defaultAvatarUrl" />
                            </div>
                            <div>
                                <div class="flex items-center gap-2">
                                    <span class="font-bold text-slate-900 dark:text-slate-100 text-sm" x-text="item.employee?.name"></span>
                                    <span class="font-mono text-[10px] text-indigo-600 dark:text-indigo-400 font-bold" x-text="item.employee?.id"></span>
                                </div>
                                <p class="text-xs text-slate-500">
                                    <span x-text="dept ? dept.name : (item.employee?.departmentId || 'General')"></span> · 
                                    <span x-text="item.employee?.role"></span>
                                </p>
                            </div>
                        </div>

                        <div class="flex items-center gap-2 self-end sm:self-center">
                            <span :class="colorStyle.badge" class="px-2.5 py-1 rounded-lg text-xs font-bold"
                                  x-text="item.leave.leaveTypeName || item.leave.leaveType || 'Leave'">
                            </span>
                            <button
                                @click="selectedLeaveDetail = { leave: item.leave, employee: item.employee };"
                                class="px-3 py-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl transition cursor-pointer"
                            >
                                Inspect
                            </button>
                        </div>
                    </div>
                </template>

                <div x-show="!selectedDayDetail?.leaves || selectedDayDetail.leaves.length === 0" class="text-center text-slate-400 italic py-8">
                    No staff are on leave on this date.
                </div>
            </div>
        </div>
    </div>

</div>

<script>
    document.addEventListener('alpine:init', () => {
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    });
    document.addEventListener('DOMContentLoaded', () => {
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    });
</script>
