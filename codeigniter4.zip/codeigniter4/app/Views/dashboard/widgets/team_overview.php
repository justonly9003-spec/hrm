<div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-xs flex flex-col justify-between h-full">
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100 dark:border-slate-800">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl bg-teal-50 dark:bg-teal-950/60 border border-teal-100 dark:border-teal-800 flex items-center justify-center text-teal-600 dark:text-teal-400">
                <i data-lucide="user-check" class="w-5 h-5"></i>
            </div>
            <div>
                <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Department Team Presence</h3>
                <p class="text-xs text-slate-500 dark:text-slate-400">Direct reports, active shift check-ins, and scheduled absences</p>
            </div>
        </div>
        <div class="flex items-center gap-2">
            <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-teal-50 text-teal-700 dark:bg-teal-950/60 dark:text-teal-400 border border-teal-200/60 dark:border-teal-800/60">
                <span class="w-2 h-2 rounded-full bg-teal-500"></span>
                Team Roster Live
            </span>
        </div>
    </div>

    <!-- 4 Team Metric Cards -->
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 pt-5">
        <div class="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 border border-slate-100 dark:border-slate-800">
            <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Team Members</span>
                <div class="p-1.5 rounded-lg bg-teal-100 dark:bg-teal-900/50 text-teal-600 dark:text-teal-400">
                    <i data-lucide="users" class="w-4 h-4"></i>
                </div>
            </div>
            <div class="mt-2 flex items-baseline gap-2">
                <span class="text-2xl font-black text-slate-900 dark:text-white"><?= esc($metrics['workforce']['total_employees'] ?? 0) ?></span>
                <span class="text-xs font-semibold text-teal-600">Assigned</span>
            </div>
            <div class="mt-1 text-[11px] text-slate-400">Direct reports</div>
        </div>

        <div class="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 border border-slate-100 dark:border-slate-800">
            <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">On Shift Today</span>
                <div class="p-1.5 rounded-lg bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400">
                    <i data-lucide="check" class="w-4 h-4"></i>
                </div>
            </div>
            <div class="mt-2 flex items-baseline gap-2">
                <span class="text-2xl font-black text-slate-900 dark:text-white"><?= esc($metrics['workforce']['present_today'] ?? 0) ?></span>
                <span class="text-xs font-semibold text-emerald-600">Checked In</span>
            </div>
            <div class="mt-1 text-[11px] text-slate-400"><?= esc($metrics['workforce']['late_today'] ?? 0) ?> Late check-in</div>
        </div>

        <div class="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 border border-slate-100 dark:border-slate-800">
            <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">On Leave</span>
                <div class="p-1.5 rounded-lg bg-amber-100 dark:bg-amber-900/50 text-amber-600 dark:text-amber-400">
                    <i data-lucide="sun" class="w-4 h-4"></i>
                </div>
            </div>
            <div class="mt-2 flex items-baseline gap-2">
                <span class="text-2xl font-black text-slate-900 dark:text-white"><?= esc($metrics['workforce']['on_leave_today'] ?? 0) ?></span>
                <span class="text-xs font-semibold text-amber-600">Scheduled</span>
            </div>
            <div class="mt-1 text-[11px] text-slate-400">Approved absence</div>
        </div>

        <div class="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 border border-slate-100 dark:border-slate-800">
            <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Pending Sign-off</span>
                <div class="p-1.5 rounded-lg bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400">
                    <i data-lucide="clipboard" class="w-4 h-4"></i>
                </div>
            </div>
            <div class="mt-2 flex items-baseline gap-2">
                <span class="text-2xl font-black text-slate-900 dark:text-white"><?= esc($metrics['workforce']['pending_leave_count'] ?? 0) ?></span>
                <span class="text-xs font-semibold text-indigo-600">Requests</span>
            </div>
            <div class="mt-1 text-[11px] text-slate-400">Awaiting Manager Review</div>
        </div>
    </div>
</div>
