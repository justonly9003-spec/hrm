<?php
/**
 * Widget: Real-Time Punch Stream
 * Code: live_attendance_stream
 * Path: dashboard/widgets/live_attendance_stream
 */
$punches = $metrics['data']['recent_punches_stream'] ?? [];
?>
<div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between h-full">
    <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-3">
        <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                <i data-lucide="radio" class="w-4 h-4 animate-pulse"></i>
            </div>
            <div>
                <h3 class="text-sm font-bold text-slate-900 dark:text-white"><?= esc($widget['title']) ?></h3>
                <p class="text-[11px] text-slate-500 dark:text-slate-400">Live biometric & web check-ins today</p>
            </div>
        </div>
        <span class="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 text-[10px] font-bold">
            <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping"></span> Live Feed
        </span>
    </div>

    <!-- Punch List -->
    <div class="space-y-2.5 max-h-64 overflow-y-auto pr-1 divide-y divide-slate-100 dark:divide-slate-800/60">
        <?php if (!empty($punches)): ?>
            <?php foreach (array_slice($punches, 0, 6) as $punch): ?>
                <?php 
                    $isLate = ($punch['status'] ?? '') === 'Late';
                    $empName = trim(($punch['first_name'] ?? '') . ' ' . ($punch['last_name'] ?? '')) ?: ($punch['employee_code'] ?? 'Employee');
                    $inTime = !empty($punch['in_time']) ? date('h:i A', strtotime($punch['in_time'])) : '--:--';
                ?>
                <div class="pt-2.5 first:pt-0 flex items-center justify-between text-xs">
                    <div class="flex items-center gap-2.5 min-w-0">
                        <div class="w-7 h-7 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center font-bold text-[10px] shrink-0 font-mono">
                            <?= esc(strtoupper(substr($empName, 0, 2))) ?>
                        </div>
                        <div class="truncate">
                            <span class="font-bold text-slate-800 dark:text-slate-200 block truncate"><?= esc($empName) ?></span>
                            <span class="text-[10px] text-slate-400 block"><?= esc($punch['department_name'] ?? 'General') ?></span>
                        </div>
                    </div>
                    <div class="text-right shrink-0">
                        <span class="font-mono font-bold text-slate-800 dark:text-slate-200 text-xs"><?= esc($inTime) ?></span>
                        <span class="block text-[9px] font-bold uppercase <?= $isLate ? 'text-amber-500' : 'text-emerald-500' ?>">
                            <?= $isLate ? 'Late Entrance' : 'On Time' ?>
                        </span>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="text-center py-8 text-xs text-slate-400">
                <i data-lucide="clock" class="w-6 h-6 mx-auto mb-2 text-slate-300 dark:text-slate-600"></i>
                No check-in punches recorded yet today
            </div>
        <?php endif; ?>
    </div>

    <div class="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
        <span class="text-[11px] text-slate-400">Syncing with terminal gateways</span>
        <a href="<?= base_url('attendance') ?>" class="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1">
            Full Terminal <i data-lucide="arrow-right" class="w-3 h-3"></i>
        </a>
    </div>
</div>
