<div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-xs flex flex-col justify-between h-full">
    <div class="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/60 border border-amber-100 dark:border-amber-800 flex items-center justify-center text-amber-600 dark:text-amber-400">
                <i data-lucide="shield-alert" class="w-5 h-5"></i>
            </div>
            <div>
                <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Platform Security Audit Log</h3>
                <p class="text-xs text-slate-500 dark:text-slate-400">Real-time multi-tenant access, permission changes & auth events</p>
            </div>
        </div>
        <a href="<?= base_url('system/audit') ?>" class="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1">
            <span>Full Audit Trail</span>
            <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
        </a>
    </div>

    <!-- Audit Event Stream -->
    <div class="mt-4 divide-y divide-slate-100 dark:divide-slate-800">
        <?php 
            $recentAudits = $metrics['platform']['recent_audits'] ?? [];
            if (empty($recentAudits)):
        ?>
            <div class="py-6 text-center text-xs text-slate-400">No security audit logs recorded yet.</div>
        <?php else: ?>
            <?php foreach ($recentAudits as $log): ?>
                <div class="py-3 flex items-start justify-between gap-4">
                    <div class="flex items-start gap-3">
                        <div class="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 mt-0.5">
                            <i data-lucide="terminal" class="w-3.5 h-3.5"></i>
                        </div>
                        <div>
                            <div class="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                <span><?= esc($log['action'] ?? 'Event') ?></span>
                                <span class="text-[10px] font-mono px-1.5 py-0.2 rounded-md bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                                    <?= esc($log['module'] ?? 'Security') ?>
                                </span>
                            </div>
                            <div class="text-[11px] text-slate-500 mt-0.5">
                                User: <span class="font-semibold text-slate-700 dark:text-slate-300"><?= esc($log['user_id'] ?? 'System') ?></span> • IP: <?= esc($log['ip_address'] ?? '127.0.0.1') ?>
                            </div>
                        </div>
                    </div>
                    <div class="text-[10px] font-mono text-slate-400 whitespace-nowrap">
                        <?= esc($log['created_at'] ?? date('Y-m-d H:i')) ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
