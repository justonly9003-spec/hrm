<?php
/**
 * Widget: Performance Review Cycles & OKRs
 * Code: performance_goals
 * Path: dashboard/widgets/performance_goals
 */
$goals = [
    ['title' => 'HCM Modular Migration Completion', 'pct' => 85, 'cycle' => 'Q3 2026', 'status' => 'On Track'],
    ['title' => 'Biometric Terminal Sync Latency < 500ms', 'pct' => 92, 'cycle' => 'Q3 2026', 'status' => 'Ahead'],
    ['title' => 'Zero-Duplicate Architectural Standard Compliance', 'pct' => 100, 'cycle' => 'Q3 2026', 'status' => 'Completed'],
];
?>
<div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between h-full">
    <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-3">
        <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                <i data-lucide="target" class="w-4 h-4"></i>
            </div>
            <div>
                <h3 class="text-sm font-bold text-slate-900 dark:text-white"><?= esc($widget['title']) ?></h3>
                <p class="text-[11px] text-slate-500 dark:text-slate-400">Quarterly OKRs & appraisal cycles</p>
            </div>
        </div>
        <span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 font-mono">
            Cycle: Q3-2026
        </span>
    </div>

    <!-- Goals List -->
    <div class="space-y-3 my-auto max-h-56 overflow-y-auto pr-1">
        <?php foreach ($goals as $goal): ?>
            <div class="space-y-1.5 text-xs">
                <div class="flex items-center justify-between">
                    <span class="font-bold text-slate-800 dark:text-slate-200 text-xs truncate"><?= esc($goal['title']) ?></span>
                    <span class="font-mono text-[11px] font-bold text-slate-600 dark:text-slate-300"><?= esc($goal['pct']) ?>%</span>
                </div>
                <div class="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                    <div class="h-full rounded-full <?= $goal['pct'] == 100 ? 'bg-emerald-500' : 'bg-indigo-600' ?> transition-all duration-500" style="width: <?= esc($goal['pct']) ?>%"></div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
        <span class="text-[11px] text-slate-400">Review Window: Open</span>
        <a href="<?= base_url('performance') ?>" class="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1">
            Goal Matrix <i data-lucide="arrow-right" class="w-3 h-3"></i>
        </a>
    </div>
</div>
