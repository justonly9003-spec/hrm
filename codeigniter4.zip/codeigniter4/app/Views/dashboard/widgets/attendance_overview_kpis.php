<?php
/**
 * Widget: Attendance Master Overview KPI Deck (12 Cards)
 * Single authoritative component used on both Unified Dashboard and Attendance Tracker Overview.
 */
$stats = $stats ?? ($data['attendance_overview_stats'] ?? []);
$settings = $settings ?? ($data['attendance_policy_settings'] ?? []);
$employees = $employees ?? ($data['attendance_employees'] ?? ($data['all_employees'] ?? []));

$totalActive = $stats['totalActive'] ?? $stats['totalEmployees'] ?? count($employees);
$present = (int)($stats['present'] ?? 0);
$absent = (int)($stats['absent'] ?? 0);
$late = (int)($stats['late'] ?? 0);
$earlyOut = (int)($stats['earlyOut'] ?? $stats['early_out'] ?? 0);
$halfDay = (int)($stats['halfDay'] ?? $stats['half_day'] ?? 0);
$onLeave = (int)($stats['onLeave'] ?? $stats['on_leave'] ?? 0);
$holiday = (int)($stats['holiday'] ?? $stats['holiday_count'] ?? 0);
$weeklyOff = (int)($stats['weeklyOff'] ?? $stats['weekly_off_count'] ?? 0);
$missingPunch = (int)($stats['missingPunch'] ?? $stats['missing_punch'] ?? 0);
$workedHours = $stats['totalWorkedHours'] ?? $stats['totalWorkingHours'] ?? $stats['total_working_hours'] ?? 0;
$overtimeHours = $stats['totalOvertimeHours'] ?? $stats['totalOvertime'] ?? $stats['total_overtime'] ?? 0;
$presenceRate = $stats['presenceRate'] ?? ($totalActive > 0 ? round(($present / $totalActive) * 100) : 0);
$graceTime = (int)($settings['graceTime'] ?? 0);
?>

<div class="w-full space-y-3">
    <div class="flex items-center justify-between pb-1 border-b border-slate-100 dark:border-slate-800">
        <div class="flex items-center gap-2">
            <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <h3 class="font-bold text-slate-900 dark:text-white text-sm">Attendance Master KPI Deck</h3>
        </div>
        <a href="<?= base_url('attendance') ?>" class="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1">
            <span>Open Attendance Hub</span>
            <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
        </a>
    </div>

    <!-- 12 KPI Grid -->
    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
        
        <!-- 1. Total Employees -->
        <div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4 shadow-xs space-y-1">
            <div class="flex items-center justify-between text-slate-500 dark:text-slate-400">
                <span class="text-[10px] font-bold uppercase tracking-wider">Total Headcount</span>
                <i data-lucide="users" class="w-3.5 h-3.5 text-slate-400"></i>
            </div>
            <div class="text-2xl font-black text-slate-900 dark:text-white font-mono"><?= esc($totalActive) ?></div>
            <span class="text-[10px] text-slate-400 block">Registered Staff</span>
        </div>

        <!-- 2. Present -->
        <div class="bg-white dark:bg-slate-900 border border-emerald-100 dark:border-emerald-950/60 rounded-2xl p-4 shadow-xs space-y-1">
            <div class="flex items-center justify-between text-emerald-600">
                <span class="text-[10px] font-bold uppercase tracking-wider">Present</span>
                <i data-lucide="check-circle-2" class="w-3.5 h-3.5 text-emerald-500"></i>
            </div>
            <div class="text-2xl font-black text-emerald-600 font-mono"><?= esc($present) ?></div>
            <span class="text-[10px] font-bold text-emerald-600/90"><?= esc($presenceRate) ?>% presence rate</span>
        </div>

        <!-- 3. Absent -->
        <div class="bg-white dark:bg-slate-900 border border-rose-100 dark:border-rose-950/60 rounded-2xl p-4 shadow-xs space-y-1">
            <div class="flex items-center justify-between text-rose-600">
                <span class="text-[10px] font-bold uppercase tracking-wider">Absent</span>
                <i data-lucide="x-circle" class="w-3.5 h-3.5 text-rose-500"></i>
            </div>
            <div class="text-2xl font-black text-rose-600 font-mono"><?= esc($absent) ?></div>
            <span class="text-[10px] text-slate-400">Unaccounted</span>
        </div>

        <!-- 4. Late Arrivals -->
        <div class="bg-white dark:bg-slate-900 border border-amber-100 dark:border-amber-950/60 rounded-2xl p-4 shadow-xs space-y-1">
            <div class="flex items-center justify-between text-amber-600">
                <span class="text-[10px] font-bold uppercase tracking-wider">Late Arrivals</span>
                <i data-lucide="clock" class="w-3.5 h-3.5 text-amber-500"></i>
            </div>
            <div class="text-2xl font-black text-amber-600 font-mono"><?= esc($late) ?></div>
            <span class="text-[10px] text-amber-600/90 font-bold">&gt;<?= $graceTime ?>m Grace</span>
        </div>

        <!-- 5. Early Departure -->
        <div class="bg-white dark:bg-slate-900 border border-indigo-100 dark:border-indigo-950/60 rounded-2xl p-4 shadow-xs space-y-1">
            <div class="flex items-center justify-between text-indigo-600">
                <span class="text-[10px] font-bold uppercase tracking-wider">Early Departure</span>
                <i data-lucide="coffee" class="w-3.5 h-3.5 text-indigo-500"></i>
            </div>
            <div class="text-2xl font-black text-indigo-600 font-mono"><?= esc($earlyOut) ?></div>
            <span class="text-[10px] text-slate-400">Before shift end</span>
        </div>

        <!-- 6. Half Day -->
        <div class="bg-white dark:bg-slate-900 border border-purple-100 dark:border-purple-950/60 rounded-2xl p-4 shadow-xs space-y-1">
            <div class="flex items-center justify-between text-purple-600">
                <span class="text-[10px] font-bold uppercase tracking-wider">Half Day</span>
                <i data-lucide="layers" class="w-3.5 h-3.5 text-purple-500"></i>
            </div>
            <div class="text-2xl font-black text-purple-600 font-mono"><?= esc($halfDay) ?></div>
            <span class="text-[10px] text-slate-400">&lt;4 hrs worked</span>
        </div>

        <!-- 7. On Leave -->
        <div class="bg-white dark:bg-slate-900 border border-blue-100 dark:border-blue-950/60 rounded-2xl p-4 shadow-xs space-y-1">
            <div class="flex items-center justify-between text-blue-600">
                <span class="text-[10px] font-bold uppercase tracking-wider">On Leave</span>
                <i data-lucide="calendar" class="w-3.5 h-3.5 text-blue-500"></i>
            </div>
            <div class="text-2xl font-black text-slate-800 dark:text-slate-200 font-mono"><?= esc($onLeave) ?></div>
            <span class="text-[10px] text-slate-400">Approved Leave</span>
        </div>

        <!-- 8. Holiday -->
        <div class="bg-white dark:bg-slate-900 border border-sky-100 dark:border-sky-950/60 rounded-2xl p-4 shadow-xs space-y-1">
            <div class="flex items-center justify-between text-sky-600">
                <span class="text-[10px] font-bold uppercase tracking-wider">Holiday</span>
                <i data-lucide="award" class="w-3.5 h-3.5 text-sky-500"></i>
            </div>
            <div class="text-2xl font-black text-slate-800 dark:text-slate-200 font-mono"><?= esc($holiday) ?></div>
            <span class="text-[10px] text-slate-400">Public/Company</span>
        </div>

        <!-- 9. Weekly Off -->
        <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs space-y-1">
            <div class="flex items-center justify-between text-slate-600 dark:text-slate-400">
                <span class="text-[10px] font-bold uppercase tracking-wider">Weekly Off</span>
                <i data-lucide="calendar" class="w-3.5 h-3.5 text-slate-400"></i>
            </div>
            <div class="text-2xl font-black text-slate-800 dark:text-slate-200 font-mono"><?= esc($weeklyOff) ?></div>
            <span class="text-[10px] text-slate-400">Rest Day</span>
        </div>

        <!-- 10. Missing Punch -->
        <div class="bg-white dark:bg-slate-900 border border-orange-100 dark:border-orange-950/60 rounded-2xl p-4 shadow-xs space-y-1">
            <div class="flex items-center justify-between text-orange-600">
                <span class="text-[10px] font-bold uppercase tracking-wider">Missing Punch</span>
                <i data-lucide="alert-triangle" class="w-3.5 h-3.5 text-orange-500"></i>
            </div>
            <div class="text-2xl font-black text-orange-600 font-mono"><?= esc($missingPunch) ?></div>
            <span class="text-[10px] text-slate-400">Single IN / OUT</span>
        </div>

        <!-- 11. Total Working Hours -->
        <div class="bg-white dark:bg-slate-900 border border-indigo-100 dark:border-indigo-950/60 rounded-2xl p-4 shadow-xs space-y-1">
            <div class="flex items-center justify-between text-indigo-600">
                <span class="text-[10px] font-bold uppercase tracking-wider">Total Worked Hrs</span>
                <i data-lucide="clock" class="w-3.5 h-3.5 text-indigo-500"></i>
            </div>
            <div class="text-2xl font-black text-indigo-600 font-mono"><?= is_numeric($workedHours) ? number_format((float)$workedHours, 1) : esc($workedHours) ?>h</div>
            <span class="text-[10px] text-slate-400">Net Productive</span>
        </div>

        <!-- 12. Total Overtime Hours -->
        <div class="bg-white dark:bg-slate-900 border border-emerald-100 dark:border-emerald-950/60 rounded-2xl p-4 shadow-xs space-y-1">
            <div class="flex items-center justify-between text-emerald-600">
                <span class="text-[10px] font-bold uppercase tracking-wider">Total OT Hours</span>
                <i data-lucide="trending-up" class="w-3.5 h-3.5 text-emerald-500"></i>
            </div>
            <div class="text-2xl font-black text-emerald-600 font-mono"><?= is_numeric($overtimeHours) ? number_format((float)$overtimeHours, 1) : esc($overtimeHours) ?>h</div>
            <span class="text-[10px] text-emerald-600/90 font-bold">Payable OT</span>
        </div>

    </div>
</div>
