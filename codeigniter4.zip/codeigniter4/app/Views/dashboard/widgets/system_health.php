<?php
$shm = $data['system_health_metrics'] ?? ($system_health_metrics ?? []);
$dbStatus = $shm['db_status'] ?? null;
$cacheHitRate = $shm['cache_hit_rate'] ?? null;
$queueBacklog = $shm['queue_backlog'] ?? null;
$biometricSync = $shm['biometric_sync'] ?? null;

$isDbOnline = ($dbStatus !== null);
?>
<div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-xs flex flex-col justify-between h-full">
    <div class="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl <?= $isDbOnline ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-100 dark:border-emerald-800 text-emerald-600 dark:text-emerald-400' : 'bg-amber-50 dark:bg-amber-950/60 border-amber-100 dark:border-amber-800 text-amber-600 dark:text-amber-400' ?> border flex items-center justify-center">
                <i data-lucide="activity" class="w-5 h-5"></i>
            </div>
            <div>
                <h3 class="text-base font-extrabold text-slate-900 dark:text-white">System Health & Infrastructure</h3>
                <p class="text-xs text-slate-500 dark:text-slate-400">Node runtime, database connectivity & background services</p>
            </div>
        </div>
        <span class="text-xs font-mono font-bold <?= $isDbOnline ? 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-800' : 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 border-amber-200 dark:border-amber-800' ?> px-2 py-0.5 rounded-md border">
            <?= $isDbOnline ? 'HEALTHY' : 'DEGRADED' ?>
        </span>
    </div>

    <!-- Health Metrics List -->
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3.5 mt-4">
        <!-- Database Pool -->
        <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
            <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-slate-700 dark:text-slate-300">Database Engine</span>
                <span class="text-xs font-mono font-bold <?= $dbStatus !== null ? 'text-emerald-600' : 'text-slate-400' ?>">
                    <?= esc($dbStatus !== null ? $dbStatus : 'Not available') ?>
                </span>
            </div>
            <div class="mt-2 text-xs text-slate-500">Multi-Tenant Relational Engine</div>
            <div class="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full mt-2 overflow-hidden">
                <div class="<?= $dbStatus !== null ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-600' ?> h-full rounded-full" style="width: <?= $dbStatus !== null ? '100%' : '0%' ?>"></div>
            </div>
            <div class="mt-1 flex justify-between text-[10px] text-slate-400">
                <span>Status: <?= esc($dbStatus !== null ? 'Online' : 'Not available') ?></span>
                <span>Type: MySQL / PostgreSQL</span>
            </div>
        </div>

        <!-- Biometric Fleet Daemon -->
        <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
            <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-slate-700 dark:text-slate-300">Hardware Biometric Fleet</span>
                <span class="text-xs font-mono font-bold <?= $biometricSync !== null ? 'text-emerald-600' : 'text-slate-400' ?>">
                    <?= esc($biometricSync !== null ? $biometricSync : 'Not available') ?>
                </span>
            </div>
            <div class="mt-2 text-xs text-slate-500">ZKTeco Biometric Sync Daemon</div>
            <div class="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full mt-2 overflow-hidden">
                <div class="<?= $biometricSync !== null ? 'bg-indigo-500' : 'bg-slate-300 dark:bg-slate-600' ?> h-full rounded-full" style="width: <?= $biometricSync !== null ? '100%' : '0%' ?>"></div>
            </div>
            <div class="mt-1 flex justify-between text-[10px] text-slate-400">
                <span>Fleet Sync: <?= esc($biometricSync !== null ? 'Active' : 'Not available') ?></span>
                <span>Interval: Real-time</span>
            </div>
        </div>

        <!-- Session & Cache Service -->
        <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
            <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-slate-700 dark:text-slate-300">Cache Hit Rate</span>
                <span class="text-xs font-mono font-bold <?= $cacheHitRate !== null ? 'text-emerald-600' : 'text-slate-400' ?>">
                    <?= esc($cacheHitRate !== null ? $cacheHitRate : 'Not available') ?>
                </span>
            </div>
            <div class="mt-2 text-xs text-slate-500">Application Cache Subsystem</div>
            <div class="mt-2 text-[11px] text-slate-400 flex items-center gap-1.5">
                <i data-lucide="zap" class="w-3.5 h-3.5 <?= $cacheHitRate !== null ? 'text-emerald-500' : 'text-slate-400' ?>"></i>
                <span>Hit efficiency: <?= esc($cacheHitRate !== null ? $cacheHitRate : 'Not available') ?></span>
            </div>
        </div>

        <!-- Background Queue & Audit -->
        <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
            <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-slate-700 dark:text-slate-300">Queue Backlog</span>
                <span class="text-xs font-mono font-bold <?= $queueBacklog !== null ? 'text-indigo-600' : 'text-slate-400' ?>">
                    <?= esc($queueBacklog !== null ? $queueBacklog . ' pending' : 'Not available') ?>
                </span>
            </div>
            <div class="mt-2 text-xs text-slate-500">Email & Async Worker Queue</div>
            <div class="mt-2 flex items-center justify-between">
                <span class="text-[11px] text-slate-400">
                    Pending Jobs: <?= esc($queueBacklog !== null ? (string)$queueBacklog : 'Not available') ?>
                </span>
                <a href="<?= base_url('system/backups') ?>" class="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1">
                    <span>Snapshots</span>
                    <i data-lucide="arrow-up-right" class="w-3 h-3"></i>
                </a>
            </div>
        </div>
    </div>
</div>
