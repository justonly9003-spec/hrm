<div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-xs flex flex-col justify-between h-full">
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100 dark:border-slate-800">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/60 border border-blue-100 dark:border-blue-800 flex items-center justify-center text-blue-600 dark:text-blue-400">
                <i data-lucide="users" class="w-5 h-5"></i>
            </div>
            <div>
                <h3 class="text-base font-extrabold text-slate-900 dark:text-white">HR Talent & Workforce Metrics</h3>
                <p class="text-xs text-slate-500 dark:text-slate-400">Staff lifecycle, daily presence monitoring, and talent retention</p>
            </div>
        </div>
        <div class="flex items-center gap-2">
            <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-400 border border-blue-200 dark:border-blue-800">
                <i data-lucide="user-check" class="w-3.5 h-3.5"></i>
                HR Management Desk
            </span>
        </div>
    </div>

    <!-- 4 HR Metric Cards -->
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 pt-5">
        <div class="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 border border-slate-100 dark:border-slate-800">
            <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Active Staff</span>
                <div class="p-1.5 rounded-lg bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400">
                    <i data-lucide="users-2" class="w-4 h-4"></i>
                </div>
            </div>
            <div class="mt-2 flex items-baseline gap-2">
                <span class="text-2xl font-black text-slate-900 dark:text-white"><?= esc($metrics['workforce']['active_employees'] ?? 0) ?></span>
                <span class="text-xs font-semibold text-slate-500">of <?= esc($metrics['workforce']['total_employees'] ?? 0) ?></span>
            </div>
            <div class="mt-1 text-[11px] text-emerald-600 font-medium">100% Retained</div>
        </div>

        <div class="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 border border-slate-100 dark:border-slate-800">
            <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Present Today</span>
                <div class="p-1.5 rounded-lg bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400">
                    <i data-lucide="fingerprint" class="w-4 h-4"></i>
                </div>
            </div>
            <div class="mt-2 flex items-baseline gap-2">
                <span class="text-2xl font-black text-slate-900 dark:text-white"><?= esc($metrics['workforce']['present_today'] ?? 0) ?></span>
                <span class="text-xs font-semibold text-emerald-600"><?= esc($metrics['workforce']['attendance_rate'] ?? 0) ?>%</span>
            </div>
            <div class="mt-1 text-[11px] text-slate-400"><?= esc($metrics['workforce']['late_today'] ?? 0) ?> Arrived Late</div>
        </div>

        <div class="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 border border-slate-100 dark:border-slate-800">
            <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Leave Liability</span>
                <div class="p-1.5 rounded-lg bg-amber-100 dark:bg-amber-900/50 text-amber-600 dark:text-amber-400">
                    <i data-lucide="calendar-off" class="w-4 h-4"></i>
                </div>
            </div>
            <div class="mt-2 flex items-baseline gap-2">
                <span class="text-2xl font-black text-slate-900 dark:text-white"><?= esc($metrics['workforce']['on_leave_today'] ?? 0) ?></span>
                <span class="text-xs font-semibold text-amber-600">On Leave</span>
            </div>
            <div class="mt-1 text-[11px] text-slate-400"><?= esc($metrics['workforce']['pending_leave_count'] ?? 0) ?> Needs Review</div>
        </div>

        <div class="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 border border-slate-100 dark:border-slate-800">
            <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">New Joiners</span>
                <div class="p-1.5 rounded-lg bg-purple-100 dark:bg-purple-900/50 text-purple-600 dark:text-purple-400">
                    <i data-lucide="sparkles" class="w-4 h-4"></i>
                </div>
            </div>
            <div class="mt-2 flex items-baseline gap-2">
                <span class="text-2xl font-black text-slate-900 dark:text-white"><?= esc($metrics['workforce']['new_joiners'] ?? 0) ?></span>
                <span class="text-xs font-semibold text-purple-600">this month</span>
            </div>
            <div class="mt-1 text-[11px] text-slate-400">Onboarding active</div>
        </div>
    </div>
</div>
