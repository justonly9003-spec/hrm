<div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-xs flex flex-col justify-between h-full">
    <div>
        <div class="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-950/60 border border-purple-100 dark:border-purple-800 flex items-center justify-center text-purple-600 dark:text-purple-400">
                    <i data-lucide="calendar-range" class="w-5 h-5"></i>
                </div>
                <div>
                    <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Weekly Shift Coverage</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Department roster schedule and staffing capacity</p>
                </div>
            </div>
            <a href="<?= base_url('attendance/roster') ?>" class="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1">
                <span>Roster</span>
                <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
            </a>
        </div>

        <div class="mt-4 space-y-3">
            <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 flex items-center justify-center font-bold text-xs">
                        <i data-lucide="sun" class="w-4 h-4"></i>
                    </div>
                    <div>
                        <div class="text-xs font-bold text-slate-900 dark:text-white">Morning Shift (09:00 - 18:00)</div>
                        <div class="text-[11px] text-slate-500">Core business hours • Standard schedule</div>
                    </div>
                </div>
                <span class="text-xs font-bold text-indigo-600 dark:text-indigo-400 px-2.5 py-1 bg-indigo-50 dark:bg-indigo-950/60 rounded-lg border border-indigo-200 dark:border-indigo-800">
                    8 Staff
                </span>
            </div>

            <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 rounded-lg bg-purple-100 dark:bg-purple-900/50 text-purple-600 flex items-center justify-center font-bold text-xs">
                        <i data-lucide="moon" class="w-4 h-4"></i>
                    </div>
                    <div>
                        <div class="text-xs font-bold text-slate-900 dark:text-white">Evening / Support Shift</div>
                        <div class="text-[11px] text-slate-500">Coverage hours • Customer operations</div>
                    </div>
                </div>
                <span class="text-xs font-bold text-purple-600 dark:text-purple-400 px-2.5 py-1 bg-purple-50 dark:bg-purple-950/60 rounded-lg border border-purple-200 dark:border-purple-800">
                    4 Staff
                </span>
            </div>
        </div>
    </div>

    <div class="pt-4 border-t border-slate-100 dark:border-slate-800 mt-4 flex items-center justify-between text-xs">
        <span class="text-slate-500">Roster Status: <strong class="text-emerald-600">Published</strong></span>
        <a href="<?= base_url('attendance/roster') ?>" class="text-indigo-600 dark:text-indigo-400 font-bold hover:underline">
            Edit Shift Plan →
        </a>
    </div>
</div>
