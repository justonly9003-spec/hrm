<?php
/**
 * Widget: Upcoming Training Programs & Certifications
 * Code: training_certifications
 * Path: dashboard/widgets/training_certifications
 */
$trainings = [
    ['title' => 'Occupational Workplace Health & Safety', 'type' => 'Mandatory Compliance', 'date' => date('M d, Y', strtotime('+5 days')), 'badge' => 'Required'],
    ['title' => 'CodeIgniter 4 Enterprise Patterns & Clean Architecture', 'type' => 'Engineering Excellence', 'date' => date('M d, Y', strtotime('+12 days')), 'badge' => 'Enrolled'],
];
?>
<div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between h-full">
    <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-3">
        <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                <i data-lucide="graduation-cap" class="w-4 h-4"></i>
            </div>
            <div>
                <h3 class="text-sm font-bold text-slate-900 dark:text-white"><?= esc($widget['title']) ?></h3>
                <p class="text-[11px] text-slate-500 dark:text-slate-400">Professional development & compliance</p>
            </div>
        </div>
        <span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-mono">
            <?= count($trainings) ?> Upcoming
        </span>
    </div>

    <!-- Trainings List -->
    <div class="space-y-2.5 my-auto max-h-56 overflow-y-auto pr-1">
        <?php foreach ($trainings as $tr): ?>
            <div class="p-3 rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 text-xs flex items-center justify-between">
                <div>
                    <span class="font-bold text-slate-800 dark:text-slate-200 block"><?= esc($tr['title']) ?></span>
                    <span class="text-[10px] text-slate-500 dark:text-slate-400 block mt-0.5"><?= esc($tr['type']) ?> • <?= esc($tr['date']) ?></span>
                </div>
                <span class="px-2 py-0.5 rounded-md text-[10px] font-bold font-mono uppercase tracking-wider <?= $tr['badge'] === 'Required' ? 'bg-rose-50 text-rose-600 dark:bg-rose-950/60 dark:text-rose-400 border border-rose-200 dark:border-rose-900/60' : 'bg-indigo-50 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-900/60' ?>">
                    <?= esc($tr['badge']) ?>
                </span>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
        <span class="text-[11px] text-slate-400">Accredited training gateway</span>
        <a href="<?= base_url('training') ?>" class="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1">
            Browse Catalog <i data-lucide="arrow-right" class="w-3 h-3"></i>
        </a>
    </div>
</div>
