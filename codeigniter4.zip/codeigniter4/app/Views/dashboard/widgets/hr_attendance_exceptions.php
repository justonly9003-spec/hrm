<div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-xs flex flex-col justify-between h-full">
    <div>
        <div class="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-100 dark:border-rose-800 flex items-center justify-center text-rose-600 dark:text-rose-400">
                    <i data-lucide="clock-alert" class="w-5 h-5"></i>
                </div>
                <div>
                    <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Attendance Exceptions</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Late clock-ins, missing punches & unexcused absences</p>
                </div>
            </div>
            <a href="<?= base_url('attendance') ?>" class="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1">
                <span>Tracker</span>
                <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
            </a>
        </div>

<?php
// Owner rule: attendance_late_arrivals is the canonical owner of late employee counts.
// If attendance_late_arrivals is active in this render or for this role, suppress the duplicate row.
$currentUserRole = strtolower((string)($role ?? session()->get('role') ?? ($user['role'] ?? '')));
$rolesWithLateOwner = ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'branch_manager', 'manager'];
$hideLateCheckIns = !empty($hasLateArrivalsWidget) || in_array($currentUserRole, $rolesWithLateOwner, true);
?>
        <div class="mt-4 space-y-3">
            <?php if (!$hideLateCheckIns): ?>
            <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 rounded-lg bg-amber-100 dark:bg-amber-900/50 text-amber-600 flex items-center justify-center font-bold text-xs">
                        <i data-lucide="alert-triangle" class="w-4 h-4"></i>
                    </div>
                    <div>
                        <div class="text-xs font-bold text-slate-900 dark:text-white">Late Check-Ins</div>
                        <div class="text-[11px] text-slate-500">Arrived after shift grace period</div>
                    </div>
                </div>
                <span class="text-xs font-bold text-amber-600 dark:text-amber-400 px-2.5 py-1 bg-amber-50 dark:bg-amber-950/60 rounded-lg border border-amber-200 dark:border-amber-800">
                    <?= esc($metrics['workforce']['late_today'] ?? 0) ?> Staff
                </span>
            </div>
            <?php endif; ?>

            <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 rounded-lg bg-rose-100 dark:bg-rose-900/50 text-rose-600 flex items-center justify-center font-bold text-xs">
                        <i data-lucide="user-x" class="w-4 h-4"></i>
                    </div>
                    <div>
                        <div class="text-xs font-bold text-slate-900 dark:text-white">Unscheduled Absence</div>
                        <div class="text-[11px] text-slate-500">No punch and no approved leave</div>
                    </div>
                </div>
                <span class="text-xs font-bold text-rose-600 dark:text-rose-400 px-2.5 py-1 bg-rose-50 dark:bg-rose-950/60 rounded-lg border border-rose-200 dark:border-rose-800">
                    <?= esc($metrics['workforce']['absent_today'] ?? 0) ?> Staff
                </span>
            </div>
        </div>
    </div>

    <div class="pt-4 border-t border-slate-100 dark:border-slate-800 mt-4 flex items-center justify-between text-xs">
        <span class="text-slate-500">Live Biometric Synchronization: <strong class="text-emerald-600">Active</strong></span>
        <a href="<?= base_url('attendance/sync') ?>" class="text-indigo-600 dark:text-indigo-400 font-bold hover:underline">
            Biometric Sync →
        </a>
    </div>
</div>
