<div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-xs flex flex-col justify-between h-full">
    <div>
        <div class="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-100 dark:border-emerald-800 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                    <i data-lucide="check-circle-2" class="w-5 h-5"></i>
                </div>
                <div>
                    <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Executive Approvals Queue</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Key pending requests, leave verifications & company notices</p>
                </div>
            </div>
            <a href="<?= base_url('leave') ?>" class="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1">
                <span>Manage</span>
                <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
            </a>
        </div>

        <div class="mt-4 space-y-3">
            <?php 
                $pending = $metrics['workforce']['pending_leaves'] ?? [];
                if (empty($pending)):
            ?>
                <div class="p-6 text-center text-xs text-slate-400 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-dashed border-slate-200 dark:border-slate-700">
                    <i data-lucide="check-check" class="w-6 h-6 text-emerald-500 mx-auto mb-1.5"></i>
                    All pending operations and leave applications are currently up to date!
                </div>
            <?php else: ?>
                <?php foreach (array_slice($pending, 0, 3) as $req): ?>
                    <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <div class="w-8 h-8 rounded-lg bg-amber-100 dark:bg-amber-900/50 text-amber-700 dark:text-amber-300 font-bold text-xs flex items-center justify-center">
                                <i data-lucide="file-text" class="w-4 h-4"></i>
                            </div>
                            <div>
                                <div class="text-xs font-bold text-slate-900 dark:text-white"><?= esc($req['employee_name'] ?? 'Staff Member') ?></div>
                                <div class="text-[11px] text-slate-500">
                                    <?= esc($req['from_date']) ?> to <?= esc($req['to_date']) ?> • <span class="font-semibold text-amber-600"><?= esc($req['days'] ?? 1) ?> day(s)</span>
                                </div>
                            </div>
                        </div>
                        <a href="<?= base_url('leave') ?>" class="px-2.5 py-1 text-xs font-bold rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition">
                            Review
                        </a>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="pt-4 border-t border-slate-100 dark:border-slate-800 mt-4 flex items-center justify-between text-xs">
        <span class="text-slate-500">Total Pending: <strong class="text-amber-600"><?= count($pending) ?></strong></span>
        <a href="<?= base_url('leave') ?>" class="text-indigo-600 dark:text-indigo-400 font-bold hover:underline">
            Go to Leave Center →
        </a>
    </div>
</div>
