<?php
/**
 * Widget: Missing Punch Irregularities (Single Metric Card)
 */
$stats = $stats ?? ($data['attendance_overview_stats'] ?? []);
$missingPunch = (int)($stats['missingPunch'] ?? $stats['missing_punch'] ?? 0);
?>

<div class="bg-white dark:bg-slate-900 border border-orange-100 dark:border-orange-950/60 rounded-2xl p-5 shadow-xs flex flex-col justify-between h-full">
    <div>
        <div class="flex items-center justify-between text-orange-600 mb-2">
            <span class="text-[11px] font-bold uppercase tracking-wider">Missing Punches</span>
            <div class="w-8 h-8 rounded-lg bg-orange-50 dark:bg-orange-950/60 flex items-center justify-center">
                <i data-lucide="alert-triangle" class="w-4 h-4 text-orange-500"></i>
            </div>
        </div>
        <div class="flex items-baseline gap-2">
            <span class="text-3xl font-black text-orange-600 font-mono"><?= esc($missingPunch) ?></span>
            <span class="text-xs text-slate-400 font-medium">Discrepancies</span>
        </div>
        <p class="text-[11px] text-slate-500 dark:text-slate-400 mt-2">
            Staff members with single check-in or single check-out requiring regularization.
        </p>
    </div>
    <div class="pt-3 border-t border-slate-100 dark:border-slate-800 mt-3 flex items-center justify-between text-[11px]">
        <span class="text-orange-600 font-bold">Single IN/OUT</span>
        <a href="<?= base_url('attendance?tab=today&status=Missing Punch') ?>" class="text-orange-600 dark:text-orange-400 font-bold hover:underline flex items-center gap-1">
            <span>Filter Missing Punch</span>
            <i data-lucide="arrow-right" class="w-3 h-3"></i>
        </a>
    </div>
</div>
