<?php
/**
 * Widget: Today's Late Arrivals (Single Metric Card)
 */
$stats = $stats ?? ($data['attendance_overview_stats'] ?? []);
$settings = $settings ?? ($data['attendance_policy_settings'] ?? []);

$late = (int)($stats['late'] ?? 0);
$graceTime = (int)($stats['grace_minutes'] ?? $stats['graceMinutes'] ?? ($settings['graceTime'] ?? 0));
?>

<div class="bg-white dark:bg-slate-900 border border-amber-100 dark:border-amber-950/60 rounded-2xl p-5 shadow-xs flex flex-col justify-between h-full">
    <div>
        <div class="flex items-center justify-between text-amber-600 mb-2">
            <span class="text-[11px] font-bold uppercase tracking-wider">Late Arrivals</span>
            <div class="w-8 h-8 rounded-lg bg-amber-50 dark:bg-amber-950/60 flex items-center justify-center">
                <i data-lucide="clock" class="w-4 h-4 text-amber-500"></i>
            </div>
        </div>
        <div class="flex items-baseline gap-2">
            <span class="text-3xl font-black text-amber-600 font-mono"><?= esc($late) ?></span>
            <span class="text-xs text-slate-400 font-medium">Employees</span>
        </div>
        <p class="text-[11px] text-slate-500 dark:text-slate-400 mt-2">
            Arrived past the <strong class="text-amber-600"><?= $graceTime ?>m</strong> shift arrival grace window.
        </p>
    </div>
    <div class="pt-3 border-t border-slate-100 dark:border-slate-800 mt-3 flex items-center justify-between text-[11px]">
        <span class="text-amber-600/90 font-bold">&gt;<?= $graceTime ?>m Grace Threshold</span>
        <a href="<?= base_url('attendance?tab=today&status=Late') ?>" class="text-amber-600 dark:text-amber-400 font-bold hover:underline flex items-center gap-1">
            <span>Filter Late</span>
            <i data-lucide="arrow-right" class="w-3 h-3"></i>
        </a>
    </div>
</div>
