<?php
/**
 * Widget: Company Organogram & Hierarchy
 * Code: organogram_preview
 * Path: dashboard/widgets/organogram_preview
 */
$deptDistribution = $metrics['workforce']['department_distribution'] ?? [];
?>
<div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between h-full">
    <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-3">
        <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                <i data-lucide="git-pull-request" class="w-4 h-4"></i>
            </div>
            <div>
                <h3 class="text-sm font-bold text-slate-900 dark:text-white"><?= esc($widget['title']) ?></h3>
                <p class="text-[11px] text-slate-500 dark:text-slate-400">Department leadership & structural chain</p>
            </div>
        </div>
        <span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-mono">
            <?= count($deptDistribution) ?> Business Units
        </span>
    </div>

    <!-- Tree Preview -->
    <div class="space-y-2.5 my-auto max-h-56 overflow-y-auto pr-1">
        <?php if (!empty($deptDistribution)): ?>
            <div class="divide-y divide-slate-100 dark:divide-slate-800/60 text-xs">
                <?php foreach ($deptDistribution as $dept): ?>
                    <div class="py-2 first:pt-0 flex items-center justify-between">
                        <div class="flex items-center gap-2.5">
                            <div class="w-2 h-2 rounded-full bg-indigo-500"></div>
                            <div>
                                <span class="font-bold text-slate-800 dark:text-slate-200"><?= esc($dept['name'] ?? 'Department') ?></span>
                                <span class="text-[10px] text-slate-400 block font-mono">Designated Lead: Active</span>
                            </div>
                        </div>
                        <span class="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono text-[10px] font-bold">
                            <?= esc($dept['count'] ?? $dept['headcount'] ?? $dept['total'] ?? 0) ?> Staff
                        </span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-6 text-xs text-slate-400">Department structure loading...</div>
        <?php endif; ?>
    </div>

    <div class="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
        <span class="text-[11px] text-slate-400">Interactive reporting tree</span>
        <a href="<?= base_url('organogram') ?>" class="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1">
            Visual Tree <i data-lucide="arrow-right" class="w-3 h-3"></i>
        </a>
    </div>
</div>
