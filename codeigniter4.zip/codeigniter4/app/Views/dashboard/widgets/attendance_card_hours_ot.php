<?php
/**
 * Widget: Productive Hours & Overtime Meter (Single Part Card)
 */
$stats = $stats ?? ($data['attendance_overview_stats'] ?? []);
$workedHours = $stats['totalWorkedHours'] ?? $stats['totalWorkingHours'] ?? $stats['total_working_hours'] ?? 0;
$overtimeHours = $stats['totalOvertimeHours'] ?? $stats['totalOvertime'] ?? $stats['total_overtime'] ?? 0;
?>

<div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between h-full">
    <div>
        <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div class="flex items-center gap-2.5">
                <div class="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
                    <i data-lucide="trending-up" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Productive Hours & OT</h3>
                    <p class="text-[11px] text-slate-400">Aggregate daily workforce output</p>
                </div>
            </div>
            <a href="<?= base_url('attendance?tab=today') ?>" class="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1">
                <span>Muster</span>
                <i data-lucide="arrow-right" class="w-3 h-3"></i>
            </a>
        </div>

        <div class="grid grid-cols-2 gap-4 mt-4">
            <div class="p-3.5 rounded-xl bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 space-y-1">
                <span class="text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 block">Total Worked</span>
                <div class="text-2xl font-black text-indigo-600 dark:text-indigo-400 font-mono">
                    <?= is_numeric($workedHours) ? number_format((float)$workedHours, 1) : esc($workedHours) ?>h
                </div>
                <span class="text-[10px] text-slate-400">Net Productive Time</span>
            </div>

            <div class="p-3.5 rounded-xl bg-emerald-50/50 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/50 space-y-1">
                <span class="text-[10px] font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 block">Overtime</span>
                <div class="text-2xl font-black text-emerald-600 dark:text-emerald-400 font-mono">
                    <?= is_numeric($overtimeHours) ? number_format((float)$overtimeHours, 1) : esc($overtimeHours) ?>h
                </div>
                <span class="text-[10px] text-emerald-600/90 font-bold">Rule Engine Calculated</span>
            </div>
        </div>
    </div>

    <div class="pt-3 border-t border-slate-100 dark:border-slate-800 mt-3 flex items-center justify-between text-[11px] text-slate-400">
        <span>Continuous calculation via RuleResolver</span>
        <span class="font-mono text-slate-500">Live Pulse</span>
    </div>
</div>
