<div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-xs flex flex-col justify-between h-full">
    <div>
        <div class="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/60 border border-blue-100 dark:border-blue-800 flex items-center justify-center text-blue-600 dark:text-blue-400">
                    <i data-lucide="layers" class="w-5 h-5"></i>
                </div>
                <div>
                    <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Tenant Organization Fleet</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Manage tenant companies, modules & subscription plans</p>
                </div>
            </div>
            <a href="<?= base_url('master/companies') ?>" class="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1">
                <span>View All</span>
                <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
            </a>
        </div>

        <!-- Companies Table / List -->
        <div class="mt-4 divide-y divide-slate-100 dark:divide-slate-800">
            <?php 
                $compList = $metrics['platform']['companies_list'] ?? [];
                if (empty($compList)):
            ?>
                <div class="py-6 text-center text-xs text-slate-400">No organizations found.</div>
            <?php else: ?>
                <?php foreach (array_slice($compList, 0, 5) as $comp): ?>
                    <div class="py-3 flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <div class="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-bold text-xs text-slate-700 dark:text-slate-300">
                                <?= strtoupper(substr($comp['name'] ?? 'C', 0, 2)) ?>
                            </div>
                            <div>
                                <div class="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                                    <span><?= esc($comp['name']) ?></span>
                                    <span class="text-[10px] font-mono px-1.5 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                                        <?= esc($comp['code'] ?? 'ORG') ?>
                                    </span>
                                </div>
                                <div class="text-[11px] text-slate-400">
                                    <?= esc($comp['email'] ?? 'admin@company.com') ?> • <?= esc($comp['country'] ?? 'Global') ?>
                                </div>
                            </div>
                        </div>
                        <div class="text-right">
                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold <?= (strtolower($comp['status'] ?? 'active') === 'active') ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400' : 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400' ?>">
                                <?= ucfirst(esc($comp['status'] ?? 'active')) ?>
                            </span>
                            <div class="text-[10px] text-indigo-600 dark:text-indigo-400 font-semibold uppercase mt-0.5">
                                <?= esc($comp['subscription_plan'] ?? 'Enterprise') ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="pt-4 border-t border-slate-100 dark:border-slate-800 mt-4 flex items-center justify-between text-xs">
        <span class="text-slate-500">Need to onboard a new organization?</span>
        <a href="<?= base_url('master/companies') ?>" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 text-white font-bold hover:bg-indigo-700 transition text-xs shadow-xs">
            <i data-lucide="plus" class="w-3.5 h-3.5"></i>
            <span>Provision Company</span>
        </a>
    </div>
</div>
