<?php
/**
 * Widget: Monthly Payroll Cost Summary
 * Code: payroll_cost_summary
 * Path: dashboard/widgets/payroll_cost_summary
 */
$monthlyGross = (float)($data['monthly_payroll'] ?? ($metrics['data']['monthly_payroll'] ?? 0.00));
$breakdown = $data['payroll_breakdown'] ?? ($metrics['data']['payroll_breakdown'] ?? null);
$currentMonthName = $metrics['current_month_name'] ?? date('F Y');
$currency = esc(!empty($company['currency_symbol']) ? $company['currency_symbol'] : (!empty($company['currency']) ? $company['currency'] : 'BDT'));
$isProcessed = $monthlyGross > 0;
$basic = (float)($breakdown['basic'] ?? 0.00);
$allowances = (float)($breakdown['allowances'] ?? 0.00);
$deductions = (float)($breakdown['deductions'] ?? 0.00);

if (!$isProcessed && empty($basic)) {
    $basic = 0.00;
    $allowances = 0.00;
    $deductions = 0.00;
} elseif ($isProcessed && $basic <= 0) {
    $basic = $monthlyGross;
    $allowances = 0.00;
    $deductions = 0.00;
}
?>
<div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between h-full">
    <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-3">
        <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                <i data-lucide="credit-card" class="w-4 h-4"></i>
            </div>
            <div>
                <h3 class="text-sm font-bold text-slate-900 dark:text-white"><?= esc($widget['title']) ?></h3>
                <p class="text-[11px] text-slate-500 dark:text-slate-400">Total disbursement commitment</p>
            </div>
        </div>
        <span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-mono">
            <?= esc($currentMonthName) ?>
        </span>
    </div>

    <!-- Big KPI Display -->
    <div class="my-auto py-2">
        <div class="flex items-baseline justify-between mb-3">
            <div>
                <span class="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Projected Net Payout</span>
                <span class="text-2xl lg:text-3xl font-black text-slate-900 dark:text-white font-mono tracking-tight">
                    <?= $currency ?> <?= number_format($monthlyGross, 2) ?>
                </span>
            </div>
            <?php if ($isProcessed): ?>
                <span class="px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 text-xs font-bold border border-emerald-200 dark:border-emerald-800/60">
                    Processed
                </span>
            <?php else: ?>
                <span class="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 text-xs font-bold border border-slate-200 dark:border-slate-700">
                    Pending Batch
                </span>
            <?php endif; ?>
        </div>

        <!-- Breakdown strip -->
        <div class="grid grid-cols-3 gap-2 pt-2 border-t border-slate-100 dark:border-slate-800/60 text-xs">
            <div class="p-2 rounded-xl bg-slate-50 dark:bg-slate-800/40">
                <span class="text-[9px] font-bold text-slate-400 uppercase block">Basic Salary</span>
                <span class="font-mono font-bold text-slate-800 dark:text-slate-200 text-xs"><?= $currency ?> <?= number_format($basic, 2) ?></span>
            </div>
            <div class="p-2 rounded-xl bg-slate-50 dark:bg-slate-800/40">
                <span class="text-[9px] font-bold text-slate-400 uppercase block">Allowances</span>
                <span class="font-mono font-bold text-slate-800 dark:text-slate-200 text-xs"><?= $currency ?> <?= number_format($allowances, 2) ?></span>
            </div>
            <div class="p-2 rounded-xl bg-slate-50 dark:bg-slate-800/40">
                <span class="text-[9px] font-bold text-slate-400 uppercase block">Deductions</span>
                <span class="font-mono font-bold text-slate-800 dark:text-slate-200 text-xs"><?= $currency ?> <?= number_format($deductions, 2) ?></span>
            </div>
        </div>
    </div>

    <div class="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
        <span class="text-[11px] text-slate-400">Payroll Cycle: Monthly</span>
        <a href="<?= base_url('payroll') ?>" class="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1">
            Payroll Ledger <i data-lucide="arrow-right" class="w-3 h-3"></i>
        </a>
    </div>
</div>
