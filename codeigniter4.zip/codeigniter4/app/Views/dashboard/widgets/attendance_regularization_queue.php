<?php
/**
 * Widget: Attendance Regularization Action Queue
 * Role: Manager, HR Admin, Company Admin
 * Permission: attendance.regularize_approve
 */
$pendingCorrections = $pendingCorrections ?? ($data['attendance_pending_corrections'] ?? []);
$canApproveCorrection = (new \App\Services\PermissionService())->hasAccess(session()->get('user_id'), 'attendance', 'regularize_approve', $role ?? null);
?>

<div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-xs w-full h-full flex flex-col justify-between">
    <div>
        <div class="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
            <div class="flex items-center gap-2">
                <i data-lucide="shield-alert" class="w-4 h-4 text-amber-500"></i>
                <h3 class="font-bold text-slate-800 dark:text-white text-sm">Attendance Correction & Regularization Queue</h3>
            </div>
            <div class="flex items-center gap-2">
                <span class="px-2.5 py-0.5 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 font-bold text-[11px] border border-amber-200 dark:border-amber-800">
                    <?= count($pendingCorrections) ?> Pending Action
                </span>
                <button 
                    type="button"
                    @click="typeof setTab === 'function' ? setTab('corrections') : window.location.href='<?= base_url('attendance?tab=corrections') ?>'" 
                    class="text-xs text-indigo-600 dark:text-indigo-400 font-bold hover:underline cursor-pointer flex items-center gap-1"
                >
                    <span>View All</span>
                    <i data-lucide="arrow-right" class="w-3 h-3"></i>
                </button>
            </div>
        </div>

        <div class="divide-y divide-slate-100 dark:divide-slate-800 mt-2 max-h-[380px] overflow-y-auto pr-1">
            <?php if (empty($pendingCorrections)): ?>
                <div class="py-8 text-center text-slate-400 text-xs">
                    <i data-lucide="check-circle-2" class="w-8 h-8 text-emerald-500 mx-auto mb-2 opacity-80"></i>
                    All regularization requests have been reviewed and resolved.
                </div>
            <?php else: ?>
                <?php foreach (array_slice($pendingCorrections, 0, 4) as $pc): ?>
                    <div class="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                        <div class="space-y-1">
                            <div class="flex items-center gap-2 flex-wrap">
                                <span class="font-bold text-slate-900 dark:text-white"><?= esc($pc['employee_name'] ?? 'Employee') ?></span>
                                <span class="text-[10px] font-mono text-slate-400">(<?= esc($pc['employee_code'] ?? 'EMP') ?>)</span>
                                <span class="px-2 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-400 text-[10px] font-bold"><?= esc($pc['request_type'] ?? 'Missing Check-In') ?></span>
                            </div>
                            <div class="text-slate-500 dark:text-slate-400 text-[11px] flex items-center gap-3">
                                <span>Date: <strong><?= esc($pc['attendance_date'] ?? $pc['date'] ?? '') ?></strong></span>
                                <span>Proposed: <strong class="text-indigo-600 dark:text-indigo-400 font-mono"><?= esc($pc['proposed_check_in'] ?? '--') ?> to <?= esc($pc['proposed_check_out'] ?? '--') ?></strong></span>
                            </div>
                            <div class="text-[11px] text-slate-600 dark:text-slate-300 italic">
                                "<?= esc($pc['reason'] ?? 'No reason provided') ?>"
                            </div>
                        </div>

                        <?php if (!empty($canApproveCorrection)): ?>
                            <div class="flex items-center gap-2 shrink-0">
                                <form action="<?= base_url('attendance/correction/approve/' . ($pc['id'] ?? '')) ?>" method="POST">
                                    <?= csrf_field() ?>
                                    <button type="submit" class="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs inline-flex items-center gap-1 shadow-xs cursor-pointer">
                                        <i data-lucide="check" class="w-3.5 h-3.5"></i> Approve
                                    </button>
                                </form>
                                <form action="<?= base_url('attendance/correction/reject/' . ($pc['id'] ?? '')) ?>" method="POST">
                                    <?= csrf_field() ?>
                                    <button type="submit" class="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-rose-50 hover:text-rose-600 text-slate-700 dark:text-slate-300 font-bold text-xs inline-flex items-center gap-1 cursor-pointer">
                                        <i data-lucide="x" class="w-3.5 h-3.5"></i> Reject
                                    </button>
                                </form>
                            </div>
                        <?php else: ?>
                            <div class="flex items-center gap-1 text-[11px] text-amber-600 dark:text-amber-400 font-medium">
                                <i data-lucide="clock" class="w-3 h-3"></i> Awaiting Review
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 flex items-center justify-between mt-3">
        <span>Managerial authorization enforced</span>
        <?php if (!empty($canApproveCorrection)): ?>
            <a href="<?= base_url('attendance?tab=corrections') ?>" class="text-indigo-600 dark:text-indigo-400 font-bold hover:underline">
                Manage Queue &rarr;
            </a>
        <?php endif; ?>
    </div>
</div>
