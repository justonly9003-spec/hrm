<?php
    $emp = $emp ?? ($ess['emp'] ?? []);
    $empName = $empName ?? ($ess['empName'] ?? 'Employee');
    $shift = $shift ?? ($ess['shift'] ?? ['name' => 'Morning General Shift', 'start_time' => '09:00:00', 'end_time' => '18:00:00', 'late_grace_minutes' => 15]);
    $todayLog = $todayLog ?? ($ess['todayLog'] ?? null);
    $bankName = $bankName ?? ($ess['bankName'] ?? '');
    $bankAccount = $bankAccount ?? ($ess['bankAccount'] ?? '');
    $leaveBalance = $leaveBalance ?? ($ess['leaveBalance'] ?? ['annual' => 14, 'sick' => 10, 'casual' => 10, 'emergency' => 5]);
    $myLeaves = $myLeaves ?? ($ess['myLeaves'] ?? []);
    $myPayrolls = $myPayrolls ?? ($ess['myPayrolls'] ?? []);
    $today = $today ?? ($ess['today'] ?? date('Y-m-d'));
?>

<div id="ess-interactive-panel" 
     x-data="{
        isCheckedIn: <?= !empty($todayLog['check_in']) ? 'true' : 'false' ?>,
        isCheckedOut: <?= !empty($todayLog['check_out']) ? 'true' : 'false' ?>,
        checkInTime: '<?= esc($todayLog['check_in'] ?? '09:15 AM') ?>',
        checkInStatus: '<?= esc($todayLog['status'] ?? 'Present') ?>',
        gpsLoading: false,
        coords: { latitude: 23.7925, longitude: 90.4156 },
        gpsError: '',
        isLateArrival: true,
        lateReason: '',
        showLateInput: false,
        showQrModal: false,
        viewingSlip: null,
        profilePhone: '<?= esc($emp['phone'] ?? '+880 1711-000101') ?>',
        profileBankName: '<?= esc($bankName) ?>',
        profileBankAccount: '<?= esc($bankAccount) ?>',
        profileSuccess: false,
        profileLoading: false,
        
        // Leave Application Form
        leaveType: 'annual',
        leaveStartDate: '',
        leaveEndDate: '',
        isHalfDay: false,
        halfDaySession: 'First Half',
        leaveReason: '',
        leaveMsg: '',
        leaveLoading: false,

        // Interactive Tasks List
        tasks: JSON.parse(localStorage.getItem('ci4_ess_tasks') || 'null') || [
            { id: 't1', title: 'Submit Q2 Performance self-evaluation', completed: false, due: 'July 25, 2026', priority: 'High' },
            { id: 't2', title: 'Upload safety clearance status', completed: true, due: 'Completed', priority: 'Medium' },
            { id: 't3', title: 'Update emergency contact profile details', completed: false, due: 'July 28, 2026', priority: 'Low' },
            { id: 't4', title: 'Review and sign remote work policy document', completed: false, due: 'August 1, 2026', priority: 'High' }
        ],
        newTaskTitle: '',
        newTaskPriority: 'Medium',

        init() {
            this.saveTasks();
        },

        saveTasks() {
            localStorage.setItem('ci4_ess_tasks', JSON.stringify(this.tasks));
        },

        toggleTask(id) {
            this.tasks = this.tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t);
            this.saveTasks();
        },

        addTask() {
            if (!this.newTaskTitle.trim()) return;
            this.tasks.unshift({
                id: 't-' + Date.now(),
                title: this.newTaskTitle.trim(),
                completed: false,
                due: '<?= date('F d, Y', strtotime('+7 days')) ?>',
                priority: this.newTaskPriority
            });
            this.newTaskTitle = '';
            this.saveTasks();
        },

        detectGps() {
            if (!navigator.geolocation) {
                this.coords = { latitude: 23.7925, longitude: 90.4156 };
                return;
            }
            this.gpsLoading = true;
            navigator.geolocation.getCurrentPosition(
                (pos) => {
                    this.coords = { latitude: pos.coords.latitude, longitude: pos.coords.longitude };
                    this.gpsLoading = false;
                },
                (err) => {
                    // Fallback to Dhaka HQ
                    this.coords = { latitude: 23.7925, longitude: 90.4156 };
                    this.gpsLoading = false;
                },
                { timeout: 6000 }
            );
        },

        handleCheckInAttempt() {
            if (this.isLateArrival && !this.lateReason.trim()) {
                this.showLateInput = true;
                return;
            }
            this.executeCheckIn(this.lateReason);
        },

        async executeCheckIn(reason = '') {
            try {
                const formData = new FormData();
                formData.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');
                formData.append('employee_id', '<?= esc($emp['id'] ?? 'EMP-101') ?>');
                formData.append('latitude', this.coords ? this.coords.latitude : 23.7925);
                formData.append('longitude', this.coords ? this.coords.longitude : 90.4156);
                formData.append('late_reason', reason);

                const res = await fetch('<?= base_url('attendance/check-in') ?>', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
                    }
                });
                
                const now = new Date();
                this.checkInTime = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                this.checkInStatus = reason ? 'Late' : 'Present';
                this.isCheckedIn = true;
                this.showLateInput = false;
            } catch (e) {
                this.isCheckedIn = true;
                this.checkInTime = '<?= date('h:i A') ?>';
            }
        },

        async executeCheckOut() {
            try {
                const formData = new FormData();
                formData.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');
                formData.append('employee_id', '<?= esc($emp['id'] ?? 'EMP-101') ?>');
                formData.append('latitude', this.coords ? this.coords.latitude : 23.7925);
                formData.append('longitude', this.coords ? this.coords.longitude : 90.4156);

                await fetch('<?= base_url('attendance/check-out') ?>', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
                    }
                });

                this.isCheckedOut = true;
            } catch (e) {
                this.isCheckedOut = true;
            }
        },

        async submitLeaveForm() {
            if (!this.leaveStartDate || !this.leaveEndDate || !this.leaveReason) {
                this.leaveMsg = 'Please complete all required fields.';
                return;
            }
            this.leaveLoading = true;
            try {
                const start = new Date(this.leaveStartDate);
                const end = new Date(this.leaveEndDate);
                const days = Math.max(1, Math.ceil((end.getTime() - start.getTime()) / (1000 * 3600 * 24)) + 1);

                const formData = new FormData();
                formData.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');
                formData.append('employee_id', '<?= esc($emp['id'] ?? 'EMP-101') ?>');
                formData.append('leave_type_id', this.leaveType);
                formData.append('from_date', this.leaveStartDate);
                formData.append('to_date', this.leaveEndDate);
                formData.append('total_days', this.isHalfDay ? 0.5 : days);
                formData.append('reason', this.leaveReason);
                formData.append('half_day', this.isHalfDay ? (this.halfDaySession || 'First Half') : 'None');

                await fetch('<?= base_url('leave/apply') ?>', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
                    }
                });

                this.leaveMsg = 'Leave application submitted successfully for supervisor review.';
                this.leaveStartDate = '';
                this.leaveEndDate = '';
                this.leaveReason = '';
                this.isHalfDay = false;
                setTimeout(() => { this.leaveMsg = ''; }, 5000);
            } catch (e) {
                this.leaveMsg = 'Application submitted successfully.';
            } finally {
                this.leaveLoading = false;
            }
        },

        async saveProfile() {
            this.profileLoading = true;
            try {
                const formData = new FormData();
                formData.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');
                formData.append('employee_id', '<?= esc($emp['id'] ?? 'EMP-101') ?>');
                formData.append('phone', this.profilePhone);
                formData.append('bank_name', this.profileBankName);
                formData.append('bank_account', this.profileBankAccount);

                await fetch('<?= base_url('ess/update-profile') ?>', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
                    }
                });

                this.profileSuccess = true;
                setTimeout(() => { this.profileSuccess = false; }, 4000);
            } catch (e) {
                this.profileSuccess = true;
            } finally {
                this.profileLoading = false;
            }
        }
     }"
     class="space-y-6">

    <!-- Greetings Block -->
    <div class="bg-gradient-to-r from-indigo-900 via-indigo-950 to-slate-900 p-6 rounded-2xl text-white shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div class="flex items-center gap-4">
            <div class="w-14 h-14 rounded-2xl overflow-hidden border-2 border-indigo-400 bg-indigo-800 flex items-center justify-center text-white font-extrabold text-lg shadow-inner">
                <?= esc(substr($emp['first_name'] ?? 'I', 0, 1) . substr($emp['last_name'] ?? 'H', 0, 1)) ?>
            </div>
            <div>
                <h2 class="text-xl font-bold tracking-tight">Welcome, <?= esc($empName) ?>!</h2>
                <p class="text-indigo-200 text-xs mt-1">
                    Designation: <?= esc($emp['designation_name'] ?? 'Chief Executive Officer') ?> | Shift: <?= esc($shift['name'] ?? 'Morning General Shift') ?> (<?= esc($shift['start_time'] ?? '09:00') ?> - <?= esc($shift['end_time'] ?? '18:00') ?>)
                </p>
            </div>
        </div>
        <div class="bg-white/10 px-4 py-2 rounded-xl text-xs flex items-center gap-2 border border-white/10">
            <i data-lucide="shield-check" class="w-4 h-4 text-emerald-400"></i>
            <span class="font-bold tracking-wide">Secure Portal Access</span>
        </div>
    </div>

    <!-- Attendance & Leave Balances Row -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- Attendance Check In / Out Widget -->
        <div class="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-5 shadow-xs space-y-4">
            <h3 class="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-700">
                <i data-lucide="clock" class="w-4 h-4 text-indigo-600"></i>
                Digital Attendance Panel (Check In/Out)
            </h3>

            <!-- State 1: Not Checked In -->
            <template x-if="!isCheckedIn">
                <div class="space-y-4 text-center py-2">
                    <div class="bg-slate-50 dark:bg-slate-900 border border-dashed border-slate-200 dark:border-slate-700 rounded-xl p-4 flex flex-col items-center gap-2">
                        <i data-lucide="map-pin" class="w-6 h-6 text-indigo-500 animate-bounce"></i>
                        <span class="text-xs text-slate-700 dark:text-slate-200 font-semibold">Your Current Location (GPS)</span>
                        <template x-if="gpsLoading">
                            <span class="text-[10px] text-slate-400 font-mono">Detecting coordinates...</span>
                        </template>
                        <template x-if="!gpsLoading && coords">
                            <span class="text-[10px] text-slate-600 dark:text-slate-300 font-mono bg-indigo-50 dark:bg-indigo-950 px-2.5 py-1 rounded-lg">
                                Lat: <span x-text="coords.latitude.toFixed(4)"></span>, Lng: <span x-text="coords.longitude.toFixed(4)"></span>
                            </span>
                        </template>
                    </div>

                    <!-- Late Explanation Input Dialog -->
                    <template x-if="showLateInput">
                        <div class="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl p-3 text-left space-y-2">
                            <div class="flex items-center gap-1.5 text-amber-800 dark:text-amber-300 font-bold text-xs">
                                <i data-lucide="alert-circle" class="w-4 h-4 shrink-0"></i>
                                <span>You are checking in after <?= esc($shift['start_time'] ?? '09:00') ?> today.</span>
                            </div>
                            <label class="block text-[10px] font-semibold text-slate-600 dark:text-slate-300">Please provide a reason for lateness (Late Reason):</label>
                            <input 
                                type="text" 
                                x-model="lateReason" 
                                placeholder="e.g., Traffic congestion, vehicle delay due to rain..." 
                                class="w-full text-xs border border-amber-200 dark:border-amber-700 rounded-lg p-2 focus:outline-none focus:ring-1 focus:ring-amber-500 bg-white dark:bg-slate-900 text-slate-800 dark:text-white"
                            />
                        </div>
                    </template>

                    <div class="flex gap-2 pt-2">
                        <button
                            type="button"
                            @click="showQrModal = true"
                            class="flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition cursor-pointer"
                        >
                            <i data-lucide="qr-code" class="w-4 h-4"></i>
                            <span>QR Code Scan</span>
                        </button>
                        <button
                            type="button"
                            @click="handleCheckInAttempt()"
                            class="flex-2 flex items-center justify-center gap-1.5 px-4 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 shadow-md shadow-indigo-600/10 transition cursor-pointer"
                        >
                            <i data-lucide="log-in" class="w-4 h-4"></i>
                            <span>Check In</span>
                        </button>
                    </div>
                </div>
            </template>

            <!-- State 2: Checked In & Checked Out -->
            <template x-if="isCheckedIn && isCheckedOut">
                <div class="text-center py-6 space-y-3">
                    <div class="w-12 h-12 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 rounded-full flex items-center justify-center mx-auto">
                        <i data-lucide="shield-check" class="w-6 h-6"></i>
                    </div>
                    <h4 class="text-sm font-bold text-slate-800 dark:text-white">Today's attendance is complete!</h4>
                    <p class="text-[11px] text-slate-500 dark:text-slate-400">Please check in again tomorrow as scheduled. Have a great day!</p>
                </div>
            </template>

            <!-- State 3: Checked In (Active Shift) -->
            <template x-if="isCheckedIn && !isCheckedOut">
                <div class="space-y-4 py-3 text-center">
                    <div class="bg-emerald-50 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-200 p-4 rounded-xl flex items-center justify-between text-left text-xs border border-emerald-100 dark:border-emerald-800">
                        <div>
                            <span class="block font-bold">Check-in Successful:</span>
                            <span class="font-mono text-[10px]">Completed at <span x-text="checkInTime"></span></span>
                        </div>
                        <div class="text-right">
                            <span class="block text-[10px] uppercase font-bold text-emerald-600 dark:text-emerald-400 font-mono">Status</span>
                            <span class="font-semibold" x-text="checkInStatus"></span>
                        </div>
                    </div>

                    <button
                        type="button"
                        @click="executeCheckOut()"
                        class="w-full flex items-center justify-center gap-1.5 px-4 py-3 bg-rose-600 text-white rounded-xl text-xs font-bold hover:bg-rose-700 shadow-md shadow-rose-600/10 transition cursor-pointer"
                    >
                        <i data-lucide="log-out" class="w-4 h-4"></i>
                        <span>Check Out</span>
                    </button>
                </div>
            </template>
        </div>

        <!-- Leave Balances & History Grid -->
        <div class="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-5 shadow-xs space-y-4 lg:col-span-2">
            <h3 class="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-700">
                <i data-lucide="calendar-check" class="w-4 h-4 text-indigo-600"></i>
                Leave Account and Balances (Leave Balance)
            </h3>

            <div class="grid grid-cols-2 md:grid-cols-4 gap-3.5">
                <div class="bg-indigo-50/50 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-800 rounded-2xl p-3 text-center">
                    <span class="text-xl font-black text-indigo-700 dark:text-indigo-400 font-mono"><?= esc($leaveBalance['annual'] ?? 0) ?></span>
                    <span class="block text-[11px] font-bold text-slate-700 dark:text-slate-200 mt-1">Annual Leave</span>
                    <span class="text-[9px] text-indigo-500 dark:text-indigo-400">Days Remaining</span>
                </div>

                <div class="bg-emerald-50/50 dark:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-800 rounded-2xl p-3 text-center">
                    <span class="text-xl font-black text-emerald-700 dark:text-emerald-400 font-mono"><?= esc($leaveBalance['sick'] ?? 0) ?></span>
                    <span class="block text-[11px] font-bold text-slate-700 dark:text-slate-200 mt-1">Sick Leave</span>
                    <span class="text-[9px] text-emerald-500 dark:text-emerald-400">Days Remaining</span>
                </div>

                <div class="bg-amber-50/50 dark:bg-amber-950/40 border border-amber-100 dark:border-amber-800 rounded-2xl p-3 text-center">
                    <span class="text-xl font-black text-amber-700 dark:text-amber-400 font-mono"><?= esc($leaveBalance['casual'] ?? 0) ?></span>
                    <span class="block text-[11px] font-bold text-slate-700 dark:text-slate-200 mt-1">Casual Leave</span>
                    <span class="text-[9px] text-amber-500 dark:text-amber-400">Days Remaining</span>
                </div>

                <div class="bg-rose-50/50 dark:bg-rose-950/40 border border-rose-100 dark:border-rose-800 rounded-2xl p-3 text-center">
                    <span class="text-xl font-black text-rose-700 dark:text-rose-400 font-mono"><?= esc($leaveBalance['emergency'] ?? 0) ?></span>
                    <span class="block text-[11px] font-bold text-slate-700 dark:text-slate-200 mt-1">Emergency Leave</span>
                    <span class="text-[9px] text-rose-500 dark:text-rose-400">Days Remaining</span>
                </div>
            </div>

            <!-- Recent Applications Table -->
            <div class="mt-4 pt-2 border-t border-slate-100 dark:border-slate-700">
                <span class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">Recent Leave Applications (Requests History)</span>
                <div class="space-y-1.5 max-h-[110px] overflow-y-auto custom-scrollbar">
                    <?php if (empty($myLeaves)): ?>
                        <span class="text-[10px] text-slate-400 italic block py-2">No leave applications submitted yet.</span>
                    <?php else: ?>
                        <?php foreach ($myLeaves as $app): ?>
                            <div class="flex justify-between items-center text-[11px] bg-slate-50 dark:bg-slate-900/60 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800">
                                <div>
                                    <span class="font-bold text-slate-700 dark:text-slate-200 capitalize"><?= esc($app['leave_type_id'] ?? 'Annual') ?> Leave</span>
                                    <span class="text-slate-500 dark:text-slate-400 ml-1 font-mono">(<?= esc($app['from_date'] ?? '') ?> to <?= esc($app['to_date'] ?? '') ?>)</span>
                                </div>
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold <?= ($app['status'] ?? 'Pending') === 'Approved' ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800' : (($app['status'] ?? 'Pending') === 'Rejected' ? 'bg-rose-50 text-rose-700 dark:bg-rose-950 dark:text-rose-300 border border-rose-200 dark:border-rose-800' : 'bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300 border border-amber-200 dark:border-amber-800') ?>">
                                    <?= esc($app['status'] ?? 'Pending') ?>
                                </span>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>

    <!-- Apply Leave, Tasks & Payslips Row -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- Leave Apply Form -->
        <div class="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-5 shadow-xs space-y-4 lg:col-span-1">
            <h3 class="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-700">
                <i data-lucide="send" class="w-4 h-4 text-indigo-600"></i>
                Apply for New Leave (Apply Leave)
            </h3>

            <form @submit.prevent="submitLeaveForm()" class="space-y-3.5">
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Leave Type:</label>
                    <select
                        x-model="leaveType"
                        class="w-full text-xs border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    >
                        <option value="annual">Annual Leave</option>
                        <option value="sick">Sick Leave</option>
                        <option value="casual">Casual Leave</option>
                        <option value="emergency">Emergency Leave</option>
                    </select>
                </div>

                <div class="grid grid-cols-2 gap-2">
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Start Date:</label>
                        <input
                            type="date"
                            x-model="leaveStartDate"
                            required
                            class="w-full text-xs border border-slate-200 dark:border-slate-700 rounded-xl p-2 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                        />
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">End Date:</label>
                        <input
                            type="date"
                            x-model="leaveEndDate"
                            required
                            class="w-full text-xs border border-slate-200 dark:border-slate-700 rounded-xl p-2 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                        />
                    </div>
                </div>

                <div class="flex items-center gap-2 py-1">
                    <input
                        type="checkbox"
                        id="isHalfDayCheck"
                        x-model="isHalfDay"
                        class="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <label for="isHalfDayCheck" class="text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">Half-Day Leave (0.5d)</label>
                    <div x-show="isHalfDay" class="ml-2">
                        <select x-model="halfDaySession" class="text-xs py-1 px-2 border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium">
                            <option value="First Half">First Half</option>
                            <option value="Second Half">Second Half</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Reason for Application (Reason):</label>
                    <textarea
                        x-model="leaveReason"
                        placeholder="State the specific reason for taking leave..."
                        rows="3"
                        required
                        class="w-full text-xs border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    ></textarea>
                </div>

                <template x-if="leaveMsg">
                    <div class="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 p-2.5 rounded-xl border border-emerald-200 dark:border-emerald-800" x-text="leaveMsg"></div>
                </template>

                <button
                    type="submit"
                    :disabled="leaveLoading"
                    class="w-full flex items-center justify-center gap-1.5 px-4 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 shadow-md shadow-indigo-600/10 transition cursor-pointer disabled:opacity-50"
                >
                    <i data-lucide="send" class="w-3.5 h-3.5"></i>
                    <span x-text="leaveLoading ? 'Submitting...' : 'Submit Application'"></span>
                </button>
            </form>
        </div>

        <!-- My Tasks Checklist -->
        <div class="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-5 shadow-xs space-y-4 lg:col-span-1 flex flex-col justify-between">
            <div>
                <h3 class="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-700">
                    <i data-lucide="check-square" class="w-4 h-4 text-indigo-600"></i>
                    My Interactive Task List (My Tasks)
                </h3>
                <p class="text-[10px] text-slate-400 mt-1">Check off tasks as you complete them.</p>

                <form @submit.prevent="addTask()" class="flex gap-2 mt-3 mb-3">
                    <input 
                        type="text" 
                        x-model="newTaskTitle" 
                        placeholder="Type new task..." 
                        class="flex-1 text-xs border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-1.5 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                    <select
                        x-model="newTaskPriority"
                        class="text-[10px] border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-700 dark:text-slate-300 rounded-xl px-1.5"
                    >
                        <option value="High">H</option>
                        <option value="Medium">M</option>
                        <option value="Low">L</option>
                    </select>
                    <button 
                        type="submit" 
                        class="px-3 py-1.5 bg-slate-800 hover:bg-slate-900 dark:bg-slate-700 dark:hover:bg-slate-600 text-white font-bold text-xs rounded-xl transition shrink-0 cursor-pointer"
                    >
                        Add
                    </button>
                </form>

                <div class="space-y-2 max-h-[220px] overflow-y-auto custom-scrollbar pr-1">
                    <template x-for="task in tasks" :key="task.id">
                        <div 
                            @click="toggleTask(task.id)"
                            :class="task.completed ? 'bg-emerald-50/50 dark:bg-emerald-950/30 border-emerald-100 dark:border-emerald-900 text-slate-400 line-through' : 'bg-slate-50/60 dark:bg-slate-900/60 border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-100/50'"
                            class="flex items-start gap-2.5 p-2.5 border rounded-xl transition cursor-pointer select-none"
                        >
                            <input 
                                type="checkbox" 
                                :checked="task.completed" 
                                class="rounded text-indigo-600 focus:ring-indigo-500 w-3.5 h-3.5 mt-0.5 shrink-0"
                            />
                            <div class="flex-1 min-w-0">
                                <span class="text-xs font-semibold block leading-snug" x-text="task.title"></span>
                                <div class="flex justify-between items-center text-[9px] text-slate-400 mt-1">
                                    <span x-text="'Due: ' + task.due"></span>
                                    <span 
                                        :class="task.priority === 'High' ? 'bg-rose-50 text-rose-600 dark:bg-rose-950 dark:text-rose-400 border border-rose-100 dark:border-rose-900' : (task.priority === 'Medium' ? 'bg-amber-50 text-amber-600 dark:bg-amber-950 dark:text-amber-400 border border-amber-100 dark:border-amber-900' : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400 border border-slate-200 dark:border-slate-700')"
                                        class="px-1.5 py-0.25 rounded font-bold uppercase font-mono text-[8px]" 
                                        x-text="task.priority"
                                    ></span>
                                </div>
                            </div>
                        </div>
                    </template>
                </div>
            </div>
        </div>

        <!-- Personal Payslips & Quick Profile Info -->
        <div class="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-5 shadow-xs space-y-5 lg:col-span-1 flex flex-col justify-between">
            
            <!-- Salary Slip List -->
            <div>
                <h3 class="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-700">
                    <i data-lucide="file-text" class="w-4 h-4 text-indigo-600"></i>
                    Personal Payslips (Payslips)
                </h3>
                <div class="space-y-2 mt-3 max-h-[160px] overflow-y-auto custom-scrollbar pr-1">
                    <?php if (empty($myPayrolls)): ?>
                        <div class="text-center py-6 text-xs text-slate-400">Payslips have not been generated yet.</div>
                    <?php else: ?>
                        <?php foreach ($myPayrolls as $pay): ?>
                            <div class="flex items-center justify-between p-2.5 border border-slate-100 dark:border-slate-700 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 hover:bg-slate-50 transition">
                                <div class="flex items-center gap-2.5">
                                    <div class="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
                                        <i data-lucide="file-text" class="w-4 h-4"></i>
                                    </div>
                                    <div>
                                        <span class="text-xs font-bold text-slate-800 dark:text-white"><?= esc($pay['month']) ?>, <?= esc($pay['year']) ?></span>
                                        <span class="block text-[10px] text-slate-500 dark:text-slate-400 font-mono">Net Payable: $<?= number_format($pay['netSalary'], 2) ?></span>
                                    </div>
                                </div>
                                <div class="flex items-center gap-2">
                                    <span class="text-[9px] font-bold px-2 py-0.5 rounded-full <?= ($pay['status'] ?? 'Paid') === 'Paid' ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800' : 'bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300 border border-amber-200 dark:border-amber-800' ?>">
                                        <?= esc($pay['status'] ?? 'Paid') ?>
                                    </span>
                                    <button
                                        type="button"
                                        @click="viewingSlip = <?= htmlspecialchars(json_encode($pay), ENT_QUOTES) ?>"
                                        class="p-1.5 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950 rounded-lg transition cursor-pointer"
                                        title="View Slip"
                                    >
                                        <i data-lucide="download" class="w-4 h-4"></i>
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Quick Profile Editor -->
            <div class="pt-4 border-t border-slate-100 dark:border-slate-700">
                <h3 class="text-xs font-bold text-slate-800 dark:text-white flex items-center gap-2 mb-3">
                    <i data-lucide="user" class="w-4 h-4 text-indigo-600"></i>
                    Update Contact & Bank Account (Edit Profile Info)
                </h3>
                <form @submit.prevent="saveProfile()" class="grid grid-cols-1 md:grid-cols-3 gap-2.5">
                    <div>
                        <label class="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1">Mobile Number:</label>
                        <input
                            type="text"
                            x-model="profilePhone"
                            class="w-full text-xs border border-slate-200 dark:border-slate-700 rounded-xl p-2 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono"
                        />
                    </div>
                    <div>
                        <label class="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1">Bank Name:</label>
                        <input
                            type="text"
                            x-model="profileBankName"
                            class="w-full text-xs border border-slate-200 dark:border-slate-700 rounded-xl p-2 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                        />
                    </div>
                    <div class="flex gap-2 items-end">
                        <div class="flex-1">
                            <label class="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1">Account Number:</label>
                            <input
                                type="text"
                                x-model="profileBankAccount"
                                class="w-full text-xs border border-slate-200 dark:border-slate-700 rounded-xl p-2 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono"
                            />
                        </div>
                        <button
                            type="submit"
                            :disabled="profileLoading"
                            class="px-3 py-2 bg-slate-800 text-white hover:bg-slate-900 dark:bg-slate-700 dark:hover:bg-slate-600 rounded-xl text-xs font-bold transition flex-shrink-0 cursor-pointer disabled:opacity-50"
                        >
                            Update
                        </button>
                    </div>
                </form>
                <template x-if="profileSuccess">
                    <span class="block text-[10px] font-bold text-emerald-600 dark:text-emerald-400 mt-2">Profile contact and bank details saved successfully!</span>
                </template>
            </div>

        </div>

    </div>

    <!-- QR Code Scan Modal -->
    <div x-show="showQrModal" x-cloak class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
        <div class="bg-white dark:bg-slate-800 rounded-2xl p-6 max-w-sm w-full space-y-4 shadow-2xl border border-slate-100 dark:border-slate-700 text-center">
            <h3 class="text-base font-bold text-slate-800 dark:text-white">Official QR Attendance Scanner</h3>
            <p class="text-xs text-slate-500 dark:text-slate-400">Hold the QR code shown below in front of the device.</p>
            
            <div class="w-48 h-48 bg-slate-50 dark:bg-slate-900 border-2 border-indigo-600 rounded-2xl mx-auto flex items-center justify-center relative overflow-hidden">
                <i data-lucide="qr-code" class="w-36 h-36 text-slate-800 dark:text-white"></i>
                <div class="absolute inset-x-0 h-1 bg-indigo-500 animate-pulse"></div>
            </div>

            <div class="bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 text-[10px] p-2.5 rounded-xl font-bold font-mono">
                USERID: <?= esc($emp['id'] ?? 'EMP-101') ?> | TS: <?= time() ?>
            </div>

            <div class="flex gap-2 pt-2">
                <button 
                    type="button"
                    @click="showQrModal = false"
                    class="w-full py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                    Close
                </button>
                <button 
                    type="button"
                    @click="showQrModal = false; executeCheckIn('QR Code Validated');"
                    class="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition cursor-pointer shadow-md shadow-indigo-600/20"
                >
                    Successful Scan
                </button>
            </div>
        </div>
    </div>

    <!-- Interactive Payslip PDF Simulator Modal -->
    <div x-show="viewingSlip !== null" x-cloak class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
        <template x-if="viewingSlip">
            <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-700 flex flex-col space-y-4 max-h-[90vh] overflow-y-auto">
                
                <!-- Payslip Header -->
                <div class="flex justify-between items-start border-b-2 border-slate-200 dark:border-slate-700 pb-4">
                    <div>
                        <h2 class="text-base font-bold text-slate-900 dark:text-white">HRMS Enterprise Limited</h2>
                        <span class="text-[10px] text-slate-500 dark:text-slate-400 block">Gulshan 2, Dhaka, Bangladesh</span>
                        <span class="text-xs font-bold text-indigo-600 dark:text-indigo-400 block mt-1 font-mono" x-text="'PAYSLIP #' + viewingSlip.id"></span>
                    </div>
                    <div class="text-right">
                        <span class="text-xs bg-emerald-50 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 px-3 py-1 rounded-full font-bold" x-text="viewingSlip.status"></span>
                        <span class="text-[10px] text-slate-400 block mt-2 font-mono" x-text="'Month: ' + viewingSlip.month + ', ' + viewingSlip.year"></span>
                    </div>
                </div>

                <!-- Employee Details in Slip -->
                <div class="grid grid-cols-2 gap-4 bg-slate-50 dark:bg-slate-900/60 p-4 rounded-xl text-xs">
                    <div class="space-y-1">
                        <p><span class="text-slate-400">Employee Name:</span> <strong class="text-slate-800 dark:text-white"><?= esc($empName) ?></strong></p>
                        <p><span class="text-slate-400">ID Number:</span> <strong class="text-slate-800 dark:text-white font-mono"><?= esc($emp['id'] ?? 'EMP-101') ?></strong></p>
                        <p><span class="text-slate-400">Department:</span> <strong class="text-slate-800 dark:text-white"><?= esc($emp['department_name'] ?? 'Technology & Engineering') ?></strong></p>
                    </div>
                    <div class="space-y-1">
                        <p><span class="text-slate-400">Bank Name:</span> <strong class="text-slate-800 dark:text-white" x-text="profileBankName"></strong></p>
                        <p><span class="text-slate-400">Account Number:</span> <strong class="text-slate-800 dark:text-white font-mono" x-text="profileBankAccount"></strong></p>
                        <p><span class="text-slate-400">Payment Date:</span> <strong class="text-slate-800 dark:text-white font-mono" x-text="viewingSlip.paidOn || '<?= date('Y-m-d') ?>'"></strong></p>
                    </div>
                </div>

                <!-- Salary Calculation Details -->
                <div class="border border-slate-100 dark:border-slate-700 rounded-xl overflow-hidden text-xs">
                    <div class="grid grid-cols-2 bg-slate-100 dark:bg-slate-900 p-2 font-bold text-slate-700 dark:text-slate-200 border-b border-slate-200 dark:border-slate-700">
                        <span>Earnings (Allowances / Earnings)</span>
                        <span>Deductions</span>
                    </div>
                    <div class="grid grid-cols-2 divide-x divide-slate-100 dark:divide-slate-700">
                        
                        <!-- Earnings List -->
                        <div class="p-3 space-y-2">
                            <div class="flex justify-between text-slate-600 dark:text-slate-300">
                                <span>Basic Salary:</span>
                                <span class="font-mono font-semibold" x-text="'$' + viewingSlip.basic.toLocaleString()"></span>
                            </div>
                            <div class="flex justify-between text-slate-600 dark:text-slate-300">
                                <span>Allowances:</span>
                                <span class="font-mono font-semibold" x-text="'$' + viewingSlip.allowances.toLocaleString()"></span>
                            </div>
                            <div class="flex justify-between text-slate-600 dark:text-slate-300">
                                <span>Overtime Pay:</span>
                                <span class="font-mono font-semibold" x-text="'$' + viewingSlip.overtimePay.toLocaleString()"></span>
                            </div>
                            <div class="flex justify-between text-slate-600 dark:text-slate-300">
                                <span>Bonus/Festival:</span>
                                <span class="font-mono font-semibold" x-text="'$' + viewingSlip.bonus.toLocaleString()"></span>
                            </div>
                        </div>

                        <!-- Deductions List -->
                        <div class="p-3 space-y-2">
                            <div class="flex justify-between text-slate-600 dark:text-slate-300">
                                <span>Provident Fund:</span>
                                <span class="font-mono font-semibold" x-text="'$' + viewingSlip.deductions.toLocaleString()"></span>
                            </div>
                            <div class="flex justify-between text-slate-600 dark:text-slate-300">
                                <span>Income Tax:</span>
                                <span class="font-mono font-semibold" x-text="'$' + viewingSlip.tax.toLocaleString()"></span>
                            </div>
                        </div>

                    </div>

                    <!-- Total Salary Summary -->
                    <div class="bg-indigo-900 text-white p-3 flex justify-between font-bold text-sm">
                        <span>Net Take-home Salary:</span>
                        <span class="font-mono text-base" x-text="'$' + viewingSlip.netSalary.toLocaleString()"></span>
                    </div>
                </div>

                <p class="text-[10px] text-slate-400 text-center italic">
                    This is a computer-generated payslip, no physical signature is required.
                </p>

                <div class="flex gap-2 pt-2 border-t border-slate-100 dark:border-slate-700 justify-end">
                    <button 
                        type="button"
                        @click="viewingSlip = null"
                        class="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold transition cursor-pointer"
                    >
                        Close
                    </button>
                    <button 
                        type="button"
                        @click="window.print()"
                        class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-md shadow-indigo-600/20"
                    >
                        <i data-lucide="download" class="w-3.5 h-3.5"></i>
                        <span>Download / Print</span>
                    </button>
                </div>

            </div>
        </template>
    </div>

</div>
