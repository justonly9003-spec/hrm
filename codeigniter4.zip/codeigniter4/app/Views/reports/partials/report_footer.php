<?php
/**
 * Report Footer Partial - Strictly Adheres to Independent Branding & Optional Image Rules
 * 
 * 1. REPORT FOOTER IMAGE is completely independent from Application Logo and Report Header.
 * 2. Layouts supported: 'center', 'left', 'right', 'full' (full-width banner), 'split'.
 * 3. Zero-space fallback: If no footer image is configured, disclaimer and page numbers render with 0px reserved whitespace.
 */

// Strictly separate: Report Footer Image must NOT fallback to application logo or header image
$rawFooterImg = $reportFooterImage ?? $company['report_footer_image'] ?? $footerImage ?? null;
$footerImgUrl = is_string($rawFooterImg) ? trim($rawFooterImg) : '';
$hasFooterImg = !empty($footerImgUrl) && 
                $footerImgUrl !== 'null' && 
                $footerImgUrl !== 'undefined' && 
                $footerImgUrl !== 'none' &&
                strlen($footerImgUrl) > 5;

$footerText = $reportFooterText ?? $company['report_footer_text'] ?? $footerText ?? 'This is an official system-generated document from Enterprise HRMS. Unauthorized alteration is prohibited.';
$footerLayout = $reportFooterLayout ?? $company['report_footer_layout'] ?? $layout ?? 'center';
$genDate = $generatedDate ?? date('Y-m-d H:i:s');
$pageText = $pageNumberText ?? 'Page 1 of 1';

$imgJustifyClass = $footerLayout === 'left' ? 'justify-start' : ($footerLayout === 'right' ? 'justify-end' : 'justify-center');
?>

<div class="report-footer-wrapper mt-4 pt-3 border-t border-slate-300">
    <?php if ($hasFooterImg): ?>
        <!-- [FOOTER IMAGE] - Rendered ONLY if configured; 0px reserved when absent -->
        <div class="report-footer-image-box mb-2.5 flex <?= $imgJustifyClass ?> <?= $footerLayout === 'full' ? 'w-full' : '' ?>">
            <?php if ($footerLayout === 'full'): ?>
                <div class="w-full max-h-20 md:max-h-24 overflow-hidden rounded-md border border-slate-200">
                    <img src="<?= esc($footerImgUrl) ?>" 
                         alt="Footer Banner" 
                         class="w-full h-full max-h-20 md:max-h-24 object-cover"
                         onerror="this.closest('.report-footer-image-box')?.remove();" />
                </div>
            <?php else: ?>
                <img src="<?= esc($footerImgUrl) ?>" 
                     alt="Footer Banner" 
                     class="max-h-14 md:max-h-16 max-w-full object-contain"
                     onerror="this.closest('.report-footer-image-box')?.remove();" />
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <!-- Footer Text, Generated Date & Page numbering -->
    <?php if ($footerLayout === 'center'): ?>
        <div class="report-footer-meta text-center space-y-1 text-[11px] text-slate-600 font-medium">
            <p class="footer-msg max-w-lg mx-auto leading-tight"><?= esc($footerText) ?></p>
            <div class="flex justify-center items-center gap-4 font-mono">
                <span>Generated Date: <strong class="text-slate-700 font-bold"><?= esc($genDate) ?></strong></span>
                <span>|</span>
                <strong class="text-slate-700 font-bold"><?= esc($pageText) ?></strong>
            </div>
        </div>
    <?php elseif ($footerLayout === 'left'): ?>
        <div class="report-footer-meta text-left space-y-1 text-[11px] text-slate-600 font-medium">
            <p class="footer-msg max-w-xl leading-tight"><?= esc($footerText) ?></p>
            <div class="flex items-center gap-4 font-mono">
                <span>Generated Date: <strong class="text-slate-700 font-bold"><?= esc($genDate) ?></strong></span>
                <span>|</span>
                <strong class="text-slate-700 font-bold"><?= esc($pageText) ?></strong>
            </div>
        </div>
    <?php elseif ($footerLayout === 'right'): ?>
        <div class="report-footer-meta text-right space-y-1 text-[11px] text-slate-600 font-medium">
            <p class="footer-msg max-w-xl ml-auto leading-tight"><?= esc($footerText) ?></p>
            <div class="flex justify-end items-center gap-4 font-mono">
                <span>Generated Date: <strong class="text-slate-700 font-bold"><?= esc($genDate) ?></strong></span>
                <span>|</span>
                <strong class="text-slate-700 font-bold"><?= esc($pageText) ?></strong>
            </div>
        </div>
    <?php else: ?>
        <div class="flex flex-row justify-between items-center gap-2 text-[11px] text-slate-600 font-medium">
            <div class="footer-msg text-left max-w-md">
                <?= esc($footerText) ?>
            </div>
            <div class="footer-date font-mono">
                Generated Date: <span class="font-semibold text-slate-700"><?= esc($genDate) ?></span>
            </div>
            <div class="footer-page font-mono font-semibold text-slate-700">
                <?= esc($pageText) ?>
            </div>
        </div>
    <?php endif; ?>
</div>
