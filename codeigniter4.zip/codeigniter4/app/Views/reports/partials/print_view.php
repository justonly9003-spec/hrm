<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $cleanType = strtolower(trim(str_replace(['-', ' '], '_', $type ?? 'attendance')));
    if (str_starts_with($cleanType, 'att_')) {
        $cleanType = substr($cleanType, 4);
    }
    
    // Directory of all 22 Attendance & Time Management Reports with English specifications
    $reportSpecs = [
        'daily_summary' => [
            'number'      => 1,
            'title'       => 'Daily Attendance Summary',
            'subtitle'    => 'Overall daily workforce presence, absence, leave, and off-duty metrics',
            'info_en'     => 'Total Employees, Present, Absent, Late, Leave, Holiday, Weekly Off',
            'category'    => 'Summary & Analytics',
            'orientation' => 'landscape',
        ],
        'monthly_summary' => [
            'number'      => 2,
            'title'       => 'Monthly Attendance Summary',
            'subtitle'    => 'Employee-wise monthly attendance, absence, and payable days summary',
            'info_en'     => 'Calendar Days, Present Days, Absent Days, Leave Days, Weekly Offs, Holidays, Late Days, Total Worked Hours, Overtime Hours, Attendance Rate',
            'category'    => 'Summary & Analytics',
            'orientation' => 'landscape',
        ],
        'employee_details' => [
            'number'      => 3,
            'title'       => 'Employee Attendance Details',
            'subtitle'    => 'Daily check-in, check-out, worked hours, and punch timestamps',
            'info_en'     => 'Check-in, Check-out, Regular Hours, Worked Hours, Overtime Hours, Late Minutes, Early Out Minutes, Verification Method',
            'category'    => 'Registers & Details',
            'orientation' => 'landscape',
        ],
        'attendance_register' => [
            'number'      => 4,
            'title'       => 'Attendance Register',
            'subtitle'    => 'Comprehensive date-wise staff attendance and time log register',
            'info_en'     => 'All employee date-wise attendance, Shift, In Time, Out Time, Late Minutes, Early Out Minutes, Worked Hours, Day Type',
            'category'    => 'Registers & Details',
            'orientation' => 'landscape',
        ],
        'department_summary' => [
            'number'      => 5,
            'title'       => 'Department Attendance Summary',
            'subtitle'    => 'Department-level attendance percentage, late arrival rate, and work hours',
            'info_en'     => 'Total Staff, Present, Absent, On Leave, Late Count, Average Worked Hours, Punctuality Score, Attendance Rate (%)',
            'category'    => 'Summary & Analytics',
            'orientation' => 'portrait',
        ],
        'branch_summary' => [
            'number'      => 6,
            'title'       => 'Branch Attendance Summary',
            'subtitle'    => 'Branch/Office workforce presence, punctuality, and work hours summary',
            'info_en'     => 'Branch Name, Active Staff, Present, Absent, Late, On Leave, Average Worked Hours, Attendance Rate (%)',
            'category'    => 'Summary & Analytics',
            'orientation' => 'portrait',
        ],
        'shift_wise' => [
            'number'      => 7,
            'title'       => 'Shift-wise Attendance',
            'subtitle'    => 'Attendance, lateness, and completion rate breakdown by operational shift',
            'info_en'     => 'Shift Name, Timing, Scheduled Staff, Present, Absent, Late Arrivals, Shift Adherence Rate (%)',
            'category'    => 'Operational',
            'orientation' => 'landscape',
        ],
        'late_attendance' => [
            'number'      => 8,
            'title'       => 'Late Attendance Report',
            'subtitle'    => 'Late arrival dates, shift start times, delay minutes, and monthly late frequency',
            'info_en'     => 'Date, Employee Code, Name, Department, Shift, Shift Start Time, Actual In Time, Late Minutes, Period Total Late Count',
            'category'    => 'Punctuality & Discipline',
            'orientation' => 'landscape',
        ],
        'early_checkout' => [
            'number'      => 9,
            'title'       => 'Early Checkout Report',
            'subtitle'    => 'Early departure records before scheduled shift conclusion and duration lost',
            'info_en'     => 'Shift End Time, Actual Check-Out Time, Early Out Minutes, Worked Hours, Departure Remarks',
            'category'    => 'Punctuality & Discipline',
            'orientation' => 'landscape',
        ],
        'absenteeism' => [
            'number'      => 10,
            'title'       => 'Absenteeism Report',
            'subtitle'    => 'Unexcused absence days, absenteeism percentage, and streak monitoring',
            'info_en'     => 'Total Calendar Days, Absent Days, Consecutive Absent Streak, Absenteeism Rate (%), Disciplinary Risk Rating',
            'category'    => 'Punctuality & Discipline',
            'orientation' => 'portrait',
        ],
        'missing_punch' => [
            'number'      => 11,
            'title'       => 'Missing Punch Report',
            'subtitle'    => 'Incomplete attendance records missing either check-in or check-out punch',
            'info_en'     => 'Date, Check-In Status, Check-Out Status, Missing Punch Type, Regularization Status',
            'category'    => 'Exceptions & Anomalies',
            'orientation' => 'portrait',
        ],
        'attendance_correction' => [
            'number'      => 12,
            'title'       => 'Attendance Correction Report',
            'subtitle'    => 'Regularization requests, adjustment approval audit trail, and original vs proposed times',
            'info_en'     => 'Request Date, Original Timestamps, Proposed Timestamps, Reason, Approved By, Audit Status',
            'category'    => 'Audit & Regularization',
            'orientation' => 'landscape',
        ],
        'manual_attendance' => [
            'number'      => 13,
            'title'       => 'Manual Attendance Report',
            'subtitle'    => 'Manually entered or overridden attendance records with operator justification',
            'info_en'     => 'Punch Date, Manual In, Manual Out, Worked Hours, Entered By, Reason / Justification',
            'category'    => 'Audit & Regularization',
            'orientation' => 'landscape',
        ],
        'gps_geofence' => [
            'number'      => 14,
            'title'       => 'GPS / Geofence Attendance Report',
            'subtitle'    => 'Mobile/remote punches, GPS coordinates, distance, and geofence perimeter violations',
            'info_en'     => 'Punch Timestamp, GPS Coordinates (Latitude / Longitude), Location Address, Geofence Distance, Geofence Violation Flag',
            'category'    => 'Mobile & Biometric',
            'orientation' => 'landscape',
        ],
        'qr_kiosk' => [
            'number'      => 15,
            'title'       => 'QR / Kiosk Attendance Report',
            'subtitle'    => 'Attendance captured via stationary tablet kiosks and dynamic QR scanners',
            'info_en'     => 'Kiosk Terminal ID, Device Name, Location, Scan Mode (QR / Pin / Face), Punch Timestamp',
            'category'    => 'Mobile & Biometric',
            'orientation' => 'landscape',
        ],
        'zkteco_sync' => [
            'number'      => 16,
            'title'       => 'ZKTeco Device Sync Report',
            'subtitle'    => 'Biometric hardware synchronization history, imported punches, and duplicate audit',
            'info_en'     => 'Device Serial, Sync Status, Imported Punches Count, Sync Failures, Duplicate Punches Skipped, Last Sync Timestamp',
            'category'    => 'Hardware Integration',
            'orientation' => 'landscape',
        ],
        'worked_hours' => [
            'number'      => 17,
            'title'       => 'Worked Hours Report',
            'subtitle'    => 'Daily, weekly, and monthly worked hours, scheduled duty, overtime, and shortfalls',
            'info_en'     => 'Daily Average Hours, Weekly Worked Hours, Monthly Total Hours, Scheduled Hours, Overtime Hours, Shortfall Hours, Completion Rate (%)',
            'category'    => 'Analytics & Labor Hours',
            'orientation' => 'landscape',
        ],
        'attendance_percentage' => [
            'number'      => 18,
            'title'       => 'Attendance Percentage Report',
            'subtitle'    => 'Multi-level attendance rate percentages across employee, department, and branch',
            'info_en'     => 'Scope Level, Entity Name, Present Days, Required Days, Attendance Percentage (%), Punctuality Score, Rating',
            'category'    => 'Analytics & Compliance',
            'orientation' => 'landscape',
        ],
        'muster_roll' => [
            'number'      => 19,
            'title'       => 'Muster Roll / Muster Register',
            'subtitle'    => 'Statutory labor law muster roll grid of daily attendance status codes (days 1-31)',
            'info_en'     => 'Daily Grid (Day 01 to 31), Total Present, Total Absent, Total Weekly Off, Total Holiday, Total Leave, Net Payable Days',
            'category'    => 'Statutory & Labor Register',
            'orientation' => 'landscape',
        ],
        'attendance_exception' => [
            'number'      => 20,
            'title'       => 'Attendance Exception Report',
            'subtitle'    => 'Wrong shifts, duplicate punches within 5 mins, excessive shift hours, and anomalies',
            'info_en'     => 'Exception Category, Severity, Anomaly Details, Action Recommended',
            'category'    => 'Exceptions & Anomalies',
            'orientation' => 'landscape',
        ],
        'joining_boundary' => [
            'number'      => 21,
            'title'       => 'Joining-date Boundary Report',
            'subtitle'    => 'Pre-joining date boundary audit verifying zero false absent deductions before joining',
            'info_en'     => 'Joining Date, Days Prior to Joining, Pre-Joining Log Rows, False Absent Count, Compliance Status',
            'category'    => 'Statutory & Compliance',
            'orientation' => 'landscape',
        ],
        'roster_vs_actual' => [
            'number'      => 23,
            'title'       => 'Roster vs Actual Attendance Comparison',
            'subtitle'    => 'Scheduled shift vs biometric punch adherence, early/late deviations, and variance',
            'info_en'     => 'Scheduled Shift, Shift Timing, Scheduled Hours, Actual In, Actual Out, Actual Worked Hours, Variance, Compliance Status',
            'category'    => 'Roster & Adherence',
            'orientation' => 'landscape',
        ],
        'shift_coverage' => [
            'number'      => 24,
            'title'       => 'Shift Coverage & Staffing Analysis',
            'subtitle'    => 'Shift-wise staffing target versus actual presence headcount and variance analysis',
            'info_en'     => 'Date, Shift Code, Shift Name, Shift Timing, Scheduled Staff, Actual Present, Staff Variance, Coverage (%), Staffing Status',
            'category'    => 'Roster & Staffing',
            'orientation' => 'landscape',
        ],
        'weekly_roster' => [
            'number'      => 25,
            'title'       => 'Weekly Roster Master Schedule',
            'subtitle'    => 'Weekly employee shift rotation grid with daily shift codes and off-day allocations',
            'info_en'     => 'Employee Code, Employee Name, Department, 7-Day Shift Grid, Total Working Days, Total Rest Days',
            'category'    => 'Roster & Staffing',
            'orientation' => 'landscape',
        ],
        'monthly_roster' => [
            'number'      => 26,
            'title'       => 'Monthly Shift & Roster Schedule',
            'subtitle'    => 'Monthly aggregate of working shifts, scheduled rest days, duty overrides, and roster statuses',
            'info_en'     => 'Employee Code, Employee Name, Department, Master Shift, Working Days, Off Days, Duty Assignments, Roster Status',
            'category'    => 'Roster & Staffing',
            'orientation' => 'landscape',
        ],
        'employee_roster' => [
            'number'      => 27,
            'title'       => 'Individual Employee Roster Calendar',
            'subtitle'    => 'Personal shift schedule calendar showing assignment tier, timing, and rest day status',
            'info_en'     => 'Date, Day, Employee Code, Employee Name, Department, Scheduled Shift, Timing, Assignment Source, Day Off',
            'category'    => 'Roster & Staffing',
            'orientation' => 'landscape',
        ],
        'department_branch_roster' => [
            'number'      => 28,
            'title'       => 'Department & Branch Roster Deployment',
            'subtitle'    => 'Roster headcount and man-hour distribution across branches, departments, and shifts',
            'info_en'     => 'Branch, Department, Date, Shift Code, Shift Name, Shift Hours, Published Staff, Draft Staff, Headcount, Manhours',
            'category'    => 'Roster & Staffing',
            'orientation' => 'landscape',
        ],
        'late_early' => [
            'number'      => 29,
            'title'       => 'Consolidated Late & Early Departure Report',
            'subtitle'    => 'Unified punctuality audit of late arrivals and early checkouts with total lost minutes',
            'info_en'     => 'Date, Employee Code, Employee Name, Department, Scheduled In, Actual In, Late Mins, Scheduled Out, Actual Out, Early Mins, Total Lost Mins',
            'category'    => 'Punctuality & Exceptions',
            'orientation' => 'landscape',
        ],
        'holiday_off_day_work' => [
            'number'      => 30,
            'title'       => 'Holiday & Scheduled Off-Day Work Audit',
            'subtitle'    => 'Duty performed on public holidays and scheduled weekly offs with overtime claim status',
            'info_en'     => 'Date, Employee Code, Employee Name, Department, Day Classification, Occasion, Clock In, Clock Out, Worked Hours, OT Hours, Approval Status',
            'category'    => 'Labor Law & Exceptions',
            'orientation' => 'landscape',
        ],
        'unassigned_employee' => [
            'number'      => 31,
            'title'       => 'Unassigned Shift & Gap Analysis',
            'subtitle'    => 'Identifies active workforce missing master shift assignments or roster schedules',
            'info_en'     => 'Employee Code, Employee Name, Department, Designation, Branch, Master Shift Status, Rostered Days, Unassigned Days, Risk Level',
            'category'    => 'Compliance & Roster Gaps',
            'orientation' => 'landscape',
        ],
        'shift_conflict' => [
            'number'      => 32,
            'title'       => 'Shift Conflict & Turnaround Audit',
            'subtitle'    => 'Detects turnaround rest violations (<8h), leave overlaps, and conflicting duty schedules',
            'info_en'     => 'Date, Employee Code, Employee Name, Department, Conflict Type, Primary Schedule, Conflicting Assignment, Turnaround Gap, Severity',
            'category'    => 'Compliance & Audit',
            'orientation' => 'landscape',
        ],
        'daily_overtime' => [
            'number'      => 69,
            'title'       => 'Daily Overtime Operational Register',
            'subtitle'    => 'Detailed daily overtime records with early arrival, post-shift, holiday hours, and rates',
            'info_en'     => 'Date, Employee Code, Employee Name, Department, OT Type, Start Time, End Time, Payable Mins, OT Hours, Rate, Amount, Status',
            'category'    => 'Overtime Operations',
            'orientation' => 'landscape',
        ],
        'weekly_overtime' => [
            'number'      => 70,
            'title'       => 'Weekly Overtime Distribution Report',
            'subtitle'    => 'Weekly employee overtime distribution separating regular shift OT from off-day OT',
            'info_en'     => 'Week Period, Employee Code, Employee Name, Department, Regular OT, Off-Day OT, Holiday OT, Total Hours, Amount, Approval Status',
            'category'    => 'Overtime Operations',
            'orientation' => 'landscape',
        ],
        'lock_reopen' => [
            'number'      => 22,
            'title'       => 'Attendance Lock / Reopen Report',
            'subtitle'    => 'Monthly attendance lock and administrative reopen audit trail with justification notes',
            'info_en'     => 'Period Month, Action, Lock Type, Status, Administrator, Action Timestamp, Lock Hash, Reason / Justification',
            'category'    => 'Statutory & Compliance',
            'orientation' => 'landscape',
        ],
        // Leave Management Reports (23 to 40)
        'leave_application_register' => [
            'number'      => 23,
            'title'       => 'Leave Application Register',
            'subtitle'    => 'Master register of all employee leave applications, requested dates, and current status',
            'info_en'     => 'Application ID, Applied Date, Employee Code, Name, Department, Designation, Leave Type, Duration, Status',
            'category'    => 'Leave Management & Registers',
            'orientation' => 'landscape',
        ],
        'pending_leave_approval' => [
            'number'      => 24,
            'title'       => 'Pending Leave Approval',
            'subtitle'    => 'Leave applications awaiting approval, pending duration aging, and designated approvers',
            'info_en'     => 'Application ID, Submission Date, Employee Code, Name, Department, Leave Type, Duration, Days Pending, Reason',
            'category'    => 'Workflow & Approvals',
            'orientation' => 'landscape',
        ],
        'approved_leave_report' => [
            'number'      => 25,
            'title'       => 'Approved Leave Report',
            'subtitle'    => 'List of all authorized leaves, approved duration, approval dates, and authorizing managers',
            'info_en'     => 'Application ID, Employee Code, Name, Department, Leave Type, Approved Dates, Days, Approved By, Approval Date',
            'category'    => 'Workflow & Approvals',
            'orientation' => 'landscape',
        ],
        'rejected_leave_report' => [
            'number'      => 26,
            'title'       => 'Rejected Leave Report',
            'subtitle'    => 'Rejected leave requests audit log with rejection reasons, timestamps, and reviewers',
            'info_en'     => 'Application ID, Employee Code, Name, Department, Leave Type, Requested Dates, Rejected By, Rejection Reason',
            'category'    => 'Workflow & Approvals',
            'orientation' => 'landscape',
        ],
        'cancelled_leave_report' => [
            'number'      => 27,
            'title'       => 'Cancelled Leave Report',
            'subtitle'    => 'Leave requests cancelled after submission or authorization with cancellation reasons',
            'info_en'     => 'Application ID, Employee Code, Name, Department, Leave Type, Cancelled Dates, Cancelled By, Cancellation Reason',
            'category'    => 'Workflow & Approvals',
            'orientation' => 'landscape',
        ],
        'employee_leave_balance' => [
            'number'      => 28,
            'title'       => 'Employee Leave Balance',
            'subtitle'    => 'Detailed leave balance accounting: opening, earned, availed, pending, and net remaining',
            'info_en'     => 'Employee Code, Name, Department, Leave Type, Opening Balance, Entitled / Earned, Used, Pending, Remaining Balance',
            'category'    => 'Balances & Entitlements',
            'orientation' => 'landscape',
        ],
        'leave_ledger' => [
            'number'      => 29,
            'title'       => 'Leave Ledger',
            'subtitle'    => 'Individual chronological transaction ledger of all leave debits, credits, and adjustments',
            'info_en'     => 'Transaction Date, Employee Code, Name, Department, Leave Type, Type (Credit/Debit), Days, Reference, Remarks',
            'category'    => 'Balances & Entitlements',
            'orientation' => 'landscape',
        ],
        'leave_type_summary' => [
            'number'      => 30,
            'title'       => 'Leave Type Summary',
            'subtitle'    => 'Company-wide summary of leave quotas across Earned, Annual, Sick, Casual, Paid, and Unpaid',
            'info_en'     => 'Leave Code, Leave Type Name, Category, Annual Quota, Enrolled Staff, Total Entitled, Total Taken, Remaining, Utilization %',
            'category'    => 'Summary & Analytics',
            'orientation' => 'landscape',
        ],
        'department_leave_calendar' => [
            'number'      => 31,
            'title'       => 'Department Leave Calendar',
            'subtitle'    => 'Departmental leave schedule, staffing coverage, and daily absence impact analysis',
            'info_en'     => 'Leave Date, Department, Employee Code, Name, Designation, Leave Type, Duration, Dept Headcount, Staff On Leave, Present Count',
            'category'    => 'Calendar & Planning',
            'orientation' => 'landscape',
        ],
        'branch_leave_calendar' => [
            'number'      => 32,
            'title'       => 'Branch Leave Calendar',
            'subtitle'    => 'Branch-level workforce leave calendar, absence distribution, and operational availability',
            'info_en'     => 'Leave Period, Branch Name, Employee Code, Name, Department, Leave Type, Days, Branch Headcount, Available Staff, Availability %',
            'category'    => 'Calendar & Planning',
            'orientation' => 'landscape',
        ],
        'leave_encashment_report' => [
            'number'      => 33,
            'title'       => 'Leave Encashment Report',
            'subtitle'    => 'Monetary calculation of encashable leave balances, daily basic rates, and payout amounts',
            'info_en'     => 'Employee Code, Name, Department, Designation, Leave Type, Encashed Days, Basic Salary, Daily Rate, Encashment Payout, Status',
            'category'    => 'Financial & Payroll Integration',
            'orientation' => 'landscape',
        ],
        'leave_accrual_report' => [
            'number'      => 34,
            'title'       => 'Leave Accrual Report',
            'subtitle'    => 'Periodic monthly/annual leave accrual calculations, earned rates, and tenure progression',
            'info_en'     => 'Accrual Period, Employee Code, Name, Department, Leave Type, Monthly Rate, Period Accrued, Cumulative Accrued, Annual Cap',
            'category'    => 'Balances & Entitlements',
            'orientation' => 'landscape',
        ],
        'carry_forward_report' => [
            'number'      => 35,
            'title'       => 'Carry-forward Report',
            'subtitle'    => 'Annual year-end carry-over audit, maximum carry limits, and expired/lapsed leave balances',
            'info_en'     => 'Year, Employee Code, Name, Department, Leave Type, Previous Year Unused, Max Carry Limit, Carried Forward Days, Lapsed Days',
            'category'    => 'Balances & Entitlements',
            'orientation' => 'landscape',
        ],
        'loss_of_pay_report' => [
            'number'      => 36,
            'title'       => 'Loss of Pay (LOP) Report',
            'subtitle'    => 'Unpaid leave days, unexcused absence days, daily rate, and estimated payroll deductions',
            'info_en'     => 'Period Month, Employee Code, Name, Department, Designation, Unpaid Days, Absent Days, Total LOP Days, Daily Rate, Estimated Deduction',
            'category'    => 'Financial & Payroll Integration',
            'orientation' => 'landscape',
        ],
        'probation_leave_eligibility' => [
            'number'      => 37,
            'title'       => 'Probation Leave Eligibility',
            'subtitle'    => 'Probationary employee leave entitlement status, waiting periods, and policy restrictions',
            'info_en'     => 'Employee Code, Name, Department, Designation, Joining Date, Probation End Date, Probation Status, Leave Type, Eligibility Mode',
            'category'    => 'Policy & Compliance',
            'orientation' => 'landscape',
        ],
        'leave_policy_compliance' => [
            'number'      => 38,
            'title'       => 'Leave Policy Compliance',
            'subtitle'    => 'Labor law & organizational policy adherence audit: notice periods, sandwich rule, and limits',
            'info_en'     => 'Application ID, Employee Code, Name, Department, Leave Type, Leave Duration, Notice Given, Sandwich Rule, Compliance Status',
            'category'    => 'Policy & Compliance',
            'orientation' => 'landscape',
        ],
        'leave_overlap_conflict' => [
            'number'      => 39,
            'title'       => 'Leave Overlap / Conflict Report',
            'subtitle'    => 'Simultaneous leave conflicts within departments, staffing shortages, and operational risk',
            'info_en'     => 'Conflict Date, Department, Overlapping Staff Count, Staff On Leave Names, Dept Headcount, Active Staff, Shortfall Risk Level',
            'category'    => 'Risk & Operations',
            'orientation' => 'landscape',
        ],
        'leave_approval_history' => [
            'number'      => 40,
            'title'       => 'Leave Approval History',
            'subtitle'    => 'Complete approval lifecycle audit log: applicants, reviewers, timestamps, and turnaround times',
            'info_en'     => 'Application ID, Employee Code, Name, Department, Leave Type, Submission Time, Final Status, Decision Maker, Decision Time, Turnaround',
            'category'    => 'Audit & Governance',
            'orientation' => 'landscape',
        ],
    ];

    $spec = $reportSpecs[$cleanType] ?? [
        'number'      => null,
        'title'       => ucwords(str_replace('_', ' ', $cleanType)) . ' Report',
        'subtitle'    => 'Operational analytics and audit statement',
        'info_en'     => 'Selected period records and analytical breakdown',
        'category'    => 'Operational',
        'orientation' => (!empty($reportData) && count(array_keys($reportData[0])) > 7) ? 'landscape' : 'portrait',
    ];

    $orientation = $spec['orientation'] ?? 'portrait';
    if (!empty($reportData) && count(array_keys($reportData[0])) > 8) {
        $orientation = 'landscape';
    }

    $colCount = !empty($reportData) ? count(array_keys($reportData[0])) : 1;
    ?>
    <title><?= esc($spec['title']) ?> - <?= esc($company['name'] ?? 'HRMS Enterprise') ?></title>
    <!-- Multi-CDN resilient loading of html2pdf bundle -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        if (typeof window.html2pdf === 'undefined') {
            var fbScript = document.createElement('script');
            fbScript.src = "https://cdn.jsdelivr.net/npm/html2pdf.js@0.10.1/dist/html2pdf.bundle.min.js";
            fbScript.crossOrigin = "anonymous";
            document.head.appendChild(fbScript);
        }
    </script>
    <style>
        @page {
            size: <?= $orientation === 'landscape' ? 'landscape' : 'portrait' ?>;
            margin: 8mm 8mm 10mm 8mm;
        }

        *, *::before, *::after {
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            font-size: 10.5px;
            line-height: 1.4;
            color: #0f172a;
            background: #ffffff;
            margin: 0;
            padding: 15px 20px;
        }

        /* Top Action Bar (hidden when printed) */
        .action-bar {
            background: #0f172a;
            color: #ffffff;
            padding: 10px 16px;
            margin: -15px -20px 20px -20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 2px 6px rgba(0,0,0,0.15);
            font-size: 12px;
        }
        .action-bar-left {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .action-bar-btn {
            background: #3b82f6;
            color: #ffffff;
            border: none;
            padding: 6px 14px;
            border-radius: 6px;
            font-weight: 600;
            font-size: 12px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: background 0.15s;
        }
        .action-bar-btn:hover {
            background: #2563eb;
        }
        .action-bar-btn.btn-secondary {
            background: #334155;
        }
        .action-bar-btn.btn-secondary:hover {
            background: #475569;
        }

        /* Official Corporate Document Header */
        .report-header {
            border-bottom: 2px solid #0f172a;
            padding-bottom: 12px;
            margin-bottom: 14px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 20px;
        }
        .company-brand {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .company-logo {
            max-height: 52px;
            max-width: 140px;
            object-fit: contain;
        }
        .company-avatar {
            width: 48px;
            height: 48px;
            background: #4338ca;
            color: #ffffff;
            font-size: 20px;
            font-weight: 800;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
        }
        .company-name {
            font-size: 17px;
            font-weight: 800;
            color: #0f172a;
            margin: 0;
            letter-spacing: -0.3px;
        }
        .company-meta {
            font-size: 10px;
            color: #64748b;
            margin-top: 2px;
            line-height: 1.35;
        }

        /* Report Title & Metadata Badge */
        .report-title-card {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-left: 4px solid #4338ca;
            padding: 10px 14px;
            border-radius: 6px;
            margin-bottom: 14px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }
        .report-title-text {
            font-size: 15px;
            font-weight: 800;
            color: #1e1b4b;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .report-badge-num {
            background: #4338ca;
            color: #ffffff;
            font-size: 10px;
            padding: 2px 7px;
            border-radius: 4px;
            font-weight: 700;
        }
        .report-subtitle {
            font-size: 11.5px;
            font-weight: 600;
            color: #475569;
            margin-top: 2px;
        }
        .report-info-scope {
            font-size: 10.5px;
            color: #0369a1;
            font-weight: 500;
            margin-top: 3px;
        }

        .report-stats-grid {
            display: flex;
            align-items: center;
            gap: 16px;
            font-size: 10px;
            color: #475569;
        }
        .stat-item {
            text-align: right;
        }
        .stat-value {
            font-size: 13px;
            font-weight: 800;
            color: #0f172a;
            display: block;
        }

        /* Table Styling */
        .table-container {
            width: 100%;
            overflow-x: auto;
        }
        table.report-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 10px;
            margin-top: 6px;
        }
        table.report-table th {
            background: #f1f5f9;
            color: #334155;
            font-weight: 700;
            font-size: 9.5px;
            text-transform: uppercase;
            padding: 6px 7px;
            border: 1px solid #cbd5e1;
            text-align: left;
            white-space: nowrap;
        }
        table.report-table td {
            padding: 5px 7px;
            border: 1px solid #cbd5e1;
            color: #1e293b;
            vertical-align: middle;
        }
        table.report-table tr:nth-child(even) {
            background: #f8fafc;
        }
        table.report-table tr:hover {
            background: #f1f5f9;
        }

        /* Specific Status Styling & Badges */
        .pill {
            display: inline-block;
            padding: 1.5px 5px;
            border-radius: 4px;
            font-size: 9px;
            font-weight: 700;
            text-align: center;
            white-space: nowrap;
        }
        .pill-present { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
        .pill-absent  { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
        .pill-late    { background: #fef3c7; color: #92400e; border: 1px solid #fde68a; }
        .pill-leave   { background: #e0e7ff; color: #3730a3; border: 1px solid #c7d2fe; }
        .pill-holiday { background: #f3e8ff; color: #6b21a8; border: 1px solid #e9d5ff; }
        .pill-off     { background: #f1f5f9; color: #475569; border: 1px solid #e2e8f0; }
        .pill-half    { background: #ffedd5; color: #9a3412; border: 1px solid #fed7aa; }
        .pill-alert   { background: #ffe4e6; color: #be123c; border: 1px solid #fecdd3; }
        .pill-success { background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0; }

        /* Hours / Numeric formatting */
        .num-val {
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
            font-weight: 600;
        }

        /* Statutory Signature Block */
        .sign-off-block {
            margin-top: 36px;
            padding-top: 10px;
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            page-break-inside: avoid;
        }
        .sign-col {
            width: 28%;
            text-align: center;
        }
        .sign-line {
            border-top: 1px dashed #64748b;
            margin-bottom: 5px;
        }
        .sign-title {
            font-weight: 700;
            font-size: 10.5px;
            color: #1e293b;
        }
        .sign-sub {
            font-size: 9px;
            color: #64748b;
        }

        /* Document Footer */
        .report-footer {
            margin-top: 24px;
            border-top: 1px solid #cbd5e1;
            padding-top: 6px;
            display: flex;
            justify-content: space-between;
            font-size: 9px;
            color: #64748b;
        }

        /* Print Media Overrides */
        @media print {
            .no-print {
                display: none !important;
            }
            body {
                padding: 0;
                margin: 0;
            }
            .action-bar, .no-print {
                display: none !important;
            }
            table.report-table {
                font-size: 8.5px;
            }
            table.report-table th, table.report-table td {
                padding: 3.5px 5px;
            }
            tr {
                page-break-inside: avoid;
            }
            thead {
                display: table-header-group;
            }
        }
    </style>
</head>
<body>

    <!-- Non-printable Top Action Bar with Print Controls -->
    <div class="action-bar no-print">
        <div class="action-bar-left">
            <strong><?= esc($spec['category'] ?? 'Enterprise Reporting Engine') ?></strong>
            <span style="opacity: 0.6;">|</span>
            <span>Report #<?= esc($spec['number'] ?? '—') ?>: <?= esc($spec['title']) ?></span>
            <span style="background: rgba(255,255,255,0.15); padding: 2px 6px; border-radius: 4px; font-size: 10px;">
                <?= esc($orientation) ?> layout
            </span>
        </div>
        <div style="display: flex; align-items: center; gap: 8px;">
            <button type="button" onclick="toggleOrientation()" class="action-bar-btn btn-secondary">
                Toggle Orientation
            </button>
            <button type="button" id="btnDownloadPdf" onclick="downloadPdfReport()" class="action-bar-btn" style="background: #4f46e5; border-color: #6366f1; font-weight: 700;">
                ⬇ Download PDF
            </button>
            <button type="button" onclick="window.print()" class="action-bar-btn btn-secondary" title="Save as PDF via standard browser print engine">
                🖨 Print / Save as PDF
            </button>
            <button type="button" onclick="window.close()" class="action-bar-btn btn-secondary">
                Close
            </button>
        </div>
    </div>

    <!-- Printable Report Document Container -->
    <div id="reportDocument" class="report-document" style="background: #ffffff;">

    <!-- Official Corporate Document Header -->
    <div class="report-header">
        <div class="company-brand">
            <?php if (!empty($company['logo'])): ?>
                <img src="<?= esc($company['logo']) ?>" alt="Company Logo" class="company-logo">
            <?php else: ?>
                <div class="company-avatar">
                    <?= esc(substr($company['name'] ?? 'HR', 0, 2)) ?>
                </div>
            <?php endif; ?>
            <div>
                <h1 class="company-name"><?= esc($company['name'] ?? 'HRMS Enterprise Systems') ?></h1>
                <div class="company-meta">
                    <?= esc($company['address'] ?? 'Corporate Headquarters') ?>
                    <?php if (!empty($company['phone'])): ?> | Tel: <?= esc($company['phone']) ?><?php endif; ?>
                    <?php if (!empty($company['email'])): ?> | Email: <?= esc($company['email']) ?><?php endif; ?>
                </div>
                <div class="company-meta" style="font-weight: 600; color: #4338ca; margin-top: 2px;">
                    Department of Human Resources & Labor Compliance Register
                </div>
            </div>
        </div>

        <div style="text-align: right; min-width: 180px;">
            <div style="font-size: 9px; color: #64748b;">Printed On: <strong style="color: #0f172a;"><?= esc($generatedAt ?? date('d M Y, h:i A')) ?></strong></div>
            <div style="font-size: 9px; color: #64748b; margin-top: 1px;">Generated By: <strong style="color: #0f172a;"><?= esc($generatedBy ?? 'Authorized Officer') ?></strong></div>
            <div style="margin-top: 5px;">
                <span style="font-size: 9px; font-weight: 800; color: #0284c7; background: #e0f2fe; border: 1px solid #bae6fd; padding: 2px 7px; border-radius: 4px; text-transform: uppercase;">
                    Official Audit Copy
                </span>
            </div>
        </div>
    </div>

    <!-- Report Title Card with Requirement Spec Info -->
    <div class="report-title-card">
        <div>
            <div class="report-title-text">
                <?php if (!empty($spec['number'])): ?>
                    <span class="report-badge-num">Report #<?= esc($spec['number']) ?></span>
                <?php endif; ?>
                <span><?= esc($spec['title']) ?></span>
            </div>
            <div class="report-subtitle">
                <?= esc($spec['subtitle']) ?>
            </div>
            <div class="report-info-scope">
                <strong>Included Data Fields:</strong> <?= esc($spec['info_en']) ?>
            </div>
        </div>

        <div class="report-stats-grid">
            <div class="stat-item">
                <span class="stat-value"><?= esc($from ?? date('Y-m-01')) ?> &rarr; <?= esc($to ?? date('Y-m-d')) ?></span>
                <span>Audit Period</span>
            </div>
            <div class="stat-item" style="border-left: 1px solid #cbd5e1; padding-left: 12px;">
                <span class="stat-value" style="color: #4338ca;"><?= count($reportData ?? []) ?></span>
                <span>Total Records</span>
            </div>
            <div class="stat-item" style="border-left: 1px solid #cbd5e1; padding-left: 12px;">
                <span class="stat-value"><?= esc($spec['category']) ?></span>
                <span>Category</span>
            </div>
        </div>
    </div>

    <!-- Main Data Table -->
    <div class="table-container">
        <table class="report-table">
            <thead>
                <tr>
                    <th style="width: 30px; text-align: center;">#</th>
                    <?php if (!empty($reportData)): ?>
                        <?php foreach (array_keys($reportData[0]) as $col): ?>
                            <?php if ($col === 'id' || $col === 'password_hash') continue; ?>
                            <th><?= esc(ucwords(str_replace('_', ' ', $col))) ?></th>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <th>Report Data</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($reportData)): ?>
                    <?php $rowNum = 1; foreach ($reportData as $row): ?>
                        <tr>
                            <td style="text-align: center; color: #64748b; font-weight: 600;"><?= $rowNum++ ?></td>
                            <?php foreach ($row as $colKey => $val): ?>
                                <?php if ($colKey === 'id' || $colKey === 'password_hash') continue; ?>
                                <?php
                                $valStr = is_array($val) ? json_encode($val) : (string)$val;
                                $lowerVal = strtolower(trim($valStr));
                                $lowerCol = strtolower($colKey);
                                ?>
                                <td>
                                    <?php if ($lowerVal === 'approved'): ?>
                                        <span class="pill pill-present" style="background:#dcfce7;color:#166534;font-weight:600;padding:2px 6px;">Approved</span>
                                    <?php elseif ($lowerVal === 'pending'): ?>
                                        <span class="pill pill-half" style="background:#fef3c7;color:#92400e;font-weight:600;padding:2px 6px;">Pending</span>
                                    <?php elseif ($lowerVal === 'rejected'): ?>
                                        <span class="pill pill-absent" style="background:#fee2e2;color:#991b1b;font-weight:600;padding:2px 6px;">Rejected</span>
                                    <?php elseif ($lowerVal === 'cancelled'): ?>
                                        <span class="pill pill-late" style="background:#f1f5f9;color:#475569;font-weight:600;padding:2px 6px;">Cancelled</span>
                                    <?php elseif ($lowerVal === 'p' || $lowerVal === 'present'): ?>
                                        <span class="pill pill-present">P</span>
                                    <?php elseif ($lowerVal === 'a' || $lowerVal === 'absent'): ?>
                                        <span class="pill pill-absent">A</span>
                                    <?php elseif ($lowerVal === 'l' || str_contains($lowerVal, 'leave')): ?>
                                        <span class="pill pill-leave">L</span>
                                    <?php elseif ($lowerVal === 'w' || $lowerVal === 'off' || str_contains($lowerVal, 'weekly')): ?>
                                        <span class="pill pill-off">W</span>
                                    <?php elseif ($lowerVal === 'h' || str_contains($lowerVal, 'holiday')): ?>
                                        <span class="pill pill-holiday">H</span>
                                    <?php elseif ($lowerVal === 'hd' || str_contains($lowerVal, 'half')): ?>
                                        <span class="pill pill-half">HD</span>
                                    <?php elseif ($lowerVal === 'late' || str_contains($lowerVal, 'delay')): ?>
                                        <span class="pill pill-late">Late</span>
                                    <?php elseif (str_contains($lowerVal, 'violation') || str_contains($lowerVal, 'critical')): ?>
                                        <span class="pill pill-alert"><?= esc($valStr) ?></span>
                                    <?php elseif (str_contains($lowerVal, 'compliant') || str_contains($lowerVal, 'success')): ?>
                                        <span class="pill pill-success"><?= esc($valStr) ?></span>
                                    <?php elseif (is_numeric($valStr) && (str_contains($lowerCol, 'hour') || str_contains($lowerCol, 'rate') || str_contains($lowerCol, 'percent') || str_contains($lowerCol, 'total'))): ?>
                                        <span class="num-val"><?= esc($valStr) ?></span>
                                    <?php else: ?>
                                        <?= esc($valStr !== '' ? $valStr : '—') ?>
                                    <?php endif; ?>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="<?= max(1, $colCount + 1) ?>" style="text-align: center; padding: 25px; color: #94a3b8; font-style: italic;">
                            No matching attendance records found for the selected parameters and date scope.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Statutory HR Compliance Sign-off Block -->
    <div class="sign-off-block">
        <div class="sign-col">
            <div class="sign-line"></div>
            <div class="sign-title">Prepared By</div>
            <div class="sign-sub"><?= esc($generatedBy ?? 'HR Officer') ?> / Attendance Operator</div>
        </div>
        <div class="sign-col">
            <div class="sign-line"></div>
            <div class="sign-title">Verified By</div>
            <div class="sign-sub">Head of Department / Operations</div>
        </div>
        <div class="sign-col">
            <div class="sign-line"></div>
            <div class="sign-title">Approved & Authorized By</div>
            <div class="sign-sub">Director HR & Administration / Managing Director</div>
        </div>
    </div>

    <!-- Document Footer -->
    <div class="report-footer">
        <div>
            Enterprise HRMS Reporting & Labor Law Compliance Engine | Certified Snapshot
        </div>
        <div>
            Document Ref: HR-REP-<?= strtoupper(substr($cleanType, 0, 4)) ?>-<?= date('YmdHis') ?> | Page 1 of 1
        </div>
    </div>
    </div><!-- /#reportDocument -->

    <script>
        function toggleOrientation() {
            var styles = document.getElementsByTagName('style');
            for (var i = 0; i < styles.length; i++) {
                if (styles[i].innerHTML.indexOf('@page') !== -1) {
                    if (styles[i].innerHTML.indexOf('landscape') !== -1) {
                        styles[i].innerHTML = styles[i].innerHTML.replace('landscape', 'portrait');
                    } else {
                        styles[i].innerHTML = styles[i].innerHTML.replace('portrait', 'landscape');
                    }
                    break;
                }
            }
        }

        function downloadPdfReport() {
            var btn = document.getElementById('btnDownloadPdf');
            var originalText = btn ? btn.innerHTML : '⬇ Download PDF';
            if (btn) {
                btn.disabled = true;
                btn.innerHTML = '⏳ Generating PDF...';
            }

            var reportEl = document.getElementById('reportDocument') || document.body;
            var reportTitle = <?= json_encode(preg_replace('/[^a-zA-Z0-9_\-]/', '_', strtolower($spec['title'] ?? 'report'))) ?>;
            var cleanFilename = reportTitle + '_' + '<?= date('Ymd_His') ?>' + '.pdf';
            var currentOrientation = '<?= $orientation === 'landscape' ? 'landscape' : 'portrait' ?>';

            // Detect active page orientation
            var styles = document.getElementsByTagName('style');
            for (var i = 0; i < styles.length; i++) {
                if (styles[i].innerHTML.indexOf('@page') !== -1) {
                    if (styles[i].innerHTML.indexOf('landscape') !== -1) {
                        currentOrientation = 'landscape';
                    } else if (styles[i].innerHTML.indexOf('portrait') !== -1) {
                        currentOrientation = 'portrait';
                    }
                    break;
                }
            }

            var opt = {
                margin: [6, 6, 8, 6],
                filename: cleanFilename,
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { 
                    scale: 1.5, 
                    useCORS: true, 
                    allowTaint: true, 
                    logging: false,
                    backgroundColor: '#ffffff'
                },
                jsPDF: { unit: 'mm', format: 'a4', orientation: currentOrientation },
                pagebreak: { mode: ['css', 'legacy'] }
            };

            function finish(msg) {
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = msg || originalText;
                    if (msg) setTimeout(function() { btn.innerHTML = originalText; }, 2500);
                }
            }

            var watchdog = setTimeout(function() {
                if (btn && btn.disabled) {
                    console.warn('PDF generation watchdog triggered; invoking print engine');
                    finish('🖨 Opening Print / PDF...');
                    window.print();
                }
            }, 8000);

            if (typeof window.html2pdf !== 'undefined') {
                try {
                    window.html2pdf().set(opt).from(reportEl).save().then(function() {
                        clearTimeout(watchdog);
                        finish('✓ Downloaded!');
                    }).catch(function(err) {
                        clearTimeout(watchdog);
                        console.warn('html2pdf generation warning, falling back to print dialog:', err);
                        finish('🖨 Opening Print...');
                        window.print();
                    });
                } catch (e) {
                    clearTimeout(watchdog);
                    console.warn('html2pdf exception, falling back to print dialog:', e);
                    finish('🖨 Opening Print...');
                    window.print();
                }
            } else {
                // Dynamically fetch fallback script and execute
                var fallbackScript = document.createElement('script');
                fallbackScript.src = 'https://cdn.jsdelivr.net/npm/html2pdf.js@0.10.1/dist/html2pdf.bundle.min.js';
                fallbackScript.crossOrigin = 'anonymous';
                fallbackScript.onload = function() {
                    if (typeof window.html2pdf !== 'undefined') {
                        try {
                            window.html2pdf().set(opt).from(reportEl).save().then(function() {
                                clearTimeout(watchdog);
                                finish('✓ Downloaded!');
                            }).catch(function() {
                                clearTimeout(watchdog);
                                finish();
                                window.print();
                            });
                            return;
                        } catch (err) {}
                    }
                    clearTimeout(watchdog);
                    finish();
                    window.print();
                };
                fallbackScript.onerror = function() {
                    clearTimeout(watchdog);
                    finish();
                    window.print();
                };
                document.head.appendChild(fallbackScript);
            }
        }

        // Auto-download with polling for library readiness
        (function() {
            var shouldAutoDownload = <?= !empty($autoDownload) ? 'true' : 'false' ?>;
            if (!shouldAutoDownload) {
                var params = new URLSearchParams(window.location.search);
                shouldAutoDownload = (params.get('download') === 'pdf' || params.get('download') === '1' || params.get('auto_download') === '1');
            }

            if (shouldAutoDownload) {
                var attempts = 0;
                var checkInterval = setInterval(function() {
                    attempts++;
                    if (typeof window.html2pdf !== 'undefined' || attempts >= 25) {
                        clearInterval(checkInterval);
                        setTimeout(downloadPdfReport, 250);
                    }
                }, 100);
            }
        })();
    </script>
</body>
</html>
