<?php
/**
 * Report Header Partial - Strictly Adheres to Independent Branding & Optional Image Rules
 * 
 * 1. REPORT HEADER IMAGE is completely independent from Application Logo and Report Footer.
 * 2. Layouts supported: 'center', 'left', 'right', 'full'.
 * 3. Zero-space fallback: If no header image is configured, the header image container collapses with 0px reserved whitespace.
 */

if (!isset($company)) {
    $compModel = new \App\Models\CompanyModel();
    $currCompId = session()->get('company_id');
    $company = $currCompId ? $compModel->find($currCompId) : $compModel->first();
}

$rawHeaderImg = $reportHeaderImage ?? $company['report_header_image'] ?? $headerImage ?? null;
$headerImgUrl = is_string($rawHeaderImg) ? trim($rawHeaderImg) : '';
$hasHeaderImg = !empty($headerImgUrl) && 
                $headerImgUrl !== 'null' && 
                $headerImgUrl !== 'undefined' && 
                $headerImgUrl !== 'none' &&
                strlen($headerImgUrl) > 5;

$headerLayout = $reportHeaderLayout ?? $company['report_header_layout'] ?? $layout ?? 'center';
$headerText = $reportHeaderText ?? $company['report_header_text'] ?? null;
$title = $reportTitle ?? 'Enterprise Operational Report';
$period = $reportPeriod ?? (date('Y-m-01') . ' to ' . date('Y-m-d'));

$imgJustifyClass = $headerLayout === 'left' ? 'justify-start' : ($headerLayout === 'right' ? 'justify-end' : 'justify-center');
?>

<div class="report-header-wrapper mb-4 pb-3 border-b border-slate-300">
    <!-- [HEADER IMAGE] - Rendered ONLY if configured; 0px reserved when absent -->
    <div class="report-header-image-box mb-3 flex <?= $imgJustifyClass ?> <?= $headerLayout === 'full' ? 'w-full' : '' ?>" style="<?= $hasHeaderImg ? '' : 'display: none;' ?>">
        <?php if ($headerLayout === 'full'): ?>
            <div class="w-full max-h-24 md:max-h-28 overflow-hidden rounded-md border border-slate-200">
                <img src="<?= esc($headerImgUrl) ?>" 
                     alt="Report Header Banner" 
                     class="w-full h-full max-h-24 md:max-h-28 object-cover"
                     onerror="this.closest('.report-header-image-box').style.display='none';" />
            </div>
        <?php else: ?>
            <img src="<?= esc($headerImgUrl) ?>" 
                 alt="Report Header Logo" 
                 class="max-h-16 md:max-h-20 max-w-full object-contain"
                 onerror="this.closest('.report-header-image-box').style.display='none';" />
        <?php endif; ?>
    </div>

    <!-- Organization & Report Meta Banner -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-slate-800 dark:text-slate-200">
        <!-- Organization Identity -->
        <div class="flex items-center gap-3">
            <?php if (!empty($company['logo'])): ?>
                <img src="<?= esc($company['logo']) ?>" alt="Logo" class="w-11 h-11 rounded-lg border border-slate-200 object-contain p-0.5 bg-white shrink-0">
            <?php else: ?>
                <div class="w-11 h-11 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-base shrink-0 shadow-xs">
                    <?= esc(substr($company['name'] ?? 'HR', 0, 2)) ?>
                </div>
            <?php endif; ?>
            <div>
                <h2 class="text-sm md:text-base font-bold text-slate-900 dark:text-white leading-tight">
                    <?= esc($company['name'] ?? 'Corporate HRMS Enterprise') ?>
                </h2>
                <?php if (!empty($headerText)): ?>
                    <p class="text-[11px] font-medium text-indigo-600 dark:text-indigo-400">
                        <?= esc($headerText) ?>
                    </p>
                <?php endif; ?>
                <div class="text-[10.5px] text-slate-500 dark:text-slate-400 flex items-center gap-1.5 flex-wrap">
                    <span><?= esc($company['address'] ?? 'Corporate Headquarters') ?></span>
                    <?php if (!empty($company['phone'])): ?>
                        <span>&bull; Phone: <?= esc($company['phone']) ?></span>
                    <?php endif; ?>
                    <?php if (!empty($company['email'])): ?>
                        <span>&bull; Email: <?= esc($company['email']) ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Report Title & Period Details -->
        <div class="text-left sm:text-right space-y-0.5 shrink-0">
            <span class="inline-block px-2.5 py-1 rounded-md text-[11px] font-bold bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200/60 dark:border-indigo-800/60">
                <?= esc($title) ?>
            </span>
            <div class="text-[10.5px] text-slate-500 font-mono">
                Period: <strong class="text-slate-800 dark:text-slate-200 font-bold"><?= esc($period) ?></strong>
            </div>
            <div class="text-[9.5px] text-slate-400 font-mono">
                Generated: <?= date('d M Y, H:i T') ?> | Official Record
            </div>
        </div>
    </div>
</div>
