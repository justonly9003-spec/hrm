<?php
    $activeGroup = null;
    foreach (($groups ?? []) as $g) {
        if ($g['id'] === ($activeGroupId ?? '')) {
            $activeGroup = $g;
            break;
        }
    }
    if (!$activeGroup && !empty($groups)) {
        $activeGroup = $groups[0];
        $activeGroupId = $activeGroup['id'];
    }

    $colorStyles = [
        'sky' => [
            'chip'     => 'bg-sky-100 text-sky-700 dark:bg-sky-950/80 dark:text-sky-300 border border-sky-200/60 dark:border-sky-800/60',
            'badge'    => 'text-sky-700 dark:text-sky-300 bg-sky-50 dark:bg-sky-950/40 border border-sky-200/60 dark:border-sky-800/60',
            'selected' => 'border-2 border-sky-500 dark:border-sky-400 shadow-sm bg-sky-50/20 dark:bg-sky-950/20',
        ],
        'emerald' => [
            'chip'     => 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800/60',
            'badge'    => 'text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200/60 dark:border-emerald-800/60',
            'selected' => 'border-2 border-emerald-500 dark:border-emerald-400 shadow-sm bg-emerald-50/20 dark:bg-emerald-950/20',
        ],
        'amber' => [
            'chip'     => 'bg-amber-100 text-amber-700 dark:bg-amber-950/80 dark:text-amber-300 border border-amber-200/60 dark:border-amber-800/60',
            'badge'    => 'text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40 border border-amber-200/60 dark:border-amber-800/60',
            'selected' => 'border-2 border-amber-500 dark:border-amber-400 shadow-sm bg-amber-50/20 dark:bg-amber-950/20',
        ],
        'violet' => [
            'chip'     => 'bg-violet-100 text-violet-700 dark:bg-violet-950/80 dark:text-violet-300 border border-violet-200/60 dark:border-violet-800/60',
            'badge'    => 'text-violet-700 dark:text-violet-300 bg-violet-50 dark:bg-violet-950/40 border border-violet-200/60 dark:border-violet-800/60',
            'selected' => 'border-2 border-violet-500 dark:border-violet-400 shadow-sm bg-violet-50/20 dark:bg-violet-950/20',
        ],
        'orange' => [
            'chip'     => 'bg-orange-100 text-orange-700 dark:bg-orange-950/80 dark:text-orange-300 border border-orange-200/60 dark:border-orange-800/60',
            'badge'    => 'text-orange-700 dark:text-orange-300 bg-orange-50 dark:bg-orange-950/40 border border-orange-200/60 dark:border-orange-800/60',
            'selected' => 'border-2 border-orange-500 dark:border-orange-400 shadow-sm bg-orange-50/20 dark:bg-orange-950/20',
        ],
        'indigo' => [
            'chip'     => 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950/80 dark:text-indigo-300 border border-indigo-200/60 dark:border-indigo-800/60',
            'badge'    => 'text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200/60 dark:border-indigo-800/60',
            'selected' => 'border-2 border-indigo-500 dark:border-indigo-400 shadow-sm bg-indigo-50/20 dark:bg-indigo-950/20',
        ],
        'slate' => [
            'chip'     => 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-600',
            'badge'    => 'text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700',
            'selected' => 'border-2 border-slate-500 dark:border-slate-400 shadow-sm bg-slate-50/40 dark:bg-slate-900/40',
        ],
    ];

    $baseParams = [];
    if (!empty($filters['from'])) $baseParams['from'] = $filters['from'];
    if (!empty($filters['to'])) $baseParams['to'] = $filters['to'];
    if (!empty($filters['branch_id'])) $baseParams['branch_id'] = $filters['branch_id'];
    if (!empty($filters['department_id'])) $baseParams['department_id'] = $filters['department_id'];
    if (!empty($filters['employee_id'])) $baseParams['employee_id'] = $filters['employee_id'];
?>

<div class="space-y-6" x-data="reportsHub()">
    <!-- Print-only Report Header (Follows Optional Image Rule) -->
    <div class="hidden print:block">
        <?= view('reports/partials/report_header', [
            'reportTitle' => strtoupper($type ?? 'OPERATIONAL') . ' AUDIT & REGISTER REPORT',
            'reportPeriod' => ($from ?? date('Y-m-01')) . ' to ' . ($to ?? date('Y-m-d'))
        ]) ?>
    </div>

    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 no-print">
        <div>
            <h1 class="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <i data-lucide="bar-chart-3" class="w-7 h-7 text-indigo-600"></i>
                Enterprise Analytics & Forensic Reports Hub
            </h1>
            <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">Multi-tenant statutory tax registers, loan schedules, overtime reconciliation, and payroll gap analytics.</p>
        </div>
        <div class="flex items-center gap-2 flex-wrap">
            <?php 
                $reportsPermService = new \App\Services\PermissionService();
                $currentRepUid = (string)(session()->get('user_id') ?? '');
                $canRepViewPf = $reportsPermService->hasAccess(null, 'pf', 'view', $currentRepUid) 
                    || $reportsPermService->hasAccess(null, 'payroll', 'view', $currentRepUid)
                    || in_array($reportsPermService->canonicalizeRole(session()->get('role') ?? session()->get('role_code') ?? ''), ['software_app_admin', 'company_admin', 'hr_admin', 'finance', 'auditor'], true);
                if ($canRepViewPf):
            ?>
            <a href="<?= base_url('pf/reports/summary') ?>" class="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-sm text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/60 hover:bg-amber-100 transition-all border border-amber-200 dark:border-amber-800 min-h-[44px]">
                <i data-lucide="piggy-bank" class="w-4 h-4 text-amber-600"></i>
                PF Summary & Statements
            </a>
            <?php endif; ?>
            <a href="<?= base_url('reports/upload') ?>" class="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-sm text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 transition-all border border-indigo-200 dark:border-indigo-800 min-h-[44px]">
                <i data-lucide="upload-cloud" class="w-4 h-4 text-indigo-600"></i>
                Report Upload Hub
            </a>
            <a href="<?= current_url() . '?' . http_build_query(array_merge($_GET, ['export' => 'csv'])) ?>" class="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-sm text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 transition-all shadow-xs min-h-[44px]">
                <i data-lucide="download" class="w-4 h-4 text-slate-500"></i>
                Export to CSV
            </a>
            <?php if (class_exists(\PhpOffice\PhpSpreadsheet\Spreadsheet::class)): ?>
            <a href="<?= current_url() . '?' . http_build_query(array_merge($_GET, ['export' => 'excel'])) ?>" class="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-sm text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 transition-all shadow-xs min-h-[44px]">
                <i data-lucide="sheet" class="w-4 h-4 text-emerald-600"></i>
                Export to Excel
            </a>
            <?php endif; ?>
            <a href="<?= base_url('reports/print-view') . '?' . http_build_query(array_merge($_GET, ['download' => 'pdf'])) ?>" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-sm text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm transition-all min-h-[44px]">
                <i data-lucide="file-text" class="w-4 h-4"></i>
                Export to PDF
            </a>
            <a href="<?= base_url('reports/print-view') . '?' . http_build_query($_GET) ?>" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-sm text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 transition-all shadow-xs min-h-[44px]">
                <i data-lucide="printer" class="w-4 h-4 text-slate-500"></i>
                Print Report
            </a>
        </div>
    </div>

    <!-- Group Cards Grid -->
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-3.5 no-print" role="region" aria-label="Report Categories">
        <?php foreach (($groups ?? []) as $g): ?>
            <?php
                $gColor = $g['color'] ?? 'indigo';
                $style = $colorStyles[$gColor] ?? $colorStyles['indigo'];
                $isSelected = ($g['id'] === ($activeGroupId ?? ''));

                $cardParams = $baseParams;
                $cardParams['group'] = $g['id'];
                if ($g['id'] === 'tx' && !empty($filters['tax_year'])) {
                    $cardParams['tax_year'] = $filters['tax_year'];
                }
                if (in_array($g['id'], ['pr', 'ot', 'ln', 'tx'], true) && !empty($filters['payroll_month'])) {
                    $cardParams['payroll_month'] = $filters['payroll_month'];
                }
                $cardUrl = base_url('reports') . '?' . http_build_query($cardParams);
            ?>
            <a href="<?= $cardUrl ?>"
               @click.prevent="selectGroup('<?= esc($g['id']) ?>')"
               role="button"
               tabindex="0"
               aria-label="<?= esc($g['title']) ?> (<?= count($g['reports']) ?> reports)"
               :aria-pressed="activeGroupId === '<?= esc($g['id']) ?>' ? 'true' : 'false'"
               aria-pressed="<?= $isSelected ? 'true' : 'false' ?>"
               class="group relative min-h-[128px] p-3.5 rounded-2xl flex flex-col justify-between transition-all focus:outline-hidden focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 cursor-pointer <?= $isSelected 
                   ? $style['selected'] 
                   : 'border border-slate-200/80 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-slate-300 dark:hover:border-slate-600 hover:shadow-xs' ?>"
               :class="activeGroupId === '<?= esc($g['id']) ?>' 
                   ? '<?= $style['selected'] ?>' 
                   : 'border border-slate-200/80 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-slate-300 dark:hover:border-slate-600 hover:shadow-xs'">
                <div class="flex items-center justify-between gap-2">
                    <div class="w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs tracking-wider shrink-0 <?= $style['chip'] ?>">
                        <?= esc($g['code']) ?>
                    </div>
                    <span class="text-[11px] font-semibold px-2 py-0.5 rounded-full <?= $style['badge'] ?>">
                        <?= count($g['reports']) ?> reports
                    </span>
                </div>
                <div class="mt-2 min-w-0">
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white truncate">
                        <?= esc($g['title']) ?>
                    </h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5" title="<?= esc($g['description']) ?>">
                        <?= esc($g['description']) ?>
                    </p>
                </div>
            </a>
        <?php endforeach; ?>
    </div>

    <!-- Reports Workspace: Filters Form -->
    <div class="flex flex-col gap-5 items-start no-print">
        <!-- Filters Form -->
        <div class="w-full min-w-0 bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-xs">
            <form id="report_filter_form" method="GET" action="<?= base_url('reports') ?>" class="space-y-4">
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div class="lg:col-span-2">
                        <label for="report_type_select" class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                            Select Report (in <span x-text="activeGroup ? activeGroup.title : '<?= esc($activeGroup['title'] ?? '') ?>'"><?= esc($activeGroup['title'] ?? '') ?></span>)
                        </label>
                        <select name="type" 
                                id="report_type_select" 
                                x-model="activeType"
                                @change="submitReport($event.target.value)"
                                class="w-full px-3.5 py-2 min-h-[44px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm font-medium text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                            <template x-for="r in currentReports" :key="r.type">
                                <option :value="r.type" x-text="r.label" :selected="r.type === activeType"></option>
                            </template>
                            <?php foreach (($activeGroup['reports'] ?? []) as $r): ?>
                                <option value="<?= esc($r['type']) ?>" <?= ($r['type'] === ($activeType ?? '')) ? 'selected' : '' ?> class="server-fallback">
                                    <?= esc($r['label']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label for="payroll_month_input" class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Payroll Month</label>
                        <input type="month" id="payroll_month_input" name="payroll_month" value="<?= esc($filters['payroll_month'] ?? '') ?>" class="w-full px-3.5 py-2 min-h-[44px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
                    </div>

                    <div>
                        <label for="tax_year_select" class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Tax Fiscal Year</label>
                        <select id="tax_year_select" name="tax_year" class="w-full px-3.5 py-2 min-h-[44px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
                            <option value="">Default Fiscal Year</option>
                            <?php
                                $currFY = \App\Services\Tax\TaxCalculator::getFiscalYear();
                                $fys = ['2027-2028', '2026-2027', '2025-2026', '2024-2025', '2023-2024'];
                                foreach ($fys as $fy):
                            ?>
                                <option value="<?= $fy ?>" <?= ($filters['tax_year'] ?? '') === $fy ? 'selected' : '' ?>><?= $fy ?><?= $fy === $currFY ? ' (Current)' : '' ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4 items-end">
                    <div>
                        <label for="from_date_input" class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">From Date</label>
                        <input type="date" id="from_date_input" name="from" value="<?= esc($from ?? date('Y-m-01')) ?>" class="w-full px-3.5 py-2 min-h-[44px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
                    </div>

                    <div>
                        <label for="to_date_input" class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">To Date</label>
                        <input type="date" id="to_date_input" name="to" value="<?= esc($to ?? date('Y-m-d')) ?>" class="w-full px-3.5 py-2 min-h-[44px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
                    </div>

                    <div>
                        <label for="branch_select" class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Branch</label>
                        <select id="branch_select" name="branch_id" class="w-full px-3.5 py-2 min-h-[44px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
                            <option value="">All Branches</option>
                            <?php foreach (($branches ?? []) as $b): ?>
                                <option value="<?= esc($b['id']) ?>" <?= ($filters['branch_id'] ?? '') === $b['id'] ? 'selected' : '' ?>><?= esc($b['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label for="department_select" class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Department</label>
                        <select id="department_select" name="department_id" class="w-full px-3.5 py-2 min-h-[44px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
                            <option value="">All Departments</option>
                            <?php foreach (($departments ?? []) as $d): ?>
                                <option value="<?= esc($d['id']) ?>" <?= ($filters['department_id'] ?? '') === $d['id'] ? 'selected' : '' ?>><?= esc($d['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label for="employee_select" class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Employee</label>
                        <select id="employee_select" name="employee_id" class="w-full px-3.5 py-2 min-h-[44px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
                            <option value="">All Employees</option>
                            <?php foreach (($employees ?? []) as $emp): ?>
                                <option value="<?= esc($emp['id']) ?>" <?= ($filters['employee_id'] ?? '') === $emp['id'] ? 'selected' : '' ?>><?= esc($emp['employee_code']) ?> - <?= esc($emp['first_name'] . ' ' . ($emp['last_name'] ?? '')) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <button type="submit" class="w-full min-h-[44px] px-4 py-2 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2 shadow-xs cursor-pointer focus:outline-hidden focus:ring-2 focus:ring-indigo-500">
                            <i data-lucide="filter" class="w-4 h-4"></i>
                            Filter Report
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script>
        function reportsHub() {
            return {
                groups: <?= json_encode($groups ?? [], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>,
                activeGroupId: '<?= esc($activeGroupId ?? '') ?>',
                activeType: '<?= esc($activeType ?? '') ?>',
                get activeGroup() {
                    return this.groups.find(g => g.id === this.activeGroupId) || this.groups[0] || null;
                },
                get currentReports() {
                    return this.activeGroup ? this.activeGroup.reports : [];
                },
                init() {
                    // Remove static SSR fallback items now that Alpine reactive state is hydrated
                    document.querySelectorAll('.server-fallback').forEach(el => el.remove());
                    if (window.lucide && typeof window.lucide.createIcons === 'function') {
                        window.lucide.createIcons();
                    }
                },
                selectGroup(groupId) {
                    if (this.activeGroupId === groupId) return;
                    this.activeGroupId = groupId;
                    const grp = this.activeGroup;
                    if (grp && grp.reports.length > 0) {
                        this.activeType = grp.reports[0].type;
                    }

                    // Switching group: clear report-specific params if new group/report does not use them
                    const form = document.getElementById('report_filter_form');
                    if (form) {
                        if (groupId !== 'tx') {
                            const taxInput = form.querySelector('select[name="tax_year"]');
                            if (taxInput) taxInput.value = '';
                        }
                        if (!['pr', 'ot', 'ln', 'tx'].includes(groupId)) {
                            const monthInput = form.querySelector('input[name="payroll_month"]');
                            if (monthInput) monthInput.value = '';
                        }
                    }

                    this.$nextTick(() => {
                        if (window.lucide && typeof window.lucide.createIcons === 'function') {
                            window.lucide.createIcons();
                        }
                    });
                },
                submitReport(type) {
                    this.activeType = type;
                    const form = document.getElementById('report_filter_form');
                    if (form) {
                        const typeSelect = form.querySelector('#report_type_select');
                        if (typeSelect) {
                            typeSelect.value = type;
                        }
                        // Clear report-specific params if current report doesn't use them
                        if (this.activeGroupId !== 'tx' && !type.includes('tax')) {
                            const taxInput = form.querySelector('select[name="tax_year"]');
                            if (taxInput) taxInput.value = '';
                        }
                        if (!['pr', 'ot', 'ln', 'tx'].includes(this.activeGroupId) && type !== 'monthly_summary') {
                            const monthInput = form.querySelector('input[name="payroll_month"]');
                            if (monthInput) monthInput.value = '';
                        }
                        form.submit();
                    }
                }
            };
        }
    </script>

    <!-- Data Table -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-xs">
        <div class="p-5 border-b border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
            <h3 class="font-semibold text-slate-900 dark:text-white text-base capitalize flex items-center gap-2">
                <i data-lucide="table" class="w-4 h-4 text-indigo-600"></i>
                <?= esc(str_replace('_', ' ', $type)) ?> Results
            </h3>
            <span class="text-xs font-semibold px-2.5 py-1 rounded-full bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                <?= count($reportData ?? []) ?> Records Found
            </span>
        </div>
        <div class="overflow-x-auto max-h-[650px] overflow-y-auto">
            <?php if (empty($reportData)): ?>
                <div class="py-16 text-center text-slate-400">
                    <i data-lucide="search" class="w-12 h-12 mx-auto text-slate-300 dark:text-slate-600 mb-3"></i>
                    <p class="text-base font-medium text-slate-700 dark:text-slate-300">No records found</p>
                    <p class="text-xs text-slate-400 dark:text-slate-500 mt-1">Try adjusting the filter date range or selecting another report type.</p>
                </div>
            <?php else: ?>
                <table class="w-full text-left border-collapse text-xs">
                    <thead class="sticky top-0 bg-slate-50 dark:bg-slate-900/95 backdrop-blur-xs border-b border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 z-10">
                        <tr>
                            <?php foreach (array_keys($reportData[0]) as $col): ?>
                                <?php if ($col === 'id' || $col === 'password_hash') continue; ?>
                                <th class="py-3 px-4 uppercase font-semibold tracking-wider whitespace-nowrap"><?= esc(str_replace('_', ' ', $col)) ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-700/50">
                        <?php foreach ($reportData as $row): ?>
                            <?php
                                $firstCell = reset($row);
                                $isTotalRow = ($firstCell === 'TOTAL' || $firstCell === 'Grand Total');
                                $rowClass = $isTotalRow 
                                    ? 'bg-slate-100 dark:bg-slate-900/90 font-bold border-t-2 border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white sticky bottom-0 z-10' 
                                    : 'hover:bg-slate-50/60 dark:hover:bg-slate-700/30 transition-colors';
                            ?>
                            <tr class="<?= $rowClass ?>">
                                <?php foreach ($row as $colKey => $cell): ?>
                                    <?php if ($colKey === 'id' || $colKey === 'password_hash') continue; ?>
                                    <td class="py-2.5 px-4 text-slate-700 dark:text-slate-300 whitespace-nowrap <?= $isTotalRow ? 'font-semibold text-slate-900 dark:text-white' : '' ?>">
                                        <?php
                                            $cellStr = (string)$cell;
                                            $isException = str_contains($cellStr, 'EXCEPTION') || str_contains($cellStr, '[MISSING') || str_contains(strtolower($cellStr), 'critical') || str_contains(strtolower($cellStr), 'breach');
                                        ?>
                                        <?php if ($isException): ?>
                                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-bold bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 border border-rose-300 dark:border-rose-800">
                                                <?= esc($cellStr) ?>
                                            </span>
                                        <?php elseif (in_array(strtolower($colKey), ['status', 'payment_status', 'tax_status', 'approval_status', 'compliance_status', 'reconciliation_status', 'lock_state'], true)): ?>
                                            <?php
                                                $valStr = strtolower($cellStr);
                                                $badgeClass = 'bg-slate-100 text-slate-700 border-slate-200';
                                                if (str_contains($valStr, 'approved') || str_contains($valStr, 'paid') || str_contains($valStr, 'compliant') || str_contains($valStr, 'matched') || str_contains($valStr, 'reconciled') || str_contains($valStr, 'locked')) {
                                                    $badgeClass = 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800';
                                                } elseif (str_contains($valStr, 'pending') || str_contains($valStr, 'draft') || str_contains($valStr, 'partial') || str_contains($valStr, 'scheduled')) {
                                                    $badgeClass = 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800';
                                                } elseif (str_contains($valStr, 'rejected') || str_contains($valStr, 'overdue') || str_contains($valStr, 'failed') || str_contains($valStr, 'default')) {
                                                    $badgeClass = 'bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800';
                                                }
                                            ?>
                                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold border <?= $badgeClass ?>">
                                                <?= esc($cellStr) ?>
                                            </span>
                                        <?php elseif (is_numeric($cell) && !in_array($colKey, ['Sl', 'sl', 'Tenure (Months)', 'Months Paid', 'Employees Processed', 'Headcount', 'Installment #'], true)): ?>
                                            <span class="font-mono text-slate-800 dark:text-slate-200"><?= esc($cellStr) ?></span>
                                        <?php else: ?>
                                            <?= is_array($cell) ? json_encode($cell) : esc($cellStr) ?>
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <!-- Print-only Report Footer (Follows Optional Image Rule) -->
    <div class="hidden print:block">
        <?= view('reports/partials/report_footer', [
            'footerText' => 'Official system-generated report from Enterprise HRMS Analytics Hub. Confidential.',
            'generatedDate' => date('Y-m-d H:i:s'),
            'pageNumberText' => 'Page 1 of 1'
        ]) ?>
    </div>
</div>
