<?= view('reports/upload_hub', get_defined_vars()) ?>
