<?php
    $currency = (string)(session()->get('currency_symbol') ?? session()->get('currency_code') ?? 'BDT');
?>
<div class="space-y-6">
    <!-- Header / Banner -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div class="flex items-center gap-3">
            <div class="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900 font-bold flex items-center justify-center shadow-xs">
                <i data-lucide="piggy-bank" class="w-6 h-6"></i>
            </div>
            <div>
                <h1 class="text-xl font-bold text-slate-900 dark:text-white">Provident Fund Statutory Reports & Ledger</h1>
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Authoritative retirement corpus accumulation, employee-wise statements, eligibility census, and ledger reconciliation</p>
            </div>
        </div>
        <div class="flex items-center gap-2">
            <?php if (!empty($isSelfOnly)): ?>
                <a href="<?= base_url('employees/profile/' . ($selectedEmp ?? '')) ?>" class="px-3.5 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:bg-slate-50 transition flex items-center gap-1.5">
                    <i data-lucide="arrow-left" class="w-4 h-4"></i>
                    <span>Back to My Profile</span>
                </a>
            <?php else: ?>
                <a href="<?= base_url('payroll') ?>" class="px-3.5 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:bg-slate-50 transition flex items-center gap-1.5">
                    <i data-lucide="arrow-left" class="w-4 h-4"></i>
                    <span>Back to Payroll</span>
                </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Navigation Tabs -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-2 shadow-xs">
        <div class="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-1">
            <?php if (empty($isSelfOnly)): ?>
            <a href="<?= base_url('pf/reports/summary') ?>" class="px-4 py-2 rounded-xl text-xs font-semibold transition flex items-center gap-2 shrink-0 <?= ($activeTab === 'summary') ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/50' ?>">
                <i data-lucide="users" class="w-4 h-4"></i>
                <span>PF Summary Report</span>
            </a>
            <?php endif; ?>
            <a href="<?= base_url('pf/reports/details') ?>" class="px-4 py-2 rounded-xl text-xs font-semibold transition flex items-center gap-2 shrink-0 <?= ($activeTab === 'details') ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/50' ?>">
                <i data-lucide="receipt" class="w-4 h-4"></i>
                <span><?= !empty($isSelfOnly) ? 'My PF Ledger Statement' : 'PF Details Ledger' ?></span>
            </a>
            <?php if (empty($isSelfOnly)): ?>
            <a href="<?= base_url('pf/reports/eligibility') ?>" class="px-4 py-2 rounded-xl text-xs font-semibold transition flex items-center gap-2 shrink-0 <?= ($activeTab === 'eligibility') ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/50' ?>">
                <i data-lucide="shield-alert" class="w-4 h-4"></i>
                <span>Eligibility & Exceptions</span>
            </a>
            <a href="<?= base_url('pf/reports/reconciliation') ?>" class="px-4 py-2 rounded-xl text-xs font-semibold transition flex items-center gap-2 shrink-0 <?= ($activeTab === 'reconciliation') ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/50' ?>">
                <i data-lucide="scale" class="w-4 h-4"></i>
                <span>Ledger Reconciliation</span>
            </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- TAB 1: SUMMARY REPORT -->
    <?php if ($activeTab === 'summary'): ?>
        <div class="space-y-6">
            <!-- Filter Bar -->
            <form action="<?= base_url('pf/reports/summary') ?>" method="GET" class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-4 shadow-xs">
                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-7 gap-3 text-xs">
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">From Date</label>
                        <input type="date" name="from_date" value="<?= esc($fromDate) ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                    </div>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">To Date</label>
                        <input type="date" name="to_date" value="<?= esc($toDate) ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                    </div>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Department</label>
                        <select name="department_id" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                            <option value="">All Departments</option>
                            <?php foreach ($departments as $d): ?>
                                <option value="<?= esc($d['id']) ?>" <?= ($deptId === $d['id']) ? 'selected' : '' ?>><?= esc($d['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Branch</label>
                        <select name="branch_id" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                            <option value="">All Branches</option>
                            <?php foreach ($branches as $b): ?>
                                <option value="<?= esc($b['id']) ?>" <?= ($branchId === $b['id']) ? 'selected' : '' ?>><?= esc($b['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Eligibility</label>
                        <select name="status" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                            <option value="">All</option>
                            <option value="Eligible" <?= ($statusFilter === 'Eligible') ? 'selected' : '' ?>>Eligible</option>
                            <option value="Not Eligible" <?= ($statusFilter === 'Not Eligible') ? 'selected' : '' ?>>Not Eligible</option>
                            <option value="Exempt" <?= ($statusFilter === 'Exempt') ? 'selected' : '' ?>>Exempt</option>
                        </select>
                    </div>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Ledger Status</label>
                        <select name="entry_status" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                            <option value="all" <?= (($entryStatus ?? 'all') === 'all') ? 'selected' : '' ?>>All (Finalized + Draft)</option>
                            <option value="posted" <?= (($entryStatus ?? '') === 'posted') ? 'selected' : '' ?>>Finalized (Posted)</option>
                            <option value="draft" <?= (($entryStatus ?? '') === 'draft') ? 'selected' : '' ?>>Draft (Unfinalized)</option>
                        </select>
                    </div>
                    <div class="flex items-end gap-2">
                        <button type="submit" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl text-xs shadow-xs transition flex items-center justify-center gap-1.5 flex-1 cursor-pointer">
                            <i data-lucide="filter" class="w-3.5 h-3.5"></i>
                            <span>Filter</span>
                        </button>
                        <a href="<?= base_url('pf/reports/export-summary?' . http_build_query($_GET)) ?>" class="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-xs shadow-xs transition flex items-center justify-center gap-1 cursor-pointer" title="Export CSV">
                            <i data-lucide="download" class="w-3.5 h-3.5"></i>
                            <span>CSV</span>
                        </a>
                    </div>
                </div>
            </form>

            <?php if (!empty($totals['draft_uncommitted']) && $totals['draft_uncommitted'] > 0): ?>
                <div class="p-3.5 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-2xl text-xs text-amber-800 dark:text-amber-200 flex flex-wrap items-center justify-between gap-2 shadow-xs">
                    <div class="flex items-center gap-2.5">
                        <i data-lucide="info" class="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0"></i>
                        <span>This summary includes <strong><?= esc($currency) ?> <?= number_format($totals['draft_uncommitted'], 2) ?></strong> in uncommitted draft payroll contributions. Locking the payroll batch will commit them into permanent posted ledger balances.</span>
                    </div>
                    <span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-200 dark:bg-amber-900 text-amber-900 dark:text-amber-100 uppercase tracking-wider shrink-0">Unfinalized Draft Included</span>
                </div>
            <?php endif; ?>

            <!-- KPI Totals Cards -->
            <div class="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div class="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-xs">
                    <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Opening Total (<?= esc($fromDate) ?>)</span>
                    <span class="text-lg font-bold font-mono text-slate-700 dark:text-slate-300 mt-1 block"><?= esc($currency) ?> <?= number_format($totals['opening_balance'], 2) ?></span>
                </div>
                <div class="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-xs">
                    <span class="text-[10px] font-bold text-indigo-500 uppercase tracking-wider block">Employee Savings</span>
                    <span class="text-lg font-bold font-mono text-indigo-600 dark:text-indigo-400 mt-1 block"><?= esc($currency) ?> <?= number_format($totals['employee_contribution'], 2) ?></span>
                </div>
                <div class="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-xs">
                    <span class="text-[10px] font-bold text-emerald-500 uppercase tracking-wider block">Employer Match</span>
                    <span class="text-lg font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-1 block"><?= esc($currency) ?> <?= number_format($totals['employer_contribution'], 2) ?></span>
                </div>
                <div class="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-xs">
                    <span class="text-[10px] font-bold text-amber-500 uppercase tracking-wider block">Adjustments / Interest</span>
                    <span class="text-lg font-bold font-mono text-amber-600 dark:text-amber-400 mt-1 block"><?= esc($currency) ?> <?= number_format($totals['adjustments_interest'], 2) ?></span>
                </div>
                <div class="p-4 bg-gradient-to-br from-emerald-600 to-teal-700 text-white rounded-2xl shadow-sm">
                    <span class="text-[10px] font-bold text-emerald-100 uppercase tracking-wider block">Closing Total (<?= esc($toDate) ?>)</span>
                    <span class="text-xl font-black font-mono mt-1 block"><?= esc($currency) ?> <?= number_format($totals['closing_balance'], 2) ?></span>
                </div>
            </div>

            <!-- Summary Table -->
            <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-xs">
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse text-xs">
                        <thead>
                            <tr class="bg-slate-50 dark:bg-slate-900/60 border-b border-slate-200/80 dark:border-slate-700 text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                                <th class="p-3.5">Employee</th>
                                <th class="p-3.5">Dept / Branch</th>
                                <th class="p-3.5">Member ID</th>
                                <th class="p-3.5">Status (on <?= esc($toDate) ?>)</th>
                                <th class="p-3.5 text-right">Opening</th>
                                <th class="p-3.5 text-right">Employee</th>
                                <th class="p-3.5 text-right">Employer</th>
                                <th class="p-3.5 text-right">Adj / Int</th>
                                <th class="p-3.5 text-right">Period Net</th>
                                <th class="p-3.5 text-right font-black">Closing Balance</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-slate-700/60">
                            <?php if (empty($reportRows)): ?>
                                <tr>
                                    <td colspan="10" class="p-8 text-center text-slate-400">No Provident Fund employee records matched the filter criteria.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($reportRows as $r): ?>
                                    <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/20 transition">
                                        <td class="p-3.5">
                                            <a href="<?= base_url('employees/profile/' . $r['employee_id'] . '?tab=provident_fund') ?>" class="font-bold text-slate-900 dark:text-white hover:text-indigo-600 transition block">
                                                <?= esc($r['employee_name']) ?>
                                            </a>
                                            <span class="text-[10px] font-mono text-slate-400"><?= esc($r['employee_code']) ?></span>
                                        </td>
                                        <td class="p-3.5">
                                            <div class="text-slate-700 dark:text-slate-300"><?= esc($r['department_name']) ?></div>
                                            <div class="text-[10px] text-slate-400"><?= esc($r['branch_name']) ?></div>
                                        </td>
                                        <td class="p-3.5 font-mono text-slate-600 dark:text-slate-400"><?= esc($r['member_id']) ?></td>
                                        <td class="p-3.5">
                                            <?php if ($r['eligibility_status'] === 'Eligible'): ?>
                                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">Eligible</span>
                                            <?php elseif ($r['eligibility_status'] === 'Exempt'): ?>
                                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300">Exempt</span>
                                            <?php else: ?>
                                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300">Not Eligible</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="p-3.5 text-right font-mono text-slate-600 dark:text-slate-400"><?= esc($currency) ?> <?= number_format($r['opening_balance'], 2) ?></td>
                                        <td class="p-3.5 text-right font-mono text-indigo-600 dark:text-indigo-400 font-semibold"><?= esc($currency) ?> <?= number_format($r['employee_contribution'], 2) ?></td>
                                        <td class="p-3.5 text-right font-mono text-emerald-600 dark:text-emerald-400 font-semibold"><?= esc($currency) ?> <?= number_format($r['employer_contribution'], 2) ?></td>
                                        <td class="p-3.5 text-right font-mono text-amber-600 dark:text-amber-400"><?= esc($currency) ?> <?= number_format($r['adjustments_interest'], 2) ?></td>
                                        <td class="p-3.5 text-right font-mono font-bold text-slate-800 dark:text-slate-200">
                                            <?= esc($currency) ?> <?= number_format($r['period_total'], 2) ?>
                                            <?php if (!empty($r['draft_uncommitted']) && $r['draft_uncommitted'] > 0): ?>
                                                <span class="block text-[9px] font-normal text-amber-600 dark:text-amber-400">(Draft Included)</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="p-3.5 text-right font-mono font-black text-emerald-700 dark:text-emerald-400"><?= esc($currency) ?> <?= number_format($r['closing_balance'], 2) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- TAB 2: DETAILS REPORT (LEDGER) -->
    <?php if ($activeTab === 'details'): ?>
        <div class="space-y-6">
            <form action="<?= base_url('pf/reports/details') ?>" method="GET" class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-4 shadow-xs">
                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3 text-xs">
                    <?php if (empty($isSelfOnly)): ?>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Employee</label>
                        <select name="employee_id" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                            <option value="">All Employees</option>
                            <?php foreach ($employees as $e): ?>
                                <option value="<?= esc($e['id']) ?>" <?= ($selectedEmp === $e['id']) ? 'selected' : '' ?>>
                                    <?= esc($e['employee_code'] ?? '') ?> - <?= esc(trim(($e['first_name'] ?? '') . ' ' . ($e['last_name'] ?? ''))) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php endif; ?>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Year</label>
                        <input type="number" name="year" value="<?= esc($selectedYear ?? date('Y')) ?>" placeholder="e.g. 2026" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                    </div>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Month</label>
                        <select name="month" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                            <option value="">All Months</option>
                            <?php for ($m = 1; $m <= 12; $m++): ?>
                                <option value="<?= $m ?>" <?= ((int)($selectedMonth ?? 0) === $m) ? 'selected' : '' ?>><?= date('F', mktime(0, 0, 0, $m, 10)) ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Status</label>
                        <select name="status" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                            <option value="all" <?= ($selectedStatus === 'all') ? 'selected' : '' ?>>All Entries</option>
                            <option value="posted" <?= ($selectedStatus === 'posted' || empty($selectedStatus)) ? 'selected' : '' ?>>Committed (Posted)</option>
                            <option value="draft" <?= ($selectedStatus === 'draft') ? 'selected' : '' ?>>Draft / Uncommitted</option>
                        </select>
                    </div>
                    <div class="flex items-end gap-2">
                        <button type="submit" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl text-xs shadow-xs transition flex items-center justify-center gap-1.5 flex-1 cursor-pointer">
                            <i data-lucide="filter" class="w-3.5 h-3.5"></i>
                            <span>Filter</span>
                        </button>
                        <a href="<?= base_url('pf/reports/export-details?' . http_build_query($_GET)) ?>" class="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-xs shadow-xs transition flex items-center justify-center gap-1 cursor-pointer" title="Export CSV">
                            <i data-lucide="download" class="w-3.5 h-3.5"></i>
                            <span>CSV</span>
                        </a>
                    </div>
                </div>
            </form>

            <?php
                $hasDraft = false;
                $draftMonths = [];
                if (!empty($records) && is_array($records)) {
                    foreach ($records as $rec) {
                        if (strtolower((string)($rec['status'] ?? '')) === 'draft') {
                            $hasDraft = true;
                            $m = (int)($rec['payroll_month'] ?? 0);
                            $y = (int)($rec['payroll_year'] ?? 0);
                            if ($m > 0 && $y > 0) {
                                $draftMonths["{$y}-{$m}"] = ['month' => $m, 'year' => $y];
                            }
                        }
                    }
                }
            ?>
            <?php if ($hasDraft): ?>
                <div class="p-4 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-amber-900 dark:text-amber-200">
                    <div class="flex items-start gap-2.5">
                        <i data-lucide="alert-circle" class="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5"></i>
                        <div>
                            <span class="font-bold">Unfinalized Draft Contributions (Pending Lock):</span>
                            <p class="text-amber-700 dark:text-amber-300 mt-0.5">
                                Monthly PF contributions remain in <strong>Draft</strong> state until the corresponding monthly Payroll batch is <strong>Locked</strong> or <strong>Marked Paid</strong>. Once locked, running balances commit and status updates to <strong>Posted</strong>.
                            </p>
                        </div>
                    </div>
                    <div class="flex flex-wrap items-center gap-2 shrink-0">
                        <?php foreach ($draftMonths as $dm): ?>
                            <?php if (empty($isSelfOnly)): ?>
                                <form action="<?= base_url('pf/reports/commit-drafts') ?>" method="POST" class="inline" onsubmit="return confirm('Post and finalize all draft Provident Fund contributions for <?= sprintf('%02d/%04d', $dm['month'], $dm['year']) ?>? This will commit and lock their running balances.');">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="month" value="<?= $dm['month'] ?>">
                                    <input type="hidden" name="year" value="<?= $dm['year'] ?>">
                                    <button type="submit" class="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-xs shadow-xs transition flex items-center gap-1.5 cursor-pointer">
                                        <i data-lucide="check-circle" class="w-3.5 h-3.5"></i>
                                        <span>Post Drafts (<?= sprintf('%02d/%04d', $dm['month'], $dm['year']) ?>)</span>
                                    </button>
                                </form>
                            <?php endif; ?>
                            <a href="<?= base_url('payroll?month=' . $dm['month'] . '&year=' . $dm['year']) ?>" class="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-semibold rounded-xl text-xs shadow-xs transition flex items-center gap-1">
                                <span>Lock Payroll Batch</span>
                                <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-xs">
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse text-xs">
                        <thead>
                            <tr class="bg-slate-50 dark:bg-slate-900/60 border-b border-slate-200/80 dark:border-slate-700 text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                                <th class="p-3.5">Date</th>
                                <th class="p-3.5">Ref No</th>
                                <th class="p-3.5">Employee</th>
                                <th class="p-3.5">Period</th>
                                <th class="p-3.5">Type</th>
                                <th class="p-3.5 text-right">Base Salary</th>
                                <th class="p-3.5 text-right">Employee</th>
                                <th class="p-3.5 text-right">Employer</th>
                                <th class="p-3.5 text-right">Total Trans</th>
                                <th class="p-3.5 text-right">Running Balance</th>
                                <th class="p-3.5">Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-slate-700/60">
                            <?php if (empty($records)): ?>
                                <tr>
                                    <td colspan="11" class="p-8 text-center text-slate-400">No PF ledger transactions found for this filter.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($records as $r): ?>
                                    <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/20 transition">
                                        <td class="p-3.5 font-mono text-slate-500"><?= esc($r['transaction_date']) ?></td>
                                        <td class="p-3.5 font-mono text-slate-700 dark:text-slate-300 font-semibold"><?= esc($r['reference_no'] ?? $r['id']) ?></td>
                                        <td class="p-3.5">
                                            <span class="font-bold text-slate-900 dark:text-white"><?= esc(trim(($r['first_name'] ?? '') . ' ' . ($r['last_name'] ?? ''))) ?></span>
                                            <span class="text-[10px] font-mono text-slate-400 block"><?= esc($r['employee_code'] ?? $r['employee_id']) ?></span>
                                        </td>
                                        <td class="p-3.5 font-mono"><?= esc(sprintf('%02d/%04d', $r['payroll_month'] ?? 0, $r['payroll_year'] ?? 0)) ?></td>
                                        <td class="p-3.5">
                                            <span class="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-300">
                                                <?= esc($r['transaction_type']) ?>
                                            </span>
                                        </td>
                                        <td class="p-3.5 text-right font-mono text-slate-600 dark:text-slate-400"><?= esc($currency) ?> <?= number_format((float)($r['pf_base_salary'] ?? 0), 2) ?></td>
                                        <td class="p-3.5 text-right font-mono text-indigo-600 dark:text-indigo-400 font-semibold"><?= esc($currency) ?> <?= number_format((float)$r['employee_contribution'], 2) ?></td>
                                        <td class="p-3.5 text-right font-mono text-emerald-600 dark:text-emerald-400 font-semibold"><?= esc($currency) ?> <?= number_format((float)$r['employer_contribution'], 2) ?></td>
                                        <td class="p-3.5 text-right font-mono font-bold text-slate-900 dark:text-white"><?= esc($currency) ?> <?= number_format((float)$r['total_contribution'], 2) ?></td>
                                        <td class="p-3.5 text-right font-mono">
                                            <?php if (strtolower((string)($r['status'] ?? '')) === 'draft'): ?>
                                                <div class="text-amber-600 dark:text-amber-400 font-semibold" title="Unfinalized draft - running balance commits when payroll batch is locked">
                                                    <?= esc($currency) ?> <?= number_format((float)($r['running_balance'] > 0 ? $r['running_balance'] : ($r['total_contribution'] ?? 0)), 2) ?>
                                                    <span class="text-[9px] font-normal text-amber-500 block uppercase tracking-wider">(Pending Lock)</span>
                                                </div>
                                            <?php else: ?>
                                                <span class="font-black text-emerald-700 dark:text-emerald-400">
                                                    <?= esc($currency) ?> <?= number_format((float)$r['running_balance'], 2) ?>
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="p-3.5">
                                            <?php if ($r['status'] === 'posted'): ?>
                                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">Posted</span>
                                            <?php elseif ($r['status'] === 'draft'): ?>
                                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300">Draft</span>
                                            <?php else: ?>
                                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300"><?= esc($r['status']) ?></span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- TAB 3: ELIGIBILITY & EXCEPTIONS REPORT -->
    <?php if ($activeTab === 'eligibility'): ?>
        <div class="space-y-6">
            <form action="<?= base_url('pf/reports/eligibility') ?>" method="GET" class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-4 shadow-xs">
                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Census Evaluation Date</label>
                        <input type="date" name="eval_date" value="<?= esc($evalDate) ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                    </div>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Status Filter</label>
                        <select name="status" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                            <option value="">All Statuses</option>
                            <option value="Eligible" <?= ($statusFilter === 'Eligible') ? 'selected' : '' ?>>Eligible Only</option>
                            <option value="Not Eligible" <?= ($statusFilter === 'Not Eligible') ? 'selected' : '' ?>>Not Eligible Only</option>
                            <option value="Exempt" <?= ($statusFilter === 'Exempt') ? 'selected' : '' ?>>Exempt Only</option>
                        </select>
                    </div>
                    <div class="flex items-end gap-2 md:col-span-2">
                        <button type="submit" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl text-xs shadow-xs transition flex items-center justify-center gap-1.5 flex-1 cursor-pointer">
                            <i data-lucide="filter" class="w-3.5 h-3.5"></i>
                            <span>Evaluate Census</span>
                        </button>
                        <a href="<?= base_url('pf/reports/export-eligibility?eval_date=' . urlencode($evalDate)) ?>" class="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-xs shadow-xs transition flex items-center justify-center gap-1 cursor-pointer" title="Export CSV">
                            <i data-lucide="download" class="w-3.5 h-3.5"></i>
                            <span>CSV</span>
                        </a>
                    </div>
                </div>
            </form>

            <!-- Exceptions Alert Cards -->
            <?php if (!empty($eligibleWithZeroContrib) || !empty($nonEligibleWithContrib)): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <!-- Exception 1: Eligible with Zero Contributions -->
                    <div class="bg-amber-50 dark:bg-amber-950/40 rounded-2xl border border-amber-200 dark:border-amber-800 p-4 space-y-3">
                        <div class="flex items-center gap-2 text-amber-900 dark:text-amber-200 font-bold text-xs">
                            <i data-lucide="alert-triangle" class="w-4 h-4 text-amber-600 shrink-0"></i>
                            <span>Discrepancy: Eligible Members With Zero Contributions (<?= count($eligibleWithZeroContrib) ?>)</span>
                        </div>
                        <p class="text-[11px] text-amber-800 dark:text-amber-300">
                            Active eligible employees who had $0.00 PF contribution recorded for the evaluated month (due to mid-month pending date or zero basis).
                        </p>
                        <div class="max-h-40 overflow-y-auto space-y-1">
                            <?php foreach ($eligibleWithZeroContrib as $ex): ?>
                                <div class="flex items-center justify-between text-xs bg-white/60 dark:bg-slate-900/60 p-2 rounded-lg">
                                    <span class="font-bold"><?= esc($ex['employee_code']) ?> - <?= esc($ex['employee_name']) ?></span>
                                    <span class="text-[10px] font-mono text-amber-700 dark:text-amber-400">Effective: <?= esc($ex['effective_from']) ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Exception 2: Non-Eligible with Active Contributions -->
                    <div class="bg-rose-50 dark:bg-rose-950/40 rounded-2xl border border-rose-200 dark:border-rose-800 p-4 space-y-3">
                        <div class="flex items-center gap-2 text-rose-900 dark:text-rose-200 font-bold text-xs">
                            <i data-lucide="alert-octagon" class="w-4 h-4 text-rose-600 shrink-0"></i>
                            <span>Anomaly: Non-Eligible/Exempt With Active Deductions (<?= count($nonEligibleWithContrib) ?>)</span>
                        </div>
                        <p class="text-[11px] text-rose-800 dark:text-rose-300">
                            Employees marked Not Eligible or Exempt who have active contributions in this period.
                        </p>
                        <div class="max-h-40 overflow-y-auto space-y-1">
                            <?php if (empty($nonEligibleWithContrib)): ?>
                                <div class="text-[11px] text-emerald-700 dark:text-emerald-300 p-2 bg-emerald-50 dark:bg-emerald-950/40 rounded-lg">No anomalies detected. Integrity verified.</div>
                            <?php else: ?>
                                <?php foreach ($nonEligibleWithContrib as $ex): ?>
                                    <div class="flex items-center justify-between text-xs bg-white/60 dark:bg-slate-900/60 p-2 rounded-lg">
                                        <span class="font-bold text-rose-800 dark:text-rose-300"><?= esc($ex['employee_code']) ?> - <?= esc($ex['employee_name']) ?></span>
                                        <span class="font-mono text-rose-700 font-bold">$<?= number_format($ex['current_month_contrib'], 2) ?></span>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Full Census Table -->
            <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-xs">
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse text-xs">
                        <thead>
                            <tr class="bg-slate-50 dark:bg-slate-900/60 border-b border-slate-200/80 dark:border-slate-700 text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                                <th class="p-3.5">Employee</th>
                                <th class="p-3.5">Department</th>
                                <th class="p-3.5">Status (on <?= esc($evalDate) ?>)</th>
                                <th class="p-3.5">Effective Range</th>
                                <th class="p-3.5">Reason / Justification</th>
                                <th class="p-3.5">PF Member ID</th>
                                <th class="p-3.5 text-right">Period Contrib</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-slate-700/60">
                            <?php foreach ($rows as $r): ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/20 transition">
                                    <td class="p-3.5">
                                        <a href="<?= base_url('employees/profile/' . $r['employee_id'] . '?tab=provident_fund') ?>" class="font-bold text-slate-900 dark:text-white hover:text-indigo-600 transition block">
                                            <?= esc($r['employee_name']) ?>
                                        </a>
                                        <span class="text-[10px] font-mono text-slate-400"><?= esc($r['employee_code']) ?></span>
                                    </td>
                                    <td class="p-3.5 text-slate-700 dark:text-slate-300"><?= esc($r['department_name']) ?></td>
                                    <td class="p-3.5">
                                        <?php if ($r['status'] === 'Eligible'): ?>
                                            <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">Eligible</span>
                                        <?php elseif ($r['status'] === 'Exempt'): ?>
                                            <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300">Exempt</span>
                                        <?php else: ?>
                                            <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300">Not Eligible</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="p-3.5 font-mono text-[11px] text-slate-600 dark:text-slate-400">
                                        <?= esc($r['effective_from']) ?> &rarr; <?= esc($r['effective_to']) ?>
                                    </td>
                                    <td class="p-3.5 text-slate-600 dark:text-slate-400 max-w-xs truncate"><?= esc($r['reason'] ?: '—') ?></td>
                                    <td class="p-3.5 font-mono text-slate-700 dark:text-slate-300"><?= esc($r['member_id']) ?></td>
                                    <td class="p-3.5 text-right font-mono font-bold <?= ($r['current_month_contrib'] > 0) ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400' ?>">
                                        <?= esc($currency) ?> <?= number_format((float)$r['current_month_contrib'], 2) ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- TAB 4: RECONCILIATION REPORT -->
    <?php if ($activeTab === 'reconciliation'): ?>
        <div class="space-y-6">
            <form action="<?= base_url('pf/reports/reconciliation') ?>" method="GET" class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-4 shadow-xs">
                <div class="flex items-center gap-3 text-xs max-w-md">
                    <label class="font-semibold text-slate-700 dark:text-slate-300 shrink-0">Reconciliation Year:</label>
                    <input type="number" name="year" value="<?= esc($selectedYear ?? date('Y')) ?>" class="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white font-mono w-32">
                    <button type="submit" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer">
                        <i data-lucide="refresh-cw" class="w-3.5 h-3.5"></i>
                        <span>Reconcile</span>
                    </button>
                </div>
            </form>

            <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-xs">
                <div class="p-4 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between">
                    <div>
                        <h3 class="font-bold text-slate-900 dark:text-white text-sm">Monthly General Ledger vs Payroll Items Cross-Audit</h3>
                        <p class="text-xs text-slate-500 mt-0.5">Compares approved payroll run PF deductions against committed provident_fund_ledgers postings.</p>
                    </div>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse text-xs">
                        <thead>
                            <tr class="bg-slate-50 dark:bg-slate-900/60 border-b border-slate-200/80 dark:border-slate-700 text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                                <th class="p-3.5">Month</th>
                                <th class="p-3.5 text-right">Payroll Employee PF</th>
                                <th class="p-3.5 text-right">Payroll Employer Match</th>
                                <th class="p-3.5 text-right">Total Payroll PF</th>
                                <th class="p-3.5 text-right">Ledger Employee PF</th>
                                <th class="p-3.5 text-right">Ledger Employer Match</th>
                                <th class="p-3.5 text-right font-bold">Total Ledger PF</th>
                                <th class="p-3.5 text-right">Variance</th>
                                <th class="p-3.5 text-center">Audit Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-slate-700/60">
                            <?php foreach ($monthsReport as $m): ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/20 transition">
                                    <td class="p-3.5 font-bold text-slate-900 dark:text-white"><?= esc($m['month_name']) ?></td>
                                    <td class="p-3.5 text-right font-mono text-slate-600 dark:text-slate-400"><?= esc($currency) ?> <?= number_format($m['payroll_emp_pf'], 2) ?></td>
                                    <td class="p-3.5 text-right font-mono text-slate-600 dark:text-slate-400"><?= esc($currency) ?> <?= number_format($m['payroll_comp_pf'], 2) ?></td>
                                    <td class="p-3.5 text-right font-mono font-bold text-slate-800 dark:text-slate-200"><?= esc($currency) ?> <?= number_format($m['payroll_total'], 2) ?></td>
                                    <td class="p-3.5 text-right font-mono text-indigo-600 dark:text-indigo-400"><?= esc($currency) ?> <?= number_format($m['ledger_emp_pf'], 2) ?></td>
                                    <td class="p-3.5 text-right font-mono text-emerald-600 dark:text-emerald-400"><?= esc($currency) ?> <?= number_format($m['ledger_comp_pf'], 2) ?></td>
                                    <td class="p-3.5 text-right font-mono font-bold text-slate-800 dark:text-slate-200"><?= esc($currency) ?> <?= number_format($m['ledger_total'], 2) ?></td>
                                    <td class="p-3.5 text-right font-mono font-bold <?= ($m['variance'] == 0) ? 'text-slate-400' : 'text-rose-600' ?>">
                                        <?= esc($currency) ?> <?= number_format($m['variance'], 2) ?>
                                    </td>
                                    <td class="p-3.5 text-center">
                                        <?php if ($m['is_balanced']): ?>
                                            <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">
                                                <i data-lucide="check-circle" class="w-3 h-3"></i>
                                                <span>Balanced</span>
                                            </span>
                                        <?php else: ?>
                                            <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300">
                                                <i data-lucide="alert-circle" class="w-3 h-3"></i>
                                                <span>Discrepancy</span>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
