<div class="space-y-6">
    <!-- Hero Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
        <div>
            <div class="flex items-center gap-2.5">
                <div class="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60 flex items-center justify-center shadow-xs">
                    <i data-lucide="upload-cloud" class="w-5 h-5"></i>
                </div>
                <div>
                    <h1 class="text-xl font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
                        Report & Document Upload Center
                    </h1>
                    <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                        Ingest biometric logs, salary spreadsheets, audit archives, and manage official report branding assets.
                    </p>
                </div>
            </div>
        </div>

        <!-- Quick Nav / Action -->
        <div class="flex items-center gap-2 flex-wrap">
            <a href="<?= base_url('reports') ?>" class="px-3.5 py-2 text-xs font-semibold rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition flex items-center gap-1.5 cursor-pointer">
                <i data-lucide="file-spreadsheet" class="w-4 h-4 text-indigo-600"></i>
                <span>Open Report Generator</span>
            </a>
            <a href="<?= base_url('reports/upload?tab=branding') ?>" class="px-3.5 py-2 text-xs font-semibold rounded-xl bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900 text-indigo-700 dark:text-indigo-300 transition flex items-center gap-1.5 cursor-pointer">
                <i data-lucide="image" class="w-4 h-4 text-indigo-600"></i>
                <span>Visual Branding Studio</span>
            </a>
        </div>
    </div>

    <!-- Feedback Alerts -->
    <?php if (!empty($success)): ?>
        <div class="p-4 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 rounded-2xl text-xs flex items-center justify-between gap-3 shadow-xs">
            <div class="flex items-center gap-3">
                <i data-lucide="check-circle-2" class="w-4 h-4 text-emerald-600 shrink-0"></i>
                <span><?= esc($success) ?></span>
            </div>
            <button type="button" onclick="this.parentElement.remove();" class="text-emerald-600 hover:text-emerald-800 dark:hover:text-emerald-300 cursor-pointer">
                <i data-lucide="x" class="w-4 h-4"></i>
            </button>
        </div>
    <?php endif; ?>

    <?php if (!empty($error)): ?>
        <div class="p-4 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200 rounded-2xl text-xs flex items-center justify-between gap-3 shadow-xs">
            <div class="flex items-center gap-3">
                <i data-lucide="alert-circle" class="w-4 h-4 text-rose-600 shrink-0"></i>
                <span><?= esc($error) ?></span>
            </div>
            <button type="button" onclick="this.parentElement.remove();" class="text-rose-600 hover:text-rose-800 dark:hover:text-rose-300 cursor-pointer">
                <i data-lucide="x" class="w-4 h-4"></i>
            </button>
        </div>
    <?php endif; ?>

    <!-- Sub-Navigation Tabs -->
    <div class="flex border-b border-slate-200 dark:border-slate-800 gap-2 overflow-x-auto">
        <a href="<?= base_url('reports/upload?tab=upload') ?>" class="pb-3 px-4 text-xs font-bold transition-all border-b-2 flex items-center gap-2 cursor-pointer whitespace-nowrap <?= $activeSubTab === 'upload' ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white' ?>">
            <i data-lucide="upload-cloud" class="w-4 h-4"></i>
            <span>Upload File / Template</span>
        </a>

        <a href="<?= base_url('reports/upload?tab=repository') ?>" class="pb-3 px-4 text-xs font-bold transition-all border-b-2 flex items-center gap-2 cursor-pointer whitespace-nowrap <?= $activeSubTab === 'repository' ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white' ?>">
            <i data-lucide="folder-open" class="w-4 h-4"></i>
            <span>Document Repository</span>
            <span class="px-1.5 py-0.5 rounded-full text-[10px] bg-indigo-50 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-400 font-mono font-bold">
                <?= count($documents) ?>
            </span>
        </a>

        <a href="<?= base_url('reports/upload?tab=branding') ?>" class="pb-3 px-4 text-xs font-bold transition-all border-b-2 flex items-center gap-2 cursor-pointer whitespace-nowrap <?= $activeSubTab === 'branding' ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white' ?>">
            <i data-lucide="image" class="w-4 h-4"></i>
            <span>Report Logo & Branding</span>
        </a>

        <a href="<?= base_url('reports/upload?tab=presets') ?>" class="pb-3 px-4 text-xs font-bold transition-all border-b-2 flex items-center gap-2 cursor-pointer whitespace-nowrap <?= $activeSubTab === 'presets' ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white' ?>">
            <i data-lucide="sparkles" class="w-4 h-4"></i>
            <span>Standard Presets & Samples</span>
        </a>
    </div>

    <!-- TAB 1: UPLOAD FILES & TEMPLATES -->
    <?php if ($activeSubTab === 'upload'): ?>
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Main Upload Zone (2 cols) -->
            <div class="lg:col-span-2 space-y-6">
                <div class="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
                    <h2 class="text-sm font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                        <i data-lucide="upload-cloud" class="w-4 h-4 text-indigo-600"></i>
                        <span>Upload New Report, Template, or Branding Asset</span>
                    </h2>

                    <form action="<?= base_url('reports/upload') ?>" method="post" enctype="multipart/form-data" class="space-y-4" id="reportUploadForm">
                        <?= csrf_field() ?>

                        <!-- Client-side Validation Alert Box -->
                        <div id="uploadErrorFeedback" class="hidden p-3.5 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200 rounded-xl text-xs font-semibold flex items-center gap-2.5">
                            <i data-lucide="alert-triangle" class="w-4 h-4 text-rose-600 shrink-0"></i>
                            <span id="uploadErrorFeedbackText">Please choose or drag-and-drop a file to upload.</span>
                        </div>

                        <!-- Drag and Drop Zone -->
                        <div id="dropZone" 
                             class="border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all flex flex-col items-center justify-center border-slate-300 dark:border-slate-700 hover:border-indigo-500 hover:bg-indigo-50/20 bg-slate-50/50 dark:bg-slate-800/30">
                            <input id="reportFileInput" type="file" name="report_file" accept=".csv,.xlsx,.xls,.pdf,.png,.jpg,.jpeg,.json,.docx,.zip" class="hidden" />

                            <div class="w-12 h-12 rounded-2xl bg-indigo-100 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mb-3 shadow-xs">
                                <i data-lucide="upload-cloud" class="w-6 h-6"></i>
                            </div>

                            <div id="dropZonePlaceholder" class="space-y-1">
                                <p class="text-sm font-bold text-slate-800 dark:text-slate-200">
                                    Drag and drop your report or document here, or <span class="text-indigo-600 dark:text-indigo-400 underline font-bold">browse</span>
                                </p>
                                <p class="text-xs text-slate-400">
                                    Supports CSV, XLSX, PDF, PNG/JPG Branding Logos, DOCX, JSON (Max: 25 MB)
                                </p>
                            </div>

                            <div id="dropZoneFileInfo" class="space-y-1 hidden">
                                <p id="selectedFileName" class="text-sm font-bold text-slate-900 dark:text-white"></p>
                                <p id="selectedFileSize" class="text-xs text-emerald-600 dark:text-emerald-400 font-semibold"></p>
                                <p class="text-[11px] text-slate-400 mt-2">Click or drag another file to replace</p>
                            </div>
                        </div>

                        <!-- Image Preview (Hidden by default) -->
                        <div id="imagePreviewBox" class="p-3.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700 items-center gap-3 hidden">
                            <img id="imagePreviewElement" src="" alt="Upload Preview" class="w-16 h-16 object-contain rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-1 shrink-0" />
                            <div>
                                <p class="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                                    <i data-lucide="check" class="w-3.5 h-3.5 text-emerald-600"></i>
                                    <span>Image / Logo Asset Detected</span>
                                </p>
                                <p class="text-[11px] text-slate-500 mt-0.5">This image will be stored as high-resolution asset and can be applied as your Company Report Header Logo.</p>
                            </div>
                        </div>

                        <!-- CSV Stream Sample Box (Hidden by default) -->
                        <div id="csvPreviewBox" class="p-4 bg-slate-900 text-slate-100 rounded-xl border border-slate-800 font-mono text-[11px] hidden space-y-2">
                            <div class="flex items-center justify-between pb-2 border-b border-slate-800 text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                                <span class="flex items-center gap-1.5 text-indigo-400">
                                    <i data-lucide="file-spreadsheet" class="w-3.5 h-3.5"></i>
                                    <span>CSV Stream Header Sample Preview</span>
                                </span>
                                <span id="csvRowCountBadge" class="text-emerald-400"></span>
                            </div>
                            <pre id="csvPreviewContent" class="overflow-x-auto text-[10.5px] leading-relaxed text-slate-300"></pre>
                        </div>

                        <!-- Form Controls -->
                        <div>
                            <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                                Document Title / Label <span class="text-slate-400 font-normal">(Optional, defaults to file name)</span>
                            </label>
                            <input type="text" name="name" id="docNameInput" placeholder="e.g. October 2026 Biometric Raw Logs" class="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2.5 text-slate-900 dark:text-white placeholder-slate-400 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden" />
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                                    Document Category
                                </label>
                                <select id="categorySelect" name="category" class="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2.5 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden">
                                    <option value="payroll">Payroll & Salary Sheets</option>
                                    <option value="attendance">Biometric Attendance Logs</option>
                                    <option value="tax">Tax & Statutory Certificates</option>
                                    <option value="audit">Audit & Compliance Reports</option>
                                    <option value="branding">Company Logo & Report Headers</option>
                                    <option value="template">Standard Report Template</option>
                                    <option value="general">General Documentation</option>
                                </select>
                            </div>

                            <div>
                                <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                                    Uploaded By
                                </label>
                                <input type="text" disabled value="<?= esc($currentUser['name'] ?? $currentUser['username'] ?? 'Administrator') ?>" class="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800/60 px-3.5 py-2.5 text-slate-500 dark:text-slate-400 cursor-not-allowed" />
                            </div>
                        </div>

                        <div>
                            <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                                Description & Audit Reference
                            </label>
                            <textarea name="description" rows="2" placeholder="Enter audit notes, ingestion purpose, or billing period..." class="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2 text-slate-900 dark:text-white placeholder-slate-400 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"></textarea>
                        </div>

                        <div class="flex items-center justify-end gap-3 pt-2">
                            <button type="button" id="resetUploadBtn" class="px-4 py-2.5 text-xs font-semibold text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white transition cursor-pointer">
                                Clear
                            </button>

                            <button type="submit" id="submitUploadBtn" class="px-5 py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs shadow-indigo-600/20 flex items-center gap-2 cursor-pointer transition">
                                <i data-lucide="check" class="w-4 h-4"></i>
                                <span>Confirm & Ingest File</span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Right Sidebar: Rules & Guidelines (1 col) -->
            <div class="space-y-6">
                <div class="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
                    <h3 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3 flex items-center gap-2">
                        <i data-lucide="shield-check" class="w-4 h-4 text-indigo-600"></i>
                        <span>Report Branding & Format Rules</span>
                    </h3>

                    <div class="space-y-3 text-xs text-slate-600 dark:text-slate-300">
                        <div class="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                            <p class="font-bold text-slate-900 dark:text-white">Optional Image Rule Enforced</p>
                            <p class="text-[11px] text-slate-500 mt-1">
                                When you upload an official company logo, it renders in official printable reports. If no logo is uploaded or an image is missing, the report automatically collapses with <strong>zero reserved vertical space</strong>.
                            </p>
                        </div>

                        <div class="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                            <p class="font-bold text-slate-900 dark:text-white">Recommended Dimensions</p>
                            <ul class="text-[11px] text-slate-500 mt-1 space-y-1 list-disc list-inside">
                                <li>Report Header Logo: 240 × 80 px (PNG/SVG)</li>
                                <li>Sidebar Brand Icon: 64 × 64 px (Square PNG)</li>
                                <li>Report Footer Graphic: 400 × 40 px</li>
                            </ul>
                        </div>

                        <div class="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                            <p class="font-bold text-slate-900 dark:text-white">Biometric Log Standard</p>
                            <p class="text-[11px] text-slate-500 mt-1">
                                Accepts ZKTeco, BioTime, and ZKFinger SDK punch format CSVs with headers: <code class="font-mono text-[10px] bg-slate-200 dark:bg-slate-700 px-1 rounded">employee_code, datetime, punch_state</code>.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- TAB 2: DOCUMENT REPOSITORY -->
    <?php if ($activeSubTab === 'repository'): ?>
        <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden">
            <!-- Filters Bar -->
            <form action="<?= base_url('reports/upload') ?>" method="get" class="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/50 dark:bg-slate-950/30">
                <input type="hidden" name="tab" value="repository" />

                <div class="flex items-center gap-2 flex-1 max-w-md">
                    <div class="relative flex-1">
                        <i data-lucide="search" class="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
                        <input type="text" name="q" value="<?= esc($search ?? '') ?>" placeholder="Search by file name, author, or description..." class="w-full text-xs pl-9 pr-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden" />
                    </div>
                    <button type="submit" class="px-3 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 rounded-xl transition cursor-pointer">
                        Search
                    </button>
                </div>

                <div class="flex items-center gap-2 flex-wrap">
                    <select name="category" onchange="this.form.submit()" class="text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden">
                        <option value="all" <?= ($filterCategory === 'all') ? 'selected' : '' ?>>All Categories</option>
                        <option value="payroll" <?= ($filterCategory === 'payroll') ? 'selected' : '' ?>>Payroll Sheets</option>
                        <option value="attendance" <?= ($filterCategory === 'attendance') ? 'selected' : '' ?>>Biometric Attendance</option>
                        <option value="tax" <?= ($filterCategory === 'tax') ? 'selected' : '' ?>>Tax & Compliance</option>
                        <option value="audit" <?= ($filterCategory === 'audit') ? 'selected' : '' ?>>Audit Records</option>
                        <option value="branding" <?= ($filterCategory === 'branding') ? 'selected' : '' ?>>Branding & Logos</option>
                        <option value="template" <?= ($filterCategory === 'template') ? 'selected' : '' ?>>Standard Templates</option>
                    </select>

                    <a href="<?= base_url('reports/upload?tab=upload') ?>" class="px-3.5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-xs">
                        <i data-lucide="upload-cloud" class="w-3.5 h-3.5"></i>
                        <span>Upload New</span>
                    </a>
                </div>
            </form>

            <!-- Data Table -->
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs border-collapse">
                    <thead>
                        <tr class="border-b border-slate-200 dark:border-slate-800 bg-slate-50/75 dark:bg-slate-950/50 text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                            <th class="py-3 px-4">Document / File Name</th>
                            <th class="py-3 px-4">Category</th>
                            <th class="py-3 px-4">Size</th>
                            <th class="py-3 px-4">Uploaded By & Date</th>
                            <th class="py-3 px-4">Status</th>
                            <th class="py-3 px-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-800/60">
                        <?php if (empty($documents)): ?>
                            <tr>
                                <td colspan="6" class="py-8 text-center text-slate-400">
                                    No documents found matching your filter criteria.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($documents as $doc): ?>
                                <tr class="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition">
                                    <td class="py-3 px-4">
                                        <div class="flex items-center gap-3 cursor-pointer" onclick="openInspectorModal('<?= esc($doc['id']) ?>')">
                                            <div class="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0 border border-indigo-200/60 dark:border-indigo-800/60">
                                                <?php if ($doc['category'] === 'branding' || str_starts_with($doc['file_type'] ?? '', 'image/')): ?>
                                                    <i data-lucide="image" class="w-4 h-4"></i>
                                                <?php elseif (str_contains($doc['file_type'] ?? '', 'pdf')): ?>
                                                    <i data-lucide="file-text" class="w-4 h-4"></i>
                                                <?php else: ?>
                                                    <i data-lucide="file-spreadsheet" class="w-4 h-4"></i>
                                                <?php endif; ?>
                                            </div>
                                            <div class="min-w-0">
                                                <p class="font-bold text-slate-900 dark:text-white truncate max-w-xs sm:max-w-md hover:text-indigo-600 transition">
                                                    <?= esc($doc['name']) ?>
                                                </p>
                                                <?php if (!empty($doc['description'])): ?>
                                                    <p class="text-[11px] text-slate-400 truncate max-w-xs sm:max-w-md">
                                                        <?= esc($doc['description']) ?>
                                                    </p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="py-3 px-4">
                                        <span class="capitalize px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                                            <?= esc($doc['category']) ?>
                                        </span>
                                    </td>
                                    <td class="py-3 px-4 font-mono text-slate-600 dark:text-slate-400">
                                        <?php 
                                            $b = (int)($doc['size'] ?? 0);
                                            if ($b > 1048576) {
                                                echo round($b / 1048576, 2) . ' MB';
                                            } elseif ($b > 1024) {
                                                echo round($b / 1024, 2) . ' KB';
                                            } else {
                                                echo $b . ' Bytes';
                                            }
                                        ?>
                                    </td>
                                    <td class="py-3 px-4">
                                        <div class="text-slate-700 dark:text-slate-300 font-semibold"><?= esc($doc['uploaded_by']) ?></div>
                                        <div class="text-[10px] text-slate-400 font-mono"><?= esc($doc['upload_date']) ?></div>
                                    </td>
                                    <td class="py-3 px-4">
                                        <span class="px-2 py-0.5 rounded-md text-[10px] font-bold <?= ($doc['status'] === 'Verified' || $doc['status'] === 'Ingested') ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200/60 dark:border-emerald-800/60' : 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400 border border-amber-200/60 dark:border-amber-800/60' ?>">
                                            <?= esc($doc['status']) ?>
                                        </span>
                                    </td>
                                    <td class="py-3 px-4 text-right">
                                        <div class="flex items-center justify-end gap-1.5">
                                            <!-- Inspect Document Button -->
                                            <button type="button" onclick="openInspectorModal('<?= esc($doc['id']) ?>')" title="Inspect Ingestion Details" class="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-slate-800 rounded-lg transition cursor-pointer">
                                                <i data-lucide="eye" class="w-4 h-4"></i>
                                            </button>

                                            <!-- Ingest Biometric Punches if Attendance -->
                                            <?php if ($doc['category'] === 'attendance' && (str_ends_with(strtolower($doc['name']), '.csv') || $doc['file_type'] === 'text/csv')): ?>
                                                <form action="<?= base_url('reports/upload/ingest-biometric/' . $doc['id']) ?>" method="post" class="inline" onsubmit="return confirm('Ingest punches from this CSV directly into attendance logs?');">
                                                    <?= csrf_field() ?>
                                                    <button type="submit" title="Ingest Biometric CSV into Attendance DB" class="p-1.5 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950 rounded-lg transition cursor-pointer">
                                                        <i data-lucide="database-zap" class="w-4 h-4"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>

                                            <!-- Set as Company Logo or Report Header -->
                                            <?php if (!empty($doc['data_url']) || str_starts_with($doc['file_type'] ?? '', 'image/')): ?>
                                                <form action="<?= base_url('reports/upload/apply-branding/' . $doc['id']) ?>" method="post" class="inline">
                                                    <?= csrf_field() ?>
                                                    <input type="hidden" name="target" value="report_header_image" />
                                                    <button type="submit" title="Set as Company Report Header Logo" class="p-1.5 text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950 rounded-lg transition cursor-pointer">
                                                        <i data-lucide="building-2" class="w-4 h-4"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>

                                            <!-- Download File -->
                                            <a href="<?= base_url('reports/upload/download/' . $doc['id']) ?>" title="Download Document" class="p-1.5 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition">
                                                <i data-lucide="download" class="w-4 h-4"></i>
                                            </a>

                                            <!-- Delete File -->
                                            <form action="<?= base_url('reports/upload/delete/' . $doc['id']) ?>" method="POST" class="inline" onsubmit="return confirm('Are you sure you want to remove document <?= esc($doc['name']) ?>?');">
                                                <?= csrf_field() ?>
                                                <button type="submit" title="Delete Document" class="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 dark:hover:bg-rose-950 rounded-lg transition">
                                                    <i data-lucide="trash-2" class="w-4 h-4"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>

    <!-- TAB 3: REPORT LOGO & BRANDING ASSETS -->
    <?php if ($activeSubTab === 'branding'): ?>
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Branding Settings Form (1 col) -->
            <div class="lg:col-span-1 space-y-6">
                <div class="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
                    <h2 class="text-sm font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                        <i data-lucide="image" class="w-4 h-4 text-indigo-600"></i>
                        <span>Independent Report Branding Settings</span>
                    </h2>

                    <form action="<?= base_url('reports/branding/save') ?>" method="post" class="space-y-4" id="brandingStudioForm">
                        <?= csrf_field() ?>

                        <!-- 1. Application Logo (Independent) -->
                        <div class="p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200/60 dark:border-slate-700/60 space-y-2">
                            <div class="flex items-center justify-between">
                                <label class="block text-xs font-bold text-slate-800 dark:text-slate-200">
                                    1. Application / Main Logo
                                </label>
                                <span class="text-[10px] text-slate-400 font-mono">App & Navbar</span>
                            </div>
                            
                            <input type="file" id="appLogoFileInput" accept="image/*" class="hidden" onchange="handleBrandingFileInput(this, 'appLogoInput', 'appLogoThumb')" />
                            
                            <div class="flex items-center gap-3">
                                <button type="button" onclick="document.getElementById('appLogoFileInput').click()" class="px-3 py-1.5 text-xs font-bold bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950 dark:hover:bg-indigo-900 text-indigo-700 dark:text-indigo-300 rounded-lg border border-indigo-200 dark:border-indigo-800 flex items-center gap-1.5 transition cursor-pointer">
                                    <i data-lucide="upload" class="w-3.5 h-3.5"></i>
                                    <span>Upload Logo</span>
                                </button>
                                <button type="button" onclick="document.getElementById('appLogoInput').value = ''; const th = document.getElementById('appLogoThumb'); if(th){th.src=''; th.classList.add('hidden');} updateLivePreview();" class="text-[11px] font-semibold text-slate-500 hover:text-rose-600 transition">
                                    Clear
                                </button>
                                <img id="appLogoThumb" src="<?= esc($company['logo'] ?? '') ?>" alt="App Logo" class="w-8 h-8 object-contain rounded border border-slate-200 dark:border-slate-700 p-0.5 <?= !empty($company['logo']) ? '' : 'hidden' ?>" />
                            </div>

                            <input type="text" id="appLogoInput" name="logo_url" value="<?= esc($company['logo'] ?? '') ?>" placeholder="Paste image URL or upload above..." class="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2 text-slate-900 dark:text-white placeholder-slate-400 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden" />
                        </div>

                        <!-- 2. Report Header Image & Layout (Independent) -->
                        <div class="p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200/60 dark:border-slate-700/60 space-y-3">
                            <div class="flex items-center justify-between">
                                <label class="block text-xs font-bold text-slate-800 dark:text-slate-200">
                                    2. Report Header Banner
                                </label>
                                <span class="text-[10px] text-indigo-600 dark:text-indigo-400 font-mono font-bold">A4 Reports</span>
                            </div>
                            
                            <input type="file" id="headerBannerFileInput" accept="image/*" class="hidden" onchange="handleBrandingFileInput(this, 'reportHeaderImgInput', null)" />

                            <div class="flex items-center gap-2">
                                <button type="button" onclick="document.getElementById('headerBannerFileInput').click()" class="px-3 py-1.5 text-xs font-bold bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950 dark:hover:bg-indigo-900 text-indigo-700 dark:text-indigo-300 rounded-lg border border-indigo-200 dark:border-indigo-800 flex items-center gap-1.5 transition cursor-pointer">
                                    <i data-lucide="upload" class="w-3.5 h-3.5"></i>
                                    <span>Upload Header Image</span>
                                </button>
                                <button type="button" onclick="clearHeaderLogo()" class="text-[11px] font-semibold text-slate-500 hover:text-rose-600 transition">
                                    Zero-Space (Clear)
                                </button>
                            </div>
                            
                            <input type="text" id="reportHeaderImgInput" name="report_header_image" value="<?= esc($company['report_header_image'] ?? '') ?>" placeholder="Image URL or Base64 (leave empty for 0px text-only header)" class="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2 text-slate-900 dark:text-white placeholder-slate-400 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden" oninput="updateLivePreview()" />
                            
                            <div class="flex gap-2 text-[10px]">
                                <button type="button" onclick="setPresetHeader('https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=240&auto=format&fit=crop&q=80')" class="font-bold text-indigo-600 hover:underline cursor-pointer">
                                    Sample A
                                </button>
                                <span class="text-slate-300">|</span>
                                <button type="button" onclick="setPresetHeader('https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=240&auto=format&fit=crop&q=80')" class="font-bold text-indigo-600 hover:underline cursor-pointer">
                                    Sample B
                                </button>
                            </div>

                            <!-- Header Layout Selector -->
                            <div>
                                <label class="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                                    Header Alignment Layout
                                </label>
                                <div class="grid grid-cols-4 gap-1.5 text-center text-xs">
                                    <label class="cursor-pointer">
                                        <input type="radio" name="report_header_layout" value="center" class="peer hidden" <?= ($company['report_header_layout'] ?? 'center') === 'center' ? 'checked' : '' ?> onchange="updateLivePreview()" />
                                        <div class="py-1.5 px-1 rounded-lg border border-slate-200 dark:border-slate-700 peer-checked:border-indigo-600 peer-checked:bg-indigo-50 peer-checked:text-indigo-700 dark:peer-checked:bg-indigo-950 dark:peer-checked:text-indigo-300 font-semibold text-[10px] transition">
                                            Center
                                        </div>
                                    </label>
                                    <label class="cursor-pointer">
                                        <input type="radio" name="report_header_layout" value="left" class="peer hidden" <?= ($company['report_header_layout'] ?? '') === 'left' ? 'checked' : '' ?> onchange="updateLivePreview()" />
                                        <div class="py-1.5 px-1 rounded-lg border border-slate-200 dark:border-slate-700 peer-checked:border-indigo-600 peer-checked:bg-indigo-50 peer-checked:text-indigo-700 dark:peer-checked:bg-indigo-950 dark:peer-checked:text-indigo-300 font-semibold text-[10px] transition">
                                            Left
                                        </div>
                                    </label>
                                    <label class="cursor-pointer">
                                        <input type="radio" name="report_header_layout" value="right" class="peer hidden" <?= ($company['report_header_layout'] ?? '') === 'right' ? 'checked' : '' ?> onchange="updateLivePreview()" />
                                        <div class="py-1.5 px-1 rounded-lg border border-slate-200 dark:border-slate-700 peer-checked:border-indigo-600 peer-checked:bg-indigo-50 peer-checked:text-indigo-700 dark:peer-checked:bg-indigo-950 dark:peer-checked:text-indigo-300 font-semibold text-[10px] transition">
                                            Right
                                        </div>
                                    </label>
                                    <label class="cursor-pointer">
                                        <input type="radio" name="report_header_layout" value="full" class="peer hidden" <?= ($company['report_header_layout'] ?? '') === 'full' ? 'checked' : '' ?> onchange="updateLivePreview()" />
                                        <div class="py-1.5 px-1 rounded-lg border border-slate-200 dark:border-slate-700 peer-checked:border-indigo-600 peer-checked:bg-indigo-50 peer-checked:text-indigo-700 dark:peer-checked:bg-indigo-950 dark:peer-checked:text-indigo-300 font-semibold text-[10px] transition">
                                            Full Width
                                        </div>
                                    </label>
                                </div>
                            </div>

                            <div>
                                <label class="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                                    Custom Header Slogan / Subtitle
                                </label>
                                <input type="text" id="reportHeaderText" name="report_header_text" value="<?= esc($company['report_header_text'] ?? '') ?>" placeholder="e.g., ISO 9001:2015 Certified Organization" class="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden" oninput="updateLivePreview()" />
                            </div>
                        </div>

                        <!-- 3. Report Footer Image & Disclaimer (Independent) -->
                        <div class="p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200/60 dark:border-slate-700/60 space-y-3">
                            <div class="flex items-center justify-between">
                                <label class="block text-xs font-bold text-slate-800 dark:text-slate-200">
                                    3. Report Footer Graphic
                                </label>
                                <span class="text-[10px] text-slate-400 font-mono">Optional Banner</span>
                            </div>

                            <input type="file" id="footerBannerFileInput" accept="image/*" class="hidden" onchange="handleBrandingFileInput(this, 'reportFooterImgInput', null)" />

                            <div class="flex items-center gap-2">
                                <button type="button" onclick="document.getElementById('footerBannerFileInput').click()" class="px-3 py-1.5 text-xs font-bold bg-amber-50 hover:bg-amber-100 dark:bg-amber-950 dark:hover:bg-amber-900 text-amber-700 dark:text-amber-300 rounded-lg border border-amber-200 dark:border-amber-800 flex items-center gap-1.5 transition cursor-pointer">
                                    <i data-lucide="upload" class="w-3.5 h-3.5"></i>
                                    <span>Upload Footer Image</span>
                                </button>
                                <button type="button" onclick="document.getElementById('reportFooterImgInput').value = ''; updateLivePreview();" class="text-[11px] font-semibold text-slate-500 hover:text-rose-600 transition">
                                    Zero-Space (Clear)
                                </button>
                            </div>

                            <input type="text" id="reportFooterImgInput" name="report_footer_image" value="<?= esc($company['report_footer_image'] ?? '') ?>" placeholder="Image URL or Base64 (leave blank for text-only footer)" class="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2 text-slate-900 dark:text-white placeholder-slate-400 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden" oninput="updateLivePreview()" />

                            <!-- Footer Layout Selector -->
                            <div>
                                <label class="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                                    Footer Alignment Layout
                                </label>
                                <div class="grid grid-cols-4 gap-1.5 text-center text-xs">
                                    <label class="cursor-pointer">
                                        <input type="radio" name="report_footer_layout" value="center" class="peer hidden" <?= ($company['report_footer_layout'] ?? 'center') === 'center' ? 'checked' : '' ?> onchange="updateLivePreview()" />
                                        <div class="py-1.5 px-1 rounded-lg border border-slate-200 dark:border-slate-700 peer-checked:border-amber-600 peer-checked:bg-amber-50 peer-checked:text-amber-700 dark:peer-checked:bg-amber-950 dark:peer-checked:text-amber-300 font-semibold text-[10px] transition">
                                            Center
                                        </div>
                                    </label>
                                    <label class="cursor-pointer">
                                        <input type="radio" name="report_footer_layout" value="left" class="peer hidden" <?= ($company['report_footer_layout'] ?? '') === 'left' ? 'checked' : '' ?> onchange="updateLivePreview()" />
                                        <div class="py-1.5 px-1 rounded-lg border border-slate-200 dark:border-slate-700 peer-checked:border-amber-600 peer-checked:bg-amber-50 peer-checked:text-amber-700 dark:peer-checked:bg-amber-950 dark:peer-checked:text-amber-300 font-semibold text-[10px] transition">
                                            Left
                                        </div>
                                    </label>
                                    <label class="cursor-pointer">
                                        <input type="radio" name="report_footer_layout" value="right" class="peer hidden" <?= ($company['report_footer_layout'] ?? '') === 'right' ? 'checked' : '' ?> onchange="updateLivePreview()" />
                                        <div class="py-1.5 px-1 rounded-lg border border-slate-200 dark:border-slate-700 peer-checked:border-amber-600 peer-checked:bg-amber-50 peer-checked:text-amber-700 dark:peer-checked:bg-amber-950 dark:peer-checked:text-amber-300 font-semibold text-[10px] transition">
                                            Right
                                        </div>
                                    </label>
                                    <label class="cursor-pointer">
                                        <input type="radio" name="report_footer_layout" value="full" class="peer hidden" <?= ($company['report_footer_layout'] ?? '') === 'full' ? 'checked' : '' ?> onchange="updateLivePreview()" />
                                        <div class="py-1.5 px-1 rounded-lg border border-slate-200 dark:border-slate-700 peer-checked:border-amber-600 peer-checked:bg-amber-50 peer-checked:text-amber-700 dark:peer-checked:bg-amber-950 dark:peer-checked:text-amber-300 font-semibold text-[10px] transition">
                                            Full Width
                                        </div>
                                    </label>
                                </div>
                            </div>

                            <div>
                                <label class="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                                    Report Footer Disclaimer / Text
                                </label>
                                <textarea id="reportFooterTextInput" name="report_footer_text" rows="2" class="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden" oninput="updateLivePreview()"><?= esc($company['report_footer_text'] ?? 'This is an official system-generated document from Enterprise HRMS Analytics Hub. Confidential.') ?></textarea>
                            </div>
                        </div>

                        <div class="pt-2">
                            <button type="submit" class="w-full py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs shadow-indigo-600/20 flex items-center justify-center gap-2 transition cursor-pointer">
                                <i data-lucide="check" class="w-4 h-4"></i>
                                <span>Save Branding Configuration</span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Live Printable A4 Page Preview (2 cols) -->
            <div class="lg:col-span-2 space-y-4">
                <div class="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
                    <div class="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 mb-4">
                        <h3 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
                            <i data-lucide="eye" class="w-4 h-4 text-indigo-600"></i>
                            <span>Live Printable A4 Page Preview</span>
                        </h3>
                        <span id="previewStatusBadge" class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 font-mono">
                            <?= !empty($company['report_header_image']) ? 'HEADER IMAGE ACTIVE' : 'ZERO-SPACE FALLBACK ACTIVE' ?>
                        </span>
                    </div>

                    <!-- A4 Sheet Container -->
                    <div class="bg-slate-100 dark:bg-slate-950 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-inner">
                        <div id="a4PreviewCanvas" class="bg-white dark:bg-slate-900 p-8 rounded-lg shadow-sm border border-slate-200 dark:border-slate-800 max-w-2xl mx-auto space-y-6">
                            
                            <!-- Dynamic Header Adhering to the Optional Image Rule -->
                            <?= view('reports/partials/report_header', [
                                'company'            => $company,
                                'reportTitle'        => 'MONTHLY SALARY & ATTENDANCE AUDIT REGISTER',
                                'reportPeriod'       => 'July 01, 2026 to July 31, 2026',
                                'reportHeaderImage'  => $company['report_header_image'] ?? null,
                                'reportHeaderLayout' => $company['report_header_layout'] ?? 'center',
                                'reportHeaderText'   => $company['report_header_text'] ?? null,
                            ]) ?>

                            <!-- Mock Report Table -->
                            <div class="border border-slate-200 dark:border-slate-800 rounded-md overflow-hidden text-[10px]">
                                <table class="w-full text-left">
                                    <thead class="bg-slate-100 dark:bg-slate-800 font-bold">
                                        <tr>
                                            <th class="p-1.5">EMP ID</th>
                                            <th class="p-1.5">NAME</th>
                                            <th class="p-1.5">DEPT</th>
                                            <th class="p-1.5">PRESENT</th>
                                            <th class="p-1.5">NET SALARY</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                                        <tr>
                                            <td class="p-1.5 font-mono">EMP-001</td>
                                            <td class="p-1.5 font-bold">Rahim Ahmed</td>
                                            <td class="p-1.5">Engineering</td>
                                            <td class="p-1.5">26 Days</td>
                                            <td class="p-1.5 font-mono font-bold"><?= esc($company['currency_symbol'] ?? '$') ?> 65,000</td>
                                        </tr>
                                        <tr>
                                            <td class="p-1.5 font-mono">EMP-002</td>
                                            <td class="p-1.5 font-bold">Sadia Islam</td>
                                            <td class="p-1.5">HR & Operations</td>
                                            <td class="p-1.5">25 Days</td>
                                            <td class="p-1.5 font-mono font-bold"><?= esc($company['currency_symbol'] ?? '$') ?> 48,000</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <!-- Dynamic Footer Adhering to the Optional Image Rule -->
                            <?= view('reports/partials/report_footer', [
                                'company'           => $company,
                                'reportFooterImage' => $company['report_footer_image'] ?? null,
                                'reportFooterText'  => $company['report_footer_text'] ?? 'This is an official system-generated document from Enterprise HRMS Analytics Hub. Confidential.',
                                'generatedDate'     => date('Y-m-d H:i:s'),
                                'pageNumberText'    => 'Page 1 of 1'
                            ]) ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- TAB 4: STANDARD PRESETS & SAMPLES -->
    <?php if ($activeSubTab === 'presets'): ?>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <!-- 1. Biometric ZKTeco -->
            <div class="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col justify-between">
                <div>
                    <div class="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-3">
                        <i data-lucide="file-spreadsheet" class="w-5 h-5"></i>
                    </div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">
                        Biometric ZKTeco Hardware Push CSV
                    </h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">
                        Standard format for importing bulk offline punches from biometric terminals (<code class="font-mono text-[10px] bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded">employee_code, datetime, punch_state, device_sn</code>).
                    </p>
                </div>
                <a href="<?= base_url('reports/upload/sample/zkteco_punch') ?>" class="mt-4 w-full py-2 text-xs font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer">
                    <i data-lucide="download" class="w-3.5 h-3.5"></i>
                    <span>Download CSV Template</span>
                </a>
            </div>

            <!-- 2. Monthly Salary Disbursement -->
            <div class="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col justify-between">
                <div>
                    <div class="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mb-3">
                        <i data-lucide="file-spreadsheet" class="w-5 h-5"></i>
                    </div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">
                        Monthly Salary Disbursement Schedule
                    </h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">
                        Pre-formatted payroll sheet for bank remittances, tax withholdings, and provident fund deductions.
                    </p>
                </div>
                <a href="<?= base_url('reports/upload/sample/salary_schedule') ?>" class="mt-4 w-full py-2 text-xs font-bold text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer">
                    <i data-lucide="download" class="w-3.5 h-3.5"></i>
                    <span>Download Payroll Template</span>
                </a>
            </div>

            <!-- 3. Tax Withholding Form 108 -->
            <div class="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col justify-between">
                <div>
                    <div class="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center mb-3">
                        <i data-lucide="file-text" class="w-5 h-5"></i>
                    </div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">
                        Tax Withholding Form 108 Template
                    </h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">
                        Annual employee tax deduction summary schedule prepared for statutory government compliance filing.
                    </p>
                </div>
                <a href="<?= base_url('reports/upload/sample/tax_form108') ?>" class="mt-4 w-full py-2 text-xs font-bold text-purple-700 dark:text-purple-300 bg-purple-50 dark:bg-purple-950/60 hover:bg-purple-100 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer">
                    <i data-lucide="download" class="w-3.5 h-3.5"></i>
                    <span>Download Form 108 Template</span>
                </a>
            </div>

            <!-- 4. Performance Bonus & Incentives -->
            <div class="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col justify-between">
                <div>
                    <div class="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center mb-3">
                        <i data-lucide="gift" class="w-5 h-5"></i>
                    </div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">
                        Bonus & Incentive Schedule Template
                    </h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">
                        Festival bonus, quarterly sales commission, and performance incentive computation spreadsheet.
                    </p>
                </div>
                <a href="<?= base_url('reports/upload/sample/bonus_incentive') ?>" class="mt-4 w-full py-2 text-xs font-bold text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/60 hover:bg-amber-100 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer">
                    <i data-lucide="download" class="w-3.5 h-3.5"></i>
                    <span>Download Bonus Template</span>
                </a>
            </div>

            <!-- 5. Overtime Work Claim Schedule -->
            <div class="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col justify-between">
                <div>
                    <div class="w-10 h-10 rounded-xl bg-cyan-50 dark:bg-cyan-950/60 text-cyan-600 dark:text-cyan-400 flex items-center justify-center mb-3">
                        <i data-lucide="clock" class="w-5 h-5"></i>
                    </div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">
                        Overtime Claim Verification Schedule
                    </h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">
                        Spreadsheet format for monthly overtime hours claim, rate multipliers, and justification notes.
                    </p>
                </div>
                <a href="<?= base_url('reports/upload/sample/overtime_claim') ?>" class="mt-4 w-full py-2 text-xs font-bold text-cyan-700 dark:text-cyan-300 bg-cyan-50 dark:bg-cyan-950/60 hover:bg-cyan-100 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer">
                    <i data-lucide="download" class="w-3.5 h-3.5"></i>
                    <span>Download Overtime Template</span>
                </a>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- DOCUMENT INSPECTOR / INGESTION PREVIEW MODAL -->
<div id="inspectorModal" class="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 hidden">
    <div class="bg-white dark:bg-slate-900 w-full max-w-2xl rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh]">
        <!-- Modal Header -->
        <div class="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                    <i data-lucide="file-search" class="w-5 h-5"></i>
                </div>
                <div>
                    <h3 id="modalDocName" class="text-sm font-bold text-slate-900 dark:text-white">Document Ingestion Details</h3>
                    <p id="modalDocMeta" class="text-xs text-slate-500"></p>
                </div>
            </div>
            <button type="button" onclick="closeInspectorModal()" class="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1.5 rounded-lg cursor-pointer">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>

        <!-- Modal Body -->
        <div class="p-5 overflow-y-auto space-y-4 text-xs">
            <div id="modalLoading" class="py-8 text-center text-slate-400 flex items-center justify-center gap-2">
                <i data-lucide="loader-2" class="w-5 h-5 animate-spin text-indigo-600"></i>
                <span>Loading document metadata and parsing preview...</span>
            </div>

            <div id="modalContent" class="space-y-4 hidden">
                <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div class="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                        <span class="text-[10px] text-slate-400 uppercase font-bold block">Category</span>
                        <span id="modalDocCategory" class="font-bold text-slate-800 dark:text-slate-200 capitalize"></span>
                    </div>
                    <div class="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                        <span class="text-[10px] text-slate-400 uppercase font-bold block">Size</span>
                        <span id="modalDocSize" class="font-bold font-mono text-slate-800 dark:text-slate-200"></span>
                    </div>
                    <div class="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                        <span class="text-[10px] text-slate-400 uppercase font-bold block">Status</span>
                        <span id="modalDocStatus" class="font-bold text-emerald-600"></span>
                    </div>
                    <div class="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                        <span class="text-[10px] text-slate-400 uppercase font-bold block">Parsed Rows</span>
                        <span id="modalDocRowCount" class="font-bold font-mono text-indigo-600"></span>
                    </div>
                </div>

                <!-- Description / Notes -->
                <div class="p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                    <span class="text-[10px] text-slate-400 uppercase font-bold block mb-1">Description & Audit Reference</span>
                    <p id="modalDocDescription" class="text-slate-700 dark:text-slate-300"></p>
                </div>

                <!-- Sample Rows Preview Table (for CSV) -->
                <div id="modalCsvBox" class="hidden space-y-2">
                    <span class="text-[10px] text-slate-400 uppercase font-bold block">CSV Sample Rows Excerpt</span>
                    <div class="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-xl">
                        <table id="modalCsvTable" class="w-full text-left text-[11px] font-mono"></table>
                    </div>
                </div>

                <!-- Image Preview (if image) -->
                <div id="modalImageBox" class="hidden text-center p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700">
                    <img id="modalImagePreview" src="" alt="Branding Preview" class="max-h-48 max-w-full mx-auto object-contain rounded-lg" />
                </div>
            </div>
        </div>

        <!-- Modal Footer -->
        <div class="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/30 flex items-center justify-between">
            <button type="button" onclick="closeInspectorModal()" class="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 dark:text-slate-400 cursor-pointer">
                Close
            </button>

            <div id="modalActionButtons" class="flex items-center gap-2"></div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }

    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('reportFileInput');
    const dropZonePlaceholder = document.getElementById('dropZonePlaceholder');
    const dropZoneFileInfo = document.getElementById('dropZoneFileInfo');
    const selectedFileName = document.getElementById('selectedFileName');
    const selectedFileSize = document.getElementById('selectedFileSize');
    const imagePreviewBox = document.getElementById('imagePreviewBox');
    const imagePreviewElement = document.getElementById('imagePreviewElement');
    const csvPreviewBox = document.getElementById('csvPreviewBox');
    const csvPreviewContent = document.getElementById('csvPreviewContent');
    const csvRowCountBadge = document.getElementById('csvRowCountBadge');
    const categorySelect = document.getElementById('categorySelect');
    const resetUploadBtn = document.getElementById('resetUploadBtn');

    if (resetUploadBtn) {
        resetUploadBtn.addEventListener('click', function() {
            if (fileInput) fileInput.value = '';
            const docNameInput = document.getElementById('docNameInput');
            if (docNameInput) docNameInput.value = '';
            if (dropZonePlaceholder) dropZonePlaceholder.classList.remove('hidden');
            if (dropZoneFileInfo) dropZoneFileInfo.classList.add('hidden');
            if (imagePreviewBox) imagePreviewBox.classList.add('hidden');
            if (csvPreviewBox) csvPreviewBox.classList.add('hidden');
            if (categorySelect) categorySelect.value = 'payroll';
            const errDiv = document.getElementById('uploadErrorFeedback');
            if (errDiv) errDiv.classList.add('hidden');
            if (dropZone) dropZone.classList.remove('border-rose-500', 'bg-rose-50/30');
        });
    }

    const reportForm = document.getElementById('reportUploadForm');
    if (reportForm) {
        reportForm.addEventListener('submit', function(e) {
            if (!fileInput || !fileInput.files || fileInput.files.length === 0) {
                e.preventDefault();
                const errDiv = document.getElementById('uploadErrorFeedback');
                const errText = document.getElementById('uploadErrorFeedbackText');
                if (errDiv && errText) {
                    errText.textContent = 'Please choose or drag-and-drop a file before confirming upload.';
                    errDiv.classList.remove('hidden');
                }
                if (dropZone) {
                    dropZone.classList.add('border-rose-500', 'bg-rose-50/30');
                }
                return false;
            }
        });
    }

    if (dropZone && fileInput) {
        fileInput.addEventListener('click', (e) => e.stopPropagation());
        dropZone.addEventListener('click', () => fileInput.click());

        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('border-indigo-600', 'bg-indigo-50/50', 'dark:bg-indigo-950/30');
        });

        dropZone.addEventListener('dragleave', (e) => {
            e.preventDefault();
            dropZone.classList.remove('border-indigo-600', 'bg-indigo-50/50', 'dark:bg-indigo-950/30');
        });

        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('border-indigo-600', 'bg-indigo-50/50', 'dark:bg-indigo-950/30');
            if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                fileInput.files = e.dataTransfer.files;
                handleFileSelection(e.dataTransfer.files[0]);
            }
        });

        fileInput.addEventListener('change', (e) => {
            if (e.target.files && e.target.files[0]) {
                handleFileSelection(e.target.files[0]);
            }
        });
    }

    function handleFileSelection(file) {
        if (!file) return;

        const errDiv = document.getElementById('uploadErrorFeedback');
        if (errDiv) errDiv.classList.add('hidden');
        if (dropZone) dropZone.classList.remove('border-rose-500', 'bg-rose-50/30');

        dropZonePlaceholder.classList.add('hidden');
        dropZoneFileInfo.classList.remove('hidden');
        selectedFileName.textContent = file.name;
        
        let sizeText = file.size + ' Bytes';
        if (file.size > 1048576) sizeText = (file.size / 1048576).toFixed(2) + ' MB';
        else if (file.size > 1024) sizeText = (file.size / 1024).toFixed(2) + ' KB';

        selectedFileSize.textContent = 'Ready to ingest • ' + sizeText;

        const docNameInput = document.getElementById('docNameInput');
        if (docNameInput && !docNameInput.value) {
            docNameInput.value = file.name;
        }

        // Auto-category selection
        const lowerName = file.name.toLowerCase();
        if (lowerName.includes('zk') || lowerName.includes('punch') || lowerName.includes('attendance') || lowerName.includes('biotime')) {
            if (categorySelect) categorySelect.value = 'attendance';
        } else if (lowerName.includes('salary') || lowerName.includes('pay') || lowerName.includes('payroll') || lowerName.includes('disbursement')) {
            if (categorySelect) categorySelect.value = 'payroll';
        } else if (lowerName.includes('tax') || lowerName.includes('tin') || lowerName.includes('nbr') || lowerName.includes('108')) {
            if (categorySelect) categorySelect.value = 'tax';
        } else if (lowerName.includes('logo') || lowerName.includes('brand') || lowerName.includes('header') || file.type.startsWith('image/')) {
            if (categorySelect) categorySelect.value = 'branding';
        } else if (lowerName.includes('audit') || lowerName.includes('compliance')) {
            if (categorySelect) categorySelect.value = 'audit';
        } else if (lowerName.includes('template') || lowerName.includes('preset')) {
            if (categorySelect) categorySelect.value = 'template';
        }

        // Image preview
        if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = function(evt) {
                if (imagePreviewBox && imagePreviewElement) {
                    imagePreviewElement.src = evt.target.result;
                    imagePreviewBox.classList.remove('hidden');
                    imagePreviewBox.classList.add('flex');
                }
            };
            reader.readAsDataURL(file);
        } else {
            if (imagePreviewBox) {
                imagePreviewBox.classList.add('hidden');
                imagePreviewBox.classList.remove('flex');
            }
        }

        // CSV parsing preview
        if (file.name.toLowerCase().endsWith('.csv') || file.type === 'text/csv') {
            const reader = new FileReader();
            reader.onload = function(evt) {
                const text = evt.target.result;
                const lines = text.split(/\r?\n/).filter(l => l.trim().length > 0);
                if (lines.length > 0) {
                    const sample = lines.slice(0, 6).join('\n');
                    if (csvPreviewContent) csvPreviewContent.textContent = sample;
                    if (csvRowCountBadge) csvRowCountBadge.textContent = lines.length + ' Total Rows Detected';
                    if (csvPreviewBox) csvPreviewBox.classList.remove('hidden');
                }
            };
            reader.readAsText(file);
        } else {
            if (csvPreviewBox) csvPreviewBox.classList.add('hidden');
        }
    }
});

// Direct branding file upload handler
function handleBrandingFileInput(fileInput, targetInputId, thumbImgId) {
    if (fileInput.files && fileInput.files[0]) {
        const file = fileInput.files[0];
        const reader = new FileReader();
        reader.onload = function(e) {
            const dataUrl = e.target.result;
            const targetInput = document.getElementById(targetInputId);
            if (targetInput) {
                targetInput.value = dataUrl;
            }
            if (thumbImgId) {
                const thumb = document.getElementById(thumbImgId);
                if (thumb) {
                    thumb.src = dataUrl;
                    thumb.classList.remove('hidden');
                }
            }
            updateLivePreview();
        };
        reader.readAsDataURL(file);
    }
}

// Real-time synchronization for Branding Tab & Zero-Space Fallback
function setPresetHeader(url) {
    const input = document.getElementById('reportHeaderImgInput');
    if (input) {
        input.value = url;
        updateLivePreview();
    }
}

function clearHeaderLogo() {
    const input = document.getElementById('reportHeaderImgInput');
    if (input) {
        input.value = '';
        updateLivePreview();
    }
}

function updateLivePreview() {
    const headerImgInput = document.getElementById('reportHeaderImgInput');
    const footerImgInput = document.getElementById('reportFooterImgInput');
    const footerTextInput = document.getElementById('reportFooterTextInput');
    const badge = document.getElementById('previewStatusBadge');
    const layoutRadios = document.getElementsByName('report_header_layout');
    
    let selectedLayout = 'center';
    for (const r of layoutRadios) {
        if (r.checked) {
            selectedLayout = r.value;
            break;
        }
    }

    const headerBox = document.querySelector('.report-header-wrapper');
    const headerImgBox = document.querySelector('.report-header-image-box');
    const headerImg = headerImgBox ? headerImgBox.querySelector('img') : null;
    const footerMsg = document.querySelector('.footer-msg');
    const footerImgBox = document.querySelector('.report-footer-image-box');
    const footerImg = footerImgBox ? footerImgBox.querySelector('img') : null;

    const hasHeaderUrl = headerImgInput && headerImgInput.value.trim().length > 5;
    
    if (badge) {
        if (hasHeaderUrl) {
            badge.textContent = 'HEADER IMAGE ACTIVE (' + selectedLayout.toUpperCase() + ')';
            badge.className = 'text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 font-mono';
        } else {
            badge.textContent = 'ZERO-SPACE FALLBACK ACTIVE';
            badge.className = 'text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 font-mono';
        }
    }

    if (headerImg && headerImgInput) {
        if (hasHeaderUrl) {
            headerImg.src = headerImgInput.value.trim();
            if (headerImgBox) headerImgBox.style.display = '';
        } else {
            if (headerImgBox) headerImgBox.style.display = 'none';
        }
    }

    if (footerMsg && footerTextInput) {
        footerMsg.textContent = footerTextInput.value;
    }

    if (footerImg && footerImgInput) {
        if (footerImgInput.value.trim().length > 5) {
            footerImg.src = footerImgInput.value.trim();
            if (footerImgBox) footerImgBox.style.display = '';
        } else {
            if (footerImgBox) footerImgBox.style.display = 'none';
        }
    }
}

// Ingestion Inspector Modal
function openInspectorModal(docId) {
    const modal = document.getElementById('inspectorModal');
    const modalLoading = document.getElementById('modalLoading');
    const modalContent = document.getElementById('modalContent');
    const modalDocName = document.getElementById('modalDocName');
    const modalDocMeta = document.getElementById('modalDocMeta');
    const modalDocCategory = document.getElementById('modalDocCategory');
    const modalDocSize = document.getElementById('modalDocSize');
    const modalDocStatus = document.getElementById('modalDocStatus');
    const modalDocRowCount = document.getElementById('modalDocRowCount');
    const modalDocDescription = document.getElementById('modalDocDescription');
    const modalCsvBox = document.getElementById('modalCsvBox');
    const modalCsvTable = document.getElementById('modalCsvTable');
    const modalImageBox = document.getElementById('modalImageBox');
    const modalImagePreview = document.getElementById('modalImagePreview');
    const modalActionButtons = document.getElementById('modalActionButtons');

    if (!modal) return;
    modal.classList.remove('hidden');
    modalLoading.classList.remove('hidden');
    modalContent.classList.add('hidden');

    fetch('<?= base_url('reports/upload/preview-json') ?>/' + encodeURIComponent(docId))
        .then(res => res.json())
        .then(data => {
            if (!data.success || !data.document) {
                modalLoading.innerHTML = '<span class="text-rose-500">' + (data.message || 'Failed to load document metadata.') + '</span>';
                return;
            }
            modalLoading.classList.add('hidden');
            modalContent.classList.remove('hidden');

            const doc = data.document;
            modalDocName.textContent = doc.name;
            modalDocMeta.textContent = 'Uploaded by ' + doc.uploaded_by + ' on ' + doc.upload_date;
            modalDocCategory.textContent = doc.category;
            
            let sizeText = (doc.size || 0) + ' B';
            if (doc.size > 1048576) sizeText = (doc.size / 1048576).toFixed(2) + ' MB';
            else if (doc.size > 1024) sizeText = (doc.size / 1024).toFixed(2) + ' KB';
            modalDocSize.textContent = sizeText;

            modalDocStatus.textContent = doc.status || 'Verified';
            modalDocRowCount.textContent = doc.parsed_row_count ? (doc.parsed_row_count + ' Rows') : 'N/A';
            modalDocDescription.textContent = doc.description || 'No additional description provided.';

            // CSV excerpt table
            if (data.sampleRows && data.sampleRows.length > 0) {
                modalCsvBox.classList.remove('hidden');
                modalCsvTable.innerHTML = '';
                data.sampleRows.forEach((row, idx) => {
                    const tr = document.createElement('tr');
                    tr.className = idx === 0 ? 'bg-slate-100 dark:bg-slate-800 font-bold' : 'border-t border-slate-100 dark:border-slate-800';
                    row.forEach(cell => {
                        const td = document.createElement(idx === 0 ? 'th' : 'td');
                        td.className = 'p-2 text-slate-700 dark:text-slate-300';
                        td.textContent = cell;
                        tr.appendChild(td);
                    });
                    modalCsvTable.appendChild(tr);
                });
            } else {
                modalCsvBox.classList.add('hidden');
            }

            // Image preview
            if (doc.data_url || (doc.file_type && doc.file_type.startsWith('image/'))) {
                modalImageBox.classList.remove('hidden');
                modalImagePreview.src = doc.data_url || ('<?= base_url('uploads/reports') ?>/' + doc.file_path.split('/').pop());
            } else {
                modalImageBox.classList.add('hidden');
            }

            // Action Buttons
            modalActionButtons.innerHTML = `
                <a href="<?= base_url('reports/upload/download') ?>/${encodeURIComponent(doc.id)}" class="px-3.5 py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-200 rounded-xl transition flex items-center gap-1.5">
                    <i data-lucide="download" class="w-3.5 h-3.5"></i>
                    <span>Download</span>
                </a>
            `;

            if (typeof lucide !== 'undefined') {
                lucide.createIcons();
            }
        })
        .catch(err => {
            modalLoading.innerHTML = '<span class="text-rose-500">Failed to load document metadata.</span>';
        });
}

function closeInspectorModal() {
    const modal = document.getElementById('inspectorModal');
    if (modal) modal.classList.add('hidden');
}
</script>
