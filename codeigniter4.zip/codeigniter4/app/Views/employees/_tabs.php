<?php
/**
 * Shared Employees Module Navigation Bar
 * 
 * Target URLs:
 * - Directory:               /employees
 * - Hierarchy:               /employees/hierarchy
 * - Probation:               /employees/probation
 * - Transfers & promotions:  /employees/movements
 * - Separation:              /employees/separation
 * 
 * @var string $activeTab Current active tab identifier
 * @var array  $tabCounts Optional associative array of counts for badges
 */

$currentActive = $activeTab ?? 'directory';

// Fetch counts if not explicitly passed
if (!isset($tabCounts) || !is_array($tabCounts)) {
    $db = \Config\Database::connect();
    $tabCounts = [
        'directory'  => 0,
        'probation'  => 0,
        'separation' => 0,
    ];

    try {
        $companyId = session()->get('company_id');
        $isSoftwareAdmin = (session()->get('role_code') === 'software_app_admin' || session()->get('role') === 'Software App Admin');

        // Total Workforce
        $empBuilder = $db->table('employees');
        if (!$isSoftwareAdmin && !empty($companyId)) {
            $empBuilder->where('company_id', $companyId);
        }
        $tabCounts['directory'] = $empBuilder->countAllResults();

        // Probation pending evaluation or ending within 30 days
        $hasConfirmCol = $db->fieldExists('confirmation_date', 'employees');
        $probBuilder = $db->table('employees');
        if (!$isSoftwareAdmin && !empty($companyId)) {
            $probBuilder->where('employees.company_id', $companyId);
        }
        $probBuilder->join('employment_types', 'employment_types.id = employees.employment_type_id', 'left');
        $probBuilder->groupStart()
            ->where('employees.status', \App\Models\EmployeeModel::STATUS_PROBATION)
            ->orWhereIn('employees.probation_status', ['Active', 'Pending', 'Extended', 'On Probation'])
            ->orLike('employment_types.name', 'probation')
            ->orLike('employment_types.code', 'prob')
        ->groupEnd();
        $probBuilder->whereNotIn('employees.status', [\App\Models\EmployeeModel::STATUS_TERMINATED, \App\Models\EmployeeModel::STATUS_RESIGNED, \App\Models\EmployeeModel::STATUS_INACTIVE]);
        $probBuilder->groupStart()
            ->where('employees.probation_status IS NULL')
            ->orWhereNotIn('employees.probation_status', ['Completed', 'Confirmed', 'Cancelled', 'Not Applicable'])
        ->groupEnd();
        $probBuilder->where('employees.probation_confirmed_date IS NULL');
        if ($hasConfirmCol) {
            $probBuilder->where('employees.confirmation_date IS NULL');
        }
        $probBuilder->groupStart()
            ->where('employees.probation_end_date >=', date('Y-m-d'))
            ->where('employees.probation_end_date <=', date('Y-m-d', strtotime('+30 days')))
            ->orWhere('employees.probation_end_date <', date('Y-m-d'))
            ->orWhere('employees.probation_end_date IS NULL')
        ->groupEnd();
        $tabCounts['probation'] = $probBuilder->countAllResults();

        // Separation pending
        $sepPendingCount = 0;
        if ($db->tableExists('employee_resignations')) {
            $resBuilder = $db->table('employee_resignations');
            if (!$isSoftwareAdmin && !empty($companyId)) {
                $resBuilder->join('employees', 'employees.id = employee_resignations.employee_id', 'inner');
                $resBuilder->where('employees.company_id', $companyId);
            }
            $sepPendingCount += $resBuilder->where('employee_resignations.status', 'Pending')->countAllResults();
        }
        if ($db->tableExists('employee_terminations')) {
            $termBuilder = $db->table('employee_terminations');
            if (!$isSoftwareAdmin && !empty($companyId)) {
                $termBuilder->join('employees', 'employees.id = employee_terminations.employee_id', 'inner');
                $termBuilder->where('employees.company_id', $companyId);
            }
            $sepPendingCount += $termBuilder->groupStart()
                ->where('employee_terminations.clearance_status', 'In Progress')
                ->orWhere('employee_terminations.final_settlement_status', 'Pending')
            ->groupEnd()->countAllResults();
        }
        $tabCounts['separation'] = $sepPendingCount;
    } catch (\Throwable $e) {
        log_message('debug', 'Error fetching employee _tabs counts: ' . $e->getMessage());
    }
}

$tabsList = [
    [
        'id'         => 'directory',
        'label'      => 'Directory',
        'url'        => base_url('employees'),
        'icon'       => 'users',
        'badge'      => (int)($tabCounts['directory'] ?? 0),
        'badge_type' => 'neutral',
        'permission' => 'employees.view',
    ],
    [
        'id'         => 'hierarchy',
        'label'      => 'Hierarchy',
        'url'        => base_url('employees/hierarchy'),
        'icon'       => 'git-fork',
        'badge'      => null,
        'permission' => 'organogram.view',
    ],
    [
        'id'         => 'probation',
        'label'      => 'Probation',
        'url'        => base_url('employees/probation'),
        'icon'       => 'user-check',
        'badge'      => (int)($tabCounts['probation'] ?? 0),
        'badge_type' => 'amber',
        'permission' => 'employees.probation',
    ],
    [
        'id'         => 'movements',
        'label'      => 'Transfers & Promotions',
        'url'        => base_url('employees/movements'),
        'icon'       => 'arrow-left-right',
        'badge'      => null,
        'permission' => 'employees.movement',
    ],
    [
        'id'         => 'separation',
        'label'      => 'Separation',
        'url'        => base_url('employees/separation'),
        'icon'       => 'user-x',
        'badge'      => (int)($tabCounts['separation'] ?? 0),
        'badge_type' => 'rose',
        'permission' => 'employees.separate',
    ],
];
?>

<div class="flex items-center gap-2 p-1.5 bg-slate-100/90 dark:bg-slate-900/70 rounded-2xl border border-slate-200/80 dark:border-slate-800 overflow-x-auto scrollbar-none shadow-2xs">
    <?php foreach ($tabsList as $t): ?>
        <?php 
        $permKey = $t['permission'] ?? null;
        if (!empty($permKey) && !can($permKey)) {
            continue;
        }
        $isActive = ($currentActive === $t['id']);
        ?>
        <a href="<?= esc($t['url']) ?>" 
           class="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all shrink-0 <?= $isActive 
                ? 'bg-indigo-600 text-white shadow-sm' 
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-white dark:hover:bg-slate-800/80' ?>">
            <i data-lucide="<?= esc($t['icon']) ?>" class="w-4 h-4 <?= $isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-600' ?>"></i>
            <span><?= esc($t['label']) ?></span>
            
            <?php if (!empty($t['badge']) && (int)$t['badge'] > 0): ?>
                <?php if ($isActive): ?>
                    <span class="px-1.5 py-0.5 rounded-full text-[10px] font-mono bg-white/20 text-white font-extrabold">
                        <?= (int)$t['badge'] ?>
                    </span>
                <?php elseif (($t['badge_type'] ?? '') === 'amber'): ?>
                    <span class="px-1.5 py-0.5 rounded-full text-[10px] font-mono bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300 font-extrabold border border-amber-300/60 dark:border-amber-800/60">
                        <?= (int)$t['badge'] ?>
                    </span>
                <?php elseif (($t['badge_type'] ?? '') === 'rose'): ?>
                    <span class="px-1.5 py-0.5 rounded-full text-[10px] font-mono bg-rose-100 text-rose-800 dark:bg-rose-950/70 dark:text-rose-300 font-extrabold border border-rose-300/60 dark:border-rose-800/60">
                        <?= (int)$t['badge'] ?>
                    </span>
                <?php else: ?>
                    <span class="px-1.5 py-0.5 rounded-full text-[10px] font-mono bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-extrabold">
                        <?= (int)$t['badge'] ?>
                    </span>
                <?php endif; ?>
            <?php endif; ?>
        </a>
    <?php endforeach; ?>
</div>
