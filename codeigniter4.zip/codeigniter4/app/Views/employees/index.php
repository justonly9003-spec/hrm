<div class="space-y-6" x-data="employeeDirectory(<?= htmlspecialchars(json_encode([
    'isSoftwareAdmin'   => $isSoftwareAdmin ?? false,
    'selectedCompanyId' => $selectedCompanyId ?? '',
    'selectedBranchId'  => $selectedBranchId ?? '',
    'selectedDeptId'    => $filters['department_id'] ?? '',
    'selectedStatus'    => $filters['status'] ?? '',
    'initialSearch'     => $filters['search'] ?? '',
    'branches'          => $branches ?? [],
    'companies'         => $companies ?? [],
    'departments'           => $departments ?? [],
    'designations'          => $designations ?? [],
    'shifts'                => $shifts ?? [],
    'employmentTypes'       => $employmentTypes ?? [],
    'employees'             => $employees ?? [],
    'pfRules'               => $pfRules ?? [],
    'pfPrefix'              => $pfPrefix ?? 'PF-',
    'suggestedEmployeeCode' => $suggestedEmployeeCode ?? '',
    'csrfName'              => csrf_token(),
    'csrfHash'          => csrf_hash(),
    'baseUrl'           => base_url()
]), ENT_QUOTES) ?>)">

    <?php if (!empty($emptyStateNotice)): ?>
        <div class="p-4 rounded-xl border border-amber-200 bg-amber-50 dark:bg-amber-950/40 dark:border-amber-800 text-amber-800 dark:text-amber-200 flex items-center gap-3">
            <i data-lucide="alert-circle" class="w-5 h-5 flex-shrink-0 text-amber-600 dark:text-amber-400"></i>
            <div>
                <p class="text-sm font-semibold"><?= esc($emptyStateNotice) ?></p>
                <p class="text-xs text-amber-600 dark:text-amber-400 mt-0.5">Please contact your administrator to associate your user account with an active organization.</p>
            </div>
        </div>
    <?php endif; ?>

    <!-- Page Header & Action Bar -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <div class="flex items-center gap-2 mb-1">
                <span class="text-[11px] font-bold px-2.5 py-0.5 rounded-md bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60">
                    Talent & Workforce Suite
                </span>
                <span class="text-[11px] text-slate-400 font-mono">
                    <?= !empty($isSoftwareAdmin) ? 'Multi-Tenant Root Console' : 'Enterprise Tenant Console' ?>
                </span>
            </div>
            <h2 class="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">Employee Directory</h2>
            <p class="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                Multi-tier personnel directory, salary structures, and headcount analytics
            </p>
        </div>
        <div class="flex flex-wrap items-center gap-2.5">
            <!-- View Mode Switcher -->
            <div class="bg-slate-100 dark:bg-slate-800 p-1 rounded-xl flex items-center gap-1 border border-slate-200 dark:border-slate-700">
                <button type="button"
                        @click="activeView = 'table'"
                        :class="activeView === 'table' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'"
                        class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition">
                    <i data-lucide="table" class="w-3.5 h-3.5"></i>
                    <span>Table View</span>
                </button>
                <button type="button"
                        @click="activeView = 'analytics'"
                        :class="activeView === 'analytics' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'"
                        class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition">
                    <i data-lucide="bar-chart-3" class="w-3.5 h-3.5"></i>
                    <span>Headcount Analytics</span>
                </button>
            </div>

            <!-- Export CSV -->
            <?php if (can('employee.export')): ?>
            <a :href="baseUrl + 'employees/export/csv?' + currentQueryParams()" 
               class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 shadow-xs transition">
                <i data-lucide="download" class="w-4 h-4 text-slate-500"></i>
                <span>Export CSV</span>
            </a>
            <?php endif; ?>

            <!-- Bulk Upload (XLS / CSV) Modal Trigger -->
            <button type="button"
                    @click="openBulkUploadModal()"
                    class="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl font-bold text-xs text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 border border-emerald-200 dark:border-emerald-800 shadow-xs transition-all cursor-pointer">
                <i data-lucide="file-spreadsheet" class="w-4 h-4 text-emerald-600 dark:text-emerald-400"></i>
                <span>Bulk Upload (XLS / CSV)</span>
            </button>

            <!-- Add Employee Modal Trigger -->
            <button type="button"
                    @click="openAddModal()"
                    class="inline-flex items-center gap-2 px-4 py-2 rounded-xl font-bold text-xs text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm transition-all cursor-pointer">
                <i data-lucide="user-plus" class="w-4 h-4"></i>
                <span>Add Employee</span>
            </button>
        </div>
    </div>

    <!-- Shared Employees Module Navigation Tabs -->
    <?= view('employees/_tabs', ['activeTab' => 'directory']) ?>

    <?php
    $canViewSalary = !empty($isSoftwareAdmin)
        || (session()->get('role_code') === 'company_admin')
        || (session()->get('role_code') === 'software_app_admin')
        || (function_exists('can') && (can('employees.salary.view') || can('employee.view_salary') || can('employees.view_salary')));
    $kpi = $analytics['kpi'] ?? $analytics;
    $totalEmployees = (int)($kpi['total_employees'] ?? ($totalEmployees ?? count($employees ?? [])));
    $totalDepts = $totalDepts ?? count($departments ?? []);
    $totalSalary = (float)($kpi['total_basic_salary'] ?? ($totalSalary ?? 0.0));
    $activeCount = (int)($kpi['active_count'] ?? 0);
    $probationCount = (int)($kpi['probation_count'] ?? 0);
    $newJoinersMonth = (int)($kpi['new_joiners_month'] ?? 0);
    $separatedCount = (int)($kpi['separated_count'] ?? 0);
    ?>
    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
        <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-xs">
            <div class="flex items-center justify-between">
                <span class="text-xs font-medium text-slate-500 dark:text-slate-400">Total Workforce</span>
                <div class="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                    <i data-lucide="users" class="w-4 h-4"></i>
                </div>
            </div>
            <p class="text-2xl font-bold text-slate-900 dark:text-white mt-2"><?= $totalEmployees ?></p>
            <p class="text-[11px] text-slate-500 dark:text-slate-400 mt-1">Directory size</p>
        </div>

        <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-xs">
            <div class="flex items-center justify-between">
                <span class="text-xs font-medium text-slate-500 dark:text-slate-400">Active</span>
                <div class="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                    <i data-lucide="user-check" class="w-4 h-4"></i>
                </div>
            </div>
            <p class="text-2xl font-bold text-emerald-600 dark:text-emerald-400 mt-2"><?= $activeCount ?></p>
            <p class="text-[11px] text-slate-500 dark:text-slate-400 mt-1">Operational accounts</p>
        </div>

        <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-xs">
            <div class="flex items-center justify-between">
                <span class="text-xs font-medium text-slate-500 dark:text-slate-400">On Probation</span>
                <div class="w-8 h-8 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                    <i data-lucide="clock" class="w-4 h-4"></i>
                </div>
            </div>
            <p class="text-2xl font-bold text-amber-600 dark:text-amber-400 mt-2"><?= $probationCount ?></p>
            <p class="text-[11px] text-slate-500 dark:text-slate-400 mt-1">Evaluation period</p>
        </div>

        <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-xs">
            <div class="flex items-center justify-between">
                <span class="text-xs font-medium text-slate-500 dark:text-slate-400">New Joiners</span>
                <div class="w-8 h-8 rounded-xl bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 flex items-center justify-center">
                    <i data-lucide="user-plus" class="w-4 h-4"></i>
                </div>
            </div>
            <p class="text-2xl font-bold text-sky-600 dark:text-sky-400 mt-2"><?= $newJoinersMonth ?></p>
            <p class="text-[11px] text-slate-500 dark:text-slate-400 mt-1">Joined this month</p>
        </div>

        <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-xs">
            <div class="flex items-center justify-between">
                <span class="text-xs font-medium text-slate-500 dark:text-slate-400">Separated</span>
                <div class="w-8 h-8 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center">
                    <i data-lucide="user-x" class="w-4 h-4"></i>
                </div>
            </div>
            <p class="text-2xl font-bold text-slate-700 dark:text-slate-300 mt-2"><?= $separatedCount ?></p>
            <p class="text-[11px] text-rose-500 mt-1">Resigned & Terminated</p>
        </div>
    </div>

    <!-- Filters & Hierarchy Toolbar (Company -> Branch -> Employees) -->
    <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-xs">
        <form id="filterForm" action="<?= base_url('employees') ?>" method="GET" class="space-y-3">
            <div class="flex flex-wrap items-center justify-between gap-3">
                
                <!-- Left: Hierarchy Filters -->
                <div class="flex flex-wrap items-center gap-3 flex-1">
                    
                    <!-- Search Input -->
                    <div class="relative min-w-[220px] max-w-xs flex-1">
                        <i data-lucide="search" class="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"></i>
                        <input type="text" 
                               name="search" 
                               x-model="searchQuery" 
                               value="<?= esc($filters['search'] ?? '') ?>" 
                               placeholder="Search name, code, email..." 
                               class="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>

                    <!-- 1. Company Filter -->
                    <?php if (!empty($isSoftwareAdmin)): ?>
                        <div class="min-w-[190px]">
                            <label class="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 flex items-center gap-1">
                                <i data-lucide="building" class="w-3 h-3 text-indigo-500"></i> Company
                            </label>
                            <select name="company_id" 
                                    x-model="selectedCompany" 
                                    @change="onCompanyChange()" 
                                    class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                <option value="">All Companies</option>
                                <?php foreach ($companies as $c): ?>
                                    <option value="<?= esc($c['id']) ?>" <?= ($selectedCompanyId ?? '') === $c['id'] ? 'selected' : '' ?>>
                                        <?= esc($c['name']) ?> (<?= esc($c['code'] ?? '') ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php else: ?>
                        <!-- Company Admin: Fixed Company Indicator -->
                        <?php 
                        $currentComp = !empty($companies[0]) ? $companies[0] : null;
                        ?>
                        <div class="min-w-[190px]">
                            <label class="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 flex items-center gap-1">
                                <i data-lucide="building" class="w-3 h-3 text-emerald-500"></i> Logged-in Company
                            </label>
                            <div class="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center justify-between">
                                <span class="truncate"><?= esc($currentComp['name'] ?? 'Assigned Company') ?></span>
                                <span class="text-[10px] px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400 font-mono">Scoped</span>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- 2. Branch Filter -->
                    <div class="min-w-[170px]">
                        <label class="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 flex items-center gap-1">
                            <i data-lucide="map-pin" class="w-3 h-3 text-indigo-500"></i> Branch
                        </label>
                        <select name="branch_id" 
                                x-model="selectedBranch" 
                                class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <option value="">All Branches</option>
                            <template x-for="b in filteredBranches" :key="b.id">
                                <option :value="b.id" :selected="b.id === selectedBranch" x-text="b.name"></option>
                            </template>
                        </select>
                    </div>

                    <!-- 3. Department Filter -->
                    <div class="min-w-[140px]">
                        <label class="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Department</label>
                        <select name="department_id" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <option value="">All Departments</option>
                            <?php foreach ($departments as $d): ?>
                                <option value="<?= esc($d['id']) ?>" <?= ($filters['department_id'] ?? '') === $d['id'] ? 'selected' : '' ?>>
                                    <?= esc($d['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Designation Filter -->
                    <div class="min-w-[140px]">
                        <label class="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Designation</label>
                        <select name="designation_id" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <option value="">All Designations</option>
                            <?php foreach ($designations ?? [] as $desg): ?>
                                <option value="<?= esc($desg['id']) ?>" <?= ($filters['designation_id'] ?? '') === $desg['id'] ? 'selected' : '' ?>>
                                    <?= esc($desg['name'] ?? $desg['title'] ?? '') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Employment Type Filter -->
                    <div class="min-w-[130px]">
                        <label class="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Emp Type</label>
                        <select name="employment_type_id" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <option value="">All Types</option>
                            <?php foreach ($employmentTypes ?? [] as $et): ?>
                                <option value="<?= esc($et['id']) ?>" <?= ($filters['employment_type_id'] ?? '') === $et['id'] ? 'selected' : '' ?>>
                                    <?= esc($et['name'] ?? '') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Shift Filter -->
                    <div class="min-w-[130px]">
                        <label class="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Shift</label>
                        <select name="shift_id" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <option value="">All Shifts</option>
                            <?php foreach ($shifts ?? [] as $sh): ?>
                                <option value="<?= esc($sh['id']) ?>" <?= ($filters['shift_id'] ?? '') === $sh['id'] ? 'selected' : '' ?>>
                                    <?= esc($sh['name'] ?? '') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Manager Filter -->
                    <div class="min-w-[140px]">
                        <label class="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Manager</label>
                        <select name="reporting_manager_id" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <option value="">All Managers</option>
                            <?php foreach ($managers ?? [] as $mgr): ?>
                                <option value="<?= esc($mgr['id']) ?>" <?= ($filters['reporting_manager_id'] ?? '') === $mgr['id'] ? 'selected' : '' ?>>
                                    <?= esc(trim(($mgr['first_name'] ?? '') . ' ' . ($mgr['last_name'] ?? ''))) ?> (<?= esc($mgr['employee_code'] ?? '') ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- 4. Status Filter -->
                    <div class="min-w-[120px]">
                        <label class="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Status</label>
                        <select name="status" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <option value="">All Statuses</option>
                            <?php foreach (\App\Models\EmployeeModel::STATUS_LABELS as $sVal => $sLabel): ?>
                                <option value="<?= esc($sVal) ?>" <?= ($filters['status'] ?? '') === $sVal ? 'selected' : '' ?>><?= esc($sLabel) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- 5. PF Status Filter -->
                    <div class="min-w-[130px]">
                        <label class="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 flex items-center gap-1">
                            <i data-lucide="shield-check" class="w-3 h-3 text-emerald-500"></i> PF Status
                        </label>
                        <select name="pf_status" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <option value="">All PF Status</option>
                            <option value="Enrolled" <?= ($filters['pf_status'] ?? '') === 'Enrolled' ? 'selected' : '' ?>>Enrolled</option>
                            <option value="Closed" <?= ($filters['pf_status'] ?? '') === 'Closed' ? 'selected' : '' ?>>Closed</option>
                            <option value="Not Enrolled" <?= ($filters['pf_status'] ?? '') === 'Not Enrolled' ? 'selected' : '' ?>>Not Enrolled</option>
                            <option value="Exempt" <?= ($filters['pf_status'] ?? '') === 'Exempt' ? 'selected' : '' ?>>Exempt</option>
                            <option value="Ineligible" <?= ($filters['pf_status'] ?? '') === 'Ineligible' ? 'selected' : '' ?>>Ineligible</option>
                        </select>
                    </div>
                </div>

                <!-- Right: Submit Actions -->
                <div class="flex items-center gap-2 self-end pt-5">
                    <button type="submit" class="px-4 py-2 bg-slate-900 hover:bg-slate-800 dark:bg-indigo-600 dark:hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-xs transition flex items-center gap-1.5">
                        <i data-lucide="filter" class="w-3.5 h-3.5"></i>
                        <span>Apply Filter</span>
                    </button>
                    <?php if (!empty($filters['search']) || !empty($filters['company_id']) || !empty($filters['branch_id']) || !empty($filters['department_id']) || !empty($filters['designation_id']) || !empty($filters['employment_type_id']) || !empty($filters['shift_id']) || !empty($filters['reporting_manager_id']) || !empty($filters['status']) || !empty($filters['pf_status'])): ?>
                        <a href="<?= base_url('employees') ?>" class="px-3 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300 rounded-xl text-xs font-semibold transition">
                            Reset
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>

    <!-- Active Hierarchy Scope Indicator Pill -->
    <div class="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-900/50 p-2.5 px-4 rounded-xl border border-slate-200/60 dark:border-slate-800">
        <i data-lucide="git-fork" class="w-4 h-4 text-indigo-500"></i>
        <span>Active Scope Hierarchy:</span>
        <span class="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1">
            <span class="px-2 py-0.5 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-400 rounded-md font-mono">
                <?= !empty($selectedCompanyId) ? esc(array_values(array_filter($companies ?? [], fn($c) => $c['id'] === $selectedCompanyId))[0]['name'] ?? $selectedCompanyId) : 'All Companies' ?>
            </span>
            <span>&rarr;</span>
            <span class="px-2 py-0.5 bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-400 rounded-md font-mono">
                <?= !empty($selectedBranchId) ? esc(array_values(array_filter($branches ?? [], fn($b) => $b['id'] === $selectedBranchId))[0]['name'] ?? $selectedBranchId) : 'All Branches' ?>
            </span>
            <span>&rarr;</span>
            <span class="text-slate-600 dark:text-slate-400 font-semibold">
                <?= (int)($totalEmployees ?? count($employees ?? [])) ?> Staff Members
            </span>
        </span>
    </div>

    <!-- ============================================================= -->
    <!-- VIEW 1: DIRECTORY TABLE -->
    <!-- ============================================================= -->
    <div x-show="activeView === 'table'" class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-xs">
        <div class="p-4 border-b border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
            <div class="flex items-center gap-2">
                <i data-lucide="list-filter" class="w-4 h-4 text-indigo-600 dark:text-indigo-400"></i>
                <h3 class="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Personnel Registry (<?= (int)($pagination['total'] ?? count($employees ?? [])) ?> Records)
                </h3>
            </div>
            <span class="text-xs text-slate-400">Click actions to View Profile, Edit, Promote, Confirm, or Terminate</span>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs text-slate-600 dark:text-slate-300">
                <thead class="bg-slate-50/80 dark:bg-slate-900/50 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200/80 dark:border-slate-700 text-[11px] uppercase tracking-wider">
                    <tr>
                        <th class="py-3.5 px-3 w-10 text-center">
                            <input type="checkbox" @change="toggleSelectAll($event)" :checked="isAllSelected()" class="rounded border-slate-300 dark:border-slate-600 text-indigo-600 focus:ring-indigo-500 cursor-pointer">
                        </th>
                        <th class="py-3.5 px-4">Employee Details</th>
                        <th class="py-3.5 px-4">Company & Branch Hierarchy</th>
                        <th class="py-3.5 px-4">Department & Role</th>
                        <th class="py-3.5 px-4">Reporting Manager</th>
                        <th class="py-3.5 px-4">Join Date</th>
                        <?php if (!empty($canViewSalary)): ?>
                            <th class="py-3.5 px-4">Base Salary & PF</th>
                        <?php endif; ?>
                        <th class="py-3.5 px-4">Contract / Status</th>
                        <th class="py-3.5 px-4 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-700/60">
                    <?php if (empty($employees)): ?>
                        <tr>
                            <td colspan="8" class="py-12 text-center text-slate-400">
                                <div class="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-700 flex items-center justify-center mx-auto mb-3 text-slate-400">
                                    <i data-lucide="user-x" class="w-6 h-6"></i>
                                </div>
                                <p class="text-sm font-semibold text-slate-600 dark:text-slate-300">
                                    <?= !empty($emptyStateNotice) ? esc($emptyStateNotice) : 'No employee records match the selected hierarchy & filters' ?>
                                </p>
                                <p class="text-xs text-slate-400 mt-1">
                                    <?= !empty($emptyStateNotice) ? 'Directory access requires an active company assignment.' : 'Try switching company/branch or clearing active search filters' ?>
                                </p>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($employees as $e): ?>
                            <?php 
                            $isAppAdmin = ($e['role'] ?? '') === 'Software App Admin' || ($e['employee_code'] ?? '') === 'SUPER_ADMIN';
                            $empName = !empty($e['full_name']) ? $e['full_name'] : (!empty($e['name']) ? $e['name'] : trim(($e['first_name'] ?? '') . ' ' . ($e['last_name'] ?? '')));
                            if (empty($empName)) {
                                $empName = $e['employee_code'] ?? 'Employee #' . substr($e['id'] ?? '', 0, 6);
                            }
                            $reversedName = trim(($e['last_name'] ?? '') . ' ' . ($e['first_name'] ?? ''));
                            $searchRowText = implode(' ', array_filter([
                                $empName,
                                $reversedName,
                                $e['first_name'] ?? '',
                                $e['last_name'] ?? '',
                                $e['employee_code'] ?? '',
                                $e['email'] ?? '',
                                $e['phone'] ?? '',
                                $e['department_name'] ?? '',
                                $e['designation_name'] ?? '',
                                $e['company_name'] ?? '',
                                $e['branch_name'] ?? '',
                            ]));
                            $initials = strtoupper(substr($e['first_name'] ?? $empName, 0, 1) . substr($e['last_name'] ?? '', 0, 1));
                            if (strlen($initials) === 0) $initials = 'EM';
                            $status = \App\Models\EmployeeModel::normalizeStatus($e['status'] ?? \App\Models\EmployeeModel::STATUS_ACTIVE, true);
                            $statusLabel = \App\Models\EmployeeModel::STATUS_LABELS[$status] ?? ucfirst($status);
                            $statusClass = match($status) {
                                \App\Models\EmployeeModel::STATUS_ACTIVE => 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800',
                                \App\Models\EmployeeModel::STATUS_PROBATION => 'bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-400 border-amber-200 dark:border-amber-800',
                                \App\Models\EmployeeModel::STATUS_ON_LEAVE => 'bg-sky-50 text-sky-700 dark:bg-sky-950/50 dark:text-sky-400 border-sky-200 dark:border-sky-800',
                                \App\Models\EmployeeModel::STATUS_SUSPENDED => 'bg-rose-50 text-rose-700 dark:bg-rose-950/50 dark:text-rose-400 border-rose-200 dark:border-rose-800',
                                \App\Models\EmployeeModel::STATUS_RESIGNED, \App\Models\EmployeeModel::STATUS_TERMINATED, \App\Models\EmployeeModel::STATUS_INACTIVE => 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-slate-200 dark:border-slate-700',
                                default => 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                            };
                            ?>
                            <tr class="hover:bg-slate-50/70 dark:hover:bg-slate-700/30 transition-colors"
                                x-show="matchesSearch(<?= htmlspecialchars(json_encode($searchRowText), ENT_QUOTES) ?>)">
                                
                                <!-- Selection Checkbox -->
                                <td class="py-3.5 px-3 text-center">
                                    <?php if (!$isAppAdmin): ?>
                                        <input type="checkbox" :value="'<?= esc($e['id'], 'js') ?>'" x-model="selectedEmployees" class="rounded border-slate-300 dark:border-slate-600 text-indigo-600 focus:ring-indigo-500 cursor-pointer">
                                    <?php else: ?>
                                        <span class="text-[10px] text-slate-400 font-bold" title="Software App Admin Excluded">-</span>
                                    <?php endif; ?>
                                </td>

                                <!-- Employee Details -->
                                <td class="py-3.5 px-4">
                                    <div class="flex items-center gap-3">
                                        <div class="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-xs shrink-0 border border-indigo-100 dark:border-indigo-900/50 shadow-2xs">
                                            <?= esc($initials) ?>
                                        </div>
                                        <div>
                                            <a href="<?= base_url('employees/profile/' . $e['id']) ?>" class="font-bold text-slate-900 dark:text-white hover:text-indigo-600 dark:hover:text-indigo-400 transition text-xs flex items-center gap-1.5">
                                                <span><?= esc($empName) ?></span>
                                            </a>
                                            <div class="flex items-center gap-2 mt-0.5">
                                                <span class="font-mono text-[10px] font-semibold px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800">
                                                    <?= esc($e['employee_code'] ?? $e['id']) ?>
                                                </span>
                                                <span class="text-[11px] text-slate-400 truncate max-w-[160px]"><?= esc($e['email'] ?? 'No email') ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </td>

                                <!-- Company & Branch Hierarchy -->
                                <td class="py-3.5 px-4">
                                    <div class="space-y-1">
                                        <p class="font-semibold text-slate-900 dark:text-white flex items-center gap-1.5">
                                            <i data-lucide="building" class="w-3.5 h-3.5 text-indigo-500"></i>
                                            <span><?= esc($e['company_name'] ?? 'Main Enterprise') ?></span>
                                        </p>
                                        <p class="text-[11px] text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                                            <i data-lucide="map-pin" class="w-3.5 h-3.5 text-slate-400"></i>
                                            <span><?= esc($e['branch_name'] ?? 'Head Office') ?></span>
                                        </p>
                                    </div>
                                </td>

                                <!-- Department & Role -->
                                <td class="py-3.5 px-4">
                                    <div class="space-y-0.5">
                                        <p class="font-semibold text-slate-900 dark:text-white flex items-center gap-1.5">
                                            <i data-lucide="briefcase" class="w-3.5 h-3.5 text-slate-400"></i>
                                            <?= esc($e['designation_name'] ?? $e['designation_title'] ?? 'Staff Member') ?>
                                        </p>
                                        <p class="text-[11px] text-slate-500 dark:text-slate-400">
                                            <?= esc($e['department_name'] ?? 'General Department') ?>
                                        </p>
                                    </div>
                                </td>

                                <!-- Reporting Manager -->
                                <td class="py-3.5 px-4">
                                    <?php if (!empty($e['reporting_manager_id']) || !empty($e['manager_name'])): ?>
                                        <div>
                                            <span class="font-semibold text-slate-800 dark:text-slate-200 block text-xs"><?= esc($e['manager_name'] ?? 'Assigned Manager') ?></span>
                                        </div>
                                    <?php else: ?>
                                        <span class="text-[10px] bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400 px-2 py-0.5 rounded font-bold uppercase tracking-wider border border-slate-200 dark:border-slate-800">
                                            C-Suite / Root
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <!-- Join Date -->
                                <td class="py-3.5 px-4 font-mono text-xs text-slate-600 dark:text-slate-300">
                                    <?= esc(!empty($e['joining_date']) ? $e['joining_date'] : ($e['join_date'] ?? 'N/A')) ?>
                                </td>

                                <!-- Salary & PF -->
                                <?php if (!empty($canViewSalary)): ?>
                                <td class="py-3.5 px-4">
                                    <div class="space-y-1">
                                        <span class="font-mono font-bold text-slate-900 dark:text-white block">
                                            <?= number_format((float)($e['basic_salary'] ?? 0), 2) ?>
                                        </span>
                                        <div>
                                            <?php if ($isAppAdmin): ?>
                                                <span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400">
                                                    Excluded (Admin)
                                                </span>
                                            <?php elseif (!empty($e['is_pf_applicable']) && ($e['pf_status'] ?? '') === 'Enrolled'): ?>
                                                <?php if (!empty($e['pf_effective_date']) && date('Y-m-d') < $e['pf_effective_date']): ?>
                                                    <span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-sky-50 text-sky-700 dark:bg-sky-950/60 dark:text-sky-400 border border-sky-200 dark:border-sky-800" title="Effective from <?= esc($e['pf_effective_date']) ?>">
                                                        <i data-lucide="clock" class="w-3 h-3 mr-1 inline"></i>Pending
                                                    </span>
                                                <?php else: ?>
                                                    <span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800" title="<?= esc($e['pf_rule_name'] ?? 'Enrolled') ?>">
                                                        <i data-lucide="shield-check" class="w-3 h-3 mr-1 inline"></i>Enrolled
                                                    </span>
                                                <?php endif; ?>
                                            <?php elseif (($e['pf_status'] ?? '') === 'Exempt'): ?>
                                                <span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400 border border-amber-200 dark:border-amber-800">
                                                    Exempt
                                                </span>
                                            <?php elseif (($e['pf_status'] ?? '') === 'Ineligible'): ?>
                                                <span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400 border border-rose-200 dark:border-rose-800">
                                                    Ineligible
                                                </span>
                                            <?php elseif (!empty($e['pf_close_date']) && date('Y-m-d') >= $e['pf_close_date']): ?>
                                                <span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-400 border border-purple-200 dark:border-purple-800" title="Closed effective <?= esc($e['pf_close_date']) ?>">
                                                    <i data-lucide="shield-off" class="w-3 h-3 mr-1 inline"></i>Closed
                                                </span>
                                            <?php else: ?>
                                                <span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400 border border-slate-200 dark:border-slate-700">
                                                    Not Enrolled
                                                </span>
                                            <?php endif; ?>
                                            <?php if (!empty($e['pf_member_id'])): ?>
                                                <p class="text-[9px] text-slate-400 font-mono mt-0.5"><?= esc($e['pf_member_id']) ?></p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <?php endif; ?>

                                <!-- Contract & Status -->
                                <td class="py-3.5 px-4">
                                    <div class="space-y-1">
                                        <span class="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold border <?= $statusClass ?>">
                                            <span class="w-1.5 h-1.5 rounded-full mr-1.5 <?= $status === \App\Models\EmployeeModel::STATUS_ACTIVE ? 'bg-emerald-500' : ($status === \App\Models\EmployeeModel::STATUS_PROBATION ? 'bg-amber-500' : 'bg-rose-500') ?>"></span>
                                            <?= esc($statusLabel) ?>
                                        </span>
                                        <p class="text-[10px] text-slate-500 dark:text-slate-400 font-medium">
                                            <?= esc($e['employment_type_name'] ?? 'Full-Time') ?>
                                        </p>
                                    </div>
                                </td>

                                <!-- Actions -->
                                <td class="py-3.5 px-4 text-right">
                                    <div class="flex items-center justify-end gap-1">
                                        <!-- View Profile -->
                                        <?php if (can('employees.view')): ?>
                                        <a href="<?= base_url('employees/profile/' . $e['id']) ?>" 
                                           class="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 transition" 
                                           title="View 360° Profile">
                                            <i data-lucide="eye" class="w-4 h-4"></i>
                                        </a>
                                        <?php endif; ?>

                                        <!-- Confirm Status (if probationary) -->
                                        <?php if ($status === \App\Models\EmployeeModel::STATUS_PROBATION && can('employees.probation')): ?>
                                            <button type="button" 
                                                    @click="openActionModal({ id: '<?= esc($e['id'], 'js') ?>', full_name: '<?= esc($empName, 'js') ?>', employee_code: '<?= esc($e['employee_code'] ?? '', 'js') ?>', designation_id: '<?= esc($e['designation_id'] ?? '', 'js') ?>', branch_id: '<?= esc($e['branch_id'] ?? '', 'js') ?>' }, 'confirm')"
                                                    class="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 transition" 
                                                    title="Confirm Employee Status">
                                                <i data-lucide="user-check" class="w-4 h-4"></i>
                                            </button>
                                        <?php endif; ?>

                                        <!-- Promote / Transfer -->
                                        <?php if (can('employees.movement')): ?>
                                        <button type="button" 
                                                @click="openActionModal({ id: '<?= esc($e['id'], 'js') ?>', full_name: '<?= esc($empName, 'js') ?>', employee_code: '<?= esc($e['employee_code'] ?? '', 'js') ?>', designation_id: '<?= esc($e['designation_id'] ?? '', 'js') ?>', branch_id: '<?= esc($e['branch_id'] ?? '', 'js') ?>' }, 'promote')"
                                                class="p-1.5 rounded-lg text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 transition" 
                                                title="Promote & Transfer">
                                            <i data-lucide="arrow-left-right" class="w-4 h-4"></i>
                                        </button>
                                        <?php endif; ?>

                                        <!-- Resign / Terminate -->
                                        <?php if ($status !== \App\Models\EmployeeModel::STATUS_TERMINATED && $status !== \App\Models\EmployeeModel::STATUS_RESIGNED && can('employees.separate')): ?>
                                            <button type="button" 
                                                    @click="openActionModal({ id: '<?= esc($e['id'], 'js') ?>', full_name: '<?= esc($empName, 'js') ?>', employee_code: '<?= esc($e['employee_code'] ?? '', 'js') ?>', designation_id: '<?= esc($e['designation_id'] ?? '', 'js') ?>', branch_id: '<?= esc($e['branch_id'] ?? '', 'js') ?>' }, 'resign')"
                                                    class="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition" 
                                                    title="Process Resignation / Termination">
                                                <i data-lucide="user-minus" class="w-4 h-4"></i>
                                            </button>
                                        <?php endif; ?>

                                        <!-- Edit Modal Trigger -->
                                        <?php if (can('employees.edit')): ?>
                                        <button type="button" 
                                                @click="openEditModal('<?= esc($e['id'], 'js') ?>')" 
                                                class="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 transition" 
                                                title="Edit Personnel File">
                                            <i data-lucide="edit-3" class="w-4 h-4"></i>
                                        </button>
                                        <?php endif; ?>

                                        <!-- Delete Button & Form -->
                                        <?php if (can('directory.delete') || can('employees.delete') || can('employees.manage')): ?>
                                        <form method="POST" 
                                              action="<?= base_url('employees/delete/' . $e['id']) ?>" 
                                              onsubmit="return confirm('Delete employee <?= esc($empName, 'js') ?> (<?= esc($e['employee_code'] ?? $e['id'], 'js') ?>)? The record will be soft-deleted and the linked login deactivated. Deletion is blocked if payroll, attendance, loans or settlements exist.');"
                                              class="inline-block">
                                            <?= csrf_field() ?>
                                            <button type="submit" 
                                                    class="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition" 
                                                    title="Delete Record">
                                                <i data-lucide="trash-2" class="w-4 h-4"></i>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Server-side Pagination Footer -->
        <?php
        $currentPage = (int)($pagination['page'] ?? 1);
        $totalPages = (int)($pagination['total_pages'] ?? 1);
        $totalRecords = (int)($pagination['total'] ?? count($employees ?? []));
        $perPage = (int)($pagination['per_page'] ?? 25);
        $fromRecord = $totalRecords > 0 ? (($currentPage - 1) * $perPage) + 1 : 0;
        $toRecord = min($totalRecords, $currentPage * $perPage);

        $buildPageUrl = function($p) use ($perPage) {
            $params = $_GET;
            $params['page'] = $p;
            $params['per_page'] = $perPage;
            return base_url('employees') . '?' . http_build_query($params);
        };
        ?>
        <div class="px-6 py-4 border-t border-slate-100 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/50 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div class="flex items-center gap-4 text-xs text-slate-500 dark:text-slate-400">
                <div>
                    Showing <span class="font-bold text-slate-700 dark:text-slate-200"><?= $fromRecord ?></span> to 
                    <span class="font-bold text-slate-700 dark:text-slate-200"><?= $toRecord ?></span> of 
                    <span class="font-bold text-slate-700 dark:text-slate-200"><?= $totalRecords ?></span> employees
                </div>
                <div class="flex items-center gap-1.5 border-l border-slate-200 dark:border-slate-700 pl-4">
                    <span class="text-[11px] text-slate-400">Per page:</span>
                    <select onchange="const url = new URL(window.location.href); url.searchParams.set('per_page', this.value); url.searchParams.set('page', 1); window.location.href = url.toString();" 
                            class="px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-semibold text-slate-700 dark:text-slate-200">
                        <?php foreach ([10, 25, 50, 100] as $sz): ?>
                            <option value="<?= $sz ?>" <?= $perPage === $sz ? 'selected' : '' ?>><?= $sz ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <?php if ($totalPages > 1): ?>
            <div class="flex items-center gap-1">
                <?php if ($currentPage > 1): ?>
                    <a href="<?= $buildPageUrl($currentPage - 1) ?>" class="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 transition" title="Previous Page">
                        <i data-lucide="chevron-left" class="w-4 h-4"></i>
                    </a>
                <?php else: ?>
                    <span class="p-2 rounded-xl text-slate-300 dark:text-slate-600 border border-slate-100 dark:border-slate-800 cursor-not-allowed">
                        <i data-lucide="chevron-left" class="w-4 h-4"></i>
                    </span>
                <?php endif; ?>

                <?php
                $startPage = max(1, $currentPage - 2);
                $endPage = min($totalPages, $currentPage + 2);
                if ($startPage > 1): ?>
                    <a href="<?= $buildPageUrl(1) ?>" class="px-3 py-1.5 rounded-xl text-xs font-semibold border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300">1</a>
                    <?php if ($startPage > 2): ?><span class="px-1 text-slate-400">...</span><?php endif; ?>
                <?php endif; ?>

                <?php for ($p = $startPage; $p <= $endPage; $p++): ?>
                    <?php if ($p === $currentPage): ?>
                        <span class="px-3 py-1.5 rounded-xl text-xs font-bold bg-indigo-600 text-white shadow-xs"><?= $p ?></span>
                    <?php else: ?>
                        <a href="<?= $buildPageUrl($p) ?>" class="px-3 py-1.5 rounded-xl text-xs font-semibold border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300"><?= $p ?></a>
                    <?php endif; ?>
                <?php endfor; ?>

                <?php if ($endPage < $totalPages): ?>
                    <?php if ($endPage < $totalPages - 1): ?><span class="px-1 text-slate-400">...</span><?php endif; ?>
                    <a href="<?= $buildPageUrl($totalPages) ?>" class="px-3 py-1.5 rounded-xl text-xs font-semibold border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300"><?= $totalPages ?></a>
                <?php endif; ?>

                <?php if ($currentPage < $totalPages): ?>
                    <a href="<?= $buildPageUrl($currentPage + 1) ?>" class="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 transition" title="Next Page">
                        <i data-lucide="chevron-right" class="w-4 h-4"></i>
                    </a>
                <?php else: ?>
                    <span class="p-2 rounded-xl text-slate-300 dark:text-slate-600 border border-slate-100 dark:border-slate-800 cursor-not-allowed">
                        <i data-lucide="chevron-right" class="w-4 h-4"></i>
                    </span>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ============================================================= -->
    <!-- VIEW 2: HEADCOUNT & PAYROLL ANALYTICS -->
    <!-- ============================================================= -->
    <div x-show="activeView === 'analytics'" class="space-y-6">
        <!-- Analytics Top Metrics -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div class="bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700 rounded-2xl p-5 shadow-xs">
                <span class="text-xs font-bold text-slate-400 uppercase tracking-wider block">Active Headcount</span>
                <div class="flex items-baseline gap-2 mt-2">
                    <span class="text-2xl font-extrabold text-slate-800 dark:text-white"><?= $activeCount ?></span>
                    <span class="text-xs text-slate-500">/ <?= $totalEmployees ?> total staff</span>
                </div>
            </div>

            <div class="bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700 rounded-2xl p-5 shadow-xs">
                <span class="text-xs font-bold text-slate-400 uppercase tracking-wider block">Probationary Staff</span>
                <div class="flex items-baseline gap-2 mt-2">
                    <span class="text-2xl font-extrabold text-amber-600"><?= $probationCount ?></span>
                    <span class="text-xs text-slate-500">under evaluation</span>
                </div>
            </div>

            <div class="bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700 rounded-2xl p-5 shadow-xs">
                <span class="text-xs font-bold text-slate-400 uppercase tracking-wider block">Active Departments</span>
                <div class="flex items-baseline gap-2 mt-2">
                    <span class="text-2xl font-extrabold text-indigo-600 dark:text-indigo-400"><?= esc($totalDepts ?? count($departments ?? [])) ?></span>
                    <span class="text-xs text-slate-500">operational units</span>
                </div>
            </div>

            <div class="bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700 rounded-2xl p-5 shadow-xs">
                <span class="text-xs font-bold text-slate-400 uppercase tracking-wider block">Base Monthly Commitment</span>
                <div class="flex items-baseline gap-2 mt-2">
                    <?php if ($canViewSalary): ?>
                        <span class="text-2xl font-extrabold text-slate-800 dark:text-white"><?= !empty($currencyCode) ? esc($currencyCode) . ' ' : '' ?><?= number_format($totalSalary ?? 0, 0) ?></span>
                        <span class="text-xs text-slate-500">monthly basic</span>
                    <?php else: ?>
                        <span class="text-xl font-bold text-slate-400 italic">Protected</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Department Headcount & Payroll Allocation Matrix -->
        <div class="bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700 rounded-2xl shadow-xs overflow-hidden p-6">
            <h3 class="text-sm font-extrabold text-slate-800 dark:text-white mb-4 flex items-center gap-2">
                <i data-lucide="building-2" class="w-4 h-4 text-indigo-600 dark:text-indigo-400"></i>
                <span>Department Headcount & Payroll Allocation Matrix</span>
            </h3>
            
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse text-xs text-slate-600 dark:text-slate-300">
                    <thead>
                        <tr class="bg-slate-50 dark:bg-slate-900/50 border-b border-slate-100 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-bold">
                            <th class="p-3.5">Department Name</th>
                            <th class="p-3.5">Total Staff</th>
                            <th class="p-3.5">Active</th>
                            <th class="p-3.5">On Probation</th>
                            <th class="p-3.5">Monthly Basic Commitment</th>
                            <th class="p-3.5 text-right">Headcount Share</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-700/60">
                        <?php 
                        $analyticsDepts = $analytics['departments'] ?? [];
                        if (empty($analyticsDepts)): ?>
                            <tr><td colspan="6" class="p-4 text-center text-slate-400">No departmental data available.</td></tr>
                        <?php else:
                            foreach ($analyticsDepts as $dRow):
                                $dTotal = (int)($dRow['dept_total'] ?? 0);
                                $dActive = (int)($dRow['dept_active'] ?? 0);
                                $dProb = (int)($dRow['dept_probation'] ?? 0);
                                $dSalary = (float)($dRow['dept_salary'] ?? 0);
                                $pct = $totalEmployees > 0 ? round(($dTotal / $totalEmployees) * 100) : 0;
                        ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30 transition">
                                <td class="p-3.5 font-bold text-slate-800 dark:text-white flex items-center gap-2">
                                    <span class="w-2 h-2 rounded-full bg-indigo-500"></span>
                                    <span><?= esc($dRow['department_name'] ?? 'Unassigned') ?></span>
                                </td>
                                <td class="p-3.5 font-bold text-slate-800 dark:text-white"><?= $dTotal ?> members</td>
                                <td class="p-3.5 text-emerald-600 font-semibold"><?= $dActive ?></td>
                                <td class="p-3.5 text-amber-600 font-semibold"><?= $dProb ?></td>
                                <td class="p-3.5 font-mono font-bold text-slate-800 dark:text-white">
                                    <?php if ($canViewSalary): ?>
                                        <?= !empty($currencyCode) ? esc($currencyCode) . ' ' : '' ?><?= number_format($dSalary, 2) ?>
                                    <?php else: ?>
                                        <span class="text-slate-400 italic font-sans text-[11px]">Protected</span>
                                    <?php endif; ?>
                                </td>
                                <td class="p-3.5 text-right">
                                    <div class="flex items-center justify-end gap-2">
                                        <span class="font-mono text-slate-600 dark:text-slate-400 font-bold"><?= $pct ?>%</span>
                                        <div class="w-20 h-2 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                                            <div class="h-full bg-indigo-600 rounded-full" style="width: <?= $pct ?>%"></div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach;
                        endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- ============================================================= -->
    <!-- COMPREHENSIVE ADD EMPLOYEE MODAL (COMPANY ONBOARDING ENGINE) -->
    <!-- ============================================================= -->
    <template x-teleport="body">
        <div x-show="addModalOpen" 
             x-cloak 
             class="fixed inset-0 z-[1000] overflow-y-auto" 
             role="dialog" 
             aria-modal="true"
             @keydown.escape.window="addModalOpen = false"
             x-init="$watch('addModalOpen', val => {
                 if (val) {
                     if (window.ModalManager) window.ModalManager.lock();
                     $nextTick(() => {
                         $el.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex=\'-1\'])')?.focus();
                     });
                 } else {
                     if (window.ModalManager) window.ModalManager.unlock();
                 }
             })"
             @destroy="if (window.ModalManager) window.ModalManager.unlock()">
            <div class="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
                <div x-show="addModalOpen" 
                     x-transition:enter="ease-out duration-300"
                     x-transition:enter-start="opacity-0"
                     x-transition:enter-end="opacity-100"
                     x-transition:leave="ease-in duration-200"
                     x-transition:leave-start="opacity-100"
                     x-transition:leave-end="opacity-0"
                     class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity" 
                     @click="addModalOpen = false"></div>

            <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

            <div x-show="addModalOpen" 
                 x-transition:enter="ease-out duration-300"
                 x-transition:enter-start="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                 x-transition:enter-end="opacity-100 translate-y-0 sm:scale-100"
                 x-transition:leave="ease-in duration-200"
                 x-transition:leave-start="opacity-100 translate-y-0 sm:scale-100"
                 x-transition:leave-end="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                 class="inline-block align-bottom bg-white dark:bg-slate-800 rounded-3xl text-left overflow-hidden shadow-2xl transform transition-all sm:my-8 sm:align-middle sm:max-w-3xl w-full border border-slate-200 dark:border-slate-700">
                
                <div class="px-6 pt-6 pb-4 flex items-center justify-between border-b border-slate-100 dark:border-slate-700/60">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
                            <i data-lucide="building-2" class="w-5 h-5"></i>
                        </div>
                        <div>
                            <h3 class="text-base font-bold text-slate-900 dark:text-white">Register New Employee</h3>
                            <p class="text-xs text-slate-500 dark:text-slate-400">Company Onboarding Engine: Identity, Department, Shifts & Compensation</p>
                        </div>
                    </div>
                    <button type="button" @click="addModalOpen = false" class="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-700 transition">
                        <i data-lucide="x" class="w-4 h-4"></i>
                    </button>
                </div>

                <form action="<?= base_url('employees/store') ?>" method="POST" class="p-6 space-y-4 max-h-[75vh] overflow-y-auto custom-scrollbar">
                    <?= csrf_field() ?>

                    <!-- SECTION 1: TARGET COMPANY ENTITY -->
                    <div class="p-4 bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 rounded-2xl space-y-3">
                        <div class="flex items-center justify-between">
                            <label class="block text-xs font-bold text-indigo-950 dark:text-indigo-300 flex items-center gap-1.5">
                                <i data-lucide="building" class="w-4 h-4 text-indigo-600"></i>
                                Target Company Entity <span class="text-rose-500">*</span>
                            </label>
                            <span class="text-[11px] text-indigo-600 dark:text-indigo-400 font-medium">Scopes branch, department & shift master records</span>
                        </div>

                        <?php if (!empty($isSoftwareAdmin)): ?>
                            <select name="company_id" 
                                    x-model="newEmp.company_id" 
                                    @change="onModalCompanyChange()"
                                    class="w-full p-2.5 bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-800 rounded-xl font-bold text-slate-800 dark:text-white text-xs shadow-xs" 
                                    required>
                                <?php foreach ($companies as $c): ?>
                                    <option value="<?= esc($c['id']) ?>"><?= esc($c['name']) ?> (<?= esc($c['code'] ?? '') ?>) — <?= esc($c['currency'] ?? 'BDT') ?></option>
                                <?php endforeach; ?>
                            </select>
                        <?php else: ?>
                            <?php $curr = $companies[0] ?? ['id' => $userCompanyId ?? '', 'name' => 'Assigned Company']; ?>
                            <input type="hidden" name="company_id" value="<?= esc($curr['id']) ?>">
                            <div class="p-2.5 bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-800 rounded-xl font-bold text-slate-800 dark:text-white text-xs">
                                <?= esc($curr['name']) ?> (<?= esc($curr['code'] ?? '') ?>)
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- SECTION 2: IDENTITY & CONTACT -->
                    <div class="space-y-2 border-b border-slate-100 dark:border-slate-700/60 pb-4">
                        <h4 class="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">1. Identity & Contact Information</h4>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                            <div>
                                <div class="flex items-center justify-between mb-1">
                                    <label class="block font-semibold text-slate-700 dark:text-slate-300">Employee Code / ID:</label>
                                    <span x-show="isCheckingAvailability" class="text-[10px] font-mono text-slate-400">Checking...</span>
                                    <span x-show="!isCheckingAvailability && availabilityStatus === 'taken'" class="text-[10px] font-mono font-semibold text-rose-600 dark:text-rose-400" x-text="codeErrorMessage || 'Already exists in database!'"></span>
                                </div>
                                <div class="relative">
                                    <input type="text" name="employee_code" x-model="newEmp.employee_code" @blur="checkEmployeeCodeAvailability()" @input="onCodeInput()" class="w-full p-2.5 border rounded-xl font-mono uppercase bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500" :class="availabilityStatus === 'taken' ? 'border-rose-400 focus:ring-rose-500' : 'border-slate-200 dark:border-slate-700'" required>
                                    <div x-show="isCheckingAvailability" class="absolute right-3 top-2.5 text-slate-400 pointer-events-none">
                                        <svg class="animate-spin w-4 h-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">First Name <span class="text-rose-500">*</span>:</label>
                                <input type="text" name="first_name" x-model="newEmp.first_name" placeholder="e.g. Imran" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white bg-white dark:bg-slate-900" required>
                            </div>
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Last Name:</label>
                                <input type="text" name="last_name" x-model="newEmp.last_name" placeholder="e.g. Hasan" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white bg-white dark:bg-slate-900">
                            </div>
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Official Email <span class="text-rose-500">*</span>:</label>
                                <input type="email" name="email" x-model="newEmp.email" placeholder="user@company.com" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl font-mono text-slate-900 dark:text-white bg-white dark:bg-slate-900" required>
                            </div>
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Phone Number <span class="text-rose-500">*</span>:</label>
                                <input type="text" name="phone" x-model="newEmp.phone" placeholder="+880 1712-XXXXXX" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl font-mono text-slate-900 dark:text-white bg-white dark:bg-slate-900" required>
                            </div>
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">National ID / Passport:</label>
                                <input type="text" name="national_id" x-model="newEmp.national_id" placeholder="e.g. 1992837192" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl font-mono text-slate-900 dark:text-white bg-white dark:bg-slate-900">
                            </div>
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Date of Birth <span class="text-rose-500">*</span>:</label>
                                <input type="date" name="dob" x-model="newEmp.dob" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl font-mono text-slate-900 dark:text-white bg-white dark:bg-slate-900" :class="!newEmp.dob ? 'border-amber-300 dark:border-amber-700' : ''" required>
                                <span x-show="!newEmp.dob" class="text-[10px] text-rose-500 font-medium block mt-1">Date of birth is required.</span>
                            </div>
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Gender <span class="text-rose-500">*</span>:</label>
                                <select name="gender" x-model="newEmp.gender" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white bg-white dark:bg-slate-900" :class="!newEmp.gender ? 'border-amber-300 dark:border-amber-700' : ''" required>
                                    <option value="">Select Gender</option>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                    <option value="other">Other</option>
                                </select>
                                <span x-show="!newEmp.gender" class="text-[10px] text-rose-500 font-medium block mt-1">Gender selection is required.</span>
                            </div>
                        </div>
                    </div>

                    <!-- SECTION 3: COMPANY ALLOCATION & SHIFT SCHEDULE -->
                    <div class="space-y-2 border-b border-slate-100 dark:border-slate-700/60 pb-4">
                        <h4 class="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">2. Company Allocation & Shift Schedule</h4>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Branch Facility <span class="text-rose-500">*</span>:</label>
                                <select name="branch_id" x-model="newEmp.branch_id" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white" required>
                                    <option value="">Select Branch</option>
                                    <template x-for="b in modalFilteredBranches" :key="b.id">
                                        <option :value="b.id" x-text="b.name"></option>
                                    </template>
                                </select>
                            </div>
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Department <span class="text-rose-500">*</span>:</label>
                                <select name="department_id" x-model="newEmp.department_id" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white" required>
                                    <option value="">Select Department</option>
                                    <?php foreach ($departments as $d): ?>
                                        <option value="<?= esc($d['id']) ?>"><?= esc($d['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Designation <span class="text-rose-500">*</span>:</label>
                                <select name="designation_id" x-model="newEmp.designation_id" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white" required>
                                    <option value="">Select Designation</option>
                                    <?php foreach ($designations as $ds): ?>
                                        <option value="<?= esc($ds['id']) ?>"><?= esc($ds['name'] ?? $ds['title'] ?? '') ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs pt-1">
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Reporting Manager:</label>
                                <select name="reporting_manager_id" x-model="newEmp.reporting_manager_id" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                                    <option value="">-- No Direct Manager (Root) --</option>
                                    <?php foreach ($employees as $empM): ?>
                                        <option value="<?= esc($empM['id']) ?>"><?= esc($empM['full_name'] ?? $empM['first_name'] ?? $empM['id']) ?> (<?= esc($empM['employee_code'] ?? $empM['id']) ?>)</option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Shift Schedule <span class="text-rose-500">*</span>:</label>
                                <select name="shift_id" x-model="newEmp.shift_id" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white" required>
                                    <option value="">Select Shift</option>
                                    <?php foreach ($shifts as $s): ?>
                                        <option value="<?= esc($s['id']) ?>"><?= esc($s['name']) ?> (<?= esc($s['start_time']) ?>-<?= esc($s['end_time']) ?>)</option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                                    Employment Type <span class="text-rose-500">*</span>:
                                </label>
                                <select name="employment_type_id" x-model="newEmp.employment_type_id" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white" required>
                                    <option value="">Select Company Employment Type</option>
                                    <template x-for="et in modalFilteredEmploymentTypes" :key="et.id">
                                        <option :value="et.id" x-text="et.name + (et.code ? ' (' + et.code + ')' : '')"></option>
                                    </template>
                                </select>
                                <span class="text-[10px] text-indigo-500 font-medium block mt-0.5">
                                    Strictly scoped to selected company
                                </span>
                            </div>
                        </div>
                    </div>

                    <!-- SECTION 4: SALARY STRUCTURE & BANKING -->
                    <div class="space-y-2 border-b border-slate-100 dark:border-slate-700/60 pb-4">
                        <h4 class="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">3. Salary Structure & Banking</h4>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                            <div>
                                <div class="flex items-center justify-between mb-1">
                                    <label class="block font-semibold text-slate-700 dark:text-slate-300">Basic Monthly Salary ($ / BDT):</label>
                                    <a href="<?= base_url('payroll?tab=structures&subtab=assignment') ?>" target="_blank" class="text-[11px] text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-0.5">
                                        <span>Assignments</span>
                                        <i data-lucide="external-link" class="w-3 h-3"></i>
                                    </a>
                                </div>
                                <input type="number" step="0.01" min="0" name="basic_salary" x-model="newEmp.basic_salary" placeholder="e.g. 35000" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl font-mono text-slate-900 dark:text-white bg-white dark:bg-slate-900 focus:ring-2 focus:ring-indigo-500">
                                <span class="text-[10px] text-slate-400 mt-1 block">Initial monthly base compensation.</span>
                            </div>
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Provident Fund ID (PF):</label>
                                <input type="text" name="pf_member_id" x-model="newEmp.pf_member_id" :placeholder="'e.g. ' + (config.pfPrefix || 'PF-') + '009'" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl font-mono text-slate-900 dark:text-white bg-white dark:bg-slate-900">
                            </div>
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Tax ID Number (TIN):</label>
                                <input type="text" name="tax_identification_number" x-model="newEmp.tax_identification_number" placeholder="e.g. TIN-9283710291" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl font-mono text-slate-900 dark:text-white bg-white dark:bg-slate-900">
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs pt-1">
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Disbursement Bank Name <span class="text-rose-500">*</span>:</label>
                                <input type="text" name="bank_name" x-model="newEmp.bank_name" placeholder="e.g. City Bank PLC" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white bg-white dark:bg-slate-900" required>
                            </div>
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Bank Account / IBAN <span class="text-rose-500">*</span>:</label>
                                <input type="text" name="bank_account" x-model="newEmp.bank_account" placeholder="1203XXXXXXXXX" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl font-mono text-slate-900 dark:text-white bg-white dark:bg-slate-900" required>
                            </div>
                        </div>
                    </div>

                    <!-- SECTION 5: LOGIN CREDENTIALS PROVISIONING -->
                    <div class="p-4 bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 rounded-2xl space-y-2">
                        <div class="flex items-center justify-between">
                            <h4 class="text-xs font-bold text-slate-800 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                                <i data-lucide="key" class="w-4 h-4 text-indigo-600"></i>
                                4. System Login & Access Credentials
                            </h4>
                            <span class="px-2 py-0.5 bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-400 rounded text-[10px] font-bold">Auto-Provisioned</span>
                        </div>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1">
                            <div class="bg-white dark:bg-slate-800 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                                <span class="text-[10px] text-slate-400 font-bold uppercase block">Default Username</span>
                                <span class="font-mono font-bold text-slate-700 dark:text-slate-200 text-xs truncate block mt-0.5" 
                                      x-text="newEmp.email ? newEmp.email.split('@')[0] : (newEmp.first_name ? newEmp.first_name.toLowerCase() : 'auto.generated')">
                                </span>
                            </div>
                            <div class="bg-white dark:bg-slate-800 p-3 rounded-xl border border-indigo-200 dark:border-indigo-800 bg-indigo-50/30">
                                <span class="text-[10px] text-indigo-500 font-bold uppercase block">Login Password</span>
                                <span class="text-slate-500 dark:text-slate-400 text-xs block mt-0.5 italic">
                                    Managed securely by system policy
                                </span>
                            </div>
                        </div>
                        <p class="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1.5 pt-1">
                            <i data-lucide="shield-check" class="w-3.5 h-3.5 text-emerald-600"></i>
                            Employee credentials are securely auto-provisioned upon addition.
                        </p>
                    </div>

                    <div class="pt-4 flex items-center justify-end gap-3 border-t border-slate-100 dark:border-slate-700/60">
                        <button type="button" @click="addModalOpen = false" class="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer">
                            Cancel
                        </button>
                        <button type="submit" class="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm transition flex items-center gap-2 cursor-pointer">
                            <i data-lucide="plus" class="w-4 h-4"></i>
                            <span>Register Employee</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </template>

    <!-- ============================================================= -->
    <!-- COMPREHENSIVE EDIT EMPLOYEE MODAL -->
    <!-- ============================================================= -->
    <template x-teleport="body">
        <div x-show="editModalOpen" 
             x-cloak 
             class="fixed inset-0 z-[1000] overflow-y-auto" 
             role="dialog" 
             aria-modal="true"
             @keydown.escape.window="editModalOpen = false"
             x-init="$watch('editModalOpen', val => {
                 if (val) {
                     if (window.ModalManager) window.ModalManager.lock();
                     $nextTick(() => {
                         $el.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex=\'-1\'])')?.focus();
                     });
                 } else {
                     if (window.ModalManager) window.ModalManager.unlock();
                 }
             })"
             @destroy="if (window.ModalManager) window.ModalManager.unlock()">
            <div class="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
                <div x-show="editModalOpen" 
                     x-transition:enter="ease-out duration-300"
                     x-transition:enter-start="opacity-0"
                     x-transition:enter-end="opacity-100"
                 x-transition:leave="ease-in duration-200"
                 x-transition:leave-start="opacity-100"
                 x-transition:leave-end="opacity-0"
                 class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity" 
                 @click="editModalOpen = false"></div>

            <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

            <div x-show="editModalOpen" 
                 x-transition:enter="ease-out duration-300"
                 x-transition:enter-start="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                 x-transition:enter-end="opacity-100 translate-y-0 sm:scale-100"
                 x-transition:leave="ease-in duration-200"
                 x-transition:leave-start="opacity-100 translate-y-0 sm:scale-100"
                 x-transition:leave-end="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                 class="inline-block align-bottom bg-white dark:bg-slate-800 rounded-3xl text-left overflow-hidden shadow-2xl transform transition-all sm:my-8 sm:align-middle sm:max-w-2xl w-full border border-slate-200 dark:border-slate-700">
                
                <div class="px-6 pt-6 pb-4 flex items-center justify-between border-b border-slate-100 dark:border-slate-700/60">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
                            <i data-lucide="user-cog" class="w-5 h-5"></i>
                        </div>
                        <div>
                            <h3 class="text-base font-bold text-slate-900 dark:text-white">Edit Employee File</h3>
                            <p class="text-xs text-slate-500 dark:text-slate-400" x-text="'Updating ' + (editData.full_name || editData.first_name || 'Staff Record')"></p>
                        </div>
                    </div>
                    <button type="button" @click="editModalOpen = false" class="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-700 transition">
                        <i data-lucide="x" class="w-4 h-4"></i>
                    </button>
                </div>

                <div x-show="isLoadingEdit" class="p-12 text-center text-slate-500 dark:text-slate-400">
                    <div class="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mb-3"></div>
                    <p class="text-xs">Loading employee details...</p>
                </div>

                <form x-show="!isLoadingEdit" :action="'<?= base_url('employees/update') ?>/' + (editData.id || '')" method="POST" class="p-6 space-y-4 max-h-[75vh] overflow-y-auto custom-scrollbar">
                    <?= csrf_field() ?>

                    <div class="space-y-4">
                        <!-- Section 1: Personal & Identity -->
                        <div class="border-b border-slate-100 dark:border-slate-700/60 pb-3">
                            <h4 class="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider mb-3">1. Personal & Identity Specs</h4>
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">First Name *</label>
                                    <input type="text" name="first_name" x-model="editData.first_name" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Last Name</label>
                                    <input type="text" name="last_name" x-model="editData.last_name" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Employee Code *</label>
                                    <input type="text" name="employee_code" x-model="editData.employee_code" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono uppercase text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Email Address *</label>
                                    <input type="email" name="email" x-model="editData.email" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Phone Number</label>
                                    <input type="text" name="phone" x-model="editData.phone" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                                </div>
                                <div x-show="editData.can_view_sensitive">
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">National ID / Passport</label>
                                    <input type="text" name="national_id" x-model="editData.national_id" :disabled="!editData.can_view_sensitive" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                                </div>
                            </div>
                        </div>

                        <!-- Section 2: Department, Role & Placement -->
                        <div class="border-b border-slate-100 dark:border-slate-700/60 pb-3">
                            <h4 class="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider mb-3">2. Department, Role & Rostering</h4>
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Department *</label>
                                    <select name="department_id" x-model="editData.department_id" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                                        <option value="">Select Department</option>
                                        <?php foreach ($departments as $d): ?>
                                            <option value="<?= esc($d['id']) ?>"><?= esc($d['name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Designation / Role *</label>
                                    <select name="designation_id" x-model="editData.designation_id" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                                        <option value="">Select Designation</option>
                                        <?php foreach ($designations as $ds): ?>
                                            <option value="<?= esc($ds['id']) ?>"><?= esc($ds['name'] ?? $ds['title'] ?? '') ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Branch / Location *</label>
                                    <select name="branch_id" x-model="editData.branch_id" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                                        <option value="">Select Branch</option>
                                        <?php foreach ($branches as $b): ?>
                                            <option value="<?= esc($b['id']) ?>"><?= esc($b['name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Shift Timing Schedule *</label>
                                    <select name="shift_id" x-model="editData.shift_id" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                                        <option value="">Select Shift</option>
                                        <?php foreach ($shifts as $s): ?>
                                            <option value="<?= esc($s['id']) ?>"><?= esc($s['name']) ?> (<?= esc($s['start_time']) ?> - <?= esc($s['end_time']) ?>)</option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Section 3: Compensation & Employment Status -->
                        <div>
                            <h4 class="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider mb-3">3. Compensation & Status</h4>
                            <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                                <div x-show="editData.can_view_salary">
                                    <div class="flex items-center justify-between mb-1">
                                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300">Base Monthly Salary ($)</label>
                                        <a :href="'<?= base_url('employees/profile') ?>/' + editData.id + '?tab=payroll'" target="_blank" class="text-[11px] text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-0.5">
                                            <span>Assign Details</span>
                                            <i data-lucide="external-link" class="w-3 h-3"></i>
                                        </a>
                                    </div>
                                    <input type="number" step="0.01" min="0" name="basic_salary" x-model="editData.basic_salary" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                                    <span class="text-[10px] text-slate-400 mt-0.5 block">Monthly basic compensation (saved directly to profile).</span>
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Employment Type</label>
                                    <select name="employment_type_id" x-model="editData.employment_type_id" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                                        <option value="">Select Contract Type</option>
                                        <?php foreach ($employmentTypes as $et): ?>
                                            <option value="<?= esc($et['id']) ?>"><?= esc($et['name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Account State *</label>
                                    <select name="status" x-model="editData.status" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                                        <?php foreach (\App\Models\EmployeeModel::STATUS_LABELS as $sVal => $sLabel): ?>
                                            <option value="<?= esc($sVal) ?>"><?= esc($sLabel) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="pt-4 flex items-center justify-end gap-3 border-t border-slate-100 dark:border-slate-700/60">
                        <button type="button" @click="editModalOpen = false" class="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer">
                            Cancel
                        </button>
                        <button type="submit" class="px-5 py-2 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm transition flex items-center gap-2 cursor-pointer">
                            <i data-lucide="check" class="w-4 h-4"></i>
                            <span>Save Changes</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </template>

    <!-- ============================================================= -->
    <!-- ACTION (PROMOTE / CONFIRM / RESIGN) MODAL -->
    <!-- ============================================================= -->
    <template x-teleport="body">
        <div x-show="actionModalOpen" 
             x-cloak 
             class="fixed inset-0 z-[1000] overflow-y-auto" 
             role="dialog" 
             aria-modal="true"
             @keydown.escape.window="actionModalOpen = false"
             x-init="$watch('actionModalOpen', val => {
                 if (val) {
                     if (window.ModalManager) window.ModalManager.lock();
                     $nextTick(() => {
                         $el.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex=\'-1\'])')?.focus();
                     });
                 } else {
                     if (window.ModalManager) window.ModalManager.unlock();
                 }
             })"
             @destroy="if (window.ModalManager) window.ModalManager.unlock()">
            <div class="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
                <div x-show="actionModalOpen" 
                     x-transition:enter="ease-out duration-300"
                     x-transition:enter-start="opacity-0"
                     x-transition:enter-end="opacity-100"
                 x-transition:leave="ease-in duration-200"
                 x-transition:leave-start="opacity-100"
                 x-transition:leave-end="opacity-0"
                 class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity" 
                 @click="actionModalOpen = false"></div>

            <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

            <div x-show="actionModalOpen" 
                 x-transition:enter="ease-out duration-300"
                 x-transition:enter-start="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                 x-transition:enter-end="opacity-100 translate-y-0 sm:scale-100"
                 x-transition:leave="ease-in duration-200"
                 x-transition:leave-start="opacity-100 translate-y-0 sm:scale-100"
                 x-transition:leave-end="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                 class="inline-block align-bottom bg-white dark:bg-slate-800 rounded-3xl text-left overflow-hidden shadow-2xl transform transition-all sm:my-8 sm:align-middle sm:max-w-md w-full border border-slate-200 dark:border-slate-700">
                
                <div class="p-6 space-y-4">
                    <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700/60">
                        <h3 class="text-base font-bold text-slate-800 dark:text-white uppercase tracking-wide" 
                            x-text="actionType === 'confirm' ? 'Confirm Employee Status' : (actionType === 'resign' ? 'Process Resignation / Termination' : 'Promote & Transfer Employee')">
                        </h3>
                        <button type="button" @click="actionModalOpen = false" class="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg">
                            <i data-lucide="x" class="w-4 h-4"></i>
                        </button>
                    </div>

                    <p class="text-xs text-slate-500 dark:text-slate-400">
                        Are you sure you want to perform this operation on employee <strong class="text-slate-800 dark:text-white" x-text="(actionEmp.full_name || actionEmp.first_name || 'Staff') + ' (' + (actionEmp.employee_code || actionEmp.id) + ')'"></strong>?
                    </p>

                    <!-- PROMOTE FORM -->
                    <template x-if="actionType === 'promote'">
                        <div class="space-y-3.5 text-xs">
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">New Designation:</label>
                                <select x-model="promoDesg" class="w-full p-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                                    <?php foreach ($designations as $dg): ?>
                                        <option value="<?= esc($dg['id']) ?>"><?= esc($dg['name'] ?? $dg['title'] ?? '') ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">New Branch Location:</label>
                                <select x-model="promoBranch" class="w-full p-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                                    <?php foreach ($branches as $b): ?>
                                        <option value="<?= esc($b['id']) ?>"><?= esc($b['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div>
                                <div class="flex items-center justify-between mb-1">
                                    <label class="block font-semibold text-slate-700 dark:text-slate-300">New Basic Monthly Salary ($):</label>
                                    <a :href="'<?= base_url('employees/profile') ?>/' + (actionEmp ? actionEmp.id : '') + '?tab=payroll'" target="_blank" class="text-[11px] text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-0.5">
                                        <span>Assignment Tab</span>
                                        <i data-lucide="external-link" class="w-3 h-3"></i>
                                    </a>
                                </div>
                                <input type="number" step="0.01" x-model="promoSalary" class="w-full p-2 border border-slate-200 dark:border-slate-700 rounded-xl font-mono text-slate-900 dark:text-white bg-white dark:bg-slate-900">
                                <span class="text-[10px] text-slate-400 mt-0.5 block">Syncs via EmployeeSalaryService::assignSalary</span>
                            </div>
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Reason / Promotion Memo:</label>
                                <input type="text" x-model="actionReason" placeholder="e.g. Annual Performance Evaluation" class="w-full p-2 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white bg-white dark:bg-slate-900">
                            </div>
                        </div>
                    </template>

                    <!-- RESIGN / TERMINATE FORM -->
                    <template x-if="actionType === 'resign'">
                        <div class="space-y-3.5 text-xs">
                            <div class="grid grid-cols-2 gap-3">
                                <div>
                                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Termination Type <span class="text-rose-500">*</span>:</label>
                                    <select x-model="terminationType" name="termination_type" class="w-full p-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                                        <option value="Resignation">Resignation</option>
                                        <option value="Termination">Termination</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Termination Date <span class="text-rose-500">*</span>:</label>
                                    <input type="date" x-model="terminationDate" name="termination_date" class="w-full p-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white" required>
                                </div>
                            </div>
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Separation Reason / Remarks <span class="text-rose-500">*</span>:</label>
                                <textarea x-model="actionReason" rows="3" placeholder="e.g. Career Transition / Resignation submitted" class="w-full p-2 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white bg-white dark:bg-slate-900" required></textarea>
                            </div>
                        </div>
                    </template>

                    <div class="flex gap-2 pt-4 border-t border-slate-100 dark:border-slate-700/60 justify-end">
                        <button type="button" @click="actionModalOpen = false" class="px-4 py-2 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold transition cursor-pointer">
                            Cancel
                        </button>
                        <button type="button" 
                                @click="submitLifecycleAction()"
                                :disabled="isSubmittingAction"
                                class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition cursor-pointer">
                            <span x-text="isSubmittingAction ? 'Processing...' : 'Confirm Changes'"></span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </template>

    <!-- Floating Sticky Bulk Action Bar -->
    <div x-show="selectedEmployees.length > 0"
         x-cloak
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0 translate-y-4"
         x-transition:enter-end="opacity-100 translate-y-0"
         x-transition:leave="transition ease-in duration-150"
         x-transition:leave-start="opacity-100 translate-y-0"
         x-transition:leave-end="opacity-0 translate-y-4"
         class="fixed bottom-6 inset-x-0 z-40 max-w-2xl mx-auto px-4 pointer-events-auto">
        <div class="bg-slate-900 dark:bg-slate-800 text-white rounded-2xl p-4 shadow-2xl border border-slate-700 flex flex-wrap items-center justify-between gap-3">
            <div class="flex items-center gap-2.5">
                <span class="w-7 h-7 rounded-xl bg-indigo-600 flex items-center justify-center font-bold text-xs" x-text="selectedEmployees.length"></span>
                <span class="text-xs font-semibold text-slate-200">employee(s) selected</span>
            </div>
            <div class="flex items-center gap-2">
                <button type="button" @click="openBulkPfModal('assign')" class="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer">
                    <i data-lucide="shield-check" class="w-3.5 h-3.5"></i>
                    <span>Assign PF Scheme</span>
                </button>
                <button type="button" @click="executeBulkPfAction('exempt')" class="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer">
                    <i data-lucide="shield-alert" class="w-3.5 h-3.5"></i>
                    <span>Exempt</span>
                </button>
                <button type="button" @click="executeBulkPfAction('remove')" class="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer">
                    <i data-lucide="shield-off" class="w-3.5 h-3.5"></i>
                    <span>Remove</span>
                </button>
                <button type="button" @click="selectedEmployees = []" class="px-2.5 py-1.5 text-slate-400 hover:text-white text-xs font-medium transition cursor-pointer">
                    Cancel
                </button>
            </div>
        </div>
    </div>

    <!-- Bulk PF Assignment Modal -->
    <template x-teleport="body">
        <div x-show="showBulkPfModal"
             x-cloak
             role="dialog"
             aria-modal="true"
             aria-labelledby="bulk-pf-modal-title"
             @keydown.escape.window="if (!isSubmittingBulkPf) { showBulkPfModal = false; }"
             class="fixed inset-0 z-[1000] flex items-center justify-center p-2 md:p-4 bg-slate-900/70 backdrop-blur-xs transition-opacity"
             @click.self="if (!isSubmittingBulkPf) { showBulkPfModal = false; }"
             x-init="$watch('showBulkPfModal', val => {
                 if (val) {
                     if (window.ModalManager) window.ModalManager.lock();
                     $nextTick(() => {
                         $el.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex=\'-1\'])')?.focus();
                     });
                 } else {
                     if (window.ModalManager) window.ModalManager.unlock();
                 }
             })"
             @destroy="if (window.ModalManager) window.ModalManager.unlock()">
            <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-lg w-[calc(100vw-1rem)] md:w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-700 space-y-5"
                 @click.stop>
                <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                    <div class="flex items-center gap-2">
                        <div class="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
                            <i data-lucide="shield-check" class="w-4 h-4"></i>
                        </div>
                        <div>
                            <h3 id="bulk-pf-modal-title" class="font-bold text-slate-900 dark:text-white text-sm">Bulk Assign Provident Fund Policy</h3>
                            <p class="text-xs text-slate-500">Applying to <strong x-text="selectedEmployees.length"></strong> selected personnel</p>
                        </div>
                    </div>
                    <button type="button" @click="showBulkPfModal = false" class="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                        <i data-lucide="x" class="w-5 h-5"></i>
                    </button>
                </div>

                <div class="space-y-4 text-xs">
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Select Policy Scheme</label>
                        <select x-model="bulkPfData.rule_id" @change="onBulkSchemeChange()" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                            <option value="">Standard Company PF Policy</option>
                            <template x-for="r in pfRules" :key="r.id">
                                <option :value="r.id" x-text="r.rule_name"></option>
                            </template>
                        </select>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Contribution Method</label>
                            <select x-model="bulkPfData.contribution_type" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                                <option value="Percentage">Percentage of Basic (%)</option>
                                <option value="Fixed">Fixed Monthly ($)</option>
                            </select>
                        </div>
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Effective Date</label>
                            <input type="date" x-model="bulkPfData.effective_date" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                        </div>
                    </div>

                    <template x-if="bulkPfData.contribution_type === 'Percentage'">
                        <div class="grid grid-cols-2 gap-3">
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Employee Rate (%)</label>
                                <input type="number" step="0.1" min="0" max="100" x-model.number="bulkPfData.employee_rate" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono">
                            </div>
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Employer Rate (%)</label>
                                <input type="number" step="0.1" min="0" max="100" x-model.number="bulkPfData.employer_rate" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono">
                            </div>
                        </div>
                    </template>

                    <template x-if="bulkPfData.contribution_type === 'Fixed'">
                        <div class="grid grid-cols-2 gap-3">
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Employee Monthly ($)</label>
                                <input type="number" step="1" min="0" x-model.number="bulkPfData.employee_fixed_amount" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono">
                            </div>
                            <div>
                                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Employer Monthly ($)</label>
                                <input type="number" step="1" min="0" x-model.number="bulkPfData.employer_fixed_amount" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono">
                            </div>
                        </div>
                    </template>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">HR Audit Notes</label>
                        <textarea x-model="bulkPfData.notes" rows="2" placeholder="Optional audit memo or board decision" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white"></textarea>
                    </div>
                </div>

                <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-700">
                    <button type="button" @click="showBulkPfModal = false" class="px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700">
                        Cancel
                    </button>
                    <button type="button" @click="submitBulkPfAssignment()" :disabled="isSubmittingBulkPf" class="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer">
                        <i data-lucide="check" class="w-4 h-4"></i>
                        <span x-text="isSubmittingBulkPf ? 'Applying...' : 'Apply to Selected (' + selectedEmployees.length + ')'"></span>
                    </button>
                </div>
            </div>
        </div>
    </template>

    <!-- ============================================================= -->
    <!-- MODAL 5: BULK UPLOAD EMPLOYEES WITH USERNAME & PASSWORD       -->
    <!-- ============================================================= -->
    <template x-teleport="body">
        <div x-show="bulkUploadModalOpen" 
             x-cloak 
             role="dialog" 
             aria-modal="true" 
             aria-labelledby="bulk-upload-modal-title"
             @keydown.escape.window="if (!isSubmittingBulkUpload) { bulkUploadModalOpen = false; }"
             class="fixed inset-0 z-[1000] flex items-center justify-center p-2 md:p-4 bg-slate-900/70 backdrop-blur-xs transition-opacity"
             @click.self="if (!isSubmittingBulkUpload) { bulkUploadModalOpen = false; }"
             x-init="$watch('bulkUploadModalOpen', val => {
                 if (val) {
                     if (window.ModalManager) window.ModalManager.lock();
                     $nextTick(() => {
                         $el.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex=\'-1\'])')?.focus();
                     });
                 } else {
                     if (window.ModalManager) window.ModalManager.unlock();
                 }
             })"
             @destroy="if (window.ModalManager) window.ModalManager.unlock()">
            
            <div @click.stop
                 class="bg-white dark:bg-slate-850 rounded-2xl md:rounded-3xl border border-slate-200/90 dark:border-slate-700/80 shadow-2xl flex flex-col overflow-hidden transition-all w-[calc(100vw-1rem)] max-h-[calc(100vh-1rem)] md:w-[min(1100px,calc(100vw-2rem))] md:max-h-[calc(100vh-2rem)]">
                
                <!-- Modal Header (Fixed / Shrink-0) -->
                <div class="px-4 sm:px-6 py-3.5 sm:py-4 border-b border-slate-200/80 dark:border-slate-700/80 flex items-center justify-between bg-slate-50/80 dark:bg-slate-900/70 shrink-0">
                    <div class="flex items-center gap-3.5">
                        <div class="w-11 h-11 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white flex items-center justify-center shadow-md shadow-emerald-500/20 shrink-0">
                            <i data-lucide="file-spreadsheet" class="w-5 h-5"></i>
                        </div>
                        <div>
                            <div class="flex items-center gap-2">
                                <h3 id="bulk-upload-modal-title" class="text-base font-extrabold text-slate-900 dark:text-white tracking-tight">Bulk Employee Onboarding &amp; Provisioning</h3>
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-extrabold font-mono bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                                    XLS / CSV / Paste
                                </span>
                            </div>
                            <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Import staff rosters, auto-create missing departments/designations, and provision user credentials seamlessly</p>
                        </div>
                    </div>
                    <div class="flex items-center gap-2.5">
                        <a href="<?= base_url('employees/bulk-template') ?>" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 border border-emerald-200 dark:border-emerald-800 transition shadow-2xs">
                            <i data-lucide="download" class="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400"></i>
                            <span>Template (.csv)</span>
                        </a>
                        <button type="button" @click="if (!isSubmittingBulkUpload) { bulkUploadModalOpen = false; }" class="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer" aria-label="Close modal">
                            <i data-lucide="x" class="w-5 h-5"></i>
                        </button>
                    </div>
                </div>

                <!-- Modal Body (Scrollable, min-height: 0) -->
                <div class="p-4 sm:p-6 overflow-y-auto space-y-5 flex-1 min-h-0 custom-scrollbar">
                    <!-- Error / Status Alert Banner -->
                    <div x-show="bulkErrorMsg" class="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs font-semibold flex items-center justify-between shadow-2xs">
                        <div class="flex items-center gap-2.5">
                            <i data-lucide="alert-circle" class="w-4 h-4 shrink-0 text-rose-600 dark:text-rose-400"></i>
                            <span x-text="bulkErrorMsg"></span>
                        </div>
                        <button type="button" @click="bulkErrorMsg = ''" class="text-rose-500 hover:text-rose-700 text-xs font-bold cursor-pointer">Dismiss</button>
                    </div>

                    <!-- STEP 1: Configuration & Input Source (Hidden when showing final results) -->
                    <div x-show="!bulkUploadResult" class="space-y-4">
                        
                        <!-- Top Source Mode Segmented Tabs -->
                        <div class="flex flex-wrap items-center justify-between gap-3">
                            <div class="inline-flex p-1 bg-slate-100 dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-700/80">
                                <button type="button" 
                                        @click="bulkInputMode = 'file'" 
                                        :class="bulkInputMode === 'file' ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-xs font-bold' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 font-semibold'" 
                                        class="flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs transition cursor-pointer">
                                    <i data-lucide="upload-cloud" class="w-3.5 h-3.5"></i>
                                    <span>1. Upload Spreadsheet File</span>
                                </button>
                                <button type="button" 
                                        @click="bulkInputMode = 'paste'" 
                                        :class="bulkInputMode === 'paste' ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-xs font-bold' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 font-semibold'" 
                                        class="flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs transition cursor-pointer">
                                    <i data-lucide="clipboard-paste" class="w-3.5 h-3.5"></i>
                                    <span>2. Paste from Clipboard</span>
                                </button>
                                <button type="button" 
                                        @click="bulkInputMode = 'demo'" 
                                        :class="bulkInputMode === 'demo' ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-xs font-bold' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 font-semibold'" 
                                        class="flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs transition cursor-pointer">
                                    <i data-lucide="sparkles" class="w-3.5 h-3.5 text-amber-500"></i>
                                    <span>3. Demo Sample Data</span>
                                </button>
                            </div>

                            <!-- Quick file status indicator if loaded -->
                            <div x-show="bulkUploadedFileName" class="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-[11px] font-semibold text-emerald-700 dark:text-emerald-300">
                                <i data-lucide="check" class="w-3.5 h-3.5 text-emerald-600"></i>
                                <span class="truncate max-w-[240px]" x-text="'Loaded: ' + bulkUploadedFileName"></span>
                            </div>
                        </div>

                        <!-- Input Mode Panel 1: File Upload Dropzone -->
                        <div x-show="bulkInputMode === 'file'" class="relative p-6 rounded-2xl border-2 border-dashed border-indigo-200 dark:border-indigo-800/80 bg-gradient-to-b from-indigo-50/40 to-slate-50/30 dark:from-indigo-950/20 dark:to-slate-900/20 hover:border-indigo-400 dark:hover:border-indigo-600 transition flex flex-col items-center justify-center text-center group">
                            <input type="file" 
                                   accept=".xlsx,.xls,.csv,.tsv,.txt" 
                                   @change="handleBulkFileUpload($event)" 
                                   class="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10">
                            <div class="w-12 h-12 rounded-2xl bg-indigo-100 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mb-2.5 group-hover:scale-105 transition-transform shadow-xs">
                                <i data-lucide="upload-cloud" class="w-6 h-6"></i>
                            </div>
                            <h4 class="text-sm font-bold text-slate-800 dark:text-white">
                                Choose an Excel (.xlsx / .xls) or CSV file, or drag and drop here
                            </h4>
                            <p class="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xl">
                                Auto-maps columns: <span class="font-mono text-[11px] text-indigo-600 dark:text-indigo-400 font-semibold">Employee Name, ID, Phone, Email, Designation, Department, Join Date, Emp Type, DOB, Gender</span>
                            </p>
                            <div class="mt-3.5 flex items-center gap-2">
                                <span class="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 shadow-2xs group-hover:border-indigo-300">
                                    Browse File
                                </span>
                                <span class="text-[11px] text-slate-400">Max size 10MB</span>
                            </div>
                        </div>

                        <!-- Input Mode Panel 2: Direct Clipboard Paste -->
                        <div x-show="bulkInputMode === 'paste'" class="p-4 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50/60 dark:bg-slate-900/40 space-y-2.5">
                            <div class="flex items-center justify-between">
                                <div class="flex items-center gap-2">
                                    <i data-lucide="clipboard" class="w-4 h-4 text-emerald-600"></i>
                                    <span class="text-xs font-bold text-slate-800 dark:text-white">Paste Spreadsheet Rows (with header row)</span>
                                </div>
                                <button type="button" @click="parseBulkPastedText()" class="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-2xs transition inline-flex items-center gap-1.5 cursor-pointer">
                                    <i data-lucide="arrow-down-to-line" class="w-3.5 h-3.5"></i>
                                    <span>Parse Pasted Data</span>
                                </button>
                            </div>
                            <textarea x-model="bulkRawPaste" rows="3" placeholder="Paste tab-separated cells copied directly from Excel, Google Sheets, or CSV here...&#10;Example: Sl | Employee Name | ID | Phone | Email | Designation | Department | Join Date | Employee Type | Date of Birth | Gender" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-[11px] font-mono text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"></textarea>
                        </div>

                        <!-- Input Mode Panel 3: Demo Sample Roster -->
                        <div x-show="bulkInputMode === 'demo'" class="p-4 rounded-2xl border border-amber-200/80 dark:border-amber-800/80 bg-amber-50/50 dark:bg-amber-950/20 flex flex-wrap items-center justify-between gap-3">
                            <div class="flex items-center gap-3">
                                <div class="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-xs">
                                    <i data-lucide="sparkles" class="w-4 h-4"></i>
                                </div>
                                <div>
                                    <h4 class="text-xs font-bold text-amber-950 dark:text-amber-200">Sample Demo Roster (3 Staff)</h4>
                                    <p class="text-[11px] text-amber-800 dark:text-amber-400">Includes Jane Doe (1001), John Smith (1002), Alex Roy (1003)</p>
                                </div>
                            </div>
                            <button type="button" @click="loadUserProvidedSheet()" class="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-2xs transition inline-flex items-center gap-1.5 cursor-pointer">
                                <i data-lucide="refresh-cw" class="w-3.5 h-3.5"></i>
                                <span>Load demo data</span>
                            </button>
                        </div>

                        <!-- Target Hierarchy & Credential Rules Toolbar -->
                        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-700/80 space-y-3">
                            <div class="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500 flex items-center gap-2">
                                <i data-lucide="sliders" class="w-3.5 h-3.5 text-indigo-500"></i>
                                <span>Hierarchy Defaults &amp; Account Provisioning Rules</span>
                            </div>
                            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3">
                                <?php if (!empty($isSoftwareAdmin)): ?>
                                <div>
                                    <label class="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Target Company</label>
                                    <select x-model="bulkConfig.company_id" @change="onBulkCompanyChange()" class="w-full px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white">
                                        <?php foreach ($companies as $c): ?>
                                            <option value="<?= esc($c['id']) ?>"><?= esc($c['name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <?php endif; ?>

                                <div>
                                    <label class="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Default Branch</label>
                                    <select x-model="bulkConfig.branch_id" class="w-full px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white">
                                        <template x-for="b in bulkFilteredBranches" :key="b.id">
                                            <option :value="b.id" x-text="b.name"></option>
                                        </template>
                                    </select>
                                </div>

                                <div>
                                    <label class="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Default Shift</label>
                                    <select x-model="bulkConfig.shift_id" class="w-full px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white">
                                        <template x-for="s in allShifts" :key="s.id">
                                            <option :value="s.id" x-text="s.name"></option>
                                        </template>
                                    </select>
                                </div>

                                <div>
                                    <label class="block text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider mb-1">Username Format</label>
                                    <div class="flex items-center gap-1.5">
                                        <select x-model="bulkConfig.username_strategy" @change="applyBulkCredentialsStrategy(false)" class="w-full px-3 py-1.5 rounded-xl border border-indigo-200 dark:border-indigo-800 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white">
                                            <option value="email_prefix">Email Prefix (e.g. jane.doe)</option>
                                            <option value="employee_code">Employee ID (e.g. 1001)</option>
                                            <option value="full_email">Full Email Address</option>
                                        </select>
                                        <button type="button" @click="applyBulkCredentialsStrategy(true)" title="Apply username rule to all staged rows" class="px-2.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-bold shrink-0 cursor-pointer">
                                            Apply
                                        </button>
                                    </div>
                                </div>

                                <div>
                                    <label class="block text-[10px] font-bold text-teal-600 dark:text-teal-400 uppercase tracking-wider mb-1">Default PF Eligibility</label>
                                    <div class="flex items-center gap-1.5">
                                        <select x-model="bulkConfig.default_pf_eligible" @change="applyBulkPfStrategy(false)" class="w-full px-3 py-1.5 rounded-xl border border-teal-200 dark:border-teal-800 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white">
                                            <option :value="true">Eligible (Enrolled)</option>
                                            <option :value="false">Not Eligible</option>
                                        </select>
                                        <button type="button" @click="applyBulkPfStrategy(true)" title="Apply PF eligibility rule to all staged rows" class="px-2.5 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-[11px] font-bold shrink-0 cursor-pointer">
                                            Apply
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div class="pt-1 flex items-center justify-between border-t border-slate-200/60 dark:border-slate-700/60">
                                <label class="inline-flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-300 cursor-pointer">
                                    <input type="checkbox" x-model="bulkConfig.update_existing" class="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500">
                                    <span>Update existing employee profile and reset credentials if ID or Email already exists in directory</span>
                                </label>
                                <span class="text-[11px] text-slate-400 font-mono">Role: Employee (ESS)</span>
                            </div>
                        </div>

                        <!-- Staged Rows Preview Table -->
                        <div class="space-y-2.5">
                            <div class="flex flex-wrap items-center justify-between gap-3">
                                <div class="flex items-center gap-2.5">
                                    <h4 class="text-xs font-extrabold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
                                        <span>Staged Employee Rows</span>
                                        <span class="px-2 py-0.5 rounded-full text-[11px] font-bold bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 font-mono" x-text="bulkRows.length"></span>
                                        <span x-show="isDemoDataLoaded" class="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-amber-500 text-white tracking-wider shadow-2xs">DEMO DATA - not real employees</span>
                                    </h4>
                                    <span x-show="bulkRows.length > 0 && !isDemoDataLoaded" class="text-[11px] text-slate-400">&bull; Review &amp; edit cell values before provisioning</span>
                                </div>

                                <div class="flex items-center gap-2">
                                    <!-- Search filter inside staged rows -->
                                    <div x-show="bulkRows.length > 2" class="relative">
                                        <i data-lucide="search" class="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2"></i>
                                        <input type="text" x-model="bulkTableSearch" placeholder="Filter rows..." class="pl-8 pr-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs w-36 sm:w-48 focus:outline-none focus:ring-1 focus:ring-indigo-500">
                                    </div>

                                    <button type="button" @click="addBlankBulkRow()" class="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5 transition cursor-pointer shadow-2xs">
                                        <i data-lucide="plus" class="w-3.5 h-3.5 text-indigo-600"></i>
                                        <span>Add Row</span>
                                    </button>
                                    <button type="button" @click="if(confirm('Clear all staged rows?')) { bulkRows = []; isDemoDataLoaded = false; }" x-show="bulkRows.length > 0" class="px-3 py-1.5 rounded-xl border border-rose-200 dark:border-rose-800 bg-rose-50 dark:bg-rose-950/40 text-xs font-bold text-rose-600 dark:text-rose-400 hover:bg-rose-100 transition cursor-pointer">
                                        Clear All
                                    </button>
                                </div>
                            </div>

                            <!-- Explicit DEMO DATA notice banner when demo records are loaded -->
                            <div x-show="isDemoDataLoaded && bulkRows.length > 0" class="p-3.5 rounded-2xl border border-amber-300 dark:border-amber-700/80 bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 flex flex-wrap items-center justify-between gap-3 shadow-2xs">
                                <div class="flex items-center gap-2.5">
                                    <span class="px-2.5 py-1 rounded-lg bg-amber-600 text-white text-[11px] font-extrabold uppercase tracking-wider shrink-0">DEMO DATA - not real employees</span>
                                    <span class="text-xs font-semibold">Upload is disabled while demo data is loaded. Please upload a spreadsheet file or paste real employee data.</span>
                                </div>
                                <button type="button" @click="bulkRows = []; isDemoDataLoaded = false;" class="text-xs font-bold text-amber-700 dark:text-amber-400 hover:text-amber-900 dark:hover:text-amber-200 underline cursor-pointer">
                                    Clear Demo Rows
                                </button>
                            </div>

                            <!-- Client-Side Validation Errors Banner -->
                            <div x-show="!isDemoDataLoaded && hasInvalidRows" class="p-3.5 rounded-2xl border border-rose-300 dark:border-rose-800 bg-rose-50/90 dark:bg-rose-950/60 text-rose-900 dark:text-rose-200 space-y-2 shadow-2xs">
                                <div class="flex items-center gap-2 text-xs font-bold text-rose-700 dark:text-rose-300">
                                    <i data-lucide="alert-circle" class="w-4 h-4 text-rose-600 shrink-0"></i>
                                    <span>Validation Error: <span x-text="invalidRowsSummary.length"></span> row(s) missing required fields (Name, Gender, DOB, Department, Designation, Employment Type)</span>
                                </div>
                                <div class="max-h-28 overflow-y-auto space-y-1 text-[11px] pr-2">
                                    <template x-for="item in invalidRowsSummary" :key="item.rowNum">
                                        <div class="flex items-center gap-2 text-rose-800 dark:text-rose-300">
                                            <span class="font-bold text-rose-600 dark:text-rose-400 font-mono">Row #<span x-text="item.rowNum"></span>:</span>
                                            <span x-show="item.name !== '(unnamed)'" class="font-semibold text-slate-700 dark:text-slate-300" x-text="item.name + ' — '"></span>
                                            <span>Missing <span class="font-bold underline text-rose-700 dark:text-rose-200" x-text="item.missing"></span></span>
                                        </div>
                                    </template>
                                </div>
                            </div>

                            <!-- Modern Spreadsheet Table Container (Scrolls horizontally inside modal) -->
                            <div class="w-full border border-slate-200/90 dark:border-slate-700/80 rounded-2xl overflow-x-auto max-h-[390px] shadow-2xs custom-scrollbar">
                                <table class="w-full min-w-[1100px] text-left border-collapse text-xs">
                                    <thead class="bg-slate-100/95 dark:bg-slate-900/95 text-[10px] font-bold uppercase text-slate-500 dark:text-slate-400 sticky top-0 z-20 backdrop-blur-md">
                                        <tr class="border-b border-slate-200 dark:border-slate-700">
                                            <th class="py-2.5 px-2.5 text-center w-8">#</th>
                                            <th class="py-2.5 px-2 min-w-[90px]">ID (Code) *</th>
                                            <th class="py-2.5 px-2 min-w-[170px]">Full Name *</th>
                                            <th class="py-2.5 px-2 min-w-[120px]">Phone</th>
                                            <th class="py-2.5 px-2 min-w-[185px]">Email Address</th>
                                            <th class="py-2.5 px-2 min-w-[145px]">Designation *</th>
                                            <th class="py-2.5 px-2 min-w-[145px]">Department *</th>
                                            <th class="py-2.5 px-2 min-w-[130px]">Join Date</th>
                                            <th class="py-2.5 px-2 min-w-[110px]">Emp Type *</th>
                                            <th class="py-2.5 px-2 min-w-[130px]">Date of Birth *</th>
                                            <th class="py-2.5 px-2 min-w-[110px]">Gender *</th>
                                            <th class="py-2.5 px-2 min-w-[110px]">Basic Salary ($)</th>
                                            <th class="py-2.5 px-2 min-w-[125px] text-teal-700 dark:text-teal-400 bg-teal-50/50 dark:bg-teal-950/40">PF Eligible</th>
                                            <th class="py-2.5 px-2 min-w-[140px] text-indigo-700 dark:text-indigo-400 bg-indigo-50/50 dark:bg-indigo-950/40">Username *</th>
                                            <th class="py-2.5 px-2 text-center w-9"></th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-100 dark:divide-slate-700/60 bg-white dark:bg-slate-850">
                                        <template x-for="(row, rIdx) in filteredBulkRows" :key="rIdx">
                                            <tr :class="isRowInvalid(row) ? 'bg-rose-50/70 dark:bg-rose-950/40 border-l-4 border-l-rose-500 hover:bg-rose-100/60' : 'hover:bg-slate-50/90 dark:hover:bg-slate-800/40'" class="transition-colors">
                                                <td class="py-1.5 px-2 text-center font-mono text-[11px]">
                                                    <span :class="isRowInvalid(row) ? 'text-rose-600 font-bold' : 'text-slate-400'" x-text="rIdx + 1"></span>
                                                    <span x-show="isRowInvalid(row)" class="block text-[9px] text-rose-500 font-bold" :title="'Missing: ' + getRowMissingFields(row).join(', ')">!</span>
                                                </td>
                                                <td class="py-1.5 px-1.5">
                                                    <input type="text" x-model="row.employee_code" placeholder="1001" class="w-full px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent hover:bg-white dark:hover:bg-slate-900 focus:bg-white dark:focus:bg-slate-900 font-mono text-[11px] font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500 transition">
                                                </td>
                                                <td class="py-1.5 px-1.5">
                                                    <input type="text" x-model="row.name" placeholder="Employee Name *" :class="!String(row.name || '').trim() ? 'border-rose-400 dark:border-rose-600 bg-rose-50/40' : 'border-slate-200 dark:border-slate-700'" class="w-full px-2 py-1 rounded-lg border bg-transparent hover:bg-white dark:hover:bg-slate-900 focus:bg-white dark:focus:bg-slate-900 text-[11px] font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500 transition">
                                                </td>
                                                <td class="py-1.5 px-1.5">
                                                    <input type="text" x-model="row.phone" placeholder="017..." class="w-full px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent hover:bg-white dark:hover:bg-slate-900 focus:bg-white dark:focus:bg-slate-900 font-mono text-[11px] text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition">
                                                </td>
                                                <td class="py-1.5 px-1.5">
                                                    <input type="email" x-model="row.email" placeholder="user@company.com" class="w-full px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent hover:bg-white dark:hover:bg-slate-900 focus:bg-white dark:focus:bg-slate-900 text-[11px] text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition">
                                                </td>
                                                <td class="py-1.5 px-1.5">
                                                    <input type="text" x-model="row.designation" placeholder="Designation *" :class="!String(row.designation || '').trim() ? 'border-rose-400 dark:border-rose-600 bg-rose-50/40' : 'border-slate-200 dark:border-slate-700'" class="w-full px-2 py-1 rounded-lg border bg-transparent hover:bg-white dark:hover:bg-slate-900 focus:bg-white dark:focus:bg-slate-900 text-[11px] text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition">
                                                </td>
                                                <td class="py-1.5 px-1.5">
                                                    <input type="text" x-model="row.department" placeholder="Department *" :class="!String(row.department || '').trim() ? 'border-rose-400 dark:border-rose-600 bg-rose-50/40' : 'border-slate-200 dark:border-slate-700'" class="w-full px-2 py-1 rounded-lg border bg-transparent hover:bg-white dark:hover:bg-slate-900 focus:bg-white dark:focus:bg-slate-900 text-[11px] text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition">
                                                </td>
                                                <td class="py-1.5 px-1.5">
                                                    <input type="date" x-model="row.join_date" class="w-full px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent hover:bg-white dark:hover:bg-slate-900 focus:bg-white dark:focus:bg-slate-900 font-mono text-[11px] text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition">
                                                </td>
                                                <td class="py-1.5 px-1.5">
                                                    <input type="text" x-model="row.employee_type" placeholder="Employment Type *" :class="!String(row.employee_type || '').trim() ? 'border-rose-400 dark:border-rose-600 bg-rose-50/40' : 'border-slate-200 dark:border-slate-700'" class="w-full px-2 py-1 rounded-lg border bg-transparent hover:bg-white dark:hover:bg-slate-900 focus:bg-white dark:focus:bg-slate-900 text-[11px] text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition">
                                                </td>
                                                <td class="py-1.5 px-1.5">
                                                    <input type="date" x-model="row.dob" :class="!String(row.dob || '').trim() ? 'border-rose-400 dark:border-rose-600 bg-rose-50/40' : 'border-slate-200 dark:border-slate-700'" class="w-full px-2 py-1 rounded-lg border bg-transparent hover:bg-white dark:hover:bg-slate-900 focus:bg-white dark:focus:bg-slate-900 font-mono text-[11px] text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition">
                                                </td>
                                                <td class="py-1.5 px-1.5">
                                                    <select x-model="row.gender" :class="!['male', 'female', 'other'].includes(String(row.gender || '').trim().toLowerCase()) ? 'border-rose-400 dark:border-rose-600 bg-rose-50/40' : 'border-slate-200 dark:border-slate-700'" class="w-full px-2 py-1 rounded-lg border bg-transparent hover:bg-white dark:hover:bg-slate-900 focus:bg-white dark:focus:bg-slate-900 text-[11px] text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition">
                                                        <option value="">Select Gender *</option>
                                                        <option value="male">Male</option>
                                                        <option value="female">Female</option>
                                                        <option value="other">Other</option>
                                                    </select>
                                                </td>
                                                <td class="py-1.5 px-1.5">
                                                    <input type="number" step="100" min="0" x-model="row.basic_salary" placeholder="0" class="w-full px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent hover:bg-white dark:hover:bg-slate-900 focus:bg-white dark:focus:bg-slate-900 font-mono text-[11px] text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition">
                                                </td>
                                                <td class="py-1.5 px-1.5 bg-teal-50/30 dark:bg-teal-950/20">
                                                    <select x-model="row.pf_eligible" class="w-full px-2 py-1 rounded-lg border border-teal-200 dark:border-teal-800 bg-white/80 dark:bg-slate-900/80 font-mono text-[11px] font-bold text-teal-700 dark:text-teal-300 focus:outline-none focus:ring-1 focus:ring-teal-500 transition">
                                                        <option value="1">Yes (Eligible)</option>
                                                        <option value="0">No (Not Eligible)</option>
                                                        <option value="exempt">Exempt</option>
                                                    </select>
                                                </td>
                                                <td class="py-1.5 px-1.5 bg-indigo-50/30 dark:bg-indigo-950/20">
                                                    <input type="text" x-model="row.username" placeholder="Username" class="w-full px-2 py-1 rounded-lg border border-indigo-200 dark:border-indigo-800 bg-white/80 dark:bg-slate-900/80 font-mono text-[11px] font-bold text-indigo-700 dark:text-indigo-300 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition">
                                                </td>
                                                <td class="py-1.5 px-1.5 text-center">
                                                    <button type="button" @click="removeBulkRow(rIdx)" class="p-1 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/30 transition cursor-pointer" title="Remove Row">
                                                        <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        </template>
                                    </tbody>
                                </table>

                                <!-- Empty Staged Rows Placeholder -->
                                <div x-show="bulkRows.length === 0" class="py-12 px-4 text-center">
                                    <div class="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center mx-auto mb-3">
                                        <i data-lucide="file-question" class="w-6 h-6"></i>
                                    </div>
                                    <h5 class="text-sm font-bold text-slate-700 dark:text-slate-300">No Employee Rows Staged Yet</h5>
                                    <p class="text-xs text-slate-400 mt-1">Upload a spreadsheet file, paste clipboard cells, or load sample demo staff above.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- STEP 2: Post-Upload Provisioned Credentials Summary -->
                    <div x-show="bulkUploadResult" class="space-y-4">
                        <!-- Metrics Card Banner -->
                        <div class="p-5 rounded-3xl bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 dark:from-emerald-950/40 dark:via-teal-950/30 dark:to-emerald-950/40 border border-emerald-200/80 dark:border-emerald-800/80 flex flex-wrap items-center justify-between gap-4 shadow-sm">
                            <div class="flex items-center gap-4">
                                <div class="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-bold shadow-md shadow-emerald-600/20 shrink-0">
                                    <i data-lucide="check-circle-2" class="w-6 h-6"></i>
                                </div>
                                <div>
                                    <h4 class="text-sm font-extrabold text-emerald-950 dark:text-emerald-200 tracking-tight" x-text="bulkUploadResult ? bulkUploadResult.message : ''"></h4>
                                    <div class="flex items-center gap-3 mt-1.5">
                                        <span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-200">
                                            Created: <strong x-text="bulkUploadResult?.created_count || 0"></strong>
                                        </span>
                                        <span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-100 dark:bg-indigo-900/60 text-indigo-800 dark:text-indigo-200">
                                            Updated: <strong x-text="bulkUploadResult?.updated_count || 0"></strong>
                                        </span>
                                        <span x-show="(bulkUploadResult?.skipped_count || 0) > 0" class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-200/80 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                                            Skipped: <strong x-text="bulkUploadResult?.skipped_count || 0"></strong>
                                        </span>
                                        <span x-show="bulkUploadResult?.failed_count > 0" class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-100 dark:bg-rose-900/60 text-rose-800 dark:text-rose-200">
                                            Failed: <strong x-text="bulkUploadResult?.failed_count || 0"></strong>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="flex items-center gap-2">
                                <button x-show="bulkUploadResult?.failed_count > 0" type="button" @click="downloadFailedRowsCsv()" class="px-3.5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-sm inline-flex items-center gap-2 cursor-pointer transition">
                                    <i data-lucide="alert-circle" class="w-4 h-4"></i>
                                    <span>Download Failed Rows (<span x-text="bulkUploadResult?.failed_count || 0"></span>)</span>
                                </button>
                                <button type="button" @click="downloadProvisionedCredentialsCsv()" class="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm inline-flex items-center gap-2 cursor-pointer transition">
                                    <i data-lucide="download" class="w-4 h-4"></i>
                                    <span>Export Credentials CSV Sheet</span>
                                </button>
                            </div>
                        </div>

                        <!-- Provisioned Accounts Roster Table -->
                        <div class="w-full border border-slate-200 dark:border-slate-700 rounded-2xl overflow-x-auto max-h-[390px] shadow-2xs custom-scrollbar">
                            <table class="w-full min-w-[750px] text-left border-collapse text-xs">
                                <thead class="bg-slate-100/90 dark:bg-slate-900/90 text-[10px] font-bold uppercase text-slate-500 sticky top-0 z-10 backdrop-blur-md">
                                    <tr class="border-b border-slate-200 dark:border-slate-700">
                                        <th class="py-2.5 px-3">ID</th>
                                        <th class="py-2.5 px-3">Employee Name</th>
                                        <th class="py-2.5 px-3">Department &amp; Designation</th>
                                        <th class="py-2.5 px-3">Join Date</th>
                                        <th class="py-2.5 px-3 text-teal-600 dark:text-teal-400">PF Status</th>
                                        <th class="py-2.5 px-3 text-indigo-600 dark:text-indigo-400">Username</th>
                                        <th class="py-2.5 px-3">Status</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-slate-100 dark:divide-slate-700/60 bg-white dark:bg-slate-850">
                                    <template x-for="(res, idx) in (bulkUploadResult?.results || [])" :key="idx">
                                        <tr class="hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                                            <td class="py-2 px-3 font-mono font-bold text-slate-700 dark:text-slate-200" x-text="res.employee_code || '-'"></td>
                                            <td class="py-2 px-3 font-bold text-slate-900 dark:text-white" x-text="res.name"></td>
                                            <td class="py-2 px-3 text-slate-600 dark:text-slate-300" x-text="(res.designation || '') + ' — ' + (res.department || '')"></td>
                                            <td class="py-2 px-3 font-mono text-slate-600 dark:text-slate-300" x-text="res.join_date || '-'"></td>
                                            <td class="py-2 px-3">
                                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold font-mono"
                                                      :class="{
                                                          'bg-teal-100 text-teal-700 dark:bg-teal-950 dark:text-teal-300': (res.pf_eligible === 'Eligible' || res.pf_status === 'Enrolled'),
                                                          'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300': (res.pf_eligible === 'Exempt' || res.pf_status === 'Exempt'),
                                                          'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400': (res.pf_eligible === 'Not Eligible' || res.pf_status === 'Not Enrolled' || !res.pf_eligible)
                                                      }"
                                                      x-text="res.pf_eligible || res.pf_status || 'Not Eligible'"></span>
                                            </td>
                                            <td class="py-2 px-3 font-mono font-bold text-indigo-600 dark:text-indigo-400" x-text="res.username || '-'"></td>
                                            <td class="py-2 px-3">
                                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase"
                                                      :class="{
                                                          'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300': res.status === 'failed',
                                                          'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border border-slate-200 dark:border-slate-700': res.status === 'skipped',
                                                          'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300': res.status === 'created',
                                                          'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300': res.status === 'updated'
                                                      }"
                                                      x-text="res.status + ((res.status === 'failed' || res.status === 'skipped') && res.message ? ': ' + res.message : '')"></span>
                                            </td>
                                        </tr>
                                    </template>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Modal Footer (Fixed / Shrink-0) -->
                <div class="px-4 sm:px-6 py-3.5 sm:py-4 border-t border-slate-200/80 dark:border-slate-700/80 bg-slate-50/80 dark:bg-slate-900/70 flex items-center justify-between shrink-0">
                    <div class="text-xs text-slate-500 dark:text-slate-400">
                        <span x-show="!bulkUploadResult">Missing Departments, Designations, and Employment Types are auto-created under your company context.</span>
                        <span x-show="bulkUploadResult">All employee accounts are active immediately and can log into Self-Service (ESS).</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <button type="button" x-show="!bulkUploadResult" @click="if (!isSubmittingBulkUpload) { bulkUploadModalOpen = false; }" class="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer">
                            Cancel
                        </button>
                        <button type="button" 
                                x-show="!bulkUploadResult" 
                                @click="submitBulkUpload()" 
                                :disabled="isSubmittingBulkUpload || bulkRows.length === 0 || isDemoDataLoaded || hasInvalidRows" 
                                :class="(isDemoDataLoaded || hasInvalidRows || bulkRows.length === 0) ? 'opacity-50 cursor-not-allowed bg-slate-400 dark:bg-slate-600' : 'bg-emerald-600 hover:bg-emerald-700 cursor-pointer shadow-md shadow-emerald-600/20'" 
                                class="px-5 py-2.5 rounded-xl text-white text-xs font-bold transition inline-flex items-center gap-2">
                            <i x-show="!isSubmittingBulkUpload" data-lucide="upload" class="w-4 h-4"></i>
                            <svg x-show="isSubmittingBulkUpload" class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            <span x-text="isSubmittingBulkUpload ? 'Uploading & Provisioning Accounts...' : (isDemoDataLoaded ? 'Upload Disabled (Demo Data)' : (hasInvalidRows ? 'Upload Blocked (' + invalidRowsSummary.length + ' Invalid Rows)' : 'Upload & Provision ' + bulkRows.length + ' Employees'))"></span>
                        </button>
                        <button type="button" x-show="bulkUploadResult" @click="window.location.reload()" class="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-sm transition inline-flex items-center gap-2 cursor-pointer">
                            <i data-lucide="check" class="w-4 h-4"></i>
                            <span>Done &amp; Refresh Directory</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </template>

</div>

<script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
<script>
function employeeDirectory(config) {
    return {
        activeView: 'table', // 'table' | 'analytics'
        searchQuery: config.initialSearch || '',
        isSoftwareAdmin: config.isSoftwareAdmin || false,
        selectedCompany: config.selectedCompanyId || '',
        selectedBranch: config.selectedBranchId || '',
        allBranches: config.branches || [],
        allCompanies: config.companies || [],
        allDepartments: config.departments || [],
        allDesignations: config.designations || [],
        allShifts: config.shifts || [],
        allEmploymentTypes: config.employmentTypes || [],
        allEmployees: config.employees || [],
        filteredBranches: [],
        modalFilteredBranches: [],
        modalFilteredEmploymentTypes: [],

        // Modals
        addModalOpen: false,
        editModalOpen: false,
        actionModalOpen: false,
        bulkUploadModalOpen: false,
        isSubmittingBulkUpload: false,
        bulkInputMode: 'file', // 'file' | 'paste' | 'demo'
        bulkTableSearch: '',
        bulkUploadedFileName: '',
        bulkErrorMsg: '',
        bulkRawPaste: '',
        bulkUploadResult: null,
        bulkFilteredBranches: [],
        bulkConfig: {
            company_id: config.selectedCompanyId || (config.companies[0] ? config.companies[0].id : ''),
            branch_id: config.selectedBranchId || (config.branches[0] ? config.branches[0].id : ''),
            shift_id: config.shifts && config.shifts[0] ? config.shifts[0].id : '',
            username_strategy: 'email_prefix',
            default_pf_eligible: true,
            update_existing: true
        },
        bulkRows: [],
        isDemoDataLoaded: false,

        getRowMissingFields(row) {
            const missing = [];
            if (!row.name || !String(row.name).trim()) missing.push('Full Name');
            const gender = String(row.gender || '').trim().toLowerCase();
            if (!gender || !['male', 'female', 'other'].includes(gender)) missing.push('Gender');
            if (!row.dob || !String(row.dob).trim()) missing.push('Date of Birth');
            if (!row.department || !String(row.department).trim()) missing.push('Department');
            if (!row.designation || !String(row.designation).trim()) missing.push('Designation');
            const empType = row.employee_type || row.employment_type;
            if (!empType || !String(empType).trim()) missing.push('Employment Type');
            return missing;
        },

        isRowInvalid(row) {
            return this.getRowMissingFields(row).length > 0;
        },

        get invalidRowsSummary() {
            if (!this.bulkRows || this.bulkRows.length === 0) return [];
            const list = [];
            this.bulkRows.forEach((r, idx) => {
                const missing = this.getRowMissingFields(r);
                if (missing.length > 0) {
                    list.push({
                        rowNum: idx + 1,
                        name: r.name ? String(r.name).trim() : '(unnamed)',
                        missing: missing.join(', ')
                    });
                }
            });
            return list;
        },

        get hasInvalidRows() {
            return this.invalidRowsSummary.length > 0;
        },

        get readyRowsCount() {
            return this.bulkRows.filter(r => r.name && r.name.trim() !== '' && r.employee_code && r.employee_code.trim() !== '').length;
        },

        get filteredBulkRows() {
            if (!this.bulkTableSearch || !this.bulkTableSearch.trim()) return this.bulkRows;
            const q = this.bulkTableSearch.toLowerCase().trim();
            return this.bulkRows.filter(r => 
                (r.name && r.name.toLowerCase().includes(q)) ||
                (r.employee_code && r.employee_code.toLowerCase().includes(q)) ||
                (r.email && r.email.toLowerCase().includes(q)) ||
                (r.department && r.department.toLowerCase().includes(q)) ||
                (r.designation && r.designation.toLowerCase().includes(q)) ||
                (r.username && r.username.toLowerCase().includes(q))
            );
        },
        editData: {},
        isLoadingEdit: false,
        actionEmp: {},
        actionType: null, // 'confirm' | 'promote' | 'resign'
        actionReason: '',
        promoDesg: '',
        promoBranch: '',
        promoSalary: '',
        terminationType: 'Resignation',
        terminationDate: new Date().toISOString().split('T')[0],
        isSubmittingAction: false,

        // Bulk Provident Fund Management State
        pfRules: config.pfRules || [],
        selectedEmployees: [],
        showBulkPfModal: false,
        bulkPfAction: 'assign', // 'assign' | 'exempt' | 'remove'
        bulkPfData: {
            rule_id: '',
            rule_name: 'Standard Company PF Policy',
            contribution_type: 'Percentage',
            employee_rate: 10.0,
            employer_rate: 10.0,
            employee_fixed_amount: 0.0,
            employer_fixed_amount: 0.0,
            effective_date: new Date().toISOString().split('T')[0],
            exemption_reason: '',
            notes: ''
        },
        isSubmittingBulkPf: false,

        // Employee Code State Machine (idle: availabilityStatus = null, isCheckingAvailability = false)
        availabilityStatus: null, // null | 'taken'
        isCheckingAvailability: false,
        codeErrorMessage: '',
        newEmp: {
            company_id: config.selectedCompanyId || (config.companies[0] ? config.companies[0].id : ''),
            employee_code: config.suggestedEmployeeCode || '',
            first_name: '',
            last_name: '',
            email: '',
            phone: '',
            national_id: '',
            dob: '',
            gender: '',
            department_id: '',
            designation_id: '',
            branch_id: '',
            shift_id: '',
            reporting_manager_id: '',
            employment_type_id: '',
            basic_salary: '',
            pf_member_id: (config.pfPrefix || 'PF-') + ((config.suggestedEmployeeCode || '101').replace(/[^0-9]/g, '')),
            tax_identification_number: '',
            bank_name: '',
            bank_account: ''
        },

        init() {
            this.updateFilteredBranches();
            this.updateModalBranches();
            this.updateModalEmploymentTypes();
            this.$nextTick(() => {
                if (typeof lucide !== 'undefined') {
                    lucide.createIcons();
                }
            });
        },

        onCompanyChange() {
            this.selectedBranch = '';
            this.updateFilteredBranches();
            document.getElementById('filterForm').submit();
        },

        onModalCompanyChange() {
            this.updateModalBranches();
            this.updateModalEmploymentTypes();
            this.fetchAuthoritativeCode(this.newEmp.company_id);
        },

        updateFilteredBranches() {
            if (!this.selectedCompany) {
                this.filteredBranches = this.allBranches;
            } else {
                this.filteredBranches = this.allBranches.filter(b => !b.company_id || b.company_id === this.selectedCompany);
            }
        },

        updateModalBranches() {
            const comp = this.newEmp.company_id;
            if (!comp) {
                this.modalFilteredBranches = this.allBranches;
            } else {
                this.modalFilteredBranches = this.allBranches.filter(b => !b.company_id || b.company_id === comp);
            }
            if (this.modalFilteredBranches.length > 0 && !this.newEmp.branch_id) {
                this.newEmp.branch_id = this.modalFilteredBranches[0].id;
            }
        },

        updateModalEmploymentTypes() {
            const comp = this.newEmp.company_id;
            if (!comp) {
                this.modalFilteredEmploymentTypes = this.allEmploymentTypes;
            } else {
                // Tenant Isolation: prioritize company-specific types; fallback to global unassigned only
                const compTypes = this.allEmploymentTypes.filter(et => et.company_id === comp);
                if (compTypes.length > 0) {
                    this.modalFilteredEmploymentTypes = compTypes;
                } else {
                    // Only fallback to types with no company assigned, NEVER show other companies' types
                    this.modalFilteredEmploymentTypes = this.allEmploymentTypes.filter(et => !et.company_id);
                }
            }

            // Sync selected employment_type_id
            if (this.modalFilteredEmploymentTypes.length > 0) {
                const isValid = this.modalFilteredEmploymentTypes.some(et => String(et.id) === String(this.newEmp.employment_type_id));
                if (!isValid) {
                    this.newEmp.employment_type_id = this.modalFilteredEmploymentTypes[0].id;
                }
            } else {
                this.newEmp.employment_type_id = '';
            }
        },

        onCodeInput() {
            this.availabilityStatus = null;
            this.isCheckingAvailability = false;
            this.codeErrorMessage = '';
        },

        async fetchAuthoritativeCode(companyId = null) {
            try {
                const comp = companyId || this.newEmp.company_id || config.selectedCompanyId || '';
                const pfPref = config.pfPrefix || '';
                const res = await fetch(`<?= base_url('employees/next-code') ?>?company_id=${encodeURIComponent(comp)}&pf_prefix=${encodeURIComponent(pfPref)}`);
                if (res.ok) {
                    const data = await res.json();
                    if (data && (data.success || data.status === 'success') && data.employee_code) {
                        this.newEmp.employee_code = data.employee_code;
                        this.newEmp.pf_member_id = data.pf_member_id || ((config.pfPrefix || 'PF-') + data.employee_code.replace(/[^0-9]/g, ''));
                    }
                }
            } catch (err) {
                console.error('Failed to fetch authoritative employee code:', err);
            } finally {
                this.availabilityStatus = null;
                this.isCheckingAvailability = false;
                this.codeErrorMessage = '';
            }
        },

        async checkEmployeeCodeAvailability() {
            const code = (this.newEmp.employee_code || '').trim();
            if (!code) {
                this.availabilityStatus = null;
                this.isCheckingAvailability = false;
                this.codeErrorMessage = '';
                return;
            }
            this.isCheckingAvailability = true;
            this.codeErrorMessage = '';
            try {
                const comp = this.newEmp.company_id || (typeof config !== 'undefined' ? config.selectedCompanyId : '') || '';
                const res = await fetch(`<?= base_url('employees/check-code') ?>?code=${encodeURIComponent(code)}&company_id=${encodeURIComponent(comp)}`);
                if (res.ok) {
                    const data = await res.json();
                    if (data.exists) {
                        this.availabilityStatus = 'taken';
                        this.codeErrorMessage = 'Already exists in database!';
                    } else {
                        // Success -> Return to clean idle state (no persistent badge)
                        this.availabilityStatus = null;
                        this.codeErrorMessage = '';
                    }
                } else {
                    this.availabilityStatus = null;
                }
            } catch (e) {
                this.availabilityStatus = null;
            } finally {
                this.isCheckingAvailability = false;
            }
        },

        openAddModal() {
            this.updateModalBranches();
            this.updateModalEmploymentTypes();
            this.availabilityStatus = null;
            this.isCheckingAvailability = false;
            this.codeErrorMessage = '';
            this.addModalOpen = true;
            this.fetchAuthoritativeCode(this.newEmp.company_id);
            this.$nextTick(() => {
                if (typeof lucide !== 'undefined') {
                    lucide.createIcons();
                }
            });
        },

        async openEditModal(empId) {
            this.isLoadingEdit = true;
            this.editModalOpen = true;
            this.editData = { id: empId, first_name: '', last_name: '', employee_code: '', email: '', phone: '', status: '<?= \App\Models\EmployeeModel::STATUS_ACTIVE ?>' };
            try {
                const res = await fetch(`<?= base_url('employees') ?>/${encodeURIComponent(empId)}/edit-data`, {
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                });
                const json = await res.json();
                if (json.success && json.data) {
                    this.editData = Object.assign({}, json.data);
                    if (!this.editData.first_name && this.editData.full_name) {
                        const parts = this.editData.full_name.split(' ');
                        this.editData.first_name = parts[0] || '';
                        this.editData.last_name = parts.slice(1).join(' ') || '';
                    }
                }
            } catch (err) {
                console.error('Failed to load employee edit data:', err);
            } finally {
                this.isLoadingEdit = false;
                this.$nextTick(() => {
                    if (typeof lucide !== 'undefined') {
                        lucide.createIcons();
                    }
                });
            }
        },

        openActionModal(emp, type) {
            this.actionEmp = emp;
            this.actionType = type;
            this.actionReason = '';
            this.promoDesg = emp.designation_id || (this.allDesignations[0]?.id || '');
            this.promoBranch = emp.branch_id || (this.allBranches[0]?.id || '');
            this.promoSalary = '';
            this.terminationType = 'Resignation';
            this.terminationDate = new Date().toISOString().split('T')[0];
            this.actionModalOpen = true;
            this.$nextTick(() => {
                if (typeof lucide !== 'undefined') {
                    lucide.createIcons();
                }
            });
        },

        async submitLifecycleAction() {
            this.isSubmittingAction = true;
            const empId = this.actionEmp.id;

            try {
                let url = '';
                let formData = new FormData();
                formData.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');
                formData.append('employee_id', empId);

                if (this.actionType === 'confirm') {
                    url = '<?= base_url('employees/confirm') ?>/' + empId;
                } else if (this.actionType === 'promote') {
                    url = '<?= base_url('employees/promote') ?>';
                    formData.append('new_designation_id', this.promoDesg);
                    formData.append('new_branch_id', this.promoBranch);
                    formData.append('new_salary', this.promoSalary);
                    formData.append('reason', this.actionReason || 'Promoted');
                } else if (this.actionType === 'resign') {
                    url = '<?= base_url('employees/terminate') ?>';
                    formData.append('termination_type', this.terminationType || 'Resignation');
                    formData.append('termination_date', this.terminationDate || new Date().toISOString().split('T')[0]);
                    formData.append('reason', this.actionReason || 'Resigned/Terminated');
                }

                const response = await fetch(url, {
                    method: 'POST',
                    body: formData,
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                });

                const res = await response.json();
                if (res.success === true || res.status === 'success') {
                    window.location.reload();
                } else {
                    alert(res.message || 'Operation failed. Please try again.');
                }
            } catch (err) {
                console.error(err);
                alert('Error connecting to server. Please try again.');
            } finally {
                this.isSubmittingAction = false;
            }
        },

        currentQueryParams() {
            const params = new URLSearchParams();
            const form = document.getElementById('filterForm');
            if (form) {
                const getVal = (name) => {
                    const el = form.elements[name];
                    return el && el.value ? el.value : '';
                };
                const companyId = getVal('company_id') || this.selectedCompany;
                const branchId = getVal('branch_id') || this.selectedBranch;
                const deptId = getVal('department_id');
                const desgId = getVal('designation_id');
                const empTypeId = getVal('employment_type_id');
                const shiftId = getVal('shift_id');
                const mgrId = getVal('reporting_manager_id');
                const status = getVal('status');
                const pfStatus = getVal('pf_status');

                if (companyId) params.append('company_id', companyId);
                if (branchId) params.append('branch_id', branchId);
                if (deptId) params.append('department_id', deptId);
                if (desgId) params.append('designation_id', desgId);
                if (empTypeId) params.append('employment_type_id', empTypeId);
                if (shiftId) params.append('shift_id', shiftId);
                if (mgrId) params.append('reporting_manager_id', mgrId);
                if (status) params.append('status', status);
                if (pfStatus) params.append('pf_status', pfStatus);
            } else {
                if (this.selectedCompany) params.append('company_id', this.selectedCompany);
                if (this.selectedBranch) params.append('branch_id', this.selectedBranch);
                if (config.selectedDeptId) params.append('department_id', config.selectedDeptId);
                if (config.selectedStatus) params.append('status', config.selectedStatus);
            }
            if (config.initialSearch && config.initialSearch.trim() !== '') {
                params.append('search', config.initialSearch.trim());
            }
            return params.toString();
        },

        matchesSearch(text) {
            if (!this.searchQuery || this.searchQuery.trim() === '') return true;
            const query = this.searchQuery.toLowerCase().trim();
            const target = (text || '').toLowerCase();
            if (target.includes(query)) return true;
            const words = query.split(/\s+/).filter(w => w.length > 0);
            if (words.length > 0 && words.every(w => target.includes(w))) {
                return true;
            }
            return false;
        },

        // ==========================================
        // BULK PROVIDENT FUND METHODS
        // ==========================================
        buildEmployeeSearchText(emp) {
            const empName = emp.full_name || emp.name || `${emp.first_name || ''} ${emp.last_name || ''}`.trim() || emp.employee_code || '';
            const reversedName = `${emp.last_name || ''} ${emp.first_name || ''}`.trim();
            return [
                empName,
                reversedName,
                emp.first_name || '',
                emp.last_name || '',
                emp.employee_code || '',
                emp.email || '',
                emp.phone || '',
                emp.department_name || '',
                emp.designation_name || '',
                emp.company_name || '',
                emp.branch_name || '',
            ].filter(Boolean).join(' ');
        },

        toggleSelectAll(e) {
            const checked = e.target.checked;
            if (checked) {
                // Select all eligible employees matching search (excluding Software App Admin)
                this.selectedEmployees = this.allEmployees
                    .filter(emp => emp.role !== 'Software App Admin' && emp.employee_code !== 'SUPER_ADMIN' && this.matchesSearch(this.buildEmployeeSearchText(emp)))
                    .map(emp => String(emp.id));
            } else {
                this.selectedEmployees = [];
            }
        },

        isAllSelected() {
            const eligible = this.allEmployees.filter(emp => emp.role !== 'Software App Admin' && emp.employee_code !== 'SUPER_ADMIN' && this.matchesSearch(this.buildEmployeeSearchText(emp)));
            return eligible.length > 0 && eligible.every(emp => this.selectedEmployees.includes(String(emp.id)));
        },

        openBulkPfModal(action = 'assign') {
            this.bulkPfAction = action;
            if (action === 'assign') {
                if (this.pfRules && this.pfRules.length > 0) {
                    this.bulkPfData.rule_id = this.pfRules[0].id;
                    this.onBulkSchemeChange();
                }
            }
            this.showBulkPfModal = true;
        },

        onBulkSchemeChange() {
            if (!this.bulkPfData.rule_id) {
                this.bulkPfData.rule_name = 'Standard Company PF Policy';
                return;
            }
            const found = this.pfRules.find(r => r.id === this.bulkPfData.rule_id);
            if (found) {
                this.bulkPfData.rule_name = found.name;
                if (String(found.contribution_type || '').toLowerCase() === 'fixed') {
                    this.bulkPfData.contribution_type = 'Fixed';
                    this.bulkPfData.employee_fixed_amount = parseFloat(found.employee_fixed_amount) || 0;
                    this.bulkPfData.employer_fixed_amount = parseFloat(found.employer_fixed_amount) || 0;
                } else {
                    this.bulkPfData.contribution_type = 'Percentage';
                    this.bulkPfData.employee_rate = parseFloat(found.employee_rate) || 0;
                    this.bulkPfData.employer_rate = parseFloat(found.employer_rate) || 0;
                }
            }
        },

        async executeBulkPfAction(actionType) {
            if (this.selectedEmployees.length === 0) return;
            if (actionType === 'assign') {
                this.openBulkPfModal('assign');
                return;
            }
            const confirmMsg = actionType === 'exempt'
                ? `Exempt all ${this.selectedEmployees.length} selected employee(s) from Provident Fund?`
                : `Remove / de-enroll all ${this.selectedEmployees.length} selected employee(s) from Provident Fund?`;
            
            if (!confirm(confirmMsg)) return;

            await this.postBulkPfPayload({
                action: actionType,
                employee_ids: this.selectedEmployees,
                exemption_reason: actionType === 'exempt' ? 'Bulk statutory exemption by HR' : ''
            });
        },

        async submitBulkPfAssignment() {
            if (this.selectedEmployees.length === 0) return;
            this.isSubmittingBulkPf = true;
            try {
                const payload = {
                    action: this.bulkPfAction,
                    employee_ids: this.selectedEmployees,
                    rule_id: this.bulkPfData.rule_id,
                    rule_name: this.bulkPfData.rule_name,
                    contribution_type: this.bulkPfData.contribution_type,
                    employee_rate: this.bulkPfData.employee_rate,
                    employer_rate: this.bulkPfData.employer_rate,
                    employee_fixed_amount: this.bulkPfData.employee_fixed_amount,
                    employer_fixed_amount: this.bulkPfData.employer_fixed_amount,
                    effective_date: this.bulkPfData.effective_date,
                    exemption_reason: this.bulkPfData.exemption_reason,
                    notes: this.bulkPfData.notes
                };
                await this.postBulkPfPayload(payload);
            } finally {
                this.isSubmittingBulkPf = false;
            }
        },

        async postBulkPfPayload(payload) {
            try {
                const formData = new FormData();
                formData.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');
                formData.append('payload', JSON.stringify(payload));

                const res = await fetch('<?= base_url('employees/bulk-pf-assign') ?>', {
                    method: 'POST',
                    body: formData,
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                });

                const data = await res.json();
                if (data.success || data.status === 'success') {
                    window.location.reload();
                } else {
                    alert(data.message || 'Failed to update employees.');
                }
            } catch (err) {
                console.error('Bulk PF assign error:', err);
                alert('A network error occurred while performing bulk PF assignment.');
            }
        },

        // =============================================================
        // BULK UPLOAD EMPLOYEES & CREDENTIALS METHODS
        // =============================================================
        openBulkUploadModal() {
            this.bulkErrorMsg = '';
            this.bulkUploadResult = null;
            this.bulkInputMode = 'file';
            this.bulkTableSearch = '';
            this.onBulkCompanyChange();
            // Bulk table starts empty - demo data loaded only via explicit button
            this.bulkUploadModalOpen = true;
            this.$nextTick(() => {
                if (typeof lucide !== 'undefined') {
                    lucide.createIcons();
                }
            });
        },

        onBulkCompanyChange() {
            const comp = this.bulkConfig.company_id;
            if (!comp) {
                this.bulkFilteredBranches = this.allBranches;
            } else {
                this.bulkFilteredBranches = this.allBranches.filter(b => !b.company_id || b.company_id === comp);
            }
            if (this.bulkFilteredBranches.length > 0) {
                this.bulkConfig.branch_id = this.bulkFilteredBranches[0].id;
            }
        },

        normalizeDateForInput(raw) {
            if (!raw && raw !== 0) return '';
            const str = String(raw).trim();
            if (!str) return '';
            // Excel serial number
            if (/^\d{5}$/.test(str)) {
                const utcDays = parseInt(str, 10) - 25569;
                const d = new Date(utcDays * 86400 * 1000);
                if (!isNaN(d.getTime())) {
                    return d.toISOString().split('T')[0];
                }
            }
            // YYYY-MM-DD
            const isoMatch = str.match(/^(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})$/);
            if (isoMatch) {
                return `${isoMatch[1]}-${String(isoMatch[2]).padStart(2, '0')}-${String(isoMatch[3]).padStart(2, '0')}`;
            }
            // DD-MM-YYYY or MM-DD-YYYY (default DD-MM-YYYY when 2nd part <= 12)
            const dmyMatch = str.match(/^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})$/);
            if (dmyMatch) {
                const p1 = parseInt(dmyMatch[1], 10);
                const p2 = parseInt(dmyMatch[2], 10);
                const yr = dmyMatch[3];
                const day = p2 <= 12 ? p1 : p2;
                const mon = p2 <= 12 ? p2 : p1;
                return `${yr}-${String(mon).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            }
            return str;
        },

        buildUsernameForRow(row) {
            const strat = this.bulkConfig.username_strategy || 'email_prefix';
            const email = String(row.email || '').trim().toLowerCase();
            const code = String(row.employee_code || '').trim().toLowerCase();
            if (strat === 'employee_code' && code) {
                return code;
            }
            if (strat === 'full_email' && email) {
                return email;
            }
            if (email && email.includes('@')) {
                return email.split('@')[0];
            }
            return code || 'emp_user';
        },

        applyBulkCredentialsStrategy(overwriteAll = false) {
            this.bulkRows = this.bulkRows.map(r => {
                const updated = Object.assign({}, r);
                if (overwriteAll || !updated.username) {
                    updated.username = this.buildUsernameForRow(updated);
                }
                return updated;
            });
        },

        applyBulkPfStrategy(overwriteAll = false) {
            const targetVal = this.bulkConfig.default_pf_eligible ? '1' : '0';
            this.bulkRows = this.bulkRows.map(r => {
                const updated = Object.assign({}, r);
                if (overwriteAll || updated.pf_eligible === undefined || updated.pf_eligible === null || updated.pf_eligible === '') {
                    updated.pf_eligible = targetVal;
                }
                return updated;
            });
        },

        loadUserProvidedSheet() {
            this.bulkUploadedFileName = 'sample_demo_roster.xlsx';
            const initialData = [
                { employee_code: '1001', name: 'Jane Doe', phone: '01700000000', email: 'jane.doe@example.com', designation: 'Staff', department: 'General', join_date: '2024-01-01', employee_type: 'Permanent', dob: '1990-01-01', gender: 'female', basic_salary: 50000, pf_eligible: '1', username: '' },
                { employee_code: '1002', name: 'John Smith', phone: '01700000001', email: 'john.smith@example.com', designation: 'Staff', department: 'General', join_date: '2024-01-01', employee_type: 'Permanent', dob: '1992-05-15', gender: 'male', basic_salary: 50000, pf_eligible: '1', username: '' },
                { employee_code: '1003', name: 'Alex Roy', phone: '01700000002', email: 'alex.roy@example.com', designation: 'Staff', department: 'General', join_date: '2024-01-01', employee_type: 'Permanent', dob: '1995-09-20', gender: 'other', basic_salary: 50000, pf_eligible: '0', username: '' }
            ];
            this.bulkRows = initialData.map(r => {
                r.username = this.buildUsernameForRow(r);
                return r;
            });
            this.isDemoDataLoaded = true;
            this.bulkErrorMsg = '';
            this.$nextTick(() => {
                if (typeof lucide !== 'undefined') {
                    lucide.createIcons();
                }
            });
        },

        mapRawRecordsToBulkRows(records) {
            this.isDemoDataLoaded = false;
            const mappedRows = [];
            for (const rec of records) {
                const normObj = {};
                for (const k of Object.keys(rec)) {
                    const cleanKey = String(k).toLowerCase().replace(/[^a-z0-9]/g, '');
                    normObj[cleanKey] = String(rec[k] ?? '').trim();
                }
                const name = normObj.employeename || normObj.name || normObj.fullname || '';
                const code = normObj.id || normObj.employeeid || normObj.employeecode || normObj.code || '';
                const email = (normObj.email || normObj.emailaddress || '').toLowerCase();
                if (!name && !code && !email) continue;

                const rawSal = normObj.basicsalary || normObj.salary || normObj.basic || normObj.grosssalary || normObj.monthlysalary || '';
                const parsedSal = (rawSal && !isNaN(rawSal)) ? parseFloat(rawSal) : 0;

                // PF Eligibility parsing
                const rawPf = (normObj.pfeligible || normObj.pf || normObj.ispfeligible || normObj.pfapplicable || normObj.providentfund || normObj.pfstatus || normObj.pfmembership || '').trim().toLowerCase();
                let parsedPf = this.bulkConfig.default_pf_eligible ? '1' : '0';
                if (['1', 'true', 'yes', 'y', 'eligible', 'enrolled', 'active'].includes(rawPf)) {
                    parsedPf = '1';
                } else if (['exempt'].includes(rawPf)) {
                    parsedPf = 'exempt';
                } else if (['0', 'false', 'no', 'n', 'not eligible', 'not enrolled', 'closed'].includes(rawPf)) {
                    parsedPf = '0';
                } else if (rawPf !== '') {
                    parsedPf = (rawPf === '1' || rawPf === 'yes') ? '1' : '0';
                }

                const rawGender = (normObj.gender || normObj.sex || '').trim().toLowerCase();
                let parsedGender = '';
                if (['male', 'm'].includes(rawGender)) {
                    parsedGender = 'male';
                } else if (['female', 'f'].includes(rawGender)) {
                    parsedGender = 'female';
                } else if (['other', 'o'].includes(rawGender)) {
                    parsedGender = 'other';
                } else if (['male', 'female', 'other'].includes(rawGender)) {
                    parsedGender = rawGender;
                } else {
                    parsedGender = '';
                }

                const row = {
                    employee_code: code,
                    name: name,
                    phone: normObj.phone || normObj.mobile || normObj.contact || '',
                    email: email,
                    designation: normObj.designation || normObj.role || normObj.position || '',
                    department: normObj.department || normObj.dept || '',
                    join_date: this.normalizeDateForInput(normObj.joindate || normObj.joiningdate || normObj.hiredate || ''),
                    employee_type: normObj.employeetype || normObj.employmenttype || normObj.type || '',
                    dob: this.normalizeDateForInput(normObj.dateofbirth || normObj.dob || normObj.birthdate || ''),
                    gender: parsedGender,
                    basic_salary: parsedSal,
                    pf_eligible: parsedPf,
                    username: normObj.username || normObj.userid || ''
                };
                if (!row.username) {
                    row.username = this.buildUsernameForRow(row);
                }
                mappedRows.push(row);
            }
            if (mappedRows.length > 0) {
                this.bulkRows = mappedRows;
                this.bulkErrorMsg = '';
            } else {
                this.bulkErrorMsg = 'Could not detect valid employee rows. Ensure headers include Employee Name, ID, Phone, Email, Designation, Department.';
            }
        },

        handleBulkFileUpload(event) {
            const file = event.target.files ? event.target.files[0] : null;
            if (!file) return;
            this.bulkErrorMsg = '';
            this.isDemoDataLoaded = false;
            this.bulkUploadedFileName = file.name || 'uploaded_spreadsheet.xlsx';

            if (typeof XLSX !== 'undefined') {
                const reader = new FileReader();
                reader.onload = (e) => {
                    try {
                        const data = new Uint8Array(e.target.result);
                        const workbook = XLSX.read(data, { type: 'array', raw: false });
                        const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
                        const jsonRows = XLSX.utils.sheet_to_json(firstSheet, { defval: '' });
                        this.mapRawRecordsToBulkRows(jsonRows);
                    } catch (err) {
                        this.bulkErrorMsg = 'Failed to parse spreadsheet file: ' + (err.message || 'Invalid format');
                    }
                };
                reader.readAsArrayBuffer(file);
            } else {
                const reader = new FileReader();
                reader.onload = (e) => {
                    this.bulkRawPaste = e.target.result || '';
                    this.parseBulkPastedText();
                };
                reader.readAsText(file);
            }
        },

        parseBulkPastedText() {
            this.isDemoDataLoaded = false;
            const raw = (this.bulkRawPaste || '').trim();
            if (!raw) {
                this.bulkErrorMsg = 'Please paste rows from Excel first.';
                return;
            }
            const lines = raw.split(/\r\n|\r|\n/).filter(l => l.trim() !== '');
            if (lines.length < 2) {
                this.bulkErrorMsg = 'Please include both the header row and at least one employee data row.';
                return;
            }
            const delimiter = lines[0].includes('\t') ? '\t' : ',';
            const headers = lines[0].split(delimiter).map(h => h.trim());
            const records = [];
            for (let i = 1; i < lines.length; i++) {
                const cols = lines[i].split(delimiter);
                const obj = {};
                headers.forEach((h, idx) => {
                    obj[h] = (cols[idx] ?? '').trim();
                });
                records.push(obj);
            }
            this.mapRawRecordsToBulkRows(records);
        },

        addBlankBulkRow() {
            this.isDemoDataLoaded = false;
            this.bulkRows.push({
                employee_code: '',
                name: '',
                phone: '',
                email: '',
                designation: '',
                department: '',
                join_date: new Date().toISOString().split('T')[0],
                employee_type: '',
                dob: '',
                gender: '',
                basic_salary: 0,
                pf_eligible: (this.bulkConfig.default_pf_eligible ? '1' : '0'),
                username: ''
            });
        },

        removeBulkRow(idx) {
            this.bulkRows.splice(idx, 1);
            if (this.bulkRows.length === 0) {
                this.isDemoDataLoaded = false;
            }
        },

        async submitBulkUpload() {
            if (this.bulkRows.length === 0) return;
            if (this.isDemoDataLoaded) {
                this.bulkErrorMsg = 'Upload is disabled while demo data is loaded. Please upload real employee data.';
                return;
            }
            if (this.hasInvalidRows) {
                this.bulkErrorMsg = 'Cannot upload: Please fill in all required fields (Name, Gender, DOB, Department, Designation, and Employment Type) for all rows.';
                return;
            }
            this.isSubmittingBulkUpload = true;
            this.bulkErrorMsg = '';
            try {
                const payload = {
                    company_id: this.bulkConfig.company_id,
                    branch_id: this.bulkConfig.branch_id,
                    shift_id: this.bulkConfig.shift_id,
                    update_existing: this.bulkConfig.update_existing,
                    default_pf_eligible: this.bulkConfig.default_pf_eligible,
                    rows: this.bulkRows
                };

                const formData = new FormData();
                formData.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');
                formData.append('payload', JSON.stringify(payload));

                const res = await fetch('<?= base_url('employees/bulk-upload') ?>', {
                    method: 'POST',
                    body: formData,
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                });

                const data = await res.json();
                if (data.success) {
                    this.bulkUploadResult = {
                        message: data.message,
                        created_count: data.data?.created_count || 0,
                        updated_count: data.data?.updated_count || 0,
                        skipped_count: data.data?.skipped_count || 0,
                        failed_count: data.data?.failed_count || 0,
                        results: data.data?.results || []
                    };
                    this.$nextTick(() => {
                        if (typeof lucide !== 'undefined') {
                            lucide.createIcons();
                        }
                    });
                } else {
                    this.bulkErrorMsg = data.message || 'Bulk upload failed. Please check your inputs.';
                }
            } catch (err) {
                console.error('Bulk employee upload error:', err);
                this.bulkErrorMsg = 'Network error occurred while uploading employees.';
            } finally {
                this.isSubmittingBulkUpload = false;
            }
        },

        downloadFailedRowsCsv() {
            const results = (this.bulkUploadResult?.results || []).filter(r => r.status === 'failed');
            if (results.length === 0) return;
            const headers = ['Row', 'Employee ID', 'Employee Name', 'Status', 'Message'];
            const csvLines = [headers.join(',')];
            for (const r of results) {
                const rowVals = [
                    r.row || '',
                    r.employee_code || '',
                    r.name || '',
                    r.status || '',
                    r.message || ''
                ].map(v => `"${String(v).replace(/"/g, '""')}"`);
                csvLines.push(rowVals.join(','));
            }
            const blob = new Blob([csvLines.join('\n')], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'bulk_upload_failed_rows.csv';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        },

        downloadProvisionedCredentialsCsv() {
            const results = this.bulkUploadResult?.results || [];
            if (results.length === 0) return;
            const headers = ['Employee ID', 'Employee Name', 'Email', 'Phone', 'Department', 'Designation', 'Join Date', 'PF Eligible', 'PF Status', 'Username', 'Status'];
            const csvLines = [headers.join(',')];
            for (const r of results) {
                const rowVals = [
                    r.employee_code || '',
                    r.name || '',
                    r.email || '',
                    r.phone || '',
                    r.department || '',
                    r.designation || '',
                    r.join_date || '',
                    r.pf_eligible || '',
                    r.pf_status || '',
                    r.username || '',
                    r.status || ''
                ].map(v => `"${String(v).replace(/"/g, '""')}"`);
                csvLines.push(rowVals.join(','));
            }
            const blob = new Blob([csvLines.join('\n')], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'provisioned_employees_roster.csv';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }
    };
}
</script>
