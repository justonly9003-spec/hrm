<div class="max-w-5xl mx-auto space-y-6">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <div class="flex items-center gap-2 mb-1">
                <span class="text-[11px] font-bold px-2.5 py-0.5 rounded-md bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60">
                    Personnel Onboarding
                </span>
                <span class="text-[11px] text-slate-400 font-mono">Talent Acquisition</span>
            </div>
            <h2 class="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">New Employee Registration</h2>
            <p class="text-sm text-slate-500 dark:text-slate-400 mt-0.5">Provide official identity, departmental allocation, shift assignment, and compensation specs</p>
        </div>
        <a href="<?= base_url('employees') ?>" class="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/60 transition shadow-2xs">
            <i data-lucide="arrow-left" class="w-4 h-4 text-slate-400"></i>
            <span>Back to Directory</span>
        </a>
    </div>

    <!-- Working Sub-Navigation Bar -->
    <div class="flex items-center gap-2 p-1.5 bg-slate-100/80 dark:bg-slate-900/60 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 overflow-x-auto scrollbar-none">
        <a href="<?= base_url('employees') ?>" class="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold text-white bg-indigo-600 shadow-sm transition shrink-0">
            <i data-lucide="users" class="w-4 h-4 text-white"></i>
            <span>Employees Directory</span>
        </a>

        <a href="<?= base_url('attendance') ?>" class="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800 transition shrink-0">
            <i data-lucide="calendar-check" class="w-4 h-4 text-slate-500"></i>
            <span>Attendance & GPS</span>
        </a>

        <a href="<?= base_url('attendance/roster') ?>" class="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800 transition shrink-0">
            <i data-lucide="calendar-range" class="w-4 h-4 text-slate-500"></i>
            <span>Shift Rostering</span>
        </a>

        <a href="<?= base_url('attendance/overtime') ?>" class="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800 transition shrink-0">
            <i data-lucide="clock" class="w-4 h-4 text-slate-500"></i>
            <span>Overtime & Claims</span>
        </a>

        <a href="<?= base_url('attendance/sync') ?>" class="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800 transition shrink-0">
            <i data-lucide="refresh-cw" class="w-4 h-4 text-slate-500"></i>
            <span>Biometric Device Sync</span>
        </a>

        <a href="<?= base_url('leave') ?>" class="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800 transition shrink-0">
            <i data-lucide="calendar-off" class="w-4 h-4 text-slate-500"></i>
            <span>Leave Balances & Approval</span>
        </a>
    </div>

    <!-- Main Registration Card -->
    <form action="<?= base_url('employees/store') ?>" method="POST" class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-6">
        <?= csrf_field() ?>

        <?php if (!empty($unmatchedBiometric)): ?>
            <!-- Biometric Onboarding Callout Banner -->
            <div class="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-900 dark:text-amber-200">
                <div class="flex items-start gap-3">
                    <div class="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                        <i data-lucide="fingerprint" class="w-5 h-5"></i>
                    </div>
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center gap-2">
                            <span class="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-300">Biometric Machine Staff Onboarding</span>
                            <span class="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-800 dark:text-amber-300 font-mono font-bold">Auto-Link Enabled</span>
                        </div>
                        <p class="text-xs mt-1 text-slate-700 dark:text-slate-300">
                            Onboarding identity for Biometric User ID <strong class="font-mono text-amber-700 dark:text-amber-400 font-bold"><?= esc($unmatchedBiometric['biometric_user_id']) ?></strong>
                            <?php if (!empty($unmatchedBiometric['name_from_device'])): ?>
                                (Name from machine: <strong><?= esc($unmatchedBiometric['name_from_device']) ?></strong>)
                            <?php endif; ?>
                            from device <strong><?= esc($unmatchedBiometric['device_name'] ?? 'Biometric Device') ?></strong>.
                            Submitting this form will register the employee in HRM and immediately credit their <strong><?= esc($unmatchedBiometric['event_count']) ?> unprocessed punches</strong>.
                        </p>
                    </div>
                </div>
                <input type="hidden" name="unmatched_biometric_id" value="<?= esc($unmatchedBiometric['id']) ?>">
                <input type="hidden" name="biometric_user_id" value="<?= esc($unmatchedBiometric['biometric_user_id']) ?>">
                <input type="hidden" name="biometric_device_id" value="<?= esc($unmatchedBiometric['device_id'] ?? '') ?>">
            </div>
        <?php endif; ?>
        
        <!-- Section 0: Tenant & Company Entity Context -->
        <div class="border-b border-slate-100 dark:border-slate-700/60 pb-5">
            <div class="flex items-center justify-between mb-3">
                <div class="flex items-center gap-2">
                    <div class="w-7 h-7 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-xs">
                        <i data-lucide="building-2" class="w-4 h-4"></i>
                    </div>
                    <div>
                        <h3 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Company Legal Entity & Tenant Scoping</h3>
                        <p class="text-[11px] text-slate-500">Employment types, branches, shifts, and departments are strictly isolated to this company.</p>
                    </div>
                </div>
                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200/60 dark:border-emerald-800/60 flex items-center gap-1">
                    <i data-lucide="shield-check" class="w-3 h-3"></i>
                    <span>Tenant Isolated</span>
                </span>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <?php if (!empty($isSoftwareAdmin)): ?>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Company Legal Entity *</label>
                        <select name="company_id" id="company_select" onchange="onCompanySelectChanged(this.value)" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                            <?php foreach ($companies as $comp): ?>
                                <option value="<?= esc($comp['id']) ?>" <?= (string)($selectedCompanyId ?? '') === (string)$comp['id'] ? 'selected' : '' ?>>
                                    <?= esc($comp['name']) ?> (<?= esc($comp['code'] ?? 'TENANT') ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                <?php else: ?>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Company Legal Entity</label>
                        <div class="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 text-xs font-semibold text-slate-900 dark:text-white flex items-center justify-between">
                            <span><?= esc($companies[0]['name'] ?? 'Authorized Company') ?></span>
                            <span class="text-[10px] font-mono text-slate-400"><?= esc($companies[0]['code'] ?? '') ?></span>
                        </div>
                        <input type="hidden" name="company_id" id="company_select" value="<?= esc($companies[0]['id'] ?? '') ?>">
                    </div>
                <?php endif; ?>

                <div class="flex items-center">
                    <div class="p-2.5 rounded-xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 text-indigo-900 dark:text-indigo-200 text-xs flex items-center gap-2 w-full">
                        <i data-lucide="info" class="w-4 h-4 shrink-0 text-indigo-600 dark:text-indigo-400"></i>
                        <span class="text-[11px]">Only employment types configured for your company will be available for contract selection.</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section 1 -->
        <div class="border-b border-slate-100 dark:border-slate-700/60 pb-5">
            <div class="flex items-center gap-2 mb-4">
                <div class="w-7 h-7 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-xs">
                    1
                </div>
                <h3 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Personal & Identity Details</h3>
            </div>
            
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                <div>
                    <div class="flex items-center justify-between mb-1">
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300">Employee Code *</label>
                        <span id="code_status_msg" class="text-[10px] font-mono hidden"></span>
                    </div>
                    <div class="relative">
                        <input type="text" name="employee_code" id="employee_code_input" value="<?= esc($suggestedEmployeeCode ?? '') ?>" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono uppercase text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                        <div id="code_checking_spinner" class="absolute right-3 top-2.5 text-slate-400 hidden pointer-events-none">
                            <svg class="animate-spin w-4 h-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                        </div>
                    </div>
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Full Legal Name *</label>
                    <input type="text" name="name" value="<?= esc($unmatchedBiometric['name_from_device'] ?? '') ?>" required placeholder="e.g. Johnathan Vance" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Official Email Address *</label>
                    <input type="email" name="email" required placeholder="e.g. john@enterprise.com" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Contact Phone</label>
                    <input type="text" name="phone" placeholder="+1 (555) 234-5678" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Join Date *</label>
                    <input type="date" name="joining_date" value="<?= date('Y-m-d') ?>" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Gender *</label>
                    <select name="gender" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                        <option value="">-- Select Gender --</option>
                        <option value="male" <?= old('gender') === 'male' ? 'selected' : '' ?>>Male</option>
                        <option value="female" <?= old('gender') === 'female' ? 'selected' : '' ?>>Female</option>
                        <option value="other" <?= old('gender') === 'other' ? 'selected' : '' ?>>Other</option>
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Date of Birth *</label>
                    <input type="date" name="dob" value="<?= esc(old('dob', '')) ?>" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Employment Type <span class="text-rose-500">*</span>
                    </label>
                    <select name="employment_type_id" id="employment_type_select" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                        <option value="">-- Select Company Employment Type --</option>
                        <?php foreach ($employmentTypes as $et): ?>
                            <option value="<?= esc($et['id']) ?>" data-company="<?= esc($et['company_id'] ?? '') ?>">
                                <?= esc($et['name']) ?> <?= !empty($et['code']) ? '(' . esc($et['code']) . ')' : '' ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p class="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
                        <i data-lucide="lock" class="w-3 h-3 text-indigo-500"></i>
                        <span>Company tenant-isolated contract types only</span>
                    </p>
                </div>
            </div>
        </div>

        <!-- Section 2 -->
        <div class="border-b border-slate-100 dark:border-slate-700/60 pb-5">
            <div class="flex items-center gap-2 mb-4">
                <div class="w-7 h-7 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-xs">
                    2
                </div>
                <h3 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Organizational Placement & Rostering</h3>
            </div>
            
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Department *</label>
                    <select name="department_id" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                        <option value="">Select Department</option>
                        <?php foreach ($departments as $d): ?>
                            <option value="<?= esc($d['id']) ?>"><?= esc($d['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Designation / Role *</label>
                    <select name="designation_id" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                        <option value="">Select Designation</option>
                        <?php foreach ($designations as $ds): ?>
                            <option value="<?= esc($ds['id']) ?>"><?= esc($ds['name'] ?? $ds['title'] ?? '') ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Assigned Branch *</label>
                    <select name="branch_id" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                        <option value="">Select Branch</option>
                        <?php foreach ($branches as $b): ?>
                            <option value="<?= esc($b['id']) ?>"><?= esc($b['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Working Shift *</label>
                    <select name="shift_id" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                        <option value="">Select Shift</option>
                        <?php foreach ($shifts as $s): ?>
                            <option value="<?= esc($s['id']) ?>"><?= esc($s['name']) ?> (<?= esc($s['start_time']) ?> - <?= esc($s['end_time']) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
        </div>

        <!-- Section 3 -->
        <div>
            <div class="flex items-center justify-between mb-4">
                <div class="flex items-center gap-2">
                    <div class="w-7 h-7 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-xs">
                        3
                    </div>
                    <h3 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Compensation, Allowances & Banking</h3>
                </div>
                <span class="text-[11px] font-medium text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/50 px-2 py-0.5 rounded-full border border-amber-200/60 dark:border-amber-800/50">
                    Optional during onboarding &bull; Can be configured post-joining
                </span>
            </div>
            
            <div class="p-3 bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl mb-4 flex items-center justify-between">
                <div>
                    <span class="text-xs font-bold text-slate-700 dark:text-slate-200">Salary Assignment Governed by Payroll</span>
                    <p class="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                        New employees are initialized with status <span class="font-semibold text-amber-600 dark:text-amber-400">NOT_CONFIGURED</span>. Salaries and allowances are configured post-creation via Salary Assignments.
                    </p>
                </div>
                <a href="<?= base_url('payroll?tab=structures&subtab=assignment') ?>" target="_blank" class="px-3 py-1.5 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 rounded-xl text-xs font-bold border border-indigo-200 dark:border-indigo-800 flex items-center gap-1.5 shrink-0 hover:bg-indigo-100">
                    <span>Salary Assignments</span>
                    <i data-lucide="external-link" class="w-3.5 h-3.5"></i>
                </a>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Basic Monthly Salary ($)</label>
                    <input type="number" step="0.01" min="0" name="basic_salary" value="<?= esc(old('basic_salary', '')) ?>" placeholder="e.g. 35000" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">House Rent Allowance ($)</label>
                    <input type="number" step="0.01" min="0" name="house_rent_allowance" value="<?= esc(old('house_rent_allowance', '')) ?>" placeholder="Optional (e.g. 15000)" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Bank Name</label>
                    <input type="text" name="bank_name" value="<?= esc(old('bank_name', '')) ?>" placeholder="e.g. JPMorgan Chase" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Bank Account Number</label>
                    <input type="text" name="bank_account" value="<?= esc(old('bank_account', '')) ?>" placeholder="e.g. 9876543210" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                </div>
            </div>
        </div>

        <!-- Section 4: System Access & Login Credentials -->
        <div class="p-4 bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 rounded-2xl space-y-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-2">
                    <div class="w-7 h-7 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold text-xs">
                        4
                    </div>
                    <h3 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">System Login & Credentials Provisioning</h3>
                </div>
                <span class="px-2 py-0.5 bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 rounded text-[10px] font-bold">Auto-Provisioned</span>
            </div>
            
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div class="bg-white dark:bg-slate-800 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                    <span class="text-[10px] text-slate-400 font-bold uppercase block">Default Username</span>
                    <span class="font-mono font-bold text-slate-700 dark:text-slate-300 text-xs block mt-0.5">Based on email prefix (e.g. john)</span>
                </div>
                <div class="bg-white dark:bg-slate-800 p-3 rounded-xl border border-indigo-200 dark:border-indigo-800">
                    <span class="text-[10px] text-indigo-500 dark:text-indigo-400 font-bold uppercase block">Default Login Password</span>
                    <span class="font-mono font-bold text-indigo-600 dark:text-indigo-400 text-sm block mt-0.5">123456</span>
                </div>
            </div>
            <p class="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <i data-lucide="shield-check" class="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0"></i>
                All newly created employees are automatically granted a system login with default password <strong class="font-mono text-slate-900 dark:text-white">123456</strong>.
            </p>
        </div>

        <div class="flex items-center justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-700/60">
            <a href="<?= base_url('employees') ?>" class="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition">
                Cancel
            </a>
            <button type="submit" class="inline-flex items-center gap-2 px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition">
                <i data-lucide="check" class="w-4 h-4"></i>
                <span>Save & Onboard Employee</span>
            </button>
        </div>
    </form>
</div>

<script>
    const allEmploymentTypes = <?= json_encode($allEmploymentTypes ?? []) ?>;

    let availabilityStatus = null; // null | 'taken'
    let isCheckingAvailability = false;

    function setIdleState() {
        availabilityStatus = null;
        isCheckingAvailability = false;
        const statusMsg = document.getElementById('code_status_msg');
        const spinner = document.getElementById('code_checking_spinner');
        const input = document.getElementById('employee_code_input');
        if (statusMsg) {
            statusMsg.textContent = '';
            statusMsg.className = 'text-[10px] font-mono hidden';
        }
        if (spinner) {
            spinner.classList.add('hidden');
        }
        if (input) {
            input.classList.remove('border-rose-400', 'focus:ring-rose-500');
            input.classList.add('border-slate-200', 'dark:border-slate-700');
        }
    }

    async function refreshAuthoritativeCode() {
        const input = document.getElementById('employee_code_input');
        const companySelect = document.querySelector('select[name="company_id"]');
        const companyId = companySelect ? companySelect.value : '';

        try {
            const res = await fetch(`<?= base_url('employees/next-code') ?>?company_id=${encodeURIComponent(companyId)}`);
            if (res.ok) {
                const data = await res.json();
                if (data && data.status === 'success' && data.employee_code) {
                    if (input) input.value = data.employee_code;
                }
            }
        } catch (err) {
            console.error('Failed to fetch next employee code:', err);
        } finally {
            setIdleState();
        }
    }

    async function checkCodeAvailability() {
        const input = document.getElementById('employee_code_input');
        const statusMsg = document.getElementById('code_status_msg');
        const spinner = document.getElementById('code_checking_spinner');
        if (!input) return;
        const code = input.value.trim();
        if (!code) {
            setIdleState();
            return;
        }

        isCheckingAvailability = true;
        if (spinner) spinner.classList.remove('hidden');
        if (statusMsg) {
            statusMsg.textContent = 'Checking...';
            statusMsg.className = 'text-[10px] font-mono text-slate-400';
            statusMsg.classList.remove('hidden');
        }

        try {
            const compSelect = document.getElementById('company_select');
            const companyId = compSelect ? compSelect.value : '';
            const res = await fetch(`<?= base_url('employees/check-code') ?>?code=${encodeURIComponent(code)}&company_id=${encodeURIComponent(companyId)}`);
            if (res.ok) {
                const data = await res.json();
                if (data.exists) {
                    availabilityStatus = 'taken';
                    if (statusMsg) {
                        statusMsg.textContent = 'Already exists in database!';
                        statusMsg.className = 'text-[10px] font-mono font-semibold text-rose-600 dark:text-rose-400';
                        statusMsg.classList.remove('hidden');
                    }
                    input.classList.add('border-rose-400', 'focus:ring-rose-500');
                    input.classList.remove('border-slate-200', 'dark:border-slate-700');
                } else {
                    setIdleState();
                }
            } else {
                setIdleState();
            }
        } catch (e) {
            setIdleState();
        } finally {
            isCheckingAvailability = false;
            if (spinner) spinner.classList.add('hidden');
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        const input = document.getElementById('employee_code_input');
        if (input) {
            input.addEventListener('blur', checkCodeAvailability);
            input.addEventListener('input', () => {
                if (availabilityStatus === 'taken') {
                    setIdleState();
                }
            });
        }
        setIdleState();
    });

    function onCompanySelectChanged(companyId) {
        refreshAuthoritativeCode();
        const typeSelect = document.getElementById('employment_type_select');
        if (!typeSelect) return;

        typeSelect.innerHTML = '<option value="">-- Select Company Employment Type --</option>';

        let filteredTypes = [];
        if (companyId) {
            filteredTypes = allEmploymentTypes.filter(et => et.company_id === companyId);
            if (filteredTypes.length === 0) {
                // Fallback to unassigned global types only, NEVER another company's types
                filteredTypes = allEmploymentTypes.filter(et => !et.company_id);
            }
        } else {
            filteredTypes = allEmploymentTypes;
        }

        filteredTypes.forEach(et => {
            const opt = document.createElement('option');
            opt.value = et.id;
            opt.textContent = et.name + (et.code ? ` (${et.code})` : '');
            typeSelect.appendChild(opt);
        });

        if (filteredTypes.length > 0) {
            typeSelect.value = filteredTypes[0].id;
        }
    }
</script>
