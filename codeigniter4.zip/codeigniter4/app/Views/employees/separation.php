<div class="space-y-6" x-data="separationConsole('<?= esc($currentSubtab ?? 'resignation') ?>')">

    <!-- Header Section -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <div class="flex items-center gap-2 mb-1">
                <span class="text-[11px] font-bold px-2.5 py-0.5 rounded-md bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400 border border-rose-200/60 dark:border-rose-800/60">
                    Personnel Offboarding & Separation
                </span>
                <span class="text-[11px] text-slate-400 font-mono">
                    <?= !empty($isSoftwareAdmin) ? 'Multi-Tenant Governance' : 'Clearance & Settlement Engine' ?>
                </span>
            </div>
            <h2 class="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">Separation & Offboarding</h2>
            <p class="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                Process resignations, administrative terminations, departmental clearances, and final dues settlement drafts.
            </p>
        </div>

        <div class="flex flex-wrap items-center gap-2.5">
            <button type="button" @click="resignationModalOpen = true" class="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/60 shadow-2xs transition">
                <i data-lucide="file-text" class="w-4 h-4 text-slate-500"></i>
                <span>Submit Resignation</span>
            </button>

            <?php if (!empty($canTerminate)): ?>
            <button type="button" @click="terminationModalOpen = true" class="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 shadow-sm transition">
                <i data-lucide="shield-alert" class="w-4 h-4"></i>
                <span>Record Termination</span>
            </button>
            <?php endif; ?>
        </div>
    </div>

    <!-- Shared Employees Module Navigation Tabs -->
    <?= view('employees/_tabs', ['activeTab' => 'separation']) ?>

    <!-- Sub-navigation: Resignation / Termination / Settlement -->
    <div class="flex items-center gap-2 border-b border-slate-200 dark:border-slate-700 pb-2">
        <a href="<?= base_url('employees/separation/resignation') ?>"
           class="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition <?= ($currentSubtab === 'resignation') ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800' ?>">
            <i data-lucide="log-out" class="w-4 h-4"></i>
            <span>Resignations</span>
            <?php if (!empty($pendingResignations)): ?>
                <span class="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-amber-500 text-white font-extrabold"><?= $pendingResignations ?></span>
            <?php endif; ?>
        </a>

        <a href="<?= base_url('employees/separation/termination') ?>"
           class="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition <?= ($currentSubtab === 'termination') ? 'bg-rose-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800' ?>">
            <i data-lucide="shield-alert" class="w-4 h-4"></i>
            <span>Terminations</span>
            <?php if (!empty($pendingClearances)): ?>
                <span class="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-rose-700 text-white font-extrabold"><?= $pendingClearances ?></span>
            <?php endif; ?>
        </a>

        <a href="<?= base_url('employees/separation/settlement') ?>"
           class="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition <?= ($currentSubtab === 'settlement') ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800' ?>">
            <i data-lucide="receipt" class="w-4 h-4"></i>
            <span>Final Settlement Statements</span>
            <span class="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200"><?= count($settlements ?? []) ?></span>
        </a>
    </div>

    <!-- SUBTAB 1: RESIGNATIONS -->
    <?php if ($currentSubtab === 'resignation'): ?>
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-2xs">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
                <thead class="bg-slate-50/80 dark:bg-slate-900/60 border-b border-slate-200/80 dark:border-slate-700 text-slate-500 dark:text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                    <tr>
                        <th class="py-3 px-4">Employee</th>
                        <th class="py-3 px-4">Notice Date</th>
                        <th class="py-3 px-4">Target Last Day</th>
                        <th class="py-3 px-4">Reason / Remarks</th>
                        <th class="py-3 px-4">Clearance</th>
                        <th class="py-3 px-4">Status</th>
                        <th class="py-3 px-4 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-700/60">
                    <?php if (empty($resignations)): ?>
                        <tr>
                            <td colspan="7" class="py-12 text-center text-slate-400">
                                <div class="flex flex-col items-center justify-center gap-2">
                                    <i data-lucide="user-check" class="w-8 h-8 text-slate-300 dark:text-slate-600"></i>
                                    <p class="font-medium text-slate-500 dark:text-slate-400">No resignation records found.</p>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($resignations as $r): ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-750 transition-colors">
                                <td class="py-3 px-4">
                                    <div class="font-semibold text-slate-900 dark:text-white">
                                        <?= esc(trim(($r['first_name'] ?? '') . ' ' . ($r['last_name'] ?? ''))) ?>
                                    </div>
                                    <div class="text-[10px] text-slate-400 font-mono"><?= esc($r['employee_code']) ?> &bull; <?= esc($r['designation_name'] ?? 'Staff') ?></div>
                                </td>
                                <td class="py-3 px-4 font-mono text-slate-600 dark:text-slate-400">
                                    <?= esc($r['notice_date'] ?: $r['submission_date']) ?>
                                </td>
                                <td class="py-3 px-4 font-mono font-semibold text-slate-800 dark:text-slate-200">
                                    <?= esc($r['resignation_date'] ?: 'Pending Review') ?>
                                </td>
                                <td class="py-3 px-4 text-slate-600 dark:text-slate-400 max-w-[220px] truncate">
                                    <?= esc($r['reason'] ?: 'Career Transition') ?>
                                </td>
                                <td class="py-3 px-4">
                                    <span class="px-2 py-0.5 rounded text-[10px] font-semibold <?= ($r['clearance_status'] ?? '') === 'Cleared' ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400' : 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400' ?>">
                                        <?= esc($r['clearance_status'] ?? 'In Progress') ?>
                                    </span>
                                </td>
                                <td class="py-3 px-4">
                                    <?php if ($r['status'] === 'Approved'): ?>
                                        <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
                                            Approved
                                        </span>
                                    <?php elseif ($r['status'] === 'Rejected'): ?>
                                        <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400 border border-rose-200 dark:border-rose-800">
                                            Rejected
                                        </span>
                                    <?php else: ?>
                                        <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400 border border-amber-200 dark:border-amber-800">
                                            Pending Review
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3 px-4 text-right">
                                    <div class="flex items-center justify-end gap-1.5">
                                        <?php 
                                        $isOwn = ((string)$r['employee_id'] === (string)($currentEmployeeId ?? ''));
                                        if ($r['status'] === 'Pending' && !$isOwn && !empty($canApproveResignation)): 
                                        ?>
                                            <button type="button" @click="openApproveResignationModal(<?= htmlspecialchars(json_encode($r), ENT_QUOTES) ?>)" class="px-2.5 py-1 rounded-lg text-xs font-semibold bg-emerald-50 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-950/60 dark:text-emerald-400 transition">
                                                Approve
                                            </button>
                                            <button type="button" @click="openRejectResignationModal(<?= htmlspecialchars(json_encode($r), ENT_QUOTES) ?>)" class="px-2.5 py-1 rounded-lg text-xs font-semibold bg-rose-50 text-rose-700 hover:bg-rose-100 dark:bg-rose-950/60 dark:text-rose-400 transition">
                                                Reject
                                            </button>
                                        <?php endif; ?>
                                        <a href="<?= base_url('employees/profile/' . $r['employee_id'] . '?tab=exit') ?>" class="p-1 text-slate-400 hover:text-indigo-600 transition" title="View Profile">
                                            <i data-lucide="user" class="w-4 h-4"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

    <!-- SUBTAB 2: TERMINATIONS -->
    <?php if ($currentSubtab === 'termination'): ?>
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-2xs">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
                <thead class="bg-slate-50/80 dark:bg-slate-900/60 border-b border-slate-200/80 dark:border-slate-700 text-slate-500 dark:text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                    <tr>
                        <th class="py-3 px-4">Employee</th>
                        <th class="py-3 px-4">Date</th>
                        <th class="py-3 px-4">Type</th>
                        <th class="py-3 px-4">Reason</th>
                        <th class="py-3 px-4">Clearance Status</th>
                        <th class="py-3 px-4">Settlement</th>
                        <th class="py-3 px-4 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-700/60">
                    <?php if (empty($terminations)): ?>
                        <tr>
                            <td colspan="7" class="py-12 text-center text-slate-400">
                                <div class="flex flex-col items-center justify-center gap-2">
                                    <i data-lucide="shield-check" class="w-8 h-8 text-slate-300 dark:text-slate-600"></i>
                                    <p class="font-medium text-slate-500 dark:text-slate-400">No termination records found.</p>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($terminations as $t): ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-750 transition-colors">
                                <td class="py-3 px-4">
                                    <div class="font-semibold text-slate-900 dark:text-white">
                                        <?= esc(trim(($t['first_name'] ?? '') . ' ' . ($t['last_name'] ?? ''))) ?>
                                    </div>
                                    <div class="text-[10px] text-slate-400 font-mono"><?= esc($t['employee_code']) ?> &bull; <?= esc($t['designation_name'] ?? 'Staff') ?></div>
                                </td>
                                <td class="py-3 px-4 font-mono text-slate-600 dark:text-slate-400">
                                    <?= esc($t['termination_date']) ?>
                                </td>
                                <td class="py-3 px-4 font-medium text-slate-800 dark:text-slate-200">
                                    <?= esc($t['termination_type'] ?? 'Termination') ?>
                                </td>
                                <td class="py-3 px-4 text-slate-600 dark:text-slate-400 max-w-[220px] truncate">
                                    <?= esc($t['reason']) ?>
                                </td>
                                <td class="py-3 px-4">
                                    <span class="px-2 py-0.5 rounded text-[10px] font-semibold <?= ($t['clearance_status'] ?? '') === 'Cleared' ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400' : 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400' ?>">
                                        <?= esc($t['clearance_status'] ?? 'In Progress') ?>
                                    </span>
                                </td>
                                <td class="py-3 px-4">
                                    <span class="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                                        <?= esc($t['final_settlement_status'] ?? 'Pending') ?>
                                    </span>
                                </td>
                                <td class="py-3 px-4 text-right">
                                    <a href="<?= base_url('employees/profile/' . $t['employee_id'] . '?tab=exit') ?>" class="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:text-indigo-400 transition">
                                        <span>View Exit File</span>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

    <!-- SUBTAB 3: FINAL SETTLEMENTS -->
    <?php if ($currentSubtab === 'settlement'): ?>
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-2xs">
        <div class="p-4 bg-slate-50/60 dark:bg-slate-900/40 border-b border-slate-200/80 dark:border-slate-700 flex items-center justify-between">
            <div class="flex items-center gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600"></i>
                <span class="text-xs font-medium text-slate-600 dark:text-slate-300">
                    Final settlements are prepared here and calculated through the authoritative Payroll Final Settlement Engine.
                </span>
            </div>
            <a href="<?= base_url('payroll?tab=settlement') ?>" class="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 transition">
                <span>Open Payroll Statement Console</span>
                <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
            </a>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
                <thead class="bg-slate-50/80 dark:bg-slate-900/60 border-b border-slate-200/80 dark:border-slate-700 text-slate-500 dark:text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                    <tr>
                        <th class="py-3 px-4">Settlement ID</th>
                        <th class="py-3 px-4">Employee</th>
                        <th class="py-3 px-4">Separation Type</th>
                        <th class="py-3 px-4">Last Working Day</th>
                        <th class="py-3 px-4">Net Dues</th>
                        <th class="py-3 px-4">Payment Status</th>
                        <th class="py-3 px-4 text-right">Payroll Statement</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-700/60">
                    <?php if (empty($settlements)): ?>
                        <tr>
                            <td colspan="7" class="py-12 text-center text-slate-400">
                                <div class="flex flex-col items-center justify-center gap-2">
                                    <i data-lucide="receipt" class="w-8 h-8 text-slate-300 dark:text-slate-600"></i>
                                    <p class="font-medium text-slate-500 dark:text-slate-400">No final settlement statements recorded.</p>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($settlements as $s): ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-750 transition-colors">
                                <td class="py-3 px-4 font-mono font-bold text-indigo-600 dark:text-indigo-400">
                                    <?= esc($s['id']) ?>
                                </td>
                                <td class="py-3 px-4">
                                    <div class="font-semibold text-slate-900 dark:text-white">
                                        <?= esc(trim(($s['first_name'] ?? '') . ' ' . ($s['last_name'] ?? ''))) ?>
                                    </div>
                                    <div class="text-[10px] text-slate-400 font-mono"><?= esc($s['employee_code']) ?></div>
                                </td>
                                <td class="py-3 px-4 font-medium text-slate-700 dark:text-slate-300">
                                    <?= esc($s['separation_type'] ?? 'Resignation') ?>
                                </td>
                                <td class="py-3 px-4 font-mono text-slate-600 dark:text-slate-400">
                                    <?= esc($s['last_working_day']) ?>
                                </td>
                                <td class="py-3 px-4 font-mono font-bold text-slate-900 dark:text-white">
                                    <?php if (!empty($canViewSalary) && isset($s['net_settlement_amount'])): ?>
                                        <?= number_format((float)$s['net_settlement_amount'], 2) ?>
                                    <?php else: ?>
                                        <span class="text-slate-400 font-sans text-[11px] font-normal italic">Restricted</span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3 px-4">
                                    <?php if ($s['payment_status'] === 'Disbursed' || $s['payment_status'] === 'Settled'): ?>
                                        <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
                                            Disbursed
                                        </span>
                                    <?php elseif ($s['payment_status'] === 'Approved'): ?>
                                        <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800">
                                            Approved
                                        </span>
                                    <?php else: ?>
                                        <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400 border border-amber-200 dark:border-amber-800">
                                            Draft
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3 px-4 text-right">
                                    <a href="<?= base_url('payroll?tab=settlement&employee_id=' . $s['employee_id']) ?>" class="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:text-indigo-400 transition">
                                        <span>Payroll Statement</span>
                                        <i data-lucide="external-link" class="w-3 h-3"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

    <!-- MODAL: Submit Resignation -->
    <template x-if="resignationModalOpen">
        <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs" @click.self="resignationModalOpen = false">
            <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200 dark:border-slate-700 space-y-4">
                <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                    <h3 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                        <i data-lucide="log-out" class="w-4 h-4 text-indigo-600"></i>
                        Submit Employee Resignation
                    </h3>
                    <button type="button" @click="resignationModalOpen = false" class="text-slate-400 hover:text-slate-600">
                        <i data-lucide="x" class="w-4 h-4"></i>
                    </button>
                </div>

                <form action="<?= base_url('employees/separation/resignation/submit') ?>" method="POST" class="space-y-4 text-xs">
                    <?= csrf_field() ?>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Select Employee <span class="text-rose-500">*</span>:</label>
                        <select name="employee_id" required class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                            <option value="">-- Choose Employee --</option>
                            <?php foreach ($employeeOptions as $op): ?>
                                <option value="<?= esc($op['id']) ?>">
                                    <?= esc(trim(($op['first_name'] ?? '') . ' ' . ($op['last_name'] ?? ''))) ?> (<?= esc($op['employee_code']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Notice Tender Date <span class="text-rose-500">*</span>:</label>
                            <input type="date" name="notice_date" value="<?= date('Y-m-d') ?>" required class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                        </div>
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Requested Last Working Day:</label>
                            <input type="date" name="resignation_date" value="<?= date('Y-m-d', strtotime('+30 days')) ?>" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                        </div>
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Resignation Reason <span class="text-rose-500">*</span>:</label>
                        <textarea name="reason" rows="3" required placeholder="Reason for resignation tender..." class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white"></textarea>
                    </div>

                    <div class="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-700">
                        <button type="button" @click="resignationModalOpen = false" class="px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-bold">Cancel</button>
                        <button type="submit" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold">Save Resignation</button>
                    </div>
                </form>
            </div>
        </div>
    </template>

    <!-- MODAL: Record Termination (With Required Checklist) -->
    <template x-if="terminationModalOpen">
        <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs" @click.self="terminationModalOpen = false">
            <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200 dark:border-slate-700 space-y-4">
                <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                    <h3 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                        <i data-lucide="shield-alert" class="w-4 h-4 text-rose-600"></i>
                        Record Employee Termination & Offboarding
                    </h3>
                    <button type="button" @click="terminationModalOpen = false" class="text-slate-400 hover:text-slate-600">
                        <i data-lucide="x" class="w-4 h-4"></i>
                    </button>
                </div>

                <form action="<?= base_url('employees/separation/termination/save') ?>" method="POST" class="space-y-4 text-xs">
                    <?= csrf_field() ?>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Select Employee <span class="text-rose-500">*</span>:</label>
                        <select name="employee_id" required class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                            <option value="">-- Choose Employee --</option>
                            <?php foreach ($employeeOptions as $op): ?>
                                <option value="<?= esc($op['id']) ?>">
                                    <?= esc(trim(($op['first_name'] ?? '') . ' ' . ($op['last_name'] ?? ''))) ?> (<?= esc($op['employee_code']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Termination Type:</label>
                            <select name="termination_type" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                                <option value="Involuntary Termination">Involuntary Termination</option>
                                <option value="Gross Misconduct">Gross Misconduct</option>
                                <option value="Contract Expiry">Contract Expiry</option>
                                <option value="Redundancy / Layoff">Redundancy / Layoff</option>
                                <option value="Mutual Separation">Mutual Separation</option>
                            </select>
                        </div>
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Termination Effective Date <span class="text-rose-500">*</span>:</label>
                            <input type="date" name="termination_date" value="<?= date('Y-m-d') ?>" required class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                        </div>
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Formal Termination Reason <span class="text-rose-500">*</span>:</label>
                        <textarea name="reason" rows="2" required placeholder="Mandatory official justification..." class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white"></textarea>
                    </div>

                    <!-- Mandatory Clearance Checklist -->
                    <div class="p-3 bg-amber-50/70 dark:bg-amber-950/30 rounded-xl border border-amber-200/60 dark:border-amber-900/40 space-y-2">
                        <div class="font-bold text-amber-900 dark:text-amber-300 flex items-center gap-1.5">
                            <i data-lucide="check-square" class="w-4 h-4 text-amber-600"></i>
                            Mandatory Clearance Checklist Verification
                        </div>
                        <div class="space-y-1.5 text-[11px] text-slate-700 dark:text-slate-300">
                            <label class="flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" name="checklist_assets" required class="rounded text-rose-600 focus:ring-rose-500">
                                <span>All company assets & hardware surrendered or flagged for recovery</span>
                            </label>
                            <label class="flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" name="checklist_docs" required class="rounded text-rose-600 focus:ring-rose-500">
                                <span>Security tokens, keycards & access credentials revoked</span>
                            </label>
                            <label class="flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" name="checklist_dues" required class="rounded text-rose-600 focus:ring-rose-500">
                                <span>User account disabled and final settlement statement draft initialized</span>
                            </label>
                        </div>
                    </div>

                    <div class="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-700">
                        <button type="button" @click="terminationModalOpen = false" class="px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-bold">Cancel</button>
                        <button type="submit" class="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold">Process Termination</button>
                    </div>
                </form>
            </div>
        </div>
    </template>

    <!-- MODAL: Approve Resignation -->
    <template x-if="approveModalOpen">
        <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs" @click.self="approveModalOpen = false">
            <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-700 space-y-4">
                <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                    <h3 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                        <i data-lucide="check-circle" class="w-4 h-4 text-emerald-600"></i>
                        Approve Resignation
                    </h3>
                    <button type="button" @click="approveModalOpen = false" class="text-slate-400 hover:text-slate-600">
                        <i data-lucide="x" class="w-4 h-4"></i>
                    </button>
                </div>

                <form :action="'<?= base_url('employees/separation/resignation/approve') ?>/' + selectedResignation.id" method="POST" class="space-y-4 text-xs">
                    <?= csrf_field() ?>
                    <p class="text-slate-600 dark:text-slate-300">
                        Approve resignation for <strong class="text-slate-900 dark:text-white" x-text="selectedResignation.first_name + ' ' + selectedResignation.last_name"></strong>? This will formalize the last working day, start the notice period, deactivate login on that date, and create a settlement draft.
                    </p>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Approved Last Working Day <span class="text-rose-500">*</span>:</label>
                        <input type="date" name="last_working_day" :value="selectedResignation.resignation_date || '<?= date('Y-m-d') ?>'" required class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Approval Memo / HR Review Remarks:</label>
                        <textarea name="remarks" rows="2" placeholder="e.g. Resignation accepted. Clearance process initiated." class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white"></textarea>
                    </div>

                    <div class="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-700">
                        <button type="button" @click="approveModalOpen = false" class="px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-bold">Cancel</button>
                        <button type="submit" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold">Confirm Approval</button>
                    </div>
                </form>
            </div>
        </div>
    </template>

    <!-- MODAL: Reject Resignation -->
    <template x-if="rejectModalOpen">
        <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs" @click.self="rejectModalOpen = false">
            <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-700 space-y-4">
                <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                    <h3 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                        <i data-lucide="x-circle" class="w-4 h-4 text-rose-600"></i>
                        Reject Resignation
                    </h3>
                    <button type="button" @click="rejectModalOpen = false" class="text-slate-400 hover:text-slate-600">
                        <i data-lucide="x" class="w-4 h-4"></i>
                    </button>
                </div>

                <form :action="'<?= base_url('employees/separation/resignation/reject') ?>/' + selectedResignation.id" method="POST" class="space-y-4 text-xs">
                    <?= csrf_field() ?>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Rejection Reason:</label>
                        <textarea name="reason" rows="3" required placeholder="Mandatory explanation for rejection..." class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white"></textarea>
                    </div>

                    <div class="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-700">
                        <button type="button" @click="rejectModalOpen = false" class="px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-bold">Cancel</button>
                        <button type="submit" class="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold">Reject Resignation</button>
                    </div>
                </form>
            </div>
        </div>
    </template>

</div>

<script>
function separationConsole(defaultSubtab) {
    return {
        subtab: defaultSubtab,
        resignationModalOpen: false,
        terminationModalOpen: false,
        approveModalOpen: false,
        rejectModalOpen: false,
        selectedResignation: {},

        openApproveResignationModal(r) {
            this.selectedResignation = r;
            this.approveModalOpen = true;
            this.$nextTick(() => { if (window.lucide) lucide.createIcons(); });
        },
        openRejectResignationModal(r) {
            this.selectedResignation = r;
            this.rejectModalOpen = true;
            this.$nextTick(() => { if (window.lucide) lucide.createIcons(); });
        },
        init() {
            this.$nextTick(() => { if (window.lucide) lucide.createIcons(); });
        }
    };
}
</script>
