<div class="space-y-6" x-data="probationManager()">

    <!-- Header Section -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <div class="flex items-center gap-2 mb-1">
                <span class="text-[11px] font-bold px-2.5 py-0.5 rounded-md bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60">
                    Talent Onboarding & Lifecycle
                </span>
                <span class="text-[11px] text-slate-400 font-mono">
                    <?= !empty($isSoftwareAdmin) ? 'Multi-Tenant Governance' : 'Enterprise Evaluation Engine' ?>
                </span>
            </div>
            <h2 class="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">Probation Management</h2>
            <p class="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                Track employee probation periods, evaluate milestone performance, and confirm or extend tenures with audit trails.
            </p>
        </div>

        <div class="flex items-center gap-2.5">
            <a href="<?= base_url('employees') ?>" class="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/60 shadow-2xs transition">
                <i data-lucide="users" class="w-4 h-4 text-slate-500"></i>
                <span>Directory</span>
            </a>
            <a href="<?= base_url('employees/reports/probation') ?>" class="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold text-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 border border-indigo-200/60 dark:border-indigo-800/60 transition">
                <i data-lucide="file-text" class="w-4 h-4 text-indigo-600"></i>
                <span>Probation Report</span>
            </a>
        </div>
    </div>

    <!-- Shared Employees Module Navigation Tabs -->
    <?= view('employees/_tabs', ['activeTab' => 'probation']) ?>

    <!-- Summary Metrics -->
    <?php
    $totalCount = count($employees ?? []);
    $endingSoon = 0;
    $extendedCount = 0;
    $overdueCount = 0;
    foreach ($employees as $e) {
        $dl = $e['days_left'] ?? null;
        $dispSt = $e['display_probation_status'] ?? $e['probation_status'] ?? '';
        if ($dl !== null) {
            if ($dl < 0 && !in_array($dispSt, ['Completed', 'Confirmed', 'Cancelled'], true)) {
                $overdueCount++;
            } elseif ($dl <= 30 && $dl >= 0) {
                $endingSoon++;
            }
        }
        if ($dispSt === 'Extended' || ($e['probation_status'] ?? '') === 'Extended') {
            $extendedCount++;
        }
    }
    ?>
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-2xs">
            <div class="flex items-center justify-between">
                <span class="text-xs font-medium text-slate-500 dark:text-slate-400">Total in Scope</span>
                <div class="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                    <i data-lucide="user-check" class="w-4 h-4"></i>
                </div>
            </div>
            <p class="text-2xl font-bold text-slate-900 dark:text-white mt-2"><?= $totalCount ?></p>
            <p class="text-[11px] text-slate-400 mt-1">Evaluations under review</p>
        </div>

        <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-2xs">
            <div class="flex items-center justify-between">
                <span class="text-xs font-medium text-slate-500 dark:text-slate-400">Ending in 30 Days</span>
                <div class="w-8 h-8 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                    <i data-lucide="clock" class="w-4 h-4"></i>
                </div>
            </div>
            <p class="text-2xl font-bold text-amber-600 dark:text-amber-400 mt-2"><?= $endingSoon ?></p>
            <p class="text-[11px] text-amber-600/80 dark:text-amber-400/80 mt-1">Requires confirmation or extension</p>
        </div>

        <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-2xs">
            <div class="flex items-center justify-between">
                <span class="text-xs font-medium text-slate-500 dark:text-slate-400">Past Due / Overdue</span>
                <div class="w-8 h-8 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center">
                    <i data-lucide="alert-triangle" class="w-4 h-4"></i>
                </div>
            </div>
            <p class="text-2xl font-bold text-rose-600 dark:text-rose-400 mt-2"><?= $overdueCount ?></p>
            <p class="text-[11px] text-rose-500 mt-1">Date passed without action</p>
        </div>

        <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-2xs">
            <div class="flex items-center justify-between">
                <span class="text-xs font-medium text-slate-500 dark:text-slate-400">Extensions Granted</span>
                <div class="w-8 h-8 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center">
                    <i data-lucide="calendar-plus" class="w-4 h-4"></i>
                </div>
            </div>
            <p class="text-2xl font-bold text-slate-900 dark:text-white mt-2"><?= $extendedCount ?></p>
            <p class="text-[11px] text-purple-500 mt-1">Subsequent review phases</p>
        </div>
    </div>

    <!-- Filters Bar -->
    <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-2xs">
        <form method="GET" action="<?= base_url('employees/probation') ?>" class="flex flex-wrap items-center justify-between gap-3">
            <div class="flex flex-wrap items-center gap-3 flex-1">
                <!-- Search Input -->
                <div class="relative min-w-[220px] max-w-xs flex-1">
                    <i data-lucide="search" class="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"></i>
                    <input type="text" 
                           name="search" 
                           value="<?= esc($search ?? '') ?>" 
                           placeholder="Search employee, code, email..." 
                           class="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                </div>

                <!-- Status Filter -->
                <div class="min-w-[150px]">
                    <select name="status" onchange="this.form.submit()" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        <option value="Active" <?= ($statusFilter ?? '') === 'Active' ? 'selected' : '' ?>>Active Probation</option>
                        <option value="Ending_Soon" <?= ($statusFilter ?? '') === 'Ending_Soon' ? 'selected' : '' ?>>Ending in 30 Days (<?= $endingSoon ?>)</option>
                        <option value="Completed" <?= ($statusFilter ?? '') === 'Completed' ? 'selected' : '' ?>>Confirmed / Completed</option>
                        <option value="Extended" <?= ($statusFilter ?? '') === 'Extended' ? 'selected' : '' ?>>Extended</option>
                        <option value="All" <?= ($statusFilter ?? '') === 'All' ? 'selected' : '' ?>>All Records</option>
                    </select>
                </div>

                <!-- Branch Filter -->
                <?php if (!empty($branches)): ?>
                <div class="min-w-[150px]">
                    <select name="branch_id" onchange="this.form.submit()" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        <option value="">All Branches</option>
                        <?php foreach ($branches as $br): ?>
                            <option value="<?= esc($br['id']) ?>" <?= ($branchFilter ?? '') === $br['id'] ? 'selected' : '' ?>><?= esc($br['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>

                <!-- Department Filter -->
                <?php if (!empty($departments)): ?>
                <div class="min-w-[150px]">
                    <select name="department_id" onchange="this.form.submit()" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        <option value="">All Departments</option>
                        <?php foreach ($departments as $dept): ?>
                            <option value="<?= esc($dept['id']) ?>" <?= ($deptFilter ?? '') === $dept['id'] ? 'selected' : '' ?>><?= esc($dept['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>
            </div>

            <div class="flex items-center gap-2">
                <button type="submit" class="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs transition">
                    Filter
                </button>
                <a href="<?= base_url('employees/probation') ?>" class="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700/60 font-medium text-xs transition">
                    Reset
                </a>
            </div>
        </form>
    </div>

    <!-- Main Probation List Table -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-2xs">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
                <thead class="bg-slate-50/80 dark:bg-slate-900/60 border-b border-slate-200/80 dark:border-slate-700 text-slate-500 dark:text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                    <tr>
                        <th class="py-3 px-4">Employee</th>
                        <th class="py-3 px-4">Department & Designation</th>
                        <th class="py-3 px-4">Branch</th>
                        <th class="py-3 px-4">Joining Date</th>
                        <th class="py-3 px-4">Probation End</th>
                        <th class="py-3 px-4">Days Left</th>
                        <th class="py-3 px-4">Status</th>
                        <th class="py-3 px-4 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-700/60">
                    <?php if (empty($employees)): ?>
                        <tr>
                            <td colspan="8" class="py-12 text-center text-slate-400">
                                <div class="flex flex-col items-center justify-center gap-2">
                                    <i data-lucide="user-x" class="w-8 h-8 text-slate-300 dark:text-slate-600"></i>
                                    <p class="font-medium text-slate-500 dark:text-slate-400">No employees found matching probation filters.</p>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($employees as $emp): ?>
                            <?php 
                            $daysLeft = $emp['days_left'] ?? null;
                            $probStatus = $emp['display_probation_status'] ?? (!empty($emp['probation_confirmed_date']) || !empty($emp['confirmation_date']) || ($emp['probation_status'] ?? '') === 'Completed' ? 'Completed' : 'On Probation');
                            ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-750 transition-colors">
                                <!-- Employee Info -->
                                <td class="py-3.5 px-4">
                                    <div class="flex items-center gap-3">
                                        <div class="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-xs uppercase border border-indigo-100 dark:border-indigo-900 shrink-0">
                                            <?= esc(substr($emp['first_name'] ?? 'E', 0, 1) . substr($emp['last_name'] ?? '', 0, 1)) ?>
                                        </div>
                                        <div>
                                            <a href="<?= base_url('employees/profile/' . $emp['id']) ?>" class="font-semibold text-slate-900 dark:text-white hover:text-indigo-600 dark:hover:text-indigo-400 transition">
                                                <?= esc($emp['full_name'] ?: trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? ''))) ?>
                                            </a>
                                            <div class="flex items-center gap-1.5 text-[10px] text-slate-400 font-mono mt-0.5">
                                                <span><?= esc($emp['employee_code'] ?? 'N/A') ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </td>

                                <!-- Department & Designation -->
                                <td class="py-3.5 px-4 text-slate-700 dark:text-slate-300">
                                    <div class="font-medium"><?= esc($emp['designation_name'] ?? 'Staff') ?></div>
                                    <div class="text-[11px] text-slate-400"><?= esc($emp['department_name'] ?? 'General') ?></div>
                                </td>

                                <!-- Branch -->
                                <td class="py-3.5 px-4 text-slate-600 dark:text-slate-400 font-medium">
                                    <?= esc($emp['branch_name'] ?? 'Main Office') ?>
                                </td>

                                <!-- Joining Date -->
                                <td class="py-3.5 px-4 font-mono text-slate-600 dark:text-slate-400">
                                    <?= esc(!empty($emp['joining_date']) ? $emp['joining_date'] : ($emp['join_date'] ?? 'N/A')) ?>
                                </td>

                                <!-- Probation End -->
                                <td class="py-3.5 px-4 font-mono font-semibold text-slate-800 dark:text-slate-200">
                                    <?= esc($emp['probation_end_date'] ?? 'Not Set') ?>
                                </td>

                                <!-- Days Left -->
                                <td class="py-3.5 px-4 font-mono">
                                    <?php if ($daysLeft === null): ?>
                                        <span class="text-slate-400">--</span>
                                    <?php elseif ($probStatus === 'Completed'): ?>
                                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
                                            <i data-lucide="check" class="w-3 h-3"></i> Confirmed
                                        </span>
                                    <?php elseif ($daysLeft < 0): ?>
                                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400 border border-rose-200 dark:border-rose-800">
                                            <?= abs($daysLeft) ?>d Overdue
                                        </span>
                                    <?php elseif ($daysLeft <= 30): ?>
                                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400 border border-amber-200 dark:border-amber-800">
                                            <?= $daysLeft ?>d left
                                        </span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                                            <?= $daysLeft ?>d left
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <!-- Status -->
                                <td class="py-3.5 px-4">
                                    <?php if ($probStatus === 'Completed'): ?>
                                        <span class="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
                                            Confirmed
                                        </span>
                                    <?php elseif ($probStatus === 'Extended'): ?>
                                        <span class="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-400 border border-purple-200 dark:border-purple-800">
                                            Extended
                                        </span>
                                    <?php elseif ($probStatus === 'Cancelled'): ?>
                                        <span class="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400">
                                            Cancelled
                                        </span>
                                    <?php else: ?>
                                        <span class="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800">
                                            On Probation
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <!-- Row Actions -->
                                <td class="py-3.5 px-4 text-right">
                                    <div class="flex items-center justify-end gap-1.5">
                                        <?php 
                                        $isOwn = ((string)$emp['id'] === (string)($currentEmployeeId ?? ''));
                                        if ($probStatus !== 'Completed' && !$isOwn && !empty($canManageProbation)): 
                                        ?>
                                            <button type="button" 
                                                    @click="openConfirmModal(<?= htmlspecialchars(json_encode($emp), ENT_QUOTES) ?>)"
                                                    class="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-emerald-50 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-950/60 dark:text-emerald-400 dark:hover:bg-emerald-900/60 border border-emerald-200/60 dark:border-emerald-800/60 transition"
                                                    title="Confirm to Permanent Status">
                                                <i data-lucide="check-circle" class="w-3.5 h-3.5 text-emerald-600"></i>
                                                <span>Confirm</span>
                                            </button>

                                            <button type="button" 
                                                    @click="openExtendModal(<?= htmlspecialchars(json_encode($emp), ENT_QUOTES) ?>)"
                                                    class="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-purple-50 text-purple-700 hover:bg-purple-100 dark:bg-purple-950/60 dark:text-purple-400 dark:hover:bg-purple-900/60 border border-purple-200/60 dark:border-purple-800/60 transition"
                                                    title="Extend Probation Period">
                                                <i data-lucide="calendar-plus" class="w-3.5 h-3.5 text-purple-600"></i>
                                                <span>Extend</span>
                                            </button>

                                            <button type="button" 
                                                    @click="openCancelModal(<?= htmlspecialchars(json_encode($emp), ENT_QUOTES) ?>)"
                                                    class="inline-flex items-center p-1.5 rounded-lg text-xs text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition"
                                                    title="Cancel Evaluation">
                                                <i data-lucide="x" class="w-3.5 h-3.5"></i>
                                            </button>
                                        <?php else: ?>
                                            <a href="<?= base_url('employees/profile/' . $emp['id']) ?>" class="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-600 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-700/60 transition">
                                                <i data-lucide="user" class="w-3.5 h-3.5"></i>
                                                <span>View</span>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Audit Logs Section -->
    <?php if (!empty($recentLogs)): ?>
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-5 shadow-2xs space-y-3">
        <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
            <div class="flex items-center gap-2">
                <i data-lucide="history" class="w-4 h-4 text-indigo-600"></i>
                <h3 class="font-bold text-slate-900 dark:text-white text-xs uppercase tracking-wider">Probation Audit Trail (Recent Activity)</h3>
            </div>
            <span class="text-[11px] text-slate-400">probation_audit_logs</span>
        </div>

        <div class="divide-y divide-slate-100 dark:divide-slate-700/60 text-xs">
            <?php foreach ($recentLogs as $log): ?>
                <div class="py-2.5 flex flex-wrap items-center justify-between gap-2">
                    <div class="space-y-0.5">
                        <div class="flex items-center gap-2">
                            <span class="font-bold text-slate-800 dark:text-slate-200"><?= esc(trim(($log['first_name'] ?? '') . ' ' . ($log['last_name'] ?? ''))) ?></span>
                            <span class="font-mono text-[10px] text-slate-400">(<?= esc($log['employee_code'] ?? $log['employee_id']) ?>)</span>
                            <span class="px-2 py-0.5 rounded text-[10px] font-semibold bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-400">
                                <?= esc($log['action_type'] ?? 'Action') ?>
                            </span>
                        </div>
                        <p class="text-[11px] text-slate-500 dark:text-slate-400"><?= esc($log['details'] ?? $log['reason'] ?? '') ?></p>
                    </div>
                    <div class="text-right text-[11px] text-slate-400 font-mono">
                        <div>by <?= esc($log['performed_by_name'] ?? 'HR') ?></div>
                        <div><?= esc($log['created_at']) ?></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Modal: Confirm Probation -->
    <template x-if="confirmModalOpen">
        <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs" @click.self="confirmModalOpen = false">
            <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-700 space-y-4">
                <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                    <h3 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                        <i data-lucide="check-circle" class="w-4 h-4 text-emerald-600"></i>
                        Confirm Probation to Permanent Status
                    </h3>
                    <button type="button" @click="confirmModalOpen = false" class="text-slate-400 hover:text-slate-600">
                        <i data-lucide="x" class="w-4 h-4"></i>
                    </button>
                </div>

                <form :action="'<?= base_url('employees/probation/confirm') ?>/' + selectedEmp.id" method="POST" class="space-y-4 text-xs">
                    <?= csrf_field() ?>
                    <p class="text-slate-600 dark:text-slate-300">
                        Confirm employee <strong class="text-slate-900 dark:text-white" x-text="selectedEmp.full_name || selectedEmp.first_name"></strong> (<span class="font-mono" x-text="selectedEmp.employee_code"></span>) to permanent status? This will transition employee status to Active and unlock post-probation leave privileges.
                    </p>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Confirmation Effective Date:</label>
                        <input type="date" name="completion_date" value="<?= date('Y-m-d') ?>" class="w-full p-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Evaluation Memo / Remarks:</label>
                        <textarea name="reason" rows="2" placeholder="e.g. Completed evaluation milestone with satisfactory marks." class="w-full p-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white"></textarea>
                    </div>

                    <div class="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-700">
                        <button type="button" @click="confirmModalOpen = false" class="px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-bold">Cancel</button>
                        <button type="submit" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold">Confirm Status</button>
                    </div>
                </form>
            </div>
        </div>
    </template>

    <!-- Modal: Extend Probation -->
    <template x-if="extendModalOpen">
        <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs" @click.self="extendModalOpen = false">
            <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-700 space-y-4">
                <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                    <h3 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                        <i data-lucide="calendar-plus" class="w-4 h-4 text-purple-600"></i>
                        Extend Probation Period
                    </h3>
                    <button type="button" @click="extendModalOpen = false" class="text-slate-400 hover:text-slate-600">
                        <i data-lucide="x" class="w-4 h-4"></i>
                    </button>
                </div>

                <form :action="'<?= base_url('employees/probation/extend') ?>/' + selectedEmp.id" method="POST" class="space-y-4 text-xs">
                    <?= csrf_field() ?>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">New Probation End Date <span class="text-rose-500">*</span>:</label>
                        <input type="date" name="new_end_date" required class="w-full p-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                        <p class="text-[10px] text-slate-400 mt-1">Current End: <span class="font-mono font-bold" x-text="selectedEmp.probation_end_date || 'N/A'"></span></p>
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Mandatory Extension Reason <span class="text-rose-500">*</span>:</label>
                        <textarea name="reason" rows="3" required placeholder="Mandatory explanation for extension (e.g. Additional 90-day KPI review required)" class="w-full p-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white"></textarea>
                    </div>

                    <div class="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-700">
                        <button type="button" @click="extendModalOpen = false" class="px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-bold">Cancel</button>
                        <button type="submit" class="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-bold">Save Extension</button>
                    </div>
                </form>
            </div>
        </div>
    </template>

    <!-- Modal: Cancel Probation -->
    <template x-if="cancelModalOpen">
        <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs" @click.self="cancelModalOpen = false">
            <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-700 space-y-4">
                <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                    <h3 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                        <i data-lucide="x-circle" class="w-4 h-4 text-rose-600"></i>
                        Cancel Probation Evaluation
                    </h3>
                    <button type="button" @click="cancelModalOpen = false" class="text-slate-400 hover:text-slate-600">
                        <i data-lucide="x" class="w-4 h-4"></i>
                    </button>
                </div>

                <form :action="'<?= base_url('employees/probation/cancel') ?>/' + selectedEmp.id" method="POST" class="space-y-4 text-xs">
                    <?= csrf_field() ?>
                    <p class="text-slate-600 dark:text-slate-300">
                        Cancel probation tracking for <strong class="text-slate-900 dark:text-white" x-text="selectedEmp.full_name || selectedEmp.first_name"></strong>?
                    </p>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Cancellation Reason:</label>
                        <textarea name="reason" rows="2" placeholder="e.g. Waived per executive decision / contract alteration." class="w-full p-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white"></textarea>
                    </div>

                    <div class="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-700">
                        <button type="button" @click="cancelModalOpen = false" class="px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-bold">Dismiss</button>
                        <button type="submit" class="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold">Cancel Probation</button>
                    </div>
                </form>
            </div>
        </div>
    </template>

</div>

<script>
function probationManager() {
    return {
        confirmModalOpen: false,
        extendModalOpen: false,
        cancelModalOpen: false,
        selectedEmp: {},

        openConfirmModal(emp) {
            this.selectedEmp = emp;
            this.confirmModalOpen = true;
            this.$nextTick(() => { if (window.lucide) lucide.createIcons(); });
        },
        openExtendModal(emp) {
            this.selectedEmp = emp;
            this.extendModalOpen = true;
            this.$nextTick(() => { if (window.lucide) lucide.createIcons(); });
        },
        openCancelModal(emp) {
            this.selectedEmp = emp;
            this.cancelModalOpen = true;
            this.$nextTick(() => { if (window.lucide) lucide.createIcons(); });
        }
    };
}
</script>
