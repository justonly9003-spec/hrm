<!-- Family Details Tab -->
<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-6" x-data="{ showAddFamily: false }">
    <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-4">
        <div>
            <h3 class="font-bold text-slate-900 dark:text-white text-base">Family & Dependent Information</h3>
            <p class="text-xs text-slate-500 mt-0.5">Spouse, children, parents, and healthcare insurance dependents</p>
        </div>
        <button type="button" @click="showAddFamily = true" class="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400 rounded-xl text-xs font-semibold border border-indigo-200 dark:border-indigo-800 flex items-center gap-1.5 transition">
            <i data-lucide="plus" class="w-3.5 h-3.5"></i>
            <span>Add Family Member</span>
        </button>
    </div>

    <!-- Family Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <?php if (empty($family)): ?>
            <div class="md:col-span-2 py-8 text-center text-slate-400">
                <i data-lucide="users" class="w-8 h-8 mx-auto mb-2 text-slate-300"></i>
                <p class="text-xs">No family records registered.</p>
            </div>
        <?php else: ?>
            <?php foreach ($family as $fam): ?>
                <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 text-xs space-y-2">
                    <div class="flex items-center justify-between">
                        <span class="font-bold text-slate-900 dark:text-white text-sm"><?= esc($fam['name']) ?></span>
                        <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-900">
                            <?= esc($fam['relationship']) ?>
                        </span>
                    </div>
                    <div class="text-slate-500 space-y-1">
                        <div>Occupation: <strong class="text-slate-700 dark:text-slate-300"><?= esc($fam['occupation'] ?? 'N/A') ?></strong></div>
                        <div>Contact: <span class="font-mono"><?= esc($fam['contact'] ?? 'N/A') ?></span></div>
                        <div>Dependent: <span class="font-semibold <?= !empty($fam['dependent_status']) ? 'text-emerald-600' : 'text-slate-400' ?>"><?= !empty($fam['dependent_status']) ? 'Yes (Enrolled)' : 'No' ?></span></div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Add Family Modal -->
    <div x-show="showAddFamily" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" style="display: none;">
        <div @click.away="showAddFamily = false" class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 w-full max-w-md p-6 shadow-xl space-y-4">
            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                <h3 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                    <i data-lucide="user-plus" class="w-4 h-4 text-indigo-600"></i>
                    Add Family Member
                </h3>
                <button type="button" @click="showAddFamily = false" class="text-slate-400 hover:text-slate-600">
                    <i data-lucide="x" class="w-4 h-4"></i>
                </button>
            </div>

            <form action="<?= base_url('employees/profile/' . $employee['id'] . '/family/save') ?>" method="POST" class="space-y-4 text-xs">
                <?= csrf_field() ?>
                
                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Full Name</label>
                    <input type="text" name="name" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Relationship</label>
                        <select name="relationship" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                            <option value="Father">Father</option>
                            <option value="Mother">Mother</option>
                            <option value="Spouse">Spouse</option>
                            <option value="Son">Son</option>
                            <option value="Daughter">Daughter</option>
                            <option value="Brother">Brother</option>
                            <option value="Sister">Sister</option>
                        </select>
                    </div>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Occupation</label>
                        <input type="text" name="occupation" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Date of Birth</label>
                        <input type="date" name="dob" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                    </div>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Contact Phone</label>
                        <input type="text" name="contact" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                    </div>
                </div>

                <label class="flex items-center gap-2 font-semibold text-slate-700 dark:text-slate-300 cursor-pointer pt-1">
                    <input type="checkbox" name="dependent_status" value="1" checked class="rounded border-slate-300 text-indigo-600">
                    <span>Enroll as Healthcare / Tax Dependent</span>
                </label>

                <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-700">
                    <button type="button" @click="showAddFamily = false" class="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold">Cancel</button>
                    <button type="submit" class="px-4 py-2 rounded-xl bg-indigo-600 text-white font-semibold hover:bg-indigo-700 shadow-sm">Save Family Member</button>
                </div>
            </form>
        </div>
    </div>
</div>
