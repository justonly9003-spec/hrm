<!-- Contact Tab -->
<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-6">
    <div class="border-b border-slate-100 dark:border-slate-700 pb-4">
        <h3 class="font-bold text-slate-900 dark:text-white text-base">Contact Information</h3>
        <p class="text-xs text-slate-500 mt-0.5">Direct communication channels and official emails</p>
    </div>

    <form action="<?= base_url('employees/profile/' . $employee['id'] . '/update-contact') ?>" method="POST" class="space-y-6">
        <?= csrf_field() ?>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Primary Mobile Phone</label>
                <input type="text" name="phone" value="<?= esc($employee['phone'] ?? '') ?>" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden">
            </div>

            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Alternate / Landline Phone</label>
                <input type="text" name="alternate_phone" value="<?= esc($employee['alternate_phone'] ?? '') ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden">
            </div>

            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Official Organization Email</label>
                <input type="email" name="email" value="<?= esc($employee['email'] ?? '') ?>" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden">
            </div>

            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Personal Email</label>
                <input type="email" name="personal_email" value="<?= esc($employee['personal_email'] ?? '') ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden">
            </div>
        </div>

        <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 space-y-4">
            <h4 class="font-bold text-slate-900 dark:text-white text-xs flex items-center gap-2">
                <i data-lucide="phone-call" class="w-4 h-4 text-indigo-600"></i>
                Primary Emergency Contact Shortcut
            </h4>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                <div>
                    <label class="block font-medium text-slate-600 dark:text-slate-400 mb-1">Contact Person Name</label>
                    <input type="text" name="emergency_contact_name" value="<?= esc($emergencyContacts[0]['name'] ?? '') ?>" class="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                </div>
                <div>
                    <label class="block font-medium text-slate-600 dark:text-slate-400 mb-1">Contact Phone</label>
                    <input type="text" name="emergency_contact_phone" value="<?= esc($emergencyContacts[0]['phone'] ?? '') ?>" class="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                </div>
                <div>
                    <label class="block font-medium text-slate-600 dark:text-slate-400 mb-1">Relationship</label>
                    <input type="text" name="emergency_relationship" value="<?= esc($emergencyContacts[0]['relationship'] ?? 'Spouse / Parent') ?>" class="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                </div>
            </div>
        </div>

        <div class="flex justify-end pt-4 border-t border-slate-100 dark:border-slate-700">
            <button type="submit" class="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition flex items-center gap-2">
                <i data-lucide="check" class="w-4 h-4"></i>
                <span>Save Contact Details</span>
            </button>
        </div>
    </form>
</div>
