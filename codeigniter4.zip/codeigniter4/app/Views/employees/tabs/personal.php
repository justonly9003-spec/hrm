<!-- Personal Info Tab -->
<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-6">
    <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-4">
        <div>
            <h3 class="font-bold text-slate-900 dark:text-white text-base">Personal Information</h3>
            <p class="text-xs text-slate-500 mt-0.5">Primary identity and demographic data</p>
        </div>
        <span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300 border border-indigo-100 dark:border-indigo-900">
            <?= esc($employee['employee_code'] ?? 'EMP-001') ?>
        </span>
    </div>

    <form action="<?= base_url('employees/profile/' . $employee['id'] . '/update-personal') ?>" method="POST" class="space-y-4">
        <?= csrf_field() ?>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Date of Birth</label>
                <input type="date" name="dob" value="<?= esc($employee['dob'] ?? '') ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden">
            </div>

            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Gender</label>
                <select name="gender" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden">
                    <option value="male" <?= strtolower($employee['gender'] ?? '') === 'male' ? 'selected' : '' ?>>Male</option>
                    <option value="female" <?= strtolower($employee['gender'] ?? '') === 'female' ? 'selected' : '' ?>>Female</option>
                    <option value="other" <?= strtolower($employee['gender'] ?? '') === 'other' ? 'selected' : '' ?>>Other</option>
                </select>
            </div>

            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Blood Group</label>
                <select name="blood_group" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden">
                    <option value="">Select Blood Group</option>
                    <?php foreach (['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] as $bg): ?>
                        <option value="<?= $bg ?>" <?= ($employee['blood_group'] ?? '') === $bg ? 'selected' : '' ?>><?= $bg ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Religion</label>
                <input type="text" name="religion" value="<?= esc($employee['religion'] ?? '') ?>" placeholder="e.g. Islam, Christianity" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden">
            </div>

            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Marital Status</label>
                <select name="marital_status" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden">
                    <option value="">Select Marital Status</option>
                    <option value="Single" <?= ($employee['marital_status'] ?? '') === 'Single' ? 'selected' : '' ?>>Single</option>
                    <option value="Married" <?= ($employee['marital_status'] ?? '') === 'Married' ? 'selected' : '' ?>>Married</option>
                    <option value="Divorced" <?= ($employee['marital_status'] ?? '') === 'Divorced' ? 'selected' : '' ?>>Divorced</option>
                </select>
            </div>

            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Nationality</label>
                <input type="text" name="nationality" value="<?= esc($employee['nationality'] ?? '') ?>" placeholder="e.g. Bangladeshi, American" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden">
            </div>

            <div class="md:col-span-2">
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">National ID (NID) / Passport No</label>
                <input type="text" name="national_id" value="<?= esc($employee['national_id'] ?? $employee['nid'] ?? '') ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden font-mono">
            </div>
        </div>

        <div class="flex justify-end pt-4 border-t border-slate-100 dark:border-slate-700">
            <button type="submit" class="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition flex items-center gap-2">
                <i data-lucide="check" class="w-4 h-4"></i>
                <span>Save Personal Information</span>
            </button>
        </div>
    </form>
</div>
