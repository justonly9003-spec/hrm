<!-- Performance Tab -->
<div class="space-y-6">
    <!-- Performance Summary -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-4">
        <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-4">
            <div>
                <h3 class="font-bold text-slate-900 dark:text-white text-base">Appraisal & Performance Reviews</h3>
                <p class="text-xs text-slate-500 mt-0.5">KPI scores, manager assessments, and annual review cycles</p>
            </div>
            <div class="flex items-center gap-2">
                <span class="text-xs font-bold text-slate-500">Overall Rating:</span>
                <span class="px-2.5 py-1 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 font-bold text-xs border border-amber-200 dark:border-amber-800 flex items-center gap-1">
                    <i data-lucide="star" class="w-3.5 h-3.5 fill-amber-500 text-amber-500"></i>
                    4.8 / 5.0 (Exceeds Expectations)
                </span>
            </div>
        </div>

        <!-- Score Breakdown Grid -->
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                <div class="text-slate-400 font-semibold">Technical Excellence</div>
                <div class="text-lg font-bold text-slate-900 dark:text-white mt-1">96%</div>
                <div class="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full mt-2 overflow-hidden">
                    <div class="bg-emerald-500 h-full rounded-full" style="width: 96%"></div>
                </div>
            </div>
            <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                <div class="text-slate-400 font-semibold">Collaboration & Teamwork</div>
                <div class="text-lg font-bold text-slate-900 dark:text-white mt-1">92%</div>
                <div class="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full mt-2 overflow-hidden">
                    <div class="bg-indigo-500 h-full rounded-full" style="width: 92%"></div>
                </div>
            </div>
            <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                <div class="text-slate-400 font-semibold">Delivery & Timeliness</div>
                <div class="text-lg font-bold text-slate-900 dark:text-white mt-1">98%</div>
                <div class="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full mt-2 overflow-hidden">
                    <div class="bg-purple-500 h-full rounded-full" style="width: 98%"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Review History Table -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-xs">
        <div class="p-5 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between">
            <h3 class="font-bold text-slate-900 dark:text-white text-base">Appraisal History</h3>
            <span class="text-xs text-slate-400">Quarterly & Annual cycles</span>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-xs">
                <thead>
                    <tr class="border-b border-slate-100 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 text-slate-500 font-medium">
                        <th class="py-3 px-4">Appraisal Cycle</th>
                        <th class="py-3 px-4">Evaluation Period</th>
                        <th class="py-3 px-4">Reviewer</th>
                        <th class="py-3 px-4">Final Score</th>
                        <th class="py-3 px-4">Rating Category</th>
                        <th class="py-3 px-4">Appraisal Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-700">
                    <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                        <td class="py-3 px-4 font-bold text-slate-900 dark:text-white">Annual Appraisal 2025</td>
                        <td class="py-3 px-4 font-mono text-slate-500">Jan 2025 - Dec 2025</td>
                        <td class="py-3 px-4 font-medium"><?= esc($employee['manager_name'] ?? 'Direct Manager') ?></td>
                        <td class="py-3 px-4 font-mono font-bold text-indigo-600">4.85 / 5.0</td>
                        <td class="py-3 px-4"><span class="font-semibold text-emerald-600">Outstanding</span></td>
                        <td class="py-3 px-4"><span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">Finalized & Locked</span></td>
                    </tr>
                    <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                        <td class="py-3 px-4 font-bold text-slate-900 dark:text-white">Mid-Year Review 2025</td>
                        <td class="py-3 px-4 font-mono text-slate-500">Jan 2025 - Jun 2025</td>
                        <td class="py-3 px-4 font-medium"><?= esc($employee['manager_name'] ?? 'Direct Manager') ?></td>
                        <td class="py-3 px-4 font-mono font-bold text-indigo-600">4.70 / 5.0</td>
                        <td class="py-3 px-4"><span class="font-semibold text-emerald-600">Exceeds Targets</span></td>
                        <td class="py-3 px-4"><span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">Finalized & Locked</span></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
