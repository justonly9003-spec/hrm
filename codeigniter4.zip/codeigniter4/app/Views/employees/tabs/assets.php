<?php
/**
 * Employee Profile - Company Assets Tab
 *
 * Displays:
 * 1. Currently assigned assets with real data, count badge, and empty state "No assets assigned".
 * 2. Custody history table (assignments and returns) with handover/return conditions and dates.
 * 3. Purchase value displayed only when viewer has assets.export or assets.manage permissions.
 */

$assets = $assets ?? [];
$assetHistory = $assetHistory ?? [];
$canViewPurchaseValue = !empty($canViewPurchaseValue);
$companyCurrency = app_currency_code($employee['company_id'] ?? null);
?>

<div class="space-y-6">
    <!-- Current Assigned Assets Section -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-4">
        <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-4">
            <div>
                <h3 class="font-bold text-slate-900 dark:text-white text-base">Assigned Company Assets</h3>
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Hardware, tools, access devices, and equipment currently allocated to this employee</p>
            </div>
            <span class="text-xs font-bold text-indigo-600 dark:text-indigo-400 px-3 py-1 bg-indigo-50 dark:bg-indigo-950/60 rounded-xl border border-indigo-200 dark:border-indigo-800">
                <?= count($assets) ?> <?= count($assets) === 1 ? 'Item Allocated' : 'Items Allocated' ?>
            </span>
        </div>

        <?php if (empty($assets)): ?>
            <div class="p-8 text-center bg-slate-50 dark:bg-slate-900/40 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700">
                <div class="w-12 h-12 mx-auto rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400 dark:text-slate-500 mb-3">
                    <i data-lucide="package-open" class="w-6 h-6"></i>
                </div>
                <h4 class="text-sm font-bold text-slate-800 dark:text-slate-200">No assets assigned</h4>
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto">This employee currently has no company assets checked out or assigned.</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <?php foreach ($assets as $ast): ?>
                    <?php
                        $assetName = $ast['asset_name'] ?? $ast['name'] ?? 'Unnamed Asset';
                        $assetCode = $ast['asset_code'] ?? $ast['code'] ?? '—';
                        $serialNumber = $ast['serial_number'] ?? null;
                        $categoryName = $ast['category_name'] ?? $ast['category'] ?? 'General';
                        $assignedDate = $ast['assigned_date'] ?? '—';
                        $cond = strtolower($ast['condition_status'] ?? 'good');
                        $badgeClass = match($cond) {
                            'new'         => 'bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-400 border-blue-200 dark:border-blue-800',
                            'good'        => 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800',
                            'fair'        => 'bg-yellow-50 text-yellow-700 dark:bg-yellow-950/40 dark:text-yellow-400 border-yellow-200 dark:border-yellow-800',
                            'poor'        => 'bg-orange-50 text-orange-700 dark:bg-orange-950/40 dark:text-orange-400 border-orange-200 dark:border-orange-800',
                            'damaged'     => 'bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400 border-red-200 dark:border-red-800',
                            'maintenance' => 'bg-purple-50 text-purple-700 dark:bg-purple-950/40 dark:text-purple-400 border-purple-200 dark:border-purple-800',
                            default       => 'bg-slate-50 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                        };
                    ?>
                    <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 space-y-3">
                        <div class="flex items-start justify-between gap-2">
                            <div>
                                <h4 class="font-bold text-slate-900 dark:text-white text-sm"><?= esc($assetName) ?></h4>
                                <span class="inline-block mt-0.5 text-[11px] font-medium text-slate-500 dark:text-slate-400">
                                    <?= esc($categoryName) ?>
                                </span>
                            </div>
                            <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800 shrink-0">
                                In Possession
                            </span>
                        </div>

                        <div class="text-slate-500 dark:text-slate-400 space-y-1.5 pt-1 border-t border-slate-200/60 dark:border-slate-700/60">
                            <div class="flex items-center justify-between">
                                <span class="text-slate-400">Asset Tag:</span>
                                <span class="font-mono font-bold text-slate-700 dark:text-slate-200"><?= esc($assetCode) ?></span>
                            </div>
                            <div class="flex items-center justify-between">
                                <span class="text-slate-400">Serial Number:</span>
                                <span class="font-mono text-slate-700 dark:text-slate-300"><?= esc($serialNumber ?: 'N/A') ?></span>
                            </div>
                            <div class="flex items-center justify-between">
                                <span class="text-slate-400">Condition:</span>
                                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium border <?= $badgeClass ?> capitalize">
                                    <?= esc($cond) ?>
                                </span>
                            </div>
                            <div class="flex items-center justify-between">
                                <span class="text-slate-400">Allocated Date:</span>
                                <span class="font-mono text-slate-700 dark:text-slate-300"><?= esc($assignedDate) ?></span>
                            </div>
                            <?php if ($canViewPurchaseValue && isset($ast['purchase_value']) && $ast['purchase_value'] !== '' && $ast['purchase_value'] !== null): ?>
                                <div class="flex items-center justify-between">
                                    <span class="text-slate-400">Purchase Value:</span>
                                    <span class="font-mono font-semibold text-slate-800 dark:text-slate-200"><?= esc(format_money($ast['purchase_value'], $companyCurrency)) ?></span>
                                </div>
                            <?php endif; ?>
                            <?php if (!empty($ast['notes'])): ?>
                                <div class="pt-1 text-[11px] text-slate-500 dark:text-slate-400 italic">
                                    <?= esc($ast['notes']) ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Asset Custody History Section -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-4">
        <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-4">
            <div>
                <h3 class="font-bold text-slate-900 dark:text-white text-base">Custody & Assignment History</h3>
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Historical record of all company assets assigned to, held by, or returned by this employee</p>
            </div>
            <span class="text-xs font-bold text-slate-600 dark:text-slate-300 px-3 py-1 bg-slate-100 dark:bg-slate-700/60 rounded-xl border border-slate-200 dark:border-slate-600">
                <?= count($assetHistory) ?> <?= count($assetHistory) === 1 ? 'Record' : 'Records' ?>
            </span>
        </div>

        <?php if (empty($assetHistory)): ?>
            <div class="p-6 text-center bg-slate-50 dark:bg-slate-900/40 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700">
                <p class="text-xs text-slate-500 dark:text-slate-400">No previous asset assignment history on record.</p>
            </div>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse text-xs">
                    <thead>
                        <tr class="border-b border-slate-200 dark:border-slate-700 text-slate-400 font-semibold">
                            <th class="py-2.5 px-3">Asset</th>
                            <th class="py-2.5 px-3">Category & Serial</th>
                            <th class="py-2.5 px-3">Assigned Date</th>
                            <th class="py-2.5 px-3">Handover Condition</th>
                            <th class="py-2.5 px-3">Returned Date</th>
                            <th class="py-2.5 px-3">Return Condition</th>
                            <th class="py-2.5 px-3 text-center">Status</th>
                            <?php if ($canViewPurchaseValue): ?>
                                <th class="py-2.5 px-3 text-right">Purchase Value</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-700/60">
                        <?php foreach ($assetHistory as $hist): ?>
                            <?php
                                $histAssetName = $hist['asset_name'] ?? 'Asset #' . ($hist['asset_id'] ?? '');
                                $histAssetCode = $hist['asset_code'] ?? '—';
                                $histSerial = $hist['serial_number'] ?? null;
                                $histCategory = $hist['category_name'] ?? $hist['category'] ?? 'General';
                                $isReturned = !empty($hist['returned_date']);
                                $condAssign = strtolower($hist['condition_on_assign'] ?? 'good');
                                $condReturn = !empty($hist['condition_on_return']) ? strtolower($hist['condition_on_return']) : null;
                            ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30 transition-colors">
                                <td class="py-3 px-3">
                                    <div class="font-bold text-slate-800 dark:text-slate-200"><?= esc($histAssetName) ?></div>
                                    <div class="font-mono text-[10px] text-slate-400"><?= esc($histAssetCode) ?></div>
                                </td>
                                <td class="py-3 px-3 text-slate-600 dark:text-slate-300">
                                    <div><?= esc($histCategory) ?></div>
                                    <div class="font-mono text-[10px] text-slate-400">SN: <?= esc($histSerial ?: 'N/A') ?></div>
                                </td>
                                <td class="py-3 px-3 font-mono text-slate-700 dark:text-slate-300">
                                    <?= esc($hist['assigned_date'] ?? '—') ?>
                                </td>
                                <td class="py-3 px-3">
                                    <span class="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 capitalize">
                                        <?= esc($condAssign) ?>
                                    </span>
                                </td>
                                <td class="py-3 px-3 font-mono text-slate-700 dark:text-slate-300">
                                    <?= esc($isReturned ? $hist['returned_date'] : '—') ?>
                                </td>
                                <td class="py-3 px-3">
                                    <?php if ($condReturn): ?>
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 capitalize">
                                            <?= esc($condReturn) ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="text-slate-400">—</span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3 px-3 text-center">
                                    <?php if ($isReturned): ?>
                                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700">
                                            Returned
                                        </span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
                                            In Custody
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <?php if ($canViewPurchaseValue): ?>
                                    <td class="py-3 px-3 text-right font-mono font-medium text-slate-700 dark:text-slate-300">
                                        <?php if (isset($hist['purchase_value']) && $hist['purchase_value'] !== '' && $hist['purchase_value'] !== null): ?>
                                            <?= esc(format_money($hist['purchase_value'], $companyCurrency)) ?>
                                        <?php else: ?>
                                            <span class="text-slate-400">—</span>
                                        <?php endif; ?>
                                    </td>
                                <?php endif; ?>
                            </tr>
                            <?php if (!empty($hist['notes'])): ?>
                                <tr class="bg-slate-50/30 dark:bg-slate-900/20">
                                    <td colspan="<?= $canViewPurchaseValue ? 8 : 7 ?>" class="px-3 py-1.5 text-[11px] text-slate-400 dark:text-slate-500 italic">
                                        Note: <?= esc($hist['notes']) ?>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
