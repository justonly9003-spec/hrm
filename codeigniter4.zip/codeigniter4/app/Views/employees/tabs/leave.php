<!-- Leave Tab -->
<div class="space-y-6">
    <!-- Leave Balances Matrix -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-5 shadow-xs">
        <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
            <h3 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                <i data-lucide="plane-takeoff" class="w-4 h-4 text-emerald-600"></i>
                Annual Leave Entitlement & Balances (<?= date('Y') ?>)
            </h3>
            <a href="<?= base_url('leave') ?>" class="text-xs text-indigo-600 hover:text-indigo-700 font-semibold flex items-center gap-1">
                <span>Open Leave Portal</span>
                <i data-lucide="external-link" class="w-3.5 h-3.5"></i>
            </a>
        </div>
        <?php 
        $activeBalances = !empty($leaveBalances) ? $leaveBalances : (!empty($leaveBalance) && is_array($leaveBalance) && isset($leaveBalance[0]) ? $leaveBalance : []);
        ?>
        <?php if (empty($activeBalances)): ?>
            <div class="p-6 text-center text-sm font-semibold text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-slate-100 dark:border-slate-700 mt-4">
                Not configured
            </div>
        <?php else: ?>
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4">
                <?php 
                $colorPalettes = [
                    ['bg' => 'bg-indigo-50/50 dark:bg-indigo-950/30', 'border' => 'border-indigo-100 dark:border-indigo-900/40', 'title' => 'text-indigo-500', 'val' => 'text-indigo-700 dark:text-indigo-300'],
                    ['bg' => 'bg-emerald-50/50 dark:bg-emerald-950/30', 'border' => 'border-emerald-100 dark:border-emerald-900/40', 'title' => 'text-emerald-500', 'val' => 'text-emerald-700 dark:text-emerald-300'],
                    ['bg' => 'bg-amber-50/50 dark:bg-amber-950/30', 'border' => 'border-amber-100 dark:border-amber-900/40', 'title' => 'text-amber-500', 'val' => 'text-amber-700 dark:text-amber-300'],
                    ['bg' => 'bg-purple-50/50 dark:bg-purple-950/30', 'border' => 'border-purple-100 dark:border-purple-900/40', 'title' => 'text-purple-500', 'val' => 'text-purple-700 dark:text-purple-300'],
                    ['bg' => 'bg-sky-50/50 dark:bg-sky-950/30', 'border' => 'border-sky-100 dark:border-sky-900/40', 'title' => 'text-sky-500', 'val' => 'text-sky-700 dark:text-sky-300'],
                ];
                $cIdx = 0;
                ?>
                <?php foreach ($activeBalances as $lb): ?>
                    <?php $pal = $colorPalettes[$cIdx % count($colorPalettes)]; $cIdx++; ?>
                    <div class="p-3.5 <?= $pal['bg'] ?> rounded-xl border <?= $pal['border'] ?> text-center">
                        <div class="text-[10px] uppercase font-bold <?= $pal['title'] ?> truncate" title="<?= esc($lb['leave_type_name']) ?>"><?= esc($lb['leave_type_name']) ?></div>
                        <div class="text-xl font-bold <?= $pal['val'] ?> mt-1"><?= (float)($lb['available_balance'] ?? 0) ?>d</div>
                        <div class="text-[10px] text-slate-400 mt-0.5" title="Used / Total Entitlement">Used: <?= (float)($lb['total_used'] ?? 0) ?>d / Total: <?= (float)($lb['total_entitlement'] ?? 0) ?>d</div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Leave History Table -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-xs">
        <div class="p-5 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between">
            <h3 class="font-bold text-slate-900 dark:text-white text-base">Leave Applications & Approvals History</h3>
            <span class="text-xs text-slate-400">Lifetime records</span>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-xs">
                <thead>
                    <tr class="border-b border-slate-100 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 text-slate-500 font-medium">
                        <th class="py-3 px-4">Leave Type</th>
                        <th class="py-3 px-4">Start Date</th>
                        <th class="py-3 px-4">End Date</th>
                        <th class="py-3 px-4">Total Days</th>
                        <th class="py-3 px-4">Reason / Notes</th>
                        <th class="py-3 px-4">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-700">
                    <?php if (empty($leaves)): ?>
                        <tr><td colspan="6" class="py-8 text-center text-slate-400">No leave applications found for this employee.</td></tr>
                    <?php else: ?>
                        <?php foreach ($leaves as $lv): ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                                <td class="py-3 px-4 font-bold text-slate-900 dark:text-white"><?= esc($lv['leave_type_name'] ?? $lv['type'] ?? 'Casual Leave') ?></td>
                                <td class="py-3 px-4 font-mono"><?= esc($lv['start_date']) ?></td>
                                <td class="py-3 px-4 font-mono"><?= esc($lv['end_date']) ?></td>
                                <td class="py-3 px-4 font-mono font-bold text-indigo-600"><?= esc($lv['total_days'] ?? '1') ?> Days</td>
                                <td class="py-3 px-4 max-w-xs truncate"><?= esc($lv['reason'] ?? 'Personal reasons') ?></td>
                                <td class="py-3 px-4">
                                    <span class="px-2 py-0.5 rounded text-[10px] font-bold <?= ($lv['status'] ?? 'Approved') === 'Approved' ? 'bg-emerald-100 text-emerald-800' : (($lv['status'] ?? '') === 'Pending' ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800') ?>">
                                        <?= esc($lv['status'] ?? 'Approved') ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
