<!-- Experience Tab -->
<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-6" x-data="{ showAddExp: false }">
    <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-4">
        <div>
            <h3 class="font-bold text-slate-900 dark:text-white text-base">Prior Work Experience</h3>
            <p class="text-xs text-slate-500 mt-0.5">Past employment history and professional track record</p>
        </div>
        <button type="button" @click="showAddExp = true" class="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400 rounded-xl text-xs font-semibold border border-indigo-200 dark:border-indigo-800 flex items-center gap-1.5 transition">
            <i data-lucide="plus" class="w-3.5 h-3.5"></i>
            <span>Add Experience</span>
        </button>
    </div>

    <!-- Experience List -->
    <div class="space-y-4">
        <?php if (empty($experience)): ?>
            <div class="py-8 text-center text-slate-400">
                <i data-lucide="briefcase" class="w-8 h-8 mx-auto mb-2 text-slate-300"></i>
                <p class="text-xs">No prior work experience recorded.</p>
            </div>
        <?php else: ?>
            <?php foreach ($experience as $exp): ?>
                <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 flex flex-col md:flex-row md:items-start justify-between gap-4 text-xs">
                    <div class="space-y-1.5">
                        <div class="flex items-center gap-2">
                            <h4 class="font-bold text-slate-900 dark:text-white text-sm"><?= esc($exp['designation']) ?></h4>
                            <span class="text-slate-400">at</span>
                            <span class="font-semibold text-indigo-600 dark:text-indigo-400"><?= esc($exp['company']) ?></span>
                        </div>
                        <div class="text-slate-500 font-mono text-[11px]">
                            <?= esc($exp['joining_date']) ?> — <?= !empty($exp['leaving_date']) ? esc($exp['leaving_date']) : 'Present' ?>
                        </div>
                        <?php if (!empty($exp['responsibilities'])): ?>
                            <p class="text-slate-600 dark:text-slate-300 text-xs mt-2"><?= esc($exp['responsibilities']) ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="shrink-0 flex items-center gap-2">
                        <form method="POST" action="<?= base_url('employees/profile/' . $employee['id'] . '/experience/delete/' . $exp['id']) ?>" onsubmit="return confirm('Delete this experience?')" class="inline-block m-0 p-0">
                            <?= csrf_field() ?>
                            <button type="submit" class="p-1.5 text-rose-500 hover:text-rose-700 rounded-lg hover:bg-rose-50 transition bg-transparent border-0 cursor-pointer" title="Delete">
                                <i data-lucide="trash-2" class="w-4 h-4"></i>
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Add Experience Modal -->
    <div x-show="showAddExp" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" style="display: none;">
        <div @click.away="showAddExp = false" class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 w-full max-w-lg p-6 shadow-xl space-y-4">
            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                <h3 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                    <i data-lucide="briefcase" class="w-4 h-4 text-indigo-600"></i>
                    Add Past Work Experience
                </h3>
                <button type="button" @click="showAddExp = false" class="text-slate-400 hover:text-slate-600">
                    <i data-lucide="x" class="w-4 h-4"></i>
                </button>
            </div>

            <form action="<?= base_url('employees/profile/' . $employee['id'] . '/experience/add') ?>" method="POST" class="space-y-4 text-xs">
                <?= csrf_field() ?>
                
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Company / Organization</label>
                        <input type="text" name="company" placeholder="e.g. Acme Corp Ltd" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                    </div>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Designation / Role</label>
                        <input type="text" name="designation" placeholder="e.g. Junior Developer" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Joining Date</label>
                        <input type="date" name="joining_date" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                    </div>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Leaving Date</label>
                        <input type="date" name="leaving_date" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                    </div>
                </div>

                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Key Responsibilities & Projects</label>
                    <textarea name="responsibilities" rows="3" placeholder="Key deliverables, achievements..." class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"></textarea>
                </div>

                <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-700">
                    <button type="button" @click="showAddExp = false" class="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold">Cancel</button>
                    <button type="submit" class="px-4 py-2 rounded-xl bg-indigo-600 text-white font-semibold hover:bg-indigo-700 shadow-sm">Save Experience</button>
                </div>
            </form>
        </div>
    </div>
</div>
