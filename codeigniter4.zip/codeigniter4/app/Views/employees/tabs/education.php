<!-- Education Tab -->
<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-6" x-data="{ showAddEdu: false }">
    <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-4">
        <div>
            <h3 class="font-bold text-slate-900 dark:text-white text-base">Educational Qualifications</h3>
            <p class="text-xs text-slate-500 mt-0.5">Academic credentials, degrees, and institutions</p>
        </div>
        <button type="button" @click="showAddEdu = true" class="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400 rounded-xl text-xs font-semibold border border-indigo-200 dark:border-indigo-800 flex items-center gap-1.5 transition">
            <i data-lucide="plus" class="w-3.5 h-3.5"></i>
            <span>Add Qualification</span>
        </button>
    </div>

    <!-- Education Table -->
    <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse text-xs">
            <thead>
                <tr class="border-b border-slate-100 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 text-slate-500 font-medium">
                    <th class="py-3 px-4">Exam / Degree</th>
                    <th class="py-3 px-4">Institute / University</th>
                    <th class="py-3 px-4">Major / Subject</th>
                    <th class="py-3 px-4">Passing Year</th>
                    <th class="py-3 px-4">Result / GPA</th>
                    <th class="py-3 px-4 text-right">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100 dark:divide-slate-700">
                <?php if (empty($education)): ?>
                    <tr>
                        <td colspan="6" class="py-8 text-center text-slate-400">
                            <i data-lucide="graduation-cap" class="w-8 h-8 mx-auto mb-2 text-slate-300"></i>
                            <p>No educational qualifications added yet.</p>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($education as $edu): ?>
                        <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                            <td class="py-3 px-4 font-bold text-slate-900 dark:text-white"><?= esc($edu['degree']) ?></td>
                            <td class="py-3 px-4 text-slate-700 dark:text-slate-300"><?= esc($edu['institution']) ?></td>
                            <td class="py-3 px-4 text-slate-600 dark:text-slate-400"><?= esc($edu['subject'] ?? 'General') ?></td>
                            <td class="py-3 px-4 font-mono"><?= esc($edu['passing_year']) ?></td>
                            <td class="py-3 px-4 font-bold text-emerald-600 dark:text-emerald-400"><?= esc($edu['result']) ?></td>
                            <td class="py-3 px-4 text-right">
                                <form method="POST" action="<?= base_url('employees/profile/' . $employee['id'] . '/education/delete/' . $edu['id']) ?>" onsubmit="return confirm('Remove this qualification?')" class="inline-block m-0 p-0">
                                    <?= csrf_field() ?>
                                    <button type="submit" class="p-1 text-rose-500 hover:text-rose-700 transition bg-transparent border-0 cursor-pointer" title="Delete Qualification">
                                        <i data-lucide="trash-2" class="w-4 h-4 inline"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Add Education Modal -->
    <div x-show="showAddEdu" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" style="display: none;">
        <div @click.away="showAddEdu = false" class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 w-full max-w-lg p-6 shadow-xl space-y-4">
            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                <h3 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                    <i data-lucide="graduation-cap" class="w-4 h-4 text-indigo-600"></i>
                    Add Educational Qualification
                </h3>
                <button type="button" @click="showAddEdu = false" class="text-slate-400 hover:text-slate-600">
                    <i data-lucide="x" class="w-4 h-4"></i>
                </button>
            </div>

            <form action="<?= base_url('employees/profile/' . $employee['id'] . '/education/add') ?>" method="POST" class="space-y-4 text-xs">
                <?= csrf_field() ?>
                
                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Degree / Examination Name</label>
                    <input type="text" name="degree" placeholder="e.g. B.Sc. in Computer Science & Engineering" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                </div>

                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Institute / University</label>
                    <input type="text" name="institution" placeholder="e.g. University of Dhaka" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Major / Subject</label>
                        <input type="text" name="subject" placeholder="e.g. Computer Science" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                    </div>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Board / University Board</label>
                        <input type="text" name="board_university" placeholder="e.g. Dhaka" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Passing Year</label>
                        <input type="number" name="passing_year" placeholder="e.g. 2020" value="<?= date('Y') - 4 ?>" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono">
                    </div>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Result / CGPA / Grade</label>
                        <input type="text" name="result" placeholder="e.g. 3.85 / 4.00" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                    </div>
                </div>

                <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-700">
                    <button type="button" @click="showAddEdu = false" class="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold">Cancel</button>
                    <button type="submit" class="px-4 py-2 rounded-xl bg-indigo-600 text-white font-semibold hover:bg-indigo-700 shadow-sm">Save Qualification</button>
                </div>
            </form>
        </div>
    </div>
</div>
