<!-- Emergency Contacts Tab -->
<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-6" x-data="{ showAddEm: false }">
    <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-4">
        <div>
            <h3 class="font-bold text-slate-900 dark:text-white text-base">Emergency Contacts Directory</h3>
            <p class="text-xs text-slate-500 mt-0.5">Designated points of contact in case of workplace or medical emergencies</p>
        </div>
        <button type="button" @click="showAddEm = true" class="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400 rounded-xl text-xs font-semibold border border-indigo-200 dark:border-indigo-800 flex items-center gap-1.5 transition">
            <i data-lucide="plus" class="w-3.5 h-3.5"></i>
            <span>Add Emergency Contact</span>
        </button>
    </div>

    <!-- Emergency Contacts Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <?php if (empty($emergencyContacts)): ?>
            <div class="md:col-span-2 py-8 text-center text-slate-400">
                <i data-lucide="phone-call" class="w-8 h-8 mx-auto mb-2 text-slate-300"></i>
                <p class="text-xs">No designated emergency contacts found.</p>
            </div>
        <?php else: ?>
            <?php foreach ($emergencyContacts as $em): ?>
                <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 flex flex-col justify-between text-xs space-y-3">
                    <div>
                        <div class="flex items-center justify-between">
                            <h4 class="font-bold text-slate-900 dark:text-white text-sm"><?= esc($em['name']) ?></h4>
                            <?php if (!empty($em['primary_contact'])): ?>
                                <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">Primary Contact</span>
                            <?php endif; ?>
                        </div>
                        <span class="text-indigo-600 dark:text-indigo-400 font-semibold"><?= esc($em['relationship']) ?></span>
                        <div class="mt-2 space-y-1 text-slate-600 dark:text-slate-300">
                            <div>Phone: <span class="font-mono font-bold"><?= esc($em['phone']) ?></span></div>
                            <?php if (!empty($em['alternate_phone'])): ?>
                                <div>Alt Phone: <span class="font-mono"><?= esc($em['alternate_phone']) ?></span></div>
                            <?php endif; ?>
                            <?php if (!empty($em['address'])): ?>
                                <div>Address: <?= esc($em['address']) ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="pt-2 border-t border-slate-200 dark:border-slate-700 flex justify-end">
                        <form method="POST" action="<?= base_url('employees/profile/' . $employee['id'] . '/emergency/delete/' . $em['id']) ?>" onsubmit="return confirm('Remove this emergency contact?')" class="inline-block m-0 p-0">
                            <?= csrf_field() ?>
                            <button type="submit" class="text-rose-500 hover:text-rose-700 text-xs font-semibold flex items-center gap-1 bg-transparent border-0 cursor-pointer p-0">
                                <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                                <span>Remove</span>
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Add Emergency Contact Modal -->
    <div x-show="showAddEm" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" style="display: none;">
        <div @click.away="showAddEm = false" class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 w-full max-w-md p-6 shadow-xl space-y-4">
            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                <h3 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                    <i data-lucide="phone-call" class="w-4 h-4 text-indigo-600"></i>
                    Add Emergency Contact
                </h3>
                <button type="button" @click="showAddEm = false" class="text-slate-400 hover:text-slate-600">
                    <i data-lucide="x" class="w-4 h-4"></i>
                </button>
            </div>

            <form action="<?= base_url('employees/profile/' . $employee['id'] . '/emergency/add') ?>" method="POST" class="space-y-4 text-xs">
                <?= csrf_field() ?>
                
                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Contact Full Name</label>
                    <input type="text" name="name" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Relationship</label>
                        <input type="text" name="relationship" placeholder="e.g. Spouse / Brother" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                    </div>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Primary Phone</label>
                        <input type="text" name="phone" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                    </div>
                </div>

                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Alternate Phone</label>
                    <input type="text" name="alternate_phone" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                </div>

                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Physical Address</label>
                    <input type="text" name="address" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                </div>

                <label class="flex items-center gap-2 font-semibold text-slate-700 dark:text-slate-300 cursor-pointer pt-1">
                    <input type="checkbox" name="primary_contact" value="1" class="rounded border-slate-300 text-indigo-600">
                    <span>Designate as Primary Emergency Contact</span>
                </label>

                <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-700">
                    <button type="button" @click="showAddEm = false" class="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold">Cancel</button>
                    <button type="submit" class="px-4 py-2 rounded-xl bg-indigo-600 text-white font-semibold hover:bg-indigo-700 shadow-sm">Save Contact</button>
                </div>
            </form>
        </div>
    </div>
</div>
