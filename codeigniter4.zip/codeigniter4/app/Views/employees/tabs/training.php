<!-- Training & Development Tab -->
<div class="space-y-6">
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-4">
        <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-4">
            <div>
                <h3 class="font-bold text-slate-900 dark:text-white text-base">Corporate Training & Professional Development</h3>
                <p class="text-xs text-slate-500 mt-0.5">Assigned workshops, compliance programs, and certificates earned</p>
            </div>
            <span class="text-xs font-bold text-indigo-600 px-3 py-1 bg-indigo-50 dark:bg-indigo-950/60 rounded-xl border border-indigo-200 dark:border-indigo-800">
                2 Completed Programs
            </span>
        </div>

        <div class="space-y-3">
            <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
                <div class="space-y-1">
                    <div class="flex items-center gap-2">
                        <span class="font-bold text-slate-900 dark:text-white text-sm">Advanced System Architecture & Cloud Security</span>
                        <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">Passed (95%)</span>
                    </div>
                    <p class="text-slate-500">Conducted by Tech Lead Academy &bull; 40 Hours Coursework</p>
                </div>
                <div class="text-right font-mono text-slate-400 text-[11px]">
                    Completed: 2025-11-20
                </div>
            </div>

            <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
                <div class="space-y-1">
                    <div class="flex items-center gap-2">
                        <span class="font-bold text-slate-900 dark:text-white text-sm">HIPAA Compliance & Healthcare Data Privacy</span>
                        <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">Certified</span>
                    </div>
                    <p class="text-slate-500">Corporate Mandatory Training &bull; 16 Hours</p>
                </div>
                <div class="text-right font-mono text-slate-400 text-[11px]">
                    Completed: 2026-01-15
                </div>
            </div>
        </div>
    </div>
</div>
