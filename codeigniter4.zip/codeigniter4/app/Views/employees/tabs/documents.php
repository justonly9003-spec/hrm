<!-- Documents Tab -->
<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-6" x-data="{ showUploadDoc: false }">
    <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-4">
        <div>
            <h3 class="font-bold text-slate-900 dark:text-white text-base">Documents & Attachments</h3>
            <p class="text-xs text-slate-500 mt-0.5">National identity, resume, certificates, and compliance contracts</p>
        </div>
        <button type="button" @click="showUploadDoc = true" class="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400 rounded-xl text-xs font-semibold border border-indigo-200 dark:border-indigo-800 flex items-center gap-1.5 transition">
            <i data-lucide="upload" class="w-3.5 h-3.5"></i>
            <span>Upload Document</span>
        </button>
    </div>

    <!-- Documents Grid -->
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        <?php if (empty($documents)): ?>
            <!-- Default Pre-seeded Documents List for showcase -->
            <?php 
            $defaultDocs = [
                ['name' => 'Profile Photo', 'type' => 'JPG', 'size' => '250 KB', 'date' => '2026-01-01', 'expiry' => 'N/A'],
                ['name' => 'Resume / CV', 'type' => 'PDF', 'size' => '1.2 MB', 'date' => '2026-01-01', 'expiry' => 'N/A'],
                ['name' => 'National ID (NID)', 'type' => 'PDF', 'size' => '840 KB', 'date' => '2026-01-01', 'expiry' => '2034-12-31'],
                ['name' => 'Academic Degree Certificate', 'type' => 'PDF', 'size' => '2.5 MB', 'date' => '2026-01-01', 'expiry' => 'N/A'],
                ['name' => 'Offer & Appointment Letter', 'type' => 'PDF', 'size' => '1.8 MB', 'date' => '2026-01-01', 'expiry' => 'N/A'],
                ['name' => 'Passport Copy', 'type' => 'PDF', 'size' => '2.1 MB', 'date' => '2026-01-01', 'expiry' => '2029-05-15'],
            ];
            ?>
            <?php foreach ($defaultDocs as $doc): ?>
                <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 flex flex-col justify-between text-xs space-y-3">
                    <div class="flex items-start justify-between gap-2">
                        <div class="flex items-center gap-2.5">
                            <div class="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-xs">
                                <?= esc($doc['type']) ?>
                            </div>
                            <div>
                                <h4 class="font-bold text-slate-900 dark:text-white"><?= esc($doc['name']) ?></h4>
                                <span class="text-[11px] text-slate-400 font-mono"><?= esc($doc['size']) ?></span>
                            </div>
                        </div>
                    </div>
                    <div class="pt-2 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between text-[11px] text-slate-500">
                        <span>Uploaded: <?= esc($doc['date']) ?></span>
                        <a href="javascript:void(0)" class="text-indigo-600 hover:text-indigo-700 font-semibold flex items-center gap-1">
                            <i data-lucide="download" class="w-3.5 h-3.5"></i>
                            <span>View</span>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <?php foreach ($documents as $doc): ?>
                <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 flex flex-col justify-between text-xs space-y-3">
                    <div class="flex items-start justify-between gap-2">
                        <div class="flex items-center gap-2.5">
                            <div class="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-xs">
                                PDF
                            </div>
                            <div>
                                <h4 class="font-bold text-slate-900 dark:text-white"><?= esc($doc['file_name']) ?></h4>
                                <span class="text-[11px] text-slate-400"><?= esc($doc['document_type'] ?? 'General') ?></span>
                            </div>
                        </div>
                    </div>
                    <div class="pt-2 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between text-[11px] text-slate-500">
                        <span><?= esc(substr($doc['created_at'] ?? date('Y-m-d'), 0, 10)) ?></span>
                        <div class="flex items-center gap-3">
                            <form method="POST" action="<?= base_url('employees/profile/' . $employee['id'] . '/documents/visibility/' . $doc['id']) ?>" class="inline-block m-0 p-0">
                                <?= csrf_field() ?>
                                <button type="submit" title="Show or hide this document in the employee mobile app" class="font-semibold bg-transparent border-0 cursor-pointer p-0 text-xs <?= !empty($doc['employee_visible']) ? 'text-emerald-600 hover:text-emerald-700' : 'text-slate-400 hover:text-slate-600' ?>">
                                    <?= !empty($doc['employee_visible']) ? 'Visible in app' : 'Hidden from app' ?>
                                </button>
                            </form>
                            <a href="<?= base_url('employees/profile/' . $employee['id'] . '/documents/download/' . $doc['id']) ?>" target="_blank" class="text-indigo-600 hover:text-indigo-700 font-semibold flex items-center gap-1">
                                <i data-lucide="download" class="w-3.5 h-3.5"></i>
                                <span>Download</span>
                            </a>
                            <form method="POST" action="<?= base_url('employees/profile/' . $employee['id'] . '/documents/delete/' . $doc['id']) ?>" onsubmit="return confirm('Permanently delete this compliance document?')" class="inline-block m-0 p-0">
                                <?= csrf_field() ?>
                                <button type="submit" class="text-rose-500 hover:text-rose-700 font-semibold bg-transparent border-0 cursor-pointer p-0 text-xs">Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Upload Document Modal -->
    <div x-show="showUploadDoc" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" style="display: none;">
        <div @click.away="showUploadDoc = false" class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 w-full max-w-md p-6 shadow-xl space-y-4">
            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                <h3 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                    <i data-lucide="upload-cloud" class="w-4 h-4 text-indigo-600"></i>
                    Upload Employee Document
                </h3>
                <button type="button" @click="showUploadDoc = false" class="text-slate-400 hover:text-slate-600">
                    <i data-lucide="x" class="w-4 h-4"></i>
                </button>
            </div>

            <form action="<?= base_url('employees/profile/' . $employee['id'] . '/documents/upload') ?>" method="POST" enctype="multipart/form-data" class="space-y-4 text-xs">
                <?= csrf_field() ?>
                
                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Document Category</label>
                    <select name="document_type" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                        <option value="National ID (NID)">National ID (NID)</option>
                        <option value="Passport">Passport</option>
                        <option value="Academic Certificate">Academic Certificate</option>
                        <option value="Appointment Letter">Appointment Letter</option>
                        <option value="CV / Resume">CV / Resume</option>
                        <option value="Tax Certificate">Tax Return / TIN Certificate</option>
                        <option value="Other">Other Compliance Document</option>
                    </select>
                </div>

                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Document Title / Display Name</label>
                    <input type="text" name="file_name" placeholder="e.g. Master Degree Certificate 2024" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                </div>

                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Expiry Date (Optional)</label>
                    <input type="date" name="expiry_date" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                </div>

                <label class="flex items-center gap-2 font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">
                    <input type="checkbox" name="employee_visible" value="1" class="rounded border-slate-300">
                    <span>Show this document in the employee mobile app <span class="font-normal text-slate-400">(HR only)</span></span>
                </label>

                <div class="border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-xl p-4 text-center space-y-2">
                    <i data-lucide="file-up" class="w-6 h-6 mx-auto text-indigo-500"></i>
                    <div class="font-semibold text-slate-700 dark:text-slate-300">Choose file to upload</div>
                    <input type="file" name="document_file" required accept=".pdf,.jpg,.jpeg,.png" class="block w-full text-xs text-slate-500 dark:text-slate-400 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 dark:file:bg-indigo-950/60 dark:file:text-indigo-400 cursor-pointer">
                    <div class="text-[10px] text-slate-400">PDF, JPG, PNG &bull; Max 10MB</div>
                </div>

                <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-700">
                    <button type="button" @click="showUploadDoc = false" class="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold">Cancel</button>
                    <button type="submit" class="px-4 py-2 rounded-xl bg-indigo-600 text-white font-semibold hover:bg-indigo-700 shadow-sm">Save & Attach</button>
                </div>
            </form>
        </div>
    </div>
</div>
