<!-- Skills & Certifications Tab -->
<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-6">
    <div class="border-b border-slate-100 dark:border-slate-700 pb-4">
        <h3 class="font-bold text-slate-900 dark:text-white text-base">Skills & Competency Matrix</h3>
        <p class="text-xs text-slate-500 mt-0.5">Technical competencies, soft skills, languages, and certifications</p>
    </div>

    <form action="<?= base_url('employees/profile/' . $employee['id'] . '/update-skills') ?>" method="POST" class="space-y-4 text-xs">
        <?= csrf_field() ?>
        
        <div>
            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Technical & Domain Skills (Comma separated)</label>
            <textarea name="tech_skills" rows="3" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"><?= esc($employee['tech_skills'] ?? 'PHP, CodeIgniter 4, React.js, TypeScript, MySQL, REST APIs, Tailwind CSS, Git') ?></textarea>
        </div>

        <div>
            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Soft & Leadership Skills</label>
            <textarea name="soft_skills" rows="2" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"><?= esc($employee['soft_skills'] ?? 'Team Leadership, Problem Solving, Cross-functional Communication, Time Management') ?></textarea>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Language Proficiencies</label>
                <input type="text" name="languages" value="<?= esc($employee['languages'] ?? 'English (Fluent), Bengali (Native)') ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
            </div>

            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Professional Certifications</label>
                <input type="text" name="certifications" value="<?= esc($employee['certifications'] ?? 'AWS Certified Solutions Architect, Certified Scrum Master') ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
            </div>
        </div>

        <div class="flex justify-end pt-4 border-t border-slate-100 dark:border-slate-700">
            <button type="submit" class="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition flex items-center gap-2">
                <i data-lucide="check" class="w-4 h-4"></i>
                <span>Save Skills & Certifications</span>
            </button>
        </div>
    </form>
</div>
