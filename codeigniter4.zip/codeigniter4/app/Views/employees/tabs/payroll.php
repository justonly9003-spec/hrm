<!-- Payroll & Salary Breakdown Tab -->
<?php
$activeSalary = $salarySetup['active_salary'] ?? null;
$basic = (float)($activeSalary['basic_salary'] ?? $salarySetup['basic_salary'] ?? $employee['basic_salary'] ?? 0);
$gross = (float)($activeSalary['gross_salary'] ?? $salarySetup['gross_salary'] ?? $employee['gross_salary'] ?? $basic);
$totalDeductions = (float)($activeSalary['total_deductions'] ?? 0);
$netSalary = (float)($activeSalary['net_salary'] ?? max(0, $gross - $totalDeductions));
$ctc = (float)($activeSalary['ctc'] ?? $gross);

$isConfigured = !empty($salarySetup['is_configured']) && ($basic > 0 || $gross > 0);
$activeEarnings = $activeSalary['earnings'] ?? [];
$activeDeductions = $activeSalary['deductions'] ?? [];
$activeEmployerContributions = $activeSalary['employer_contributions'] ?? [];
$activeStructureId = $activeSalary['structure_id'] ?? $salarySetup['structure_id'] ?? '';

// Fallback legacy values if no active earnings array
if (empty($activeEarnings) && $isConfigured) {
    $components = $salarySetup['components'] ?? [];
    $houseRent = (float)($components['house_rent'] ?? $employee['house_rent_allowance'] ?? 0);
    $medical = (float)($components['medical'] ?? $employee['medical_allowance'] ?? 0);
    $transport = (float)($components['conveyance'] ?? $employee['conveyance_allowance'] ?? $employee['transport_allowance'] ?? 0);
    $other = (float)($components['other_allowances'] ?? $employee['other_allowances'] ?? 0);
} else {
    $houseRent = 0;
    $medical = 0;
    $transport = 0;
    $other = 0;
    foreach ($activeEarnings as $ae) {
        $c = strtoupper($ae['code'] ?? '');
        if ($c === 'HRA' || stripos($ae['name'] ?? '', 'house rent') !== false) {
            $houseRent = (float)($ae['amount'] ?? 0);
        } elseif ($c === 'MED' || stripos($ae['name'] ?? '', 'medical') !== false) {
            $medical = (float)($ae['amount'] ?? 0);
        } elseif ($c === 'CONV' || stripos($ae['name'] ?? '', 'conveyance') !== false || stripos($ae['name'] ?? '', 'transport') !== false) {
            $transport = (float)($ae['amount'] ?? 0);
        } elseif ($c !== 'BASIC' && stripos($ae['name'] ?? '', 'basic') === false) {
            $other += (float)($ae['amount'] ?? 0);
        }
    }
}

$salaryHistory = $salarySetup['salary_history'] ?? [];
$revisions = $salarySetup['revisions'] ?? [];
$canManageSalary = !empty($isSalaryAdmin);
$companyComponents = $salarySetup['components'] ?? [];

$existingTaxSettings = [];
if (!empty($activeSalary['tax_settings_json'])) {
    $existingTaxSettings = is_string($activeSalary['tax_settings_json']) ? json_decode($activeSalary['tax_settings_json'], true) : $activeSalary['tax_settings_json'];
} elseif (!empty($activeSalary['tax_settings']) && is_array($activeSalary['tax_settings'])) {
    $existingTaxSettings = $activeSalary['tax_settings'];
}
$curTaxCategory = $existingTaxSettings['category'] ?? $employee['tax_category'] ?? 'General';
$curTaxTin = $existingTaxSettings['tin'] ?? $employee['tax_identification_number'] ?? '';
$curTaxMode = $existingTaxSettings['calculation_mode'] ?? (!empty($existingTaxSettings['is_override']) ? (!empty($existingTaxSettings['custom_tax_amount']) ? 'Fixed' : 'Exempt') : 'Auto');
$curTaxCustomAmt = $existingTaxSettings['custom_tax_amount'] ?? $existingTaxSettings['fixed_amount'] ?? '';
$curTaxReason = $existingTaxSettings['override_reason'] ?? '';
$curAutoCalc  = ($curTaxMode === 'Auto') ? 'active' : (($curTaxMode === 'Exempt') ? 'exempt' : 'inactive');
$curAnnualTax = $existingTaxSettings['annual_tax_amount']
    ?? ((isset($existingTaxSettings['custom_tax_amount']) && is_numeric($existingTaxSettings['custom_tax_amount']) && (float)$existingTaxSettings['custom_tax_amount'] > 0)
        ? round((float)$existingTaxSettings['custom_tax_amount'] * 12, 2) : '');
$curAnnualTaxYear = $existingTaxSettings['annual_tax_year'] ?? '';
?>

<div class="space-y-6">
    <!-- Mandatory Manual Salary Assignment Policy Notification -->
    <?php if (!$isConfigured): ?>
        <div class="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/80 rounded-2xl p-5 shadow-xs">
            <div class="flex items-start gap-4">
                <div class="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-900/60 text-amber-700 dark:text-amber-300 flex items-center justify-center shrink-0">
                    <i data-lucide="alert-triangle" class="w-5 h-5"></i>
                </div>
                <div class="space-y-1.5 flex-1">
                    <div class="flex items-center justify-between">
                        <h4 class="font-bold text-amber-950 dark:text-amber-200 text-sm">Salary Configuration Required</h4>
                        <span class="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-200/60 dark:bg-amber-900 text-amber-900 dark:text-amber-200">
                            Status: NOT CONFIGURED
                        </span>
                    </div>
                    <p class="text-xs text-amber-800 dark:text-amber-300/90 leading-relaxed">
                        In accordance with enterprise payroll governance, an employee's actual salary must be explicitly assigned by an authorized HR/Admin user. The system strictly forbids silent generation of salaries from default structures, demo salaries, or generic allowances. This employee will remain <strong>excluded</strong> from automated monthly payroll batches until compensation is explicitly configured.
                    </p>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Current Salary Overview Card -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-6">
        <div class="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-700 pb-4">
            <div>
                <div class="flex items-center gap-2">
                    <h3 class="font-bold text-slate-900 dark:text-white text-base">Monthly Compensation & Allowance Breakdown</h3>
                    <?php if ($isConfigured): ?>
                        <span class="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                            Configured & Active
                        </span>
                    <?php else: ?>
                        <span class="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                            Pending HR Assignment
                        </span>
                    <?php endif; ?>
                </div>
                <p class="text-xs text-slate-500 mt-0.5">Authoritative employee salary components and baseline deductions</p>
            </div>

            <div class="flex items-center gap-3">
                <span class="text-xs font-mono font-bold px-3 py-1.5 <?= $isConfigured ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800' : 'bg-slate-100 text-slate-500 dark:bg-slate-700 dark:text-slate-400 border-slate-200 dark:border-slate-600' ?> rounded-xl border">
                    Net Pay: <?= format_money($netSalary) ?>
                </span>
                <?php if ($canManageSalary): ?>
                    <button type="button" 
                            onclick="document.getElementById('salary-assignment-card').scrollIntoView({ behavior: 'smooth' }); document.getElementById('assign-basic-salary').focus();"
                            class="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-medium transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer">
                        <i data-lucide="edit-3" class="w-3.5 h-3.5"></i>
                        <?= $isConfigured ? 'Revise Salary' : 'Assign Salary' ?>
                    </button>
                <?php endif; ?>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            <!-- Earnings / Allowances -->
            <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 space-y-3">
                <h4 class="font-bold text-slate-900 dark:text-white text-xs flex items-center gap-1.5 text-indigo-600">
                    <i data-lucide="plus-circle" class="w-4 h-4"></i>
                    Earnings & Allowances
                </h4>
                <div class="space-y-2">
                    <?php if (!empty($activeEarnings)): ?>
                        <?php foreach ($activeEarnings as $ea): ?>
                            <div class="flex justify-between items-center">
                                <span class="text-slate-600 dark:text-slate-300">
                                    <?= esc($ea['name'] ?? 'Earning') ?>
                                    <?php if (!empty($ea['code'])): ?>
                                        <span class="text-[10px] text-slate-400 font-mono">[<?= esc($ea['code']) ?>]</span>
                                    <?php endif; ?>
                                </span>
                                <span class="font-mono font-medium text-slate-900 dark:text-white">
                                    <?= format_money((float)($ea['amount'] ?? 0)) ?>
                                </span>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="flex justify-between items-center">
                            <span class="text-slate-500">Basic Salary</span>
                            <span class="font-mono font-bold text-slate-900 dark:text-white"><?= format_money($basic) ?></span>
                        </div>
                        <?php if ($houseRent > 0): ?>
                            <div class="flex justify-between items-center">
                                <span class="text-slate-500">House Rent Allowance</span>
                                <span class="font-mono font-medium text-slate-800 dark:text-slate-200"><?= format_money($houseRent) ?></span>
                            </div>
                        <?php endif; ?>
                        <?php if ($medical > 0): ?>
                            <div class="flex justify-between items-center">
                                <span class="text-slate-500">Medical Allowance</span>
                                <span class="font-mono font-medium text-slate-800 dark:text-slate-200"><?= format_money($medical) ?></span>
                            </div>
                        <?php endif; ?>
                        <?php if ($transport > 0): ?>
                            <div class="flex justify-between items-center">
                                <span class="text-slate-500">Conveyance / Transport</span>
                                <span class="font-mono font-medium text-slate-800 dark:text-slate-200"><?= format_money($transport) ?></span>
                            </div>
                        <?php endif; ?>
                        <?php if ($other > 0): ?>
                            <div class="flex justify-between items-center">
                                <span class="text-slate-500">Other Allowances</span>
                                <span class="font-mono font-medium text-slate-800 dark:text-slate-200"><?= format_money($other) ?></span>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>

                    <div class="pt-2 border-t border-slate-200 dark:border-slate-700 flex justify-between items-center font-bold">
                        <span class="text-indigo-600 dark:text-indigo-400">Gross Monthly Salary</span>
                        <span class="font-mono text-indigo-700 dark:text-indigo-300 text-sm"><?= format_money($gross) ?></span>
                    </div>
                </div>
            </div>

            <!-- Deductions -->
            <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 space-y-3">
                <h4 class="font-bold text-slate-900 dark:text-white text-xs flex items-center gap-1.5 text-rose-600">
                    <i data-lucide="minus-circle" class="w-4 h-4"></i>
                    Statutory & Voluntary Deductions
                </h4>
                <div class="space-y-2">
                    <?php if (!empty($activeDeductions)): ?>
                        <?php foreach ($activeDeductions as $ded): ?>
                            <div class="flex justify-between items-center">
                                <span class="text-slate-600 dark:text-slate-300">
                                    <?= esc($ded['name'] ?? 'Deduction') ?>
                                    <?php if (!empty($ded['code'])): ?>
                                        <span class="text-[10px] text-slate-400 font-mono">[<?= esc($ded['code']) ?>]</span>
                                    <?php endif; ?>
                                </span>
                                <span class="font-mono font-medium text-rose-600">
                                    -<?= format_money((float)($ded['amount'] ?? 0)) ?>
                                </span>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="flex justify-between items-center">
                            <span class="text-slate-500">Provident Fund (PF)</span>
                            <span class="font-mono font-medium text-slate-400"><?= format_money(0.00) ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-slate-500">Income Tax (Withholding)</span>
                            <span class="font-mono font-medium text-slate-400"><?= format_money(0.00) ?></span>
                        </div>
                    <?php endif; ?>
                    <div class="pt-2 border-t border-slate-200 dark:border-slate-700 flex justify-between items-center font-bold">
                        <span class="text-rose-600">Total Deductions</span>
                        <span class="font-mono text-rose-600 text-sm">-<?= format_money($totalDeductions) ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Explicit Manual Salary Assignment Form (Authorized HR/Admin Only) -->
    <?php if ($canManageSalary): ?>
        <div id="salary-assignment-card" class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-6">
            <div class="border-b border-slate-100 dark:border-slate-700 pb-4">
                <div class="flex items-center gap-2">
                    <div class="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                        <i data-lucide="shield-check" class="w-4 h-4"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-slate-900 dark:text-white text-base">
                            <?= $isConfigured ? 'Revise Assigned Salary & Structure' : 'Assign Employee Salary & Structure' ?>
                        </h3>
                        <p class="text-xs text-slate-500">
                            Dynamic salary structure template-driven compensation assignment with live editable component cells.
                        </p>
                    </div>
                </div>
            </div>

            <form action="<?= base_url("employees/{$employee['id']}/salary") ?>" method="POST" class="space-y-6" id="salary-assignment-form">
                <?= csrf_field() ?>
                <input type="hidden" name="components_json" id="assign-components-json" value="">
                
                <!-- Legacy fallbacks populated automatically by JS engine -->
                <input type="hidden" name="house_rent_value" id="legacy-house-rent" value="<?= $houseRent ?>">
                <input type="hidden" name="medical_value" id="legacy-medical" value="<?= $medical ?>">
                <input type="hidden" name="conveyance_allowance" id="legacy-conveyance" value="<?= $transport ?>">
                <input type="hidden" name="other_allowances" id="legacy-other" value="<?= $other ?>">

                <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                    <!-- Basic Salary (Mandatory Base) -->
                    <div>
                        <label for="assign-basic-salary" class="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                            Basic Salary (<?= esc($currencyCode) ?>) <span class="text-rose-500 font-bold">*</span>
                        </label>
                        <div class="relative">
                            <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 font-mono"><?= esc($currencyCode) ?></span>
                            <input type="number" 
                                   step="0.01" 
                                   min="0" 
                                   required 
                                   id="assign-basic-salary" 
                                   name="basic_salary" 
                                   value="<?= $basic > 0 ? $basic : '' ?>" 
                                   placeholder="e.g. 350000.00"
                                   class="w-full pl-8 pr-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 font-mono font-bold text-sm">
                        </div>
                        <p class="text-[11px] text-slate-400 mt-1">Core baseline amount for percentage allowances, PF, and tax calculation.</p>
                    </div>

                    <!-- Salary Structure Template Selection -->
                    <div>
                        <label for="assign-structure-id" class="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                            Salary Structure Template <span class="text-indigo-600 font-semibold">(Template Wise Cells)</span>
                        </label>
                        <select id="assign-structure-id" 
                                name="structure_id" 
                                class="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 font-medium">
                            <option value="">-- No Preset Template (Custom Allowances) --</option>
                            <?php if (!empty($salaryStructures)): ?>
                                <?php foreach ($salaryStructures as $st): ?>
                                    <option value="<?= esc($st['id']) ?>" <?= (!empty($activeStructureId) && $activeStructureId === $st['id']) ? 'selected' : '' ?>>
                                        <?= esc($st['name']) ?> (<?= count($st['items'] ?? []) ?> components)
                                    </option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                        <p class="text-[11px] text-slate-400 mt-1">Selecting a template loads its salary components and calculation cells dynamically.</p>
                    </div>

                    <!-- Effective From Date -->
                    <div>
                        <label for="assign-effective-from" class="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                            Effective Date <span class="text-rose-500 font-bold">*</span>
                        </label>
                        <input type="date" 
                               required 
                               id="assign-effective-from" 
                               name="effective_from" 
                               value="<?= date('Y-m-d') ?>" 
                               class="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 font-medium">
                        <p class="text-[11px] text-slate-400 mt-1">Date when this salary configuration becomes active and authoritative.</p>
                    </div>
                </div>

                <!-- Statutory Policy Settings (Single Source for Income Tax TDS & Provident Fund) -->
                <div class="pt-4 border-t border-slate-200 dark:border-slate-700">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <!-- Income Tax (TDS) Card -->
                        <div id="card-emp-tab-tax" class="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl p-4 space-y-3">
                            <div class="flex items-center justify-between">
                                <span class="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                                    <i data-lucide="receipt" class="w-3.5 h-3.5 text-indigo-600"></i>
                                    <span>Income Tax (TDS) Settings</span>
                                </span>
                                <span class="px-2 py-0.5 rounded-full text-[9px] font-bold font-mono bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 uppercase">
                                    Statutory Rule • TAX
                                </span>
                            </div>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400">Single Source for employee Tax TDS. Governed by statutory slab calculation.</p>
                            <div class="grid grid-cols-2 gap-2 text-xs">
                                <div>
                                    <label class="block text-[10px] font-medium text-slate-600 dark:text-slate-300 mb-1">Tax Category</label>
                                    <select name="tax_settings[category]" id="assign-tax-category" class="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs">
                                        <option value="General" <?= $curTaxCategory === 'General' ? 'selected' : '' ?>>General</option>
                                        <option value="Female" <?= $curTaxCategory === 'Female' ? 'selected' : '' ?>>Female</option>
                                        <option value="Senior Citizen" <?= $curTaxCategory === 'Senior Citizen' ? 'selected' : '' ?>>Senior Citizen (65+)</option>
                                        <option value="Person with Disability" <?= $curTaxCategory === 'Person with Disability' ? 'selected' : '' ?>>Physically Challenged</option>
                                        <option value="Gazette-notified War-wounded Freedom Fighter" <?= $curTaxCategory === 'Gazette-notified War-wounded Freedom Fighter' ? 'selected' : '' ?>>Freedom Fighter</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-[10px] font-medium text-slate-600 dark:text-slate-300 mb-1">TIN Number</label>
                                    <input type="text" name="tax_settings[tin]" value="<?= esc($curTaxTin) ?>" placeholder="12-digit TIN" class="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs font-mono">
                                </div>
                            </div>
                            <div class="space-y-2 pt-1 border-t border-slate-200/60 dark:border-slate-700/60">
                                <div class="flex items-center justify-between text-xs">
                                    <span class="font-medium text-slate-600 dark:text-slate-300 text-[11px]">Auto Tax Calculation:</span>
                                    <select name="tax_settings[auto_calculation]" id="emp-tab-tax-auto" onchange="toggleEmployeeTabTaxOverride(this.value)"
                                            class="px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs">
                                        <option value="active"   <?= $curAutoCalc === 'active'   ? 'selected' : '' ?>>Active (automatic slab calculation)</option>
                                        <option value="inactive" <?= $curAutoCalc === 'inactive' ? 'selected' : '' ?>>Deactive (annual amount ÷ 12)</option>
                                        <?php if ($curAutoCalc === 'exempt'): ?>
                                            <option value="exempt" selected>Exempt (legacy, no tax)</option>
                                        <?php endif; ?>
                                    </select>
                                </div>

                                <div id="emp-tab-tax-annual-wrap" class="space-y-1">
                                    <label class="block text-[10px] font-bold text-slate-700 dark:text-slate-300 mb-0.5">Annual Tax Amount (BDT)</label>
                                    <input type="number" min="0" step="0.01" id="emp-tab-tax-annual" name="tax_settings[annual_tax_amount]"
                                           value="<?= esc($curAnnualTax) ?>" placeholder="0.00" oninput="onEmployeeTabAnnualTaxInput()"
                                           class="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-mono">
                                    <p class="text-[10px] text-slate-500">
                                        Monthly deduction when Deactive: <span id="emp-tab-tax-monthly-preview" class="font-mono font-bold">0.00</span> BDT (annual ÷ 12).
                                        When Active, this amount is saved but not used.
                                    </p>
                                    <?php if ($curAnnualTaxYear !== ''): ?>
                                        <p class="text-[10px] text-slate-400">Amount set for fiscal year <?= esc($curAnnualTaxYear) ?>.</p>
                                    <?php endif; ?>
                                </div>

                                <div id="emp-tab-tax-reason-wrap" class="<?= $curAutoCalc === 'active' ? 'hidden' : '' ?>">
                                    <label class="block text-[10px] font-bold text-amber-900 dark:text-amber-300 mb-0.5">Reason (required when Deactive)*</label>
                                    <input type="text" id="emp-tab-tax-reason" name="tax_settings[override_reason]" value="<?= esc($curTaxReason) ?>"
                                           placeholder="Why is automatic tax calculation turned off?"
                                           class="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs">
                                </div>
                            </div>
                        </div>

                        <!-- Provident Fund (PF) Card -->
                        <?php
                        $rawEmpPfStatus = $employee['pf_status'] ?? (!empty($employee['is_pf_applicable']) ? 'Enrolled' : 'Not Enrolled');
                        $normalizedPfBadge = match($rawEmpPfStatus) {
                            'Enrolled'   => ['label' => 'Enrolled', 'class' => 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'],
                            'Exempt'     => ['label' => 'Exempt', 'class' => 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border-amber-200 dark:border-amber-800'],
                            'Ineligible' => ['label' => 'Ineligible', 'class' => 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border-rose-200 dark:border-rose-800'],
                            default      => ['label' => 'Not Enrolled', 'class' => 'bg-slate-100 text-slate-600 dark:bg-slate-700/60 dark:text-slate-300 border-slate-200 dark:border-slate-600']
                        };
                        $isPfCurrentlyEnrolled = (!empty($employee['is_pf_applicable']) && $rawEmpPfStatus === 'Enrolled') ? 1 : 0;
                        $menuVisService = $menuVis ?? new \App\Services\MenuVisibilityService();
                        $currentSessionUid = (string)(session()->get('user_id') ?? '');
                        $canViewPfTab = $menuVisService->isVisible($currentSessionUid, 'employees.provident_fund');
                        ?>
                        <div id="card-emp-tab-pf" class="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl p-4 space-y-3 flex flex-col justify-between">
                            <div class="space-y-2">
                                <div class="flex items-center justify-between">
                                    <span class="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                                        <i data-lucide="piggy-bank" class="w-3.5 h-3.5 text-indigo-600"></i>
                                        <span>Provident Fund (PF) Settings</span>
                                    </span>
                                    <span class="px-2 py-0.5 rounded-full text-[9px] font-bold font-mono bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 uppercase">
                                        Statutory Rule • PF
                                    </span>
                                </div>
                                <p class="text-[11px] text-slate-500 dark:text-slate-400">Employee enrolment and contribution rules governed by RuleResolver PF domain.</p>
                                <div class="pt-1 flex items-center gap-2">
                                    <span class="text-xs font-medium text-slate-500 dark:text-slate-400">Status:</span>
                                    <span class="px-2.5 py-0.5 rounded-full text-xs font-bold border <?= $normalizedPfBadge['class'] ?>">
                                        <?= esc($normalizedPfBadge['label']) ?>
                                    </span>
                                </div>
                                <input type="hidden" name="pf_settings[is_eligible]" value="<?= $isPfCurrentlyEnrolled ?>">
                                <input type="checkbox" id="assign-pf-eligible" class="hidden" disabled <?= $isPfCurrentlyEnrolled ? 'checked' : '' ?>>
                                <?php if ($canViewPfTab): ?>
                                    <div class="pt-1">
                                        <button type="button" @click="activeTab = 'provident_fund'" class="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 hover:text-indigo-700 dark:text-indigo-400 dark:hover:text-indigo-300">
                                            <i data-lucide="external-link" class="w-3.5 h-3.5"></i>
                                            <span>Change enrolment in Provident Fund tab</span>
                                        </button>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="text-[11px] text-slate-400 italic pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
                                Standard statutory deductions & employer match apply automatically based on Company PF rules.
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Template-Wise Interactive Component Cells Section -->
                <div class="pt-4 border-t border-slate-200 dark:border-slate-700 space-y-4">
                    <div class="flex flex-wrap items-center justify-between gap-3">
                        <div class="flex items-center gap-2">
                            <span class="w-2.5 h-2.5 rounded-full bg-indigo-500 animate-pulse"></span>
                            <h4 id="template-title-display" class="font-bold text-slate-900 dark:text-white text-xs uppercase tracking-wider">
                                Salary Structure Component Cells
                            </h4>
                            <span id="template-badge-display" class="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                                Template Driven
                            </span>
                        </div>

                        <div class="flex items-center gap-2">
                            <button type="button" 
                                    id="btn-reset-template-defaults" 
                                    class="px-2.5 py-1 text-xs font-medium text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 rounded-lg transition-colors flex items-center gap-1 cursor-pointer">
                                <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                Reset to Template Defaults
                            </button>
                            <button type="button" 
                                    id="btn-add-custom-cell" 
                                    class="px-2.5 py-1 text-xs font-medium text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950 hover:bg-indigo-100 rounded-lg transition-colors flex items-center gap-1 border border-indigo-200 dark:border-indigo-800 cursor-pointer">
                                <i data-lucide="plus" class="w-3 h-3"></i>
                                Add Custom Component Cell
                            </button>
                        </div>
                    </div>

                    <!-- Single Source of Truth Clarification Banner -->
                    <div class="p-3 bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-200/80 dark:border-indigo-900/60 rounded-xl text-xs text-indigo-900 dark:text-indigo-200 flex items-start gap-2.5">
                        <i data-lucide="shield-check" class="w-4 h-4 text-indigo-600 dark:text-indigo-400 mt-0.5 shrink-0"></i>
                        <div class="leading-relaxed">
                            <strong class="font-semibold text-slate-900 dark:text-white">Earnings, Deductions & Statutory Withholdings:</strong>
                            <span class="text-slate-600 dark:text-slate-300"> Complete breakdown of contractual earnings, custom deductions, and statutory withholdings (<strong class="text-indigo-700 dark:text-indigo-300">Income Tax TDS</strong> and <strong class="text-indigo-700 dark:text-indigo-300">Provident Fund</strong>). Statutory withholding rules are governed authoritatively by their dedicated policy cards above.</span>
                        </div>
                    </div>

                    <!-- Earnings & Allowances Cells Table -->
                    <div class="rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-2xs">
                        <div class="bg-indigo-50/70 dark:bg-indigo-950/40 px-4 py-2.5 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
                            <span class="text-xs font-bold text-indigo-900 dark:text-indigo-200 flex items-center gap-1.5">
                                <i data-lucide="plus-circle" class="w-3.5 h-3.5 text-indigo-600"></i>
                                Earnings & Allowances Breakdown (Cells)
                            </span>
                            <span class="text-[11px] text-slate-500 font-mono">
                                Subtotal: <strong id="earnings-subtotal-display" class="text-indigo-700 dark:text-indigo-300 font-bold"><?= format_money(0.00) ?></strong>
                            </span>
                        </div>
                        <div class="overflow-x-auto bg-white dark:bg-slate-900">
                            <table class="w-full text-left text-xs border-collapse" id="table-earnings-cells">
                                <thead>
                                    <tr class="bg-slate-50 dark:bg-slate-800/80 text-slate-500 font-semibold border-b border-slate-200 dark:border-slate-700">
                                        <th class="py-2.5 px-3 w-8 text-center">Inc.</th>
                                        <th class="py-2.5 px-3 min-w-[160px]">Salary Component</th>
                                        <th class="py-2.5 px-3 min-w-[130px]">Calculation Rule</th>
                                        <th class="py-2.5 px-3 w-32">Rate / %</th>
                                        <th class="py-2.5 px-3 w-44">Assigned Amount (<?= esc($currencyCode) ?>)</th>
                                        <th class="py-2.5 px-3 w-24 text-center">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="tbody-earnings-cells" class="divide-y divide-slate-100 dark:divide-slate-800">
                                    <!-- Dynamic rows injected by JavaScript -->
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Deductions Cells Table -->
                    <div class="rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-2xs">
                        <div class="bg-rose-50/70 dark:bg-rose-950/40 px-4 py-2.5 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
                            <span class="text-xs font-bold text-rose-900 dark:text-rose-200 flex items-center gap-1.5">
                                <i data-lucide="minus-circle" class="w-3.5 h-3.5 text-rose-600"></i>
                                Deductions & Statutory Withholdings (Cells)
                            </span>
                            <span class="text-[11px] text-slate-500 font-mono">
                                Subtotal: <strong id="deductions-subtotal-display" class="text-rose-600 font-bold">-<?= format_money(0.00) ?></strong>
                            </span>
                        </div>
                        <div class="overflow-x-auto bg-white dark:bg-slate-900">
                            <table class="w-full text-left text-xs border-collapse" id="table-deductions-cells">
                                <thead>
                                    <tr class="bg-slate-50 dark:bg-slate-800/80 text-slate-500 font-semibold border-b border-slate-200 dark:border-slate-700">
                                        <th class="py-2.5 px-3 w-8 text-center">Inc.</th>
                                        <th class="py-2.5 px-3 min-w-[160px]">Deduction Component</th>
                                        <th class="py-2.5 px-3 min-w-[130px]">Calculation Rule</th>
                                        <th class="py-2.5 px-3 w-32">Rate / %</th>
                                        <th class="py-2.5 px-3 w-44">Deduction Amount (<?= esc($currencyCode) ?>)</th>
                                        <th class="py-2.5 px-3 w-24 text-center">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="tbody-deductions-cells" class="divide-y divide-slate-100 dark:divide-slate-800">
                                    <!-- Dynamic rows injected by JavaScript -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Real-Time Calculated Metrics Summary Card -->
                <div class="p-4 rounded-xl bg-slate-900 text-white shadow-sm">
                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center divide-y sm:divide-y-0 sm:divide-x divide-slate-800">
                        <div class="px-2 py-1">
                            <span class="text-[11px] uppercase tracking-wider text-slate-400 font-semibold block">Basic Salary</span>
                            <span id="metric-basic-display" class="font-mono font-bold text-base text-white mt-0.5 block">
                                <?= format_money($basic) ?>
                            </span>
                        </div>
                        <div class="px-2 py-1">
                            <span class="text-[11px] uppercase tracking-wider text-indigo-300 font-semibold block">Gross Monthly Pay</span>
                            <span id="metric-gross-display" class="font-mono font-bold text-base text-indigo-400 mt-0.5 block">
                                <?= format_money($gross) ?>
                            </span>
                        </div>
                        <div class="px-2 py-1">
                            <span class="text-[11px] uppercase tracking-wider text-rose-300 font-semibold block">Total Deductions</span>
                            <span id="metric-deductions-display" class="font-mono font-bold text-base text-rose-400 mt-0.5 block">
                                -<?= format_money($totalDeductions) ?>
                            </span>
                        </div>
                        <div class="px-2 py-1">
                            <span class="text-[11px] uppercase tracking-wider text-emerald-300 font-semibold block">Net Take-Home Pay</span>
                            <span id="metric-net-display" class="font-mono font-bold text-base text-emerald-400 mt-0.5 block">
                                <?= format_money($netSalary) ?>
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Assignment Justification & Calculated Summary -->
                <div class="pt-3 border-t border-slate-100 dark:border-slate-700 flex flex-wrap items-center justify-between gap-4">
                    <div class="flex-1 min-w-[260px]">
                        <input type="text" 
                               name="notes" 
                               placeholder="Audit note / justification (e.g. Assigned from Structure Template with custom cells)" 
                               class="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                    </div>

                    <div class="flex items-center gap-3">
                        <button type="submit" 
                                id="btn-submit-salary" 
                                class="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-xs flex items-center gap-2 transition-colors cursor-pointer">
                            <i data-lucide="check-circle" class="w-4 h-4"></i>
                            <?= $isConfigured ? 'Save Salary Revision' : 'Assign & Activate Salary' ?>
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Add Custom Component Cell Modal -->
        <div id="modal-custom-cell" class="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 hidden">
            <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-5 w-full max-w-md shadow-xl space-y-4">
                <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                    <h4 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-1.5">
                        <i data-lucide="plus-circle" class="w-4 h-4 text-indigo-600"></i>
                        Add Salary Component Cell
                    </h4>
                    <button type="button" onclick="closeCustomCellModal()" class="text-slate-400 hover:text-slate-600 cursor-pointer">
                        <i data-lucide="x" class="w-4 h-4"></i>
                    </button>
                </div>

                <div class="space-y-3 text-xs">
                    <div>
                        <label class="block font-medium text-slate-700 dark:text-slate-300 mb-1">Select from Company Master or Create Custom</label>
                        <select id="modal-component-select" onchange="handleModalComponentSelect(this)" class="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                            <option value="CUSTOM">-- New Custom Component --</option>
                            <?php if (!empty($companyComponents)): ?>
                                <?php foreach ($companyComponents as $cc): ?>
                                    <?php 
                                    $ccActive = (($cc['status'] ?? 'Active') === 'Active') && (!isset($cc['is_active']) || (int)$cc['is_active'] === 1);
                                    if (!$ccActive) continue;
                                    $cCode = strtoupper(trim((string)($cc['code'] ?? '')));
                                    $cName = strtolower(trim((string)($cc['name'] ?? '')));
                                    if (in_array($cCode, ['TDS', 'TAX', 'PF', 'EMP_PF', 'ER_PF', 'OT'], true)) continue;
                                    if (strpos($cName, 'income tax') !== false || strpos($cName, 'provident fund') !== false || strpos($cName, 'overtime') !== false) continue;
                                    ?>
                                    <option value="<?= esc($cc['id']) ?>" 
                                            data-name="<?= esc($cc['name']) ?>" 
                                            data-code="<?= esc($cc['code']) ?>" 
                                            data-type="<?= esc($cc['type'] ?? 'earning') ?>" 
                                            data-calctype="<?= esc($cc['calculation_type'] ?? 'fixed') ?>" 
                                            data-calcbase="<?= esc($cc['calculation_base'] ?? 'Basic Salary') ?>" 
                                            data-rate="<?= esc($cc['percentage'] ?? $cc['amount'] ?? 0) ?>">
                                        <?= esc($cc['name']) ?> [<?= esc($cc['code']) ?>] (<?= ucfirst(esc($cc['type'] ?? 'earning')) ?>)
                                    </option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-medium text-slate-700 dark:text-slate-300 mb-1">Component Name</label>
                            <input type="text" id="modal-comp-name" placeholder="e.g. Special Allowance" class="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                        </div>
                        <div>
                            <label class="block font-medium text-slate-700 dark:text-slate-300 mb-1">Code</label>
                            <input type="text" id="modal-comp-code" placeholder="e.g. SPEC_ALW" class="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white uppercase font-mono">
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-medium text-slate-700 dark:text-slate-300 mb-1">Type</label>
                            <select id="modal-comp-type" class="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                                <option value="earning">Earning / Allowance</option>
                                <option value="deduction">Deduction</option>
                            </select>
                        </div>
                        <div>
                            <label class="block font-medium text-slate-700 dark:text-slate-300 mb-1">Calculation Type</label>
                            <select id="modal-comp-calctype" class="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                                <option value="fixed">Fixed Dollar Amount</option>
                                <option value="percentage">% of Basic Salary</option>
                                <option value="percent_gross">% of Gross Salary</option>
                            </select>
                        </div>
                    </div>

                    <div>
                        <label class="block font-medium text-slate-700 dark:text-slate-300 mb-1">Rate or Amount</label>
                        <input type="number" step="0.01" id="modal-comp-rate" placeholder="e.g. 500.00 or 10 for 10%" class="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono">
                    </div>
                </div>

                <div class="pt-3 border-t border-slate-100 dark:border-slate-700 flex justify-end gap-2">
                    <button type="button" onclick="closeCustomCellModal()" class="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer">Cancel</button>
                    <button type="button" onclick="confirmAddCustomCell()" class="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold cursor-pointer">Add Component Cell</button>
                </div>
            </div>
        </div>

        <script>
        // Data injected from backend controller
        window.SALARY_STRUCTURES = <?= json_encode($salaryStructures ?? [], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>;
        window.ACTIVE_SALARY = <?= json_encode($activeSalary ?? null, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>;
        window.COMPANY_COMPONENTS = <?= json_encode($companyComponents ?? [], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>;

        // In-memory working components state
        var currentComponentCells = [];

        // Helper: format currency
        function fmtCur(val) {
            var num = parseFloat(val) || 0;
            return '<?= esc($currencyCode) ?> ' + num.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        }

        // Standard default items when no template is selected or structure has no items
        function getStandardDefaultComponents() {
            return [
                {
                    component_id: 'comp-basic',
                    code: 'BASIC',
                    name: 'Basic Salary',
                    type: 'earning',
                    calculation_type: 'fixed',
                    calculation_base: 'Basic Salary',
                    rate_or_amount: 0,
                    amount: 0,
                    is_enabled: true,
                    is_included_in_gross: true,
                    is_overridden: false,
                    is_taxable: true,
                    is_pf_applicable: true
                },
                {
                    component_id: 'comp-hra',
                    code: 'HRA',
                    name: 'House Rent Allowance',
                    type: 'earning',
                    calculation_type: 'percentage',
                    calculation_base: 'Basic Salary',
                    rate_or_amount: 50,
                    amount: 0,
                    is_enabled: true,
                    is_included_in_gross: true,
                    is_overridden: false,
                    is_taxable: true,
                    is_pf_applicable: false
                },
                {
                    component_id: 'comp-med',
                    code: 'MED',
                    name: 'Medical Allowance',
                    type: 'earning',
                    calculation_type: 'fixed',
                    calculation_base: 'Basic Salary',
                    rate_or_amount: 0,
                    amount: 0,
                    is_enabled: true,
                    is_included_in_gross: true,
                    is_overridden: false,
                    is_taxable: true,
                    is_pf_applicable: false
                },
                {
                    component_id: 'comp-conv',
                    code: 'CONV',
                    name: 'Conveyance Allowance',
                    type: 'earning',
                    calculation_type: 'fixed',
                    calculation_base: 'Basic Salary',
                    rate_or_amount: 0,
                    amount: 0,
                    is_enabled: true,
                    is_included_in_gross: true,
                    is_overridden: false,
                    is_taxable: true,
                    is_pf_applicable: false
                }
            ];
        }

        // Initialize component cells from a template structure
        function loadStructureTemplateCells(structureId, resetOverrides) {
            var struct = null;
            if (structureId && window.SALARY_STRUCTURES) {
                struct = window.SALARY_STRUCTURES.find(function(s) { return String(s.id) === String(structureId); });
            }

            var newCells = [];
            var titleElem = document.getElementById('template-title-display');
            var badgeElem = document.getElementById('template-badge-display');

            if (struct) {
                titleElem.innerText = struct.name + ' — Component Cells';
                badgeElem.innerText = 'Template: ' + (struct.name || 'Assigned');
                badgeElem.className = 'px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800';

                var rawItems = struct.items || [];
                var items = rawItems.filter(function(it) {
                    var c = (it.component_code || it.code || '').toUpperCase();
                    var n = (it.component_name || it.name || '').toLowerCase();
                    if (c === 'OT' || c.indexOf('OVERTIME') !== -1 || n.indexOf('overtime') !== -1) return false;
                    return true;
                });
                if (items.length > 0) {
                    items.forEach(function(it) {
                        var cType = (it.type || 'earning').toLowerCase();
                        var calcType = (it.calculation_type || 'fixed').toLowerCase();
                        var calcBase = it.calculation_base || 'Basic Salary';
                        var rate = parseFloat(it.default_value !== undefined ? it.default_value : (it.percentage || 0)) || 0;

                        newCells.push({
                            component_id: it.component_id || ('comp-' + (it.component_code || Math.random())),
                            code: it.component_code || it.code || '',
                            name: it.component_name || it.name || 'Component',
                            type: cType,
                            calculation_type: calcType,
                            calculation_base: calcBase,
                            rate_or_amount: rate,
                            amount: 0,
                            custom_formula: it.custom_formula || null,
                            is_enabled: it.is_enabled !== undefined ? (it.is_enabled == 1 || it.is_enabled === true) : true,
                            is_included_in_gross: it.is_included_in_gross !== undefined ? (it.is_included_in_gross == 1 || it.is_included_in_gross === true) : (cType === 'earning'),
                            is_overridden: false,
                            is_taxable: it.is_taxable == 1 || it.is_taxable === true,
                            is_pf_applicable: it.is_pf_applicable == 1 || it.is_pf_applicable === true,
                            is_statutory: false
                        });
                    });
                } else {
                    // Fallback to default template components if template has no explicit items
                    newCells = getStandardDefaultComponents();
                }
            } else {
                titleElem.innerText = 'Custom Allowance & Deduction Cells';
                badgeElem.innerText = 'Custom Policy';
                badgeElem.className = 'px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-600';
                newCells = getStandardDefaultComponents();
            }

            // Always ensure Basic Salary exists as an earning item
            var hasBasic = newCells.some(function(c) { return c.code === 'BASIC' || c.name.toLowerCase().indexOf('basic') !== -1; });
            if (!hasBasic) {
                newCells.unshift({
                    component_id: 'comp-basic',
                    code: 'BASIC',
                    name: 'Basic Salary',
                    type: 'earning',
                    calculation_type: 'fixed',
                    calculation_base: 'Basic Salary',
                    rate_or_amount: 0,
                    amount: 0,
                    is_enabled: true,
                    is_included_in_gross: true,
                    is_overridden: false,
                    is_taxable: true,
                    is_pf_applicable: true
                });
            }

            ensureStatutoryCellsInList(newCells);
            currentComponentCells = newCells;
            recalculateAllCells();
            renderComponentCellsUI();
        }

        // Ensure statutory PF and TDS components are present or removed according to policy cards
        function ensureStatutoryCellsInList(cells) {
            var pfChk = document.getElementById('assign-pf-eligible');
            var isPfElig = pfChk ? pfChk.checked : <?= (!isset($employee['is_pf_applicable']) || (int)$employee['is_pf_applicable'] === 1) ? 'true' : 'false' ?>;
            var autoSel = document.getElementById('emp-tab-tax-auto');
            var autoVal = autoSel ? autoSel.value : '<?= esc($curAutoCalc) ?>';
            var curMode = (autoVal === 'active') ? 'Auto' : (autoVal === 'exempt' ? 'Exempt' : 'Fixed');
            var annualInp = document.getElementById('emp-tab-tax-annual');
            var customTaxVal = annualInp ? Math.round(((parseFloat(annualInp.value) || 0) / 12) * 100) / 100
                                         : <?= round(((float)($curAnnualTax === '' ? 0 : $curAnnualTax)) / 12, 2) ?>;

            var hasPf = cells.some(function(c) {
                var code = (c.code || '').toUpperCase();
                var name = (c.name || '').toLowerCase();
                return c.type === 'deduction' && (code === 'PF' || code === 'EMP_PF' || name.indexOf('provident fund') !== -1);
            });

            if (isPfElig && !hasPf) {
                cells.push({
                    component_id: 'comp-pf',
                    code: 'EMP_PF',
                    name: 'Provident Fund (Employee)',
                    type: 'deduction',
                    calculation_type: 'percentage',
                    calculation_base: 'Basic Salary',
                    rate_or_amount: 7,
                    amount: 0,
                    is_enabled: true,
                    is_included_in_gross: false,
                    is_overridden: false,
                    is_taxable: false,
                    is_pf_applicable: false,
                    is_statutory: true
                });
            } else if (!isPfElig && hasPf) {
                for (var i = cells.length - 1; i >= 0; i--) {
                    var code = (cells[i].code || '').toUpperCase();
                    var name = (cells[i].name || '').toLowerCase();
                    if (cells[i].type === 'deduction' && (code === 'PF' || code === 'EMP_PF' || name.indexOf('provident fund') !== -1)) {
                        cells.splice(i, 1);
                    }
                }
            }

            var hasTax = cells.some(function(c) {
                var code = (c.code || '').toUpperCase();
                var name = (c.name || '').toLowerCase();
                return c.type === 'deduction' && (code === 'TDS' || code === 'TAX' || name.indexOf('income tax') !== -1);
            });

            if (curMode !== 'Exempt' && !hasTax) {
                cells.push({
                    component_id: 'comp-tax',
                    code: 'TDS',
                    name: 'Income Tax (TDS Withholding)',
                    type: 'deduction',
                    calculation_type: curMode === 'Fixed' ? 'fixed' : 'slab',
                    calculation_base: 'Gross Salary',
                    rate_or_amount: customTaxVal,
                    amount: 0,
                    is_enabled: true,
                    is_included_in_gross: false,
                    is_overridden: false,
                    is_taxable: false,
                    is_pf_applicable: false,
                    is_statutory: true
                });
            } else if (curMode === 'Exempt' && hasTax) {
                for (var j = cells.length - 1; j >= 0; j--) {
                    var code = (cells[j].code || '').toUpperCase();
                    var name = (cells[j].name || '').toLowerCase();
                    if (cells[j].type === 'deduction' && (code === 'TDS' || code === 'TAX' || name.indexOf('income tax') !== -1)) {
                        cells.splice(j, 1);
                    }
                }
            } else if (hasTax) {
                cells.forEach(function(c) {
                    var code = (c.code || '').toUpperCase();
                    var name = (c.name || '').toLowerCase();
                    if (c.type === 'deduction' && (code === 'TDS' || code === 'TAX' || name.indexOf('income tax') !== -1)) {
                        c.calculation_type = curMode === 'Fixed' ? 'fixed' : 'slab';
                        c.rate_or_amount = customTaxVal;
                    }
                });
            }
        }

        function syncStatutoryDeductionsToCells() {
            ensureStatutoryCellsInList(currentComponentCells);
            recalculateAllCells();
            renderComponentCellsUI();
        }

        // Live calculation engine for all component cells
        function recalculateAllCells() {
            var basicInput = document.getElementById('assign-basic-salary');
            var basicSalary = parseFloat(basicInput ? basicInput.value : 0) || 0;

            // Step 1: calculate earnings & Gross
            var runningGross = 0;
            var earningsSubtotal = 0;

            currentComponentCells.forEach(function(c) {
                if (c.type !== 'earning') return;

                if (c.code === 'BASIC' || c.name.toLowerCase() === 'basic salary') {
                    c.amount = basicSalary;
                    c.rate_or_amount = basicSalary;
                } else {
                    var calcType = (c.calculation_type || 'fixed').toLowerCase();
                    if (!c.is_overridden) {
                        if (calcType === 'fixed') {
                            c.amount = parseFloat(c.rate_or_amount) || 0;
                        } else if (calcType === 'percentage' || calcType === 'percent_basic') {
                            var pct = parseFloat(c.rate_or_amount) || 0;
                            if (pct <= 1.0 && pct > 0) { pct = pct * 100; }
                            c.amount = Math.round(basicSalary * (pct / 100) * 100) / 100;
                        }
                    }
                }

                if (c.is_enabled) {
                    earningsSubtotal += (parseFloat(c.amount) || 0);
                    if (c.is_included_in_gross !== false) {
                        runningGross += (parseFloat(c.amount) || 0);
                    }
                }
            });

            // Step 2: calculate deductions
            var totalDeductions = 0;
            currentComponentCells.forEach(function(c) {
                if (c.type !== 'deduction') return;

                var calcType = (c.calculation_type || 'fixed').toLowerCase();
                var calcBase = (c.calculation_base || 'Basic Salary');
                var codeUpper = (c.code || '').toUpperCase();
                var nameLower = (c.name || '').toLowerCase();
                var isTds = codeUpper === 'TAX' || codeUpper === 'TDS' || nameLower.indexOf('income tax') !== -1;
                var isPf = codeUpper === 'PF' || codeUpper === 'EMP_PF' || nameLower.indexOf('provident fund') !== -1;

                if (!c.is_overridden) {
                    if (isPf) {
                        var pfRate = parseFloat(c.rate_or_amount) || 0;
                        c.amount = Math.round(basicSalary * (pfRate / 100) * 100) / 100;
                    } else if (isTds) {
                        if (calcType === 'fixed') {
                            c.amount = parseFloat(c.rate_or_amount) || 0;
                        } else {
                            c.amount = parseFloat(c.amount ?? c.rate_or_amount) || 0;
                        }
                    } else if (calcType === 'fixed') {
                        c.amount = parseFloat(c.rate_or_amount) || 0;
                    } else if (calcType === 'percentage' || calcType === 'percent_basic' || calcType === 'percent_gross') {
                        var baseVal = (calcType === 'percent_gross' || calcBase === 'Gross Salary') ? runningGross : basicSalary;
                        var pct = parseFloat(c.rate_or_amount) || 0;
                        if (pct <= 1.0 && pct > 0) { pct = pct * 100; }
                        c.amount = Math.round(baseVal * (pct / 100) * 100) / 100;
                    }
                }

                if (c.is_enabled) {
                    totalDeductions += (parseFloat(c.amount) || 0);
                }
            });

            var netSalary = Math.max(0, runningGross - totalDeductions);

            // Update UI metric cards
            var mBasic = document.getElementById('metric-basic-display');
            var mGross = document.getElementById('metric-gross-display');
            var mDeductions = document.getElementById('metric-deductions-display');
            var mNet = document.getElementById('metric-net-display');
            var eSubtotal = document.getElementById('earnings-subtotal-display');
            var dSubtotal = document.getElementById('deductions-subtotal-display');

            if (mBasic) mBasic.innerText = fmtCur(basicSalary);
            if (mGross) mGross.innerText = fmtCur(runningGross);
            if (mDeductions) mDeductions.innerText = '-' + fmtCur(totalDeductions);
            if (mNet) mNet.innerText = fmtCur(netSalary);
            if (eSubtotal) eSubtotal.innerText = fmtCur(earningsSubtotal);
            if (dSubtotal) dSubtotal.innerText = '-' + fmtCur(totalDeductions);

            // Populate legacy hidden fields
            var legacyHra = 0, legacyMed = 0, legacyConv = 0, legacyOther = 0;
            currentComponentCells.forEach(function(c) {
                if (c.type !== 'earning') return;
                var code = (c.code || '').toUpperCase();
                var name = (c.name || '').toLowerCase();
                var amt = parseFloat(c.amount) || 0;
                if (code === 'HRA' || name.indexOf('house rent') !== -1) {
                    legacyHra += amt;
                } else if (code === 'MED' || name.indexOf('medical') !== -1) {
                    legacyMed += amt;
                } else if (code === 'CONV' || name.indexOf('conveyance') !== -1 || name.indexOf('transport') !== -1) {
                    legacyConv += amt;
                } else if (code !== 'BASIC' && name.indexOf('basic') === -1) {
                    legacyOther += amt;
                }
            });

            var legH = document.getElementById('legacy-house-rent');
            var legM = document.getElementById('legacy-medical');
            var legC = document.getElementById('legacy-conveyance');
            var legO = document.getElementById('legacy-other');
            if (legH) legH.value = legacyHra.toFixed(2);
            if (legM) legM.value = legacyMed.toFixed(2);
            if (legC) legC.value = legacyConv.toFixed(2);
            if (legO) legO.value = legacyOther.toFixed(2);

            // Serialize components state into JSON hidden input
            var jsonInput = document.getElementById('assign-components-json');
            if (jsonInput) {
                jsonInput.value = JSON.stringify(currentComponentCells);
            }
        }

        // Render dynamic table rows for both Earnings and Deductions
        function renderComponentCellsUI() {
            var tbodyEarnings = document.getElementById('tbody-earnings-cells');
            var tbodyDeductions = document.getElementById('tbody-deductions-cells');

            if (!tbodyEarnings || !tbodyDeductions) return;

            tbodyEarnings.innerHTML = '';
            tbodyDeductions.innerHTML = '';

            currentComponentCells.forEach(function(cell, idx) {
                var isEarning = cell.type === 'earning';
                var targetTbody = isEarning ? tbodyEarnings : tbodyDeductions;
                var isBasic = cell.code === 'BASIC' || cell.name.toLowerCase() === 'basic salary';

                var codeUpper = (cell.code || '').toUpperCase();
                var nameLower = (cell.name || '').toLowerCase();
                var cidStr = String(cell.component_id || cell.id || '');

                var tr = document.createElement('tr');
                tr.className = 'hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition-colors border-b border-slate-100 dark:border-slate-800';

                // Column 1: Checkbox Include/Enable
                var tdCheck = document.createElement('td');
                tdCheck.className = 'py-2.5 px-3 text-center';
                if (isBasic) {
                    tdCheck.innerHTML = '<input type="checkbox" checked disabled class="rounded text-indigo-600 cursor-not-allowed opacity-70">';
                } else {
                    var chk = document.createElement('input');
                    chk.type = 'checkbox';
                    chk.checked = cell.is_enabled;
                    chk.className = 'rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer';
                    chk.onchange = function() {
                        cell.is_enabled = this.checked;
                        recalculateAllCells();
                        updateCellRowVisuals(tr, cell);
                    };
                    tdCheck.appendChild(chk);
                }
                tr.appendChild(tdCheck);

                // Column 2: Component Name & Badges
                var tdName = document.createElement('td');
                tdName.className = 'py-2.5 px-3 font-medium text-slate-800 dark:text-slate-200';
                var nameHtml = '<div class="flex items-center gap-1.5">';
                nameHtml += '<span class="font-semibold">' + (cell.name || 'Component') + '</span>';
                if (cell.code) {
                    nameHtml += '<span class="text-[10px] font-mono text-slate-400 bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded">[' + cell.code + ']</span>';
                }
                if (cell.is_taxable) {
                    nameHtml += '<span class="text-[9px] text-emerald-600 dark:text-emerald-400 font-semibold">Taxable</span>';
                }
                if (cell.is_statutory) {
                    nameHtml += '<span class="text-[9px] text-amber-600 dark:text-amber-400 font-semibold">Statutory</span>';
                }
                nameHtml += '</div>';
                tdName.innerHTML = nameHtml;
                tr.appendChild(tdName);

                // Column 3: Rule description
                var tdRule = document.createElement('td');
                tdRule.className = 'py-2.5 px-3 text-slate-500 text-[11px]';
                var isTds = (cell.code || '').toUpperCase() === 'TAX' || (cell.code || '').toUpperCase() === 'TDS' || (cell.name || '').toLowerCase().indexOf('income tax') !== -1;
                var isPf = (cell.code || '').toUpperCase() === 'PF' || (cell.code || '').toUpperCase() === 'EMP_PF' || (cell.name || '').toLowerCase().indexOf('provident fund') !== -1;

                var ruleText = 'Fixed Dollar';
                if (isBasic) {
                    ruleText = 'Base Amount';
                } else if (isTds) {
                    ruleText = 'Statutory Slabs (Domain TAX)';
                } else if (isPf) {
                    ruleText = 'Statutory Rate (Domain PF)';
                } else if (cell.calculation_type === 'percentage' || cell.calculation_type === 'percent_basic') {
                    ruleText = '% of Basic Salary';
                } else if (cell.calculation_type === 'percent_gross') {
                    ruleText = '% of Gross Salary';
                } else if (cell.calculation_type === 'formula') {
                    ruleText = 'Formula: ' + (cell.custom_formula || 'Custom');
                }
                tdRule.innerText = ruleText;
                tr.appendChild(tdRule);

                // Column 4: Rate / % Cell
                var tdRate = document.createElement('td');
                tdRate.className = 'py-2.5 px-3';
                if (isBasic) {
                    tdRate.innerHTML = '<span class="text-slate-400 font-mono text-[11px]">100.00%</span>';
                } else if (isTds) {
                    tdRate.innerHTML = '<span class="text-indigo-600 dark:text-indigo-400 font-medium text-[11px]">Tax Slices</span>';
                } else if (isPf) {
                    tdRate.innerHTML = '<span class="text-indigo-600 dark:text-indigo-400 font-medium text-[11px]">Policy Rate</span>';
                } else if (cell.calculation_type === 'percentage' || cell.calculation_type === 'percent_basic' || cell.calculation_type === 'percent_gross') {
                    var rateInput = document.createElement('input');
                    rateInput.type = 'number';
                    rateInput.step = '0.01';
                    rateInput.min = '0';
                    rateInput.value = cell.rate_or_amount;
                    rateInput.className = 'w-24 px-2 py-1 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono text-xs focus:ring-1 focus:ring-indigo-500';
                    rateInput.oninput = function() {
                        cell.rate_or_amount = parseFloat(this.value) || 0;
                        cell.is_overridden = false; // Rate change re-enables formula
                        recalculateAllCells();
                        // Update amount input box in this row
                        var amtBox = tr.querySelector('.cell-amount-input');
                        if (amtBox) amtBox.value = (parseFloat(cell.amount) || 0).toFixed(2);
                        var badge = tr.querySelector('.override-badge');
                        if (badge) badge.style.display = 'none';
                    };
                    var rWrap = document.createElement('div');
                    rWrap.className = 'flex items-center gap-1';
                    rWrap.appendChild(rateInput);
                    rWrap.insertAdjacentHTML('beforeend', '<span class="text-slate-400 font-bold text-xs">%</span>');
                    tdRate.appendChild(rWrap);
                } else {
                    tdRate.innerHTML = '<span class="text-slate-400 font-mono text-[11px]">Fixed</span>';
                }
                tr.appendChild(tdRate);

                // Column 5: Calculated / Overridden Amount (<?= esc($currencyCode) ?>) Cell
                var tdAmount = document.createElement('td');
                tdAmount.className = 'py-2.5 px-3';
                var amtWrap = document.createElement('div');
                amtWrap.className = 'relative flex items-center';

                var amtInput = document.createElement('input');
                amtInput.type = 'number';
                amtInput.step = '0.01';
                amtInput.min = '0';
                amtInput.value = (parseFloat(cell.amount) || 0).toFixed(2);
                amtInput.className = 'cell-amount-input w-36 pl-11 pr-2 py-1 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono font-bold text-xs focus:ring-2 focus:ring-indigo-500';
                
                if (isBasic || isTds || isPf) {
                    amtInput.readOnly = true;
                    amtInput.className += ' bg-slate-50 dark:bg-slate-800 text-slate-500 cursor-not-allowed';
                    if (isTds) amtInput.title = 'Statutory deduction governed by Tax Card above';
                    if (isPf) amtInput.title = 'Statutory deduction governed by PF Card above';
                } else {
                    amtInput.oninput = function() {
                        cell.amount = parseFloat(this.value) || 0;
                        cell.is_overridden = true;
                        recalculateAllCells();
                        var badge = tr.querySelector('.override-badge');
                        if (badge) badge.style.display = 'inline-block';
                    };
                }

                amtWrap.insertAdjacentHTML('afterbegin', '<span class="absolute left-2 text-slate-400 font-mono text-xs"><?= esc($currencyCode) ?></span>');
                amtWrap.appendChild(amtInput);

                // Overridden indicator pill
                var overrideBadge = document.createElement('span');
                overrideBadge.className = 'override-badge ml-1.5 px-1.5 py-0.5 rounded text-[9px] font-semibold bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200 border border-amber-300 dark:border-amber-700';
                overrideBadge.innerText = 'Custom';
                overrideBadge.style.display = cell.is_overridden ? 'inline-block' : 'none';
                amtWrap.appendChild(overrideBadge);

                tdAmount.appendChild(amtWrap);
                tr.appendChild(tdAmount);

                // Column 6: Actions (Reset / Remove)
                var tdActions = document.createElement('td');
                tdActions.className = 'py-2.5 px-3 text-center';
                if (!isBasic) {
                    if (isTds) {
                        tdActions.innerHTML = '<button type="button" onclick="document.getElementById(\'card-emp-tab-tax\').scrollIntoView({behavior:\'smooth\'})" class="text-[10px] text-indigo-600 dark:text-indigo-400 font-semibold hover:underline cursor-pointer">Tax Card ↑</button>';
                    } else if (isPf) {
                        tdActions.innerHTML = '<button type="button" onclick="document.getElementById(\'card-emp-tab-pf\').scrollIntoView({behavior:\'smooth\'})" class="text-[10px] text-indigo-600 dark:text-indigo-400 font-semibold hover:underline cursor-pointer">PF Card ↑</button>';
                    } else {
                        var actWrap = document.createElement('div');
                        actWrap.className = 'flex items-center justify-center gap-1.5';

                        // Reset button
                        var btnReset = document.createElement('button');
                        btnReset.type = 'button';
                        btnReset.title = 'Reset cell to standard template rule';
                        btnReset.className = 'p-1 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded transition-colors cursor-pointer';
                        btnReset.innerHTML = '<svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>';
                        btnReset.onclick = function() {
                            cell.is_overridden = false;
                            recalculateAllCells();
                            amtInput.value = (parseFloat(cell.amount) || 0).toFixed(2);
                            overrideBadge.style.display = 'none';
                        };
                        actWrap.appendChild(btnReset);

                        // Delete button (if custom cell)
                        if (cell.is_custom_added) {
                            var btnDel = document.createElement('button');
                            btnDel.type = 'button';
                            btnDel.title = 'Remove custom cell';
                            btnDel.className = 'p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors cursor-pointer';
                            btnDel.innerHTML = '<svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>';
                            btnDel.onclick = function() {
                                var pos = currentComponentCells.indexOf(cell);
                                if (pos > -1) {
                                    currentComponentCells.splice(pos, 1);
                                    recalculateAllCells();
                                    renderComponentCellsUI();
                                }
                            };
                            actWrap.appendChild(btnDel);
                        }

                        tdActions.appendChild(actWrap);
                    }
                }
                tr.appendChild(tdActions);

                updateCellRowVisuals(tr, cell);
                targetTbody.appendChild(tr);
            });

            if (tbodyDeductions.children.length === 0) {
                tbodyDeductions.innerHTML = '<tr><td colspan="6" class="py-5 text-center text-slate-400 dark:text-slate-500 text-xs italic">No contractual deductions or statutory withholdings assigned.</td></tr>';
            }
            if (tbodyEarnings.children.length === 0) {
                tbodyEarnings.innerHTML = '<tr><td colspan="6" class="py-5 text-center text-slate-400 dark:text-slate-500 text-xs italic">No contractual allowances assigned. Click "Add Custom Component Cell" above to add allowances.</td></tr>';
            }

            // Re-render lucide icons if available
            if (window.lucide && typeof window.lucide.createIcons === 'function') {
                window.lucide.createIcons();
            }
        }

        // Visual helper for row disabled/enabled styling
        function updateCellRowVisuals(tr, cell) {
            if (!cell.is_enabled) {
                tr.classList.add('opacity-40');
            } else {
                tr.classList.remove('opacity-40');
            }
        }

        // Modal: Add Custom Component Cell
        function openCustomCellModal() {
            var modal = document.getElementById('modal-custom-cell');
            if (modal) modal.classList.remove('hidden');
        }

        function closeCustomCellModal() {
            var modal = document.getElementById('modal-custom-cell');
            if (modal) modal.classList.add('hidden');
        }

        function toggleEmployeeTabTaxOverride(val) {
            var reasonWrap = document.getElementById('emp-tab-tax-reason-wrap');
            if (reasonWrap) reasonWrap.classList.toggle('hidden', val === 'active');
            onEmployeeTabAnnualTaxInput();
        }

        function onEmployeeTabAnnualTaxInput() {
            var inp = document.getElementById('emp-tab-tax-annual');
            var prev = document.getElementById('emp-tab-tax-monthly-preview');
            var annual = inp ? (parseFloat(inp.value) || 0) : 0;
            if (prev) prev.textContent = (Math.round(annual / 12 * 100) / 100).toFixed(2);
            if (typeof syncStatutoryDeductionsToCells === 'function') syncStatutoryDeductionsToCells();
        }

        function handleModalComponentSelect(sel) {
            var opt = sel.options[sel.selectedIndex];
            if (sel.value === 'CUSTOM') {
                document.getElementById('modal-comp-name').value = '';
                document.getElementById('modal-comp-code').value = '';
                document.getElementById('modal-comp-type').value = 'earning';
                document.getElementById('modal-comp-calctype').value = 'fixed';
                document.getElementById('modal-comp-rate').value = '';
            } else {
                document.getElementById('modal-comp-name').value = opt.getAttribute('data-name') || '';
                document.getElementById('modal-comp-code').value = opt.getAttribute('data-code') || '';
                document.getElementById('modal-comp-type').value = opt.getAttribute('data-type') || 'earning';
                document.getElementById('modal-comp-calctype').value = opt.getAttribute('data-calctype') || 'fixed';
                document.getElementById('modal-comp-rate').value = opt.getAttribute('data-rate') || 0;
            }
        }

        function confirmAddCustomCell() {
            var name = (document.getElementById('modal-comp-name').value || '').trim();
            var code = (document.getElementById('modal-comp-code').value || '').trim().toUpperCase();
            var type = document.getElementById('modal-comp-type').value || 'earning';
            var calcType = document.getElementById('modal-comp-calctype').value || 'fixed';
            var rate = parseFloat(document.getElementById('modal-comp-rate').value) || 0;

            if (!name) {
                alert('Please enter a component name.');
                return;
            }

            if (!code) {
                code = name.replace(/[^a-zA-Z0-9]/g, '_').toUpperCase().substring(0, 10);
            }

            currentComponentCells.push({
                component_id: 'custom-' + Date.now(),
                code: code,
                name: name,
                type: type,
                calculation_type: calcType,
                calculation_base: calcType === 'percent_gross' ? 'Gross Salary' : 'Basic Salary',
                rate_or_amount: rate,
                amount: 0,
                is_enabled: true,
                is_included_in_gross: type === 'earning',
                is_overridden: false,
                is_custom_added: true,
                is_taxable: true,
                is_statutory: false
            });

            closeCustomCellModal();
            recalculateAllCells();
            renderComponentCellsUI();
        }

        // DOM Initialization
        document.addEventListener('DOMContentLoaded', function() {
            var basicInput = document.getElementById('assign-basic-salary');
            var structSelect = document.getElementById('assign-structure-id');
            var btnReset = document.getElementById('btn-reset-template-defaults');
            var btnAddCell = document.getElementById('btn-add-custom-cell');

            // Basic salary input listener
            if (basicInput) {
                basicInput.addEventListener('input', function() {
                    recalculateAllCells();
                    // Update the Basic row amount in the UI
                    var basicRowAmt = document.querySelector('#table-earnings-cells tr .cell-amount-input');
                    if (basicRowAmt) basicRowAmt.value = (parseFloat(this.value) || 0).toFixed(2);
                });
            }

            // Structure dropdown change listener
            if (structSelect) {
                structSelect.addEventListener('change', function() {
                    loadStructureTemplateCells(this.value, true);
                });
            }

            // Reset template defaults button
            if (btnReset) {
                btnReset.addEventListener('click', function() {
                    var currentStructId = structSelect ? structSelect.value : '';
                    loadStructureTemplateCells(currentStructId, true);
                });
            }

            // Add custom cell button
            if (btnAddCell) {
                btnAddCell.addEventListener('click', function() {
                    openCustomCellModal();
                });
            }

            // Initial load from Active Salary or selected structure
            var active = window.ACTIVE_SALARY;
            var activeItems = [];
            if (active && (active.earnings || active.deductions)) {
                if (active.earnings && active.earnings.length > 0) {
                    activeItems = activeItems.concat(active.earnings);
                }
                if (active.deductions && active.deductions.length > 0) {
                    activeItems = activeItems.concat(active.deductions);
                }
                activeItems = activeItems.filter(function(it) {
                    var c = (it.code || it.component_code || '').toUpperCase();
                    var n = (it.name || '').toLowerCase();
                    if (c === 'OT' || c.indexOf('OVERTIME') !== -1 || n.indexOf('overtime') !== -1) return false;
                    return true;
                });
            }

            if (activeItems.length > 0) {
                // Initialize with active saved components
                currentComponentCells = activeItems.map(function(it) {
                    var codeUpper = (it.code || it.component_code || '').toUpperCase();
                    var nameLower = (it.name || '').toLowerCase();
                    var isStat = it.is_statutory || codeUpper === 'PF' || codeUpper === 'EMP_PF' || codeUpper === 'TDS' || codeUpper === 'TAX' || nameLower.indexOf('provident') !== -1 || nameLower.indexOf('income tax') !== -1;
                    return {
                        component_id: it.component_id || it.id,
                        code: it.code || '',
                        name: it.name || 'Component',
                        type: it.type || 'earning',
                        calculation_type: it.calculation_type || 'fixed',
                        calculation_base: it.calculation_base || 'Basic Salary',
                        rate_or_amount: parseFloat(it.rate_or_amount) || 0,
                        amount: parseFloat(it.amount) || 0,
                        custom_formula: it.custom_formula || null,
                        is_enabled: it.is_enabled !== undefined ? (it.is_enabled == 1 || it.is_enabled === true) : true,
                        is_included_in_gross: it.is_included_in_gross !== undefined ? (it.is_included_in_gross == 1 || it.is_included_in_gross === true) : true,
                        is_overridden: it.is_overridden == 1 || it.is_overridden === true,
                        is_taxable: it.is_taxable == 1 || it.is_taxable === true,
                        is_statutory: !!isStat
                    };
                });
                ensureStatutoryCellsInList(currentComponentCells);
                recalculateAllCells();
                renderComponentCellsUI();
            } else {
                // Load from selected template structure or defaults
                var initialStructureId = structSelect ? structSelect.value : '';
                loadStructureTemplateCells(initialStructureId, true);
            }

            // Sync initial Tax override view state
            toggleEmployeeTabTaxOverride('<?= esc($curAutoCalc) ?>');

            // Form submission safety hook
            var form = document.getElementById('salary-assignment-form');
            if (form) {
                form.addEventListener('submit', function(e) {
                    var autoSel2 = document.getElementById('emp-tab-tax-auto');
                    if (autoSel2 && autoSel2.value !== 'active') {
                        var a = document.getElementById('emp-tab-tax-annual');
                        var r = document.getElementById('emp-tab-tax-reason');
                        var aVal = a ? parseFloat(a.value) : NaN;
                        if (isNaN(aVal) || aVal < 0) { e.preventDefault(); alert('Enter the Annual Tax Amount (0 or more).'); return; }
                        if (!r || r.value.trim().length < 3) { e.preventDefault(); alert('Enter a reason for turning Auto Tax Calculation off.'); return; }
                    }
                    recalculateAllCells();
                });
            }
        });
        </script>
    <?php endif; ?>

    <!-- Salary Revision History -->
    <?php if (!empty($salaryHistory) || !empty($revisions)): ?>
        <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-xs">
            <div class="p-5 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between">
                <div>
                    <h3 class="font-bold text-slate-900 dark:text-white text-base">Salary Assignment & Revision History</h3>
                    <p class="text-xs text-slate-500 mt-0.5">Authoritative audit trail of past salary decisions</p>
                </div>
                <span class="text-xs text-slate-400"><?= count($salaryHistory ?: $revisions) ?> record(s)</span>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse text-xs">
                    <thead>
                        <tr class="border-b border-slate-100 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 text-slate-500 font-medium">
                            <th class="py-3 px-4">Effective Date</th>
                            <th class="py-3 px-4">Basic Salary</th>
                            <th class="py-3 px-4">Gross Salary</th>
                            <th class="py-3 px-4">Structure</th>
                            <th class="py-3 px-4">Assigned By</th>
                            <th class="py-3 px-4">Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-700">
                        <?php foreach (($salaryHistory ?: $revisions) as $hist): ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                                <td class="py-3 px-4 font-mono font-medium text-slate-800 dark:text-slate-200">
                                    <?= esc($hist['effective_from'] ?? $hist['effective_date'] ?? '---') ?>
                                </td>
                                <td class="py-3 px-4 font-mono font-bold text-slate-900 dark:text-white">
                                    <?= format_money((float)($hist['basic_salary'] ?? $hist['new_basic'] ?? 0)) ?>
                                </td>
                                <td class="py-3 px-4 font-mono text-indigo-600 dark:text-indigo-400">
                                    <?= format_money((float)($hist['gross_salary'] ?? $hist['new_gross'] ?? 0)) ?>
                                </td>
                                <td class="py-3 px-4 text-slate-600 dark:text-slate-300">
                                    <?= esc($hist['structure_name'] ?? 'Manual Policy') ?>
                                </td>
                                <td class="py-3 px-4 text-slate-500">
                                    <?= esc($hist['assigned_by_name'] ?? 'Authorized HR') ?>
                                </td>
                                <td class="py-3 px-4">
                                    <span class="px-2 py-0.5 rounded text-[10px] font-bold <?= ($hist['status'] ?? 'Active') === 'Active' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-slate-100 text-slate-600' ?>">
                                        <?= esc($hist['status'] ?? 'Active') ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>

    <!-- Monthly Payslips History (Real Database Records Only) -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-xs">
        <div class="p-5 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between">
            <div>
                <h3 class="font-bold text-slate-900 dark:text-white text-base">Disbursed Payslips & Payroll Archive</h3>
                <p class="text-xs text-slate-500 mt-0.5">Official electronic records of payroll runs for this employee</p>
            </div>
            <span class="text-xs text-slate-400"><?= count($payrolls ?? []) ?> record(s)</span>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-xs">
                <thead>
                    <tr class="border-b border-slate-100 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 text-slate-500 font-medium">
                        <th class="py-3 px-4">Payroll Cycle</th>
                        <th class="py-3 px-4">Basic Pay</th>
                        <th class="py-3 px-4">Gross Earnings</th>
                        <th class="py-3 px-4">Deductions</th>
                        <th class="py-3 px-4">Net Disbursed</th>
                        <th class="py-3 px-4">Payment Method</th>
                        <th class="py-3 px-4">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-700">
                    <?php if (empty($payrolls)): ?>
                        <tr>
                            <td colspan="7" class="py-8 text-center text-slate-400">
                                <div class="flex flex-col items-center justify-center gap-2">
                                    <i data-lucide="receipt" class="w-6 h-6 text-slate-300 dark:text-slate-600"></i>
                                    <span>No finalized or disbursed payslips found for this employee yet.</span>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($payrolls as $py): ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                                <td class="py-3 px-4 font-bold text-slate-900 dark:text-white"><?= esc($py['payroll_month']) ?></td>
                                <td class="py-3 px-4 font-mono"><?= format_money((float)($py['basic_salary'] ?? $basic)) ?></td>
                                <td class="py-3 px-4 font-mono"><?= format_money((float)($py['gross_salary'] ?? $gross)) ?></td>
                                <td class="py-3 px-4 font-mono text-rose-500">-<?= format_money((float)($py['total_deductions'] ?? $totalDeductions)) ?></td>
                                <td class="py-3 px-4 font-mono font-bold text-emerald-600 dark:text-emerald-400"><?= format_money((float)($py['net_salary'] ?? $netSalary)) ?></td>
                                <td class="py-3 px-4"><?= esc($employee['bank_name'] ?? 'Direct Transfer') ?></td>
                                <td class="py-3 px-4">
                                    <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                                        <?= esc($py['status'] ?? 'Paid') ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
