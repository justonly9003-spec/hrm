<!-- Overview Tab -->
<div class="space-y-6">
    <!-- 4 High Impact Metric Cards -->
    <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div class="p-4 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/50 space-y-1">
            <span class="text-[11px] uppercase tracking-wider font-bold text-indigo-500">Attendance Rate</span>
            <div class="text-xl font-bold text-indigo-700 dark:text-indigo-300">96.5%</div>
            <span class="text-[10px] text-slate-400">Past 30 active days</span>
        </div>
        <div class="p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-900/50 space-y-1">
            <span class="text-[11px] uppercase tracking-wider font-bold text-emerald-500">Leave Balance</span>
            <?php 
            $activeBalances = !empty($leaveBalances) ? $leaveBalances : (!empty($leaveBalance) && is_array($leaveBalance) && isset($leaveBalance[0]) ? $leaveBalance : []);
            ?>
            <?php if (!empty($activeBalances)): ?>
                <?php 
                $totalAvail = array_sum(array_column($activeBalances, 'available_balance'));
                $totalEnt   = array_sum(array_column($activeBalances, 'total_entitlement'));
                ?>
                <div class="text-xl font-bold text-emerald-700 dark:text-emerald-300"><?= (float)$totalAvail ?> Days</div>
                <span class="text-[10px] text-slate-400"><?= (float)$totalAvail ?> available of <?= (float)$totalEnt ?> for <?= date('Y') ?></span>
            <?php else: ?>
                <div class="text-sm font-semibold text-slate-500 dark:text-slate-400 mt-1">Not configured</div>
                <span class="text-[10px] text-slate-400">For <?= date('Y') ?></span>
            <?php endif; ?>
        </div>
        <div class="p-4 rounded-2xl bg-sky-50/70 dark:bg-sky-950/40 border border-sky-100 dark:border-sky-900/50 space-y-1">
            <span class="text-[11px] uppercase tracking-wider font-bold text-sky-500">Gross Salary</span>
            <?php
            $activeGross = $salarySetup['active_salary']['gross_salary'] ?? ($employee['gross_salary'] ?? 0);
            ?>
            <div class="text-xl font-bold text-sky-700 dark:text-sky-300 font-mono">
                <?= !empty($canViewSalaryFigures) ? format_money((float)$activeGross) : 'Restricted' ?>
            </div>
            <span class="text-[10px] text-slate-400">Monthly Compensation</span>
        </div>
        <div class="p-4 rounded-2xl bg-amber-50/70 dark:bg-amber-950/40 border border-amber-100 dark:border-amber-900/50 space-y-1">
            <span class="text-[11px] uppercase tracking-wider font-bold text-amber-500">KPI Rating</span>
            <div class="text-xl font-bold text-amber-700 dark:text-amber-300"><?= esc($employee['kpi_score'] ?? 'Not configured') ?></div>
            <span class="text-[10px] text-slate-400">Performance Index</span>
        </div>
    </div>

    <!-- Recent Attendance Activity -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-xs">
        <div class="p-5 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between">
            <h3 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                <i data-lucide="calendar-check" class="w-4 h-4 text-indigo-600"></i>
                Recent Attendance Activity
            </h3>
            <button type="button" @click="activeTab = 'attendance'" class="text-xs text-indigo-600 hover:text-indigo-700 font-semibold flex items-center gap-1">
                <span>View Full Log</span>
                <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
            </button>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-xs">
                <thead>
                    <tr class="border-b border-slate-100 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 text-slate-500 font-medium">
                        <th class="py-3 px-4">Date</th>
                        <th class="py-3 px-4">Check In</th>
                        <th class="py-3 px-4">Check Out</th>
                        <th class="py-3 px-4">Working Hours</th>
                        <th class="py-3 px-4">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-700">
                    <?php if (empty($attendance)): ?>
                        <tr><td colspan="5" class="py-6 text-center text-slate-400">No punch records found.</td></tr>
                    <?php else: ?>
                        <?php foreach (array_slice($attendance, 0, 5) as $att): ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                                <td class="py-3 px-4 font-mono"><?= esc($att['date']) ?></td>
                                <td class="py-3 px-4"><?= esc($att['check_in'] ?? '--:--') ?></td>
                                <td class="py-3 px-4"><?= esc($att['check_out'] ?? '--:--') ?></td>
                                <td class="py-3 px-4 font-mono"><?= number_format((float)($att['working_hours'] ?? 0), 2) ?> hrs</td>
                                <td class="py-3 px-4">
                                    <span class="px-2 py-0.5 rounded text-[10px] font-bold <?= ($att['status'] ?? 'Present') === 'Present' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800' ?>">
                                        <?= esc($att['status'] ?? 'Present') ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Recent Leave Requests -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-xs">
        <div class="p-5 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between">
            <h3 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                <i data-lucide="plane-takeoff" class="w-4 h-4 text-emerald-600"></i>
                Recent Leave Applications
            </h3>
            <button type="button" @click="activeTab = 'leave'" class="text-xs text-indigo-600 hover:text-indigo-700 font-semibold flex items-center gap-1">
                <span>View All Leaves</span>
                <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
            </button>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-xs">
                <thead>
                    <tr class="border-b border-slate-100 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 text-slate-500 font-medium">
                        <th class="py-3 px-4">Type</th>
                        <th class="py-3 px-4">Date Range</th>
                        <th class="py-3 px-4">Days</th>
                        <th class="py-3 px-4">Reason</th>
                        <th class="py-3 px-4">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-700">
                    <?php if (empty($leaves)): ?>
                        <tr><td colspan="5" class="py-6 text-center text-slate-400">No leave requests recorded.</td></tr>
                    <?php else: ?>
                        <?php foreach (array_slice($leaves, 0, 5) as $lv): ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                                <td class="py-3 px-4 font-semibold"><?= esc($lv['leave_type_name'] ?? $lv['type'] ?? 'Casual Leave') ?></td>
                                <td class="py-3 px-4 font-mono text-slate-600 dark:text-slate-300"><?= esc($lv['start_date']) ?> to <?= esc($lv['end_date']) ?></td>
                                <td class="py-3 px-4 font-mono"><?= esc($lv['total_days'] ?? '1') ?>d</td>
                                <td class="py-3 px-4 max-w-xs truncate"><?= esc($lv['reason'] ?? 'N/A') ?></td>
                                <td class="py-3 px-4">
                                    <span class="px-2 py-0.5 rounded text-[10px] font-bold <?= ($lv['status'] ?? 'Approved') === 'Approved' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800' ?>">
                                        <?= esc($lv['status'] ?? 'Pending') ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
