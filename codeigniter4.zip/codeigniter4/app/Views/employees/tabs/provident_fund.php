<!-- Provident Fund (PF) Tab -->
<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-6">
    <div class="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-700 pb-4">
        <div>
            <div class="flex items-center gap-2">
                <div class="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
                    <i data-lucide="shield-check" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="font-bold text-slate-900 dark:text-white text-base">Provident Fund (PF) Balance & Statutory Profile</h3>
                    <p class="text-xs text-slate-500 mt-0.5">Retirement corpus management, monthly contributions, balance accumulation, and ledger statement</p>
                </div>
            </div>
        </div>
        <div class="flex items-center gap-2">
            <span class="px-2.5 py-1 text-xs font-semibold rounded-lg bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                Company Scope: <?= esc($employee['company_name'] ?? 'Assigned Tenant') ?>
            </span>
            <a href="<?= base_url('pf/reports/details' . (!empty($canManagePf) ? '?employee_id=' . esc($employee['id']) : '')) ?>" class="px-2.5 py-1 text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition flex items-center gap-1">
                <i data-lucide="external-link" class="w-3.5 h-3.5"></i>
                <span>Full Ledger View</span>
            </a>
        </div>
    </div>

    <?php if (($employee['role'] ?? '') === 'Software App Admin' || ($employee['employee_code'] ?? '') === 'SUPER_ADMIN'): ?>
        <!-- Software App Admin Exclusion Notice -->
        <div class="p-6 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200 space-y-3">
            <div class="flex items-center gap-2.5 font-bold text-sm">
                <i data-lucide="alert-triangle" class="w-5 h-5 text-amber-600"></i>
                <span>Software App Admin Excluded from Statutory Provident Fund</span>
            </div>
            <p class="text-xs text-amber-800 dark:text-amber-300 leading-relaxed">
                Under the SaaS multi-tenant governance architecture, Software App Admin represents a global system supervisor and is not an operational corporate employee. Software App Admin is strictly prohibited from participating in corporate Provident Fund schemes, receiving retirement ledger postings, or undergoing payroll deductions.
            </p>
        </div>
    <?php else: ?>

        <?php
            $isPfApplicable = !empty($employee['is_pf_applicable']) && ((int)$employee['is_pf_applicable'] === 1);
            $rawStatus = trim((string)($employee['pf_status'] ?? ''));
            if ($rawStatus === 'Enrolled' && !$isPfApplicable) {
                $pfStatus = 'Not Enrolled';
            } elseif ($isPfApplicable && $rawStatus === '') {
                $pfStatus = 'Enrolled';
            } else {
                $pfStatus = $rawStatus !== '' ? $rawStatus : ($isPfApplicable ? 'Enrolled' : 'Not Enrolled');
            }
            $pfRuleId = '';
            $pfRuleName = 'Provident Fund Rule';
            $pfContribType = 'Percentage';
            $pfEmpRate = 0.00;
            $pfCompRate = 0.00;
            $pfEmpFixed = (float)($employee['pf_employee_fixed_amount'] ?? 0.00);
            $pfCompFixed = (float)($employee['pf_employer_fixed_amount'] ?? 0.00);

            // Read resolved PF rule from controller (RuleResolver SSOT)
            if (isset($resolvedPfRule) && $resolvedPfRule instanceof \App\Services\Rules\ResolvedRule) {
                $pfRuleId      = $resolvedPfRule->effectiveRuleId();
                $pfContribType = ucfirst((string)$resolvedPfRule->get('contribution_type'));
                $pfEmpRate     = (float)$resolvedPfRule->get('employee_rate');
                $pfCompRate    = (float)$resolvedPfRule->get('employer_rate');
                $pfEmpFixed    = (float)$resolvedPfRule->get('employee_fixed_amount');
                $pfCompFixed   = (float)$resolvedPfRule->get('employer_fixed_amount');
            } elseif (!empty($pfRules) && is_array($pfRules)) {
                $firstRule     = $pfRules[0];
                $pfRuleId      = $firstRule['id'] ?? '';
                $pfContribType = ucfirst((string)($firstRule['contribution_type'] ?? 'Percentage'));
                $pfEmpRate     = (float)($firstRule['employee_rate'] ?? 0.00);
                $pfCompRate    = (float)($firstRule['employer_rate'] ?? 0.00);
                $pfRuleName    = $firstRule['name'] ?? 'Provident Fund Rule';
                if (isset($firstRule['employee_fixed_amount'])) {
                    $pfEmpFixed = (float)$firstRule['employee_fixed_amount'];
                }
                if (isset($firstRule['employer_fixed_amount'])) {
                    $pfCompFixed = (float)$firstRule['employer_fixed_amount'];
                }
            } elseif (!empty($employee['company_id'])) {
                try {
                    $rule = \App\Services\Rules\RuleResolver::resolve((string)$employee['company_id'], 'PF', date('Y-m-d'), $employee);
                    $pfRuleId      = $rule->effectiveRuleId();
                    $pfContribType = ucfirst((string)$rule->get('contribution_type'));
                    $pfEmpRate     = (float)$rule->get('employee_rate');
                    $pfCompRate    = (float)$rule->get('employer_rate');
                    $pfEmpFixed    = (float)$rule->get('employee_fixed_amount');
                    $pfCompFixed   = (float)$rule->get('employer_fixed_amount');
                } catch (\Throwable $e) {}
            }

            $pfEffectiveDate = !empty($employee['pf_effective_date'])
                ? $employee['pf_effective_date']
                : (!empty($employee['joining_date']) ? $employee['joining_date'] : date('Y-m-d'));
            $pfCloseDate = $employee['pf_close_date'] ?? '';
            $pfCloseReason = $employee['pf_close_reason'] ?? '';
            $pfMemberId = $employee['pf_member_id'] ?? '';
            if ($isPfApplicable && $pfStatus === 'Enrolled' && empty($pfMemberId)) {
                $pfMemberId = 'PF-' . ($employee['employee_code'] ?? $employee['id']);
            }
            $pfVoluntaryRate = (float)($employee['pf_voluntary_rate'] ?? 0.00);
            $pfExemptionReason = $employee['pf_exemption_reason'] ?? '';
            $pfNotes = $employee['pf_notes'] ?? '';
            $basicSalary = (float)($employee['basic_salary'] ?? 0.00);

            $empSafeId = preg_replace('/[^a-zA-Z0-9_]/', '_', (string)$employee['id']);
            $pfConfigPayload = [
                'isApplicable'    => $isPfApplicable,
                'pfStatus'        => $pfStatus,
                'ruleId'          => $pfRuleId,
                'ruleName'        => $pfRuleName,
                'contribType'     => $pfContribType,
                'empRate'         => (float)$pfEmpRate,
                'compRate'        => (float)$pfCompRate,
                'empFixed'        => (float)$pfEmpFixed,
                'compFixed'       => (float)$pfCompFixed,
                'effectiveDate'   => (string)$pfEffectiveDate,
                'closeDate'       => (string)$pfCloseDate,
                'closeReason'     => (string)$pfCloseReason,
                'memberId'        => (string)$pfMemberId,
                'voluntaryRate'   => (float)$pfVoluntaryRate,
                'exemptionReason' => (string)$pfExemptionReason,
                'notes'           => (string)$pfNotes,
                'basicSalary'     => (float)$basicSalary,
                'rules'           => $pfRules ?? [],
                'employeeCode'    => (string)($employee['employee_code'] ?? $employee['id']),
                'joiningDate'     => (string)($employee['joining_date'] ?? date('Y-m-d')),
            ];
        ?>

        <!-- Script Definition Prior to DOM Node (Guarantees Alpine Function Exists with Zero Quote Conflicts) -->
        <script>
        (function() {
            var rawConfig = <?= json_encode($pfConfigPayload, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>;
            window.__pfConfig_<?= $empSafeId ?> = rawConfig;

            window.employeePfHandler_<?= $empSafeId ?> = function(cfg) {
                var config = cfg || window.__pfConfig_<?= $empSafeId ?> || {};
                return {
                    initialApplicable: Boolean(config.isApplicable),
                    isApplicable: Boolean(config.isApplicable),
                    pfStatus: config.pfStatus || 'Not Enrolled',
                    ruleId: config.ruleId || '',
                    ruleName: config.ruleName || 'Provident Fund Rule',
                    contribType: config.contribType || 'Percentage',
                    empRate: parseFloat(config.empRate) || 0,
                    compRate: parseFloat(config.compRate) || 0,
                    empFixed: parseFloat(config.empFixed) || 0,
                    compFixed: parseFloat(config.compFixed) || 0,
                    effectiveDate: config.effectiveDate || '',
                    closeDate: config.closeDate || '',
                    closeReason: config.closeReason || '',
                    memberId: config.memberId || '',
                    voluntaryRate: parseFloat(config.voluntaryRate) || 0,
                    exemptionReason: config.exemptionReason || '',
                    notes: config.notes || '',
                    basicSalary: parseFloat(config.basicSalary) || 0,
                    rules: config.rules || [],

                    init: function() {
                        window.__pfCurrentComponent = this;
                    },

                    toggleApplicable: function() {
                        this.isApplicable = !this.isApplicable;
                        this.handleApplicableState();
                    },

                    onToggleApplicable: function() {
                        this.isApplicable = !this.isApplicable;
                        this.handleApplicableState();
                    },

                    handleApplicableState: function() {
                        var today = new Date().toISOString().slice(0, 10);
                        if (this.isApplicable) {
                            this.pfStatus = 'Enrolled';
                            if (!this.memberId) {
                                this.memberId = 'PF-' + (config.employeeCode || '');
                            }
                            if (!this.effectiveDate) {
                                this.effectiveDate = config.joiningDate || today;
                            }
                            this.closeDate = '';
                            this.closeReason = '';
                        } else {
                            this.pfStatus = 'Not Enrolled';
                            if (this.initialApplicable && !this.closeDate) {
                                this.closeDate = (this.effectiveDate && today < this.effectiveDate) ? this.effectiveDate : today;
                            }
                        }
                        this.syncDomInputs();
                    },

                    onStatusChange: function() {
                        var today = new Date().toISOString().slice(0, 10);
                        if (this.pfStatus === 'Enrolled') {
                            this.isApplicable = true;
                            if (!this.memberId) {
                                this.memberId = 'PF-' + (config.employeeCode || '');
                            }
                            if (!this.effectiveDate) {
                                this.effectiveDate = config.joiningDate || today;
                            }
                            this.closeDate = '';
                            this.closeReason = '';
                        } else {
                            this.isApplicable = false;
                            if (this.pfStatus === 'Not Enrolled' && this.initialApplicable && !this.closeDate) {
                                this.closeDate = (this.effectiveDate && today < this.effectiveDate) ? this.effectiveDate : today;
                            }
                        }
                        this.syncDomInputs();
                    },

                    syncDomInputs: function() {
                        var inp = document.getElementById('is_pf_applicable_input');
                        if (inp) inp.value = this.isApplicable ? '1' : '0';
                        var sel = document.getElementById('pf_status_select');
                        if (sel) sel.value = this.pfStatus;
                    },

                    getDisplayStatus: function() {
                        if (this.isApplicable && this.pfStatus === 'Enrolled') {
                            if (this.isFutureEffective()) {
                                return 'Pending (' + this.effectiveDate + ')';
                            }
                            return 'Enrolled (Active)';
                        }
                        if (this.closeDate && (!this.isApplicable || this.pfStatus === 'Not Enrolled')) {
                            return 'Closed (' + this.closeDate + ')';
                        }
                        return this.pfStatus || 'Not Enrolled';
                    },

                    isFutureEffective: function() {
                        if (!this.effectiveDate) return false;
                        var today = new Date().toISOString().slice(0, 10);
                        return this.effectiveDate > today;
                    },

                    isClosedForDate: function() {
                        if (!this.isApplicable || this.pfStatus !== 'Enrolled') return true;
                        if (this.closeDate) {
                            var today = new Date().toISOString().slice(0, 10);
                            return today >= this.closeDate;
                        }
                        return false;
                    },

                    calcEmpMonthly: function() {
                        if (!this.isApplicable || this.pfStatus !== 'Enrolled' || this.isFutureEffective() || this.isClosedForDate()) return 0;
                        if (this.contribType === 'Fixed') {
                            return this.empFixed;
                        }
                        var totalRate = this.empRate + (this.voluntaryRate || 0);
                        return (this.basicSalary * totalRate) / 100;
                    },

                    calcCompMonthly: function() {
                        if (!this.isApplicable || this.pfStatus !== 'Enrolled' || this.isFutureEffective() || this.isClosedForDate()) return 0;
                        if (this.contribType === 'Fixed') {
                            return this.compFixed;
                        }
                        return (this.basicSalary * this.compRate) / 100;
                    },

                    calcTotalMonthly: function() {
                        return this.calcEmpMonthly() + this.calcCompMonthly();
                    }
                };
            };

            // Register standard alias
            window.employeePfHandler = window.employeePfHandler_<?= $empSafeId ?>;
            if (window.Alpine) {
                window.Alpine.data('employeePfHandler', window.employeePfHandler);
            }
            document.addEventListener('alpine:init', function() {
                if (window.Alpine) {
                    window.Alpine.data('employeePfHandler', window.employeePfHandler);
                }
            });

            // Resilient instant toggle fallback (works even if Alpine is deferred)
            window.__pfToggleManual = function() {
                if (window.Alpine && window.__pfCurrentComponent) {
                    return; // Handled natively by Alpine @click
                }
                var hiddenInp = document.getElementById('is_pf_applicable_input');
                var btn = document.getElementById('pf_toggle_btn');
                var knob = document.getElementById('pf_toggle_knob');
                var badge = document.getElementById('pf_status_text_badge');
                var statusSelect = document.getElementById('pf_status_select');
                
                var isCurrentOn = hiddenInp ? hiddenInp.value === '1' : false;
                var newOn = !isCurrentOn;

                if (hiddenInp) hiddenInp.value = newOn ? '1' : '0';
                if (btn) {
                    if (newOn) {
                        btn.classList.remove('bg-slate-300', 'dark:bg-slate-700');
                        btn.classList.add('bg-emerald-600');
                        btn.setAttribute('aria-checked', 'true');
                    } else {
                        btn.classList.remove('bg-emerald-600');
                        btn.classList.add('bg-slate-300', 'dark:bg-slate-700');
                        btn.setAttribute('aria-checked', 'false');
                    }
                }
                if (knob) {
                    if (newOn) {
                        knob.classList.remove('translate-x-0');
                        knob.classList.add('translate-x-5');
                    } else {
                        knob.classList.remove('translate-x-5');
                        knob.classList.add('translate-x-0');
                    }
                }
                if (badge) {
                    badge.textContent = newOn ? 'Covered (Active)' : 'Not Covered';
                    if (newOn) {
                        badge.classList.remove('text-slate-400');
                        badge.classList.add('text-emerald-600', 'font-bold');
                    } else {
                        badge.classList.remove('text-emerald-600', 'font-bold');
                        badge.classList.add('text-slate-400');
                    }
                }
                if (statusSelect) {
                    statusSelect.value = newOn ? 'Enrolled' : 'Not Enrolled';
                }
            };
        })();
        </script>

        <div x-data="employeePfHandler(window.__pfConfig_<?= $empSafeId ?>)" class="space-y-6">

            <!-- 1. PF Balance Summary Overview Cards -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <!-- Authoritative Accumulated Corpus Card -->
                <div class="p-5 rounded-2xl bg-gradient-to-br from-emerald-600 to-teal-700 text-white shadow-md relative overflow-hidden sm:col-span-2 lg:col-span-1">
                    <div class="flex items-center justify-between opacity-80 text-[11px] font-semibold uppercase tracking-wider">
                        <span>Accumulated PF Balance</span>
                        <i data-lucide="shield-check" class="w-4 h-4"></i>
                    </div>
                    <div class="text-2xl font-black font-mono mt-2">
                        <?= format_money((float)($pfSummary['balance'] ?? 0.00)) ?>
                    </div>
                    <div class="text-[11px] opacity-80 mt-1 flex items-center gap-1.5">
                        <span class="inline-block w-1.5 h-1.5 rounded-full bg-emerald-300"></span>
                        <span>As of <?= esc($pfSummary['as_of'] ?? date('Y-m-d')) ?></span>
                    </div>
                </div>

                <!-- Employee Deductions -->
                <div class="p-5 rounded-2xl border border-slate-200/80 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-xs">
                    <div class="flex items-center justify-between text-slate-500 dark:text-slate-400 text-[11px] font-semibold uppercase tracking-wider">
                        <span>Employee Deductions</span>
                        <i data-lucide="user-check" class="w-4 h-4 text-indigo-500"></i>
                    </div>
                    <div class="text-xl font-bold font-mono text-slate-900 dark:text-white mt-2">
                        <?= format_money((float)($pfSummary['employee_contribution'] ?? 0.00)) ?>
                    </div>
                    <div class="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                        Direct employee contribution
                    </div>
                </div>

                <!-- Employer Matching -->
                <div class="p-5 rounded-2xl border border-slate-200/80 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-xs">
                    <div class="flex items-center justify-between text-slate-500 dark:text-slate-400 text-[11px] font-semibold uppercase tracking-wider">
                        <span>Employer Match</span>
                        <i data-lucide="building" class="w-4 h-4 text-emerald-500"></i>
                    </div>
                    <div class="text-xl font-bold font-mono text-slate-900 dark:text-white mt-2">
                        <?= format_money((float)($pfSummary['employer_contribution'] ?? 0.00)) ?>
                    </div>
                    <div class="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                        Company matching contribution
                    </div>
                </div>

                <!-- Interest & Opening Balance -->
                <div class="p-5 rounded-2xl border border-slate-200/80 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-xs">
                    <div class="flex items-center justify-between text-slate-500 dark:text-slate-400 text-[11px] font-semibold uppercase tracking-wider">
                        <span>Interest & Opening</span>
                        <i data-lucide="trending-up" class="w-4 h-4 text-amber-500"></i>
                    </div>
                    <div class="text-xl font-bold font-mono text-slate-900 dark:text-white mt-2">
                        <?= format_money((float)(($pfSummary['interest'] ?? 0.00) + ($pfSummary['opening_balance'] ?? 0.00))) ?>
                    </div>
                    <div class="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                        Interest: <?= format_money((float)($pfSummary['interest'] ?? 0.00)) ?>
                    </div>
                </div>
            </div>

            <!-- 2. Official Provident Fund Ledger Statement Table -->
            <div class="p-5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-xs space-y-4">
                <div class="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
                    <div class="flex items-center gap-2">
                        <i data-lucide="receipt" class="w-4 h-4 text-emerald-600 dark:text-emerald-400"></i>
                        <h4 class="font-bold text-slate-900 dark:text-white text-sm">Official Provident Fund Ledger Statement</h4>
                        <span class="px-2 py-0.5 text-[10px] font-bold rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-mono">
                            <?= count($pfLedger ?? []) ?> posted entries
                        </span>
                    </div>
                    <div class="flex items-center gap-2">
                        <a href="<?= base_url('pf/reports/export-details?employee_id=' . esc($employee['id'])) ?>" class="px-2.5 py-1 text-xs font-semibold rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 border border-emerald-200 dark:border-emerald-800 transition flex items-center gap-1.5">
                            <i data-lucide="download" class="w-3.5 h-3.5"></i>
                            <span>Export CSV</span>
                        </a>
                    </div>
                </div>

                <?php if (!empty($pfLedger)): ?>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse text-xs">
                            <thead>
                                <tr class="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                                    <th class="p-3">Date</th>
                                    <th class="p-3">Period</th>
                                    <th class="p-3">Transaction Type</th>
                                    <th class="p-3 text-right">PF Base Salary</th>
                                    <th class="p-3 text-right">Employee Contrib</th>
                                    <th class="p-3 text-right">Employer Match</th>
                                    <th class="p-3 text-right">Total Movement</th>
                                    <th class="p-3 text-right">Running Balance</th>
                                    <th class="p-3">Reference / Notes</th>
                                    <th class="p-3 text-center">Status</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
                                <?php foreach ($pfLedger as $entry): ?>
                                    <?php
                                        $transType = strtoupper((string)($entry['transaction_type'] ?? 'CONTRIBUTION'));
                                        $typeBadge = match($transType) {
                                            'CONTRIBUTION'    => 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800',
                                            'INTEREST'        => 'bg-blue-50 text-blue-700 dark:bg-blue-950/50 dark:text-blue-300 border border-blue-200 dark:border-blue-800',
                                            'OPENING_BALANCE' => 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800',
                                            'REVERSAL'        => 'bg-rose-50 text-rose-700 dark:bg-rose-950/50 dark:text-rose-300 border border-rose-200 dark:border-rose-800',
                                            'ADJUSTMENT'      => 'bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-300 border border-amber-200 dark:border-amber-800',
                                            default           => 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                                        };
                                        $typeLabel = match($transType) {
                                            'CONTRIBUTION'    => 'Contribution',
                                            'INTEREST'        => 'Interest',
                                            'OPENING_BALANCE' => 'Opening Balance',
                                            'REVERSAL'        => 'Reversal',
                                            'ADJUSTMENT'      => 'Adjustment',
                                            default           => ucfirst(strtolower($transType))
                                        };
                                        $periodStr = (!empty($entry['payroll_month']) && !empty($entry['payroll_year']))
                                            ? date('M Y', mktime(0, 0, 0, (int)$entry['payroll_month'], 1, (int)$entry['payroll_year']))
                                            : '-';
                                    ?>
                                    <tr class="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition">
                                        <td class="p-3 text-slate-700 dark:text-slate-300 whitespace-nowrap font-sans font-medium">
                                            <?= esc($entry['transaction_date'] ?? '-') ?>
                                        </td>
                                        <td class="p-3 text-slate-600 dark:text-slate-400 whitespace-nowrap">
                                            <?= esc($periodStr) ?>
                                        </td>
                                        <td class="p-3 whitespace-nowrap">
                                            <span class="px-2 py-0.5 text-[10px] font-semibold rounded-full font-sans <?= $typeBadge ?>">
                                                <?= esc($typeLabel) ?>
                                            </span>
                                        </td>
                                        <td class="p-3 text-right text-slate-700 dark:text-slate-300">
                                            <?= format_money((float)($entry['pf_base_salary'] ?? 0)) ?>
                                        </td>
                                        <td class="p-3 text-right text-rose-600 dark:text-rose-400 font-semibold">
                                            <?= format_money((float)($entry['employee_contribution'] ?? 0)) ?>
                                        </td>
                                        <td class="p-3 text-right text-emerald-600 dark:text-emerald-400 font-semibold">
                                            <?= format_money((float)($entry['employer_contribution'] ?? 0)) ?>
                                        </td>
                                        <td class="p-3 text-right font-bold text-slate-900 dark:text-white">
                                            <?= format_money((float)($entry['total_contribution'] ?? 0)) ?>
                                        </td>
                                        <td class="p-3 text-right font-black text-emerald-600 dark:text-emerald-400 bg-emerald-50/30 dark:bg-emerald-950/20">
                                            <?= format_money((float)($entry['running_balance'] ?? 0)) ?>
                                        </td>
                                        <td class="p-3 text-slate-500 dark:text-slate-400 font-sans text-[11px] max-w-xs truncate" title="<?= esc($entry['notes'] ?? $entry['reference_no'] ?? '') ?>">
                                            <?= esc($entry['reference_no'] ?: ($entry['notes'] ?: '-')) ?>
                                        </td>
                                        <td class="p-3 text-center whitespace-nowrap font-sans">
                                            <span class="px-2 py-0.5 text-[10px] font-semibold rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300">
                                                Posted
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="p-8 text-center rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 space-y-2">
                        <div class="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-400 mx-auto flex items-center justify-center">
                            <i data-lucide="receipt" class="w-5 h-5"></i>
                        </div>
                        <p class="font-bold text-slate-700 dark:text-slate-300 text-xs">No Posted Provident Fund Transactions Yet</p>
                        <p class="text-[11px] text-slate-500 dark:text-slate-400 max-w-md mx-auto">
                            Provident fund contributions and employer matching will automatically appear here once monthly payroll runs are approved and disbursed.
                        </p>
                    </div>
                <?php endif; ?>
            </div>

            <?php if (!empty($canManagePf)): ?>
                <!-- 3. Administrative PF Configuration Section (HR / Admin only) -->
                <div class="pt-4 border-t border-slate-200 dark:border-slate-700 space-y-4">
                    <div class="flex items-center gap-2">
                        <i data-lucide="settings" class="w-4 h-4 text-indigo-600 dark:text-indigo-400"></i>
                        <h4 class="font-bold text-slate-900 dark:text-white text-sm">Provident Fund Membership & Enrolment Settings</h4>
                    </div>

                    <!-- Summary / Banner Cards -->
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div class="p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50">
                            <div class="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Current Membership State</div>
                            <div class="flex items-center gap-2 mt-2">
                                <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold"
                                    :class="{
                                        'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300': isApplicable && pfStatus === 'Enrolled' && !isFutureEffective(),
                                        'bg-sky-100 text-sky-800 dark:bg-sky-950/80 dark:text-sky-300': isApplicable && pfStatus === 'Enrolled' && isFutureEffective(),
                                        'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300': pfStatus === 'Exempt',
                                        'bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-300': pfStatus === 'Ineligible',
                                        'bg-slate-200 text-slate-800 dark:bg-slate-800 dark:text-slate-300': (!isApplicable || pfStatus === 'Not Enrolled') && !closeDate,
                                        'bg-purple-100 text-purple-800 dark:bg-purple-950/80 dark:text-purple-300': (!isApplicable || pfStatus === 'Not Enrolled') && closeDate
                                    }">
                                    <span class="w-1.5 h-1.5 rounded-full mr-1.5"
                                        :class="{
                                            'bg-emerald-500': isApplicable && pfStatus === 'Enrolled' && !isFutureEffective(),
                                            'bg-sky-500': isApplicable && pfStatus === 'Enrolled' && isFutureEffective(),
                                            'bg-amber-500': pfStatus === 'Exempt',
                                            'bg-rose-500': pfStatus === 'Ineligible',
                                            'bg-slate-400': (!isApplicable || pfStatus === 'Not Enrolled') && !closeDate,
                                            'bg-purple-500': (!isApplicable || pfStatus === 'Not Enrolled') && closeDate
                                        }"></span>
                                    <span x-text="getDisplayStatus()"><?= esc($isPfApplicable ? ($pfStatus === 'Enrolled' ? 'Enrolled (Active)' : $pfStatus) : 'Not Enrolled') ?></span>
                                </span>
                            </div>
                        </div>

                        <div class="p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50">
                            <div class="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">PF Member / Account ID</div>
                            <div class="flex items-center gap-2 mt-2">
                                <span class="text-sm font-mono font-bold text-slate-900 dark:text-white" x-text="memberId || 'Not Registered'"><?= esc($pfMemberId ?: 'Not Registered') ?></span>
                                <template x-if="closeDate && (!isApplicable || pfStatus !== 'Enrolled')">
                                    <span class="text-[10px] px-1.5 py-0.5 rounded bg-slate-200 text-slate-600 dark:bg-slate-800 dark:text-slate-400 font-sans font-medium">Preserved</span>
                                </template>
                            </div>
                        </div>

                        <div class="p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50">
                            <div class="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Basic Salary Basis</div>
                            <div class="text-sm font-mono font-bold text-slate-900 dark:text-white mt-2">
                                <?= format_money($basicSalary) ?>
                            </div>
                        </div>
                    </div>

                    <!-- Configuration Form -->
                    <form action="<?= base_url('employees/profile/' . $employee['id'] . '/update-pf') ?>" method="POST" class="space-y-6">
                        <?= csrf_field() ?>

                        <div class="p-5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 space-y-4">
                            <!-- Toggle Switch Section -->
                            <div class="flex items-center justify-between">
                                <div class="cursor-pointer select-none" @click="toggleApplicable()">
                                    <label class="font-bold text-slate-900 dark:text-white text-sm cursor-pointer">Covered by Provident Fund (PF)</label>
                                    <p class="text-xs text-slate-500 mt-0.5">Enable or disable monthly retirement contributions for this employee</p>
                                </div>
                                <div class="flex items-center gap-3">
                                    <span class="text-xs font-semibold cursor-pointer select-none" @click="toggleApplicable()" :class="isApplicable ? 'text-emerald-600 dark:text-emerald-400 font-bold' : 'text-slate-400'">
                                        <span id="pf_status_text_badge" x-text="isApplicable ? 'Covered (Active)' : 'Not Covered'"><?= $isPfApplicable ? 'Covered (Active)' : 'Not Covered' ?></span>
                                    </span>
                                    <button type="button" 
                                        id="pf_toggle_btn"
                                        @click="toggleApplicable()"
                                        :class="isApplicable ? 'bg-emerald-600' : 'bg-slate-300 dark:bg-slate-700'"
                                        class="relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 <?= $isPfApplicable ? 'bg-emerald-600' : 'bg-slate-300 dark:bg-slate-700' ?>"
                                        role="switch" 
                                        :aria-checked="isApplicable ? 'true' : 'false'">
                                        <span class="sr-only">Covered by Provident Fund</span>
                                        <span id="pf_toggle_knob"
                                            :class="isApplicable ? 'translate-x-5' : 'translate-x-0'"
                                            class="pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out <?= $isPfApplicable ? 'translate-x-5' : 'translate-x-0' ?>"></span>
                                    </button>
                                    <!-- Guaranteed POST input value with static fallback -->
                                    <input type="hidden" name="is_pf_applicable" id="is_pf_applicable_input" :value="isApplicable ? '1' : '0'" value="<?= $isPfApplicable ? '1' : '0' ?>">
                                </div>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-slate-100 dark:border-slate-800 text-xs">
                                <div>
                                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Participation Status <span class="text-rose-500">*</span></label>
                                    <select name="pf_status" id="pf_status_select" x-model="pfStatus" @change="onStatusChange()" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                                        <option value="Enrolled" <?= $pfStatus === 'Enrolled' ? 'selected' : '' ?>>Enrolled (Active Participation)</option>
                                        <option value="Not Enrolled" <?= $pfStatus === 'Not Enrolled' ? 'selected' : '' ?>>Not Enrolled</option>
                                        <option value="Exempt" <?= $pfStatus === 'Exempt' ? 'selected' : '' ?>>Statutory Exempt</option>
                                        <option value="Ineligible" <?= $pfStatus === 'Ineligible' ? 'selected' : '' ?>>Ineligible (Contractual / Probation)</option>
                                    </select>
                                </div>

                                <div>
                                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                                        PF Member / UAN ID
                                        <span x-show="!isApplicable" class="text-slate-400 font-normal">(Preserved for historical reporting)</span>
                                    </label>
                                    <input type="text" name="pf_member_id" id="pf_member_id_input" x-model="memberId" value="<?= esc($pfMemberId) ?>" placeholder="e.g. PF-101 or UAN-892348" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono">
                                </div>

                                <div>
                                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                                        Effective Enrollment Date
                                        <span x-show="isApplicable" class="text-rose-500">*</span>
                                    </label>
                                    <input type="date" name="pf_effective_date" id="pf_effective_date_input" x-model="effectiveDate" value="<?= esc($pfEffectiveDate) ?>" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                                    <p class="text-[11px] text-slate-400 mt-1">Date when active PF deductions commenced</p>
                                </div>

                                <!-- PF Close Date (Visible when membership is being terminated or has ended) -->
                                <div x-show="!isApplicable || pfStatus === 'Not Enrolled' || Boolean(closeDate)">
                                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                                        PF Close / Termination Date
                                        <span x-show="!isApplicable && pfStatus === 'Not Enrolled'" class="text-amber-500 font-normal">(PF ends from this date)</span>
                                    </label>
                                    <input type="date" name="pf_close_date" id="pf_close_date_input" x-model="closeDate" value="<?= esc($pfCloseDate) ?>" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                                    <p class="text-[11px] text-slate-400 mt-1">Payrolls on or after this date will have zero PF deductions</p>
                                </div>

                                <!-- PF Close Reason -->
                                <div class="col-span-1 md:col-span-2" x-show="!isApplicable || pfStatus === 'Not Enrolled' || Boolean(closeDate)">
                                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">PF Termination / Close Reason</label>
                                    <textarea name="pf_close_reason" id="pf_close_reason_input" x-model="closeReason" rows="2" placeholder="State reason for PF closure (e.g. Employee resignation, retirement, opting out under statutory threshold, mutual settlement)" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-slate-900 dark:text-white"><?= esc($pfCloseReason) ?></textarea>
                                </div>

                                <!-- Centralized Policy Rule Banner (No Rates Stored Here) -->
                                <div class="col-span-1 md:col-span-2 p-3.5 bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/60 rounded-xl text-indigo-900 dark:text-indigo-200">
                                    <div class="flex items-start gap-2.5">
                                        <i data-lucide="shield-check" class="w-4 h-4 text-indigo-600 dark:text-indigo-400 mt-0.5 shrink-0"></i>
                                        <div class="space-y-1 text-xs">
                                            <p class="font-bold">Statutory Policy Governed (No Local Rates)</p>
                                            <p class="text-[11px] text-indigo-700 dark:text-indigo-300">
                                                Provident fund rules, employee deduction rates, and employer matching contributions are strictly governed by the company's active <strong>PROVIDENT_FUND</strong> Statutory Policy by effective date. This profile tab manages only membership registration, close dates, and exemption reasons.
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <!-- Exemption Reason conditional textarea -->
                                <div class="col-span-1 md:col-span-2" x-show="pfStatus === 'Exempt' || pfStatus === 'Ineligible'">
                                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Exemption / Ineligibility Justification <span class="text-rose-500">*</span></label>
                                    <textarea name="pf_exemption_reason" id="pf_exemption_reason_input" x-model="exemptionReason" rows="2" placeholder="State reason for exemption (e.g., Covered under international pension scheme, non-resident consultant, statutory age threshold)" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-slate-900 dark:text-white"><?= esc($pfExemptionReason) ?></textarea>
                                </div>

                                <div class="col-span-1 md:col-span-2">
                                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">HR Audit Notes / Authorization Reference</label>
                                    <textarea name="pf_notes" id="pf_notes_input" x-model="notes" rows="2" placeholder="Administrative notes, approval board minutes, or trustee reference" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-slate-900 dark:text-white"><?= esc($pfNotes) ?></textarea>
                                </div>
                            </div>
                        </div>

                        <!-- Live Statutory Preview Card -->
                        <div class="p-5 rounded-2xl bg-gradient-to-br from-slate-900 to-indigo-950 text-white shadow-lg space-y-4">
                            <div class="flex items-center justify-between border-b border-indigo-800/60 pb-3">
                                <div class="flex items-center gap-2">
                                    <i data-lucide="calculator" class="w-4 h-4 text-emerald-400"></i>
                                    <span class="font-bold text-xs uppercase tracking-wider text-indigo-200">Monthly Statutory Contribution Impact Preview</span>
                                </div>
                                <span class="text-[11px] font-mono text-emerald-400" x-text="ruleName || 'Standard Policy'"><?= esc($pfRuleName) ?></span>
                            </div>

                            <template x-if="!isApplicable || pfStatus !== 'Enrolled'">
                                <div>
                                    <template x-if="closeDate">
                                        <div class="p-3 bg-purple-500/10 border border-purple-500/30 rounded-xl text-purple-200 text-xs space-y-1">
                                            <div class="flex items-center gap-1.5 font-bold">
                                                <i data-lucide="shield-alert" class="w-4 h-4 text-purple-400"></i>
                                                <span>PF Membership Terminated / Closed</span>
                                            </div>
                                            <p class="text-[11px] leading-relaxed">
                                                Active PF membership ended on <strong x-text="closeDate"></strong>. Zero PF deductions and employer contributions will occur for payrolls on or after this date. Historical payrolls prior to close date remain preserved.
                                            </p>
                                        </div>
                                    </template>
                                    <template x-if="!closeDate">
                                        <div class="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-200 text-xs">
                                            <span class="font-bold">No Deductions:</span> Employee is currently <strong x-text="pfStatus"></strong>. Zero Provident Fund deductions will occur during monthly payroll generation.
                                        </div>
                                    </template>
                                </div>
                            </template>

                            <template x-if="isApplicable && pfStatus === 'Enrolled' && isFutureEffective()">
                                <div class="p-3 bg-sky-500/10 border border-sky-500/30 rounded-xl text-sky-200 text-xs">
                                    <span class="font-bold">Pending Effective Date:</span> Enrolment is scheduled effective from <strong x-text="effectiveDate"></strong>. Zero deductions will occur until effective date.
                                </div>
                            </template>

                            <div class="grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs">
                                <div class="p-3 bg-white/5 rounded-xl border border-white/10">
                                    <span class="text-[10px] uppercase text-indigo-300 block">Basic Salary Basis</span>
                                    <span class="text-sm font-bold font-mono text-white mt-0.5"><?= format_money($basicSalary) ?></span>
                                </div>
                                <div class="p-3 bg-white/5 rounded-xl border border-white/10">
                                    <span class="text-[10px] uppercase text-indigo-300 block">Employee Monthly Deduction</span>
                                    <span class="text-sm font-bold font-mono text-rose-400 mt-0.5" x-text="'<?= esc(app_currency_code($employee['company_id'] ?? null)) ?> ' + calcEmpMonthly().toFixed(2)"><?= format_money(($basicSalary * $pfEmpRate) / 100) ?></span>
                                </div>
                                <div class="p-3 bg-white/5 rounded-xl border border-white/10">
                                    <span class="text-[10px] uppercase text-indigo-300 block">Employer Monthly Match</span>
                                    <span class="text-sm font-bold font-mono text-emerald-400 mt-0.5" x-text="'<?= esc(app_currency_code($employee['company_id'] ?? null)) ?> ' + calcCompMonthly().toFixed(2)"><?= format_money(($basicSalary * $pfCompRate) / 100) ?></span>
                                </div>
                                <div class="p-3 bg-emerald-500/20 rounded-xl border border-emerald-500/40">
                                    <span class="text-[10px] uppercase text-emerald-300 block font-semibold">Total Monthly Deposit</span>
                                    <span class="text-base font-black font-mono text-emerald-300 mt-0.5" x-text="'<?= esc(app_currency_code($employee['company_id'] ?? null)) ?> ' + calcTotalMonthly().toFixed(2)"><?= format_money(($basicSalary * ($pfEmpRate + $pfCompRate)) / 100) ?></span>
                                </div>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="flex items-center justify-end gap-3">
                            <button type="submit" class="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-xl shadow-sm transition-all flex items-center gap-2 cursor-pointer">
                                <i data-lucide="save" class="w-4 h-4"></i>
                                <span>Save Provident Fund Configuration</span>
                            </button>
                        </div>
                    </form>
                </div>
            <?php else: ?>
                <!-- 3. Read-Only Statutory Enrolment & Policy Details (Employee Self-Service View) -->
                <div class="p-5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-xs space-y-4">
                    <div class="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                        <i data-lucide="info" class="w-4 h-4 text-indigo-600 dark:text-indigo-400"></i>
                        <h4 class="font-bold text-slate-900 dark:text-white text-sm">Provident Fund Enrolment & Statutory Policy Rules</h4>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                        <div class="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/80">
                            <span class="text-[10px] uppercase font-bold text-slate-400 block">Enrolment Status</span>
                            <div class="mt-1 flex items-center gap-2">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold <?= $isPfApplicable ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300' : 'bg-slate-200 text-slate-800 dark:bg-slate-800 dark:text-slate-300' ?>">
                                    <?= esc($pfStatus) ?>
                                </span>
                            </div>
                        </div>
                        <div class="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/80">
                            <span class="text-[10px] uppercase font-bold text-slate-400 block">PF Account / Member ID</span>
                            <span class="text-sm font-mono font-bold text-slate-900 dark:text-white mt-1 block">
                                <?= esc($pfMemberId ?: 'Not Registered') ?>
                            </span>
                        </div>
                        <div class="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/80">
                            <span class="text-[10px] uppercase font-bold text-slate-400 block">Effective Date</span>
                            <span class="text-sm font-semibold text-slate-900 dark:text-white mt-1 block">
                                <?= esc($pfEffectiveDate ?: '-') ?>
                            </span>
                        </div>
                    </div>

                    <!-- Statutory Rule Parameters -->
                    <div class="p-4 rounded-xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 text-xs space-y-2">
                        <div class="font-bold text-indigo-900 dark:text-indigo-200 flex items-center gap-1.5">
                            <i data-lucide="scale" class="w-3.5 h-3.5 text-indigo-600"></i>
                            <span>Corporate Statutory Policy: <?= esc($pfRuleName) ?></span>
                        </div>
                        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-slate-700 dark:text-slate-300 text-[11px] pt-1">
                            <div>
                                <span class="text-slate-500 dark:text-slate-400 block">Employee Contribution Rate:</span>
                                <span class="font-bold text-slate-900 dark:text-white"><?= $pfContribType === 'Fixed' ? format_money($pfEmpFixed) : esc($pfEmpRate) . '%' ?></span>
                            </div>
                            <div>
                                <span class="text-slate-500 dark:text-slate-400 block">Employer Matching Rate:</span>
                                <span class="font-bold text-slate-900 dark:text-white"><?= $pfContribType === 'Fixed' ? format_money($pfCompFixed) : esc($pfCompRate) . '%' ?></span>
                            </div>
                            <div>
                                <span class="text-slate-500 dark:text-slate-400 block">Calculation Basis:</span>
                                <span class="font-bold text-slate-900 dark:text-white"><?= esc($resolvedPfRule ? $resolvedPfRule->get('calculation_basis') : 'Basic Salary') ?></span>
                            </div>
                        </div>
                        <p class="text-[10px] text-indigo-700 dark:text-indigo-300 pt-1 border-t border-indigo-100 dark:border-indigo-900/40">
                            * Statutory contributions are managed centrally by HR policy. Contributions are deducted and credited automatically during monthly payroll execution.
                        </p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>
