<!-- Bank & Payment Tab -->
<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-6">
    <div class="border-b border-slate-100 dark:border-slate-700 pb-4">
        <h3 class="font-bold text-slate-900 dark:text-white text-base">Bank Account & Disbursement Channels</h3>
        <p class="text-xs text-slate-500 mt-0.5">Direct deposit and electronic payroll disbursement settings</p>
    </div>

    <!-- Visual Bank Card Presentation -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <!-- Direct Deposit Bank Card -->
        <div class="p-5 rounded-2xl bg-gradient-to-br from-indigo-900 via-indigo-800 to-slate-900 text-white shadow-md space-y-4 relative overflow-hidden">
            <div class="flex items-center justify-between">
                <span class="text-xs font-mono font-bold tracking-widest text-indigo-300">SALARY DISBURSEMENT</span>
                <i data-lucide="landmark" class="w-6 h-6 text-indigo-300"></i>
            </div>
            <div class="space-y-1">
                <div class="text-[10px] text-indigo-300 uppercase tracking-wider">Account Number</div>
                <div class="text-lg font-mono font-bold tracking-wider"><?= esc(!empty($employee['bank_account']) ? $employee['bank_account'] : (!empty($bankAccount['account_number']) ? $bankAccount['account_number'] : '—')) ?></div>
            </div>
            <div class="flex items-center justify-between text-xs pt-2 border-t border-indigo-700/50">
                <div>
                    <span class="text-[9px] block text-indigo-300 uppercase">Bank Name</span>
                    <span class="font-bold"><?= esc(!empty($employee['bank_name']) ? $employee['bank_name'] : (!empty($bankAccount['bank_name']) ? $bankAccount['bank_name'] : '—')) ?></span>
                </div>
                <div>
                    <span class="text-[9px] block text-indigo-300 uppercase">Routing No</span>
                    <span class="font-mono font-bold"><?= esc(!empty($bankAccount['routing_number']) ? $bankAccount['routing_number'] : '—') ?></span>
                </div>
            </div>
        </div>

        <!-- Mobile Banking / Alternate Card -->
        <div class="p-5 rounded-2xl bg-gradient-to-br from-pink-900 via-rose-900 to-slate-900 text-white shadow-md space-y-4 relative overflow-hidden">
            <div class="flex items-center justify-between">
                <span class="text-xs font-mono font-bold tracking-widest text-pink-300">MFS WALLET</span>
                <i data-lucide="smartphone" class="w-6 h-6 text-pink-300"></i>
            </div>
            <div class="space-y-1">
                <div class="text-[10px] text-pink-300 uppercase tracking-wider">Mobile Wallet Number</div>
                <div class="text-lg font-mono font-bold tracking-wider"><?= esc(!empty($bankAccount['mobile_banking']) ? $bankAccount['mobile_banking'] : (!empty($employee['phone']) ? $employee['phone'] : '—')) ?></div>
            </div>
            <div class="flex items-center justify-between text-xs pt-2 border-t border-rose-700/50">
                <div>
                    <span class="text-[9px] block text-pink-300 uppercase">Wallet Provider</span>
                    <span class="font-bold"><?= esc(!empty($bankAccount['wallet_provider']) ? $bankAccount['wallet_provider'] : '—') ?></span>
                </div>
                <div>
                    <span class="text-[9px] block text-pink-300 uppercase">Default Channel</span>
                    <span class="font-bold"><?= esc($bankAccount['payment_method'] ?? 'Bank Transfer') ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Bank Details Form -->
    <form action="<?= base_url('employees/profile/' . $employee['id'] . '/update-bank') ?>" method="POST" class="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-700">
        <?= csrf_field() ?>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Bank Name</label>
                <input type="text" name="bank_name" value="<?= esc($employee['bank_name'] ?? ($bankAccount['bank_name'] ?? '')) ?>" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
            </div>

            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Branch Name</label>
                <input type="text" name="branch_name" value="<?= esc($bankAccount['branch_name'] ?? ($bankAccount['branch'] ?? '')) ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
            </div>

            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Account Title / Name</label>
                <input type="text" name="account_name" value="<?= esc($bankAccount['account_name'] ?? $employee['name'] ?? '') ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
            </div>

            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Bank Account Number</label>
                <input type="text" name="bank_account" value="<?= esc($employee['bank_account'] ?? ($bankAccount['account_number'] ?? '')) ?>" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono">
            </div>

            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Routing Number (Electronic Clearing)</label>
                <input type="text" name="routing_number" value="<?= esc($bankAccount['routing_number'] ?? '') ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono">
            </div>

            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">SWIFT / BIC Code</label>
                <input type="text" name="swift" value="<?= esc($bankAccount['swift_code'] ?? ($bankAccount['swift'] ?? '')) ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono">
            </div>

            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Mobile Banking Wallet No (MFS)</label>
                <input type="text" name="mobile_banking" value="<?= esc($bankAccount['mobile_banking'] ?? ($employee['phone'] ?? '')) ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono">
            </div>

            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Primary Payment Method</label>
                <select name="payment_method" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                    <option value="Bank Transfer" <?= ($bankAccount['payment_method'] ?? 'Bank Transfer') === 'Bank Transfer' ? 'selected' : '' ?>>Direct Bank Transfer</option>
                    <option value="Mobile Banking" <?= ($bankAccount['payment_method'] ?? '') === 'Mobile Banking' ? 'selected' : '' ?>>Mobile Financial Services (bKash/Nagad)</option>
                    <option value="Cheque" <?= ($bankAccount['payment_method'] ?? '') === 'Cheque' ? 'selected' : '' ?>>Corporate Cheque</option>
                    <option value="Cash" <?= ($bankAccount['payment_method'] ?? '') === 'Cash' ? 'selected' : '' ?>>Cash in Hand</option>
                </select>
            </div>
        </div>

        <div class="flex justify-end pt-4 border-t border-slate-100 dark:border-slate-700">
            <button type="submit" class="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition flex items-center gap-2">
                <i data-lucide="check" class="w-4 h-4"></i>
                <span>Save Bank & Payment Coordinates</span>
            </button>
        </div>
    </form>
</div>
