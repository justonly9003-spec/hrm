<!-- Promotion Tab -->
<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-6" x-data="{ showAddPromo: false }">
    <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-4">
        <div>
            <h3 class="font-bold text-slate-900 dark:text-white text-base">Promotions</h3>
            <p class="text-xs text-slate-500 mt-0.5">Career advancement trajectory and designation progression events</p>
        </div>
        <button type="button" @click="showAddPromo = true" class="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400 rounded-xl text-xs font-semibold border border-indigo-200 dark:border-indigo-800 flex items-center gap-1.5 transition">
            <i data-lucide="trending-up" class="w-3.5 h-3.5"></i>
            <span>Process Promotion</span>
        </button>
    </div>

    <!-- Promotions Timeline / Table -->
    <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse text-xs">
            <thead>
                <tr class="border-b border-slate-100 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 text-slate-500 font-medium">
                    <th class="py-3 px-4">Effective Date</th>
                    <th class="py-3 px-4">Previous Designation</th>
                    <th class="py-3 px-4">New Designation</th>
                    <th class="py-3 px-4">Previous Salary</th>
                    <th class="py-3 px-4">Revised Salary</th>
                    <th class="py-3 px-4">Reason / Notes</th>
                    <th class="py-3 px-4">Authorized By</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100 dark:divide-slate-700">
                <?php if (empty($promotions)): ?>
                    <tr>
                        <td colspan="7" class="py-8 text-center text-slate-400">
                            <i data-lucide="trending-up" class="w-8 h-8 mx-auto mb-2 text-slate-300"></i>
                            <p>No promotion records found.</p>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($promotions as $prm): ?>
                        <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                            <td class="py-3 px-4 font-mono"><?= esc($prm['promotion_date'] ?? $prm['effective_date'] ?? '2026-01-01') ?></td>
                            <td class="py-3 px-4 text-slate-500"><?= esc($prm['previous_designation_name'] ?? 'Associate') ?></td>
                            <td class="py-3 px-4 font-bold text-indigo-600 dark:text-indigo-400"><?= esc($prm['new_designation_name'] ?? $employee['designation_name'] ?? 'Senior Specialist') ?></td>
                            <td class="py-3 px-4 font-mono"><?= format_money((float)($prm['previous_salary'] ?? 0)) ?></td>
                            <td class="py-3 px-4 font-mono font-bold text-emerald-600 dark:text-emerald-400"><?= format_money((float)($prm['new_salary'] ?? $employee['basic_salary'] ?? 0)) ?></td>
                            <td class="py-3 px-4 max-w-xs truncate"><?= esc($prm['reason'] ?? 'Annual appraisal & milestone promotion') ?></td>
                            <td class="py-3 px-4 font-semibold text-slate-700 dark:text-slate-300"><?= esc($prm['approved_by'] ?? '-') ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Add Promotion Modal -->
    <div x-show="showAddPromo" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" style="display: none;">
        <div @click.away="showAddPromo = false" class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 w-full max-w-lg p-6 shadow-xl space-y-4">
            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                <h3 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                    <i data-lucide="trending-up" class="w-4 h-4 text-indigo-600"></i>
                    Record Employee Promotion & Increment
                </h3>
                <button type="button" @click="showAddPromo = false" class="text-slate-400 hover:text-slate-600">
                    <i data-lucide="x" class="w-4 h-4"></i>
                </button>
            </div>

            <form action="<?= base_url('employees/profile/' . $employee['id'] . '/promotion/add') ?>" method="POST" class="space-y-4 text-xs">
                <?= csrf_field() ?>
                
                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">New Upgraded Designation</label>
                    <select name="new_designation_id" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                        <?php foreach ($designations as $dsg): ?>
                            <option value="<?= esc($dsg['id']) ?>" <?= ($employee['designation_id'] ?? '') === $dsg['id'] ? 'selected' : '' ?>><?= esc($dsg['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <div class="flex items-center justify-between mb-1">
                            <label class="block font-semibold text-slate-700 dark:text-slate-300">Revised Basic Salary (<?= esc(app_currency_code($employee['company_id'] ?? null)) ?>)</label>
                            <a href="<?= base_url('employees/profile/' . $employee['id'] . '?tab=payroll') ?>" class="text-[11px] text-indigo-600 dark:text-indigo-400 font-semibold hover:underline flex items-center gap-0.5">
                                <span>Assign Tab</span>
                                <i data-lucide="external-link" class="w-3 h-3"></i>
                            </a>
                        </div>
                        <input type="number" step="0.01" min="0" name="new_salary" value="<?= number_format((float)($employee['basic_salary'] ?? 0), 2, '.', '') ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono">
                        <span class="text-[10px] text-slate-400 mt-1 block">Current salary shown. Enter revised basic salary or configure in <a href="<?= base_url('employees/profile/' . $employee['id'] . '?tab=payroll') ?>" class="text-indigo-600 underline">Salary tab</a>.</span>
                    </div>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Effective Date</label>
                        <input type="date" name="promotion_date" value="<?= date('Y-m-d') ?>" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                    </div>
                </div>

                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Justification & Appraisal Notes</label>
                    <textarea name="reason" rows="2" placeholder="Outstanding performance evaluation and leadership contributions" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"></textarea>
                </div>

                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Approved By</label>
                    <input type="text" name="approved_by" value="HR Management Committee" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                </div>

                <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-700">
                    <button type="button" @click="showAddPromo = false" class="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold">Cancel</button>
                    <button type="submit" class="px-4 py-2 rounded-xl bg-indigo-600 text-white font-semibold hover:bg-indigo-700 shadow-sm">Save & Apply Promotion</button>
                </div>
            </form>
        </div>
    </div>
</div>
