<!-- Termination Tab -->
<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-6">
    <div class="border-b border-slate-100 dark:border-slate-700 pb-4 flex items-center justify-between">
        <div>
            <h3 class="font-bold text-slate-900 dark:text-white text-base">Involuntary Termination & Separation</h3>
            <p class="text-xs text-slate-500 mt-0.5">Disciplinary, redundancy, contract expiration, or severance processing</p>
        </div>
        <span class="px-2.5 py-1 rounded-full text-xs font-semibold <?= !empty($termination) ? 'bg-rose-50 text-rose-700 border border-rose-200' : 'bg-slate-100 text-slate-600' ?>">
            <?= esc($termination ? 'Terminated Record' : 'No Separation Action') ?>
        </span>
    </div>

    <form action="<?= base_url('employees/profile/' . $employee['id'] . '/termination/save') ?>" method="POST" class="space-y-4 text-xs">
        <?= csrf_field() ?>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Official Termination Date</label>
                <input type="date" name="termination_date" value="<?= esc($termination['termination_date'] ?? date('Y-m-d')) ?>" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
            </div>

            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Notice Period / Severance Days</label>
                <input type="number" name="notice_period_days" value="<?= (int)($termination['notice_period_days'] ?? 30) ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono">
            </div>
        </div>

        <div>
            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Reason & Legal Grounds</label>
            <textarea name="reason" rows="2" placeholder="Document reasons, performance review failure, or mutual severance" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"><?= esc($termination['reason'] ?? '') ?></textarea>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Authorized By</label>
                <input type="text" name="approved_by" value="<?= esc($termination['approved_by'] ?? session()->get('name') ?? session()->get('username') ?? '') ?>" readonly class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50 text-slate-700 dark:text-slate-300">
            </div>
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Asset & Financial Clearance Status</label>
                <select name="clearance_status" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                    <option value="In Progress" <?= ($termination['clearance_status'] ?? 'In Progress') === 'In Progress' ? 'selected' : '' ?>>In Progress (Assets Pending)</option>
                    <option value="Completed" <?= ($termination['clearance_status'] ?? '') === 'Completed' ? 'selected' : '' ?>>Completed (All Cleared)</option>
                    <option value="On Hold" <?= ($termination['clearance_status'] ?? '') === 'On Hold' ? 'selected' : '' ?>>On Hold</option>
                </select>
            </div>
        </div>

        <div>
            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Exit Interview & HR Notes</label>
            <textarea name="exit_interview_notes" rows="2" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"><?= esc($termination['exit_interview_notes'] ?? '') ?></textarea>
        </div>

        <div class="flex justify-end pt-4 border-t border-slate-100 dark:border-slate-700">
            <button type="submit" onclick="return confirm('Confirm employee termination? This will set employee status to Terminated.')" class="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-sm transition flex items-center gap-2">
                <i data-lucide="shield-alert" class="w-4 h-4"></i>
                <span>Execute & Record Termination</span>
            </button>
        </div>
    </form>
</div>
