<!-- Employment Tab -->
<div class="space-y-6">
    <!-- 1. Core Coordinates & Period Configuration -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-6">
        <div class="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-700 pb-4">
            <div>
                <h3 class="font-bold text-slate-900 dark:text-white text-base">Employment & Lifecycle Coordinates</h3>
                <p class="text-xs text-slate-500 mt-0.5">Core organizational parameters and contract duration tracking</p>
            </div>
            <?php 
                $periodStatus = $employee['employment_period_status'] ?? 'Active';
                $statusColors = [
                    'Active'        => 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800',
                    'Expiring Soon' => 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-800',
                    'Completed'     => 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/40 dark:text-blue-400 dark:border-blue-800',
                    'Expired'       => 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/40 dark:text-rose-400 dark:border-rose-800',
                ];
                $badgeClass = $statusColors[$periodStatus] ?? 'bg-slate-50 text-slate-700 border-slate-200';
            ?>
            <div class="flex items-center gap-2">
                <span class="text-xs text-slate-500">Period Status:</span>
                <span class="px-2.5 py-1 text-xs font-bold rounded-full border <?= $badgeClass ?> flex items-center gap-1.5">
                    <span class="w-2 h-2 rounded-full <?= $periodStatus === 'Active' ? 'bg-emerald-500' : ($periodStatus === 'Expiring Soon' ? 'bg-amber-500' : ($periodStatus === 'Completed' ? 'bg-blue-500' : 'bg-rose-500')) ?>"></span>
                    <?= esc($periodStatus) ?>
                </span>
            </div>
        </div>

        <form action="<?= base_url('employees/profile/' . $employee['id'] . '/update-employment') ?>" method="POST" x-data="{
            durationEnabled: <?= !empty($employee['duration_enabled']) ? 'true' : 'false' ?>,
            durationValue: <?= (int)($employee['employment_duration_value'] ?? 6) ?>,
            durationUnit: '<?= esc($employee['employment_duration_unit'] ?? 'Months') ?>',
            autoCalculate: <?= !isset($employee['employment_auto_calculate']) || $employee['employment_auto_calculate'] ? 'true' : 'false' ?>,
            startDate: '<?= esc($employee['employment_start_date'] ?? (employee_joining_date($employee) ?? date('Y-m-d'))) ?>',
            endDate: '<?= esc($employee['employment_end_date'] ?? '') ?>',
            recalculate() {
                if (!this.durationEnabled || !this.autoCalculate || !this.startDate || this.durationValue <= 0) return;
                const d = new Date(this.startDate);
                if (this.durationUnit === 'Days') {
                    d.setDate(d.getDate() + parseInt(this.durationValue));
                } else if (this.durationUnit === 'Months') {
                    d.setMonth(d.getMonth() + parseInt(this.durationValue));
                } else if (this.durationUnit === 'Years') {
                    d.setFullYear(d.getFullYear() + parseInt(this.durationValue));
                }
                d.setDate(d.getDate() - 1);
                this.endDate = d.toISOString().split('T')[0];
            }
        }" class="space-y-6">
            <?= csrf_field() ?>
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Official Joining Date</label>
                    <input type="date" name="joining_date" value="<?= esc(employee_joining_date($employee) ?? '') ?>" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden">
                </div>

                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Confirmation Date</label>
                    <input type="date" name="confirmation_date" value="<?= esc($employee['confirmation_date'] ?? '') ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden">
                </div>

                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Employment Type Classification</label>
                    <select name="employment_type_id" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden">
                        <?php if (!empty($employmentTypes)): ?>
                            <?php foreach ($employmentTypes as $et): ?>
                                <option value="<?= esc($et['id']) ?>" <?= ($employee['employment_type_id'] ?? '') === $et['id'] ? 'selected' : '' ?>>
                                    <?= esc($et['name']) ?> (<?= esc($et['code'] ?? 'ET') ?>)
                                </option>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <option value="emptype-permanent" <?= ($employee['employment_type_id'] ?? '') === 'emptype-permanent' ? 'selected' : '' ?>>Permanent Full-Time</option>
                            <option value="emptype-contract" <?= ($employee['employment_type_id'] ?? '') === 'emptype-contract' ? 'selected' : '' ?>>Contractual Basis</option>
                            <option value="emptype-probation" <?= ($employee['employment_type_id'] ?? '') === 'emptype-probation' ? 'selected' : '' ?>>Probationary</option>
                            <option value="emptype-intern" <?= ($employee['employment_type_id'] ?? '') === 'emptype-intern' ? 'selected' : '' ?>>Internship</option>
                        <?php endif; ?>
                    </select>
                </div>

                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Working Shift</label>
                    <select name="shift_id" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden">
                        <?php if (!empty($shifts)): ?>
                            <?php foreach ($shifts as $sh): ?>
                                <option value="<?= esc($sh['id']) ?>" <?= ($employee['shift_id'] ?? '') === $sh['id'] ? 'selected' : '' ?>>
                                    <?= esc($sh['name']) ?> (<?= esc($sh['start_time']) ?> - <?= esc($sh['end_time']) ?>)
                                </option>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <option value="shift-general" selected>General Day Shift (09:00 - 18:00)</option>
                        <?php endif; ?>
                    </select>
                </div>

                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Employment Status</label>
                    <select name="status" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden">
                        <?php 
                        $curEmpStatus = \App\Models\EmployeeModel::normalizeStatus($employee['status'] ?? \App\Models\EmployeeModel::STATUS_ACTIVE, true);
                        foreach (\App\Models\EmployeeModel::STATUS_LABELS as $sVal => $sLabel): 
                        ?>
                            <option value="<?= esc($sVal) ?>" <?= $curEmpStatus === $sVal ? 'selected' : '' ?>><?= esc($sLabel) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Reporting Manager</label>
                    <input type="text" name="manager_name_display" value="<?= esc($employee['manager_name'] ?? 'Direct to Executive Board') ?>" readonly class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50 text-slate-700 dark:text-slate-300 cursor-not-allowed">
                </div>
            </div>

            <!-- Dynamic Employment Period & Duration Tracking Card -->
            <div class="p-5 rounded-2xl bg-indigo-50/40 dark:bg-indigo-950/20 border border-indigo-100 dark:border-slate-700 space-y-4">
                <div class="flex flex-wrap items-center justify-between gap-3">
                    <div class="flex items-center gap-2.5">
                        <div class="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center">
                            <i data-lucide="calendar-clock" class="w-4 h-4"></i>
                        </div>
                        <div>
                            <h4 class="text-xs font-bold text-slate-900 dark:text-white">Contract / Period Duration Tracking</h4>
                            <p class="text-[11px] text-slate-500">Configures period lifecycle, auto-calculation, and expiry notification reminders</p>
                        </div>
                    </div>
                    <label class="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" name="duration_enabled" value="1" x-model="durationEnabled" class="sr-only peer">
                        <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
                        <span class="ml-2 text-xs font-semibold text-slate-700 dark:text-slate-300">Enable Duration</span>
                    </label>
                </div>

                <div x-show="durationEnabled" class="pt-3 border-t border-indigo-100 dark:border-slate-700 space-y-4 text-xs">
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Period Start Date *</label>
                            <input type="date" name="employment_start_date" x-model="startDate" @change="recalculate()" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                        </div>

                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Duration Value</label>
                            <input type="number" min="1" name="employment_duration_value" x-model="durationValue" @input="recalculate()" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono text-slate-900 dark:text-white">
                        </div>

                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Duration Unit</label>
                            <select name="employment_duration_unit" x-model="durationUnit" @change="recalculate()" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                                <option value="Days">Days</option>
                                <option value="Months">Months</option>
                                <option value="Years">Years</option>
                            </select>
                        </div>

                        <div>
                            <div class="flex items-center justify-between mb-1.5">
                                <label class="font-semibold text-slate-700 dark:text-slate-300">Period End Date</label>
                                <label class="inline-flex items-center gap-1 text-[10px] text-slate-500 cursor-pointer">
                                    <input type="checkbox" name="employment_auto_calculate" value="1" x-model="autoCalculate" @change="recalculate()" class="rounded-sm border-slate-300 text-indigo-600">
                                    <span>Auto-Calc</span>
                                </label>
                            </div>
                            <input type="date" name="employment_end_date" x-model="endDate" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-indigo-100/60 dark:border-slate-700/60">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">HR Expiry Reminder (Days Before Completion)</label>
                            <input type="number" min="1" max="90" name="employment_expiry_reminder_days" value="<?= (int)($employee['employment_expiry_reminder_days'] ?? 15) ?>" placeholder="15" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono text-slate-900 dark:text-white">
                            <span class="text-[10px] text-slate-500 mt-1 block">HR will receive automatic notifications when period approaches this threshold.</span>
                        </div>

                        <!-- Remaining Days Metric -->
                        <?php 
                            $endDateVal = $employee['employment_end_date'] ?? null;
                            $remaining = null;
                            if ($endDateVal) {
                                $end = new \DateTime($endDateVal);
                                $now = new \DateTime(date('Y-m-d'));
                                $diff = (int)$now->diff($end)->format('%r%a');
                                $remaining = $diff;
                            }
                        ?>
                        <div class="p-3 rounded-xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700 flex items-center justify-between">
                            <div>
                                <span class="text-[11px] font-semibold text-slate-500 block">Remaining Period Time</span>
                                <?php if ($remaining !== null): ?>
                                    <span class="text-sm font-bold <?= $remaining < 0 ? 'text-rose-600' : ($remaining <= 15 ? 'text-amber-600' : 'text-emerald-600') ?>">
                                        <?= $remaining < 0 ? abs($remaining) . ' days expired' : ($remaining === 0 ? 'Expires today' : $remaining . ' days remaining') ?>
                                    </span>
                                <?php else: ?>
                                    <span class="text-xs text-slate-400">No active end date set</span>
                                <?php endif; ?>
                            </div>
                            <div class="text-right">
                                <span class="text-[10px] text-slate-400 block">Status Flag</span>
                                <span class="text-xs font-bold text-slate-700 dark:text-slate-300"><?= esc($periodStatus) ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="flex justify-end pt-2 border-t border-slate-100 dark:border-slate-700">
                <button type="submit" class="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition flex items-center gap-2">
                    <i data-lucide="check" class="w-4 h-4"></i>
                    <span>Save Employment Coordinates</span>
                </button>
            </div>
        </form>
    </div>

    <!-- 2. Contract Extension / Renewal Action Card -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-4" x-data="{ openExtend: false }">
        <div class="flex items-center justify-between">
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                    <i data-lucide="refresh-cw" class="w-4 h-4"></i>
                </div>
                <div>
                    <h4 class="font-bold text-slate-900 dark:text-white text-sm">Contract Renewal & Extension</h4>
                    <p class="text-xs text-slate-500">Extend probation, renew contractual specialist term, or adjust period</p>
                </div>
            </div>
            <button type="button" @click="openExtend = !openExtend" class="px-3.5 py-1.5 rounded-xl text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 transition flex items-center gap-1.5">
                <i data-lucide="plus" class="w-3.5 h-3.5"></i>
                <span x-text="openExtend ? 'Cancel' : 'Extend / Renew Period'"></span>
            </button>
        </div>

        <div x-show="openExtend" x-cloak class="pt-4 border-t border-slate-100 dark:border-slate-700">
            <form action="<?= base_url('master/employment-types/extend/' . $employee['id']) ?>" method="POST" class="space-y-4 text-xs">
                <?= csrf_field() ?>
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Action Type</label>
                        <select name="action_type" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                            <option value="Renewal">Contract Renewal</option>
                            <option value="Extension">Period Extension</option>
                            <option value="Manual Override">Manual Override</option>
                        </select>
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Add Duration Value</label>
                        <input type="number" min="1" name="duration_value" value="6" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono text-slate-900 dark:text-white">
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Duration Unit</label>
                        <select name="duration_unit" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                            <option value="Months" selected>Months</option>
                            <option value="Days">Days</option>
                            <option value="Years">Years</option>
                        </select>
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Manual End Date Override (Optional)</label>
                        <input type="date" name="end_date" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                    </div>
                </div>

                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Reason & Evaluation Remarks *</label>
                    <textarea name="remarks" required rows="2" placeholder="e.g. 6-month probation extension granted based on Q2 performance review..." class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"></textarea>
                </div>

                <div class="flex justify-end">
                    <button type="submit" class="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm transition flex items-center gap-1.5">
                        <i data-lucide="check" class="w-3.5 h-3.5"></i>
                        <span>Apply Extension / Renewal</span>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- 3. Employment Contract Lifecycle History Timeline -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-4">
        <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
            <div class="flex items-center gap-2">
                <i data-lucide="history" class="w-4 h-4 text-slate-500"></i>
                <h4 class="font-bold text-slate-900 dark:text-white text-sm">Employment Period Lifecycle History</h4>
            </div>
            <span class="text-xs text-slate-400 font-mono"><?= count($employmentHistories ?? []) ?> Record(s)</span>
        </div>

        <?php if (empty($employmentHistories)): ?>
            <div class="py-8 text-center text-xs text-slate-400">
                No contract lifecycle records logged yet. Updates to employment duration will appear here.
            </div>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead>
                        <tr class="border-b border-slate-100 dark:border-slate-700 text-slate-400 uppercase text-[10px]">
                            <th class="py-2.5 px-3">Date</th>
                            <th class="py-2.5 px-3">Action</th>
                            <th class="py-2.5 px-3">Employment Type</th>
                            <th class="py-2.5 px-3">Period Window</th>
                            <th class="py-2.5 px-3">Status</th>
                            <th class="py-2.5 px-3">Actor</th>
                            <th class="py-2.5 px-3">Remarks</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-700/60 text-slate-700 dark:text-slate-300">
                        <?php foreach ($employmentHistories as $h): ?>
                            <tr>
                                <td class="py-2.5 px-3 font-mono text-[11px] text-slate-500">
                                    <?= date('Y-m-d H:i', strtotime($h['created_at'])) ?>
                                </td>
                                <td class="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">
                                    <?= esc($h['action_type'] ?? 'Assignment') ?>
                                </td>
                                <td class="py-2.5 px-3">
                                    <?= esc($h['employment_type_name'] ?? 'General') ?>
                                </td>
                                <td class="py-2.5 px-3 font-mono text-[11px]">
                                    <?= esc($h['start_date'] ?? '-') ?> → <?= esc($h['end_date'] ?? 'Ongoing') ?>
                                </td>
                                <td class="py-2.5 px-3">
                                    <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                                        <?= esc($h['status'] ?? 'Active') ?>
                                    </span>
                                </td>
                                <td class="py-2.5 px-3 text-slate-500">
                                    <?= esc($h['created_by_name'] ?? 'HR Admin') ?>
                                </td>
                                <td class="py-2.5 px-3 text-slate-500 max-w-xs truncate" title="<?= esc($h['remarks'] ?? '') ?>">
                                    <?= esc($h['remarks'] ?? '-') ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

