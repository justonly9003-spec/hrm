<!-- Transfer Tab -->
<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-6" x-data="{ showAddTransfer: false }">
    <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-4">
        <div>
            <h3 class="font-bold text-slate-900 dark:text-white text-base">Department & Branch Transfers</h3>
            <p class="text-xs text-slate-500 mt-0.5">Internal movement across branches, units, and departments</p>
        </div>
        <button type="button" @click="showAddTransfer = true" class="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400 rounded-xl text-xs font-semibold border border-indigo-200 dark:border-indigo-800 flex items-center gap-1.5 transition">
            <i data-lucide="arrow-left-right" class="w-3.5 h-3.5"></i>
            <span>Process Transfer</span>
        </button>
    </div>

    <!-- Transfers Table -->
    <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse text-xs">
            <thead>
                <tr class="border-b border-slate-100 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 text-slate-500 font-medium">
                    <th class="py-3 px-4">Transfer Date</th>
                    <th class="py-3 px-4">Branch (From &rarr; To)</th>
                    <th class="py-3 px-4">Department (From &rarr; To)</th>
                    <th class="py-3 px-4">Designation</th>
                    <th class="py-3 px-4">Reason</th>
                    <th class="py-3 px-4">Authorized By</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100 dark:divide-slate-700">
                <?php if (empty($transfers)): ?>
                    <tr>
                        <td colspan="6" class="py-8 text-center text-slate-400">
                            <i data-lucide="arrow-left-right" class="w-8 h-8 mx-auto mb-2 text-slate-300"></i>
                            <p>No department or branch transfer history recorded.</p>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($transfers as $trf): ?>
                        <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                            <td class="py-3 px-4 font-mono"><?= esc($trf['transfer_date']) ?></td>
                            <td class="py-3 px-4">
                                <div class="font-medium text-slate-900 dark:text-white"><?= esc($trf['from_branch_name'] ?? 'Headquarters') ?> &rarr; <span class="text-indigo-600 dark:text-indigo-400 font-bold"><?= esc($trf['to_branch_name'] ?? 'Regional Branch') ?></span></div>
                            </td>
                            <td class="py-3 px-4">
                                <div><?= esc($trf['from_dept_name'] ?? 'General') ?> &rarr; <span class="font-semibold text-slate-800 dark:text-slate-200"><?= esc($trf['to_dept_name'] ?? 'Operations') ?></span></div>
                            </td>
                            <td class="py-3 px-4 text-slate-600 dark:text-slate-300"><?= esc($trf['to_desg_name'] ?? $employee['designation_name'] ?? 'Specialist') ?></td>
                            <td class="py-3 px-4 max-w-xs truncate"><?= esc($trf['reason'] ?? 'Operational restructuring') ?></td>
                            <td class="py-3 px-4 text-slate-500 font-semibold"><?= esc($trf['approved_by'] ?? '-') ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Add Transfer Modal -->
    <div x-show="showAddTransfer" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" style="display: none;">
        <div @click.away="showAddTransfer = false" class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 w-full max-w-lg p-6 shadow-xl space-y-4">
            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                <h3 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                    <i data-lucide="arrow-left-right" class="w-4 h-4 text-indigo-600"></i>
                    Initiate Employee Transfer
                </h3>
                <button type="button" @click="showAddTransfer = false" class="text-slate-400 hover:text-slate-600">
                    <i data-lucide="x" class="w-4 h-4"></i>
                </button>
            </div>

            <form action="<?= base_url('employees/profile/' . $employee['id'] . '/transfer/add') ?>" method="POST" class="space-y-4 text-xs">
                <?= csrf_field() ?>
                
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Target Branch</label>
                        <select name="to_branch_id" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                            <?php foreach ($branches as $br): ?>
                                <option value="<?= esc($br['id']) ?>"><?= esc($br['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Target Department</label>
                        <select name="to_department_id" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                            <?php foreach ($departments as $dp): ?>
                                <option value="<?= esc($dp['id']) ?>"><?= esc($dp['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Target Designation</label>
                        <select name="to_designation_id" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                            <?php foreach ($designations as $dsg): ?>
                                <option value="<?= esc($dsg['id']) ?>" <?= ($employee['designation_id'] ?? '') === $dsg['id'] ? 'selected' : '' ?>><?= esc($dsg['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Transfer Date</label>
                        <input type="date" name="transfer_date" value="<?= date('Y-m-d') ?>" required class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                    </div>
                </div>

                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Transfer Reason / Management Note</label>
                    <textarea name="reason" rows="2" placeholder="Strategic branch realignment and capacity building" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"></textarea>
                </div>

                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Authorized By</label>
                    <input type="text" name="approved_by" value="<?= esc(session()->get('name') ?? session()->get('username') ?? '') ?>" readonly class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50 text-slate-700 dark:text-slate-300">
                </div>

                <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-700">
                    <button type="button" @click="showAddTransfer = false" class="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold">Cancel</button>
                    <button type="submit" class="px-4 py-2 rounded-xl bg-indigo-600 text-white font-semibold hover:bg-indigo-700 shadow-sm">Confirm Transfer</button>
                </div>
            </form>
        </div>
    </div>
</div>
