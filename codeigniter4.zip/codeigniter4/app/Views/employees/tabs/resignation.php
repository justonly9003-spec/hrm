<!-- Resignation Tab -->
<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-6">
    <div class="border-b border-slate-100 dark:border-slate-700 pb-4 flex items-center justify-between">
        <div>
            <h3 class="font-bold text-slate-900 dark:text-white text-base">Voluntary Resignation Workflow</h3>
            <p class="text-xs text-slate-500 mt-0.5">Formal employee separation notice, clearance, and handover status</p>
        </div>
        <span class="px-2.5 py-1 rounded-full text-xs font-semibold <?= !empty($resignation) && $resignation['status'] === 'Approved' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-slate-100 text-slate-600' ?>">
            <?= esc($resignation['status'] ?? 'No Active Resignation') ?>
        </span>
    </div>

    <form action="<?= base_url('employees/profile/' . $employee['id'] . '/resignation/save') ?>" method="POST" class="space-y-4 text-xs">
        <?= csrf_field() ?>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Notice Submission Date</label>
                <input type="date" name="submission_date" value="<?= esc($resignation['submission_date'] ?? date('Y-m-d')) ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
            </div>

            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Notice Effective Date</label>
                <input type="date" name="notice_date" value="<?= esc($resignation['notice_date'] ?? date('Y-m-d')) ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
            </div>

            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Intended Last Working Day</label>
                <input type="date" name="resignation_date" value="<?= esc($resignation['resignation_date'] ?? date('Y-m-d', strtotime('+30 days'))) ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
            </div>
        </div>

        <div>
            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Reason for Resignation</label>
            <textarea name="reason" rows="2" placeholder="e.g. Relocating abroad / Better career opportunity" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"><?= esc($resignation['reason'] ?? '') ?></textarea>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Manager Feedback & Handover Note</label>
                <textarea name="manager_review" rows="2" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"><?= esc($resignation['manager_review'] ?? '') ?></textarea>
            </div>
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">HR Operations Review</label>
                <textarea name="hr_review" rows="2" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"><?= esc($resignation['hr_review'] ?? '') ?></textarea>
            </div>
        </div>

        <div>
            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Approval Status</label>
            <select name="status" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                <option value="Pending" <?= ($resignation['status'] ?? 'Pending') === 'Pending' ? 'selected' : '' ?>>Pending Review</option>
                <option value="Approved" <?= ($resignation['status'] ?? '') === 'Approved' ? 'selected' : '' ?>>Approved (Update Status to Resigned)</option>
                <option value="Rejected" <?= ($resignation['status'] ?? '') === 'Rejected' ? 'selected' : '' ?>>Rejected / Retained</option>
            </select>
        </div>

        <div class="flex justify-end pt-4 border-t border-slate-100 dark:border-slate-700">
            <button type="submit" class="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition flex items-center gap-2">
                <i data-lucide="check" class="w-4 h-4"></i>
                <span>Save Resignation Details</span>
            </button>
        </div>
    </form>
</div>
