<!-- Attendance Tab -->
<div class="space-y-6">
    <!-- Shift & Working Hours Policy Badge -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-5 shadow-xs">
        <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
            <h3 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                <i data-lucide="clock" class="w-4 h-4 text-indigo-600"></i>
                Shift & Attendance Policy Guidelines
            </h3>
            <a href="<?= base_url('attendance') ?>" class="text-xs text-indigo-600 hover:text-indigo-700 font-semibold flex items-center gap-1">
                <span>Go to Attendance Module</span>
                <i data-lucide="external-link" class="w-3.5 h-3.5"></i>
            </a>
        </div>
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4 text-xs">
            <div class="p-3 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700">
                <span class="text-slate-400 block font-semibold text-[11px]">Assigned Shift</span>
                <span class="font-bold text-slate-900 dark:text-white mt-0.5 block"><?= esc($employee['shift_name'] ?? 'General Shift') ?></span>
            </div>
            <div class="p-3 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700">
                <span class="text-slate-400 block font-semibold text-[11px]">Standard Hours</span>
                <span class="font-bold text-slate-900 dark:text-white font-mono mt-0.5 block">09:00 - 18:00</span>
            </div>
            <div class="p-3 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700">
                <span class="text-slate-400 block font-semibold text-[11px]">Late Grace Period</span>
                <span class="font-bold text-slate-900 dark:text-white font-mono mt-0.5 block">15 Minutes</span>
            </div>
            <div class="p-3 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700">
                <span class="text-slate-400 block font-semibold text-[11px]">Overtime Eligibility</span>
                <span class="font-bold text-emerald-600 dark:text-emerald-400 mt-0.5 block">Eligible (1.5x)</span>
            </div>
        </div>
    </div>

    <!-- Attendance History Table -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-xs">
        <div class="p-5 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between">
            <div>
                <h3 class="font-bold text-slate-900 dark:text-white text-base">Monthly Punch Logs</h3>
                <p class="text-xs text-slate-500 mt-0.5">Biometric, RFID card, and mobile GPS clock-in logs</p>
            </div>
            <span class="text-xs text-slate-400 font-mono">Last 30 days</span>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-xs">
                <thead>
                    <tr class="border-b border-slate-100 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 text-slate-500 font-medium">
                        <th class="py-3 px-4">Date</th>
                        <th class="py-3 px-4">Day</th>
                        <th class="py-3 px-4">In Time</th>
                        <th class="py-3 px-4">Out Time</th>
                        <th class="py-3 px-4">Total Hours</th>
                        <th class="py-3 px-4">Overtime</th>
                        <th class="py-3 px-4">Punch Source</th>
                        <th class="py-3 px-4">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-700">
                    <?php if (empty($attendance)): ?>
                        <tr><td colspan="8" class="py-8 text-center text-slate-400">No punch records found for this employee.</td></tr>
                    <?php else: ?>
                        <?php foreach ($attendance as $att): ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                                <td class="py-3 px-4 font-mono font-medium"><?= esc($att['date']) ?></td>
                                <td class="py-3 px-4 text-slate-500"><?= date('D', strtotime($att['date'])) ?></td>
                                <td class="py-3 px-4 font-mono"><?= esc($att['check_in'] ?? '--:--') ?></td>
                                <td class="py-3 px-4 font-mono"><?= esc($att['check_out'] ?? '--:--') ?></td>
                                <td class="py-3 px-4 font-mono"><?= number_format((float)($att['working_hours'] ?? 0), 2) ?> hrs</td>
                                <td class="py-3 px-4 font-mono text-emerald-600"><?= number_format((float)($att['overtime_hours'] ?? 0), 2) ?> hrs</td>
                                <td class="py-3 px-4 text-slate-500 font-medium"><?= esc($att['punch_source'] ?? 'ZKTeco Bio') ?></td>
                                <td class="py-3 px-4">
                                    <span class="px-2 py-0.5 rounded text-[10px] font-bold <?= ($att['status'] ?? 'Present') === 'Present' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' : (($att['status'] ?? '') === 'Late' ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800') ?>">
                                        <?= esc($att['status'] ?? 'Present') ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
