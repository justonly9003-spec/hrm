<!-- Login & Security Credentials Tab -->
<div class="space-y-6" x-data="{ showPass: false, showNewPass: false }">
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-6">
        <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-4">
            <div>
                <h3 class="font-bold text-slate-900 dark:text-white text-base">User Account & Authentication Credentials</h3>
                <p class="text-xs text-slate-500 mt-0.5">System login ID, employee portal credentials, and password access management</p>
            </div>
            <span class="px-2.5 py-1 rounded-full text-xs font-semibold <?= !empty($userAccount['is_active']) || !empty($employee['is_active']) ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-200' : 'bg-slate-100 text-slate-600' ?>">
                <?= (!empty($userAccount['is_active']) || !empty($employee['is_active'])) ? 'Account Active' : 'Active Account' ?>
            </span>
        </div>

        <!-- Account Overview Card with User ID and Password highlight -->
        <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700">
            <h4 class="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-3">
                <i data-lucide="shield-check" class="w-4 h-4 text-indigo-600"></i>
                Active Login Account Identifiers
            </h4>
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                <div class="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                    <span class="text-[11px] text-slate-400 font-semibold uppercase block">User ID / Username</span>
                    <span class="font-mono font-bold text-slate-900 dark:text-white text-sm mt-0.5 block"><?= esc($userAccount['username'] ?? $employee['employee_code'] ?? 'admin@gmail.com') ?></span>
                </div>
                <div class="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                    <span class="text-[11px] text-slate-400 font-semibold uppercase block">Login Email</span>
                    <span class="font-mono font-bold text-indigo-600 dark:text-indigo-400 text-sm mt-0.5 block truncate"><?= esc($userAccount['email'] ?? $employee['email'] ?? 'admin@gmail.com') ?></span>
                </div>
                <div class="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                    <span class="text-[11px] text-slate-400 font-semibold uppercase block">Assigned Role</span>
                    <span class="font-bold text-slate-900 dark:text-white text-sm mt-0.5 block"><?= esc($userAccount['role_name'] ?? $employee['role_name'] ?? 'Employee / Administrator') ?></span>
                </div>
            </div>
        </div>

        <!-- Password Reset Form -->
        <form action="<?= base_url('employees/profile/' . $employee['id'] . '/update-password') ?>" method="POST" class="space-y-4 pt-2">
            <?= csrf_field() ?>
            
            <h4 class="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <i data-lucide="key" class="w-4 h-4 text-indigo-600"></i>
                Update Portal Password
            </h4>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">New Password</label>
                    <div class="relative">
                        <input :type="showNewPass ? 'text' : 'password'" name="password" required minlength="6" placeholder="Enter minimum 6 characters..." class="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white pr-10 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden font-mono">
                        <button type="button" @click="showNewPass = !showNewPass" class="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                            <i data-lucide="eye" x-show="!showNewPass" class="w-4 h-4"></i>
                            <i data-lucide="eye-off" x-show="showNewPass" class="w-4 h-4" style="display: none;"></i>
                        </button>
                    </div>
                </div>

                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Confirm New Password</label>
                    <div class="relative">
                        <input :type="showNewPass ? 'text' : 'password'" name="confirm_password" required minlength="6" placeholder="Re-type new password..." class="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white pr-10 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden font-mono">
                    </div>
                </div>
            </div>

            <div class="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-700">
                <span class="text-[11px] text-slate-400">Password change will be recorded in security audit trail.</span>
                <button type="submit" class="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition flex items-center gap-2">
                    <i data-lucide="lock" class="w-4 h-4"></i>
                    <span>Set New Password</span>
                </button>
            </div>
        </form>
    </div>
</div>
