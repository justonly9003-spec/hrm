<!-- Address Tab -->
<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-6" x-data="{
    sameAsPresent: false,
    presentAddr: '<?= esc($employee['address'] ?? '') ?>',
    permanentAddr: '<?= esc($employee['permanent_address'] ?? $employee['address'] ?? '') ?>'
}">
    <div class="border-b border-slate-100 dark:border-slate-700 pb-4">
        <h3 class="font-bold text-slate-900 dark:text-white text-base">Address & Location Details</h3>
        <p class="text-xs text-slate-500 mt-0.5">Present and permanent residence coordinates</p>
    </div>

    <form action="<?= base_url('employees/profile/' . $employee['id'] . '/update-address') ?>" method="POST" class="space-y-6">
        <?= csrf_field() ?>
        
        <!-- Present Address -->
        <div class="space-y-4">
            <h4 class="font-bold text-slate-900 dark:text-white text-xs flex items-center gap-2">
                <i data-lucide="map-pin" class="w-4 h-4 text-indigo-600"></i>
                Present Address (Current Residence)
            </h4>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div class="md:col-span-2">
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Street / Holding / Area</label>
                    <input type="text" name="present_address" x-model="presentAddr" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden">
                </div>
                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Division / State</label>
                    <input type="text" name="present_division" value="<?= esc($employee['present_division'] ?? 'Dhaka') ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                </div>
                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">District / City</label>
                    <input type="text" name="present_district" value="<?= esc($employee['present_district'] ?? 'Dhaka') ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                </div>
                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Thana / Upazila</label>
                    <input type="text" name="present_upazila" value="<?= esc($employee['present_upazila'] ?? 'Gulshan') ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                </div>
                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Postal Code</label>
                    <input type="text" name="present_post_code" value="<?= esc($employee['present_post_code'] ?? '1212') ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                </div>
            </div>
        </div>

        <!-- Permanent Address -->
        <div class="pt-4 border-t border-slate-100 dark:border-slate-700 space-y-4">
            <div class="flex items-center justify-between">
                <h4 class="font-bold text-slate-900 dark:text-white text-xs flex items-center gap-2">
                    <i data-lucide="home" class="w-4 h-4 text-emerald-600"></i>
                    Permanent Address
                </h4>
                <label class="flex items-center gap-2 text-xs font-semibold text-indigo-600 cursor-pointer">
                    <input type="checkbox" x-model="sameAsPresent" @change="if (sameAsPresent) permanentAddr = presentAddr" class="rounded border-slate-300 text-indigo-600">
                    <span>Same as Present Address</span>
                </label>
            </div>
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5 text-xs">Permanent Address Details</label>
                <textarea name="permanent_address" x-model="permanentAddr" rows="3" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden"></textarea>
            </div>
        </div>

        <div class="flex justify-end pt-4 border-t border-slate-100 dark:border-slate-700">
            <button type="submit" class="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition flex items-center gap-2">
                <i data-lucide="check" class="w-4 h-4"></i>
                <span>Save Addresses</span>
            </button>
        </div>
    </form>
</div>
