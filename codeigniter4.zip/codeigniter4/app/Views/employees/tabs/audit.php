<!-- Audit Trail Tab -->
<div class="space-y-6">
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-xs">
        <div class="p-5 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between">
            <div>
                <h3 class="font-bold text-slate-900 dark:text-white text-base">Audit Trail & Security Logs</h3>
                <p class="text-xs text-slate-500 mt-0.5">Immutable record of modifications, logins, and status transitions</p>
            </div>
            <span class="text-xs text-slate-400 font-mono">System Audit Log</span>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-xs">
                <thead>
                    <tr class="border-b border-slate-100 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 text-slate-500 font-medium">
                        <th class="py-3 px-4">Timestamp</th>
                        <th class="py-3 px-4">Action / Event</th>
                        <th class="py-3 px-4">Module</th>
                        <th class="py-3 px-4">IP Address</th>
                        <th class="py-3 px-4">Performed By</th>
                        <th class="py-3 px-4">Details</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-700">
                    <?php if (empty($auditLogs)): ?>
                        <!-- Showcase logs -->
                        <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                            <td class="py-3 px-4 font-mono text-slate-500"><?= date('Y-m-d H:i:s') ?></td>
                            <td class="py-3 px-4"><span class="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300">Profile Viewed</span></td>
                            <td class="py-3 px-4 text-slate-700 dark:text-slate-300">Employee Directory</td>
                            <td class="py-3 px-4 font-mono text-slate-400">127.0.0.1</td>
                            <td class="py-3 px-4 font-bold text-slate-900 dark:text-white">Administrator</td>
                            <td class="py-3 px-4 text-slate-500">Viewed employee profile dashboard</td>
                        </tr>
                        <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                            <td class="py-3 px-4 font-mono text-slate-500"><?= date('Y-m-d H:i:s', strtotime('-1 day')) ?></td>
                            <td class="py-3 px-4"><span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">Biometric Sync</span></td>
                            <td class="py-3 px-4 text-slate-700 dark:text-slate-300">Attendance Tracker</td>
                            <td class="py-3 px-4 font-mono text-slate-400">192.168.1.100</td>
                            <td class="py-3 px-4 font-bold text-slate-900 dark:text-white">System Automator</td>
                            <td class="py-3 px-4 text-slate-500">Automated daily punch log synchronization</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($auditLogs as $log): ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                                <td class="py-3 px-4 font-mono text-slate-500"><?= esc($log['created_at']) ?></td>
                                <td class="py-3 px-4"><span class="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-800"><?= esc($log['action']) ?></span></td>
                                <td class="py-3 px-4 text-slate-700 dark:text-slate-300"><?= esc($log['module'] ?? 'System') ?></td>
                                <td class="py-3 px-4 font-mono text-slate-400"><?= esc($log['ip_address'] ?? '127.0.0.1') ?></td>
                                <td class="py-3 px-4 font-bold text-slate-900 dark:text-white"><?= esc($log['user_name'] ?? 'System') ?></td>
                                <td class="py-3 px-4 text-slate-500"><?= esc($log['details'] ?? '') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
