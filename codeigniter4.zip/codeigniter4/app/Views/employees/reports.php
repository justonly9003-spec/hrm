<div class="space-y-6">

    <!-- Header Section -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <div class="flex items-center gap-2 mb-1">
                <span class="text-[11px] font-bold px-2.5 py-0.5 rounded-md bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60">
                    Talent Analytics & Compliance
                </span>
                <span class="text-[11px] text-slate-400 font-mono">
                    <?= !empty($isSoftwareAdmin) ? 'Multi-Tenant Reporting' : 'Enterprise Intelligence' ?>
                </span>
            </div>
            <h2 class="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">Workforce Reports Hub</h2>
            <p class="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                Authoritative personnel metrics: headcount, attrition rate, new joiners & separations, document expiry, and mobility history.
            </p>
        </div>

        <div class="flex items-center gap-2.5">
            <a href="<?= base_url('employees/reports/export/' . $reportType) ?>" class="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/60 shadow-2xs transition">
                <i data-lucide="download" class="w-4 h-4 text-slate-500"></i>
                <span>Export CSV</span>
            </a>
            <a href="<?= base_url('employees') ?>" class="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 transition">
                <i data-lucide="users" class="w-4 h-4"></i>
                <span>Directory</span>
            </a>
        </div>
    </div>

    <!-- Shared Employees Module Navigation Tabs -->
    <?= view('employees/_tabs', ['activeTab' => 'directory']) ?>

    <!-- Report Types Sub-Nav Tabs -->
    <div class="flex items-center gap-2 border-b border-slate-200 dark:border-slate-700 pb-2 overflow-x-auto scrollbar-none">
        <?php
        $reportsList = [
            ['id' => 'headcount', 'label' => 'Headcount Summary', 'icon' => 'users'],
            ['id' => 'joiners_separations', 'label' => 'Joiners & Separations', 'icon' => 'arrow-left-right'],
            ['id' => 'probation', 'label' => 'Probation Expiry', 'icon' => 'user-check'],
            ['id' => 'document_expiry', 'label' => 'Document Expiry', 'icon' => 'file-text'],
            ['id' => 'movements', 'label' => 'Promotion & Transfer History', 'icon' => 'trending-up'],
            ['id' => 'attrition', 'label' => 'Attrition Rate & Turnover', 'icon' => 'pie-chart'],
        ];
        ?>
        <?php foreach ($reportsList as $r): ?>
            <?php $isActive = ($reportType === $r['id']); ?>
            <a href="<?= base_url('employees/reports/' . $r['id']) ?>" 
               class="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition shrink-0 <?= $isActive ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800' ?>">
                <i data-lucide="<?= $r['icon'] ?>" class="w-4 h-4"></i>
                <span><?= esc($r['label']) ?></span>
            </a>
        <?php endforeach; ?>
    </div>

    <!-- Report Content Rendering -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-2xs space-y-4">
        
        <!-- HEADCOUNT -->
        <?php if ($reportType === 'headcount'): ?>
            <h3 class="font-bold text-slate-900 dark:text-white text-base">Department & Branch Headcount Distribution</h3>
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead class="bg-slate-50 dark:bg-slate-900 text-slate-500 font-semibold uppercase text-[10px]">
                        <tr>
                            <th class="py-2.5 px-3">Branch Location</th>
                            <th class="py-2.5 px-3">Department</th>
                            <th class="py-2.5 px-3">Status</th>
                            <th class="py-2.5 px-3 text-right">Headcount Count</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-700">
                        <?php foreach ($reportData as $row): ?>
                            <tr>
                                <td class="py-2 px-3 font-medium text-slate-900 dark:text-white"><?= esc($row['branch_name'] ?: 'Headquarters') ?></td>
                                <td class="py-2 px-3 text-slate-600 dark:text-slate-400"><?= esc($row['department_name'] ?: 'General') ?></td>
                                <td class="py-2 px-3">
                                    <span class="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400"><?= esc($row['status']) ?></span>
                                </td>
                                <td class="py-2 px-3 font-mono font-bold text-slate-900 dark:text-white text-right"><?= (int)$row['count'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        <!-- ATTRITION RATE -->
        <?php elseif ($reportType === 'attrition'): ?>
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                    <div class="text-xs text-slate-400 font-medium">Active Workforce</div>
                    <div class="text-2xl font-bold text-emerald-600 mt-1"><?= $reportData['active'] ?? 0 ?></div>
                </div>
                <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                    <div class="text-xs text-slate-400 font-medium">Separated Personnel</div>
                    <div class="text-2xl font-bold text-rose-600 mt-1"><?= $reportData['separated'] ?? 0 ?></div>
                </div>
                <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                    <div class="text-xs text-slate-400 font-medium">Total Lifetime Workforce</div>
                    <div class="text-2xl font-bold text-slate-800 dark:text-slate-200 mt-1"><?= $reportData['total'] ?? 0 ?></div>
                </div>
                <div class="p-4 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800">
                    <div class="text-xs text-indigo-600 dark:text-indigo-400 font-medium">Annualized Attrition Rate</div>
                    <div class="text-3xl font-extrabold text-indigo-700 dark:text-indigo-300 mt-1"><?= $reportData['attrition_rate'] ?? 0 ?>%</div>
                </div>
            </div>

        <!-- JOINERS & SEPARATIONS -->
        <?php elseif ($reportType === 'joiners_separations'): ?>
            <div class="space-y-6">
                <div>
                    <h3 class="font-bold text-slate-900 dark:text-white text-base mb-2">New Joiners (<?= esc($year) ?>)</h3>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-xs">
                            <thead class="bg-slate-50 dark:bg-slate-900 text-slate-500 font-semibold uppercase text-[10px]">
                                <tr>
                                    <th class="py-2.5 px-3">Employee</th>
                                    <th class="py-2.5 px-3">Branch</th>
                                    <th class="py-2.5 px-3">Department</th>
                                    <th class="py-2.5 px-3">Joining Date</th>
                                    <th class="py-2.5 px-3">Status</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-slate-700">
                                <?php if (empty($reportData['joiners'])): ?>
                                    <tr><td colspan="5" class="py-4 text-center text-slate-400">No joiners recorded in <?= esc($year) ?>.</td></tr>
                                <?php else: ?>
                                    <?php foreach ($reportData['joiners'] as $j): ?>
                                        <tr>
                                            <td class="py-2 px-3 font-medium text-slate-900 dark:text-white">
                                                <?= esc(trim(($j['first_name'] ?? '') . ' ' . ($j['last_name'] ?? ''))) ?>
                                                <span class="text-[10px] text-slate-400 font-mono">(<?= esc($j['employee_code']) ?>)</span>
                                            </td>
                                            <td class="py-2 px-3 text-slate-600 dark:text-slate-400"><?= esc($j['branch_name'] ?: 'N/A') ?></td>
                                            <td class="py-2 px-3 text-slate-600 dark:text-slate-400"><?= esc($j['department_name'] ?: 'N/A') ?></td>
                                            <td class="py-2 px-3 font-mono"><?= esc($j['joining_date']) ?></td>
                                            <td class="py-2 px-3">
                                                <span class="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400"><?= esc($j['status']) ?></span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div>
                    <h3 class="font-bold text-slate-900 dark:text-white text-base mb-2">Separations (<?= esc($year) ?>)</h3>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-xs">
                            <thead class="bg-slate-50 dark:bg-slate-900 text-slate-500 font-semibold uppercase text-[10px]">
                                <tr>
                                    <th class="py-2.5 px-3">Employee</th>
                                    <th class="py-2.5 px-3">Branch</th>
                                    <th class="py-2.5 px-3">Type</th>
                                    <th class="py-2.5 px-3">Last Working Day</th>
                                    <th class="py-2.5 px-3">Settlement Status</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-slate-700">
                                <?php if (empty($reportData['separations'])): ?>
                                    <tr><td colspan="5" class="py-4 text-center text-slate-400">No separations recorded in <?= esc($year) ?>.</td></tr>
                                <?php else: ?>
                                    <?php foreach ($reportData['separations'] as $s): ?>
                                        <tr>
                                            <td class="py-2 px-3 font-medium text-slate-900 dark:text-white">
                                                <?= esc(trim(($s['first_name'] ?? '') . ' ' . ($s['last_name'] ?? ''))) ?>
                                                <span class="text-[10px] text-slate-400 font-mono">(<?= esc($s['employee_code']) ?>)</span>
                                            </td>
                                            <td class="py-2 px-3 text-slate-600 dark:text-slate-400"><?= esc($s['branch_name'] ?: 'N/A') ?></td>
                                            <td class="py-2 px-3 font-medium text-slate-800 dark:text-slate-200"><?= esc($s['separation_type'] ?? 'Separation') ?></td>
                                            <td class="py-2 px-3 font-mono"><?= esc($s['last_working_day'] ?: $s['separation_date']) ?></td>
                                            <td class="py-2 px-3">
                                                <span class="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300"><?= esc($s['payment_status'] ?? 'Pending') ?></span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        <!-- PROBATION EXPIRY -->
        <?php elseif ($reportType === 'probation'): ?>
            <h3 class="font-bold text-slate-900 dark:text-white text-base">Probation Pipeline (Scheduled End Dates)</h3>
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead class="bg-slate-50 dark:bg-slate-900 text-slate-500 font-semibold uppercase text-[10px]">
                        <tr>
                            <th class="py-2.5 px-3">Employee</th>
                            <th class="py-2.5 px-3">Branch</th>
                            <th class="py-2.5 px-3">Department</th>
                            <th class="py-2.5 px-3">Designation</th>
                            <th class="py-2.5 px-3">Joining Date</th>
                            <th class="py-2.5 px-3">Probation End</th>
                            <th class="py-2.5 px-3">Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-700">
                        <?php if (empty($reportData)): ?>
                            <tr><td colspan="7" class="py-4 text-center text-slate-400">No employees under active probation evaluation.</td></tr>
                        <?php else: ?>
                            <?php foreach ($reportData as $p): ?>
                                <tr>
                                    <td class="py-2 px-3 font-medium text-slate-900 dark:text-white">
                                        <?= esc(trim(($p['first_name'] ?? '') . ' ' . ($p['last_name'] ?? ''))) ?>
                                        <span class="text-[10px] text-slate-400 font-mono">(<?= esc($p['employee_code']) ?>)</span>
                                    </td>
                                    <td class="py-2 px-3 text-slate-600 dark:text-slate-400"><?= esc($p['branch_name'] ?: 'N/A') ?></td>
                                    <td class="py-2 px-3 text-slate-600 dark:text-slate-400"><?= esc($p['department_name'] ?: 'N/A') ?></td>
                                    <td class="py-2 px-3 text-slate-600 dark:text-slate-400"><?= esc($p['designation_name'] ?: 'N/A') ?></td>
                                    <td class="py-2 px-3 font-mono"><?= esc($p['joining_date']) ?></td>
                                    <td class="py-2 px-3 font-mono font-semibold text-amber-600 dark:text-amber-400"><?= esc($p['probation_end_date']) ?></td>
                                    <td class="py-2 px-3">
                                        <span class="px-2 py-0.5 rounded text-[10px] font-semibold bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-400"><?= esc($p['probation_status'] ?: 'Active') ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        <!-- DOCUMENT EXPIRY -->
        <?php elseif ($reportType === 'document_expiry'): ?>
            <h3 class="font-bold text-slate-900 dark:text-white text-base">Personnel Document Expiration Tracking</h3>
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead class="bg-slate-50 dark:bg-slate-900 text-slate-500 font-semibold uppercase text-[10px]">
                        <tr>
                            <th class="py-2.5 px-3">Employee</th>
                            <th class="py-2.5 px-3">Branch</th>
                            <th class="py-2.5 px-3">Document Name</th>
                            <th class="py-2.5 px-3">Document Type</th>
                            <th class="py-2.5 px-3">Expiry Date</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-700">
                        <?php if (empty($reportData)): ?>
                            <tr><td colspan="5" class="py-4 text-center text-slate-400">No expiring documents found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($reportData as $d): ?>
                                <tr>
                                    <td class="py-2 px-3 font-medium text-slate-900 dark:text-white">
                                        <?= esc(trim(($d['first_name'] ?? '') . ' ' . ($d['last_name'] ?? ''))) ?>
                                        <span class="text-[10px] text-slate-400 font-mono">(<?= esc($d['employee_code']) ?>)</span>
                                    </td>
                                    <td class="py-2 px-3 text-slate-600 dark:text-slate-400"><?= esc($d['branch_name'] ?: 'N/A') ?></td>
                                    <td class="py-2 px-3 font-medium text-slate-800 dark:text-slate-200"><?= esc($d['document_name']) ?></td>
                                    <td class="py-2 px-3 text-slate-600 dark:text-slate-400"><?= esc($d['document_type'] ?: 'General') ?></td>
                                    <td class="py-2 px-3 font-mono font-bold text-rose-600 dark:text-rose-400"><?= esc($d['expiry_date']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        <!-- MOVEMENTS -->
        <?php elseif ($reportType === 'movements'): ?>
            <h3 class="font-bold text-slate-900 dark:text-white text-base">Promotions & Movement Trajectory</h3>
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead class="bg-slate-50 dark:bg-slate-900 text-slate-500 font-semibold uppercase text-[10px]">
                        <tr>
                            <th class="py-2.5 px-3">Effective Date</th>
                            <th class="py-2.5 px-3">Employee</th>
                            <th class="py-2.5 px-3">New Designation</th>
                            <?php if (!empty($canViewSalary)): ?>
                                <th class="py-2.5 px-3 text-right">Previous Salary</th>
                                <th class="py-2.5 px-3 text-right">New Salary</th>
                            <?php endif; ?>
                            <th class="py-2.5 px-3">Reason / Memo</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-700">
                        <?php if (empty($reportData)): ?>
                            <tr><td colspan="<?= !empty($canViewSalary) ? '6' : '4' ?>" class="py-4 text-center text-slate-400">No promotion movements recorded.</td></tr>
                        <?php else: ?>
                            <?php foreach ($reportData as $m): ?>
                                <tr>
                                    <td class="py-2 px-3 font-mono text-slate-600 dark:text-slate-400"><?= esc($m['effective_date'] ?: $m['promotion_date']) ?></td>
                                    <td class="py-2 px-3 font-medium text-slate-900 dark:text-white">
                                        <?= esc(trim(($m['first_name'] ?? '') . ' ' . ($m['last_name'] ?? ''))) ?>
                                        <span class="text-[10px] text-slate-400 font-mono">(<?= esc($m['employee_code']) ?>)</span>
                                    </td>
                                    <td class="py-2 px-3 font-semibold text-slate-800 dark:text-slate-200"><?= esc($m['new_desg_name'] ?: 'Promotion') ?></td>
                                    <?php if (!empty($canViewSalary)): ?>
                                        <td class="py-2 px-3 font-mono text-right text-slate-600 dark:text-slate-400"><?= number_format((float)($m['previous_salary'] ?? 0), 2) ?></td>
                                        <td class="py-2 px-3 font-mono text-right font-bold text-emerald-600 dark:text-emerald-400"><?= number_format((float)($m['new_salary'] ?? 0), 2) ?></td>
                                    <?php endif; ?>
                                    <td class="py-2 px-3 text-slate-600 dark:text-slate-400"><?= esc($m['reason'] ?: 'Performance upgrade') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        <!-- OTHER REPORT TYPES -->
        <?php else: ?>
            <p class="text-xs text-slate-500 dark:text-slate-400">Displaying report data for: <strong class="text-slate-900 dark:text-white"><?= esc(ucwords(str_replace('_', ' ', $reportType))) ?></strong></p>
            <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-mono text-slate-700 dark:text-slate-300">
                <?= count((array)$reportData) ?> records found matching current tenant filter. Use "Export CSV" to download detailed raw data.
            </div>
        <?php endif; ?>

    </div>

</div>
