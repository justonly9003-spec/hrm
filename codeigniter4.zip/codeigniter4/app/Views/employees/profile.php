<?php
$userId = !empty($userAccount['username']) ? $userAccount['username'] : (!empty($employee['user_username']) ? $employee['user_username'] : (!empty($employee['email']) ? explode('@', $employee['email'])[0] : ($employee['employee_code'] ?? 'EMP-001')));
$userRole = !empty($userAccount['role_name']) ? $userAccount['role_name'] : (!empty($employee['user_role_name']) ? $employee['user_role_name'] : (!empty($employee['designation_name']) ? $employee['designation_name'] : 'Employee'));
$defaultPassword = \Config\Hrms::DEFAULT_PASSWORD;

$menuVis = new \App\Services\MenuVisibilityService();
$currentUserId = (string)(session()->get('user_id') ?? '');
$canResetPassword = !empty($isSoftwareAdmin) || session()->get('role_code') === 'company_admin' || (function_exists('can') && can('users.edit'));
$isSelf = !empty($isSelf) ? true : (!empty(session()->get('employee_id')) && (string)session()->get('employee_id') === (string)($employee['id'] ?? ''));
$requestedTab = $_GET['tab'] ?? 'overview';

// If requested tab is hidden for this user/role, fallback to first visible tab
$canAccessRequestedTab = ($isSelf && in_array($requestedTab, ['overview', 'provident_fund', 'attendance', 'leave', 'payroll'], true))
    ? true
    : $menuVis->isVisible($currentUserId, 'employees.' . $requestedTab);

if (!$canAccessRequestedTab) {
    $firstTab = $menuVis->getFirstVisibleTab('employees', $currentUserId) ?? 'overview';
    $requestedTab = $firstTab;
}
?>

<div class="space-y-6" x-data="{ 
    activeTab: '<?= esc($requestedTab) ?>',
    showPassword: false, 
    copiedUser: false, 
    copiedPass: false, 
    resetModalOpen: false,
    copyToClipboard(text, type) {
        navigator.clipboard.writeText(text).then(() => {
            if (type === 'user') {
                this.copiedUser = true;
                setTimeout(() => this.copiedUser = false, 2000);
            } else if (type === 'pass') {
                this.copiedPass = true;
                setTimeout(() => this.copiedPass = false, 2000);
            }
        });
    }
}">
    <!-- Profile Top Banner / Header -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div class="flex items-center gap-5">
            <div class="w-16 h-16 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-900 font-bold text-2xl flex items-center justify-center shadow-xs">
                <?= strtoupper(substr($employee['first_name'] ?? 'E', 0, 1) . substr($employee['last_name'] ?? 'M', 0, 1)) ?>
            </div>
            <div>
                <div class="flex items-center gap-3">
                    <h1 class="text-2xl font-bold text-slate-900 dark:text-white"><?= esc($employee['name'] ?? trim(($employee['first_name'] ?? '') . ' ' . ($employee['last_name'] ?? ''))) ?></h1>
                    <?php
                    $empProfileStatus = \App\Models\EmployeeModel::normalizeStatus($employee['status'] ?? \App\Models\EmployeeModel::STATUS_ACTIVE, true);
                    $empBadgeClass = match($empProfileStatus) {
                        \App\Models\EmployeeModel::STATUS_ACTIVE => 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800',
                        \App\Models\EmployeeModel::STATUS_PROBATION => 'bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-400 border border-amber-200 dark:border-amber-800',
                        \App\Models\EmployeeModel::STATUS_ON_LEAVE => 'bg-sky-50 text-sky-700 dark:bg-sky-950/50 dark:text-sky-400 border border-sky-200 dark:border-sky-800',
                        \App\Models\EmployeeModel::STATUS_SUSPENDED => 'bg-rose-50 text-rose-700 dark:bg-rose-950/50 dark:text-rose-400 border border-rose-200 dark:border-rose-800',
                        default => 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                    };
                    ?>
                    <span class="px-2.5 py-0.5 text-xs font-semibold rounded-full <?= $empBadgeClass ?>">
                        <?= esc(\App\Models\EmployeeModel::getStatusLabel($empProfileStatus)) ?>
                    </span>
                </div>
                <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">
                    <?= esc($employee['designation_name'] ?? 'Staff') ?> &bull; <?= esc($employee['department_name'] ?? 'General') ?> &bull; <span class="font-mono text-xs text-indigo-600 dark:text-indigo-400"><?= esc($employee['employee_code'] ?? '') ?></span>
                </p>
            </div>
        </div>
        <div class="flex flex-wrap items-center gap-2">
            <?php if ($canResetPassword): ?>
            <button type="button" @click="resetModalOpen = true" class="inline-flex items-center gap-2 px-4 py-2 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 text-xs font-semibold rounded-xl border border-indigo-200 dark:border-indigo-800 transition-all">
                <i data-lucide="key-round" class="w-4 h-4 text-indigo-600"></i>
                <span>Reset User Password</span>
            </button>
            <?php endif; ?>
            <?php if (!empty($isSoftwareAdmin) || session()->get('role_code') === 'company_admin' || (function_exists('can') && can('directory.view') && session()->get('role_code') !== 'employee')): ?>
            <a href="<?= base_url('employees') ?>" class="inline-flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 text-xs font-semibold rounded-xl transition-all">
                <i data-lucide="arrow-left" class="w-4 h-4 text-slate-400"></i>
                <span>Back to Directory</span>
            </a>
            <?php else: ?>
            <a href="<?= base_url('dashboard') ?>" class="inline-flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 text-xs font-semibold rounded-xl transition-all">
                <i data-lucide="arrow-left" class="w-4 h-4 text-slate-400"></i>
                <span>Back to Dashboard</span>
            </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- One-Time Auto-Generated Password Notice -->
    <?php if (session()->getFlashdata('temp_password')): ?>
        <div role="status" class="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-800 dark:text-emerald-300 flex items-center justify-between shadow-xs">
            <div class="flex items-center gap-3">
                <i data-lucide="shield-alert" class="w-5 h-5 text-emerald-600 shrink-0"></i>
                <div>
                    <span class="font-bold">Auto-Generated Temporary Password:</span>
                    <code class="ml-2 px-2.5 py-1 rounded-lg bg-emerald-100 dark:bg-emerald-900 font-mono font-bold text-sm text-emerald-950 dark:text-emerald-100 select-all"><?= esc(session()->getFlashdata('temp_password')) ?></code>
                    <span class="text-[11px] text-emerald-600 dark:text-emerald-400 ml-2">(Shown once only. Please securely provide this to the employee.)</span>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Shared UI Flash Notification Container for all profile actions -->
    <?php if (session()->getFlashdata('error')): ?>
        <div class="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200 text-xs font-semibold flex items-center gap-2 shadow-xs">
            <i data-lucide="alert-circle" class="w-4 h-4 text-rose-600 shrink-0"></i>
            <span><?= esc(session()->getFlashdata('error')) ?></span>
        </div>
    <?php endif; ?>
    <?php if (session()->getFlashdata('success')): ?>
        <div class="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs font-semibold flex items-center gap-2 shadow-xs">
            <i data-lucide="check-circle" class="w-4 h-4 text-emerald-600 shrink-0"></i>
            <span><?= esc(session()->getFlashdata('success')) ?></span>
        </div>
    <?php endif; ?>

    <!-- Main Grid: Left Fixed Context Column & Right Dynamic Tab Sub-System -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Summary Context Column (Left) -->
        <div class="space-y-6">
            <!-- Employment Overview Card with User ID & Password Prominently Displayed -->
            <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-5 shadow-xs space-y-4">
                <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-2">
                    <h3 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                        <i data-lucide="briefcase" class="w-4 h-4 text-indigo-600"></i>
                        Employment Overview
                    </h3>
                    <span class="text-[10px] uppercase font-bold text-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 px-2 py-0.5 rounded">Core Record</span>
                </div>
                
                <div class="text-xs space-y-3">
                    <div class="flex justify-between items-center"><span class="text-slate-400">Email</span><span class="font-medium text-slate-800 dark:text-slate-200"><?= esc(!empty($employee['email']) ? $employee['email'] : '—') ?></span></div>
                    <div class="flex justify-between items-center"><span class="text-slate-400">Phone</span><span class="font-medium text-slate-800 dark:text-slate-200"><?= esc(!empty($employee['phone']) ? $employee['phone'] : '—') ?></span></div>
                    <div class="flex justify-between items-center"><span class="text-slate-400">Branch</span><span class="font-medium text-slate-800 dark:text-slate-200"><?= esc(!empty($employee['branch_name']) ? $employee['branch_name'] : '—') ?></span></div>
                    <div class="flex justify-between items-center"><span class="text-slate-400">Join Date</span><span class="font-mono text-slate-800 dark:text-slate-200"><?= esc(employee_joining_date($employee) ?? '—') ?></span></div>
                    <div class="flex justify-between items-center"><span class="text-slate-400">Working Shift</span><span class="font-medium text-slate-800 dark:text-slate-200"><?= esc(!empty($employee['shift_name']) ? $employee['shift_name'] : '—') ?></span></div>
                    <div class="flex justify-between items-center"><span class="text-slate-400">Employment Type</span><span class="font-medium text-slate-800 dark:text-slate-200"><?= esc(!empty($employee['employment_type_name']) ? $employee['employment_type_name'] : '—') ?></span></div>
                    <?php if (!empty($canViewSalaryFigures)): ?>
                    <div class="flex justify-between items-center"><span class="text-slate-400">Basic Salary</span><span class="font-mono font-bold text-slate-900 dark:text-white"><?= format_money((float)($employee['basic_salary'] ?? 0)) ?></span></div>
                    <?php endif; ?>
                    <div class="flex justify-between items-center"><span class="text-slate-400">Reporting Manager</span><span class="font-medium text-slate-800 dark:text-slate-200"><?= esc(!empty($employee['manager_name']) ? $employee['manager_name'] : '—') ?></span></div>
                    
                    <!-- System Credentials: User ID & Password -->
                    <div class="pt-3 border-t border-slate-100 dark:border-slate-700 space-y-3">
                        <div class="flex items-center justify-between">
                            <span class="text-slate-500 dark:text-slate-400 font-semibold flex items-center gap-1.5">
                                <i data-lucide="user-check" class="w-3.5 h-3.5 text-indigo-500"></i>
                                User ID (Username)
                            </span>
                            <div class="flex items-center gap-1.5">
                                <span class="font-mono font-bold text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-100 dark:border-indigo-900"><?= esc($userId) ?></span>
                                <button type="button" @click="copyToClipboard('<?= esc($userId) ?>', 'user')" class="p-1 text-slate-400 hover:text-indigo-600 transition" title="Copy Username">
                                    <i x-show="!copiedUser" data-lucide="copy" class="w-3.5 h-3.5"></i>
                                    <i x-show="copiedUser" data-lucide="check" class="w-3.5 h-3.5 text-emerald-500" style="display: none;"></i>
                                </button>
                            </div>
                        </div>

                        <?php if ($canResetPassword): ?>
                        <div class="flex items-center justify-between">
                            <span class="text-slate-500 dark:text-slate-400 font-semibold flex items-center gap-1.5">
                                <i data-lucide="lock" class="w-3.5 h-3.5 text-amber-500"></i>
                                Initial Password
                            </span>
                            <div class="flex items-center gap-1.5">
                                <span class="font-mono font-bold text-slate-800 dark:text-slate-100 bg-slate-100 dark:bg-slate-900 px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700">
                                    <span x-show="!showPassword">••••••</span>
                                    <span x-show="showPassword" style="display: none;"><?= esc($defaultPassword) ?></span>
                                </span>
                                <button type="button" @click="showPassword = !showPassword" class="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition" title="Toggle Password Visibility">
                                    <i x-show="!showPassword" data-lucide="eye" class="w-4 h-4"></i>
                                    <i x-show="showPassword" data-lucide="eye-off" class="w-4 h-4 text-amber-600" style="display: none;"></i>
                                </button>
                                <button type="button" @click="copyToClipboard('<?= esc($defaultPassword) ?>', 'pass')" class="p-1 text-slate-400 hover:text-indigo-600 transition" title="Copy Password">
                                    <i x-show="!copiedPass" data-lucide="copy" class="w-3.5 h-3.5"></i>
                                    <i x-show="copiedPass" data-lucide="check" class="w-3.5 h-3.5 text-emerald-500" style="display: none;"></i>
                                </button>
                            </div>
                        </div>

                        <div class="p-2.5 rounded-xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200/60 dark:border-amber-900/40 text-[11px] text-amber-800 dark:text-amber-300 flex items-start gap-2">
                            <i data-lucide="shield-check" class="w-4 h-4 text-amber-600 shrink-0 mt-0.5"></i>
                            <div>
                                <span>Initial provisioned password is <strong class="font-mono font-bold"><?= esc($defaultPassword) ?></strong> (valid only until the employee changes it).</span>
                                <button type="button" @click="resetModalOpen = true" class="underline font-semibold ml-1 hover:text-amber-900 dark:hover:text-amber-100">Change Password</button>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Leave Balances -->
            <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-5 shadow-xs space-y-4">
                <h3 class="font-bold text-slate-900 dark:text-white text-sm border-b border-slate-100 dark:border-slate-700 pb-2">Active Leave Balances (<?= date('Y') ?>)</h3>
                <?php 
                $activeBalances = !empty($leaveBalances) ? $leaveBalances : (!empty($leaveBalance) && is_array($leaveBalance) && isset($leaveBalance[0]) ? $leaveBalance : []);
                ?>
                <?php if (empty($activeBalances)): ?>
                    <div class="text-xs text-slate-500 dark:text-slate-400 text-center py-2 font-medium">Not configured</div>
                <?php else: ?>
                    <div class="grid grid-cols-2 sm:grid-cols-3 gap-2 text-center text-xs">
                        <?php 
                        $colorPalettes = [
                            ['bg' => 'bg-indigo-50/50 dark:bg-indigo-950/30', 'border' => 'border-indigo-100 dark:border-indigo-900/40', 'title' => 'text-indigo-500', 'val' => 'text-indigo-700 dark:text-indigo-400'],
                            ['bg' => 'bg-emerald-50/50 dark:bg-emerald-950/30', 'border' => 'border-emerald-100 dark:border-emerald-900/40', 'title' => 'text-emerald-500', 'val' => 'text-emerald-700 dark:text-emerald-400'],
                            ['bg' => 'bg-amber-50/50 dark:bg-amber-950/30', 'border' => 'border-amber-100 dark:border-amber-900/40', 'title' => 'text-amber-500', 'val' => 'text-amber-700 dark:text-amber-400'],
                            ['bg' => 'bg-purple-50/50 dark:bg-purple-950/30', 'border' => 'border-purple-100 dark:border-purple-900/40', 'title' => 'text-purple-500', 'val' => 'text-purple-700 dark:text-purple-400'],
                            ['bg' => 'bg-sky-50/50 dark:bg-sky-950/30', 'border' => 'border-sky-100 dark:border-sky-900/40', 'title' => 'text-sky-500', 'val' => 'text-sky-700 dark:text-sky-400'],
                        ];
                        $cIdx = 0;
                        ?>
                        <?php foreach ($activeBalances as $lb): ?>
                            <?php $pal = $colorPalettes[$cIdx % count($colorPalettes)]; $cIdx++; ?>
                            <div class="p-3 <?= $pal['bg'] ?> rounded-xl border <?= $pal['border'] ?>">
                                <div class="text-[10px] uppercase font-bold <?= $pal['title'] ?> truncate" title="<?= esc($lb['leave_type_name']) ?>"><?= esc($lb['leave_type_name']) ?></div>
                                <div class="text-base font-bold <?= $pal['val'] ?> mt-1"><?= (float)($lb['available_balance'] ?? 0) ?>d</div>
                                <div class="text-[10px] text-slate-400 mt-0.5" title="Used / Total Entitlement">Used: <?= (float)($lb['total_used'] ?? 0) ?>d / <?= (float)($lb['total_entitlement'] ?? 0) ?>d</div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Right Side Multi-Tab Content Container -->
        <div class="lg:col-span-2 space-y-6">
            <!-- Tab Navigation Bar (Identical to React Application) -->
            <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-2 shadow-xs">
                <div class="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-1">
                    <?php
                    $tabs = [
                        ['id' => 'overview', 'label' => 'Overview', 'icon' => 'layout-dashboard'],
                        ['id' => 'personal', 'label' => 'Personal Info', 'icon' => 'user'],
                        ['id' => 'contact', 'label' => 'Contact', 'icon' => 'phone'],
                        ['id' => 'address', 'label' => 'Address', 'icon' => 'map-pin'],
                        ['id' => 'employment', 'label' => 'Employment', 'icon' => 'briefcase'],
                        ['id' => 'bank', 'label' => 'Bank Account', 'icon' => 'landmark'],
                        ['id' => 'education', 'label' => 'Education', 'icon' => 'graduation-cap'],
                        ['id' => 'experience', 'label' => 'Experience', 'icon' => 'award'],
                        ['id' => 'family', 'label' => 'Family', 'icon' => 'users'],
                        ['id' => 'emergency', 'label' => 'Emergency', 'icon' => 'phone-call'],
                        ['id' => 'documents', 'label' => 'Documents', 'icon' => 'file-text'],
                        ['id' => 'promotion', 'label' => 'Promotions', 'icon' => 'trending-up'],
                        ['id' => 'transfer', 'label' => 'Transfers', 'icon' => 'arrow-left-right'],
                        ['id' => 'resignation', 'label' => 'Resignation', 'icon' => 'log-out'],
                        ['id' => 'termination', 'label' => 'Termination', 'icon' => 'shield-alert'],
                        ['id' => 'attendance', 'label' => 'Attendance', 'icon' => 'clock'],
                        ['id' => 'leave', 'label' => 'Leave History', 'icon' => 'plane-takeoff'],
                        ['id' => 'payroll', 'label' => 'Salary & Payroll', 'icon' => 'receipt'],
                        ['id' => 'provident_fund', 'label' => 'Provident Fund', 'icon' => 'piggy-bank'],
                        ['id' => 'skills', 'label' => 'Skills', 'icon' => 'zap'],
                        ['id' => 'performance', 'label' => 'Performance', 'icon' => 'star'],
                        ['id' => 'training', 'label' => 'Training', 'icon' => 'book-open'],
                        ['id' => 'assets', 'label' => 'Assets', 'icon' => 'laptop'],
                        ['id' => 'login', 'label' => 'Login & Security', 'icon' => 'shield-check'],
                        ['id' => 'audit', 'label' => 'Audit Trail', 'icon' => 'history'],
                    ];
                    $tabs = array_values(array_filter($tabs, function($t) use ($menuVis, $currentUserId, $isSelf, $canViewAssets) {
                        if ($t['id'] === 'assets') {
                            if (!empty($isSelf)) {
                                return true;
                            }
                            return !empty($canViewAssets) && $menuVis->isVisible($currentUserId, 'employees.assets');
                        }
                        if (!empty($isSelf) && $t['id'] === 'provident_fund') {
                            return true;
                        }
                        return $menuVis->isVisible($currentUserId, 'employees.' . $t['id']);
                    }));
                    ?>
                    <?php foreach ($tabs as $tab): ?>
                        <button type="button" 
                                @click="activeTab = '<?= $tab['id'] ?>'" 
                                :class="activeTab === '<?= $tab['id'] ?>' ? 'bg-indigo-600 text-white font-bold shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-700/50 font-semibold'" 
                                class="px-3 py-2 rounded-xl text-xs flex items-center gap-1.5 shrink-0 transition-all">
                            <i data-lucide="<?= $tab['icon'] ?>" class="w-3.5 h-3.5"></i>
                            <span><?= esc($tab['label']) ?></span>
                        </button>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Tab Contents (Sub-Views) -->
            <div>
                <!-- Overview Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.overview')): ?>
                <div x-show="activeTab === 'overview'">
                    <?= view('employees/tabs/overview', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Personal Info Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.personal')): ?>
                <div x-show="activeTab === 'personal'" style="display: none;">
                    <?= view('employees/tabs/personal', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Contact Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.contact')): ?>
                <div x-show="activeTab === 'contact'" style="display: none;">
                    <?= view('employees/tabs/contact', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Address Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.address')): ?>
                <div x-show="activeTab === 'address'" style="display: none;">
                    <?= view('employees/tabs/address', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Employment Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.employment')): ?>
                <div x-show="activeTab === 'employment'" style="display: none;">
                    <?= view('employees/tabs/employment', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Bank & Payment Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.bank')): ?>
                <div x-show="activeTab === 'bank'" style="display: none;">
                    <?= view('employees/tabs/bank', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Education Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.education')): ?>
                <div x-show="activeTab === 'education'" style="display: none;">
                    <?= view('employees/tabs/education', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Experience Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.experience')): ?>
                <div x-show="activeTab === 'experience'" style="display: none;">
                    <?= view('employees/tabs/experience', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Family Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.family')): ?>
                <div x-show="activeTab === 'family'" style="display: none;">
                    <?= view('employees/tabs/family', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Emergency Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.emergency')): ?>
                <div x-show="activeTab === 'emergency'" style="display: none;">
                    <?= view('employees/tabs/emergency', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Documents Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.documents')): ?>
                <div x-show="activeTab === 'documents'" style="display: none;">
                    <?= view('employees/tabs/documents', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Promotion Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.promotion')): ?>
                <div x-show="activeTab === 'promotion'" style="display: none;">
                    <?= view('employees/tabs/promotion', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Transfer Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.transfer')): ?>
                <div x-show="activeTab === 'transfer'" style="display: none;">
                    <?= view('employees/tabs/transfer', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Resignation Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.resignation')): ?>
                <div x-show="activeTab === 'resignation'" style="display: none;">
                    <?= view('employees/tabs/resignation', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Termination Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.termination')): ?>
                <div x-show="activeTab === 'termination'" style="display: none;">
                    <?= view('employees/tabs/termination', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Attendance Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.attendance')): ?>
                <div x-show="activeTab === 'attendance'" style="display: none;">
                    <?= view('employees/tabs/attendance', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Leave Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.leave')): ?>
                <div x-show="activeTab === 'leave'" style="display: none;">
                    <?= view('employees/tabs/leave', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Payroll Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.payroll')): ?>
                <div x-show="activeTab === 'payroll'" style="display: none;">
                    <?= view('employees/tabs/payroll', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Provident Fund Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.provident_fund') || !empty($isSelf)): ?>
                <div x-show="activeTab === 'provident_fund'" style="display: none;">
                    <?= view('employees/tabs/provident_fund', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Skills Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.skills')): ?>
                <div x-show="activeTab === 'skills'" style="display: none;">
                    <?= view('employees/tabs/skills', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Performance Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.performance')): ?>
                <div x-show="activeTab === 'performance'" style="display: none;">
                    <?= view('employees/tabs/performance', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Training Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.training')): ?>
                <div x-show="activeTab === 'training'" style="display: none;">
                    <?= view('employees/tabs/training', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Assets Tab -->
                <?php if (($isSelf || $menuVis->isVisible($currentUserId, 'employees.assets')) && !empty($canViewAssets)): ?>
                <div x-show="activeTab === 'assets'" style="display: none;">
                    <?= view('employees/tabs/assets', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Login & Credentials Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.login')): ?>
                <div x-show="activeTab === 'login'" style="display: none;">
                    <?= view('employees/tabs/login', get_defined_vars()) ?>
                </div>
                <?php endif; ?>

                <!-- Audit Trail Tab -->
                <?php if ($menuVis->isVisible($currentUserId, 'employees.audit')): ?>
                <div x-show="activeTab === 'audit'" style="display: none;">
                    <?= view('employees/tabs/audit', get_defined_vars()) ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Password Reset Modal -->
    <div x-show="resetModalOpen" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" style="display: none;">
        <div @click.away="resetModalOpen = false" class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 w-full max-w-md p-6 shadow-xl space-y-5 animate-in fade-in zoom-in-95 duration-150">
            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                <h3 class="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                    <i data-lucide="key-round" class="w-5 h-5 text-indigo-600"></i>
                    Reset User Password
                </h3>
                <button type="button" @click="resetModalOpen = false" class="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>

            <form action="<?= base_url('employees/profile/' . $employee['id'] . '/reset-password') ?>" method="POST" class="space-y-4">
                <?= csrf_field() ?>
                
                <div class="p-3 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-slate-200 dark:border-slate-700 text-xs space-y-1.5">
                    <div class="text-slate-500">Employee: <strong class="text-slate-800 dark:text-slate-200"><?= esc($employee['name'] ?? trim(($employee['first_name'] ?? '') . ' ' . ($employee['last_name'] ?? ''))) ?></strong></div>
                    <div class="text-slate-500">Username: <span class="font-mono font-bold text-indigo-600"><?= esc($userId) ?></span></div>
                    <div class="text-slate-500">Email: <span class="font-mono text-slate-700 dark:text-slate-300"><?= esc($employee['email'] ?? 'N/A') ?></span></div>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">New Password</label>
                    <input type="text" name="new_password" value="<?= esc($defaultPassword) ?>" required class="w-full px-3 py-2 text-xs font-mono font-bold rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden">
                    <p class="text-[11px] text-slate-400 mt-1">Default suggested value: <strong class="font-mono"><?= esc($defaultPassword) ?></strong></p>
                </div>

                <div class="flex items-center justify-end gap-3 pt-2">
                    <button type="button" @click="resetModalOpen = false" class="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600 transition">
                        Cancel
                    </button>
                    <button type="submit" class="px-4 py-2 text-xs font-semibold rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 shadow-sm transition flex items-center gap-2">
                        <i data-lucide="check" class="w-4 h-4"></i>
                        <span>Confirm & Update Password</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
