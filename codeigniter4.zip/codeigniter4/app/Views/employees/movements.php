<div class="space-y-6" x-data="movementConsole()">

    <!-- Header Section -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <div class="flex items-center gap-2 mb-1">
                <span class="text-[11px] font-bold px-2.5 py-0.5 rounded-md bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60">
                    Personnel Mobility & Growth
                </span>
                <span class="text-[11px] text-slate-400 font-mono">
                    <?= !empty($isSoftwareAdmin) ? 'Multi-Tenant Lifecycle' : 'Internal Mobility Engine' ?>
                </span>
            </div>
            <h2 class="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">Transfers & Promotions</h2>
            <p class="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                Manage inter-branch redeployments, department transfers, and career promotions with synchronized compensation tracking.
            </p>
        </div>

        <div class="flex flex-wrap items-center gap-2.5">
            <button type="button" @click="promoModalOpen = true" class="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 shadow-sm transition">
                <i data-lucide="trending-up" class="w-4 h-4"></i>
                <span>Record Promotion</span>
            </button>

            <button type="button" @click="transferModalOpen = true" class="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm transition">
                <i data-lucide="arrow-left-right" class="w-4 h-4"></i>
                <span>Record Transfer</span>
            </button>
        </div>
    </div>

    <!-- Shared Employees Module Navigation Tabs -->
    <?= view('employees/_tabs', ['activeTab' => 'movements']) ?>

    <!-- Metrics Cards -->
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-2xs">
            <div class="flex items-center justify-between">
                <span class="text-xs font-medium text-slate-500 dark:text-slate-400">Total Movements</span>
                <div class="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                    <i data-lucide="history" class="w-4 h-4"></i>
                </div>
            </div>
            <p class="text-2xl font-bold text-slate-900 dark:text-white mt-2"><?= count($movements ?? []) ?></p>
            <p class="text-[11px] text-slate-400 mt-1">Historical personnel actions</p>
        </div>

        <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-2xs">
            <div class="flex items-center justify-between">
                <span class="text-xs font-medium text-slate-500 dark:text-slate-400">Promotions Executed</span>
                <div class="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                    <i data-lucide="trending-up" class="w-4 h-4"></i>
                </div>
            </div>
            <p class="text-2xl font-bold text-emerald-600 dark:text-emerald-400 mt-2"><?= $promoCount ?? 0 ?></p>
            <p class="text-[11px] text-emerald-600/80 dark:text-emerald-400/80 mt-1">Designation & merit upgrades</p>
        </div>

        <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-2xs">
            <div class="flex items-center justify-between">
                <span class="text-xs font-medium text-slate-500 dark:text-slate-400">Branch Transfers</span>
                <div class="w-8 h-8 rounded-xl bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 flex items-center justify-center">
                    <i data-lucide="arrow-left-right" class="w-4 h-4"></i>
                </div>
            </div>
            <p class="text-2xl font-bold text-sky-600 dark:text-sky-400 mt-2"><?= $transferCount ?? 0 ?></p>
            <p class="text-[11px] text-sky-600/80 dark:text-sky-400/80 mt-1">Branch and department shifts</p>
        </div>

        <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-2xs">
            <div class="flex items-center justify-between">
                <span class="text-xs font-medium text-slate-500 dark:text-slate-400">Single Source Engine</span>
                <div class="w-8 h-8 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center">
                    <i data-lucide="shield-check" class="w-4 h-4"></i>
                </div>
            </div>
            <p class="text-2xl font-bold text-purple-600 dark:text-purple-400 mt-2">100%</p>
            <p class="text-[11px] text-purple-600/80 dark:text-purple-400/80 mt-1">EmployeeMovementService</p>
        </div>
    </div>

    <!-- Filter Bar -->
    <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-2xs">
        <form method="GET" action="<?= base_url('employees/movements') ?>" class="flex flex-wrap items-center justify-between gap-3">
            <div class="flex flex-wrap items-center gap-3 flex-1">
                <!-- Search Input -->
                <div class="relative min-w-[220px] max-w-xs flex-1">
                    <i data-lucide="search" class="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"></i>
                    <input type="text" 
                           name="search" 
                           value="<?= esc($search ?? '') ?>" 
                           placeholder="Search employee, code..." 
                           class="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                </div>

                <!-- Type Filter -->
                <div class="min-w-[150px]">
                    <select name="type" onchange="this.form.submit()" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        <option value="All" <?= ($typeFilter ?? '') === 'All' ? 'selected' : '' ?>>All Movement Types</option>
                        <option value="Promotion" <?= ($typeFilter ?? '') === 'Promotion' ? 'selected' : '' ?>>Promotions Only</option>
                        <option value="Transfer" <?= ($typeFilter ?? '') === 'Transfer' ? 'selected' : '' ?>>Transfers Only</option>
                    </select>
                </div>

                <!-- Branch Filter -->
                <?php if (!empty($branches)): ?>
                <div class="min-w-[150px]">
                    <select name="branch_id" onchange="this.form.submit()" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        <option value="">All Branches</option>
                        <?php foreach ($branches as $br): ?>
                            <option value="<?= esc($br['id']) ?>" <?= ($branchFilter ?? '') === $br['id'] ? 'selected' : '' ?>><?= esc($br['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>
            </div>

            <div class="flex items-center gap-2">
                <button type="submit" class="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs transition">
                    Filter
                </button>
                <a href="<?= base_url('employees/movements') ?>" class="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700/60 font-medium text-xs transition">
                    Reset
                </a>
            </div>
        </form>
    </div>

    <!-- Movement Records Table -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-2xs">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
                <thead class="bg-slate-50/80 dark:bg-slate-900/60 border-b border-slate-200/80 dark:border-slate-700 text-slate-500 dark:text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                    <tr>
                        <th class="py-3 px-4">Date</th>
                        <th class="py-3 px-4">Employee</th>
                        <th class="py-3 px-4">Type</th>
                        <th class="py-3 px-4">From</th>
                        <th class="py-3 px-4">To</th>
                        <th class="py-3 px-4">Effective Date</th>
                        <th class="py-3 px-4">Status</th>
                        <th class="py-3 px-4">Reason / Notes</th>
                        <th class="py-3 px-4 text-right">Profile</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-700/60">
                    <?php if (empty($movements)): ?>
                        <tr>
                            <td colspan="9" class="py-12 text-center text-slate-400">
                                <div class="flex flex-col items-center justify-center gap-2">
                                    <i data-lucide="arrow-left-right" class="w-8 h-8 text-slate-300 dark:text-slate-600"></i>
                                    <p class="font-medium text-slate-500 dark:text-slate-400">No promotion or transfer records found matching criteria.</p>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($movements as $m): ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-750 transition-colors">
                                <!-- Record Date -->
                                <td class="py-3 px-4 font-mono text-slate-500 dark:text-slate-400 whitespace-nowrap">
                                    <?= esc(substr($m['created_at'] ?: $m['effective_date'], 0, 10)) ?>
                                </td>

                                <!-- Employee -->
                                <td class="py-3 px-4">
                                    <a href="<?= base_url('employees/profile/' . $m['employee_id']) ?>" class="font-semibold text-slate-900 dark:text-white hover:text-indigo-600 dark:hover:text-indigo-400 transition">
                                        <?= esc($m['employee_name']) ?>
                                    </a>
                                    <div class="text-[10px] text-slate-400 font-mono"><?= esc($m['employee_code']) ?></div>
                                </td>

                                <!-- Movement Type -->
                                <td class="py-3 px-4">
                                    <?php if ($m['movement_type'] === 'Promotion'): ?>
                                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
                                            <i data-lucide="trending-up" class="w-3 h-3"></i> Promotion
                                        </span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-50 text-sky-700 dark:bg-sky-950/60 dark:text-sky-400 border border-sky-200 dark:border-sky-800">
                                            <i data-lucide="arrow-left-right" class="w-3 h-3"></i> Transfer
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <!-- From -->
                                <td class="py-3 px-4 text-slate-500 dark:text-slate-400 max-w-[160px] truncate">
                                    <?= esc($m['from']) ?>
                                </td>

                                <!-- To -->
                                <td class="py-3 px-4 font-semibold text-slate-900 dark:text-white max-w-[160px] truncate">
                                    <?= esc($m['to']) ?>
                                </td>

                                <!-- Effective Date -->
                                <td class="py-3 px-4 font-mono text-slate-700 dark:text-slate-300 whitespace-nowrap">
                                    <?= esc($m['effective_date'] ?: 'Immediate') ?>
                                </td>

                                <!-- Status -->
                                <td class="py-3 px-4">
                                    <span class="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                                        <?= esc($m['status']) ?>
                                    </span>
                                </td>

                                <!-- Reason -->
                                <td class="py-3 px-4 text-slate-600 dark:text-slate-400 max-w-[200px] truncate">
                                    <?= esc($m['reason'] ?: 'Routine staffing re-alignment') ?>
                                </td>

                                <!-- Action -->
                                <td class="py-3 px-4 text-right">
                                    <a href="<?= base_url('employees/profile/' . $m['employee_id'] . '?tab=career') ?>" class="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:text-indigo-400 transition">
                                        <span>View</span>
                                        <i data-lucide="external-link" class="w-3 h-3"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- MODAL: Record Promotion -->
    <template x-if="promoModalOpen">
        <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs" @click.self="promoModalOpen = false">
            <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200 dark:border-slate-700 space-y-4">
                <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                    <h3 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                        <i data-lucide="trending-up" class="w-4 h-4 text-emerald-600"></i>
                        Record Employee Promotion
                    </h3>
                    <button type="button" @click="promoModalOpen = false" class="text-slate-400 hover:text-slate-600">
                        <i data-lucide="x" class="w-4 h-4"></i>
                    </button>
                </div>

                <form action="<?= base_url('employees/promote') ?>" method="POST" class="space-y-4 text-xs">
                    <?= csrf_field() ?>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Select Employee <span class="text-rose-500">*</span>:</label>
                        <select name="employee_id" required class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                            <option value="">-- Choose Staff Member --</option>
                            <?php foreach ($employeeOptions as $op): ?>
                                <option value="<?= esc($op['id']) ?>">
                                    <?= esc(trim(($op['first_name'] ?? '') . ' ' . ($op['last_name'] ?? ''))) ?> (<?= esc($op['employee_code']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">New Designation <span class="text-rose-500">*</span>:</label>
                            <select name="new_designation_id" required class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                                <option value="">-- Select Role --</option>
                                <?php foreach ($designations as $dg): ?>
                                    <option value="<?= esc($dg['id']) ?>"><?= esc($dg['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Effective Date:</label>
                            <input type="date" name="promotion_date" value="<?= date('Y-m-d') ?>" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                        </div>
                    </div>

                    <?php if (!empty($canViewSalary)): ?>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">New Basic Monthly Salary (Optional adjustment):</label>
                        <input type="number" step="0.01" name="new_salary" placeholder="Leave blank to maintain current salary" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl font-mono bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                        <span class="text-[10px] text-slate-400 mt-1 block">Synchronizes via EmployeeSalaryService with compensation history preserved.</span>
                    </div>
                    <?php endif; ?>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Promotion Justification / Memo:</label>
                        <textarea name="reason" rows="2" placeholder="e.g. Promoted following annual performance review." class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white"></textarea>
                    </div>

                    <div class="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-700">
                        <button type="button" @click="promoModalOpen = false" class="px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-bold">Cancel</button>
                        <button type="submit" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold">Submit Promotion</button>
                    </div>
                </form>
            </div>
        </div>
    </template>

    <!-- MODAL: Record Transfer -->
    <template x-if="transferModalOpen">
        <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs" @click.self="transferModalOpen = false">
            <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200 dark:border-slate-700 space-y-4">
                <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                    <h3 class="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                        <i data-lucide="arrow-left-right" class="w-4 h-4 text-indigo-600"></i>
                        Record Employee Transfer
                    </h3>
                    <button type="button" @click="transferModalOpen = false" class="text-slate-400 hover:text-slate-600">
                        <i data-lucide="x" class="w-4 h-4"></i>
                    </button>
                </div>

                <form action="<?= base_url('employees/transfer') ?>" method="POST" class="space-y-4 text-xs">
                    <?= csrf_field() ?>
                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Select Employee <span class="text-rose-500">*</span>:</label>
                        <select name="employee_id" required class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                            <option value="">-- Choose Staff Member --</option>
                            <?php foreach ($employeeOptions as $op): ?>
                                <option value="<?= esc($op['id']) ?>">
                                    <?= esc(trim(($op['first_name'] ?? '') . ' ' . ($op['last_name'] ?? ''))) ?> (<?= esc($op['employee_code']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Target Branch Location:</label>
                            <select name="to_branch_id" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                                <option value="">-- Keep Current Branch --</option>
                                <?php foreach ($branches as $b): ?>
                                    <option value="<?= esc($b['id']) ?>"><?= esc($b['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Target Department:</label>
                            <select name="to_department_id" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                                <option value="">-- Keep Current Dept --</option>
                                <?php foreach ($departments as $d): ?>
                                    <option value="<?= esc($d['id']) ?>"><?= esc($d['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Target Designation:</label>
                            <select name="to_designation_id" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                                <option value="">-- Keep Current Designation --</option>
                                <?php foreach ($designations as $dg): ?>
                                    <option value="<?= esc($dg['id']) ?>"><?= esc($dg['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Transfer Date:</label>
                            <input type="date" name="transfer_date" value="<?= date('Y-m-d') ?>" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
                        </div>
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Transfer Reason / Operational Memo:</label>
                        <textarea name="reason" rows="2" placeholder="e.g. Branch expansion redeployment." class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white"></textarea>
                    </div>

                    <div class="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-700">
                        <button type="button" @click="transferModalOpen = false" class="px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-bold">Cancel</button>
                        <button type="submit" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold">Execute Transfer</button>
                    </div>
                </form>
            </div>
        </div>
    </template>

</div>

<script>
function movementConsole() {
    return {
        promoModalOpen: false,
        transferModalOpen: false,
        init() {
            this.$nextTick(() => { if (window.lucide) lucide.createIcons(); });
        }
    };
}
</script>
