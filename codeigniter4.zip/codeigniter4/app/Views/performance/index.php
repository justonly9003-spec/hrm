<div class="space-y-6">

    <!-- Header & Action Controls -->
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
            <h1 class="text-2xl font-black tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
                <span class="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
                    <i data-lucide="award" class="w-6 h-6"></i>
                </span>
                Performance Management & 360 Appraisals
            </h1>
            <p class="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1">
                Multi-tier scoring engine (Self 20%, Peer 20%, Manager 40%, KPI 20%), OKR goal tracking, and automated merit promotion matrix.
            </p>
        </div>

        <div class="flex flex-wrap items-center gap-2.5">
            <a href="<?= base_url('performance/export-csv') ?>" class="px-3.5 py-2 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold flex items-center gap-1.5 transition shadow-xs">
                <i data-lucide="download" class="w-4 h-4 text-slate-500"></i> Export CSV
            </a>
            
            <button onclick="openModal('reviewModal')" class="tab-action-btn action-reviews px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition shadow-md shadow-indigo-600/10">
                <i data-lucide="award" class="w-4 h-4"></i> Conduct 360 Appraisal
            </button>

            <button onclick="openModal('goalModal')" class="tab-action-btn action-goals px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition shadow-md shadow-indigo-600/10 hidden">
                <i data-lucide="trending-up" class="w-4 h-4"></i> Set Goal / OKR
            </button>

            <button onclick="openModal('kpiModal')" class="tab-action-btn action-kpis px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition shadow-md shadow-indigo-600/10 hidden">
                <i data-lucide="layers" class="w-4 h-4"></i> Add Designation KPI
            </button>

            <button onclick="openModal('promoModal')" class="tab-action-btn action-promotions px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition shadow-md shadow-indigo-600/10 hidden">
                <i data-lucide="arrow-up-right" class="w-4 h-4"></i> Initiate Promotion
            </button>
        </div>
    </div>

    <!-- Performance Analytics Metric Strip -->
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 shadow-xs space-y-1">
            <div class="flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400">
                <span>Avg 360 Score</span>
                <i data-lucide="star" class="w-4 h-4 text-amber-500"></i>
            </div>
            <div class="flex items-baseline gap-2">
                <span class="text-2xl font-black font-mono text-indigo-600 dark:text-indigo-400"><?= esc($stats['average_score'] ?? '0.0') ?></span>
                <span class="text-xs text-slate-400">/ 100</span>
            </div>
            <span class="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium">
                <?= esc($stats['exceeds_expectations_count'] ?? 0) ?> Exceeds Expectations
            </span>
        </div>

        <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 shadow-xs space-y-1">
            <div class="flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400">
                <span>OKR Completion</span>
                <i data-lucide="target" class="w-4 h-4 text-emerald-500"></i>
            </div>
            <div class="flex items-baseline gap-2">
                <span class="text-2xl font-black font-mono text-slate-900 dark:text-white"><?= esc($stats['goal_completion_rate'] ?? '0') ?>%</span>
                <span class="text-xs text-slate-400"><?= esc($stats['achieved_goals'] ?? 0) ?> of <?= esc($stats['total_goals'] ?? 0) ?></span>
            </div>
            <span class="text-[11px] text-slate-500 dark:text-slate-400">
                <?= esc($stats['ongoing_goals'] ?? 0) ?> Active Initiatives
            </span>
        </div>

        <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 shadow-xs space-y-1">
            <div class="flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400">
                <span>Designation KPIs</span>
                <i data-lucide="bar-chart-2" class="w-4 h-4 text-indigo-500"></i>
            </div>
            <div class="flex items-baseline gap-2">
                <span class="text-2xl font-black font-mono text-slate-900 dark:text-white"><?= esc($stats['total_kpis'] ?? 0) ?></span>
                <span class="text-xs text-slate-400">Profiles</span>
            </div>
            <span class="text-[11px] text-indigo-600 dark:text-indigo-400 font-medium">
                Weighted Benchmarks Active
            </span>
        </div>

        <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 shadow-xs space-y-1">
            <div class="flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400">
                <span>Promotion Pipeline</span>
                <i data-lucide="trending-up" class="w-4 h-4 text-purple-500"></i>
            </div>
            <div class="flex items-baseline gap-2">
                <span class="text-2xl font-black font-mono text-purple-600 dark:text-purple-400"><?= esc($stats['pending_promotions'] ?? 0) ?></span>
                <span class="text-xs text-slate-400">Pending</span>
            </div>
            <span class="text-[11px] text-slate-500 dark:text-slate-400">
                <?= esc($stats['total_promotions'] ?? 0) ?> Total Records
            </span>
        </div>
    </div>

    <!-- Navigation Sub-Tabs -->
    <div class="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-1 overflow-x-auto">
        <button onclick="switchTab('reviews')" id="tab-btn-reviews" class="tab-nav-btn px-4 py-2 text-xs font-bold rounded-xl transition whitespace-nowrap bg-indigo-600 text-white shadow-xs">
            🌟 360 Appraisals & Score Matrix
        </button>
        <button onclick="switchTab('goals')" id="tab-btn-goals" class="tab-nav-btn px-4 py-2 text-xs font-bold rounded-xl transition whitespace-nowrap text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800">
            🎯 Employee Goals & OKR Tracking
        </button>
        <button onclick="switchTab('kpis')" id="tab-btn-kpis" class="tab-nav-btn px-4 py-2 text-xs font-bold rounded-xl transition whitespace-nowrap text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800">
            📐 Designation KPI Weight Distributions
        </button>
        <button onclick="switchTab('promotions')" id="tab-btn-promotions" class="tab-nav-btn px-4 py-2 text-xs font-bold rounded-xl transition whitespace-nowrap text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800">
            🚀 Promotion & Merit Increment Pipeline
        </button>
    </div>

    <!-- ========================================== -->
    <!-- SUB-TAB 1: 360 APPRAISALS & SCORE MATRIX -->
    <!-- ========================================== -->
    <div id="subtab-reviews" class="subtab-content space-y-4">
        <?php if (empty($reviews)): ?>
            <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-12 text-center space-y-3">
                <div class="w-12 h-12 rounded-full bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto">
                    <i data-lucide="award" class="w-6 h-6"></i>
                </div>
                <h3 class="text-base font-bold text-slate-800 dark:text-white">No 360 Appraisals Recorded</h3>
                <p class="text-xs text-slate-500 max-w-sm mx-auto">Start an appraisal cycle to calculate multi-tier scores (Self 20%, Peer 20%, Manager 40%, KPI 20%).</p>
                <button onclick="openModal('reviewModal')" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold inline-flex items-center gap-1.5">
                    <i data-lucide="plus" class="w-4 h-4"></i> Conduct First Appraisal
                </button>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <?php foreach ($reviews as $rev): ?>
                    <div class="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-5 shadow-xs space-y-4">
                        <div class="flex items-start justify-between">
                            <div>
                                <span class="text-[10px] font-mono text-slate-400 font-bold block uppercase tracking-wider">
                                    <?= esc($rev['id']) ?> | <?= esc($rev['cycle_name'] ?? 'Annual Appraisal') ?>
                                </span>
                                <h3 class="font-extrabold text-slate-900 dark:text-white text-sm mt-0.5"><?= esc($rev['employee_name'] ?? 'Employee') ?></h3>
                                <span class="text-[11px] text-slate-500 dark:text-slate-400 font-mono"><?= esc($rev['employee_code'] ?? $rev['employee_id']) ?> • <?= esc($rev['designation_title'] ?? $rev['department_name'] ?? 'Staff') ?></span>
                            </div>

                            <div class="text-right">
                                <span class="text-2xl font-black font-mono text-indigo-600 dark:text-indigo-400 block">
                                    <?= number_format((float)($rev['aggregate_score'] ?? 0), 1) ?>
                                </span>
                                <span class="text-[10px] text-slate-400">/ 100 Aggregate</span>
                            </div>
                        </div>

                        <!-- 4-Way Score Breakdown Chips -->
                        <div class="grid grid-cols-4 gap-2 pt-1 text-center">
                            <div class="p-2 bg-slate-50 dark:bg-slate-900/60 rounded-xl border border-slate-100 dark:border-slate-800">
                                <span class="text-[9px] text-slate-400 font-bold block">Self (20%)</span>
                                <span class="font-bold text-xs font-mono text-slate-700 dark:text-slate-300"><?= esc($rev['self_score'] ?? 85) ?></span>
                            </div>
                            <div class="p-2 bg-slate-50 dark:bg-slate-900/60 rounded-xl border border-slate-100 dark:border-slate-800">
                                <span class="text-[9px] text-slate-400 font-bold block">Peer (20%)</span>
                                <span class="font-bold text-xs font-mono text-slate-700 dark:text-slate-300"><?= esc($rev['peer_score'] ?? 85) ?></span>
                            </div>
                            <div class="p-2 bg-slate-50 dark:bg-slate-900/60 rounded-xl border border-slate-100 dark:border-slate-800">
                                <span class="text-[9px] text-slate-400 font-bold block">Mgr (40%)</span>
                                <span class="font-bold text-xs font-mono text-indigo-600 dark:text-indigo-400"><?= esc($rev['manager_score'] ?? 90) ?></span>
                            </div>
                            <div class="p-2 bg-slate-50 dark:bg-slate-900/60 rounded-xl border border-slate-100 dark:border-slate-800">
                                <span class="text-[9px] text-slate-400 font-bold block">KPI (20%)</span>
                                <span class="font-bold text-xs font-mono text-slate-700 dark:text-slate-300"><?= esc($rev['kpi_score'] ?? 88) ?></span>
                            </div>
                        </div>

                        <div class="p-3 bg-indigo-50/60 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/50 rounded-xl space-y-1 text-xs">
                            <span class="font-bold text-indigo-900 dark:text-indigo-300 block text-[11px]"><?= esc($rev['rating_class'] ?? 'Meets Expectations') ?></span>
                            <p class="text-indigo-800 dark:text-indigo-400 text-[11px] font-medium"><?= esc($rev['recommendation'] ?? 'Standard Merit Increment') ?></p>
                        </div>

                        <p class="text-xs text-slate-600 dark:text-slate-300 italic">"<?= esc($rev['comments'] ?? '') ?>"</p>

                        <div class="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-700/60 text-xs">
                            <?php 
                                $stage = $rev['stage'] ?? 'Manager_Reviewed';
                                $badgeClass = ($stage === 'HR_Closed') 
                                    ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                                    : (($stage === 'Manager_Reviewed') 
                                        ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800'
                                        : 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 border-amber-200 dark:border-amber-800');
                            ?>
                            <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold border <?= $badgeClass ?>">
                                Stage: <?= esc(str_replace('_', ' ', $stage)) ?>
                            </span>

                            <?php if ($stage === 'Manager_Reviewed'): ?>
                                <form method="POST" action="<?= base_url('performance/advance-stage/' . $rev['id']) ?>" class="inline">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="stage" value="HR_Closed">
                                    <button type="submit" class="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-[10px] transition shadow-xs flex items-center gap-1">
                                        <i data-lucide="check-circle-2" class="w-3 h-3"></i> Close & Endorse to Payroll
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- ========================================== -->
    <!-- SUB-TAB 2: GOALS / OKRs -->
    <!-- ========================================== -->
    <div id="subtab-goals" class="subtab-content space-y-4 hidden">
        <div class="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl shadow-xs overflow-hidden p-6 space-y-4">
            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                <div>
                    <h3 class="text-sm font-extrabold text-slate-800 dark:text-white">Active Strategic Goals & OKRs</h3>
                    <p class="text-xs text-slate-500">Track quarterly deliverables, sprint milestones, and progress completion rates.</p>
                </div>
                <button onclick="openModal('goalModal')" class="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1">
                    <i data-lucide="plus" class="w-3.5 h-3.5"></i> Set New Goal
                </button>
            </div>

            <?php if (empty($goals)): ?>
                <div class="py-8 text-center text-slate-400 text-xs">No goals currently registered. Click 'Set New Goal' to assign initiatives.</div>
            <?php else: ?>
                <div class="space-y-3">
                    <?php foreach ($goals as $g): ?>
                        <div class="p-4 bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700/80 rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                            <div class="space-y-1">
                                <span class="font-bold text-slate-800 dark:text-white text-xs block"><?= esc($g['title']) ?></span>
                                <span class="text-[10px] text-slate-500 dark:text-slate-400">
                                    <?= esc($g['employee_name']) ?> (<?= esc($g['employee_code'] ?? $g['employee_id']) ?>) • Target Completion: <?= esc($g['target_date']) ?>
                                </span>
                            </div>

                            <div class="flex items-center gap-3 w-full sm:w-auto justify-end">
                                <div class="w-28 sm:w-36 bg-slate-200 dark:bg-slate-700 h-2.5 rounded-full overflow-hidden">
                                    <div class="bg-indigo-600 h-full rounded-full transition-all duration-300" style="width: <?= min(100, max(0, (int)$g['progress_pct'])) ?>%"></div>
                                </div>
                                <span class="font-mono text-xs font-bold text-slate-700 dark:text-slate-300 w-10 text-right"><?= (int)$g['progress_pct'] ?>%</span>

                                <?php if ((int)$g['progress_pct'] < 100): ?>
                                    <form method="POST" action="<?= base_url('performance/goal/update-progress/' . $g['id']) ?>" class="inline">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="progress_pct" value="<?= min(100, (int)$g['progress_pct'] + 25) ?>">
                                        <button type="submit" class="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 rounded-lg text-[10px] font-bold transition">
                                            +25% Progress
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <span class="px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 rounded-lg text-[10px] font-bold border border-emerald-200 dark:border-emerald-800">
                                        Achieved
                                    </span>
                                <?php endif; ?>

                                <form method="POST" action="<?= base_url('performance/goal/delete/' . $g['id']) ?>" class="inline" onsubmit="return confirm('Delete this goal?')">
                                    <?= csrf_field() ?>
                                    <button type="submit" class="p-1 text-slate-400 hover:text-rose-600 transition" title="Delete goal">
                                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ========================================== -->
    <!-- SUB-TAB 3: DESIGNATION KPIS -->
    <!-- ========================================== -->
    <div id="subtab-kpis" class="subtab-content space-y-4 hidden">
        <div class="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl shadow-xs overflow-hidden p-6 space-y-4">
            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                <div>
                    <h3 class="text-sm font-extrabold text-slate-800 dark:text-white">Designation KPI Weight Distributions</h3>
                    <p class="text-xs text-slate-500">Structured competency guidelines and percentage allocations per role.</p>
                </div>
                <button onclick="openModal('kpiModal')" class="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1">
                    <i data-lucide="plus" class="w-3.5 h-3.5"></i> Define KPI
                </button>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse text-xs">
                    <thead>
                        <tr class="bg-slate-50 dark:bg-slate-900/60 border-b border-slate-100 dark:border-slate-700/80 text-slate-500 dark:text-slate-400 font-bold">
                            <th class="p-3">Designation Position</th>
                            <th class="p-3">KPI Name</th>
                            <th class="p-3">Target Objective Metric</th>
                            <th class="p-3 font-mono">Weight Allocation</th>
                            <th class="p-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-700/60">
                        <?php if (empty($kpis)): ?>
                            <tr>
                                <td colspan="5" class="p-6 text-center text-slate-400">No KPIs configured. Click 'Define KPI' to create benchmark targets.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($kpis as $k): ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                                    <td class="p-3 font-bold text-slate-800 dark:text-white"><?= esc($k['designation_title'] ?? 'Role') ?></td>
                                    <td class="p-3 font-semibold text-indigo-600 dark:text-indigo-400"><?= esc($k['kpi_name']) ?></td>
                                    <td class="p-3 text-slate-600 dark:text-slate-300"><?= esc($k['target_metric']) ?></td>
                                    <td class="p-3 font-mono font-bold text-slate-800 dark:text-white"><?= (int)$k['weight'] ?>%</td>
                                    <td class="p-3 text-right">
                                        <form method="POST" action="<?= base_url('performance/kpi/delete/' . $k['id']) ?>" class="inline" onsubmit="return confirm('Delete this KPI definition?')">
                                            <?= csrf_field() ?>
                                            <button type="submit" class="text-rose-500 hover:text-rose-700 p-1" title="Delete KPI">
                                                <i data-lucide="trash" class="w-3.5 h-3.5 inline"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- ========================================== -->
    <!-- SUB-TAB 4: PROMOTION PIPELINE -->
    <!-- ========================================== -->
    <div id="subtab-promotions" class="subtab-content space-y-4 hidden">
        <div class="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl shadow-xs overflow-hidden p-6 space-y-4">
            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                <div>
                    <h3 class="text-sm font-extrabold text-slate-800 dark:text-white">Promotion & Merit Increment Register</h3>
                    <p class="text-xs text-slate-500">Tracks salary upgrades, rank elevations, and executive approval chains.</p>
                </div>
                <button onclick="openModal('promoModal')" class="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1">
                    <i data-lucide="plus" class="w-3.5 h-3.5"></i> Initiate Promotion
                </button>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse text-xs">
                    <thead>
                        <tr class="bg-slate-50 dark:bg-slate-900/60 border-b border-slate-100 dark:border-slate-700/80 text-slate-500 dark:text-slate-400 font-bold">
                            <th class="p-3">Employee</th>
                            <th class="p-3">Previous Position & Salary</th>
                            <th class="p-3">Promoted Position & New Salary</th>
                            <th class="p-3">Effective Date</th>
                            <th class="p-3">Status</th>
                            <th class="p-3 text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-700/60">
                        <?php if (empty($promotions)): ?>
                            <tr>
                                <td colspan="6" class="p-6 text-center text-slate-400">No promotions recorded in pipeline.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($promotions as $p): ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                                    <td class="p-3 font-bold text-slate-800 dark:text-white">
                                        <?= esc($p['employee_name']) ?>
                                        <div class="text-[10px] text-slate-400 font-normal font-mono"><?= esc($p['employee_code'] ?? $p['employee_id']) ?></div>
                                    </td>
                                    <td class="p-3 text-slate-600 dark:text-slate-300">
                                        <?= esc($p['previous_designation_title'] ?? 'Officer') ?>
                                        <span class="text-slate-400 block font-mono">$<?= number_format((float)($p['previous_salary'] ?? 0)) ?></span>
                                    </td>
                                    <td class="p-3 font-semibold text-indigo-600 dark:text-indigo-400">
                                        <?= esc($p['new_designation_title'] ?? 'Senior') ?>
                                        <span class="text-indigo-700 dark:text-indigo-300 block font-mono font-bold">$<?= number_format((float)($p['new_salary'] ?? 0)) ?></span>
                                    </td>
                                    <td class="p-3 font-mono text-slate-600 dark:text-slate-300"><?= esc($p['effective_date'] ?? date('Y-m-d')) ?></td>
                                    <td class="p-3">
                                        <?php 
                                            $pStatus = $p['status'] ?? 'Pending_Approval';
                                            $badge = ($pStatus === 'Approved') 
                                                ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 border-emerald-200' 
                                                : 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 border-amber-200';
                                        ?>
                                        <span class="px-2 py-0.5 rounded-full text-[10px] font-bold border <?= $badge ?>">
                                            <?= esc(str_replace('_', ' ', $pStatus)) ?>
                                        </span>
                                    </td>
                                    <td class="p-3 text-right">
                                        <?php if ($pStatus === 'Pending_Approval'): ?>
                                            <div class="inline-flex items-center gap-1.5 justify-end">
                                                <form method="POST" action="<?= base_url('performance/promotion/approve/' . $p['id']) ?>" class="inline">
                                                    <?= csrf_field() ?>
                                                    <button type="submit" class="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-[10px] transition inline-flex items-center gap-1 shadow-xs">
                                                        <i data-lucide="check" class="w-3 h-3"></i> Approve
                                                    </button>
                                                </form>
                                                <form method="POST" action="<?= base_url('performance/promotion/reject/' . $p['id']) ?>" class="inline" onsubmit="return confirm('Reject this promotion request?')">
                                                    <?= csrf_field() ?>
                                                    <button type="submit" class="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 rounded-lg font-bold text-[10px] transition inline-flex items-center gap-1 border border-rose-200 dark:border-rose-800">
                                                        <i data-lucide="x" class="w-3 h-3"></i> Reject
                                                    </button>
                                                </form>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-[10px] text-slate-400 font-mono">Completed</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<!-- ========================================== -->
<!-- MODAL 1: CONDUCT 360 APPRAISAL -->
<!-- ========================================== -->
<div id="reviewModal" class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 hidden">
    <div class="bg-white dark:bg-slate-800 rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-700 max-h-[90vh] overflow-y-auto space-y-4">
        <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700">
            <div>
                <h3 class="text-base font-bold text-slate-800 dark:text-white">Conduct 360 Performance Appraisal</h3>
                <p class="text-xs text-slate-500">Calculates weighted scores (Self 20%, Peer 20%, Manager 40%, KPI 20%).</p>
            </div>
            <button onclick="closeModal('reviewModal')" class="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>

        <form method="POST" action="<?= base_url('performance/submit-360') ?>" class="space-y-4 text-xs">
            <?= csrf_field() ?>
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Select Employee:</label>
                <select name="employee_id" required class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 focus:outline-none">
                    <option value="">-- Choose Employee --</option>
                    <?php foreach ($employees as $emp): ?>
                        <option value="<?= esc($emp['id']) ?>"><?= esc($emp['first_name'] . ' ' . $emp['last_name']) ?> (<?= esc($emp['employee_code']) ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Appraisal Cycle Name:</label>
                <input type="text" name="cycle_name" value="Annual Appraisal <?= date('Y') ?>" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 font-medium" required>
            </div>

            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Self Review (20%):</label>
                    <input type="number" min="0" max="100" id="in_self" name="self_score" value="85" oninput="calcPreview()" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 font-mono text-slate-800 dark:text-slate-200" required>
                </div>
                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Peer Review (20%):</label>
                    <input type="number" min="0" max="100" id="in_peer" name="peer_score" value="88" oninput="calcPreview()" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 font-mono text-slate-800 dark:text-slate-200" required>
                </div>
            </div>

            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Manager Review (40%):</label>
                    <input type="number" min="0" max="100" id="in_mgr" name="manager_score" value="92" oninput="calcPreview()" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 font-mono text-slate-800 dark:text-slate-200" required>
                </div>
                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Objective KPI Score (20%):</label>
                    <input type="number" min="0" max="100" id="in_kpi" name="kpi_score" value="90" oninput="calcPreview()" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 font-mono text-slate-800 dark:text-slate-200" required>
                </div>
            </div>

            <!-- Real-time Score preview strip -->
            <div class="p-3 rounded-xl bg-indigo-50/70 dark:bg-indigo-950/50 border border-indigo-100 dark:border-indigo-900/60 flex items-center justify-between">
                <div>
                    <span class="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Calculated Aggregate</span>
                    <span id="preview_class" class="font-bold text-indigo-700 dark:text-indigo-300 text-xs">Exceeds Expectations</span>
                </div>
                <div class="text-right">
                    <span id="preview_score" class="text-xl font-black font-mono text-indigo-600 dark:text-indigo-400">90.2</span>
                    <span class="text-[10px] text-slate-400">/ 100</span>
                </div>
            </div>

            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Evaluation Notes & Recommendations:</label>
                <textarea name="comments" rows="3" required placeholder="Key accomplishments, growth areas, merit promotion recommendation..." class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 focus:outline-none"></textarea>
            </div>

            <div class="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-700">
                <button type="button" onclick="closeModal('reviewModal')" class="px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-bold">Cancel</button>
                <button type="submit" class="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold shadow-md shadow-indigo-600/10">Submit 360 Appraisal</button>
            </div>
        </form>
    </div>
</div>

<!-- ========================================== -->
<!-- MODAL 2: SET GOAL / OKR -->
<!-- ========================================== -->
<div id="goalModal" class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 hidden">
    <div class="bg-white dark:bg-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-700 space-y-4">
        <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700">
            <h3 class="text-base font-bold text-slate-800 dark:text-white">Set Employee Goal / OKR</h3>
            <button onclick="closeModal('goalModal')" class="text-slate-400 hover:text-slate-600"><i data-lucide="x" class="w-5 h-5"></i></button>
        </div>
        <form method="POST" action="<?= base_url('performance/goal/create') ?>" class="space-y-3 text-xs">
            <?= csrf_field() ?>
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Employee:</label>
                <select name="employee_id" required class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200">
                    <?php foreach ($employees as $emp): ?>
                        <option value="<?= esc($emp['id']) ?>"><?= esc($emp['first_name'] . ' ' . $emp['last_name']) ?> (<?= esc($emp['employee_code']) ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Goal Title:</label>
                <input type="text" name="title" placeholder="e.g. Implement automated unit testing suite" required class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200">
            </div>
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Target Completion Date:</label>
                <input type="date" name="target_date" value="<?= date('Y-m-d', strtotime('+30 days')) ?>" required class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 font-mono">
            </div>
            <div class="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-700">
                <button type="button" onclick="closeModal('goalModal')" class="px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-bold">Cancel</button>
                <button type="submit" class="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold">Create Goal</button>
            </div>
        </form>
    </div>
</div>

<!-- ========================================== -->
<!-- MODAL 3: ADD DESIGNATION KPI -->
<!-- ========================================== -->
<div id="kpiModal" class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 hidden">
    <div class="bg-white dark:bg-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-700 space-y-4">
        <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700">
            <h3 class="text-base font-bold text-slate-800 dark:text-white">Define Designation KPI</h3>
            <button onclick="closeModal('kpiModal')" class="text-slate-400 hover:text-slate-600"><i data-lucide="x" class="w-5 h-5"></i></button>
        </div>
        <form method="POST" action="<?= base_url('performance/kpi/save') ?>" class="space-y-3 text-xs">
            <?= csrf_field() ?>
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Target Designation:</label>
                <select name="designation_id" required class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200">
                    <?php foreach ($designations as $d): ?>
                        <option value="<?= esc($d['id']) ?>"><?= esc($d['name'] ?? $d['title'] ?? 'Role') ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">KPI Title:</label>
                <input type="text" name="kpi_name" placeholder="e.g. Platform Uptime & SLA Maintenance" required class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200">
            </div>
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Target Objective Metric:</label>
                <textarea name="target_metric" rows="2" placeholder="e.g. Maintain 99.95% production uptime, zero fatal data loss events" required class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200"></textarea>
            </div>
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Weight Allocation (%):</label>
                <input type="number" min="1" max="100" name="weight" value="30" required class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 font-mono text-slate-800 dark:text-slate-200">
            </div>
            <div class="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-700">
                <button type="button" onclick="closeModal('kpiModal')" class="px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-bold">Cancel</button>
                <button type="submit" class="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold">Save KPI Metric</button>
            </div>
        </form>
    </div>
</div>

<!-- ========================================== -->
<!-- MODAL 4: INITIATE PROMOTION -->
<!-- ========================================== -->
<div id="promoModal" class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 hidden">
    <div class="bg-white dark:bg-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-700 space-y-4">
        <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700">
            <h3 class="text-base font-bold text-slate-800 dark:text-white">Initiate Promotion / Increment</h3>
            <button onclick="closeModal('promoModal')" class="text-slate-400 hover:text-slate-600"><i data-lucide="x" class="w-5 h-5"></i></button>
        </div>
        <form method="POST" action="<?= base_url('performance/promotion/initiate') ?>" class="space-y-3 text-xs">
            <?= csrf_field() ?>
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Select Employee:</label>
                <select name="employee_id" required class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200">
                    <option value="">-- Select Employee --</option>
                    <?php foreach ($employees as $emp): ?>
                        <option value="<?= esc($emp['id']) ?>"><?= esc($emp['first_name'] . ' ' . $emp['last_name']) ?> (Current Salary: $<?= number_format((float)($emp['basic_salary'] ?? 0)) ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">New Target Position:</label>
                <select name="new_designation_id" required class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200">
                    <option value="">-- Choose New Designation --</option>
                    <?php foreach ($designations as $d): ?>
                        <option value="<?= esc($d['id']) ?>"><?= esc($d['name'] ?? $d['title'] ?? 'Role') ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <div class="flex items-center justify-between mb-1">
                    <label class="block font-semibold text-slate-700 dark:text-slate-300">New Adjusted Basic Salary ($ BDT):</label>
                    <a href="<?= base_url('payroll?tab=structures&subtab=assignment') ?>" target="_blank" class="text-[11px] text-indigo-600 dark:text-indigo-400 font-semibold hover:underline flex items-center gap-0.5">
                        <span>Salary Assignments</span>
                        <i data-lucide="external-link" class="w-3 h-3"></i>
                    </a>
                </div>
                <input type="number" step="100" min="0" name="new_salary" placeholder="e.g. 65000" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 font-mono text-slate-800 dark:text-slate-200">
                <span class="text-[10px] text-slate-400 mt-0.5 block">Approved salary syncs via EmployeeSalaryService::assignSalary.</span>
            </div>
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Effective Date:</label>
                <input type="date" name="effective_date" value="<?= date('Y-m-d') ?>" required class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 font-mono text-slate-800 dark:text-slate-200">
            </div>
            <div>
                <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Appraisal Basis / Remarks:</label>
                <input type="text" name="remarks" placeholder="High appraisal score, leadership endorsement" class="w-full p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200">
            </div>
            <div class="flex items-center gap-2 pt-1">
                <input type="checkbox" id="auto_approve" name="auto_approve" value="1" class="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500">
                <label for="auto_approve" class="text-[11px] text-slate-600 dark:text-slate-300">Auto-Approve & Apply to Employee Master</label>
            </div>
            <div class="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-700">
                <button type="button" onclick="closeModal('promoModal')" class="px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-bold">Cancel</button>
                <button type="submit" class="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold">Submit for Approval</button>
            </div>
        </form>
    </div>
</div>

<script>
    function switchTab(tabId) {
        // Update content visibility
        document.querySelectorAll('.subtab-content').forEach(el => el.classList.add('hidden'));
        const target = document.getElementById('subtab-' + tabId);
        if (target) target.classList.remove('hidden');

        // Update button styles
        document.querySelectorAll('.tab-nav-btn').forEach(btn => {
            btn.className = 'tab-nav-btn px-4 py-2 text-xs font-bold rounded-xl transition whitespace-nowrap text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800';
        });
        const activeBtn = document.getElementById('tab-btn-' + tabId);
        if (activeBtn) {
            activeBtn.className = 'tab-nav-btn px-4 py-2 text-xs font-bold rounded-xl transition whitespace-nowrap bg-indigo-600 text-white shadow-xs';
        }

        // Toggle top action button
        document.querySelectorAll('.tab-action-btn').forEach(b => b.classList.add('hidden'));
        const actionBtn = document.querySelector('.action-' + tabId);
        if (actionBtn) actionBtn.classList.remove('hidden');

        // Save state
        localStorage.setItem('subtab_performance_eval', tabId);
        if (window.history.replaceState) {
            window.history.replaceState(null, null, '#' + tabId);
        }
    }

    function openModal(id) {
        const m = document.getElementById(id);
        if (m) m.classList.remove('hidden');
    }

    function closeModal(id) {
        const m = document.getElementById(id);
        if (m) m.classList.add('hidden');
    }

    function calcPreview() {
        const s = parseFloat(document.getElementById('in_self')?.value || 85);
        const p = parseFloat(document.getElementById('in_peer')?.value || 88);
        const m = parseFloat(document.getElementById('in_mgr')?.value || 92);
        const k = parseFloat(document.getElementById('in_kpi')?.value || 90);

        const agg = (s * 0.20) + (p * 0.20) + (m * 0.40) + (k * 0.20);
        const rounded = Math.round(agg * 10) / 10;

        const scoreEl = document.getElementById('preview_score');
        const classEl = document.getElementById('preview_class');

        if (scoreEl) scoreEl.textContent = rounded.toFixed(1);

        if (classEl) {
            if (rounded >= 90) {
                classEl.textContent = 'Exceeds Expectations (15% Increment)';
            } else if (rounded >= 75) {
                classEl.textContent = 'Meets Expectations (8% Increment)';
            } else if (rounded >= 60) {
                classEl.textContent = 'Developing (4% Adjustment)';
            } else {
                classEl.textContent = 'Needs Improvement (PIP Required)';
            }
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        // Determine initial subtab
        const hash = window.location.hash.replace('#', '');
        const saved = localStorage.getItem('subtab_performance_eval');
        const valid = ['reviews', 'goals', 'kpis', 'promotions'];
        const initial = valid.includes(hash) ? hash : (valid.includes(saved) ? saved : 'reviews');
        switchTab(initial);
        calcPreview();

        if (window.lucide) {
            window.lucide.createIcons();
        }
    });
</script>
