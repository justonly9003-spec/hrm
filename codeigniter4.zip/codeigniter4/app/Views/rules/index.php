<div x-data="ruleEngineApp()" x-init="init()" class="space-y-4 w-full pb-28" x-cloak>
    <!-- Canonical Rule Engine Sub-Navigation Bar -->
    <?= view('partials/rules_nav', ['activeTab' => $activeTab ?? 'OVERVIEW', 'allowedDomains' => $allowedDomains ?? [], 'canManage' => $canManage ?? false]) ?>

    <!-- Compact Header (Active when in a specific domain) -->
    <div x-show="activeDomain !== 'OVERVIEW'" class="bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200/80 dark:border-slate-800 shadow-sm transition">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div class="space-y-1">
                <div class="flex items-center gap-2.5 flex-wrap">
                    <div class="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
                        <i :data-lucide="getDomainIcon(activeDomain)" class="w-4 h-4"></i>
                    </div>
                    <h1 class="text-lg sm:text-xl font-black text-slate-900 dark:text-white" x-text="getDomainTitle(activeDomain)"></h1>

                    <!-- Status Chip -->
                    <template x-if="isDirty">
                        <span class="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border border-amber-300 dark:border-amber-700 flex items-center gap-1.5">
                            <span class="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span>
                            Unsaved changes
                        </span>
                    </template>
                    <template x-if="!isDirty && activeVersion">
                        <span class="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700 flex items-center gap-1.5">
                            <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                            <span x-text="'Live since ' + formatDisplayDate(activeVersion.effective_from)"></span>
                        </span>
                    </template>
                    <template x-if="!isDirty && !activeVersion">
                        <span class="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border border-slate-300 dark:border-slate-700">
                            Draft
                        </span>
                    </template>

                    <!-- Last Changed Info -->
                    <template x-if="lastChangeInfo">
                        <span class="text-xs text-slate-500 dark:text-slate-400 font-medium" x-text="'• Last changed by ' + lastChangeInfo.user + ' on ' + lastChangeInfo.date"></span>
                    </template>
                </div>
                <p class="text-xs text-slate-500 dark:text-slate-400 max-w-2xl" x-text="getDomainDescription(activeDomain)"></p>
            </div>

            <!-- Header Quick Actions -->
            <div class="flex items-center gap-2 shrink-0">
                <button 
                    type="button" 
                    @click="openExplainModal()"
                    class="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-semibold text-xs transition flex items-center gap-1.5 cursor-pointer"
                    title="Inspect resolved rule snapshot"
                >
                    <i data-lucide="microscope" class="w-3.5 h-3.5 text-indigo-500"></i>
                    <span>Explain Snapshot</span>
                </button>
            </div>
        </div>
    </div>

    <!-- Overview Top Banner (Only on OVERVIEW tab) -->
    <div x-show="activeDomain === 'OVERVIEW'" class="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-4 sm:p-5 text-white shadow-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
            <h1 class="text-lg sm:text-xl font-black text-white flex items-center gap-2">
                <i data-lucide="layers" class="w-5 h-5 text-indigo-400"></i>
                Company Business Policies & Rules
            </h1>
            <p class="text-xs text-slate-300 mt-1 max-w-2xl">
                Configure attendance, leave, overtime, bonus, provident fund, gratuity, final settlements, and tax calculation rules.
            </p>
        </div>
        <div class="flex items-center gap-2">
            <button 
                type="button" 
                @click="fetchOverview(true)"
                :disabled="overviewLoading"
                class="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs border border-white/20 transition flex items-center gap-1.5 cursor-pointer shadow-sm disabled:opacity-50"
            >
                <i data-lucide="refresh-cw" class="w-3.5 h-3.5" :class="{ 'animate-spin': overviewLoading }"></i>
                <span>Refresh</span>
            </button>
            <a 
                href="<?= base_url('payroll') ?>" 
                class="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
                <i data-lucide="banknote" class="w-3.5 h-3.5"></i>
                <span>Payroll →</span>
            </a>
        </div>
    </div>

    <!-- Alert / Toast Messages -->
    <div x-show="globalError" class="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200 text-xs font-semibold flex items-start gap-3 shadow-xs">
        <i data-lucide="alert-triangle" class="w-4 h-4 text-rose-600 shrink-0 mt-0.5"></i>
        <div class="flex-1">
            <span class="font-bold">Error: </span>
            <span x-text="globalError"></span>
        </div>
        <button type="button" @click="globalError = ''" class="text-rose-500 hover:text-rose-700">
            <i data-lucide="x" class="w-4 h-4"></i>
        </button>
    </div>

    <!-- Applied Toast Floating Alert -->
    <div 
        x-show="appliedToast" 
        x-transition:enter="transition ease-out duration-300 transform"
        x-transition:enter-start="opacity-0 translate-y-2 scale-95"
        x-transition:enter-end="opacity-100 translate-y-0 scale-100"
        x-transition:leave="transition ease-in duration-200 transform"
        x-transition:leave-start="opacity-100 translate-y-0 scale-100"
        x-transition:leave-end="opacity-0 translate-y-2 scale-95"
        class="fixed top-5 right-5 z-50 p-4 rounded-2xl bg-emerald-600 text-white shadow-2xl flex items-center gap-3 border border-emerald-500"
    >
        <div class="w-7 h-7 rounded-full bg-emerald-500/40 flex items-center justify-center">
            <i data-lucide="check" class="w-4 h-4 text-white"></i>
        </div>
        <div>
            <div class="font-black text-xs">Rule Published Successfully</div>
            <div class="text-[11px] text-emerald-100" x-text="appliedToast"></div>
        </div>
        <button type="button" @click="appliedToast = null" class="text-emerald-200 hover:text-white ml-2">
            <i data-lucide="x" class="w-3.5 h-3.5"></i>
        </button>
    </div>

    <!-- Small Compact Card View: Scope Selection & Effective Date + Reason -->
    <template x-if="activeDomain !== 'OVERVIEW'">
        <div class="max-w-4xl grid grid-cols-1 md:grid-cols-2 gap-3 items-start">
            <!-- Card 1: Scope & Applicability Small Card -->
            <div class="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs p-3.5 space-y-2.5 transition">
                <div class="flex items-center justify-between gap-2">
                    <div class="flex items-center gap-2 min-w-0">
                        <span class="w-2 h-2 rounded-full bg-indigo-500 shrink-0"></span>
                        <span class="text-xs text-slate-500 dark:text-slate-400 font-medium">Applies to:</span>
                        <span class="text-xs font-bold text-slate-900 dark:text-white truncate" x-text="selectedScopeLevel === 'Company' ? 'Whole company' : (selectedScopeLevel + ' · ' + getSelectedScopeEntityName())"></span>
                    </div>
                    <template x-if="selectedScopeLevel !== 'Company'">
                        <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 shrink-0">Override Active</span>
                    </template>
                </div>

                <!-- Scope Selection Options Directly Displayed -->
                <div class="space-y-2 pt-1 border-t border-slate-100 dark:border-slate-800">
                    <div>
                        <span class="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider block mb-1.5">Scope Level</span>
                        <div class="flex items-center gap-1.5 flex-wrap">
                            <template x-for="scope in (currentDomainDef?.allowed_scopes || ['Company'])" :key="scope">
                                <button 
                                    type="button" 
                                    @click="setScopeLevel(scope)"
                                    :class="selectedScopeLevel === scope ? 'bg-indigo-600 text-white font-bold shadow-xs' : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 font-medium'"
                                    class="px-2.5 py-1 rounded-xl text-xs transition cursor-pointer flex items-center gap-1"
                                    x-text="scope === 'Company' ? 'Whole Company' : scope"
                                ></button>
                            </template>
                        </div>
                    </div>

                    <!-- Entity Dropdown (When child scope selected) -->
                    <template x-if="selectedScopeLevel !== 'Company'">
                        <div class="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1.5">
                            <label class="block text-[11px] font-bold text-slate-700 dark:text-slate-300">
                                Target <span x-text="selectedScopeLevel"></span>:
                            </label>
                            <select 
                                x-model="selectedScopeId" 
                                @change="onScopeIdChange()"
                                class="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                            >
                                <option value="">-- Choose <span x-text="selectedScopeLevel"></span> --</option>
                                <template x-for="item in getScopeEntities()" :key="item.id">
                                    <option :value="item.id" x-text="item.name + (item.employee_number ? ' [' + item.employee_number + ']' : '')"></option>
                                </template>
                            </select>
                            <div class="text-[10px] text-slate-500 dark:text-slate-400">
                                Unset parameters inherit from the Whole Company policy.
                            </div>
                        </div>
                    </template>
                </div>
            </div>

            <!-- Card 2: Effective Date & Change Reason Small Card -->
            <div class="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs p-3.5 space-y-2.5 transition">
                <div class="flex items-center justify-between gap-2">
                    <div class="flex items-center gap-2 min-w-0">
                        <i data-lucide="calendar-clock" class="w-3.5 h-3.5 text-slate-400 shrink-0"></i>
                        <span class="text-xs font-bold text-slate-700 dark:text-slate-300">Effective Date & Reason</span>
                    </div>
                    <span class="text-[10px] text-slate-400 shrink-0" x-text="'Today: ' + getTodayDate()"></span>
                </div>

                <!-- Date Inputs Directly Displayed -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1 border-t border-slate-100 dark:border-slate-800">
                    <div>
                        <div class="flex items-center justify-between mb-1">
                            <label class="block text-[11px] font-bold text-slate-600 dark:text-slate-400">Effective From</label>
                            <button type="button" @click="formMeta.effective_from = getTodayDate()" class="text-[10px] text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer">Set Today</button>
                        </div>
                        <input 
                            type="date" 
                            x-model="formMeta.effective_from"
                            class="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold text-xs text-slate-900 dark:text-white"
                        />
                    </div>
                    <div>
                        <label class="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">Effective To (Optional)</label>
                        <input 
                            type="date" 
                            x-model="formMeta.effective_to"
                            class="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold text-xs text-slate-900 dark:text-white"
                        />
                    </div>
                </div>

                <!-- Change Reason Box Directly Displayed -->
                <div class="pt-1">
                    <div class="flex items-center justify-between mb-1">
                        <label class="block text-[11px] font-bold text-slate-700 dark:text-slate-300">
                            Change Reason <span class="text-rose-500 font-bold">* (Required)</span>
                        </label>
                        <span class="text-[10px] text-amber-600 dark:text-amber-400 font-semibold">Mandatory</span>
                    </div>
                    <input 
                        type="text" 
                        id="change_reason_input"
                        x-model="formMeta.change_reason"
                        placeholder="State reason for policy change (e.g. FY2026 Board Approval, Policy Update)"
                        required
                        class="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-semibold text-xs text-slate-900 dark:text-white transition"
                        :class="!formMeta.change_reason || !formMeta.change_reason.trim() || formMeta.change_reason.toLowerCase().includes('seed') ? 'border-amber-400 dark:border-amber-600 bg-amber-50/40 dark:bg-amber-950/20' : 'border-slate-200 dark:border-slate-700'"
                    />
                    <p class="text-[10px] text-slate-500 dark:text-slate-400 mt-1 flex items-center gap-1">
                        <i data-lucide="mail" class="w-3 h-3 text-indigo-500 shrink-0"></i>
                        <span>All employees in this company will receive an email notice upon publication.</span>
                    </p>
                </div>
            </div>
        </div>
    </template>

    <!-- Search + Filter Bar for Policy Settings -->
    <template x-if="activeDomain !== 'OVERVIEW'">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
            <div class="relative flex-1">
                <i data-lucide="search" class="w-4 h-4 text-slate-400 absolute left-3 top-2.5"></i>
                <input 
                    type="text" 
                    x-model="domainSearchQuery"
                    placeholder="Search settings by title or description..." 
                    class="w-full pl-9 pr-3.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                />
            </div>
            <div class="flex items-center gap-4 shrink-0">
                <label class="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700 dark:text-slate-300">
                    <input type="checkbox" x-model="showOnlyChanged" class="rounded text-indigo-600 focus:ring-indigo-500">
                    <span>Show only changed settings</span>
                    <template x-if="unsavedChangesCount > 0">
                        <span class="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 font-mono" x-text="unsavedChangesCount"></span>
                    </template>
                </label>
            </div>
        </div>
    </template>

    <!-- Empty Child Scope Notice (Only when non-company scope has NO target selected) -->
    <div x-show="activeDomain !== 'OVERVIEW' && selectedScopeLevel !== 'Company' && !selectedScopeId" class="p-8 sm:p-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-dashed border-slate-300 dark:border-slate-700 space-y-3">
        <div class="w-12 h-12 rounded-2xl bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto">
            <i data-lucide="layers" class="w-6 h-6"></i>
        </div>
        <h3 class="text-sm font-bold text-slate-800 dark:text-slate-200">Select a <span x-text="selectedScopeLevel"></span> Target</h3>
        <p class="text-xs text-slate-500 max-w-md mx-auto">Please choose a target from the scope dropdown above to configure policy overrides for that specific <span x-text="selectedScopeLevel"></span>.</p>
    </div>

    <!-- Active Form Container (Shown when Company or Child Target is selected) -->
    <div x-show="activeDomain !== 'OVERVIEW' && (selectedScopeLevel === 'Company' || selectedScopeId)" class="space-y-6">

        <!-- Attendance Domain View -->
        <template x-if="activeDomain === 'ATTENDANCE'">
            <div class="space-y-4">
                <?= view('rules/domains/attendance') ?>
            </div>
        </template>

        <!-- Overtime Domain View -->
        <template x-if="activeDomain === 'OVERTIME'">
            <div class="space-y-4">
                <?= view('rules/domains/overtime') ?>
            </div>
        </template>

        <!-- Leave Domain View -->
        <template x-if="activeDomain === 'LEAVE'">
            <div class="space-y-4">
                <?= view('rules/domains/leave') ?>
            </div>
        </template>

        <!-- Bonus Domain View -->
        <template x-if="activeDomain === 'BONUS'">
            <div class="space-y-4">
                <?= view('rules/domains/bonus') ?>
            </div>
        </template>

        <!-- Provident Fund Domain View -->
        <template x-if="activeDomain === 'PF'">
            <div class="space-y-4">
                <?= view('rules/domains/pf') ?>
            </div>
        </template>

        <!-- Gratuity Domain View -->
        <template x-if="activeDomain === 'GRATUITY'">
            <div class="space-y-4">
                <?= view('rules/domains/gratuity') ?>
            </div>
        </template>

        <!-- Settlement Domain View -->
        <template x-if="activeDomain === 'SETTLEMENT'">
            <div class="space-y-4">
                <?= view('rules/domains/settlement') ?>
            </div>
        </template>

        <!-- Tax Domain View -->
        <template x-if="activeDomain === 'TAX'">
            <div class="space-y-4">
                <?= view('rules/domains/tax') ?>
            </div>
        </template>

        <!-- Payroll Basics Domain View -->
        <template x-if="activeDomain === 'PAYROLL_BASICS'">
            <div class="space-y-4">
                <?= view('rules/domains/payroll_basics') ?>
            </div>
        </template>

        <!-- Generic Schema-Driven Form (For any other unmapped domains) -->
        <div x-show="!['ATTENDANCE','OVERTIME','LEAVE','BONUS','PF','GRATUITY','SETTLEMENT','TAX','PAYROLL_BASICS'].includes(activeDomain)" class="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-7 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-6">
            <h3 class="text-base font-bold text-slate-900 dark:text-white" x-text="(currentDomainDef?.label || activeDomain) + ' Settings'"></h3>
            <div class="space-y-4">
                <template x-for="param in filteredParams" :key="param.key">
                    <div class="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
                        <div class="flex items-center justify-between">
                            <label class="text-xs font-bold text-slate-800 dark:text-slate-200" x-text="param.label || param.key"></label>
                            <span x-show="isFieldDirty(param.key)" class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                        </div>
                        <input 
                            type="text" 
                            x-model="formParams[param.key]" 
                            class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold"
                        />
                        <p class="text-[11px] text-slate-400" x-text="param.help || ''"></p>
                    </div>
                </template>
            </div>
        </div>

    </div>

    <!-- Overview Panel (Shown when activeDomain === 'OVERVIEW') -->
    <div x-show="activeDomain === 'OVERVIEW'" class="space-y-4">
        <!-- 4 KPI Cards -->
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <div class="bg-white dark:bg-slate-900 rounded-2xl p-3.5 sm:p-4 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-1">
                <div class="text-[11px] font-black uppercase tracking-wider text-slate-400 dark:text-slate-500 flex items-center justify-between">
                    <span>Governed Domains</span>
                    <i data-lucide="layers" class="w-4 h-4 text-indigo-500"></i>
                </div>
                <div class="text-2xl font-black text-slate-900 dark:text-white font-mono" x-text="overviewData?.total_domains || 9"></div>
                <div class="text-[11px] text-slate-500 font-medium">9 Business Domains</div>
            </div>

            <div class="bg-white dark:bg-slate-900 rounded-2xl p-3.5 sm:p-4 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-1">
                <div class="text-[11px] font-black uppercase tracking-wider text-slate-400 dark:text-slate-500 flex items-center justify-between">
                    <span>Active Policies</span>
                    <i data-lucide="check-circle-2" class="w-4 h-4 text-emerald-500"></i>
                </div>
                <div class="text-2xl font-black text-emerald-600 dark:text-emerald-400 font-mono flex items-center gap-2">
                    <span x-text="overviewData?.total_active || 9"></span>
                    <span class="text-xs px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold">100% Live</span>
                </div>
                <div class="text-[11px] text-slate-500 font-medium">Company Scope Active</div>
            </div>

            <div class="bg-white dark:bg-slate-900 rounded-2xl p-3.5 sm:p-4 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-1">
                <div class="text-[11px] font-black uppercase tracking-wider text-slate-400 dark:text-slate-500 flex items-center justify-between">
                    <span>Configured Parameters</span>
                    <i data-lucide="sliders" class="w-4 h-4 text-purple-500"></i>
                </div>
                <div class="text-2xl font-black text-purple-600 dark:text-purple-400 font-mono" x-text="overviewData?.total_params || 80"></div>
                <div class="text-[11px] text-slate-500 font-medium">Centrally Governed</div>
            </div>

            <div class="bg-white dark:bg-slate-900 rounded-2xl p-3.5 sm:p-4 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-1">
                <div class="text-[11px] font-black uppercase tracking-wider text-slate-400 dark:text-slate-500 flex items-center justify-between">
                    <span>Scope Overrides</span>
                    <i data-lucide="git-branch" class="w-4 h-4 text-amber-500"></i>
                </div>
                <div class="text-2xl font-black text-amber-600 dark:text-amber-400 font-mono" x-text="overviewData?.total_overrides || 0"></div>
                <div class="text-[11px] text-slate-500 font-medium">Branch / Dept / Employee</div>
            </div>
        </div>

        <!-- 9 Domains Quick Navigator Grid -->
        <div class="bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
            <h3 class="text-sm font-black text-slate-900 dark:text-white uppercase tracking-wider">Payroll & HR Rule Policies</h3>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                <template x-for="d in (overviewData?.domains || [])" :key="d.domain">
                    <div 
                        @click="selectDomain(d.domain)"
                        class="p-4 rounded-xl border border-slate-200/70 dark:border-slate-700/70 hover:border-indigo-400 dark:hover:border-indigo-500 bg-slate-50/50 dark:bg-slate-800/40 hover:bg-white dark:hover:bg-slate-800 transition cursor-pointer space-y-2 group"
                    >
                        <div class="flex items-center justify-between">
                            <span class="text-xs font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition" x-text="d.label"></span>
                            <span class="px-2 py-0.5 rounded text-[10px] font-bold font-mono bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">Live</span>
                        </div>
                        <div class="text-[11px] text-slate-500 flex items-center justify-between">
                            <span x-text="d.param_count + ' settings'"></span>
                            <span class="text-indigo-600 dark:text-indigo-400 font-bold group-hover:translate-x-0.5 transition">Configure →</span>
                        </div>
                    </div>
                </template>
            </div>
        </div>
    </div>

    <!-- STICKY BOTTOM SAVE BAR (Shown ONLY when unsaved changes exist) -->
    <div 
        x-show="isDirty" 
        x-transition:enter="transition ease-out duration-200 transform"
        x-transition:enter-start="translate-y-full opacity-0"
        x-transition:enter-end="translate-y-0 opacity-100"
        x-transition:leave="transition ease-in duration-150 transform"
        x-transition:leave-start="translate-y-0 opacity-100"
        x-transition:leave-end="translate-y-full opacity-0"
        class="fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 shadow-2xl p-3 sm:px-6"
    >
        <!-- Review Changes Inline Popover/Panel -->
        <div 
            x-show="showReviewPanel" 
            x-collapse 
            class="max-w-4xl mx-auto mb-3 p-3.5 bg-slate-50 dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-lg text-xs space-y-2"
        >
            <div class="flex items-center justify-between pb-1.5 border-b border-slate-200 dark:border-slate-700">
                <span class="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                    <i data-lucide="check-square" class="w-4 h-4 text-emerald-500"></i>
                    Review Changes (<span x-text="unsavedChangesCount"></span> setting<span x-show="unsavedChangesCount !== 1">s</span>)
                </span>
                <button type="button" @click="showReviewPanel = false" class="text-slate-400 hover:text-slate-600">
                    <i data-lucide="x" class="w-4 h-4"></i>
                </button>
            </div>

            <div class="max-h-48 overflow-y-auto space-y-1.5 divide-y divide-slate-100 dark:divide-slate-700/60 pr-1">
                <template x-for="item in changedFieldsList" :key="item.key">
                    <div class="pt-1.5 first:pt-0 flex items-center justify-between gap-3 text-xs">
                        <span class="font-semibold text-slate-700 dark:text-slate-300" x-text="item.label"></span>
                        <div class="flex items-center gap-2 font-mono text-[11px] shrink-0">
                            <span class="text-slate-400 line-through truncate max-w-[120px]" x-text="formatVal(item.oldVal)"></span>
                            <span class="text-slate-400">→</span>
                            <span class="text-emerald-600 dark:text-emerald-400 font-bold truncate max-w-[120px]" x-text="formatVal(item.newVal)"></span>
                            <button type="button" @click="resetField(item.key)" title="Reset to saved value" class="text-slate-400 hover:text-rose-500 p-0.5 rounded cursor-pointer">
                                <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i>
                            </button>
                        </div>
                    </div>
                </template>
            </div>

            <div class="pt-2 border-t border-slate-200 dark:border-slate-700 space-y-2">
                <div class="p-2.5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="block text-[11px] font-bold text-slate-700 dark:text-slate-300">
                            Change Reason <span class="text-rose-500 font-bold">* (Required)</span>:
                        </label>
                        <span class="text-[10px] text-amber-600 dark:text-amber-400 font-medium">Mandatory</span>
                    </div>
                    <input 
                        type="text" 
                        x-model="formMeta.change_reason"
                        placeholder="State reason for policy change (e.g. FY2026 Board Approval, Minimum Wage Update)" 
                        class="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        :class="!formMeta.change_reason || !formMeta.change_reason.trim() || formMeta.change_reason.toLowerCase().includes('seed') ? 'border-amber-400 dark:border-amber-600 bg-amber-50/40 dark:bg-amber-950/20' : 'border-slate-200 dark:border-slate-700'"
                    />
                    <p class="text-[10px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
                        <i data-lucide="mail" class="w-3 h-3 text-indigo-500 shrink-0"></i>
                        <span>An automated email update will be dispatched to all company employees upon application.</span>
                    </p>
                </div>

                <div class="flex items-center justify-between pt-1">
                    <span class="text-[11px] text-slate-500">Will take effect from <strong x-text="formMeta.effective_from || 'Today'"></strong></span>
                    <div class="flex items-center gap-2">
                        <button type="button" @click="showReviewPanel = false" class="px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-200/60 dark:text-slate-300">
                            Back to Editing
                        </button>
                        <button 
                            type="button" 
                            @click="executeSaveAndApply()"
                            :disabled="saving || publishing"
                            class="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-sm cursor-pointer disabled:opacity-50"
                        >
                            <i data-lucide="check" class="w-3.5 h-3.5"></i>
                            <span x-text="(saving || publishing) ? 'Applying...' : 'Confirm & Apply'"></span>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Bar Actions Row -->
        <div class="max-w-4xl mx-auto flex flex-wrap items-center justify-between gap-3">
            <div class="flex items-center gap-3 flex-wrap">
                <span class="text-xs sm:text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <span class="w-2 h-2 rounded-full bg-amber-500 animate-ping"></span>
                    <span x-text="unsavedChangesCount"></span> setting<span x-show="unsavedChangesCount !== 1">s</span> changed
                </span>

                <button 
                    type="button" 
                    @click="showReviewPanel = !showReviewPanel"
                    class="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer flex items-center gap-1"
                >
                    <i data-lucide="eye" class="w-3.5 h-3.5"></i>
                    <span x-text="showReviewPanel ? 'Hide review' : 'Review changes'"></span>
                </button>

                <!-- Validation Problems Indicator -->
                <template x-if="errorCount > 0">
                    <button 
                        type="button" 
                        @click="jumpToFirstError()"
                        class="text-xs font-bold text-rose-600 dark:text-rose-400 underline cursor-pointer flex items-center gap-1"
                    >
                        <i data-lucide="alert-circle" class="w-3.5 h-3.5"></i>
                        <span x-text="errorCount + ' problem' + (errorCount !== 1 ? 's' : '') + ' - jump to first'"></span>
                    </button>
                </template>
            </div>

            <!-- Action Buttons -->
            <?php if (!empty($canManage)): ?>
            <div class="flex items-center gap-2 shrink-0">
                <button 
                    type="button" 
                    @click="discardChanges()"
                    class="px-3.5 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
                >
                    Discard
                </button>

                <!-- Save & Apply Primary Split Button -->
                <div class="relative inline-flex rounded-xl shadow-md">
                    <button 
                        type="button" 
                        @click="saveAndApply()"
                        :disabled="saving || publishing"
                        class="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black rounded-l-xl transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                    >
                        <span x-show="saving || publishing" class="inline-block animate-spin">
                            <i data-lucide="loader-2" class="w-3.5 h-3.5"></i>
                        </span>
                        <span x-show="!(saving || publishing)">
                            <i data-lucide="check" class="w-3.5 h-3.5"></i>
                        </span>
                        <span x-text="(saving || publishing) ? 'Applying...' : 'Save & apply'"></span>
                    </button>

                    <button 
                        type="button" 
                        @click="showDraftDropdown = !showDraftDropdown"
                        class="px-2 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-r-xl border-l border-emerald-600 cursor-pointer"
                        title="More options"
                    >
                        <i data-lucide="chevron-down" class="w-3 h-3"></i>
                    </button>

                    <!-- Dropdown for Save as Draft -->
                    <div 
                        x-show="showDraftDropdown" 
                        @click.outside="showDraftDropdown = false" 
                        class="absolute bottom-full right-0 mb-2 w-40 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 py-1 text-xs z-50"
                    >
                        <button 
                            type="button" 
                            @click="saveDraft(); showDraftDropdown = false;" 
                            class="w-full text-left px-3 py-2 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 font-semibold flex items-center gap-2 cursor-pointer"
                        >
                            <i data-lucide="file-text" class="w-3.5 h-3.5 text-slate-400"></i>
                            Save as draft
                        </button>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <div class="flex items-center gap-2 shrink-0">
                <span class="px-3.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 font-semibold text-xs flex items-center gap-1.5 border border-slate-200 dark:border-slate-700 shadow-2xs">
                    <i data-lucide="lock" class="w-3.5 h-3.5 text-slate-400"></i>
                    <span>Read-Only Mode (requires rules.manage)</span>
                </span>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- EXPLAIN SNAPSHOT MODAL -->
    <div x-show="showExplainModal" class="fixed inset-0 z-50 overflow-y-auto" style="display: none;">
        <div class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs" @click="showExplainModal = false"></div>
        <div class="relative min-h-screen flex items-center justify-center p-4">
            <div class="relative bg-white dark:bg-slate-900 rounded-3xl max-w-3xl w-full p-6 sm:p-7 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5">
                <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                    <div class="flex items-center gap-2.5">
                        <div class="w-8 h-8 rounded-xl bg-indigo-100 dark:bg-indigo-950 text-indigo-600 flex items-center justify-center">
                            <i data-lucide="microscope" class="w-4 h-4"></i>
                        </div>
                        <div>
                            <h3 class="text-base font-black text-slate-900 dark:text-white">Rule Resolution Inspector</h3>
                            <p class="text-xs text-slate-400 font-mono">Trace hierarchical resolution & origin layer</p>
                        </div>
                    </div>
                    <button type="button" @click="showExplainModal = false" class="text-slate-400 hover:text-slate-600">
                        <i data-lucide="x" class="w-5 h-5"></i>
                    </button>
                </div>

                <div class="flex justify-end pt-2 border-t border-slate-100 dark:border-slate-800">
                    <button 
                        type="button" 
                        @click="showExplainModal = false"
                        class="px-5 py-2 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 transition cursor-pointer"
                    >
                        Close
                    </button>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
function ruleEngineApp() {
    return {
        loading: true,
        saving: false,
        publishing: false,
        overviewLoading: false,
        schemaVersion: 1,
        canManage: <?= $canManage ? 'true' : 'false' ?>,

        canManageDomain(dom = this.activeDomain) {
            return !!this.canManage;
        },

        // Overview State
        overviewData: null,

        // Active domain & definition
        domains: [],
        activeDomain: '<?= esc($activeTab ?? 'OVERVIEW') ?>',
        currentDomainDef: null,
        domainSearchQuery: '',
        showOnlyChanged: false,

        // Scope state (defaults to Company)
        selectedScopeLevel: 'Company',
        selectedScopeId: '',
        masters: {
            branches: <?= json_encode($masters['branches'] ?? []) ?>,
            departments: <?= json_encode($masters['departments'] ?? []) ?>,
            designations: <?= json_encode($masters['designations'] ?? []) ?>,
            shifts: <?= json_encode($masters['shifts'] ?? []) ?>,
            employees: <?= json_encode($masters['employees'] ?? []) ?>,
            leave_types: <?= json_encode($masters['leave_types'] ?? []) ?>,
            salary_components: <?= json_encode($masters['salary_components'] ?? []) ?>,
            company_weekly_off: <?= json_encode($masters['company_weekly_off'] ?? []) ?>,
            standard_daily_hours: <?= json_encode($masters['standard_daily_hours'] ?? null) ?>,
        },
        lockedBonusSchemeCodes: <?= json_encode($lockedBonusSchemeCodes ?? []) ?>,
        schemaDomainParams: <?= json_encode($schemaDomainParams ?? []) ?>,
        schemaDomainLabels: <?= json_encode($schemaDomainLabels ?? []) ?>,
        schemaDomainDescriptions: <?= json_encode($schemaDomainDescriptions ?? []) ?>,

        // Parameter & dirty tracking state
        companyParams: {},
        overriddenKeys: {},
        formParams: {},
        initialParams: {}, // baseline snapshot of last saved values
        baselineReady: false,

        // Meta form (Effective Date & Reason)
        formMeta: {
            effective_from: (function() {
                const d = new Date();
                const y = d.getFullYear();
                const m = String(d.getMonth() + 1).padStart(2, '0');
                const day = String(d.getDate()).padStart(2, '0');
                return `${y}-${m}-${day}`;
            })(),
            effective_to: '',
            change_reason: '',
        },

        // Versions list for active domain
        versions: [],
        currentVersion: null,
        activeVersion: null,

        // UI state
        showReviewPanel: false,
        showDraftDropdown: false,
        appliedToast: null,
        errors: {},
        globalError: '',
        globalSuccess: '',

        // Explain modal
        showExplainModal: false,

        // Computed properties
        get activeDomainKeys() {
            if (!this.activeDomain || this.activeDomain === 'OVERVIEW') return [];
            const upper = String(this.activeDomain).toUpperCase();
            if (this.schemaDomainParams && Array.isArray(this.schemaDomainParams[upper]) && this.schemaDomainParams[upper].length > 0) {
                return this.schemaDomainParams[upper];
            }
            if (this.currentDomainDef?.params && Array.isArray(this.currentDomainDef.params)) {
                return this.currentDomainDef.params.map(p => p.key);
            }
            return [];
        },

        get changedFieldsList() {
            if (!this.initialParams || !this.formParams || !this.activeDomain || this.activeDomain === 'OVERVIEW') return [];
            const domainKeys = this.activeDomainKeys;
            if (!domainKeys || domainKeys.length === 0) return [];
            const list = [];
            for (const key of domainKeys) {
                if (this.isFieldDirty(key)) {
                    const paramDef = (this.currentDomainDef?.params || []).find(p => p.key === key);
                    const label = paramDef?.label || key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
                    list.push({
                        key: key,
                        label: label,
                        oldVal: this.initialParams[key],
                        newVal: this.formParams[key]
                    });
                }
            }
            return list;
        },

        get isDirty() {
            return this.baselineReady && this.changedFieldsList.length > 0;
        },

        get unsavedChangesCount() {
            return this.changedFieldsList.length;
        },

        get errorCount() {
            return Object.keys(this.errors || {}).length;
        },

        get lastChangeInfo() {
            if (this.overviewData?.recent_changes) {
                const match = this.overviewData.recent_changes.find(c => c.domain === this.activeDomain);
                if (match) {
                    return {
                        user: match.actor_id ? ('User ' + match.actor_id.substring(0, 8)) : 'HR Admin',
                        date: this.formatDisplayDate(match.created_at)
                    };
                }
            }
            if (this.activeVersion && this.activeVersion.updated_at) {
                return {
                    user: 'HR Admin',
                    date: this.formatDisplayDate(this.activeVersion.updated_at)
                };
            }
            return null;
        },

        get filteredParams() {
            if (!this.currentDomainDef || !this.currentDomainDef.params) return [];
            let list = this.currentDomainDef.params;
            if (this.domainSearchQuery && this.domainSearchQuery.trim()) {
                const q = this.domainSearchQuery.toLowerCase().trim();
                list = list.filter(p => 
                    (p.key && p.key.toLowerCase().includes(q)) ||
                    (p.label && p.label.toLowerCase().includes(q)) ||
                    (p.help && p.help.toLowerCase().includes(q))
                );
            }
            if (this.showOnlyChanged) {
                list = list.filter(p => this.isFieldDirty(p.key));
            }
            return list;
        },

        openCards: {},

        cardOpen(cardId, defaultOpen = false) {
            if (this.openCards && this.openCards[cardId] !== undefined) {
                return this.openCards[cardId];
            }
            return defaultOpen;
        },

        toggleCard(cardId, defaultOpen = false) {
            this.openCards[cardId] = !this.cardOpen(cardId, defaultOpen);
            this.$nextTick(() => {
                if (typeof lucide !== 'undefined') lucide.createIcons();
            });
        },

        isCardVisible(title, desc = '', keys = []) {
            if (this.showOnlyChanged) {
                if (!keys || keys.length === 0) return false;
                const hasDirty = keys.some(k => this.isFieldDirty(k));
                if (!hasDirty) return false;
            }
            if (this.domainSearchQuery && this.domainSearchQuery.trim()) {
                const q = this.domainSearchQuery.toLowerCase().trim();
                const textMatch = (title && title.toLowerCase().includes(q)) || (desc && desc.toLowerCase().includes(q));
                if (textMatch) return true;
                if (keys && keys.some(k => k.toLowerCase().includes(q))) return true;
                return false;
            }
            return true;
        },

        // Robust, canonical equality check to avoid false dirty positives
        areValuesEqual(a, b) {
            if (a === b) return true;
            if ((a === null || a === undefined || a === '') && (b === null || b === undefined || b === '')) {
                return true;
            }
            if (a === null || a === undefined || b === null || b === undefined) {
                return false;
            }
            // Boolean normalization (handles true/false, "1"/"0", 1/0, "true"/"false")
            if (typeof a === 'boolean' || typeof b === 'boolean') {
                const normBool = v => (v === true || v === 1 || v === '1' || v === 'true');
                return normBool(a) === normBool(b);
            }
            // Number normalization (handles MySQL string "8.00" vs JS number 8)
            if (typeof a === 'number' || typeof b === 'number') {
                const numA = Number(a);
                const numB = Number(b);
                if (!isNaN(numA) && !isNaN(numB) && a !== '' && b !== '') {
                    return numA === numB;
                }
            }
            // Array comparison (deep & order-aware for elements)
            if (Array.isArray(a) && Array.isArray(b)) {
                if (a.length !== b.length) return false;
                for (let i = 0; i < a.length; i++) {
                    if (!this.areValuesEqual(a[i], b[i])) return false;
                }
                return true;
            }
            // Object comparison (order-independent, deep)
            if (typeof a === 'object' && typeof b === 'object' && !Array.isArray(a) && !Array.isArray(b)) {
                const keysA = Object.keys(a).filter(k => a[k] !== undefined && a[k] !== null && a[k] !== '');
                const keysB = Object.keys(b).filter(k => b[k] !== undefined && b[k] !== null && b[k] !== '');
                const allKeys = new Set([...keysA, ...keysB]);
                for (const k of allKeys) {
                    if (!this.areValuesEqual(a[k], b[k])) return false;
                }
                return true;
            }
            return String(a).trim() === String(b).trim();
        },

        // Helper methods
        isFieldDirty(key) {
            if (!this.initialParams) return false;
            if (!(key in this.initialParams) && !(key in this.formParams)) return false;
            return !this.areValuesEqual(this.formParams[key], this.initialParams[key]);
        },

        syncInitialBaseline() {
            this.initialParams = JSON.parse(JSON.stringify(this.formParams || {}));
        },

        resetField(key) {
            if (!this.initialParams || !(key in this.initialParams)) return;
            this.formParams[key] = JSON.parse(JSON.stringify(this.initialParams[key]));
            if (this.selectedScopeLevel !== 'Company' && !this.isFieldDirty(key)) {
                delete this.overriddenKeys[key];
            }
        },

        discardChanges() {
            if (!this.initialParams) return;
            this.formParams = JSON.parse(JSON.stringify(this.initialParams));
            this.errors = {};
            this.globalError = '';
            this.showReviewPanel = false;
            this.$nextTick(() => {
                if (typeof lucide !== 'undefined') lucide.createIcons();
            });
        },

        // ==========================================
        // DOMAIN HELPER METHODS & STATE
        // ==========================================
        // Attendance Domain Helpers
        allDaysOfWeek: ['Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],

        isWeeklyOff(day) {
            return Array.isArray(this.formParams.weekly_off_days) && this.formParams.weekly_off_days.includes(day);
        },

        toggleWeeklyOffDay(day) {
            if (!Array.isArray(this.formParams.weekly_off_days)) this.formParams.weekly_off_days = [];
            const idx = this.formParams.weekly_off_days.indexOf(day);
            if (idx === -1) {
                this.formParams.weekly_off_days.push(day);
            } else {
                this.formParams.weekly_off_days.splice(idx, 1);
            }
            if (this.selectedScopeLevel !== 'Company') this.overriddenKeys['weekly_off_days'] = true;
        },

        // Provident Fund Domain Helpers
        allBasisComponents: ['Basic', 'HouseRent', 'Medical', 'Conveyance', 'Food', 'Special', 'DA'],

        toggleComponent(comp) {
            this.togglePfComponent(comp);
        },

        togglePfComponent(comp) {
            if (!Array.isArray(this.formParams.basis_components)) this.formParams.basis_components = [];
            const idx = this.formParams.basis_components.indexOf(comp);
            if (idx === -1) {
                this.formParams.basis_components.push(comp);
            } else {
                this.formParams.basis_components.splice(idx, 1);
            }
            if (this.selectedScopeLevel !== 'Company') this.overriddenKeys['basis_components'] = true;
        },

        // Settlement Domain Helpers
        allSeparationTypes: ['Resignation', 'Termination', 'Retirement', 'Mutual Separation', 'Dismissal', 'Contract Expiry', 'Death', 'Disability'],

        toggleNoticeShortfall(sep) {
            if (!Array.isArray(this.formParams.notice_shortfall_applies_to)) this.formParams.notice_shortfall_applies_to = [];
            const idx = this.formParams.notice_shortfall_applies_to.indexOf(sep);
            if (idx === -1) {
                this.formParams.notice_shortfall_applies_to.push(sep);
            } else {
                this.formParams.notice_shortfall_applies_to.splice(idx, 1);
            }
            if (this.selectedScopeLevel !== 'Company') this.overriddenKeys['notice_shortfall_applies_to'] = true;
        },

        // Tax Domain Helpers
        setCategoryThreshold(cat, val) {
            if (!this.formParams.category_thresholds) this.formParams.category_thresholds = {};
            this.formParams.category_thresholds[cat] = parseFloat(val) || 0;
            if (this.selectedScopeLevel !== 'Company') this.overriddenKeys['category_thresholds'] = true;
        },

        // Leave Domain Helpers
        selectedLeaveTypeIndex: 0,

        getResolvedLeaveTypes() {
            const dbTypes = this.masters?.leave_types || [];
            const existing = Array.isArray(this.formParams.entitlements) ? this.formParams.entitlements : [];
            if (!dbTypes || dbTypes.length === 0) {
                if (existing.length === 0) {
                    return [
                        { leave_type_code: 'AL', leave_type_name: 'Annual Leave', applicable_gender: 'All', days_per_year: 14, is_paid: true, accrual_mode: 'Fixed yearly days', carry_forward_allowed: true, carry_forward_max_days: 14, carry_forward_percentage: 100, carry_forward_expiry_months: 12, approval_required: true, is_auto_approved: false, min_notice_days: 3, max_consecutive_days: 14, allow_half_day: true },
                        { leave_type_code: 'CL', leave_type_name: 'Casual Leave', applicable_gender: 'All', days_per_year: 10, is_paid: true, accrual_mode: 'Fixed yearly days', carry_forward_allowed: false, carry_forward_max_days: 0, carry_forward_percentage: 0, carry_forward_expiry_months: 0, approval_required: true, is_auto_approved: false, min_notice_days: 1, max_consecutive_days: 3, allow_half_day: true },
                        { leave_type_code: 'SL', leave_type_name: 'Sick Leave', applicable_gender: 'All', days_per_year: 14, is_paid: true, accrual_mode: 'Fixed yearly days', carry_forward_allowed: false, carry_forward_max_days: 0, carry_forward_percentage: 0, carry_forward_expiry_months: 0, approval_required: true, is_auto_approved: false, min_notice_days: 0, max_consecutive_days: 14, allow_half_day: true },
                        { leave_type_code: 'EL', leave_type_name: 'Earned Leave', applicable_gender: 'All', days_per_year: 18, is_paid: true, accrual_mode: 'Calendar days', earn_every_days: 12, earn_leave_per_cycle: 1.0, carry_forward_allowed: true, carry_forward_max_days: 30, carry_forward_percentage: 100, carry_forward_expiry_months: 12, approval_required: true, is_auto_approved: false, min_notice_days: 7, max_consecutive_days: 18, allow_half_day: false },
                        { leave_type_code: 'ML', leave_type_name: 'Maternity Leave', applicable_gender: 'Female', days_per_year: 90, is_paid: true, accrual_mode: 'Fixed yearly days', carry_forward_allowed: false, carry_forward_max_days: 0, carry_forward_percentage: 0, carry_forward_expiry_months: 0, approval_required: true, is_auto_approved: false, min_notice_days: 30, max_consecutive_days: 90, allow_half_day: false },
                        { leave_type_code: 'PL', leave_type_name: 'Paternity Leave', applicable_gender: 'Male', days_per_year: 5, is_paid: true, accrual_mode: 'Fixed yearly days', carry_forward_allowed: false, carry_forward_max_days: 0, carry_forward_percentage: 0, carry_forward_expiry_months: 0, approval_required: true, is_auto_approved: false, min_notice_days: 14, max_consecutive_days: 5, allow_half_day: false },
                        { leave_type_code: 'SPL', leave_type_name: 'Special Leave', applicable_gender: 'All', days_per_year: 5, is_paid: true, accrual_mode: 'Fixed yearly days', carry_forward_allowed: false, carry_forward_max_days: 0, carry_forward_percentage: 0, carry_forward_expiry_months: 0, approval_required: true, is_auto_approved: false, min_notice_days: 2, max_consecutive_days: 5, allow_half_day: true },
                        { leave_type_code: 'UL', leave_type_name: 'Unpaid Leave', applicable_gender: 'All', days_per_year: 0, is_paid: false, accrual_mode: 'Fixed yearly days', carry_forward_allowed: false, carry_forward_max_days: 0, carry_forward_percentage: 0, carry_forward_expiry_months: 0, approval_required: true, is_auto_approved: false, min_notice_days: 3, max_consecutive_days: 90, allow_half_day: true },
                    ];
                }
                return existing;
            }

            const merged = [];
            for (const lt of dbTypes) {
                const found = existing.find(e => (e.leave_type_code || '').toUpperCase() === (lt.code || '').toUpperCase());
                const defaultGender = lt.applicable_gender || (['ML', 'MATERNITY'].includes((lt.code || '').toUpperCase()) ? 'Female' : (['PL', 'PATERNITY'].includes((lt.code || '').toUpperCase()) ? 'Male' : 'All'));
                if (found) {
                    merged.push({ 
                        ...found, 
                        leave_type_code: lt.code, 
                        leave_type_name: lt.name || lt.code,
                        applicable_gender: found.applicable_gender || defaultGender
                    });
                } else {
                    merged.push({
                        leave_type_code: lt.code,
                        leave_type_name: lt.name || lt.code,
                        applicable_gender: defaultGender,
                        days_per_year: (lt.code || '').toUpperCase() === 'ML' ? 90 : ((lt.code || '').toUpperCase() === 'PL' ? 5 : ((lt.code || '').toUpperCase() === 'SPL' ? 5 : 14)),
                        is_paid: !['UL', 'LWP', 'UNPAID'].includes((lt.code || '').toUpperCase()),
                        accrual_mode: 'Fixed yearly days',
                        carry_forward_allowed: false,
                        carry_forward_max_days: 0,
                        carry_forward_percentage: 100,
                        carry_forward_expiry_months: 12,
                        approval_required: true,
                        is_auto_approved: false,
                        max_consecutive_days: 14,
                        min_notice_days: 3,
                        allow_half_day: true,
                        allow_negative_balance: false,
                        earn_every_days: 12,
                        earn_leave_per_cycle: 1.0
                    });
                }
            }
            return merged;
        },

        getCurrentEntitlement() {
            const types = this.getResolvedLeaveTypes();
            if (this.selectedLeaveTypeIndex >= types.length) {
                this.selectedLeaveTypeIndex = 0;
            }
            return types[this.selectedLeaveTypeIndex] || {};
        },

        updateEntitlementField(field, val) {
            if (!Array.isArray(this.formParams.entitlements) || this.formParams.entitlements.length === 0) {
                this.formParams.entitlements = this.getResolvedLeaveTypes();
            }
            if (this.formParams.entitlements[this.selectedLeaveTypeIndex]) {
                this.formParams.entitlements[this.selectedLeaveTypeIndex][field] = val;
                if (this.selectedScopeLevel !== 'Company') this.overriddenKeys['entitlements'] = true;
            }
        },

        ensureLeaveProbationConfig() {
            if (!this.formParams.probation || typeof this.formParams.probation !== 'object') {
                this.formParams.probation = {
                    probation_duration_months: 6,
                    can_apply_during_probation: true,
                    accrue_during_probation: false,
                    allowed_leave_type_codes: ['SL', 'UL'],
                    blocked_leave_type_codes: ['AL', 'EL'],
                    allow_paid_leave: false,
                    allow_unpaid_leave: true,
                    auto_transition_on_confirmation: true,
                    eligibility_rules: []
                };
            }
            if (!Array.isArray(this.formParams.probation.allowed_leave_type_codes)) {
                this.formParams.probation.allowed_leave_type_codes = ['SL', 'UL'];
            }
            if (!Array.isArray(this.formParams.probation.blocked_leave_type_codes)) {
                this.formParams.probation.blocked_leave_type_codes = ['AL', 'EL'];
            }
        },

        isLeaveCodeAllowedInProbation(code) {
            if (!code) return false;
            this.ensureLeaveProbationConfig();
            const upper = String(code).trim().toUpperCase();
            return (this.formParams.probation.allowed_leave_type_codes || []).map(c => String(c).toUpperCase()).includes(upper);
        },

        toggleLeaveCodeProbation(code, isAllowed) {
            if (!code) return;
            this.ensureLeaveProbationConfig();
            const upper = String(code).trim().toUpperCase();
            let allowed = (this.formParams.probation.allowed_leave_type_codes || []).map(c => String(c).toUpperCase());
            let blocked = (this.formParams.probation.blocked_leave_type_codes || []).map(c => String(c).toUpperCase());

            if (isAllowed) {
                if (!allowed.includes(upper)) allowed.push(upper);
                blocked = blocked.filter(c => c !== upper);
            } else {
                allowed = allowed.filter(c => c !== upper);
                if (!blocked.includes(upper)) blocked.push(upper);
            }
            this.formParams.probation.allowed_leave_type_codes = allowed;
            this.formParams.probation.blocked_leave_type_codes = blocked;
            if (this.selectedScopeLevel !== 'Company') this.overriddenKeys['probation'] = true;
        },

        // Bonus Domain Helpers & Scheme Modal State
        showSchemeModal: false,
        editingIndex: null,
        schemeModalError: '',
        schemeForm: {
            code: '',
            name: '',
            category: 'Festival',
            calculation_type: 'Percentage_Basic',
            value: 100,
            salary_basis: 'Basic Salary',
            included_component_codes: [],
            min_service_days: 90,
            prorate_under_service_days: true,
            prorate_threshold_months: 6,
            prorate_min_ratio: 0.1,
            include_probation: false,
            priority: 1,
            custom_formula: '',
            status: 'Active'
        },

        isSchemeLocked(code) {
            if (!code) return false;
            const c = String(code).trim().toUpperCase();
            const locked = Array.isArray(this.lockedBonusSchemeCodes) ? this.lockedBonusSchemeCodes : [];
            return locked.some(lc => String(lc).trim().toUpperCase() === c);
        },

        prefillFromCompany() {
            if (Array.isArray(this.companyParams?.schemes) && this.companyParams.schemes.length > 0) {
                const copied = JSON.parse(JSON.stringify(this.companyParams.schemes));
                if (!this.formParams) this.formParams = {};
                this.formParams.schemes = copied;
                this.formParams = { ...this.formParams, schemes: copied };
                if (this.selectedScopeLevel !== 'Company') {
                    if (!this.overriddenKeys) this.overriddenKeys = {};
                    this.overriddenKeys['schemes'] = true;
                }
            }
        },

        openAddSchemeModal() {
            this.editingIndex = null;
            this.schemeModalError = '';
            const existingSchemes = (this.formParams && Array.isArray(this.formParams.schemes)) ? this.formParams.schemes : [];
            this.schemeForm = {
                code: '',
                name: '',
                category: 'Festival',
                calculation_type: 'Percentage_Basic',
                value: 100,
                salary_basis: 'Basic Salary',
                included_component_codes: [],
                min_service_days: 90,
                prorate_under_service_days: true,
                prorate_threshold_months: 6,
                prorate_min_ratio: 0.1,
                include_probation: false,
                priority: existingSchemes.length + 1,
                custom_formula: '',
                status: 'Active'
            };
            this.showSchemeModal = true;
            this.$nextTick(() => {
                if (typeof lucide !== 'undefined') lucide.createIcons();
            });
        },

        openEditSchemeModal(idx) {
            this.editingIndex = idx;
            this.schemeModalError = '';
            const schemes = (this.formParams && Array.isArray(this.formParams.schemes)) ? this.formParams.schemes : [];
            const item = schemes[idx] || {};
            this.schemeForm = {
                code: item.code || '',
                name: item.name || '',
                category: item.category || 'Festival',
                calculation_type: item.calculation_type === 'Fixed_Amount' ? 'Flat' : (item.calculation_type || 'Percentage_Basic'),
                value: item.value !== undefined ? item.value : 100,
                salary_basis: item.salary_basis || 'Basic Salary',
                included_component_codes: Array.isArray(item.included_component_codes) ? [...item.included_component_codes] : [],
                min_service_days: item.min_service_days !== undefined ? item.min_service_days : 90,
                prorate_under_service_days: item.prorate_under_service_days !== undefined ? item.prorate_under_service_days : true,
                prorate_threshold_months: item.prorate_threshold_months !== undefined ? item.prorate_threshold_months : 6,
                prorate_min_ratio: item.prorate_min_ratio !== undefined ? item.prorate_min_ratio : 0.1,
                include_probation: !!item.include_probation,
                priority: item.priority !== undefined ? item.priority : 1,
                custom_formula: item.custom_formula || '',
                status: item.status || 'Active'
            };
            this.showSchemeModal = true;
            this.$nextTick(() => {
                if (typeof lucide !== 'undefined') lucide.createIcons();
            });
        },

        saveSchemeModal() {
            this.schemeModalError = '';
            const trimmedCode = (this.schemeForm.code || '').trim().toUpperCase();
            const trimmedName = (this.schemeForm.name || '').trim();

            if (!trimmedCode) {
                this.schemeModalError = 'Scheme code is required.';
                return;
            }
            if (!trimmedName) {
                this.schemeModalError = 'Scheme name is required.';
                return;
            }
            if (!this.schemeForm.calculation_type) {
                this.schemeModalError = 'Calculation type is required.';
                return;
            }
            if (this.schemeForm.calculation_type !== 'Formula') {
                if (this.schemeForm.value === '' || this.schemeForm.value === null || isNaN(Number(this.schemeForm.value))) {
                    this.schemeModalError = 'Value is required.';
                    return;
                }
            }
            if (!this.schemeForm.salary_basis) {
                this.schemeModalError = 'Salary basis is required.';
                return;
            }
            if (this.schemeForm.min_service_days === '' || this.schemeForm.min_service_days === null || isNaN(Number(this.schemeForm.min_service_days))) {
                this.schemeModalError = 'Min service days is required.';
                return;
            }
            if (!this.schemeForm.status) {
                this.schemeModalError = 'Status is required.';
                return;
            }

            if (!this.formParams) this.formParams = {};
            const schemes = Array.isArray(this.formParams.schemes) ? [...this.formParams.schemes] : [];

            // Duplicate code validation
            for (let i = 0; i < schemes.length; i++) {
                if (this.editingIndex !== null && i === this.editingIndex) continue;
                if (String(schemes[i].code || '').trim().toUpperCase() === trimmedCode) {
                    this.schemeModalError = `Duplicate code '${trimmedCode}' already exists. Scheme codes must be unique.`;
                    return;
                }
            }

            if (this.schemeForm.salary_basis === 'Selected Components') {
                if (!Array.isArray(this.schemeForm.included_component_codes) || this.schemeForm.included_component_codes.length === 0) {
                    this.schemeModalError = 'At least one salary component must be selected when Salary Basis is "Selected Components".';
                    return;
                }
            }

            // Locked scheme code validation
            if (this.editingIndex !== null) {
                const originalCode = (schemes[this.editingIndex]?.code || '').trim().toUpperCase();
                if (this.isSchemeLocked(originalCode) && originalCode !== trimmedCode) {
                    this.schemeModalError = `Scheme '${originalCode}' is referenced by existing bonus records and cannot be renamed.`;
                    return;
                }
            }

            const cleanItem = {
                code: trimmedCode,
                name: trimmedName,
                category: this.schemeForm.category || 'Festival',
                calculation_type: this.schemeForm.calculation_type,
                value: this.schemeForm.calculation_type === 'Formula' ? 0 : (Number(this.schemeForm.value) || 0),
                salary_basis: this.schemeForm.salary_basis,
                included_component_codes: this.schemeForm.salary_basis === 'Selected Components' ? [...this.schemeForm.included_component_codes] : [],
                min_service_days: Number(this.schemeForm.min_service_days) || 0,
                prorate_under_service_days: !!this.schemeForm.prorate_under_service_days,
                prorate_threshold_months: Number(this.schemeForm.prorate_threshold_months) || 0,
                prorate_min_ratio: Number(this.schemeForm.prorate_min_ratio) || 0,
                include_probation: !!this.schemeForm.include_probation,
                priority: Number(this.schemeForm.priority) || 1,
                custom_formula: this.schemeForm.calculation_type === 'Formula' ? (this.schemeForm.custom_formula || '') : null,
                status: this.schemeForm.status || 'Active'
            };

            if (this.editingIndex !== null) {
                schemes[this.editingIndex] = cleanItem;
            } else {
                schemes.push(cleanItem);
            }

            this.formParams.schemes = schemes;
            this.formParams = { ...this.formParams, schemes: schemes };

            if (this.selectedScopeLevel !== 'Company') {
                if (!this.overriddenKeys) this.overriddenKeys = {};
                this.overriddenKeys['schemes'] = true;
            }
            this.showSchemeModal = false;
            this.$nextTick(() => {
                if (typeof lucide !== 'undefined') lucide.createIcons();
            });
        },

        toggleSchemeStatus(idx) {
            if (!this.formParams || !Array.isArray(this.formParams.schemes) || !this.formParams.schemes[idx]) return;
            const schemes = [...this.formParams.schemes];
            const cur = schemes[idx].status || 'Active';
            schemes[idx] = { ...schemes[idx], status: cur === 'Active' ? 'Inactive' : 'Active' };
            this.formParams.schemes = schemes;
            this.formParams = { ...this.formParams, schemes: schemes };
            if (this.selectedScopeLevel !== 'Company') {
                if (!this.overriddenKeys) this.overriddenKeys = {};
                this.overriddenKeys['schemes'] = true;
            }
        },

        removeScheme(idx) {
            if (!this.formParams || !Array.isArray(this.formParams.schemes) || !this.formParams.schemes[idx]) return;
            const code = this.formParams.schemes[idx].code;
            if (this.isSchemeLocked(code)) {
                alert(`Scheme '${code}' is referenced by existing bonus records and cannot be deleted. You can deactivate it by toggling its status to Inactive.`);
                return;
            }
            if (confirm(`Remove bonus scheme '${this.formParams.schemes[idx].name || code}'?`)) {
                const schemes = [...this.formParams.schemes];
                schemes.splice(idx, 1);
                this.formParams.schemes = schemes;
                this.formParams = { ...this.formParams, schemes: schemes };
                if (this.selectedScopeLevel !== 'Company') {
                    if (!this.overriddenKeys) this.overriddenKeys = {};
                    this.overriddenKeys['schemes'] = true;
                }
            }
        },

        toggleComponentSelection(code) {
            if (!Array.isArray(this.schemeForm.included_component_codes)) {
                this.schemeForm.included_component_codes = [];
            }
            const idx = this.schemeForm.included_component_codes.indexOf(code);
            if (idx === -1) {
                this.schemeForm.included_component_codes.push(code);
            } else {
                this.schemeForm.included_component_codes.splice(idx, 1);
            }
        },

        formatVal(val) {
            if (val === null || val === undefined) return 'None';
            if (typeof val === 'boolean') return val ? 'Yes' : 'No';
            if (typeof val === 'object') return JSON.stringify(val);
            return String(val);
        },

        getTodayDate() {
            const d = new Date();
            const y = d.getFullYear();
            const m = String(d.getMonth() + 1).padStart(2, '0');
            const day = String(d.getDate()).padStart(2, '0');
            return `${y}-${m}-${day}`;
        },

        formatDisplayDate(dStr) {
            if (!dStr) return 'Not Set';
            try {
                const d = new Date(dStr);
                if (isNaN(d.getTime())) return dStr;
                return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
            } catch (e) {
                return dStr;
            }
        },

        getDomainTitle(domain) {
            if (this.schemaDomainLabels && this.schemaDomainLabels[domain]) {
                return this.schemaDomainLabels[domain];
            }
            if (Array.isArray(this.domains)) {
                const found = this.domains.find(d => d.domain === domain);
                if (found && found.label) return found.label;
            }
            return domain;
        },

        getDomainDescription(domain) {
            if (this.schemaDomainDescriptions && this.schemaDomainDescriptions[domain]) {
                return this.schemaDomainDescriptions[domain];
            }
            if (Array.isArray(this.domains)) {
                const found = this.domains.find(d => d.domain === domain);
                if (found && found.description) return found.description;
            }
            return 'Business policy rules governing this domain.';
        },

        getDomainIcon(domain) {
            const icons = {
                'PAYROLL_BASICS': 'banknote',
                'ATTENDANCE': 'clock',
                'OVERTIME': 'timer',
                'LEAVE': 'calendar-days',
                'BONUS': 'gift',
                'PF': 'shield-check',
                'GRATUITY': 'award',
                'SETTLEMENT': 'receipt',
                'TAX': 'file-text'
            };
            return icons[domain] || 'sliders';
        },

        getScopeEntities() {
            switch (this.selectedScopeLevel) {
                case 'Branch': return this.masters.branches || [];
                case 'Department': return this.masters.departments || [];
                case 'Designation': return this.masters.designations || [];
                case 'Shift': return this.masters.shifts || [];
                case 'Employee': return this.masters.employees || [];
                default: return [];
            }
        },

        getSelectedScopeEntityName() {
            if (this.selectedScopeLevel === 'Company') return 'Whole company';
            if (!this.selectedScopeId) return 'None Selected';
            const list = this.getScopeEntities();
            const found = list.find(item => String(item.id) === String(this.selectedScopeId));
            if (found) {
                return found.name + (found.employee_number ? ' [' + found.employee_number + ']' : '');
            }
            return this.selectedScopeId;
        },

        async setScopeLevel(scope) {
            if (this.selectedScopeLevel === scope) return;
            if (this.isDirty) {
                if (!confirm('You have unsaved changes. Discard changes and switch scope?')) return;
            }
            this.selectedScopeLevel = scope;
            this.selectedScopeId = '';
            this.errors = {};
            this.globalError = '';
            await this.fetchVersions(this.activeDomain);
        },

        async onScopeIdChange() {
            this.errors = {};
            this.globalError = '';
            await this.fetchVersions(this.activeDomain);
        },

        jumpToFirstError() {
            const errorKeys = Object.keys(this.errors || {});
            if (errorKeys.length === 0) return;
            const firstKey = errorKeys[0];
            const el = document.getElementById('field-container-' + firstKey) || 
                       document.getElementById(firstKey) || 
                       document.querySelector('[name="' + firstKey + '"]');
            if (el) {
                el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                const input = el.tagName === 'INPUT' || el.tagName === 'SELECT' ? el : el.querySelector('input, select, textarea');
                if (input) input.focus();
            }
        },

        showAppliedToast(msg) {
            this.appliedToast = msg;
            setTimeout(() => {
                if (this.appliedToast === msg) {
                    this.appliedToast = null;
                }
            }, 4000);
        },

        // Lifecycle & Initialization
        async init() {
            // Guard beforeunload when dirty
            window.addEventListener('beforeunload', (e) => {
                if (this.isDirty) {
                    e.preventDefault();
                    e.returnValue = '';
                    return '';
                }
            });

            await Promise.all([
                this.fetchMasters(),
                this.fetchDomains(),
                this.fetchOverview()
            ]);

            const urlParams = new URLSearchParams(window.location.search);
            const reqDomain = (urlParams.get('domain') || '').toUpperCase();
            const reqTab = (urlParams.get('tab') || '').toLowerCase();

            if (reqDomain && reqDomain !== 'OVERVIEW' && this.domains.some(d => d.domain === reqDomain)) {
                await this.selectDomain(reqDomain);
            } else if (reqTab === 'overview' || reqDomain === 'OVERVIEW' || this.activeDomain === 'OVERVIEW') {
                await this.selectOverviewTab();
            } else if (this.activeDomain && this.activeDomain !== 'OVERVIEW' && this.domains.some(d => d.domain === this.activeDomain)) {
                await this.selectDomain(this.activeDomain);
            } else {
                await this.selectOverviewTab();
            }

            this.$nextTick(() => {
                if (typeof lucide !== 'undefined') lucide.createIcons();
            });
        },

        async selectOverviewTab() {
            if (this.isDirty) {
                if (!confirm('You have unsaved changes. Discard changes and switch view?')) return;
            }
            this.activeDomain = 'OVERVIEW';
            this.currentDomainDef = null;
            this.errors = {};
            this.globalError = '';
            try {
                const url = new URL(window.location.href);
                url.searchParams.delete('domain');
                url.searchParams.set('tab', 'overview');
                window.history.replaceState({}, '', url.toString());
            } catch (e) {}
            await this.fetchOverview();
            this.$nextTick(() => {
                if (typeof lucide !== 'undefined') lucide.createIcons();
            });
        },

        async selectDomain(domainKey) {
            if (this.activeDomain === domainKey && this.currentDomainDef) return;
            if (this.isDirty) {
                if (!confirm('You have unsaved changes. Discard changes and switch domain?')) return;
            }

            this.baselineReady = false;
            this.activeDomain = domainKey;
            this.errors = {};
            this.globalError = '';
            this.domainSearchQuery = '';
            this.showOnlyChanged = false;
            this.formParams = {};
            this.initialParams = {};
            this.overriddenKeys = {};

            if (!this.domains || this.domains.length === 0) {
                await this.fetchDomains();
            }
            this.currentDomainDef = (this.domains || []).find(d => d.domain === domainKey) || null;

            try {
                const url = new URL(window.location.href);
                url.searchParams.delete('tab');
                url.searchParams.set('domain', domainKey);
                window.history.replaceState({}, '', url.toString());
            } catch (e) {}

            // Reset scope if current level not allowed
            const allowed = this.currentDomainDef?.allowed_scopes || ['Company'];
            if (!allowed.includes(this.selectedScopeLevel)) {
                this.selectedScopeLevel = 'Company';
                this.selectedScopeId = '';
            }

            await this.fetchVersions(domainKey);
            this.$nextTick(() => {
                if (typeof lucide !== 'undefined') lucide.createIcons();
            });
        },

        async fetchOverview(force = false) {
            if (this.overviewLoading) return;
            if (this.overviewData && !force) return;
            this.overviewLoading = true;
            try {
                const res = await fetch('<?= base_url('rules/overview') ?>', {
                    headers: { 'Accept': 'application/json' }
                });
                const json = await res.json();
                if (json.success && json.data) {
                    this.overviewData = json.data;
                }
            } catch (err) {
                console.error('Failed to load rules overview:', err);
            } finally {
                this.overviewLoading = false;
                this.$nextTick(() => {
                    if (typeof lucide !== 'undefined') lucide.createIcons();
                });
            }
        },

        async fetchMasters() {
            try {
                const res = await fetch('<?= base_url('rules/masters') ?>', {
                    headers: { 'Accept': 'application/json' }
                });
                const json = await res.json();
                if (json.success && json.data) {
                    this.masters = {
                        branches: json.data.branches || [],
                        departments: json.data.departments || [],
                        designations: json.data.designations || [],
                        shifts: json.data.shifts || [],
                        employees: json.data.employees || [],
                        leave_types: json.data.leave_types || [],
                        salary_components: json.data.salary_components || [],
                        company_weekly_off: json.data.company_weekly_off || [],
                        standard_daily_hours: json.data.standard_daily_hours || null,
                    };
                }
            } catch (err) {
                console.error('Failed to load masters:', err);
            }
        },

        async fetchDomains() {
            this.loading = true;
            try {
                const res = await fetch('<?= base_url('rules/domains') ?>', {
                    headers: { 'Accept': 'application/json' }
                });
                const json = await res.json();
                if (json.success && json.data && json.data.domains) {
                    this.schemaVersion = json.data.schema_version || 1;
                    this.domains = json.data.domains;
                }
            } catch (err) {
                console.error('Failed to load rule domains:', err);
            } finally {
                this.loading = false;
            }
        },

        async fetchCompanyBaseline(domainKey) {
            try {
                const res = await fetch(`<?= base_url('rules/list') ?>/${domainKey}?scope_level=Company`, {
                    headers: { 'Accept': 'application/json' }
                });
                const json = await res.json();
                if (json.success && json.data?.versions) {
                    const active = json.data.versions.find(v => v.status === 'Active') || json.data.versions[0];
                    if (active && active.params) {
                        this.companyParams = JSON.parse(JSON.stringify(active.params));
                    }
                }
            } catch (e) {
                console.error('Failed to load company baseline:', e);
            }
        },

        async fetchVersions(domainKey) {
            if (!domainKey || domainKey === 'OVERVIEW') return;

            if (this.selectedScopeLevel !== 'Company') {
                await this.fetchCompanyBaseline(domainKey);
            }

            let url = `<?= base_url('rules/list') ?>/${domainKey}?scope_level=${encodeURIComponent(this.selectedScopeLevel)}`;
            if (this.selectedScopeLevel !== 'Company' && this.selectedScopeId) {
                url += `&scope_id=${encodeURIComponent(this.selectedScopeId)}`;
            }

            let loaded = false;
            try {
                const res = await fetch(url, {
                    headers: { 'Accept': 'application/json' }
                });
                const json = await res.json();
                if (json.success && json.data) {
                    this.versions = json.data.versions || [];
                    this.activeVersion = this.versions.find(v => v.status === 'Active') || null;

                    if (this.selectedScopeLevel === 'Company' && this.activeVersion?.params) {
                        this.companyParams = JSON.parse(JSON.stringify(this.activeVersion.params));
                    }

                    if (this.activeVersion) {
                        this.selectVersion(this.activeVersion);
                    } else if (this.versions.length > 0) {
                        this.selectVersion(this.versions[0]);
                    } else {
                        this.initNewDraft();
                    }
                    loaded = true;
                }
            } catch (err) {
                this.globalError = 'Failed to fetch policy for ' + domainKey + ': ' + err.message;
            }
            this.$nextTick(() => {
                if (loaded) {
                    this.syncInitialBaseline();
                    this.baselineReady = true;
                }
                if (typeof lucide !== 'undefined') lucide.createIcons();
            });
        },

        selectVersion(v) {
            this.currentVersion = v;
            this.errors = {};
            this.globalError = '';

            const today = this.getTodayDate();
            // Never copy historical default seed reasons (RuleWriteService::SEED_REASON)
            const existingReason = (v.change_reason || '').trim();
            const cleanReason = (existingReason && !existingReason.toLowerCase().includes('seed')) ? existingReason : '';
            this.formMeta = {
                effective_from: today,
                effective_to: v.effective_to ? v.effective_to.substring(0, 10) : '',
                change_reason: (v.status === 'Draft' ? cleanReason : ''),
            };

            const versionParams = v.params || {};
            this.overriddenKeys = {};

            if (this.selectedScopeLevel === 'Company') {
                const cloned = JSON.parse(JSON.stringify(versionParams));
                if (this.currentDomainDef?.params) {
                    for (const p of this.currentDomainDef.params) {
                        if (!(p.key in cloned)) {
                            cloned[p.key] = this.defaultParamValue(p);
                        }
                    }
                }
                this.formParams = cloned;
            } else {
                const merged = JSON.parse(JSON.stringify(this.companyParams || {}));
                if (this.currentDomainDef?.params) {
                    for (const p of this.currentDomainDef.params) {
                        if (!(p.key in merged)) {
                            merged[p.key] = this.defaultParamValue(p);
                        }
                    }
                }
                for (const [key, val] of Object.entries(versionParams)) {
                    merged[key] = JSON.parse(JSON.stringify(val));
                    this.overriddenKeys[key] = true;
                }
                this.formParams = merged;
            }

            // Snapshot the saved params for dirty detection
            this.syncInitialBaseline();

            this.$nextTick(() => {
                this.syncInitialBaseline();
                if (typeof lucide !== 'undefined') lucide.createIcons();
            });
        },

        initNewDraft() {
            this.currentVersion = null;
            this.errors = {};
            this.overriddenKeys = {};

            const today = this.getTodayDate();
            this.formMeta = {
                effective_from: today,
                effective_to: '',
                change_reason: '',
            };

            const baseParams = (this.selectedScopeLevel === 'Company' && this.activeVersion) 
                ? JSON.parse(JSON.stringify(this.activeVersion.params || {}))
                : JSON.parse(JSON.stringify(this.companyParams || {}));

            if (this.currentDomainDef?.params) {
                for (const p of this.currentDomainDef.params) {
                    if (!(p.key in baseParams)) {
                        baseParams[p.key] = this.defaultParamValue(p);
                    }
                }
            }
            this.formParams = baseParams;
            this.syncInitialBaseline();

            this.$nextTick(() => {
                this.syncInitialBaseline();
                if (typeof lucide !== 'undefined') lucide.createIcons();
            });
        },

        defaultParamValue(p) {
            if (p.seed !== undefined) return JSON.parse(JSON.stringify(p.seed));
            switch (p.type) {
                case 'int': return 0;
                case 'decimal': return 0.0;
                case 'bool': return false;
                case 'enum': return (p.enum && p.enum[0]) ? p.enum[0] : '';
                case 'enum_list': return [];
                case 'array': return [];
                case 'json': return {};
                default: return '';
            }
        },

        buildParamsToSend() {
            // Find allowed schema keys for the active domain
            const activeDomainUpper = (this.activeDomain || '').toUpperCase();
            let validKeys = (this.schemaDomainParams && this.schemaDomainParams[activeDomainUpper]) || null;
            if (!validKeys && Array.isArray(this.domains) && this.domains.length > 0) {
                const domObj = this.domains.find(d => (d.domain || '').toUpperCase() === activeDomainUpper);
                if (domObj && Array.isArray(domObj.params)) {
                    validKeys = domObj.params.map(p => p.key);
                }
            }

            if (this.selectedScopeLevel === 'Company') {
                if (!validKeys || !Array.isArray(validKeys) || validKeys.length === 0) {
                    return this.formParams;
                }
                const filtered = {};
                for (const key of validKeys) {
                    if (key in this.formParams) {
                        filtered[key] = this.formParams[key];
                    }
                }
                return filtered;
            }

            const partial = {};
            for (const key of Object.keys(this.overriddenKeys)) {
                if (key in this.formParams) {
                    if (!validKeys || validKeys.includes(key)) {
                        partial[key] = this.formParams[key];
                    }
                }
            }
            return partial;
        },

        // ONE-CLICK SAVE & APPLY
        async saveAndApply() {
            return this.executeSaveAndApply();
        },

        async executeSaveAndApply() {
            if (this.selectedScopeLevel !== 'Company' && !this.selectedScopeId) {
                this.globalError = 'Please select a specific ' + this.selectedScopeLevel + ' target before applying.';
                return;
            }

            const today = this.getTodayDate();
            const effectiveFrom = this.formMeta.effective_from || today;
            const effectiveTo = this.formMeta.effective_to || null;
            const changeReason = (this.formMeta.change_reason || '').trim();

            if (!changeReason || changeReason.toLowerCase().includes('seed')) {
                this.globalError = 'A change reason is required when modifying business rules.';
                this.$nextTick(() => {
                    const el = document.getElementById('change_reason_input');
                    if (el) {
                        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        el.focus();
                    }
                });
                return;
            }

            const paramsToSend = this.buildParamsToSend();
            if (this.selectedScopeLevel !== 'Company' && Object.keys(paramsToSend).length === 0) {
                this.globalError = 'No parameters have been changed for this override.';
                return;
            }

            this.saving = true;
            this.publishing = true;
            this.errors = {};
            this.globalError = '';
            this.showReviewPanel = false;

            // Step 1: Save version draft
            const savePayload = {
                domain: this.activeDomain,
                scope_level: this.selectedScopeLevel,
                scope_id: this.selectedScopeLevel === 'Company' ? null : this.selectedScopeId,
                effective_from: effectiveFrom,
                effective_to: effectiveTo,
                change_reason: changeReason,
                params: paramsToSend,
            };

            if (this.currentVersion && this.currentVersion.status === 'Draft' && this.currentVersion.id) {
                savePayload.id = this.currentVersion.id;
            }

            let targetId = null;
            try {
                const saveRes = await fetch('<?= base_url('rules/version/save') ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                    },
                    body: JSON.stringify(savePayload)
                });
                const saveJson = await saveRes.json();
                if (!saveJson.success) {
                    this.globalError = saveJson.message || 'Validation failed while saving.';
                    if (saveJson.data && saveJson.data.errors) {
                        this.errors = saveJson.data.errors;
                    }
                    this.saving = false;
                    this.publishing = false;
                    return;
                }
                targetId = saveJson.data?.id;
            } catch (err) {
                this.globalError = 'Failed to save rule: ' + err.message;
                this.saving = false;
                this.publishing = false;
                return;
            }

            if (!targetId) {
                this.globalError = 'No version ID returned from server to publish.';
                this.saving = false;
                this.publishing = false;
                return;
            }

            // Step 2: Publish immediately
            try {
                const pubRes = await fetch(`<?= base_url('rules/version/publish') ?>/${encodeURIComponent(targetId)}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                    },
                    body: JSON.stringify({
                        change_reason: changeReason,
                        effective_from: effectiveFrom
                    })
                });
                const pubJson = await pubRes.json();
                if (pubJson.success) {
                    this.showAppliedToast('Applied from ' + effectiveFrom);
                    this.showReviewPanel = false;
                    await this.fetchVersions(this.activeDomain);
                    this.syncInitialBaseline();
                    await this.fetchOverview(true);
                } else {
                    this.globalError = pubJson.message || 'Saved as draft, but publication failed.';
                    if (pubJson.data && pubJson.data.errors) {
                        this.errors = pubJson.data.errors;
                    }
                }
            } catch (err) {
                this.globalError = 'Publication error: ' + err.message;
            } finally {
                this.saving = false;
                this.publishing = false;
            }
        },

        // SECONDARY: SAVE AS DRAFT ONLY
        async saveDraft() {
            if (this.selectedScopeLevel !== 'Company' && !this.selectedScopeId) {
                this.globalError = 'Please select a specific ' + this.selectedScopeLevel + ' target before saving.';
                return;
            }

            const today = this.getTodayDate();
            const effectiveFrom = this.formMeta.effective_from || today;
            const changeReason = (this.formMeta.change_reason || '').trim();

            if (!changeReason || changeReason.toLowerCase().includes('seed')) {
                this.globalError = 'A change reason is required when modifying business rules.';
                this.$nextTick(() => {
                    const el = document.getElementById('change_reason_input');
                    if (el) {
                        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        el.focus();
                    }
                });
                return;
            }

            const paramsToSend = this.buildParamsToSend();
            this.saving = true;
            this.errors = {};
            this.globalError = '';

            const payload = {
                domain: this.activeDomain,
                scope_level: this.selectedScopeLevel,
                scope_id: this.selectedScopeLevel === 'Company' ? null : this.selectedScopeId,
                effective_from: effectiveFrom,
                effective_to: this.formMeta.effective_to || null,
                change_reason: changeReason,
                params: paramsToSend,
            };

            if (this.currentVersion && this.currentVersion.status === 'Draft' && this.currentVersion.id) {
                payload.id = this.currentVersion.id;
            }

            try {
                const res = await fetch('<?= base_url('rules/version/save') ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                    },
                    body: JSON.stringify(payload)
                });
                const json = await res.json();
                if (json.success) {
                    this.showAppliedToast('Draft saved successfully');
                    this.showReviewPanel = false;
                    await this.fetchVersions(this.activeDomain);
                    this.syncInitialBaseline();
                } else {
                    this.globalError = json.message || 'Validation failed.';
                    if (json.data && json.data.errors) {
                        this.errors = json.data.errors;
                    }
                }
            } catch (err) {
                this.globalError = 'Failed to save draft: ' + err.message;
            } finally {
                this.saving = false;
            }
        },

        openExplainModal() {
            this.showExplainModal = true;
            this.$nextTick(() => {
                if (typeof lucide !== 'undefined') lucide.createIcons();
            });
        }
    };
}
</script>
