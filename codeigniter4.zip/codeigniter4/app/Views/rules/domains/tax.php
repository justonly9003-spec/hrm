<?php
/**
 * Income Tax Policy Configuration View
 * Single source rule definitions for progressive tax slabs, demographic categories,
 * component exemptions, and investment rebate limits.
 */
?>
<div class="space-y-4">

    <!-- Card 1: Progressive Tax Slabs (OPEN BY DEFAULT) -->
    <div 
        x-show="isCardVisible('Progressive Tax Brackets', 'Progressive tax slabs, percentage rates, and minimum tax', ['slabs', 'tax_free_limit_yearly', 'min_tax_amount'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('tax_slabs', true)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
                    <i data-lucide="file-text" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Progressive Tax Brackets (Slabs)</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Government statutory progressive tax brackets and annual tax-free limits.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('tax_slabs', true) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('tax_slabs', true)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Annual Tax-Free General Limit</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="0"
                            x-model.number="formParams.tax_free_limit_yearly"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['tax_free_limit_yearly'] = true;"
                            class="w-full px-3 py-1.5 pr-14 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">BDT</span>
                    </div>
                </div>

                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Minimum Annual Tax Payable</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="0"
                            x-model.number="formParams.min_tax_amount"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['min_tax_amount'] = true;"
                            class="w-full px-3 py-1.5 pr-14 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">BDT</span>
                    </div>
                </div>
            </div>

            <!-- Slabs Table -->
            <div class="space-y-2">
                <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Tax Slabs Ladder</label>
                <div class="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden text-xs">
                    <template x-for="(slab, sIdx) in (formParams.slabs || [])" :key="sIdx">
                        <div class="p-2.5 flex items-center justify-between gap-3 bg-slate-50/50 dark:bg-slate-800/40">
                            <span class="font-bold text-slate-800 dark:text-slate-200" x-text="slab.label || ('Slab ' + (sIdx + 1))"></span>
                            <div class="flex items-center gap-2 font-mono text-[11px]">
                                <span class="text-slate-500" x-text="Number(slab.min || 0).toLocaleString() + ' BDT'"></span>
                                <span class="text-slate-400">→</span>
                                <span class="text-slate-500" x-text="slab.max ? (Number(slab.max).toLocaleString() + ' BDT') : 'Balance'"></span>
                                <span class="px-2 py-0.5 rounded font-bold bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300" x-text="slab.rate + '%'"></span>
                            </div>
                        </div>
                    </template>
                </div>
            </div>

            <!-- Live Example Sentence -->
            <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Rule in action: </span>
                    <span x-text="'First ' + Number(formParams.tax_free_limit_yearly || 350000).toLocaleString() + ' BDT is tax-free, with subsequent income taxed in progressive tiers up to 25%. Minimum annual tax payable is ' + Number(formParams.min_tax_amount || 5000).toLocaleString() + ' BDT.'"></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 2: Demographic Tax-Free Thresholds (Collapsible) -->
    <div 
        x-show="isCardVisible('Demographic Tax-Free Thresholds', 'Special tax-free allowances for female, senior, and disabled employees', ['category_thresholds'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('tax_categories', false)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0">
                    <i data-lucide="users" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Demographic Tax-Free Thresholds</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Statutory tax-free allowances for female, senior, disabled, and freedom fighters.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('tax_categories', false) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('tax_categories', false)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <template x-for="(val, cat) in (formParams.category_thresholds || {})" :key="cat">
                    <div class="space-y-1">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300" x-text="cat"></label>
                        <div class="relative">
                            <input 
                                type="number" 
                                min="0" 
                                :value="val"
                                @input="setCategoryThreshold(cat, $event.target.value)"
                                class="w-full px-3 py-1.5 pr-14 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                            />
                            <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">BDT</span>
                        </div>
                    </div>
                </template>
            </div>

            <!-- Live Example Sentence -->
            <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Rule in action: </span>
                    <span x-text="'Female and senior employees enjoy higher tax-free threshold of ' + Number(formParams.category_thresholds?.Female || 400000).toLocaleString() + ' BDT.'"></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 3: Salary Component Exemptions & Rebate (Collapsible) -->
    <div 
        x-show="isCardVisible('Component Exemptions & Rebate', 'House rent, medical, conveyance exemptions, and investment tax rebate', ['house_rent_exemption_pct', 'house_rent_exemption_max', 'medical_exemption_pct', 'medical_exemption_max', 'rebate_pct'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('tax_exemptions', false)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                    <i data-lucide="percent" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Component Exemptions & Investment Rebate</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Allowances exempt from taxable income and investment rebate percentage.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('tax_exemptions', false) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('tax_exemptions', false)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">House Rent Exemption Max</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="0"
                            x-model.number="formParams.house_rent_exemption_max"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['house_rent_exemption_max'] = true;"
                            class="w-full px-3 py-1.5 pr-14 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">BDT</span>
                    </div>
                </div>

                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Medical Exemption Max</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="0"
                            x-model.number="formParams.medical_exemption_max"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['medical_exemption_max'] = true;"
                            class="w-full px-3 py-1.5 pr-14 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">BDT</span>
                    </div>
                </div>

                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Investment Tax Rebate</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="0" 
                            max="50"
                            x-model.number="formParams.rebate_pct"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['rebate_pct'] = true;"
                            class="w-full px-3 py-1.5 pr-10 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">%</span>
                    </div>
                </div>
            </div>

            <!-- Live Example Sentence -->
            <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Rule in action: </span>
                    <span x-text="'House rent exempt up to ' + Number(formParams.house_rent_exemption_max || 300000).toLocaleString() + ' BDT; Medical exempt up to ' + Number(formParams.medical_exemption_max || 120000).toLocaleString() + ' BDT; ' + (formParams.rebate_pct || 15) + '% tax rebate on eligible investments.'"></span>
                </div>
            </div>
        </div>
    </div>
</div>
