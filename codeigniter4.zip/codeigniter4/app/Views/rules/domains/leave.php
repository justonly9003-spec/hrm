<?php
/**
 * Leave Policy Configuration View
 * Single source rule definitions for leave entitlements, accrual cycles,
 * sandwich rules, probation eligibility, and unpaid deductions.
 */
?>
<div class="space-y-4">

    <!-- Card 1: Leave Entitlements & Accrual (OPEN BY DEFAULT) -->
    <div 
        x-show="isCardVisible('Leave Entitlements & Accrual', 'Annual quotas, accrual schedule, paid status, and rollover', ['entitlements'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('leave_entitlements', true)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                    <i data-lucide="calendar-days" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Leave Entitlements & Accrual</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Configure quotas, accrual modes, carry-forward, and restrictions per leave type.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('leave_entitlements', true) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('leave_entitlements', true)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-5">
            <!-- Leave Type Tab Pills -->
            <div>
                <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">Select Leave Type to Configure</label>
                <div class="flex items-center gap-2 flex-wrap">
                    <template x-for="(lt, idx) in getResolvedLeaveTypes()" :key="lt.leave_type_code">
                        <button 
                            type="button" 
                            @click="selectedLeaveTypeIndex = idx"
                            :class="selectedLeaveTypeIndex === idx ? 'bg-emerald-600 text-white font-bold shadow-xs' : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 font-medium'"
                            class="px-3.5 py-1.5 rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5"
                        >
                            <span x-text="lt.leave_type_name"></span>
                            <span class="text-[10px] opacity-75 font-mono" x-text="'[' + lt.leave_type_code + ']'"></span>
                        </button>
                    </template>
                </div>
            </div>

            <!-- Parameters Grid for Selected Type -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <!-- Applicable Gender -->
                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Applicable Gender</label>
                    <select 
                        :value="getCurrentEntitlement().applicable_gender || (['ML', 'MATERNITY'].includes((getCurrentEntitlement().leave_type_code || '').toUpperCase()) ? 'Female' : (['PL', 'PATERNITY'].includes((getCurrentEntitlement().leave_type_code || '').toUpperCase()) ? 'Male' : 'All'))"
                        @change="updateEntitlementField('applicable_gender', $event.target.value)"
                        class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                    >
                        <option value="All">All Genders (Male &amp; Female)</option>
                        <option value="Female">Female Only (Maternity)</option>
                        <option value="Male">Male Only (Paternity)</option>
                    </select>
                    <p class="text-[11px] text-slate-400">Gender eligibility restriction</p>
                </div>

                <!-- Accrual Mode -->
                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Accrual Mode</label>
                    <select 
                        :value="getCurrentEntitlement().accrual_mode || 'Fixed yearly days'"
                        @change="updateEntitlementField('accrual_mode', $event.target.value)"
                        class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                    >
                        <option value="Fixed yearly days">Fixed yearly days (credited Jan 1)</option>
                        <option value="Calendar days">Calendar days (Earned per N days)</option>
                        <option value="Monthly accrual">Monthly accrual (credited monthly)</option>
                        <option value="Pro-rata">Pro-rata by joining date</option>
                        <option value="Service-based" disabled>Service-based (not supported yet)</option>
                    </select>
                    <p class="text-[11px] text-slate-400">Schedule when leave balance is credited</p>
                </div>

                <!-- Annual Quota (SHOW ONLY FOR Fixed Mode) -->
                <div x-show="getCurrentEntitlement().accrual_mode === 'Fixed yearly days' || !getCurrentEntitlement().accrual_mode" class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Annual Quota</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            step="0.5" 
                            min="0" 
                            max="365"
                            :value="getCurrentEntitlement().days_per_year !== undefined ? getCurrentEntitlement().days_per_year : 14"
                            @input="updateEntitlementField('days_per_year', parseFloat($event.target.value) || 0)"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">days</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Fixed annual days credited at start of year</p>
                </div>

                <!-- Monthly Accrual Rate (SHOW ONLY FOR Monthly Mode) -->
                <div x-show="getCurrentEntitlement().accrual_mode === 'Monthly accrual'" class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Monthly Accrual Rate</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            step="0.25" 
                            min="0" 
                            max="31"
                            :value="getCurrentEntitlement().accrual_rate_per_month || (getCurrentEntitlement().days_per_year ? (getCurrentEntitlement().days_per_year / 12).toFixed(2) : 1.25)"
                            @input="updateEntitlementField('accrual_rate_per_month', parseFloat($event.target.value) || 0)"
                            class="w-full px-3 py-1.5 pr-14 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">days/mo</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Days credited per completed month</p>
                </div>

                <!-- Paid Leave Toggle -->
                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Paid Leave Status</label>
                    <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-semibold" x-text="getCurrentEntitlement().is_paid ? 'Paid (Salary Credit)' : 'Unpaid'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                :checked="getCurrentEntitlement().is_paid"
                                @change="updateEntitlementField('is_paid', $event.target.checked)"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Whether employee receives wage during leave</p>
                </div>

                <!-- Carry Forward -->
                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Carry Forward to Next Year</label>
                    <div class="flex items-center gap-2">
                        <label class="relative inline-flex items-center cursor-pointer shrink-0">
                            <input 
                                type="checkbox" 
                                :checked="getCurrentEntitlement().carry_forward_allowed"
                                @change="updateEntitlementField('carry_forward_allowed', $event.target.checked)"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                        <div class="relative flex-1">
                            <input 
                                type="number" 
                                min="0" 
                                max="365"
                                placeholder="Max days"
                                :disabled="!getCurrentEntitlement().carry_forward_allowed"
                                :value="getCurrentEntitlement().carry_forward_max_days"
                                @input="updateEntitlementField('carry_forward_max_days', parseFloat($event.target.value) || 0)"
                                class="w-full px-2.5 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white disabled:opacity-40"
                            />
                            <span class="absolute right-2.5 top-2 text-[10px] font-bold text-slate-400">max</span>
                        </div>
                    </div>
                    <p class="text-[11px] text-slate-400">Balance rollover into subsequent calendar year</p>
                </div>

                <!-- Carry Forward Rollover Details (when enabled) -->
                <div x-show="getCurrentEntitlement().carry_forward_allowed" class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Carry Forward % &amp; Expiry</label>
                    <div class="flex items-center gap-2">
                        <div class="relative flex-1">
                            <input 
                                type="number" 
                                min="0" 
                                max="100"
                                placeholder="100%"
                                :value="getCurrentEntitlement().carry_forward_percentage !== undefined ? getCurrentEntitlement().carry_forward_percentage : 100"
                                @input="updateEntitlementField('carry_forward_percentage', parseInt($event.target.value) || 100)"
                                class="w-full px-2.5 py-1.5 pr-8 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                            />
                            <span class="absolute right-2.5 top-2 text-[10px] font-bold text-slate-400">%</span>
                        </div>
                        <div class="relative flex-1">
                            <input 
                                type="number" 
                                min="0" 
                                max="60"
                                placeholder="Months"
                                :value="getCurrentEntitlement().carry_forward_expiry_months !== undefined ? getCurrentEntitlement().carry_forward_expiry_months : 12"
                                @input="updateEntitlementField('carry_forward_expiry_months', parseInt($event.target.value) || 0)"
                                class="w-full px-2.5 py-1.5 pr-8 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                            />
                            <span class="absolute right-2.5 top-2 text-[10px] font-bold text-slate-400">mo</span>
                        </div>
                    </div>
                    <p class="text-[11px] text-slate-400">Rollover ratio and validity in months (0 = no expiry)</p>
                </div>

                <!-- Notice Days -->
                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Notice Days Required</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="0" 
                            max="60"
                            :value="getCurrentEntitlement().min_notice_days || 0"
                            @input="updateEntitlementField('min_notice_days', parseInt($event.target.value) || 0)"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">days</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Advance submission requirement before leave</p>
                </div>

                <!-- Max Consecutive Days -->
                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Max Consecutive Days</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="0" 
                            max="365"
                            :value="getCurrentEntitlement().max_consecutive_days !== undefined ? getCurrentEntitlement().max_consecutive_days : 14"
                            @input="updateEntitlementField('max_consecutive_days', parseInt($event.target.value) || 0)"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">days</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Max consecutive days per application (0 = no limit)</p>
                </div>

                <!-- Allow Half-Day Toggle -->
                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Allow Half-Day Applications</label>
                    <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-semibold" x-text="getCurrentEntitlement().allow_half_day !== false ? 'Permitted (0.5d)' : 'Disabled'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                :checked="getCurrentEntitlement().allow_half_day !== false"
                                @change="updateEntitlementField('allow_half_day', $event.target.checked)"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Whether half-day sessions can be requested</p>
                </div>

                <!-- Allow Hourly Leave Toggle -->
                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Allow Hourly Leave</label>
                    <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-semibold" x-text="getCurrentEntitlement().allow_hourly_leave ? 'Enabled' : 'Disabled'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                :checked="!!getCurrentEntitlement().allow_hourly_leave"
                                @change="updateEntitlementField('allow_hourly_leave', $event.target.checked)"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Permit partial-day leave in hours</p>
                </div>

                <!-- Hourly Leave Duration Min / Max (SHOW ONLY WHEN Hourly Leave Enabled) -->
                <div x-show="!!getCurrentEntitlement().allow_hourly_leave" class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Hourly Leave Min / Max Hours</label>
                    <div class="flex items-center gap-2">
                        <div class="relative flex-1">
                            <input 
                                type="number" 
                                step="0.5" 
                                min="0.5" 
                                max="24"
                                placeholder="Min hours"
                                :value="getCurrentEntitlement().min_hourly_hours !== undefined ? getCurrentEntitlement().min_hourly_hours : 2.0"
                                @input="updateEntitlementField('min_hourly_hours', parseFloat($event.target.value) || 2.0)"
                                class="w-full px-2.5 py-1.5 pr-10 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                            />
                            <span class="absolute right-2.5 top-2 text-[10px] font-bold text-slate-400">min h</span>
                        </div>
                        <div class="relative flex-1">
                            <input 
                                type="number" 
                                step="0.5" 
                                min="0.5" 
                                max="24"
                                placeholder="Max hours"
                                :value="getCurrentEntitlement().max_hourly_hours !== undefined ? getCurrentEntitlement().max_hourly_hours : 4.0"
                                @input="updateEntitlementField('max_hourly_hours', parseFloat($event.target.value) || 4.0)"
                                class="w-full px-2.5 py-1.5 pr-10 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                            />
                            <span class="absolute right-2.5 top-2 text-[10px] font-bold text-slate-400">max h</span>
                        </div>
                    </div>
                    <p class="text-[11px] text-slate-400">Min and max hours per partial-day leave request</p>
                </div>

                <!-- Mandatory Application Reason Toggle -->
                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Mandatory Application Reason</label>
                    <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-semibold" x-text="getCurrentEntitlement().requires_reason !== false ? 'Required' : 'Optional'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                :checked="getCurrentEntitlement().requires_reason !== false"
                                @change="updateEntitlementField('requires_reason', $event.target.checked)"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Employee must provide written justification</p>
                </div>

                <!-- Medical Certificate Requirement -->
                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Medical Certificate</label>
                    <div class="flex items-center gap-2">
                        <label class="relative inline-flex items-center cursor-pointer shrink-0">
                            <input 
                                type="checkbox" 
                                :checked="!!getCurrentEntitlement().requires_medical_certificate"
                                @change="updateEntitlementField('requires_medical_certificate', $event.target.checked)"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                        <div class="relative flex-1">
                            <input 
                                type="number" 
                                min="0" 
                                max="365"
                                placeholder="Threshold"
                                :disabled="!getCurrentEntitlement().requires_medical_certificate"
                                :value="getCurrentEntitlement().medical_certificate_threshold_days || 0"
                                @input="updateEntitlementField('medical_certificate_threshold_days', parseInt($event.target.value) || 0)"
                                class="w-full px-2.5 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white disabled:opacity-40"
                            />
                            <span class="absolute right-2.5 top-2 text-[10px] font-bold text-slate-400">days</span>
                        </div>
                    </div>
                    <p class="text-[11px] text-slate-400">Doctor certificate required if leave duration exceeds threshold</p>
                </div>

                <!-- Allow Unpaid Split Toggle -->
                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Allow Unpaid Split</label>
                    <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-semibold" x-text="getCurrentEntitlement().allow_unpaid_split ? 'Permitted' : 'Disallowed'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                :checked="!!getCurrentEntitlement().allow_unpaid_split"
                                @change="updateEntitlementField('allow_unpaid_split', $event.target.checked)"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Split excess requested days into unpaid leave when balance is short</p>
                </div>

                <!-- Allow Negative Balance Overdraft -->
                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Negative Balance Overdraft</label>
                    <div class="flex items-center gap-2">
                        <label class="relative inline-flex items-center cursor-pointer shrink-0">
                            <input 
                                type="checkbox" 
                                :checked="!!getCurrentEntitlement().allow_negative_balance"
                                @change="updateEntitlementField('allow_negative_balance', $event.target.checked)"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                        <div class="relative flex-1">
                            <input 
                                type="number" 
                                min="0" 
                                max="365"
                                placeholder="Max days"
                                :disabled="!getCurrentEntitlement().allow_negative_balance"
                                :value="getCurrentEntitlement().max_negative_days || 0"
                                @input="updateEntitlementField('max_negative_days', parseInt($event.target.value) || 0)"
                                class="w-full px-2.5 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white disabled:opacity-40"
                            />
                            <span class="absolute right-2.5 top-2 text-[10px] font-bold text-slate-400">max</span>
                        </div>
                    </div>
                    <p class="text-[11px] text-slate-400">Permit advance overdraft up to maximum negative balance days</p>
                </div>

                <!-- Allow Emergency Absence Toggle -->
                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Allow Emergency Absence</label>
                    <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-semibold" x-text="getCurrentEntitlement().allow_emergency_absence ? 'Allowed for Employees' : 'Restricted to HR/Managers'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                :checked="!!getCurrentEntitlement().allow_emergency_absence"
                                @change="updateEntitlementField('allow_emergency_absence', $event.target.checked)"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Allow regular staff to submit emergency requests for this leave category</p>
                </div>

                <!-- Allow Backdated Application Toggle -->
                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Allow Backdated Application</label>
                    <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-semibold" x-text="getCurrentEntitlement().allow_backdated_application !== false ? 'Allowed (Default)' : 'Disabled for Employees'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                :checked="getCurrentEntitlement().allow_backdated_application !== false"
                                @change="updateEntitlementField('allow_backdated_application', $event.target.checked)"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Backdated allowed by default for employee regularization; disabling blocks employees from self-applying</p>
                </div>

                <!-- Max Backdate Days -->
                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Max Backdate Days</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="0" 
                            max="365"
                            :value="getCurrentEntitlement().max_backdate_days !== undefined ? getCurrentEntitlement().max_backdate_days : 0"
                            @input="updateEntitlementField('max_backdate_days', parseInt($event.target.value) || 0)"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">days</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Limit on days in past for employee self-application (0 = no limit; HR recording for others is exempt)</p>
                </div>

                <!-- Approval Required -->
                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Approval Required</label>
                    <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-semibold" x-text="getCurrentEntitlement().approval_required !== false ? 'Required (Multi-Tier)' : 'Direct Approval'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                :checked="getCurrentEntitlement().approval_required !== false"
                                @change="updateEntitlementField('approval_required', $event.target.checked)"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Whether application requires supervisor/HR approval</p>
                </div>

                <!-- Auto-Approve Requests -->
                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Auto-Approve Requests</label>
                    <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-semibold" x-text="getCurrentEntitlement().is_auto_approved ? 'Instant Auto-Approve' : 'Standard Workflow'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                :checked="!!getCurrentEntitlement().is_auto_approved"
                                @change="updateEntitlementField('is_auto_approved', $event.target.checked)"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Automatically approve applications upon submission</p>
                </div>

                <!-- Backdated Role Requirement -->
                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Backdated Approval Requirement</label>
                    <select 
                        :value="getCurrentEntitlement().backdated_role_requirement || ''"
                        @change="updateEntitlementField('backdated_role_requirement', $event.target.value)"
                        class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                    >
                        <option value="">None (Standard Tier Workflow)</option>
                        <option value="Manager and HR">Manager and HR (Both required)</option>
                        <option value="HR Only">HR Only</option>
                        <option value="Manager Only">Manager Only</option>
                    </select>
                    <p class="text-[11px] text-slate-400">Backdated applications always need extra approval and can never be auto-approved</p>
                </div>
            </div>

            <!-- Backdated Policy Help Text Banner -->
            <div class="p-3 bg-amber-50/70 dark:bg-amber-950/40 rounded-xl border border-amber-200/80 dark:border-amber-900/50 text-xs text-amber-950 dark:text-amber-200 flex items-start gap-2">
                <i data-lucide="clock" class="w-4 h-4 text-amber-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Backdated Leave Policy: </span>
                    <span>Backdated application is allowed by default for regularizing past absences. Self-application is limited by max_backdate_days (0 = no limit; HR/managers recording for others are exempt). Backdated requests always require the extra approval tier and can never be auto-approved.</span>
                </div>
            </div>

            <!-- Earn Every N Days Panel (SHOW ONLY FOR Calendar days / Earned per N days) -->
            <div 
                x-show="['Calendar days', 'Earned per N days'].includes(getCurrentEntitlement().accrual_mode)"
                class="p-4 rounded-xl bg-indigo-50/60 dark:bg-indigo-950/20 border border-indigo-200/80 dark:border-indigo-800/80 space-y-3"
            >
                <div class="flex items-center gap-2">
                    <span class="w-2 h-2 rounded-full bg-indigo-600"></span>
                    <h4 class="text-xs font-bold text-indigo-950 dark:text-indigo-200 uppercase tracking-wider">
                        Earn-as-you-work Rules (N Days = X Leave)
                    </h4>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div class="space-y-1">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Earn Every N Calendar Days (N)</label>
                        <div class="relative">
                            <input 
                                type="number" 
                                min="1" 
                                max="365"
                                :value="getCurrentEntitlement().earn_every_days || 12"
                                @input="updateEntitlementField('earn_every_days', parseInt($event.target.value) || 12)"
                                class="w-full px-3 py-1.5 pr-12 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                            />
                            <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">days</span>
                        </div>
                        <p class="text-[11px] text-slate-500">Calendar days worked to earn 1 cycle of leave</p>
                    </div>

                    <div class="space-y-1">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Leave Earned per Cycle (X)</label>
                        <div class="relative">
                            <input 
                                type="number" 
                                step="0.5" 
                                min="0.5" 
                                max="30"
                                :value="getCurrentEntitlement().earn_leave_per_cycle !== undefined ? getCurrentEntitlement().earn_leave_per_cycle : 1.0"
                                @input="updateEntitlementField('earn_leave_per_cycle', parseFloat($event.target.value) || 1.0)"
                                class="w-full px-3 py-1.5 pr-12 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                            />
                            <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">days</span>
                        </div>
                        <p class="text-[11px] text-slate-500">Days of leave awarded per completed cycle</p>
                    </div>
                </div>
            </div>

            <!-- Live Example Sentence -->
            <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Rule in action: </span>
                    <span x-text="(() => {
                        const ent = getCurrentEntitlement();
                        const mode = ent.accrual_mode || 'Fixed yearly days';
                        if (['Calendar days', 'Earned per N days'].includes(mode)) {
                            const n = ent.earn_every_days || 12;
                            const x = ent.earn_leave_per_cycle !== undefined ? ent.earn_leave_per_cycle : 1.0;
                            return 'Every ' + n + ' days worked -> ' + x + ' earned leave day (day ' + n + ' = ' + x + ', day ' + (n * 2) + ' = ' + (x * 2) + ').';
                        } else if (mode === 'Monthly accrual') {
                            const rate = ent.accrual_rate_per_month || (ent.days_per_year ? (ent.days_per_year / 12).toFixed(2) : 1.25);
                            return 'Accrues ' + rate + ' days at the end of each completed calendar month.';
                        } else {
                            const quota = ent.days_per_year !== undefined ? ent.days_per_year : 14;
                            return quota + ' days credited annually on Jan 1 (' + (ent.is_paid ? 'Paid' : 'Unpaid') + '). Carry-forward: ' + (ent.carry_forward_allowed ? (ent.carry_forward_max_days || 'unlimited') + ' days' : 'None') + '.';
                        }
                    })()"></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 2: Sandwich Rule Policy (Collapsible) -->
    <div 
        x-show="isCardVisible('Sandwich Rule Policy', 'Weekend and holiday treatment when sandwiched between leave days', ['sandwich'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('leave_sandwich', false)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                    <i data-lucide="layers" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Sandwich Rule Policy</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Treatment of weekends and holidays sandwiched between consecutive leave applications.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('leave_sandwich', false) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('leave_sandwich', false)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                <span class="text-xs font-semibold text-slate-700 dark:text-slate-300">Enable Sandwich Rule</span>
                <label class="relative inline-flex items-center cursor-pointer">
                    <input 
                        type="checkbox" 
                        x-model="formParams.sandwich.enabled"
                        @change="if(selectedScopeLevel !== 'Company') overriddenKeys['sandwich'] = true;"
                        class="sr-only peer"
                    />
                    <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                </label>
            </div>

            <div x-show="formParams.sandwich && formParams.sandwich.enabled" class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Weekend Treatment</label>
                    <select 
                        x-model="formParams.sandwich.weekend_treatment"
                        @change="if(selectedScopeLevel !== 'Company') overriddenKeys['sandwich'] = true;"
                        class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                    >
                        <option value="Include if sandwiched">Include if sandwiched (count weekends as leave)</option>
                        <option value="Exclude weekly off">Exclude weekly off (weekends not deducted)</option>
                        <option value="Count weekly off as leave">Count weekly off as leave (all weekends deducted)</option>
                    </select>
                </div>

                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Holiday Treatment</label>
                    <select 
                        x-model="formParams.sandwich.holiday_treatment"
                        @change="if(selectedScopeLevel !== 'Company') overriddenKeys['sandwich'] = true;"
                        class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                    >
                        <option value="Include if sandwiched">Include if sandwiched (count holidays as leave)</option>
                        <option value="Exclude holidays">Exclude holidays (holidays not deducted)</option>
                        <option value="Count holidays as leave">Count holidays as leave (all holidays deducted)</option>
                        <option value="Count all calendar days">Count all calendar days</option>
                    </select>
                </div>

                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Bridge Leave Action</label>
                    <select 
                        x-model="formParams.sandwich.bridge_leave_action"
                        @change="if(selectedScopeLevel !== 'Company') overriddenKeys['sandwich'] = true;"
                        class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                    >
                        <option value="Count intervening days">Count intervening days (deduct bridge days)</option>
                        <option value="Exclude intervening days">Exclude intervening days (override and exclude)</option>
                    </select>
                </div>
            </div>

            <!-- Live Example Sentence -->
            <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Rule in action: </span>
                    <span x-text="formParams.sandwich && formParams.sandwich.enabled ? 'Sandwich rule active: Leave on Thursday & Sunday with Friday/Saturday off -> ' + (formParams.sandwich.weekend_treatment === 'Include if sandwiched' ? 'weekend days are counted as leave (4 days deducted).' : 'weekend days are excluded from leave (2 days deducted).') : 'Sandwich rule disabled: Weekends and holidays are never converted to leave.'"></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 3: Unpaid Leave Deduction (Collapsible) -->
    <div 
        x-show="isCardVisible('Unpaid Leave Deduction', 'Daily salary deduction formula for unpaid leave days', ['unpaid_deduction'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('leave_unpaid', false)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
                    <i data-lucide="banknote" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Unpaid Leave Deduction</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Formula and divisor for wage deductions when leave balance is zero.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('leave_unpaid', false) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('leave_unpaid', false)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Salary Calculation Basis</label>
                    <select 
                        x-model="formParams.unpaid_deduction.salary_basis"
                        @change="if(selectedScopeLevel !== 'Company') overriddenKeys['unpaid_deduction'] = true;"
                        class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                    >
                        <option value="Basic Salary">Basic Salary</option>
                        <option value="Gross Salary">Gross Salary</option>
                    </select>
                </div>

                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Deduction Divisor</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="20" 
                            max="31" 
                            x-model.number="formParams.unpaid_deduction.divisor"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['unpaid_deduction'] = true;"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">days</span>
                    </div>
                </div>

                <!-- Domain-wide Allow Unpaid Split -->
                <div class="space-y-1 sm:col-span-2">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Allow Automatic Unpaid Split (Default)</label>
                    <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-semibold" x-text="formParams.allow_unpaid_split !== false ? 'Permitted' : 'Disallowed'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                :checked="formParams.allow_unpaid_split !== false"
                                @change="formParams.allow_unpaid_split = $event.target.checked; if(selectedScopeLevel !== 'Company') overriddenKeys['allow_unpaid_split'] = true;"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Default company policy for splitting excess requested days into unpaid leave when balance is exhausted</p>
                </div>
            </div>

            <!-- Live Example Sentence -->
            <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Rule in action: </span>
                    <span x-text="'1 unpaid leave day -> deduction of (' + (formParams.unpaid_deduction.salary_basis || 'Basic Salary') + ' / ' + (formParams.unpaid_deduction.divisor || 30) + ') from monthly payroll.'"></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 4: Probation Leave Policy & Eligibility (Collapsible) -->
    <div 
        x-show="isCardVisible('Probation Leave Policy & Eligibility', 'Rules governing leave applications during probation period', ['probation'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('leave_probation', false)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 flex items-center justify-center shrink-0">
                    <i data-lucide="shield-alert" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Probation Leave Policy &amp; Eligibility</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Configure probation duration, allowed leave categories, and paid/unpaid probation rules.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('leave_probation', false) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('leave_probation', false)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <!-- Can Apply During Probation -->
                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Can Apply During Probation</label>
                    <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-semibold" x-text="(formParams.probation && formParams.probation.can_apply_during_probation !== false) ? 'Allowed' : 'Blocked'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                :checked="!formParams.probation || formParams.probation.can_apply_during_probation !== false"
                                @change="ensureLeaveProbationConfig(); formParams.probation.can_apply_during_probation = $event.target.checked; if(selectedScopeLevel !== 'Company') overriddenKeys['probation'] = true;"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Whether probationers can submit any leave requests</p>
                </div>

                <!-- Probation Duration (Months) -->
                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Probation Duration</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="1" 
                            max="24"
                            :value="formParams.probation ? formParams.probation.probation_duration_months : 6"
                            @input="ensureLeaveProbationConfig(); formParams.probation.probation_duration_months = parseInt($event.target.value) || 6; if(selectedScopeLevel !== 'Company') overriddenKeys['probation'] = true;"
                            class="w-full px-3 py-1.5 pr-14 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">months</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Standard probation tenure from employee hire date</p>
                </div>

                <!-- Allow Paid Leave -->
                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Allow Paid Leave</label>
                    <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-semibold" x-text="(formParams.probation && formParams.probation.allow_paid_leave) ? 'Permitted' : 'Disallowed'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                :checked="formParams.probation && !!formParams.probation.allow_paid_leave"
                                @change="ensureLeaveProbationConfig(); formParams.probation.allow_paid_leave = $event.target.checked; if(selectedScopeLevel !== 'Company') overriddenKeys['probation'] = true;"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Permit paid leave usage during probation</p>
                </div>

                <!-- Allow Unpaid Leave -->
                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Allow Unpaid Leave</label>
                    <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-semibold" x-text="(!formParams.probation || formParams.probation.allow_unpaid_leave !== false) ? 'Permitted' : 'Disallowed'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                :checked="!formParams.probation || formParams.probation.allow_unpaid_leave !== false"
                                @change="ensureLeaveProbationConfig(); formParams.probation.allow_unpaid_leave = $event.target.checked; if(selectedScopeLevel !== 'Company') overriddenKeys['probation'] = true;"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Permit unpaid/loss of pay leave during probation</p>
                </div>

                <!-- Accrue Leave During Probation -->
                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Accrue During Probation</label>
                    <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-semibold" x-text="(formParams.probation && formParams.probation.accrue_during_probation) ? 'Accruing' : 'No Accrual'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                :checked="formParams.probation && !!formParams.probation.accrue_during_probation"
                                @change="ensureLeaveProbationConfig(); formParams.probation.accrue_during_probation = $event.target.checked; if(selectedScopeLevel !== 'Company') overriddenKeys['probation'] = true;"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Credit monthly/pro-rata leave days while on probation</p>
                </div>

                <!-- Auto Transition on Confirmation -->
                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Auto Transition on Confirmation</label>
                    <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-semibold" x-text="(!formParams.probation || formParams.probation.auto_transition_on_confirmation !== false) ? 'Automatic' : 'Manual'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                :checked="!formParams.probation || formParams.probation.auto_transition_on_confirmation !== false"
                                @change="ensureLeaveProbationConfig(); formParams.probation.auto_transition_on_confirmation = $event.target.checked; if(selectedScopeLevel !== 'Company') overriddenKeys['probation'] = true;"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Unlock all permanent leave entitlements upon probation completion</p>
                </div>
            </div>

            <!-- Allowed Leave Types Selection during Probation -->
            <div class="pt-2 border-t border-slate-100 dark:border-slate-800">
                <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">Leave Types Available During Probation</label>
                <div class="flex items-center gap-2 flex-wrap">
                    <template x-for="lt in getResolvedLeaveTypes()" :key="'prob_' + lt.leave_type_code">
                        <button 
                            type="button" 
                            @click="toggleLeaveCodeProbation(lt.leave_type_code, !isLeaveCodeAllowedInProbation(lt.leave_type_code))"
                            :class="isLeaveCodeAllowedInProbation(lt.leave_type_code) ? 'bg-sky-600 text-white font-bold shadow-xs' : 'bg-slate-100 dark:bg-slate-800 text-slate-400 line-through'"
                            class="px-3 py-1.5 rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5"
                        >
                            <span x-text="lt.leave_type_name"></span>
                            <span class="text-[10px] opacity-75 font-mono" x-text="'[' + lt.leave_type_code + ']'"></span>
                            <i data-lucide="check" x-show="isLeaveCodeAllowedInProbation(lt.leave_type_code)" class="w-3.5 h-3.5 inline"></i>
                        </button>
                    </template>
                </div>
                <p class="text-[11px] text-slate-400 mt-1.5">Click any category pill to toggle availability for probationers. Highlighted categories are allowed; struck-through categories are blocked.</p>
            </div>
        </div>
    </div>
</div>
