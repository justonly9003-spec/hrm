<?php
/**
 * Overtime Policy Configuration View
 * Single source rule definitions for overtime rate multipliers, early check-in qualification,
 * post check-out thresholds, billing increments, hour caps, and manager approvals.
 */
?>
<div class="space-y-4">

    <!-- Card 1: Early Check-in Overtime Policy (OPEN BY DEFAULT) -->
    <div 
        x-show="isCardVisible('Early Check-in Overtime', 'Enable/disable early check-in overtime and configure qualification threshold', ['enable_early_arrival_ot', 'early_arrival_min_threshold_minutes', 'early_arrival_grace_minutes'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('ot_early_checkin', true)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 flex items-center justify-center shrink-0">
                    <i data-lucide="log-in" class="w-4 h-4"></i>
                </div>
                <div>
                    <div class="flex items-center gap-2">
                        <h3 class="text-sm font-bold text-slate-900 dark:text-white">Early Check-in Overtime</h3>
                        <span 
                            class="px-2 py-0.5 rounded-full text-[10px] font-bold"
                            :class="formParams.enable_early_arrival_ot ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'"
                            x-text="formParams.enable_early_arrival_ot ? 'Enabled' : 'Disabled'"
                        ></span>
                    </div>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Count overtime when employees arrive before scheduled shift start time. Threshold is an eligibility condition (not a deduction).</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('ot_early_checkin', true) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('ot_early_checkin', true)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <!-- Enable Toggle -->
                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Enable Early Check-in OT</label>
                        <template x-if="isFieldDirty('enable_early_arrival_ot')">
                            <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                        </template>
                    </div>
                    <div class="flex items-center justify-between pt-2">
                        <span class="text-xs font-semibold" x-text="formParams.enable_early_arrival_ot ? 'Enabled' : 'Disabled'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                :checked="Boolean(formParams.enable_early_arrival_ot)"
                                @change="
                                    const val = $event.target.checked;
                                    formParams.enable_early_arrival_ot = val;
                                    if(selectedScopeLevel !== 'Company') {
                                        overriddenKeys['enable_early_arrival_ot'] = true;
                                    }
                                "
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-sky-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Allow early punch-in before shift start to count as overtime</p>
                </div>

                <!-- Minimum Early Check-in Minutes Threshold -->
                <div class="space-y-1" :class="!formParams.enable_early_arrival_ot ? 'opacity-50 pointer-events-none' : ''">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Min Early Check-in Duration</label>
                        <template x-if="isFieldDirty('early_arrival_min_threshold_minutes')">
                            <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                        </template>
                    </div>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="0" 
                            max="240"
                            step="5"
                            :value="formParams.early_arrival_min_threshold_minutes ?? 0"
                            @input="
                                const val = parseInt($event.target.value) || 0;
                                formParams.early_arrival_min_threshold_minutes = val;
                                if(selectedScopeLevel !== 'Company') {
                                    overriddenKeys['early_arrival_min_threshold_minutes'] = true;
                                }
                            "
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">min</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Eligibility threshold (not a deduction): must check in at least this early</p>
                </div>

                <!-- Early Check-in Grace Minutes -->
                <div class="space-y-1" :class="!formParams.enable_early_arrival_ot ? 'opacity-50 pointer-events-none' : ''">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Early Arrival Grace</label>
                        <template x-if="isFieldDirty('early_arrival_grace_minutes')">
                            <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                        </template>
                    </div>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="0" 
                            max="60"
                            step="1"
                            x-model.number="formParams.early_arrival_grace_minutes"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['early_arrival_grace_minutes'] = true;"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">min</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Grace buffer subtracted before payable early minutes begin (default 0)</p>
                </div>
            </div>

            <!-- Dynamic Rule in action preview -->
            <div class="p-3 bg-sky-50/70 dark:bg-sky-950/40 rounded-xl border border-sky-100 dark:border-sky-900/50 text-xs text-sky-950 dark:text-sky-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-sky-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Rule in action: </span>
                    <template x-if="!formParams.enable_early_arrival_ot">
                        <span>Early check-in overtime is <strong>disabled</strong>. Any time worked before shift start will not count towards overtime.</span>
                    </template>
                    <template x-if="formParams.enable_early_arrival_ot">
                        <span>
                            Early check-in overtime is <strong>enabled</strong> with a minimum eligibility threshold of <strong x-text="(formParams.early_arrival_min_threshold_minutes ?? 0) + ' minutes'"></strong>. 
                            <strong>Threshold is an eligibility condition, not a deduction:</strong> an employee checking in 45 minutes before shift meets a 30m threshold and receives all 45 minutes of early OT.
                        </span>
                    </template>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 2: Post Check-out Overtime Policy (OPEN BY DEFAULT) -->
    <div 
        x-show="isCardVisible('Post Check-out Overtime', 'Enable/disable post check-out overtime and configure minimum duration threshold', ['enable_post_shift_ot', 'post_shift_min_threshold_minutes', 'post_shift_grace_minutes', 'min_ot_minutes_to_qualify'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('ot_post_checkout', true)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
                    <i data-lucide="log-out" class="w-4 h-4"></i>
                </div>
                <div>
                    <div class="flex items-center gap-2">
                        <h3 class="text-sm font-bold text-slate-900 dark:text-white">Post Check-out Overtime</h3>
                        <span 
                            class="px-2 py-0.5 rounded-full text-[10px] font-bold"
                            :class="(formParams.enable_post_shift_ot !== false) ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'"
                            x-text="(formParams.enable_post_shift_ot !== false) ? 'Enabled' : 'Disabled'"
                        ></span>
                    </div>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Count overtime when employees work beyond scheduled shift end time. Threshold is an eligibility condition (not a deduction).</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('ot_post_checkout', true) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('ot_post_checkout', true)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <!-- Enable Toggle -->
                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Enable Post Check-out OT</label>
                        <template x-if="isFieldDirty('enable_post_shift_ot')">
                            <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                        </template>
                    </div>
                    <div class="flex items-center justify-between pt-2">
                        <span class="text-xs font-semibold" x-text="(formParams.enable_post_shift_ot !== false) ? 'Enabled' : 'Disabled'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                :checked="Boolean(formParams.enable_post_shift_ot !== false)"
                                @change="
                                    const val = $event.target.checked;
                                    formParams.enable_post_shift_ot = val;
                                    if(selectedScopeLevel !== 'Company') {
                                        overriddenKeys['enable_post_shift_ot'] = true;
                                    }
                                "
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-indigo-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Allow working past scheduled shift end to count as overtime</p>
                </div>

                <!-- Minimum Overtime Minutes (Default: 30 minutes) -->
                <div class="space-y-1" :class="(formParams.enable_post_shift_ot === false) ? 'opacity-50 pointer-events-none' : ''">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Min Overtime Duration (Default 30)</label>
                        <template x-if="isFieldDirty('post_shift_min_threshold_minutes') || isFieldDirty('min_ot_minutes_to_qualify')">
                            <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                        </template>
                    </div>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="0" 
                            max="240"
                            step="5"
                            :value="formParams.post_shift_min_threshold_minutes ?? formParams.min_ot_minutes_to_qualify ?? 30"
                            @input="
                                const val = parseInt($event.target.value) || 0;
                                formParams.post_shift_min_threshold_minutes = val;
                                formParams.min_ot_minutes_to_qualify = val;
                                if(selectedScopeLevel !== 'Company') {
                                    overriddenKeys['post_shift_min_threshold_minutes'] = true;
                                    overriddenKeys['min_ot_minutes_to_qualify'] = true;
                                }
                            "
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">min</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Eligibility threshold (not a deduction): must work past shift by at least this duration</p>
                </div>

                <!-- Post Shift Grace Minutes -->
                <div class="space-y-1" :class="(formParams.enable_post_shift_ot === false) ? 'opacity-50 pointer-events-none' : ''">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Post-Shift Grace Buffer</label>
                        <template x-if="isFieldDirty('post_shift_grace_minutes')">
                            <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                        </template>
                    </div>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="0" 
                            max="60"
                            step="1"
                            x-model.number="formParams.post_shift_grace_minutes"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['post_shift_grace_minutes'] = true;"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">min</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Tolerance window for handing over tasks before OT accrues (default 0)</p>
                </div>
            </div>

            <!-- Dynamic Rule in action preview -->
            <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Rule in action: </span>
                    <template x-if="formParams.enable_post_shift_ot === false">
                        <span>Post check-out overtime is <strong>disabled</strong>. Work beyond shift end will not count towards overtime.</span>
                    </template>
                    <template x-if="formParams.enable_post_shift_ot !== false">
                        <span>
                            Post check-out overtime is <strong>enabled</strong> with a minimum eligibility threshold of <strong x-text="(formParams.post_shift_min_threshold_minutes ?? formParams.min_ot_minutes_to_qualify ?? 30) + ' minutes'"></strong> (default 30).
                            <strong>Threshold is an eligibility condition, not a deduction:</strong> for example, if shift ends at 16:00 and checkout is 17:00 (60 minutes past shift), eligible OT is <strong>60 minutes</strong> (not 30). If checkout is at 16:20 (20 minutes past shift, under the 30m threshold), eligible OT is <strong>0 minutes</strong>.
                        </span>
                    </template>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 3: Overtime Rate Multipliers -->
    <div 
        x-show="isCardVisible('Overtime Multipliers', 'Hourly rate multipliers for workdays, weekends, holidays, special duty, and night shifts', ['normal_multiplier', 'weekly_off_multiplier', 'holiday_multiplier', 'special_multiplier', 'night_multiplier'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('ot_multipliers', false)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                    <i data-lucide="timer" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Overtime Rate Multipliers</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Multipliers applied to base hourly wage for workdays, weekends, holidays, special duty, and night shifts.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('ot_multipliers', false) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('ot_multipliers', false)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <!-- Normal Workday -->
                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Normal Workday Multiplier</label>
                        <template x-if="isFieldDirty('normal_multiplier')">
                            <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                        </template>
                    </div>
                    <div class="relative">
                        <input 
                            type="number" 
                            step="0.25" 
                            min="1.0" 
                            max="5.0"
                            x-model.number="formParams.normal_multiplier"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['normal_multiplier'] = true;"
                            class="w-full px-3 py-1.5 pr-10 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">x</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Standard overtime rate on regular working days (default 1.5x)</p>
                </div>

                <!-- Weekly Off -->
                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Weekly Off Multiplier</label>
                        <template x-if="isFieldDirty('weekly_off_multiplier')">
                            <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                        </template>
                    </div>
                    <div class="relative">
                        <input 
                            type="number" 
                            step="0.25" 
                            min="1.0" 
                            max="5.0"
                            x-model.number="formParams.weekly_off_multiplier"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['weekly_off_multiplier'] = true;"
                            class="w-full px-3 py-1.5 pr-10 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">x</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Multiplier for work performed on rest days (default 2.0x)</p>
                </div>

                <!-- Public Holiday -->
                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Public Holiday Multiplier</label>
                        <template x-if="isFieldDirty('holiday_multiplier')">
                            <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                        </template>
                    </div>
                    <div class="relative">
                        <input 
                            type="number" 
                            step="0.25" 
                            min="1.0" 
                            max="5.0"
                            x-model.number="formParams.holiday_multiplier"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['holiday_multiplier'] = true;"
                            class="w-full px-3 py-1.5 pr-10 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">x</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Multiplier for work performed on holidays (default 2.0x)</p>
                </div>

                <!-- Special Duty Multiplier -->
                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Special Duty Multiplier</label>
                        <template x-if="isFieldDirty('special_multiplier')">
                            <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                        </template>
                    </div>
                    <div class="relative">
                        <input 
                            type="number" 
                            step="0.25" 
                            min="1.0" 
                            max="5.0"
                            x-model.number="formParams.special_multiplier"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['special_multiplier'] = true;"
                            class="w-full px-3 py-1.5 pr-10 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">x</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Multiplier for assigned special / emergency duty (default 2.0x / 2.5x)</p>
                </div>

                <!-- Night Multiplier -->
                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Night Multiplier</label>
                        <template x-if="isFieldDirty('night_multiplier')">
                            <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                        </template>
                    </div>
                    <div class="relative">
                        <input 
                            type="number" 
                            step="0.25" 
                            min="1.0" 
                            max="5.0"
                            x-model.number="formParams.night_multiplier"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['night_multiplier'] = true;"
                            class="w-full px-3 py-1.5 pr-10 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">x</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Multiplier for night shift overtime windows (default 1.5x)</p>
                </div>
        </div>
    </div>

    <!-- Card 4: Billing Increments & Rounding Policy -->
    <div 
        x-show="isCardVisible('Thresholds & Rounding', 'Billing increments, time rounding, and counting units', ['min_ot_unit_minutes', 'rounding_mode'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('ot_increments', false)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                    <i data-lucide="sliders" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Billing Increments & Rounding</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Configure smallest billable overtime blocks and payroll rounding rules.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('ot_increments', false) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('ot_increments', false)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Billing Increment Unit</label>
                        <template x-if="isFieldDirty('min_ot_unit_minutes')">
                            <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                        </template>
                    </div>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="1" 
                            max="60"
                            x-model.number="formParams.min_ot_unit_minutes"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['min_ot_unit_minutes'] = true;"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">min</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Interval for counting fractional overtime units</p>
                </div>

                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Rounding Mode</label>
                        <template x-if="isFieldDirty('rounding_mode')">
                            <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                        </template>
                    </div>
                    <select 
                        x-model="formParams.rounding_mode"
                        @change="if(selectedScopeLevel !== 'Company') overriddenKeys['rounding_mode'] = true;"
                        class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                    >
                        <option value="Exact">Exact minutes</option>
                        <option value="Nearest 15 minutes">Nearest 15 minutes</option>
                        <option value="Nearest 30 minutes">Nearest 30 minutes</option>
                        <option value="Nearest 1 hour">Nearest 1 hour</option>
                        <option value="Round Down">Round Down</option>
                        <option value="Round Up">Round Up</option>
                    </select>
                    <p class="text-[11px] text-slate-400">Rounding applied to total payable minutes</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 5: Overtime Caps & Approvals -->
    <div 
        x-show="isCardVisible('Overtime Caps & Approvals', 'Maximum permissible daily and monthly OT hours and approvals', ['max_daily_ot_hours', 'max_monthly_ot_hours', 'requires_pre_approval', 'requires_post_approval'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('ot_caps', false)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                    <i data-lucide="shield-alert" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Overtime Limits & Approvals</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Daily and monthly statutory caps and supervisor sign-off requirements.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('ot_caps', false) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('ot_caps', false)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Max Daily OT</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            step="0.5" 
                            min="0" 
                            max="12"
                            x-model.number="formParams.max_daily_ot_hours"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['max_daily_ot_hours'] = true;"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">hrs</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Maximum cap per single workday</p>
                </div>

                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Max Monthly OT</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            step="1" 
                            min="0" 
                            max="200"
                            x-model.number="formParams.max_monthly_ot_hours"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['max_monthly_ot_hours'] = true;"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">hrs</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Statutory monthly ceiling</p>
                </div>

                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Pre-Approval Required</label>
                    <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-semibold" x-text="formParams.requires_pre_approval ? 'Required' : 'Not Required'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                x-model="formParams.requires_pre_approval"
                                @change="if(selectedScopeLevel !== 'Company') overriddenKeys['requires_pre_approval'] = true;"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Manager sign-off before overtime shift</p>
                </div>

                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Post-Approval Required</label>
                    <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-semibold" x-text="formParams.requires_post_approval ? 'Required' : 'Not Required'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                x-model="formParams.requires_post_approval"
                                @change="if(selectedScopeLevel !== 'Company') overriddenKeys['requires_post_approval'] = true;"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Manager sign-off on computed hours</p>
                </div>
            </div>

            <!-- Live Example Sentence -->
            <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Rule in action: </span>
                    <span x-text="'Max ' + (formParams.max_daily_ot_hours || 4) + ' hrs OT per day and ' + (formParams.max_monthly_ot_hours || 60) + ' hrs per month. ' + (formParams.requires_post_approval ? 'Requires supervisor post-shift approval before payroll inclusion.' : 'Auto-approved for payroll.')"></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 6: Weekly Overtime -->
    <div 
        x-show="isCardVisible('Weekly Overtime', 'Weekly overtime calculation based on net present days and weekly hour quota', ['weekly_ot_enabled', 'weekly_required_hours', 'weekly_present_days', 'weekly_ot_multiplier'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('ot_weekly', false)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
                    <i data-lucide="calendar-range" class="w-4 h-4"></i>
                </div>
                <div>
                    <div class="flex items-center gap-2">
                        <h3 class="text-sm font-bold text-slate-900 dark:text-white">Weekly Overtime</h3>
                        <span 
                            class="px-2 py-0.5 rounded-full text-[10px] font-bold"
                            :class="formParams.weekly_ot_enabled ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'"
                            x-text="formParams.weekly_ot_enabled ? 'Enabled' : 'Disabled'"
                        ></span>
                    </div>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Weekly overtime threshold, present day accumulation, and rate multiplier.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('ot_weekly', false) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('ot_weekly', false)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <!-- Weekly OT Toggle -->
                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Weekly OT Enabled</label>
                        <div class="flex items-center gap-1">
                            <template x-if="isFieldDirty('weekly_ot_enabled')">
                                <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                            </template>
                            <template x-if="isFieldDirty('weekly_ot_enabled')">
                                <button type="button" @click="resetField('weekly_ot_enabled')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                    <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                </button>
                            </template>
                        </div>
                    </div>
                    <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-semibold" x-text="formParams.weekly_ot_enabled ? 'Enabled' : 'Disabled'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                :checked="Boolean(formParams.weekly_ot_enabled)"
                                @change="
                                    const val = $event.target.checked;
                                    formParams.weekly_ot_enabled = val;
                                    if(selectedScopeLevel !== 'Company') {
                                        overriddenKeys['weekly_ot_enabled'] = true;
                                    }
                                "
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Replaces daily OT on normal days. Off-day and holiday OT are unchanged.</p>
                </div>

                <!-- Weekly Required Hours -->
                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Required hours per week</label>
                        <div class="flex items-center gap-1">
                            <template x-if="isFieldDirty('weekly_required_hours')">
                                <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                            </template>
                            <template x-if="isFieldDirty('weekly_required_hours')">
                                <button type="button" @click="resetField('weekly_required_hours')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                    <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                </button>
                            </template>
                        </div>
                    </div>
                    <div class="relative">
                        <input 
                            type="number" 
                            step="0.5" 
                            min="1" 
                            max="168"
                            x-model.number="formParams.weekly_required_hours"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['weekly_required_hours'] = true;"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">hrs</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Standard weekly working hours threshold</p>
                </div>

                <!-- Weekly OT Multiplier -->
                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">OT multiplier</label>
                        <div class="flex items-center gap-1">
                            <template x-if="isFieldDirty('weekly_ot_multiplier')">
                                <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                            </template>
                            <template x-if="isFieldDirty('weekly_ot_multiplier')">
                                <button type="button" @click="resetField('weekly_ot_multiplier')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                    <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                </button>
                            </template>
                        </div>
                    </div>
                    <div class="relative">
                        <input 
                            type="number" 
                            step="0.1" 
                            min="1" 
                            max="5"
                            x-model.number="formParams.weekly_ot_multiplier"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['weekly_ot_multiplier'] = true;"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">x</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Hourly rate factor applied to weekly OT hours</p>
                </div>
            </div>

            <!-- Weekly Present Days -->
            <div class="space-y-2">
                <div class="flex items-center justify-between">
                    <div>
                        <label class="text-xs font-bold text-slate-800 dark:text-slate-200">Weekly Present Days</label>
                        <p class="text-[11px] text-slate-400">Days of the week counted towards weekly required work hours</p>
                    </div>
                    <div class="flex items-center gap-1.5">
                        <template x-if="isFieldDirty('weekly_present_days')">
                            <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                        </template>
                        <template x-if="isFieldDirty('weekly_present_days')">
                            <button type="button" @click="resetField('weekly_present_days')" title="Reset to saved value" class="text-slate-400 hover:text-rose-500 p-0.5 rounded cursor-pointer">
                                <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                            </button>
                        </template>
                    </div>
                </div>

                <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
                    <template x-for="day in (allDaysOfWeek || ['Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'])" :key="day">
                        <button 
                            type="button" 
                            @click="
                                if (!Array.isArray(formParams.weekly_present_days)) formParams.weekly_present_days = [];
                                const idx = formParams.weekly_present_days.indexOf(day);
                                if (idx === -1) {
                                    formParams.weekly_present_days.push(day);
                                } else {
                                    formParams.weekly_present_days.splice(idx, 1);
                                }
                                if (selectedScopeLevel !== 'Company') overriddenKeys['weekly_present_days'] = true;
                            "
                            :class="(Array.isArray(formParams.weekly_present_days) && formParams.weekly_present_days.includes(day)) ? 'bg-indigo-600 text-white font-bold shadow-xs border-indigo-700' : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100'"
                            class="py-2 px-3 rounded-xl border text-xs text-center transition cursor-pointer flex items-center justify-center gap-1.5"
                        >
                            <i data-lucide="check" class="w-3 h-3" x-show="Array.isArray(formParams.weekly_present_days) && formParams.weekly_present_days.includes(day)"></i>
                            <span x-text="day"></span>
                        </button>
                    </template>
                </div>
            </div>

            <!-- Live Example Sentence -->
            <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Rule in action: </span>
                    <span x-text="(formParams.weekly_required_hours || 44) + ' - worked = overtime, e.g. ' + (formParams.weekly_required_hours || 44) + ' - ' + ((Number(formParams.weekly_required_hours) || 44) + 4) + ' = 4 hrs at ' + (formParams.weekly_ot_multiplier || 2) + 'x'"></span>
                </div>
            </div>
        </div>
    </div>
</div>
