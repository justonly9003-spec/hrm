<?php
/**
 * Bonus Policy Configuration View
 * Single source rule definitions for statutory festival bonus schemes,
 * corporate incentives, service proration, and weekly attendance incentive tiers.
 */
?>
<div class="space-y-4">

    <!-- Scoped Override Warning & Prefill Banner -->
    <div x-show="selectedScopeLevel !== 'Company'" class="p-4 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-amber-900 dark:text-amber-200">
        <div class="flex items-start gap-2.5">
            <i data-lucide="alert-triangle" class="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5"></i>
            <div>
                <span class="font-bold">Scope Override Notice:</span>
                <span> In the rule engine, array parameters like <strong>Bonus Schemes</strong> are replaced as a whole by scoped rules. Any schemes defined for this <span x-text="selectedScopeLevel" class="font-bold underline"></span> will completely replace the whole company schemes list for matching employees, rather than merging with it.</span>
            </div>
        </div>
        <button 
            type="button" 
            @click="prefillFromCompany()" 
            class="shrink-0 px-3 py-1.5 bg-amber-100 hover:bg-amber-200 dark:bg-amber-900 dark:hover:bg-amber-800 text-amber-900 dark:text-amber-100 rounded-lg font-bold text-[11px] transition cursor-pointer flex items-center gap-1.5"
            title="Copy baseline schemes from company rule"
        >
            <i data-lucide="copy" class="w-3.5 h-3.5"></i>
            <span>Prefill from Company</span>
        </button>
    </div>

    <!-- Global schemes validation error banner -->
    <template x-if="errors && errors['schemes']">
        <div class="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 rounded-xl text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
            <i data-lucide="alert-circle" class="w-4 h-4 text-rose-500 shrink-0"></i>
            <span x-text="errors['schemes']"></span>
        </div>
    </template>

    <!-- Card 1: Company Bonus Schemes -->
    <div 
        x-show="isCardVisible('Company Bonus Schemes', 'Festival, annual, and corporate bonus schemes', ['schemes'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <div class="px-5 py-4 flex items-center justify-between border-b border-slate-100 dark:border-slate-800">
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-pink-50 dark:bg-pink-950/60 text-pink-600 dark:text-pink-400 flex items-center justify-center shrink-0">
                    <i data-lucide="gift" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Bonus Schemes</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Festival (Eid, Puja), corporate annual, and performance bonus policies.</p>
                </div>
            </div>
            <div class="flex items-center gap-2">
                <template x-if="canManage || (typeof canManageDomain === 'function' && canManageDomain('BONUS'))">
                    <button 
                        type="button" 
                        @click.stop="openAddSchemeModal()"
                        class="px-3 py-1.5 bg-pink-600 hover:bg-pink-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs cursor-pointer"
                    >
                        <i data-lucide="plus" class="w-3.5 h-3.5"></i>
                        <span>Add Bonus Scheme</span>
                    </button>
                </template>
            </div>
        </div>

        <div class="p-5 space-y-4">
            <!-- Schemes list -->
            <div class="space-y-3">
                <template x-if="!formParams.schemes || formParams.schemes.length === 0">
                    <div class="p-8 text-center border border-dashed border-slate-200 dark:border-slate-800 rounded-2xl">
                        <i data-lucide="inbox" class="w-8 h-8 text-slate-300 dark:text-slate-600 mx-auto mb-2"></i>
                        <p class="text-xs font-bold text-slate-700 dark:text-slate-300">No bonus schemes configured</p>
                        <p class="text-[11px] text-slate-400 mt-1">Click "+ Add Bonus Scheme" above to configure your first bonus policy.</p>
                    </div>
                </template>

                <template x-for="(s, idx) in (formParams.schemes || [])" :key="idx">
                    <div 
                        class="p-4 rounded-xl border transition space-y-3"
                        :class="s.status === 'Inactive' 
                            ? 'bg-slate-100/60 dark:bg-slate-900/60 border-slate-200 dark:border-slate-800 opacity-75' 
                            : 'bg-slate-50/70 dark:bg-slate-800/40 border-slate-200/90 dark:border-slate-800 shadow-2xs'"
                    >
                        <!-- Inline Validation Error Notice for this specific item -->
                        <template x-if="errors && (errors['schemes.' + idx + '.code'] || errors['schemes.' + idx + '.name'] || errors['schemes.' + idx + '.calculation_type'] || errors['schemes.' + idx + '.value'] || errors['schemes.' + idx + '.included_component_codes'])">
                            <div class="p-2.5 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 rounded-lg text-xs text-rose-700 dark:text-rose-300 space-y-1">
                                <template x-for="(errMsg, errKey) in errors" :key="errKey">
                                    <div x-show="errKey.startsWith('schemes.' + idx + '.')" class="flex items-center gap-1.5 font-medium">
                                        <i data-lucide="alert-circle" class="w-3.5 h-3.5 text-rose-500 shrink-0"></i>
                                        <span x-text="errMsg"></span>
                                    </div>
                                </template>
                            </div>
                        </template>

                        <!-- Header Row: Name, Code, Badges, Actions -->
                        <div class="flex items-center justify-between gap-3 flex-wrap">
                            <div class="flex items-center gap-2 flex-wrap">
                                <span class="font-bold text-sm text-slate-900 dark:text-white" x-text="s.name"></span>
                                <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-pink-100 dark:bg-pink-950 text-pink-700 dark:text-pink-300" x-text="s.code"></span>
                                <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300" x-text="s.category || 'Festival'"></span>
                                <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400" x-text="'#' + (s.priority || 1)"></span>
                                
                                <span 
                                    class="px-2 py-0.5 rounded-full text-[10px] font-bold"
                                    :class="s.status === 'Inactive' ? 'bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-400' : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'"
                                    x-text="s.status || 'Active'"
                                ></span>

                                <template x-if="isSchemeLocked(s.code)">
                                    <span class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300" title="Scheme code referenced in executed bonus records; cannot rename or delete">
                                        <i data-lucide="lock" class="w-3 h-3"></i>
                                        <span>Locked</span>
                                    </span>
                                </template>
                            </div>

                            <template x-if="canManage || (typeof canManageDomain === 'function' && canManageDomain('BONUS'))">
                                <div class="flex items-center gap-1">
                                    <!-- Active / Inactive Toggle -->
                                    <button 
                                        type="button" 
                                        @click.stop="toggleSchemeStatus(idx)" 
                                        class="px-2 py-1 rounded-lg text-[11px] font-bold border transition cursor-pointer"
                                        :class="s.status === 'Inactive' ? 'bg-white dark:bg-slate-800 border-slate-300 text-slate-700 hover:bg-slate-50' : 'bg-emerald-50 dark:bg-emerald-950 border-emerald-200 text-emerald-700 hover:bg-emerald-100'"
                                        title="Toggle Active/Inactive"
                                    >
                                        <span x-text="s.status === 'Inactive' ? 'Activate' : 'Deactivate'"></span>
                                    </button>

                                    <!-- Edit Button -->
                                    <button 
                                        type="button" 
                                        @click.stop="openEditSchemeModal(idx)" 
                                        class="p-1.5 text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 rounded-lg hover:bg-slate-200/60 dark:hover:bg-slate-700 transition cursor-pointer"
                                        title="Edit scheme"
                                    >
                                        <i data-lucide="pencil" class="w-3.5 h-3.5"></i>
                                    </button>

                                    <!-- Delete Button -->
                                    <button 
                                        type="button" 
                                        @click.stop="removeScheme(idx)" 
                                        class="p-1.5 rounded-lg transition cursor-pointer"
                                        :class="isSchemeLocked(s.code) ? 'text-slate-300 dark:text-slate-600 cursor-not-allowed' : 'text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40'"
                                        :disabled="isSchemeLocked(s.code)"
                                        :title="isSchemeLocked(s.code) ? 'Cannot delete scheme referenced by bonus records' : 'Delete scheme'"
                                    >
                                        <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                                    </button>
                                </div>
                            </template>
                            <template x-if="!(canManage || (typeof canManageDomain === 'function' && canManageDomain('BONUS')))">
                                <span class="text-[11px] text-slate-400 font-medium italic">Read-only</span>
                            </template>
                        </div>

                        <!-- Scheme Details Pill Grid -->
                        <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] bg-white dark:bg-slate-900/80 p-3 rounded-lg border border-slate-200/60 dark:border-slate-800">
                            <div>
                                <span class="text-slate-400 block text-[10px] uppercase font-bold">Calculation</span>
                                <span class="font-semibold text-slate-800 dark:text-slate-200" x-text="(() => {
                                    if (s.calculation_type === 'Flat') return (s.value || 0) + ' (Flat Amount)';
                                    if (s.calculation_type === 'Percentage_Gross') return (s.value || 0) + '% of Gross Salary';
                                    if (s.calculation_type === 'Formula') return 'Formula: ' + (s.custom_formula || 'Default');
                                    return (s.value || 0) + '% of Basic Salary';
                                })()"></span>
                            </div>

                            <div>
                                <span class="text-slate-400 block text-[10px] uppercase font-bold">Salary Basis</span>
                                <span class="font-semibold text-slate-800 dark:text-slate-200" x-text="s.salary_basis || 'Basic Salary'"></span>
                                <template x-if="s.salary_basis === 'Selected Components' && Array.isArray(s.included_component_codes) && s.included_component_codes.length > 0">
                                    <span class="block text-[10px] text-pink-600 dark:text-pink-400 font-mono" x-text="'[' + s.included_component_codes.join(', ') + ']'"></span>
                                </template>
                            </div>

                            <div>
                                <span class="text-slate-400 block text-[10px] uppercase font-bold">Min Service</span>
                                <span class="font-semibold text-slate-800 dark:text-slate-200" x-text="(s.min_service_days || 0) + ' days'"></span>
                                <span class="block text-[10px] text-slate-400" x-text="s.prorate_under_service_days ? 'Prorated (< ' + (s.prorate_threshold_months || 6) + ' mo)' : 'No proration'"></span>
                            </div>

                            <div>
                                <span class="text-slate-400 block text-[10px] uppercase font-bold">Probation</span>
                                <span class="font-semibold text-slate-800 dark:text-slate-200" x-text="s.include_probation ? 'Included' : 'Excluded'"></span>
                            </div>
                        </div>
                    </div>
                </template>
            </div>

            <!-- Live Explanation Sentence -->
            <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Active policy overview: </span>
                    <span x-text="(() => {
                        const active = (formParams.schemes || []).filter(sc => sc.status !== 'Inactive');
                        if (active.length === 0) return 'No active bonus schemes configured.';
                        return active.length + ' active scheme(s): ' + active.map(a => a.name + ' (' + a.code + ' · ' + (a.calculation_type === 'Flat' ? a.value + ' Flat' : a.value + '%') + ')').join('; ');
                    })()"></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal: Add / Edit Bonus Scheme covering ALL Schema Fields -->
    <div 
        x-show="showSchemeModal" 
        x-cloak 
        class="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs"
        @keydown.escape.window="showSchemeModal = false"
        @click.self="showSchemeModal = false"
    >
        <div 
            class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl w-full max-w-2xl overflow-hidden my-8"
            @click.stop
        >
            <!-- Modal Header -->
            <div class="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <div class="flex items-center gap-2.5">
                    <div class="w-8 h-8 rounded-xl bg-pink-100 dark:bg-pink-950 text-pink-600 flex items-center justify-center">
                        <i data-lucide="gift" class="w-4 h-4"></i>
                    </div>
                    <div>
                        <h3 class="text-sm font-black text-slate-900 dark:text-white" x-text="editingIndex !== null ? 'Edit Bonus Scheme' : 'Add New Bonus Scheme'"></h3>
                        <p class="text-[11px] text-slate-500">Configure statutory or discretionary bonus calculation parameters.</p>
                    </div>
                </div>
                <button type="button" @click="showSchemeModal = false" class="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1">
                    <i data-lucide="x" class="w-4 h-4"></i>
                </button>
            </div>

            <!-- Modal Body -->
            <div class="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
                <!-- Inline Modal Error Alert -->
                <div x-show="schemeModalError" class="p-3 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 rounded-xl text-xs text-rose-700 dark:text-rose-300 font-semibold flex items-center gap-2">
                    <i data-lucide="alert-circle" class="w-4 h-4 shrink-0 text-rose-600"></i>
                    <span x-text="schemeModalError"></span>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <!-- Scheme Code -->
                    <div class="space-y-1">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">
                            Scheme Code <span class="text-rose-500">*</span>
                        </label>
                        <input 
                            type="text" 
                            x-model="schemeForm.code"
                            @input="schemeForm.code = schemeForm.code.toUpperCase().replace(/[^A-Z0-9_]/g, '')"
                            :readonly="editingIndex !== null && isSchemeLocked(schemeForm.code)"
                            :class="editingIndex !== null && isSchemeLocked(schemeForm.code) ? 'bg-slate-100 dark:bg-slate-800 cursor-not-allowed opacity-80' : 'bg-white dark:bg-slate-800'"
                            placeholder="e.g. EID_FITR, ANNUAL_2026"
                            class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono font-bold uppercase text-slate-900 dark:text-white"
                        />
                        <template x-if="editingIndex !== null && isSchemeLocked(schemeForm.code)">
                            <p class="text-[10px] text-amber-600 dark:text-amber-400 font-semibold">Code is locked because bonus records exist for this scheme.</p>
                        </template>
                        <p class="text-[10px] text-slate-400">Unique uppercase identifier (A-Z, 0-9, _).</p>
                    </div>

                    <!-- Scheme Name -->
                    <div class="space-y-1">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">
                            Scheme Name <span class="text-rose-500">*</span>
                        </label>
                        <input 
                            type="text" 
                            x-model="schemeForm.name"
                            placeholder="e.g. Eid ul Fitr Festival Bonus"
                            class="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                    </div>

                    <!-- Category -->
                    <div class="space-y-1">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Category</label>
                        <select 
                            x-model="schemeForm.category"
                            class="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        >
                            <option value="Festival">Festival (Eid, Puja, Christmas, New Year)</option>
                            <option value="Annual">Annual Corporate Incentive</option>
                            <option value="Performance">Performance Incentive</option>
                            <option value="Statutory">Statutory / Mandatory</option>
                            <option value="Other">Other Discretionary</option>
                        </select>
                    </div>

                    <!-- Calculation Type (Fixed enum: Flat instead of Fixed_Amount) -->
                    <div class="space-y-1">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Calculation Type</label>
                        <select 
                            x-model="schemeForm.calculation_type"
                            class="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        >
                            <option value="Percentage_Basic">Percentage of Basic Salary</option>
                            <option value="Percentage_Gross">Percentage of Gross Salary</option>
                            <option value="Flat">Flat Amount</option>
                            <option value="Formula">Custom Formula</option>
                        </select>
                    </div>

                    <!-- Bonus Value -->
                    <div x-show="schemeForm.calculation_type !== 'Formula'" class="space-y-1">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">
                            Bonus Value <span x-text="schemeForm.calculation_type === 'Flat' ? '(Amount)' : '(%)'"></span>
                        </label>
                        <div class="relative">
                            <input 
                                type="number" 
                                step="any"
                                min="0" 
                                x-model.number="schemeForm.value"
                                class="w-full px-3 py-2 pr-12 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white"
                            />
                            <span class="absolute right-3 top-2.5 text-xs font-bold text-slate-400" x-text="schemeForm.calculation_type === 'Flat' ? 'Flat' : '%'"></span>
                        </div>
                    </div>

                    <!-- Salary Basis -->
                    <div class="space-y-1">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Salary Basis</label>
                        <select 
                            x-model="schemeForm.salary_basis"
                            class="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        >
                            <option value="Basic Salary">Basic Salary</option>
                            <option value="Gross Salary">Gross Salary</option>
                            <option value="Selected Components">Selected Components</option>
                        </select>
                    </div>

                    <!-- Priority -->
                    <div class="space-y-1">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Evaluation Priority</label>
                        <input 
                            type="number" 
                            min="0" 
                            max="999" 
                            x-model.number="schemeForm.priority"
                            class="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                    </div>

                    <!-- Status -->
                    <div class="space-y-1">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Scheme Status</label>
                        <select 
                            x-model="schemeForm.status"
                            class="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        >
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                    </div>
                </div>

                <!-- Custom Formula (when Formula selected) -->
                <div x-show="schemeForm.calculation_type === 'Formula'" class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Custom Calculation Formula</label>
                    <input 
                        type="text" 
                        x-model="schemeForm.custom_formula"
                        placeholder="e.g. BASIC * 0.5 + HRA * 0.25"
                        class="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono font-semibold text-slate-900 dark:text-white"
                    />
                </div>

                <!-- Included Salary Components (when Selected Components selected) -->
                <div x-show="schemeForm.salary_basis === 'Selected Components'" class="space-y-2 p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">
                        Included Salary Components <span class="text-rose-500">*</span>
                    </label>
                    <p class="text-[11px] text-slate-500">Select which earning components constitute the bonus calculation base:</p>

                    <div class="flex flex-wrap gap-2 pt-1">
                        <template x-for="comp in (masters.salary_components || [])" :key="comp.code">
                            <button 
                                type="button" 
                                @click="toggleComponentSelection(comp.code)"
                                class="px-2.5 py-1 rounded-lg text-xs font-bold border transition flex items-center gap-1.5 cursor-pointer"
                                :class="(schemeForm.included_component_codes || []).includes(comp.code)
                                    ? 'bg-pink-100 border-pink-300 text-pink-700 dark:bg-pink-950 dark:border-pink-800 dark:text-pink-300'
                                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:border-slate-300'"
                            >
                                <i 
                                    data-lucide="check" 
                                    class="w-3 h-3" 
                                    x-show="(schemeForm.included_component_codes || []).includes(comp.code)"
                                ></i>
                                <span x-text="comp.name + ' (' + comp.code + ')'"></span>
                            </button>
                        </template>

                        <template x-if="!masters.salary_components || masters.salary_components.length === 0">
                            <span class="text-xs text-slate-400 italic">No salary components configured in master records.</span>
                        </template>
                    </div>
                </div>

                <!-- Service Eligibility & Proration Settings -->
                <div class="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
                    <h4 class="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                        <i data-lucide="calendar" class="w-3.5 h-3.5 text-indigo-500"></i>
                        <span>Service Duration & Proration Rules</span>
                    </h4>

                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div class="space-y-1">
                            <label class="block text-[11px] font-bold text-slate-600 dark:text-slate-400">Min Service Days</label>
                            <input 
                                type="number" 
                                min="0" 
                                max="3650"
                                x-model.number="schemeForm.min_service_days"
                                class="w-full px-2.5 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-semibold"
                            />
                        </div>

                        <div class="space-y-1">
                            <label class="block text-[11px] font-bold text-slate-600 dark:text-slate-400">Prorate Under Threshold</label>
                            <div class="flex items-center gap-2 pt-1.5">
                                <label class="relative inline-flex items-center cursor-pointer">
                                    <input 
                                        type="checkbox" 
                                        x-model="schemeForm.prorate_under_service_days"
                                        class="sr-only peer"
                                    />
                                    <div class="w-8 h-4 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all dark:border-slate-600 peer-checked:bg-pink-600"></div>
                                </label>
                                <span class="text-xs font-semibold" x-text="schemeForm.prorate_under_service_days ? 'Yes' : 'No'"></span>
                            </div>
                        </div>

                        <div class="space-y-1">
                            <label class="block text-[11px] font-bold text-slate-600 dark:text-slate-400">Include Probation</label>
                            <div class="flex items-center gap-2 pt-1.5">
                                <label class="relative inline-flex items-center cursor-pointer">
                                    <input 
                                        type="checkbox" 
                                        x-model="schemeForm.include_probation"
                                        class="sr-only peer"
                                    />
                                    <div class="w-8 h-4 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all dark:border-slate-600 peer-checked:bg-pink-600"></div>
                                </label>
                                <span class="text-xs font-semibold" x-text="schemeForm.include_probation ? 'Yes' : 'No'"></span>
                            </div>
                        </div>
                    </div>

                    <!-- Proration Parameters (shown when prorate_under_service_days is true) -->
                    <div x-show="schemeForm.prorate_under_service_days" class="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 border-t border-slate-200/60 dark:border-slate-700/60">
                        <div class="space-y-1">
                            <label class="block text-[11px] font-bold text-slate-600 dark:text-slate-400">Prorate Threshold (Months)</label>
                            <input 
                                type="number" 
                                min="0" 
                                max="120"
                                x-model.number="schemeForm.prorate_threshold_months"
                                class="w-full px-2.5 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-semibold"
                            />
                        </div>

                        <div class="space-y-1">
                            <label class="block text-[11px] font-bold text-slate-600 dark:text-slate-400">Minimum Ratio (0.0 to 1.0)</label>
                            <input 
                                type="number" 
                                step="0.05"
                                min="0" 
                                max="1"
                                x-model.number="schemeForm.prorate_min_ratio"
                                class="w-full px-2.5 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-semibold"
                            />
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal Footer -->
            <div class="px-6 py-3.5 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2.5">
                <button 
                    type="button" 
                    @click="showSchemeModal = false"
                    class="px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
                >
                    Cancel
                </button>
                <button 
                    type="button" 
                    @click="saveSchemeModal()"
                    class="px-5 py-2 bg-pink-600 hover:bg-pink-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                    <i data-lucide="check" class="w-3.5 h-3.5"></i>
                    <span x-text="editingIndex !== null ? 'Update Scheme' : 'Add Scheme'"></span>
                </button>
            </div>
        </div>
    </div>

    <!-- Card 2: Weekly Performance Incentive Bonus -->
    <div 
        x-show="isCardVisible('Weekly Performance Bonus', 'Attendance incentive bonus awarded weekly', ['weekly_bonus_enabled', 'weekly_bonus_method', 'weekly_bonus_fixed_amount', 'weekly_bonus_percentage_of_basic', 'weekly_bonus_min_present_days', 'weekly_bonus_min_weekly_hours', 'weekly_bonus_late_allowed', 'weekly_bonus_max_allowed_lates'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('bonus_weekly', false)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                    <i data-lucide="zap" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Weekly Performance Incentive</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Incentive pay granted for perfect weekly attendance and punctuality.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('bonus_weekly', false) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('bonus_weekly', false)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                <span class="text-xs font-semibold text-slate-700 dark:text-slate-300">Enable Weekly Attendance Bonus</span>
                <label class="relative inline-flex items-center cursor-pointer">
                    <input 
                        type="checkbox" 
                        x-model="formParams.weekly_bonus_enabled"
                        @change="if(selectedScopeLevel !== 'Company') overriddenKeys['weekly_bonus_enabled'] = true;"
                        class="sr-only peer"
                    />
                    <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                </label>
            </div>

            <div x-show="formParams.weekly_bonus_enabled" class="space-y-4">
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div class="space-y-1">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Incentive Method</label>
                        <select 
                            x-model="formParams.weekly_bonus_method"
                            @change="if(selectedScopeLevel !== 'Company') overriddenKeys['weekly_bonus_method'] = true;"
                            class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        >
                            <option value="Fixed Amount">Fixed Amount</option>
                            <option value="Percentage of Basic">Percentage of Basic</option>
                            <option value="Hour Based">Hour Based</option>
                            <option value="Tier Based">Tier Based</option>
                        </select>
                    </div>

                    <!-- Fixed Amount -->
                    <div x-show="formParams.weekly_bonus_method === 'Fixed Amount'" class="space-y-1">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Fixed Weekly Amount</label>
                        <div class="relative">
                            <input 
                                type="number" 
                                min="0" 
                                x-model.number="formParams.weekly_bonus_fixed_amount"
                                @input="if(selectedScopeLevel !== 'Company') overriddenKeys['weekly_bonus_fixed_amount'] = true;"
                                class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                            />
                            <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">Amt</span>
                        </div>
                    </div>

                    <!-- Percentage of Basic -->
                    <div x-show="formParams.weekly_bonus_method === 'Percentage of Basic'" class="space-y-1">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Percentage of Basic</label>
                        <div class="relative">
                            <input 
                                type="number" 
                                min="0" 
                                max="100" 
                                x-model.number="formParams.weekly_bonus_percentage_of_basic"
                                @input="if(selectedScopeLevel !== 'Company') overriddenKeys['weekly_bonus_percentage_of_basic'] = true;"
                                class="w-full px-3 py-1.5 pr-10 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                            />
                            <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">%</span>
                        </div>
                    </div>

                    <!-- Hour Based Rate (Optional override) -->
                    <div x-show="formParams.weekly_bonus_method === 'Hour Based'" class="space-y-1">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Rate per Hour (Optional)</label>
                        <div class="relative">
                            <input 
                                type="number" 
                                min="0" 
                                step="0.5"
                                placeholder="Auto OT rate"
                                x-model.number="formParams.weekly_bonus_rate_per_hour"
                                @input="if(selectedScopeLevel !== 'Company') overriddenKeys['weekly_bonus_rate_per_hour'] = true;"
                                class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                            />
                            <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">/hr</span>
                        </div>
                    </div>

                    <div class="space-y-1">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Min Present Days</label>
                        <div class="relative">
                            <input 
                                type="number" 
                                min="1" 
                                max="7" 
                                x-model.number="formParams.weekly_bonus_min_present_days"
                                @input="if(selectedScopeLevel !== 'Company') overriddenKeys['weekly_bonus_min_present_days'] = true;"
                                class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                            />
                            <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">days</span>
                        </div>
                    </div>

                    <div class="space-y-1">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Max Allowed Lates</label>
                        <div class="relative">
                            <input 
                                type="number" 
                                min="0" 
                                max="5" 
                                x-model.number="formParams.weekly_bonus_max_allowed_lates"
                                @input="if(selectedScopeLevel !== 'Company') overriddenKeys['weekly_bonus_max_allowed_lates'] = true;"
                                class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                            />
                            <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">max</span>
                        </div>
                    </div>
                </div>

                <!-- Live Example Sentence -->
                <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                    <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                    <div>
                        <span class="font-bold">Rule in action: </span>
                        <span x-text="'Work at least ' + (formParams.weekly_bonus_min_present_days || 5) + ' days with max ' + (formParams.weekly_bonus_max_allowed_lates || 2) + ' lates -> eligible for ' + (formParams.weekly_bonus_method === 'Fixed Amount' ? (formParams.weekly_bonus_fixed_amount || 500) + ' Fixed' : (formParams.weekly_bonus_percentage_of_basic || 5) + '% of Basic Salary') + ' weekly bonus.'"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
