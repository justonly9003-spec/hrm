<?php
/**
 * Provident Fund Policy Configuration View
 * Single source rule definitions for statutory employee and employer
 * provident fund contribution rates, salary basis, and monthly caps.
 */
?>
<div class="space-y-4">

    <!-- Card 1: Contribution Rates & Matching (OPEN BY DEFAULT) -->
    <div 
        x-show="isCardVisible('Contribution Rates & Matching', 'Employee and employer monthly provident fund contribution percentages', ['employee_rate', 'employer_rate', 'contribution_type'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('pf_rates', true)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-cyan-50 dark:bg-cyan-950/60 text-cyan-600 dark:text-cyan-400 flex items-center justify-center shrink-0">
                    <i data-lucide="shield-check" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Contribution Rates & Matching</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Monthly payroll deduction and matching employer contribution rates.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('pf_rates', true) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('pf_rates', true)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <!-- Employee Rate -->
                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Employee Deduction Rate</label>
                        <div class="flex items-center gap-1">
                            <template x-if="isFieldDirty('employee_rate')">
                                <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                            </template>
                            <template x-if="isFieldDirty('employee_rate')">
                                <button type="button" @click="resetField('employee_rate')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                    <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                </button>
                            </template>
                        </div>
                    </div>
                    <div class="relative">
                        <input 
                            type="number" 
                            step="0.5" 
                            min="0" 
                            max="50"
                            x-model.number="formParams.employee_rate"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['employee_rate'] = true;"
                            class="w-full px-3 py-1.5 pr-10 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">%</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Deducted from employee monthly salary</p>
                </div>

                <!-- Employer Rate -->
                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Employer Matching Rate</label>
                        <div class="flex items-center gap-1">
                            <template x-if="isFieldDirty('employer_rate')">
                                <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                            </template>
                            <template x-if="isFieldDirty('employer_rate')">
                                <button type="button" @click="resetField('employer_rate')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                    <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                </button>
                            </template>
                        </div>
                    </div>
                    <div class="relative">
                        <input 
                            type="number" 
                            step="0.5" 
                            min="0" 
                            max="50"
                            x-model.number="formParams.employer_rate"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['employer_rate'] = true;"
                            class="w-full px-3 py-1.5 pr-10 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">%</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Equal matching contribution from company</p>
                </div>
            </div>

            <!-- Live Example Sentence -->
            <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Rule in action: </span>
                    <span x-text="'Employee contributes ' + (formParams.employee_rate || 7) + '% of ' + (formParams.calculation_basis || 'Basic') + ' and Employer matches ' + (formParams.employer_rate || 7) + '% (e.g. on 50,000 BDT Basic -> ' + (50000 * ((formParams.employee_rate || 7) / 100)) + ' BDT from employee + ' + (50000 * ((formParams.employer_rate || 7) / 100)) + ' BDT from employer = ' + (50000 * (((formParams.employee_rate || 7) + (formParams.employer_rate || 7)) / 100)) + ' BDT total monthly PF deposit).'"></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 2: Calculation Basis & Components (Collapsible) -->
    <div 
        x-show="isCardVisible('Calculation Basis & Components', 'Salary components included in PF computation basis', ['calculation_basis', 'basis_components'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('pf_basis', false)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0">
                    <i data-lucide="layers" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Calculation Basis & Components</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Selected salary components subject to PF deduction.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('pf_basis', false) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('pf_basis', false)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="space-y-2">
                <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Included Salary Components</label>
                <div class="flex items-center gap-2 flex-wrap">
                    <template x-for="comp in allBasisComponents" :key="comp">
                        <button 
                            type="button" 
                            @click="toggleComponent(comp)"
                            :class="(formParams.basis_components || []).includes(comp) ? 'bg-indigo-600 text-white font-bold shadow-xs' : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 font-medium'"
                            class="px-3 py-1.5 rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5"
                        >
                            <i data-lucide="check" class="w-3 h-3" x-show="(formParams.basis_components || []).includes(comp)"></i>
                            <span x-text="comp"></span>
                        </button>
                    </template>
                </div>
                <p class="text-[11px] text-slate-400">Components summed up before applying contribution percentage</p>
            </div>

            <!-- Live Example Sentence -->
            <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Rule in action: </span>
                    <span x-text="'Calculated strictly on: ' + ((formParams.basis_components || []).join(', ') || 'Basic') + ' components.'"></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 3: Statutory Caps & Limits (Collapsible) -->
    <div 
        x-show="isCardVisible('Statutory Caps & Limits', 'Minimum and maximum salary limits and deduction caps', ['min_salary_limit', 'max_salary_limit', 'min_deduction_limit', 'max_deduction_limit'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('pf_caps', false)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                    <i data-lucide="sliders" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Statutory Caps & Limits</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Ceilings on maximum qualifying salary and monthly deductions.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('pf_caps', false) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('pf_caps', false)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Max Salary Limit (0 = Uncapped)</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="0"
                            x-model.number="formParams.max_salary_limit"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['max_salary_limit'] = true;"
                            class="w-full px-3 py-1.5 pr-14 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">BDT</span>
                    </div>
                </div>

                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Max Monthly Deduction (0 = Uncapped)</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="0"
                            x-model.number="formParams.max_deduction_limit"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['max_deduction_limit'] = true;"
                            class="w-full px-3 py-1.5 pr-14 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">BDT</span>
                    </div>
                </div>
            </div>

            <!-- Live Example Sentence -->
            <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Rule in action: </span>
                    <span x-text="formParams.max_salary_limit > 0 ? 'Salary basis capped at ' + formParams.max_salary_limit + ' BDT.' : 'No statutory salary ceiling applied (deductions calculate on full basis).'"></span>
                </div>
            </div>
        </div>
    </div>
</div>
