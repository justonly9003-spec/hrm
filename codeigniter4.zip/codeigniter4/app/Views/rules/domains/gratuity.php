<?php
/**
 * Gratuity Policy Configuration View
 * Single source rule definitions for statutory Bangladesh Labour Act gratuity accrual rates,
 * vesting years, separation eligibility, and tax exemptions.
 */
?>
<div class="space-y-4">

    <!-- Card 1: Vesting & Accrual Rates (OPEN BY DEFAULT) -->
    <div 
        x-show="isCardVisible('Vesting & Accrual Rates', 'Minimum service years and days of salary per year of service', ['enabled', 'eligibility_min_years', 'days_per_year', 'days_per_year_after_10y', 'divisor_days'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('gratuity_accrual', true)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                    <i data-lucide="award" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Gratuity Vesting & Accrual Rates</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Vesting eligibility period and days of salary accrued per year of service.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('gratuity_accrual', true) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('gratuity_accrual', true)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Vesting Years</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            step="0.5" 
                            min="1" 
                            max="20"
                            x-model.number="formParams.eligibility_min_years"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['eligibility_min_years'] = true;"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">yrs</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Minimum service to qualify</p>
                </div>

                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Days/Year (&lt; 10 Yrs)</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="1" 
                            max="60"
                            x-model.number="formParams.days_per_year"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['days_per_year'] = true;"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">days</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Standard statutory 15 days/yr</p>
                </div>

                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Days/Year (10+ Yrs)</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="1" 
                            max="60"
                            x-model.number="formParams.days_per_year_after_10y"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['days_per_year_after_10y'] = true;"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">days</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Elevated tier after 10 years (30d)</p>
                </div>

                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Divisor Days</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="20" 
                            max="31"
                            x-model.number="formParams.divisor_days"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['divisor_days'] = true;"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">days</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Denominator (standard 26 days)</p>
                </div>
            </div>

            <!-- Live Example Sentence -->
            <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Rule in action: </span>
                    <span x-text="'Employee vested after ' + (formParams.eligibility_min_years || 5) + ' years receives ' + (formParams.days_per_year || 15) + ' days of Basic Salary per year of service (' + (formParams.days_per_year_after_10y || 30) + ' days/yr after 10 years) divided by ' + (formParams.divisor_days || 26) + ' working days.'"></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 2: Ceiling & Tax Exemptions (Collapsible) -->
    <div 
        x-show="isCardVisible('Ceiling & Tax Exemptions', 'Statutory maximum gratuity ceiling and tax-free threshold', ['max_ceiling', 'tax_exemption_limit', 'tax_rate_on_excess'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('gratuity_caps', false)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0">
                    <i data-lucide="shield-check" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Ceiling & Tax Exemption Limit</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Maximum gratuity payout limit and government tax-free exemption boundary.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('gratuity_caps', false) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('gratuity_caps', false)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Maximum Gratuity Ceiling</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="0"
                            x-model.number="formParams.max_ceiling"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['max_ceiling'] = true;"
                            class="w-full px-3 py-1.5 pr-14 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">BDT</span>
                    </div>
                </div>

                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Tax Exemption Threshold</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="0"
                            x-model.number="formParams.tax_exemption_limit"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['tax_exemption_limit'] = true;"
                            class="w-full px-3 py-1.5 pr-14 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">BDT</span>
                    </div>
                </div>
            </div>

            <!-- Live Example Sentence -->
            <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Rule in action: </span>
                    <span x-text="'Gratuity capped at ' + (formParams.max_ceiling ? Number(formParams.max_ceiling).toLocaleString() : '2,000,000') + ' BDT. Up to ' + (formParams.tax_exemption_limit ? Number(formParams.tax_exemption_limit).toLocaleString() : '2,500,000') + ' BDT is tax-exempt by law.'"></span>
                </div>
            </div>
        </div>
    </div>
</div>
