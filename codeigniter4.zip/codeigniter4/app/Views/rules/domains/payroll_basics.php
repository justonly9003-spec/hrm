<?php
/**
 * Payroll Basics Rule Configuration View
 * Single source rule definitions for enterprise currency, daily rate divisors,
 * standard working hours baseline, and wage proration basis.
 */
?>
<div class="space-y-4">

    <!-- Card 1: Daily Rate Divisor & Office Hours (OPEN BY DEFAULT) -->
    <div 
        x-show="isCardVisible('Daily Rate Divisor & Office Hours', 'Currency, standard hours, and daily salary divisor mode', ['currency_code', 'money_decimals', 'daily_rate_mode', 'daily_rate_divisor', 'standard_daily_hours'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('payroll_divisors', true)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                    <i data-lucide="banknote" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Daily Rate Divisor & Standard Hours</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Denominator used to convert monthly salary into daily and hourly rates.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('payroll_divisors', true) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('payroll_divisors', true)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <!-- Currency -->
                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Currency Code</label>
                    <input 
                        type="text" 
                        maxlength="3"
                        x-model="formParams.currency_code"
                        @input="if(selectedScopeLevel !== 'Company') overriddenKeys['currency_code'] = true;"
                        class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white uppercase"
                    />
                    <p class="text-[11px] text-slate-400">Payroll currency symbol (e.g. BDT)</p>
                </div>

                <!-- Daily Rate Mode -->
                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Daily Rate Mode</label>
                    <select 
                        x-model="formParams.daily_rate_mode"
                        @change="if(selectedScopeLevel !== 'Company') overriddenKeys['daily_rate_mode'] = true;"
                        class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                    >
                        <option value="Fixed">Fixed Divisor (e.g. 30 or 26 days)</option>
                        <option value="Calendar">Actual Calendar Days in Month</option>
                    </select>
                    <p class="text-[11px] text-slate-400">Denominator rule for daily wage</p>
                </div>

                <!-- Fixed Divisor (Shown only when Fixed) -->
                <div x-show="formParams.daily_rate_mode === 'Fixed'" class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Divisor Days</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="20" 
                            max="31"
                            x-model.number="formParams.daily_rate_divisor"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['daily_rate_divisor'] = true;"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">days</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Fixed divisor (30 for calendar, 26 for working)</p>
                </div>

                <!-- Standard Daily Hours -->
                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Standard Daily Hours</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            step="0.5" 
                            min="1" 
                            max="24"
                            x-model.number="formParams.standard_daily_hours"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['standard_daily_hours'] = true;"
                            class="w-full px-3 py-1.5 pr-14 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">hrs/day</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Base full-day office work hours</p>
                </div>
            </div>

            <!-- Live Example Sentence -->
            <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Rule in action: </span>
                    <span x-text="'Daily salary = Monthly Salary / ' + (formParams.daily_rate_mode === 'Fixed' ? (formParams.daily_rate_divisor || 30) : (formParams.daily_rate_mode === 'Calendar' ? 'calendar days (28-31)' : 'working days in month')) + '. Standard full-day shift = ' + (formParams.standard_daily_hours || 8) + ' hours.'"></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 2: Salary Proration Rules (Collapsible) -->
    <div 
        x-show="isCardVisible('Salary Proration Rules', 'Rules for prorating partial month wages on joining or exit', ['proration_basis'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('payroll_proration', false)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0">
                    <i data-lucide="split" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Wage Proration Basis</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Calculation rules for employees joining or leaving mid-month.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('payroll_proration', false) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('payroll_proration', false)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="max-w-md space-y-1">
                <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Proration Basis</label>
                <select 
                    x-model="formParams.proration_basis"
                    @change="if(selectedScopeLevel !== 'Company') overriddenKeys['proration_basis'] = true;"
                    class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                >
                    <option value="Calendar">Calendar Days in Month</option>
                    <option value="WorkingDays">Working Days in Month</option>
                </select>
                <p class="text-[11px] text-slate-400">Denominator used to calculate partial-month pay</p>
            </div>

            <!-- Live Example Sentence -->
            <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Rule in action: </span>
                    <span x-text="'Mid-month joiners paid based on: ' + (formParams.proration_basis || 'Calendar') + ' days basis.'"></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 3: Minimum Net Salary Floor (Statutory Safeguard) -->
    <div 
        x-show="isCardVisible('Minimum Net Salary Floor', 'Statutory safeguard and warning threshold for minimum net take-home pay', ['minimum_net_salary_floor'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('payroll_floor', false)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                    <i data-lucide="shield-alert" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Minimum Net Salary Floor</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Guaranteed minimum take-home salary threshold; triggers payroll run warning if net pay falls below this amount.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('payroll_floor', false) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('payroll_floor', false)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="max-w-md space-y-1">
                <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Minimum Net Salary Floor Amount</label>
                <div class="relative">
                    <input 
                        type="number" 
                        step="0.01" 
                        min="0" 
                        x-model.number="formParams.minimum_net_salary_floor"
                        @input="if(selectedScopeLevel !== 'Company') overriddenKeys['minimum_net_salary_floor'] = true;"
                        class="w-full px-3 py-1.5 pr-14 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        placeholder="0.00"
                    />
                    <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400" x-text="formParams.currency_code || 'BDT'"></span>
                </div>
                <p class="text-[11px] text-slate-400">Set to 0 for no floor. Net salary will not be altered or blocked, but warnings with shortfall are highlighted.</p>
            </div>

            <!-- Live Example Sentence -->
            <div class="p-3 bg-amber-50/70 dark:bg-amber-950/40 rounded-xl border border-amber-100 dark:border-amber-900/50 text-xs text-amber-950 dark:text-amber-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-amber-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Statutory Ceiling & Floor Rule: </span>
                    <span x-text="(formParams.minimum_net_salary_floor > 0) ? 'LOP stays outside the 50% statutory ceiling. If net salary falls below ' + (formParams.currency_code || '') + ' ' + (formParams.minimum_net_salary_floor || 0) + ', a shortfall warning will be generated in payroll summary and export.' : 'Floor is disabled (0). LOP is deducted in full outside 50% ceiling.'"></span>
                </div>
            </div>
        </div>
    </div>
</div>
