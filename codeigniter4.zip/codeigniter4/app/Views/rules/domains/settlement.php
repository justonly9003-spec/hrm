<?php
/**
 * Final Settlement Policy Configuration View
 * Single source rule definitions for notice periods, notice shortfall salary deductions,
 * exit month wage basis, and separation leave encashment.
 */
?>
<div class="space-y-4">

    <!-- Card 1: Notice Period & Shortfall Deductions (OPEN BY DEFAULT) -->
    <div 
        x-show="isCardVisible('Notice Period & Shortfall Deductions', 'Notice period days, exit month calculation basis, and shortfall deduction rules', ['notice_period_days', 'notice_max_days', 'exit_month_salary_basis', 'notice_shortfall_applies_to'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('settlement_notice', true)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 flex items-center justify-center shrink-0">
                    <i data-lucide="receipt" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Notice Period & Shortfall Deductions</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Required notice length and shortfall salary deductions upon separation.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('settlement_notice', true) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('settlement_notice', true)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Standard Notice Period</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="0" 
                            max="180"
                            x-model.number="formParams.notice_period_days"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['notice_period_days'] = true;"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">days</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Standard notice required from employee</p>
                </div>

                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Maximum Notice Limit</label>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="0" 
                            max="365"
                            x-model.number="formParams.notice_max_days"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['notice_max_days'] = true;"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">days</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Upper threshold on unserved notice</p>
                </div>

                <div class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Exit Month Salary Basis</label>
                    <select 
                        x-model="formParams.exit_month_salary_basis"
                        @change="if(selectedScopeLevel !== 'Company') overriddenKeys['exit_month_salary_basis'] = true;"
                        class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                    >
                        <option value="Gross">Gross Salary</option>
                        <option value="Basic">Basic Salary</option>
                    </select>
                    <p class="text-[11px] text-slate-400">Salary basis used for shortfall cuts</p>
                </div>
            </div>

            <div class="space-y-2">
                <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Shortfall Deduction Applies To:</label>
                <div class="flex items-center gap-2 flex-wrap">
                    <template x-for="sep in allSeparationTypes" :key="sep">
                        <button 
                            type="button" 
                            @click="toggleNoticeShortfall(sep)"
                            :class="(formParams.notice_shortfall_applies_to || []).includes(sep) ? 'bg-teal-600 text-white font-bold shadow-xs' : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 font-medium'"
                            class="px-3 py-1.5 rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5"
                        >
                            <i data-lucide="check" class="w-3 h-3" x-show="(formParams.notice_shortfall_applies_to || []).includes(sep)"></i>
                            <span x-text="sep"></span>
                        </button>
                    </template>
                </div>
            </div>

            <!-- Live Example Sentence -->
            <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Rule in action: </span>
                    <span x-text="'Resigning employee must serve ' + (formParams.notice_period_days || 30) + ' days notice. Any unserved days are deducted from ' + (formParams.exit_month_salary_basis || 'Gross') + ' Salary in final settlement.'"></span>
                </div>
            </div>
        </div>
    </div>
</div>
