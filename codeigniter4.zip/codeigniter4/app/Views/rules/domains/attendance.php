<?php
/**
 * Attendance Policy Configuration View
 * Single source rule definitions for working hours, schedules, grace periods,
 * late arrival deductions, breaks, and holidays.
 */
?>
<div class="space-y-4">

    <!-- Card 1: Work Schedule & Office Timings (OPEN BY DEFAULT) -->
    <div 
        x-show="isCardVisible('Work Schedule & Office Timings', 'Standard work hours, week start, and weekly off days', ['week_start_day', 'weekly_off_days', 'office_start_time', 'office_end_time', 'half_day_time', 'daily_required_hours', 'min_work_hours_for_present', 'half_day_threshold_hours'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <!-- Card Header (Collapsible toggle) -->
        <button 
            type="button" 
            @click="toggleCard('attendance_schedule', true)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
                    <i data-lucide="calendar" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Work Schedule & Office Timings</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Week start day, office opening/closing hours, and weekly days off.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('attendance_schedule', true) ? 'rotate-180' : ''"></i>
        </button>

        <!-- Card Body -->
        <div x-show="cardOpen('attendance_schedule', true)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-5">
            <!-- Weekly Days Off -->
            <div class="space-y-2">
                <div class="flex items-center justify-between">
                    <div>
                        <label class="text-xs font-bold text-slate-800 dark:text-slate-200">Weekly Days Off</label>
                        <p class="text-[11px] text-slate-400">Regular non-working days for employee payroll calculations</p>
                    </div>
                    <div class="flex items-center gap-1.5">
                        <template x-if="isFieldDirty('weekly_off_days')">
                            <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                        </template>
                        <template x-if="isFieldDirty('weekly_off_days')">
                            <button type="button" @click="resetField('weekly_off_days')" title="Reset to saved value" class="text-slate-400 hover:text-rose-500 p-0.5 rounded cursor-pointer">
                                <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                            </button>
                        </template>
                    </div>
                </div>

                <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
                    <template x-for="day in allDaysOfWeek" :key="day">
                        <button 
                            type="button" 
                            @click="toggleWeeklyOffDay(day)"
                            :class="isWeeklyOff(day) ? 'bg-indigo-600 text-white font-bold shadow-xs border-indigo-700' : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100'"
                            class="py-2 px-3 rounded-xl border text-xs text-center transition cursor-pointer flex items-center justify-center gap-1.5"
                        >
                            <i data-lucide="check" class="w-3 h-3" x-show="isWeeklyOff(day)"></i>
                            <span x-text="day"></span>
                        </button>
                    </template>
                </div>
            </div>

            <!-- Timings Grid -->
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <!-- Office Start -->
                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Office Start Time</label>
                        <div class="flex items-center gap-1">
                            <template x-if="isFieldDirty('office_start_time')">
                                <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                            </template>
                            <template x-if="isFieldDirty('office_start_time')">
                                <button type="button" @click="resetField('office_start_time')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                    <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                </button>
                            </template>
                        </div>
                    </div>
                    <input 
                        type="time" 
                        x-model="formParams.office_start_time"
                        @input="if(selectedScopeLevel !== 'Company') overriddenKeys['office_start_time'] = true;"
                        class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                    />
                    <p class="text-[11px] text-slate-400">Official daily shift opening time</p>
                </div>

                <!-- Half-Day Cutoff -->
                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Half-Day Cutoff</label>
                        <div class="flex items-center gap-1">
                            <template x-if="isFieldDirty('half_day_time')">
                                <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                            </template>
                            <template x-if="isFieldDirty('half_day_time')">
                                <button type="button" @click="resetField('half_day_time')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                    <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                </button>
                            </template>
                        </div>
                    </div>
                    <input 
                        type="time" 
                        x-model="formParams.half_day_time"
                        @input="if(selectedScopeLevel !== 'Company') overriddenKeys['half_day_time'] = true;"
                        class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                    />
                    <p class="text-[11px] text-slate-400">Midday cutoff for half-day credit</p>
                </div>

                <!-- Office End -->
                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Office End Time</label>
                        <div class="flex items-center gap-1">
                            <template x-if="isFieldDirty('office_end_time')">
                                <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                            </template>
                            <template x-if="isFieldDirty('office_end_time')">
                                <button type="button" @click="resetField('office_end_time')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                    <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                </button>
                            </template>
                        </div>
                    </div>
                    <input 
                        type="time" 
                        x-model="formParams.office_end_time"
                        @input="if(selectedScopeLevel !== 'Company') overriddenKeys['office_end_time'] = true;"
                        class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                    />
                    <p class="text-[11px] text-slate-400">Official daily shift closing time</p>
                </div>
            </div>

            <!-- Required Hours Grid -->
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <!-- Daily Required Hours -->
                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Daily Required Hours</label>
                        <div class="flex items-center gap-1">
                            <template x-if="isFieldDirty('daily_required_hours')">
                                <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                            </template>
                            <template x-if="isFieldDirty('daily_required_hours')">
                                <button type="button" @click="resetField('daily_required_hours')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                    <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                </button>
                            </template>
                        </div>
                    </div>
                    <div class="relative">
                        <input 
                            type="number" 
                            step="0.5" 
                            min="1" 
                            max="24"
                            x-model.number="formParams.daily_required_hours"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['daily_required_hours'] = true;"
                            class="w-full px-3 py-1.5 pr-14 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">hrs/day</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Base full-day working hours quota</p>
                </div>

                <!-- Present Min -->
                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Minimum Hours for Present</label>
                        <div class="flex items-center gap-1">
                            <template x-if="isFieldDirty('min_work_hours_for_present')">
                                <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                            </template>
                            <template x-if="isFieldDirty('min_work_hours_for_present')">
                                <button type="button" @click="resetField('min_work_hours_for_present')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                    <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                </button>
                            </template>
                        </div>
                    </div>
                    <div class="relative">
                        <input 
                            type="number" 
                            step="0.5" 
                            min="0" 
                            max="24"
                            x-model.number="formParams.min_work_hours_for_present"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['min_work_hours_for_present'] = true;"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">hrs</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Minimum worked hours to avoid absent</p>
                </div>

                <!-- Half-Day Min -->
                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Half-Day Threshold</label>
                        <div class="flex items-center gap-1">
                            <template x-if="isFieldDirty('half_day_threshold_hours')">
                                <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                            </template>
                            <template x-if="isFieldDirty('half_day_threshold_hours')">
                                <button type="button" @click="resetField('half_day_threshold_hours')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                    <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                </button>
                            </template>
                        </div>
                    </div>
                    <div class="relative">
                        <input 
                            type="number" 
                            step="0.5" 
                            min="0" 
                            max="24"
                            x-model.number="formParams.half_day_threshold_hours"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['half_day_threshold_hours'] = true;"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">hrs</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Threshold hours to credit half day</p>
                </div>
            </div>

            <!-- Live Example Sentence -->
            <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Rule in action: </span>
                    <span x-text="'Standard ' + (formParams.daily_required_hours || 8) + ' hrs/day from ' + (formParams.office_start_time || '09:00') + ' to ' + (formParams.office_end_time || '18:00') + ' with ' + ((formParams.weekly_off_days || []).join(', ') || 'no weekend') + ' off. Present minimum: ' + (formParams.min_work_hours_for_present || 4) + ' hrs.'"></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 2: Late Arrival Policy (Collapsible) -->
    <div 
        x-show="isCardVisible('Late Arrival Policy', 'Grace period and tiered penalty deduction', ['late_enabled', 'late_grace_minutes', 'late_penalty_method', 'late_penalty_per_minute', 'late_consecutive_days_threshold', 'late_consecutive_penalty_leave_days'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('attendance_late', false)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
                    <i data-lucide="clock-alert" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Late Arrival Policy</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Grace period tolerance and automated deduction rules.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('attendance_late', false) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('attendance_late', false)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                <span class="text-xs font-semibold text-slate-700 dark:text-slate-300">Enable Late Arrival Tracking</span>
                <label class="relative inline-flex items-center cursor-pointer">
                    <input 
                        type="checkbox" 
                        x-model="formParams.late_enabled"
                        @change="if(selectedScopeLevel !== 'Company') overriddenKeys['late_enabled'] = true;"
                        class="sr-only peer"
                    />
                    <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                </label>
            </div>

            <div x-show="formParams.late_enabled" class="space-y-4">
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <!-- Grace Period -->
                    <div class="space-y-1">
                        <div class="flex items-center justify-between">
                            <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Grace Period</label>
                            <div class="flex items-center gap-1">
                                <template x-if="isFieldDirty('late_grace_minutes')">
                                    <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                                </template>
                                <template x-if="isFieldDirty('late_grace_minutes')">
                                    <button type="button" @click="resetField('late_grace_minutes')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                        <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                    </button>
                                </template>
                            </div>
                        </div>
                        <div class="relative">
                            <input 
                                type="number" 
                                min="0" 
                                max="240"
                                x-model.number="formParams.late_grace_minutes"
                                @input="if(selectedScopeLevel !== 'Company') overriddenKeys['late_grace_minutes'] = true;"
                                class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                            />
                            <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">min</span>
                        </div>
                        <p class="text-[11px] text-slate-400">Tolerance window after office start</p>
                    </div>

                    <!-- Penalty Method -->
                    <div class="space-y-1">
                        <div class="flex items-center justify-between">
                            <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Penalty Method</label>
                            <div class="flex items-center gap-1">
                                <template x-if="isFieldDirty('late_penalty_method')">
                                    <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                                </template>
                                <template x-if="isFieldDirty('late_penalty_method')">
                                    <button type="button" @click="resetField('late_penalty_method')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                        <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                    </button>
                                </template>
                            </div>
                        </div>
                        <select 
                            x-model="formParams.late_penalty_method"
                            @change="if(selectedScopeLevel !== 'Company') overriddenKeys['late_penalty_method'] = true;"
                            class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        >
                            <option value="Leave deduction">Leave deduction</option>
                            <option value="Warning">Warning</option>
                            <option value="Deduction">Deduction</option>
                            <option value="Reduce working hours">Reduce working hours</option>
                            <option value="Ignore">Ignore</option>
                        </select>
                        <p class="text-[11px] text-slate-400">Action taken when employee arrives late</p>
                    </div>
                </div>

                <!-- Conditional: Deduction (Penalty Per Minute) -->
                <!-- Only shown when method is Deduction; with Warning it is hidden -->
                <div x-show="formParams.late_penalty_method === 'Deduction'" class="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200/80 dark:border-slate-700/80 space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Penalty per Minute</label>
                        <div class="flex items-center gap-1">
                            <template x-if="isFieldDirty('late_penalty_per_minute')">
                                <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                            </template>
                            <template x-if="isFieldDirty('late_penalty_per_minute')">
                                <button type="button" @click="resetField('late_penalty_per_minute')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                    <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                </button>
                            </template>
                        </div>
                    </div>
                    <div class="relative max-w-xs">
                        <input 
                            type="number" 
                            step="0.5" 
                            min="0" 
                            x-model.number="formParams.late_penalty_per_minute"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['late_penalty_per_minute'] = true;"
                            class="w-full px-3 py-1.5 pr-14 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">BDT/min</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Direct salary deduction rate per minute beyond grace period</p>
                </div>

                <!-- Conditional: Leave Deduction (Threshold & Leave Days) -->
                <!-- Only shown when method is Leave deduction -->
                <div x-show="formParams.late_penalty_method === 'Leave deduction'" class="grid grid-cols-1 sm:grid-cols-2 gap-4 p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200/80 dark:border-slate-700/80">
                    <div class="space-y-1">
                        <div class="flex items-center justify-between">
                            <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Late Days Threshold</label>
                            <div class="flex items-center gap-1">
                                <template x-if="isFieldDirty('late_consecutive_days_threshold')">
                                    <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                                </template>
                                <template x-if="isFieldDirty('late_consecutive_days_threshold')">
                                    <button type="button" @click="resetField('late_consecutive_days_threshold')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                        <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                    </button>
                                </template>
                            </div>
                        </div>
                        <div class="relative">
                            <input 
                                type="number" 
                                min="1" 
                                max="31" 
                                x-model.number="formParams.late_consecutive_days_threshold"
                                @input="if(selectedScopeLevel !== 'Company') overriddenKeys['late_consecutive_days_threshold'] = true;"
                                class="w-full px-3 py-1.5 pr-12 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                            />
                            <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">days</span>
                        </div>
                        <p class="text-[11px] text-slate-400">Count of late days in a month that triggers deduction</p>
                    </div>

                    <div class="space-y-1">
                        <div class="flex items-center justify-between">
                            <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Leave Days Deducted</label>
                            <div class="flex items-center gap-1">
                                <template x-if="isFieldDirty('late_consecutive_penalty_leave_days')">
                                    <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                                </template>
                                <template x-if="isFieldDirty('late_consecutive_penalty_leave_days')">
                                    <button type="button" @click="resetField('late_consecutive_penalty_leave_days')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                        <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                    </button>
                                </template>
                            </div>
                        </div>
                        <div class="relative">
                            <input 
                                type="number" 
                                step="0.5" 
                                min="0" 
                                max="10" 
                                x-model.number="formParams.late_consecutive_penalty_leave_days"
                                @input="if(selectedScopeLevel !== 'Company') overriddenKeys['late_consecutive_penalty_leave_days'] = true;"
                                class="w-full px-3 py-1.5 pr-12 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                            />
                            <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">days</span>
                        </div>
                        <p class="text-[11px] text-slate-400">Leave/salary balance days deducted per threshold hit</p>
                    </div>
                </div>

                <!-- Live Example Sentence -->
                <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                    <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                    <div>
                        <span class="font-bold">Rule in action: </span>
                        <span x-text="(() => {
                            const grace = formParams.late_grace_minutes || 0;
                            const method = formParams.late_penalty_method || 'Warning';
                            const start = formParams.office_start_time || '09:00';
                            let example = 'Arrive after grace period (' + grace + ' min past ' + start + ') -> late. ';
                            if (method === 'Leave deduction') {
                                const days = formParams.late_consecutive_days_threshold || 3;
                                const cut = formParams.late_consecutive_penalty_leave_days || 1;
                                example += days + ' late days in a month -> ' + cut + ' day of salary deducted.';
                            } else if (method === 'Deduction') {
                                const rate = formParams.late_penalty_per_minute || 0;
                                example += 'Each minute late -> ' + rate + ' BDT deducted from salary.';
                            } else if (method === 'Warning') {
                                example += 'Late arrival issues an official warning; no financial deduction.';
                            } else if (method === 'Reduce working hours') {
                                example += 'Late minutes are deducted from credited working hours.';
                            } else {
                                example += 'Late arrival is recorded for reports without penalty.';
                            }
                            return example;
                        })()"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 3: Early Departure Policy (Collapsible) -->
    <div 
        x-show="isCardVisible('Early Departure Policy', 'Early departure threshold and associated penalty', ['early_out_enabled', 'early_out_threshold_minutes', 'early_out_penalty_method', 'early_out_penalty_per_minute'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('attendance_early_out', false)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                    <i data-lucide="log-out" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Early Departure Policy</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Departure cutoff before shift end and associated penalty method.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('attendance_early_out', false) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('attendance_early_out', false)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                <span class="text-xs font-semibold text-slate-700 dark:text-slate-300">Enable Early Departure Tracking</span>
                <label class="relative inline-flex items-center cursor-pointer">
                    <input 
                        type="checkbox" 
                        x-model="formParams.early_out_enabled"
                        @change="if(selectedScopeLevel !== 'Company') overriddenKeys['early_out_enabled'] = true;"
                        class="sr-only peer"
                    />
                    <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                </label>
            </div>

            <div x-show="formParams.early_out_enabled" class="space-y-4">
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div class="space-y-1">
                        <div class="flex items-center justify-between">
                            <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Departure Threshold</label>
                            <div class="flex items-center gap-1">
                                <template x-if="isFieldDirty('early_out_threshold_minutes')">
                                    <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                                </template>
                                <template x-if="isFieldDirty('early_out_threshold_minutes')">
                                    <button type="button" @click="resetField('early_out_threshold_minutes')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                        <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                    </button>
                                </template>
                            </div>
                        </div>
                        <div class="relative">
                            <input 
                                type="number" 
                                min="0" 
                                max="240"
                                x-model.number="formParams.early_out_threshold_minutes"
                                @input="if(selectedScopeLevel !== 'Company') overriddenKeys['early_out_threshold_minutes'] = true;"
                                class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                            />
                            <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">min</span>
                        </div>
                        <p class="text-[11px] text-slate-400">Minutes before office end time</p>
                    </div>

                    <div class="space-y-1">
                        <div class="flex items-center justify-between">
                            <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Penalty Method</label>
                            <div class="flex items-center gap-1">
                                <template x-if="isFieldDirty('early_out_penalty_method')">
                                    <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                                </template>
                                <template x-if="isFieldDirty('early_out_penalty_method')">
                                    <button type="button" @click="resetField('early_out_penalty_method')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                        <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                    </button>
                                </template>
                            </div>
                        </div>
                        <select 
                            x-model="formParams.early_out_penalty_method"
                            @change="if(selectedScopeLevel !== 'Company') overriddenKeys['early_out_penalty_method'] = true;"
                            class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        >
                            <option value="Warning">Warning</option>
                            <option value="Deduction">Deduction</option>
                            <option value="Reduce working hours">Reduce working hours</option>
                            <option value="Ignore">Ignore</option>
                        </select>
                        <p class="text-[11px] text-slate-400">Enforcement on early checkout</p>
                    </div>
                </div>

                <!-- Conditional: Deduction (Penalty Per Minute) -->
                <div x-show="formParams.early_out_penalty_method === 'Deduction'" class="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200/80 dark:border-slate-700/80 space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Penalty per Minute</label>
                        <div class="flex items-center gap-1">
                            <template x-if="isFieldDirty('early_out_penalty_per_minute')">
                                <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                            </template>
                            <template x-if="isFieldDirty('early_out_penalty_per_minute')">
                                <button type="button" @click="resetField('early_out_penalty_per_minute')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                    <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                </button>
                            </template>
                        </div>
                    </div>
                    <div class="relative max-w-xs">
                        <input 
                            type="number" 
                            step="0.5" 
                            min="0" 
                            x-model.number="formParams.early_out_penalty_per_minute"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['early_out_penalty_per_minute'] = true;"
                            class="w-full px-3 py-1.5 pr-14 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">BDT/min</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Salary cut rate for early departure</p>
                </div>

                <!-- Live Example Sentence -->
                <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                    <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                    <div>
                        <span class="font-bold">Rule in action: </span>
                        <span x-text="'Leaving ' + (formParams.early_out_threshold_minutes || 15) + ' min early triggers: ' + (formParams.early_out_penalty_method || 'Warning') + (formParams.early_out_penalty_method === 'Deduction' ? ' at ' + (formParams.early_out_penalty_per_minute || 0) + ' BDT/min.' : '.')"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 4: Break Policy (Collapsible) -->
    <div 
        x-show="isCardVisible('Break Policy', 'Scheduled daily break duration, paid status, and deductions', ['break_enabled', 'break_duration_minutes', 'break_is_paid', 'break_auto_deduct', 'unpaid_break_treatment'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('attendance_break', false)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                    <i data-lucide="coffee" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Break Policy</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Duration, paid/unpaid status, and automatic timecard deduction.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('attendance_break', false) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('attendance_break', false)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Break Duration</label>
                        <div class="flex items-center gap-1">
                            <template x-if="isFieldDirty('break_duration_minutes')">
                                <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                            </template>
                            <template x-if="isFieldDirty('break_duration_minutes')">
                                <button type="button" @click="resetField('break_duration_minutes')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                    <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                </button>
                            </template>
                        </div>
                    </div>
                    <div class="relative">
                        <input 
                            type="number" 
                            min="0" 
                            max="240"
                            x-model.number="formParams.break_duration_minutes"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['break_duration_minutes'] = true;"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">min</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Standard allotted break time per day</p>
                </div>

                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Paid Break</label>
                    <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-semibold" x-text="formParams.break_is_paid ? 'Paid' : 'Unpaid'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                x-model="formParams.break_is_paid"
                                @change="if(selectedScopeLevel !== 'Company') overriddenKeys['break_is_paid'] = true;"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Whether break counts towards credited hours</p>
                </div>

                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Auto-Deduct from Hours</label>
                    <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-semibold" x-text="formParams.break_auto_deduct ? 'Yes' : 'No'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                x-model="formParams.break_auto_deduct"
                                @change="if(selectedScopeLevel !== 'Company') overriddenKeys['break_auto_deduct'] = true;"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Automatically subtract break without manual clock-out</p>
                </div>
            </div>

            <!-- Live Example Sentence -->
            <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Rule in action: </span>
                    <span x-text="(formParams.break_duration_minutes || 60) + ' min daily break (' + (formParams.break_is_paid ? 'Paid' : 'Unpaid') + ')' + (formParams.break_auto_deduct ? ' - auto-deducted from gross working hours.' : ' - requires manual punch.')"></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 5: Holiday Working Hour Credits (Collapsible) -->
    <div 
        x-show="isCardVisible('Holiday Working Hour Credits', 'Holiday working hour credits and weekly requirement inclusion', ['holiday_credited_hours', 'holiday_counts_as_working_hours', 'holiday_counts_toward_weekly_requirement'])" 
        class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden transition"
    >
        <button 
            type="button" 
            @click="toggleCard('attendance_holidays', false)"
            class="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition cursor-pointer"
        >
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0">
                    <i data-lucide="sparkles" class="w-4 h-4"></i>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">Holiday Working Hour Credits</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Public holiday working hour credits and calculation rules.</p>
                </div>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="cardOpen('attendance_holidays', false) ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="cardOpen('attendance_holidays', false)" x-collapse class="p-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Holiday Credited Hours</label>
                        <div class="flex items-center gap-1">
                            <template x-if="isFieldDirty('holiday_credited_hours')">
                                <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                            </template>
                            <template x-if="isFieldDirty('holiday_credited_hours')">
                                <button type="button" @click="resetField('holiday_credited_hours')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                    <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                </button>
                            </template>
                        </div>
                    </div>
                    <div class="relative">
                        <input 
                            type="number" 
                            step="0.5" 
                            min="0" 
                            max="24"
                            x-model.number="formParams.holiday_credited_hours"
                            @input="if(selectedScopeLevel !== 'Company') overriddenKeys['holiday_credited_hours'] = true;"
                            class="w-full px-3 py-1.5 pr-12 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white"
                        />
                        <span class="absolute right-3 top-2 text-[11px] font-bold text-slate-400">hrs</span>
                    </div>
                    <p class="text-[11px] text-slate-400">Hours credited for approved public holidays</p>
                </div>

                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Count as Working Hours</label>
                        <div class="flex items-center gap-1">
                            <template x-if="isFieldDirty('holiday_counts_as_working_hours')">
                                <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                            </template>
                            <template x-if="isFieldDirty('holiday_counts_as_working_hours')">
                                <button type="button" @click="resetField('holiday_counts_as_working_hours')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                    <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                </button>
                            </template>
                        </div>
                    </div>
                    <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-semibold" x-text="formParams.holiday_counts_as_working_hours ? 'Yes' : 'No'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                x-model="formParams.holiday_counts_as_working_hours"
                                @change="if(selectedScopeLevel !== 'Company') overriddenKeys['holiday_counts_as_working_hours'] = true;"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Holiday counts towards standard hours worked</p>
                </div>

                <div class="space-y-1">
                    <div class="flex items-center justify-between">
                        <label class="text-xs font-bold text-slate-700 dark:text-slate-300">Weekly Requirement Inclusion</label>
                        <div class="flex items-center gap-1">
                            <template x-if="isFieldDirty('holiday_counts_toward_weekly_requirement')">
                                <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">changed</span>
                            </template>
                            <template x-if="isFieldDirty('holiday_counts_toward_weekly_requirement')">
                                <button type="button" @click="resetField('holiday_counts_toward_weekly_requirement')" title="Reset" class="text-slate-400 hover:text-rose-500 p-0.5">
                                    <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                                </button>
                            </template>
                        </div>
                    </div>
                    <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-semibold" x-text="formParams.holiday_counts_toward_weekly_requirement ? 'Yes' : 'No'"></span>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                x-model="formParams.holiday_counts_toward_weekly_requirement"
                                @change="if(selectedScopeLevel !== 'Company') overriddenKeys['holiday_counts_toward_weekly_requirement'] = true;"
                                class="sr-only peer"
                            />
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                        </label>
                    </div>
                    <p class="text-[11px] text-slate-400">Counts towards weekly minimum hours requirement</p>
                </div>
            </div>

            <!-- Live Example Sentence -->
            <div class="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 text-xs text-indigo-950 dark:text-indigo-200 flex items-start gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600 shrink-0 mt-0.5"></i>
                <div>
                    <span class="font-bold">Rule in action: </span>
                    <span x-text="'Approved holidays credit ' + (formParams.holiday_credited_hours || 8) + ' hrs towards work requirements.'"></span>
                </div>
            </div>
        </div>
    </div>
</div>
