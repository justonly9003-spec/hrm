<?php
/**
 * Security & RBAC Architecture Suite - Simplified Single-Page Roles Management
 */
$isSelRoleActive = (strtolower($selectedRole['status'] ?? 'active') === 'active');
$isSelRoleSuper  = strtolower($selectedRole['code'] ?? '') === 'software_app_admin'
    || strtolower($selectedRole['name'] ?? '') === 'software app admin'
    || in_array($selectedRoleId, ['role-001', 'r-super-admin']);

$permService = new \App\Services\PermissionService();

// Module synonyms for bidirectional mapping across aliased domains
$moduleSynonyms = [
    'directory'         => ['employees', 'employee'],
    'employees'         => ['directory', 'employee'],
    'employee'          => ['directory', 'employees'],
    'leaves'            => ['leave'],
    'leave'             => ['leaves'],
    'company_expense'   => ['expenses', 'expense'],
    'expenses'          => ['company_expense', 'expense'],
    'expense'           => ['company_expense', 'expenses'],
    'medical_insurance' => ['insurance'],
    'insurance'         => ['medical_insurance'],
    'rostering'         => ['roster', 'shifts', 'shift'],
    'roster'            => ['rostering', 'shifts', 'shift'],
    'user'              => ['users'],
    'users'             => ['user'],
    'role'              => ['roles', 'rbac'],
    'roles'             => ['role', 'rbac'],
    'pf'                => ['provident_fund', 'provident-fund'],
    'bonus'             => ['bonuses'],
    'loans'             => ['loan'],
];

// Map standard and special actions to permission IDs, prioritizing canonical seeded codes
$permCodeToId = [];

// 1. Populate directly from permLookup
foreach ($permLookup as $code => $pObj) {
    if (!empty($pObj['id'])) {
        $permCodeToId[$code] = $pObj['id'];
    }
}

// 2. Map standard actions
foreach ($standardModules as $modKey => $modLabel) {
    foreach ($standardActions as $actKey => $actLabel) {
        $code = $modKey . '.' . $actKey;
        if (isset($permCodeToId[$code])) {
            continue;
        }
        $permObj = $permLookup[$code] ?? null;
        if (!$permObj) {
            $norm = $permService->normalizePermission($code);
            $canonCode = $norm['code'];
            $permObj = $permLookup[$canonCode] ?? null;
        }
        if (!$permObj && isset($moduleSynonyms[$modKey])) {
            foreach ($moduleSynonyms[$modKey] as $synMod) {
                if (isset($permLookup[$synMod . '.' . $actKey])) {
                    $permObj = $permLookup[$synMod . '.' . $actKey];
                    break;
                }
            }
        }
        if ($permObj && !empty($permObj['id'])) {
            $permCodeToId[$code] = $permObj['id'];
        }
    }
}

// 3. Map special / granular module actions to permission IDs
$specialModuleActions = $specialModuleActions ?? [];
foreach ($specialModuleActions as $modKey => $actions) {
    foreach ($actions as $actKey => $actDef) {
        $code = $modKey . '.' . $actKey;
        if (isset($permCodeToId[$code])) {
            continue;
        }
        $permObj = $permLookup[$code] ?? null;
        if (!$permObj) {
            $norm = $permService->normalizePermission($code);
            $canonCode = $norm['code'];
            $permObj = $permLookup[$canonCode] ?? null;
        }
        if (!$permObj && isset($moduleSynonyms[$modKey])) {
            foreach ($moduleSynonyms[$modKey] as $synMod) {
                if (isset($permLookup[$synMod . '.' . $actKey])) {
                    $permObj = $permLookup[$synMod . '.' . $actKey];
                    break;
                }
            }
        }
        if ($permObj && !empty($permObj['id'])) {
            $permCodeToId[$code] = $permObj['id'];
        }
    }
}

// 4. Ensure cross-module synonym keys are mirrored in permCodeToId
foreach (array_keys($permCodeToId) as $code) {
    if (str_contains($code, '.')) {
        [$m, $a] = explode('.', $code, 2);
        if (isset($moduleSynonyms[$m])) {
            foreach ($moduleSynonyms[$m] as $synM) {
                $synCode = $synM . '.' . $a;
                if (!isset($permCodeToId[$synCode])) {
                    $permCodeToId[$synCode] = $permCodeToId[$code];
                }
            }
        }
        // Mirror action aliases
        if ($a === 'export' && !isset($permCodeToId[$m . '.export_excel'])) {
            $permCodeToId[$m . '.export_excel'] = $permCodeToId[$code];
            $permCodeToId[$m . '.export_pdf'] = $permCodeToId[$code];
        }
        if ($a === 'manage' && !isset($permCodeToId[$m . '.lock_unlock'])) {
            $permCodeToId[$m . '.lock_unlock'] = $permCodeToId[$code];
        }
    }
}

// Module icon registry covering all system modules
$moduleIcons = [
    'dashboard'         => 'layout-dashboard',
    'directory'         => 'users',
    'attendance'        => 'calendar-check',
    'overtime'          => 'clock',
    'leaves'            => 'calendar-off',
    'rostering'         => 'calendar',
    'payroll'           => 'dollar-sign',
    'pf'                => 'piggy-bank',
    'bonus'             => 'gift',
    'loans'             => 'credit-card',
    'company_expense'   => 'receipt',
    'medical_insurance' => 'heart-pulse',
    'assets'            => 'laptop',
    'training'          => 'graduation-cap',
    'performance'       => 'trending-up',
    'recruitment'       => 'user-plus',
    'notices'           => 'megaphone',
    'reports'           => 'bar-chart-3',
    'rules'             => 'sliders-horizontal',
    'master'            => 'database',
    'user'              => 'user-check',
    'role'              => 'key',
    'settings'          => 'settings',
    'audit'             => 'shield',
    'backups'           => 'hard-drive',
];

// Pre-compute normalized codes assigned to the selected role
$assignedNormCodes = [];
foreach ($assignedPermCodes as $code) {
    $norm = $permService->normalizePermission($code);
    $assignedNormCodes[$norm['code']] = true;
}

// Helper to determine if a matrix action is granted (exact code OR alias-equivalent code)
$isActionGranted = function (string $modKey, string $actKey) use ($permLookup, $assignedPermCodes, $assignedPermIds, $assignedNormCodes, $permService, $moduleSynonyms): bool {
    $rawCode = $modKey . '.' . $actKey;

    // 1. Exact raw code assigned
    if (in_array($rawCode, $assignedPermCodes, true)) {
        return true;
    }
    $permObj = $permLookup[$rawCode] ?? null;
    if ($permObj && in_array($permObj['id'], $assignedPermIds, true)) {
        return true;
    }

    // 2. Cross-module synonyms check (e.g. leaves <-> leave, directory <-> employees, company_expense <-> expenses, etc.)
    $synMods = $moduleSynonyms[$modKey] ?? [];
    foreach ($synMods as $sMod) {
        $synCode = $sMod . '.' . $actKey;
        if (in_array($synCode, $assignedPermCodes, true)) {
            return true;
        }
        $synObj = $permLookup[$synCode] ?? null;
        if ($synObj && in_array($synObj['id'], $assignedPermIds, true)) {
            return true;
        }
    }

    // 3. Action alias checks (export <-> export_excel/export_pdf, manage <-> lock_unlock)
    if ($actKey === 'export') {
        if (in_array($modKey . '.export_excel', $assignedPermCodes, true) || in_array($modKey . '.export_pdf', $assignedPermCodes, true)) {
            return true;
        }
    }
    if ($actKey === 'export_excel' || $actKey === 'export_pdf') {
        if (in_array($modKey . '.export', $assignedPermCodes, true)) {
            return true;
        }
    }
    if ($actKey === 'lock_unlock' && in_array($modKey . '.manage', $assignedPermCodes, true)) {
        return true;
    }
    if ($actKey === 'manage' && in_array($modKey . '.lock_unlock', $assignedPermCodes, true)) {
        return true;
    }

    // 4. Normalized equivalent code
    $matrixNorm = $permService->normalizePermission($rawCode);
    if (isset($assignedNormCodes[$matrixNorm['code']])) {
        return true;
    }

    return false;
};

// Initialize module states on server render
$initialModules = [];
$assignedPerms = $assignedPerms ?? [];
foreach ($standardModules as $modKey => $modLabel) {
    $hasView   = $isActionGranted($modKey, 'view');
    $hasCreate = $isActionGranted($modKey, 'create');
    $hasEdit   = $isActionGranted($modKey, 'edit');
    $hasDelete = $isActionGranted($modKey, 'delete');

    $hasApprove     = $isActionGranted($modKey, 'approve');
    $hasReject      = $isActionGranted($modKey, 'reject');
    $hasExport      = $isActionGranted($modKey, 'export');
    $hasExportExcel = $isActionGranted($modKey, 'export_excel');
    $hasExportPdf   = $isActionGranted($modKey, 'export_pdf');
    $hasPrint       = $isActionGranted($modKey, 'print');
    $hasImport      = $isActionGranted($modKey, 'import');
    $hasRestore     = $isActionGranted($modKey, 'restore');
    $hasLock        = $isActionGranted($modKey, 'lock_unlock') || $isActionGranted($modKey, 'manage');

    $moduleHasApprove = isset($permLookup[$modKey . '.approve']);
    $isCompleteFull = $hasView && $hasCreate && $hasEdit && $hasDelete && (!$moduleHasApprove || ($hasApprove && $hasReject));

    // Special module actions
    $specials = [];
    $hasAnySpecial = false;
    if (isset($specialModuleActions[$modKey])) {
        foreach ($specialModuleActions[$modKey] as $specialAct => $specialDef) {
            $isGranted = $isActionGranted($modKey, $specialAct);
            $specials[$specialAct] = $isGranted;
            if ($isGranted) {
                $hasAnySpecial = true;
            }
        }
    }

    // Determine current scope level for this module from assigned permissions
    $moduleScope = 'company';
    foreach ($assignedPerms as $ap) {
        $pMod = $ap['module'] ?? '';
        $normMod = $permService->normalizePermission($ap['code'] ?? '')['module'];
        if (($pMod === $modKey || $normMod === $modKey) && !empty($ap['scope_level'])) {
            if ($ap['scope_level'] !== 'company') {
                $moduleScope = $ap['scope_level'];
                break;
            }
        }
    }

    $level = 'none';
    $isCustom = false;

    if ($isCompleteFull) {
        $level = 'full';
    } elseif ($hasView && $hasCreate && $hasEdit && !$hasDelete && !$hasApprove) {
        $level = 'edit';
    } elseif ($hasView && !$hasCreate && !$hasEdit && !$hasDelete && !$hasApprove) {
        $level = 'view';
    } elseif (!$hasView && !$hasCreate && !$hasEdit && !$hasDelete && !$hasApprove) {
        $level = 'none';
    } else {
        // Non-exact combination (e.g. edit without create, delete without edit, or missing approve)
        $isCustom = true;
        if ($isCompleteFull) {
            $level = 'full';
        } elseif ($hasDelete && (!$moduleHasApprove || $hasApprove)) {
            $level = 'full';
        } elseif ($hasEdit || $hasCreate) {
            $level = 'edit';
        } elseif ($hasView) {
            $level = 'view';
        } else {
            $level = 'none';
        }
    }

    if ($hasApprove !== $hasReject || $hasExportExcel !== $hasExportPdf || $hasAnySpecial) {
        $isCustom = true;
    }

    $initialModules[$modKey] = [
        'key'      => $modKey,
        'label'    => $modLabel,
        'icon'     => $moduleIcons[$modKey] ?? 'layers',
        'level'    => $level,
        'isCustom' => $isCustom,
        'expanded' => false,
        'scope'    => $moduleScope,
        'extras'   => [
            'approve' => ($hasApprove || $hasReject),
            'export'  => ($hasExport || $hasExportExcel || $hasExportPdf),
            'print'   => $hasPrint,
            'import'  => $hasImport,
            'restore' => $hasRestore,
            'lock'    => $hasLock,
        ],
        'specials' => $specials,
    ];
}
?>

<div class="space-y-6" x-data="rbacSimpleManager()">
    <!-- Dynamic Alert Banners -->
    <div x-show="statusMessage" x-cloak class="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs font-medium flex items-center justify-between">
        <div class="flex items-center gap-2">
            <i data-lucide="check-circle" class="w-4 h-4 text-emerald-600 shrink-0"></i>
            <span x-text="statusMessage"></span>
        </div>
        <button type="button" @click="statusMessage = ''" class="text-emerald-600 hover:text-emerald-800 font-bold ml-2 cursor-pointer">&times;</button>
    </div>
    <div x-show="errorMessage" x-cloak class="p-4 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200 text-xs font-medium flex items-center justify-between">
        <div class="flex items-center gap-2">
            <i data-lucide="alert-triangle" class="w-4 h-4 text-rose-600 shrink-0"></i>
            <span x-text="errorMessage"></span>
        </div>
        <button type="button" @click="errorMessage = ''" class="text-rose-600 hover:text-rose-800 font-bold ml-2 cursor-pointer">&times;</button>
    </div>

    <!-- Top Breadcrumbs & Page Header (Clean, banners/badges removed) -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <div class="flex items-center gap-2 text-xs font-semibold text-slate-400 dark:text-slate-500 mb-1">
                <span>HRMS Enterprise</span>
                <span>/</span>
                <span class="text-slate-600 dark:text-slate-300">Security Administration</span>
            </div>
            <h1 class="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
                <i data-lucide="shield-check" class="w-7 h-7 text-indigo-600"></i>
                <span>Security & RBAC Architecture Suite</span>
            </h1>
        </div>
    </div>

    <!-- Security & Governance Sub-Navigation Bar -->
    <?= view('partials/security_nav', ['activeTab' => 'roles']) ?>

    <!-- 1. Role Selector Chips & Status Toggle -->
    <div class="p-4 bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 shadow-xs flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <!-- Role Chips -->
        <div class="flex items-center gap-2 flex-wrap">
            <span class="text-xs font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider mr-1">
                Roles:
            </span>
            <?php foreach ($roles as $r): ?>
                <?php $isSelected = ($r['id'] === $selectedRoleId); ?>
                <a href="<?= base_url('users/roles?role_id=' . esc($r['id'])) ?>"
                   class="px-3.5 py-1.5 rounded-full text-xs font-semibold transition cursor-pointer <?= $isSelected
                       ? 'bg-indigo-600 text-white shadow-xs'
                       : 'bg-slate-100 dark:bg-slate-700/60 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700' ?>">
                    <?= esc($r['name']) ?>
                </a>
            <?php endforeach; ?>
        </div>

        <!-- Role Status Control -->
        <div class="flex items-center gap-2 shrink-0 self-start md:self-center pt-2 md:pt-0 border-t md:border-t-0 border-slate-100 dark:border-slate-700">
            <span class="text-xs text-slate-500 dark:text-slate-400 font-medium">Status:</span>
            <?php if ($isSelRoleSuper): ?>
                <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/40 text-amber-700 dark:text-amber-400" title="Software App Admin is a protected root role">
                    <i data-lucide="shield" class="w-3.5 h-3.5 text-amber-600 shrink-0"></i>
                    <span>Protected (Active)</span>
                </span>
            <?php else: ?>
                <form method="POST" action="<?= base_url('users/roles/toggle-status/' . esc($selectedRoleId) . '/' . ($isSelRoleActive ? 'inactive' : 'active')) ?>" class="inline m-0 p-0" onsubmit="return confirm('Change status of <?= esc($selectedRole['name'] ?? 'role') ?> to <?= $isSelRoleActive ? 'Inactive' : 'Active' ?>?')">
                    <?= csrf_field() ?>
                    <button type="submit"
                       class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border transition cursor-pointer <?= $isSelRoleActive
                           ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800/40 text-emerald-700 dark:text-emerald-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 hover:text-rose-700 hover:border-rose-200'
                           : 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800/40 text-rose-700 dark:text-rose-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 hover:text-emerald-700 hover:border-emerald-200' ?>"
                       title="Click to toggle status">
                        <span class="w-2 h-2 rounded-full <?= $isSelRoleActive ? 'bg-emerald-500' : 'bg-rose-500' ?>"></span>
                        <span><?= $isSelRoleActive ? 'Active' : 'Inactive' ?></span>
                    </button>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <!-- 2. Summary & Action Bar -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 px-1">
        <div class="flex items-center gap-2">
            <p class="text-sm font-medium text-slate-700 dark:text-slate-300">
                <span class="font-bold text-indigo-600 dark:text-indigo-400" x-text="accessibleCount"></span>
                of <?= count($standardModules) ?> modules accessible
            </p>
            <span class="text-slate-300 dark:text-slate-600">•</span>
            <span class="text-xs text-slate-500 dark:text-slate-400">
                Configuring: <strong class="text-slate-900 dark:text-white"><?= esc($selectedRole['name'] ?? 'Role') ?></strong>
            </span>
        </div>

        <div class="flex items-center gap-2.5">
            <!-- Copy from role button -->
            <button type="button" 
                    @click="openCloneModal = true" 
                    class="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/80 border border-slate-200 dark:border-slate-700 transition shadow-2xs flex items-center gap-1.5 cursor-pointer">
                <i data-lucide="copy" class="w-4 h-4 text-slate-500"></i>
                <span>Copy from role</span>
            </button>

            <!-- Save changes button -->
            <?php if (!$isSelRoleSuper): ?>
                <button type="button" 
                        @click="saveForm()" 
                        :disabled="isSaving"
                        class="px-4 py-2 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 shadow-sm transition flex items-center gap-1.5 cursor-pointer">
                    <template x-if="isSaving">
                        <svg class="animate-spin h-3.5 w-3.5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                    </template>
                    <template x-if="!isSaving">
                        <i data-lucide="save" class="w-4 h-4"></i>
                    </template>
                    <span x-text="isSaving ? 'Saving...' : 'Save changes'"></span>
                </button>
            <?php else: ?>
                <button type="button" 
                        disabled 
                        class="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 dark:text-slate-500 bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 cursor-not-allowed flex items-center gap-1.5"
                        title="Root Software App Admin permissions are protected and immutable">
                    <i data-lucide="lock" class="w-4 h-4"></i>
                    <span>Permissions Protected</span>
                </button>
            <?php endif; ?>
        </div>
    </div>

    <!-- 3. Form and 18-Module List -->
    <form id="permissionsForm" method="POST" action="<?= base_url('roles/update-permissions') ?>" @submit="submitForm($event)">
        <?= csrf_field() ?>
        <input type="hidden" name="role_id" value="<?= esc($selectedRoleId) ?>">
        <div x-ref="hiddenPermInputs" id="hiddenPermInputs"></div>

        <div class="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 shadow-xs overflow-hidden">
            <!-- Filter Bar -->
            <div class="p-3.5 border-b border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/40 flex items-center justify-between gap-3">
                <div class="relative w-full max-w-xs">
                    <i data-lucide="search" class="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"></i>
                    <input type="text" 
                           x-model="searchQuery" 
                           placeholder="Filter <?= count($standardModules) ?> modules..." 
                           class="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                </div>
                <div class="text-[11px] text-slate-400 font-medium">
                    Total Modules: <b class="text-slate-700 dark:text-slate-300"><?= count($standardModules) ?></b>
                </div>
            </div>

            <!-- Module Rows -->
            <div class="divide-y divide-slate-100 dark:divide-slate-700/60">
                <template x-for="mod in Object.values(modules)" :key="mod.key">
                    <div x-show="matchesSearch(mod)" class="p-4 hover:bg-slate-50/60 dark:hover:bg-slate-700/20 transition">
                        <!-- Main Row: Module Info + Segmented Control + Chevron -->
                        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                            <!-- Module Info -->
                            <div class="flex items-center gap-3">
                                <div class="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
                                    <i :data-lucide="mod.icon" class="w-4 h-4"></i>
                                </div>
                                <div class="flex items-center gap-2">
                                    <span class="text-sm font-bold text-slate-900 dark:text-white" x-text="mod.label"></span>
                                    
                                    <!-- Custom Dot Indicator -->
                                    <template x-if="mod.isCustom">
                                        <span class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-semibold bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800" 
                                              title="Module has a custom or non-standard permission mix assigned">
                                            <span class="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                                            <span>custom</span>
                                        </span>
                                    </template>
                                </div>
                            </div>

                            <!-- Controls: 4-Option Segmented Control + Chevron -->
                            <div class="flex items-center gap-3 self-end sm:self-center">
                                <!-- Segmented Control -->
                                <div class="inline-flex p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200/80 dark:border-slate-700">
                                    <button type="button" 
                                            @click="setLevel(mod.key, 'none')" 
                                            :disabled="isReadOnly"
                                            :class="mod.level === 'none' 
                                                ? 'bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 shadow-xs font-bold' 
                                                : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 font-medium'"
                                            class="px-3 py-1 text-xs rounded-lg transition cursor-pointer disabled:cursor-not-allowed">
                                        None
                                    </button>
                                    <button type="button" 
                                            @click="setLevel(mod.key, 'view')" 
                                            :disabled="isReadOnly"
                                            :class="mod.level === 'view' 
                                                ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs font-bold' 
                                                : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 font-medium'"
                                            class="px-3 py-1 text-xs rounded-lg transition cursor-pointer disabled:cursor-not-allowed">
                                        View
                                    </button>
                                    <button type="button" 
                                            @click="setLevel(mod.key, 'edit')" 
                                            :disabled="isReadOnly"
                                            :class="mod.level === 'edit' 
                                                ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs font-bold' 
                                                : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 font-medium'"
                                            class="px-3 py-1 text-xs rounded-lg transition cursor-pointer disabled:cursor-not-allowed">
                                        Edit
                                    </button>
                                    <button type="button" 
                                            @click="setLevel(mod.key, 'full')" 
                                            :disabled="isReadOnly"
                                            :class="mod.level === 'full' 
                                                ? 'bg-indigo-600 text-white shadow-xs font-bold' 
                                                : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 font-medium'"
                                            class="px-3 py-1 text-xs rounded-lg transition cursor-pointer disabled:cursor-not-allowed">
                                        Full
                                    </button>
                                </div>

                                <!-- Extra toggles expand/collapse chevron button -->
                                <button type="button" 
                                        @click="mod.expanded = !mod.expanded; $nextTick(() => { if (window.lucide) window.lucide.createIcons(); })" 
                                        class="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-500 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer flex items-center gap-1"
                                        :title="mod.expanded ? 'Hide extra actions' : 'Expand extra actions'">
                                    <template x-if="countActiveExtras(mod) > 0">
                                        <span class="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 px-1" x-text="'+' + countActiveExtras(mod)"></span>
                                    </template>
                                    <i data-lucide="chevron-down" class="w-4 h-4 transition-transform duration-200" :class="mod.expanded ? 'rotate-180 text-indigo-600' : ''"></i>
                                </button>
                            </div>
                        </div>

                        <!-- Expanded Section: Scope, Extras, and Special Actions -->
                        <div x-show="mod.expanded" class="mt-3 pt-3 border-t border-slate-100 dark:border-slate-700/60 space-y-3">
                            <!-- Scope Selector -->
                            <div class="flex items-center gap-2">
                                <span class="text-[11px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider mr-1">
                                    Scope:
                                </span>
                                <select x-model="mod.scope" :disabled="isReadOnly" class="text-xs px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500">
                                    <option value="company">Company (All Employees)</option>
                                    <option value="branch">Branch (Assigned Branch)</option>
                                    <option value="department">Department (Assigned Dept)</option>
                                    <option value="team">Team (Direct Reports)</option>
                                    <option value="self">Self (Own Records Only)</option>
                                </select>
                            </div>

                            <!-- Extras Toggles -->
                            <div class="flex items-center gap-2 flex-wrap">
                                <span class="text-[11px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider mr-1">
                                    Extras:
                                </span>

                                <!-- 1. Approve (approve + reject) -->
                                <label class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs cursor-pointer transition select-none"
                                       :class="mod.extras.approve 
                                           ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 font-semibold' 
                                           : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50'">
                                    <input type="checkbox" x-model="mod.extras.approve" :disabled="isReadOnly" class="w-3.5 h-3.5 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer">
                                    <span>Approve</span>
                                </label>

                                <!-- 2. Export (export_excel + export_pdf) -->
                                <label class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs cursor-pointer transition select-none"
                                       :class="mod.extras.export 
                                           ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 font-semibold' 
                                           : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50'">
                                    <input type="checkbox" x-model="mod.extras.export" :disabled="isReadOnly" class="w-3.5 h-3.5 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer">
                                    <span>Export</span>
                                </label>

                                <!-- 3. Print (print) -->
                                <label class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs cursor-pointer transition select-none"
                                       :class="mod.extras.print 
                                           ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 font-semibold' 
                                           : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50'">
                                    <input type="checkbox" x-model="mod.extras.print" :disabled="isReadOnly" class="w-3.5 h-3.5 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer">
                                    <span>Print</span>
                                </label>

                                <!-- 4. Import (import) -->
                                <label class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs cursor-pointer transition select-none"
                                       :class="mod.extras.import 
                                           ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 font-semibold' 
                                           : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50'">
                                    <input type="checkbox" x-model="mod.extras.import" :disabled="isReadOnly" class="w-3.5 h-3.5 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer">
                                    <span>Import</span>
                                </label>

                                <!-- 5. Restore (restore) -->
                                <label class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs cursor-pointer transition select-none"
                                       :class="mod.extras.restore 
                                           ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 font-semibold' 
                                           : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50'">
                                    <input type="checkbox" x-model="mod.extras.restore" :disabled="isReadOnly" class="w-3.5 h-3.5 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer">
                                    <span>Restore</span>
                                </label>

                                <!-- 6. Lock (lock_unlock) -->
                                <label class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs cursor-pointer transition select-none"
                                       :class="mod.extras.lock 
                                           ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 font-semibold' 
                                           : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50'">
                                    <input type="checkbox" x-model="mod.extras.lock" :disabled="isReadOnly" class="w-3.5 h-3.5 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer">
                                    <span>Lock</span>
                                </label>
                            </div>

                            <!-- Special Module-Specific Actions -->
                            <template x-if="specialModuleActions && specialModuleActions[mod.key] && Object.keys(specialModuleActions[mod.key]).length > 0">
                                <div class="pt-2 border-t border-dashed border-slate-200 dark:border-slate-700/60 flex items-center gap-2 flex-wrap">
                                    <span class="text-[11px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider mr-1">
                                        Special Actions:
                                    </span>
                                    <template x-for="(actDef, actKey) in specialModuleActions[mod.key]" :key="actKey">
                                        <label class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs cursor-pointer transition select-none"
                                               :class="mod.specials && mod.specials[actKey] 
                                                   ? 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-800 text-indigo-800 dark:text-indigo-300 font-semibold' 
                                                   : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50'">
                                            <input type="checkbox" x-model="mod.specials[actKey]" :disabled="isReadOnly" class="w-3.5 h-3.5 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer">
                                            <span x-text="actDef.label" :title="actDef.desc"></span>
                                        </label>
                                    </template>
                                </div>
                            </template>
                        </div>
                    </div>
                </template>
            </div>

            <!-- Footer Action Bar -->
            <div class="p-4 border-t border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-900/60 flex items-center justify-between gap-3">
                <div class="text-xs text-slate-500 dark:text-slate-400">
                    <span class="font-bold text-indigo-600 dark:text-indigo-400" x-text="accessibleCount"></span> of <?= count($standardModules) ?> modules enabled
                </div>
                <?php if (!$isSelRoleSuper): ?>
                    <button type="submit" 
                            :disabled="isSaving"
                            class="py-2 px-5 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 shadow-sm transition flex items-center gap-2 cursor-pointer">
                        <template x-if="isSaving">
                            <svg class="animate-spin h-3.5 w-3.5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                        </template>
                        <template x-if="!isSaving">
                            <i data-lucide="save" class="w-4 h-4"></i>
                        </template>
                        <span x-text="isSaving ? 'Saving...' : 'Save changes for <?= esc($selectedRole['name'] ?? 'Role') ?>'"></span>
                    </button>
                <?php else: ?>
                    <span class="text-xs text-slate-400 font-medium italic">Read-only system role</span>
                <?php endif; ?>
            </div>
        </div>
    </form>

    <!-- 4. Copy from Role Modal (Reusing existing clone form / route) -->
    <div x-show="openCloneModal" 
         x-cloak 
         class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs"
         @keydown.escape.window="openCloneModal = false">
        <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xl max-w-md w-full p-6 space-y-4" 
             @click.away="openCloneModal = false">
            <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700">
                <h3 class="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <i data-lucide="copy" class="w-5 h-5 text-indigo-600"></i>
                    <span>Copy From Role</span>
                </h3>
                <button type="button" @click="openCloneModal = false" class="text-slate-400 hover:text-slate-600 cursor-pointer">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>

            <form method="POST" action="<?= base_url('users/roles/clone') ?>" class="space-y-4">
                <?= csrf_field() ?>
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Source Role to Copy *</label>
                    <select name="source_role_id" required class="w-full px-3 py-2 text-xs font-medium rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                        <option value="">Select source role...</option>
                        <?php foreach ($roles as $r): ?>
                            <option value="<?= esc($r['id']) ?>" <?= ($r['id'] === $selectedRoleId) ? 'selected' : '' ?>>
                                <?= esc($r['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">New Role Title</label>
                    <input type="text" 
                           name="new_name" 
                           placeholder="<?= esc($selectedRole['name'] ?? 'Role') ?> (Cloned)" 
                           class="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500">
                    <p class="text-[10px] text-slate-400 mt-1">Creates a new role populated with all permissions from the source role.</p>
                </div>

                <div class="pt-2 flex items-center justify-end gap-2">
                    <button type="button" 
                            @click="openCloneModal = false" 
                            class="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer">
                        Cancel
                    </button>
                    <button type="submit" 
                            class="px-4 py-2 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm transition flex items-center gap-1.5 cursor-pointer">
                        <i data-lucide="copy" class="w-4 h-4"></i>
                        <span>Copy Role</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function rbacSimpleManager() {
    return {
        modules: <?= json_encode($initialModules) ?>,
        permCodeToId: <?= json_encode($permCodeToId) ?>,
        specialModuleActions: <?= json_encode($specialModuleActions) ?>,
        isReadOnly: <?= $isSelRoleSuper ? 'true' : 'false' ?>,
        openCloneModal: false,
        searchQuery: '',
        isSaving: false,
        statusMessage: '',
        errorMessage: '',

        init() {
            this.$nextTick(() => {
                if (window.lucide) {
                    window.lucide.createIcons();
                }
            });
        },

        get accessibleCount() {
            return Object.values(this.modules).filter(m => m.level !== 'none' || this.countActiveExtras(m) > 0).length;
        },

        setLevel(modKey, level) {
            if (this.isReadOnly) return;
            if (!this.modules[modKey]) return;
            this.modules[modKey].level = level;
            this.modules[modKey].isCustom = false;
            if (level === 'none') {
                if (this.modules[modKey].extras) {
                    Object.keys(this.modules[modKey].extras).forEach(k => {
                        this.modules[modKey].extras[k] = false;
                    });
                }
                if (this.modules[modKey].specials) {
                    Object.keys(this.modules[modKey].specials).forEach(k => {
                        this.modules[modKey].specials[k] = false;
                    });
                }
            } else if (level === 'full') {
                if (this.modules[modKey].extras) {
                    Object.keys(this.modules[modKey].extras).forEach(k => {
                        this.modules[modKey].extras[k] = true;
                    });
                }
                if (this.modules[modKey].specials) {
                    Object.keys(this.modules[modKey].specials).forEach(k => {
                        this.modules[modKey].specials[k] = true;
                    });
                }
            }
        },

        countActiveExtras(mod) {
            if (!mod) return 0;
            let count = 0;
            if (mod.extras) {
                count += Object.values(mod.extras).filter(Boolean).length;
            }
            if (mod.specials) {
                count += Object.values(mod.specials).filter(Boolean).length;
            }
            return count;
        },

        matchesSearch(mod) {
            if (!this.searchQuery.trim()) return true;
            const q = this.searchQuery.toLowerCase().trim();
            return mod.label.toLowerCase().includes(q) || mod.key.toLowerCase().includes(q);
        },

        saveForm() {
            if (this.isReadOnly || this.isSaving) return;
            document.getElementById('permissionsForm').requestSubmit();
        },

        async submitForm(e) {
            if (this.isReadOnly) {
                e.preventDefault();
                return;
            }
            e.preventDefault();
            this.isSaving = true;
            this.statusMessage = '';
            this.errorMessage = '';

            const form = document.getElementById('permissionsForm');
            const container = this.$refs.hiddenPermInputs;
            container.innerHTML = '';

            const ids = new Set();
            const idToScope = {};
            const codeToScope = {};

            const levelActions = {
                'none': [],
                'view': ['view'],
                'edit': ['view', 'create', 'edit'],
                'full': ['view', 'create', 'edit', 'delete', 'approve', 'reject', 'export', 'export_excel', 'export_pdf', 'print', 'import', 'restore', 'lock_unlock', 'manage']
            };
            const extraActions = {
                'approve': ['approve', 'reject'],
                'export':  ['export', 'export_excel', 'export_pdf'],
                'print':   ['print'],
                'import':  ['import'],
                'restore': ['restore'],
                'lock':    ['lock_unlock', 'manage']
            };

            for (const [modKey, mod] of Object.entries(this.modules)) {
                const modScope = mod.scope || 'company';
                codeToScope[modKey] = modScope;

                if (mod.level === 'full') {
                    // Full gives all available actions for this module in catalog
                    for (const [code, id] of Object.entries(this.permCodeToId)) {
                        if (code === modKey || code.startsWith(`${modKey}.`)) {
                            ids.add(id);
                            idToScope[id] = modScope;
                            codeToScope[code] = modScope;
                        }
                    }
                    continue;
                }

                // Core level actions
                const actions = levelActions[mod.level] || [];
                for (const act of actions) {
                    const code = `${modKey}.${act}`;
                    if (this.permCodeToId[code]) {
                        const id = this.permCodeToId[code];
                        ids.add(id);
                        idToScope[id] = modScope;
                        codeToScope[code] = modScope;
                    }
                }

                // Extra actions
                for (const [extraKey, isEnabled] of Object.entries(mod.extras || {})) {
                    if (isEnabled && extraActions[extraKey]) {
                        for (const act of extraActions[extraKey]) {
                            const code = `${modKey}.${act}`;
                            if (this.permCodeToId[code]) {
                                const id = this.permCodeToId[code];
                                ids.add(id);
                                idToScope[id] = modScope;
                                codeToScope[code] = modScope;
                            }
                        }
                    }
                }

                // Special / granular actions
                for (const [specialKey, isEnabled] of Object.entries(mod.specials || {})) {
                    if (isEnabled) {
                        const code = `${modKey}.${specialKey}`;
                        if (this.permCodeToId[code]) {
                            const id = this.permCodeToId[code];
                            ids.add(id);
                            idToScope[id] = modScope;
                            codeToScope[code] = modScope;
                        }
                    }
                }
            }

            // Append permission IDs and their explicit scopes
            ids.forEach(id => {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'permissions[]';
                input.value = id;
                container.appendChild(input);

                if (idToScope[id]) {
                    const scopeInput = document.createElement('input');
                    scopeInput.type = 'hidden';
                    scopeInput.name = `scopes[${id}]`;
                    scopeInput.value = idToScope[id];
                    container.appendChild(scopeInput);
                }
            });

            // Also post code-based scopes so server has redundant, canonical-proof scope keys
            for (const [codeKey, sVal] of Object.entries(codeToScope)) {
                const scopeInput = document.createElement('input');
                scopeInput.type = 'hidden';
                scopeInput.name = `scopes[${codeKey}]`;
                scopeInput.value = sVal;
                container.appendChild(scopeInput);
            }

            const formData = new FormData(form);

            try {
                const resp = await fetch(form.action, {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'Accept': 'application/json'
                    },
                    body: formData
                });

                const contentType = resp.headers.get('content-type') || '';
                if (contentType.includes('application/json')) {
                    const json = await resp.json();
                    if (json.success) {
                        this.statusMessage = json.message || 'Permissions updated successfully.';
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                    } else {
                        this.errorMessage = json.message || 'Failed to update permissions.';
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                    }
                } else if (resp.ok || resp.redirected) {
                    window.location.reload();
                } else {
                    this.errorMessage = 'Server returned status ' + resp.status + '. Please check server logs or refresh.';
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                }
            } catch (err) {
                console.error('Save permissions AJAX error:', err);
                form.submit();
            } finally {
                this.isSaving = false;
                this.$nextTick(() => {
                    if (window.lucide) window.lucide.createIcons();
                });
            }
        }
    };
}
</script>
