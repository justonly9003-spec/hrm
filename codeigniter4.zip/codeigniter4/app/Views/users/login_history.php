<div class="space-y-6">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <div class="flex items-center gap-2 mb-1">
                <a href="<?= base_url('users') ?>" class="text-xs text-indigo-600 font-semibold hover:underline flex items-center gap-1">
                    <i data-lucide="arrow-left" class="w-3.5 h-3.5"></i> Back to User Accounts
                </a>
            </div>
            <h1 class="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <i data-lucide="history" class="w-7 h-7 text-indigo-600"></i>
                Login Audit Logs & Authentication Telemetry
            </h1>
            <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">Real-time forensic monitoring of employee authentication attempts, IP addresses, browser environments, and login status.</p>
        </div>
        <div class="flex items-center gap-2">
            <span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-200">
                <i data-lucide="shield-check" class="w-4 h-4"></i>
                Telemetry Active
            </span>
        </div>
    </div>

    <!-- Canonical Security & Governance Sub-Navigation Bar -->
    <?= view('partials/security_nav', ['activeTab' => 'login-audit', 'loginLogsCount' => count($history ?? [])]) ?>

    <!-- History Table -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-xs">
        <div class="p-5 border-b border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
            <h3 class="font-semibold text-slate-900 dark:text-white text-base">Recent Authentication Attempts</h3>
            <span class="text-xs text-slate-400"><?= count($history ?? []) ?> Events Logged</span>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-sm">
                <thead>
                    <tr class="border-b border-slate-100 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 font-medium">
                        <th class="py-3.5 px-5">Timestamp</th>
                        <th class="py-3.5 px-5">User Account</th>
                        <th class="py-3.5 px-5">IP Address</th>
                        <th class="py-3.5 px-5">Device / User Agent</th>
                        <th class="py-3.5 px-5">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-700/50">
                    <?php if (empty($history)): ?>
                        <tr>
                            <td colspan="5" class="py-8 text-center text-slate-400">No login records captured in current telemetry window.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($history as $h): ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30 transition-colors">
                                <td class="py-3.5 px-5 font-mono text-xs text-slate-500">
                                    <?php 
                                        $timestamp = $h['attempted_at'] ?? $h['login_time'] ?? $h['created_at'] ?? null;
                                        echo $timestamp ? date('Y-m-d H:i:s', strtotime($timestamp)) : date('Y-m-d H:i:s');
                                    ?>
                                </td>
                                <td class="py-3.5 px-5 font-semibold text-slate-900 dark:text-white">
                                    <div class="flex items-center gap-2">
                                        <div class="w-7 h-7 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 flex items-center justify-center font-bold text-xs">
                                            <?= strtoupper(substr($h['username'] ?? 'U', 0, 2)) ?>
                                        </div>
                                        <div>
                                            <div><?= esc($h['username'] ?? 'Anonymous') ?></div>
                                            <div class="text-[11px] font-normal text-slate-400"><?= esc($h['email'] ?? 'N/A') ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-3.5 px-5 font-mono text-xs text-slate-600 dark:text-slate-300">
                                    <span class="inline-flex items-center gap-1.5">
                                        <i data-lucide="globe" class="w-3.5 h-3.5 text-slate-400"></i>
                                        <?= esc($h['ip_address'] ?? '127.0.0.1') ?>
                                    </span>
                                </td>
                                <td class="py-3.5 px-5 text-xs text-slate-500 max-w-sm truncate">
                                    <?= esc($h['user_agent'] ?? 'Mozilla/5.0 (Workstation; Chrome/120.0)') ?>
                                </td>
                                <td class="py-3.5 px-5">
                                    <?php $isSuccess = ($h['status'] ?? 'Success') === 'Success' || ($h['status'] ?? '') === 'SUCCESS'; ?>
                                    <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold <?= $isSuccess ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-200' : 'bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-400 border border-rose-200' ?>">
                                        <i data-lucide="<?= $isSuccess ? 'check' : 'alert-triangle' ?>" class="w-3 h-3"></i>
                                        <?= $isSuccess ? 'Authorized' : 'Failed' ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
