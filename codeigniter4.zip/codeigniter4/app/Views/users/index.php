<?php
/**
 * User Accounts Management View
 */
$sessionRole = session()->get('role') ?? 'software_app_admin';
$permService = new \App\Services\PermissionService();
$isSoftwareAppAdmin = $permService->isSoftwareAppAdmin($sessionRole);
$canManageSecurity = $permService->canManageSecurity($sessionRole);
$canResetPassword  = $permService->canResetPassword($sessionRole);
$canManageUsers    = $permService->canManageUsers($sessionRole);
$availableRoles    = $availableRoles ?? $roles ?? [];
$editRoles         = $editRoles ?? $availableRoles;

/**
 * Compact helper for role badge classes
 */
function getRoleBadgeStyle(string $role): string {
    $r = strtolower(trim($role));
    $r = str_replace(' ', '_', $r);
    return match ($r) {
        'software_app_admin' => 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300 border-purple-200 dark:border-purple-800',
        'super_admin', 'company_admin' => 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800',
        'hr_manager', 'hr_admin' => 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300 border-blue-200 dark:border-blue-800',
        'dept_head', 'department_head' => 'bg-teal-100 text-teal-800 dark:bg-teal-900/30 dark:text-teal-300 border-teal-200 dark:border-teal-800',
        'line_manager' => 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300 border-amber-200 dark:border-amber-800',
        'employee' => 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
        default => 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-slate-200 dark:border-slate-700',
    };
}
?>
<div class="space-y-6" x-data="userManager()">

    <!-- Top Navigation Submenu -->
    <?= $this->include('partials/security_nav') ?>

    <!-- Flash Messages -->
    <?php if (session()->getFlashdata('message')): ?>
        <div class="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 flex items-center gap-3">
            <i data-lucide="check-circle" class="w-5 h-5 flex-shrink-0 text-emerald-600 dark:text-emerald-400"></i>
            <span class="text-sm font-medium"><?= esc(session()->getFlashdata('message')) ?></span>
        </div>
    <?php endif; ?>
    <?php if (session()->getFlashdata('error')): ?>
        <div class="p-4 rounded-xl bg-rose-50 dark:bg-rose-900/20 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300 flex items-center gap-3">
            <i data-lucide="alert-circle" class="w-5 h-5 flex-shrink-0 text-rose-600 dark:text-rose-400"></i>
            <span class="text-sm font-medium"><?= esc(session()->getFlashdata('error')) ?></span>
        </div>
    <?php endif; ?>

    <!-- Simple Header: Title & Primary Action -->
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
            <h1 class="text-2xl font-bold text-slate-900 dark:text-white">User Accounts</h1>
            <p class="text-sm text-slate-500 dark:text-slate-400 mt-0.5">Manage identity credentials, active roles, and security policies</p>
        </div>
        <?php if ($canManageUsers): ?>
            <button 
                type="button"
                @click="openCreateModal()"
                class="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-medium text-sm rounded-xl shadow-sm transition-all focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2">
                <i data-lucide="user-plus" class="w-4 h-4"></i>
                <span>Add user</span>
            </button>
        <?php endif; ?>
    </div>

    <!-- Filters Section: Search + Role dropdown + Collapsible more filters -->
    <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm space-y-3">
        <div class="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
            <!-- Search Input -->
            <div class="relative flex-1">
                <i data-lucide="search" class="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"></i>
                <input 
                    type="text" 
                    x-model="searchQuery" 
                    placeholder="Search by name, email, or username..." 
                    class="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500">
            </div>

            <!-- Role Dropdown -->
            <div class="w-full md:w-56">
                <select 
                    x-model="selectedRole" 
                    class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    <option value="">All Roles</option>
                    <?php if (!empty($availableRoles)): ?>
                        <?php foreach ($availableRoles as $r): ?>
                            <?php $optVal = esc($r['code'] ?? strtolower(str_replace(' ', '_', $r['name'] ?? ''))); ?>
                            <option value="<?= $optVal ?>"><?= esc($r['name']) ?></option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>

            <!-- More Filters Button & Clear Active Filters -->
            <div class="flex items-center gap-2">
                <button 
                    type="button" 
                    @click="showMoreFilters = !showMoreFilters"
                    :class="showMoreFilters || hasAdvancedFilter ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-900/20 border-indigo-200 dark:border-indigo-800' : 'text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700'"
                    class="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium border rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition">
                    <i data-lucide="sliders-horizontal" class="w-4 h-4"></i>
                    <span>More filters</span>
                    <i data-lucide="chevron-down" class="w-3.5 h-3.5 transition-transform" :class="showMoreFilters ? 'rotate-180' : ''"></i>
                </button>

                <template x-if="isFiltered">
                    <button 
                        type="button" 
                        @click="clearFilters()" 
                        class="text-xs text-rose-600 dark:text-rose-400 hover:underline px-2 py-1">
                        Clear
                    </button>
                </template>
            </div>
        </div>

        <!-- Collapsible More Filters (Status, 2FA) -->
        <div x-show="showMoreFilters" x-collapse style="display: none;" class="pt-3 border-t border-slate-100 dark:border-slate-800/80">
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                <div>
                    <label class="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">Status</label>
                    <select 
                        x-model="selectedStatus" 
                        class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        <option value="">All Statuses</option>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                        <option value="suspended">Suspended</option>
                        <option value="locked">Locked</option>
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">Two-Factor Authentication</label>
                    <select 
                        x-model="selected2fa" 
                        class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        <option value="">All 2FA States</option>
                        <option value="enabled">Enabled</option>
                        <option value="disabled">Disabled</option>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <!-- User Accounts Table -->
    <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="border-b border-slate-200 dark:border-slate-800 bg-slate-50/75 dark:bg-slate-800/40 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                        <th class="py-3.5 px-5">User</th>
                        <th class="py-3.5 px-5">Role</th>
                        <th class="py-3.5 px-5">Status</th>
                        <th class="py-3.5 px-5 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                    <?php if (empty($users)): ?>
                        <tr>
                            <td colspan="4" class="py-12 text-center text-slate-500 dark:text-slate-400">
                                <div class="flex flex-col items-center justify-center gap-2">
                                    <i data-lucide="users" class="w-8 h-8 text-slate-400"></i>
                                    <p class="font-medium">No user records found.</p>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($users as $user): ?>
                            <?php 
                                $uid = (string)($user['id'] ?? '');
                                
                                // Robust multi-layered Full Name resolution
                                $uName = trim((string)($user['name'] ?? ''));
                                if ($uName === '') {
                                    $empFirst = trim((string)($user['first_name'] ?? ''));
                                    $empLast  = trim((string)($user['last_name'] ?? ''));
                                    if ($empFirst !== '' || $empLast !== '') {
                                        $uName = trim($empFirst . ' ' . $empLast);
                                    }
                                }
                                if ($uName === '' && !empty($user['employee_name'])) {
                                    $uName = trim((string)$user['employee_name']);
                                }
                                if ($uName === '' && !empty($user['direct_name'])) {
                                    $uName = trim((string)$user['direct_name']);
                                }
                                if ($uName === '') {
                                    $uName = !empty($user['username']) ? (string)$user['username'] : (!empty($user['email']) ? explode('@', (string)$user['email'])[0] : 'Unknown User');
                                }

                                $uUsername = (string)($user['username'] ?? '');
                                $uEmail = (string)($user['email'] ?? '');
                                $uRole = (string)($user['role_name'] ?? $user['role_code'] ?? $user['role'] ?? 'employee');
                                $uStatus = strtolower((string)($user['status'] ?? 'active'));
                                $u2fa = !empty($user['is_two_factor_enabled']) || !empty($user['two_factor_enabled']) || !empty($user['google2fa_secret']);
                                $isLocked = $uStatus === 'locked' || (!empty($user['locked_until']) && strtotime($user['locked_until']) > time()) || (!empty($user['lockout_until']) && strtotime($user['lockout_until']) > time());
                                $isSuspended = $uStatus === 'suspended';
                                $uAvatar = !empty($user['employee_avatar']) ? (string)$user['employee_avatar'] : (!empty($user['photo']) ? (string)$user['photo'] : null);

                                // 2-letter initials (e.g. Mohammad Adam -> MA, Saddam Hossain -> SH, Istiaq Fuad -> IF)
                                $nameParts = preg_split('/\s+/', $uName, -1, PREG_SPLIT_NO_EMPTY);
                                if (count($nameParts) >= 2) {
                                    $initials = mb_substr($nameParts[0], 0, 1) . mb_substr(end($nameParts), 0, 1);
                                } else {
                                    $initials = mb_substr($uName, 0, 2);
                                }
                                $initials = strtoupper($initials);
                            ?>
                            <tr 
                                x-show="matchesRow('<?= esc($uName, 'js') ?>', '<?= esc($uUsername, 'js') ?>', '<?= esc($uEmail, 'js') ?>', '<?= esc($uRole, 'js') ?>', '<?= esc($uStatus, 'js') ?>', <?= $u2fa ? 'true' : 'false' ?>)"
                                class="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors">
                                <!-- Column 1: User (Name with username and email in smaller second line + 2FA lock icon) -->
                                <td class="py-3.5 px-5">
                                    <div class="flex items-center gap-3">
                                        <div class="w-9 h-9 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center font-bold text-slate-700 dark:text-slate-300 text-xs shrink-0 overflow-hidden">
                                            <?php if (!empty($uAvatar)): ?>
                                                <img src="<?= esc(base_url(ltrim($uAvatar, '/'))) ?>" alt="<?= esc($uName) ?>" class="w-full h-full object-cover" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';" />
                                                <span style="display:none;" class="w-full h-full items-center justify-center font-bold"><?= esc($initials) ?></span>
                                            <?php else: ?>
                                                <span><?= esc($initials) ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="min-w-0">
                                            <div class="flex items-center gap-1.5">
                                                <span class="font-semibold text-slate-900 dark:text-white truncate"><?= esc($uName) ?></span>
                                                <!-- 2FA lock indicator: filled if enabled, subtle outline if not -->
                                                <?php if ($u2fa): ?>
                                                    <span title="Two-Factor Authentication Active" class="inline-flex text-emerald-600 dark:text-emerald-400">
                                                        <i data-lucide="shield-check" class="w-3.5 h-3.5"></i>
                                                    </span>
                                                <?php else: ?>
                                                    <span title="2FA Disabled" class="inline-flex text-slate-300 dark:text-slate-600">
                                                        <i data-lucide="shield-alert" class="w-3.5 h-3.5"></i>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5 truncate">
                                                <span>@<?= esc($uUsername) ?></span>
                                                <span>&bull;</span>
                                                <span class="truncate"><?= esc($uEmail) ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </td>

                                <!-- Column 2: Role badge -->
                                <td class="py-3.5 px-5 whitespace-nowrap">
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border <?= getRoleBadgeStyle($uRole) ?>">
                                        <?= esc(ucwords(str_replace('_', ' ', $uRole))) ?>
                                    </span>
                                </td>

                                <!-- Column 3: Status badge -->
                                <td class="py-3.5 px-5 whitespace-nowrap">
                                    <?php if ($isLocked): ?>
                                        <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-rose-100 text-rose-800 dark:bg-rose-900/30 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
                                            <span class="w-1.5 h-1.5 rounded-full bg-rose-500"></span> Locked
                                        </span>
                                    <?php elseif ($isSuspended): ?>
                                        <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                                            <span class="w-1.5 h-1.5 rounded-full bg-amber-500"></span> Suspended
                                        </span>
                                    <?php elseif ($uStatus === 'inactive'): ?>
                                        <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-400 border border-slate-200 dark:border-slate-700">
                                            <span class="w-1.5 h-1.5 rounded-full bg-slate-400"></span> Inactive
                                        </span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                                            <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Active
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <!-- Column 4: Actions (Primary Edit + More ... menu) -->
                                <td class="py-3.5 px-5 text-right whitespace-nowrap">
                                    <div class="inline-flex items-center justify-end gap-1.5" x-data="{ openMenu: false }">
                                        <!-- Primary Action: Edit -->
                                        <button 
                                            type="button" 
                                            @click="openEditModal(<?= esc(json_encode($user)) ?>)"
                                            class="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition">
                                            <i data-lucide="pencil" class="w-3.5 h-3.5 text-slate-500"></i>
                                            <span>Edit</span>
                                        </button>

                                        <!-- Permissions Override link (if permitted) -->
                                        <?php if ($canManageSecurity): ?>
                                            <a 
                                                href="<?= base_url('users/' . esc($uid) . '/permissions') ?>" 
                                                title="Manage user permission overrides"
                                                class="p-1.5 text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition">
                                                <i data-lucide="key" class="w-4 h-4"></i>
                                            </a>
                                        <?php endif; ?>

                                        <!-- More Actions '...' Dropdown -->
                                        <div class="relative">
                                            <button 
                                                type="button" 
                                                @click="openMenu = !openMenu" 
                                                @click.outside="openMenu = false"
                                                class="p-1.5 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition">
                                                <i data-lucide="more-horizontal" class="w-4 h-4"></i>
                                            </button>

                                            <!-- Dropdown menu -->
                                            <div 
                                                x-show="openMenu" 
                                                x-cloak
                                                @click="openMenu = false"
                                                class="absolute right-0 mt-1 w-48 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-lg py-1.5 z-20 text-left">
                                                
                                                <!-- Reset Password -->
                                                <?php if ($canResetPassword): ?>
                                                    <button 
                                                        type="button"
                                                        @click="triggerResetPassword('<?= esc($uid) ?>', '<?= esc($uName, 'js') ?>')"
                                                        class="w-full flex items-center gap-2 px-3 py-1.5 text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60">
                                                        <i data-lucide="rotate-ccw" class="w-3.5 h-3.5 text-slate-400"></i>
                                                        <span>Reset password</span>
                                                    </button>
                                                <?php endif; ?>

                                                <!-- Unlock or Lock -->
                                                <?php if ($canManageSecurity): ?>
                                                    <?php if ($isLocked): ?>
                                                        <form method="POST" action="<?= base_url('users/unlock/' . esc($uid)) ?>" class="block m-0" onsubmit="return confirm('Unlock user account <?= esc($uName, 'js') ?>?');">
                                                            <?= csrf_field() ?>
                                                            <button type="submit" class="w-full flex items-center gap-2 px-3 py-1.5 text-xs text-emerald-600 dark:text-emerald-400 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-left">
                                                                <i data-lucide="unlock" class="w-3.5 h-3.5"></i>
                                                                <span>Unlock account</span>
                                                            </button>
                                                        </form>
                                                    <?php else: ?>
                                                        <form method="POST" action="<?= base_url('users/lock/' . esc($uid)) ?>" class="block m-0" onsubmit="return confirm('Lock user account <?= esc($uName, 'js') ?>?');">
                                                            <?= csrf_field() ?>
                                                            <button type="submit" class="w-full flex items-center gap-2 px-3 py-1.5 text-xs text-amber-600 dark:text-amber-400 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-left">
                                                                <i data-lucide="lock" class="w-3.5 h-3.5"></i>
                                                                <span>Lock account</span>
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                <?php endif; ?>

                                                <!-- Suspend / Unsuspend -->
                                                <?php if ($canManageUsers): ?>
                                                    <?php if ($isSuspended): ?>
                                                        <form method="POST" action="<?= base_url('users/reactivate/' . esc($uid)) ?>" class="block m-0" onsubmit="return confirm('Reactivate suspended user <?= esc($uName, 'js') ?>?');">
                                                            <?= csrf_field() ?>
                                                            <button type="submit" class="w-full flex items-center gap-2 px-3 py-1.5 text-xs text-emerald-600 dark:text-emerald-400 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-left">
                                                                <i data-lucide="check" class="w-3.5 h-3.5"></i>
                                                                <span>Reactivate user</span>
                                                            </button>
                                                        </form>
                                                    <?php else: ?>
                                                        <form method="POST" action="<?= base_url('users/suspend/' . esc($uid)) ?>" class="block m-0" onsubmit="return confirm('Suspend user <?= esc($uName, 'js') ?>?');">
                                                            <?= csrf_field() ?>
                                                            <button type="submit" class="w-full flex items-center gap-2 px-3 py-1.5 text-xs text-amber-600 dark:text-amber-400 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-left">
                                                                <i data-lucide="pause-circle" class="w-3.5 h-3.5"></i>
                                                                <span>Suspend user</span>
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                <?php endif; ?>

                                                <!-- Reset 2FA -->
                                                <?php if ($u2fa && $canManageSecurity): ?>
                                                    <form method="POST" action="<?= base_url('users/reset-2fa/' . esc($uid)) ?>" class="block m-0" onsubmit="return confirm('Reset 2FA key for <?= esc($uName, 'js') ?>?');">
                                                        <?= csrf_field() ?>
                                                        <button type="submit" class="w-full flex items-center gap-2 px-3 py-1.5 text-xs text-indigo-600 dark:text-indigo-400 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-left">
                                                            <i data-lucide="shield-off" class="w-3.5 h-3.5"></i>
                                                            <span>Reset 2FA</span>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>

                                                <div class="my-1 border-t border-slate-100 dark:border-slate-800"></div>

                                                <!-- Delete -->
                                                <?php if ($canManageUsers): ?>
                                                    <form method="POST" action="<?= base_url('users/delete/' . esc($uid)) ?>" class="block m-0" onsubmit="return confirm('Permanently delete <?= esc($uName, 'js') ?>? This action cannot be reversed.');">
                                                        <?= csrf_field() ?>
                                                        <button type="submit" class="w-full flex items-center gap-2 px-3 py-1.5 text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 text-left">
                                                            <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                                                            <span>Delete user</span>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Create User Modal -->
    <div 
        x-show="showCreateModal" 
        x-cloak 
        class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
        <div 
            @click.outside="showCreateModal = false"
            class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
            
            <div class="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div>
                    <h3 class="text-base font-bold text-slate-900 dark:text-white">Add New User</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Create an authentication identity and role</p>
                </div>
                <button type="button" @click="showCreateModal = false" class="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>

            <form method="POST" action="<?= base_url('users/create') ?>" class="p-5 overflow-y-auto space-y-4">
                <?= csrf_field() ?>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Full Name *</label>
                    <input type="text" name="name" required placeholder="e.g. Jane Doe" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Username *</label>
                        <input type="text" name="username" required placeholder="janedoe" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Email Address *</label>
                        <input type="email" name="email" required placeholder="jane@example.com" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Role *</label>
                        <select name="role" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <?php foreach ($availableRoles as $r): ?>
                                <?php $optVal = esc($r['code'] ?? strtolower(str_replace(' ', '_', $r['name'] ?? ''))); ?>
                                <option value="<?= $optVal ?>" <?= ($optVal === 'employee') ? 'selected' : '' ?>>
                                    <?= esc($r['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Status</label>
                        <select name="status" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Initial Password *</label>
                    <div class="flex gap-2">
                        <input type="text" name="password" x-model="newPassword" required placeholder="Strong password" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono">
                        <button type="button" @click="generatePassword()" class="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-semibold rounded-xl text-slate-700 dark:text-slate-300 shrink-0">
                            Generate
                        </button>
                    </div>
                </div>

                <div class="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                    <button type="button" @click="showCreateModal = false" class="px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800">
                        Cancel
                    </button>
                    <button type="submit" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-medium shadow-sm">
                        Create user
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit User Modal -->
    <div 
        x-show="showEditModal" 
        x-cloak 
        class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
        <div 
            @click.outside="showEditModal = false"
            class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
            
            <div class="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div>
                    <h3 class="text-base font-bold text-slate-900 dark:text-white">Edit User</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400" x-text="editUser.name || 'User details'"></p>
                </div>
                <button type="button" @click="showEditModal = false" class="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>

            <form method="POST" :action="'<?= base_url('users/update') ?>/' + editUser.id" class="p-5 overflow-y-auto space-y-4">
                <?= csrf_field() ?>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Full Name *</label>
                    <input type="text" name="name" x-model="editUser.name" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Username *</label>
                        <input type="text" name="username" x-model="editUser.username" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Email Address *</label>
                        <input type="email" name="email" x-model="editUser.email" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Role *</label>
                        <select name="role" x-model="editUser.role" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <?php foreach ($editRoles as $r): ?>
                                <?php $optVal = esc($r['code'] ?? strtolower(str_replace(' ', '_', $r['name'] ?? ''))); ?>
                                <option value="<?= $optVal ?>">
                                    <?= esc($r['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Status</label>
                        <select name="status" x-model="editUser.status" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                            <option value="suspended">Suspended</option>
                            <option value="locked">Locked</option>
                        </select>
                    </div>
                </div>

                <div class="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                    <button type="button" @click="showEditModal = false" class="px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800">
                        Cancel
                    </button>
                    <button type="submit" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-medium shadow-sm">
                        Save changes
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Reset Password Form (Hidden helper) -->
    <form id="resetPasswordForm" method="POST" action="" class="hidden">
        <?= csrf_field() ?>
    </form>
</div>

<script>
function userManager() {
    return {
        searchQuery: '',
        selectedRole: '',
        selectedStatus: '',
        selected2fa: '',
        showMoreFilters: false,
        showCreateModal: false,
        showEditModal: false,
        newPassword: '',
        editUser: {},

        get hasAdvancedFilter() {
            return this.selectedStatus !== '' || this.selected2fa !== '';
        },

        get isFiltered() {
            return this.searchQuery.trim() !== '' || this.selectedRole !== '' || this.selectedStatus !== '' || this.selected2fa !== '';
        },

        clearFilters() {
            this.searchQuery = '';
            this.selectedRole = '';
            this.selectedStatus = '';
            this.selected2fa = '';
            this.showMoreFilters = false;
        },

        matchesRow(name, username, email, role, status, is2fa) {
            const q = this.searchQuery.toLowerCase().trim();
            if (q) {
                const combined = (name + ' ' + username + ' ' + email).toLowerCase();
                if (!combined.includes(q)) return false;
            }
            if (this.selectedRole) {
                const normRole = (role || '').toString().toLowerCase().replace(/\s+/g, '_');
                const normFilter = (this.selectedRole || '').toString().toLowerCase().replace(/\s+/g, '_');
                if (normRole !== normFilter) return false;
            }
            if (this.selectedStatus) {
                if (status.toLowerCase() !== this.selectedStatus.toLowerCase()) return false;
            }
            if (this.selected2fa) {
                if (this.selected2fa === 'enabled' && !is2fa) return false;
                if (this.selected2fa === 'disabled' && is2fa) return false;
            }
            return true;
        },

        openCreateModal() {
            this.generatePassword();
            this.showCreateModal = true;
            this.$nextTick(() => {
                if (window.lucide) window.lucide.createIcons();
            });
        },

        openEditModal(userData) {
            this.editUser = Object.assign({}, userData);

            const rolesList = <?= json_encode(array_map(function($r) {
                return [
                    'id'   => (string)($r['id'] ?? ''),
                    'code' => strtolower((string)($r['code'] ?? '')),
                    'name' => strtolower((string)($r['name'] ?? '')),
                    'val'  => (string)($r['code'] ?? strtolower(str_replace(' ', '_', $r['name'] ?? ''))),
                ];
            }, $editRoles ?? [])) ?>;

            const targetId = (userData.role_id || '').toString();
            const targetCode = (userData.role_code || '').toString().toLowerCase().trim();
            const targetName = (userData.role_name || userData.role_title || '').toString().toLowerCase().trim();
            const targetRole = (userData.role || '').toString().toLowerCase().trim();

            let matchedRole = rolesList.find(r => r.id && r.id === targetId);
            if (!matchedRole && targetCode) {
                matchedRole = rolesList.find(r => r.code && r.code === targetCode);
            }
            if (!matchedRole && targetRole) {
                matchedRole = rolesList.find(r => 
                    (r.code && r.code === targetRole) ||
                    (r.code && r.code === targetRole.replace(/\s+/g, '_')) ||
                    (r.name && r.name === targetRole)
                );
            }
            if (!matchedRole && targetName) {
                matchedRole = rolesList.find(r => 
                    (r.name && r.name === targetName) ||
                    (r.code && r.code === targetName.replace(/\s+/g, '_'))
                );
            }

            if (matchedRole) {
                this.editUser.role = matchedRole.val;
            } else if (targetCode) {
                this.editUser.role = targetCode;
            } else if (targetRole) {
                this.editUser.role = targetRole.replace(/\s+/g, '_');
            }

            if (this.editUser.status) {
                this.editUser.status = this.editUser.status.toLowerCase();
            }

            this.showEditModal = true;
            this.$nextTick(() => {
                if (window.lucide) window.lucide.createIcons();
            });
        },

        generatePassword() {
            const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*';
            let pass = '';
            for (let i = 0; i < 14; i++) {
                pass += chars.charAt(Math.floor(Math.random() * chars.length));
            }
            this.newPassword = pass;
        },

        triggerResetPassword(userId, userName) {
            if (confirm('Send or generate a password reset for ' + userName + '?')) {
                const form = document.getElementById('resetPasswordForm');
                form.action = '<?= base_url('users/reset-password') ?>/' + userId;
                form.submit();
            }
        }
    };
}

document.addEventListener('DOMContentLoaded', function() {
    if (window.lucide) {
        window.lucide.createIcons();
    }
});
</script>
