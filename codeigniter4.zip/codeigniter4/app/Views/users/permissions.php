<?php
/**
 * User Permission Overrides Management View
 */
$permService = new \App\Services\PermissionService();
$sessionRole = session()->get('role') ?? 'software_app_admin';
$canManageSecurity = $permService->canManageSecurity($sessionRole);
$isSoftwareAppAdmin = $permService->isSoftwareAppAdmin($sessionRole);

$allModules = [
    'dashboard'   => 'Dashboard & Analytics',
    'directory'   => 'Directory & Staff Profiles',
    'attendance'  => 'Attendance & Time Tracking',
    'leaves'      => 'Leave Management & Holidays',
    'rostering'   => 'Shifts & Rostering',
    'payroll'     => 'Payroll & Compensation',
    'bonus'       => 'Bonus & Incentives',
    'loans'       => 'Loans & Salary Advances',
    'assets'      => 'Asset Management',
    'training'    => 'Training & Development',
    'performance' => 'Performance & Appraisals',
    'recruitment' => 'Recruitment & ATS',
    'notices'     => 'Notice Board & Bulletins',
    'reports'     => 'Reports & Analytics',
    'rules'       => 'Business Rules & Engine',
    'master'      => 'Master Data',
    'settings'    => 'System Settings & Governance',
    'audit'       => 'Audit Logs & Governance',
    'backups'     => 'Backups & Maintenance',
];

$extraActionDefs = [
    'approve' => ['label' => 'Approve', 'actions' => ['approve', 'reject']],
    'export'  => ['label' => 'Export',  'actions' => ['export_excel', 'export_pdf']],
    'print'   => ['label' => 'Print',   'actions' => ['print']],
    'import'  => ['label' => 'Import',  'actions' => ['import']],
    'restore' => ['label' => 'Restore', 'actions' => ['restore']],
    'lock'    => ['label' => 'Lock',    'actions' => ['lock_unlock']],
];

// Helper to determine the baseline role level
function computeRoleModuleLevel(string $module, array $assignedPermCodes, \App\Services\PermissionService $permService): string {
    $checkAction = function(string $act) use ($module, $assignedPermCodes, $permService): bool {
        $rawCode = "{$module}.{$act}";
        if (in_array($rawCode, $assignedPermCodes, true)) {
            return true;
        }
        $norm = $permService->normalizePermission($rawCode);
        if (in_array($norm['code'], $assignedPermCodes, true)) {
            return true;
        }
        if ($module === 'directory' && (in_array("employees.{$act}", $assignedPermCodes, true) || in_array("employee.{$act}", $assignedPermCodes, true))) {
            return true;
        }
        if ($module === 'leaves' && in_array("leave.{$act}", $assignedPermCodes, true)) {
            return true;
        }
        if ($module === 'rostering' && (in_array("shift.{$act}", $assignedPermCodes, true) || in_array("roster.{$act}", $assignedPermCodes, true))) {
            return true;
        }
        if ($module === 'loans' && in_array("loan.{$act}", $assignedPermCodes, true)) {
            return true;
        }
        if ($module === 'assets' && in_array("asset.{$act}", $assignedPermCodes, true)) {
            return true;
        }
        return false;
    };

    $hasView = $checkAction('view');
    $hasCreate = $checkAction('create');
    $hasEdit = $checkAction('edit');
    $hasDelete = $checkAction('delete');

    if ($hasView && $hasCreate && $hasEdit && $hasDelete) return 'full';
    if ($hasView && $hasCreate && $hasEdit) return 'edit';
    if ($hasView) return 'view';
    return 'none';
}

// Helper to retrieve user override for a module action
$getOverride = function(string $mod, string $act) use ($userOverrides, $permService): ?array {
    if (empty($userOverrides)) return null;
    $codes = ["{$mod}.{$act}"];
    $norm = $permService->normalizePermission("{$mod}.{$act}");
    if (!in_array($norm['code'], $codes, true)) {
        $codes[] = $norm['code'];
    }
    if ($mod === 'directory') {
        $codes[] = "employees.{$act}";
        $codes[] = "employee.{$act}";
    } elseif ($mod === 'leaves') {
        $codes[] = "leave.{$act}";
    } elseif ($mod === 'rostering') {
        $codes[] = "shift.{$act}";
        $codes[] = "shifts.{$act}";
        $codes[] = "roster.{$act}";
    } elseif ($mod === 'loans') {
        $codes[] = "loan.{$act}";
    } elseif ($mod === 'assets') {
        $codes[] = "asset.{$act}";
    }

    foreach ($codes as $c) {
        if (isset($userOverrides[$c])) {
            return is_array($userOverrides[$c]) ? $userOverrides[$c] : ['action' => (string)$userOverrides[$c]];
        }
    }
    return null;
};

// Compute initial state per module
$moduleStates = [];
$permMapLookup = []; // "module.action" -> [id, code]

if (!empty($allPermissions)) {
    foreach ($allPermissions as $p) {
        $code = (string)($p['code'] ?? '');
        $permMapLookup[$code] = [
            'id' => (string)($p['id'] ?? md5($code)),
            'code' => $code,
            'name' => (string)($p['name'] ?? $code),
        ];
    }
}

foreach (array_keys($allModules) as $mod) {
    $roleLevel = computeRoleModuleLevel($mod, $assignedPermCodes ?? [], $permService);
    
    // Check if user has explicit overrides on this module
    $userOverrideLevel = 'inherit';
    $isCustomExtra = false;
    
    // Actions map for extra permissions
    $extras = [
        'approve' => 'inherit',
        'export'  => 'inherit',
        'print'   => 'inherit',
        'import'  => 'inherit',
        'restore' => 'inherit',
        'lock'    => 'inherit',
    ];

    $scopeLevel = 'inherit';
    $branchScope = '';
    $deptScope = '';

    // Inspect userOverrides
    if (!empty($userOverrides)) {
        // Extra action states evaluated first so module level can reference them
        foreach ($extraActionDefs as $exKey => $exDef) {
            foreach ($exDef['actions'] as $subAct) {
                $ov = $getOverride($mod, $subAct);
                if ($ov) {
                    $st = $ov['action'] ?? $ov['state'] ?? 'inherit';
                    if ($st !== 'inherit') {
                        $extras[$exKey] = $st;
                        $isCustomExtra = true;
                        break;
                    }
                }
            }
        }

        // Core CRUD
        $viewAction   = $getOverride($mod, 'view');
        $createAction = $getOverride($mod, 'create');
        $editAction   = $getOverride($mod, 'edit');
        $deleteAction = $getOverride($mod, 'delete');

        $viewState   = $viewAction['action'] ?? $viewAction['state'] ?? 'inherit';
        $createState = $createAction['action'] ?? $createAction['state'] ?? 'inherit';
        $editState   = $editAction['action'] ?? $editAction['state'] ?? 'inherit';
        $deleteState = $deleteAction['action'] ?? $deleteAction['state'] ?? 'inherit';

        // Extract scope if configured on any action
        foreach ([$viewAction, $createAction, $editAction, $deleteAction] as $actObj) {
            if (!empty($actObj['scope']) || !empty($actObj['scope_level'])) {
                $scopeLevel = $actObj['scope'] ?? $actObj['scope_level'];
                $branchScope = $actObj['branch_id'] ?? ($scopeLevel === 'branch' ? ($actObj['scope_id'] ?? '') : '');
                $deptScope = $actObj['department_id'] ?? ($scopeLevel === 'department' ? ($actObj['scope_id'] ?? '') : '');
                break;
            }
        }

        // Determine if CRUD is overridden
        $hasAnyOverride = ($viewState !== 'inherit' || $createState !== 'inherit' || $editState !== 'inherit' || $deleteState !== 'inherit');
        
        if ($hasAnyOverride) {
            if ($viewState === 'deny') {
                $userOverrideLevel = 'none';
            } elseif ($viewState === 'grant') {
                if ($deleteState === 'grant') {
                    $userOverrideLevel = 'full';
                } elseif ($editState === 'grant' && $createState === 'grant') {
                    $userOverrideLevel = ($deleteState === 'deny') ? 'edit' : 'full';
                } elseif ($editState === 'grant' || $createState === 'grant') {
                    $userOverrideLevel = 'edit';
                } else {
                    $allExtrasGrant = true;
                    $hasConfiguredExtra = false;
                    foreach ($extras as $exVal) {
                        if ($exVal !== 'inherit') $hasConfiguredExtra = true;
                        if ($exVal !== 'grant') $allExtrasGrant = false;
                    }
                    if ($hasConfiguredExtra && $allExtrasGrant) {
                        $userOverrideLevel = 'full';
                    } else {
                        $userOverrideLevel = 'view';
                    }
                }
            } elseif ($deleteState === 'deny' || $editState === 'deny') {
                $userOverrideLevel = 'none';
            }
        }
    }

    $moduleStates[$mod] = [
        'module' => $mod,
        'label'  => $allModules[$mod],
        'roleLevel' => $roleLevel, // none, view, edit, full
        'overrideLevel' => $userOverrideLevel, // inherit, none, view, edit, full
        'extras' => $extras,
        'scope' => $scopeLevel,
        'branch_id' => $branchScope,
        'department_id' => $deptScope,
        'expanded' => false,
    ];
}
?>
<div class="space-y-6" x-data="userPermissionsManager(<?= esc(json_encode($moduleStates), 'html') ?>, <?= esc(json_encode($permMapLookup), 'html') ?>)">

    <!-- Top Navigation Submenu -->
    <?= $this->include('partials/security_nav') ?>

    <!-- Flash Messages -->
    <?php if (session()->getFlashdata('message')): ?>
        <div class="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 flex items-center gap-3">
            <i data-lucide="check-circle" class="w-5 h-5 flex-shrink-0 text-emerald-600 dark:text-emerald-400"></i>
            <span class="text-sm font-medium"><?= esc(session()->getFlashdata('message')) ?></span>
        </div>
    <?php endif; ?>
    <?php if (session()->getFlashdata('error')): ?>
        <div class="p-4 rounded-xl bg-rose-50 dark:bg-rose-900/20 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300 flex items-center gap-3">
            <i data-lucide="alert-circle" class="w-5 h-5 flex-shrink-0 text-rose-600 dark:text-rose-400"></i>
            <span class="text-sm font-medium"><?= esc(session()->getFlashdata('error')) ?></span>
        </div>
    <?php endif; ?>

    <!-- Top Header Bar: User Info, Role & Save Button -->
    <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div class="flex items-center gap-3.5">
                <a href="<?= base_url('users') ?>" class="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition">
                    <i data-lucide="arrow-left" class="w-5 h-5"></i>
                </a>
                <div class="w-10 h-10 rounded-full bg-indigo-50 dark:bg-indigo-900/30 border border-indigo-100 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 font-bold flex items-center justify-center text-sm shrink-0">
                    <?= esc(strtoupper(substr($targetUser['name'] ?? 'U', 0, 2))) ?>
                </div>
                <div>
                    <div class="flex items-center gap-2">
                        <h1 class="text-lg font-bold text-slate-900 dark:text-white"><?= esc($targetUser['name'] ?? 'User') ?></h1>
                        <span class="px-2 py-0.5 rounded-full text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                            <?= esc(ucwords(str_replace('_', ' ', $targetUser['role'] ?? 'employee'))) ?>
                        </span>
                    </div>
                    <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                        <span>@<?= esc($targetUser['username'] ?? '') ?></span>
                        <span class="mx-1">&bull;</span>
                        <span><?= esc($targetUser['email'] ?? '') ?></span>
                    </p>
                </div>
            </div>

            <div class="flex items-center gap-3">
                <div class="text-xs text-slate-500 dark:text-slate-400 hidden sm:block">
                    <span x-text="overriddenCount"></span> overridden
                </div>
                <?php if ($canManageSecurity): ?>
                    <button 
                        type="button" 
                        @click="saveOverrides()"
                        :disabled="isSaving"
                        class="inline-flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-sm rounded-xl shadow-sm transition disabled:opacity-50">
                        <i data-lucide="save" class="w-4 h-4" x-show="!isSaving"></i>
                        <span x-show="isSaving">Saving...</span>
                        <span x-show="!isSaving">Save</span>
                    </button>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Hidden Form for standard fallback submission -->
    <form id="overrideForm" method="POST" action="<?= base_url('users/permissions/save') ?>" class="hidden">
        <?= csrf_field() ?>
        <input type="hidden" name="user_id" value="<?= esc($targetUser['id'] ?? '') ?>">
    </form>

    <!-- Default View: Simple Module List -->
    <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
        <div class="p-4 border-b border-slate-100 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-800/30 flex items-center justify-between">
            <div>
                <h2 class="text-sm font-bold text-slate-900 dark:text-white">Module Access Overrides</h2>
                <p class="text-xs text-slate-500 dark:text-slate-400">Override role defaults per module or configure custom scope</p>
            </div>
            <div class="flex items-center gap-2.5">
                <button 
                    type="button" 
                    @click="setAllModulesLevel('full')"
                    class="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300 hover:underline">
                    Set all to Full access
                </button>
                <span class="text-slate-300 dark:text-slate-700">&bull;</span>
                <button 
                    type="button" 
                    @click="resetAllToRole()"
                    class="text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-400 hover:underline">
                    Reset all to role defaults
                </button>
            </div>
        </div>

        <div class="divide-y divide-slate-100 dark:divide-slate-800">
            <template x-for="(mod, modKey) in modules" :key="modKey">
                <div class="p-4 transition hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <!-- Left: Module Name + Overridden Dot + Role default text -->
                        <div class="flex items-center gap-3">
                            <span 
                                class="w-2.5 h-2.5 rounded-full shrink-0" 
                                :class="isModuleOverridden(modKey) ? 'bg-amber-500 ring-4 ring-amber-100 dark:ring-amber-900/30' : 'bg-transparent'"
                                :title="isModuleOverridden(modKey) ? 'User access differs from role' : ''"></span>
                            
                            <div>
                                <div class="flex items-center gap-2">
                                    <span class="text-sm font-semibold text-slate-900 dark:text-white" x-text="mod.label"></span>
                                    <span 
                                        x-show="isModuleOverridden(modKey)" 
                                        class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                                        Overridden
                                    </span>
                                </div>
                                <div class="text-xs text-slate-500 dark:text-slate-400 mt-0.5 flex items-center gap-1.5">
                                    <span>From role:</span>
                                    <span class="font-medium text-slate-700 dark:text-slate-300" x-text="formatLevelName(mod.roleLevel)"></span>
                                </div>
                            </div>
                        </div>

                        <!-- Right: Single Dropdown + Advanced button -->
                        <div class="flex items-center gap-3">
                            <!-- Dropdown for access level -->
                            <div class="w-44">
                                <select 
                                    x-model="mod.overrideLevel" 
                                    class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                    :class="mod.overrideLevel !== 'inherit' ? 'border-amber-300 dark:border-amber-700 font-bold text-amber-800 dark:text-amber-300' : ''">
                                    <option value="inherit">Same as role</option>
                                    <option value="none">None</option>
                                    <option value="view">View</option>
                                    <option value="edit">Edit</option>
                                    <option value="full">Full</option>
                                </select>
                            </div>

                            <!-- Advanced Expand/Collapse Button -->
                            <button 
                                type="button" 
                                @click="mod.expanded = !mod.expanded" 
                                class="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition">
                                <span>Advanced</span>
                                <i data-lucide="chevron-down" class="w-3.5 h-3.5 transition-transform" :class="mod.expanded ? 'rotate-180' : ''"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Collapsible Advanced Section: Extra Actions + Branch/Dept Scope -->
                    <div x-show="mod.expanded" x-collapse style="display: none;" class="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 space-y-4">
                        <!-- Extra Actions -->
                        <div>
                            <div class="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">Extra Permissions</div>
                            <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
                                <template x-for="(actionItem, actKey) in extraActions" :key="actKey">
                                    <div class="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/40">
                                        <div class="text-xs font-medium text-slate-800 dark:text-slate-200 mb-1.5" x-text="actionItem.label"></div>
                                        <select 
                                            x-model="mod.extras[actKey]" 
                                            class="w-full px-2 py-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-[11px] text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500">
                                            <option value="inherit">Inherit</option>
                                            <option value="grant">Grant</option>
                                            <option value="deny">Deny</option>
                                        </select>
                                    </div>
                                </template>
                            </div>
                        </div>

                        <!-- Data Scope Controls (Branch / Department) -->
                        <div class="p-3 rounded-xl bg-slate-50/75 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-3">
                            <div class="text-xs font-semibold text-slate-700 dark:text-slate-300">Data Visibility Scope</div>
                            <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                                <div>
                                    <label class="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">Scope Level</label>
                                    <select 
                                        x-model="mod.scope" 
                                        class="w-full px-2.5 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-indigo-500">
                                        <option value="inherit">Inherit from role</option>
                                        <option value="company">Company (Full)</option>
                                        <option value="branch">Branch Only</option>
                                        <option value="department">Department Only</option>
                                        <option value="team">Team Only</option>
                                        <option value="self">Self (Own records only)</option>
                                    </select>
                                </div>
                                <div x-show="mod.scope === 'branch'">
                                    <label class="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">Branch ID</label>
                                    <input 
                                        type="text" 
                                        x-model="mod.branch_id" 
                                        placeholder="e.g. BR-001" 
                                        class="w-full px-2.5 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-indigo-500">
                                </div>
                                <div x-show="mod.scope === 'department'">
                                    <label class="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">Department ID</label>
                                    <input 
                                        type="text" 
                                        x-model="mod.department_id" 
                                        placeholder="e.g. DEP-002" 
                                        class="w-full px-2.5 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-indigo-500">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </template>
        </div>
    </div>

    <!-- Collapsible Bottom Section: Check Access (Effective Permissions + Trace Inspector) -->
    <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden" x-data="{ openCheckAccess: false }">
        <button 
            type="button" 
            @click="openCheckAccess = !openCheckAccess" 
            class="w-full p-4 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/40 transition text-left">
            <div class="flex items-center gap-2.5">
                <i data-lucide="shield-alert" class="w-4 h-4 text-indigo-600 dark:text-indigo-400"></i>
                <span class="text-sm font-bold text-slate-900 dark:text-white">Check Access</span>
                <span class="text-xs text-slate-500 dark:text-slate-400">Inspect effective permissions and trace decision paths</span>
            </div>
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 transition-transform" :class="openCheckAccess ? 'rotate-180' : ''"></i>
        </button>

        <div x-show="openCheckAccess" x-collapse style="display: none;" class="p-5 border-t border-slate-100 dark:border-slate-800 space-y-6">
            <!-- Fast Metrics / Summary -->
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                <div class="p-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl">
                    <div class="text-xs text-slate-500 dark:text-slate-400">Role Base Perms</div>
                    <div class="text-lg font-bold text-slate-900 dark:text-white"><?= count($assignedPermCodes ?? []) ?></div>
                </div>
                <div class="p-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl">
                    <div class="text-xs text-slate-500 dark:text-slate-400">Active Overrides</div>
                    <div class="text-lg font-bold text-amber-600 dark:text-amber-400" x-text="overriddenCount"></div>
                </div>
                <div class="p-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl">
                    <div class="text-xs text-slate-500 dark:text-slate-400">Available Modules</div>
                    <div class="text-lg font-bold text-slate-900 dark:text-white"><?= count($allModules) ?></div>
                </div>
                <div class="p-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl">
                    <div class="text-xs text-slate-500 dark:text-slate-400">Account Status</div>
                    <div class="text-lg font-bold text-emerald-600 dark:text-emerald-400"><?= esc(ucfirst($targetUser['status'] ?? 'Active')) ?></div>
                </div>
            </div>

            <!-- Permission Trace Inspector Tool -->
            <div class="p-4 bg-slate-50/75 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 rounded-xl space-y-3">
                <div class="text-xs font-bold text-slate-900 dark:text-white">Live Access Resolver Test</div>
                <div class="flex flex-col sm:flex-row gap-2">
                    <input 
                        type="text" 
                        x-model="inspectCode" 
                        placeholder="e.g. payroll.edit or attendance.approve" 
                        class="flex-1 px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    <button 
                        type="button" 
                        @click="runAccessCheck()"
                        class="px-4 py-2 bg-slate-800 dark:bg-slate-700 text-white rounded-xl text-xs font-semibold hover:bg-slate-700 transition shrink-0">
                        Check Permission
                    </button>
                </div>

                <!-- Result Box -->
                <template x-if="checkResult">
                    <div class="p-3 rounded-lg border text-xs" :class="checkResult.granted ? 'bg-emerald-50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200' : 'bg-rose-50 dark:bg-rose-950/20 border-rose-200 dark:border-rose-800 text-rose-900 dark:text-rose-200'">
                        <div class="flex items-center gap-1.5 font-bold mb-1">
                            <span x-text="checkResult.granted ? 'GRANTED' : 'DENIED'"></span>
                            <span>&bull;</span>
                            <span x-text="checkResult.code"></span>
                        </div>
                        <p class="text-[11px]" x-text="checkResult.reason"></p>
                    </div>
                </template>
            </div>
        </div>
    </div>
</div>

<script>
function userPermissionsManager(initialModules, permLookup) {
    return {
        modules: initialModules,
        permLookup: permLookup || {},
        isSaving: false,
        inspectCode: 'payroll.edit',
        checkResult: null,

        extraActions: {
            'approve': { label: 'Approve / Reject' },
            'export':  { label: 'Export' },
            'print':   { label: 'Print' },
            'import':  { label: 'Import' },
            'restore': { label: 'Restore' },
            'lock':    { label: 'Lock / Unlock' }
        },

        get overriddenCount() {
            let count = 0;
            for (const key in this.modules) {
                if (this.isModuleOverridden(key)) {
                    count++;
                }
            }
            return count;
        },

        isModuleOverridden(modKey) {
            const m = this.modules[modKey];
            if (!m) return false;
            if (m.overrideLevel !== 'inherit') return true;
            if (m.scope !== 'inherit') return true;
            for (const act in m.extras) {
                if (m.extras[act] !== 'inherit') return true;
            }
            return false;
        },

        formatLevelName(lvl) {
            switch(lvl) {
                case 'none': return 'None';
                case 'view': return 'View';
                case 'edit': return 'Edit';
                case 'full': return 'Full';
                default: return 'None';
            }
        },

        resetAllToRole() {
            if (confirm('Reset all overrides to match role defaults?')) {
                for (const key in this.modules) {
                    this.modules[key].overrideLevel = 'inherit';
                    this.modules[key].scope = 'inherit';
                    this.modules[key].branch_id = '';
                    this.modules[key].department_id = '';
                    for (const act in this.modules[key].extras) {
                        this.modules[key].extras[act] = 'inherit';
                    }
                }
            }
        },

        buildOverridesPayload() {
            const overrides = {};
            const actionMapping = {
                'view':   ['view'],
                'create': ['create'],
                'edit':   ['edit'],
                'delete': ['delete'],
            };

            const extraActionMap = {
                'approve': ['approve', 'reject'],
                'export':  ['export_excel', 'export_pdf'],
                'print':   ['print'],
                'import':  ['import'],
                'restore': ['restore'],
                'lock':    ['lock_unlock']
            };

            for (const modKey in this.modules) {
                const m = this.modules[modKey];
                const level = m.overrideLevel;
                const scope = (m.scope && m.scope !== 'inherit') ? m.scope : 'company';
                const branchId = m.branch_id || null;
                const deptId = m.department_id || null;
                const scopeId = (scope === 'branch') ? branchId : ((scope === 'department') ? deptId : null);

                // CRUD mapping
                if (level !== 'inherit') {
                    const crudStatuses = {
                        view: 'inherit',
                        create: 'inherit',
                        edit: 'inherit',
                        delete: 'inherit'
                    };

                    if (level === 'none') {
                        crudStatuses.view = 'deny';
                        crudStatuses.create = 'deny';
                        crudStatuses.edit = 'deny';
                        crudStatuses.delete = 'deny';
                    } else if (level === 'view') {
                        crudStatuses.view = 'grant';
                        crudStatuses.create = 'deny';
                        crudStatuses.edit = 'deny';
                        crudStatuses.delete = 'deny';
                    } else if (level === 'edit') {
                        crudStatuses.view = 'grant';
                        crudStatuses.create = 'grant';
                        crudStatuses.edit = 'grant';
                        crudStatuses.delete = 'deny';
                    } else if (level === 'full') {
                        crudStatuses.view = 'grant';
                        crudStatuses.create = 'grant';
                        crudStatuses.edit = 'grant';
                        crudStatuses.delete = 'grant';
                    }

                    for (const act in crudStatuses) {
                        const code = modKey + '.' + act;
                        overrides[code] = {
                            action: crudStatuses[act],
                            state: crudStatuses[act],
                            scope_level: scope,
                            scope: scope,
                            scope_id: scopeId,
                            branch_id: branchId,
                            department_id: deptId
                        };
                    }
                } else {
                    // Level is inherit: send inherit so existing override records are cleared
                    ['view', 'create', 'edit', 'delete'].forEach(act => {
                        const code = modKey + '.' + act;
                        overrides[code] = {
                            action: 'inherit',
                            state: 'inherit'
                        };
                    });
                }

                // Extra actions
                for (const exKey in m.extras) {
                    const exState = m.extras[exKey];
                    const subActions = extraActionMap[exKey] || [exKey];
                    subActions.forEach(subAct => {
                        const code = modKey + '.' + subAct;
                        overrides[code] = {
                            action: exState,
                            state: exState,
                            scope_level: scope,
                            scope: scope,
                            scope_id: scopeId,
                            branch_id: branchId,
                            department_id: deptId
                        };
                    });
                }
            }

            return overrides;
        },

        setAllModulesLevel(targetLevel) {
            const nextModules = JSON.parse(JSON.stringify(this.modules));
            for (const modKey in nextModules) {
                nextModules[modKey].overrideLevel = targetLevel;
                if (targetLevel === 'full') {
                    for (const exKey in nextModules[modKey].extras) {
                        nextModules[modKey].extras[exKey] = 'grant';
                    }
                } else if (targetLevel === 'none') {
                    for (const exKey in nextModules[modKey].extras) {
                        nextModules[modKey].extras[exKey] = 'deny';
                    }
                } else if (targetLevel === 'inherit') {
                    for (const exKey in nextModules[modKey].extras) {
                        nextModules[modKey].extras[exKey] = 'inherit';
                    }
                }
            }
            this.modules = nextModules;
        },

        resetAllToRole() {
            if (confirm('Reset all overrides to match role defaults?')) {
                const nextModules = JSON.parse(JSON.stringify(this.modules));
                for (const key in nextModules) {
                    nextModules[key].overrideLevel = 'inherit';
                    nextModules[key].scope = 'inherit';
                    nextModules[key].branch_id = '';
                    nextModules[key].department_id = '';
                    for (const act in nextModules[key].extras) {
                        nextModules[key].extras[act] = 'inherit';
                    }
                }
                this.modules = nextModules;
            }
        },

        saveOverrides() {
            this.isSaving = true;
            const overrides = this.buildOverridesPayload();
            const form = document.getElementById('overrideForm');
            const targetUrl = form.action;

            fetch(targetUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': '<?= csrf_hash() ?>',
                    '<?= csrf_token() ?>': '<?= csrf_hash() ?>'
                },
                body: JSON.stringify({
                    '<?= csrf_token() ?>': '<?= csrf_hash() ?>',
                    user_id: '<?= esc($targetUser['id'] ?? '') ?>',
                    overrides: overrides
                })
            })
            .then(res => res.json())
            .then(data => {
                this.isSaving = false;
                if (data.success) {
                    window.location.reload();
                } else {
                    alert(data.message || 'Failed to save user overrides.');
                }
            })
            .catch(err => {
                // If JSON fails, submit via normal form post with CSRF token
                form.querySelectorAll('input[name^="overrides"]').forEach(el => el.remove());
                for (const [code, val] of Object.entries(overrides)) {
                    const input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = `overrides[${code}][action]`;
                    input.value = typeof val === 'object' ? (val.action || val.state) : val;
                    form.appendChild(input);

                    if (typeof val === 'object' && val.scope_level) {
                        const scInput = document.createElement('input');
                        scInput.type = 'hidden';
                        scInput.name = `overrides[${code}][scope_level]`;
                        scInput.value = val.scope_level;
                        form.appendChild(scInput);
                    }
                    if (typeof val === 'object' && val.scope_id) {
                        const sidInput = document.createElement('input');
                        sidInput.type = 'hidden';
                        sidInput.name = `overrides[${code}][scope_id]`;
                        sidInput.value = val.scope_id;
                        form.appendChild(sidInput);
                    }
                }
                form.submit();
            });
        },

        runAccessCheck() {
            const code = this.inspectCode.trim().toLowerCase();
            if (!code) return;
            const [mod, act] = code.split('.');
            const m = this.modules[mod];

            if (!m) {
                this.checkResult = {
                    code: code,
                    granted: false,
                    reason: 'Module does not exist in standard modules dictionary.'
                };
                return;
            }

            // Check override
            const overrideLvl = m.overrideLevel;
            if (overrideLvl !== 'inherit') {
                if (overrideLvl === 'none') {
                    this.checkResult = { code, granted: false, reason: 'Explicit user-level override: DENIED (Level: None)' };
                    return;
                }
                if (overrideLvl === 'view') {
                    const ok = (act === 'view');
                    this.checkResult = { code, granted: ok, reason: ok ? 'Explicit user override: GRANTED (View only)' : 'Denied by user override: Level is View only' };
                    return;
                }
                if (overrideLvl === 'edit') {
                    const ok = ['view', 'create', 'edit'].includes(act);
                    this.checkResult = { code, granted: ok, reason: ok ? 'Explicit user override: GRANTED (Edit level)' : 'Denied by user override: Level is Edit (no delete)' };
                    return;
                }
                if (overrideLvl === 'full') {
                    const ok = ['view', 'create', 'edit', 'delete'].includes(act);
                    this.checkResult = { code, granted: ok, reason: ok ? 'Explicit user override: GRANTED (Full access)' : 'Check extra actions' };
                    return;
                }
            }

            // Fallback to role
            const roleLvl = m.roleLevel;
            let roleOk = false;
            if (roleLvl === 'full') roleOk = ['view', 'create', 'edit', 'delete'].includes(act);
            else if (roleLvl === 'edit') roleOk = ['view', 'create', 'edit'].includes(act);
            else if (roleLvl === 'view') roleOk = (act === 'view');

            this.checkResult = {
                code,
                granted: roleOk,
                reason: roleOk ? `Inherited from role '${roleLvl}' baseline` : `Not granted by role '${roleLvl}'`
            };
        }
    };
}

document.addEventListener('DOMContentLoaded', function() {
    if (window.lucide) {
        window.lucide.createIcons();
    }
});
</script>
